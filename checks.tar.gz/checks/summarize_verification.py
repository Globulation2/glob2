from pathlib import Path
import json,xml.etree.ElementTree as E,shutil,tarfile,hashlib
root=Path('/dev/shm/glob2-air-evidence');out=Path('/dev/shm/glob2-air-publish')
reports=['engine','unit','final-routing','final-unit','final-acceptance','timeout-rerun','timeout-final','lan-timing','lan-release','slow-release','generator-release','golden-match','resource-golden']
summary={};passes={}
for name in reports:
 p=root/(name+'.xml')
 if not p.exists():continue
 cases=list(E.parse(p).iter('testcase'));failed=[];skipped=0;passed=0
 for c in cases:
  if c.find('skipped') is not None:skipped+=1
  elif c.find('failure') is not None or c.find('error') is not None:failed.append(c.attrib['name'])
  else:passed+=1;passes.setdefault(c.attrib['name'],[]).append(name)
 summary[name]={'passed':passed,'failed':len(failed),'skipped':skipped,'failed_cases':failed}
renamed={'flyers share safety fields across teams and ignore ground invalidations':'flyers share safety by team and obey forbidden paint while ignoring ground blockers'}
ledger=[{'initial_failure':name,'passing_followups':passes.get(renamed.get(name,name),[])} for name in summary['engine']['failed_cases']]
(root/'reconciliation.json').write_text(json.dumps({'reports':summary,'initial_engine_failure_followups':ledger,'unresolved_engine_cases':[r['initial_failure'] for r in ledger if not r['passing_followups']]},indent=2)+'\n')
print(json.dumps({'unresolved_engine_cases':[r['initial_failure'] for r in ledger if not r['passing_followups']]},indent=2))
if any(not r['passing_followups'] for r in ledger):raise SystemExit('Await remaining rerun before publication')
checks=out/'checks';checks.mkdir(exist_ok=True)
for name in reports:
 for suffix in ['.log','.xml','-inventory.json','-timings.json']:
  p=root/(name+suffix)
  if p.exists():shutil.copy(p,checks/p.name)
for name in ['validation-provenance.json','performance-comparison.json','reconciliation.json','resource-golden-metadata-proof.json','commands.txt','instrumentation.patch','final-build.log','final-release-build.log','acceptance-build.log','lan-release-commands.json','lan-release-build.log','generator-release-command.json','slow-release-command.json','fertility-command.json','fertility-build.log','fertility-optimized.log','shader-rules.log','sim-version.log','build_lan_release_check.py','summarize_verification.py']:
 if (root/name).exists():shutil.copy(root/name,checks/name)
for name in ['validation-provenance.json','performance-comparison.json','reconciliation.json','commands.txt']:shutil.copy(root/name,out/name)
with tarfile.open(out/'checks.tar.gz','w:gz',compresslevel=6) as t:t.add(checks,arcname='checks')
with tarfile.open(out/'continuation-artifacts.tar.gz','w:gz',compresslevel=6) as t:
 for name in ['timeout-rerun','timeout-final','slow-release','generator-release','lan-release']:
  if (root/name).exists():t.add(root/name,arcname=name)
files=sorted(out.glob('*.tar.gz'))
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files))
