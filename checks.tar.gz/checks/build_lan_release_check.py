from pathlib import Path
import shlex,subprocess,json
out=Path('/dev/shm/glob2-air-evidence');source=Path('/home/bradley/.codex/worktrees/unified-air-routing/glob2')
line=next(l for l in Path('/dev/shm/glob2-unified-air-build.log').read_text().splitlines() if 'engine-src_net_lan_LanMatchHarness.o -c' in l)
compile=shlex.split(line);compile[compile.index('-o')+1]=str(out/'lan-release.o');compile=[a if a!='-O0' else '-O3' for a in compile]
link=shlex.split(next(l for l in (out/'final-release-build.log').read_text().splitlines() if l.startswith('g++ -o /dev/shm/glob2-unified-air-release/src/glob2 ')))
link[link.index('-o')+1]='/dev/shm/glob2-air-lanreleasebin/test/glob2-engine-tests'
main=[a for a in link if a.endswith('/app/Glob2.o')];assert len(main)==1,main
link.remove(main[0]);link=[a.replace('dev/shm/glob2-unified-air-release/third_party/libGlob2JavaScript.a',str(source/'dev/shm/glob2-unified-air/third_party/libGlob2JavaScript.a')) if a=='dev/shm/glob2-unified-air-release/third_party/libGlob2JavaScript.a' else a for a in link]
link[3:3]=list(map(str,Path('/dev/shm/glob2-unified-air/test').glob('engine-support_*.o')))+[str(out/'lan-release.o')]
Path('/dev/shm/glob2-air-lanreleasebin/test').mkdir(parents=True,exist_ok=True)
(out/'lan-release-commands.json').write_text(json.dumps({'compile':compile,'link':link,'note':'LAN case compiled O3 and linked against O3 production objects. Existing test support objects and QuickJS archive are O0; QuickJS is not the timed network path.'},indent=2))
subprocess.run(compile,cwd=source,check=True);subprocess.run(link,cwd=source,check=True)
