from pathlib import Path
import subprocess,tempfile,os
p=Path('artifacts/ci-recovery/current-renderer-diagnostic.yml');s=p.read_text();start=s.index('          original_prefix=');end=s.index("          sys.exit(any",start)
s=s[:start]+'''          import threading,time
          stop=threading.Event();peak={'maps':0,'samples':0}
          def sample():
              while not stop.is_set():
                  for proc in Path('/proc').glob('[0-9]*'):
                      try:
                          if b'glob2-engine-tests' not in (proc/'cmdline').read_bytes():continue
                          maps=len((proc/'maps').read_text().splitlines());peak['samples']+=1;peak['maps']=max(peak['maps'],maps)
                      except (FileNotFoundError,PermissionError,ProcessLookupError):pass
                  stop.wait(.1)
          thread=threading.Thread(target=sample);thread.start()
          rows=[]
          try:
              for index in range(3):
                  for ordinal,case in enumerate(cases):
                      args=types.SimpleNamespace(keep_profiles=False,fullscreen=True,update_fixtures=False,artifacts=out/f'{index}-{ordinal}',verbose=False)
                      result=registry.run_job(registry.Job('engine',[case]),args,build)
                      (out/f'{index}-{ordinal}.log').write_text(result.output)
                      row={'index':index,'case':case.name,'status':result.status,'seconds':result.seconds};rows.append(row);print(json.dumps(row),flush=True)
                      (out/'results.json').write_text(json.dumps(rows,indent=2)+'\\n')
          finally:
              stop.set();thread.join();peak['systemMaxMapCount']=int(Path('/proc/sys/vm/max_map_count').read_text());(out/'peak.json').write_text(json.dumps(peak,indent=2)+'\\n')
''' +s[end:]
p.write_text(s)
parent=subprocess.check_output(['git','rev-parse','origin/ci/torus-capture-diagnostics'],text=True).strip()
with tempfile.TemporaryDirectory() as t:
 env=dict(os.environ,GIT_INDEX_FILE=t+'/index');subprocess.run(['git','read-tree',parent],env=env,check=True)
 blob=subprocess.check_output(['git','hash-object','-w',str(p)],text=True).strip();subprocess.run(['git','update-index','--cacheinfo','100644',blob,'.github/workflows/thread-sanitizer.yml'],env=env,check=True)
 tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree,'-p',parent],input='Measure each unchanged GPU regression case under the validated map budget\n',text=True).strip();subprocess.run(['git','push','origin',commit+':refs/heads/ci/torus-capture-diagnostics'],check=True)
