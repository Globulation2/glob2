from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess
out=Path('artifacts/irregular-clearing-starts/sweep');out.mkdir(exist_ok=True)
binary=str(Path('artifacts/irregular-clearing-starts/after-glob2').resolve())
cases=[]
for name in ['locust','old-growth']:
 for w,h,teams in [(128,128,4),(256,256,3),(256,256,4),(256,128,5),(128,256,5),(256,256,8),(512,256,8),(256,512,8),(512,512,8)]:
  for seed in [1,7,29]:
   cases.append(dict(generator=name,width=w,height=h,teams=teams,seed=seed,workers=8 if seed==29 else 4,options={}))
 for amount in [0,200]:
  options={'wheat-amount':amount}
  if name=='locust':options['wood-amount']=amount
  else:options.update({'forest-density':60 if amount==0 else 100,'trails':int(amount>0),'home-pools':0 if amount==0 else 8,'hidden-groves':int(amount>0)})
  for w,h in [(256,256),(256,128),(128,256)]:
   cases.append(dict(generator=name,width=w,height=h,teams=4,seed=401,workers=1 if amount==0 else 8,options=options))
(out/'requests.json').write_text(json.dumps(cases,indent=2))
def run(item):
 k,c=item;cmd=[binary,'map','generate',c['generator'],'--width',str(c['width']),'--height',str(c['height']),'--teams',str(c['teams']),'--seed',str(c['seed']),'--workers',str(c['workers']),'--report-file',str(out/f'{k:03d}.json')]
 for key,value in c['options'].items():cmd+=['--set',f'{key}={value}']
 with (out/f'{k:03d}.log').open('w') as log:
  try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 return {'case':k,'returncode':code}
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,enumerate(cases)))
(out/'results.json').write_text(json.dumps(results,indent=2));print('Cases',len(results),'failures',[r for r in results if r['returncode']],flush=True)
