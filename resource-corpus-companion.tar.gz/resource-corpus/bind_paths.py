#!/usr/bin/env python3
"""Verify frozen fixtures/catalogs, then bind ONLY declared fixture path tokens."""
import argparse,hashlib,json,pathlib

RUNTIME_EXTENSIONS = {".json", ".txt", ".js"}

def digest(path):
    result=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1048576),b''):result.update(block)
    return result.hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--corpus',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent)
    parser.add_argument('--output',type=pathlib.Path,required=True)
    parser.add_argument('--checkout',action='append',default=[],metavar='ROLE=PATH',help='Optionally verify runtime-catalog files in named checkout; no files modified')
    args=parser.parse_args();base=args.corpus.resolve();output=args.output.resolve()
    inventory=json.loads((base/'fixture-inventory.json').read_text());known={}
    for entry in inventory['files']:
        relative=pathlib.Path(entry['relative_path']);path=(base/relative).resolve()
        if relative.is_absolute() or not path.is_relative_to(base):raise ValueError('Unsafe fixture path: '+str(relative))
        if digest(path)!=entry['sha256']:raise ValueError('Fixture hash mismatch: '+str(path))
        known[str(relative)]=path
    catalogs=json.loads((base/'runtime-catalogs.json').read_text())
    verified=[]
    for specification in args.checkout:
        role,directory=specification.split('=',1)
        if role not in catalogs:raise ValueError('Unknown checkout role: '+role)
        checkout=pathlib.Path(directory).resolve()
        expected={entry['path'] for entry in catalogs[role]['files']}
        actual={str(path.relative_to(checkout)) for path in (checkout/'data').rglob('*')
                if path.is_file() and path.suffix.lower() in RUNTIME_EXTENSIONS}
        if actual!=expected:
            raise ValueError('Runtime input inventory mismatch: added='+str(sorted(actual-expected))+
                             '; missing='+str(sorted(expected-actual)))
        for entry in catalogs[role]['files']:
            path=checkout/entry['path']
            if digest(path)!=entry['sha256']:raise ValueError('Runtime input hash mismatch: '+str(path))
        verified.append(role)
    output.mkdir(parents=True,exist_ok=False)
    binding={'fixtures_verified':len(known),'catalog_roles_verified':verified,'manifests':[],'timing_valid':False}
    for source in sorted((base/'manifests').glob('*.portable.json')):
        manifest=json.loads(source.read_text())
        for scenario in manifest['scenarios']:
            fixture_hashes=scenario['fixture_sha256']
            if not set(fixture_hashes)<=set(known):raise ValueError('Manifest fixture missing from inventory')
            for relative,expected in fixture_hashes.items():
                if digest(known[relative])!=expected:raise ValueError('Manifest hash mismatch: '+relative)
            if not set(fixture_hashes)<=set(scenario['args']):raise ValueError('Fixture missing from argv')
            scenario['args']=[str(known[token]) if token in fixture_hashes else token for token in scenario['args']]
            scenario['fixture_sha256']={str(known[token]):h for token,h in fixture_hashes.items()}
        manifest['portable_binding']['bound_from_sha256']=digest(source)
        manifest['portable_binding']['corpus_root']=str(base)
        target=output/source.name.replace('.portable.json','.json');target.write_text(json.dumps(manifest,indent=2)+'\n')
        binding['manifests'].append({'file':target.name,'sha256':digest(target),'scenarios':len(manifest['scenarios'])})
    (output/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
    print(json.dumps(binding,indent=2))
if __name__=='__main__':main()
