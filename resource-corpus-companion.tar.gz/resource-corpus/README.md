# Frozen resource-refactor benchmark and tournament inputs

This companion plus the three fixture archives supplies all 110 distinct saved games used by the 98 matched legacy windows, three eight-team windows and 42 completion-tournament scenarios. The fixture archives preserve exact original gzip bytes. The current ee3 approved-fixes tournament uses the archived `completion.json` (SHA256 `229e642188e5e60ed191e7125047308c76d04b537d97cac1f1286eeb72095540`); candidate comparisons must use these same initial states. Nine swapped-player initial states are additional to the 101 benchmark saves.

No benchmark or tournament is run by the binder. All preparation and preflight timings are invalid for performance inference.

## Extract and bind

Extract all four archives in the same directory; they share the `resource-corpus/` root. Verify each archive against the published SHA256, then run:

```sh
python3 resource-corpus/bind_paths.py --output bound-inputs
```

This verifies every fixture's exact SHA256 before writing new `legacy-matched.json`, `eight-team-matched.json`, and `completion.json` manifests in a new output directory. Only declared fixture tokens in scenario `args` and `fixture_sha256` keys are rebound; original provenance fields retain their historical paths. No original manifest, fixture or checkout is modified. Raw archives and original manifests remain authoritative; portable manifests record their source hashes. `binding.json` records derived manifest hashes.

The matched performance windows use 5,120 ticks for `land-2-1002-mixed-late`, 7,680 for `water-2-1001-maxima-late`, and 6,144 for `control-land-2-1002-mixed-64-middle`; all other original lengths remain. Both arms completed those common prefixes in the separate preflight evidence bundle.

## Runtime checkouts and catalogs

Create independent checkouts from these exact Git revisions:

| Role | Revision |
|---|---|
| Corpus-generation baseline | `7e54a3fc581d22d32e7b97a6aee76dbfeae58e9f` |
| Pure ee3 comparison baseline | `ee3be8ecd9d7100de78ef63869271371d427cb66` |
| Approved-fixes ee3 control | Same ee3 revision, with `provenance/master-ee3-approved-actual.patch` applied |
| Candidate tested in the preflight | `9a54d4bf20b73bd63bd9d0f762cee67dda71eb51` |

For example, use `git worktree add --detach /chosen/pure-ee3 ee3be8ecd9d7100de78ef63869271371d427cb66` in an existing clone. Build each arm using its own checkout and the recorded compiler, flags and dependency identities in `provenance/`. Apply the control patch only in the dedicated control checkout. Do not apply it to a candidate or to the pristine baseline.

All catalog/configuration inputs matched their named Git revision byte-for-byte (verified with `git show REV:path`): no modified-control data snapshots are necessary. `runtime-catalogs.json` contains per-role file paths/SHA256 and executable hashes. The verified scope is every regular file recursively under `data/` whose filename extension is `.json`, `.txt`, or `.js` (case-insensitive), matching the runtime provenance collector. Checkout verification requires an identical path inventory as well as identical contents: added or missing files in that scope are rejected before any output manifests are written. Other asset extensions and build outputs are outside this check. Verify checkout data while binding, for example:

```sh
python3 resource-corpus/bind_paths.py --output bound-with-catalog-checks \
  --checkout pure-ee3=/chosen/pure-ee3 \
  --checkout approved-ee3=/chosen/approved-ee3 \
  --checkout candidate=/chosen/candidate
```

Build outputs and dependencies are not bundled. Absolute dependency prefixes in original build provenance are historical locations, not portable installation instructions; matching recorded versions/patches and library hashes is a separate environment reproduction requirement. This corpus makes the game inputs accessible without claiming that an arbitrary toolchain recreates identical binary hashes.

## Corpus generation provenance

`provenance/full-corpus-generation.json` records the 33 original games, map/game seeds, generator parameters, AI assignments, checkpoint commands, completion states and save hashes. `generation-records/` preserves each relevant game's original argv and terminal result. The main matrix is land/water, 2/4 teams, seeds 1001/1002, and Maxima/Cortex/Nicowar/mixed; the small 64×64 control has only the checkpoints produced before its original ending. Four cases reused the original quick corpus; their actual generation commands are retained.

`tools/prepare_parallel_compute.py`, `extend_baseline.py`, and `add_baseline_swaps.py` show the generation logic and nine reversed-controller runs. `provenance/full-corpus-swaps.json` retains the paired geometry checks. The eight-team 512×512 corpus has its own command, runtime/source provenance and preparation/finalization scripts. Its finalizer explicitly documents the original wrapper's incorrect return-field names after the engine succeeded; it did not rerun simulation.

These historical scripts contain original workstation paths and output-existence guards. Use the recorded argument arrays with the named generation-baseline checkout/binary to regenerate in a fresh directory; replace only binary/output paths. Their original save bytes can contain metadata, so regeneration is not a promise of byte-identical archives. Use the bundled hash-verified saved games to reproduce measured scenarios exactly.

No compressed or decompressed equivalence was found between the 101 original benchmark saves and the 22 committed game-save fixtures. The nine reversed-player initial states were separately generated. Fixture payloads are deduplicated across all three manifests; each of 110 content hashes appears only once across archives.
