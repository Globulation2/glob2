"""Add reversed-controller mixed-game initial states after the full baseline corpus is frozen."""
import concurrent.futures,gzip,hashlib,json,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[2];OUT=ROOT/'artifacts/resource-refactor/full-baseline-corpus'
generation=json.loads((OUT/'generation.json').read_text());assert len(generation['games'])==33
manifest=json.loads((OUT/'completion.json').read_text());assert len(manifest['scenarios'])==33
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(pathlib.Path(generation['binary']))==generation['binary_sha256']
def run(record):
 name=record['id']+'-swapped';dest=OUT/name;old=record['command'];command=[old[0]];players=[];i=1
 while i<len(old):
  key=old[i]
  if key in ['--save','--player']:
   if key=='--player':players.append(old[i+1])
   i+=2;continue
  if key in ['--output-dir','--ticks']:
   command.extend([key,str(dest) if key=='--output-dir' else '1']);i+=2;continue
  command.append(key);i+=1
 command+=['--save','initial']
 for player in reversed(players):command+=['--player',player]
 with (OUT/(name+'.log')).open('w') as log:subprocess.run(command,cwd=generation['cwd'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
 (dest/'command.json').write_text(json.dumps(command,indent=2));save=dest/'initial.game.gz'
 if not save.exists():save=dest/'initial.game'
 result=json.loads((dest/'result.json').read_text());assert result['status']=='completed'
 origmap=next((OUT/record['id']/'generated').glob('*.map.gz'));swapmap=next((dest/'generated').glob('*.map.gz'))
 assert gzip.decompress(origmap.read_bytes()) == gzip.decompress(swapmap.read_bytes()), f"Map geometry bytes changed: {name}"
 print(name,'initial',result['initialChecksum'],flush=True)
 return dict(id=name+'-completion',group='mixed',control=record['map_size']==64,start_tick=0,args=['--load-game',str(save),'--ticks','90000'],fixture_sha256={str(save):sha(save)},paired_original=record['id']+'-completion',player_order=list(reversed(players)),initial_checksum=result['initialChecksum'],command=command,geometry_map_sha256=sha(swapmap),original_geometry_map_sha256=sha(origmap))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:swaps=list(pool.map(run,[r for r in generation['games'] if r['mix']=='mixed']))
assert len(swaps)==9
manifest['scenarios']+=swaps;manifest['swapped_sides']='Every mixed assignment has reversed player order using the same generator/mapseed/gameseed and archived binary; initial states shared by before/candidate.'
(OUT/'completion.json').write_text(json.dumps(manifest,indent=2));(OUT/'swaps.json').write_text(json.dumps(swaps,indent=2));print('COMPLETE',len(manifest['scenarios']),'completion scenarios',flush=True)
