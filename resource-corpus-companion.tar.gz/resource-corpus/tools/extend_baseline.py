"""Local evidence runner. Prepare_parallel_compute full matrix plus the existing small control.
Runs are fixture generation under concurrent builds, never performance measurements.
"""
import concurrent.futures, hashlib, itertools, json, os, pathlib, shutil, subprocess, time
ROOT=pathlib.Path(__file__).resolve().parents[2]
ARCHIVE=ROOT/'artifacts/resource-refactor/baseline-source'
BINARY=ARCHIVE/'build/linux/client/release/src/glob2'
OLD=ROOT/'artifacts/resource-refactor/baseline-corpus'
OUT=ROOT/'artifacts/resource-refactor/full-baseline-corpus'
OUT.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
EXPECTED='c5d6d16ed9c3c0ec5c1e0260ba35830d94be3f887c42c3f7e26b62fc9664b84f'
assert sha(BINARY)==EXPECTED
mixes=['maxima','cortex','nicowar','mixed']
configs=list(itertools.product(['land','water'],[2,4],[1001,1002],mixes))
meta=dict(binary=str(BINARY),binary_sha256=EXPECTED,cwd=str(ARCHIVE),fixture_generation_only=True,timing_valid=False,
 note='Four concurrent baseline fixture-generation processes during candidate builds. No timing comparison.',
 preparation_logic=str(ROOT/'test/prepare_parallel_compute.py'),preparation_logic_sha256=sha(ROOT/'test/prepare_parallel_compute.py'),
 environment_overrides={},concurrency=4)
records=[]
def prepare(c):
 terrain,teams,seed,mix=c
 name=f'{terrain}-{teams}-{seed}-{mix}'
 directory=OUT/name
 reusable=name in ['land-4-1001-maxima','water-4-1001-cortex','water-4-1002-nicowar']
 if reusable and not directory.exists():shutil.copytree(OLD/name,directory)
 if reusable:
  command=json.loads((directory/'command.json').read_text())
 else:
  params=['width=8','height=8',f'teams={teams}']+(['moat=0','lakes=0'] if terrain=='land' else ['pattern=1'])
  command=[str(BINARY),'--run-game','--generator',str(15 if terrain=='land' else 26),'--map-seed',str(seed),'--game-seed','19','--ticks','32768','--save','initial','--save','every:8192','--save','final','--output-dir',str(directory)]
  for param in params:command+=['--param',param]
  for player in range(teams):command+=['--player',mixes[player%3] if mix=='mixed' else mix]
 result=directory/'result.json'
 if not result.exists():
  with (OUT/(name+'.log')).open('w') as log:
   done=subprocess.run(command,cwd=ARCHIVE,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
  if done.returncode:raise RuntimeError(f'{name}: exited {done.returncode}')
  (directory/'command.json').write_text(json.dumps(command,indent=2))
 data=json.loads(result.read_text())
 if data.get('status')!='completed':raise RuntimeError(f'{name}: {data.get("status")}')
 record=dict(id=name,terrain=terrain,teams=teams,map_seed=seed,game_seed=19,mix=mix,map_size=256,reused=reusable,command=command,
             ticks=data['ticks'],termination=data.get('termination'),initial_checksum=data.get('initialChecksum'),final_checksum=data.get('finalChecksum'),
             artifacts={str(p.relative_to(OUT)):sha(p) for p in directory.glob('*.game*')})
 print(name,'reused' if reusable else 'generated',data['ticks'],flush=True)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for record in pool.map(prepare,configs):
  records.append(record)
  (OUT/'generation.json').write_text(json.dumps(meta|{'games':records},indent=2))
control_name='control-land-2-1002-mixed-64'
control=OUT/control_name
if not control.exists():shutil.copytree(OLD/'land-2-1002-mixed',control)
control_data=json.loads((control/'result.json').read_text())
records.append(dict(id=control_name,terrain='land',teams=2,map_seed=1002,game_seed=19,mix='mixed',map_size=64,reused=True,
 command=json.loads((control/'command.json').read_text()),ticks=control_data['ticks'],termination=control_data.get('termination'),
 initial_checksum=control_data.get('initialChecksum'),final_checksum=control_data.get('finalChecksum'),artifacts={str(p.relative_to(OUT)):sha(p) for p in control.glob('*.game*')}))
windows=[];completed=[]
for record in records:
 for phase,tick in [('early',0),('middle',8192),('late',24576)]:
  save=OUT/record['id']/('initial.game' if tick==0 else f'checkpoint-{tick}.game')
  if not save.exists():save=pathlib.Path(str(save)+'.gz')
  if not save.exists():continue
  scenario=dict(id=record['id']+'-'+phase,group=record['mix'],control=record['map_size']==64,start_tick=tick,args=['--load-game',str(save),'--ticks',str(tick+8192)],fixture_sha256={str(save):sha(save)})
  windows.append(scenario)
  if tick==0:completed.append(scenario|{'id':record['id']+'-completion','args':['--load-game',str(save),'--ticks','90000']})
for name,data in [('windows',windows),('completion',completed)]:
 (OUT/(name+'.json')).write_text(json.dumps(meta|{'scenarios':data},indent=2))
(OUT/'generation.json').write_text(json.dumps(meta|{'games':records},indent=2))
assert len(records)==33 and len(completed)==33
print('COMPLETE',len(records),'games',len(windows),'windows',len(completed),'completion scenarios',flush=True)
