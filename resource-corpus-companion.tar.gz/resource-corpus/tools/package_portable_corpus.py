import collections,gzip,hashlib,json,pathlib,shutil,subprocess,tarfile
base=pathlib.Path(__file__).resolve().parent;root=base.parents[1];dest=base/'portable-resource-corpus';dest.mkdir(exist_ok=False)
companion=dest/'resource-corpus';companion.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(rel,value):
 p=companion/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
def copy(p,rel):
 q=companion/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
manifests={'legacy-matched':base/'window-preflights-ee3-9a54d4bf2/legacy-matched-windows.json','eight-team-matched':base/'window-preflights-ee3-9a54d4bf2/eight-team-matched-windows.json','completion':base/'full-baseline-corpus/completion.json'}
files={}
for label,path in manifests.items():
 original=json.load(open(path));copy(path,'manifests/original/'+label+'.json')
 for s in original['scenarios']:
  for name,h in s['fixture_sha256'].items():
   p=pathlib.Path(name);assert p.is_file() and sha(p)==h
   rel='fixtures/'+str(p.relative_to(base));files[name]={'original_path':name,'relative_path':rel,'sha256':h,'bytes':p.stat().st_size}
 for s in original['scenarios']:
  known=s['fixture_sha256'];s['args']=[files[x]['relative_path'] if x in known else x for x in s['args']]
  s['fixture_sha256']={files[k]['relative_path']:v for k,v in known.items()}
 original['portable_binding']={'format':1,'original_manifest_sha256':sha(path),'scope':'Only scenario.args exact fixture tokens and scenario.fixture_sha256 keys were rewritten. Original provenance fields remain historical.'}
 write('manifests/'+label+'.portable.json',original)
assert len(files)==110 and len({v['sha256'] for v in files.values()})==110
write('fixture-inventory.json',{'files':sorted(files.values(),key=lambda f:f['relative_path']),'files_count':110,'bytes':sum(f['bytes'] for f in files.values()),'tracked_equivalents':'No exact or decompressed match among22 tracked game saves for101 benchmark inputs; nine additional swapped initial saves were generated separately.'})
# Verify runtime data against the named committed revision, not merely a local path.
p=json.load(open(base/'window-preflights-ee3-9a54d4bf2/provenance.json'))
eight=json.load(open(base/'eight-team-corpus/provenance.json'))
approved=json.load(open(base/'master-ee3-approved-provenance.json'))
roles={'generation-baseline':('7e54a3fc581d22d32e7b97a6aee76dbfeae58e9f',eight['runtime_before']), 'pure-ee3':('ee3be8ecd9d7100de78ef63869271371d427cb66',p['runtime']['baseline']),'approved-ee3':('ee3be8ecd9d7100de78ef63869271371d427cb66',approved['runtime']),'candidate':('9a54d4bf20b73bd63bd9d0f762cee67dda71eb51',p['runtime']['candidate'])}
configs={}
for role,(revision,rt) in roles.items():
 entries=[]
 for path,h in rt['data_inputs'].items():
  payload=subprocess.run(['git','show',revision+':'+path],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  exact=payload.returncode==0 and hashlib.sha256(payload.stdout).hexdigest()==h
  entry={'path':path,'sha256':h,'matches_git_revision':exact}
  if not exact:
   local=pathlib.Path(rt['cwd'])/path;assert sha(local)==h
   snapshot='modified-control-inputs/'+role+'/'+path;copy(local,snapshot);entry['snapshot']=snapshot
  entries.append(entry)
 configs[role]={'revision':revision,'binary_sha256':rt['binary_sha256'],'files':entries,'modified_snapshots':sum(not x['matches_git_revision'] for x in entries)}
write('runtime-catalogs.json',configs)
for name in ['generation.json','swaps.json']:
 copy(base/'full-baseline-corpus'/name,'provenance/full-corpus-'+name)
for name in ['provenance.json','command.json','run.json']:
 copy(base/'eight-team-corpus'/name,'provenance/eight-team-'+name)
for name in ['master-ee3-pure-provenance.json','master-ee3-approved-provenance.json','master-ee3-approved-actual.patch','approved-fixes.patch']:
 copy(base/name,'provenance/'+name)
copy(base/'candidate-9a54d4bf2/provenance.json','provenance/candidate-9a54-provenance.json')
copy(base/'tournament-ee3-approved-fixes/provenance.json','provenance/running-ee3-control-tournament-start-provenance.json')
for name in ['extend_baseline.py','add_baseline_swaps.py','prepare_eight_team.py','finalize_eight_team.py','paired_provenance.py','package_portable_corpus.py']:
 copy(base/name,'tools/'+name)
copy(root/'test/prepare_parallel_compute.py','tools/prepare_parallel_compute.py')
# Match source generation script provenance; later wrapper finalizers are retained explicitly.
assert sha(root/'test/prepare_parallel_compute.py')==json.load(open(base/'full-baseline-corpus/generation.json'))['preparation_logic_sha256']
# Each saved-game directory supplies its original generation argv and terminal record.
for directory in sorted({pathlib.Path(p).parent for p in files}):
 for name in ['command.json','result.json']:
  if (directory/name).exists():copy(directory/name,'generation-records/'+str(directory.relative_to(base))+'/'+name)
groups=collections.defaultdict(list)
for name,item in files.items():
 game=pathlib.Path(name).parent.name;group='water-four' if game.startswith('water-4') else 'water-two' if game.startswith('water-2') else 'land-and-eight-team';groups[group].append(item)
archives=[]
for group,items in groups.items():
 path=dest/('resource-corpus-'+group+'.tar.gz')
 with tarfile.open(path,'w:gz',compresslevel=1) as tar:
  for item in sorted(items,key=lambda f:f['relative_path']):tar.add(item['original_path'],arcname='resource-corpus/'+item['relative_path'],recursive=False)
 archives.append({'archive':str(path),'sha256':sha(path),'bytes':path.stat().st_size,'files':len(items),'payload_bytes':sum(f['bytes'] for f in items)})
write('fixture-archives.json',archives)
print(json.dumps({'archives':archives,'runtime_modified_snapshots':{k:v['modified_snapshots'] for k,v in configs.items()},'companion_directory':str(companion)},indent=2))
