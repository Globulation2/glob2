"""Finalize completed preparation evidence; does not launch an engine."""
import json,os,pathlib
from paired_provenance import sha,runtime_snapshot,stable_runtime
ROOT=pathlib.Path(__file__).resolve().parents[2];out=ROOT/'artifacts/resource-refactor/eight-team-corpus'
meta=json.loads((out/'provenance.json').read_text());run=json.loads((out/'run.json').read_text())
assert run['returncode']==0 and not run['timeout'],run
assert run['loaded_libraries'] and not run['loaded_library_errors'],run
os.environ.update(meta['environment_overrides']);game=out/'land-8-1001-mixed-512'
result=json.loads((game/'result.json').read_text());assert result['ticks']==8192 and result['termination']=='tick_cap'
after=runtime_snapshot(meta['binary'],meta['cwd']);assert stable_runtime(meta['runtime_before'])==stable_runtime(after)
for name,digest in meta['source_files'].items():assert sha(pathlib.Path(meta['cwd'])/name)==digest,name
for name,identity in run['loaded_libraries'].items():assert sha(name)==identity['sha256'],name
meta.update(runtime_after=after,runtime_stable=True,source_stable=True,actual_loaded_libraries=run['loaded_libraries'],actual_library_errors=run['loaded_library_errors'])
meta['result_summary']={k:result.get(k) for k in ['status','ticks','termination','initialChecksum','finalChecksum','winning_teams','unresolved']}
meta['artifacts']={str(p.relative_to(out)):sha(p) for p in sorted(game.rglob('*')) if p.is_file()}
meta['log_sha256']=sha(out/'engine.log');meta['finalizer_script']=str(pathlib.Path(__file__).resolve());meta['finalizer_script_sha256']=sha(__file__)
meta['preparation_driver_note']='Engine completed; preparation wrapper used incorrect metadata return field names after run completion. This finalizer validates the successful recorded run and emits manifests without rerunning simulation.'
meta['actual_game_seed']=result.get('game_seed')
meta['result_top_level_keys']=list(result)
(out/'provenance.json').write_text(json.dumps(meta,indent=2))
scenarios=[]
for phase,tick in [('initial',0),('developing',4096),('middle',8192)]:
 save=game/('initial.game' if tick==0 else f'checkpoint-{tick}.game')
 if not save.exists():save=pathlib.Path(str(save)+'.gz')
 assert save.is_file(),save
 scenarios.append({'id':'land-8-1001-mixed-512-'+phase,'group':'mixed-eight-team-large','control':False,'start_tick':tick,'args':['--load-game',str(save),'--ticks',str(tick+2048)],'fixture_sha256':{str(save):sha(save)}})
manifest={k:meta[k] for k in ['binary','binary_sha256','cwd','fixture_generation_only','timing_valid','note','environment_overrides']};manifest['scenarios']=scenarios;manifest['provenance_sha256']=sha(out/'provenance.json')
(out/'windows.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'status':'complete','manifest':str(out/'windows.json'),'windows':len(scenarios),'ticks':result['ticks']}))
