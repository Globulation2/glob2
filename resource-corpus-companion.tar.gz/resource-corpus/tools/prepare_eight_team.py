"""Prepare one frozen baseline eight-team game; never valid timing evidence."""
import json,os,pathlib,platform,subprocess,sys
from paired_provenance import sha,runtime_snapshot,stable_runtime,run_observed
ROOT=pathlib.Path(__file__).resolve().parents[2]
base=ROOT/'artifacts/resource-refactor/baseline-source'
binary=base/'build/linux/client/release/src/glob2'
out=ROOT/'artifacts/resource-refactor/eight-team-corpus'
out.mkdir(exist_ok=False)
expected='c5d6d16ed9c3c0ec5c1e0260ba35830d94be3f887c42c3f7e26b62fc9664b84f'
assert sha(binary)==expected
os.environ['LD_LIBRARY_PATH']='/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib'
before=runtime_snapshot(binary,base)
sdl=[v for k,v in before['shared_libraries'].items() if pathlib.Path(k).name.startswith('libSDL3.so')]
assert len(sdl)==1 and sdl[0]['resolved'].startswith('/tmp/glob2-terrain-sdl-patched/')
source_files={str(p.relative_to(base)):sha(p) for top in ['src','libgag','libusl','scons'] for p in sorted((base/top).rglob('*')) if p.is_file() and p.suffix in {'.h','.cpp','.py','.js','.json','.txt'}}
for name in ['SConstruct','vcpkg.json']:
 if (base/name).exists():source_files[name]=sha(base/name)
name='land-8-1001-mixed-512';game=out/name
players=['maxima','cortex','nicowar','maxima','cortex','nicowar','maxima','cortex']
cmd=[str(binary),'--run-game','--generator','15','--map-seed','1001','--game-seed','19','--ticks','8192','--save','initial','--save','every:4096','--save','final','--output-dir',str(game)]
for param in ['width=9','height=9','teams=8','moat=0','lakes=0']:cmd+=['--param',param]
for player in players:cmd+=['--player',player]
meta={'binary':str(binary),'binary_sha256':expected,'cwd':str(base),'fixture_generation_only':True,'timing_valid':False,'note':'One baseline engine process while other compilation/tournament work may run. Preparation timings are not performance evidence.','concurrency':1,'host':platform.platform(),'environment_overrides':{'LD_LIBRARY_PATH':os.environ['LD_LIBRARY_PATH']},'command':cmd,'map_seed_requested':1001,'game_seed_requested':19,'players':players,'map_size':512,'teams':8,'preparation_script':str(pathlib.Path(__file__).resolve()),'preparation_script_sha256':sha(__file__),'preparation_reference_sha256':sha(ROOT/'test/prepare_parallel_compute.py'),'runtime_before':before,'source_files':source_files}
(out/'provenance.json').write_text(json.dumps(meta,indent=2));(out/'command.json').write_text(json.dumps(cmd,indent=2))
with (out/'engine.log').open('w') as log:run=run_observed(cmd,base,log,timeout=7200)
(out/'run.json').write_text(json.dumps(run,indent=2))
assert run['exit']==0 and not run['timed_out'],run
result=json.loads((game/'result.json').read_text())
assert result['ticks']==8192 and result['termination']=='tick_cap'
after=runtime_snapshot(binary,base);assert stable_runtime(before)==stable_runtime(after)
meta['runtime_after']=after;meta['runtime_stable']=True;meta['result_summary']={k:result.get(k) for k in ['ticks','termination','initial_checksum','final_checksum','winning_teams','unresolved']}
meta['artifacts']={str(p.relative_to(out)):sha(p) for p in sorted(game.rglob('*')) if p.is_file()}
meta['log_sha256']=sha(out/'engine.log');meta['actual_loaded_libraries']=run.get('actual_loaded_libraries',{});meta['actual_library_errors']=run.get('actual_library_errors',[])
(out/'provenance.json').write_text(json.dumps(meta,indent=2))
scenarios=[]
for phase,tick in [('initial',0),('developing',4096),('middle',8192)]:
 save=game/('initial.game' if tick==0 else f'checkpoint-{tick}.game')
 if not save.exists():save=pathlib.Path(str(save)+'.gz')
 assert save.is_file(),save
 scenarios.append({'id':name+'-'+phase,'group':'mixed-eight-team-large','control':False,'start_tick':tick,'args':['--load-game',str(save),'--ticks',str(tick+2048)],'fixture_sha256':{str(save):sha(save)}})
manifest={k:meta[k] for k in ['binary','binary_sha256','cwd','fixture_generation_only','timing_valid','note','environment_overrides']};manifest['scenarios']=scenarios;manifest['provenance_sha256']=sha(out/'provenance.json')
(out/'windows.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({'status':'complete','manifest':str(out/'windows.json'),'windows':len(scenarios),'ticks':result['ticks']}),flush=True)
