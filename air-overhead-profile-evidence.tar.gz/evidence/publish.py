from pathlib import Path
import json,subprocess,os,hashlib,tarfile,shutil
ROOT=Path.cwd();OUT=ROOT/'artifacts/air-overhead-profile';PUB=Path('/dev/shm/glob2-air-overhead-publication');PUB.mkdir(exist_ok=True)
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
for name in ['README.md','summary.json','gate-summary.json','islands-comparison.json','midgame24k-comparison.json']:shutil.copy2(OUT/name,PUB/name)
archive=PUB/'air-overhead-profile-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in sorted(OUT.rglob('*')):
  rel=p.relative_to(OUT)
  if not p.is_file() or p.is_symlink() or p.name.startswith('glob2-') or p.suffix in ('.o','.a') or any(x in ('profile','__pycache__') for x in rel.parts):continue
  tar.add(p,arcname=str(Path('evidence')/rel),recursive=False)
assert archive.stat().st_size<95_000_000
(PUB/'archive-sha256.txt').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
index=PUB/'index';env=dict(os.environ,GIT_INDEX_FILE=str(index))
def git(args,**kw):return subprocess.check_output(['git',*args],env=env,**kw).decode().strip()
git(['read-tree','--empty'])
for p in sorted(PUB.iterdir()):
 if not p.is_file() or p.name in ('index','index.lock'):continue
 oid=git(['hash-object','-w','--stdin'],input=p.read_bytes());git(['update-index','--add','--cacheinfo','100644',oid,p.name])
tree=git(['write-tree']);commit=git(['commit-tree',tree,'-m','Retain PR 1196 overhead attribution and direct-flight eligibility evidence']);ref='refs/heads/evidence/pr1196-air-overhead-eddff43fb';git(['update-ref',ref,commit]);subprocess.run(['git','push','origin',ref],check=True)
j={'commit':commit,'url':'https://github.com/Globulation2/glob2/tree/'+commit,'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()};(OUT/'publication.json').write_text(json.dumps(j,indent=2));print(json.dumps(j,indent=2))
