from pathlib import Path
import shlex,subprocess,json,os
ROOT=Path.cwd();OUT=ROOT/'artifacts/air-overhead-profile/gate-diagnostic';OUT.mkdir(exist_ok=True)
log=(ROOT/'artifacts/direct-flight-performance/build-release.log').read_text().splitlines();compile=next(shlex.split(l) for l in log if ' -c ' in l and l.endswith('src/map/MapCells.cpp'));link=next(shlex.split(l) for l in reversed(log) if l.startswith('g++ -o ') and '/src/glob2 ' in l)
original=(ROOT/'src/map/MapCells.cpp').read_text();s=original.replace('bool Map::hasAirRoutingConstraints(Uint32 teamMask) const\n{','''bool Map::hasAirRoutingConstraints(Uint32 teamMask) const
{
    // DIAGNOSTIC-ONLY: does not change eligibility or map state.
    struct Counts {
        unsigned long long yes[32]{},no[32]{},terrain[32]{},rescans=0;
        ~Counts(){for(unsigned i=0;i<32;++i)if(yes[i]||no[i])std::cerr << "GATE team=" << i << " field=" << yes[i] << " direct=" << no[i] << " terrain=" << terrain[i] << "\\n";std::cerr << "GATE rescans=" << rescans << "\\n";}
    }; static Counts counts;
    const auto record=[&](bool value,bool terrain=false){for(unsigned i=0;i<32;++i)if(teamMask&(Uint32(1)<<i)){if(value)++counts.yes[i];else ++counts.no[i];if(terrain)++counts.terrain[i];}return value;};''')
s=s.replace('if (hasAirTerrainConstraints()) return true;','if (hasAirTerrainConstraints()) return record(true,true);').replace('if (!cached.valid) {','if (!cached.valid) { ++counts.rescans;').replace('return cached.resourceBlockers || (cached.forbiddenTeams & teamMask);','return record(cached.resourceBlockers || (cached.forbiddenTeams & teamMask));')
s='#include <iostream>\n'+s;cpp=OUT/'MapCells.cpp';cpp.write_text(s);obj=OUT/'MapCells.o';oldobj=compile[compile.index('-o')+1];compile[compile.index('-o')+1]=str(obj);compile[-1]=str(cpp);link[link.index('-o')+1]=str(OUT/'glob2-diagnostic');link=[str(obj) if x==oldobj else x for x in link]
(OUT/'commands.json').write_text(json.dumps({'compile':compile,'link':link},indent=2));(OUT/'instrumentation.diff').write_text(subprocess.run(['diff','-u','-',str(cpp)],input=original,capture_output=True,text=True).stdout)
with (OUT/'build.log').open('w') as f:
 for args in [compile,link]:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True,env=dict(os.environ,CCACHE_DIR='/dev/shm/glob2-air-ccache',TMPDIR='/dev/shm/glob2-air-tmp'))
print('gate diagnostic built',flush=True)
