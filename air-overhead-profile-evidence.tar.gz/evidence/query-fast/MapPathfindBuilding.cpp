#include <climits>
#include <iostream>
// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#include <PerformanceTelemetry.h>
#include "Map.h"
#include "BuildingType.h"
#include "EngineTiming.h"
#include "Game.h"
#include "Utilities.h"
#include "Unit.h"
#include "MapInternal.h"
#include "BuildingGradientSearch.h"
#include "SharedBuildingGradient.h"



// Building pathfinding (buildingGradient, buildingAvailable, pathfindBuilding)

namespace {

// A unit that cannot make progress forces a rebuild at most this often (~5 s).
constexpr Uint32 STUCK_REBUILD_TICKS = 128;


} // namespace

bool Map::prepareBuildingGradient(Building *building, int swimClass, BuildingRoute route)
{
	const int slot = building->routeSlot(swimClass, route);
    auto guard=SharedBuildingGradient::lock(building->sharedGradient[slot]);
	assert(building);
	Uint16 *&gradient=building->globalGradient[slot];
	Uint32 lastUpdate=building->lastGlobalGradientUpdateStepCounter[slot];
	Uint32 now=game->stepCounter;
	building->globalGradientUsedStep[slot]=now;
	bool rebuild=false, cold=false;
	if (gradient==NULL)
	{
		gradient=acquireBuildingGradientBuffer();
		rebuild=cold=true;
	}
	else if ((building->dirtyGradient[slot] || building->gradientGeneration[slot]!=topologyGeneration)
		&& lastUpdate+GRADIENT_DIRTY_REBUILD_TICKS<=now)
	{
		rebuild=true;
	}
	// A clearing flag's goals are resources, which grow and get cleared.
	else if (building->resolveRoute(route) == BuildingRoute::Clearing && lastUpdate+CLEARING_FLAG_REFRESH_TICKS<=now)
	{
		rebuild=true;
	}
	// With scheduled building gradients a refresh is requested and the old
	// field keeps serving until its publication; a cold field has none.
	if (rebuild && (cold || !requestBuildingRefresh(building, slot)))
	{
		using Sync = BuildingSyncReason;
		if (cold)
			switch (building->gradientDrop[slot])
			{
			case Building::GradientDrop::New: noteBuildingSyncReason(Sync::ColdNew); break;
			case Building::GradientDrop::Idle: noteBuildingSyncReason(Sync::ColdIdle); break;
			case Building::GradientDrop::Own: noteBuildingSyncReason(Sync::ColdOwn); break;
			case Building::GradientDrop::Team: noteBuildingSyncReason(Sync::ColdTeam); break;
			case Building::GradientDrop::Area: noteBuildingSyncReason(Sync::ColdArea); break;
			}
		else noteBuildingSyncReason(Sync::Other);
		updateGlobalGradient(building, swimClass, route);
	}
	return !building->isLocked(building->routeAccess(swimClass, route));
}

const Uint16 *Map::buildingGradient(Building *building, int swimClass, BuildingRoute route)
{
	const int slot = building->routeSlot(swimClass, route);
    auto guard=SharedBuildingGradient::lock(building->sharedGradient[slot]);
	if (!prepareBuildingGradient(building, swimClass, route)) return NULL;
	finishBuildingGradient(building, swimClass, route);
	return building->globalGradient[slot];
}

std::shared_ptr<SharedBuildingGradient> Map::leaseBuildingRoute(Building *building, int swimClass, BuildingRoute route)
{
	const int slot = building->routeSlot(swimClass, route);
	// Observation borrows a usable generation without enrolling, allocating,
	// seeding or refreshing a field. Live admission owns normal preparation.
	if (!building->globalGradient[slot] || building->dirtyGradient[slot] ||
		building->gradientGeneration[slot] != topologyGeneration ||
		(building->resolveRoute(route) == BuildingRoute::Clearing &&
		 building->lastGlobalGradientUpdateStepCounter[slot] + CLEARING_FLAG_REFRESH_TICKS <= game->stepCounter))
		return {};
	return building->leaseGradient(slot);
}

Uint16 Map::buildingGradientValue(Building *building, int swimClass, size_t cell, BuildingRoute route) const
{
	const int slot = building->routeSlot(swimClass, route);
    auto guard=SharedBuildingGradient::lock(building->sharedGradient[slot]);
	assert(building->globalGradient[slot]);
	assert(cell < size);
	if (auto &search = building->globalGradientSearch[slot]) search->resolve(cell);
	return building->globalGradient[slot][cell];
}

bool Map::buildingGradientDirection(EntityRandom& random, Building *building, int swimClass, int x, int y,
	int *dx, int *dy, bool strict, BuildingRoute route) const
{
	const int slot = building->routeSlot(swimClass, route);
    auto guard=SharedBuildingGradient::lock(building->sharedGradient[slot]);
	// Settling this layer also settles all equal/better neighbors the generic
	// direction picker can select. Keep partial-array access inside this adapter.
	buildingGradientValue(building, swimClass, coordToIndex(x, y), route);
	return directionByGradient(random, building->owner->me, swimClass, x, y,
		building->globalGradient[slot], dx, dy, strict);
}

bool Map::buildingAvailable(Building *building, int swimClass, int x, int y, int *dist, BuildingRoute route)
{
    // MEASUREMENT-ONLY: exact uniform-air octile cost to the footprint.
    int analyticDistance=-1;
    if(swimClass==AIR_MOVEMENT_CLASS && building->resolveRoute(route)==BuildingRoute::Footprint
        && !hasAirRoutingConstraints(building->owner->me)) {
        int cost=INT_MAX;
        for(int oy=0;oy<building->type->height;++oy)
            for(int ox=0;ox<building->type->width;++ox) {
                const int ax=warpDist1d(x,(building->posX+ox)&wMask,w);
                const int ay=warpDist1d(y,(building->posY+oy)&hMask,h);
                cost=std::min(cost,std::min(ax,ay)*GRADIENT_DIAGONAL_STEP+std::abs(ax-ay)*GRADIENT_STEP);
            }
        if(cost<GRADIENT_AT_GOAL-GRADIENT_UNREACHABLE)
            analyticDistance=(cost+GRADIENT_STEP/2)/GRADIENT_STEP;
    }
#ifndef AIR_ANALYTIC_VALIDATE
    if(analyticDistance>=0) { *dist=analyticDistance; return true; }
#endif

	const int slot = building->routeSlot(swimClass, route);
    auto guard=SharedBuildingGradient::lock(building->sharedGradient[slot]);
	PERF_SCOPE_TIME(PathBuilding);
	if (!prepareBuildingGradient(building, swimClass, route))
		return false;
	// The unit's own cell can be an obstacle in this building's field - it may be
	// standing on another building, or in a forbidden area - while a cell next to
	// it is on a route. Take the first of the nine that carries a distance.
	Uint16 g=buildingGradientValue(building, swimClass, coordToIndex(x, y), route);
	for (int d=0; d<8 && g<=GRADIENT_UNREACHABLE; d++)
		g=buildingGradientValue(building, swimClass, coordToIndex(x+tabClose[d][0], y+tabClose[d][1]), route);
	if (g<=GRADIENT_UNREACHABLE)
		return false;
	*dist=gradientTiles(g);
#ifdef AIR_ANALYTIC_VALIDATE
    struct Count { unsigned n=0; ~Count(){std::cerr << "ANALYTIC_CHECKS " << n << "\n";} }; static Count count; if(analyticDistance>=0) ++count.n;
    if(analyticDistance>=0 && analyticDistance!=*dist) { std::cerr << "ANALYTIC_MISMATCH " << analyticDistance << " " << *dist << "\n"; std::abort(); }
#endif
	return true;
}


bool Map::pathfindBuilding(EntityRandom& random, Building *building, int swimClass, int x, int y, int *dx, int *dy, BuildingRoute route)
{
	const int slot = building->routeSlot(swimClass, route);
    auto guard=SharedBuildingGradient::lock(building->sharedGradient[slot]);
	PERF_SCOPE_TIME(PathBuilding);
	assert(building);
	assert(x>=0);
	assert(y>=0);
	if (((areaCells[coordToIndex(x, y)].forbidden) & building->owner->me)!=0)
	{
		// This escape path reads the cached field directly as a tie-breaker.
		// Preserve its old age (do not call buildingGradient here).
		finishBuildingGradient(building, swimClass, route);
		return pathfindForbidden(building->globalGradient[slot], building->owner->teamNumber, swimClass, x, y, dx, dy);
	}

	if (!prepareBuildingGradient(building, swimClass, route))
		return false;
	if (building->resolveRoute(route) == BuildingRoute::Clearing
		&& buildingGradientValue(building, swimClass, coordToIndex(x, y), route)==GRADIENT_AT_GOAL)
	{
		// Standing where one of the flag's resources was: it is gone, the gradient is stale.
		building->dirtyGradient[slot]=true;
		return false;
	}
	if (buildingGradientDirection(random, building, swimClass, x, y, dx, dy, true, route))
		return true;
	if (building->lastGlobalGradientUpdateStepCounter[slot]+STUCK_REBUILD_TICKS>game->stepCounter)
		return buildingGradientDirection(random, building, swimClass, x, y, dx, dy, false, route);

	// Stuck for a while: the gradient may be stale. A scheduled refresh keeps
	// sidestepping on the old field until it publishes; otherwise rebuild now.
	if (requestBuildingRefresh(building, slot))
		return buildingGradientDirection(random, building, swimClass, x, y, dx, dy, false, route);
	noteBuildingSyncReason(BuildingSyncReason::Other);
	updateGlobalGradient(building, swimClass, route);
	if (building->isLocked(building->routeAccess(swimClass, route)))
		return false;
	if (buildingGradientDirection(random, building, swimClass, x, y, dx, dy, true, route))
		return true;
	return buildingGradientDirection(random, building, swimClass, x, y, dx, dy, false, route);
}
