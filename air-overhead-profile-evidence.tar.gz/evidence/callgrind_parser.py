import re,json,statistics
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parent

def parse_file(path):
 lines=path.read_text().splitlines();events=[];position_count=1;dictionary={};functions={};edges=defaultdict(lambda:None);fn=None;child=None;skip_child=False;totals=None;thread=None;obj='';file=''
 def named(value):
  m=re.match(r'\((\d+)\)(?: (.*))?$',value)
  if not m:return value
  key=m[1]
  if m[2] is not None:dictionary[key]=m[2]
  return ('id',key)
 # First pass resolves forward name references, separate dictionaries by kind.
 dictionaries=defaultdict(dict)
 for line in lines:
  m=re.match(r'(fn|cfn|ob|cob|fl|fi|cfl|cfi)=\((\d+)\) (.*)',line)
  if m:
   kind=m[1];group='fn' if kind.endswith('fn') else 'ob' if kind.endswith('ob') else 'fl';dictionaries[group][m[2]]=m[3]
 def name(value,group):
  m=re.match(r'\((\d+)\)(?: (.*))?$',value)
  if not m:return value
  return m[2] if m[2] is not None else dictionaries[group].get(m[1],f'<unresolved:{group}:{m[1]}>')
 for line in lines:
  if line.startswith('events:'):events=line.split()[1:]
  elif line.startswith('positions:'):position_count=len(line.split())-1
  elif line.startswith('thread:'):thread=int(line.split()[1])
  elif line.startswith('totals:'):totals=[int(x) for x in line.split()[1:]]
  elif line.startswith('ob='):obj=name(line[3:],'ob')
  elif line.startswith(('fl=','fi=')):file=name(line[3:],'fl')
  elif line.startswith('fn='):
   fn=name(line[3:],'fn');key=(obj,fn)
   if key not in functions:functions[key]={'object':obj,'function':fn,'file':file,'cost':[0]*len(events)}
  elif line.startswith('cfn='):child=name(line[4:],'fn')
  elif line.startswith('calls='):skip_child=True
  elif line and not line.startswith('#') and re.match(r'^[*+\-0-9]',line):
   tokens=line.split();values=[int(x) for x in tokens[position_count:]];values+=[0]*(len(events)-len(values))
   if any(x<0 or x>=2**63 for x in values):raise RuntimeError(f'Invalid/wrapped cost in {path}: {line}')
   if skip_child:
    skip_child=False;k=(fn,child)
    if edges[k] is None:edges[k]=[0]*len(events)
    for i,x in enumerate(values):edges[k][i]+=x
   else:
    if fn is None:raise RuntimeError('Cost without function')
    for i,x in enumerate(values):functions[(obj,fn)]['cost'][i]+=x
 sumself=[sum(f['cost'][i] for f in functions.values()) for i in range(len(events))]
 totals=(totals or [0]*len(events))+[0]*max(0,len(events)-len(totals or []))
 if sumself!=totals:raise RuntimeError(f'Self-cost does not reconcile: {path} {sumself} != {totals}')
 return {'file':path.name,'thread':thread,'events':events,'totals':dict(zip(events,totals)),'functions':[dict(f,cost=dict(zip(events,f['cost']))) for f in functions.values()],'edges':[{'caller':a,'callee':b,'cost':dict(zip(events,c))} for (a,b),c in edges.items()]}

def parse_run(directory):
 metadata=json.loads((directory/'metadata.json').read_text());files=[]
 for p in directory.glob('callgrind.out.*'):
  if p.name.endswith('txt') or not p.stat().st_size:continue
  f=parse_file(p)
  if f['events']:files.append(f)
 totals=defaultdict(int);combined=defaultdict(lambda:defaultdict(int))
 for f in files:
  for event,value in f['totals'].items():totals[event]+=value
  for fn in f['functions']:
   for event,value in fn['cost'].items():combined[(fn['object'],fn['function'])][event]+=value
 log=(directory/'run.log').read_text();m=re.search(r'==\d+== Collected\s*:\s*([^\n]+)',log);reported=[int(x) for x in m[1].split()] if m else None
 if not files or reported is None:raise RuntimeError('Missing thread events or global collected totals: '+str(directory))
 keys=files[0]['events'] if files else []
 if reported and reported!=[totals[k] for k in keys]:raise RuntimeError(f'Global counts do not reconcile in {directory}: {[totals[k] for k in keys]} != {reported}')
 frames=int(metadata['environment']['PROFILE_FRAMES']);owner=next(f for f in files if f['thread']==1)
 result={'case':metadata['case'],'variant':metadata['variant'],'repeat':metadata['repeat'],'frames':frames,'totals':dict(totals),'per_frame':{k:v/frames for k,v in totals.items()},'owner_instruction_fraction':owner['totals']['Ir']/totals['Ir'],'threads':[{'thread':f['thread'],'totals':f['totals'],'has_graphics_work':any(('ComputeExecutor' in x['function'] or 'buildTerrainJob' in x['function'] or 'executeCommand' in x['function']) and x['cost']['Ir'] for x in f['functions'])} for f in files],'functions':[{'object':o,'function':n,'cost':dict(cost),'instruction_fraction':cost['Ir']/totals['Ir']} for (o,n),cost in sorted(combined.items(),key=lambda row:row[1]['Ir'],reverse=True)],'files':files,'validation':'Every thread self-cost sum equals footer totals; all thread totals exactly equal Callgrind Collected counters.'}
 return result
if __name__=='__main__':
 runs=[]
 for p in (ROOT/'callgrind').iterdir():
  if (p/'metadata.json').exists():
   r=parse_run(p);runs.append(r);print(p.name,'Ir/frame',round(r['per_frame']['Ir']),'branches/frame',round(r['per_frame']['Bc']+r['per_frame']['Bi']),'owner share',round(100*r['owner_instruction_fraction'],1))
 (ROOT/'callgrind-parsed.json').write_text(json.dumps({'runs':runs},indent=2)+'\n')
