from pathlib import Path
import subprocess,json,os,re
ROOT=Path.cwd();OUT=ROOT/'artifacts/air-overhead-profile';native=ROOT/'artifacts/direct-flight-performance/native';results=[]
for case,start in [('islands',8192),('midgame24k',24000),('swamp',8192),('ordinary32',0),('lava-shield',8192),('constrained64',0)]:
 d=OUT/('gate-'+case);d.mkdir(exist_ok=True);save=next((native/'inputs').glob(case+'.game*'))
 args=[str(OUT/'gate-diagnostic/glob2-diagnostic'),'game','run','--load-game',str(save),'--ticks',str(start+384),'--benchmark-warmup','128','--compute-threads','4','--gpu','off','--output-dir',str(d/'game')]
 (d/'command.json').write_text(json.dumps(args,indent=2));env=dict(os.environ,SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(d/'profile'),GLOB2_USER_DIR=str(d/'profile'))
 with (d/'run.log').open('w') as f:subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 a=json.load(open(d/'game/result.json'));b=json.load(open(native/f'{case}-direct-0/game/result.json'));assert all(a[k]==b[k] for k in ['initialChecksum','finalChecksum','ticks','benchmark_measured_ticks'])
 text=(d/'run.log').read_text();teams=[{'team':int(t),'field_calls':int(y),'direct_calls':int(n),'terrain_calls':int(z)} for t,y,n,z in re.findall(r'GATE team=(\d+) field=(\d+) direct=(\d+) terrain=(\d+)',text)]
 results.append({'case':case,'scope':'entire 384-tick diagnostic run, including warmup','checksums_match_native':True,'teams':teams,'field_calls':sum(t['field_calls'] for t in teams),'direct_calls':sum(t['direct_calls'] for t in teams),'terrain_calls':sum(t['terrain_calls'] for t in teams),'summary_rescans':int(re.search(r'GATE rescans=(\d+)',text)[1])});print(results[-1],flush=True)
(OUT/'gate-summary.json').write_text(json.dumps(results,indent=2))
