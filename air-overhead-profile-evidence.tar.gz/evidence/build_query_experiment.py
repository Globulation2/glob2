from pathlib import Path
import shlex,json,subprocess,os
ROOT=Path.cwd();OUT=ROOT/'artifacts/air-overhead-profile';log=(ROOT/'artifacts/direct-flight-performance/build-release.log').read_text().splitlines()
basecompile=next(shlex.split(l) for l in log if ' -c ' in l and l.endswith('src/map/pathfind/MapPathfindBuilding.cpp'));baselink=next(shlex.split(l) for l in reversed(log) if l.startswith('g++ -o ') and '/src/glob2 ' in l)
src=(ROOT/'src/map/pathfind/MapPathfindBuilding.cpp').read_text();old='bool Map::buildingAvailable(Building *building, int swimClass, int x, int y, int *dist, BuildingRoute route)\n{'
insert='''
    // MEASUREMENT-ONLY: exact uniform-air octile cost to the footprint.
#ifdef AIR_ANALYTIC_VALIDATE
    static unsigned diag=0;
    if(swimClass==AIR_MOVEMENT_CLASS && diag++<20) {
        unsigned forbidden=0,blockers=0;
        for(int yy=0;yy<h;++yy)for(int xx=0;xx<w;++xx) {
            forbidden+=(getForbidden(xx,yy)&building->owner->me)!=0;
            blockers+=resourceBlocksAir(coordToIndex(xx,yy));
        }
        std::cerr << "AIR_QUERY route=" << int(route) << " resolved=" << int(building->resolveRoute(route))
            << " footprint=" << int(BuildingRoute::Footprint) << " terrain=" << hasAirTerrainConstraints()
            << " constrained=" << hasAirRoutingConstraints(building->owner->me) << " forbidden=" << forbidden << " blockers=" << blockers << "\\n";
    }
#endif
    int analyticDistance=-1;
    if(swimClass==AIR_MOVEMENT_CLASS && building->resolveRoute(route)==BuildingRoute::Footprint
        && !hasAirRoutingConstraints(building->owner->me)) {
        int cost=INT_MAX;
        for(int oy=0;oy<building->type->height;++oy)
            for(int ox=0;ox<building->type->width;++ox) {
                const int ax=warpDist1d(x,(building->posX+ox)&wMask,w);
                const int ay=warpDist1d(y,(building->posY+oy)&hMask,h);
                cost=std::min(cost,std::min(ax,ay)*GRADIENT_DIAGONAL_STEP+std::abs(ax-ay)*GRADIENT_STEP);
            }
        if(cost<GRADIENT_AT_GOAL-GRADIENT_UNREACHABLE)
            analyticDistance=(cost+GRADIENT_STEP/2)/GRADIENT_STEP;
    }
#ifndef AIR_ANALYTIC_VALIDATE
    if(analyticDistance>=0) { *dist=analyticDistance; return true; }
#endif
'''
assert old in src;src=src.replace(old,old+insert)
src=src.replace('*dist=gradientTiles(g);','''*dist=gradientTiles(g);
#ifdef AIR_ANALYTIC_VALIDATE
    struct Count { unsigned n=0; ~Count(){std::cerr << "ANALYTIC_CHECKS " << n << "\\n";} }; static Count count; if(analyticDistance>=0) ++count.n;
    if(analyticDistance>=0 && analyticDistance!=*dist) { std::cerr << "ANALYTIC_MISMATCH " << analyticDistance << " " << *dist << "\\n"; std::abort(); }
#endif''')
src='#include <climits>\n#include <iostream>\n'+src
for mode in ['validate']:
 p=OUT/mode;p.mkdir(exist_ok=True);cpp=p/'MapPathfindBuilding.cpp';cpp.write_text(src);obj=p/'MapPathfindBuilding.o';compile=basecompile.copy();oldobj=compile[compile.index('-o')+1];compile[compile.index('-o')+1]=str(obj);compile[-1]=str(cpp)
 if mode=='validate':compile.insert(compile.index('-c'),'-DAIR_ANALYTIC_VALIDATE=1')
 link=baselink.copy();link[link.index('-o')+1]=str(p/'glob2-experiment');link=[str(obj) if a==oldobj else a for a in link]
 (p/'commands.json').write_text(json.dumps({'compile':compile,'link':link},indent=2))
 (p/'experiment.diff').write_text(subprocess.run(['diff','-u',str(ROOT/'src/map/pathfind/MapPathfindBuilding.cpp'),str(cpp)],capture_output=True,text=True).stdout)
 with (p/'build.log').open('w') as f:
  for args in [compile,link]:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True,env=dict(os.environ,CCACHE_DIR='/dev/shm/glob2-air-ccache',TMPDIR='/dev/shm/glob2-air-tmp'))
 print(mode,'built',flush=True)
