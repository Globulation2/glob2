from pathlib import Path
import json,subprocess,os,re
ROOT=Path.cwd();OUT=ROOT/'artifacts/air-overhead-profile';native=ROOT/'artifacts/direct-flight-performance/native';results=[]
for case,start in [('islands',8192),('midgame24k',24000),('swamp',8192),('ordinary32',0),('lava-shield',8192),('constrained64',0)]:
 d=OUT/('diagnose-'+case);d.mkdir(exist_ok=True);save=next((native/'inputs').glob(case+'.game*'))
 args=[str(OUT/'validate/glob2-experiment'),'game','run','--load-game',str(save),'--ticks',str(start+384),'--benchmark-warmup','128','--compute-threads','4','--gpu','off','--output-dir',str(d/'game')]
 env=dict(os.environ,SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(d/'profile'),GLOB2_USER_DIR=str(d/'profile'))
 (d/'command.json').write_text(json.dumps(args,indent=2))
 with (d/'run.log').open('w') as log:subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
 j=json.load(open(d/'game/result.json'));b=json.load(open(native/f'{case}-direct-0/game/result.json'));assert all(j[k]==b[k] for k in ['ticks','initialChecksum','finalChecksum','benchmark_measured_ticks'])
 m=re.search(r'ANALYTIC_CHECKS (\d+)',(d/'run.log').read_text());results.append({'case':case,'analytic_queries_checked':int(m[1]) if m else 0,'native_checksums_match':True});print(results[-1],flush=True)
(OUT/'query-validation.json').write_text(json.dumps(results,indent=2))
