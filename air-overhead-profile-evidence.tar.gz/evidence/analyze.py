from pathlib import Path
import json,re
from collections import defaultdict
from callgrind_parser import parse_file
OUT=Path(__file__).resolve().parent
for case in ['islands','midgame24k','swamp']:
 runs={}
 for variant in ['master','hybrid']:
  d=OUT/f'{case}-{variant}'
  if not (d/'verification.json').exists():continue
  files=[parse_file(p) for p in d.glob('callgrind.out.*') if p.stat().st_size>100];files=[f for f in files if f['events']];assert files
  total=sum(f['totals']['Ir'] for f in files);reported=int(re.search(r'Collected\s*:\s*(\d+)',(d/'valgrind.log').read_text())[1]);assert total==reported,(total,reported)
  functions=defaultdict(int);edges=defaultdict(int)
  for f in files:
   for fn in f['functions']:functions[fn['function']]+=fn['cost']['Ir']
   for e in f['edges']:edges[(e['caller'],e['callee'])]+=e['cost']['Ir']
  run={'total_instructions':total,'threads':[{'thread':f['thread'],'total_instructions':f['totals']['Ir']} for f in files],'self':[{'function':n,'instructions':i} for n,i in sorted(functions.items(),key=lambda x:-x[1])],'edges':[{'caller':a,'callee':b,'instructions':n} for (a,b),n in sorted(edges.items(),key=lambda x:-x[1])],'files':files};runs[variant]=run
  (d/'analysis.json').write_text(json.dumps(run,indent=2))
 if len(runs)!=2:continue
 a,b=runs['master'],runs['hybrid'];af={r['function']:r['instructions'] for r in a['self']};bf={r['function']:r['instructions'] for r in b['self']}
 delta=[{'function':n,'master':af.get(n,0),'hybrid':bf.get(n,0),'delta':bf.get(n,0)-af.get(n,0)} for n in af.keys()|bf.keys()];delta.sort(key=lambda x:-x['delta'])
 summary={'case':case,'master_instructions':a['total_instructions'],'hybrid_instructions':b['total_instructions'],'instruction_delta':b['total_instructions']-a['total_instructions'],'instruction_percent':100*(b['total_instructions']/a['total_instructions']-1),'exclusive_deltas':delta}
 (OUT/f'{case}-comparison.json').write_text(json.dumps(summary,indent=2))
 print(case,'total',summary['master_instructions'],summary['hybrid_instructions'],round(summary['instruction_percent'],2),'%')
 for x in delta[:15]+delta[-5:]:print(round(x['delta']/1e6,2),'M',str(x['function'])[:220])
