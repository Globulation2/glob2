# Aborted setup-stage cohort

This entire288-job cohort is excluded from efficacy analysis. Independent correctness review found custom-catalogue gaps in pending prestige from NEW_BUILDING actions and positive-origin cancellation. Root requested a corrected frozen binary before attributing any performance, although the reviewed stock behavior was unaffected. No outcomes or model scores were inspected to make this decision.

The coordinator and counts monitor were stopped. Supported coordinator/worker cancellation controls prevented further admission. Exactly14 running engine children were identified through their own dedicated attempt supervisors and sent SIGTERM; supervisors remained alive to close compressed logs and retain termination records. Such operator-terminated attempts may have tooling category `crash` from negative exit; they are deliberate aborted attempts, not evidence of an engine robustness defect or successful measurement.

Final operational counts:10 previously completed jobs preserved,278 jobs cancelled;10 attempts accepted before cancellation and16 late attempts collected afterward. All26 attempts were collected and acknowledged through the runner. Both dedicated adaptive worker daemons were confirmed stopped with no queued/running/packing work. Completed and late records,compressed artifacts,original plan,input maps,bundle,source snapshot,registration and provenance remain retained. No manual cleanup or evidence deletion was performed.

- `abort-control.json`: cancellation authority and whole-cohort exclusion.
- `abort-attempts.json`: exact operator-terminated attempt/engine/supervisor identities.
- `abort-shutdown.json`: final counts,collection rounds and confirmed stopped daemons.

Root created a separate `artifacts/prestige/adaptive-v2` follow-on directory. It must use a newly registered corrected bundle after fresh validation and all288 newly played games with the same96 original map/rotation triples. No v1 records may substitute for v2 controls or outcomes. The simulation revision remains117 for the same uncommitted feature; source archive,binary and bundle identities must distinguish the corrected freeze. No v2 launch is authorized by this stop procedure; wait for root's new validation instruction.
