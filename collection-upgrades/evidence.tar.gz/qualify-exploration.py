import hashlib,json,subprocess
from pathlib import Path
root=Path('/Users/bradley/.codex/worktrees/adaptive-resource-gradients/glob2')
out=Path('/Users/bradley/glob2/artifacts/gradient-collection-upgrade')
binary=root/'build/gradient-throughput-release/src/glob2'
for name,threads,interval,ticks in [('adaptive-zero',2,'0',4096),('fixed-one',1,'512',2048),('fixed-four',4,'512',2048)]:
 d=out/name;d.mkdir(exist_ok=True)
 cmd=[str(binary),'game','run','--map-file','/Users/bradley/glob2/artifacts/gradient-training-1024/final-performance-maps/3ffa/map.map.gz','--game-seed','859231393']
 for _ in range(3):cmd+=['--player','warrush']
 cmd+=['--ticks',str(ticks),'--compute-threads',str(threads),'--gpu','off','--telemetry','checksums','--resource-gradient-probe','--resource-gradient-exploration',interval,'--resource-gradient-exploration-seed','2935','--output-dir',str(d)]
 (d/'command.json').write_text(json.dumps(cmd,indent=2))
 with (d/'run.log').open('w') as stream:subprocess.run(cmd,cwd=root,stdout=stream,stderr=subprocess.STDOUT,check=True)
for name,reference in [('adaptive-zero','native-final/one'),('fixed-one','fixed-four')]:
 for file in ['world.checksums','snapshot.checksums','game.replay.checksums']:
  assert (out/name/file).read_bytes()==(out/reference/file).read_bytes(),(name,file)
report=dict(status='passed',zero_matches_official=True,fixed_one_four_match=True,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
(out/'exploration-parity.json').write_text(json.dumps(report,indent=2));print(report)
