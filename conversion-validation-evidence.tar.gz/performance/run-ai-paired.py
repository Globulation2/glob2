#!/usr/bin/env python3
"""Local paired performance evidence; never schedules builds or correctness runs."""
import argparse
import json
import math
import platform
import statistics
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'test'))
from benchmark_parallel_compute import execute, digest


def ordering(variants, repeat):
    if len(variants) == 2:
        return variants if repeat % 2 == 0 else variants[::-1]
    # A balanced four-condition Latin square; smoke is never acceptance evidence.
    schedule = ((0, 1, 3, 2), (1, 2, 0, 3), (2, 3, 1, 0), (3, 0, 2, 1))
    return [variants[i] for i in schedule[repeat % 4]]


def verify_hashes(expected):
    for path, sha in expected.items():
        if digest(path) != sha:
            raise ValueError('changed input or binary: ' + path)


def authoritative_provenance(record, manifest_path, binary):
    """Verify recorded build identity; ROOT's current HEAD is not binary provenance."""
    if not record:
        return {'status': 'unavailable', 'binary_sha256': digest(binary)}
    expected = record.get('binary_sha256')
    if not expected:
        raise ValueError('binary provenance lacks binary_sha256')
    if digest(binary) != expected:
        raise ValueError('binary differs from recorded build: ' + str(binary))
    result = dict(record)
    if record.get('build_metadata'):
        path = Path(record['build_metadata'])
        if not path.is_absolute():
            path = manifest_path.parent / path
        build = json.loads(path.read_text())
        if build.get('binary_sha256') != expected or build.get('source_revision') != record.get('source_revision'):
            raise ValueError('build metadata disagrees with manifest provenance: ' + str(path))
        result['verified_build_metadata'] = str(path.resolve())
        result['build_metadata_sha256'] = digest(path)
        result['build'] = build
    result['status'] = 'verified recorded build identity'
    return result


def workload(scenario):
    args = scenario['args']
    target = int(args[args.index('--ticks') + 1])
    kind = scenario.get('measurement_kind')
    if kind is None:
        kind = 'fixed_window' if scenario['id'].endswith(('-early', '-middle', '-late')) else 'full_match'
    if kind not in ('fixed_window', 'full_match'):
        raise ValueError('unknown measurement_kind: ' + kind)
    start = scenario.get('start_tick', 0)
    if kind == 'fixed_window' and (start is None or target <= start):
        raise ValueError('fixed window needs a valid start tick and later end tick')
    return kind, start, target


def comparison(scenario, baseline, candidate, smoke):
    kind, start, target = workload(scenario)
    reasons = []
    if smoke:
        reasons.append('smoke runs are not acceptance evidence')
    if len(candidate) < 10:
        reasons.append('fewer than ten complete measured pairs')
    categories = []
    for row in candidate:
        reference = baseline[row['repeat']]
        before, after = reference['result'], row['result']
        bt, at = before.get('ticks'), after.get('ticks')
        be, ae = before.get('termination'), after.get('termination')
        if kind == 'fixed_window':
            eligible = bt == at == target and be == ae == 'tick_cap'
            category = 'complete_fixed_window' if eligible else 'early_or_mismatched_window'
        elif be == ae == 'tick_cap' and bt == at == target:
            eligible, category = True, 'matched_capped_workload'
        elif be == ae == 'engine_end' and bt == at and isinstance(bt, int) and start < bt < target:
            eligible, category = True, 'matched_natural_match_duration'
        else:
            eligible, category = False, 'different_match_duration_or_termination'
        categories.append(category)
        if not eligible:
            reasons.append('pair ' + str(row['repeat']) + ': ' + category)
    values = {}
    for metric in ('cpu_s', 'wall_s'):
        logs = [math.log(row[metric] / baseline[row['repeat']][metric]) for row in candidate]
        center = statistics.mean(logs)
        spread = statistics.stdev(logs) / math.sqrt(len(logs)) if len(logs) > 1 else None
        # Exact rounded t critical at ten pairs; conservatively retain df=9 for
        # larger suites instead of silently switching to a normal interval.
        critical_df = min(len(logs) - 1, 9)
        critical = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571,
                    6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262}.get(critical_df)
        values[metric] = {
            'paired_geometric_ratio': math.exp(center),
            '95_percent_paired_log_t_interval': None if spread is None else [math.exp(center - critical * spread), math.exp(center + critical * spread)],
            'paired_samples': len(logs), 'critical_df': critical_df,
        }
    values['measurement_kind'] = kind
    values['requested_start_tick'] = start
    values['requested_end_tick'] = target
    values['requested_window_ticks'] = target - start if kind == 'fixed_window' else None
    values['pair_workload_categories'] = categories
    values['acceptance_eligible'] = not reasons
    values['acceptance_ineligible_reasons'] = reasons
    values['interpretation'] = ('Complete fixed-span process cost, including startup/load and output.' if kind == 'fixed_window' else
        'Natural matches measure total cost to an outcome; capped runs measure cost to the cap. Different durations/outcomes cannot establish equal-work throughput, and a capped run is not a completed natural match.')
    values['ticks_and_termination'] = {
        'baseline': [{'repeat': row['repeat'], 'ticks': baseline[row['repeat']]['result'].get('ticks'), 'termination': baseline[row['repeat']]['result'].get('termination')} for row in candidate],
        'candidate': [{'repeat': row['repeat'], 'ticks': row['result'].get('ticks'), 'termination': row['result'].get('termination')} for row in candidate],
    }
    values['point_estimate_within_5_percent'] = not reasons and all(values[m]['paired_geometric_ratio'] <= 1.05 for m in ('cpu_s', 'wall_s'))
    values['upper_interval_within_5_percent'] = not reasons and all(values[m]['95_percent_paired_log_t_interval'] is not None and values[m]['95_percent_paired_log_t_interval'][1] <= 1.05 for m in ('cpu_s', 'wall_s'))
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('baseline', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repeats', type=int, default=10)
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--candidate-provenance', type=Path, help='JSON with source_revision, binary_sha256 and optional build_metadata')
    args = parser.parse_args()
    args.output = args.output.resolve()
    if args.repeats < 1 or (not args.smoke and (args.repeats < 10 or args.repeats % 2)):
        parser.error('acceptance requires at least ten paired rounds and an even count; smoke requires positive repeats')
    manifest = json.loads(args.manifest.read_text())
    if not manifest.get('scenarios') or len({s['id'] for s in manifest['scenarios']}) != len(manifest['scenarios']):
        raise ValueError('manifest needs nonempty, unique scenarios')
    for scenario in manifest['scenarios']:
        workload(scenario)
    variants = [('baseline', args.baseline, []), ('candidate-default', args.candidate, [])]
    if args.smoke:
        variants += [('candidate-inline', args.candidate, ['--compute-threads', '1', '--compute-experiments', 'none']),
                     ('candidate-worker1', args.candidate, ['--compute-threads', '1', '--compute-experiments', 'ai'])]
    binaries = {str(p.resolve()): digest(p) for p in (args.baseline, args.candidate)}
    fixtures = {}
    for scenario in manifest['scenarios']:
        for path, sha in scenario.get('fixture_sha256', {}).items():
            if path in fixtures and fixtures[path] != sha:
                raise ValueError('conflicting fixture hashes: ' + path)
            fixtures[path] = sha
    verify_hashes(binaries | fixtures)
    candidate_record = json.loads(args.candidate_provenance.read_text()) if args.candidate_provenance else manifest.get('execution_candidate')
    provenance = {'baseline': authoritative_provenance(manifest.get('execution_baseline'), args.manifest, args.baseline),
                  'candidate': authoritative_provenance(candidate_record, args.candidate_provenance or args.manifest, args.candidate)}
    args.output.mkdir(parents=True, exist_ok=False)
    metadata = {
        'platform': platform.platform(), 'machine': platform.machine(),
        'runner_source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'runner_source_base': subprocess.check_output(['git', 'rev-parse', 'origin/master'], cwd=ROOT, text=True).strip(),
        'runner_source_revision_is_not_binary_provenance': True,
        'binary_provenance': provenance, 'binaries': binaries, 'fixtures': fixtures,
        'manifest': manifest, 'manifest_sha256': digest(args.manifest),
        'runner_sha256': digest(__file__), 'repeats': args.repeats, 'warmups': 1,
        'smoke': args.smoke, 'smoke_is_nonacceptance': True,
        'variants': [{'name': name, 'binary': str(binary.resolve()), 'args': extra} for name, binary, extra in variants],
        'integrity': {'start': 'verified', 'end': 'pending'},
        'interpretation': 'External elapsed and all-thread process CPU. Ten-pair uncertainty is per scenario and describes machine repeatability, not variation across seeds. Full-match outcomes and censoring remain distinct. Requires an otherwise idle build machine.',
    }
    path = args.output / 'metadata.json'
    path.write_text(json.dumps(metadata, indent=2))
    rows = []
    try:
        with (args.output / 'measurements.jsonl').open('w') as out:
            for scenario in manifest['scenarios']:
                for repeat in range(-1, args.repeats):
                    for name, binary, extra in ordering(variants, repeat):
                        verify_hashes(binaries | fixtures)
                        row = execute(binary.resolve(), scenario['args'] + extra, args.output / f"{scenario['id']}-{repeat}-{name}")
                        if row['result'].get('status') != 'completed':
                            raise ValueError('engine did not report a completed run')
                        row.update(scenario=scenario['id'], repeat=repeat, variant=name)
                        for metric in ('cpu_s', 'wall_s'):
                            if not math.isfinite(row[metric]) or row[metric] <= 0:
                                raise ValueError('invalid measured duration')
                        rows.append(row)
                        out.write(json.dumps(row) + '\n'); out.flush()
                        print(scenario['id'], repeat, name, round(row['wall_s'], 3), round(row['cpu_s'], 3), row['result'].get('ticks'), row['result'].get('termination'), flush=True)
        verify_hashes(binaries | fixtures)
        metadata['integrity']['end'] = 'verified'
    except BaseException as error:
        metadata['integrity']['end'] = 'incomplete or rejected'
        metadata['error'] = str(error)
        raise
    finally:
        path.write_text(json.dumps(metadata, indent=2))
    summary = {}
    for scenario in manifest['scenarios']:
        selected = [r for r in rows if r['scenario'] == scenario['id'] and r['repeat'] >= 0]
        reference = {r['repeat']: r for r in selected if r['variant'] == 'baseline'}
        summary[scenario['id']] = {name: comparison(scenario, reference, [r for r in selected if r['variant'] == name], args.smoke) for name, _, _ in variants[1:]}
    (args.output / 'summary.json').write_text(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
