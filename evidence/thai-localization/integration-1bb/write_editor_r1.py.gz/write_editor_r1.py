import json,hashlib,re
from pathlib import Path
b=Path(__file__).resolve().parent;p=b/'google-draft.json';d=json.loads(p.read_text());a=d['entries']
# Independent editorial decisions authored after reading every provider output and its usage.
rows=[
('บุกเร็ว','AI strategy tag: concise early attack, not the imperative รีบ.','major'),
('เน้นป้องกัน','Strategy adjective becomes a concise focus label, retaining canonical ป้องกัน.','minor'),
('เน้นเศรษฐกิจ','Parallel strategy focus label; economy is the gameplay economy.','minor'),
('เน้นขยายพื้นที่','AI expansion strategy, not a generic biological expansion; does not constrain expansion to a particular building.','minor'),
('แบบทดลอง','Experimental AI tag, not the act of conducting an experiment.','minor'),
('เหมาะสำหรับผู้เริ่มต้น','Natural clear beginner-oriented tag; retain provider wording.',None),
('ไฟล์และโปรไฟล์ API','Validation heading covers file plus API profile, not a profile of a file.','major'),
('ไวยากรณ์และข้อจำกัดของโปรไฟล์','Separates syntax checking from profile restrictions, matching validation documentation.','minor'),
('การเริ่มต้นและฟังก์ชันเรียกกลับ','Callback is a software function, not returning a telephone call.','minor'),
('สถานะที่คงอยู่','Persistent runtime state survives callbacks/save, not a constant or immutable state.','major'),
('การเล่นด้วยค่าสุ่มที่กำหนด','Seed is a random-number seed in repeated gameplay fixtures, not a plant seed.','major'),
('การจำลองที่ทำซ้ำได้','Natural deterministic repeatability heading; retain.',None),
('บันทึกและเล่นต่อ','Save/resume game validation, concise game register rather than generic bureaucratic continuation.','minor'),
('ดี','Good connection quality; correct concise label.',None),
('พอใช้','Middle connection-quality grade, not fairness or justice.','major'),
('แย่','Low connection quality, not monetary poverty.','major'),
('เวลาไปกลับระหว่างผู้เล่นกับรีเลย์ ก่อนเริ่มแมตช์ (การหาแมตช์ด่วนหรือรายการตรวจสอบก่อนเริ่ม) ค่านี้เป็นเพียงค่าประมาณจากการทดสอบภูมิภาคเซิร์ฟเวอร์','Time of a network round trip, not physical travel; established รีเลย์ and แมตช์. Probe gives a regional estimate before play.','major'),
('ความหน่วง','Noun naming a measured delay, parallel to ปิง and ตามหลัง, not adjective ล่าช้า.','minor'),
('ความหน่วงจากการสั่งงานของคุณ: ตั้งแต่คลิกจนทุกคนเห็นคำสั่งเกิดผล เท่ากับครึ่งหนึ่งของค่าปิงบวกเวลาที่เกมกันไว้รับความแปรปรวนของความหน่วง','Explains input-to-shared-effect delay and jitter buffer in readable Thai; jitter is variability in network timing, not visual stutter.','major'),
('ระยะเวลาที่เกมของผู้เล่นตามหลังเวลาของแมตช์ ปกติจะไม่ถึง 1 วินาที (รวมความหน่วงของผู้เล่นด้วย) รีเลย์จะระบุว่าผู้เล่นช้าเมื่อตามหลังตั้งแต่ 2 วินาทีขึ้นไป','Preserves normal under1s and inclusive2s threshold; includes input delay, not time a player spends.','major'),
('ผู้เล่น AI','Clear established AI player label; retain.',None),
('การเงิน','Appropriate administration section label; retain.',None),
('บัญชี','Matches established account terminology; retain.',None),
('การตรวจสอบ','Consistent with existing Audit history ประวัติการตรวจสอบ; retain.',None),
('1 ชั่วโมง','Correct duration unit and numeral; retain.',None),
('1 วัน','Correct duration unit and numeral; retain.',None),
('1 สัปดาห์','Correct spelling and duration unit; retain.',None),
('30 วัน','Correct reporting-period duration; retain.',None),
('เล่นมากที่สุด','Natural map sort label for play count; retain.',None),
('ฟังและสังเกตโครงสร้างและพัฒนาการของเพลง','Concise listening instruction; development refers to progression of a composition.','minor'),
('ตรวจสอบว่าเพลงทั้งสามอารมณ์เล่นได้ถูกต้อง','Music moods are อารมณ์, and playback is heard, not modes displayed.','major'),
('ฟังว่าระดับเสียงเปลี่ยนอย่างฉับพลันผิดปกติระหว่างอารมณ์เพลงหรือไม่','Targets unexpected loudness jumps at mood changes without suggesting all transitions are defects.','minor'),
('ฟังว่ามีเสียงคลิก ช่วงเงียบ หรือการเปลี่ยนแปลงฉับพลันเมื่อเพลงวนซ้ำหรือไม่','A gap is a silence in loop playback, not a spoken whitespace sound.','major'),
('ฟังว่ามีวลีดนตรีสั้น ๆ ที่ซ้ำอย่างแข็งทื่อเกินไปหรือไม่','Natural music phrase and mechanical repetition wording; standard spacing around repetition mark.','minor'),
('สลับอารมณ์เพลงแล้วฟังการเปลี่ยนแปลงของจังหวะหรือเสียงประสาน','Harmony is musical เสียงประสาน; preserve switch/listen action and timing.','minor'),
('ตรวจสอบว่าอารมณ์เพลงช่วงก่อสร้างและต่อสู้ต่างจากช่วงสงบอย่างชัดเจน','Building/Combat/Calm are the three musical moods; avoid instructing the reviewer to compare actual construction and combat behavior.','major'),
('ฟังว่ามีเสียงซ่าหรือเสียงแตกพร่าในช่วงเบาหรือไม่','Audio hiss/roughness in quiet passages; concise listening instruction.','minor'),
('ฟังว่ามีเสียงเบสอู้อี้หรือเสียงแหลมบาดหูหรือไม่','Idiomatic audio description of muddy bass/harsh highs.','minor'),
('ตรวจสอบว่ายังได้ยินช่วงเพลงสงบขณะมีเสียงเกม','Specifies calm music remains audible alongside game sound, not simply a quiet stretch of any audio.','minor'),
('ฟังว่ามีเสียงโน้ตที่ขาดหายโดยไม่คาดคิดหรือไม่','Note dropout/cutoff, not an instruction to stop notes; concise idiom.','minor'),
('สาธารณะ: แสดงในคลัง','Public catalog visibility in map library; no unnecessary space before colon.','minor'),
('ไม่แสดงในรายการ: ทุกคนที่มีลิงก์เข้าถึงได้','Unlisted remains accessible through a link; complete concise statement, not an orphaned person phrase.','minor'),
('ส่วนตัว: เฉพาะคุณ','Concise private access description with consistent colon spacing.','minor'),
('เซิร์ฟเวอร์จำลองแมตช์นี้ซ้ำแล้ว และสถานะเกมของผู้เล่นทุกคนตรงกับการจำลองนั้น','Verification compares simulation state/checksums, not merely final match results.','major'),
('เซิร์ฟเวอร์กำลังตรวจสอบแมตช์นี้ คะแนนประเมินจะเปลี่ยนเมื่อผ่านการตรวจสอบแล้ว','Uses established แมตช์ and คะแนนประเมิน; verification, not merely completion of a check, releases ratings.','major'),
('สถานะเกมของผู้เล่นรายหนึ่งไม่ตรงกับการจำลองแมตช์ซ้ำของเซิร์ฟเวอร์ จึงใช้ผลจากเซิร์ฟเวอร์','Explains client/server divergence and authoritative result without claiming display disagreement proves truth.','major'),
('เซิร์ฟเวอร์ไม่สามารถจำลองแมตช์นี้ซ้ำได้ จึงไม่เปลี่ยนคะแนนประเมิน','Unverifiable replay does not change rating; rating is not leaderboard rank.','major'),
('แมตช์นี้ไม่ได้รับการตรวจสอบ','Not-applicable verdict is unchecked, not matchmaking and not a pending promise.','major'),
('เซิร์ฟเวอร์ตรวจสอบแมตช์นี้ไม่สำเร็จ จึงยังไม่เปลี่ยนคะแนนประเมิน ผู้ดูแลระบบสามารถตรวจสอบอีกครั้งได้','Temporary failed verification and retry authority preserved in concise Thai.','major'),
('การชำระเงินจริง','Live versus test payment mode; not cash as opposed to card.','major'),
('การชำระเงินทดสอบ','Correct test-mode payment label; retain.',None),
('การชำระเงินที่ไม่ระบุประเภท','Correct unclassified payment group; retain.',None),
('ช่วงเวลาปัจจุบัน','Reporting-period label; retain.',None),
('ช่วงเวลาก่อนหน้า','Previous reporting-period label; retain.',None),
('การมอบเครดิต','Game/studio credits granted by administration; not a financial loan.','major'),
('เครดิตที่ได้รับคืน','Returned game credits; retain.',None),
('ข้อพิพาท','Payment dispute label appropriate in finance journal; retain.',None),
('ข้อพิพาทสิ้นสุดลงแล้ว','Closed dispute status does not assert a particular resolution winner; retain.',None),
('แมตช์ที่เริ่มแล้ว','Analytics count/category heading, not an event notification; canonical แมตช์.','major'),
('แมตช์ที่เสร็จแล้ว','Analytics completed-match metric, parallel noun phrase.','major'),
('แมตช์ที่ยกเลิก','Analytics cancelled-match metric, parallel noun phrase.','major'),
('การเผยแพร่: {value0}','value0 is translated libraryName, not a numeric count; publication means publishing library releases, not printed documents.','major'),
('ยอดดาวน์โหลดที่บันทึกไว้: {value0}','value0 is library category name; preserve that slot as label rather than count.','minor'),
('เวลาจนงานเสร็จ: {value0} (วินาที)','value0 is productName and units remain seconds; admin completion-duration label.','minor'),
('จำนวนตัวอย่างงานที่เสร็จ: {value0}','value0 is productName; samples are observed completed jobs used for the weighted mean, not examples of finishing.','major'),
]
assert len(a)==len(rows)==65
h=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
entries=[]
for e,(target,reason,severity) in zip(a,rows):
 assert set(re.findall(r'\{[^{}]+\}',e['source']))==set(re.findall(r'\{[^{}]+\}',target))
 assert '\u200b' not in target
 i=len(entries)
 context=('platform/packages/protocol/src/ais.ts; platform/apps/web/src/pages/Ais.tsx; docs/scripting/javascript.md:374-375' if i<13 else 'platform/packages/protocol/src/connectionQuality.ts' if i<20 else 'platform/apps/web/src/admin/Admin.tsx; platform/apps/web/src/admin/presentation.ts' if i<28 else 'platform/apps/web/src/pages/Maps.tsx' if i==28 or 40<=i<=42 else 'platform/apps/web/src/music/Validation.tsx' if 29<=i<=39 else 'platform/apps/web/src/pages/Match.tsx:44-54' if 43<=i<=48 else 'platform/apps/web/src/admin/presentation.ts')
 entries.append({'id':e['id'],'source':e['source'],'provider_draft':e['provider_draft'],'proposed_target':target,'source_value_sha256':h(e['source']),'draft_value_sha256':h(e['provider_draft']),'proposed_value_sha256':h(target),'decision':'retain_provider' if target==e['provider_draft'] else 'propose_correction','severity':severity,'rationale':reason,'confidence':'high','usage':context,'unresolved_uncertainty':False})
r={'reviewer':'thai_brief','role':'independent Thai editor','round':'initial65','status':'COMPLETE_INDEPENDENT_EDITORIAL_PROPOSALS_NOT_FINAL_APPROVAL','independence':'Read every provider draft and actual source usage before reading meaning reviewer findings; no peer findings consulted. No live catalogs or source edited.','source_contract_sha256':d['source_sha256'],'source_file_sha256':hashlib.sha256((b/'sources.json').read_bytes()).hexdigest(),'draft_file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_map_sha256':h({e['id']:e['source'] for e in a}),'draft_map_sha256':h({e['id']:e['provider_draft'] for e in a}),'proposed_map_sha256':h({e['id']:e['proposed_target'] for e in entries}),'reviewed_keys':[e['id'] for e in entries],'entries':entries,'findings':[{'id':e['id'],'severity':e['severity'],'proposed':e['proposed_target'],'reason':e['rationale']} for e in entries if e['decision']=='propose_correction'],'accepted_english':[],'unresolved_uncertainty':[],'references':{'authoritative':'English source plus actual use and protocol behavior; FR/JA/VI are comparisons only.','existing_thai':'Existing th.json ปิง/รีเลย์/เครดิต/คะแนนประเมิน plus reviewed brief แมตช์ and ค่าสุ่ม. Music manual mood-blend wording establishes ก่อสร้าง/ต่อสู้/สงบ.','comparison_catalogs':{'locales':['fr','ja','vi'],'keys':['Rush','Persistent state','Seeded gameplay','Fair','Poor','Live payments','Credit grant','{value0} publications','{value0} completion samples','Check that building and combat feel distinct from calm.']},'orthography_basis':'Existing language-brief.json actual Royal Society and W3C consultations reused as campaign guidance; no new dictionary attestation claimed for these65. Thai online text uses normal browser word breaking without native U+200B. Standard phrase spaces and repetition mark spacing reviewed.'},'limits':['Agent-reviewed Standard Thai; no native-human certification.','No final text approval until reconciliation and fresh final review.','No browser, runtime, packaging, billing-operation, or product build qualification from this language review.']}
out=b/'editor-r1.json';assert not out.exists(),'Preserve initial independent review immutable';out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'entries':len(entries),'retained':sum(e['decision']=='retain_provider' for e in entries),'findings':len(r['findings']),'file_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'proposed_map_sha256':r['proposed_map_sha256']},indent=2))
