"""Owner cloud_adapter ONLY: independent exact carry/context acceptance, no gates."""
import copy,hashlib,importlib.util,json
from pathlib import Path
ROOT=Path.cwd();K=ROOT/'artifacts/thai-localization-integrated-1bb';H=K/'history/predecessor-48';OWNER='cloud_adapter'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p;p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
s=importlib.util.spec_from_file_location('tpcarry',ROOT/'tools/localization/translation_program.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t)
m=read(K/'manifest.json');oldm=read(H/'manifest.json');src={s:read(K/('source/'+s+'.json')) for s in ['native','online']};oldsrc={s:read(H/('source/'+s+'.json')) for s in src};th={'native':t.CHECKER.read_table(K/'drafts/th/texts.th.txt')[0],'online':read(K/'drafts/th/th.json')};oldth={'native':t.CHECKER.read_table(H/'drafts/th/texts.th.txt')[0],'online':read(H/'drafts/th/th.json')}
assert t.sources(ROOT)[4]==m['source_sha256']
assert (ROOT/'data/texts.th.txt').read_bytes()==(K/'drafts/th/texts.th.txt').read_bytes() and (ROOT/'platform/packages/i18n/locales/th.json').read_bytes()==(K/'drafts/th/th.json').read_bytes()
allrows=[]
for surface,cat in oldsrc.items():
 for key,source in cat.items():
  assert src[surface][key]==source and th[surface][key]==oldth[surface][key]
  allrows.append({'id':surface+':'+key,'source':source,'target':th[surface][key]})
assert len(allrows)==6321
context=read(K/'checks/context-changes-1bb.json')
for e in context['changes']:
 p=ROOT/e['path'];assert (sha(p) if p.is_file() else None)==e['new_sha256']
assert len(context['changes'])==94
fresh_context={'native:[settings Command your colony without opening a menu.]':'Newcommander placeholder reuses reviewedcontrol-colony sentence; commandpurpose unchanged; readableThaiwording remains correct.','native:[Send]':'Newcommander Enter action is sendingcommand; ส่ง remains correct.','native:[Close]':'Newcommander Esc action closes inputscreen; ปิด remains correct.','online:Walk':'ExplicitACTION_LABELS walk maps to displayWalk; เดิน remains same walkinganimation.','online:Swim':'ExplicitACTION_LABELS swim maps to displaySwim; ว่ายน้ำ remains same swimminganimation.','online:Harvest':'ExplicitACTION_LABELS harvest maps to displayHarvest; เก็บเกี่ยว remains same gatheranimation.','online:Fight':'ExplicitACTION_LABELS fight maps to displayFight; ต่อสู้ remains same combatanimation.','online:Fly':'ExplicitACTION_LABELS fly maps to displayFly; บิน remains same explorerflight animation.'}
assessment={'owner':OWNER,'source_sha256':m['source_sha256'],'source_context_manifest_sha256':sha(K/'checks/context-changes-1bb.json'),'context_files_verified_current':94,'semantic_assessment':[
'NativeThaiTrueTypeFont shapingroute unchanged; addedmsLatin authoredadvance branch does not replace Thaiassets. SharedTextLayout refactor exposes samevalidatedcluster helper; TextEditor nowuses clusterends. CorrectThai wording/hints remainmeaningvalid; freshvisual/platform validation remains pending.',
'Nativechat/username/LAN bytebounds reject wholeedits; map/room/share paths no longer bytecut authorcontent. None changes fixedThai labels into simulationidentifiers. Composer commmanderrawEnglish replaced3reviewedkeys; freshly rechecked in context.',
'Statistics topicrows, tutorialforeground/collapse, minimaplayering and WebGLalpha are presentation/input changes with unchanged statistic/tutorial meanings. No visualsuccess inferred.',
'FiveStudio callers onlyadd stableidPrefix; sixteenpreviousowned supplement entries retain samepricing/unavailable/save/finish-request contexts. SharedCreditPanel translates domainlabels and usesactualcreditcount, maintaining preexistingcredit meanings.',
'SkinexplicitACTION_LABELS maps exactlythe same5Englishdisplaywords; fresh5context recheck approvesThai verbs. MODELS name keys retain Worker/Warrior/Explorer/Swarm; unusednewmodelSentenceName helper has noactualconsumer. Materials/shapes/descriptions remain unchangedownedlabels. SkinCopyName truncateswholegraphemes toformUTF16limit withouttranslating authoredprefix; no newfixedwording.',
'CSSshape/material/sets/sidebar/layout changes alter containment/accessibility; do not change labelconcepts. Languagepickerth/ThaiScript/LTR remains registered whilems/bnadded and contradictoryscriptselection hardened.',
'Othernewadmin/music/AI/verdict/visibility display wrapping is covered by genuine separateblind65review. Otherunownedoldonlineowner bindings remaintheir responsibility.',
'All94changedfile names and old/newhashes inspected/verified. Productionusage diffs above read; generatedbrowseri18n assessed through authoritativei18nTSsource, not claimed semanticreading of its minified bundle. Tests/harness/asset-export tooling assessed as verificationcontext only; no executionclaim.'
],'fresh_context_rechecked_keys':fresh_context,'findings':[],'unresolved_uncertainty':[],'limits':'Ownerlinguisticcarry/contextscope only; no sharedrenderer/platform/build/browser gates passed.'}
contextpath=K/'reviews/cloud-adapter-context-acceptance.json';write(contextpath,assessment)
batches={b['id']:b for b in m['batches']};created=[];fresh_count=0;oldcount=0
for candidate in sorted((K/'reviews/unsigned-owner-candidates/final-editor').glob('*.json')):
 c=read(candidate)
 if c['expected_owner']!=OWNER:continue
 b=batches[c['id']];ids=b['keys'];p=K/c['prior_owner_record']['path'];prior=read(p)
 assert sha(p)==c['prior_owner_record']['sha256'] and prior['editor']==OWNER and prior['source_sha256']==oldm['source_sha256'] and set(prior['approved_keys'])==set(ids) and len(prior['approved_keys'])==len(ids)
 targets={i:th[i.split(':',1)[0]][i.split(':',1)[1]] for i in ids};sources={i:src[i.split(':',1)[0]][i.split(':',1)[1]] for i in ids}
 for i in ids:
  surface,key=i.split(':',1);assert oldsrc[surface][key]==sources[i] and oldth[surface][key]==targets[i]
 assert canonical(targets)==c['target_sha256']==prior['target_sha256']
 fresh=[i for i in ids if i in fresh_context];carried=[i for i in ids if i not in fresh]
 r={'id':b['id'],'editor':OWNER,'source_sha256':m['source_sha256'],'target_sha256':canonical(targets),'approved_keys':ids,'fresh_reviewed_keys':fresh,'carried_keys':carried,'carried_subset_sha256':canonical({i:targets[i] for i in carried}),'findings':[],'accepted_english':copy.deepcopy(prior.get('accepted_english',[])),'status':'ownerapproved exactsource/targetcarry plus actualcontextassessment','prior_owner_record':c['prior_owner_record'],'context_acceptance':{'path':str(contextpath.relative_to(K)),'sha256':sha(contextpath)},'fresh_context_rationales':{i:fresh_context[i] for i in fresh},'review_basis':'Alloldtuples independentlyasserted equal; priorownapprovedmembership and bytehash verified. Onlylistedfreshcontextkeys freshlyreread now; no freshwholecatalogreading claim.','certification':'Agent-reviewed; not native-human-certified'}
 out=K/'reviews/final-editor'/(b['id']+'.json');write(out,r);created.append({'role':'final-editor','id':b['id'],'path':str(out.relative_to(K)),'sha256':sha(out),'keys':len(ids)});fresh_count+=len(fresh);oldcount+=len(ids)
assert len(created)==30 and oldcount==3485 and fresh_count==8
c=read(K/'reviews/unsigned-owner-candidates/final-adversarial/online-master-1bb-001.json');assert c['expected_owner']==OWNER
p=Path(c['genuine_fresh_review']['path']);p=p if p.is_absolute() else ROOT/p;prior=read(p);assert sha(p)==c['genuine_fresh_review']['sha256'] and prior['adversarial_reviewer']==OWNER and prior['source_sha256']==sha(ROOT/'platform/packages/i18n/locales/en.json')
b=batches['online-master-1bb-001'];targets={i:th['online'][i[7:]] for i in b['keys']};assert set(prior['approved_keys'])==set(b['keys']) and len(prior['approved_keys'])==65 and canonical(targets)==prior['target_sha256']
for e in prior['per_key_reviews']:assert canonical(th['online'][e['id'][7:]])==e['target_sha256'] and canonical(src['online'][e['id'][7:]])==e['source_sha256']
r={'id':b['id'],'adversarial_reviewer':OWNER,'source_sha256':m['source_sha256'],'target_sha256':canonical(targets),'approved_keys':b['keys'],'fresh_reviewed_keys':[],'carried_keys':b['keys'],'carried_subset_sha256':canonical(targets),'findings':[],'accepted_english':prior['accepted_english'],'prior_genuine_fresh_review':c['genuine_fresh_review'],'source_hash_scope_transition':'Priorblind65source93fullENfile+perkeysourcehashes nowwrappedbyglobal1bsourcehash; actualsource/targets exact; no secondfresh65reading claimed.','independence':prior['independence'],'certification':'Agent-reviewed; not native-human-certified'}
out=K/'reviews/final-adversarial'/(b['id']+'.json');write(out,r);created.append({'role':'final-adversarial','id':b['id'],'path':str(out.relative_to(K)),'sha256':sha(out),'keys':65})
write(K/'reviews/cloud-adapter-owner-carry-approval.json',{'owner':OWNER,'source_sha256':m['source_sha256'],'revision':m['revision'],'old6321tupleequality_verified':True,'owned_editor_batches':30,'owned_editor_keys':3485,'fresh_context_keys':8,'carried_editor_keys':3477,'owned_adversarial_batches':1,'owned_adversarial_keys':65,'prior_fresh65blind_record':c['genuine_fresh_review'],'context_acceptance':{'path':str(contextpath.relative_to(K)),'sha256':sha(contextpath)},'records':created,'otherowners_signed':False,'gate_passes_created':False})
print('Ownerrecords written:',len(created),'editor3485/adversarial65;8freshcontext keys, no otherowners/gates')
