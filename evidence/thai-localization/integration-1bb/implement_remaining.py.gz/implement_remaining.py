from pathlib import Path
B=Path('platform/apps/web/src')
def change(file,old,new,count=1):
 p=B/file;s=p.read_text();assert s.count(old)==count,(file,old,s.count(old),count);p.write_text(s.replace(old,new))
# Browser dialogs preserve exact choice, action and authored parameters.
for f in ['pages/TerrainStudio.tsx','pages/AiBuildingStudio.tsx']:
 for text in ['Leave the editor with unsaved changes?','Restore this saved draft? The current draft will remain in history.']:
  change(f,"window.confirm('"+text+"')","window.confirm(t('"+text+"'))") if text.startswith('Leave') else change(f,"'"+text+"',","t('"+text+"'),")
for f,text in [('pages/TerrainStudio.tsx','Restore this version as the current draft? The current draft stays in history.'),('pages/Generators.tsx','Remove this generator from the library? Existing matches retain their maps.'),('pages/MusicStudio.tsx','Delete this conversation and its source history? Finished music remains in your library.')]:change(f,"'"+text+"',","t('"+text+"'),")
for f,text in [('pages/CodingStudio.tsx','Delete this private project and its history?'),('pages/Ais.tsx','Delete this AI and its published versions?')]:change(f,"window.confirm('"+text+"')","window.confirm(t('"+text+"'))")
change('pages/Ais.tsx',"window.prompt('Reason for hiding this AI')","window.prompt(t('Reason for hiding this AI'))")
change('pages/BuildingStudio.tsx','`Delete “${name}”? This removes the account draft and this device’s recovery copy. Published releases remain available.`',"t('Delete “{value0}”? This removes the account draft and this device’s recovery copy. Published releases remain available.', { value0: name })")
change('pages/BuildingLibrary.tsx','`Withdraw “${family.name}” and all its releases? Library downloads and links will stop working. Studio drafts and copies embedded in existing maps or saves remain available.`',"t('Withdraw “{value0}” and all its releases? Library downloads and links will stop working. Studio drafts and copies embedded in existing maps or saves remain available.', { value0: family.name })")
change('admin/Operations.tsx','`Reconcile ${usage.input} input (${usage.cachedInput} cached; ${usage.cacheWrite} cache write) and ${usage.output} output tokens? Verified usage is charged up to the ${row.reserved}-credit reservation and the remainder is released.`',"t('Reconcile {value0} input ({value1} cached; {value2} cache write) and {value3} output tokens? Verified usage is charged up to the {value4}-credit reservation and the remainder is released.', { value0: usage.input, value1: usage.cachedInput, value2: usage.cacheWrite, value3: usage.output, value4: row.reserved })")
change('admin/Matches.tsx','empty="No matches found."',"empty={t('No matches found.')}")
# Known source notices translate at render, raw authored titles/IDs remain untouched.
for f in ['pages/BuildingLibrary.tsx','skins/Reporting.tsx','skins/Store.tsx','skins/MeshPreview.tsx','pages/Maps.tsx']:
 p=B/f;s=p.read_text();rel='../i18n.tsx';s="import { displayMessage } from '"+rel+"';\n"+s; p.write_text(s)
change('pages/BuildingLibrary.tsx','<p role="status">{message}</p>','<p role="status">{displayMessage(message)}</p>')
change('skins/Reporting.tsx','<p role="status">{message}</p>','<p role="status">{displayMessage(message)}</p>')
change('skins/Store.tsx','<p role="status">{message}</p>','<p role="status">{displayMessage(message)}</p>')
change('skins/MeshPreview.tsx',"props.interactive === false ? t('Preview unavailable') : error","props.interactive === false ? t('Preview unavailable') : displayMessage(error)")
change('pages/Maps.tsx','<div className="notice">{message}</div>','<div className="notice">{displayMessage(message)}</div>')
change('pages/Maps.tsx','          {fileError}\n','          {fileError && displayMessage(fileError)}\n')
change('music/Library.tsx','<p role="alert">{notice}</p>','<p role="alert">{displayMessage(notice)}</p>',count=1)
change('format.ts',"if (!id) return 'AI';","if (!id) return 'AI';\n  if (id === 'none') return t('Nobody');")
# Ensure the new stored status/fallback sources are inventoried by existing tooling.
change('sets/Workspace.tsx',"import { displayMessage } from '../i18n.tsx';","import { displayMessage, message as sourceMessage } from '../i18n.tsx';")
change('sets/Workspace.tsx',"'This sheet is used by an entry. Change its spritesheet or remove that entry before removing the sheet.',","sourceMessage('This sheet is used by an entry. Change its spritesheet or remove that entry before removing the sheet.'),")
change('pages/BuildingStudio.tsx',"kind === 'array' ? 'Enter a valid JSON array.' : 'Enter valid JSON.',","kind === 'array' ? t('Enter a valid JSON array.') : t('Enter valid JSON.'),")
change('pages/BuildingStudio.tsx',"setError(kind === 'array' ? 'Enter a valid JSON array.' : 'Enter valid JSON.');","setError(kind === 'array' ? sourceMessage('Enter a valid JSON array.') : sourceMessage('Enter valid JSON.'));")
change('pages/BuildingStudio.tsx',"element.setCustomValidity(t('Enter valid JSON.'));","element.setCustomValidity(kind === 'array' ? t('Enter a valid JSON array.') : t('Enter valid JSON.'));")
# These fallbacks are owned presentation strings; externally supplied diagnostics stay raw.
change('pages/Maps.tsx',"import { displayMessage } from '../i18n.tsx';","import { displayMessage, MessageError, message as sourceMessage } from '../i18n.tsx';")
change('pages/Maps.tsx',"throw new Error(\n            'Checking the map is taking longer than usual.","throw new MessageError(\n            'Checking the map is taking longer than usual.")
change('pages/Maps.tsx','checked.reason ?? "The game couldn\'t load this map."','checked.reason ?? sourceMessage("The game couldn\'t load this map.")')
change('pages/Maps.tsx',"'Uploaded. The server checks the file and draws a preview; this takes a moment.',","sourceMessage('Uploaded. The server checks the file and draws a preview; this takes a moment.'),")
change('music/Library.tsx',"import { displayMessage } from '../i18n.tsx';","import { displayMessage, message as sourceMessage } from '../i18n.tsx';")
change('music/Library.tsx',"error.message ?? 'Download failed.'","error.message ?? sourceMessage('Download failed.')")
