import pathlib,json,hashlib,re
r=pathlib.Path(__file__).resolve().parent;p=r/'edited.json';d=json.loads(p.read_text());e=d['entries'];assert len(e)==30
h=lambda b:hashlib.sha256(b).hexdigest();canon=lambda x:json.dumps(x,sort_keys=True,ensure_ascii=False).encode()
reasons=[
'Freshly rechecked actual Player/Library/Workspace construction soundtrack mood: การก่อสร้าง denotes construction process, with raw Building mood IDs unchanged.',
'Freshly rechecked Conversation ongoing generation branch: กำลังสร้าง preserves in-progress action, distinct from queued, checking and delivered.',
'Actual AI/generator report reason broken is nonworking software: ใช้งานไม่ได้ is accurate, while submitted broken identifier remains untouched.',
'Admin chart y-axis describes account count per day; จำนวนบัญชีต่อวัน preserves quantity/unit without adding cumulative interpretation.',
'Admin match chart y-axis describes count per day; จำนวนแมตช์ต่อวัน retains established match terminology.',
'Guest chart series means guest accounts, consistently บัญชีผู้เยี่ยมชม; no claim of signed-in membership.',
'Registered chart series explicitly retains registered accounts, contrasting correctly with guests.',
'Filtered match-list empty state clearly says no matches found; does not imply the service failed.',
'Failure wrapper preserves value0 exactly for raw diagnostic or separately translated owned timeout. No instruction translates user/runtime diagnostic content.',
'Launch-timeout guidance accurately reports failure to start within allowed time, with browser support check OR restart; does not assert unsupported browser as certain cause.',
'Browser renderer waiting status retains ongoing loading and browser rendering-system meaning, not an image editing instruction.',
'Preview fallback retains failed preview, not successful rendering or saved-source validation.',
'Generation fallback retains failure to generate and leaves separate diagnostic channel untouched.',
'Manual array-required JSON validity instruction retains array shape and JSON acronym; not satisfied by an arbitrary valid JSON object.',
'Actual referenced-sheet removal guard requires changing the entry spritesheet OR deleting that entry BEFORE removing this sheet. Thai preserves dependency, alternatives and sequence.',
'Music-download fallback accurately reports download failure, without introducing a payment or provider outcome.',
'Actual upload flow times out in checking before createMap. Thai states map not created and requests retry in a few minutes; it does not promise an existing map or require re-payment.',
'Map checker fallback preserves inability of the game to load this map; not a file-deletion or download error.',
'Upload notice retains completed upload, server file checking and preview generation still taking a moment; it does not claim validation already passed.',
'Confirm prompt retains leaving editor with changes unsaved; question remains decision-neutral and cancel path unaffected.',
'Saved-draft restore confirmation retains restoration of selected saved draft and explicit retention of current draft in history.',
'Version adoption confirmation retains setting selected version as current draft and keeping prior current draft in history.',
'Private-project deletion confirmation includes project AND its history; does not falsely promise recoverability.',
'Generator removal confirmation preserves removal from library and existing matches retaining their original maps; does not claim removal of already embedded maps.',
'AI hide-reason prompt retains reason for hiding this AI; reason entered by user remains authored, not translated.',
'AI deletion confirmation includes published versions, not merely private draft. Thai all published versions is faithful to plural its published versions.',
'Building-draft deletion confirmation preserves authored value0 in quotes, deletes account draft AND this device recovery copy, and explicitly keeps published releases available.',
'Family withdrawal confirmation preserves authored value0, all releases, download/link breakage, and continued availability of studio drafts and copies embedded in existing maps/saves.',
'Music-conversation deletion confirmation covers conversation and source history while preserving finished music in library; no promise to retain deleted source history.',
'Admin recover confirmation preserves all five numeric positions exactly: input value0, cached-read value1, cache-write value2, output value3, reserved credits value4. It caps verified usage charges at reservation and returns/releases unused balance, not the whole charge; no cash-refund promise.'
]
assert len(reasons)==len(e)
rows=[]
for x,reason in zip(e,reasons):
 assert isinstance(x['target'],str) and '\u200b' not in x['target']
 tokens=lambda s:sorted(re.findall(r'\{[^{}]+\}',s))
 assert tokens(x['source'])==tokens(x['target']),x['id']
 rows.append({**x,'source_value_sha256':h(canon(x['source'])),'target_value_sha256':h(canon(x['target'])),'status':'approved','rationale':reason,'findings':[]})
target=h(canon({x['id']:x['target'] for x in e}));assert target==d['target_sha256']
report={'adversarial_reviewer':'online_adversarial','fully_blind_independent_initial_pass':True,'independence_scope':'Read only this edited.json source/context/target file and actual caller source, plus own prior fresh3 source judgment. No peer reconciliation, meaning or editor records read for this30. Prior65 metadata exposure did not include these27 supplemental entries and is recorded separately.','source_sha256':d['source_sha256'],'target_sha256':target,'candidate_file_sha256':h(p.read_bytes()),'source_values_sha256':h(canon({x['id']:x['source'] for x in e})),'hash_encoding':'File hash raw bytes; per-value and ID→value hashes SHA256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).','fresh_reviewed_keys':[x['id'] for x in e],'approved_keys':[x['id'] for x in e],'entries':rows,'findings':[],'accepted_english':[],'callsite_index_sha256':h((r/'adversarial-callsite-index.json').read_bytes()),'validation':{'entries_read':30,'source_target_placeholders_exact':True,'online_U200B_count':0,'all_targets_string_shape':True,'no_live_target_edits':True,'no_browser_or_build_for_language_review':True},'status':'all30 approved; zero findings; no open uncertainty'}
(r/'final-adversarial.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('report_sha256',h((r/'final-adversarial.json').read_bytes()));print('target_sha256',target)
