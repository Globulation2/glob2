#!/usr/bin/env python3
"""Create UNSIGNED successor after final65 import+clean commit. Never signs owners/gates."""
import argparse,copy,hashlib,importlib.util,json,shutil,subprocess
from pathlib import Path
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'SConstruct').is_file())
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(x):return sha(json.dumps(x,sort_keys=True,ensure_ascii=False).encode())
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
previous=load('oldbuilder',ROOT/'artifacts/thai-localization/checks/final-ship-successor-builder/build_successor.py')
def flat(d):return {s+':'+k:v for s,c in d.items() for k,v in c.items()}
def compare(oldsrc,oldth,newsrc,newth,contract):
 old,new,prior,current=map(flat,[oldsrc,newsrc,oldth,newth])
 if len(old)!=6321 or set(old)!=set(prior) or len(new)!=6386 or set(new)!=set(current):raise ValueError('Expected exact6321→6386 source/target inventory')
 if len(contract)!=65 or any(not k.startswith('online:') for k in contract) or set(new)-set(old)!=set(contract):raise ValueError('Expected exactly65 added online contract IDs')
 rows=[]
 for k in sorted(old):
  if old[k]!=new.get(k):raise ValueError('Old source changed: '+k)
  if prior[k]!=current[k]:raise ValueError('Old target changed: '+k)
  rows.append({'id':k,'source_sha256':canonical(old[k]),'target_sha256':canonical(prior[k]),'source_equal':True,'target_equal':True})
 for k,v in contract.items():
  if new[k]!=v:raise ValueError('New source contract mismatch: '+k)
  if not isinstance(current[k],str) or not current[k].strip() or '\u200b' in current[k]:raise ValueError('New online target blank/nonstring/nativehint: '+k)
 return rows

def fresh_owner(record,role,legacy_field):
 allowed={'final-editor':{'final-editor','independent Thai editor'},'final-meaning':{'final-meaning','independent meaning reviewer'},'final-adversarial':{'final-adversarial','independent adversarial reviewer'}}[role]
 declared=record.get('role')
 if declared is not None and declared not in allowed:raise ValueError('Explicit freshreview role mismatch: '+role)
 legacy=record.get(legacy_field)
 scoped=record.get('reviewer') if declared in allowed else None
 if legacy and scoped and legacy!=scoped:raise ValueError('Conflicting freshreview owneridentities: '+role)
 owner=legacy or scoped
 if not isinstance(owner,str) or not owner.strip():raise ValueError('Missing role-scoped owneridentity: '+role)
 return owner

def verify_fresh65(spec,edited,actual,paths,english_file_sha256):
 # Actual campaign65 contract binds fullEnglish FILESHA, unlike prior52 IDmapSHA.
 if spec['source_sha256']!=english_file_sha256:raise ValueError('FullEnglish sourcefilehash changed')
 ids={e['id'] for e in spec['entries']};targets=edited.get('targets')
 if targets is None:targets={e['id']:e['target'] for e in edited['entries']}
 if edited['source_sha256']!=spec['source_sha256'] or set(targets)!=ids or targets!=actual or edited['target_sha256']!=canonical(targets):raise ValueError('Fresh65 source/actualtarget/membership mismatch')
 owners=[];proofs={}
 for role,field in [('final-meaning','reviewer'),('final-editor','editor'),('final-adversarial','adversarial_reviewer')]:
  path=Path(paths[role]);r=read(path);owner=fresh_owner(r,role,field)
  if not owner or r.get('source_sha256')!=spec['source_sha256'] or r.get('target_sha256')!=canonical(targets) or len(r.get('approved_keys',[]))!=len(ids) or set(r.get('approved_keys',[]))!=ids or r.get('findings') or r.get('unresolved_uncertainty') or r.get('open_uncertainty'):raise ValueError('Fresh65 genuinefinalproof invalid: '+role)
  owners.append(owner);proofs[role]={'path':str(path),'sha256':sha(path.read_bytes()),'owner':owner}
 if len(set(owners))!=3:raise ValueError('Fresh65 roleowners not distinct')
 return proofs

def context_inventory(root,base,head):
 paths=subprocess.check_output(['git','diff','--name-only',base,head],cwd=root,text=True).splitlines();out=[]
 for p in paths:
  native=p.startswith(('src/','libgag/','libusl/','scons/','mobile/','darwin/','tools/TranslationPreviewHarness','data/fonts/','browser/')) or p=='SConstruct'
  online=(p.startswith('platform/') and '/locales/' not in p) or p.startswith('browser/')
  if not(native or online):continue
  def blob(rev):
   r=subprocess.run(['git','show',rev+':'+p],cwd=root,capture_output=True);return sha(r.stdout) if r.returncode==0 else None
  out.append({'path':p,'old_sha256':blob(base),'new_sha256':blob(head),'affects_surfaces':(['native'] if native else [])+(['online'] if online else []),'assessment':'Owner must assess actual sharedrender/layout/callsite semantic context; exactcatalog equality alone is not contextapproval.'})
 return out

def unsigned_candidate(role,proof,batch,sourcehash,targethash,contexts,archive):
 return {'kind':'UNSIGNED owner-carry candidate; NOT approval','id':batch['id'],'source_sha256':sourcehash,'target_sha256':targethash,'expected_owner':proof['owner'],'role':role,'candidate_carried_keys':batch['keys'],'fresh_reviewed_keys':[],'approved_keys':[],'owner_accepted':False,'required_checks':['Recompute each old source+target equality and genuine priorapprovedmembership/recordhash independently.','Inspect changed shared/callsite context files relevant to your batch; classify unchangedsemanticusage or freshly recheck affectedkeys with exactsource/targethashes.','Write your OWN final-role record only after checks; never adopt this unsignedtemplate as a signature.'],'context_change_evidence':contexts,'prior_owner_record':{'path':str(archive/proof['path']),'sha256':proof['sha256']},'old_platform_visual_gates_carried':False}

def run(args):
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
 if head!=args.revision or subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT).strip():raise ValueError('Exact final committed fullHEAD and clean trackedcheckout required')
 subprocess.run(['git','merge-base','--is-ancestor',args.master_revision,head],cwd=ROOT,check=True)
 pred=args.predecessor.resolve();out=args.output.resolve()
 if out.exists() or not out.is_relative_to(ROOT/'artifacts') or out.is_relative_to(pred) or pred.is_relative_to(out):raise ValueError('Need fresh independent artifactoutput')
 tool=load('tp1bb',ROOT/'tools/localization/translation_program.py');m=read(pred/'manifest.json');a=read(pred/'reviews/th.json')
 if len(m['batches'])!=48 or a['source_sha256']!=m['source_sha256']:raise ValueError('Stale/incomplete48 predecessor')
 oldsrc={s:read(pred/('source/'+s+'.json')) for s in ['native','online']};oldth={'native':tool.CHECKER.read_table(pred/'drafts/th/texts.th.txt')[0],'online':read(pred/'drafts/th/th.json')}
 oldhash={s:sha(p.read_bytes()) for s,p in tool.catalog_paths(pred,'th').items()}
 if oldhash!=a['catalog_sha256']:raise ValueError('Predecessor cataloghash mismatch')
 keys,native,online,sourcefiles,sourcehash=tool.sources(ROOT);th,errors=tool.CHECKER.read_table(ROOT/'data/texts.th.txt')
 if errors or len(native)!=3417 or len(online)!=2969:raise ValueError('Need final3417native/2969online sources')
 newsrc={'native':native,'online':online};newth={'native':th,'online':read(ROOT/'platform/packages/i18n/locales/th.json')};spec=read(args.source_contract);contract={e['id']:e['source'] for e in spec['entries']}
 if len(contract)!=len(spec['entries']) or spec['source_sha256']!=sha((ROOT/'platform/packages/i18n/locales/en.json').read_bytes()):raise ValueError('Contract duplicate/fullEnglishfilehash mismatch')
 rows=compare(oldsrc,oldth,newsrc,newth,contract);edited=read(args.edited_target)
 fresh=verify_fresh65(spec,edited,{k:newth['online'][k.split(':',1)[1]] for k in contract},{'final-meaning':args.fresh_meaning,'final-editor':args.fresh_editor,'final-adversarial':args.fresh_adversarial},sha((ROOT/'platform/packages/i18n/locales/en.json').read_bytes()))
 ag={b['id']:b for b in a['batches']};payloads=[];proofs=[];seen=set();oldall=flat(oldsrc);targets=flat(oldth)
 for b in m['batches']:
  payload=read(pred/b['path']);ids=[e['id'] for e in payload['entries']]
  if ids!=b['keys'] or seen.intersection(ids):raise ValueError('Predecessor duplicate/batchmembership mismatch')
  seen.update(ids);targethash=canonical({k:targets[k] for k in ids})
  for e in payload['entries']:
   if e['source']!=oldall[e['id']] or e['target']!=targets[e['id']]:raise ValueError('Predecessor snapshot differs')
  ownerproof=previous.verify_owner_proofs(pred,b,ag[b['id']],m['source_sha256'],targethash)
  if ag[b['id']]['target_sha256']!=targethash or ag[b['id']]['source_sha256']!=m['source_sha256'] or payload['source_sha256']!=m['source_sha256']:raise ValueError('Aggregate batch stale')
  if len({ag[b['id']].get(k) for k in ['author','reviewer','editor','adversarial_reviewer']})!=4:raise ValueError('Predecessor independentauthor/roles invalid')
  payload['source_sha256']=sourcehash;payloads.append((b,payload,targethash,ownerproof))
 if seen!=set(oldall):raise ValueError('Predecessor48coverage incomplete')
 contexts=context_inventory(ROOT,m['revision'],head)
 # Readonly validation complete. Explicit archival paths never recurse OS/build/package folders.
 out.mkdir(parents=True);hist=out/'history/predecessor-48';hist.mkdir(parents=True)
 for name in ['source','drafts','batches','reviews','history']:
  if (pred/name).exists():shutil.copytree(pred/name,hist/name)
 for name in ['manifest.json','successor-proof.json']:shutil.copy2(pred/name,hist/name)
 archivehash={str(p.relative_to(hist)):sha(p.read_bytes()) for p in sorted(hist.rglob('*')) if p.is_file()}
 tool.prepare(out,batch_size=m['batch_size'],root=ROOT,locales=['th']);tool.draft(out,'th')
 for p in (out/'batches').glob('*.json'):p.unlink()
 nm=read(out/'manifest.json');nm['batches']=copy.deepcopy(m['batches']);write(out/'checks/context-changes-1bb.json',{'predecessor_revision':m['revision'],'revision':head,'changes':contexts,'automatic_context_approval':False})
 for b,payload,targethash,ownerproof in payloads:
  write(out/b['path'],payload)
  relevant=[x for x in contexts if payload['surface'] in x['affects_surfaces']]
  for role,proof in ownerproof.items():write(out/'reviews/unsigned-owner-candidates'/role/(b['id']+'.json'),unsigned_candidate(role,proof,b,sourcehash,targethash,relevant,Path('history/predecessor-48')))
 newname='online-master-1bb-001';newpath='batches/'+newname+'.json';ids=list(contract)
 write(out/newpath,{'id':newname,'source_sha256':sourcehash,'surface':'online','domain':'online','context':'Newmaster65 presentation labels and notices; actual source/context contracts and fresh reviews in source/master-1bb-contract.json; executionIDs and authoredcontent preserved.','entries':[{'id':k,'key':k.split(':',1)[1],'source':contract[k],'target':newth['online'][k.split(':',1)[1]]} for k in ids]})
 nm['batches'].append({'id':newname,'path':newpath,'keys':ids});write(out/'manifest.json',nm);write(out/'source/master-1bb-contract.json',spec);shutil.copy2(ROOT/'data/texts.th.txt',out/'drafts/th/texts.th.txt');shutil.copy2(ROOT/'platform/packages/i18n/locales/th.json',out/'drafts/th/th.json')
 for role,proof in fresh.items():
  write(out/'reviews/unsigned-owner-candidates'/role/(newname+'.json'),{'kind':'UNSIGNED fresh65 proofbinding candidate; NOT owner signature','id':newname,'source_sha256':sourcehash,'target_sha256':canonical({k:newth['online'][k.split(':',1)[1]] for k in ids}),'expected_owner':proof['owner'],'approved_keys':[],'candidate_prior_fresh_review_keys':ids,'fresh_reviewed_keys':[],'owner_accepted':False,'genuine_fresh_review':copy.deepcopy(proof),'context_assessment_required':'Owner must bind own exact65 final review to actualnewkit/context; this builder does not sign it.'})
  src=Path(proof['path']);dest=out/'reviews/provenance'/('master-1bb-'+role+'.json');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);proof['copied_path']=str(dest.relative_to(out))
 cataloghash={s:sha(p.read_bytes()) for s,p in tool.catalog_paths(out,'th').items()};pending=read(out/'reviews/th.json');pending['catalog_sha256']=cataloghash;pending['accepted_english']=copy.deepcopy(a.get('accepted_english',[]));pending['provenance']={'predecessor_aggregate_sha256':sha((pred/'reviews/th.json').read_bytes()),'gates_reset_reason':'Newmaster changes sharedrenderer/browser/runtime/sourcecontext; all9gates pending until actualnewscope/equivalence evidence. No oldproducer relabelled.','owner_templates_unsigned':True};write(out/'reviews/th.json',pending)
 write(out/'successor-proof.json',{'revision':head,'merged_master_revision':args.master_revision,'predecessor_root':str(pred),'predecessor_source_sha256':m['source_sha256'],'source_sha256':sourcehash,'old_entries':6321,'new_entries':65,'total_entries':6386,'preserved_batches':48,'new_batches':1,'exact_old_source_and_target_comparisons':rows,'comparison_set_sha256':canonical(rows),'history_files_sha256':archivehash,'new_catalog_sha256':cataloghash,'new65_fresh_review_proofs':fresh,'context_changes_path':'checks/context-changes-1bb.json','status':'UNSIGNED ownercarry/contextassessment pending;49batchaggregate empty and ALL9gates pending','approvals_created':False,'gate_passes_created':False})
 print('Prepared UNSIGNED49batch successor:',out)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--revision',required=True);p.add_argument('--master-revision',default='1bb5155e96b61144583466a00041fb1d04fc9def');p.add_argument('--predecessor',type=Path,default=ROOT/'artifacts/thai-localization-final-ship');p.add_argument('--output',type=Path,required=True);p.add_argument('--source-contract',type=Path,default=Path(__file__).with_name('sources.json'));p.add_argument('--edited-target',type=Path,required=True);p.add_argument('--fresh-meaning',type=Path,required=True);p.add_argument('--fresh-editor',type=Path,required=True);p.add_argument('--fresh-adversarial',type=Path,required=True);run(p.parse_args())
