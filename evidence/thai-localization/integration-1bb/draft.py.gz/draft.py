import json,hashlib,importlib.util
from decimal import Decimal
from pathlib import Path
r=Path.cwd();out=r/'artifacts/thai-localization/integration-1bb';s=importlib.util.spec_from_file_location('g',r/'tools/localization/google_draft.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
d=json.loads((out/'sources.json').read_text());entries=d['entries'];inv=json.loads((r/'platform/packages/i18n/invariants.json').read_text());manifest=json.loads((r/'artifacts/thai-localization/manifest.json').read_text());folder=r/'artifacts/thai-localization/google/th';assert len(entries)==65;assert hashlib.sha256((r/'platform/packages/i18n/locales/en.json').read_bytes()).hexdigest()==d['source_sha256']
with g.campaign_lock(folder):
 c=g.Campaign(folder,'bradley-personal-20261027','th',manifest['source_sha256'],Decimal(25),Decimal(20));before=json.loads((folder/'ledger.json').read_text());n=len(before['attempts']);batch=[];chars=0
 def request(es):
  ps=[g.protect(e['source'],inv.get(e['key'],())) for e in es];response=c.translate([p[0] for p in ps]);assert len(response['translations'])==len(es)
  for e,p,v in zip(es,ps,response['translations']):e['provider_draft']=g.restore(v['translatedText'],p,e['source'],native=False);assert '\u200b' not in e['provider_draft']
 for e in entries:
  size=len(g.protect(e['source'],inv.get(e['key'],()))[0])
  if batch and chars+size>3000:request(batch);batch=[];chars=0
  batch.append(e);chars+=size
 if batch:request(batch)
 after=json.loads((folder/'ledger.json').read_text());assert after['attempts'][:n]==before['attempts'];d.update(prior_attempts=n,cumulative_reserved_usd=str(c.spent),new_attempts=len(after['attempts'])-n,source_freeze_note='Exact integrated English file hash binds this65-entry source snapshot while merge is being finalized; authoritative merge revision will be recorded separately.');(out/'google-draft.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'entries':len(entries),'reserved_usd':str(c.spent),'new_attempts':len(after['attempts'])-n}))
