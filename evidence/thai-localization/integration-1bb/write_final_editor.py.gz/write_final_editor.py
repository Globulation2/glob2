import json,hashlib,re
from pathlib import Path
b=Path(__file__).resolve().parent;p=b/'blind-edited.json';d=json.loads(p.read_text());s=json.loads((b/'sources.json').read_text());prior=json.loads((b/'editor-r1.json').read_text());previous={e['id']:e for e in prior['entries']};contract={e['id']:e['source']for e in s['entries']}
h=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
assert len(d['entries'])==65
assert {e['id']:e['source']for e in d['entries']}==contract
assert d['source_sha256']==s['source_sha256']
assert h({e['id']:e['target']for e in d['entries']})==d['target_sha256']
changes={
'online:Expansion':'Freshly read เน้นขยายอาณานิคม. Natural parallel strategy label; expansion of the colony encompasses its territory and productive reach, without adding an execution constraint or prescribing a particular building. อาณานิคม is canonical game vocabulary.',
'online:Audit':'Freshly read บันทึกการตรวจสอบ. The Admin audit navigation opens the Audit log/history component, so specifying the log is accurate and clearer than an unspecified checking action. Consistent with existing ประวัติการตรวจสอบ.',
'online:Unclassified payments':'Freshly read การชำระเงินที่ยังไม่จัดประเภท. Natural label for payments whose live/test mode has not been classified. It does not assert that these payments are cash or failed, and does not change ledger mode identifiers.',
}
entries=[]
for e in d['entries']:
 assert set(re.findall(r'\{[^{}]+\}',e['source']))==set(re.findall(r'\{[^{}]+\}',e['target']))
 assert '\u200b'not in e['target']
 reason=changes.get(e['id'])
 if reason is None:
  assert e['target']==previous[e['id']]['proposed_target']
  reason='Freshly read actual final source and target: '+previous[e['id']]['rationale']+' Final wording is idiomatic, coherent and acceptable in the cited context; no remaining editorial issue.'
 entries.append({'id':e['id'],'source':e['source'],'target':e['target'],'source_value_sha256':h(e['source']),'target_value_sha256':h(e['target']),'decision':'approve','rationale':reason,'confidence':'high','usage':previous[e['id']]['usage']})
r={'reviewer':'thai_brief','role':'independent Thai editor','round':'final65-r1','status':'APPROVED','review_basis':'Freshly read every one of the65 actual reconciled targets against the frozen English source and usage; no carried-entry reading claim. No adversarial findings consulted before saving this record. Coordinator choices individually reassessed rather than presumed accepted.','source_sha256':d['source_sha256'],'source_id_map_sha256':h(contract),'target_sha256':d['target_sha256'],'canonical_target_hash_format':'SHA256 of UTF8 json.dumps({id:target},ensure_ascii=False,sort_keys=True), default JSON separators, no trailing newline. source_sha256 is the frozen contract identity; source_id_map_sha256 independently binds exact per-key sources.','candidate_file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_contract_file_sha256':hashlib.sha256((b/'sources.json').read_bytes()).hexdigest(),'initial_independent_editor_record_sha256':hashlib.sha256((b/'editor-r1.json').read_bytes()).hexdigest(),'reviewed_keys':[e['id']for e in entries],'fresh_reviewed_keys':[e['id']for e in entries],'approved_keys':[e['id']for e in entries],'entries':entries,'findings':[],'accepted_english':[],'unresolved_uncertainty':[],'references':prior['references'],'limits':['Agent-reviewed Standard Thai; no native-human certification.','Approval binds only these65 exact values. Any changed wording requires affected-key fresh review.','No product, rendering, platform, package or browser gates passed by this linguistic approval.']}
out=b/'final-editor.json';assert not out.exists(),'Preserve prior review';out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'keys':len(entries),'source':r['source_sha256'],'target':r['target_sha256'],'record_sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
