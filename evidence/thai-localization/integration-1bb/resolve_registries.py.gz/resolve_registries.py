from pathlib import Path
import subprocess,json,re
r=Path.cwd()
def side(f,n):return subprocess.check_output(['git','show',f':{n}:{f}'],text=True)
def write(f,s):(r/f).write_text(s)
f='platform/packages/i18n/src/locales.ts';s=side(f,3);s=s.replace('] as const;',"  { code: 'th', gameCode: 'th', name: 'ไทย', dir: 'ltr' },\n] as const;");write(f,s)
f='platform/packages/i18n/src/index.ts';s=side(f,3);s=s.replace("language === 'bn'", "language === 'th'\n          ? 'thai'\n          : language === 'bn'",1);s=s.replace("const loaders: Record<string, () => Promise<{ default: Catalog }>> = {", "const loaders: Record<string, () => Promise<{ default: Catalog }>> = {\n  th: () => import('../locales/th.json', { with: { type: 'json' } }),");write(f,s)
f='browser/unit/language.test.js';s=side(f,3);o=side(f,2);start=o.index("test('Thai online preference");s+='\n'+o[start:];write(f,s)
f='platform/packages/i18n/test/runtime.test.ts';s=side(f,2);a=s.index("  it('contains 38 unique");b=s.index("\n});",a);s=s[:a]+"""  it('contains 40 unique game catalog mappings including Thai, Bengali and Malay', () => {
    expect(locales).toHaveLength(40);
    expect(new Set(locales.map((l) => l.gameCode)).size).toBe(locales.length);
    expect(new Set(locales.map((l) => l.code)).size).toBe(locales.length);
    for (const [code, name] of [['th', 'ไทย'], ['bn', 'বাংলা'], ['ms', 'Bahasa Melayu'], ['nb', 'Norsk bokmål']])
      expect(locales).toContainEqual({code, gameCode: code, name, dir: 'ltr'});
  });"""+s[b:];# use other nonconflicting auto-merged blocks rather than lost master tests
merged=(r/f).read_text();prefix=merged[:merged.index('<<<<<<< HEAD')];suffix=merged[merged.index('\n});',merged.index('>>>>>>> origin/master',merged.index('>>>>>>> origin/master')+1)):];s=prefix+s[s.index("  it('contains 40 unique"):s.index('\n});',s.index("  it('contains 40 unique"))]+suffix;write(f,s)
for f in ['data/texts.list.txt','data/texts.incomplete.txt']:
 s=side(f,3);s+='data/texts.th.txt\n';write(f,s)
f='data/texts.pending.txt';s=side(f,3);o=side(f,2);s+='\n'+'\n'.join(x for x in o.splitlines() if x and x not in s.splitlines())+'\n';write(f,s)
f='test/translation_shared_values.json';b,o,t=[json.loads(side(f,n)) for n in [1,2,3]]
def union(o,t):
 if isinstance(o,dict) and isinstance(t,dict):return {k:union(o[k],v) if k in o else v for k,v in t.items()}|{k:v for k,v in o.items() if k not in t}
 if isinstance(o,list) and isinstance(t,list):return list(dict.fromkeys(t+o))
 return t
write(f,json.dumps(union(o,t),ensure_ascii=False,indent=2)+'\n')
# Generated files are rebuilt after the authoritative registries/catalogs resolve.
for f in ['browser/i18n.js','browser/assets/sources.json']:write(f,side(f,3))
