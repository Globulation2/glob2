#!/usr/bin/env python3
"""Prepare UNSIGNED50batch successor after committed completecontext import; preserve49history."""
import argparse,copy,hashlib,importlib.util,json,shutil,subprocess
from pathlib import Path
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'SConstruct').is_file())
s=importlib.util.spec_from_file_location('m49',Path(__file__).with_name('migrate_successor.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
read,write,sha,canonical=m.read,m.write,m.sha,m.canonical
C919='c919a00fe879be597d0f9ddde9114123a26dcb40';BROKEN='online:Broken'
def flat(d):return {s+':'+k:v for s,c in d.items() for k,v in c.items()}
def contract_new_ids(spec,expected_new,expected_fresh):
 entries=spec.get('entries',[]);ids=[e['id'] for e in entries]
 if expected_new<1 or expected_fresh!=expected_new+1 or expected_fresh>160:raise ValueError('Need explicitbounded newN/freshN+1 counters')
 if len(ids)!=len(set(ids)) or len(ids)!=expected_fresh or BROKEN not in ids or any(not i.startswith('online:') for i in ids):raise ValueError('Completefreshcontract membership/counters invalid')
 return set(ids)-{BROKEN}
def compare50(oldsrc,oldth,newsrc,newth,context,spec,expected_new,expected_fresh):
 added=contract_new_ids(spec,expected_new,expected_fresh);old,prior,new,current=map(flat,[oldsrc,oldth,newsrc,newth]);approved={e['id']:e['target'] for e in context['entries']};english={e['id']:e['source'] for e in spec['entries']}
 if len(old)!=6386 or len(new)!=6386+expected_new or set(old)!=set(prior) or set(new)!=set(current) or set(new)-set(old)!=added:raise ValueError('Registerednewkeyset must exactlyequal completefreshnewcontract')
 if len(context['entries'])!=expected_fresh or set(approved)!=(added|{BROKEN}):raise ValueError('Fresh editedmembership/counters differ')
 changes=[]
 for k,v in old.items():
  if new.get(k)!=v:raise ValueError('Existing English source changed: '+k)
  if k==BROKEN:
   if prior[k]!='แตกหัก' or current[k]!='ใช้งานไม่ได้' or current[k]!=approved[k]:raise ValueError('Only exactreviewedBroken exception allowed')
   changes.append(k)
  elif current[k]!=prior[k]:raise ValueError('Unapproved oldtarget edit: '+k)
 for k,v in english.items():
  if new[k]!=v or current[k]!=approved[k]:raise ValueError('ActualfreshEnglish/target differsfrom explicitcontract: '+k)
 return {'old_unchanged':6385,'changed_old_keys':changes,'added_keys':sorted(added)}
def verify_supplement(spec,edited,paths,current_en_hash,expected_new,expected_fresh):
 added=contract_new_ids(spec,expected_new,expected_fresh)
 if spec['source_sha256']!=current_en_hash or edited['source_sha256']!=current_en_hash:raise ValueError('SupplementcurrentEnglishfileSHA mismatch')
 targets={e['id']:e['target'] for e in edited['entries']};ids=added|{BROKEN}
 if set(targets)!=ids or len(edited['entries'])!=expected_fresh or edited['target_sha256']!=canonical(targets):raise ValueError('Supplementmembership/targethash invalid')
 if any(not isinstance(v,str) or not v.strip() or '\u200b' in v for v in targets.values()):raise ValueError('Fresh blank/nonstring/nativehinttarget')
 proofs={};owners=[]
 for role,field,expected in [('final-meaning','reviewer','thai_brief'),('final-editor','editor','thai_rendering'),('final-adversarial','adversarial_reviewer','online_adversarial')]:
  p=Path(paths[role]);r=read(p);owner=r.get(field)
  allowed_roles={'final-meaning':{'final-meaning','independent final meaning reviewer','independent meaning reviewer'},'final-editor':{'final-editor','independent Thai editor'},'final-adversarial':{'final-adversarial','independent adversarial reviewer'}}
  if r.get('role') is not None and r['role'] not in allowed_roles[role]:raise ValueError('Fresh explicitrole mismatch')
  if owner is None and r.get('role') in ['final-editor','independent Thai editor']:owner=r.get('reviewer')
  if owner!=expected or r.get('source_sha256')!=current_en_hash or r.get('target_sha256')!=canonical(targets) or set(r.get('approved_keys',[]))!=ids or len(r.get('approved_keys',[]))!=expected_fresh or r.get('findings') or r.get('open_uncertainty') or r.get('unresolved_uncertainty'):raise ValueError('Supplement genuinefinalrole invalid: '+role)
  owners.append(owner);proofs[role]={'path':str(p),'sha256':sha(p.read_bytes()),'owner':owner}
 assert len(set(owners))==3
 return proofs

def main(args):
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
 if head!=args.revision or subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT).strip():raise ValueError('Need exactfinalclean committedHEAD')
 subprocess.run(['git','merge-base','--is-ancestor',C919,head],cwd=ROOT,check=True)
 pred=args.predecessor.resolve();base=args.base.resolve();out=args.output.resolve()
 if out.exists() or not out.is_relative_to(ROOT/'artifacts') or out.is_relative_to(pred) or pred.is_relative_to(out):raise ValueError('Newindependentartifactoutput required')
 tool=m.load('tp50',ROOT/'tools/localization/translation_program.py');pm=read(pred/'manifest.json');bm=read(base/'manifest.json');ba=read(base/'reviews/th.json')
 if len(pm['batches'])!=49 or len(bm['batches'])!=48:raise ValueError('Need genuine49predecessor+48base')
 oldsrc={s:read(pred/('source/'+s+'.json')) for s in ['native','online']};oldth={'native':tool.CHECKER.read_table(pred/'drafts/th/texts.th.txt')[0],'online':read(pred/'drafts/th/th.json')}
 keys,native,online,files,sourcehash=tool.sources(ROOT);targets,errors=tool.CHECKER.read_table(ROOT/'data/texts.th.txt');newsrc={'native':native,'online':online};newth={'native':targets,'online':read(ROOT/'platform/packages/i18n/locales/th.json')}
 if errors or len(native)!=3417 or len(online)!=2969+args.expected_new_count:raise ValueError('Need3417native plus2969+explicitnewcount online')
 spec=read(args.context_contract);edited=read(args.context_target);contextproofs=verify_supplement(spec,edited,{'final-meaning':args.context_meaning,'final-editor':args.context_editor,'final-adversarial':args.context_adversarial},sha((ROOT/'platform/packages/i18n/locales/en.json').read_bytes()),args.expected_new_count,args.expected_fresh_count)
 summary=compare50(oldsrc,oldth,newsrc,newth,edited,spec,args.expected_new_count,args.expected_fresh_count)
 added=set(summary['added_keys'])
 for e in spec['entries']:
  if e['id']!='online:'+e['key'] or newsrc['online'][e['key']]!=e['source']:raise ValueError('ActualcontextEnglish differs')
 # Fresh65 uses immutablec919English FILESHA93, never demands currentfullENfile equal93.
 p65=Path(__file__).with_name('sources.json');spec65=read(p65);en65bytes=subprocess.check_output(['git','show',C919+':platform/packages/i18n/locales/en.json'],cwd=ROOT);en65=json.loads(en65bytes)
 if sha(en65bytes)!=spec65['source_sha256']:raise ValueError('Immutablec919fullEnglishhash mismatch')
 for e in spec65['entries']:
  if en65[e['key']]!=e['source'] or online[e['key']]!=e['source']:raise ValueError('65reviewedsource value changed')
 edited65=read(Path(__file__).with_name('blind-edited.json'));actual65={e['id']:newth['online'][e['key']] for e in spec65['entries']}
 proofs65=m.verify_fresh65(spec65,edited65,actual65,{'final-meaning':Path(__file__).with_name('final-meaning.json'),'final-editor':Path(__file__).with_name('final-editor.json'),'final-adversarial':Path(__file__).with_name('blind-adversarial-r1.json')},sha(en65bytes))
 bsrc={s:read(base/('source/'+s+'.json')) for s in ['native','online']};bth={'native':tool.CHECKER.read_table(base/'drafts/th/texts.th.txt')[0],'online':read(base/'drafts/th/th.json')};allbase=flat(bsrc);baseth=flat(bth);current=flat(newth);current_source=flat(newsrc)
 if len(allbase)!=6321 or {s:sha(p.read_bytes()) for s,p in tool.catalog_paths(base,'th').items()}!=ba['catalog_sha256']:raise ValueError('Base48source/catalogproof stale')
 for k,v in allbase.items():
  if current_source[k]!=v or (k!=BROKEN and current[k]!=baseth[k]):raise ValueError('Unexpectedbase6321source/target edit')
 records={r['id']:r for r in ba['batches']};payloads=[];seen=set();candidates=[]
 for b in bm['batches']:
  payload=read(base/b['path']);ids=b['keys'];priorhash=canonical({k:baseth[k] for k in ids});owners=m.previous.verify_owner_proofs(base,b,records[b['id']],bm['source_sha256'],priorhash)
  if [e['id'] for e in payload['entries']]!=ids or seen.intersection(ids):raise ValueError('Base48batchmembership changed')
  seen.update(ids)
  for e in payload['entries']:
   if e['source']!=allbase[e['id']] or e['target']!=baseth[e['id']]:raise ValueError('Base48batchsnapshot stale')
   e['target']=current[e['id']]
  payload['source_sha256']=sourcehash;targethash=canonical({k:current[k] for k in ids});payloads.append((b,payload))
  for role,proof in owners.items():
   fresh=[BROKEN] if BROKEN in ids else []
   if fresh and proof['owner']!=contextproofs[role]['owner']:raise ValueError('Brokenfreshowner differsfromoriginalowner')
   candidates.append((role,b['id'],{'kind':'UNSIGNED old48carry/context-freshcandidate','id':b['id'],'source_sha256':sourcehash,'target_sha256':targethash,'expected_owner':proof['owner'],'approved_keys':[],'candidate_carried_keys':[k for k in ids if k not in fresh],'candidate_fresh_keys':fresh,'owner_accepted':False,'prior_original48_owner':proof,'fresh_supplement_proof':contextproofs[role] if fresh else None,'context_assessment_required':True}))
 if seen!=set(allbase):raise ValueError('48basecoverage incomplete')
 b65=next(b for b in pm['batches'] if b['id']=='online-master-1bb-001');payload=read(pred/b65['path']);payload['source_sha256']=sourcehash
 if [e['id'] for e in payload['entries']]!=b65['keys'] or any(e['source']!=online[e['key']] for e in payload['entries']) or {e['id']:e['target'] for e in payload['entries']}!=actual65:raise ValueError('49reviewed65snapshot differs')
 payloads.append((b65,payload))
 for role,proof in proofs65.items():
  partial=pred/'reviews'/role/(b65['id']+'.json');partialref=None
  if partial.exists():
   r=read(partial)
   if r['source_sha256']!=pm['source_sha256'] or r['target_sha256']!=canonical(actual65) or set(r['approved_keys'])!=set(actual65):raise ValueError('49partial65owner record stale')
   partialref={'path':str(partial),'sha256':sha(partial.read_bytes())}
  candidates.append((role,b65['id'],{'kind':'UNSIGNED genuine65reviewbindingcandidate','id':b65['id'],'source_sha256':sourcehash,'target_sha256':canonical(actual65),'expected_owner':proof['owner'],'approved_keys':[],'candidate_carried_keys':b65['keys'],'candidate_fresh_keys':[],'genuine_fresh65proof':proof,'partial49_owner_proof':partialref,'immutable65_sourcefile_revision':C919,'source_hash_scope_transition':'FullENfile93 atc919exact65sourcevalues+dfmap nowwrappedbynewglobalsource; currentENfileallowedexplicitreviewednewadditions.','owner_accepted':False}))
 newname='online-context-supplement-001';ids=sorted(added);b2={'id':newname,'path':'batches/'+newname+'.json','keys':ids};payloads.append((b2,{'id':newname,'source_sha256':sourcehash,'surface':'online','domain':'online','context':'Complete scoped caller/status/modal/metadata supplement per explicit sourcecontract; physicalBuilding staysoldkey, Broken staysoriginalbatch.','entries':[{'id':i,'key':i[7:],'source':online[i[7:]],'target':newth['online'][i[7:]]} for i in ids]}))
 for role,proof in contextproofs.items():candidates.append((role,newname,{'kind':'UNSIGNED freshnewsubsetbinding of actualcomplete supplementreview','id':newname,'source_sha256':sourcehash,'target_sha256':canonical({i:current[i] for i in ids}),'expected_owner':proof['owner'],'approved_keys':[],'candidate_fresh_keys':ids,'genuine_fresh_supplement_proof':proof,'owner_accepted':False}))
 contexts=m.context_inventory(ROOT,pm['revision'],head)
 # No writes above. Archive entireexplicit49reviewcore andpartialrealclosures byteexact.
 out.mkdir(parents=True);hist=out/'history/predecessor-49';hist.mkdir(parents=True)
 for name in ['source','drafts','batches','reviews','history']:
  if (pred/name).exists():shutil.copytree(pred/name,hist/name)
 for name in ['manifest.json','successor-proof.json']:shutil.copy2(pred/name,hist/name)
 historyhash={str(p.relative_to(hist)):sha(p.read_bytes()) for p in hist.rglob('*') if p.is_file()}
 for rel,digest in historyhash.items():
  if sha((pred/rel).read_bytes())!=digest:raise ValueError('Predecessor49 changed during archive; use freshattempt output')
 tool.prepare(out,batch_size=pm['batch_size'],root=ROOT,locales=['th']);tool.draft(out,'th')
 for p in (out/'batches').glob('*.json'):p.unlink()
 assert len(payloads)==50 and len(candidates)==150
 nm=read(out/'manifest.json');nm['batches']=[copy.deepcopy(b) for b,_ in payloads]
 for b,payload in payloads:write(out/b['path'],payload)
 write(out/'manifest.json',nm);shutil.copy2(ROOT/'data/texts.th.txt',out/'drafts/th/texts.th.txt');shutil.copy2(ROOT/'platform/packages/i18n/locales/th.json',out/'drafts/th/th.json')
 for role,name,candidate in candidates:write(out/'reviews/unsigned-owner-candidates'/role/(name+'.json'),candidate)
 for name,p in [('master65-sources',p65),('master65-edited',Path(__file__).with_name('blind-edited.json')),('context-supplement-sources',args.context_contract),('context-supplement-edited',args.context_target)]:shutil.copy2(p,out/'source'/(name+'.json'))
 for group,proofs in [('master65',proofs65),('context-supplement',contextproofs)]:
  for role,proof in proofs.items():dest=out/'reviews/provenance'/(group+'-'+role+'.json');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(proof['path'],dest)
 cataloghash={s:sha(p.read_bytes()) for s,p in tool.catalog_paths(out,'th').items()};aggregate=read(out/'reviews/th.json');aggregate['catalog_sha256']=cataloghash;aggregate['accepted_english']=copy.deepcopy(ba.get('accepted_english',[]));aggregate['provenance']={'gates_reset':True,'reason':'Sharedmasterrender/browser plus freshmusic/progress/softwarecontextfix; unsignedownership and all9gatespending.'};write(out/'reviews/th.json',aggregate)
 write(out/'checks/context-changes-after49.json',{'prior49revision':pm['revision'],'revision':head,'changes':contexts,'automatic_context_approval':False})
 write(out/'successor-proof.json',{'revision':head,'source_sha256':sourcehash,'catalog_sha256':cataloghash,'base48':str(base),'predecessor49':str(pred),'base48keys':6321,'unchanged_base48targets':6320,'reviewed_base48_target_exception':BROKEN,'preserved49batchIDs':49,'newbatch':b2,'counts':{'native':3417,'online':len(online),'total':len(native)+len(online),'batches':50},'comparison49to50':summary,'genuine65proofs':proofs65,'genuine_supplement_proofs':contextproofs,'history_files_sha256':historyhash,'approvals_created':False,'gate_passes_created':False})
 print('Prepared UNSIGNED50kit',out)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--revision',required=True);p.add_argument('--expected-new-count',type=int,required=True);p.add_argument('--expected-fresh-count',type=int,required=True);p.add_argument('--predecessor',type=Path,default=ROOT/'artifacts/thai-localization-integrated-1bb');p.add_argument('--base',type=Path,default=ROOT/'artifacts/thai-localization-final-ship');p.add_argument('--output',type=Path,required=True);ctx=Path(__file__).with_name('context-seven');p.add_argument('--context-contract',type=Path,default=ctx/'sources.json');p.add_argument('--context-target',type=Path,default=ctx/'edited.json');p.add_argument('--context-meaning',type=Path,default=ctx/'final-meaning.json');p.add_argument('--context-editor',type=Path,default=ctx/'final-editor.json');p.add_argument('--context-adversarial',type=Path,default=ctx/'final-adversarial.json');main(p.parse_args())
