import copy,importlib.util,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
s=importlib.util.spec_from_file_location('migrate1bb',Path(__file__).with_name('migrate_successor.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class MigrationContracts(unittest.TestCase):
 def setUp(self):
  self.old={'native':{'[n'+str(i)+']':'English'+str(i) for i in range(3417)},'online':{'old'+str(i):'Text'+str(i) for i in range(2904)}};self.th=copy.deepcopy(self.old);self.new=copy.deepcopy(self.old);self.current=copy.deepcopy(self.th);self.contract={'online:new'+str(i):'New'+str(i) for i in range(65)}
  for k,v in self.contract.items():self.new['online'][k[7:]]=v;self.current['online'][k[7:]]='ไทย'+v
 def test_exact6321_carry_plus65_new(self):
  rows=m.compare(self.old,self.th,self.new,self.current,self.contract);self.assertEqual(len(rows),6321);self.assertTrue(all(r['source_equal'] and r['target_equal'] for r in rows))
 def test_old_source_or_target_edits_never_silently_carried(self):
  self.new['native']['[n0]']='Changed'
  with self.assertRaisesRegex(ValueError,'Old source changed'):m.compare(self.old,self.th,self.new,self.current,self.contract)
  self.new['native']['[n0]']=self.old['native']['[n0]'];self.current['online']['old0']='Different'
  with self.assertRaisesRegex(ValueError,'Old target changed'):m.compare(self.old,self.th,self.new,self.current,self.contract)
 def test_new_target_hint_and_wrong_added_membership_rejected(self):
  self.current['online']['new0']='ไทย\u200b'
  with self.assertRaisesRegex(ValueError,'nativehint'):m.compare(self.old,self.th,self.new,self.current,self.contract)
  self.current['online']['new0']='ไทย';bad=dict(self.contract);bad['online:unknown']=bad.pop('online:new0')
  with self.assertRaisesRegex(ValueError,'exactly65'):m.compare(self.old,self.th,self.new,self.current,bad)
 def test_templates_never_forge_owner_or_context_acceptance(self):
  candidate=m.unsigned_candidate('final-editor',{'owner':'editor','path':'reviews/a.json','sha256':'abc'},{'id':'batch','keys':['online:X']},'source','target',[{'path':'libgag/src/ui/TextLayout.cpp'}],Path('history/prior'))
  self.assertEqual(candidate['expected_owner'],'editor');self.assertNotIn('editor',candidate);self.assertFalse(candidate['owner_accepted']);self.assertEqual(candidate['approved_keys'],[]);self.assertTrue(candidate['context_change_evidence']);self.assertFalse(candidate['old_platform_visual_gates_carried'])
 def test_campaign_full_english_file_hash_not_subset_hash_and_genuine_distinct_roles(self):
  import json
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);targets={'online:X':'ไทย'};spec={'source_sha256':'FULL_ENGLISH_FILE_HASH','entries':[{'id':'online:X','source':'X'}]};edited={'source_sha256':spec['source_sha256'],'target_sha256':m.canonical(targets),'entries':[{'id':'online:X','source':'X','target':'ไทย'}]};paths={}
   for role,field,owner in [('final-meaning','reviewer','meaning'),('final-editor','editor','editor'),('final-adversarial','adversarial_reviewer','adversary')]:
    p=root/(role+'.json');p.write_text(json.dumps({field:owner,'source_sha256':spec['source_sha256'],'target_sha256':edited['target_sha256'],'approved_keys':['online:X'],'findings':[]}));paths[role]=p
   self.assertEqual(len(m.verify_fresh65(spec,edited,targets,paths,'FULL_ENGLISH_FILE_HASH')),3)
   with self.assertRaisesRegex(ValueError,'FullEnglish'):m.verify_fresh65(spec,edited,targets,paths,'DIFFERENT_SOURCE')
   r=m.read(paths['final-adversarial']);r['adversarial_reviewer']='editor';paths['final-adversarial'].write_text(json.dumps(r))
   with self.assertRaisesRegex(ValueError,'not distinct'):m.verify_fresh65(spec,edited,targets,paths,'FULL_ENGLISH_FILE_HASH')
 def test_explicit_editor_role_reviewer_schema_preserves_identity_guards(self):
  self.assertEqual(m.fresh_owner({'reviewer':'thai_brief','role':'independent Thai editor'},'final-editor','editor'),'thai_brief')
  self.assertEqual(m.fresh_owner({'editor':'thai_brief'},'final-editor','editor'),'thai_brief')
  for record in [{'reviewer':'meaning','role':'final-meaning'},{'reviewer':'unknown'},{'editor':'one','reviewer':'two','role':'independent Thai editor'}]:
   with self.assertRaises(ValueError):m.fresh_owner(record,'final-editor','editor')
 def test_actual_context_delta_keeps_sharedrender_and_online_callsites(self):
  class P:
   returncode=0;stdout=b'actual source bytes'
  with patch.object(m.subprocess,'check_output',return_value='libgag/src/ui/TextLayout.cpp\nplatform/apps/web/src/pages/Sets.tsx\nplatform/packages/i18n/locales/en.json\ndata/texts.th.txt\n'),patch.object(m.subprocess,'run',return_value=P()):
   rows=m.context_inventory(Path('.'),'old','new')
  self.assertEqual([r['path'] for r in rows],['libgag/src/ui/TextLayout.cpp','platform/apps/web/src/pages/Sets.tsx']);self.assertEqual(rows[0]['affects_surfaces'],['native']);self.assertEqual(rows[1]['affects_surfaces'],['online'])
if __name__=='__main__':unittest.main()
