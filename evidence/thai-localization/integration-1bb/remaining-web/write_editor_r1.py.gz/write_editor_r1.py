from pathlib import Path
import json,hashlib
D=Path('artifacts/thai-localization/integration-1bb/remaining-web');p=D/'google-draft.json';j=json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();can=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True).encode()).hexdigest();decisions=[
('ไม่พบแมตช์','Empty match list, not generic no matching searchresults; retain canonicalแมตช์.','major'),
('การทดสอบการเล่นล้มเหลว: {value0}','CanonicalPlaytest retained; remove spurious space beforecolon, exact diagnostic token preserved.','minor'),
('เกมไม่เริ่มภายในเวลาที่กำหนด ตรวจสอบว่าเบราว์เซอร์รองรับหรือเริ่มการทดสอบการเล่นใหม่','Timeout is failedstartup deadline, not scheduledstart punctuality; clear browser-support/retry choices.','minor'),
('กำลังโหลดระบบแสดงผลในเบราว์เซอร์…','Natural waitingstatus for actual browserrenderer; retainellipsis.','minor'),
('การแสดงตัวอย่างล้มเหลว','Natural concise previewfailure, provider retained.','none'),
('การสร้างล้มเหลว','Generator executioncreation failed, not generation ofpeople; providerคนรุ่นนั้น iswrong.','major'),
('ป้อนอาร์เรย์ JSON ที่ถูกต้อง','Correct technicalarray instruction, JSON preserved.','none'),
('มีรายการที่ใช้สไปรท์ชีทนี้อยู่ เปลี่ยนสไปรท์ชีทของรายการนั้นหรือลบรายการนั้นก่อนลบสไปรท์ชีทนี้','Asset isspritesheet, notdocument. Explain actualreference constraint andbothsafeactions, canonicalสไปรท์ชีท.','major'),
('การดาวน์โหลดล้มเหลว','Concise correctdownloadfallback retained.','none'),
('การตรวจสอบแผนที่ใช้เวลานานกว่าปกติ ยังไม่ได้สร้างอะไร โปรดลองอีกครั้งในอีกไม่กี่นาที','Mapvalidation timeout beforecreation; retain explicit fewminutes rather than vague moment.','minor'),
('เกมไม่สามารถโหลดแผนที่นี้ได้','Correctfallback maploadfailure retained.','none'),
('อัปโหลดแล้ว เซิร์ฟเวอร์กำลังตรวจสอบไฟล์และสร้างภาพตัวอย่าง ซึ่งใช้เวลาสักครู่','Successfulupload distinctfrompendingservercheck/render; naturalสร้างภาพตัวอย่าง.','minor'),
('ออกจากตัวแก้ไขโดยยังไม่บันทึกการเปลี่ยนแปลงหรือไม่?','Actual leaveconfirmation, not instructeditor toeditunsaved text; preserveslosscontext.','major'),
('คืนค่าฉบับร่างที่บันทึกไว้นี้หรือไม่? ฉบับร่างปัจจุบันจะยังอยู่ในประวัติ','CanonicalRestoreคืนค่า andretainedcurrenthistory assurance.','minor'),
('คืนค่าเวอร์ชันนี้เป็นฉบับร่างปัจจุบันหรือไม่? ฉบับร่างปัจจุบันจะยังอยู่ในประวัติ','Clear replacement target/version andhistorypreservation; no permanentdeletion implication.','minor'),
('ลบโครงการส่วนตัวนี้และประวัติของโครงการหรือไม่?','Project-specific history, notalluserhistory; canonicalโครงการ.','minor'),
('นำตัวสร้างนี้ออกจากคลังหรือไม่? แมตช์ที่มีอยู่ยังคงมีแผนที่เดิม','Correct librarywithdrawal; existingmatchesretainmaps, provideromitsmapandmisreadsmatch aspairing.','major'),
('เหตุผลในการซ่อน AI นี้','Naturalreportreason prompt, notclaimAIalreadyhidden.','minor'),
('ลบ AI นี้และเวอร์ชันที่เผยแพร่แล้วทั้งหมดหรือไม่?','Correct destructiveconfirmation retained;AIbrandtoken unchanged.','none'),
('ลบ “{value0}” หรือไม่? การดำเนินการนี้จะลบฉบับร่างในบัญชีและสำเนาสำหรับกู้คืนบนอุปกรณ์นี้ รุ่นที่เผยแพร่แล้วยังคงใช้งานได้','Accountdraft meansdraftstoredinaccount, notdraftaccount. Removeproviderplaceholderquote whitespace; distinguishpublishedreleases.','major'),
('ถอน “{value0}” และทุกรุ่นที่เผยแพร่หรือไม่? การดาวน์โหลดและลิงก์ในคลังจะใช้งานไม่ได้ ฉบับร่างในสตูดิโอและสำเนาที่ฝังอยู่ในแผนที่หรือไฟล์บันทึกเดิมยังคงใช้งานได้','Digitalassetlibrary notphysicalห้องสมุด; exactwithdrawal consequences andretainedembeddedcopies.','major'),
('ลบการสนทนานี้และประวัติต้นฉบับหรือไม่? เพลงที่เสร็จแล้วยังคงอยู่ในคลังของคุณ','Sourcehistory isgeneratedcomposition/sourcehistory inproject, notgenericprovenance. Keepsfinishedmusicassurance.','minor'),
('กระทบยอดโทเค็นอินพุต {value0} (อ่านจากแคช {value1}; เขียนลงแคช {value2}) และโทเค็นเอาต์พุต {value3} หรือไม่? คิดเครดิตตามการใช้งานที่ตรวจสอบแล้ว ไม่เกิน {value4} เครดิตที่สำรองไว้ และคืนส่วนที่เหลือ','Adminconfirmation preserves5numericparameters, cache-read/write distinctions, verifiedusagecharge cappedbyreservationandreleaseunusedcredits; nocash/lending implication.','minor'),
];assert len(decisions)==len(j['entries'])==23
entries=[{**e,'proposed':target,'rationale':why,'confidence':'high','finding':None if sev=='none' else {'severity':sev,'reason':why}} for e,(target,why,sev) in zip(j['entries'],decisions)]
files=sorted({p for e in j['entries'] for p in e['callsites']});o={'editor':'thai_rendering','role':'editor','source_sha256':j['source_sha256'],'draft_file_sha256':sha(p),'target_sha256':can({e['id']:e['proposed'] for e in entries}),'edited_keys':[e['id'] for e in entries],'entries':entries,'callsites_sha256_at_review':{p:sha(Path(p)) for p in files},'accepted_english':[],'open_uncertainty':[],'independence':'Every23source/providerdraft/context read beforemeaningfindings. Checked actualcallers/providedsealedmetadata andexistingcanonicalThaiterms. Sourcecallers maystillbeimplementationinprogress; finalactualtarget/context requiresfreshrecheck. No source/catalogedits.'};p=D/'editor-r1.json';p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n');print(sha(p),o['target_sha256'])
