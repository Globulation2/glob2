from pathlib import Path
import json,hashlib,re
b=Path(__file__).resolve().parent;p=b/'google-draft.json';d=json.loads(p.read_text());h=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
rows=[
('ไม่พบแมตช์','Filtered match list has no matches, not a search phrase matching text. Canonical แมตช์.','major'),
('การทดสอบการเล่นล้มเหลว: {value0}','Preserves existing Playtest terminology การทดสอบการเล่น; no space before colon, raw runtime detail remains a protected parameter.','minor'),
('เกมเริ่มไม่ทันเวลาที่กำหนด ตรวจสอบว่าเบราว์เซอร์รองรับหรือเริ่มการทดสอบการเล่นใหม่','Startup timeout, not a game failing to start at a scheduled clock time. Gives original browser-support/restart alternatives.','major'),
('กำลังโหลดตัวแสดงผลในเบราว์เซอร์…','Technical preview renderer is loading inside the browser; concise progress wording.','minor'),
('แสดงตัวอย่างไม่สำเร็จ','Natural concise preview failure fallback.','minor'),
('สร้างไม่สำเร็จ','Generation means procedural creation, not a human generation/cohort.','major'),
('ป้อนอาร์เรย์ JSON ที่ถูกต้อง','Correct technical JSON array validation instruction; retain provider.',None),
('มีรายการใช้สไปรต์ชีตนี้อยู่ เปลี่ยนสไปรต์ชีตของรายการนั้นหรือลบรายการนั้นก่อนลบสไปรต์ชีตนี้','Sheet is a sprite-image atlas referenced by an entry, not a document. Preserves either reassigning the entry or removing it before sheet removal. Existing instruction spelling สไปรต์ชีต reused.','major'),
('ดาวน์โหลดไม่สำเร็จ','Concise download failure fallback.','minor'),
('การตรวจสอบแผนที่ใช้เวลานานกว่าปกติ ยังไม่ได้สร้างแผนที่ โปรดลองอีกครั้งในอีกไม่กี่นาที','Map-page creation has not occurred; preserve wait of a few minutes, not merely momentarily. Uploaded source file itself is not claimed erased or modified.','minor'),
('เกมไม่สามารถโหลดแผนที่นี้ได้','Accurate map-loading failure fallback; retain.',None),
('อัปโหลดแล้ว เซิร์ฟเวอร์จะตรวจสอบไฟล์และสร้างภาพตัวอย่าง ซึ่งใช้เวลาสักครู่','Upload succeeded; checking and producing a preview follow asynchronously. Clear future procedure, no false completed-check claim.','minor'),
('ออกจากตัวแก้ไขโดยยังไม่บันทึกการเปลี่ยนแปลงหรือไม่?','Leave the editor is an exit confirmation, not allowing a text editor to perform an action. Does not add an unpromised discard behavior.','major'),
('คืนค่าฉบับร่างที่บันทึกไว้นี้หรือไม่? ฉบับร่างปัจจุบันจะยังอยู่ในประวัติ','Restore saved draft while retaining current history; matches existing Restore คืนค่า.','minor'),
('คืนค่าเวอร์ชันนี้เป็นฉบับร่างปัจจุบันหรือไม่? ฉบับร่างปัจจุบันจะยังอยู่ในประวัติ','Published/saved version becomes current draft without losing historical current draft.','minor'),
('ลบโครงการส่วนตัวนี้และประวัติทั้งหมดหรือไม่?','Project uses existing โครงการ; history is project history, not usage tracking.','minor'),
('นำตัวสร้างนี้ออกจากคลังหรือไม่? แมตช์ที่มีอยู่จะยังคงใช้แผนที่เดิม','Generator removal preserves maps in existing matches; provider omitted the map-retention object and mistranslated match as matchmaking.','major'),
('เหตุผลในการซ่อน AI นี้','Natural prompt asking for a moderation hiding reason; entered user text stays raw.','minor'),
('ลบ AI นี้และเวอร์ชันที่เผยแพร่แล้วทั้งหมดหรือไม่?','Accurate deletion confirmation scope; retain provider.',None),
('ลบ “{value0}” หรือไม่? การดำเนินการนี้จะลบฉบับร่างในบัญชีและสำเนากู้คืนบนอุปกรณ์นี้ เวอร์ชันที่เผยแพร่แล้วจะยังใช้งานได้','Account draft means draft stored in the account, not a draft account. Authored title parameter has no added internal quote spaces; published releases retained.','major'),
('ถอน “{value0}” และเวอร์ชันที่เผยแพร่ทั้งหมดหรือไม่? การดาวน์โหลดและลิงก์ในคลังจะใช้งานไม่ได้ ฉบับร่างในสตูดิโอและสำเนาที่ฝังไว้ในแผนที่หรือไฟล์บันทึกที่มีอยู่จะยังใช้งานได้','Library is the application content catalog, not a physical library. Withdrawal versus preserved embedded copies/drafts clearly distinguished, title untouched.','major'),
('ลบการสนทนานี้และประวัติซอร์สหรือไม่? เพลงที่เสร็จแล้วจะยังอยู่ในคลังของคุณ','Source history means retained source versions of this private conversation, not attribution/provenance of completed music. Uses technical ซอร์ส without narrowing to a particular code format.','major'),
('กระทบยอดโทเค็นอินพุต {value0} (แคชไว้ {value1}; เขียนแคช {value2}) และโทเค็นเอาต์พุต {value3} หรือไม่? จะคิดเครดิตตามการใช้งานที่ตรวจสอบแล้วไม่เกิน {value4} เครดิตที่กันไว้ และคืนส่วนที่เหลือ','All5 numeric slots retain their roles. Credits are virtual reserved product credits, not cash billing; cap and release of remainder explicit. Consistent กระทบยอด/โทเค็น/แคช.','major'),
]
assert len(rows)==len(d['entries'])==23
entries=[]
for e,(target,reason,severity)in zip(d['entries'],rows):
 assert set(re.findall(r'\{[^{}]+\}',e['source']))==set(re.findall(r'\{[^{}]+\}',target))
 entries.append({**{k:e[k]for k in ['id','source','context','callsites','provider_draft']},'proposed_target':target,'source_value_sha256':h(e['source']),'draft_value_sha256':h(e['provider_draft']),'proposed_value_sha256':h(target),'decision':'retain_provider'if target==e['provider_draft']else'propose_correction','severity':severity,'rationale':reason,'confidence':'high'})
r={'reviewer':'thai_brief','role':'independent meaning reviewer','status':'COMPLETE_INITIAL_PROPOSALS_NOT_FINAL_APPROVAL','source_sha256':d['source_sha256'],'draft_file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_file_sha256':hashlib.sha256((b.parent/'remaining-web-source-spec.json').read_bytes()).hexdigest(),'proposed_target_map_sha256':h({e['id']:e['proposed_target']for e in entries}),'reviewed_keys':[e['id']for e in entries],'entries':entries,'findings':[{'id':e['id'],'severity':e['severity'],'proposed':e['proposed_target'],'reason':e['rationale']}for e in entries if e['decision']!='retain_provider'],'accepted_english':[],'unresolved_uncertainty':[],'independence':'Read every actual23 Google draft against each actual source context. No new editor findings consulted before sealing. Original source and current control behavior authoritative; no blanket approval of draft.','limits':['Agent-reviewed Standard Thai, not native-human certification.','No final exact-value approval before reconciled recheck.','No browser/build/platform gates from this review.']};out=b/'meaning-r1.json';assert not out.exists();out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'keys':23,'findings':len(r['findings']),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
