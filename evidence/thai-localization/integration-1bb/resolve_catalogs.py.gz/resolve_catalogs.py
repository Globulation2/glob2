import subprocess,json
from pathlib import Path
root=Path.cwd(); changes=[]
def stage(f,n):return json.loads(subprocess.check_output(['git','show',f':{n}:{f}']))
files=subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True).splitlines()
for f in files:
 if not f.startswith('platform/packages/i18n/locales/') or not f.endswith('.json'):continue
 b,o,t=[stage(f,n) for n in [1,2,3]];out=dict(t)
 for k,v in o.items():
  if k not in t or (v!=b.get(k) and t[k]==b.get(k)):out[k]=v
  elif v!=t[k] and v!=b.get(k) and t[k]!=b.get(k):changes.append({'file':f,'key':k,'ours':v,'master':t[k],'choice':'master reviewed value over prior English fallback'})
 (root/f).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
# Register existing-language omissions explicitly; Thai receives real supplemental drafts/reviews.
en=json.loads((root/'platform/packages/i18n/locales/en.json').read_text());shared='platform/packages/i18n/shared-values.json';b,o,t=[stage(shared,n) for n in [1,2,3]];sv={k:list(dict.fromkeys(t.get(k,[])+o.get(k,[]))) for k in t.keys()|o.keys()}
for p in (root/'platform/packages/i18n/locales').glob('*.json'):
 if p.stem in ['en','th']:continue
 d=json.loads(p.read_text());missing=[k for k in en if k not in d]
 if missing:
  d.update({k:en[k] for k in missing});sv.setdefault(p.stem,[]).extend(missing);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
# Retain shared assertions only where a value actually equals English after translation merges.
for lc,keys in sv.items():
 p=root/f'platform/packages/i18n/locales/{lc}.json'
 if p.exists():
  d=json.loads(p.read_text());sv[lc]=list(dict.fromkeys(k for k in keys if k in en and d.get(k)==en[k]))
(root/shared).write_text(json.dumps(sv,ensure_ascii=False,indent=2)+'\n')
(root/'artifacts/thai-localization/integration-1bb/catalog-merge-choices.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n');print('catalog count',len(en),'master-valued conflicts',len(changes))
