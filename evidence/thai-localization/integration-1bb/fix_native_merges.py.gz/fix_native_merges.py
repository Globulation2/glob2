from pathlib import Path
import json,subprocess,importlib.util
r=Path.cwd();spec=importlib.util.spec_from_file_location('c',r/'data/check_translations.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
report=[]
for name in ['hi','ur','sw','nb']:
 p=r/f'data/texts.{name}.txt';lines=p.read_text().splitlines();master=subprocess.check_output(['git','show',f'1bb5155e96:data/texts.{name}.txt'],text=True).splitlines();mv={master[i]:master[i+1] for i in range(0,len(master),2)};seen=set();out=[]
 for i in range(0,len(lines),2):
  k,v=lines[i:i+2]
  if k in seen:report.append({'file':str(p.relative_to(r)),'key':k,'resolution':'single master reviewed value'});continue
  seen.add(k);out.extend([k,mv[k] if lines.count(k)>1 else v])
 p.write_text('\n'.join(out)+'\n')
keys=(r/'data/texts.keys.txt').read_text().splitlines()
for name in ['bn','ms']:
 p=r/f'data/texts.{name}.txt';table,errors=c.read_table(p);assert not errors
 missing=[k for k in keys if k not in table];assert len(missing)==6
 with p.open('a') as f:
  for k in missing:f.write(k+'\n\n')
 report.append({'file':str(p.relative_to(r)),'added_pending_keys':missing,'note':'Same explicit pending blanks as every existing non-Thai locale; no fallback is accepted for Thai.'})
p=r/'data/texts.pending.txt';p.write_text('\n'.join(dict.fromkeys(x for x in p.read_text().splitlines() if x))+'\n')
p=r/'data/texts.incomplete.txt';lines=p.read_text().splitlines();lines=['*'+x if x in ['data/texts.bn.txt','data/texts.nb.txt','data/texts.ms.txt'] else x for x in lines];p.write_text('\n'.join(lines)+'\n')
(r/'artifacts/thai-localization/integration-1bb/native-merge-corrections.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
