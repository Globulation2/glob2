import json,pathlib,hashlib,re
r=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads((r/n).read_text())
sha=lambda x:hashlib.sha256(x).hexdigest()
canon=lambda x:json.dumps(x,sort_keys=True,ensure_ascii=False).encode()
d=load('reconciled-r1.json');draft=load('google-draft.json');source=load('sources.json');e=d['entries'];assert len(e)==65
bydraft={x['id']:x for x in draft['entries']};bysource={x['id']:x for x in source['entries']}
reasons=[
'AI strategy tag: บุกเร็ว conveys early attack/rush rather than generic haste.',
'AI strategy tag expresses defensive emphasis and matches canonical ป้องกัน.',
'AI strategy emphasis on economy is retained; not a financial payment label.',
'Expansion AI tag explicitly names colony expansion, appropriate to colony strategy.',
'Experimental AI tag is concise and does not imply an experiment has finished.',
'Beginner suitability is explicit and idiomatic; no promise of automated assistance.',
'Validation heading retains file and API profile, leaving API as the technical acronym.',
'Validation heading retains syntax and profile constraints; no identifier or restriction reversed.',
'Validation heading covers initialization and callback function, technically clearer than a telephone callback.',
'Persistent state remains state that survives, rather than immutable/fixed state.',
'Seeded gameplay uses existing ค่าสุ่ม terminology and preserves the predetermined-seed concept.',
'Repeatable simulation is accurately expressed as reproducible/repeatable simulation.',
'Save and resume describes saving and continuing play, not resetting or replaying.',
'Connection-quality good tier is ดี, an ordinary quality judgment.',
'Connection-quality fair tier is พอใช้; avoids the unrelated fairness meaning.',
'Connection-quality poor tier is แย่; avoids poverty or financial ambiguity.',
'Ping tooltip retains player-relay round-trip time, pre-match probe/estimate qualification, regional server context and quick-match/start-checklist examples.',
'Delay is translated as latency in this connection metric context.',
'Input delay explanation retains click-to-effect for all participants and half-ping plus jitter buffer; no multiplication or subtraction reversal.',
'Behind tooltip preserves strictly below one second as normal and inclusive threshold ตั้งแต่ 2 วินาทีขึ้นไป. Actual poorMs2000 and >= comparison agree.',
'AI-player page name is preserved; AI remains the established technical acronym.',
'Admin finance navigation uses ordinary Thai financial-domain noun.',
'Admin accounts navigation retains account meaning without interpreting as accounting ledger.',
'Admin audit route lists audit events; บันทึกการตรวจสอบ accurately identifies the log.',
'Admin activity window keeps numeric one hour with exact time unit.',
'Admin activity window keeps numeric one day with exact time unit.',
'Admin activity window keeps numeric one week with exact time unit.',
'Admin activity window keeps numeric thirty days; no month-length assumption.',
'Map sort option means most played; superlative retained and no ranking-score claim.',
'Music composition guidance preserves listening for structure and musical development.',
'Music playback guidance preserves all three moods and correct playback.',
'Loudness guidance preserves unexpected abrupt volume changes between moods.',
'Loop-continuity guidance retains all three defects: click, silence gap and abrupt change at repetition.',
'Musical-variety guidance retains short musical phrases and excessively mechanical repetition.',
'Mood-synchronization guidance retains switching moods and listening for timing/harmony changes.',
'Mood-contrast guidance uses existing ก่อสร้าง/ต่อสู้/สงบ mood terms and requires distinctness.',
'Background-noise guidance retains hiss and scratchy distortion in quiet passages.',
'Mix-balance guidance retains muddy bass and harsh/bothersome high frequencies.',
'Audibility guidance retains hearing calm music alongside actual game sound, not muting game sound.',
'Sustained-note guidance retains unexpected note cutoff/dropout, rather than ordinary note ending.',
'Public visibility retains listing in the catalog/library; not a private link-only state.',
'Unlisted visibility preserves access for everyone with the link and lack of public listing.',
'Private visibility preserves only-you access, without adding collaborators.',
'Verified tooltip retains server replay and all players agreeing with replayed game state, not merely equal final scores.',
'Pending tooltip retains active verification and rating change only after verification succeeds.',
'Diverged tooltip retains one player state disagreeing with replay and server result taking precedence.',
'Unverifiable tooltip retains inability to reproduce the match and no rating change.',
'Not-applicable tooltip states that the match is not checked, not merely still pending.',
'Error tooltip retains incomplete checking, no rating change for now and administrator retry ability.',
'Live payment mode means real payments; Thai explicitly avoids cash-only or streaming interpretation.',
'Test payment mode remains test payments, distinct from live transactions.',
'Unclassified payment mode means not yet classified, not unpaid/failed or a payment method reversal.',
'Current reporting window is accurately current period, with no claim it is complete.',
'Previous reporting window is the preceding period, not a future period.',
'Credit grant means granting service balance; no lending/loan or credit-card meaning.',
'Returned credits retains service credits being returned; not a cash refund promise.',
'Payment dispute event remains a dispute, without prejudging its outcome.',
'Closed dispute event states closed/ended, without incorrectly claiming won, lost or refunded.',
'Analytics match-start label describes matches that started; does not assert wins or completion.',
'Analytics match-completion label describes finished matches, distinct from started/cancelled.',
'Analytics cancelled-match label retains cancellation and does not treat it as a completed win.',
'measureName passes libraryName(dimension), a category label, into value0. การเผยแพร่: {value0} preserves that category and avoids a numeric classifier.',
'measureName passes a library category into value0. ยอดดาวน์โหลดที่บันทึกไว้: {value0} describes the recorded-download metric/category rather than interpreting value0 as a count.',
'Completion label receives productName(metric suffix), not elapsed seconds, in value0. เวลาจนงานเสร็จ: {value0} (วินาที) labels the product duration and retains seconds as the measure unit.',
'Completion-sample label receives the product category in value0. จำนวนตัวอย่างงานที่เสร็จ: {value0} identifies a count metric for that category without claiming value0 itself is a numeric sample count.'
]
assert len(reasons)==65
rows=[]
for x,reason in zip(e,reasons):
 assert x['source']==bysource[x['id']]['source'];assert x['provider_draft']==bydraft[x['id']]['provider_draft']
 assert isinstance(x['target'],str) and '\u200b' not in x['target']
 tokens=lambda s:sorted(re.findall(r'\{[^{}]+\}',s))
 assert tokens(x['source'])==tokens(x['target']),x['id']
 rows.append({'id':x['id'],'source':x['source'],'provider_draft':x['provider_draft'],'target':x['target'],'source_value_sha256':sha(canon(x['source'])),'draft_value_sha256':sha(canon(x['provider_draft'])),'target_value_sha256':sha(canon(x['target'])),'status':'approved','rationale':reason,'findings':[]})
th=sha(canon({x['id']:x['target'] for x in e}));assert th==d['target_sha256']
report={'adversarial_reviewer':'online_adversarial','kind':'additional source-and-callsite adversarial review with disclosed metadata exposure','fully_blind_independent_initial_pass':False,'independence_disclosure':'Initial inspection accidentally printed full reconciled entry objects including integration_choice and reconciliation fields. No meaning-r1/editor review files were opened, but coordinator metadata was exposed before this review was saved. This record must not count as a fully blind independent initial approval; parent informed and arranging another blind source/target-only review. Actual all65 source/target/callsite judgments below remain useful additional review.','source_sha256':d['source_sha256'],'source_file_sha256':sha((r/'sources.json').read_bytes()),'candidate_file_sha256':sha((r/'reconciled-r1.json').read_bytes()),'draft_file_sha256':sha((r/'google-draft.json').read_bytes()),'source_values_sha256':sha(canon({x['id']:x['source'] for x in e})),'draft_values_sha256':sha(canon({x['id']:x['provider_draft'] for x in e})),'target_sha256':th,'hash_encoding':'SHA256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()); file hashes are raw bytes.','actual_reviewed_keys':[x['id'] for x in e],'approved_keys':[x['id'] for x in e],'entries':rows,'findings':[],'accepted_english':[],'callsite_evidence':'adversarial-callsite-index.json','caller_files_read':['platform/packages/protocol/src/ais.ts','platform/packages/protocol/src/connectionQuality.ts','platform/apps/web/src/admin/presentation.ts','platform/apps/web/src/music/Validation.tsx','platform/apps/web/src/pages/Ais.tsx','platform/apps/web/src/pages/Match.tsx (verification map via exact callsite extraction)','platform/apps/web/src/pages/Maps.tsx (visibility/sort maps via exact callsite extraction)','platform/packages/i18n/locales/th.json (existing credit/music terminology)'],'validation':{'entries_read':65,'source_draft_membership_exact':True,'placeholders_exact':True,'online_U200B_count':0,'all_targets_string_shape':True,'live_catalog_edits':False,'browser_or_build_executed':False},'status':'65 approved; zero findings; blind-independent gate not certified by this record'}
(r/'adversarial-r1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('report_sha256',sha((r/'adversarial-r1.json').read_bytes()));print('target_sha256',th)
