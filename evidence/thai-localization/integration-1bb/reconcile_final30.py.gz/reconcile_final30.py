import json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent;out=p/'final-supplement30';out.mkdir(exist_ok=True);r=Path.cwd();en=json.loads((r/'platform/packages/i18n/locales/en.json').read_text());entries=[];inputs={}
for group in ['music-context','chart-labels','remaining-web']:
 d=json.loads((p/group/'google-draft.json').read_text());m=json.loads((p/group/'meaning-r1.json').read_text());ed=json.loads((p/group/'editor-r1.json').read_text());mm={e['id']:e for e in m['entries']};ee={e['id']:e for e in ed['entries']}
 for f in ['google-draft.json','meaning-r1.json','editor-r1.json']:inputs[str(Path(group)/f)]=hashlib.sha256((p/group/f).read_bytes()).hexdigest()
 for e in d['entries']:
  a,b=mm[e['id']],ee[e['id']];assert a['source']==b['source']==e['source']==en[e['key']]
  target=b.get('proposed',b.get('proposed_target'));choice='editor'
  if group=='remaining-web' and (e['key'].startswith('Uploaded. The server') or e['key'].startswith('Checking the map') or e['key'].startswith('Delete “') or e['key'].startswith('Withdraw “')):target=a.get('proposed_target',a.get('proposed'));choice='meaning'
  entries.append({k:e[k] for k in ['id','key','source','context']}|{'target':target,'integration_choice':choice})
assert len(entries)==30 and len({e['id'] for e in entries})==30
sourcehash=hashlib.sha256((r/'platform/packages/i18n/locales/en.json').read_bytes()).hexdigest();canon=lambda d:hashlib.sha256(json.dumps(d,ensure_ascii=False,sort_keys=True).encode()).hexdigest();targethash=canon({e['id']:e['target'] for e in entries});sources={'source_sha256':sourcehash,'entries':[{k:e[k] for k in ['id','key','source','context']} for e in entries],'new_keys':29,'fresh_review_entries':30,'existing_target_correction':'online:Broken','initial_review_files_sha256':inputs}
(out/'sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n');(out/'edited.json').write_text(json.dumps({'source_sha256':sourcehash,'target_sha256':targethash,'entries':[{k:e[k] for k in ['id','key','source','context','target']} for e in entries]},ensure_ascii=False,indent=2)+'\n');(out/'reconciliation.json').write_text(json.dumps({'source_sha256':sourcehash,'target_sha256':targethash,'entries':entries,'input_sha256':inputs,'rationale':'Editor wording retains existingspritesheet anderror terminology. Source-based meaning proposals preserve asynchronousserverfuture, mapobjectscope, andversion wording inrelease confirmations. Requirefinalmeaning/editorandblindadversary onactual30 values.'},ensure_ascii=False,indent=2)+'\n');print(sourcehash,targethash)
