import copy,hashlib,importlib.util,json
from pathlib import Path
R=Path.cwd();K=R/'artifacts/thai-localization-final-1bb';P=K/'history/predecessor-49';OWNER='cloud_adapter'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canon(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def write(p,x):assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
s=importlib.util.spec_from_file_location('tp50owner',R/'tools/localization/translation_program.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t)
m=read(K/'manifest.json');pm=read(P/'manifest.json');a=read(K/'reviews/th.json');assert t.sources(R)[4]==m['source_sha256'];assert m['source_sha256']=='29eb9486cc01ae7d5871ba0bc31547e85356c3b8bd204598a229f81296488099'
source={s:read(K/('source/'+s+'.json')) for s in ['native','online']};oldsource={s:read(P/('source/'+s+'.json')) for s in source};target={'native':t.CHECKER.read_table(K/'drafts/th/texts.th.txt')[0],'online':read(K/'drafts/th/th.json')};oldtarget={'native':t.CHECKER.read_table(P/'drafts/th/texts.th.txt')[0],'online':read(P/'drafts/th/th.json')}
assert (R/'data/texts.th.txt').read_bytes()==(K/'drafts/th/texts.th.txt').read_bytes() and (R/'platform/packages/i18n/locales/th.json').read_bytes()==(K/'drafts/th/th.json').read_bytes()
priorroll=P/'reviews/cloud-adapter-owner-carry-approval.json';roll=read(priorroll);assert roll['owner']==OWNER
priorrecords={(r['role'],r['id']):r for r in roll['records']};batches={b['id']:b for b in m['batches']};created=[]
for candidate in (K/'reviews/unsigned-owner-candidates').rglob('*.json'):
 c=read(candidate)
 if c.get('expected_owner')!=OWNER:continue
 role=candidate.parent.name;key=(role,c['id']);pr=priorrecords[key];path=P/pr['path'];old=read(path);assert sha(path)==pr['sha256'];field='editor' if role=='final-editor' else 'adversarial_reviewer';assert old[field]==OWNER and old['source_sha256']==pm['source_sha256']
 ids=batches[c['id']]['keys'];assert len(old['approved_keys'])==len(ids) and set(old['approved_keys'])==set(ids);values={}
 for i in ids:
  surface,k=i.split(':',1);assert source[surface][k]==oldsource[surface][k] and target[surface][k]==oldtarget[surface][k];values[i]=target[surface][k]
 assert canon(values)==old['target_sha256']==c['target_sha256']
 r={'id':c['id'],field:OWNER,'source_sha256':m['source_sha256'],'target_sha256':canon(values),'approved_keys':ids,'fresh_reviewed_keys':[],'carried_keys':ids,'carried_subset_sha256':canon(values),'findings':[],'accepted_english':copy.deepcopy(old.get('accepted_english',[])),'prior_genuine_owner_record':{'path':str(path.relative_to(K)),'sha256':sha(path)},'owner_context_assessment':'NativeC++/Thai81unchanged from previousownclosure. After49 callerchanges inspected forown16Studio/Skin52: addedtranslatedconfirmation/statuswrappers, deferredownedstatus preservingrawdiagnostics, musicBuilding nowexplicitconstructioncontext. No ownsource/targetmeaningchange. New65 network/AI/music/verdict/adminsamecontexts; music3constructionstate helper correctlydisambiguatesunderlying mood. Allownsource/targetvalues and priorapprovedmembership independentlyequalchecked; no newwholecatalogreading or layoutgateclaim.','certification':'Agent-reviewed; not native-human-certified'}
 out=K/'reviews'/role/(c['id']+'.json');write(out,r);created.append({'role':role,'id':c['id'],'keys':len(ids),'path':str(out.relative_to(K)),'sha256':sha(out)})
assert len(created)==31 and sum(r['keys'] for r in created if r['role']=='final-editor')==3485 and sum(r['keys'] for r in created if r['role']=='final-adversarial')==65
write(K/'reviews/cloud-adapter-final50-owner-approval.json',{'owner':OWNER,'source_sha256':m['source_sha256'],'revision':m['revision'],'catalog_sha256':a['catalog_sha256'],'prior_owner_rollup':{'path':str(priorroll.relative_to(K)),'sha256':sha(priorroll)},'records':created,'owned_final_editor_batches':30,'owned_editor_keys':3485,'owned_adversarial_batches':1,'owned_adversarial_keys':65,'fresh_reviewed_keys':[],'findings':[],'gate_passes_created':False,'otherowners_signed':False})
print('Own31final50records approved exactcarry; no gates/otherowners')
