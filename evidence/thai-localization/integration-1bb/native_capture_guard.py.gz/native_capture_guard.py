"""Bind native captures to exact reviewed inputs while unrelated web work advances."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path.cwd()
REFERENCE='c919a00fe879be597d0f9ddde9114123a26dcb40'
EXPECTED_CATALOGS={'data/texts.th.txt':'81dafe8781cbaf26458a9d6a947c66e406d12e38df5ac81bc753eed82bf4997b','platform/packages/i18n/locales/th.json':'0afb158127959d293fe2c28bb40dd7f95bc775d2584311db066e322a1679794b'}
ALLOWED_UNRELATED=('platform/apps/web/','platform/packages/i18n/','docs/','browser/i18n.js')
def filehash(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def canonical(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def git(*parts):return subprocess.check_output(['git',*parts],text=True).strip()
def definitions():
 ns={};exec((ROOT/'artifacts/thai-localization/checks/native-scoped-equivalence.py').read_text().split('inv={r:inventory(r) for r in revs};')[0],ns);return ns

def snapshot(binary):
 head=git('rev-parse','HEAD');committed=git('diff','--name-only',REFERENCE,head).splitlines();dirty=git('diff','--name-only','HEAD').splitlines()
 assert all(p.startswith(ALLOWED_UNRELATED) for p in committed),('Unexpected committed capture input change',committed)
 assert all(p.startswith(ALLOWED_UNRELATED) for p in dirty),('Unexpected uncommitted capture input change',dirty)
 ns=definitions();base=ns['inventory'](REFERENCE);now=ns['inventory'](head);inventory={}
 for category in ('native_runtime_build_test_sources','native_os_packaging'):
  assert base[category]==now[category],category;inventory[category]=canonical(now[category])
 catalogs={}
 for path,expected in EXPECTED_CATALOGS.items():
  actual=filehash(ROOT/path);assert actual==expected,path;catalogs[path]=actual
 for path in ('data/texts.en.txt','data/texts.keys.txt'):
  expected=hashlib.sha256(subprocess.check_output(['git','show',REFERENCE+':'+path])).hexdigest();assert filehash(ROOT/path)==expected,path;catalogs[path]=expected
 assert filehash(ROOT/'platform/packages/i18n/locales/en.json')=='27a0e6691bd168410a997b31f813c0f8c9e3d2d7dfeb51b9f1490353adf8301e'
 catalogs['platform/packages/i18n/locales/en.json']='27a0e6691bd168410a997b31f813c0f8c9e3d2d7dfeb51b9f1490353adf8301e'
 libs={str(p.relative_to(ROOT)):filehash(p) for p in sorted((ROOT/'artifacts/thai-localization/sdl-prefix/lib').glob('*.so*')) if p.is_file()}
 pins={p:filehash(ROOT/p) for p in ('scons/sdl3-versions.json','scons/sdl3-vendored.json','scons/recording-versions.json','scons/opus-versions.json','SConstruct')}
 return {'actual_checkout_head':head,'documented_unrelated_committed_paths':committed,'unrelated_working_paths':dirty,'reference_native_inputs':REFERENCE,'native_git_inventory_hashes':inventory,'catalog_file_hashes':catalogs,'prefix_library_hashes':libs,'build_pin_hashes':pins,'binary_sha256':filehash(binary),'scope':'Only documented web/i18n/browsergeneratedJS/docs changes may differ from integratedc919; exact final approved Thai/English overlay hashes are checked; no broad platform exemption. Exact native code/assets/packaging and reviewed catalogs are checked before and after.'}

def compare(before,after):
 for key in ('native_git_inventory_hashes','catalog_file_hashes','prefix_library_hashes','build_pin_hashes','binary_sha256'):
  assert before[key]==after[key],('Capture inputs changed during execution',key)
