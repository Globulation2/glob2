import hashlib,json,re,subprocess
from pathlib import Path
P=Path('artifacts/thai-localization/integration-1bb');p=P/'blind-edited.json';raw=p.read_bytes();x=json.loads(raw)
def canonical(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
reasons=[
'AI strategy tag: บุกเร็ว means an early attack, not hurried UI action; rawRush executiontag remains unchanged.',
'AI strategy tag: เน้นป้องกัน expresses a defensive playstyle without promising invulnerability.',
'AI strategy tag: เน้นเศรษฐกิจ denotes economic focus, not a currency/price setting.',
'AI strategy tag: เน้นขยายอาณานิคม makes game-territory expansion clear; executiontag staysExpansion.',
'AI tag: แบบทดลอง denotes experimental status, not confirmed beststrategy or a laboratorybuilding.',
'AI tag: เหมาะสำหรับผู้เริ่มต้น describes beginner suitability without claiming a mandatorydifficulty setting.',
'AI file check heading: ไฟล์และโปรไฟล์ API preserves both file and APIprofile; API acronym is intentionaltechnical terminology, not an untranslatedsentence.',
'AI syntax check heading: ไวยากรณ์และข้อจำกัดของโปรไฟล์ preserves syntax validation and profileconstraints; not grammar of playerchat.',
'AI startup check heading: ฟังก์ชันเรียกกลับ identifies a programming callback, not a phonecallback.',
'AI state check heading: สถานะที่คงอยู่ denotes retained persistentprogramstate, not country/state or accountstatus.',
'AI gameplay check: ค่าสุ่มที่กำหนด follows existing ThaiSeed=ค่าสุ่ม; no confusion with mapseeding/planting or uncontrolled randomness.',
'AI determinism check: การจำลองที่ทำซ้ำได้ preserves repeatableexecution; does not claim accelerated or repeateduserturns.',
'AI continuation check: บันทึกและเล่นต่อ clearly pairs saving with resumedplay, not publishing or restarting.',
'Connectionquality adjective: ดี is the good tier; no numericthresholdinvented.',
'Connectionquality middle tier: พอใช้ means acceptable/fair quality, not fairness of gameoutcome; FRMoyen/JAnormal supportcontext.',
'Connectionquality lowest tier: แย่ clearly contrasts withดี/พอใช้; threshold remains codeowned.',
'Pingdescription preserves player–relay roundtrip, prematchregionprobe and estimatequalification; no claim of a liveinmatch measurement beforestart.',
'Input metric label: ความหน่วง is latency/delay rather than a command to wait; unit remains external.',
'Inputdelay tooltip preserves click→effect forparticipants, halfping and extra timebuffer againstjitter. Thaiเวลาที่เกมกันไว้ explains temporalbuffer without suggesting an itemresource.',
'Behind tooltip preserves lagbehindmatchclock, normalunder1second includingdelay, and slowmarker at2secondsinclusive; no thresholdreversal.',
'Player page title: ผู้เล่น AI distinguishes AIcontroller from an accountowner or editableAIfile.',
'Administration tab: การเงิน denotes financeoverview; no change to currency or paymentmode.',
'Administration tab: บัญชี correctly denotes useraccounts, not accountingentries.',
'Administration tab: บันทึกการตรวจสอบ usefully clarifies the audittrail table; does not claim a financialaudit report.',
'Mute-duration choice: 1 ชั่วโมง preserves onehour exactly; code60minutes unchanged.',
'Mute-duration choice: 1 วัน preserves oneday exactly; code1440minutes unchanged.',
'Mute-duration choice: 1 สัปดาห์ preserves oneweek exactly; code10080minutes unchanged.',
'Mute-duration choice: 30 วัน preserves thirtydays rather than assuming calendarmonth.',
'Map sort label: เล่นมากที่สุด correctly orders byplays, not downloads/likes or a call to playmore.',
'Musiccomposition guidance preserves both musicalstructure and development; ฟังและสังเกต is a natural listeninginstruction.',
'Musicformat guidance preserves allthreemoods and correctplayback; no replacement with threeinstruments or tempos.',
'Loudness guidance identifies unexpected abruptvolume changes between moods, rather than forbidding intentional musicaldynamics.',
'Loopcontinuity guidance retains clickartifact, gap and abruptchange whenlooprepeats; คลิก here is a sound, not userinput.',
'Repetition guidance retains shortmusicalphrases and excessmechanical repetition; วลีดนตรี avoids spokenphrase ambiguity.',
'Moodsynchronization guidance retains switchingmoods and timing/rhythm or harmonychanges; จังหวะ/เสียงประสาน are musical concepts, not tonevolume.',
'Moodcontrast guidance distinguishes construction/combat mood fromcalm; no assertion of separate gameinstructions or unitbehaviour.',
'Noise guidance preserves hiss/scratchiness duringquietpassages; เสียงซ่า/เสียงแตกพร่า are audiblyrecognizable defects.',
'Mixbalance guidance preserves muddybass and harshhighfrequencies with natural เบสอู้อี้/แหลมบาดหู; no volume-only simplification.',
'Audibility guidance retains calm music remainingheard alongsidegamesound; not a command to silencegameaudio.',
'Dropout guidance retains unexpected notecutoff; does not suggest missing musicalnotation or deliberate staccato.',
'Visibility choice: สาธารณะ and แสดงในคลัง preserve publiclylisted catalogstatus; no promise of forced download.',
'Unlisted choice preserves linkaccess foranyone and exclusionfromlisting; not private or passwordprotected.',
'Private choice: ส่วนตัว: เฉพาะคุณ preserves onlyyou access, not team/friendsharing.',
'Verifiedverdict preserves actual server replay/resimulation and agreement of everyplayer gamestate; no claim of humanfairplay certification.',
'Pendingverdict preserves checkingnow and ratingchange onlyafterverification; no premature ratingupdate.',
'Divergedverdict preserves oneplayer gamestate disagreement and authoritative serverresult; does not discardallresults or accusecheating.',
'Unverifiableverdict preserves inabilitytoreproduce and noratingchange, not a serverloss or zero rating.',
'Notapplicableverdict states match is notchecked; no substitution with failedcheck or verifiedstatus.',
'Failedverdict preserves unfinishedcheck, temporarynoratingchange and administratorretry; excludes permanent-ratingfreeze implication.',
'Paymentmode: การชำระเงินจริง differentiates livemoney from testcase; no livebroadcast meaning.',
'Paymentmode: การชำระเงินทดสอบ preserves testenvironment rather than a trialpurchase chargedrealmoney.',
'Paymentmode: การชำระเงินที่ยังไม่จัดประเภท preserves unknown/unclassifiedmode, not unpaid or deniedpayment.',
'Report period label: ช่วงเวลาปัจจุบัน preserves current reportingwindow, not exactcalendar-daytoday.',
'Report period label: ช่วงเวลาก่อนหน้า preserves precedingwindow without adding month/yearassumption.',
'Financekind: การมอบเครดิต identifies accountcreditgrant, not a bankloan or pricepurchase.',
'Financekind: เครดิตที่ได้รับคืน correctly describes returnedaccountcredits; distinct from cashrefund alreadyseparatelylabelled.',
'Financekind: ข้อพิพาท denotes paymentdispute without assuming outcome or fraud.',
'Financekind: ข้อพิพาทสิ้นสุดลงแล้ว preserves disputeclosed only; no invented won/lost/refundoutcome.',
'Analytics metric: แมตช์ที่เริ่มแล้ว counts startedmatches, not scheduledmatches.',
'Analytics metric: แมตช์ที่เสร็จแล้ว counts completedmatches, not successfulplayerwins.',
'Analytics metric: แมตช์ที่ยกเลิก counts cancelledmatches, not every unfinishedmatch.',
'Publicationmetric placeholder is translatedlibraryname from libraryName(dimension), not numericalcount. การเผยแพร่: {value0} preserves label semantics and exacttoken.',
'Downloadmetric placeholder is translatedlibraryname. ยอดดาวน์โหลดที่บันทึกไว้ retains recordedmeasurement qualification and exacttoken; does not infer unrecordedhistory.',
'Completiontime placeholder is productName(metric), not durationnumber. เวลาจนงานเสร็จ: {value0} (วินาที) preserves productcontext and secondsunit; rawaggregation stayscodeowned.',
'Completionsamples placeholder is productname, not samplecount. จำนวนตัวอย่างงานที่เสร็จ denotes successfulcompletion observationcount; no averaging or percentageclaim.'
]
assert len(reasons)==len(x['entries'])==65
sources={e['id']:e['source'] for e in x['entries']};targets={e['id']:e['target'] for e in x['entries']};assert sha(Path('platform/packages/i18n/locales/en.json'))==x['source_sha256'] and canonical(targets)==x['target_sha256'];english=json.loads(Path('platform/packages/i18n/locales/en.json').read_text(encoding='utf-8'));assert all(english[e['key']]==e['source'] for e in x['entries'])
checks=[]
for e,reason in zip(x['entries'],reasons):
 assert re.findall(r'\{[^{}]+\}',e['source'])==re.findall(r'\{[^{}]+\}',e['target']) and '\u200b' not in e['target']
 checks.append({'id':e['id'],'source_sha256':canonical(e['source']),'target_sha256':canonical(e['target']),'status':'approved','rationale':reason})
paths=['platform/packages/protocol/src/ais.ts','platform/packages/protocol/src/connectionQuality.ts','platform/apps/web/src/pages/Ais.tsx','platform/apps/web/src/pages/Match.tsx','platform/apps/web/src/pages/Maps.tsx','platform/apps/web/src/pages/Player.tsx','platform/apps/web/src/App.tsx','platform/apps/web/src/admin/Admin.tsx','platform/apps/web/src/admin/Accounts.tsx','platform/apps/web/src/admin/presentation.ts','platform/apps/web/src/music/Validation.tsx']
references=['platform/packages/i18n/locales/'+l+'.json' for l in ['th','fr','ja','vi']]
r={'kind':'Independent BLIND adversarial finaledited65 review','adversarial_reviewer':'cloud_adapter','source_sha256':x['source_sha256'],'source_hash_scope':'Full registered integrated English online catalog fileSHA; exact65ID→English canonical map separatelybound','source_subset_sha256':canonical(sources),'target_sha256':x['target_sha256'],'input':{'path':str(p),'sha256':sha(p)},'actual_head_during_review':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'reviewed_keys':list(sources),'adversarial_reviewed_keys':list(sources),'approved_keys':list(sources),'per_key_reviews':checks,'source_context_sha256':{p:sha(Path(p)) for p in paths},'reference_catalog_sha256':{p:sha(Path(p)) for p in references},'reference_notes':['English and actualconsumers authoritative; French/Japanese/Vietnamese consulted for AIchecktitles, network/verdicts, audit/credits and completion metrics. Vietnamese literalSeed=hạtgiống not copied; existing Thaiค่าสุ่ม retained.','ActualadminmeasureName passes product/librarynames into {value0}; these are labeldimensions, not count/time values.','Protocolstabletags/checkIDs/financekind keys retained; translation is onlydisplaytext.'],'findings':[],'unresolved_uncertainty':[],'accepted_english':[],'independence':'Read blind-edited.json and actualsource/callsite/referencecatalogs ONLY. Did NOT open reconciled-r1 or peer meaning/editor/adversarial findings. Original migration code/schema work read sources/rawGoogle, not peerfindings. Each65source+editedtarget actuallyread and assessed now.','certification':'Agent-reviewed; not native-human-certified','limits':'Linguistic/meaning/technicalinstruction adversarialreview only; no layout/browser/OS/platform gate approval or executionclaim.'}
out=P/'blind-adversarial-r1.json';assert not out.exists();out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('saved',out,'sha256',sha(out),'approved',len(checks))
