import concurrent.futures,hashlib,json,os,subprocess
from pathlib import Path
R=Path.cwd();BASE=R/'artifacts/thai-localization/rendering';OUT=R/'artifacts/thai-localization/integration-1bb/native-qa/regressions';OUT.mkdir(exist_ok=True);BINARY=R/'build/thai-localization/test/TranslationPreviewHarness';INPUT=OUT/'inputs'
jobs=[]
for locale in ['fr','ja','vi']:
 for name in ['main','settings']:jobs.append((locale+'-'+name,'screen',locale+'-full',1280,800,name,False))
for locale in ['fr','ja','vi','en-source']:jobs.append((locale+'-matrix','matrix',locale+'-matrix',1280,900,'',False))
def run(job):
 name,mode,source,w,h,kind,phone=job;dest=OUT/name;dest.mkdir(exist_ok=True);profile=OUT/'profiles'/name;profile.mkdir(exist_ok=True,parents=True);env=dict(os.environ,GLOB2_USER_DATA_DIR=str(profile),SDL_VIDEODRIVER='dummy',SDL_RENDER_DRIVER='software',SDL_AUDIODRIVER='dummy');env.pop('GLOB2_MOBILE_UI',None);env.pop('GLOB2_GENERATOR_PROTOTYPE_DIAGNOSTICS',None)
 if phone:env['GLOB2_MOBILE_UI']='1'
 cmd=[str(BINARY),mode,str(R),str(INPUT/source),str(dest),str(w),str(h)]+([kind] if kind else [])
 with (dest/'capture.log').open('w') as log:
  try:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240);status=result.returncode
  except subprocess.TimeoutExpired:status='timeout'
 result={'name':name,'command':cmd,'phone_presentation_requested':phone,'status':status,'pngs':{str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.glob('*.png')},'scope':'Fresh integrated native runtime; inspect actual producer identity and current hashed catalog inputs; per-report producer must be verified after execution. English source matrix usesfrlocaleidentity under harness limitation, not English language selection evidence.'};(dest/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(name,status,flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:results=list(pool.map(run,jobs))
(OUT/'manifest.json').write_text(json.dumps({'results':results,'passed':all(r['status']==0 for r in results),'kind':'bounded regression/extracapture; softwareSDLdummy; dev_fast; not mobileOS or releasepackage evidence'},indent=2)+'\n')
if not all(r['status']==0 for r in results):raise SystemExit(1)
