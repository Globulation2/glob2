import hashlib,json,shlex,subprocess,shutil
from pathlib import Path
R=Path.cwd();O=R/'artifacts/thai-localization/integration-1bb/native-qa/baseline';log=R/'artifacts/thai-localization/integration-1bb/native-build.log';files=[R/'artifacts/thai-localization/rendering/final-provenance-build.log',R/'artifacts/thai-localization/checks/integrated-native-build.log',log];commands=[]
for name,source in [('TrueTypeFont','libgag/src/TrueTypeFont.cpp'),('TextLayout','libgag/src/ui/TextLayout.cpp')]:
 line=None
 for p in files:
  for l in p.read_text(errors='replace').splitlines():
   if l.startswith('/usr/bin/ccache g++ ') and l.endswith(' '+source):line=l
 assert line,source
 cmd=shlex.split(line);cmd[cmd.index('-o')+1]=str(O/(name+'.o'));cmd[-1]=str(O/(name+'.cpp'));cmd.insert(-1,'-Ilibgag/src')
 with (O/(name+'-compile.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 commands.append(cmd);print(name+' exact currentmaster baseline compiled',flush=True)
line=next(l for l in log.read_text(errors='replace').splitlines() if l.startswith('g++ -o build/thai-localization/test/TranslationPreviewHarness '))
cmd=shlex.split(line);cmd[cmd.index('-o')+1]=str(O/'TranslationPreviewHarness-base-font-wrap')
archive='build/thai-localization/libgag/src/libgag.a'
if archive in cmd:
 private=O/'libgag-base-font-wrap.a';shutil.copy2(archive,private)
 members=subprocess.check_output(['ar','t',archive],text=True).splitlines()
 assert members.count('TrueTypeFont.o')==members.count('TextLayout.o')==1
 replacement=['ar','rcs',str(private),str(O/'TrueTypeFont.o'),str(O/'TextLayout.o')]
 subprocess.run(replacement,check=True);commands.append(replacement)
 assert subprocess.check_output(['ar','t',str(private)],text=True).splitlines()==members
 for name in ('TrueTypeFont','TextLayout'):
  assert subprocess.check_output(['ar','p',str(private),name+'.o'])==(O/(name+'.o')).read_bytes()
 cmd[cmd.index(archive)]=str(private)
else:
 for before,after in [('build/thai-localization/libgag/src/TrueTypeFont.o',O/'TrueTypeFont.o'),('build/thai-localization/libgag/src/ui/TextLayout.o',O/'TextLayout.o')]:
  assert cmd.count(before)==1,before;cmd[cmd.index(before)]=str(after)
with (O/'link.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
commands.append(cmd)
(O/'commands.json').write_text(json.dumps({'base_revision':subprocess.check_output(['git','rev-parse','1bb5155e96b61144583466a00041fb1d04fc9def'],text=True).strip(),'primary_harness_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'commands':commands,'scope':'Focused actual master font+wrapper modules linked into current harness and current remainder; not a complete baseline release build. Base module sources extracted by gitshow, exact hashes retained.'},indent=2)+'\n')
print('Fresh master baseline font+wrap linked',flush=True)
