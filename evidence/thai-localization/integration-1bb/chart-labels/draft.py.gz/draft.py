import json,importlib.util,hashlib
from decimal import Decimal
from pathlib import Path
r=Path.cwd();p=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('g',r/'tools/localization/google_draft.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g);d=json.loads((p/'sources.json').read_text());assert hashlib.sha256((r/'platform/packages/i18n/locales/en.json').read_bytes()).hexdigest()==d['source_sha256'];folder=r/'artifacts/thai-localization/google/th';manifest=json.load(open(r/'artifacts/thai-localization/manifest.json'));ps=[g.protect(e['source']) for e in d['entries']]
with g.campaign_lock(folder):
 c=g.Campaign(folder,'bradley-personal-20261027','th',manifest['source_sha256'],Decimal(25),Decimal(20));before=json.load(open(folder/'ledger.json'));response=c.translate([x[0] for x in ps]);assert len(response['translations'])==len(d['entries'])
 for e,pro,t in zip(d['entries'],ps,response['translations']):e['provider_draft']=g.restore(t['translatedText'],pro,e['source'],native=False)
 after=json.load(open(folder/'ledger.json'));assert after['attempts'][:len(before['attempts'])]==before['attempts'];d.update(prior_attempts=len(before['attempts']),new_attempts=len(after['attempts'])-len(before['attempts']),cumulative_reserved_usd=str(c.spent));(p/'google-draft.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'entries':len(d['entries']),'new_attempts':d['new_attempts'],'cumulative_reserved_usd':str(c.spent)}))
