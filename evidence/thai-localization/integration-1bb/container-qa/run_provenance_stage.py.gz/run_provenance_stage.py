"""Run an artifact-only QA target, refusing uncached production stage work."""
from pathlib import Path
import subprocess,gzip,json,time,re,threading,signal,collections,argparse
p=argparse.ArgumentParser();p.add_argument('target');p.add_argument('label');args=p.parse_args();r=Path(__file__).resolve().parent;ctx=Path(json.loads((r/'final-context-provenance.json').read_text())['context'])
cmd=['docker','build','--progress=plain','--target',args.target,'--build-arg','JOBS=4','--build-arg','GLOB2_DESIGN_SYSTEM_SHA=220b965b061e402df7531fa0f9ad5104bf29a638','-f',str(r/'Dockerfile.provenance'),'--output','type=local,dest='+str(r/args.label),str(ctx)]
q=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);start=time.time();guarded={};descriptions={};timers=[];tail=collections.deque(maxlen=15);aborted=[];total=0
def abort(step):
 if guarded.get(step)=='pending' and q.poll() is None:aborted.append(step);q.send_signal(signal.SIGINT)
with gzip.open(r/(args.label+'.log.gz'),'wb') as log:
 for line in q.stdout:
  total+=len(line)
  if total>128*1024*1024:q.send_signal(signal.SIGINT);raise RuntimeError('QA build diagnostic allowance exceeded')
  log.write(line);log.flush();s=line.decode(errors='replace').rstrip();tail.append(s)
  m=re.match(r'(#\d+) \[engine-build (\d)/4\]',s)
  if m and m.group(2) in ['1','3','4']:
   step=m.group(1);descriptions[step]=s;guarded[step]='pending';t=threading.Timer(.5,abort,args=(step,));t.start();timers.append(t)
  for step in list(guarded):
   if s==step+' CACHED':guarded[step]='cached'
code=q.wait()
for t in timers:t.cancel()
d=dict(command=cmd,exit_code=code,elapsed_seconds=time.time()-start,cached_engine_steps=guarded,step_descriptions=descriptions,aborted_steps=aborted,uncompressed_log_bytes=total);(r/(args.label+'-result.json')).write_text(json.dumps(d,indent=2)+'\n');print('\n'.join(tail));print(json.dumps(d));raise SystemExit(code)
