import pathlib,json,hashlib
r=pathlib.Path(__file__).resolve().parent;d=json.loads((r/'final-context-provenance.json').read_text());ctx=pathlib.Path(d['context']);short=d['revision'][:8];old=pathlib.Path('artifacts/thai-localization-final-ship/container-qa');latest=pathlib.Path('artifacts/thai-localization-final-ship/container-caddy-final-15638');engine=pathlib.Path('artifacts/thai-localization-final-ship/container-engine-qa')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ex=json.loads((latest/'expected.json').read_text());ex['revision']=d['revision'];keys=list(ex['source_files'])
for p in (ctx/'platform/packages/i18n/locales').glob('*.json'):
 name=p.relative_to(ctx).as_posix()
 if name not in keys:keys.append(name)
ex['source_files']={name:sha(ctx/name) for name in keys};new={}
for name in ['reconciled-r1.json','final-supplement30/edited.json']:
 for e in json.loads((r.parent/name).read_text())['entries']:new[e['key']]=e['target']
ex['integration_targets']=new
assert len(list((ctx/'platform/packages/i18n/locales').glob('*.json')))==40
assert len(json.loads((ctx/'platform/packages/i18n/locales/th.json').read_text()))==2998
for k,v in new.items():assert json.loads((ctx/'platform/packages/i18n/locales/th.json').read_text())[k]==v,k
(r/'expected.json').write_text(json.dumps(ex,ensure_ascii=False,indent=2)+'\n')
for name,source in [('platform-smoke.mjs',old),('run_platform_checks.py',old),('caddy-smoke.mjs',latest),('run_caddy_checks.py',latest),('caddy-http-smoke.sh',latest)]:
 s=(source/name).read_text().replace('platform-smoke-carried-3d59.stdout','platform-smoke.stdout').replace('3d59',short).replace('15638',short).replace('38','40').replace('2904','2998') if name.endswith('.mjs') else (source/name).read_text().replace('3d59',short).replace('15638',short)
 if name.endswith('.mjs'):
  # Avoid changing cryptographic constants containing decimal 38: patch inventory text only below instead.
  s=(source/name).read_text().replace('platform-smoke-carried-3d59.stdout','platform-smoke.stdout').replace('length,38','length,40').replace('length,2904','length,2998').replace('All38','All40').replace('2904keys','2998keys').replace('Final15638','Final'+short)
  if name=='platform-smoke.mjs':s=s.replace("const server =", "for(const [key,value] of Object.entries(expected.integration_targets))assert.deepEqual(th[key],value,key);\nresult.checks.push('All95 integration targets exact source-bound values including revised Broken');\nconst server =")
  if name=='caddy-smoke.mjs':s=s.replace("const js=", "for(const [key,value] of Object.entries(expected.integration_targets))assert.deepEqual(th[key],value,key);result.checks.push('All95 integration targets exact');\nconst js=")
 if name=='run_caddy_checks.py':
  # Never use stale producer image metadata or private extraction path.
  s=s.replace("json.loads(Path('artifacts/thai-localization-final-ship/container-qa/platform-image-inspect.json').read_text())", "json.loads((r/'platform-image-inspect.json').read_text())")
 (r/name).write_text(s)
prov={'upstream_revision':d['revision'],'frozen_context':str(ctx),'source_files':{p.relative_to(ctx).as_posix():sha(p) for p in list((ctx/'data').glob('texts.*.txt'))+list((ctx/'data/fonts').glob('LICENSE*'))+[ctx/'data/fonts/sans.ttf',ctx/'data/fonts/scripts/manifest.json']}}
er=r/'engine-runtime';er.mkdir(exist_ok=True);(er/'provenance.json').write_text(json.dumps(prov,indent=2)+'\n');(er/'inspect.mjs').write_text((engine/'inspect.mjs').read_text());s=(engine/'run_checks.py').read_text().replace('engine-source-83e',ctx.name).replace('glob2-thai-engine-qa:83e','glob2-thai-engine-qa:'+short).replace('-83e','-'+short);(er/'run_checks.py').write_text(s)
print('Prepared actual final expectation:40 catalogs ×2998, integration targets',len(new))
