from PIL import Image,ImageDraw
import pathlib,json,hashlib
r=pathlib.Path(__file__).resolve().parent;out=r/'font-output';canvas=Image.new('RGB',(1000,270),'#ffffff');draw=ImageDraw.Draw(canvas);rows=[]
for index,size in enumerate([10,13,20]):
 report=json.loads((out/f'report-{size}.json').read_text());p=out/f'render-{size}/th.bmp';im=Image.open(p).convert('RGBA');y=index*90;draw.text((12,y+8),f'Actual packaged SDL_ttf / HarfBuzz Thai primary NotoSansThai, size {size}; exact pixels at 2x below',fill='black');zoom=im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST);canvas.paste(zoom,(14,y+30),zoom)
 rows.append({'size':size,'bmp_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'original_dimensions':list(im.size),'font_sha256':report['font_sha256'],'fallback_fonts':report['fallback_fonts'],'harfbuzz_version':report['harfbuzz_version'],'missing':report['locales']['th']['missing'],'text':report['locales']['th']['text'],'display':'RGBA alpha composited on white background, exact nearest-neighbor 2x pixels; no glyph regeneration'})
p=out/'thai-primary-probes-contact.png';canvas.save(p);(out/'contact-metadata.json').write_text(json.dumps({'PNG_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':rows},ensure_ascii=False,indent=2)+'\n');print(p)
