from pathlib import Path
import subprocess,gzip,time,json,signal,collections
r=Path(__file__).resolve().parent;ctx=Path('artifacts/thai-localization/dev-tools/engine-source-c919').resolve();cmd=['docker','build','--progress=plain','--target','engine-agent','--build-arg','JOBS=4','--build-arg','GLOB2_DESIGN_SYSTEM_SHA=220b965b061e402df7531fa0f9ad5104bf29a638','-f',str(ctx/'deploy/Dockerfile'),'-t','glob2-thai-engine-qa:c919',str(ctx)];start=time.time();(r/'build-start.json').write_text(json.dumps({'command':cmd,'started_epoch':start},indent=2)+'\n');p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);tail=collections.deque(maxlen=15);total=0
with gzip.open(r/'build.log.gz','wb') as log:
 for data in p.stdout:
  total+=len(data)
  if total>128*1024*1024:p.send_signal(signal.SIGINT);raise RuntimeError('128MiB uncompressed build diagnostic allowance exceeded')
  log.write(data);log.flush();tail.append(data.decode(errors='replace').strip())
code=p.wait();(r/'build-result.json').write_text(json.dumps({'command':cmd,'exit_code':code,'seconds':time.time()-start,'uncompressed_log_bytes':total},indent=2)+'\n');print('\n'.join(tail));raise SystemExit(code)
