import pathlib,subprocess,tarfile,json,hashlib
root=pathlib.Path.cwd();r=pathlib.Path(__file__).resolve().parent;rev='c919a00fe879be597d0f9ddde9114123a26dcb40';ctx=root/'artifacts/thai-localization/dev-tools/engine-source-c919';ctx.mkdir(exist_ok=False)
p=subprocess.Popen(['git','archive',rev],stdout=subprocess.PIPE)
with tarfile.open(fileobj=p.stdout,mode='r|') as t:t.extractall(ctx,filter='data')
assert p.wait()==0
native=['src','libgag','libusl','scons','SConstruct','SConscript','deploy','mobile','third_party']
rows=subprocess.check_output(['git','ls-tree','-r','1076ef17ad','--',*native]);now=subprocess.check_output(['git','ls-tree','-r',rev,'--',*native]);assert rows==now
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d={'actual_context_revision':rev,'context':str(ctx),'construction':'Immutable git archive from exact committed c919, not dirty working tree. No source writes.','native_code_build_inputs_equal_to':'1076ef17ad','native_code_build_input_rows':len(rows.splitlines()),'native_code_build_input_rows_sha256':hashlib.sha256(rows).hexdigest(),'catalog_assets_not_claimed_equal_to_1076':'Subsequent commits updated native pending catalogs; actual c919 data is captured.','Dockerfile_sha256':sha(ctx/'deploy/Dockerfile'),'native_thai_sha256':sha(ctx/'data/texts.th.txt'),'online_thai_sha256':sha(ctx/'platform/packages/i18n/locales/th.json'),'native_registry_sha256':sha(ctx/'data/texts.list.txt'),'warning':'Upcoming web/i18n source fixes may change engine-agent packaged Node catalog bytes. This c919 producer is preparatory; final engine-agent must bind actual final Node source and cannot be relabeled.'}
(r/'context-provenance.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
