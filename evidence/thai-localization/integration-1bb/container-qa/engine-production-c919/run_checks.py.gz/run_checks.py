import pathlib,subprocess,json,os,hashlib
r=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('artifacts/thai-localization/dev-tools/engine-source-c919').resolve();overlay=(pathlib.Path.cwd()/'artifacts/thai-localization/dev-tools/engine-python').resolve();image='glob2-thai-engine-qa:c919'
output=r/'font-output';output.mkdir(exist_ok=True);output.chmod(0o777)
base=['docker','run','--rm','--user','10001:10001','--network','none','--read-only','--cap-drop=ALL','--security-opt','no-new-privileges','--tmpfs','/tmp:rw,noexec,nosuid,size=32m','--env','SDL_VIDEODRIVER=dummy','--env','SDL_AUDIODRIVER=dummy','--env','LIBGL_ALWAYS_SOFTWARE=1','--workdir','/opt/glob2/share']
records=[]
def run(label,cmd):
 p=subprocess.run(cmd,capture_output=True,text=True,timeout=120)
 (r/(label+'.stdout')).write_text(p.stdout);(r/(label+'.stderr')).write_text(p.stderr);records.append(dict(label=label,command=cmd,exit_code=p.returncode));(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,'exit',p.returncode,flush=True)
 if p.returncode:print(p.stderr[-5000:]);raise RuntimeError(label+' failed')
run('inspect',base+['--name','glob2-thai-engine-inspect-c919','--mount',f'type=bind,src={r},dst=/qa,readonly',image,'node','/qa/inspect.mjs'])
for name in ['version','sim-version','catalog','paths']:
 run('cli-'+name,base+['--name','glob2-thai-engine-cli-'+name+'-c919','--entrypoint','/opt/glob2/bin/glob2',image,'info',name,'--format','json'])
for size in [10,13,20]:
 run('font-'+str(size),base+['--name',f'glob2-thai-engine-font-{size}-c919','--env','PYTHONHOME=/qa-python','--env','PYTHONDONTWRITEBYTECODE=1','--env','LD_LIBRARY_PATH=/qa-python/lib:/opt/glob2/lib/glob2','--mount',f'type=bind,src={overlay},dst=/qa-python,readonly','--mount',f'type=bind,src={repo}/data/fonts/check_script_support.py,dst=/qa/check_script_support.py,readonly','--mount',f'type=bind,src={repo}/data/fonts/script-probes.json,dst=/qa/script-probes.json,readonly','--mount',f'type=bind,src={output},dst=/qa-output', '--entrypoint','/qa-python/bin/python3.12',image,'-B','/qa/check_script_support.py','--font','/opt/glob2/share/data/fonts/scripts/NotoSansThai-Regular.ttf','--fallback-font','/opt/glob2/share/data/fonts/sans.ttf','--probes','/qa/script-probes.json','--sdl-library','/opt/glob2/lib/glob2/libSDL3.so','--library','/opt/glob2/lib/glob2/libSDL3_ttf.so','--locales','th','--size',str(size),'--json-output',f'/qa-output/report-{size}.json','--render-directory',f'/qa-output/render-{size}'])
 report=json.load(open(output/f'report-{size}.json'));assert report['harfbuzz_version']==[10,1,0];assert report['locales']['th']['missing']==[]
print('All engine image checks passed',flush=True)
