import hashlib,json
from pathlib import Path
R=Path.cwd();O=R/'artifacts/thai-localization/integration-1bb/native-qa/regressions/inputs'
def hashfile(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def native(locale):
 lines=(R/f'data/texts.{locale}.txt').read_text().splitlines();return dict(zip(lines[::2],lines[1::2]))
def online(locale):return json.loads((R/f'platform/packages/i18n/locales/{locale}.json').read_text())
def save(name,locale,n,o,meta):
 p=O/name;p.mkdir(parents=True,exist_ok=True)
 for f,v in [('native',n),('online',o),('metadata',{'locale':locale,**meta})]:(p/(f+'.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
keys=['[language]','[language-code]','[language-name]','[quit]','[settings Language & player]','[settings Player name]','[settings Text size]','[settings Choose which server you play on and how you sign in to it.]','[settings Smooth unit motion]','[Explorer]','[barracks]','[warflag]','[clearingflag]','[guard area]','[%0 units can\'t access building]','[intro briefing]','[intro instruction scout]','[intro help supply]','[intro help touch attack]','[lesson healing briefing]','[lesson defensive-tactics guard help]','[stat worker time about]','[stat warrior level about]','[stats health]','[settings Press a key. Escape cancels capture. Use Bind Escape to assign Escape.]','[Portage Lakes cannot fit a useful dry woodland shortcut on this seed.]','[stat health]','[stat unit resources]','[stat band carrying]','[lesson upgrades upgrade hint]','[settings The official Globulation 2 server · ranked queues, leaderboards, map catalog]']
onlinekeys=['Sign in','Sign out','Display name','Settings','Matchmaking','Play','Custom content credits','No maps found.','Source identity','{slot0} teams','The provider outcome needs reconciliation. Your reserved {value0} credits remain held; new requests are paused. Manual editing and export remain available.','Good under {value0}, fair under {value1}, poor from {value2}.']
for locale in ('th','fr','ja','vi'):
 n,o=native(locale),online(locale);meta={'full_native_catalog_path':f'data/texts.{locale}.txt','full_native_catalog_sha256':hashfile(R/f'data/texts.{locale}.txt'),'full_online_catalog_path':f'platform/packages/i18n/locales/{locale}.json','full_online_catalog_sha256':hashfile(R/f'platform/packages/i18n/locales/{locale}.json'),'scope':'Full shipped catalog overlay; viewport/platform claims reported separately.'}
 save(locale+'-full',locale,n,o,meta)
 sn={k:n[k] for k in keys if k in n};so={k:o[k] for k in onlinekeys if k in o};save(locale+'-matrix',locale,sn,so,{**meta,'scope':'Bounded diagnostic subset, not complete visual catalog coverage.','selected_native_keys':list(sn),'selected_online_keys':list(so)})
n,o=native('en'),online('en');save('en-source-matrix','fr',{k:n[k] for k in keys if k in n},{k:o[k] for k in onlinekeys if k in o},{'reference_locale':'en','scope':'English source text font/wrapping reference only. Harness forbids en overlays, so fr locale identity is used. This does not establish English language selection or UI switching.','full_native_catalog_sha256':hashfile(R/'data/texts.en.txt'),'full_online_catalog_sha256':hashfile(R/'platform/packages/i18n/locales/en.json')})
print('Prepared4fullcatalog inputs and5boundedmatrix inputs; no tracked files changed.')
