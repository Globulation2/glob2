import json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
read=lambda n:json.loads((p/n).read_text())
m=read('meaning-r1.json');e=read('editor-r1.json');draft=read('google-draft.json');mm={x['id']:x for x in m['entries']};ee={x['id']:x for x in e['entries']}
meaning_keys={'Expansion','Audit','Unclassified payments'};entries=[]
for d in draft['entries']:
 a,b=mm[d['id']],ee[d['id']];assert a['source']==b['source']==d['source'];target=a['proposed'] if d['key'] in meaning_keys else b['proposed_target'];entries.append({**d,'target':target,'integration_choice':'meaning' if d['key'] in meaning_keys else 'editor','reconciliation':'Retain meaning source/callsite constraints with concise editor wording. Expansion explicitly names colony; Audit is an event log; unclassified refers to unknown payment mode.' if d['key'] in meaning_keys else 'Editor wording preserves the independently checked concept. Music mood terminology follows the existing Thai catalog; analytics product/library token is a category label, not a count.'})
h=lambda b:hashlib.sha256(b).hexdigest();out={'coordinator':'/root','source_sha256':draft['source_sha256'],'target_sha256':h(json.dumps({x['id']:x['target'] for x in entries},ensure_ascii=False,sort_keys=True).encode()),'input_sha256':{n:h((p/n).read_bytes()) for n in ['google-draft.json','meaning-r1.json','editor-r1.json']},'entries':entries,'status':'requires independent adversarial then final meaning/editor recheck'};(p/'reconciled-r1.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(len(entries),out['target_sha256'])
