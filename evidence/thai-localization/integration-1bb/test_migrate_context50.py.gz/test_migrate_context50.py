import copy,importlib.util,json,tempfile,unittest
from pathlib import Path
s=importlib.util.spec_from_file_location('m50',Path(__file__).with_name('migrate_context50.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class ContextSuccessorContracts(unittest.TestCase):
 def setUp(self):
  self.old={'native':{'[n'+str(i)+']':'N'+str(i) for i in range(3417)},'online':{'old'+str(i):'V'+str(i) for i in range(2967)}};self.old['online'].update(Broken='Broken',Building='Building');self.th=copy.deepcopy(self.old);self.th['online']['Broken']='แตกหัก';self.th['online']['Building']='อาคาร';self.new=copy.deepcopy(self.old);self.current=copy.deepcopy(self.th);self.current['online']['Broken']='ใช้งานไม่ได้';self.edited={'entries':[{'id':m.BROKEN,'target':'ใช้งานไม่ได้'}]}
  self.added={'online:Building (music mood)','online:Building (generation progress)','online:Accounts per day','online:Matches per day','online:Guest accounts','online:Registered accounts'}
  self.new_english={k:('Building' if k.startswith('online:Building (') else k[7:]) for k in self.added}
  for i,source in self.new_english.items():self.new['online'][i[7:]]=source;self.current['online'][i[7:]]='ไทย'+i;self.edited['entries'].append({'id':i,'target':'ไทย'+i})
  self.spec={'entries':[{'id':e['id'],'source':self.new['online'][e['id'][7:]]} for e in self.edited['entries']]}
 def test_only_broken_changes_old6386_and_exact6new_appear(self):
  x=m.compare50(self.old,self.th,self.new,self.current,self.edited,self.spec,6,7);self.assertEqual(x['changed_old_keys'],['online:Broken']);self.assertEqual(x['old_unchanged'],6385);self.assertEqual(len(x['added_keys']),6);self.assertEqual(self.current['online']['Building'],'อาคาร')
 def test_unapproved_second_old_edit_rejected(self):
  self.current['online']['Building']='การก่อสร้าง'
  with self.assertRaisesRegex(ValueError,'Unapproved'):m.compare50(self.old,self.th,self.new,self.current,self.edited,self.spec,6,7)
 def test_broken_exception_cannot_cover_any_other_newtarget(self):
  self.current['online']['Broken']='เสีย'
  with self.assertRaisesRegex(ValueError,'exactreviewedBroken'):m.compare50(self.old,self.th,self.new,self.current,self.edited,self.spec,6,7)
 def test_additional_two_symbolic_sources_require_exact_explicit_contract(self):
  for key in ['online:Symbolic modal A','online:Symbolic status B']:
   self.new['online'][key[7:]]='Exact English '+key;self.current['online'][key[7:]]='ไทย '+key;self.spec['entries'].append({'id':key,'source':'Exact English '+key});self.edited['entries'].append({'id':key,'target':'ไทย '+key})
  x=m.compare50(self.old,self.th,self.new,self.current,self.edited,self.spec,8,9);self.assertEqual(len(x['added_keys']),8)
  self.new['online']['Symbolic modal A']='Wrong English'
  with self.assertRaisesRegex(ValueError,'ActualfreshEnglish'):m.compare50(self.old,self.th,self.new,self.current,self.edited,self.spec,8,9)
 def test_unknown_extra_review_source_and_unbounded_counts_rejected(self):
  extra=copy.deepcopy(self.spec);extra['entries'][-1]['id']='online:Unregistered implicit label'
  with self.assertRaisesRegex(ValueError,'Registerednewkeyset'):m.compare50(self.old,self.th,self.new,self.current,self.edited,extra,6,7)
  with self.assertRaisesRegex(ValueError,'bounded'):m.contract_new_ids(self.spec,160,161)
 def test_context7_must_bind_all7_targets_exactroles_and_no_hints(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);spec={'source_sha256':'CURRENT_EN_FILE','entries':[{'id':e['id']} for e in self.edited['entries']]};edited=copy.deepcopy(self.edited);edited.update(source_sha256='CURRENT_EN_FILE',target_sha256=m.canonical({e['id']:e['target'] for e in edited['entries']}));ids=[e['id'] for e in edited['entries']];paths={}
   for role,field,owner in [('final-meaning','reviewer','thai_brief'),('final-editor','editor','thai_rendering'),('final-adversarial','adversarial_reviewer','online_adversarial')]:
    p=root/(role+'.json');p.write_text(json.dumps({field:owner,'source_sha256':spec['source_sha256'],'target_sha256':edited['target_sha256'],'approved_keys':ids,'findings':[]}));paths[role]=p
   self.assertEqual(len(m.verify_supplement(spec,edited,paths,'CURRENT_EN_FILE',6,7)),3)
   x=m.read(paths['final-editor']);x['approved_keys']=ids[:-1];paths['final-editor'].write_text(json.dumps(x))
   with self.assertRaisesRegex(ValueError,'genuinefinalrole'):m.verify_supplement(spec,edited,paths,'CURRENT_EN_FILE',6,7)
if __name__=='__main__':unittest.main()
