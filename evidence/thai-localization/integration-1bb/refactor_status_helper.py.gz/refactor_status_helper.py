from pathlib import Path
b=Path('platform/apps/web/src');p=b/'messages.ts';s=p.read_text();anchor='/** Carry source and parameters until an error is presented in the current locale. */';assert anchor in s
helper='''/** Owned status copy is deferred; raw runtime diagnostics remain byte-for-byte strings. */
export type StatusMessage = string | {
  source: string;
  params?: Record<string, string | number> | (() => Record<string, string | number>);
};
export function sourceMessage(
  source: string,
  params?: Exclude<StatusMessage, string>['params'],
): Exclude<StatusMessage, string> {
  return { source, params };
}
export function statusText(status: StatusMessage): string {
  return typeof status === 'string'
    ? status
    : t(status.source, typeof status.params === 'function' ? status.params() : status.params);
}

''';s=s.replace(anchor,helper+anchor);p.write_text(s)
for f,rel in [('sets/Preview.tsx','../messages.ts'),('pages/aiStudio/Playtest.tsx','../../messages.ts'),('pages/generatorStudio/Preview.tsx','../../messages.ts')]:
 p=b/f;s=p.read_text();start=s.index('// Keep owned status messages translatable');end=s.index('\nexport ',start);s=s[:start]+s[end+1:];s="import { sourceMessage, statusText, type StatusMessage } from '"+rel+"';\n"+s;p.write_text(s)
