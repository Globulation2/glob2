from pathlib import Path
B=Path('platform/apps/web/src')
helper='''// Keep owned status messages translatable after a locale switch; engine diagnostics stay raw.
type StatusMessage = string | {
  source: string;
  params?: Record<string, string | number> | (() => Record<string, string | number>);
};
function sourceMessage(source: string, params?: Exclude<StatusMessage, string>['params']): Exclude<StatusMessage, string> {
  return { source, params };
}
function statusText(status: StatusMessage): string {
  return typeof status === 'string' ? status : t(status.source, typeof status.params === 'function' ? status.params() : status.params);
}
'''
for f,rel in [('sets/Preview.tsx','../i18n.tsx'),('pages/aiStudio/Playtest.tsx','../../i18n.tsx'),('pages/generatorStudio/Preview.tsx','../../i18n.tsx')]:
 p=B/f;s=p.read_text();old="import { message as sourceMessage } from '"+rel+"';\n";assert old in s;s=s.replace(old,'');pos=s.index('export ');s=s[:pos]+helper+s[pos:];s=s.replace('[status, setStatus] = useState(\'\')',"[status, setStatus] = useState<StatusMessage>('')");s=s.replace("[status, setStatus] = useState(t('Loading game…'))","[status, setStatus] = useState<StatusMessage>(sourceMessage('Loading game…'))");s=s.replace("[status, setStatus] = useState(t('Loading engine…'))","[status, setStatus] = useState<StatusMessage>(sourceMessage('Loading engine…'))");s=s.replace('<p role="status">{status}</p>','<p role="status">{statusText(status)}</p>');p.write_text(s)
p=B/'sets/Preview.tsx';s=p.read_text();s=s.replace("setStatus('Loading browser renderer…')","setStatus(sourceMessage('Loading browser renderer…'))");old="} else setStatus(String(m.report?.reason ?? 'Preview failed.').slice(0, 2000));";assert old in s;s=s.replace(old,"} else setStatus(m.report?.reason == null ? sourceMessage('Preview failed.') : String(m.report.reason).slice(0, 2000));");p.write_text(s)
p=B/'pages/aiStudio/Playtest.tsx';s=p.read_text();old="        diagnostic?: unknown;\n      },\n    ) => {";assert old in s;s=s.replace(old,"        diagnostic?: unknown;\n      },\n      fixedReason?: string,\n    ) => {");old="? 'Playtest failed: ' + String(value.text ?? value.result).slice(0, 2000)\n          : t('Finished: {value0}', { value0: String(value.result).slice(0, 2000) }),";assert old in s;s=s.replace(old,"? sourceMessage('Playtest failed: {value0}', () => ({ value0: fixedReason ? t(fixedReason) : String(value.text ?? value.result).slice(0, 2000) }))\n          : sourceMessage('Finished: {value0}', { value0: String(value.result).slice(0, 2000) }),");old="""        () =>
          finish('error', {
            text: 'The game did not start in time. Check browser support or restart the playtest.',
          }),""";assert old in s;s=s.replace(old,"""        () => {
          const reason = sourceMessage('The game did not start in time. Check browser support or restart the playtest.');
          finish('error', { text: reason.source }, reason.source);
        },""");s=s.replace("          t('Revision {value0} · tick {value1} · live',", "          sourceMessage('Revision {value0} · tick {value1} · live',");p.write_text(s)
p=B/'pages/generatorStudio/Preview.tsx';s=p.read_text();s=s.replace("? t('Revision {value0} · seed {value1} · {value2} seconds',", "? sourceMessage('Revision {value0} · seed {value1} · {value2} seconds',");old=": String(m.diagnostic || 'Generation failed').slice(0, 2000),";assert old in s;s=s.replace(old,": m.diagnostic ? String(m.diagnostic).slice(0, 2000) : sourceMessage('Generation failed'),");s=s.replace("          t('Revision {value0} · tick {value1} · live',", "          sourceMessage('Revision {value0} · tick {value1} · live',");old="setStatus(String(m.text ?? m.result ?? 'Finished').slice(0, 2000));";assert old in s;s=s.replace(old,"const detail = m.text ?? m.result;\n        setStatus(detail == null ? sourceMessage('Finished') : String(detail).slice(0, 2000));");p.write_text(s)
