from pathlib import Path
import subprocess,os,gzip,json,hashlib,time,signal,collections
r=Path(__file__).resolve().parent;root=Path.cwd();env=dict(os.environ);env['PATH']='/home/bradley/.local/share/glob2/development/toolchains/emscripten/Linux-x86_64-88a621bc131cd4954413aa39/node/24.19.0_64bit/bin:'+env['PATH'];env['GLOB2_TEST_URL']='http://127.0.0.1:8797'
cmd=[str(root/'browser/node_modules/.bin/playwright'),'test','thai-localization.spec.js','--config',str(r/'playwright.config.cjs'),'--workers=1'];start=time.time();proof={'command':cmd,'start_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'baseURL':env['GLOB2_TEST_URL'],'package_version':'019983d0d9b34aa9','package_sha256sums':hashlib.sha256((root/'artifacts/thai-localization-final-0a5/browser-package-114/SHA256SUMS').read_bytes()).hexdigest(),'raw_log_allowance_bytes':128*1024*1024,'browser_overlap':'None; current311onlineUI qualification and six raw114goldenbrowsercases completed before this shipping-shell phase'};(r/'run-start.json').write_text(json.dumps(proof,indent=2)+'\n');p=subprocess.Popen(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);n=0;tail=collections.deque(maxlen=16)
with gzip.open(r/'compiled-tests.log.gz','wb') as f:
 for b in p.stdout:
  n+=len(b)
  if n>128*1024*1024:p.send_signal(signal.SIGINT);raise RuntimeError('128MiB rawcompiledlogallowanceexceeded')
  f.write(b);f.flush();tail.append(b.decode(errors='replace').rstrip())
code=p.wait();proof.update(exit_code=code,elapsed_seconds=time.time()-start,raw_log_bytes=n,end_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip());(r/'run-result.json').write_text(json.dumps(proof,indent=2)+'\n');print('\n'.join(tail));raise SystemExit(code)
