from pathlib import Path
import json,hashlib,gzip,re
r=Path(__file__).resolve().parent;d=json.loads((r/'package-files.json').read_text());pkg=Path(d['package']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(pkg/'SHA256SUMS')==d['sha256sums_sha256'];actual={str(p.relative_to(pkg)) for p in pkg.rglob('*') if p.is_file() and p.name!='SHA256SUMS'};assert actual==set(d['files'])
s=gzip.decompress((r/'http.stdout.gz').read_bytes()).decode();records=[]
for method,label,path,encoding,body in re.findall(r'@@BEGIN (GET|HEAD|CONDITIONAL) (\S+) (\S+) (\S+)\n(.*?)@@END',s,re.S):
 statuses=re.findall(r'^\s*HTTP/\S+ (\d+)',body,re.M);assert statuses;headers={m.group(1).lower():m.group(2).strip() for m in re.finditer(r'^\s*([A-Za-z][A-Za-z-]*):\s*(.*?)\s*$',body,re.M)};record={'method':method,'id':label,'path':path,'accept_encoding':encoding,'status':int(statuses[0]),'headers':headers}
 for field in ['WIRE_SHA','PLAIN_SHA']:
  m=re.search(r'@@'+field+r' ([a-f0-9]{64})',body)
  if m:record[field.lower()]=m.group(1)
 records.append(record)
index={(x['method'],x['id']):x for x in records}
assert index[('HEAD','bare_play')]['status'] in [302,308] and index[('HEAD','bare_play')]['headers']['location']=='/play/'
assert index[('HEAD','missing_font')]['status']==404
requests=json.loads((r/'requests.json').read_text())
for req in requests:
 x=index[(req['method'],req['id'])];h=x['headers'];assert x['status']==200,req;assert h['cross-origin-opener-policy']=='same-origin';assert h['cross-origin-embedder-policy']=='require-corp';assert 'wasm-unsafe-eval' in h['content-security-policy'];assert h['x-content-type-options']=='nosniff';assert 'accept-encoding' in h['vary'].lower()
 p=req['source'];mime='text/html' if p.endswith('.html') else 'text/javascript' if p.endswith('.js') else 'application/json' if p.endswith('.json') else 'text/css' if p.endswith('.css') else 'text/plain' if p.endswith('.txt') else 'font/ttf' if p.endswith('.ttf') else 'application/wasm' if p.endswith('.wasm') else 'application/octet-stream';assert h['content-type'].split(';')[0]==mime,(p,h)
 expected_cache='public, max-age=31536000, immutable' if p in d['content_addressed_assets'] else 'no-cache';assert h['cache-control']==expected_cache,(p,h)
 if req['encoding']=='gzip':assert h['content-encoding']=='gzip',(p,h)
 else:assert 'content-encoding' not in h,(p,h)
 if 'content-length' in h:assert int(h['content-length'])==req['wire_bytes'],(p,h)
 else:assert req['encoding']=='gzip' and (req['method']=='HEAD' or h.get('transfer-encoding')=='chunked'),(p,h)
 if req['method']=='GET':assert x['wire_sha']==req['wire_sha256'] and x['plain_sha']==req['plain_sha256']
for label in ['index_identity','index_gzip','font_identity']:assert index[('CONDITIONAL',label)]['status']==304
assert len(records)==len(requests)+5
(r/'http-responses.json').write_text(json.dumps(records,indent=2)+'\n');print('PASS',len(records),'actualHTTPresponses;selectedwire+decodedSHA;36contentaddressedHEADpairs;bothvariants MIME/COOP/COEP/cache')
