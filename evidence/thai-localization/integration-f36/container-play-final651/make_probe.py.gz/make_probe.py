from pathlib import Path
import json,shlex
r=Path(__file__).resolve().parent;d=json.loads((r/'package-files.json').read_text());files=d['files'];q=shlex.quote
script='''#!/bin/sh
set -eu
id
caddy version
sha256sum /etc/caddy/Caddyfile
caddy run --config /etc/caddy/Caddyfile --adapter caddyfile >/tmp/server.log 2>&1 &
qa_caddy_pid=$!
trap 'kill "$qa_caddy_pid" 2>/dev/null || true; wait "$qa_caddy_pid" 2>/dev/null || true' EXIT
qa_attempt=0
until wget -q -O /tmp/live http://127.0.0.1:2015/livez; do
 qa_attempt=$((qa_attempt+1));if [ "$qa_attempt" -gt 50 ];then cat /tmp/server.log;exit 1;fi;sleep 0.2
done
qa_get() {
 qa_id=$1;qa_path=$2;qa_encoding=$3;qa_expected_wire=$4;qa_expected_plain=$5
 printf '@@BEGIN GET %s %s %s\\n' "$qa_id" "$qa_path" "$qa_encoding"
 wget -S --header "Accept-Encoding: $qa_encoding" -O /tmp/body "http://127.0.0.1:8089$qa_path" 2>/tmp/headers
 cat /tmp/headers
 qa_wire=$(sha256sum /tmp/body | cut -d' ' -f1)
 printf '@@WIRE_SHA %s\\n' "$qa_wire"
 test "$qa_wire" = "$qa_expected_wire"
 if [ "$qa_encoding" = gzip ];then
  gzip -t /tmp/body
  qa_plain=$(gzip -dc /tmp/body | sha256sum | cut -d' ' -f1)
 else qa_plain=$qa_wire;fi
 printf '@@PLAIN_SHA %s\\n' "$qa_plain"
 test "$qa_plain" = "$qa_expected_plain"
 printf '@@END\\n'
 if [ "$qa_id" = index_identity ] || [ "$qa_id" = index_gzip ] || [ "$qa_id" = font_identity ];then
  qa_etag=$(awk 'tolower($1)=="etag:" {print $2}' /tmp/headers | tr -d '\\r')
  test -n "$qa_etag"
  printf '@@BEGIN CONDITIONAL %s %s %s\\n' "$qa_id" "$qa_path" "$qa_encoding"
  set +e
  wget -S --header "Accept-Encoding: $qa_encoding" --header "If-None-Match: $qa_etag" -O /tmp/conditional "http://127.0.0.1:8089$qa_path" 2>/tmp/conditional.headers
  qa_code=$?
  set -e
  cat /tmp/conditional.headers;printf '@@WGET_EXIT %s\\n' "$qa_code"
  grep -q '304 Not Modified' /tmp/conditional.headers
  printf '@@END\\n'
 fi
}
qa_head() {
 qa_id=$1;qa_path=$2;qa_encoding=$3
 printf '@@BEGIN HEAD %s %s %s\\n' "$qa_id" "$qa_path" "$qa_encoding"
 printf 'HEAD %s HTTP/1.1\\r\\nHost: 127.0.0.1:8089\\r\\nAccept-Encoding: %s\\r\\nConnection: close\\r\\n\\r\\n' "$qa_path" "$qa_encoding" | nc 127.0.0.1 8089
 printf '\\n@@END\\n'
}
qa_head bare_play /play identity
'''
requests=[]
def get(label,path,file,encoding):
 wire=files[file+('.gz' if encoding=='gzip' else '')];plain=files[file];scriptline='qa_get '+' '.join(map(q,[label,path,encoding,wire['sha256'],plain['sha256']]))+'\n';requests.append({'method':'GET','id':label,'path':path,'encoding':encoding,'source':file,'wire_sha256':wire['sha256'],'wire_bytes':wire['bytes'],'plain_sha256':plain['sha256']});return scriptline
script+=get('play_root','/play/','index.html','identity')
for n,file in enumerate(d['GET_selected_originals']):
 label='index' if file=='index.html' else 'font' if file=='fonts/NotoSansThai-Regular.ttf' else 'selected_'+str(n)
 for enc in ['identity','gzip']:script+=get(label+'_'+enc,'/play/'+file,file,enc)
for n,file in enumerate(d['content_addressed_assets']):
 for enc in ['identity','gzip']:
  label='content_'+str(n)+'_'+enc;script+='qa_head '+' '.join(map(q,[label,'/play/'+file,enc]))+'\n';wire=files[file+('.gz' if enc=='gzip' else '')];requests.append({'method':'HEAD','id':label,'path':'/play/'+file,'encoding':enc,'source':file,'wire_bytes':wire['bytes']})
script+='''qa_head missing_font /play/fonts/does-not-exist.ttf identity
printf '@@SERVER_LOG\\n';cat /tmp/server.log
'''
(r/'probe.sh').write_text(script);(r/'requests.json').write_text(json.dumps(requests,indent=2)+'\n');print('prepared',len(requests),'assetrequests +rootredirect/3conditional/missing404')
