import pathlib,subprocess,json,os,hashlib
r=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('artifacts/thai-localization/dev-tools/production-source-65133e65').resolve();overlay=(pathlib.Path.cwd()/'artifacts/thai-localization/dev-tools/engine-python').resolve();image='glob2-thai-engine-qa:65133e65'
output=r/'font-output';output.mkdir(exist_ok=True);output.chmod(0o777)
base=['docker','run','--rm','--user','10001:10001','--network','none','--read-only','--cap-drop=ALL','--security-opt','no-new-privileges','--tmpfs','/tmp:rw,noexec,nosuid,size=32m','--env','SDL_VIDEODRIVER=dummy','--env','SDL_AUDIODRIVER=dummy','--env','LIBGL_ALWAYS_SOFTWARE=1','--workdir','/opt/glob2/share']
records=[]
def run(label,cmd):
 p=subprocess.run(cmd,capture_output=True,text=True,timeout=120)
 (r/(label+'.stdout')).write_text(p.stdout);(r/(label+'.stderr')).write_text(p.stderr);records.append(dict(label=label,command=cmd,exit_code=p.returncode));(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,'exit',p.returncode,flush=True)
 if p.returncode:print(p.stderr[-5000:]);raise RuntimeError(label+' failed')
run('inspect',base+['--name','glob2-thai-engine-inspect-65133e65','--mount',f'type=bind,src={r},dst=/qa,readonly',image,'node','/qa/inspect.mjs'])
for name in ['version','sim-version','catalog','paths']:
 run('cli-'+name,base+['--name','glob2-thai-engine-cli-'+name+'-65133e65','--entrypoint','/opt/glob2/bin/glob2',image,'info',name,'--format','json'])
print('Actual final651 image inspection and CLI passed; identical native library/font probes carried separately',flush=True)
