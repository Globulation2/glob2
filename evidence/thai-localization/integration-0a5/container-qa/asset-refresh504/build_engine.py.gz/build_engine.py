from pathlib import Path
import subprocess,gzip,time,json,signal,collections,os
r=Path(__file__).resolve().parent;d=json.loads((r/'final-context-provenance.json').read_text());ctx=Path(d['context']);short=d['revision'][:8]
for target in ['engine-agent']:
 label='engine' if target=='engine-agent' else target;tag=f'glob2-thai-{label}-qa:{short}';cmd=['docker','build','--progress=plain','--target',target,'--build-arg','JOBS=4','--build-arg','GLOB2_DESIGN_SYSTEM_SHA=220b965b061e402df7531fa0f9ad5104bf29a638','--build-context','engine-build=docker-image://glob2-thai-engine-build-stage-qa:504ad800','--build-context','music-web-build=docker-image://glob2-thai-music-build-qa:63020def','-f',str(ctx/'deploy/Dockerfile'),'-t',tag,str(ctx)];start=time.time();(r/(label+'-build-start.json')).write_text(json.dumps({'actual_revision':d['revision'],'command':cmd,'started_epoch':start},indent=2)+'\n');p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);tail=collections.deque(maxlen=8);total=0;aborted=False
 with gzip.open(r/(label+'-build.log.gz'),'wb') as log:
  for data in p.stdout:
   total+=len(data)
   if total>128*1024*1024 and not aborted:os.killpg(p.pid,signal.SIGINT);aborted=True
   if not aborted:log.write(data);log.flush()
   tail.append(data.decode(errors='replace').strip()[:700])
 code=p.wait();result={'actual_revision':d['revision'],'tag':tag,'command':cmd,'exit_code':code,'seconds':time.time()-start,'uncompressed_log_bytes':total,'allowance_bytes':128*1024*1024,'aborted_diagnostic_limit':aborted};(r/(label+'-build.json')).write_text(json.dumps(result,indent=2)+'\n');print(label,json.dumps(result),flush=True);print('\n'.join(tail),flush=True)
 if code or aborted:raise SystemExit(code or 1)
 image=json.loads(subprocess.check_output(['docker','image','inspect',tag]))[0];(r/(label+'-image-inspect.json')).write_text(json.dumps(image,indent=2)+'\n')
