import pathlib,subprocess,shutil,os,json,hashlib,argparse
p=argparse.ArgumentParser();p.add_argument('--revision',required=True);a=p.parse_args();rev=subprocess.check_output(['git','rev-parse',a.revision],text=True).strip();base='02755c1788c207e354c139d4cb51e03feee66b82';root=pathlib.Path.cwd();r=pathlib.Path(__file__).resolve().parent;ctx=root/'artifacts/thai-localization/dev-tools'/('production-source-'+rev[:8]);old=root/'artifacts/thai-localization/dev-tools/production-source-02755c17';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==rev;assert not subprocess.check_output(['git','status','--porcelain'],text=True)
shutil.copytree(old,ctx,copy_function=os.link,symlinks=True)
changes=subprocess.check_output(['git','diff','--name-status','--no-renames',base,rev],text=True).splitlines();proof=[]
for row in changes:
 status,name=row.split('\t');f=ctx/name;prev=old/name
 prior=hashlib.sha256(prev.read_bytes()).hexdigest() if prev.is_file() else None
 if f.is_file() or f.is_symlink():f.unlink()
 if status!='D':
  blob=subprocess.check_output(['git','show',rev+':'+name]);mode=subprocess.check_output(['git','ls-tree',rev,'--',name],text=True).split()[0];f.parent.mkdir(parents=True,exist_ok=True)
  if mode=='120000':f.symlink_to(blob.decode())
  else:f.write_bytes(blob);f.chmod(0o755 if mode=='100755' else 0o644)
  assert f.read_bytes()==blob if not f.is_symlink() else os.readlink(f).encode()==blob
 if prev.is_file():assert hashlib.sha256(prev.read_bytes()).hexdigest()==prior
 proof.append({'status':status,'path':name,'previous_sha256':prior,'new_sha256':hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None})
d={'revision':rev,'context':str(ctx),'predecessor_context':str(old),'predecessor_revision':base,'construction':'Hardlink clone of immutable committed git archive; changed committed Git blobs installed as new inodes; predecessor file bytes checked unchanged. Dirty worktree refused.','changed_files':proof,'Dockerfile_sha256':hashlib.sha256((ctx/'deploy/Dockerfile').read_bytes()).hexdigest(),'native_thai_sha256':hashlib.sha256((ctx/'data/texts.th.txt').read_bytes()).hexdigest(),'online_thai_sha256':hashlib.sha256((ctx/'platform/packages/i18n/locales/th.json').read_bytes()).hexdigest()};(r/'final-context-provenance.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'revision':rev,'context':str(ctx),'changed_files':len(proof)}))
