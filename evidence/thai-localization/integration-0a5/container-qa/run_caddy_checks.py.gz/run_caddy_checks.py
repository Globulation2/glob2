from pathlib import Path
import subprocess,json,time,hashlib,re
r=Path(__file__).resolve().parent;web=Path('artifacts/thai-localization/dev-tools/caddy-web-8fb92a6e').resolve();images={'platform':json.loads((r/'platform-image-inspect.json').read_text())['Id'],'caddy':json.loads((r/'caddy-image-inspect.json').read_text())['Id']};commands=json.loads((r/'caddy-check-commands.json').read_text()) if (r/'caddy-check-commands.json').exists() else []
def run(label,cmd,timeout=120):
 start=time.time();p=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout);(r/(label+'.stdout')).write_text(p.stdout);(r/(label+'.stderr')).write_text(p.stderr);commands.append({'label':label,'command':cmd,'exit_code':p.returncode,'seconds':time.time()-start});(r/'caddy-check-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode:print(p.stderr[-2000:]);raise RuntimeError(label)
 return p
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if web.exists():
 inventory=json.loads((r/'caddy-web-inventory.json').read_text())
 for path,meta in inventory.items():assert sha(web/path)==meta['sha256'],path
else:
 web.mkdir();name='glob2-thai-caddy-extract-8fb92a6e'
 run('caddy-create',['docker','create','--name',name,'--network','none',images['caddy']])
 try:run('caddy-extract',['docker','cp',name+':/srv/web/.',str(web)],timeout=180)
 finally:run('caddy-remove-extract',['docker','rm',name])
 inventory={str(p.relative_to(web)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in web.rglob('*') if p.is_file()};(r/'caddy-web-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
run('caddy-smoke',['docker','run','--rm','--name','glob2-thai-caddy-assets-smoke-8fb92a6e','--user','10001:10001','--network','none','--read-only','--cap-drop=ALL','--security-opt','no-new-privileges','--mount',f'type=bind,src={r},dst=/qa,readonly','--mount',f'type=bind,src={web},dst=/qa-web,readonly',images['platform'],'node','/qa/caddy-smoke.mjs'])
d=json.loads((r/'caddy-smoke.stdout').read_text());font='/assets/'+d['fonts']['NotoSansThai']['path'];thai='/assets/'+d['catalogs']['th']['path'];css='/assets/'+d['map_owner_css'];extra_css='/assets/'+d['music_upload_css']
for p in [font,thai,css,extra_css]:assert re.fullmatch(r'/assets/[A-Za-z0-9._-]+',p),p
cmd=['docker','run','--rm','--name','glob2-thai-caddy-http-smoke-8fb92a6e','--user','10001:10001','--network','none','--read-only','--cap-drop=ALL','--security-opt','no-new-privileges','--tmpfs','/tmp:rw,noexec,nosuid,size=16m','--tmpfs','/config:rw,noexec,nosuid,size=16m,uid=10001,gid=10001,mode=0700','--tmpfs','/data:rw,noexec,nosuid,size=16m,uid=10001,gid=10001,mode=0700','--env','GLOB2_DOMAIN=http://127.0.0.1:8088','--env','GLOB2_PUBLIC_ORIGIN=http://127.0.0.1:8088','--env','GLOB2_TLS_MODE=auto','--env','QA_FONT_PATH='+font,'--env','QA_THAI_PATH='+thai,'--env','QA_CSS_PATH='+css,'--env','QA_EXTRA_CSS_PATH='+extra_css,'--mount',f'type=bind,src={r},dst=/qa,readonly','--entrypoint','/bin/sh',images['caddy'],'/qa/caddy-http-smoke.sh']
p=run('caddy-http-smoke',cmd);text=p.stdout
for h in [d['fonts']['NotoSansThai']['sha256'],d['catalogs']['th']['sha256'],inventory[css[1:]]['sha256'],inventory[extra_css[1:]]['sha256']]:assert h in text,h
for v in d['notices'].values():assert v['sha256'] in text
ssr=json.loads((r/'platform-smoke.stdout').read_text());assert ssr['files']['glob2-sans.woff2']['sha256'] in text
assert len(re.findall(r'Content-Type: text/plain',text,re.I))>=4
assert re.search(r'Content-Type: font/woff2',text,re.I)
assert re.search(r'Content-Type: text/css',text,re.I)
assert re.search(r'Content-Type: (?:text|application)/javascript',text,re.I)
assert re.search(r'Content-Type: font/ttf',text,re.I);assert 'Content-Encoding: gzip' in text;assert '304 Not Modified' in text;assert 'public, max-age=31536000, immutable' in text
(r/'caddy-http-result.json').write_text(json.dumps({'status':'passed','font':font,'font_sha256':d['fonts']['NotoSansThai']['sha256'],'font_mime':'font/ttf','cold_font_get':200,'conditional_font_get':304,'thai_chunk':thai,'gzip_decompressed_sha256':d['catalogs']['th']['sha256'],'skin_css':css,'skin_css_gzip_decompressed_sha256':inventory[css[1:]]['sha256'],'brotli':'Existingproductionencodezstdgzip; br-onlyrequestreturnedidentitywithoriginalhash; No brotli web sidecars in actual image. /play package is not mounted or qualified in these web checks; new-master game package remains a separate handoff.','scope':'ActualCaddyproductionconfig,HTTPboundonlyloopbackinsideownnetworknonecontainer,read-only/u10001,tmpfsonly; coldserverassetrequestandconditionalcachevalidation,notbrowserfontloadingor /playqualification.'},indent=2)+'\n')
print('ALLCaddyactualpackagechecksPASS',flush=True)
