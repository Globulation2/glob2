import json,hashlib
from pathlib import Path
ROOT=Path('artifacts/thai-localization')
def record(batch, rows, english=None):
 d=json.loads((ROOT/'round1/batches'/f'{batch}.json').read_text())
 findings=[]
 for row in rows:
  index, proposed, severity, reason=row
  e=d['entries'][index]
  findings.append({'id':e['id'],'severity':severity,'proposed':proposed,'reason':reason,'boundary_status':'plain Thai proposal; regenerate candidate boundaries and review before approval'})
 r={'editor':'cloud_adapter','source_sha256':d['source_sha256'],'target_sha256':hashlib.sha256(json.dumps({e['id']:e['target'] for e in d['entries']},sort_keys=True,ensure_ascii=False).encode()).hexdigest(),'edited_keys':[e['id'] for e in d['entries']],'findings':findings,'accepted_english':english or [],'review_basis':'Every source and actual target in this immutable batch read independently; meaning findings not consulted. Plain Thai corrections await boundary regeneration/recheck.','status':'independent-editorial-proposals; not final sign-off'}
 (ROOT/'reviews/editor'/f'{batch}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
 print(batch,len(r['edited_keys']),len(findings))
