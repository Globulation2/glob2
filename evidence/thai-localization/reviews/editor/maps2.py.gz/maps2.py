from record import record
record('native-maps-002',[
(0,'เลือกแปรง สมาชิกในแต่ละกลุ่มใช้กฎชุดเดียวกันและต่างกันเพียงรูปลักษณ์','major','Rules are shared within a group; the draft can imply all different groups use identical rules.'),
(3,'แชร์แผนที่ออนไลน์แล้ว','minor','Completed action feedback, not an adjective describing a shared map.'),
(4,'นำเข้าข้อกำหนดภูมิประเทศ…','minor','Consistent data-definition wording.'),
(5,'ตัวสร้างแผนที่ทั้งหมด','major','Generators are map software, not electricity generators.'),
(6,'กำลังดาวน์โหลดตัวสร้างแผนที่…','minor','Explicit software context.'),
(9,'เปิดใช้ตระกูลอาคารที่ติดตั้งไว้ด้านล่าง การเลือกบันทึกในโปรไฟล์บนอุปกรณ์นี้ แผนที่และเกมที่บันทึกไว้ยังคงอาคารเดิม หากต้องการเล่นออนไลน์ ให้สร้างแผนที่ที่ใช้ตระกูลเหล่านี้ เผยแพร่ในคลังแผนที่ แล้วเลือกแผนที่นั้นในห้อง','minor','Local profile is on device, not regional/locality profile; concise continuity guidance.'),
(10,'แฮชไฟล์ตัวสร้างแผนที่ไม่ตรงกัน','minor','Keep แฮช intact and clarify generator type.'),
(11,'ติดตั้งตัวสร้างแผนที่แล้ว การเลือกครั้งต่อไปจะใช้รุ่นเผยแพร่นี้','major','No signal generator involved; release refers to installed software content version.'),
(12,'ข้อมูลระบุแพ็กเกจตัวสร้างแผนที่ไม่ตรงกัน','minor','Natural error wording, intact แพ็กเกจ, explicit software context.'),
(13,'ตัวสร้างแผนที่','major','Not electrical generators.'),
(14,'ตัวสร้างแผนที่','minor','Keep consistent software noun.'),
(15,'ตัวสร้างแผนที่ของฉัน','major','Not electrical generators.'),
(16,'ตัวสร้างแผนที่สำหรับเล่น','major','Playable generator generates playable maps, not a machine one plays.'),
(17,'กำลังบันทึกคลังตัวสร้างแผนที่…','minor','Consistent library/generator terminology.'),
])
