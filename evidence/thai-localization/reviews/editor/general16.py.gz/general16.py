import json,re
from pathlib import Path
from record import record
entries=json.loads(Path('artifacts/thai-localization/round1/batches/native-general-016.json').read_text())['entries']
fixes={
0:('รุ่นเผยแพร่ %0','major','Release is a content version noun, not a release command.'),
2:('ซีด: %0','major','Map randomness seed.'),
13:('บทแนะนำ','minor','Concise introductory lesson label.'),
16:('ยูนิตทำงานเอง คุณกำหนดหน้าที่ผ่านอาคารและธง ในบทแนะนำสั้นๆ นี้ คุณจะสำรวจจุดสังเกต เพิ่มแหล่งอาหาร เพิ่มคนงาน และสั่งการบุกเล็กๆ','critical','Globules are game units, not energy balls. Preserve indirect control teaching.'),
17:('ใช้เวลาประมาณ 10 นาที บันทึกได้จากเมนูในเกมแล้วเล่นต่อผ่านโหลดเกม ใช้กฎความหิวและการรบตามปกติ เลือกบทเรียนฝึกสอนจากเมนูหลักเพื่อฝึกทักษะเพิ่ม','major','Saving is from in-game menu, not main menu; preserve load/resume and normal rules.'),
19:('สำรวจจุดสังเกตที่เป็นหิน','minor','Natural descriptive landmark.'),
20:('สร้างโรงเตี๊ยมเพิ่ม','major','Canonical feeding building.'),
21:('ส่งเสบียงให้โรงเตี๊ยมใหม่','major','Supply food, not hotel equipment.'),
23:('ทำลายรังศัตรู','major','Birth-producing building, not an enemy swarm group.'),
25:('เปิดสร้าง แล้ววางโรงเตี๊ยมใกล้ข้าวสาลี มอบหมายคนงานว่างให้ก่อสร้าง และคงคนงานส่งเสบียงให้โรงเตี๊ยมเดิมไว้','major','Keep existing food supply staffed while making builders available.'),
26:('เลือกโรงเตี๊ยมใหม่ที่สร้างเสร็จแล้ว มอบหมายคนงานส่งเสบียงอย่างน้อย 1 ตัว แล้วรอให้ส่งข้าวสาลี','major','Suppliers are autonomous workers, not external vendors.'),
27:('เลือกรัง ตั้งจำนวนคนงานที่มอบหมายอย่างน้อย 2 และตั้งสัดส่วนให้สร้างเฉพาะคนงาน ส่งเสบียงให้โรงเตี๊ยมทั้งสองแห่งระหว่างรอคนงานใหม่เกิด','major','Worker target is supplier staffing, distinct from unit-production ratio.'),
28:('หารังศัตรูถัดไปทางตะวันออก ใช้ธงรบชี้เป้าให้นักรบโจมตี เปิดช่วยเหลือได้หากต้องการทบทวน','major','Enemy Swarm is a building; Help is an in-game control, not contacting support.'),
30:('ใช้แผนที่ย่อเลื่อนไปตะวันออกเพื่อหากองหิน เลือกธงสำรวจในธง วางบนหิน แล้วกดปุ่มเมาส์รองเพื่อออกจากโหมดวาง เลือกธงและกำหนดนักสำรวจ 1 ตัว ธงร้องขอยูนิต ไม่ได้ย้ายยูนิตทันที นักสำรวจอาจหยุดกินอาหาร','major','Leave placement means exit placement mode; units move independently, not the flag moving.'),
31:('การก่อสร้างใช้ไม้ที่คนงานขนมา เลือกโรงเตี๊ยมจากแผงเลือกอาคาร วางบนที่โล่งใกล้ข้าวสาลี และกำหนดคนงานก่อสร้าง 2 ตัว จำนวนเป้าหมายคือจำนวนที่ร้องขอ ไม่ใช่คนงานที่อยู่แล้ว คงคนงานส่งเสบียงให้โรงเตี๊ยมเดิมและรังไว้ วางตรงไหนที่ถูกต้องก็นับ','critical','Target is requested worker count, not number of requests; preserve own Swarm supply.'),
32:('งานก่อสร้างกับงานส่งเสบียงมีจำนวนคนงานเป้าหมายแยกกัน เลือกโรงเตี๊ยมที่เสร็จแล้วแล้วเพิ่มจำนวนคนงานใช้งาน คนงานส่งเสบียงจะเก็บข้าวสาลีมาที่นี่ ยูนิตที่หิวกินที่โรงเตี๊ยม หากไม่มีคนงานส่งเสบียง อาหารจะหมดในที่สุด เปิดทางไปยังแปลงข้าวสาลีไว้','major','Canonical buildings, units and actual supply role.'),
33:('รังใช้ข้าวสาลีสร้างยูนิต ตั้งสัดส่วนคนงานเป็น 1 นักสำรวจและนักรบเป็น 0 เพิ่มคนงานที่มอบหมายให้รังเป็น 2 ขึ้นไป คนงานส่งเสบียงมากขึ้นขนข้าวสาลีได้เร็วขึ้น แต่ดึงคนงานจากงานอื่น ส่งอาหารให้โรงเตี๊ยมทั้งสองต่อไป','critical','This is own Swarm, not enemy swarm. Preserve supply-vs-birth settings and labor tradeoff.'),
34:('เปิดธง เลือกธงรบ แล้ววางทับรังศัตรูทางตะวันออกของหิน ออกจากโหมดวางด้วยปุ่มเมาส์รองก่อนเลือกธง แล้วกำหนดนักรบสูงสุด 4 ตัว ใช้รัศมีเล็กเพื่อรวมกำลัง หากนักรบหมดให้สร้างเพิ่มที่รังของคุณ นักรบอาจหยุดกินอาหาร จึงต้องส่งเสบียงให้โรงเตี๊ยมต่อไป','critical','Produce replacements at own Swarm, not enemy; preserve placement exit and cap.'),
38:('ตรวจเสบียงของรังและตั้งให้สร้างเฉพาะคนงาน ส่งอาหารให้โรงเตี๊ยมต่อไประหว่างรอคนงานใหม่','major','Worker-only production is choosing unit type, not food produced by workers only.'),
43:('คุณกำหนดงานให้ยูนิตอัตโนมัติ เพิ่มอาหาร ขยายอาณานิคม และจัดการบุกแล้ว ฝึกการฝึกฝน อัปเกรด และป้องกันต่อในบทเรียนฝึกสอน หรือกลับเมนูหลักเพื่อเริ่มแมตช์','major','Game units, not automatic particles; canonical match.'),
45:('เริ่มบทแนะนำใหม่','major','Restart is action, not a noun introduction about restarting.'),
47:('ลากพื้นที่ว่างเพื่อเลื่อนมุมมองก่อนวางธง หากองหินทางตะวันออก เปิดธง เลือกธงสำรวจ วางบนหินแล้วยืนยัน เลือกธงแล้วตั้งจำนวนนักสำรวจ 1 ตัว ยูนิตเดินทางเองและอาจหยุดกินอาหาร','major','Touch interaction and autonomous unit behavior, not physical spherical objects.'),
48:('เลือกโรงเตี๊ยมจากสร้าง วางบนที่โล่งใกล้ข้าวสาลีแล้วยืนยัน เลือกพื้นที่ก่อสร้างและกำหนดคนงาน 2 ตัว จำนวนเป้าหมายคือจำนวนที่ร้องขอ ไม่ใช่จำนวนที่มีอยู่ ส่งเสบียงให้โรงเตี๊ยมเดิมและรังต่อไป วางตรงไหนที่ถูกต้องก็นับ','major','Translate referenced controls and preserve active supply, not keep buildings unchanged.'),
50:('เลือกรัง ตั้งสัดส่วนคนงานเป็น 1 นักสำรวจและนักรบเป็น 0 เพิ่มคนงานที่มอบหมายเป็น 2 ขึ้นไป คนงานส่งเสบียงนำข้าวสาลีมาสร้างยูนิตใหม่ แต่ต้องแบ่งจากงานอื่น ส่งเสบียงให้โรงเตี๊ยมทั้งสองต่อไป','major','Preserve supplier-vs-production distinction and labor competition.'),
51:('เปิดธง เลือกธงรบ วางทับรังศัตรูทางตะวันออกของหินแล้วยืนยัน เลือกธงและกำหนดนักรบสูงสุด 4 ตัว ใช้รัศมีเล็กเพื่อรวมกำลัง หากไม่มีนักรบให้สร้างที่รังของคุณ นักรบอาจหยุดกินอาหาร จึงต้องส่งเสบียงให้โรงเตี๊ยมต่อไป','critical','Create warriors at own birth building, not send them to an invented own enemy swarm.'),
53:('สำรวจที่นี่','critical','Scout is an action, not a boy scout present here.'),
56:('เลือกโรงเตี๊ยมใหม่ กำหนดคนงานส่งเสบียงอย่างน้อย 1 ตัว รอข้าวสาลี','major','Canonical building and supplier role.'),
57:('เลือกรัง กำหนดคนงานส่งเสบียง 2 ตัว สร้างเฉพาะคนงาน','major','Birth building and actual supplier role.'),
61:('โรงพยาบาลรักษายูนิตบาดเจ็บแล้ว ส่งเสบียงให้โรงเตี๊ยมต่อไป เพราะความหิวทำให้ยูนิตบาดเจ็บได้อีก','critical','Heal a game unit, not repair a flesh lump; canonical inn.'),
65:('เว้นทางให้ยูนิตเข้าออก โรงพยาบาลรักษาบาดเจ็บ โรงเตี๊ยมให้อาหาร ยูนิตตัวนี้กินอิ่มแล้ว','critical','Globules are game creatures, not blood cells.'),
68:('รอให้ผู้ป่วยฟื้นตัว','minor','Waiting for autonomous healing, not an instruction for bed rest.'),
71:('รอให้ผู้ป่วยฟื้นตัว','minor','Same marker as title.'),
73:('สร้างสนามวิ่ง แล้วดูคนงานเดิมฝึกจนเดินเร็วขึ้น','major','Walking skill training, not observing employee behavior at a car racetrack.'),
80:('เปิดทางเข้าสนามวิ่งแล้วรอให้คนงานฝึกจนเสร็จ ยูนิตที่มีคุณสมบัติเหมาะสมฝึกเอง เว้นคนงานบางส่วนจากงานส่งเสบียง และเก็บอาหารไว้ในโรงเตี๊ยมทั้งสองให้พอ','major','Autonomous units, not particles; food stocks, not hotel merchandise.'),
81:('ฝึกคนงานเดิม','minor','Canonical worker and distinction from newborn units.'),
83:('ยูนิตที่มีคุณสมบัติเหมาะสมฝึกเอง เว้นคนงานบางส่วนจากงานส่งเสบียง และเก็บอาหารในโรงเตี๊ยมทั้งสองให้พอ','major','Autonomous units, not particle groups or hotel staffing.'),
85:('ฝึกคนงานให้ว่ายน้ำ แล้วใช้สาหร่ายจากบ่อสร้างโรงเรียน','critical','School is generic skill building, not a swimming school.'),
86:('คนงานที่ว่ายน้ำได้ขนทรัพยากรในน้ำมาให้โรงเรียน การเข้าถึงน้ำเพิ่มงานที่อาณานิคมทำได้','major','Water resources are algae, not water delivered as a resource.'),
92:('รอให้คนงานเดิมฝึกว่ายน้ำจนเสร็จ ยูนิตเลือกฝึกเอง ส่งเสบียงต่อไปและเปิดทางให้คนงานว่างไปถึงสระว่ายน้ำ','major','Game units, not organizations choosing professional training.'),
95:('ยูนิตเลือกฝึกเอง ส่งเสบียงต่อไปและเปิดทางให้คนงานว่างไปถึงสระว่ายน้ำ','major','Pool is the training building, not a generic source of water.'),
104:('สร้างโรงเรียนในที่โล่งแล้วมอบหมายคนงานก่อสร้าง อาณานิคมมีคนงานว่ายน้ำได้เพื่อเก็บสาหร่ายแล้ว เปิดทางไปหาไม้และน้ำไว้ ไม้ผลให้ทรัพยากรสำหรับเกียรติยศ ส่วนอาหารยังมาจากข้าวสาลี','major','Swimmers harvest algae, not clear/destroy it; preserve resource role distinction.'),
107:('อาณานิคมมีคนงานว่ายน้ำได้เพื่อเก็บสาหร่ายแล้ว เปิดทางไปหาไม้และน้ำไว้ ไม้ผลให้ทรัพยากรสำหรับเกียรติยศ ส่วนอาหารยังมาจากข้าวสาลี','major','Harvest algae rather than remove it; terrain access rather than merely keep sources.'),
111:('รอให้คนงานเดิมฝึกที่โรงเรียนจนเสร็จ','major','Completion of existing unit training, not continued education degree.'),
121:('ให้คนงานเดิมฝึกเดินให้เร็วขึ้นที่สนามวิ่งที่อัปเกรดแล้ว การอัปเกรดที่เสร็จเพิ่มระดับการฝึกที่มี อาคารระดับสูงต้องใช้ทักษะก่อสร้างสูงขึ้น ระดับที่แสดงเริ่มจาก 1','major','Worker learns faster movement, not learns movement at a faster learning rate.'),
123:('ให้คนงานเดิมฝึกเดินให้เร็วขึ้นที่สนามวิ่งที่อัปเกรดแล้ว','major','Walking speed improves, not training learning speed.'),
126:('สร้างหอคอยที่มีเสบียงและกำแพงป้องกัน แล้วทดสอบรับการบุกเล็กๆ หนึ่งครั้ง','major','Supplied tower needs ammunition, and test is against an incoming attack rather than launching one.'),
127:('แนวป้องกันที่มีเสบียงหยุดการบุกทดสอบได้ หอคอยต้องมีหิน และกำแพงต้องเว้นช่องให้คนงานส่งเสบียงเข้าถึง','major','Suppliers are workers, not messengers.'),
128:('สร้างหอคอยในพื้นที่ที่ทำเครื่องหมายแล้วมอบหมายคนงานก่อสร้าง วางใกล้เหมืองหินและเว้นทางให้คนงานส่งเสบียง การบุกจะไม่เริ่มจนกว่าเป้าหมายเตรียมการจะครบ','critical','Provider reverses leave supplier access into prohibit access.'),
131:('วางใกล้เหมืองหินและเว้นทางให้คนงานส่งเสบียง การบุกจะไม่เริ่มจนกว่าเป้าหมายเตรียมการจะครบ','critical','Provider reverses access requirement and tells player to block suppliers.'),
138:('เลือกหอคอยและมอบหมายคนงานส่งเสบียง รอให้มีหินอย่างน้อย 2 หน่วย หอคอยที่เสร็จต้องกำหนดคนงานใช้งานเพื่อขนกระสุน แยกจากจำนวนคนงานก่อสร้าง','major','Preserve stone material, separate staffing targets and actual supplier role.'),
139:('ส่งกระสุน','major','Supply ammunition, not fire it as an additional instruction.'),
140:('เลือกหอคอยและมอบหมายคนงานส่งเสบียง รอให้มีหินอย่างน้อย 2 หน่วย','major','Actual supplier role and coherent count.'),
142:('ส่งกระสุน','major','Same supply marker, no invented firing action.'),
150:('คุณสำรวจ ป้องกันเขต และสั่งโต้กลับแล้ว จำนวนเป้าหมายของธงร้องขอยูนิต ส่วนรัศมีกำหนดพื้นที่ที่ยูนิตทำงาน','major','Targets are requested counts, not simply placing a flag.'),
156:('วาดเขตป้องกันในพื้นที่ที่ทำเครื่องหมาย แล้วรอนักรบ 2 ตัวเข้าถึง เปิดธง เลือกป้องกัน และวาดอย่างน้อย 4 ช่องในพื้นที่ เขตป้องกันดึงดูดนักรบว่าง เขตหวงห้ามกั้นการเดิน ส่วนเขตแผ้วถางร้องขอให้กำจัดทรัพยากร','critical','Clearing requests removal of resources, not consumption of resources.'),
157:('เตรียมเขตป้องกัน','minor','Canonical guard-zone term.'),
159:('เปิดธง เลือกป้องกัน และวาดอย่างน้อย 4 ช่องในพื้นที่ เขตป้องกันดึงดูดนักรบว่าง เขตหวงห้ามกั้นการเดิน ส่วนเขตแผ้วถางร้องขอให้กำจัดทรัพยากร','critical','Consistent actual control labels and removal vs consumption semantics.'),
}
substitutions=[('โรงเรียนสอนว่ายน้ำ','โรงเรียน'),('กลุ่มอนุภาคอัตโนมัติ','ยูนิตอัตโนมัติ'),('กลุ่มอนุภาค','ยูนิต'),('ลูกบอลพลังงาน','ยูนิต'),('วัตถุทรงกลม','ยูนิต'),('ก้อนกลมๆ เหล่านั้น','ยูนิต'),('ก้อนกลมๆ','ยูนิต'),('ก้อนกลม','ยูนิต'),('ก้อนเนื้อ','ยูนิต'),('เม็ดเลือด','ยูนิต'),('โรงแรม','โรงเตี๊ยม'),('สนามแข่งรถ','สนามวิ่ง'),('สนามแข่ง','สนามวิ่ง'),('พนักงาน','คนงาน'),('หน่วยงาน','ยูนิต'),('หน่วยรบ','ยูนิต'),('หน่วยต่างๆ','ยูนิต'),('หน่วยที่เพิ่งเกิด','ยูนิตที่เพิ่งเกิด'),('ผู้รับเหมาก่อสร้าง','คนงานก่อสร้าง'),('ผู้จัดหาวัสดุอุปกรณ์','คนงานส่งเสบียง'),('ซัพพลายเออร์','คนงานส่งเสบียง'),('ผู้จำหน่าย','คนงานส่งเสบียง'),('ผู้จัดหา','คนงานส่งเสบียง'),('ธงสงคราม','ธงรบ'),('กำลังทหาร','นักรบ'),('ทหารฝึกหัด','นักรบทดสอบ'),('นักรบฝึกหัด','นักรบทดสอบ'),('ช่างก่อสร้าง','คนงานก่อสร้าง'),('ช่างฝีมือ','คนงานก่อสร้าง'),('ผู้สร้างสนาม','คนงานก่อสร้าง'),('ผู้สร้าง','คนงานก่อสร้าง'),('การฝึกอบรม','การฝึก'),('ฝึกอบรม','ฝึก'),('การปรับปรุงอาคาร','การอัปเกรดอาคาร')]
rows=[]
for index,e in enumerate(entries):
 if index in fixes:
  proposed,severity,reason=fixes[index];rows.append((index,proposed,severity,reason));continue
 text=e['target'].replace('\u200b','')
 for before,after in substitutions:text=text.replace(before,after)
 text=re.sub(r'(นักสำรวจ|นักรบ|คนงาน(?:ก่อสร้าง|ส่งเสบียง)?) (\d+) (?:คน|นาย|ราย)',r'\1 \2 ตัว',text)
 text=text.replace('นักสำรวจหนึ่งคน','นักสำรวจหนึ่งตัว')
 if text!=e['target'].replace('\u200b',''):rows.append((index,text,'minor','Independently read source and target: normalize creature/building/training/supplier terms and classifiers; remove anatomical/employee/car-racing senses.'))
record('native-general-016',rows,[{'id':'native:[library GL only]','reason':'GL is the technical graphics-renderer acronym; Thai restriction term is translated.'}])
