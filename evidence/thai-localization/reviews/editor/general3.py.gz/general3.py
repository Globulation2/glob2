import json,re
from pathlib import Path
from record import record
entries=json.loads(Path('artifacts/thai-localization/round1/batches/native-general-003.json').read_text())['entries']
def normalized(index,changes=()):
 text=entries[index]['target'].replace('\u200b','')
 text=re.sub(r'\s*\\n\s*\\n\s*',lambda m:r'\n\n',text)
 for before,after in [('โรงแรม','โรงเตี๊ยม'),('ค่ายทหาร','ค่ายฝึก'),('อัพเกรด','อัปเกรด'),('ธงสงคราม','ธงรบ'),('หน่วยรบ','ยูนิต'),('หน่วยศัตรู','ยูนิตศัตรู')]+list(changes):text=text.replace(before,after)
 return text
rows=[
(0,'เลือกวางพื้นที่แผ้วถาง','major','Select the zone-placement tool, not a location-cleanup description.'),
(1,'เลือกวางพื้นที่ฟาร์ม','major','Translate retained English tool action.'),
(2,'เลือกวางเขตหวงห้าม','major','This selects placement of a forbidden zone, not a forbidden location.'),
(3,'เลือกวางเขตป้องกัน','minor','Include placement action.'),
(5,'Shift-%0','major','Physical Shift modifier, not a move/scroll action.'),
(8,'การแสดงผล','minor','Display category, not Show verb.'),
(10,'Space','minor','Physical spacebar key legend.'),
(14,'แผนที่ยูนิตอดอยาก','major','Overlay locates starving units, not a map themed around famine.'),
(19,'ยังมียูนิตทำงานอยู่ 1 ตัว','major','A working unit, not a still-operational machine.'),
(20,'ยังเหลือ 1 ตัว','minor','Concise remaining-unit status.'),
(23,'แบบไม่ต้องสั่งการ','minor','Paired stone-wall explanation describes passive defense, not generic element.'),
(24,'สิ่งก่อสร้างป้องกัน','minor','Paired rows describe passive defensive structure.'),
(28,'ของยูนิต','minor','Pair with first row, canonical unit term.'),
(29,'เพิ่มความเร็วว่ายน้ำ','major','Specifically raises swimming speed, not generic skill improvement.'),
(32,'เลือกแปรงพื้นที่ 1','minor','Concise consistent tool-selection label.'),
(36,'เลือกแปรงพื้นที่ 5','minor','A map editing brush, not a sweeping brush.'),
(42,'SysRq','major','Physical system-request key, not software system requirements.'),
(43,'Tab','minor','Physical key legend.'),
(47,'ค่ายฝึกสร้างเสร็จแล้ว','minor','Canonical training-building name.'),
(48,'ค่ายฝึกกำลังถูกโจมตี','minor','Canonical training-building name.'),
(50,'หอคอยป้องกันกำลังถูกโจมตี','minor','Consistent name with completed-building notification.'),
(52,'เกม','minor','Standard Thai spelling; no English plural suffix.'),
(57,'สนามวิ่งสร้างเสร็จแล้ว','major','Walking-training building, not car racing.'),
(58,'สนามวิ่งกำลังถูกโจมตี','major','Canonical walking-training building.'),
(59,'รีเพลย์','minor','Keep the borrowed word whole; candidate splits เพ|ลย์.'),
(60,'โรงเรียนสร้างเสร็จแล้ว','major','Finished means completed construction, not school vacation.'),
(62,'กำแพงส่วนหนึ่งสร้างเสร็จแล้ว','minor','A wall section, not a house interior wall.'),
(68,'เปิด/ปิดหมายเลขทีม','minor','Toggle visibility, not switch the team numbers themselves.'),
(69,'เปิด/ปิดข้อมูลประกอบ','minor','Toggle on-screen information overlay rather than drawing-data term.'),
(70,'เปิด/ปิดเส้นทางยูนิต','minor','Visibility toggle and canonical unit term.'),
(74,'พลังป้องกันรวม','major','Game defense power, not national defense power.'),
(76,'เกียรติยศรวมที่ทำได้','major','Total prestige attained, not highest prestige.'),
(78,'ไม่ได้ควบคุม','minor','Uncontrolled player/controller state, not physically uncontrollable.'),
(80,'ตัวแก้ไขยูนิต','major','Software editor, not a human editor.'),
(81,' ยูนิตที่ทำงาน','major','Units are game creatures, not organizations; preserve leading authored space.'),
(82,'ยูนิต','minor','Canonical term.'),
(87,'ค่าเริ่มต้นของการอัปเกรด','major','Settings defaults for upgrade behavior, not an imperative to upgrade defaults.'),
(88,'อัปเกรด','minor','Keep borrowed word whole.'),
(90,'เวอร์ชัน','minor','Use consistent contemporary Thai software spelling.'),
(91,'ดูประวัติ','major','An action to view history, not viewing history noun.'),
(94,'รอการกดปุ่ม…','major','Waiting for keyboard binding input, not an authentication code.'),
(103,'ชนะ: พันธมิตร %0 ของคุณมีเกียรติยศสูงสุด','minor','Use canonical prestige term, not generic fame.'),
(114,'ยูนิตของคุณเข้าร่วมทีมของ %0 แล้ว','minor','Canonical unit term.'),
(115,'ปรับได้เฉพาะเกมผู้เล่นคนเดียวและรีเพลย์ โหมดหลายผู้เล่นใช้ความเร็ว 1x','major','This restricts speed adjustment, not which modes can be played.'),
(121,'กลยุทธ์ AI และวิธีรับมือ','minor','Counterplay belongs to the player, not AI own counterplay.'),
(123,'พัฒนาอาณานิคมให้มีแนวป้องกัน แล้วโจมตีอาคารทหารและวิทยาศาสตร์','minor','Fortified does not require literal fortress structures.'),
(125,'ส่งอาหารและรักษาพยาบาลที่แนวหน้าเพื่อหนุนการบุกต่อเนื่อง','major','Forward means at the front, not supplied in advance temporally.'),
(127,'บุกเร็วโดยมีฟาร์ม การอัปเกรด การป้องกัน และนักสำรวจโจมตีคอยสนับสนุน','major','Rush is an attack, not merely starting the game quickly.'),
(129,'อาณานิคมที่อยู่นิ่งสำหรับการทดลอง','major','Idle colony still exists and has units, not abandoned/empty ruins.'),
(131,'ค่อยๆ พัฒนาอาณานิคมตามกำหนดเวลา แล้วโจมตีด้วยกำลังจำนวนมาก','major','AI policy is not a living organism.'),
(137,'ประสานการเติบโตของอาณานิคมกับการบุกของนักรบที่ฝึกแล้ว โดยเล็งอาคารรักษาและอาหารก่อน','major','Forces are trained, attacks themselves are not trained; explicit target buildings.'),
(155,'FFA','minor','Established free-for-all game mode abbreviation.'),
]
rows += [
(122,normalized(122,[('แลกแรงกดดันในช่วงต้นกับฐานที่พัฒนาแล้วและกองกำลังที่แข็งแกร่งกว่า','ยอมลดแรงกดดันช่วงต้นเพื่อพัฒนาฐานและกองกำลังให้แข็งแกร่งกว่า'),('แย่งชิงการขยายตัวตั้งแต่เนิ่นๆ','ขัดขวางการขยายฐานตั้งแต่ต้น')]),'major','Repair exact paragraph separators, canonical building names and idiomatic tradeoff/counterplay wording.'),
(124,r'กลยุทธ์หลัก: ปรับลำดับความสำคัญตามสถานการณ์เพื่อพัฒนาเศรษฐกิจ และใช้แรงงานส่วนเกินผลิตอาหาร เทคโนโลยี และแรงกดดันทางทหาร นโยบายปกติทำงานตามกฎ ส่วนการทดลองนโยบายที่เรียนรู้ต้องตั้งค่าแยก\n\nเศรษฐกิจและการพัฒนา: ผลิตคนงานตามความต้องการกำลังคนและสร้างยูนิตใหม่ต่อเนื่อง เมื่อขาดอาหารจะลดการขยายฐานและการพัฒนาเทคโนโลยี เพิ่มการฝึกว่ายน้ำเมื่อช่วยให้เข้าถึงพื้นที่ได้มากขึ้น\n\nการโจมตีและการป้องกัน: เตรียมบุกจากเทคโนโลยีศัตรูที่พบและกำลังที่มี การข้ามน้ำต้องใช้นักรบที่ว่ายน้ำได้ สร้างโรงเตี๊ยมและโรงพยาบาลแนวหน้าหนุนการรบระยะยาว และรวมพลก่อนรุกได้\n\nการบุกต่อเนื่องและเหตุฉุกเฉิน: บุกต่อแม้ถูกก่อกวนเล็กน้อย แทนที่จะเดินกลับฐานซ้ำๆ แต่การโจมตีรุนแรงอาจเรียกกำลังกลับป้องกัน เหตุฉุกเฉินช่วงต้นอาจทำให้สร้างเฉพาะนักรบและสร้างโรงพยาบาล ส่วนภาวะอดอยากอาจทำให้บุกครั้งเล็กแบบเสี่ยงตาย\n\nเปรียบเทียบกับ AI อื่น: เน้นการสนับสนุนแนวหน้ามากกว่า Warrush ส่วน Maxima วางแผนการเกิด การฝึก และการส่งกำลังให้ยั่งยืนตามกำลังศัตรูที่ประเมินไว้อย่างละเอียดกว่า\n\nจุดแข็งและจุดอ่อน: เชื่อมการบุกกับอาหาร การรักษา และเส้นทางที่เข้าถึงได้ อาคารแนวหน้าต้องได้รับเสบียงเสมอ และการสร้างยูนิตต่อเนื่องอาจกดดันอาหารที่จำกัด ลำดับความสำคัญยามฉุกเฉินทำให้ต้องเลือกระหว่างเติบโตกับอยู่รอด\n\nวิธีรับมือที่ควรลอง: แย่งชิงโรงเตี๊ยม โรงพยาบาล และแหล่งอาหารแนวหน้า รวมกำลังป้องกันรับการบุก การก่อกวนเล็กน้อยอาจไม่ทำให้ถอย\n\nการสำรวจ: ใช้อาคารและกองกำลังศัตรูที่ค้นพบแล้ว','major','Provider lost heading/body text and reordered paragraph markers. Restore every source section and distinguish forward support, reactive policy, sustained births and warrior-only production.'),
(126,normalized(126,[('เมื่อมีหน่วยทั้งหมดห้าหน่วย','เมื่อมียูนิตทั้งหมดห้าตัว'),('นักรบห้าคน','นักรบห้าตัว'),('ธงโจมตี','ธงรบ'),('ธงเคลียร์','ธงแผ้วถาง'),('เปิดเส้นทางที่ถูกปิดกั้นทรัพยากร','เปิดเส้นทางที่ทรัพยากรกีดขวาง'),('พนักงานด้านอาหาร','คนงานส่งอาหาร'),('กลุ่มของหน่วยและอาคาร','กลุ่มยูนิตและอาคาร'),('กลุ่มหน่วยของศัตรู','กลุ่มยูนิตศัตรู')]),'major','Repair paragraph delimiters, canonical buildings/flags/units and resource-blocked-route grammar while preserving five-unit/five-warrior thresholds.'),
(128,normalized(128),'major','Restore exact literal paragraph separator sequences so profile headings are parsed correctly.'),
(130,normalized(130,[('ปลูกพืชและฝึกฝนเพื่อเตรียมพร้อมสำหรับการโจมตี','ระหว่างบุกยังขยายแหล่งอาหารและฝึกฝนต่อไป')]),'major','Canonical buildings/flags, exact paragraph separators, and development behind ongoing attacks rather than only preparing attacks.'),
(132,r'กลยุทธ์หลัก: สร้างคนงานและนักสำรวจ ขยายเศรษฐกิจ และใช้อาหารกับผลไม้ดึงยูนิตศัตรูมาเข้าทีม ไม่มีการบุกด้วยนักรบแบบทั่วไป\n\nเศรษฐกิจและการพัฒนา: สร้างโรงเตี๊ยมและรังใกล้แหล่งอาหาร เพิ่มการศึกษาและการฝึกเคลื่อนที่ แล้วอัปเกรดอาคาร ติดตามอาหารสำรองและคงอาคารกับธงสำรวจไว้ แม้อาหารลดลงหรือเป้าหมายหายไป\n\nฟาร์มและการดึงยูนิตเข้าทีม: ปกป้องแหล่งอาหารและไม้ที่งอกใหม่ได้ใกล้น้ำ ส่งนักสำรวจไปยังแหล่งผลไม้และอาณานิคมศัตรู และประกาศว่ามีอาหารให้ศัตรูรู้ขณะหาแหล่งผลไม้ อาหารและผลไม้ที่ดีกว่าช่วยดึงยูนิตมาเข้าทีม\n\nเปรียบเทียบกับ AI อื่น: เน้นเศรษฐกิจเฉพาะทางที่สุด Cabino และ Maxima ก็หาผลไม้ แต่สร้างกองทัพควบคู่กัน\n\nจุดแข็งและจุดอ่อน: เติบโตได้ขณะที่คู่ต่อสู้ทุ่มกำลังทหารจนหมดแรง และแข่งขันด้วยการดึงยูนิตเข้าทีมอีกทางหนึ่ง แต่ไม่มีนักรบรับการบุกต่อเนื่อง อาหาร ผลไม้ ภูมิประเทศ และกฎชัยชนะจึงมีผลมาก\n\nวิธีรับมือที่ควรลอง: กดดันส่วนขยายที่ป้องกันไม่ทั่วถึง ส่งอาหารและผลไม้ให้โรงเตี๊ยมของคุณเสมอเพื่อรักษายูนิตไว้ หลีกเลี่ยงการรบที่ไม่จำเป็นจนหมดแรงขณะที่อีกฝ่ายเติบโต','major','Conversion is changing team, not religion. Restore corrupt headings/separators and canonical inn/swarm/unit terms.'),
(134,r'กลยุทธ์หลัก: บุกก่อนคู่ต่อสู้พัฒนาเศรษฐกิจหรือเทคโนโลยีได้เต็มที่ หวังตัดสินเกมด้วยการรบก่อนต้องสร้างระบบสนับสนุนขนาดใหญ่\n\nเศรษฐกิจและการพัฒนา: เมื่อมียูนิตเก็บเกี่ยวได้หกตัว จะตั้งการผลิตเป็นคนงานสี่ นักสำรวจหนึ่ง และนักรบสาม เพิ่มค่ายฝึกเมื่อการฝึกเต็มความจุ แต่จำกัดโรงเตี๊ยมใหม่ งานก่อสร้างที่เหลือมักเป็นโรงพยาบาลและอาคารฝึกเคลื่อนที่\n\nการโจมตีและการป้องกัน: วางเขตป้องกันบนอาคารศัตรูที่ค้นพบเพื่อให้นักรบกดดันต่อเนื่อง ไม่รอรวมพลเป็นระลอกอย่างรอบคอบ แผ้วถางทรัพยากรที่ขวางทางและปกป้องแหล่งทรัพยากรที่งอกใหม่ได้บางส่วน\n\nนโยบายผลไม้: ห้ามเก็บผลไม้เพื่อเลี่ยงผลลดเกราะที่เกี่ยวกับผลไม้ และไม่ใช้กลยุทธ์ดึงยูนิตเข้าทีมแบบ Econo\n\nเปรียบเทียบกับ AI อื่น: เน้นกดดันช่วงต้นมากกว่า Numbi หรือ Castor ส่วน Nicowar ก็เปิดเกมดุดันแต่ตามด้วยการอัปเกรดและยุทธวิธีที่หลากหลายกว่า\n\nจุดแข็งและจุดอ่อน: ลงโทษผู้ที่เริ่มช้าและบังคับให้ลงทุนป้องกันเร็ว แต่การอัปเกรดที่จำกัดและระบบอาหารที่ประหยัดทำให้เสียหายมากเมื่อบุกไม่คืบ ภูมิประเทศและทางเดินไกลอาจลบข้อได้เปรียบช่วงต้น\n\nวิธีรับมือที่ควรลอง: ป้องกันโรงเตี๊ยมและรังตั้งแต่ต้น สร้างคนงานและกำลังป้องกันทดแทน พัฒนาการฝึก แล้วโต้กลับเมื่อการบุกเริ่มอ่อนแรง\n\nการสำรวจ: ธงสำรวจช่วงต้นใช้ตำแหน่งเริ่มต้นศัตรูโดยตรง ส่วนการวางเขตโจมตีภายหลังต้องเห็นพื้นที่ก่อน','major','Protect own inns/swarms, not enemy swarm; replace lost units, not switch workers. Preserve ratios, scouting disclosure, fruit penalty and paragraph contracts.'),
(136,r'กลยุทธ์หลัก: แบ่งการผลิตยูนิตให้การก่อสร้าง อัปเกรด ป้องกัน โจมตี และสำรวจ ตัวจัดการแต่ละส่วนร้องขอและจองยูนิตแยกกัน เพื่อพัฒนาเศรษฐกิจกับกองทัพไปพร้อมกัน\n\nเศรษฐกิจและการพัฒนา: สร้างและอัปเกรดฐานขนาดใหญ่ จัดคนงานให้โรงเตี๊ยมและหอคอย แผ้วถางรอบอาคารและปกป้องทรัพยากรที่งอกใหม่ได้ สำรวจผลไม้และประกาศว่ามีอาหารเพื่อดึงยูนิตเข้าทีม\n\nการโจมตีและการป้องกัน: เลือกศัตรูแล้วเล็งโรงพยาบาลก่อน ตามด้วยโรงเตี๊ยมและค่ายฝึก บุกพร้อมกันได้สูงสุดสี่จุด โดยทั่วไปส่งนักรบแปดถึงยี่สิบตัวต่อเป้าหมายตามกำลังที่มีและศัตรูใกล้เคียง ใช้ธงป้องกันแยกกันรอบอาคารที่ถูกคุกคาม\n\nการฝึก: ต้องมีนักรบที่เหมาะสมเพียงพอและค่ายฝึกที่สร้างเสร็จก่อนบุก แต่ไม่รอเทคโนโลยีสูงสุด การอัปเกรดและฝึกต่อเนื่องทำให้การบุกภายหลังแข็งแกร่งขึ้น\n\nเปรียบเทียบกับ AI อื่น: มุ่งทำลายอาคารสนับสนุนชัดเจนกว่า Nicowar กระจายการบุกมากกว่า Maxima ที่รวมพลเป็นระลอก โดยจองยูนิตเพื่อจัดการความต้องการหลายด้าน\n\nจุดแข็งและจุดอ่อน: ผสานการเติบโต การฝึก การป้องกัน และการบุกหลายจุด การทำลายอาหารกับการรักษาทำให้ทั้งอาณานิคมอ่อนแอได้ แต่การสุ่มคู่ต่อสู้และลำดับเป้าหมายตายตัวอาจพลาดโอกาส และการบุกหลายจุดอาจแบ่งกำลังมากเกินไป\n\nวิธีรับมือที่ควรลอง: ป้องกันโรงพยาบาลและโรงเตี๊ยม ขัดขวางส่วนขยายที่ป้องกันไม่ทั่วถึงและรวมกำลังรับการบุกแต่ละจุด ทำลายอาหารหรือการฝึกก่อนอีกฝ่ายจะตั้งแนวรบหลายด้านได้\n\nการสำรวจ: ตัวเลือกเป้าหมายโจมตีอ่านรายชื่ออาคารศัตรูโดยไม่ตรวจการมองเห็นอย่างชัดเจน และการเปรียบเทียบเศรษฐกิจบางอย่างใช้สถิติศัตรูโดยตรง','major','Restore lost heading/body text and paragraph delimiters; simultaneous attacks are fronts, not total attack count; unit managers are software, not human executives.'),
]
record('native-general-003',rows,[{'id':'native:[FFA]','reason':'FFA is the established free-for-all mode acronym; retain recognizable mode label.'}])
