import json
from pathlib import Path
from record import record
entries=json.loads(Path('artifacts/thai-localization/round1/batches/native-settings-001.json').read_text())['entries']
rows=[
(17,'Enter: ส่งข้อความแชท','major','Physical key name, not the action enter/input.'),
(19,'จำนวนยูนิตที่มอบหมายเริ่มต้น','minor','Canonical units and desired assignment count.'),
(20,'สร้างแผนที่ไม่สำเร็จ ปรับการตั้งค่าหรือกดเริ่มเพื่อลองใหม่','minor','Map generation, not generic data generation.'),
(21,'ไม่มีตัวอย่าง ปรับการตั้งค่าหรือกดเริ่มเพื่อลองใหม่','major','Preserve Start as the retry mechanism.'),
(22,'สร้างแผนที่ไม่สำเร็จ ปรับการตั้งค่าหรือลองใหม่','minor','Map-generation context.'),
(23,'การตั้งค่าแผนที่เปลี่ยนแล้ว สร้างตัวอย่างใหม่หรือกดเริ่ม','major','Start the game, not restart settings or match.'),
(24,'เพิ่มปุ่มในลำดับ','minor','Physical keyboard key.'),
(26,'ปรับจำนวนยูนิตที่มอบหมายด้วยล้อเมาส์ เมื่อปิดตัวเลือกนี้ให้กด Ctrl ค้างไว้ ส่วน Shift ใช้ปรับรัศมีธง และตัวเลือกนี้ยังควบคุมล้อเมาส์ในเมนูอื่นด้วย','critical','When off means disabled setting, not powering device off; preserve modifier behaviors.'),
(29,'กำหนดปุ่มขั้นสูง','critical','Key binding, not bookbinding.'),
(32,'กำหนด Esc','critical','Bind physical Escape key, not bind a fleeing action.'),
(38,'เปลี่ยนตัวเรนเดอร์แล้วต้องปิดและเปิดเกมใหม่','major','Restart application, not reboot the computer.'),
(47,'จอแสดงผลปัจจุบัน','minor','Current monitor/display, not generic rendered content.'),
(49,'การแสดงผล','minor','Settings category, not Show imperative.'),
(62,'ขนาดส่วนติดต่อ','minor','Clear interface-scale setting.'),
(63,'ใช้ต่อ','minor','Confirm keeping new display mode.'),
(66,'ปุ่ม','critical','Keyboard key, not the adjective important.'),
(67,'ปุ่มลัดแป้นพิมพ์','minor','Conventional shortcuts wording.'),
(80,'เปิด','critical','Toggle On, not spatial on top.'),
(84,'กดปุ่ม Esc ยกเลิกการรับปุ่ม หากต้องการใช้ Esc เป็นปุ่มลัด ให้เลือกกำหนด Esc','critical','Key capture, not screenshot capture; reference translated Bind Escape label.'),
(86,'ลดรายละเอียด','minor','Graphics detail option.'),
(89,'จำการมอบหมายข้ามเกม','critical','Persist unit assignment defaults, not remind player about missions.'),
(90,'ลบปุ่ม','critical','Remove a keyboard binding, not take a lock key out.'),
(92,'ตัวเรนเดอร์','minor','Renderer noun.'),
(93,'แทนที่การกำหนดปุ่มที่ซ้ำกัน','major','Keyboard conflicts, not data-binding conflicts.'),
(95,'ความละเอียด','critical','Pixel resolution, not determination or a formal resolution.'),
(98,'คืนค่า','minor','Restore previous display mode.'),
(99,'คืนค่าในอีก','minor','Countdown until previous mode is restored.'),
(101,'บันทึกแล้ว — ต้องเปิดเกมใหม่','minor','Explicit game application restart.'),
(102,'กำลังบันทึก…','critical','Persist settings, not economize money.'),
(104,'ตั้งจำนวนยูนิตเริ่มต้นที่มอบหมายตามชนิดและระดับอาคาร','minor','Canonical unit term.'),
(107,'ปรับได้เฉพาะเกมผู้เล่นคนเดียวและรีเพลย์ โหมดหลายผู้เล่นใช้ความเร็ว 1x','major','Restriction concerns speed adjustment, not available game modes.'),
(109,'จำนวนยูนิตและรัศมีเริ่มต้นของธงที่วางใหม่','minor','Canonical units.'),
(111,'ทำงานเมื่อ','major','Press/release trigger configuration, not an external stimulus.'),
(112,'ยังไม่กำหนด','critical','Unbound key action, not something detached/fallen.'),
(113,'จำนวนยูนิตที่มอบหมายให้พื้นที่ก่อสร้างใหม่','minor','Canonical units and assignment meaning.'),
(114,'จำนวนยูนิตที่มอบหมายให้อาคารที่เสร็จแล้ว','minor','Assigned workers, not units physically inside the building.'),
(115,'จำนวนยูนิตที่มอบหมายระหว่างอัปเกรดอาคาร','minor','Canonical units and upgrade.'),
(116,'ยูนิต','minor','Canonical units.'),
(119,'ระดับเสียงพูด','major','Voice volume distinct from music and overall volume.'),
(121,'ขนาดที่ใช้ได้เฉพาะโหมดหน้าต่างจะเปลี่ยนเกมเป็นโหมดหน้าต่างด้วย','major','Window-only sizes, not any selectable size.'),
(129,'แสดงภาพรวมทอรัสอัตโนมัติขณะเลื่อนแผนที่ (OpenGL)','minor','Consistent view name.'),
(133,'ซีดนี้สร้างทางลัดป่าแห้งที่ใช้งานได้ในทะเลสาบพอร์เทจไม่ได้','major','Random seed, not plant seed; translated landscape name.'),
(134,'ซีดนี้สร้างทางลัดว่ายน้ำที่ใช้งานได้ในทะเลสาบพอร์เทจไม่ได้','major','Random seed, not plant seed.'),
(142,'แบบกว้างใช้แผงด้านข้างเมื่อมีที่พอ แบบกะทัดรัดใช้แถบเครื่องมือและแผงเลื่อน','minor','UI drawers, not physical furniture.'),
(146,'สีกล่องโต้ตอบและส่วนติดต่อแบบสัมผัสระหว่างเล่นเกมและในตัวแก้ไข','major','UI dialogs, not character conversations.'),
(147,'สว่าง','minor','Theme adjective.'),
(151,'เนินทราย','major','Terrain-inspired theme, not Dune proper name.'),
(152,'คอนทราสต์สูง','minor','Contrast, distinct from image resolution/sharpness.'),
]
seen={row[0] for row in rows}
for index in [9,10,12,15,16,25,53,91,96,100,110]:
 if index not in seen:
  text=entries[index]['target'].replace('\u200b','').replace('ทางลัด','ปุ่มลัด')
  rows.append((index,text,'minor','Conventional keyboard shortcut terminology; these are key bindings, not map shortcuts.'))
record('native-settings-001',rows)
