from record import record
record('native-tutorial-001',[
(0,'ยินดีต้อนรับสู่บทฝึกสอนเบื้องต้นของ Globulation 2! คุณจะได้เรียนตั้งแต่สร้างโรงเตี๊ยม สำรวจพื้นที่ จนถึงทำลายศัตรู พร้อมความรู้ที่มีประโยชน์อีกมากมาย','major','Canonical Inn and natural introduction wording.'),
(1,'เมื่อเข้าใจพื้นฐานแล้ว มาทำความคุ้นเคยกับอาคารอื่น เช่น สนามวิ่ง สระว่ายน้ำ และโรงเรียน','major','Racetrack is walking-training building, not car-racing track.'),
(2,'คุณทำได้ดีที่มาถึงจุดนี้ ต่อไปคือนักรบ ค่ายฝึก และการอัปเกรด','minor','Canonical training-building name.'),
(3,'ใกล้จบบทฝึกแล้ว เหลือธงและการโจมตี จากนั้นคุณจะพร้อมลองเกมกำหนดเอง และเล่นออนไลน์กับผู้เล่นฝีมือเยี่ยมของ Globulation 2','major','Almost finished with tutorial, not almost ended the game.'),
(4,'บทฝึกสอน','minor','Consistent tutorial terminology.'),
(5,'บทเรียนฝึกสอน','minor','Match references in introduction and menu instructions.'),
(7,'เริ่มบทเรียนนี้ใหม่จากอาณานิคมที่เตรียมไว้หรือไม่? ความคืบหน้าที่ยังไม่บันทึกจะหายไป','critical','Prepared colony, not a collection of prepared lessons.'),
(9,'ฝึกส่งเสบียงอาหาร','major','Hands-on practice, not formal food-supply guidelines.'),
(10,'ฝึกเพิ่มเสบียงอาหาร: สร้างโรงเตี๊ยมเพิ่ม มอบหมายคนงานส่งเสบียง แล้วดูข้าวสาลีมาถึง','major','Canonical Inn and worker-supplier role, not commercial vendors.'),
(11,'คุณสร้างโรงเตี๊ยมและส่งข้าวสาลีให้แล้ว ลองบทเรียนอื่นหรือกลับเมนูหลัก','major','Canonical feeding-building name.'),
(12,'โหลดบทเรียนฝึกสอนไม่ได้','minor','Consistent tutorial wording.'),
])
