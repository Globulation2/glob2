import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from save_adversarial import save
root=Path('artifacts/thai-localization/round2/batches')
def t(name,i):return json.loads((root/(name+'.json')).read_text())['entries'][i-1]['target']
n='native-settings-002';f={
19:('รายการ\u200bและ\u200bแผง\u200bต่างๆ ยืด\u200bเลย\u200bขอบ\u200bไป\u200bมาก\u200bน้อย\u200bแค่\u200bไหน แล้ว\u200bเด้ง\u200bกลับ','Remove repeated how-much phrase; bounce controls overscroll stretch.'),
55:(t(n,55).replace('ข้อ\u200bความใน','ข้อความ\u200bใน'),'Keep text noun and following preposition at correct word boundaries.'),
84:('เซิร์ฟเวอร์\u200bอย่าง\u200bเป็นทางการ\u200bของ Globulation 2 · คิว\u200bจัดอันดับ ตาราง\u200bอันดับ และ\u200bแคตตาล็อก\u200bแผนที่','Ranked queues are queues, not merely a player ranking system.'),
101:('แสดง\u200bสกิน\u200bของ\u200bอาณานิคม','Keep borrowed word skin intact.'),
106:('อนุญาต\u200bการ\u200bติดตาม\u200bคำสั่ง\u200bใหม่','Keep follow-up verb intact, not sever it before following command.'),
107:(t(n,107).replace('ติด\u200bตามคำสั่ง','ติดตาม\u200bคำสั่ง'),'Correct follow-up word boundary.'),
}
for i in range(1,161):
 s=t(n,i);new=s.replace('ผู้\u200bเล่น','ผู้เล่น').replace('ผู้\u200bเยี่ยมชม','ผู้เยี่ยมชม').replace('ตัว\u200bเรนเดอร์','ตัวเรนเดอร์')
 if new!=s and i not in f:f[i]=(new,'Keep complete player/guest/renderer term at a word boundary.','minor')
save(n,f,{103:'Hive Mind is the named commander feature, preserved as product name.'})
n='native-settings-003';f={
6:(t(n,6).replace('อีก\u200bครั้งก่อน','อีกครั้ง\u200bก่อน'),'Break before before, not within again.'),
30:('ทดสอบ\u200bครอสเฟด','Keep crossfade loanword intact.','minor'),
37:(t(n,37).replace('เม\u200bตา','เมตา'),'Keep metadata element intact.','minor'),
43:('นำเข้า\u200bตัวสร้าง\u200bแผนที่','Import is one word, not นำ then เข้าตัว.'),
44:('ยัง\u200bไม่\u200bได้\u200bติดตั้ง\u200bตัวสร้าง\u200bแผนที่\u200bแบบ\u200bกำหนด\u200bเอง','Match generator terminology and no installed yet status.'),
50:(t(n,50).replace('แผนที่แล้ว','แผนที่\u200bแล้ว'),'Separate completion adverb from map noun.','minor'),
51:('บันทึก\u200bข้อมูล\u200bไม่\u200bได้ ยัง\u200bเก็บ\u200bคลัง\u200bเดิม\u200bไว้','Correct awkward คงคลัง boundary and retention wording.'),
60:(t(n,60).replace('รอง\u200bรับใช้','รองรับ\u200bใช้'),'Unsupported work uses CPU; break between support and use, not create รับใช้.'),
63:('แพร่\u200bค่า\u200bแบบ\u200bบักเก็ต','Keep bucket loanword intact.','minor'),
84:('เรียกดู\u200bตัวสร้าง\u200bแผนที่\u200bที่\u200bแชร์','Separate browse and generator words.'),
94:('เปิด\u200bใช้\u200bล้อเลื่อน\u200bใน\u200bเมนู','Avoid splitting wheel and unnatural วงล้อเลื่อน.'),
}
for i in range(1,100):
 s=t(n,i);new=s.replace('เกรเดียนต์','กราเดียนต์').replace('ทอ\u200bรัส','ทอรัส').replace('ตัว\u200bเรนเดอร์','ตัวเรนเดอร์')
 if new!=s and i not in f:f[i]=(new,'Use consistent gradient terminology and intact torus/renderer terms.','minor')
save(n,f)
n='native-tutorial-001';f={3:(t(n,3).replace('ค่าย\u200bฝึก','ค่ายฝึก'),'Keep canonical training camp building name intact.','minor'),4:(t(n,4).replace('ผู้\u200bเล่น','ผู้เล่น'),'Keep player noun intact.','minor'),9:('บทเรียน\u200bจบ\u200bแล้ว','Preserve lesson noun; break before completed verb.','minor')}
save(n,f)
