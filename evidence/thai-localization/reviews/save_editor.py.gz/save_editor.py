import json,hashlib
from pathlib import Path
ROOT=Path("artifacts/thai-localization")
def save(number, fixes, accepted):
 b=json.loads((ROOT/f"round1/batches/online-online-{number:03d}.json").read_text()); entries=b["entries"]; values={e["id"]:e["target"] for e in entries}
 findings=[]
 for index,fix in fixes.items():
  e=entries[index-1]; proposed,reason,*severity=fix
  findings.append({"id":e["id"],"severity":severity[0] if severity else "major","proposed":proposed,"reason":reason})
 record={"editor":"thai_rendering","source_sha256":b["source_sha256"],"target_sha256":hashlib.sha256(json.dumps(values,sort_keys=True,ensure_ascii=False).encode()).hexdigest(),"edited_keys":[e["id"] for e in entries],"findings":findings,"accepted_english":[{"id":entries[i-1]["id"],"reason":reason} for i,reason in accepted.items()],"method":"Every entry read against immutable English/Thai snapshot; retained entries included. No prior reviewer findings read. Standard Thai language brief and selected FR/JA/VI contextual cross-checks used. Agent-reviewed; not native-human-certified."}
 (ROOT/f"reviews/editor/{b['id']}.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
 print(b["id"],len(entries),"entries",len(findings),"findings")
