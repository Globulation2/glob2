import json,hashlib,pathlib
root=pathlib.Path('artifacts/thai-localization')
def save(n,changes):
 d=json.load(open(root/f'round2/batches/online-online-{n:03}.json'))
 findings=[]
 for idx,severity,proposed,reason in changes:
  findings.append(dict(id=d['entries'][idx]['id'],severity=severity,proposed=proposed,reason=reason))
 out=dict(adversarial_reviewer='online_adversarial',source_sha256=d['source_sha256'],target_sha256=hashlib.sha256(json.dumps({e['id']:e['target'] for e in d['entries']},sort_keys=True,ensure_ascii=False).encode()).hexdigest(),adversarial_reviewed_keys=[e['id'] for e in d['entries']],findings=findings,accepted_english=[dict(id=e['id'],reason='Preserved technical notation, placeholder, proper name, licence identifier or nonlinguistic separator.') for e in d['entries'] if e['source']==e['target']])
 (root/f'reviews/adversarial/{d["id"]}.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
