import json,importlib.util,hashlib
from pathlib import Path
spec=importlib.util.spec_from_file_location('p','tools/localization/translation_program.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
root=Path('artifacts/thai-localization');native,_=p.CHECKER.read_table(root/'drafts/th/texts.th.txt');ns=json.loads((root/'source/native.json').read_text());online=json.loads((root/'drafts/th/th.json').read_text());os=json.loads((root/'source/online.json').read_text())
changes={
'native:[%0 level %1]':('%0 ระดับ %1','major','%0 names the object and %1 its level; Thai must not label %0 itself as the level. FR/JA/VI agree on object followed by level.'),
'native:[%0 units can\'t access building]':('ยูนิต %0 ตัวเข้าอาคารไม่ได้','minor','Use the same explicit unit noun and count order as the other assignment explanations.'),
'native:[%0 units can\'t access flag]':('ยูนิต %0 ตัวเข้าถึงธงไม่ได้','minor','%0 is a count of units, not a unit identifier; normalize the count construction.'),
'native:[%0 units can\'t access fruit]':('ยูนิต %0 ตัวเข้าถึงผลไม้ไม่ได้','minor','Use consistent concise unit-count phrasing.'),
'native:[%0 units can\'t access resource]':('ยูนิต %0 ตัวเข้าถึงวัสดุที่ต้องใช้ไม่ได้','major','หน่วยงาน means an agency/organization and แห่ง is its classifier. The HUD describes game units blocked from required resources.'),
'native:[%0 units not available]':('ยูนิต %0 ตัวไม่พร้อมใช้งาน','major','สินค้า means goods. This is a shortage/unavailability of assignable game units, as confirmed by HUD code and JA.'),
'native:[%0 units too far from building]':('ยูนิต %0 ตัวอยู่ไกลจากอาคารเกินไป','major','%0 counts units; it is not a distance measurement. Make the counted subject explicit.'),
'native:[%0 units too far from flag]':('ยูนิต %0 ตัวอยู่ไกลจากธงเกินไป','major','The draft loses too far and reads as a distance. Restore excessive distance and explicit unit count.'),
'native:[%0 units too far from fruit]':('ยูนิต %0 ตัวอยู่ไกลจากผลไม้เกินไป','major','%0 counts affected units, not units of distance.'),
'native:[%0 units too far from resource]':('ยูนิต %0 ตัวอยู่ไกลจากวัสดุที่ต้องใช้เกินไป','major','Make affected units the subject and align needed-material terminology.'),
'native:[%0 units too low level]':('ยูนิต %0 ตัวมีระดับต่ำเกินไป','major','The missing ระดับ drops the reason that units lack required training/level.'),
'native:[%0% Uploaded]':('อัปโหลดแล้ว %0%','minor','Keep the percentage sign attached to its value and use completed-progress phrasing.'),
'native:[%0\'s team unit got converted to your team]':('ยูนิตจากทีมของ %0 เข้าร่วมทีมของคุณแล้ว','minor','Use consistent game-unit terminology rather than human team member; preserve completed conversion.'),
'native:[clearingflag]':('ธงแผ้วถาง','major','เคลียร์ is vague and can mean dismiss/reset; the flag assigns resource clearing. Apply the brief.'),
'native:[music set]':('ชุดเพลง','minor','Align with the existing music-set load error; a set contains songs rather than abstract music.'),
'native:[random music set]':('สุ่มทุกแมตช์','minor','Shorter idiomatic option label while retaining each-match timing.'),
'native:[inn explanation]':('ให้อาหารยูนิตของคุณ','minor','Concise description of feeding, not physically spoon-feeding or accommodation.'),
'native:[inn]':('โรงเตี๊ยม','major','Apply agreed building name. โรงแรม means hotel and obscures this game building.'),
'native:[market explanation 2]':('กับผู้อื่น','major','Others refers to other players/teams, not other things; pair this row with the first row.'),
'native:[market explanation]':('ใช้แลกเปลี่ยนผลไม้','major','Translate the two-row explanation as a coherent whole: ใช้แลกเปลี่ยนผลไม้ / กับผู้อื่น.'),
'native:[swarm explanation]':('สร้างยูนิตใหม่','minor','Use consistent unit terminology.'),
'native:[swarm]':('รัง','major','This is a birth-producing building, supported by FR Ruche, JA 巣, VI Tổ; ฝูง denotes a moving group.'),
'native:[warflag]':('ธงรบ','minor','Apply concise agreed terminology.'),
'native:[Pass width]':('ความกว้างช่องเขา','major','Terrain pass is a mountain route, not a generic passage.'),
'native:[Sandbars]':('สันดอนทราย','major','Use the sediment-bar terrain term, distinct from dunes or generic sand ridges.'),
'native:[Fjord bank deposits]':('แหล่งทรัพยากรริมฝั่งฟยอร์ด','major','เงินฝากธนาคาร is a financial bank deposit. These are resource deposits on fjord banks.'),
'native:[Stream reach]':('ความยาวลำธาร','major','The generator controls stream length, not access to a stream.'),
'native:[stop recording]':('หยุดบันทึก','minor','Match the parallel เริ่มบันทึก action with concise verb form.'),
'native:[finalizing recording]':('กำลังจัดทำไฟล์บันทึกให้เสร็จ…','minor','Avoid the calque ดำเนินการบันทึกขั้นสุดท้าย; the application is completing the recorded file.'),
'native:[settings Edge scrolling]':('เลื่อนแผนที่ที่ขอบจอ','major','การเลื่อนขอบ reads as moving an edge. The setting scrolls the map when the pointer reaches an edge.'),
'native:[settings Edge scrolling in fullscreen]':('เลื่อนที่ขอบจอเมื่อเต็มหน้าจอ','minor','Make the trigger and mode clear in a compact setting label.'),
'native:[settings Edge scrolling in windowed mode]':('เลื่อนที่ขอบจอในโหมดหน้าต่าง','minor','Use the same trigger terminology as the full-screen setting.'),
'native:[settings Move the game and editor maps when the mouse reaches the window edge.]':('เลื่อนแผนที่ในเกมและตัวแก้ไขเมื่อเมาส์ถึงขอบหน้าต่าง','major','Editor maps means maps in the map editor; แผนที่แก้ไข is not an application context.'),
'native:[hub finish in browser, game continues]':('ลงชื่อเข้าใช้ให้เสร็จในเบราว์เซอร์ เกมจะดำเนินการต่อโดยอัตโนมัติเมื่อเสร็จแล้ว','minor','Apply sign-in terminology and avoid suggesting that a paused match plays itself.'),
'native:[hub browser did not open]':('เบราว์เซอร์ไม่เปิดขึ้น โปรดเปิดหน้าลงชื่อเข้าใช้เพื่อดำเนินการต่อ','minor','Consistent sign-in terminology; this reports that browser launch did not occur, not necessarily that it is impossible.'),
'native:[hub compare code %0]':('หากหน้าเว็บขอให้ตรวจสอบ ให้ดูว่าแสดงรหัส %0 ตรงกัน','major','The trailing ไม่ in the draft introduces negation/incompleteness. This is a security code comparison instruction.'),
'native:[hub code copied]':('คัดลอกรหัสแล้ว','minor','This is an authentication code, not program source code.'),
'native:[settings Finish in your browser. The game continues by itself.]':('ดำเนินการให้เสร็จในเบราว์เซอร์ เกมจะดำเนินการต่อโดยอัตโนมัติ','major','จบเกม says finish/end the game. The source asks the player to finish the browser authentication step.'),
'online:Licence':('สัญญาอนุญาต','major','Use the agreed content/software licence term, distinct from an administrative permit.'),
'online:License':('สัญญาอนุญาต','major','Keep the alternate English spelling aligned with Licence.'),
'online:Rooms':('ห้อง','major','ห้องพัก implies lodging; these are multiplayer game rooms. Thai does not require a plural suffix.'),
'online:Sign in':('ลงชื่อเข้าใช้','minor','Apply language-brief terminology consistently across native and online surfaces.'),
}
entries=[]
for surface, source, target in [('native',ns,native),('online',os,online)]:
 for key,value in target.items():
  if isinstance(value,str) and value.strip():
   id=surface+':'+key
   proposal,severity,reason=changes.get(id,(value,None,'Retain: correct concise Thai, preserves source meaning and required tokens, and agrees with the language brief.'))
   entries.append({'id':id,'source':source[key],'observed_target':value,'proposal':proposal,'decision':'change' if proposal!=value else 'retain','severity':severity,'reason':reason})
record={'reviewer':'cloud_adapter','role':'independent Thai editor','independence':'Reviewed current nonblank Google draft against frozen source, language brief, FR/JA/VI reference catalogs and HUD usage before reading any meaning-review findings. Did not read pilot-google-review.json.','source_sha256':json.loads((root/'manifest.json').read_text())['source_sha256'],'catalog_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in p.catalog_paths(root,'th').items()},'edited_keys':[e['id'] for e in entries],'entries':entries,'summary':{'reviewed':len(entries),'changes':sum(e['decision']=='change' for e in entries)},'status':'independent-first-pass-proposals; parent must integrate and recheck; no release approval'}
(root/'reviews/pilot-editor.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(record['summary'])
