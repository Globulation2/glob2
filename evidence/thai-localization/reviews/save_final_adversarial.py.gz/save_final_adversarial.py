import hashlib,json
from pathlib import Path
R=Path('artifacts/thai-localization')
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def save(name,findings=[]):
 p=R/f'round3-native/batches/{name}.json';b=json.loads(p.read_text());r2path=R/f'round2/batches/{name}.json';r2={e['id']:e['target'] for e in json.loads(r2path.read_text())['entries']};oldpath=R/f'reviews/adversarial/{name}.json';old=json.loads(oldpath.read_text());assert old['target_sha256']==sha(r2);assert old['adversarial_reviewed_keys']==list(r2)
 values={e['id']:e['target'] for e in b['entries']};carried={};fresh=[]
 for e in b['entries']:
  if e['changed_since_round2']:assert e['target']!=r2[e['id']];fresh.append(e['id'])
  else:assert e['target']==r2[e['id']];carried[e['id']]=e['target']
 blocked={f['id'] for f in findings};out={'adversarial_reviewer':'thai_rendering','source_sha256':b['source_sha256'],'target_sha256':sha(values),'approved_keys':[k for k in values if k not in blocked],'fresh_reviewed_keys':fresh,'carried_keys':list(carried),'carried_subset_sha256':sha(carried),'findings':findings,'accepted_english':old.get('accepted_english',[]),'carry_proof':{'round2_batch_sha256':hashlib.sha256(r2path.read_bytes()).hexdigest(),'round2_review_sha256':hashlib.sha256(oldpath.read_bytes()).hexdigest()},'method':'Fresh independent adversarial recheck of every changed actual round3 target against English, gameplay and terminology. Remaining values carried only after exact equality proof against this reviewer’s fully read round2 batch; no fresh-read claim for carried text. Agent-reviewed, not native-human-certified.'}
 target=R/f'reviews/final-adversarial/{name}.json';target.parent.mkdir(exist_ok=True);target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(name,len(fresh),'fresh',len(carried),'carried',len(findings),'unresolved')
