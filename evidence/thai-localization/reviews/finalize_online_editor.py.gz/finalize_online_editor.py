import hashlib,json
from pathlib import Path
r=Path('artifacts/thai-localization')
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
allfresh=allcarry=0
for p in sorted((r/'round3-online/batches').glob('*.json')):
 b=json.loads(p.read_text());old=json.loads((r/'round1/batches'/p.name).read_text());reviewpath=r/'reviews/editor'/p.name;review=json.loads(reviewpath.read_text());proposals={f['id']:f['proposed'] for f in review['findings']};original={e['id']:e['target'] for e in old['entries']};carried={};fresh=[];accepted={a['id']:a['reason'] for a in review['accepted_english']}
 for e in b['entries']:
  expected=proposals.get(e['id'],original[e['id']]);assert e['editor_expected_target']==expected,e['id']
  if e['target']==expected:carried[e['id']]=e['target']
  else:fresh.append(e['id'])
  if e['target']==e['source'] and isinstance(e['source'],str):
   if e['id']=='online:V{slot0} · {slot1}':accepted[e['id']]='Compact revision/version marker V with interpolated values; preserve marker and separator.'
   assert e['source'] in ['Cabino','Castor','Cortex','Econo','Maxima','Nicowar','Numbi','Reach to Infinity','Toubib','Warrush'] or e['id'] in accepted,e['id']
   if e['id'] not in accepted:accepted[e['id']]='Exact registered AI identity/display name; preserve it for lookup and recognition across catalogs.'
 values={e['id']:e['target'] for e in b['entries']}
 result={'editor':'thai_rendering','source_sha256':b['source_sha256'],'target_sha256':sha(values),'approved_keys':list(values),'fresh_reviewed_keys':fresh,'carried_keys':list(carried),'carried_subset_sha256':sha(carried),'findings':[],'accepted_english':[{'id':k,'reason':v} for k,v in accepted.items()], 'carry_proof':{'initial_batch_sha256':hashlib.sha256((r/'round1/batches'/p.name).read_bytes()).hexdigest(),'initial_editor_record_sha256':hashlib.sha256(reviewpath.read_bytes()).hexdigest(),'rule':'Actual target exactly equals individually reviewed round1 target or this editor’s exact authored proposal; asserted against original records.'},'method':'Fresh editorial recheck of every listed changed target against English and expected text; exact identical previously reviewed text carried with hash proof, not claimed as a fresh reading. All fresh changes checked for idiom, register, technical meaning, tokens, and shared terminology. Agent-reviewed, not native-human-certified.'}
 out=r/'reviews/final-editor'/p.name;out.parent.mkdir(exist_ok=True);out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');allfresh+=len(fresh);allcarry+=len(carried)
print(allfresh,'fresh reviewed;',allcarry,'exact text carried; total',allfresh+allcarry)
