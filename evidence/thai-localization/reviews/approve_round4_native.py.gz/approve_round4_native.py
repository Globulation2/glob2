import hashlib,json
from pathlib import Path
R=Path('artifacts/thai-localization')
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
nt=nc=0
for p in sorted((R/'round4-native/batches').glob('*.json')):
 b=json.loads(p.read_text());prevpath=R/'reviews/final-adversarial-r3'/p.name;prev=json.loads(prevpath.read_text());r3={e['id']:e['target'] for e in json.loads((R/'round3-native/batches'/p.name).read_text())['entries']};assert prev['target_sha256']==sha(r3)
 values={e['id']:e['target'] for e in b['entries']};carry={};fresh=[]
 for e in b['entries']:
  if e['changed_since_round3']:assert e['target']!=r3[e['id']];fresh.append(e['id'])
  else:assert e['target']==r3[e['id']] and e['id'] in prev['approved_keys'];carry[e['id']]=e['target']
 result={'adversarial_reviewer':'thai_rendering','source_sha256':b['source_sha256'],'target_sha256':sha(values),'approved_keys':list(values),'fresh_reviewed_keys':fresh,'carried_keys':list(carry),'carried_subset_sha256':sha(carry),'priorrecordproof':{'path':str(prevpath),'sha256':hashlib.sha256(prevpath.read_bytes()).hexdigest(),'rule':'Carried values exactly equal previously approved round3 text; asserted against immutable original batch and prior approval keys.'},'findings':[],'accepted_english':prev.get('accepted_english',[]),'method':'Read all21 actual changed round4 source/Thai entries independently, including guard selector/tutorial consistency, Switchbacks name, on-stone placement, already-fed units, Portage land/forest sense, and reviewed word-break corrections. No unresolved findings. Other3372entries carried only from exact previously approved text with hash proof. Agent-reviewed, not native-human-certified.'}
 (R/'reviews/final-adversarial'/p.name).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');nt+=len(fresh);nc+=len(carry)
print(nt,'fresh;',nc,'carried;',nt+nc,'approved; no unresolved findings')
