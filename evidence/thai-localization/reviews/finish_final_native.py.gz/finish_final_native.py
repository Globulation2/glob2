import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from save_final_adversarial import save
r=Path('artifacts/thai-localization/round3-native/batches')
for p in sorted(r.glob('*.json')):
 b=json.loads(p.read_text());findings=[]
 for e in b['entries']:
  key=e['key'];s=e['target'];new=s;reason=None;severity='major'
  if 'รักษาการณ์' in s:
   new=s.replace('พื้นที่\u200bรักษาการณ์','เขต\u200bป้องกัน').replace('รักษาการณ์','ป้องกัน');reason='Match final actual Guard=ป้องกัน and Guard area=เขตป้องกัน labels consistently; tutorial must name the selectable control.'
  if key=='[Switchbacks]':new='ทาง\u200bโค้ง\u200bหักศอก';reason='Match both final Switchbacks generator error messages to the same landscape name.'
  if key=='[intro instruction scout]':new=s.replace('เหนือ\u200bผืน\u200bหิน','บน\u200bกลุ่ม\u200bหิน');reason='Place directly on the stone patch; เหนือ can direct above/north of it, which fails tutorial location gate.'
  if key=='[lesson healing briefing]':new='สร้าง\u200bโรงพยาบาล\u200bและ\u200bช่วย\u200bคนงาน\u200bบาดเจ็บ\u200bให้\u200bฟื้นตัว ยูนิต\u200bใน\u200bอาณานิคม\u200bเริ่ม\u200bโดย\u200bกิน\u200bอาหาร\u200bแล้ว และ\u200bมี\u200bคนงาน\u200bบาดเจ็บ 1 ตัว';reason='Starts fed describes already-fed units, not merely stocked food; retain actual prepared state.'
  if 'พอร์\u200bเท\u200bจ' in new:new=new.replace('พอร์\u200bเท\u200bจ','พอร์เทจ');reason='Keep Portage proper name intact, matching final landscape label.';severity='minor'
  if key=='[settings Double-tap the map, hold, then drag to zoom.]':new=s.replace('แผนที่สอง','แผนที่\u200bสอง');reason='Separate map noun from two-times tap count; reviewed soft word boundaries should reflect actual words.';severity='minor'
  if new!=s:findings.append({'id':e['id'],'severity':severity,'proposed':new,'reason':reason})
 save(p.stem,findings)
