from record_final import record
record('native-maps-002',{
7:('แต่ละ|ภูมิประเทศ|แสดง|แผนที่|จริง|ตาม|ขนาด|และ|จำนวน|อาณานิคม|ด้านล่าง ซึ่ง|ปรับ|ได้|ที่นี่ เลือก|ใช้|เพื่อ|เล่น|แผนที่|ที่|แสดง','minor','Repair map noun boundaries and clarify adjustable exact preview.'),
11:('ติดตั้ง|ตัวสร้าง|แผนที่|แล้ว การ|เลือก|ครั้ง|ต่อไป|ใช้|รุ่น|เผยแพร่|นี้','major','Repair ติด|ตั้งตัว and แผน|ที่แล้ว boundaries.'),
})
