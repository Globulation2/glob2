from record_final import record
record('native-maps-001',{
29:('แต่ละ|ภูมิประเทศ|แสดง|เป็น|แผนที่|จริง|ตาม|ขนาด|และ|จำนวน|อาณานิคม|ปัจจุบัน เลือก|ใช้|เพื่อ|เล่น|แผนที่|ที่|แสดง','minor','Repair map-word boundary and concise exact-preview description.'),
47:('หุบเขา|ใหญ่|เกินขนาด|แผนที่ ให้|ใช้|แผนที่|ใหญ่|ขึ้น|หรือ|ลด|ขนาด|หุบเขา','minor','Semantic valley/large boundary, not หุบ / เขาใหญ่ proper-name grouping.'),
62:('ลาก|เพื่อ|เลื่อน|วน|แผนที่ หมุน|ล้อ|เมาส์|เพื่อ|ซูม คลิก|ขวา|หรือ|ดับเบิลคลิก|เพื่อ|รีเซ็ต','major','Repair แบ|บวน boundary; accept concise meaning-review wording for toroidal panning.'),
63:('ลาก|เพื่อ|เลื่อน|วน|แผนที่ หมุน|ล้อ|เมาส์|เพื่อ|ซูม','major','Same valid wrap/pan instruction.'),
80:('เกาะ|เล็ก|เกิน|แปลง|ที่|กำหนด ให้|ใช้|แผนที่|ใหญ่|ขึ้น ลด|ขนาด|แปลง หรือ|ลด|จำนวน|อาณานิคม','major','Plantations generator plot includes crop band and usable centre; avoid wrongly asserting only building plots. Preserve three remedies.'),
101:('ทะเลสาบ|พอร์เทจ|ต้อง|มี|ทะเลสาบ|ว่ายน้ำ|แยก|จากกัน|ใน|ซีด|นี้','minor','Accept exact separate-lakes requirement after checking PortageLakes validation.'),
106:('ปล่อย|เพื่อ|วาง|บน|พื้นที่|ที่|ถูกต้อง','minor','Valid-placement instruction, not generic suitability judgment.'),
128:('ปริมาณ|วัสดุ|ที่|งอก|เพิ่ม|ใน|แหล่ง|ทรัพยากร|ทั่ว|แผนที่ วัด|เป็น|แต้ม|การ|เติบโต ไม่|ใช่|หน่วย|วัสดุ|ที่|เก็บเกี่ยว ค่า|นี้|เท่ากัน|ทุก|อาณานิคม','major','Growth points differ from harvested material loads; avoid falsely defining loads as number of trips.'),
})
