from record_final import record
record('native-general-004',{
49:('คุณ|ปะทะ|ทุกฝ่าย','minor','All opponents, not every object.'),
65:('ภูมิประเทศ|นี้|กำหนด|ตำแหน่ง|ทรัพยากร|ตายตัว','minor','Consistent landscape term and concise placement statement.'),
88:('ใช้|รายการ|ที่|เลือก','minor','Natural selection action.'),
108:('ที่ราบสูง|หิน','minor','Accept idiomatic highlands rendering from meaning review.'),
148:('ทาง|คดเคี้ยว','minor','Match Switchbacks landscape name used by its constraint messages.'),
})
