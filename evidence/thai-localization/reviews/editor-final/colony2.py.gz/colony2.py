from record_final import record
record('native-colony-002',{
8:('คุณ|กำหนด|การ|สร้าง|นักรบ|และ|ฝึก|นักรบ|แล้ว ส่ง|อาหาร|ต่อเนื่อง|ไว้ เพราะ|นักรบ|ยัง|ต้อง|กิน|อาหาร','minor','Canonical roles and concise completion reminder.'),
14:('สร้าง|ค่ายฝึก|ใน|พื้นที่|โล่ง แล้ว|มอบหมาย|คนงาน|ก่อสร้าง หยุด|หรือ|ลด|การ|สร้าง|นักรบ|เมื่อ|มี|เพียงพอ ค่ายฝึก|สอน|ทักษะ|การต่อสู้|และ|ต้อง|มี|ที่ว่าง|รอบ|อาคาร','minor','Keep building noun separate from following สอน verb and preserve valid actor/terrain boundaries.'),
17:('หยุด|หรือ|ลด|การ|สร้าง|นักรบ|เมื่อ|มี|เพียงพอ ค่ายฝึก|สอน|ทักษะ|การต่อสู้|และ|ต้อง|มี|ที่ว่าง|รอบ|อาคาร','minor','Same semantic camp/teaches boundary.'),
})
