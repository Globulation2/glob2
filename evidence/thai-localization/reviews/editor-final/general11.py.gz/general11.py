import json
from pathlib import Path
from record_final import record,whole
entries=json.loads(Path('artifacts/thai-localization/round2/batches/native-general-011.json').read_text())['entries']
fixes={
24:('ใช้งาน|ไม่|ได้','minor','Report category: broken map, not an abstract ineffective result.'),
51:('ไม่|พบ|แผนที่|ตรง|เงื่อนไข','minor','Repair มีแผน|ที่ใด boundary and natural empty-search state.'),
62:('เซิร์ฟเวอร์|กำลัง|โหลด|แผนที่','major','Repair โห|ลดลง boundary and make map validation actor clear.'),
125:('ยัง|ไม่|มี|ที่นั่ง','minor','Unseated lobby state rather than physically not sitting.'),
136:('ออกจาก|แมตช์|ใน|ห้อง|แล้ว|นับว่า|แพ้|ใน|ประวัติ คนอื่น|ยัง|เล่น|ต่อ และ|กลับ|เข้า|แมตช์|นี้|ไม่|ได้','minor','Scope no-return consequence to this match, not all future play.'),
}
for index in (76,83):
 text=whole(entries[index]['target']).replace('แผนที่สาธารณะ','แผนที่\u200bสาธารณะ')
 fixes[index]=(text,'minor','Boundary between map noun and public adjective rather than inside แผนที่.')
record('native-general-011',fixes)
