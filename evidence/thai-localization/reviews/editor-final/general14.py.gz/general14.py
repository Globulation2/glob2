from record_final import record
record('native-general-014',{
72:('ไม้|ป่า|ดงดิบ','minor','Jungle trees differ visually from generic forest trees.'),
86:('ดง|ไม้พุ่ม','minor','Distinguish dense thicket from scrub bushes.'),
105:('น้ำ|สี|เข้ม','minor','Natural description of dark water artwork.'),
106:('หลุม','minor','Terrain hole, not a hole drilled in an object.'),
137:('ทีม…','minor','Consistent team-menu label; Thai does not need ต่างๆ to pluralize.'),
142:('พื้นที่|ห้าม|งอก','minor','Unify no-growth zone label with corresponding controls.'),
})
