from record_final import record
record('native-tutorial-001',{
8:('จบ|บทเรียน|แล้ว','minor','Avoid word boundary that groups finished กับ เรียน; natural completion title.'),
})
