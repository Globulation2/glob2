from record_final import record
record('native-general-005',{
155:('ติด|อยู่','minor','Trapped means boxed in, not necessarily an explicit trap object.'),
145:('อาหาร|ที่|ขนส่ง','major','Loads are material packets/amounts, not necessarily counts of hauling trips.'),
159:('หน่วย/นาที','major','Material flow rate, avoiding an incorrect claim of trip counts.'),
103:('วัด|จุดเริ่มต้น|ของ|ทุก|อาณานิคม|จาก|แผนที่|ที่|สร้าง|เสร็จ แบบจำลอง|ที่|ฝึก|จาก|เกม|นับ|พัน|ระหว่าง|คู่แข่ง|ฝีมือ|เท่ากัน|แปลง|ผลวัด|เป็น|คะแนน|ความเหมาะสม คะแนน|บอก|โอกาส|ชนะ|ของ|อาณานิคม ความเป็นธรรม|บอก|ความ|เท่าเทียม|ของ|โอกาส: 1 เมื่อ|ทุก|อาณานิคม|มี|โอกาส|ชนะ|เท่ากัน และ 0 เมื่อ|อาณานิคม|เดียว|มี|โอกาส|ชนะ|ทั้งหมด','major','Repair invalid ถู|กวัด and บอ|กว่า boundaries and make probability/fairness definition idiomatic without changing thresholds.'),
})
