from record_final import record
record('native-settings-001',{
38:('เปลี่ยน|ตัวเรนเดอร์|แล้ว|ต้อง|ปิด|และ|เปิด|เกม|ใหม่','minor','Separate change verb from renderer noun; application restart requirement remains clear.'),
74:('ตาม|เดสก์ท็อป','minor','Use desktop resolution option, not general aesthetic compatibility.'),
75:('ไม่|พบ|แบบอักษร','minor','Natural missing-font status.'),
84:('กด|ปุ่ม|ที่|ต้องการ ส่วน Esc ใช้|ยกเลิก หาก|ต้องการ|ตั้ง Esc เป็น|ปุ่มลัด ให้|เลือก|กำหนด Esc','major','Initial wording could read as an instruction to press Esc; restore press-a-key instruction and distinct cancellation behavior.'),
133:('ซีด|นี้|วาง|ทางลัด|บนบก|ผ่าน|ป่า|ที่|ใช้งาน|ได้|ใน|ทะเลสาบ|พอร์เทจ|ไม่|ได้','major','Dry woodland shortcut means walking over land through trees, not an arid forest biome; accept meaning refinement.'),
})
