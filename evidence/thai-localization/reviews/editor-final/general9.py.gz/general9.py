from record_final import record
record('native-general-009',{
47:('ลอง|ใหม่|ใน|อีก %0 วินาที ห้อง|ออนไลน์|และ|หาคู่แข่งด่วน|ใช้ไม่ได้ เกม LAN ใน|เมนูหลัก|ไม่|ต้อง|ใช้|เซิร์ฟเวอร์|นี้','minor','Future retry interval and valid กำลัง boundary; refer to actual quick-match label.'),
63:('หาคู่แข่งด่วน|จะ|ปรากฏ|เมื่อ|เซิร์ฟเวอร์|ตอบกลับ','minor','Refer to canonical named action.'),
64:('หาคู่แข่งด่วน|ยัง|ใช้ไม่ได้|ใน|เวอร์ชัน|นี้','minor','Refer to canonical named action.'),
128:('ตรวจสอบ|แล้ว · เบื้องต้น','minor','Provisional is preliminary, not a temporary expiring result.'),
})
