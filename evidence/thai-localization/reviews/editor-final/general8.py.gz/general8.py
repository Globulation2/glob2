from record_final import record
record('native-general-008',{
3:('ผล|ต่อ|คะแนน','minor','Source StartQualityScreen shows each model feature contribution to fitness; concise idiomatic label.'),
44:('ป้องกัน','major','Actual Guard tool referenced by defensive-tactics instructions.'),
109:('%0 · ผล|ต่อ|คะแนน: %1','minor','Same model contribution term as heading.'),
111:('ยืนยัน: %0','critical','Touch action formats with Destroy in GameGUITouchActions.cpp:124; confirmation, not healthy unit state. Revert meaning regression.'),
117:('ปรับ|สมดุล|เขต|ป้องกัน','minor','Canonical guard-zone term.'),
118:('นักรบ|ที่|ว่าง|จะ|กระจาย|ตาม|เขต|ป้องกัน|ที่|วาด|ไว้ แทน|การ|ไป|รวม|ที่|เขต|ใกล้|สุด เขต|ใหญ่|ได้|นักรบ|มากกว่า และ|เขต|ที่|มี|มาก|เกินไป|จะ|แบ่ง|ไป|เขต|อื่น','minor','Repair ป้อง|กันที่ boundary while preserving allocation rules.'),
119:('พื้นที่|ฟาร์ม','minor','Match Farm area brush terminology.'),
130:('ใช้|ที่อยู่|ล็อบบี้|ของ|โฮสต์','minor','Network endpoint as usable connection address.'),
147:('ตามหลัง: ระยะเวลา|ที่|เกม|ของ|ผู้เล่น|ช้า|กว่า|นาฬิกา|แมตช์ รวม|ความหน่วง|ของ|ผู้เล่น|ด้วย ต่ำกว่า %0 ถือว่า|ปกติ ตั้งแต่ %1 จะ|ทำเครื่องหมาย|ว่า|ช้า','minor','Do not imply input delay is necessarily manually configured; preserve inclusive threshold semantics.'),
})
