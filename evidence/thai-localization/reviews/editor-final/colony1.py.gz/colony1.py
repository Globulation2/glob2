from record_final import record
record('native-colony-001',{
33:('เลือก|ค่ายฝึก','major','Canonical same building as Training Camp, agreed by meaning/editor/adversary.'),
84:('คนงาน 8 ตัว / ความเร็ว 2 เท่า','minor','Creature classifier ตัว, consistent with unit count terminology.'),
86:('ปะทะ|ด่วน: ความเร็ว 2 เท่า แผนที่|ที่|สร้าง|ขึ้น|เริ่ม|ด้วย|คนงาน 8 ตัว','minor','Canonical preset name and creature classifier.'),
90:('พื้นที่|ก่อสร้าง|ใน|ไร่','minor','Accept meaning refinement: farm is cultivated region, no separate Farm building type.'),
103:('กำลัง|คำนวณ|เกรเดียนต์…','major','Use agreed technical spelling and prevent split inside transliterated term.'),
129:('สัดส่วน|เวลา|ที่|คนงาน|ไม่|มี|งาน|ทำ ค่า|สูง|แปลว่า|คนงาน|มากกว่า|งาน ค่า|ใกล้|ศูนย์|แปลว่า|ทุก|ตัว|มี|งาน|และ|อาจ|มี|งาน|รอ','major','Denominator is all worker time including idle time, not only working time.'),
133:('จำนวน|นักรบ|ของ|อาณานิคม แยก|กราฟ|เพื่อ|ดู|ว่า|กี่|ตัว|อยู่|ใกล้|ฐาน ใกล้|อาณานิคม|ศัตรู หรือ|ใน|พื้นที่|โล่ง พื้นที่|ใกล้|ทั้งสอง|ฝ่าย|นับ|เป็น|ใกล้|ฐาน','minor','Canonical classifier and home-zone wording; source tie rule preserved.'),
135:('ระดับ|โจมตี|เฉลี่ย|ของ|นักรบ|ใน|อาณานิคม โดย|ให้|น้ำหนัก|ความเร็ว|โจมตี|และ|พลัง|โจมตี|เท่ากัน ใช้|มาตรา 1 ถึง 4 ตามที่|เกม|แสดง การ|ฝึก|ที่|ค่ายฝึก|เพิ่ม|ค่า|นี้ ส่วน|นักรบ|ใหม่|ที่|ยัง|ไม่|ฝึก|ทำให้|ค่าเฉลี่ย|ลดลง','major','Canonical training-building name; preserve meaning and numeric scale.'),
143:('เวลา|ของ|คนงาน','major','Worker time includes idle/eating/healing, not just working hours.'),
})
