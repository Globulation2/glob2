from record_final import record
record('native-general-001',{
27:('สำรวจ เพิ่ม|แหล่ง|อาหาร และ|รวบรวม|นักรบ|เป็น|ระลอก','minor','Accept meaning refinement: develops food supply rather than merely accumulating stock.'),
34:('คู่ต่อสู้|ที่|รับมือ|ง่าย แต่|ยัง|ขยายฐาน|และ|โจมตี','minor','Forgiving difficulty, not a personal kindness claim.'),
36:('ขยาย|เศรษฐกิจ|และ|แข่ง|ดึง|ยูนิต|มา|เข้า|ทีม โดย|ไม่|สร้าง|นักรบ','minor','Converts are game units rather than generic people; compact AI description.'),
})
