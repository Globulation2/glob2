from record_final import record
record('native-general-002',{
11:('พื้นที่|ป้องกัน','minor','Unify Guard-zone vocabulary with actual tool/tutorial term.'),
56:('แพ้: %0 มี|เกียรติยศ|มากกว่า|คุณ','major','Use gameplay prestige terminology, not generic personal honor.'),
89:('เปิด|ตัวแก้ไข|ทีม','minor','Break between imperative เปิด and editor noun, not idiom เปิดตัว (debut).'),
})
