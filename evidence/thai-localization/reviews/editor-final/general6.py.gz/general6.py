from record_final import record
record('native-general-006',{
103:('ระยะห่าง|ของ|ดรัมลิน','major','Repair ขอ|งด|รัม|ลิ|น which splits both ของ and geological name.'),
104:('ความยาว|ของ|ดรัมลิน','major','Same invalid word/name boundaries.'),
116:('ทิศทาง|การ|วาง','minor','Keep ทิศทาง whole and separate from following nominal การ.'),
149:('ทางข้าม|ย่อย|เพิ่มเติม|ต่อ|พื้นที่|แม่','minor','Semantic boundary เพิ่มเติม / ต่อ rather than เพิ่ม / เติมต่อ.'),
})
