import json
from pathlib import Path
from record_final import record,whole
entries=json.loads(Path('artifacts/thai-localization/round2/batches/native-general-003.json').read_text())['entries']
p122=whole(entries[122]['target']).replace('ศึกษา|เรื่อง|น้ำ'.replace('|','\u200b'),'พิจารณา|ความชุ่มชื้น'.replace('|','\u200b')).replace('บริหาร|จัดการ|การ|ขยายตัว|ของ|อาหาร'.replace('|','\u200b'),'บริหาร|จัดการ|การ|ขยาย|แหล่ง|อาหาร'.replace('|','\u200b')).replace('และ|การ|เข้าถึง|ของ|คนงาน'.replace('|','\u200b'),'และ|พื้นที่|ที่|คนงาน|เข้าถึง'.replace('|','\u200b'))
p130=whole(entries[130]['target']).replace('หรือ|หมดเวลา'.replace('|','\u200b'),'หรือ|ถึง|เวลา|ที่|กำหนด'.replace('|','\u200b')).replace('การ|เลือก|เป้าหมาย|ที่|ง่าย'.replace('|','\u200b'),'วิธี|เลือก|เป้าหมาย|ที่|เรียบง่าย'.replace('|','\u200b'))
p136=whole(entries[136]['target']).replace('ตัวต่อ','ตัว\u200bต่อ')
record('native-general-003',{
55:('โฮสต์|ยกเลิก|เกม|แล้ว','minor','Use consistent room-host role, not an event host.'),
122:(p122,'minor','Accept meaning refinements: soil hydration, workers reach, and expansion of food sources; preserve all other reviewed profile hints.'),
130:(p130,'minor','AI attack timeout rather than match ending; simple selection algorithm rather than easy targets.'),
133:('สร้าง|อาณานิคม|ที่|มี|อาหาร|มาก และ|แข่ง|ดึง|ยูนิต|เข้า|ทีม|โดย|ไม่|สร้าง|นักรบ','minor','Food-based team conversion concerns units, not generic people.'),
136:(p136,'minor','Separate classifier ตัว from preposition ต่อ rather than grouping them as the wasp word ตัวต่อ.'),
})
