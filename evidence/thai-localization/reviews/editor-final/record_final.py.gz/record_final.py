import json,hashlib,re
from pathlib import Path
ROOT=Path('artifacts/thai-localization')
# Each call is made only after the actual batch and corresponding disagreement
# entries have been read. These spellings are source-context terminology, not a
# blanket claim that an entire dictionary's line breaking is correct.
WHOLE=['นักสำรวจ','คนงาน','พื้นที่','กีดขวาง','เกรเดียนต์','ฟยอร์ด','เอเวอร์เกลดส์','พอลเดอร์','เชอร์รี','แชท','อัปโหลด','อัปเกรด','สนามวิ่ง','ค่ายฝึก','ธงรบ','ธงสำรวจ','ธงแผ้วถาง','พลังชีวิต','ความเป็นธรรม','คอนทราสต์','ครอสเฟด','สัญญาอนุญาต','แพ็กเกจ','เส้นขอบ','ปุ่มลัด','คาราวาน','คาสเตอร์','แม็กซิมา','คอร์เทกซ์','นิโควาร์','นัมบี','อีโคโน','วอร์รัช','คาบิโน','ไดเร็กทอรี','ซอร์สโค้ด','ผู้เล่น','ตัวแก้ไข','รีเพลย์','รีสตาร์ท','เกียรติยศ','ทอรัส','ลากูน','หมู่บ้าน','ชายหาด','อับลม','อีโมจิ','โคลเวอร์','โมเรน','ดรัมลิน','เอสเกอร์','เซียร์ปินสกี','เนินทราย','เซสชัน','กู้คืน','เส้นทาง','ป้องกัน','แผนที่','มิลลิวินาที','ซิมูเลชัน','แอป','กำลัง','ผู้เยี่ยมชม','ลงชื่อเข้าใช้','ลงชื่อออก','เนื้อหา','ตัวกรอง','สัดส่วน','แล้ว','สูญเสีย','แซนด์บ็อกซ์','มอส','ถูก','แฮช','เมตา','โจมตี','พอร์เทจ','ฮิลเบิร์ต','หุบเขา','ตัวสร้าง','ติดตั้ง','ตัวเรนเดอร์','เกมเพลย์']
def whole(text):
 for word in WHOLE:
  pattern='\u200b?'.join(map(re.escape,word))
  text=re.sub(pattern,lambda m:word,text)
 return text

def record(batch, fixes=None, accepted=None):
 d=json.loads((ROOT/'round2/batches'/f'{batch}.json').read_text());fixes=fixes or {};findings=[]
 if accepted is None: accepted=json.loads((ROOT/'reviews/editor'/f'{batch}.json').read_text()).get('accepted_english',[])
 for i,e in enumerate(d['entries']):
  actual=e['target'];target=whole(actual)
  reason='Join the reviewed Thai lexical/gameplay term; preserve every other candidate boundary.';severity='minor'
  if i in fixes:
   value,severity,reason=fixes[i];target=value.replace('|','\u200b')
  if target!=actual:findings.append({'id':e['id'],'severity':severity,'proposed':target,'reason':reason,'boundary_status':'explicit reviewed final hints; preserve verbatim'})
 r={'editor':'cloud_adapter','source_sha256':d['source_sha256'],'target_sha256':hashlib.sha256(json.dumps({e['id']:e['target'] for e in d['entries']},sort_keys=True,ensure_ascii=False).encode()).hexdigest(),'edited_keys':[e['id'] for e in d['entries']],'findings':findings,'accepted_english':accepted or [],'review_basis':'Read every actual round2 target and every corresponding editor/meaning disagreement; frozen English source was read in initial independent pass. Inspected candidate word boundaries. Explicit final proposals preserve all reviewed hints.','status':'final-editor-pass-with-findings' if findings else 'final-editor-pass-clear'}
 (ROOT/'reviews/editor-final'/f'{batch}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(batch,len(r['edited_keys']),len(findings))
