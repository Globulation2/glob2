from record_final import record
record('native-settings-003',{
5:('ยัง|ไม่ได้|บันทึก|เพลง|อย่าง|ถาวร โปรด|ลอง|บันทึก|อีกครั้ง|ก่อน|ออก','minor','Avoid misleading again-before lexical grouping and unprovided desktop-only program scope.'),
36:('นำเข้า ZIP เพลง|ที่|ดาวน์โหลด|หรือ|แทร็ก Opus ทั้ง|สาม อ่าน|ข้อมูล|ประกอบ|และ|ภาพ|ปก|จาก|แทร็ก|สงบ ไม่ต้อง|มี|ไฟล์|อื่น','minor','Adopt meaning reviewer natural metadata wording; retain source track distinction.'),
42:('นำเข้า|ตัวสร้าง|แผนที่','minor','Break between import verb and generator noun, never inside import.'),
43:('ยัง|ไม่ได้|ติดตั้ง|ตัวสร้าง|แผนที่|แบบ|กำหนด|เอง','minor','Use canonical generator term, clarify empty installed state.'),
49:('บันทึก|คลัง|ตัวสร้าง|แผนที่|แล้ว','minor','Separate perfective แล้ว from map noun.'),
59:('ใช้|เมื่อ|ถึง|จุด|เปลี่ยน|รอบ|จำลอง|ถัดไป งาน|ที่|ไม่|รองรับ|ใช้ CPU อัตโนมัติ ส่วน|การ|เรนเดอร์|แยก|จากกัน','minor','Do not let wrap combine รับใช้ servant across unsupported-work predicate.'),
62:('แพร่|ค่า|แบบ|บักเก็ต','minor','Do not split borrowed bucket word.'),
80:('ข้อผิดพลาด: %0','minor','Normalize colon spacing.'),
83:('เรียก|ดู|ตัวสร้าง|แผนที่|ที่|แชร์','minor','Separate browse verb from generator noun.'),
84:('ใช้|ภาพประกอบ|ใน|การ|โหลด|เกม|หรือ|ตัวแก้ไข|ครั้ง|ถัดไป','minor','Use canonical editor term.'),
85:('ต้อง|ใช้|ตัวเรนเดอร์|ที่|มี|การกรอง|พื้นผิว ตัวเลือก|ที่|คุณ|บันทึก|ไว้|จะ|ยัง|คงอยู่','minor','Use canonical renderer term.'),
87:('ต้อง|ใช้|ตัวเรนเดอร์|ที่|รองรับ|ทอรัส ตัวเลือก|ที่|คุณ|บันทึก|ไว้|จะ|ยัง|คงอยู่','minor','Use canonical renderer and protect torus.'),
92:('กำลัง|เปลี่ยน|ตัวเรนเดอร์…','minor','Break between changing verb and renderer noun.'),
93:('เปิด|ใช้งาน|ล้อเลื่อน|ใน|เมนู','minor','Natural wheel scrolling label without unnatural วงล้อ.'),
98:('รายการ|และ|แผง|ต่างๆ ยืด|เลย|ขอบ|แล้ว|เด้ง|กลับ|มาก|น้อย|เพียงใด ท่าทาง|สัมผัส|ของ Mac ยืด|ออก|นุ่มนวล|กว่า','minor','Describe bounce magnitude with natural spring-back expression.'),
})
