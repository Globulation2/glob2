from record_final import record
record('native-general-013',{
0:('ติด|อยู่','minor','Trapped units, not necessarily stuck at a doorway.'),
2:('เกือบ|หมด','minor','Food reserve almost empty, natural Thai reserve-state wording.'),
34:('หน่วย','critical','Resource/material quantity suffix, not a count of living game units. Revert over-broad meaning normalization.'),
95:('ความเร็ว|ที่|ทรัพยากร|งอก|กลับ|และ|แพร่กระจาย|หลัง|เก็บเกี่ยว','major','Repair syllable split แล้|วจะ and concise regrowth-rate explanation.'),
142:('จำนวน|นักรบ|ศัตรู|ภายใน 16 ช่อง|จาก|อาคาร|ของ|อาณานิคม หาก|สอง|อาณานิคม|อยู่|ใกล้|กัน แต่ละ|ฝ่าย|จะ|นับ|กำลัง|ป้องกัน|ของ|อีก|ฝ่าย|ด้วย','minor','Canonical warriors; retain symmetric proximity counting.'),
144:('พลัง|นักรบ|ฝ่าย|ตน|ใกล้|อาคาร ลบ|พลัง|นักรบ|ศัตรู|บริเวณ|เดียวกัน โดย|นับ|จำนวน|นักรบ|และ|ระดับ|โจมตี|ของ|แต่ละ|ตัว ค่า|ต่ำกว่า|ศูนย์|แปลว่า|กำลัง|ฝ่าย|ตน|น้อยกว่า|ศัตรู|ใกล้|ฐาน','major','Source negative margin means outmatched, not necessarily outmatched by a large amount; canonical classifier.'),
})
