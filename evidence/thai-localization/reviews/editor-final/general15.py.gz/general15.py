import json
from pathlib import Path
from record_final import record,whole
entries=json.loads(Path('artifacts/thai-localization/round2/batches/native-general-015.json').read_text())['entries']
fixes={
8:('นำเข้า|ชุด|ภูมิประเทศ|และ|ทรัพยากร','minor','Import a set, not the unrelated เข้าชุด (matching set) word.'),
29:('แทนที่|รายการ|ภูมิประเทศ|และ|ทรัพยากร|ที่|วาง|ไว้|ซึ่ง|ตรงกัน รวม|การ|แก้ไข|เฉพาะ|แผนที่ รายการ|ที่|ไม่|มี|ใน|รุ่น|ใหม่|ยัง|ใช้|รุ่น|เก่า ปริมาณ|วัสดุ|เดิม|จะ|ไม่|เกิน|ความจุ|ใหม่','major','Matching entries replaced, entries omitted by new release retain old definition; preserve capacity clamp and map-local edit replacement.'),
36:('แสดง|ตัวอย่าง|เฉพาะ 64 รายการ|แรก แต่|เลือก|นำเข้า|ได้|ทุก|รายการ','major','All entries selectable, not all previewable; source previews limited to first64.'),
65:('ยูนิต|ภาคพื้นดิน|ที่|ยัง|มีชีวิต แบ่ง|ตาม|อัตราส่วน|ความเร็ว|โดยประมาณ ว่ายน้ำ 2 เท่า|หมายถึง|ว่ายน้ำ|เร็ว|เป็น|สองเท่า|ของ|วิ่ง ไม่|นับ|ยูนิต|บิน|หรือ|ยูนิต|เคลื่อนที่|ไม่|ได้','major','Correct my initial wording which could describe living ground rather than living ground units; accept meaning refinement.'),
77:('หยุด|ไม่|สำเร็จ ลอง|กด|ปุ่มลัด|หยุด|อีกครั้ง','minor','Canonical keyboard shortcut term.'),
92:('ยัง|ไม่|มี|ไฟล์|บันทึก','minor','List of recording artifacts, not recording activity.'),
93:('ไฟล์|บันทึก|ที่|ถูก|ขัดจังหวะ','minor','Recoverable artifact, not an event message.'),
152:('ลิงก์|นี้|มาจาก|เซิร์ฟเวอร์|อื่น ให้|เปลี่ยน|ไป|เซิร์ฟเวอร์|นั้น|ใน|ออนไลน์|ก่อน','minor','Instance means selected server; avoid unfamiliar split loanword and preserve required switch.'),
}
for index in [107,109,113,114,115,116,120,121,125,133,134,135,151,156]:
 text=whole(entries[index]['target']).replace('ตระกูล','ตระกูล\u200bอาคาร')
 fixes[index]=(text,'minor','Accept meaning refinement after checking BuildingLibraryScreen.cpp: these family-specific keys refer to building upgrade families.')
record('native-general-015',fixes)
