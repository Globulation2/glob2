from record_final import record
record('native-general-010',{
82:('หาก|ไม่|พบ|ผู้เล่น คุณ|จะ|เล่น|กับ AI ที่|เรตติ้ง|ใกล้|คุณ|ที่สุด|ใน|อีก %0','minor','%0 is wait duration, not region or rating range.'),
83:('หาก|ไม่|พบ|ผู้เล่น AI จะ|เข้าร่วม|ใน|อีก %0','minor','Keep เข้าร่วม verb whole, separate from following time preposition.'),
84:('หาก|ไม่|พบ|ผู้เล่น AI จะ|นั่ง|แทน|เมื่อ|ผ่าน|ไป %0','minor','Game seat fallback, not assuming an office position.'),
107:('เบื้องต้น','minor','Provisional rating is preliminary, not temporary expiry.'),
108:('✓ ตอบรับ|แล้ว','minor','Match actual Accept/Accepted control terminology.'),
150:('เบื้องต้น · %0 เกม','minor','Preliminary rating based on few games.'),
158:('เวลา|เกม|ปกติ','minor','Header describes typical match duration (median), not casual game mode.'),
})
