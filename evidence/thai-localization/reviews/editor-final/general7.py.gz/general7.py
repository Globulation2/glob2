import json
from pathlib import Path
from record_final import record,whole
entries=json.loads(Path('artifacts/thai-localization/round2/batches/native-general-007.json').read_text())['entries']
p94=whole(entries[94]['target']).replace('ป้อง|กันที่'.replace('|','\u200b'),'ป้องกัน|ที่'.replace('|','\u200b')).replace('เส้นทางการ|เสริมกำลัง'.replace('|','\u200b'),'เส้นทาง|การ|เสริมกำลัง'.replace('|','\u200b')).replace('ใช้|การตอบโต้|การป้องกัน|ใน|ท้องถิ่น'.replace('|','\u200b'),'ตอบโต้|เพื่อ|ป้องกัน|เป็น|จุดๆ'.replace('|','\u200b'))
record('native-general-007',{
45:('รางวัล|ตาม|แนว','minor','Rope is a generator-layout metaphor; avoid implying a literal rope object in game.'),
66:('พื้นที่|เพาะปลูก|ใจกลาง|ฐาน','minor','Colony homeland, not a real-world national interior.'),
94:(p94,'minor','Preserve profile meaning while repairing defense/per-unit-path boundaries and localized-defense wording.'),
})
