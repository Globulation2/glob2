from record_final import record
record('native-general-017',{
7:('รวมกำลัง|โต้กลับ','minor','Focused attack means concentrated force, consistent with requested small radius.'),
10:('รวมกำลัง|โต้กลับ','minor','Same title/marker wording.'),
17:('สร้าง → โรงเรียน มอบหมาย|คนงานก่อสร้าง|ไป|เก็บ|ไม้|และ|สาหร่าย','minor','Preserve builder role explicitly.'),
18:('สร้าง → โรงเรียน มอบหมาย|คนงานก่อสร้าง|ไป|เก็บ|ไม้|และ|สาหร่าย','minor','Same source instruction.'),
})
