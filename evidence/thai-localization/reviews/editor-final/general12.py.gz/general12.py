from record_final import record
record('native-general-012',{
77:('จบ|แมตช์|เมื่อ|แบบจำลอง|มี|ความมั่นใจ|ถึง|ระดับ|ที่|เลือก ผู้ชม|ดู|โอกาส|ชนะ|ที่|คาดการณ์|ได้|ใน|หน้า|สถิติ','minor','Statistics is a screen, not merely a statistical format; canonical match.'),
82:('พื้นที่','minor','Land-statistics group, not real-estate ownership.'),
107:('ปริมาณ|อาหาร|ที่|คนงาน|เก็บเกี่ยว|จาก|แหล่ง|ผลิต|อาหาร โรงเตี๊ยม|ใช้|อาหาร|เสิร์ฟ|เป็น|มื้อ','major','Material packets/amounts rather than a count of hauling trips; natural food-to-meals wording.'),
117:('ปริมาณ|วัสดุ|ทุกชนิด|ที่|คนงาน|เก็บเกี่ยว แยก|กราฟ|เพื่อ|ดู|แต่ละ|ชนิด','major','Avoid claiming material loads are number of worker trips.'),
123:('วัสดุ|ที่|คนงาน|ขน|เข้า|อาคาร','major','Quantity of delivered material, not trip count.'),
141:('ยูนิต|ใน|อาณานิคม|ที่|ถูก|ศัตรู|ฆ่า แยก|กราฟ|เพื่อ|ดู|คนงาน นักสำรวจ และ|นักรบ','minor','Remove stray space introduced during noun normalization and clarify split action.'),
147:('ระดับ|ทักษะ|ที่|ยูนิต|ใน|อาณานิคม|ได้|จาก|การ|ฝึก','minor','Remove stray space and use consistent training term.'),
})
