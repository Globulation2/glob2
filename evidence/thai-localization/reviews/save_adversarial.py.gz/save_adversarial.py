import json,hashlib
from pathlib import Path
ROOT=Path("artifacts/thai-localization")
def save(name,fixes,accepted={}):
 b=json.loads((ROOT/f"round2/batches/{name}.json").read_text()); es=b['entries'];values={e['id']:e['target'] for e in es}
 findings=[]
 for i,fix in fixes.items():
  proposed,reason,*severity=fix;findings.append({'id':es[i-1]['id'],'severity':severity[0] if severity else 'major','proposed':proposed,'reason':reason})
 r={'adversarial_reviewer':'thai_rendering','source_sha256':b['source_sha256'],'target_sha256':hashlib.sha256(json.dumps(values,sort_keys=True,ensure_ascii=False).encode()).hexdigest(),'adversarial_reviewed_keys':[e['id'] for e in es],'findings':findings,'accepted_english':[{'id':es[i-1]['id'],'reason':reason} for i,reason in accepted.items()],'method':'Read every immutable round2 source and target with soft boundaries shown visibly before consulting prior native findings. Checked meaning, Thai idiom, terminology, and word/cluster breaks; proposed corrections require independent recheck. Agent-reviewed; not native-human-certified.'}
 p=ROOT/f'reviews/adversarial/{name}.json';p.parent.mkdir(exist_ok=True);p.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(name,len(es),'read',len(findings),'findings')
