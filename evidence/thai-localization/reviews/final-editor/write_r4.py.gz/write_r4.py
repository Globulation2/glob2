import json,hashlib
from pathlib import Path
R=Path('artifacts/thai-localization');OUT=R/'reviews/final-editor'
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
nfresh=ncarry=0
for p in sorted((R/'round4-native/batches').glob('native-*.json')):
 d=json.loads(p.read_text());old=json.loads((R/'round3-native/batches'/p.name).read_text());priorpath=R/'reviews/final-editor-r3'/p.name;prior=json.loads(priorpath.read_text());fresh=[];carried=[];findings=[]
 assert prior['target_sha256']==digest({e['id']:e['target'] for e in old['entries']})
 for e,o in zip(d['entries'],old['entries']):
  assert e['id']==o['id'] and e['source']==o['source']
  assert e['changed_since_round3']==(e['target']!=o['target'])
  if e['changed_since_round3']:
   fresh.append(e['id'])
   if e['id']=='native:[lesson healing briefing]':findings.append({'id':e['id'],'severity':'minor','proposed':'สร้าง|โรงพยาบาล|และ|ช่วย|คนงาน|บาดเจ็บ|ให้|ฟื้นตัว เมื่อ|เริ่ม ยูนิต|ใน|อาณานิคม|กิน|อาหาร|อิ่ม|แล้ว และ|มี|คนงาน|บาดเจ็บ 1 ตัว'.replace('|','\u200b'),'reason':'State the fed initial condition naturally; เริ่มโดยกินอาหารแล้ว is awkward and can sound like an initial action rather than an existing state.','boundary_status':'explicit reviewed final hints; preserve verbatim'})
  else:
   assert e['id'] in prior['approved_keys'];assert e['target']==o['target'];carried.append(e['id'])
 blocked={f['id'] for f in findings}
 a={'editor':'cloud_adapter','source_sha256':d['source_sha256'],'target_sha256':digest({e['id']:e['target'] for e in d['entries']}),'approved_keys':[e['id'] for e in d['entries'] if e['id'] not in blocked],'fresh_reviewed_keys':fresh,'carried_keys':carried,'carried_subset_sha256':digest({e['id']:e['target'] for e in d['entries'] if e['id'] in carried}),'prior_record_sha256':hashlib.sha256(priorpath.read_bytes()).hexdigest(),'prior_target_sha256':prior['target_sha256'],'findings':findings,'accepted_english':prior['accepted_english'],'review_basis':'Freshly read all changed actual round4 values and frozen English. Carried only exact-equal entries individually approved in hash-bound round3 records. Agent editorial review, not native-human certification.','status':'changes-required' if findings else 'approved'}
 (OUT/p.name).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');nfresh+=len(fresh);ncarry+=len(carried)
print('fresh',nfresh,'exact prior-approved carries',ncarry)
