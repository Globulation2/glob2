import json,hashlib
from pathlib import Path
R=Path('artifacts/thai-localization');OUT=R/'reviews/final-editor'
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
nfresh=ncarry=napproved=0
for p in sorted((R/'round5-native/batches').glob('native-*.json')):
 d=json.loads(p.read_text());old=json.loads((R/'round4-native/batches'/p.name).read_text());priorpath=R/'reviews/final-editor-r4'/p.name;prior=json.loads(priorpath.read_text());fresh=[];carried=[]
 assert prior['target_sha256']==digest({e['id']:e['target'] for e in old['entries']})
 for e,o in zip(d['entries'],old['entries']):
  assert e['id']==o['id'] and e['source']==o['source']
  assert e['changed_since_round4']==(e['target']!=o['target'])
  if e['changed_since_round4']:
   assert e['id']=='native:[lesson healing briefing]'
   assert e['target']=='สร้าง|โรงพยาบาล|และ|ช่วย|คนงาน|บาดเจ็บ|ให้|ฟื้นตัว เมื่อ|เริ่ม ยูนิต|ใน|อาณานิคม|กิน|อาหาร|อิ่ม|แล้ว และ|มี|คนงาน|บาดเจ็บ 1 ตัว'.replace('|','\u200b')
   fresh.append(e['id'])
  else:
   assert e['id'] in prior['approved_keys'];assert e['target']==o['target'];carried.append(e['id'])
 a={'editor':'cloud_adapter','source_sha256':d['source_sha256'],'target_sha256':digest({e['id']:e['target'] for e in d['entries']}),'approved_keys':[e['id'] for e in d['entries']],'fresh_reviewed_keys':fresh,'carried_keys':carried,'carried_subset_sha256':digest({e['id']:e['target'] for e in d['entries'] if e['id'] in carried}),'prior_record_sha256':hashlib.sha256(priorpath.read_bytes()).hexdigest(),'prior_target_sha256':prior['target_sha256'],'findings':[],'accepted_english':prior['accepted_english'],'review_basis':'Freshly read the sole changed round5 actual healing briefing against English; idiom now naturally states units are already fed at lesson start and retains exactly one injured worker. Other entries carried only from individual round4 approvals after exact source/value equality and prior-record hash proof. Agent editorial review, not native-human certification.','status':'approved'}
 (OUT/p.name).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');nfresh+=len(fresh);ncarry+=len(carried);napproved+=len(a['approved_keys'])
print('batches25 fresh',nfresh,'carries',ncarry,'approved',napproved,'findings0')
