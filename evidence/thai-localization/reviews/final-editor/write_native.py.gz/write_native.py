import json,hashlib
from pathlib import Path
R=Path('artifacts/thai-localization');OUT=R/'reviews/final-editor'
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def fix(e):
 s=e['target'];t=s;reason='';severity='minor'
 if 'รักษาการณ์' in t:
  t=t.replace('รักษาการณ์','ป้องกัน');severity='major';reason='Guard UI must match canonical ป้องกัน and เขตป้องกัน; inconsistent instruction names misdirect tutorial interaction.'
 if 'พอร์\u200bเท\u200bจ' in t:
  t=t.replace('พอร์\u200bเท\u200bจ','พอร์เทจ');reason+=' Remove syllable-internal breaks in the proper generator name พอร์เทจ.'
 if e['source']=='Portage Lakes cannot fit a useful dry woodland shortcut on this seed.':
  t=t.replace('ป่า\u200bแห้ง','บน\u200bบก\u200bผ่าน\u200bป่า');severity='major';reason+=' Dry means a land shortcut through woodland, not arid forest. This restores the reviewed source-context correction.'
 if e['id']=='native:[select place guard area]':
  t='เลือก\u200bวาง\u200bเขต\u200bป้องกัน'
 if e['source']=='Health':
  t=t.replace('พลัง\u200bชีวิต','พลังชีวิต');reason+=' Preserve the canonical compound พลังชีวิต as one word.'
 if e['source']=='Use prepared skilled workers to upgrade a Racetrack and train beyond the first level.':
  t=t.replace('สนาม\u200bวิ่ง','สนามวิ่ง');reason+=' Keep the building term สนามวิ่ง unbroken.'
 if e['source'].startswith('Place an Exploration Flag at the enemy base; assign 1 explorer. Flags request'):
  t=t.replace('ธง\u200bสำรวจ','ธงสำรวจ');reason+=' Keep the named flag term ธงสำรวจ unbroken.'
 if t!=s:return {'id':e['id'],'severity':severity,'proposed':t,'reason':reason.strip(),'boundary_status':'explicit reviewed final hints; preserve verbatim'}
extra={
'native:[zoom factor %0]':'Language-neutral numeric zoom-factor placeholder and multiplication sign; no prose to translate.',
'native:[P %0/%1/%2]':'Compact technical P indicator with three numeric placeholders; preserve its designation and exact separators.',
'native:[CPU load %0]':'CPU is the standard processor abbreviation; the remaining text is only its numeric percentage placeholder.'}
count=0
for p in sorted((R/'round3-native/batches').glob('native-*.json')):
 d=json.loads(p.read_text());old=json.loads((R/'round2/batches'/p.name).read_text());assert len(d['entries'])==len(old['entries'])
 fresh=[];carried=[];findings=[];accepted=[]
 prior=json.loads((R/'reviews/editor-final'/p.name).read_text());reasons={e['id']:e['reason'] for e in prior['accepted_english']}
 for e,o in zip(d['entries'],old['entries']):
  assert e['id']==o['id'] and e['source']==o['source'] and e['round2_target']==o['target']
  assert e['changed_since_round2']==(e['target']!=o['target'])
  if e['changed_since_round2']:
   fresh.append(e['id']);f=fix(e)
   if f:findings.append(f)
  else:carried.append(e['id'])
  if e['target'] and e['target'].replace('\u200b','')==e['source']:
   reason=reasons.get(e['id'],extra.get(e['id']));assert reason,e['id'];accepted.append({'id':e['id'],'reason':reason})
 blocked={f['id'] for f in findings}
 a={'editor':'cloud_adapter','source_sha256':d['source_sha256'],'target_sha256':digest({e['id']:e['target'] for e in d['entries']}),'approved_keys':[e['id'] for e in d['entries'] if e['id'] not in blocked],'fresh_reviewed_keys':fresh,'carried_keys':carried,'carried_subset_sha256':digest({e['id']:e['target'] for e in d['entries'] if e['id'] in carried}),'findings':findings,'accepted_english':accepted,'review_basis':'Freshly read every changed actual round3 target against frozen English source including edited wording, reconciled alternatives, technical terminology and explicit word boundaries. Other entries carried only after exact source/target equality with already-read round2. This is agent editorial review, not native-human certification.','status':'changes-required' if findings else 'approved'}
 (OUT/p.name).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');count+=len(findings)
print('25 batches; 575 freshly read; 2818 exact carries; findings',count)
