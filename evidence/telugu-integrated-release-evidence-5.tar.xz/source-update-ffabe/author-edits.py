import json,hashlib
from pathlib import Path
U=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
p=U/'drafts/te/te.json';t=load(p);before=dict(t)
edits={
'Rush':'తొలి దాడి','Defensive':'రక్షణాత్మకం','Economy':'ఆర్థిక వ్యవస్థ','Experimental':'ప్రయోగాత్మకం','Beginner-friendly':'ప్రారంభకులకు అనుకూలం',
'Startup and callback':'ప్రారంభం మరియు కాల్‌బ్యాక్','Persistent state':'నిల్వ ఉండే స్థితి','Seeded gameplay':'సీడ్ ఆధారిత ఆట','Repeatable simulation':'పునరుత్పత్తి చేయగల అనుకరణ',
'Fair':'ఒక మోస్తరు','Poor':'బలహీనం',
'Round trip between a player and the relay. Before a match (quick match, start checklist) it is a probe of the region, an estimate.':'ఆటగాడి నుంచి రిలేకు వెళ్లి తిరిగి రావడానికి పట్టే సమయం. మ్యాచ్‌కు ముందు (త్వరిత మ్యాచ్, ప్రారంభ తనిఖీ జాబితాలో) ఇది ఆ ప్రాంతానికి చేసిన పరీక్ష ఆధారంగా వేసిన అంచనా.',
'Your input delay: from your click until it happens, for everyone. Half your ping plus the buffer your game holds against jitter.':'మీ ఇన్‌పుట్ ఆలస్యం: మీరు క్లిక్ చేసినప్పటి నుంచి ఆ చర్య అందరి గేమ్‌లలో అమలయ్యే వరకు పట్టే సమయం. ఇది మీ పింగ్‌లో సగంతో పాటు నెట్‌వర్క్ ఆలస్యంలోని హెచ్చుతగ్గులను తట్టుకోవడానికి మీ గేమ్ ఉంచే అదనపు సమయం.',
'How far a player’s game runs behind the match clock. Under a second is normal (it includes their delay); the relay marks a player slow from 2 s.':'ఆటగాడి గేమ్ మ్యాచ్ గడియారం కంటే ఎంత వెనుకబడి ఉందో చూపిస్తుంది. ఒక సెకను కంటే తక్కువ ఉండటం సాధారణం (ఇందులో వారి ఇన్‌పుట్ ఆలస్యం కూడా ఉంటుంది); 2 సెకన్ల నుంచి ఆ ఆటగాడిని రిలే నెమ్మదిగా ఉన్నట్లు గుర్తిస్తుంది.',
'Classic glossy':'సాంప్రదాయ మెరుపు','Matte':'మెరుపులేని పూత','Riveted metal':'రివెట్లు అమర్చిన లోహం','Hairy':'వెంట్రుకలతో','Organic':'జీవరూపాలు','Oozy goo':'జారే జిగురు','Scales':'పొలుసులు','Crystal':'స్ఫటికం','Cloud':'మేఘం','AI player':'AI ఆటగాడు','Finances':'ఆర్థిక వివరాలు',
'Listen for the musical structure and development.':'సంగీత నిర్మాణాన్ని, అది క్రమంగా సాగే తీరును వినండి.',
'Check that all three moods play correctly.':'మూడు సంగీత వాతావరణాలూ సరిగ్గా వినిపిస్తున్నాయో తనిఖీ చేయండి.',
'Listen for unexpected jumps in volume between moods.':'సంగీత వాతావరణాలు మారినప్పుడు శబ్ద తీవ్రత అనుకోకుండా మారుతుందేమో వినండి.',
'Listen for a click, gap, or abrupt change when the loop repeats.':'సంగీతం మళ్లీ మొదలైనప్పుడు క్లిక్ శబ్దం, విరామం లేదా ఆకస్మిక మార్పు ఉందేమో వినండి.',
'Listen for short phrases that repeat too mechanically.':'చిన్న సంగీత భాగాలు మరీ యాంత్రికంగా పునరావృతమవుతున్నాయేమో వినండి.',
'Switch moods and listen for changes in timing or harmony.':'సంగీత వాతావరణాలను మార్చి, లయలో లేదా స్వర సమన్వయంలో మార్పులు ఉన్నాయేమో వినండి.',
'Check that building and combat feel distinct from calm.':'నిర్మాణం, పోరాటం సంగీతాలు ప్రశాంతం సంగీతానికి భిన్నంగా అనిపిస్తున్నాయో తనిఖీ చేయండి.',
'Listen for hiss or scratchiness in quiet passages.':'నెమ్మదిగా వినిపించే భాగాల్లో బుసబుస లేదా గరగర శబ్దం ఉందేమో వినండి.',
'Listen for muddy bass or harsh high frequencies.':'తక్కువ పౌనఃపున్యాల స్వరాలు అస్పష్టంగా ఉన్నాయా, ఎక్కువ పౌనఃపున్యాల స్వరాలు కటువుగా ఉన్నాయా వినండి.',
'Check that calm passages remain audible alongside game sound.':'గేమ్ శబ్దాలతో పాటు ప్రశాంతమైన సంగీత భాగాలు కూడా వినిపిస్తున్నాయో తనిఖీ చేయండి.',
'Swarm':'గూడు','Clutch':'గుడ్ల గుంపు','Coral':'పగడం','Skep':'చుట్టల తేనెపట్టు','Bloom':'వికసించిన పువ్వు',
'A broad-capped toadstool with young caps.':'వెడల్పాటి టోపీ గల పుట్టగొడుగు, దాని చుట్టూ చిన్న పుట్టగొడుగులు.',
'A coiled hive on a stand, its door facing you.':'ఆధారంపై ఉన్న చుట్టల తేనెపట్టు, దాని ద్వారం మీ వైపు ఉంటుంది.',
'Public: listed in the catalog':'బహిరంగం: కేటలాగ్‌లో కనిపిస్తుంది','Unlisted: anyone with the link':'జాబితాలో లేదు: లింక్ ఉన్నవారికి అందుబాటు','Private: only you':'ప్రైవేట్: మీకు మాత్రమే',
'The server replayed this match and every player’s game agreed with it.':'సర్వర్ ఈ మ్యాచ్‌ను మళ్లీ నడిపింది. ప్రతి ఆటగాడి గేమ్ స్థితి దానితో సరిపోలింది.',
'A player’s game disagreed with the server’s replay of the match; the server’s result counts.':'ఒక ఆటగాడి గేమ్ స్థితి సర్వర్ మళ్లీ నడిపిన మ్యాచ్‌తో సరిపోలలేదు; సర్వర్ ఫలితమే పరిగణించబడుతుంది.',
'The server could not reproduce this match, so it changes no rating.':'సర్వర్ ఈ మ్యాచ్‌ను తిరిగి అదే విధంగా నడపలేకపోయింది. అందువల్ల రేటింగ్‌లు మారవు.',
'Harvest':'సేకరణ','Fly':'ఎగరడం','Live payments':'నిజమైన చెల్లింపులు','Test payments':'పరీక్ష చెల్లింపులు','Current period':'ప్రస్తుత కాలవ్యవధి','Previous period':'మునుపటి కాలవ్యవధి','Credit grant':'క్రెడిట్‌ల కేటాయింపు','Returned credits':'వాపసు చేసిన క్రెడిట్‌లు','Matches started':'ప్రారంభమైన మ్యాచ్‌లు','Matches completed':'పూర్తయిన మ్యాచ్‌లు','Matches cancelled':'రద్దయిన మ్యాచ్‌లు',
'{value0} publications':'{value0} ప్రచురణలు','{value0} recorded downloads':'{value0} నమోదైన డౌన్‌లోడ్‌లు','{value0} completion time (seconds)':'{value0} పూర్తి చేయడానికి పట్టిన సమయం (సెకన్లు)','{value0} completion samples':'{value0} పూర్తయిన పనుల సమయ కొలతలు',
'Apply to {slot0}':'వర్తింపజేయండి: {slot0}'
}
t.update(edits);write(p,t)
write(U/'author-initial-edits.json',{'author':'/root','changes':[{'key':k,'before':before[k],'after':v} for k,v in edits.items() if before[k]!=v],'reviewed_new_keys':list(load(U/'online-english-delta.json')['adds']),'method':'Read all111 raw Google entries and actual source-context reports. Correct semantic errors and align existing gameplay glossary/music mood terms; neutral dynamic Apply template avoids suffix agreement on inserted translated role names. Independent final reviews pending.'})
print('author edits',sum(before[k]!=v for k,v in edits.items()),'online hash',hashlib.sha256(p.read_bytes()).hexdigest())
