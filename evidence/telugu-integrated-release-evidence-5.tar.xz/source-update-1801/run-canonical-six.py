from pathlib import Path
import argparse,concurrent.futures,datetime,hashlib,json,os,shutil,socket,subprocess
A=argparse.ArgumentParser();A.add_argument('package',type=Path);A.add_argument('--provenance',required=True,type=Path);A.add_argument('--expected-head',required=True);a=A.parse_args();R=Path.cwd();P=R/'artifacts/localization-telugu/source-update-1801';O=P/'browser-canonical-final';O.mkdir(exist_ok=False);package=a.package.resolve();producer=json.loads(a.provenance.read_text());assert producer['revision']==a.expected_head and producer['sim_revision']==112 and producer['exit_code']==0;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify_package():
 for f in producer['files']:
  p=(package/f['path']).resolve();assert p.is_relative_to(package) and p.stat().st_size==f['bytes'] and sha(p)==f['sha256'],f['path']
verify_package();sources=['browser/tests/determinism.spec.js','browser/tests/runtime-host.js','browser/tests/compiled-case-inventory.js','browser/playwright.config.js','browser/serve.py','test/fixtures/multiplayer/FourSquares1.g2mr','test/fixtures/multiplayer/FourSquares1.verify-trace.txt','maps/FourSquares1.map.gz'];inputs={p:sha(R/p) for p in sources};assert inputs['test/fixtures/multiplayer/FourSquares1.g2mr']=='4727542adcd04b76c741881ec614ad08a00c6e97ee3618e4e0b78fb704bf65e7';assert inputs['test/fixtures/multiplayer/FourSquares1.verify-trace.txt']=='5a843636b78375d3233d6623bd33cc96a5a5f9c3a18a60443e52515c3de7c56c';started=datetime.datetime.now(datetime.timezone.utc).isoformat();node=Path('/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin');(O/'preflight.json').write_text(json.dumps({'actual_producer':producer['revision'],'producer_provenance_sha256':sha(a.provenance),'source_inputs':inputs,'fixture_scope':'Canonical match only; no stale replay/Studio/generator fixtures','started_utc':started},indent=2)+'\n')
def run(browser):
 B=O/browser;B.mkdir();S=B/'test-source';overlay=B/'http-overlay';overlay.mkdir()
 for f in package.iterdir():(overlay/f.name).symlink_to(f,target_is_directory=f.is_dir())
 for f in sources:
  dest=S/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/f,dest);assert sha(dest)==inputs[f]
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 config=B/'playwright.config.cjs';config.write_text('const original=require('+json.dumps(str(R/'browser/playwright.config.js'))+');module.exports={...original,testDir:'+json.dumps(str(S/'browser/tests'))+',testMatch:"determinism.spec.js",outputDir:'+json.dumps(str(B/'test-results'))+',reporter:[["list"],["json",{outputFile:'+json.dumps(str(B/'results.json'))+'}]],webServer:undefined};\n')
 env=dict(os.environ,PATH=str(node)+':'+os.environ['PATH'],NODE_PATH=str(R/'platform/node_modules'),GLOB2_TEST_URL=f'http://127.0.0.1:{port}',GLOB2_TEST_BUILD_DIR=str(overlay),CI='1');servercmd=['python3',str(S/'browser/serve.py'),str(port),'--bind','127.0.0.1','--directory',str(overlay)];command=[str(node/'node'),str(R/'platform/node_modules/@playwright/test/cli.js'),'test','--config',str(config),'--project',browser,'--grep','verifies the committed match record'];(B/'command.json').write_text(json.dumps({'command':command,'server':servercmd,'actual_producer':producer['revision'],'test_source':'Exact maintained spec/helpers/fixtures; no assertion or timeout edits; private output roots prevent cross-browser overwrites.'},indent=2)+'\n')
 with (B/'server.log').open('w') as serverlog,(B/'tests.log').open('w') as log:
  server=subprocess.Popen(servercmd,stdout=serverlog,stderr=subprocess.STDOUT)
  try:
   import time
   for _ in range(100):
    assert server.poll() is None
    try:
     with socket.create_connection(('127.0.0.1',port),timeout=.1):break
    except OSError:time.sleep(.05)
   else:raise RuntimeError('Private maintained HTTP server did not start')
   result=subprocess.run(command,env=env,cwd=S,stdout=log,stderr=subprocess.STDOUT)
  finally:server.terminate();server.wait(timeout=10)
 j=json.loads((B/'results.json').read_text());return {'browser':browser,'exit_code':result.returncode,'report_sha256':sha(B/'results.json'),'stats':j['stats']}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:runs=list(pool.map(run,['chromium','firefox','webkit']))
verify_package();assert inputs=={p:sha(R/p) for p in inputs};passed=all(x['exit_code']==0 and x['stats']['expected']==2 and x['stats']['unexpected']==0 for x in runs);(O/'verification.json').write_text(json.dumps({'actual_producer':producer['revision'],'actual_fixture_source':'current committed canonical match at75f468','source_inputs':inputs,'package_unchanged':True,'test_inputs_unchanged':True,'runs':runs,'pass':passed,'actual_cases':sum(r['stats']['expected']+r['stats']['unexpected'] for r in runs),'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Six existing maintained canonical match tests, three independent browser batches, serial/threaded each. Every observed per-tick trace must equal committed native reference exactly; no matching-order-only inference.'},indent=2)+'\n');print(json.dumps({'pass':passed,'runs':runs}));raise SystemExit(0 if passed else 1)
