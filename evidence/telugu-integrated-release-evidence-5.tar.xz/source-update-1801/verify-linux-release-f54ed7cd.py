from pathlib import Path
import ctypes,hashlib,json,os,subprocess
ROOT=Path.cwd();P=ROOT/'artifacts/localization-telugu';S=P/'linux-release-stage/usr/local';B=S/'bin/glob2';A=S/'share/glob2';L=S/'lib/glob2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();REV=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert REV=='f54ed7cd3913b95beb9f92bb0162260c2bc3a323';assert not subprocess.check_output(['git','status','--porcelain']).strip();assert sha(B)==sha(ROOT/'build/linux/client/release/src/glob2')
state=json.loads((P/'native-release-smoke/state.json').read_text());assert state['staging']['binary_sha256']==sha(B)
processes=[]
for proc in Path('/proc').glob('[0-9]*'):
 try:
  if (proc/'exe').resolve()!=B:continue
  env=dict(x.split(b'=',1) for x in (proc/'environ').read_bytes().split(b'\0') if b'=' in x)
  if env.get(b'GLOB2_USER_DATA_DIR',b'').decode()!=state['profile']:continue
  assert b'LD_LIBRARY_PATH' not in env and env[b'SDL_PREFERRED_LOCALES']==b'en_US';assert (proc/'cwd').resolve()==A
  libraries=sorted({line.split()[-1] for line in (proc/'maps').read_text().splitlines() if '/libSDL3' in line})
  assert libraries and all(Path(x).parent.resolve()==L for x in libraries)
  processes.append({'pid':int(proc.name),'executable_sha256':sha(B),'cwd':str(A),'system_preference':'en_US','LD_LIBRARY_PATH_absent':True,'loaded_bundled_libraries':[{'path':x,'sha256':sha(Path(x))} for x in libraries]})
 except (FileNotFoundError,PermissionError,ProcessLookupError):continue
assert len(processes)==1
manifest=json.loads((A/'data/fonts/scripts/manifest.json').read_text());checks=[]
for item in manifest['fonts']:
 name='data/fonts/scripts/'+item['name']+'-Regular.ttf';assert sha(A/name)==item['sha256'];checks.append({'path':name,'sha256':sha(A/name),'bytes':(A/name).stat().st_size})
for name in ['data/texts.te.txt','data/texts.list.txt','data/fonts/scripts/manifest.json','data/fonts/LICENSE-Noto.txt','data/fonts/LICENSE-HarfBuzz.txt']:
 assert sha(A/name)==sha(ROOT/name);checks.append({'path':name,'sha256':sha(A/name),'bytes':(A/name).stat().st_size})
raw=(P/'native-release-smoke/profile/preferences.txt').read_bytes();raw.decode();assert b'language=te\n' in raw;assert 'username=తెలుగు\n'.encode() in raw
lib=ctypes.CDLL(str(L/'libSDL3_ttf.so.0'));v=[ctypes.c_int() for _ in range(3)];lib.TTF_GetHarfBuzzVersion(*(ctypes.byref(x) for x in v));assert [x.value for x in v]==[10,1,0]
env=dict(os.environ);env.pop('LD_LIBRARY_PATH',None);deps=subprocess.check_output(['ldd',str(B)],env=env,text=True);assert 'not found' not in deps;(P/'source-update-1801/linux-release-f54ed7cd-ldd.txt').write_text(deps)
rpath=subprocess.check_output(['readelf','-d',str(B)],text=True);rpaths=[x for x in rpath.splitlines() if 'RUNPATH' in x or 'RPATH' in x];assert len(rpaths)==1 and '[$ORIGIN/../lib/glob2]' in rpaths[0]
version=subprocess.run([str(B),'info','version','--format','json'],cwd=A,env=env,capture_output=True,text=True,check=True);(P/'source-update-1801/linux-release-f54ed7cd-version.txt').write_text(version.stdout)
images=[]
for file in sorted((P/'native-release-smoke').glob('u8-release-*.png')):images.append({'path':str(file.relative_to(P)),'sha256':sha(file)})
result={'result':'optimized Linux release localization closure and real native UI passed','source_revision':REV,'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'binary':str(B),'binary_sha256':sha(B),'binary_bytes':B.stat().st_size,'compiler':subprocess.check_output(['g++','-dumpfullversion'],text=True).strip(),'recipe':'tools/dev_build.py dev_fast=0 release=1 linker=default -j10 INSTALLDIR=<stage>/usr/local/share BINDIR=<stage>/usr/local/bin DATADIR=/usr/local/share install translation-preview-harness; normal final-source reconciliation after graceful consolidation; identical production objects shared with optimized capture harness','flags':'-O3 -s; dev_fast/PCH/unity disabled','rpath':rpaths,'release_identity':json.loads((ROOT/'build/linux/client/release/identity.json').read_text()),'asset_checks':checks,'harfbuzz':[x.value for x in v],'actual_process':processes[0],'ui_checks':['Real optimized GUI restored saved Telugu on new process with English system preference and no username override.','Real text-field accepted the valid18-byte Telugu name, then rejected the entire37-byte oversized replacement and preserved the previous saved value; preferences strictly decode asUTF8.','Actual optimized GUI switched te→en→te with Telugu name retained and readable.'],'screenshots':images,'limits':'Staged install tree run from its packaged asset root, not a globally installed distro package. Linux/Xvfb Software backend; no performance or other native-OS UI claim. Oversized native edit rejected intact per current inherited policy. Browser complete-grapheme prefix is checked separately. Native serializers/loaders and protocol byte limit unchanged.'}
(P/'source-update-1801/linux-release-final-f54ed7cd-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('PASS optimized Linux package +18font/catalog/licence hashes +bundled runtime +actualTe typing/switch/restart')
