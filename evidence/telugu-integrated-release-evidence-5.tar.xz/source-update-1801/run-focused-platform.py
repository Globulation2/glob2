from pathlib import Path
import subprocess,json,os,hashlib,datetime
R=Path.cwd();P=R/'artifacts/localization-telugu/source-update-1801';O=P/'platform-final';O.mkdir(exist_ok=False)
expected=os.environ['TELUGU_FINAL_HEAD'];head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head==expected;assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
files=subprocess.check_output(['git','ls-files','-z','platform'],text=True).split('\0');sha=lambda b:hashlib.sha256(b).hexdigest();inputs={f:sha((R/f).read_bytes()) for f in files if f and (R/f).is_file()};(O/'platform-source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
node=Path('/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin');env=dict(os.environ,PATH=str(node)+':'+os.environ['PATH'],CI='1',GLOB2_DESIGN_SYSTEM_SHA='220b965b061e402df7531fa0f9ad5104bf29a638');cpus=sorted(os.sched_getaffinity(0))[:4];prefix=['taskset','-c',','.join(map(str,cpus))];commands=[['npm','run','lint'],['npm','run','typecheck'],['npm','run','i18n:check'],['npm','test','--','apps/web/test/teluguMetadata.test.tsx'],['npm','exec','-w','@glob2/web','--','vite','build']];results=[]
for i,cmd in enumerate(commands,1):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (O/(str(i).zfill(2)+'.log')).open('w') as log: result=subprocess.run(prefix+cmd,cwd=R/'platform',env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':prefix+cmd,'exit_code':result.returncode,'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});(O/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(i,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
assert inputs=={f:sha((R/f).read_bytes()) for f in inputs},'Platform source changed during execution'
(O/'verification.json').write_text(json.dumps({'actual_producer':head,'status':'PASS','commands':results,'platform_inputs_sha256':sha((O/'platform-source-inputs.json').read_bytes()),'node':subprocess.check_output([str(node/'node'),'--version'],text=True).strip(),'limits':'Focused final execution; not a fresh full1193-test suite. Prior full suite evidence carries only exact unchanged components, recorded separately.'},indent=2)+'\n')
