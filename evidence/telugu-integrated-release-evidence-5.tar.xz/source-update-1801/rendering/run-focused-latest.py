#!/usr/bin/env python3
"""Capture only newly added Telugu strings and changed UI contexts, with guards."""
import argparse,concurrent.futures,hashlib,json,os,pathlib,signal,subprocess,time,shutil
ROOT=pathlib.Path(__file__).resolve().parents[4]
BASE=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--binary',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--revision',required=True);a=p.parse_args()
B=a.binary.resolve();OUT=a.output.resolve();REV=a.revision;LIMIT=512*1024**2
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={str(p):sha(p) for p in [ROOT/'data/texts.en.txt',ROOT/'data/texts.te.txt',ROOT/'platform/packages/i18n/locales/te.json',ROOT/'src/game/screens/EndGameScreen.cpp',ROOT/'src/team/stats/TeamStatChart.cpp',ROOT/'src/team/stats/MetricCatalog.cpp',ROOT/'tools/TranslationPreviewHarness.cpp']}
for d in ['matrix-overlay','full-overlay']:
 for p in (BASE/d).glob('*.json'):inputs[str(p)]=sha(p)
overlay_snapshots={}
binarysha=sha(B)
meta=json.loads((BASE/'full-overlay/metadata.json').read_text());matrix=json.loads((BASE/'matrix-overlay/native.json').read_text());assert len(matrix)==1 and meta['native_entries']==3412;assert meta['requested_producer_revision']==REV;assert meta['canonical_native_catalog_sha256']==sha(ROOT/'data/texts.te.txt');assert meta['canonical_online_catalog_sha256']==sha(ROOT/'platform/packages/i18n/locales/te.json')
def guard():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==REV
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
 assert all(sha(pathlib.Path(p))==h for p,h in inputs.items())
 assert all(sha(OUT/p)==h for p,h in overlay_snapshots.items())
guard();assert not OUT.exists();assert os.statvfs(OUT.parent).f_bavail*os.statvfs(OUT.parent).f_frsize>1024**3;OUT.mkdir()
for name in ['matrix-overlay','full-overlay']:
 shutil.copytree(BASE/name,OUT/'overlays'/name)
 for p in (OUT/'overlays'/name).glob('*.json'):
  assert sha(p)==sha(BASE/name/p.name)
  overlay_snapshots[str(p.relative_to(OUT))]=sha(p)
cases=[('matrix',640,960,None,False),('matrix',1280,960,None,False),('screen',800,600,'lobby',False),('screen',390,844,'lobby',True)]
for w,h,c in [(1280,800,False),(800,600,False),(390,844,True)]:cases.append(('screen',w,h,'lobby-players',c))
cases += [('game',800,600,'tutorial:swimming',False),('game',390,844,'ingame-statistics:overview',True)]
results=[]
def save():
 (OUT/'run.json').write_text(json.dumps({'phase':'latest-1801-integration','revision':REV,'binary':str(B),'binary_sha256':binarysha,'input_sha256':inputs,'frozen_overlay_sha256':overlay_snapshots,'runner_sha256':sha(pathlib.Path(__file__)),'budget_bytes':LIMIT,'planned_cases':len(cases),'results':sorted(results,key=lambda x:x['index']),'limits':['One newly reviewednativekey12tuplematrix; earlier exactsource/targetfontmatrixproofs carried through unchangedfontinputs and verifiednormalwrapalgorithm, not freshfullcatalogclaim.','Actual maplobby800/390, playerslobby3sizes/newallAIlabel, swimming800mandatoryrealmodalROI, onecompactoverviewforcurrentproductionstatisticsHostadapter.','Root independently verifies actualnewnativewhole-editrejectinput contract; browseragent owns actualnew40locales6startup/compatibility packages.','Compactlayoutisdesktopengine,notAndroiddeviceproof.']},indent=2)+'\n')
def run(i,c):
 mode,w,h,name,compact=c;guard();label=f'{i:02d}-{mode}-{w}x{h}-'+(name or 'reviewed-new-keys');label=label.replace(':','-');out=OUT/label;overlay=OUT/'overlays'/('matrix-overlay' if mode=='matrix' else 'full-overlay');env=dict(os.environ,SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='x11',GLOB2_USER_DATA_DIR=str(OUT/'profiles'/label),LP_NUM_THREADS='2',LD_LIBRARY_PATH=str(ROOT/'artifacts/localization-telugu/rendering/sdl-prefix/lib'));env.pop('WAYLAND_DISPLAY',None);env.pop('GLOB2_MOBILE_UI',None)
 if compact:env['GLOB2_MOBILE_UI']='1'
 cmd=['xvfb-run','-a','-s',f'-screen 0 {max(w,1280)}x{max(h,960)}x24',str(B),mode,str(ROOT),str(overlay),str(out),str(w),str(h)]+([name] if name else [])
 start=time.time()
 with (OUT/(label+'.log')).open('wb') as log:
  proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=proc.wait(timeout=600)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGTERM);proc.wait();rc=124
 proofs=[]
 if rc==0:
  for report in out.glob('*.json'):
   v=json.loads(report.read_text())
   if isinstance(v,dict) and 'evidence_identity' in v:proofs.append(v['evidence_identity']['producer'])
  assert proofs and all(v['revision']==REV and not v['dirty'] for v in proofs)
  guard();assert sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())<=LIMIT
 return {'index':i,'command':cmd,'compact':compact,'returncode':rc,'seconds':time.time()-start,'report_producers':proofs}
save()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,i,c) for i,c in enumerate(cases)]
 for f in concurrent.futures.as_completed(futures):
  v=f.result();results.append(v);save();print(v['index'],v['returncode'],round(v['seconds'],1),flush=True)
assert len(results)==len(cases) and all(v['returncode']==0 for v in results),'Failures retained, not passed'
assert sha(B)==binarysha;guard()
