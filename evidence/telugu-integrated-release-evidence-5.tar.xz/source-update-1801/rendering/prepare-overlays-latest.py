#!/usr/bin/env python3
from pathlib import Path
import argparse,subprocess,hashlib,json
B=Path(__file__).resolve().parent;ROOT=B.parents[3];p=argparse.ArgumentParser();p.add_argument('--revision',required=True);a=p.parse_args();REV=a.revision
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==REV;assert not subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True).strip()
A=json.loads((B.parent/'author-one-key.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();nativepath=ROOT/'data/texts.te.txt';onlinepath=ROOT/'platform/packages/i18n/locales/te.json';assert sha(nativepath)==A['catalog_sha256']['native'];assert sha(onlinepath)==A['catalog_sha256']['online'];lines=nativepath.read_text().splitlines();assert len(lines)%2==0;native=dict(zip(lines[::2],lines[1::2]));online=json.loads(onlinepath.read_text());assert len(native)==3412 and len(online)==2947;e=A['entries'][0];assert native[e['key']]==e['target'];meta={'locale':'te','requested_producer_revision':REV,'combined_frozen_source_sha256':A['source_sha256'],'canonical_native_catalog_sha256':sha(nativepath),'canonical_online_catalog_sha256':sha(onlinepath),'native_entries':3412,'online_entries':2947,'scope':'Actual latest1801 integrated input; one approvednativekey12tupledelta, no syntheticUI; oldC1proofshistorical.'}
for name,n,o in [('matrix-overlay',{e['key']:e['target']},{}),('full-overlay',native,online)]:
 d=B/name;assert not d.exists();d.mkdir();(d/'native.json').write_text(json.dumps(n,ensure_ascii=False,indent=2)+'\n');(d/'online.json').write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n');(d/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print('Prepared3412native/2947online full +1native delta at',REV)
