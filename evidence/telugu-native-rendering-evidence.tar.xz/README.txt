Telugu native rendering and optimized Linux checkpoint
PR https://github.com/Globulation2/glob2/pull/1321
Current source e523af179adaa35c4271e08d5647298e0d935814

Unpack the original linguistic/online packet first, then this checkpoint; later final-release evidence supersedes current reviews/te.json readiness status. Exact actual producers remain inside every report: unchanged static catalog/font/UI evidence was produced at 33d9; corrected input, 64 focused tests and optimized Linux GUI were produced at e523. No old executable is relabeled as fixed.

All 107 native real-screen PNGs, both exhaustive 75,072-sample matrix reports, all 14 independently viewed matrix sample PNGs and root spot samples are included. Other matrix page PNGs remain local artifacts; every page was not manually inspected.

Raw credentials/API responses/SDKs/lease tokens/binaries are excluded. Google conservative reservation remains US$4.84862 of US$9, recorded in the original packet. This is agent-reviewed, not native-human-certified. Android and browser final changed-code release/startup gates remain pending in this checkpoint.
