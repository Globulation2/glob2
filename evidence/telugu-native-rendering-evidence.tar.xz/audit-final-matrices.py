from pathlib import Path
import collections,hashlib,json,unicodedata
P=Path(__file__).resolve().parent;REV='33d9ba37390a5e132378c4af8b32635bb30b49e4';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path('data/texts.te.txt'))=='b26cbf0fb0837ed0f25ae0c0496fcb4fd16ecaa1e65416311c9a9c6b5153829b'
assert sha(Path('platform/packages/i18n/locales/te.json'))=='40b14cffd14c76cd5d4bb76c9b50b38c4fe548e7322bb1806a64d7d0318dca42'
lines=Path('data/texts.te.txt').read_text().splitlines();assert len(lines)%2==0
native=dict(zip(lines[::2],lines[1::2]));online=json.loads(Path('platform/packages/i18n/locales/te.json').read_text());expected={('native',k,''):v for k,v in native.items()}
for k,v in online.items():
 if isinstance(v,str):expected[('online',k,'')]=v
 else:
  for branch,text in v.items():expected[('online',k,branch)]=text
old_path=P/'reviews/root-font-matrix-audit.json';old=json.loads(old_path.read_text());results=[]
for directory in sorted((P/'rendering/final-native-33d9ba37').glob('*matrix*-all')):
 file=directory/'font-matrix.json';assert file.is_file();digest=sha(file);d=json.loads(file.read_text());identity=d['evidence_identity'];assert identity['producer']['revision']==REV and not identity['producer']['dirty'] and identity['locale']=='te';assert d['native_keys_overridden']==3393 and d['harfbuzz']==[10,1,0]
 assert 'artifacts/localization-telugu/rendering/sdl-prefix/' in identity['sdl_ttf_library_path']
 previous=next((x for x in old['completed_widths'] if x['sha256']==digest),None)
 if previous:
  result=dict(previous);result['coverage_reused_from_unchanged_report_sha256']=digest
 else:
  seen=collections.Counter((x['surface'],x['key'],x['branch'],x['size'],x['scale']) for x in d['samples']);want={(a,b,c,size,scale) for a,b,c in expected for size in (10,13,20) for scale in (1,2)};assert set(seen)==want and set(seen.values())=={1}
  assert all(x['has_glyphs'] and all(y['drawn_fits_width'] and y['drawn_fits_height'] for y in x['lines']) for x in d['samples'])
  mismatch=[]
  for x in d['samples']:
   original=expected[(x['surface'],x['key'],x['branch'])];drawn=''.join(y['text'] for y in x['lines'])
   if ''.join(original.split())!=''.join(drawn.split()):mismatch.append((x['surface'],x['key'],x['size'],x['scale']))
  assert not mismatch
  result={'report':str(file.relative_to(P)),'sha256':digest,'width':d['logical_width'],'samples':len(d['samples']),'native_keys':len(native),'online_keys':len(online),'online_leaves':len(expected)-len(native),'all_key_branch_size_scale_tuples_exactly_once':True,'missing_glyphs':0,'drawn_width_failures':0,'drawn_height_failures':0,'nonwhitespace_content_mismatches':0}
 starts=[(x['surface'],x['key'],y['text']) for x in d['samples'] for y in x['lines'] if y['text'].lstrip() and (unicodedata.category(y['text'].lstrip()[0]).startswith('M') or y['text'].lstrip()[0] in '\u200c\u200d')];assert not starts
 result.update(lines_starting_with_combining_mark_or_joiner=0,clean_producer=REV,harfbuzz=d['harfbuzz'],private_sdl_runtime_verified=True);results.append(result)
assert len(results)==2 and sum(x['samples'] for x in results)==75072
out={'reviewer':'/root','source_revision':REV,'completed_widths':results,'expected_widths':[640,1280],'complete':True,'total_samples':75072,'limits':'Raw raster diagnostics differ from the complete bitmap destination drawn by production. Character conservation ignores whitespace only. Word-final Telugu virama in loanwords is valid, not itself a cluster failure. Actual page sampling is recorded separately; no manual-all-pages claim.'};old_path.write_text(json.dumps(out,indent=2)+'\n');print('PASS:75,072 exact samples; zero missing glyphs, drawn extent failures, character loss or mark/joiner line starts.')
