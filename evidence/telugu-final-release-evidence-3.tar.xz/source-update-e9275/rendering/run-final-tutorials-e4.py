#!/usr/bin/env python3
"""Final actual tutorial screenshots, bounded and isolated; no simulation mutations."""
import argparse,concurrent.futures,hashlib,json,os,pathlib,shutil,signal,subprocess,threading,time
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[3]
p=argparse.ArgumentParser();p.add_argument('--revision',required=True);p.add_argument('--binary',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();REV=a.revision;B=a.binary.resolve();OUT=a.output.resolve();LIMIT=512*1024**2;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert REV=='a43402ce84d4a111b7c55cc98da128ddaf8fb1b0';assert not OUT.exists()
meta=json.loads((BASE/'full-overlay-e4/metadata.json').read_text());assert meta['requested_producer_revision']==REV and meta['native_entries']==3411
assert sha(ROOT/'data/texts.te.txt')==meta['canonical_native_catalog_sha256']=='ac39a91a55d8e22c7fe4379532f6cac936c8d92707e8aa1fa0cb5f3de7805020'
assert sha(ROOT/'platform/packages/i18n/locales/te.json')==meta['canonical_online_catalog_sha256']
lessons=json.loads((ROOT/'scripts/tutorials/catalog.json').read_text());assert len(lessons)==10
paths=[ROOT/'artifacts/localization-telugu/rendering/deduplicate-capture-bmps.py',ROOT/'data/texts.en.txt',ROOT/'data/texts.te.txt',ROOT/'platform/packages/i18n/locales/te.json',ROOT/'tools/TranslationPreviewHarness.cpp',ROOT/'scripts/tutorials/catalog.json',*(ROOT/x['definition'] for x in lessons),*list((BASE/'full-overlay-e4').glob('*.json'))]
inputs={str(p):sha(p) for p in paths};binarysha=sha(B)
def guard():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==REV
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
 assert all(sha(pathlib.Path(p))==h for p,h in inputs.items())
guard();assert shutil.disk_usage(OUT.parent).free>1024**3;OUT.mkdir();shutil.copytree(BASE/'full-overlay-e4',OUT/'overlay')
cases=[(w,h,c,json.loads((ROOT/x['definition']).read_text())['id']) for w,h,c in [(1280,800,False),(800,600,False),(390,844,True)] for x in lessons];assert len(cases)==30
results={};active={};lock=threading.Lock()
def save():
 (OUT/'run.json').write_text(json.dumps({'revision':REV,'phase':'final-E4-tutorials','binary':str(B),'binary_sha256':binarysha,'input_sha256':inputs,'runner_sha256':sha(pathlib.Path(__file__)),'budget_bytes':LIMIT,'max_workers':2,'planned_case_count':30,'completed_count':sum(x['returncode']==0 for x in results.values()),'commands':[results[i] for i in sorted(results)],'pending_indices':[i for i in range(30) if i not in results],'limits':['Actual tutorial production screens at three desktop-engine layouts; compact is not physical Android.','No lesson completion/success or prediction accuracy claim.','Retain failures explicitly; remove only decoded-RGBA-identical completed BMP duplicates with receipt.']},indent=2)+'\n')
def worker(i):
 w,h,c,lesson=cases[i];guard();label=f'{i:02d}-tutorial-{lesson}-{w}x{h}';out=OUT/label;profile=OUT/'profiles'/label
 cmd=['xvfb-run','-a','-s',f'-screen 0 {max(w,1280)}x{max(h,960)}x24',str(B),'game',str(ROOT),str(OUT/'overlay'),str(out),str(w),str(h),'tutorial:'+lesson]
 env=dict(os.environ,SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='x11',GLOB2_USER_DATA_DIR=str(profile),LP_NUM_THREADS='2',LD_LIBRARY_PATH=str(ROOT/'artifacts/localization-telugu/rendering/sdl-prefix/lib'));env.pop('WAYLAND_DISPLAY',None);env.pop('GLOB2_MOBILE_UI',None)
 if c:env['GLOB2_MOBILE_UI']='1'
 start=time.time()
 with (OUT/(label+'.log')).open('wb') as log:
  proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  with lock:active[i]=proc
  try:rc=proc.wait(timeout=600)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGTERM);proc.wait();rc=124
  finally:
   with lock:active.pop(i,None)
 proofs=[]
 if rc==0:
  for path in out.glob('*.json'):
   d=json.loads(path.read_text())
   if isinstance(d,dict) and 'evidence_identity' in d:
    e=d['evidence_identity'];v=e['producer'];assert v['revision']==REV and not v['dirty'];assert '-O3' in (v['flags']['CXXFLAGS']+' '+v['flags']['CCFLAGS']);assert e['executable_sha256']==binarysha;assert d['native_keys_overridden']==3411
    assert e['sdl_version']==3004016 and e['sdl_ttf_version']==3002002 and e['harfbuzz_version']==[10,1,0]
    assert '/localization-telugu/rendering/sdl-prefix/' in e['sdl_library_path'] and '/localization-telugu/rendering/sdl-prefix/' in e['sdl_ttf_library_path']
    assert all(x['checksum_before_draw']==x['checksum_after_draw'] for x in d['captures']);proofs.append({'report':str(path.relative_to(OUT)),'sha256':sha(path),'producer':v})
  assert proofs;guard()
 return {'index':i,'lesson':lesson,'width':w,'height':h,'compact':c,'command':cmd,'profile':str(profile),'returncode':rc,'seconds':time.time()-start,'reports':proofs}
save();pending=list(range(30));futures={};pool=concurrent.futures.ThreadPoolExecutor(max_workers=2)
try:
 while pending or futures:
  while pending and len(futures)<2:
   i=pending.pop(0);futures[pool.submit(worker,i)]=i
  done,_=concurrent.futures.wait(futures,timeout=2,return_when=concurrent.futures.FIRST_COMPLETED)
  for future in done:
   i=futures.pop(future);r=future.result();results[i]=r;save();print(i,r['returncode'],round(r['seconds'],1),flush=True)
   if r['returncode']:raise RuntimeError(f'Case{i} failed; evidence retained')
  usage=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())
  if usage>384*1024**2:
   subprocess.run(['python3',str(ROOT/'artifacts/localization-telugu/rendering/deduplicate-capture-bmps.py'),str(OUT)],check=True)
   usage=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())
  if usage>LIMIT:raise RuntimeError(f'512MiB storage bound exceeded ({usage}); failure retained')
  if shutil.disk_usage(OUT).free<256*1024**2:raise RuntimeError('Free-space bound reached; no successful completion claim')
except BaseException:
 with lock:
  for proc in active.values():
   try:os.killpg(proc.pid,signal.SIGTERM)
   except ProcessLookupError:pass
 save();raise
finally:pool.shutdown(wait=True,cancel_futures=True)
assert len(results)==30 and all(x['returncode']==0 for x in results.values());assert sha(B)==binarysha;guard();print('COMPLETE30 actual tutorial cases',flush=True)
