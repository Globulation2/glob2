#!/usr/bin/env python3
"""Audit actual focused outputs; execution is required before any PASS exists."""
import argparse,collections,hashlib,itertools,json,pathlib,re,subprocess,unicodedata
p=argparse.ArgumentParser();p.add_argument('output',type=pathlib.Path);p.add_argument('--phase',choices=['early-D48','final-E3'],required=True);a=p.parse_args();a.expected_keys=12 if a.phase=='early-D48' else 16;a.expected_native=3407 if a.phase=='early-D48' else 3411
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[3];OUT=a.output.resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=json.loads((OUT/'run.json').read_text());REV=run['revision'];assert REV==({'early-D48':'d48ceb5978e803bc742fc51beacd94606a636574','final-E3':'9fb134665c5082238e1cfad9541891499e8a4a72'}[a.phase]);overlay_base=OUT/'overlays' if (OUT/'overlays').exists() else BASE;native=json.loads((overlay_base/'matrix-overlay/native.json').read_text());full=json.loads((overlay_base/'full-overlay/native.json').read_text());assert len(native)==a.expected_keys and len(full)==a.expected_native
assert len(run['results'])==run['planned_cases']==22 and all(x['returncode']==0 for x in run['results'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==REV
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
assert all(sha(pathlib.Path(path))==h for path,h in run['input_sha256'].items())
assert sha(pathlib.Path(run['binary']))==run['binary_sha256']
assert all(sha(OUT/p)==h for p,h in run.get('frozen_overlay_sha256',{}).items())
expected=set(itertools.product(native,[10,13,20],[1,2]));matrices=[];identities=[]
for path in sorted(OUT.glob('*matrix*/font-matrix.json')):
 d=json.loads(path.read_text());counts=collections.Counter((s['key'],s['size'],s['scale']) for s in d['samples']);assert set(counts)==expected and set(counts.values())=={1};assert d['harfbuzz']==[10,1,0];raw=[]
 for s in d['samples']:
  assert s['surface']=='native' and s['branch']=='' and s['has_glyphs'];source=re.sub(' +',' ',native[s['key']]);nw=lambda v:''.join(c for c in v if not c.isspace());assert nw(source)==nw(''.join(x['text'] for x in s['lines']));cursor=0
  for line in s['lines']:
   assert line['drawn_fits_width'] and line['drawn_fits_height'];text=line['text'];pos=source.find(text,cursor) if text else cursor;assert pos>=cursor;cursor=pos+len(text);after=source[cursor:cursor+1]
   assert not text or not(unicodedata.category(text[0]).startswith('M') or text[0] in '\u200c\u200d')
   assert not(text and after and text[-1]=='\u0c4d' and (after in '\u200c\u200d' or '\u0c15'<=after<='\u0c39'))
   if not line['fits_width'] or not line['fits_height']:raw.append({'key':s['key'],'size':s['size'],'scale':s['scale'],'line':line})
 matrices.append({'manifest':str(path.relative_to(OUT)),'sha256':sha(path),'logical_width':d['logical_width'],'samples':len(d['samples']),'exact_each_tuple_once':True,'missing_glyphs':0,'drawn_extent_failures':0,'nonwhite_character_loss':0,'combining_mark_line_start':0,'inword_virama_link_split':0,'raw_raster_diagnostics':raw})
assert len(matrices)==2 and {m['logical_width'] for m in matrices}=={640,1280}
for path in sorted(OUT.rglob('*.json')):
 d=json.loads(path.read_text())
 if not isinstance(d,dict) or 'evidence_identity' not in d:continue
 e=d['evidence_identity'];v=e['producer'];assert v['revision']==REV and not v['dirty'];assert e['executable_sha256']==run['binary_sha256'];assert '-O3' in (v['flags']['CXXFLAGS']+' '+v['flags']['CCFLAGS']);assert e['sdl_version']==3004016 and e['sdl_ttf_version']==3002002 and e['harfbuzz_version']==[10,1,0]
 assert '/localization-telugu/rendering/sdl-prefix/' in e['sdl_library_path'] and '/localization-telugu/rendering/sdl-prefix/' in e['sdl_ttf_library_path']
 assert d['native_keys_overridden']==(a.expected_keys if 'matrix' in path.parent.name else a.expected_native)
 for c in d.get('captures',[]):assert c['checksum_before_draw']==c['checksum_after_draw']
 identities.append({'report':str(path.relative_to(OUT)),'sha256':sha(path),'producer':v,'runtime':{k:e[k] for k in ['sdl_version','sdl_ttf_version','harfbuzz_version','sdl_library_path','sdl_ttf_library_path']}})
assert len(identities)==22
usage=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file());assert usage<run['budget_bytes']
report={'result':'PASS actual focused matrix and UI structural/provenance audit; visual review separate','phase':a.phase,'readiness_gate_claim':False,'scope':('Historical early layout check; no final gate claim' if a.phase=='early-D48' else 'Final focused structural audit only; parent assembles complete readiness gate'),'revision':REV,'binary':run['binary'],'binary_sha256':run['binary_sha256'],'new_keys':len(native),'native_catalog_keys':len(full),'matrix_samples':sum(m['samples'] for m in matrices),'matrices':matrices,'actual_ui_cases':20,'reports':identities,'input_sha256':run['input_sha256'],'output_bytes':usage,'budget_bytes':run['budget_bytes'],'limits':[f'This is delta coverage for {a.expected_keys} reviewed additions; original catalog coverage is historical exact-source/target carry.', ('EARLY D48 layout check only; zero final release/readiness gate claims.' if a.phase=='early-D48' else 'Final E3 data and producer validation; independent visual and package/runtime evidence still required.'),'Actual UI screenshots require independent visual review.','Desktop compact mode is not physical Android evidence.','Local source does not contain incoming bc8 terrain implementation; appearance labels are font-matrix coverage only.','Statistics scenes are scripted real simulation snapshots, not prediction-accuracy or completed-match evidence.']}
(OUT/'focused-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('PASS',report['matrix_samples'],'matrix tuples;',len(identities),'actual case reports')
