#!/usr/bin/env python3
"""Run only after root authorizes/applies E2 and ordinary build reconciliation."""
import hashlib,importlib.util,json,pathlib,subprocess
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[3];REV='1a559ee03c10da87c68887fb4aaafe8901e1b9da';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==REV,'Do not advance local source or prepare final overlays before root authorizes E2.'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
assert sha(ROOT/'data/texts.te.txt')=='ac39a91a55d8e22c7fe4379532f6cac936c8d92707e8aa1fa0cb5f3de7805020'
assert sha(ROOT/'platform/packages/i18n/locales/te.json')=='40b14cffd14c76cd5d4bb76c9b50b38c4fe548e7322bb1806a64d7d0318dca42'
s=importlib.util.spec_from_file_location('translation_program',ROOT/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
native,errors=p.CHECKER.read_table(ROOT/'data/texts.te.txt');assert not errors and len(native)==3411
online=json.loads((ROOT/'platform/packages/i18n/locales/te.json').read_text());assert len(online)==2836
old=json.loads((BASE/'early-d48ceb59/frozen-inputs/matrix-overlay/native.json').read_text());assert len(old)==12 and all(native[k]==v for k,v in old.items())
terrain=json.loads((ROOT/'artifacts/localization-telugu/source-update-bc8/author-new-terrain.json').read_text())['final'];assert len(terrain)==4 and all(native[k]==v for k,v in terrain.items());matrix={**old,**terrain};assert len(matrix)==16
meta={'locale':'te','requested_producer_revision':REV,'combined_frozen_source_sha256':'b7ed54ddecb1840204b30775c4f8cc69c34cc23d0f11695ad9ece2593bd451bb','canonical_native_catalog_sha256':sha(ROOT/'data/texts.te.txt'),'canonical_online_catalog_sha256':sha(ROOT/'platform/packages/i18n/locales/te.json'),'native_entries':3411,'online_entries':2836,'scope':'Final E2 full catalog values; local code remains D48, no incoming bc8 terrain implementation.','source_kit_revision_note':'E2 locale-only reconciliation after frozen D48 C++ graphs; source pairs for old3407 unchanged, four final terrain labels reviewed by all four roles.'}
for directory,n,o in [('matrix-overlay',matrix,{}),('full-overlay',native,online)]:
 d=BASE/directory;d.mkdir(exist_ok=True)
 for name,value in [('native.json',n),('online.json',o),('metadata.json',{**meta,'scope':('Sixteen new keys only: twelve U2 HUD plus four U3 terrain;192 tuple delta matrix.' if directory=='matrix-overlay' else meta['scope'])})]:(d/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print('Prepared final E2 overlays:16 delta keys,3411 native,2836 online; no capture gate claim.')
