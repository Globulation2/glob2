#!/usr/bin/env python3
"""Audit final actual tutorial coverage/provenance; visual review is separate."""
import argparse,collections,hashlib,itertools,json,pathlib,subprocess
from PIL import Image
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[3];REV='9fb134665c5082238e1cfad9541891499e8a4a72'
p=argparse.ArgumentParser();p.add_argument('output',type=pathlib.Path);a=p.parse_args();OUT=a.output.resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=json.loads((OUT/'run.json').read_text());assert r['revision']==REV and r['phase']=='final-E3-tutorials';assert len(r['commands'])==r['completed_count']==r['planned_case_count']==30 and not r['pending_indices'];assert all(x['returncode']==0 for x in r['commands'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==REV;assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip();assert all(sha(pathlib.Path(p))==h for p,h in r['input_sha256'].items());assert sha(pathlib.Path(r['binary']))==r['binary_sha256']
catalog=json.loads((ROOT/'scripts/tutorials/catalog.json').read_text());lessons=[json.loads((ROOT/x['definition']).read_text())['id'] for x in catalog];expected=set(itertools.product(lessons,[(1280,800,False),(800,600,False),(390,844,True)]));counts=collections.Counter((x['lesson'],(x['width'],x['height'],x['compact'])) for x in r['commands']);assert set(counts)==expected and set(counts.values())=={1}
native=json.loads((OUT/'overlay/native.json').read_text());assert len(native)==3411;reports=[];images=[]
for case in r['commands']:
 assert len(case['reports'])==1;p=OUT/case['reports'][0]['report'];assert sha(p)==case['reports'][0]['sha256'];d=json.loads(p.read_text());e=d['evidence_identity'];v=e['producer'];assert v['revision']==REV and not v['dirty'];assert e['executable_sha256']==r['binary_sha256'];assert '-O3' in (v['flags']['CXXFLAGS']+' '+v['flags']['CCFLAGS']);assert d['native_keys_overridden']==3411 and d['tutorial_lesson']==case['lesson'] and d['tutorial_instruction_shown'] and d['tutorial_capture_dialog_free'];assert d['width']==case['width'] and d['height']==case['height'] and d['phone_presentation_requested']==case['compact']
 assert e['sdl_version']==3004016 and e['sdl_ttf_version']==3002002 and e['harfbuzz_version']==[10,1,0];assert '/localization-telugu/rendering/sdl-prefix/' in e['sdl_library_path'] and '/localization-telugu/rendering/sdl-prefix/' in e['sdl_ttf_library_path']
 for key in ['tutorial_instruction','tutorial_touch_instruction']:
  if d[key]:assert native[d[key]]
 declared=[]
 for capture in d['captures']:
  assert capture['checksum_before_draw']==capture['checksum_after_draw'];png=p.parent/(capture['name']+'.png');assert png.is_file()
  with Image.open(png) as image:assert image.size==(capture['image_width'],capture['image_height'])
  declared.append(png);images.append({'path':str(png.relative_to(OUT)),'sha256':sha(png),'width':capture['image_width'],'height':capture['image_height']})
 assert set(declared)==set(p.parent.glob('*.png'));reports.append({'path':str(p.relative_to(OUT)),'sha256':sha(p),'lesson':case['lesson'],'width':case['width'],'height':case['height'],'compact':case['compact'],'captures':len(declared),'producer':v})
assert len(images)==len({i['path'] for i in images});usage=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file());assert usage<r['budget_bytes']==512*1024**2
report={'result':'PASS actual30 tutorial case coverage/provenance/checksums/PNG dimensions; independent visual review separate','phase':'final-E3-tutorials','revision':REV,'binary_sha256':r['binary_sha256'],'exact_lesson_viewport_tuples_once':30,'reports':reports,'actual_png_images':len(images),'images':images,'source_input_sha256':r['input_sha256'],'output_bytes':usage,'budget_bytes':r['budget_bytes'],'limits':['Every lesson is initialized and current instruction/briefing/dialog captured, not completed gameplay.','Compact390 is production desktop-engine phone layout, not Android-device runtime.','No image-content or shaping quality claim is made by structural audit; independent reviewer opens actual PNGs.']};(OUT/'tutorial-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('PASS30 tutorial cases',len(images),'actualPNGs',usage,'bytes')
