import hashlib,json,os,pathlib,subprocess,tarfile
root=pathlib.Path.cwd();out=root/'artifacts/unit-review';pub=out/'publication';pub.mkdir(exist_ok=True)
def git(*args,data=None,env=None):return subprocess.check_output(['git',*args],input=data,env=env).decode().strip()
head=git('rev-parse','HEAD');base='c1401a484ed788f06238626424de422df9f5dbb0'
assert git('merge-base',head,base)==base
assert not git('status','--porcelain')
summary=json.loads((out/'final-summary.json').read_text());assert summary['revision']==head
archive=pub/('unit-review-'+head[:9]+'.tar.gz')
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(out.rglob('*')):
  if not p.is_file() or pub in p.parents:continue
  relative=p.relative_to(out)
  if str(relative)=='verify-shutdown-repro/glob2-symbols':continue
  if relative.parts[0]=='base-platform-boundary':continue
  if relative.parts[0]=='patched-sdl' and str(relative)!='patched-sdl/manifest.json':continue
  tar.add(p,arcname=str(pathlib.Path('unit-review')/relative),recursive=False)
manifest={'source':head,'base':base,'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(pub/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
branch='refs/heads/codex/configurable-units-evidence';parent=git('rev-parse',branch)
index=pub/'evidence.index';index.unlink(missing_ok=True);env={**os.environ,'GIT_INDEX_FILE':str(index)}
git('read-tree',parent,env=env)
files=[archive,pub/'archive-manifest.json',pub/'README.md',out/'final-summary.json',out/'trace-comparison-final.json',out/'team-review.json',out/'gpu-routing-integration-review.json',out/'cli-session-master-integration-review.json',out/'runtime-dependency-correction.json',out/'final-master-integration.json',out/'gpu-shutdown-static-review.json',out/'gpu-shutdown-patch-review.json',out/'gpu-shutdown-execution-closure-review.json',out/'latest-master-rebase.json',out/'latest-renderer-integration-review.json',out/'latest-execution-closure-review.json',out/'base-platform-boundary.json',out/'base-platform-boundary.log']
for p in files:
 blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo','100644',blob,'evidence/unit-review/'+p.name,env=env)
tree=git('write-tree',env=env);commit=git('commit-tree',tree,'-p',parent,data=('Publish independent unit review and final integration evidence '+head[:9]+'\n').encode());git('update-ref',branch,commit,parent);index.unlink()
result={**manifest,'evidenceCommit':commit,'parent':parent};(pub/'publication-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
