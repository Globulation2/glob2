import datetime,hashlib,json,os,pathlib,platform,subprocess,sys,time
ROOT=pathlib.Path.cwd();OUT=ROOT/'artifacts/unit-review';build='build/unit-review-release';main=build+'/src/glob2'
name=sys.argv[1];base=['python3','test/run_tests.py','--build-dir',build,'-j','6','--junit',str(OUT/(name+'.xml')),'--write-inventory',str(OUT/(name+'-inventory.json')),'--artifacts',str(OUT/(name+'-cases'))]
commands={
'shutdown-loops':['python3','artifacts/unit-review/shutdown_fixed_check.py',name],
'gpu-cli':['python3','artifacts/unit-review/gpu_cli_check.py',name],
'patched-sdl':['python3','artifacts/unit-review/build_patched_sdl.py'],
'build':['python3','tools/dev_build.py','release=1','dev_fast=0','linker=default','--build='+build,main,'engine-tests','unit-tests','-j6'],
'focused':base+['--binary','engine','--no-display','--filter','UnitCatalog/authored animation*','--filter','UnitCatalog/legacy presentation*','--filter','UnitCustomization/idle painted clearing*','--filter','UnitCustomization/idle clearing permission*','--filter','UnitCustomization/migrated vision*','--filter','UnitCustomization/documented bulk carrier*'],
'regenerate-match':base+['--binary','engine','--update-fixtures','--filter','TurnEngineHarness/the committed*'],
'engine':base+['--binary','engine','--no-display','--filter','UnitCatalog/*','--filter','UnitCustomization/*','--filter','TeamStatsSave/*','--filter','EngineSession/*','--filter','LegacyReplay/*','--filter','GameDiagnostics/*','--filter','CommandLine/*','--filter','BuildingCatalog/*','--filter','BuildingProductionCombat/*','--filter','WorldSnapshot/*','--filter','TerrainHazardRouting/*','--filter','TerrainRuntime/*','--filter','Gradient/*','--filter','GradientPreparation/*','--filter','GradientPipeline/*','--filter','ComputeExecutor/*','--filter','BuildingGradientInvalidation/*','--filter','MapGradientInvalidation/*','--filter','TurnEngineHarness/the committed*'],
'hardware-gl':base+['--binary','unit','--filter','ProgrammableGLDevice/*'],
'unit':base+['--binary','unit','--no-display'],
'image-contract':base+['--binary','unit','--no-display','--filter','ImageAssets/16-bit RGBA*'],
'presentation':base+['--binary','engine','--filter','UnitCatalog/new combinations retain appearance*','--filter','ColonySkinPreview/*'],
'cli':['python3','test/test_cli_smoke.py','--binary',main,'--artifacts',str(OUT/(name+'-cases')),'--junit',str(OUT/(name+'.xml'))],
'cli-reference':['python3','tools/cli_reference.py','--binary',main,'--check'],
'traces':['python3','test/run-browser-determinism.py',main,str(OUT/name),'--engine-binary',build+'/test/glob2-engine-tests'],
'sim-contract':['python3','test/check_sim_revision.py','--base','32c7ec892b5a1dfb22bde2d9025de106e8eac4d3'],
'python-contracts':['python3','-m','unittest','discover','-s','test','-p','test_check_sim_revision.py'],
'build-contracts':['python3','-m','unittest','discover','-s','test/build_system','-p','test_*.py'],
'build-contracts-pinned':['/home/bradley/.local/share/glob2/development/caches/asset-encoder-runtime-assets-v1-py3.14/venv/bin/python','-m','unittest','discover','-s','test/build_system','-p','test_*.py'],
'asset-contracts':['/home/bradley/.local/share/glob2/development/caches/asset-encoder-runtime-assets-v1-py3.14/venv/bin/python','-m','unittest','discover','-s','test/build_system','-p','test_package_assets.py'],
'windows-package-contracts':['python3','-m','unittest','discover','-s','test/build_system','-p','test_release_windows_package.py'],
'shader-contracts':['python3','-m','unittest','discover','-s','test/build_system','-p','test_renderer_shaders.py'],
}
mode=sys.argv[2] if len(sys.argv)>2 else name;argv=commands[mode];receipt=OUT/(name+'-command.json');assert not receipt.exists()
def identity(allow_dirty=False):
 head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();expected=json.loads((OUT/'pin.json').read_text())['revision'];assert head==expected,(head,expected)
 changes=subprocess.check_output(['git','status','--porcelain'],text=True).splitlines()
 if not allow_dirty:assert not changes,changes
 else:assert all(l[3:] in ['test/fixtures/multiplayer/FourSquares1.g2mr','test/fixtures/multiplayer/FourSquares1.verify-trace.txt'] for l in changes),changes
 return {'revision':head,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'status':changes,'master':subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip()}
env={**os.environ,'GLOB2_SDL3_PREFIX':'/home/bradley/glob2-claude/build/sdl3/prefix','DISPLAY':'','WAYLAND_DISPLAY':''};env.pop('GLOB2_TEST_UPDATE_FIXTURES',None)
if mode in ['shutdown-loops','gpu-cli','regenerate-match','engine','unit','presentation','traces','cli','cli-reference','image-contract','focused','hardware-gl'] and (OUT/'patched-sdl/manifest.json').is_file():
 env['LD_LIBRARY_PATH']=str(OUT/'patched-sdl/prefix/lib')+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
if mode=='hardware-gl':env['GLOB2_TEST_SHADER_DIRECTORY']=str(ROOT/build/'shaders')
if mode in ['build-contracts-pinned','asset-contracts','windows-package-contracts','shader-contracts']:
 env.pop('GLOB2_SDL3_PREFIX',None);env.pop('GLOB2_RECORDING_PREFIX',None)
d={'status':'RUNNING','complete':False,'sourceBefore':identity(),'argv':argv,'environment':{k:env.get(k) for k in ['GLOB2_SDL3_PREFIX','GLOB2_RECORDING_PREFIX','LD_LIBRARY_PATH','DISPLAY','WAYLAND_DISPLAY','GLOB2_TEST_SHADER_DIRECTORY']},'os':platform.platform(),'architecture':platform.machine(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'driverPid':os.getpid()};receipt.write_text(json.dumps(d,indent=2)+'\n');start=time.monotonic()
try:
 with (OUT/(name+'.log')).open('w') as log:
  child=subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT);d['childPid']=child.pid;receipt.write_text(json.dumps(d,indent=2)+'\n');code=child.wait()
 d.update(commandExitCode=code,exitCode=code,status='PASS' if code==0 else 'FAIL',sourceAfter=identity(mode=='regenerate-match'));assert d['sourceBefore']['revision']==d['sourceAfter']['revision'] and d['sourceBefore']['tree']==d['sourceAfter']['tree']
except BaseException as e:d.update(status='FAIL',error=repr(e),exitCode=1)
finally:
 d.update(complete=True,closedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-start,logSha256=hashlib.sha256((OUT/(name+'.log')).read_bytes()).hexdigest());receipt.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'name':name,'status':d['status'],'exitCode':d['exitCode'],'source':d['sourceBefore']['revision']}),flush=True)
sys.exit(d['exitCode'])
