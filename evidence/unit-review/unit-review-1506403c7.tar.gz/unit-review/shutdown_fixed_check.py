import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path.cwd();out=root/'artifacts/unit-review/shutdown-fixed';out.mkdir(exist_ok=True);source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
expected=(root/'test/fixtures/multiplayer/FourSquares1.verify-trace.txt').read_bytes();results=[]
for mode,count,workers in [('cpu',4,'2'),('gpu',16,'2'),('gpu',4,'auto')]:
 for number in range(count):
  target=out/(mode+'-'+workers+'-'+str(number));target.mkdir();env={**os.environ,'SDL_VIDEODRIVER':'dummy','SDL_AUDIODRIVER':'dummy','DISPLAY':'','WAYLAND_DISPLAY':''};env.pop('GLOB2_GRADIENT_BACKEND',None)
  if mode=='cpu':env['GLOB2_GRADIENT_BACKEND']='cpu'
  argv=[str(root/'build/unit-review-release/src/glob2'),'match','verify',str(root/'test/fixtures/multiplayer/FourSquares1.g2mr'),'--map-file',str(root/'maps/FourSquares1.map.gz'),'--output-dir',str(target/'result'),'--compute-threads',workers]
  start=time.monotonic();item={'mode':mode,'computeThreads':workers,'argv':argv,'source':source,'environment':{k:env.get(k) for k in ['GLOB2_GRADIENT_BACKEND','LD_LIBRARY_PATH','SDL_VIDEODRIVER','SDL_AUDIODRIVER']}}
  with (target/'stdout.log').open('w') as log:
   try:item['exitCode']=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=15).returncode
   except subprocess.TimeoutExpired:item['exitCode']='timeout'
  item['elapsedSeconds']=time.monotonic()-start;trace=target/'result/checksums.txt';item['traceEqual']=trace.exists() and trace.read_bytes()==expected;item['traceSha256']=hashlib.sha256(trace.read_bytes()).hexdigest() if trace.exists() else None;results.append(item);(out/'manifest.json').write_text(json.dumps({'source':source,'runs':results},indent=2)+'\n');print(mode,workers,number,item['exitCode'],item['traceEqual'],flush=True)
  if item['exitCode']!=0 or not item['traceEqual']:sys.exit(1)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
