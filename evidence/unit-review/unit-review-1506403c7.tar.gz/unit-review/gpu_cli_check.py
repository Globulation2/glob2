import hashlib,json,os,pathlib,subprocess,sys
root=pathlib.Path.cwd();out=root/'artifacts/unit-review'/(sys.argv[1]+'-cases');out.mkdir(exist_ok=True)
binary=root/'build/unit-review-release/src/glob2'
env={**os.environ,'GLOB2_USER_DIR':str(out/'profile'),'GLOB2_USER_DATA_DIR':str(out/'profile'),'SDL_VIDEODRIVER':'dummy','SDL_AUDIODRIVER':'dummy'}
commands=[]
def run(args,name):
 argv=[str(binary),*map(str,args)];result=subprocess.run(argv,cwd=root,env=env,capture_output=True,text=True,timeout=300)
 (out/(name+'.log')).write_text(result.stdout+result.stderr);commands.append({'argv':argv,'exitCode':result.returncode});assert result.returncode==0,result.stderr
run(['map','generate','river','--width','128','--height','128','--teams','2','--seed','713','--output',out/'source.map'],'generate')
for mode in ['off','on']:
 run(['game','run','--output-dir',out/mode,'--ticks','512','--compute-threads','2','--gpu='+mode,'--telemetry','checksums','--write-replay','--save','final','--map-file',out/'source.map.gz','--game-seed','713','--player','castor','--player','cortex'],mode)
sys.path.insert(0,str(root/'test'));from check_javascript import complete_ticks
cpu=(out/'off/game.replay.checksums').read_bytes();gpu=(out/'on/game.replay.checksums').read_bytes();assert complete_ticks(cpu)==complete_ticks(gpu)
def extract(obj):
 if isinstance(obj,dict):
  return {key:value for key,value in obj.items() if key in ['gpu_requested','gpu_device','gpu_error','gradient_execution']}|{key:extract(value) for key,value in obj.items() if isinstance(value,(dict,list)) and extract(value)}
 if isinstance(obj,list):return [extract(x) for x in obj if extract(x)]
 return {}
report={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'commands':commands,'checksumTicksEqual':len(complete_ticks(cpu)),'off':extract(json.loads((out/'off/result.json').read_text())),'on':extract(json.loads((out/'on/result.json').read_text())),'offTraceSha256':hashlib.sha256(cpu).hexdigest(),'onTraceSha256':hashlib.sha256(gpu).hexdigest()};(out/'gpu-coverage.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
