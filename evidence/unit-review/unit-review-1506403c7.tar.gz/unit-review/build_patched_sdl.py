import hashlib,importlib.util,json,pathlib,subprocess,tarfile
root=pathlib.Path.cwd();out=root/'artifacts/unit-review/patched-sdl';out.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('sdl_deps',root/'scons/sdl3_dependencies.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
version=json.loads(m.LOCK.read_text())['SDL'];archive=pathlib.Path('/home/bradley/glob2-claude/build/sdl3/sources')/version['archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==version['sha256']
source=out/version['archive'].removesuffix('.tar.gz')
if not source.exists():
 with tarfile.open(archive) as package:package.extractall(out,filter='data')
m.apply_source_patches(source)
prefix=out/'prefix';build=out/'build'
configure=['cmake','-S',str(source),'-B',str(build),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_INSTALL_PREFIX='+str(prefix),'-DCMAKE_INSTALL_LIBDIR=lib','-DSDL_TESTS=OFF','-DSDL_TEST_LIBRARY=OFF','-DSDL_EXAMPLES=OFF','-DCMAKE_INSTALL_RPATH=$ORIGIN']
commands=[configure,['cmake','--build',str(build),'--parallel','8'],['cmake','--install',str(build)]]
for argv in commands:subprocess.run(argv,check=True)
old=pathlib.Path('/home/bradley/glob2-claude/build/sdl3/prefix/include/SDL3');new=prefix/'include/SDL3'
headers={str(p.relative_to(new)):hashlib.sha256(p.read_bytes()).hexdigest() for p in new.rglob('*.h')}
different=[name for name,h in headers.items() if not (old/name).is_file() or hashlib.sha256((old/name).read_bytes()).hexdigest()!=h]
assert not different,different
receipt={'dependency':'SDL3','version':version,'patches':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in m.SDL_PATCHES},'commands':commands,'allInstalledSdlHeadersByteIdenticalToCompilePrefix':True,'headerCount':len(headers),'headers':headers,'librarySha256':hashlib.sha256((prefix/'lib/libSDL3.so.0.4.16').read_bytes()).hexdigest(),'purpose':'Complete required repository SDL patch set in isolated runtime without modifying borrowed prefix. Same installed headers; release game binaries remain source/flag/header identical.'}
(out/'manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Patched SDL runtime installed; all compile headers remain byte-identical.')
