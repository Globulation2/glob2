"""Curate the supplemental checkpoint; exclude APIs, private profiles and binaries."""
from pathlib import Path
import json
U=Path(__file__).resolve().parent;P=U.parent;files=set()
allowed={'.json','.log','.txt','.xml','.png','.gz','.py','.cjs','.diff','.patch','.g2mr','.world','.checksums','.replay','.ts'}
blocked_parts={'google','node_modules','sdl-prefix','profiles','profile','caddy-state','playwright-profile','editor-contact','editor-crops','superseded-32-locale-preparation','resolved-candidate','candidate','rendering-integration-candidates','sgsl-candidate','ffabe-te-only-preparation','metadata-results','test-results'}
blocked_names={'state.json','lease.json','ledger.json','fixture.json','seed.json','metadata-seed.json','execution.json','run-command.json','metadata-run-command.json','prepare-kit.py','google-draft-untouched-te.json','google-draft-untouched-texts.te.txt','google-draft-111.json','draft-before-google.json','google-draft-provenance.json','kit-preparation-provenance.json','kit-preparation-correction.json','google-inventory.json','google-execution.log','candidate.index'}
def add(f):
 if not f.is_file() or f.is_symlink() or f.suffix not in allowed:return
 rel=f.relative_to(P)
 if any(part in blocked_parts for part in rel.parts) or f.name in blocked_names:return
 if f.name.startswith(('google-','ledger-','candidate-','prepare-resolved-')):return
 if f.stat().st_size>48*1024**2:raise ValueError('Oversized evidence must be deliberately reviewed: '+str(rel))
 files.add(str(rel))
for folder in ['source','batches','drafts','reviews','audit-batches','rendering','compatibility']:
 for f in (U/folder).rglob('*'):add(f)
for f in U.iterdir():add(f)
for folder in ['platform-integration-ffabe','online-integration-d543','browser-runtime-ffabe']:
 for f in (P/folder).rglob('*'):add(f)
for f in (P/'native-release-smoke').glob('u6-release-*'):add(f)
# Only manifests from frozen package payloads; no SDK, executable, APK or WASM blob.
for directory in (P/'rendering').iterdir():
 if directory.is_dir() and 'd005' in directory.name:
  for name in ['snapshot-provenance.json','localization-payload.json','frozen-apk.json','strict-final-verification.json','package-input-carry.json']:
   add(directory/name)
(U/'supplemental-public-files.json').write_text(json.dumps(sorted(files),indent=2)+'\n')
print(len(files),'curated supplemental files')
