#!/usr/bin/env python3
import collections,hashlib,json,pathlib,subprocess,sys
from PIL import Image
B=pathlib.Path(__file__).resolve().parent;ROOT=B.parents[3];OUT=pathlib.Path(sys.argv[1]).resolve();REV='d005f2d82b5a8f9a6b736fe080625f202e88299e';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((OUT/'run.json').read_text());assert r['revision']==REV and r['planned_cases']==20 and len(r['results'])==20 and all(c['returncode']==0 for c in r['results'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==REV;assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip();assert all(sha(pathlib.Path(p))==h for p,h in r['input_sha256'].items());assert sha(pathlib.Path(r['binary']))==r['binary_sha256'];assert all(sha(OUT/p)==h for p,h in r['frozen_overlay_sha256'].items())
reports=[];images=[];tuples=[]
for case in r['results']:
 cmd=case['command'];mode=cmd[cmd.index(str(pathlib.Path(r['binary'])))+1];name=cmd[-1];w,h=map(int,cmd[-3:-1]);tuples.append((mode,name,w,h,case['compact']))
 out=pathlib.Path(cmd[-4]);paths=[p for p in out.glob('*.json') if 'evidence_identity' in json.loads(p.read_text())];assert len(paths)==1
 p=paths[0];d=json.loads(p.read_text());e=d['evidence_identity'];v=e['producer'];assert v['revision']==REV and not v['dirty'] and e['executable_sha256']==r['binary_sha256'];assert '-O3' in (v['flags']['CXXFLAGS']+' '+v['flags']['CCFLAGS']);assert d['native_keys_overridden']==3411 and d['width']==w and d['height']==h
 assert e['sdl_version']==3004016 and e['sdl_ttf_version']==3002002 and e['harfbuzz_version']==[10,1,0]
 for k in ['sdl_library_path','sdl_ttf_library_path']:assert '/localization-telugu/rendering/sdl-prefix/' in e[k]
 for c in d.get('captures',[]):assert c['checksum_before_draw']==c['checksum_after_draw']
 pngs=list(out.glob('*.png'));assert pngs
 for png in pngs:
  with Image.open(png) as im:assert im.width==w and im.height==h
  images.append({'path':str(png.relative_to(OUT)),'sha256':sha(png)})
 reports.append({'path':str(p.relative_to(OUT)),'sha256':sha(p),'producer':v,'actual_pngs':len(pngs)})
expected={('screen',s,w,h,c) for s in ['main','settings','settings-audio','settings-player','lobby','lobby-players'] for w,h,c in [(1280,800,False),(800,600,False),(390,844,True)]}|{('game','gameplay',1280,800,False),('game','gameplay',800,600,False)}
assert set(tuples)==expected and len(set(tuples))==20
usage=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file());assert usage<r['budget_bytes']==512*1024**2
result={'result':'PASS actual20 current menus/settings/lobbies/gameplay case coverage and producer/pixel-dimension audit; visual review separate','revision':REV,'binary_sha256':r['binary_sha256'],'reports':reports,'images':images,'actual_pngs':len(images),'exact_case_tuples':tuples,'output_bytes':usage,'limits':['Control bounds include scroll content; actual text-fit requires independent image review.','390 compact is desktop-engine layout, not Android device runtime.','Terrain editor picker is separate optimized GUI evidence from parent.']}
(OUT/'menus-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('PASS20 cases',len(images),'PNGs')
