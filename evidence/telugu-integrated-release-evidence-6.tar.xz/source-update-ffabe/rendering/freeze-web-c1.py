#!/usr/bin/env python3
"""Freeze real supported complete BOTH shipping closure after successful C1 build."""
import hashlib,json,pathlib,shutil,subprocess,time
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[3];REV='d005f2d82b5a8f9a6b736fe080625f202e88299e';S=ROOT/'build/emscripten/client/release';OUT=BASE/'frozen-web-d005f2d8';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def guard():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==REV
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
guard();assert not OUT.exists()
logs=[BASE.parent/'web-release-d005f2d8.log',BASE.parent/'web-release-d005f2d8-j14.log'];log=logs[-1];assert 'scons: done building targets.' in log.read_text() and 'scons: ***' not in log.read_text();text='\n'.join(p.read_text() for p in logs)
files=[]
for p in S.iterdir():
 if p.is_file() and (p.suffix in ['.js','.wasm','.data','.html','.css'] or p.name in ['identity.json','options.json']):files.append(p)
for name in ['assets','fonts','locales','licenses']:
 assert (S/name).is_dir();files.extend(p for p in (S/name).rglob('*') if p.is_file())
files.extend(p for p in (S/'threaded').iterdir() if p.is_file() and (p.suffix in ['.js','.wasm','.data','.html','.css'] or p.name in ['identity.json','options.json']))
for v in ['','threaded/']:
 for name in ['index.js','index.wasm','index.data','identity.json','options.json']:assert S/(v+name) in files
 i=json.loads((S/(v+'identity.json')).read_text());o=json.loads((S/(v+'options.json')).read_text());assert i['mode']=='release' and i['target']=='web';assert o['release']=='1' and o['dev_fast']=='0' and o['linker']=='default' and o['web_variant']=='both'
assert sum(p.stat().st_size for p in files)<512*1024**2;assert shutil.disk_usage(OUT.parent).free>1024**3
OUT.mkdir();rows=[]
for p in files:
 rel=p.relative_to(S);q=OUT/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);assert sha(q)==sha(p);rows.append({'path':rel.as_posix(),'sha256':sha(q),'bytes':q.stat().st_size})
lines=text.splitlines();compiles=[x for x in lines if ' -o ' in x and ' -c ' in x];links=[x for x in lines if ' -o ' in x and ('index.js ' in x or 'index.js\" ' in x)];(OUT/'actual-compile-and-link-commands.txt').write_text('\n'.join(compiles+links)+'\n')
assert len(links)==2
r={'state':'Actual C1 ordinary supported BOTH release; complete generated shipping closure frozen, independent runtime separate','revision':REV,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),'sim_revision':112,'version_minor':191,'snapshot_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'command':'env -u GLOB2_RECORDING_PREFIX python3 tools/dev_build.py dev_fast=0 release=1 linker=default target=web web_variant=both -j14 web-package','exit_code':0,'files':rows,'bytes':sum(x['bytes'] for x in rows),'native_catalog_sha256':sha(ROOT/'data/texts.te.txt'),'online_catalog_sha256':sha(ROOT/'platform/packages/i18n/locales/te.json'),'actual_cpp_compile_commands':len(compiles),'actual_final_main_relinks':len(links),'actual_commands_sha256':sha(OUT/'actual-compile-and-link-commands.txt'),'log':str(log.relative_to(ROOT)),'log_sha256':sha(log),'phase_logs':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)} for p in logs],'reallocation_receipt_sha256':sha(BASE.parent/'compiler-reallocation-d005.json'),'emscripten_configuration_sha256':sha(S/'.emscripten'),'source_build_input_sha256':{p:sha(ROOT/p) for p in ['scons/web_build.py','scons/web_assets.py','scons/shared_dependencies.py','scons/recording_dependencies.py','scons/recording-versions.json','scons/opus_dependencies.py','scons/sources.py','data/fonts/scripts/manifest.json','browser/i18n.js','browser/shell.html','src/hud/draw/GameGUIDraw.cpp','src/game/SimRevision.h','src/app/Version.h']},'limits':['Actual fullmaster merge includes new terrain code/assets, Malay integration and ownSIM112 TeSGSL boundary.','No old E4/E5 executable relabeling or manual generated HTML changes.','No signing/deployment or browser runtime claim from payload freezing.','C2 golden-only commit may carry exact shipping inputs; actual producer remains C1.']}
assert r['native_catalog_sha256']=='ac39a91a55d8e22c7fe4379532f6cac936c8d92707e8aa1fa0cb5f3de7805020';assert r['online_catalog_sha256']=='ae11e7446fae32510cdf557a4e9f0ed2b6aafa3f5f50daadf9dc5c2a7f683b71';guard();(OUT/'snapshot-provenance.json').write_text(json.dumps(r,indent=2)+'\n');print('FROZEN',len(rows),r['bytes'])
