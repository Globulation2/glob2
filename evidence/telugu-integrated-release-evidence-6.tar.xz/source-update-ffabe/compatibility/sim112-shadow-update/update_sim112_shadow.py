import pathlib,os,json,hashlib,subprocess,shutil,time,gzip,threading,signal,resource,xml.etree.ElementTree as ET
r=pathlib.Path('/home/bradley/.codex/worktrees/7ed0/glob2');c=r/'artifacts/localization-telugu/source-update-ffabe/compatibility';p=c/'sim112-shadow-update';p.mkdir(exist_ok=False);s=p/'shadow-source';s.mkdir();head='d005f2d82b5a8f9a6b736fe080625f202e88299e';binary=r/'build/linux/client/release/test/glob2-engine-tests';expected='acfed0be16f483d1df92d3dae1e0becdd72f21333f99d69c5d539dd998ad4177';cap=128*1024*1024
rel=['test/fixtures/multiplayer/FourSquares1.g2mr','test/fixtures/multiplayer/FourSquares1.verify-trace.txt']
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(r),*a],text=True).strip()
def write(f,o):f.write_text(json.dumps(o,indent=2)+'\n')
def size():return sum(f.stat().st_size for f in c.rglob('*') if f.is_file() and not f.is_symlink())
assert git('rev-parse','HEAD')==head and not git('status','--porcelain');assert sha(binary)==expected
before={x:sha(r/x) for x in rel};links=[]
def link(src,dst):dst.symlink_to(src,target_is_directory=src.is_dir());links.append({'shadow_path':str(dst.relative_to(s)),'target':str(src)})
for f in r.iterdir():
 if f.name in ['.git','artifacts']:continue
 if f.name!='test':link(f,s/f.name)
(s/'test/fixtures/multiplayer').mkdir(parents=True)
for f in (r/'test').iterdir():
 if f.name!='fixtures':link(f,s/'test'/f.name)
for f in (r/'test/fixtures').iterdir():
 if f.name!='multiplayer':link(f,s/'test/fixtures'/f.name)
for f in (r/'test/fixtures/multiplayer').iterdir():
 dst=s/'test/fixtures/multiplayer'/f.name
 if str(f.relative_to(r)) in rel:shutil.copyfile(f,dst)
 else:link(f,dst)
for x in rel:assert not (s/x).is_symlink() and (s/x).resolve().is_relative_to(p.resolve())
write(p/'shadow-inputs.json',{'source_revision':head,'binary':str(binary),'binary_sha256':sha(binary),'real_canonical_hashes_before':before,'links':links,'omitted_roots':{'.git':'repository metadata not needed by this runtime','artifacts':'avoid recursive evidence tree; all profile/artifact outputs explicitly inside bounded campaign'},'writable_fixture_copies':[{ 'path':str(s/x),'sha256':sha(s/x)} for x in rel],'evidence_cap_bytes':cap,'preexisting_compatibility_bytes':size()})
profile=p/'profile';profile.mkdir();work=p/'work';work.mkdir();out=p/'case-artifacts';out.mkdir();tmp=p/'tmp';tmp.mkdir()
env=dict(os.environ);env.update(GLOB2_TEST_SOURCE_ROOT=str(s),GLOB2_TEST_UPDATE_FIXTURES='1',GLOB2_USER_DATA_DIR=str(profile),GLOB2_TEST_ARTIFACTS=str(out),GLOB2_TEST_ARTIFACTS_ROOT=str(out),TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),SDL_VIDEODRIVER='dummy',SDL_RENDER_DRIVER='software',SDL_AUDIODRIVER='dummy',LD_LIBRARY_PATH=str(r/'artifacts/localization-telugu/rendering/sdl-prefix/lib'))
for k in ['GLOB2_USER_DIR','GLOB2_MOBILE_UI','GLOB2_TEST_DISPLAY','GLOB2_TEST_FULLSCREEN']:env.pop(k,None)
cmd=[str(binary),'-r=junit','-o='+str(p/'junit.xml'),'--no-breaks=true','-ts=TurnEngineHarness','-tc=the committed match record verifies to the committed checksum trace*'];write(p/'command.json',{'argv':cmd,'cwd':str(work),'environment_overrides':{k:env[k] for k in ['GLOB2_TEST_SOURCE_ROOT','GLOB2_TEST_UPDATE_FIXTURES','GLOB2_USER_DATA_DIR','GLOB2_TEST_ARTIFACTS','GLOB2_TEST_ARTIFACTS_ROOT','TMPDIR','SDL_VIDEODRIVER','SDL_RENDER_DRIVER','SDL_AUDIODRIVER','LD_LIBRARY_PATH']},'per_file_limit_bytes':32*1024*1024,'campaign_cap_bytes':cap})
def limits():resource.setrlimit(resource.RLIMIT_FSIZE,(32*1024*1024,32*1024*1024))
start=time.time();proc=subprocess.Popen(cmd,cwd=work,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits);reason=None;peak=size()
def capture():
 with gzip.open(p/'actual-output.log.gz','wb') as z:
  for chunk in iter(lambda:proc.stdout.read(8192),b''):z.write(chunk)
t=threading.Thread(target=capture);t.start()
while proc.poll() is None:
 now=size();peak=max(peak,now)
 if now>cap:reason='128MiB evidence cap exceeded';os.killpg(proc.pid,signal.SIGTERM);break
 if time.time()-start>180:reason='180s bounded timeout';os.killpg(proc.pid,signal.SIGTERM);break
 time.sleep(.1)
try:rc=proc.wait(timeout=5)
except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);rc=proc.wait()
t.join();peak=max(peak,size());after={x:sha(r/x) for x in rel};status=git('status','--porcelain');actualhead=git('rev-parse','HEAD')
prov=json.loads((out/'build-provenance.json').read_text()) if (out/'build-provenance.json').exists() else None
result={'exit_code':rc,'termination_reason':reason,'elapsed_seconds':time.time()-start,'peak_compatibility_bytes':peak,'cap_bytes':cap,'real_canonical_hashes_after':after,'real_canonical_untouched':before==after,'git_status_porcelain_after':status,'source_head_after':actualhead,'binary_hash_after':sha(binary),'embedded_producer':prov,'generated':[{'path':str(s/x),'sha256':sha(s/x),'bytes':(s/x).stat().st_size} for x in rel]};write(p/'execution-result.json',result);print(json.dumps(result,indent=2));assert rc==0 and reason is None and before==after and not status and actualhead==head and sha(binary)==expected
