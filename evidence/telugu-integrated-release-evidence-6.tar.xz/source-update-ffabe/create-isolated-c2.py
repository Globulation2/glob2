"""Create a reviewable draft commit without touching the active C1 build checkout."""
from pathlib import Path
import hashlib,json,os,subprocess,tempfile
R=Path.cwd();U=R/'artifacts/localization-telugu/source-update-ffabe';P=U.parent;C1='d005f2d82b5a8f9a6b736fe080625f202e88299e'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==C1
assert not subprocess.check_output(['git','status','--porcelain']).strip()
index_before=subprocess.check_output(['git','ls-files','-s','-z']);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt=json.loads((P/'skin-hint-fix/candidate-receipt.json').read_text());assert receipt['source_base']==C1 and len(receipt['files'])==4
candidate={name:P/'skin-hint-fix/candidate'/name for name in receipt['files']}
for name,path in candidate.items():assert sha(path)==receipt['files'][name]['sha256']
golden=json.loads((U/'compatibility/sim112-shadow-update/verification.json').read_text());assert golden['status'].startswith('PASS') and golden['checkout_isolation']['real_fixture_bytes_untouched'] and golden['comparison']['trace_byte_identical']
for field,rel in [('candidate_record','test/fixtures/multiplayer/FourSquares1.g2mr'),('candidate_trace','test/fixtures/multiplayer/FourSquares1.verify-trace.txt')]:
 item=golden[field];path=R/item['path'];assert sha(path)==item['sha256'];candidate[rel]=path
with tempfile.TemporaryDirectory(dir=U,prefix='isolated-c2-') as temp:
 env=dict(os.environ,GIT_INDEX_FILE=str(Path(temp)/'index'))
 def git(*args,input=None):return subprocess.check_output(['git',*args],env=env,input=input).decode().strip()
 git('read-tree',C1);records=[]
 for name,path in candidate.items():
  blob=git('hash-object','-w','--no-filters',str(path));mode=git('ls-tree',C1,'--',name).split()[0];git('update-index','--add','--cacheinfo',mode+','+blob+','+name);records.append({'path':name,'sha256':sha(path),'blob':blob,'mode':mode})
 tree=git('write-tree');changed=git('diff','--name-only',C1,tree).splitlines();assert len(changed)==5 and set(changed)==set(candidate)-{'test/fixtures/multiplayer/FourSquares1.verify-trace.txt'},changed
 git('diff','--check',C1,tree)
 commit=git('commit-tree',tree,'-p',C1,input=b'Keep Telugu phone guidance readable and record its simulation identity\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==C1
assert subprocess.check_output(['git','ls-files','-s','-z'])==index_before
assert not subprocess.check_output(['git','status','--porcelain']).strip()
merge=subprocess.run(['git','merge-tree','--write-tree','ffabe1b9ef4e2a9986b1d6321c356124480b8a2d',commit],capture_output=True,text=True);(U/'c2-isolated-merge-tree.txt').write_text(merge.stdout+merge.stderr);assert merge.returncode==0
result={'commit':commit,'tree':tree,'parent':C1,'files':records,'changed_files':changed,'real_checkout_head_after':C1,'default_index_entries_unchanged':True,'real_worktree_clean':True,'source_sha256':json.loads((U/'manifest.json').read_text())['source_sha256'],'canonical_record_sha256':golden['candidate_record']['sha256'],'trace_sha256':golden['candidate_trace']['sha256'],'scope':'Draft implementation commit prepared through an alternate index; actual C1 release builds remain untouched. Final online candidate and browser/mobile gates still pending; no ready/merge claim.'}
(U/'c2-isolated-commit.json').write_text(json.dumps(result,indent=2)+'\n');print(commit)
