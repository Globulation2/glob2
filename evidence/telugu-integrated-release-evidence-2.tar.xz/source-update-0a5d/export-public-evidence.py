"""Export only an actually audited final campaign, never a pending gate."""
from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile
U=Path(__file__).resolve().parent;P=U.parent;ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'tools/localization'));import translation_program as program
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip()
m=json.loads((U/'manifest.json').read_text());r=json.loads((U/'reviews/te.json').read_text());issues=program.audit_locale(U,m,r,'te');assert not issues,issues
assert m['source_sha256']==program.sources()[4]
assert (U/'drafts/te/texts.te.txt').read_bytes()==(ROOT/'data/texts.te.txt').read_bytes()
assert (U/'drafts/te/te.json').read_bytes()==(ROOT/'platform/packages/i18n/locales/te.json').read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest();files=set()
for folder in ['source','batches','drafts','reviews','audit-batches']:
 for file in (U/folder).rglob('*'):
  if file.is_file() and file.suffix in ('.json','.txt'):files.add(file)
# Gate evidence is explicit and checksum-validated by audit_locale above.
for gate in r['gates'].values():
 for item in gate['evidence']:
  f=Path(item['path']);f=f if f.is_absolute() else U/f
  assert f.resolve().is_relative_to(P.resolve()),f
  files.add(f.resolve())
# Fresh visual/runtime/provenance evidence is opted in by a maintained inventory;
# raw APIs, credentials, lease/state files, binaries and dependency trees excluded.
for name in json.loads((U/'supplemental-public-files.json').read_text()):
 f=(P/name).resolve();assert f.is_relative_to(P.resolve()) and f.is_file(),f
 assert f.suffix in ('.json','.log','.txt','.xml','.png','.gz','.py','.cjs','.diff','.patch','.g2mr','.world','.checksums','.replay','.ts'),f
 assert not any(part in ('google','sdl-prefix','node_modules') for part in f.parts)
 assert f.name not in ('state.json','lease.json','ledger.json'),f
 files.add(f)
entries={str(f.relative_to(P)):f.read_bytes() for f in sorted(files)}
ledger=json.loads((P/'google/ledger.json').read_text());reserved=sum(a['reserved_microdollars'] for a in ledger['attempts']);assert reserved<=9_000_000
entries['current-budget-summary.json']=(json.dumps({'gross_reserved_usd':reserved/1_000_000,'cap_usd':9,'attempts':len(ledger['attempts']),'policy':'Full request reservation before sending, including retries and uncertain outcomes; no free-credit assumption.'},indent=2)+'\n').encode()
entries['README-current.txt']=(f'Telugu source-current supplemental release evidence\nPR https://github.com/Globulation2/glob2/pull/1321\nImplementation {revision}\nSource contract {m["source_sha256"]}\n\nExtract the original linguistic/native and E5 checkpoints first, then this uniquely named supplemental packet. Earlier packets and their actual producer identities remain immutable. Exact producers and explicit limits are recorded per report. Historical samples are carried only through exact unchanged source/target/component proofs; they are never relabeled as newly executed.\n\nAgent-reviewed, not native-human-certified. No raw credentials/API responses/SDKs/binaries are included.\n').encode()
assert all(':' not in n and '\\' not in n and not n.startswith('/') and '..' not in Path(n).parts for n in entries), 'Nonportable evidence member path'
# Keep every required original/report, but split deterministic packets so each
# GitHub review blob remains bounded; no measurement/screenshot is truncated.
limit=64*1024**2;chunks=[];chunk={};size=0
for name,blob in sorted(entries.items()):
 assert len(blob)<=limit,name
 if chunk and size+len(blob)>limit:chunks.append(chunk);chunk={};size=0
 chunk[name]=blob;size+=len(blob)
if chunk:chunks.append(chunk)
archives=[]
for index,chunk in enumerate(chunks,1):
 chunk['SHA256SUMS']=''.join(sha(b)+'  '+n+'\n' for n,b in sorted(chunk.items())).encode()
 name='telugu-integrated-release-evidence'+('' if index==1 else '-'+str(index))+'.tar.xz'
 out=P/name;tmp=out.with_name(out.name+'.tmp')
 with tarfile.open(tmp,'w:xz',preset=3) as t:
  for n,b in sorted(chunk.items()):
   item=tarfile.TarInfo(n);item.size=len(b);item.mode=0o644;item.mtime=0;t.addfile(item,io.BytesIO(b))
 assert tmp.stat().st_size<=80*1024**2,'Exceeded bounded public evidence packet'
 tmp.replace(out);archives.append({'source_revision':revision,'phase':'source-current supplemental audited Telugu localization','part':index,'parts':len(chunks),'file':name,'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'files':len(chunk)})
meta={'source_revision':revision,'phase':'source-current supplemental audited Telugu localization','archives':archives,'files':sum(a['files'] for a in archives),'bytes':sum(a['bytes'] for a in archives)}
(U/'supplemental-evidence-export.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
