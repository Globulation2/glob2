from pathlib import Path
import subprocess,json,hashlib,re
B=Path('artifacts/localization-telugu/source-update-0a5d');O='053b70a0904501060aa226d89b3d67e83d8a1b5e';M='0a5d4f68d9b8ad6faa6f4a67ab7167f3104101eb';get=lambda r,p:subprocess.check_output(['git','show',r+':'+p]).decode();sha=lambda s:hashlib.sha256(s.encode()).hexdigest();rows=[]
def write(p,s,note):
 q=B/'candidate'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s);rows.append({'path':p,'sha256':sha(s),'note':note})
def block(s,marker):
 start=s.index(marker);i=s.index('{',start);n=0
 for j in range(i,len(s)):
  if s[j]=='{':n+=1
  elif s[j]=='}':
   n-=1
   if n==0:return s[start:j+1]
 raise Exception(marker)
for p in ['data/texts.list.txt','data/texts.incomplete.txt']:
 s=get(M,p);lines=s.splitlines();assert not any(x.lstrip('*')=='data/texts.te.txt' for x in lines);lines.append('data/texts.te.txt');write(p,'\n'.join(lines)+'\n','Preserve actualpublished0a5order inclta/mr; append complete reviewednativeTeLAST. Englishindexunchanged; native3412complete.')
p='libgag/src/FontKerningTest.cpp';s=get(M,p)
def addte(m):
 text=m.group(0)
 return text[:-2]+', "te"})' if '"hi"' in text and '"te"' not in text else text
# Match both temporary inventory and switching loop; preserve mr hi→mr→hi repeats.
s=re.sub(r'for \(const char \*code : \{[^}]+\}\)',addte,s)
needle='std::string(code) == "gu" ? "ગુજરાતી ખેલાડી" :';assert needle in s;s=s.replace(needle,'std::string(code) == "te" ? "తెలుగు క్రీడాకారుడు" :\n\t\t\t\t\t'+needle);write(p,s,'Keep allTamilfractional/vowel/cluster tests, MRroundtrip/sample, BNtests; restoreTeinventory+switch+sample.')
p='src/app/SystemLanguageTest.cpp';s=get(M,p);needle='\t\tCHECK(code("hi", "IN") == "hi");';assert needle in s;s=s.replace(needle,needle+'\n\t\tCHECK(code("te", "IN") == "te");\n\t\tCHECK(code("te-Telu-IN") == "te");\n\t\tCHECK(code("te-Latn").empty());\n\t\tCHECK(code("te-u-nu-latn") == "te");');s=s.replace('PreferredLocales locales("xx_XX,pt_BR,en_US");','PreferredLocales locales("xx_XX,te-Latn-IN,pt_BR,en_US");');old=get(O,p);te=block(old,'\tTEST_CASE("startup selects installed Telugu and preserves a saved language")');last=s.rfind('\n}');s=s[:last]+'\n'+te+'\n'+s[last:];write(p,s,'Preserveallpublishedta/mr/bn/ms/nb tests plusTe4mappings/startup/wrongscriptfallback; no duplicatecases.')
p='src/scripting/sgsl/LegacyScriptCoverageTest.cpp';s=get(O,p);up=get(M,p);s=s.replace('const std::string& excludedLanguage = {})','const std::string& excludedLanguage = {}, bool publishedWithoutTelugu = false)');needle="        if (entry.empty() || (!excludedLanguage.empty()";i=s.index(needle);end=s.index('\n',i);s=s[:end]+ '\n        // Marathi was published before this PR; omit its later Telugu addition in that historical fixture.\n        if (publishedWithoutTelugu && entry == "data/texts.te.txt") continue;'+s[end:]
# Preserve all three incoming Marathi tests verbatim except adapting helper calls to scoped historical inventory.
new=[]
for title in ['Marathi SGSL language tokens require the installed catalog','Marathi SGSL selects its message and retains an authored default for other locales','adding Marathi preserves legacy SGSL source bytes and saved program counters']:
 t=block(up,'    TEST_CASE("'+title+'")');t=t.replace('loadLanguageInventory(listing, false, "mr")','loadLanguageInventory(listing, "mr", true)').replace('loadLanguageInventory(listing, true, "mr")','loadLanguageInventory(listing, {}, true)');new.append(t)
marker='    TEST_CASE("catalog languages and quoted locale names preserve suspended story continuation")';assert marker in s;s=s.replace(marker,'\n\n'.join(new)+'\n\n'+marker);write(p,s,'Keepcomplete053 genericMalay/Te/source+save tests; retainall3incomingMR tests inclallpublishedIDinvariance/MSsave bytes. MRhistoricalbaselineexcludesunpublishedTeconsistently, Teappendtestskeepallpublishedta/mr.')
# Derived core font receipt: exact final autonym character union, font output stays published byte-identical.
chars=set()
for p in subprocess.check_output(['git','ls-tree','-r','--name-only',M,'data'],text=True).splitlines():
 if not(Path(p).name.startswith('texts.') and p.endswith('.txt')):continue
 lines=get(M,p).split('\n')
 for i,l in enumerate(lines[:-1]):
  if l in ('[language]','[language incomplete]'):chars.update(lines[i+1])
lines=get(O,'data/texts.te.txt').split('\n')
for i,l in enumerate(lines[:-1]):
 if l in ('[language]','[language incomplete]'):chars.update(lines[i+1])
p='browser/assets/sources.json';d=json.loads(get(M,p));d['browser/assets/sans-core.ttf']['languageNames']=sha(''.join(sorted(chars)));write(p,json.dumps(d,indent=2,sort_keys=True)+'\n','Exactincomingreceipts+ta/mr/Teautonymhashunion; sourcefontandcorefontbyteunchanged.')
p='test/deployment/test_browser_font_types.py';s=get(M,p);needle="            (root / 'locales/bn.json').write_bytes";i=s.index(needle);s=s[:i]+"            (root / 'locales/te.json').write_bytes('{\"Game text field\":\"ఆటలో టెక్స్ట్ ఫీల్డ్\"}\\n'.encode())\n"+s[i:];s=s.replace("('locales/mr.json', 'application/json'), ('locales/bn.json', 'application/json')", "('locales/mr.json', 'application/json'), ('locales/te.json', 'application/json'), ('locales/bn.json', 'application/json')");write(p,s,'Retainincomingactualmr/bn/Caddyfont tests andactualTeluguJSONmime fixture; allpinnedscriptfontstested.')
# Fulladvanced053 harness + all incomingTamil helper/probes and fractional matrix implementation.
p='tools/TranslationPreviewHarness.cpp';s=get(O,p);up=get(M,p)
for inc in ['#include "tutorial/TutorialGuidance.h"','#include <utility>']:
 if inc not in s:s=s.replace('#include "tutorial/TutorialModel.h"', '#include "tutorial/TutorialModel.h"\n'+inc) if 'TutorialGuidance' in inc else s.replace('#include <vector>','#include <vector>\n'+inc)
helpers=[]
for marker in ['    static bool briefingTabShown(', '    static Tutorial::Guidance *guidance(', '    static bool openLiveStatistics(', '    static InGameStatisticsPanel &liveStatistics(', '    static void closeLiveStatistics(']:helpers.append(block(up,marker))
pos=s.index('    static void rebaseViewport(');s=s[:pos]+'\n'.join(helpers)+'\n'+s[pos:]
oursMatrix=block(s,'void fontMatrix(');newMatrix=block(up,'void fontMatrix(');s=s.replace(oursMatrix,newMatrix)
# Preserve optional actualguidancecollapse andgameplaylivenavigation probes; untouched053modalinitial/control/twelvefieldguards.
guidance=block(up,'        if (tutorial) {\n            auto *card =');needle='        if (kind != "statistics") capture(captureKind);';assert needle in s;s=s.replace(needle,needle+'\n'+guidance)
live=block(up,'        if (kind == "gameplay") {\n            const auto before');needle='        gui.isRunning = false;';assert needle in s;s=s.replace(needle,live+'\n'+needle)
assert 'baseline_stability_differing_pixels' in s and 'briefing-initial-frame' in s and 'raster_scales' in s and 'live_statistics_probe' in s;write(p,s,'Keepentire053productionStatisticsHost adapter, exactchecksum/initial/control/ROI guards andalladvancedmodes. UnionallTamilrealguidance/liveStats helpers/probes andfractionals1/1.5/2 matrix. No newoptionalcohortrun requested.')
r={'state':'Ignored-only native/browser/test/harness union candidates; no trackedwrites/builds','ours':O,'actual_merge_head':M,'files':rows,'font_cases':len(re.findall('TEST_CASE\\(', (B/'candidate/libgag/src/FontKerningTest.cpp').read_text())),'system_cases':len(re.findall('TEST_CASE\\(', (B/'candidate/src/app/SystemLanguageTest.cpp').read_text())),'inventory_entries':len((B/'candidate/data/texts.list.txt').read_text().splitlines()),'incomplete_entries':len((B/'candidate/data/texts.incomplete.txt').read_text().splitlines()),'matrix_scales':[1,1.5,2],'notes':['MRhistoricalinventorytestexplicitlyexcludeslaterunpublishedTeinbothloadstoavoidfalseindexshiftclaim. FinalTeappendcaseusesallactualpublishedlanguages.','Incoming1.5scaleisretained; fresh31delta willhave31×3sizes×3scales×2widths=558tuples. Historicalfull1/2coverage remainsseparate77004current after31new372requiredtuples plus186newfractionaldeltas, notfullallcatalog1.5claim.']};(B/'native-union-candidates.json').write_text(json.dumps(r,indent=2)+'\n');print('READY',[(v['path'],v['sha256']) for v in rows]);print('counts',r['font_cases'],r['system_cases'],r['inventory_entries'])
