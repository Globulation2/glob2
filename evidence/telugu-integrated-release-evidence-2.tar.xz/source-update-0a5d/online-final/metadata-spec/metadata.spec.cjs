const {test,expect}=require('/home/bradley/.codex/worktrees/7ed0/glob2/platform/node_modules/@playwright/test');
const fs=require('node:fs');const path=require('node:path');
const root="/home/bradley/.codex/worktrees/7ed0/glob2";
const te=JSON.parse(fs.readFileSync(path.join(root,'platform/packages/i18n/locales/te.json'),'utf8'));
test('Telugu actual finance and skin metadata render with canonical selections',async({page,context,request},info)=>{
 const base=String(info.project.use.baseURL);const seed=await(await request.get('/__seed')).json();
 await context.addCookies([{name:'glob2_locale',value:'te',url:base},{name:'glob2_session',value:seed.adminSession,url:base}]);
 await page.emulateMedia({reducedMotion:'reduce'});
 const capture=async name=>{
  await expect(page.locator('html')).toHaveAttribute('lang','te');
  expect(await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth),name+'viewport').toBeLessThanOrEqual(1);
  await page.evaluate(()=>document.fonts.ready);
  const out=path.join(process.env.SCREENSHOT_DIR,info.project.name);fs.mkdirSync(out,{recursive:true});
  await page.screenshot({path:path.join(out,'te-metadata-'+name+'.png'),fullPage:true});
 };
 await page.goto('/admin/finances');
 const mode=page.getByLabel(te['Payment mode']);await expect(mode).toBeVisible();
 expect(await mode.locator('option').evaluateAll(xs=>xs.map(x=>[x.value,x.textContent]))).toEqual([
  ['live',te['Live payments']],['test',te['Test payments']],['unclassified',te['Unclassified payments']]
 ]);
 await expect(page.locator('main')).toContainText('USD');await capture('finances');
 await context.addCookies([{name:'glob2_session',value:seed.userSession,url:base}]);
 await page.goto('/skins');
 await page.getByRole('button',{name:te['New skin'],exact:true}).click();
 await expect(page.getByLabel(te['Skin name'])).toBeEnabled();
 const expand=page.getByRole('button',{name:te['Expand toolbox'],exact:true});
 if(await expand.isVisible()) await expand.click();
 await page.getByRole('button',{name:te['Material'],exact:true}).click();
 const scales=page.getByRole('radio',{name:te.Scales,exact:true}).first();await scales.click();
 await expect(scales).toHaveAttribute('aria-checked','true');await capture('materials');
 await page.locator('.skin-models').getByRole('button',{name:te.Explorer,exact:true}).click();
 const fly=page.locator('.skin-actions').getByRole('button',{name:te.Fly,exact:true});await expect(fly).toBeVisible();await fly.click();await expect(fly).toHaveAttribute('aria-pressed','true');await capture('flight');
});
