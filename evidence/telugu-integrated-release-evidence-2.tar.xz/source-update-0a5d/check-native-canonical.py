from pathlib import Path
import hashlib,json,os,subprocess,time
U=Path(__file__).resolve().parent;R=U.parents[2];P=U.parent;B=P/'linux-release-stage/usr/local/bin/glob2';A=P/'linux-release-stage/usr/local/share/glob2';REV='5b2421e8510f85b7538fcaed19fb58c90db71a50';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==REV
assert sha(B)==sha(R/'build/linux/client/release/src/glob2'); assert sha(B)!='28ca0e4b6141c78a280a3482b4f3639d64193761ce1f24fd8e307d9028091d18'
O=U/'compatibility/native-canonical';O.mkdir(parents=True,exist_ok=False)
env=dict(os.environ,SDL_VIDEO_DRIVER='dummy',SDL_AUDIODRIVER='dummy',SDL_PREFERRED_LOCALES='te_IN',LP_NUM_THREADS='2');env.pop('LD_LIBRARY_PATH',None);env.pop('DISPLAY',None);env.pop('WAYLAND_DISPLAY',None)
records={'old-SIM112':U/'compatibility/sim113-identity/before-SIM112.g2mr','new-SIM113':R/'test/fixtures/multiplayer/FourSquares1.g2mr'};results=[]
for name,record in records.items():
 out=O/name;cmd=[str(B),'match','verify',str(record),'--map-file',str(R/'maps/FourSquares1.map.gz'),'--output-dir',str(out)];start=time.monotonic()
 with (O/(name+'.log')).open('w') as f:ret=subprocess.run(cmd,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 assert ret.returncode==0;verdict=json.loads((out/'verdict.json').read_text());assert verdict['verdict']==('unverifiable' if name.startswith('old') else 'verified'),verdict
 item={'record_sha256':sha(record),'command':cmd,'exit_code':ret.returncode,'seconds':time.monotonic()-start,'verdict':verdict}
 if name.startswith('new'):
  trace=out/'checksums.txt';assert trace.read_bytes()==(R/'test/fixtures/multiplayer/FourSquares1.verify-trace.txt').read_bytes();assert sha(trace)=='5a843636b78375d3233d6623bd33cc96a5a5f9c3a18a60443e52515c3de7c56c';rows=trace.read_text().splitlines();ticks=[r for r in rows if r and not r.startswith('#')];assert len(ticks)==842 and ticks[0].startswith('0 ') and ticks[-1].startswith('841 ');item.update(trace_sha256=sha(trace),trace_lines=len(rows),per_tick_checksums=len(ticks))
 results.append(item)
(O/'verification.json').write_text(json.dumps({'status':'PASS','actual_producer':REV,'binary_sha256':sha(B),'results':results,'scope':'Actual optimized staged Linux shipping verifier: old112 unverifiable, current113 verified, all842 canonical per-tick checksums identical; browser agreement is separate.'},indent=2)+'\n');print('PASS old112 boundary/current113 acceptance;842 exact native canonical checksums')
