from pathlib import Path
import subprocess,json,hashlib
R=Path.cwd();B=R/'artifacts/localization-telugu/source-update-1801';C='d005f2d82b5a8f9a6b736fe080625f202e88299e';M='1801e6a832657e183557f225abecee35e23250c2';sha=lambda b:hashlib.sha256(b).hexdigest();show=lambda rev,p:subprocess.check_output(['git','show',rev+':'+p]);assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==C;assert not subprocess.check_output(['git','status','--short'],text=True).strip();rows=[]
for name in ['texts.list.txt','texts.incomplete.txt']:
 p='data/'+name;raw=show(M,p);lines=raw.decode().splitlines();assert not any(x.lstrip('*')=='data/texts.te.txt' for x in lines);te='data/texts.te.txt';lines.append(('*' if name=='texts.incomplete.txt' else '')+te);out=('\n'.join(lines)+'\n').encode();q=B/'candidate'/p;q.write_bytes(out);assert [x for x in lines if x.lstrip('*')!=te]==raw.decode().splitlines();assert len(lines)==len(set(x.lstrip('*') for x in lines));rows.append({'path':p,'master_sha256':sha(raw),'candidate_sha256':sha(out),'entries':len(lines),'english_index':next(i for i,x in enumerate(lines) if x.lstrip('*')=='data/texts.en.txt'),'te_index':len(lines)-1,'bn_index':next(i for i,x in enumerate(lines) if x.lstrip('*')=='data/texts.bn.txt')})
# Exact font payload equality; only our durable README differs.
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',M,'data/fonts'],text=True).splitlines();fonts=[]
for p in paths:
 if p.endswith('/README.md'):continue
 a=show(C,p);b=show(M,p);assert a==b,p;fonts.append({'path':p,'sha256':sha(a),'bytes':len(a)})
chars=set()
for p in subprocess.check_output(['git','ls-tree','-r','--name-only',M,'data'],text=True).splitlines():
 if not(Path(p).name.startswith('texts.') and p.endswith('.txt')):continue
 lines=show(M,p).decode().split('\n')
 for i,l in enumerate(lines[:-1]):
  if l in ('[language]','[language incomplete]'):chars.update(lines[i+1])
lines=show(C,'data/texts.te.txt').decode().split('\n')
for i,l in enumerate(lines[:-1]):
 if l in ('[language]','[language incomplete]'):chars.update(lines[i+1])
r={'state':'Read-only provisional native bn+te union; no tracked mutation/build/commit','current_clean_revision':C,'incoming_master':M,'files':rows,'pending_native_english_key':'[AI for all computer colonies]','te_incomplete_marker':'Candidate marks Te incomplete until new3412nd source key has actual reviewed Telugu value; root must remove marker after review. No draft value invented.','ordering':'Published1801 order preserved exactly, Te appendedLAST; English index7 list/6 incomplete stable. IncomingBNbeforeNB/MS shifts those upstream language IDs; Te39C1→40union.','font_payload_equal':fonts,'font_payload_bytes':sum(x['bytes'] for x in fonts),'font_manifest_blob_equal':subprocess.check_output(['git','rev-parse',C+':data/fonts/scripts/manifest.json'],text=True).strip(),'sans_core_font_blob_equal':subprocess.check_output(['git','rev-parse',C+':browser/assets/sans-core.ttf'],text=True).strip(),'union_language_names_sha256':sha(''.join(sorted(chars)).encode()),'limits':['Does not assert any rendering/runtime gate for1801.','Generated browser i18n/derivedfont receipt must be regenerated from final reviewedunion. Existing corefont bytes are same in C1/master.','FontREADME differs onlydocumentation; actual font/license/manifest bytes all equal.','Root owns full merge/source integration and final new-key translation/reviews.']};(B/'native-inventory-candidate.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(rows,'fonts',len(fonts),r['union_language_names_sha256'])
