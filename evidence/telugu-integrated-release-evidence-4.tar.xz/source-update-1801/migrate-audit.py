"""Validate actual fresh reviews and immutable exact-pair historical coverage."""
import copy,hashlib,json,os,sys,subprocess
from pathlib import Path
U=Path(__file__).resolve().parent;P=U.parent;R=P.parents[1]
sys.path.insert(0,str(R/'tools/localization'));import translation_program as tp
load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canonical=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def ref(p):
 p=Path(p).resolve();return {'path':os.path.relpath(p,U),'sha256':sha(p)}
def write(p,v):tp.write_json(U/p,v)
O=P/'source-update-ffabe';om=load(O/'manifest.json');nm=load(U/'manifest.json');old=load(O/'reviews/te.json')
op=tp.catalog_paths(O,'te');np=tp.catalog_paths(U,'te')
assert old['catalog_sha256']=={s:sha(p) for s,p in op.items()}
assert tp.sources()[4]==nm['source_sha256']
def targets(paths):
 n,err=tp.CHECKER.read_table(paths['native']);assert not err
 return {'native':n,'online':load(paths['online'])}
ot=targets(op);nt=targets(np);ns={s:load(U/'source'/f'{s}.json') for s in nt};osrc={s:load(O/'source'/f'{s}.json') for s in nt};hashes={s:sha(p) for s,p in np.items()}
assert all(np[s].read_bytes()==(R/('data/texts.te.txt' if s=='native' else 'platform/packages/i18n/locales/te.json')).read_bytes() for s in np)
old_batch={k:b['id'] for b in om['batches'] for k in b['keys']};old_rec={b['id']:b for b in old['batches']};old_hashes=tp.batch_target_hashes(om,op)
verified={}
def verify_ref(item,base):
 p=(base/item['path']).resolve();assert sha(p)==item['sha256'],p;verified[str(p)]=ref(p)
for b in om['batches']:
 rec=old_rec[b['id']];assert rec['source_sha256']==om['source_sha256'] and rec['target_sha256']==old_hashes[b['id']]
 assert len({rec[k] for k in ['author','reviewer','editor','adversarial_reviewer']})==4
 for f in ['reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys']:assert len(rec[f])==len(set(rec[f])) and set(rec[f])==set(b['keys'])
 assert rec['rechecked_by']==rec['reviewer']
 for x in rec['evidence']:verify_ref(x,O)
for x in old['evidence']:verify_ref(x,O)
carry={};fresh=[]
for s in nt:
 assert set(nt[s])==set(ns[s]) and not set(osrc[s])-set(ns[s])
 for k,src in ns[s].items():
  identity=s+':'+k
  if k in osrc[s] and src==osrc[s][k] and nt[s][k]==ot[s][k]:
   carry[identity]={'surface':s,'key':k,'old_batch':old_batch[identity],'pair_sha256':hashlib.sha256(canonical({'source':src,'target':nt[s][k]})).hexdigest()}
  else:fresh.append(identity)
assert len(carry)==6358 and len(fresh)==1 and fresh==['native:[AI for all computer colonies]']
reports={role:load(U/name) for role,name in {'author':'author-one-key.json','reviewer':'semantic-one-key.json','editor':'editor-one-key.json','adversarial_reviewer':'adversarial-one-key.json'}.items()}
roles={role:report.get(role,report.get('reviewer')) for role,report in reports.items()};assert len(set(roles.values()))==4
for role,report in reports.items():
 assert report['status']=='PASS' and report['source_sha256']==nm['source_sha256'] and report.get('catalog_sha256',{'native':report.get('native_catalog_sha256'),'online':report.get('online_catalog_sha256')})==hashes
 entries=report['entries'];assert len(entries)==len(fresh) and {('native:'+e['key']) for e in entries}==set(fresh)
 assert not report.get('unresolved_findings',[])
 for e in entries:assert e['source']==ns['native'][e['key']] and e['target']==nt['native'][e['key']]
freshrefs=[ref(U/name) for name in ['author-one-key.json','semantic-one-key.json','editor-one-key.json','adversarial-one-key.json']]
proof={'source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'historical_source_sha256':om['source_sha256'],'historical_record':ref(O/'reviews/te.json'),'unchanged_pairs':6358,'native_unchanged_pairs':3411,'online_unchanged_pairs':2947,'freshly_reviewed_keys':fresh,'four_role_evidence':freshrefs,'pairs':carry,'historical_evidence_files_verified':list(verified.values()),'method':'Exact decoded English AND Telugu pair comparison. Historical reviews retained, not relabeled as fresh reads. The one new native all-colonies AI label was actually read by four distinct roles, including final semantic recheck.'}
write('audit-exact-pair-carry.json',proof)
bhash=tp.batch_target_hashes(nm,np);records=[]
for b in nm['batches']:
 carried=[k for k in b['keys'] if k in carry];read=[k for k in b['keys'] if k in fresh];bproof={'id':b['id'],'source_sha256':nm['source_sha256'],'target_sha256':bhash[b['id']],'carried_keys':carried,'fresh_keys':read,'historical_roles':{bid:{r:old_rec[bid][r] for r in roles} for bid in sorted({carry[k]['old_batch'] for k in carried})},'new_key_roles':roles if read else {},'evidence':[ref(U/'audit-exact-pair-carry.json'),*(freshrefs if read else [])]}
 write('audit-batches/'+b['id']+'.json',bproof)
 records.append({'id':b['id'],**roles,'source_sha256':nm['source_sha256'],'target_sha256':bhash[b['id']],'reviewed_keys':b['keys'],'edited_keys':b['keys'],'rechecked_keys':b['keys'],'rechecked_by':roles['reviewer'],'adversarial_reviewed_keys':b['keys'],'semantic_final_fresh_keys':read,'semantic_final_exact_carry_keys':carried,'review_method':proof['method'],'evidence':[ref(U/('audit-batches/'+b['id']+'.json'))]})
checked=tp.check_draft(U,'te');assert not checked['errors'] and not checked['untranslated']
accepted=copy.deepcopy(old['accepted_english']);assert set(checked['same_as_english_review_queue'])=={e['key'] for e in accepted},'New English-identical exceptions need individual actual review'
write('audit-migration-structural.json',{'source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'result':checked,'accepted_english':accepted,'historical_record':ref(O/'reviews/te.json')})
record={'locale':'te','source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'batches':records,'findings':copy.deepcopy(old['findings']),'language_brief':copy.deepcopy(old['language_brief']),'accepted_english':accepted,'gates':{},'evidence':[ref(O/'reviews/te.json'),ref(U/'audit-exact-pair-carry.json'),*freshrefs],'review_coverage':{'native_keys':3412,'online_keys':2947,'total_keys':6359,'source_batch_count':len(nm['batches']),'exact_pair_carries':6358,'actually_fresh_key_reads':1,'four_distinct_roles':roles,'historical_coverage':old['review_coverage'],'method':proof['method']},'certification':'Agent-reviewed; not native-human-certified','release_readiness':'Language complete; affected rendering/runtime/package gates pending fresh evidence.'}
for name in tp.GATES:
 gate={'passed':False,'source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'evidence':[],'scope':'Pending affected final-source rendering/runtime/package evidence.'}
 if name in ['language_brief','source_based_pilot']:
  og=old['gates'][name];assert og['passed'];[verify_ref(x,O) for x in og['evidence']]
  wrapper={'source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'historical_gate':og,'historical_evidence':[ref((O/x['path']).resolve()) for x in og['evidence']],'pair_carry':ref(U/'audit-exact-pair-carry.json'),'new_domain_reviews':freshrefs,'scope':'Same Telugu variety/script/glossary; unchanged original pilot retained. One new native all-colonies AI label reviewed in actual source context; no claim of fresh wholepilot execution.'}
  write('audit-'+name+'-carry.json',wrapper);gate.update(passed=True,evidence=[ref(U/('audit-'+name+'-carry.json'))],scope=wrapper['scope'])
 elif name=='structural':gate.update(passed=True,evidence=[ref(U/'audit-migration-structural.json'),ref(U/'audit-exact-pair-carry.json')],scope='Fresh complete6359-key contract and all individually justified exact English exceptions.')
 record['gates'][name]=gate
write('reviews/te.json',record);issues=tp.audit_locale(U,nm,record,'te');assert set(issues)=={n+' is pending or lacks evidence' for n in tp.GATES[3:]},issues
write('audit-migration-validation.json',{'source_current':True,'keys':6359,'carried':6358,'fresh':1,'batches':len(records),'expected_pending_issues':issues,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()});print(json.dumps({'keys':6359,'carry':6358,'fresh':1,'pending':issues}))
