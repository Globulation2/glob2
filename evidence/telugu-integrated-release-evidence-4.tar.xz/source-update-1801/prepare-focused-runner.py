from pathlib import Path
B=Path('artifacts/localization-telugu/source-update-1801/rendering');B.mkdir(exist_ok=True);O=Path('artifacts/localization-telugu/source-update-ffabe/rendering')
s=(O/'run-focused-c1.py').read_text();s=s.replace("matrix-overlay/online.json","matrix-overlay/native.json").replace('len(matrix)==112','len(matrix)==1').replace("meta['native_entries']==3411","meta['native_entries']==3412").replace("'final-C1-SIM112'","'latest-1801-integration'")
a=s.index("cases=[('matrix'");b=s.index('results=[]',a)
s=s[:a]+"cases=[('matrix',640,960,None,False),('matrix',1280,960,None,False),('screen',800,600,'lobby',False),('screen',390,844,'lobby',True)]\nfor w,h,c in [(1280,800,False),(800,600,False),(390,844,True)]:cases.append(('screen',w,h,'lobby-players',c))\ncases += [('game',800,600,'tutorial:swimming',False),('game',390,844,'ingame-statistics:overview',True)]\n"+s[b:]
a=s.index("'limits':[");b=s.index('},indent=2)',a)
s=s[:a]+"'limits':['One newly reviewednativekey12tuplematrix; earlier exactsource/targetfontmatrixproofs carried through unchangedfontinputs and verifiednormalwrapalgorithm, not freshfullcatalogclaim.','Actual maplobby800/390, playerslobby3sizes/newallAIlabel, swimming800mandatoryrealmodalROI, onecompactoverviewforcurrentproductionstatisticsHostadapter.','Root independently verifies actualnewnativewhole-editrejectinput contract; browseragent owns actualnew40locales6startup/compatibility packages.','Compactlayoutisdesktopengine,notAndroiddeviceproof.']"+s[b:]
(B/'run-focused-latest.py').write_text(s)
# New audit is intentionally independent of old C1 fixedphase/revision guard.
s=(O/'audit-focused-c1.py').read_text();s=s.replace("p.add_argument('output',type=pathlib.Path);a=p.parse_args();a.phase='final-C1-SIM112';a.expected_keys=112;a.expected_native=3411","p.add_argument('output',type=pathlib.Path);p.add_argument('--revision',required=True);a=p.parse_args();a.phase='latest-1801-integration';a.expected_keys=1;a.expected_native=3412")
s=s.replace("assert REV=='d005f2d82b5a8f9a6b736fe080625f202e88299e'","assert REV==a.revision").replace('matrix-overlay/online.json','matrix-overlay/native.json').replace("s['surface']=='online'","s['surface']=='native'").replace("(0 if 'matrix' in path.parent.name else a.expected_native)","(1 if 'matrix' in path.parent.name else a.expected_native)").replace("==22 and all","==9 and all").replace('assert len(identities)==22','assert len(identities)==9').replace("'actual_ui_cases':20","'actual_ui_cases':7")
needle="assert len(identities)==9";s=s.replace(needle,needle+"\nmodal=[]\nfor p in OUT.rglob('*.json'):\n d=json.loads(p.read_text())\n if isinstance(d,dict) and d.get('tutorial_lesson')=='swimming':\n  m=d['modal_highlight_comparison'];assert m['differing_pixels']==m['restoration_differing_pixels']==0;assert m['baseline_roi_sha256']==m['probe_roi_sha256']==m['restored_roi_sha256'];assert m['probe_arrow_count']==m['baseline_arrow_count']+1;assert m['checksum_before']==m['checksum_after'];assert d['tutorial_briefing_available'] and d['briefing_dismissed'];modal.append(m)\nassert len(modal)==1")
s=s.replace("'matrix_samples':sum(m['samples'] for m in matrices)","'actual_modal_highlight_regression':modal[0],'matrix_samples':sum(m['samples'] for m in matrices)")
(B/'audit-focused-latest.py').write_text(s)
# Generate guarded overlays only after root supplies a clean finalrevision.
s='''#!/usr/bin/env python3
from pathlib import Path
import argparse,subprocess,hashlib,json
B=Path(__file__).resolve().parent;ROOT=B.parents[3];p=argparse.ArgumentParser();p.add_argument('--revision',required=True);a=p.parse_args();REV=a.revision
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==REV;assert not subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True).strip()
A=json.loads((B.parent/'author-one-key.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();nativepath=ROOT/'data/texts.te.txt';onlinepath=ROOT/'platform/packages/i18n/locales/te.json';assert sha(nativepath)==A['catalog_sha256']['native'];assert sha(onlinepath)==A['catalog_sha256']['online'];lines=nativepath.read_text().splitlines();assert len(lines)%2==0;native=dict(zip(lines[::2],lines[1::2]));online=json.loads(onlinepath.read_text());assert len(native)==3412 and len(online)==2947;e=A['entries'][0];assert native[e['key']]==e['target'];meta={'locale':'te','requested_producer_revision':REV,'combined_frozen_source_sha256':A['source_sha256'],'canonical_native_catalog_sha256':sha(nativepath),'canonical_online_catalog_sha256':sha(onlinepath),'native_entries':3412,'online_entries':2947,'scope':'Actual latest1801 integrated input; one approvednativekey12tupledelta, no syntheticUI; oldC1proofshistorical.'}
for name,n,o in [('matrix-overlay',{e['key']:e['target']},{}),('full-overlay',native,online)]:
 d=B/name;assert not d.exists();d.mkdir();(d/'native.json').write_text(json.dumps(n,ensure_ascii=False,indent=2)+'\\n');(d/'online.json').write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\\n');(d/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\\n')
print('Prepared3412native/2947online full +1native delta at',REV)
'''
(B/'prepare-overlays-latest.py').write_text(s)
import py_compile
for p in B.glob('*.py'):py_compile.compile(str(p),doraise=True)
print('Preparedlatestparametric9case runner/auditor+guardedoverlaypreparer; not executed')
