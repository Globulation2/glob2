from pathlib import Path
import hashlib,json,subprocess,datetime,sys,os
root=Path.cwd(); base=root/'artifacts/thai-localization-release'; checks=base/'checks';checks.mkdir(exist_ok=True)
expected='667b2624f356a8c3f0d005535f54ffb0e46b6619'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
if head!=expected or subprocess.check_output(['git','status','--porcelain'],text=True).strip():raise SystemExit('Require clean intended qualification revision667')
if Path('/proc/2918804').exists():raise SystemExit('Original SCons still active; no overlapping build')
if 'scons: done building targets.' not in (root/'artifacts/thai-localization/checks/wasm-final-integrated-release-build.log').read_text(errors='replace'):raise SystemExit('Original SCons done marker absent')
# Root must separately confirm original session exit0 before invocation.
record={'source':head,'working_tree_clean_before':True,'original_exit_confirmation':os.environ.get('GLOB2_ORIGINAL_SCONS_EXIT_CONFIRMATION'),'scope':'Fresh release both-variant refresh and immutable browser package; no runtime test claim','commands':[]}
if record['original_exit_confirmation']!='root-confirmed-exit-0':raise SystemExit('Explicit original success confirmation required')
manifest=base/'reviews/browser-build-package-provenance.json'
def write():manifest.write_text(json.dumps(record,indent=2)+'\n')
def run(cmd,name):
 item={'argv':cmd,'cwd':str(root),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(checks/name)};record['commands'].append(item);write()
 with (checks/name).open('w') as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 item.update(exit_code=result.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=hashlib.sha256((checks/name).read_bytes()).hexdigest());write()
 if result.returncode:raise SystemExit(result.returncode)
run(['scons','target=web','release=1','--build=build/thai-browser','-j6'],'wasm-final-refresh-build.log')
if subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()!=head:raise SystemExit('Source changed during build: requalify')
package=base/'browser-package'
if package.exists():raise SystemExit('Refuse overwrite existing package')
run(['python3','browser/package-static.py','--source','build/thai-browser','--output',str(package)],'wasm-final-package.log')
run(['python3','browser/package-static.py','--verify',str(package)],'wasm-final-package-verify.log')
record['package_dir']=str(package);record['package_files_sha256']={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(package.rglob('*')) if p.is_file()};record['package_manifest']=json.loads((package/'package.json').read_text())
empp=Path('/home/bradley/.local/share/glob2/development/toolchains/emscripten/Linux-x86_64-88a621bc131cd4954413aa39/upstream/emscripten/em++')
record['compiler_version']=subprocess.check_output([str(empp),'--version'],text=True)
record['source_targets']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('data/texts.th.txt'),Path('platform/packages/i18n/locales/th.json'),Path('data/fonts/scripts/NotoSansThai-Regular.ttf')]}
record['working_tree_clean_after']=not bool(subprocess.check_output(['git','status','--porcelain'],text=True).strip());record['status']='BUILD_AND_PACKAGE_PASS_RUNTIME_QUALIFICATION_PENDING';write();print(json.dumps({'status':record['status'],'package':str(package),'files':len(record['package_files_sha256'])}))
