from pathlib import Path
import subprocess,json,hashlib,shutil
U=Path(__file__).resolve().parent;r=json.loads((U/'final-platform-candidate-files.json').read_text());assert r['format_exit_code']==0
for entry in r['files']:
 name=entry['path'];src=U/'candidate'/name;assert hashlib.sha256(src.read_bytes()).hexdigest()==entry['sha256'];shutil.copyfile(src,name)
for name in ['src/app/Settings.cpp','src/hud/draw/GameGUIDraw.cpp','test/deployment/test_browser_font_types.py']:
 subprocess.run(['git','restore','--source=1801e6a832','--worktree','--',name],check=True)
p=Path('test/deployment/test_browser_font_types.py');s=p.read_text();needle="            paths += [('fonts/' + font['name'] + '-Regular.ttf', 'font/ttf') for font in manifest['fonts']]";assert s.count(needle)==1;s=s.replace(needle,"            (root / 'locales/te.json').write_bytes((ROOT / 'platform/packages/i18n/locales/te.json').read_bytes())\n            paths.append(('locales/te.json', 'application/json'))\n"+needle);p.write_text(s)
p=Path('src/game/screens/CustomGameSetupHarness.cpp');s=p.read_text();start=s.index('<<<<<<< HEAD\n');middle=s.index('=======\n',start);end=s.index('>>>>>>> 1801e6a832\n',middle);s=s[:start]+s[start+len('<<<<<<< HEAD\n'):middle]+s[middle+len('=======\n'):end]+s[end+len('>>>>>>> 1801e6a832\n'):];assert '<<<<<<<' not in s;p.write_text(s)
p=Path('src/ui/settings/SettingsGraphicsTest.cpp');s=p.read_text();start=s.index('    TEST_CASE("player names preserve UTF-8 boundaries');end=s.index('    TEST_CASE("retired gradient',start)
s=s[:start]+'''    TEST_CASE("Telugu player names reject oversized edits and preserve saved preferences [writes-preferences]")
    {
        glob2test::HeadlessGlobals globals;
        Settings settings;
        for (const std::string input : {std::string(), std::string("ASCII player"),
             std::string("తెలుగు"), std::string(32, 'a'), std::string(29, 'a') + "గ"})
        {
            settings.setUsername(input);
            CHECK(settings.getUsername() == input);
        }
        settings.setUsername("తెలుగు");
        for (const std::string oversized : {std::string("తెలుగు పరీక్ష"),
             std::string(33, 'a'), std::string(31, 'a') + "é", std::string(31, 'a') + "😀"})
        {
            settings.setUsername(oversized);
            CHECK(settings.getUsername() == "తెలుగు");
        }
        settings.language = "te";
        const std::string file = "telugu-player-preferences.txt";
        REQUIRE(settings.save(file));
        Settings loaded;
        loaded.load(file);
        CHECK(loaded.getUsername() == "తెలుగు");
        CHECK(loaded.language == "te");
        std::filesystem::remove(std::filesystem::path(GAGCore::Toolkit::getFileManager()->getDir(0)) / file);
    }

'''+s[end:];p.write_text(s)
print('Applied48 platform candidates and preserved latest input/modal policies')
