from pathlib import Path
import hashlib,json,os,subprocess,time
U=Path(__file__).resolve().parent;R=U.parents[2];P=U.parent;B=P/'linux-release-stage/usr/local/bin/glob2';A=P/'linux-release-stage/usr/local/share/glob2';REV='f54ed7cd3913b95beb9f92bb0162260c2bc3a323';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==REV
assert sha(B)==sha(R/'build/linux/client/release/src/glob2'); assert sha(B)!='096845c69826083ae8a558e166375370156c3fa930d3cc44bf026089e57a0314'
O=U/'compatibility/native-canonical-f54';O.mkdir(parents=True,exist_ok=False)
env=dict(os.environ,SDL_VIDEO_DRIVER='dummy',SDL_AUDIODRIVER='dummy',SDL_PREFERRED_LOCALES='te_IN',LP_NUM_THREADS='2');env.pop('LD_LIBRARY_PATH',None);env.pop('DISPLAY',None);env.pop('WAYLAND_DISPLAY',None)
records={'old-SIM111':P/'source-update-ffabe/compatibility/before-sim112-FourSquares1.g2mr','new-SIM112':R/'test/fixtures/multiplayer/FourSquares1.g2mr'};results=[]
for name,record in records.items():
 out=O/name;cmd=[str(B),'match','verify',str(record),'--map-file',str(R/'maps/FourSquares1.map.gz'),'--output-dir',str(out)];start=time.monotonic()
 with (O/(name+'.log')).open('w') as f:ret=subprocess.run(cmd,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 assert ret.returncode==0;verdict=json.loads((out/'verdict.json').read_text());assert verdict['verdict']==('unverifiable' if name.startswith('old') else 'verified'),verdict
 item={'record_sha256':sha(record),'command':cmd,'exit_code':ret.returncode,'seconds':time.monotonic()-start,'verdict':verdict}
 if name.startswith('new'):
  trace=out/'checksums.txt';assert trace.read_bytes()==(R/'test/fixtures/multiplayer/FourSquares1.verify-trace.txt').read_bytes();assert sha(trace)=='5a843636b78375d3233d6623bd33cc96a5a5f9c3a18a60443e52515c3de7c56c';item.update(trace_sha256=sha(trace),checksums=len(trace.read_text().splitlines()))
 results.append(item)
(O/'verification.json').write_text(json.dumps({'status':'PASS','actual_producer':REV,'binary_sha256':sha(B),'results':results,'scope':'Actual optimized staged Linux shipping verifier: old111 unverifiable, current112 verified, all842 canonical per-tick checksums identical; browser agreement is separate.'},indent=2)+'\n');print('PASS old111 boundary/current112 acceptance;842 exact native canonical checksums')
