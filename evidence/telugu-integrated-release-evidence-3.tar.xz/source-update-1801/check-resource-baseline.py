"""Attribute an existing golden mismatch without changing a fixture."""
from pathlib import Path
import hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
U=Path(__file__).resolve().parent;R=U.parents[2];HEAD='053b70a0904501060aa226d89b3d67e83d8a1b5e';BASE='1801e6a832657e183557f225abecee35e23250c2';B=R/'build/linux/client/release/test/glob2-engine-tests'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()
OUT=U/'compatibility/resource-baseline';OUT.mkdir(parents=True,exist_ok=False)
paths=['src/game/Game_io.cpp','src/map/io/MapHeader.cpp','src/map/TerrainResourcesHarness.cpp','test/support/EngineFixtures.cpp','test/support/EngineFixtures.h','src/scripting/sgsl/SGSL.cpp','src/scripting/sgsl/SGSL.h','src/app/Version.h','test/fixtures/resources/seeded-compositions-units.trace']
closure=[]
for name in paths:
 actual=(R/name).read_bytes();base=subprocess.check_output(['git','show',BASE+':'+name],cwd=R);assert actual==base,name
 closure.append({'path':name,'sha256':hashlib.sha256(actual).hexdigest(),'same_as_master':BASE})
# HeadlessGlobals default has loadStrings=false: this case never loads the language inventory.
cmd=[str(B),'--test-suite=RuntimeResources','--test-case=frozen seeded resource compositions*','--reporters=junit','--out='+str(OUT/'tests.xml')]
env=dict(os.environ,GLOB2_TEST_SOURCE_ROOT=str(R),GLOB2_TEST_ARTIFACTS_ROOT=str(OUT/'cases'),GLOB2_USER_DATA_DIR=str(OUT/'profile'),SDL_VIDEO_DRIVER='dummy',SDL_AUDIODRIVER='dummy',LD_LIBRARY_PATH=str(R/'artifacts/localization-telugu/rendering/sdl-prefix/lib'),LP_NUM_THREADS='2')
for name in ['GLOB2_TEST_UPDATE_FIXTURES','GLOB2_TEST_ARTIFACTS','DISPLAY','WAYLAND_DISPLAY']:env.pop(name,None)
start=time.monotonic()
with (OUT/'run.log').open('w') as f:ret=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
traces=list((OUT/'cases').rglob('seeded-compositions.trace'));assert len(traces)==1
expected=(R/'test/fixtures/resources/seeded-compositions-units.trace').read_text().splitlines();actual=traces[0].read_text().splitlines();assert len(expected)==len(actual)==150
mask=((186^191)>>9|((186^191)<<(32-9)))&0xffffffff
for e,a in zip(expected,actual):
 e=e.split();a=a.split();assert len(e)==len(a)==4 and e[:2]==a[:2] and e[3]==a[3];assert int(e[2])^int(a[2])==mask,(e,a)
assert ret.returncode!=0,'Golden was expected to expose the existing stale version checksum'
xml=ET.parse(OUT/'tests.xml').getroot();failures=list(xml.iter('failure'));assert len(failures)==1 and 'golden mismatch' in ET.tostring(failures[0],encoding='unicode'),ET.tostring(xml,encoding='unicode')
v={'result':'ATTRIBUTED pre-existing master golden mismatch; not a passing golden test','source_revision':HEAD,'master':BASE,'command':cmd,'exit_code':ret.returncode,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'identical_source_closure':closure,'golden_last_update':'60be419db5 (VERSION_MINOR186)','current_master_VERSION_MINOR':191,'checksum_xor_mask':hex(mask),'rows':150,'all_seed_tick_and_rng_hashes_identical':True,'all_checksums_differ_only_by_map_header_version_rotate':True,'language_inventory_loaded':False,'fixture_modified':False,'scope':'The unchanged HeadlessGlobals default does not load strings. MapHeader::checkSum includes versionMinor; its propagated 186 XOR191 value rotates right9. All150 rows confirm this exact constant, rather than a Telugu, RNG or simulation divergence.'}
(OUT/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
