from pathlib import Path
import hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
U=Path(__file__).resolve().parent;R=U.parents[2];REV='5b2421e8510f85b7538fcaed19fb58c90db71a50'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==REV
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()
B=R/'build/linux/client/release/test';assert (B/'glob2-engine-tests').is_file()
OUT=U/'compatibility/focused-native';OUT.mkdir(parents=True,exist_ok=False)
filters=['LegacyScriptCoverage/*','FontKerning/*','SystemLanguage/*','SettingsGraphics/Telugu player names*','SettingsGraphics/text size*','CustomGameSetup/Telugu*','ReplayStepCounter/*','TurnMatchRecord/*','TurnEngineHarness/the committed match record verifies*','TurnEngineHarness/Marathi registration rejects*','MatchSetup/every MatchSetup and SimVersion*','MatchSetup/the simulation data hash*']
cmd=['python3','test/run_tests.py','--build-dir',str(B.parent),'--binary','engine','-j','3','--display-jobs','1','--junit',str(OUT/'tests.xml'),'--artifacts',str(OUT/'cases'),'--write-inventory',str(OUT/'inventory.json')]
for pattern in filters:cmd+=['--filter',pattern]
env=dict(os.environ,LD_LIBRARY_PATH=str(R/'artifacts/localization-telugu/rendering/sdl-prefix/lib'),LP_NUM_THREADS='2');env.pop('DISPLAY',None);env.pop('WAYLAND_DISPLAY',None);env['SDL_VIDEO_DRIVER']='x11';start=time.monotonic()
with (OUT/'run.log').open('w') as log:result=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
size=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file());assert size<128*1024**2,'Focused evidence exceeds bounded128MiB'
report={'source_revision':REV,'command':cmd,'exit_code':result.returncode,'seconds':time.monotonic()-start,'filters':filters,'binary_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [B/'glob2-engine-tests']},'evidence_bytes':size,'scope':'Focused actual compiled native shaping/layout/locale/UTF8 settings/Te map-pane/legacy source-token-save/checksum/replay-contract checks. Golden regenerated separately; no whole engine-suite claim.'}
if (OUT/'tests.xml').exists():
 root=ET.parse(OUT/'tests.xml').getroot();report['junit']=root.attrib
(OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));raise SystemExit(result.returncode)
