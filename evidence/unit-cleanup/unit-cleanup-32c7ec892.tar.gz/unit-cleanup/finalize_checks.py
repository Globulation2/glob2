import json,pathlib,hashlib,subprocess,xml.etree.ElementTree as ET
root=pathlib.Path.cwd();out=root/'artifacts/unit-cleanup'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='32c7ec892b5a1dfb22bde2d9025de106e8eac4d3'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
names=['build-current','engine-current','unit-current','assets-current','presentation-current','cli-current','cli-reference-current','traces-current','package-optimization-current','android-release-current','play-release-current']
checks={}
for name in names:
 d=json.loads((out/f'{name}-command.json').read_text());assert d['complete'] and d['status']=='PASS' and d['commandExitCode']==0,d
 assert d['sourceBefore']['revision']==head and d['sourceAfter']['revision']==head
 checks[name]={'status':d['status'],'exitCode':d['commandExitCode'],'receipt':f'{name}-command.json','argv':d['argv']}
 xml=out/f'{name}.xml'
 if xml.exists():
  tree=ET.parse(xml).getroot();cases=list(tree.iter('testcase'))
  nums={'tests':len(cases),**{k:sum(c.find(tag) is not None for c in cases) for k,tag in [('failures','failure'),('errors','error'),('skipped','skipped')]}}
  for k in nums:
   if k in tree.attrib:assert nums[k]==int(tree.attrib[k]),(name,k)
  assert nums['tests'] and not nums['failures'] and not nums['errors'];nums['passed']=nums['tests']-nums['skipped'];checks[name]['cases']=nums
 if name in ['package-optimization-current','android-release-current','play-release-current']:
  import re
  log=(out/f'{name}.log').read_text();count=int(re.search(r'Ran (\d+) tests',log)[1]);assert log.rstrip().endswith('OK');checks[name]['cases']={'tests':count,'failures':0,'errors':0,'skipped':0,'passed':count}
for p in (out/'traces-current').rglob('build-provenance.json'):
 d=json.loads(p.read_text());assert d['revision']==head and not d['dirty'] and not d['sourceStatus'],p

comparisons=[]
for old in json.loads((out/'canonical-comparison.json').read_text())['traces']:
 new=root/old['newPath'].replace('/traces/','/traces-current/'); ref=root/old['referencePath']
 a=new.read_bytes();b=ref.read_bytes();assert a==b,old['kind']
 comparisons.append({'kind':old['kind'],'currentPath':str(new.relative_to(root)),'referencePath':old['referencePath'],'bytes':len(a),'sha256':hashlib.sha256(a).hexdigest(),'wholeBytesEqual':True})
comparison={'status':'PASS','revision':head,'referenceProducer':'9e6f406b634023702eb34125916f74fe453a5e54','normalization':'None; whole raw bytes','traces':comparisons}
(out/'canonical-current-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
summary={'status':'PASS_FINAL_CLEANUP_VALIDATION','revision':head,'master':'c6a7eae787a0f945619a622ed99ac755c2632689','previousCleanupRevision':'00f50c5ff1b1da77254b4057c3e04059917cc5a8','originalFoundationEvidenceRevision':'66379264ecd55c8058fe31d61009eafffc7db563','checks':checks,'canonicalComparison':comparison,'preservedFailedAttempts':{'build-command.json':'Old build directory rejected by updated master build configuration, before compilation.','build-fresh-command.json':'Compilation completed and binaries passed tests; original wrapper failed because shared origin/master advanced. Raw receipt remains FAIL. Corrected current wrapper pins immutable HEAD/tree and records child exit separately.','package-contracts-current-command.json':'Incorrect unittest module invocation: no tests imported. Corrected explicit discover invocations passed32 cases.'},'limits':['Linux x86_64 GCC15.2 release verification at final revision. Display checks use Xvfb/Mesa.','Earlier platform and full-state evidence retains its original source identities; it is not relabeled as final cleanup execution.','Windows/mobile hardware execution and maintainer play-through not newly verified.','No new performance campaign or performance claim. User removed performance acceptance requirements.','Hosted CI is not claimed by local checks.']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v.get('cases',v['status']) for k,v in checks.items()}))
