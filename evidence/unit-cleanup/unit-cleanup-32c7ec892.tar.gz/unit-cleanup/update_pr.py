import json,pathlib,subprocess
out=pathlib.Path('artifacts/unit-cleanup');s=json.loads((out/'summary.json').read_text());p=json.loads((out/'publication.json').read_text());assert p['status']=='PASS'
head=s['revision'];base=s['master'];url=p['readmeUrl']
original=json.loads(subprocess.check_output(['gh','pr','view','1057','--json','body,isDraft,headRefOid'],text=True));assert original['isDraft'] and original['headRefOid']==head
body=original['body'].split('Current feature revision:',1)[0]
body+=f'''Current feature revision: `{head}`, rebased onto master `{base}`. Cleanup removes one-off continuation/full-state tracing, owner-thread benchmark timing, the unit benchmark wrapper and its extra gates, related CLI metadata/docs and instrumentation-only tests. Independent reviews passed, and the rebased tree matches the clean merge exactly. Task-owned temporary captures, build trees, test profiles, dependency staging and working notes have been removed; durable tests and fixtures remain.

Final Linux release validation passed. Engine, unit, display/asset, CLI/reference and master build/release contracts are reported with exact counts and commands in the [cleanup verification evidence]({url}). Four canonical traces match the frozen pre-cleanup reference byte-for-byte without normalization. Original failed invocations are preserved beside corrected passing results.

[Previously published foundation evidence](https://github.com/Globulation2/glob2/blob/66379264ecd55c8058fe31d61009eafffc7db563/evidence/FINAL45-README.md) retains its original source identities (`9e6f406b6` simulation producer with the reviewed non-simulation bridge to `5efe8b6f0`). Final cleanup execution is Linux-only; earlier platform evidence is not relabeled as final-head execution.
'''
bodyfile=out/'pr-body.md';bodyfile.write_text(body)
subprocess.check_call(['gh','pr','edit','1057','--body-file',str(bodyfile)])
rows=[]
for name,d in s['checks'].items():
 if 'cases' in d:
  c=d['cases'];r=f"{c['passed']} passed, {c['skipped']} declared skips,0 failures/errors"
 else:r='exit0'
 rows.append(f"- `{name}`: {r}. Exact argv and raw logs in archive.")
comment=f'''Local verification after cleanup/rebase

- Tested commit SHA: `{head}`; base `{base}`. PR head is the exact clean merge of the previous cleanup head and this master. Source clean throughout validation; immutable HEAD/tree pinned.
- Environment: Linux x86_64, GCC15.2, glibc2.43. Ordinary release (`release=1 dev_fast=0 linker=default`), O3/default stripped linking; six build jobs. SDL/native dependencies and exact compiler flags retained in raw build logs/test provenance. Display tests use Xvfb/Mesa.
- Coverage rationale: remove development-only instrumentation without changing gameplay, and cover master integration in GUI finalizers/HD assets/build metadata. Durable unit composition, service, cargo, legacy save/replay and checksum tests retained. Independent cleanup and integration reviews found no blockers.

{chr(10).join(rows)}

Four canonical replay/match/resource/unit trace files equal frozen producer `9e6f406b634023702eb34125916f74fe453a5e54` as whole raw bytes, with no normalization. Hashes, both trace sets, test results, case inventory, logs, provenance and exact commands are in [accessible cleanup evidence]({url}); [structured summary]({p['summaryUrl']}). Raw failed setup/invocation attempts remain attached with explanations and corrected passing receipts.

Old and current task-owned builds, captures, private test profiles, SDL staging and working notes were removed after checking for active users. The one-off local cleanup runner/evidence directory is removed following publication. Shared caches and unrelated worktrees/profiles remain.

Omissions/limits: no new performance campaign, as requested. This final cleanup is executed on Linux only; [earlier foundation proof](https://github.com/Globulation2/glob2/blob/66379264ecd55c8058fe31d61009eafffc7db563/evidence/FINAL45-README.md) retains actual original platform/source identities. Windows/mobile hardware execution and a maintainer play-through remain unverified. Historical309 diagnostic differences remain disclosed; gameplay/orders/RNG preservation is established, raw legacy-state equality is not claimed. No hosted CI success or maintainer acceptance is claimed; PR remains draft.
'''
commentfile=out/'pr-verification.md';commentfile.write_text(comment)
subprocess.check_call(['gh','pr','comment','1057','--body-file',str(commentfile)])
verified=json.loads(subprocess.check_output(['gh','pr','view','1057','--json','body,isDraft,headRefOid,url'],text=True));assert verified['isDraft'] and verified['headRefOid']==head and url in verified['body'];print(json.dumps({'status':'PASS','isDraft':True,'url':verified['url'],'head':head,'evidence':url}))
