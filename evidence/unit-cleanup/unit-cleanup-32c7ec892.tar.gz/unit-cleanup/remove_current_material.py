import datetime,json,os,pathlib,shutil
root=pathlib.Path.cwd();out=root/'artifacts/unit-cleanup'
assert json.loads((out/'summary.json').read_text())['status']=='PASS_FINAL_CLEANUP_VALIDATION'
prefix=str(root/'artifacts/unit-foundation/native-sdl/prefix');owned=[]
for p in sorted(pathlib.Path('/tmp').glob('glob2-test-*')):
 if not p.is_dir() or p.is_symlink():continue
 try:s=(p/'output.txt').read_text(errors='replace')[:32768]
 except OSError:continue
 for line in s.splitlines():
  if 'GLOB2_TEST_PROVENANCE ' not in line:continue
  try:d=json.loads(line.split('GLOB2_TEST_PROVENANCE ',1)[1])
  except (ValueError,IndexError):continue
  flags=d.get('flags',{}).get('LINKFLAGS','')
  if prefix in str(flags):owned.append({'path':str(p),'revision':d.get('revision'),'ownership':'Exact task-exclusive compiled SDL prefix in LINKFLAGS'})
paths=[root/'build/unit-cleanup-release',root/'artifacts/unit-foundation']+[pathlib.Path(p['path']) for p in owned]+[pathlib.Path('/tmp/unit-cleanup-runtime.patch'),pathlib.Path('/tmp/unit-foundation-native17c-unit-inventory.txt')]
active=[]
for proc in pathlib.Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:cwd=(proc/'cwd').resolve(strict=True);args=(proc/'cmdline').read_bytes().decode(errors='replace')
 except OSError:continue
 try:maps=(proc/'maps').read_text(errors='replace')
 except OSError:maps=''
 if prefix in maps or any(cwd==p or p in cwd.parents or str(p) in args for p in paths):active.append({'pid':proc.name,'cwd':str(cwd)})
assert not active,active
r={'status':'RUNNING','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'paths':[str(p) for p in paths],'ownedProfiles':owned,'scope':'Closed current build/dependency and positively owned profiles only; no shared dependency/cache or foreign worktree removed'}
f=out/'final-development-material-removal.json';f.write_text(json.dumps(r,indent=2)+'\n')
for p in paths:
 if p.is_dir():shutil.rmtree(p)
 elif p.is_file() or p.is_symlink():p.unlink()
assert all(not p.exists() for p in paths)
r.update(status='PASS',closedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());f.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':'PASS','deletedProfiles':len(owned),'deletedCurrentBuildAndDependency':True}))
