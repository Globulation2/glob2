import datetime,hashlib,json,os,pathlib,platform,subprocess,sys,time
ROOT=pathlib.Path.cwd(); OUT=ROOT/'artifacts/unit-cleanup'; EXPECTED='32c7ec892'
def identity():
 revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 assert revision.startswith(EXPECTED) and not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
 return {'revision':revision,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'master':subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip()}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
name=sys.argv[1]; build='build/unit-cleanup-release'; main=f'{build}/src/glob2';base=['python3','test/run_tests.py','--build-dir',build,'--keep-profiles','-j','6','--junit',str(OUT/f'{name}.xml'),'--write-inventory',str(OUT/f'{name}-inventory.json'),'--artifacts',str(OUT/f'{name}-cases')]
commands={
'build':['python3','tools/dev_build.py','release=1','dev_fast=0','linker=default','--build='+build,main,'engine-tests','unit-tests','-j6'],
'engine':base+['--binary','engine','--no-display','--filter','UnitCatalog/*','--filter','UnitCustomization/*','--filter','TeamStatsSave/*','--filter','EngineSession/*','--filter','LegacyReplay/*','--filter','GameDiagnostics/*','--filter','CommandLine/*'],
'unit':base+['--binary','unit','--no-display'],
'cli':['python3','test/test_cli_smoke.py','--binary',main,'--artifacts',str(OUT/f'{name}-cases'),'--junit',str(OUT/f'{name}.xml')],
'cli-reference':['python3','tools/cli_reference.py','--binary',main,'--check'],
'traces':['python3','test/run-browser-determinism.py',main,str(OUT/name),'--engine-binary',f'{build}/test/glob2-engine-tests'],
'python':['python3','-m','unittest','discover','-s','test','-p','test_benchmark*.py'],
'presentation':base+['--binary','engine','--filter','EngineSession/automatic GUI sessions poll asset finalizers*','--filter','UnitCatalog/new combinations retain appearance*'],
'assets':base+['--binary','unit','--filter','AssetLoader/*','--filter','SpriteSheets/*'],
'package-contracts':['python3','-m','unittest','test.build_system.test_package_optimization','test.build_system.test_android_release','test.build_system.test_play_release'],
'package-optimization':['python3','-m','unittest','discover','-s','test/build_system','-p','test_package_optimization.py'],
'android-release':['python3','-m','unittest','discover','-s','test/build_system','-p','test_android_release.py'],
'play-release':['python3','-m','unittest','discover','-s','test/build_system','-p','test_play_release.py'],
'benchmark-help':['python3','test/benchmark_resource_refactor.py','--help'],
}
argv=commands['build'] if name in ['build-fresh','build-confirmed','build-current'] else commands[name.removesuffix('-current')];receipt=OUT/f'{name}-command.json';assert not receipt.exists()
env={**os.environ,'GLOB2_SDL3_PREFIX':str(ROOT/'artifacts/unit-foundation/native-sdl/prefix'),'DISPLAY':'','WAYLAND_DISPLAY':''}
env.pop('GLOB2_TEST_UPDATE_FIXTURES',None)
d={'status':'RUNNING','complete':False,'sourceBefore':identity(),'argv':argv,'environment':{k:env[k] for k in ['GLOB2_SDL3_PREFIX','DISPLAY','WAYLAND_DISPLAY']},'os':platform.platform(),'architecture':platform.machine(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'driverPid':os.getpid()};receipt.write_text(json.dumps(d,indent=2)+'\n');start=time.monotonic()
try:
 with (OUT/f'{name}.log').open('w') as log:
  child=subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
  d['childPid']=child.pid;receipt.write_text(json.dumps(d,indent=2)+'\n');code=child.wait()
 d.update(commandExitCode=code,exitCode=code,status='PASS' if code==0 else 'FAIL',sourceAfter=identity());assert all(d['sourceAfter'][k]==d['sourceBefore'][k] for k in ['revision','tree'])
except BaseException as e:
 d.update(status='FAIL',error=repr(e),exitCode=1)
finally:
 d.update(complete=True,closedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-start,logSha256=sha(OUT/f'{name}.log'));receipt.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'name':name,'status':d['status'],'exitCode':d['exitCode'],'source':d['sourceBefore']['revision']}),flush=True)
sys.exit(d['exitCode'])
