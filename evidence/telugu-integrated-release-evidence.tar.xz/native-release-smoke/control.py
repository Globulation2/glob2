import json,time
from pathlib import Path
import client
BASE=Path(__file__).resolve().parent

def invoke(name,args):
    status=client.call('ui_status')['structuredContent']
    if not status['controlled']:
        lease=client.call('ui_acquire_control');(BASE/'lease.json').write_text(json.dumps(lease))
    lease=json.loads((BASE/'lease.json').read_text())['structuredContent']
    args=dict(args,token=lease['token'])
    if name=='ui_click':args['viewport_id']=status['viewport_id']
    result=client.call(name,args)
    record={'time':time.time(),'name':name,'arguments':{k:v for k,v in args.items() if k!='token'},'result':result.get('structuredContent',{})}
    with (BASE/'input-trace.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
    return result
