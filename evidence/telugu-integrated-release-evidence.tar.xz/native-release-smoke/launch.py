from pathlib import Path
import json,os
BASE=Path(__file__).resolve().parent;state=json.loads((BASE/'state.json').read_text());env=dict(os.environ,**state['environment']);env.pop('WAYLAND_DISPLAY',None);env.pop('SDL_VIDEODRIVER',None)
if state.get('use_bundled_runtime'):env.pop('LD_LIBRARY_PATH',None)
staging=state['staging'];os.chdir(state['working_directory']);args=[staging['binary'],'play','--window-size','1000x800','--no-fullscreen','--mute','--data-dir',staging['runtime_assets']]
if state.get('username_override') is not None:args+=['--username',state['username_override']]
os.execve(args[0],args,env)
