"""Local, ignored verification client for the game's documented legacy MCP adapter."""
import base64,json,pathlib,time,urllib.request
BASE=pathlib.Path(__file__).resolve().parent

def rpc(method,params):
    config=json.loads((BASE/'state.json').read_text())
    body={'jsonrpc':'2.0','id':int(time.time()*1000),'method':method,'params':params}
    req=urllib.request.Request(config['endpoint'],data=json.dumps(body).encode(),headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25'})
    with urllib.request.urlopen(req,timeout=20) as response:
        result=json.load(response)
    if 'error' in result:raise RuntimeError(result['error'])
    return result['result']

def call(name,args=None):
    result=rpc('tools/call',{'name':name,'arguments':args or {}})
    if result.get('isError'):raise RuntimeError(result)
    return result

def capture(name):
    result=call('ui_screenshot')
    images=[x for x in result.get('content',[]) if x.get('type')=='image']
    assert len(images)==1
    assert images[0]['mimeType']=='image/png'
    out=BASE/(name+'.png');out.write_bytes(base64.b64decode(images[0]['data']))
    (BASE/(name+'-metadata.json')).write_text(json.dumps({k:v for k,v in result.items() if k!='content'},indent=2)+'\n')
    return str(out)
