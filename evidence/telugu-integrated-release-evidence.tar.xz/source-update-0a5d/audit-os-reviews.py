from pathlib import Path
import json,hashlib,re,xml.etree.ElementTree as ET
U=Path(__file__).resolve().parent;R=U.parents[2];load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();src=load(U/'os-source.json');target=load(U/'os-target.json');refs=[]
for role,name,identity in [('author','author-os-final.json','/root'),('semantic','semantic-os-final.json','/root/browser_research'),('editor','editor-os-final.json','/root/telugu_final_editor'),('adversarial','adversarial-os-final.json','/root/rendering_research')]:
 p=U/name;v=load(p);assert v['status']=='PASS' and v['source_sha256']==sha(U/'os-source.json') and v['target_sha256']==sha(U/'os-target.json');assert {e['key'] for e in v['entries']}==set(src)
 for e in v['entries']:assert e['source']==src[e['key']] and e['target']==target[e['key']]
 assert not v.get('unresolved_findings',[]);refs.append({'role':role,'actual_agent':identity,'path':name,'sha256':sha(p)})
paths={'android:preparing_game':'mobile/android/app/src/main/res/values-te/strings.xml','ios:NSLocalNetworkUsageDescription':'mobile/ios/te.lproj/InfoPlist.strings','macos:NSLocalNetworkUsageDescription':'darwin/te.lproj/InfoPlist.strings'};resource=[]
for k,n in paths.items():
 p=R/n
 if k.startswith('android:'):value=ET.parse(p).getroot().find("string[@name='preparing_game']").text
 else:value=json.loads(re.search(r'=\s*(".*")\s*;',p.read_text()).group(1))
 assert value==target[k] and value.count('Globulation 2')==src[k].count('Globulation 2');resource.append({'key':k,'path':n,'sha256':sha(p)})
(U/'os-review-audit.json').write_text(json.dumps({'status':'PASS linguistic and source-resource audit only','supplemental_unique_keys':3,'source_sha256':sha(U/'os-source.json'),'target_sha256':sha(U/'os-target.json'),'four_distinct_actual_agents':refs,'resources':resource,'scope':'Android preparation and Apple localnetwork purpose strings supplement6390catalogkeys; not hidden online keys. Agentreviewed, not nativehuman certified. PhysicalAndroid/AppleOS dialog rendering not tested; gamefont matrix and package/source-copy checks are separately evidenced.'},indent=2)+'\n');print('PASS threeOSpairs/fourroles/resourcebytes')
