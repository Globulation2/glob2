from pathlib import Path
import subprocess,gzip,time,json,signal,collections,sys
r=Path(__file__).resolve().parent;ctx=Path('artifacts/thai-localization/dev-tools/platform-source-3d59').resolve();assert json.loads((r/'context-provenance.json').read_text())['revision']=='3d59ccf4ca38f09eed70bffbfb29acc3d4c3e5b4'
for target in ['platform','caddy']:
 tag=f'glob2-thai-{target}-qa:3d59';cmd=['docker','build','--progress=plain','--target',target,'--build-arg','JOBS=4','--build-arg','GLOB2_DESIGN_SYSTEM_SHA=220b965b061e402df7531fa0f9ad5104bf29a638','-f',str(ctx/'deploy/Dockerfile'),'-t',tag,str(ctx)];start=time.time();(r/(target+'-build-start.json')).write_text(json.dumps({'command':cmd,'started_epoch':start},indent=2)+'\n');p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);tail=collections.deque(maxlen=8);total=0;aborted=False
 with gzip.open(r/(target+'-build.log.gz'),'wb') as log:
  for data in p.stdout:
   total+=len(data)
   if total>128*1024*1024 and not aborted:p.send_signal(signal.SIGINT);aborted=True
   if not aborted:log.write(data);log.flush()
   tail.append(data.decode(errors='replace').strip())
 code=p.wait();result={'command':cmd,'exit_code':code,'seconds':time.time()-start,'uncompressed_log_bytes':total,'allowance_bytes':128*1024*1024,'aborted_diagnostic_limit':aborted};(r/(target+'-build.json')).write_text(json.dumps(result,indent=2)+'\n');print(target,json.dumps(result),flush=True);print('\n'.join(tail),flush=True)
 if code or aborted:raise SystemExit(code or 1)
 image=json.loads(subprocess.check_output(['docker','image','inspect',tag]))[0];(r/(target+'-image-inspect.json')).write_text(json.dumps(image,indent=2)+'\n')
