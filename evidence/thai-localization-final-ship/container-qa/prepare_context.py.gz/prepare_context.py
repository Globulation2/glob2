from pathlib import Path
import subprocess,os,shutil,json,hashlib,time,tarfile
r=Path(__file__).resolve().parent;src=Path('artifacts/thai-localization/dev-tools/engine-source-83e').resolve();dst=Path('artifacts/thai-localization/dev-tools/platform-source-3d59').resolve();rev='3d59ccf4ca38f09eed70bffbfb29acc3d4c3e5b4';previous='83ed1774965a16a929202b8cf203bcccc500d548';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==rev;assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip();start=time.time();already_cloned=dst.exists()
if not already_cloned:shutil.copytree(src,dst,copy_function=os.link,symlinks=True)
changed=[]
for line in subprocess.check_output(['git','diff','--name-status',previous,rev],text=True).splitlines():
 status,p=line.split('\t');assert status=='M';parent_hash=hashlib.sha256((src/p).read_bytes()).hexdigest();tmp=dst/p;temp=tmp.with_name(tmp.name+'.new-context');temp.write_bytes(subprocess.check_output(['git','show',rev+':'+p]));os.chmod(temp,tmp.stat().st_mode);os.replace(temp,tmp);assert hashlib.sha256((src/p).read_bytes()).hexdigest()==parent_hash;assert os.stat(src/p).st_ino!=os.stat(dst/p).st_ino;changed.append({'path':p,'previous_sha256':parent_hash,'new_sha256':hashlib.sha256(tmp.read_bytes()).hexdigest()})
rows=[];expected_paths=set()
archive=subprocess.Popen(['git','archive',rev],stdout=subprocess.PIPE)
with tarfile.open(fileobj=archive.stdout,mode='r|') as tar:
 for member in tar:
  if member.isdir():continue
  p=member.name;file=dst/p;expected_paths.add(p)
  if member.issym():
   assert file.is_symlink() and os.readlink(file)==member.linkname,p;raw=member.linkname.encode();digest=hashlib.sha256(raw).hexdigest()
  else:
   assert member.isfile() and file.is_file(),p;h=hashlib.sha256()
   with tar.extractfile(member) as f:
    for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
   digest=h.hexdigest();assert hashlib.sha256(file.read_bytes()).hexdigest()==digest,p
  rows.append([p,oct(member.mode),digest])
assert archive.wait()==0
actual_paths={str(p.relative_to(dst)) for p in dst.rglob('*') if p.is_file() or p.is_symlink()};assert actual_paths==expected_paths,(actual_paths-expected_paths,expected_paths-actual_paths)
assert len(changed)==3
proof={'revision':rev,'predecessor_context_revision':previous,'context':str(dst),'construction':'Hardlinkcloneimmutable83context; allchangedGitblobs replacedbynewinodes; ancestorbytesverifiedunchanged. No trackedworkspacewrite.','changed_files':changed,'verified_exact_git_archive_file_entries':len(rows),'archive_semantics':'Exactgitarchiveincludesexport-ignore/export-subst; barels-treecontainsadditionalexportignoredDebianfilesnotinproductioncontext.','git_blob_inventory_sha256':hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest(),'seconds':time.time()-start,'dockerfile_sha256':hashlib.sha256((dst/'deploy/Dockerfile').read_bytes()).hexdigest(),'native_catalog_sha256':hashlib.sha256((dst/'data/texts.th.txt').read_bytes()).hexdigest(),'online_catalog_sha256':hashlib.sha256((dst/'platform/packages/i18n/locales/th.json').read_bytes()).hexdigest(),'design_system_revision':'220b965b061e402df7531fa0f9ad5104bf29a638','private_profiles_in_context':False,'native83_equivalence':'Only3webCSS/naminghelper/test files differ; ALLotherGitblobs identical. Engine83proofremainsnative-scoped; online/Caddyrequirefresh3d59build.'};(r/'context-provenance.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
