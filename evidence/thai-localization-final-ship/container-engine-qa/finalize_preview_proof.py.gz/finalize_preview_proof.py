from pathlib import Path
import json,hashlib,subprocess,gzip,shutil,collections
from PIL import Image
r=Path(__file__).resolve().parent;b=r/'release-preview/capture';ctx=Path('artifacts/thai-localization/dev-tools/engine-source-83e');m=json.loads((b/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rev='83ed1774965a16a929202b8cf203bcccc500d548'
assert m['passed'] and len(m['commands'])==21 and len(m['screenshots'])==74
for p,h in m['screenshots'].items():assert sha(b/p)==h
for p,h in m['committed_source_file_sha256'].items():assert h==m['checkout_source_file_sha256'][p]==sha(ctx/p)==hashlib.sha256(subprocess.check_output(['git','show',rev+':'+p])).hexdigest(),p
matrix=json.loads((b/'1280x900-matrix/font-matrix.json').read_text());assert matrix['harfbuzz']==[10,1,0] and len(matrix['samples'])==504
counts=collections.Counter((x['size'],x['scale']) for x in matrix['samples']);assert set(counts.values())=={84}
assert all(x['has_glyphs'] for x in matrix['samples']);assert all(y['drawn_fits_width'] and y['drawn_fits_height'] for x in matrix['samples'] for y in x['lines'])
dep=json.loads((r/'preview-dependencies/qa-preview-dependencies.json').read_text());ins=json.loads((r/'inspect.stdout').read_text());actual={Path(x['path']).name:x['sha256'] for x in ins['libraries']}
for n,h in dep.items():
 if n!='TranslationPreviewHarness':assert actual[n]==h
ident=matrix['evidence_identity'];assert dep['TranslationPreviewHarness']==ident['executable_sha256']==m['executable_sha256'];assert ident['producer']['dirty']==False and '-O3' in ident['producer']['flags']['CXXFLAGS']
checks=[]
for p in b.rglob('*.json'):
 if 'profiles' in p.parts:continue
 d=json.loads(p.read_text())
 if isinstance(d,dict):
  for c in d.get('captures',[]):
   if 'checksum_before_draw' in c:assert c['checksum_before_draw']==c['checksum_after_draw'];checks.append({'json':str(p.relative_to(b)),'capture':c['name'],'checksum':c['checksum_before_draw']})
# Preserve only one lossless raster per screenshot in public proof; original
# profiles retain alloriginalbytes under the explicitly private ignoreddevtools area.
profiles=b/'profiles';bmp=[]
for p in profiles.rglob('*.bmp'):
 index=int(p.relative_to(profiles).parts[0]);folder=Path(m['commands'][index][4]).name;name=p.stem.removeprefix('translation-preview-');png=b/folder/(name+'.png');assert png.exists(),png
 assert Image.open(p).convert('RGB').tobytes()==Image.open(png).convert('RGB').tobytes(),p
 bmp.append({'profile_bitmap':str(p.relative_to(profiles)),'bytes':p.stat().st_size,'sha256':sha(p),'canonical_png':str(png.relative_to(b)),'canonical_png_sha256':sha(png),'rgb_equal':True})
private=Path('artifacts/thai-localization/dev-tools/engine-preview-private-83e').resolve();private.mkdir(exist_ok=True);private.chmod(0o700);assert not (private/'profiles').exists()
profile_files=[{'path':str(p.relative_to(profiles)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in profiles.rglob('*') if p.is_file()];shutil.move(str(profiles),str(private/'profiles'))
# Logs were compressed whilecapturing; validate CRC and totalretained diagnostic bound.
logs=[]
for p in r.rglob('*'):
 if p.is_file() and (p.name.endswith('.log.gz') or p.name.endswith('.log')):
  data=gzip.decompress(p.read_bytes()) if p.name.endswith('.gz') else p.read_bytes();logs.append({'path':str(p.relative_to(r)),'uncompressed_bytes':len(data),'stored_bytes':p.stat().st_size,'sha256':sha(p)})
assert sum(x['uncompressed_bytes'] for x in logs)<128*1024*1024
proof={'status':'passed','upstream_context_revision':rev,'actual_synthetic_revision':m['revision'],'harness_sha256':dep['TranslationPreviewHarness'],'native_catalog_sha256':m['catalogs']['native_catalog_sha256'],'online_catalog_sha256':m['catalogs']['online_catalog_sha256'],'manifest_sha256':sha(b/'manifest.json'),'commands':21,'font_cases':504,'each_size_density_cases':[{ 'size':k[0],'scale':k[1],'cases':v} for k,v in counts.items()],'glyph_and_drawn_bounds_all_pass':True,'production_dependency_artifacts_exact_image_matches':{k:v for k,v in dep.items() if k!='TranslationPreviewHarness'},'source_hashes_exact_upstream_and_context':len(m['committed_source_file_sha256']),'draw_checksums_unchanged':checks,'profile_storage':{'private_path':str(private/'profiles'),'files':len(profile_files),'bytes':sum(x['bytes'] for x in profile_files),'metadata_sha256':hashlib.sha256(json.dumps(profile_files,sort_keys=True).encode()).hexdigest(),'note':'Profiles/saves/replays keptprivate,outsideevidenceproofroot; actualoriginals preserved. RGBidenticalBMPs remainonlyinprivateprofiles, canonicalPNGsretainedinproof.'},'equivalent_private_profile_bitmaps':bmp,'logs':logs,'total_uncompressed_diagnostic_bytes':sum(x['uncompressed_bytes'] for x in logs),'diagnostic_allowance_bytes':128*1024*1024,'raw_metadata_note':'Legacyharnesssource_revision_origin wording mentionsdirtybuildgenerically; actualproducer.dirty=false andsourceStatus=[] authoritative. SyntheticGit mappingexplicit, notupstreamSHA.','qualification_gates_changed':False}
(r/'release-preview/verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');(private/'profile-file-hashes.json').write_text(json.dumps(profile_files,indent=2)+'\n');print(json.dumps({'verifiedPNGs':74,'cases':504,'privateProfiles':len(profile_files),'privateBytes':sum(x['bytes'] for x in profile_files),'BMPs_exactPNG':len(bmp),'draw_checksum_records':len(checks),'logbytes':sum(x['uncompressed_bytes'] for x in logs)},indent=2))
