from pathlib import Path
import json,hashlib,datetime
P=Path('artifacts/localization-telugu/source-update-ffabe');catalog=P/'drafts/te/te.json';r=json.loads(catalog.read_text());raw=json.loads((P/'google-draft-untouched-te.json').read_text());m=json.loads((P/'manifest.json').read_text());adds=json.loads((P/'online-english-delta.json').read_text())['adds'];keys=[*adds,'Apply to {slot0}'];assert len(keys)==112
proposals={
'Oozy goo':('minor','జారే primarily means sliding/slippery; oozy describes oozing/flowing goo.','కారే జిగురు'),
'Listen for hiss or scratchiness in quiet passages.':('minor','నెమ్మదిగా can mean slowly as well as softly. Explicit low-volume wording avoids tempo ambiguity in the noise-quality test.','తక్కువ శబ్దంతో వినిపించే భాగాల్లో బుసబుస లేదా గరగర శబ్దం ఉందేమో వినండి.'),
'{value0} publications':('minor','value0 is translated library category name, e.g.మ్యాప్‌లు. Direct concatenation yields awkward మ్యాప్‌లు ప్రచురణలు; neutral colon avoids guessing its inflection.','{value0}: ప్రచురణలు'),
'{value0} recorded downloads':('minor','value0 is category name, not count. Neutral colon clearly separates category from metric without inflecting runtime name.','{value0}: నమోదైన డౌన్‌లోడ్‌లు'),
'{value0} completion time (seconds)':('minor','value0 is product name such as AI Studio/Engine jobs, not numeric duration. Neutral colon makes metric attachment clear for every label.','{value0}: పూర్తి చేయడానికి పట్టిన సమయం (సెకన్లు)'),
'{value0} completion samples':('minor','value0 is product name; metric measures duration samples, not example templates. Current meaning is correct; neutral colon improves dynamic-name assembly.','{value0}: పూర్తయిన పనుల సమయ కొలతలు'),
}
contexts={}
for i,k in enumerate(keys):
 if i<13:context='AI_TAGS / AI_CHECK_LABELS; AI strategy tags and deterministic sandbox validation stages, not personal profiles or farming seeds.'
 elif i<20:context='CONNECTION_RATING_LABELS / CONNECTION_METRICS; quality ratings and milliseconds/clock lag, relay flags slow at >=2 seconds.'
 elif i<48:context='COLONY_SKIN_MATERIALS: visual material/group names; scales are skin plates, cloud is cloud appearance; no gameplay-property claim.'
 elif i<57:context='AI model label/admin tabs, mute/report periods and map sort names.'
 elif i<68:context='MusicValidation CATEGORIES listening guidance; three soundtrack moods Calm/Building/Combat retain existing Telugu labels, not human emotions.'
 elif i<81:context='atlas MODELS and SWARM_SHAPES visual model names/descriptions; native swarm building is గూడు, clutch is eggs, skep is a hive.'
 elif i<84:context='Maps VISIBILITY_TEXT upload+owner selects; public/unlisted/private visibility policy, not groups of people.'
 elif i<90:context='Match VERDICT_TEXT; authoritative server simulation/replay verification and rating changes, not merely playing a video.'
 elif i<95:context='skins ACTION_LABELS for unit animation/action selection; Fly is flight, not insect; Harvest is resource collection.'
 elif i<107:context='Admin finance/reporting/count metrics; Live means real payments, period is report interval, credits virtual service balance.'
 elif i<111:context='admin/presentation.measureName: value0 substituted libraryName/productName display string, not metric number.'
 else:context='StudioControls/CopyPaintDialog dynamic model application; neutral colon avoids suffixing fixed Telugu dative onto translated Worker.'
 contexts[k]=context
entries=[]
for k in keys:
 f=[]
 if k in proposals:
  sev,reason,target=proposals[k];f=[{'severity':sev,'reason':reason,'proposed_target':target}]
 entries.append({'key':k,'source':adds.get(k,k),'target':r[k],'raw_google_target':raw[k],'context':contexts[k],'findings':f,'decision':'improvement proposed' if f else 'meaning/context retained'})
report={'reviewer':'/root/browser_research','status':'INITIAL REVIEW; final recheck pending author/editor/adversarial reconciliation','source_sha256':m['source_sha256'],'catalog_sha256':{'native':hashlib.sha256((P/'drafts/te/texts.te.txt').read_bytes()).hexdigest(),'online':hashlib.sha256(catalog.read_bytes()).hexdigest()},'actual_coverage':{'fresh_source_target_entries_read':112,'new_keys':111,'changed_existing_target':'Apply to {slot0}','method':'Manually read all112 actual current root-authored source/target pairs; compared rawGoogle and actual immutableffabe callers/registries, native glossary and relevant references. No automatic scan represented as semantic reading.'},'entries':entries,'blockers':[],'minor_proposals':len(proposals),'raw_findings_preserved':['Fair rawన్యాయమైన was fairness, Poorపేద a poor person, Flyఈగ an insect; current author corrected quality/flight meanings.','Round-trip rawHinHin corruption removed; current source threshold andeveryoneinputdelay preserved.','Rawmood psychology/literalmusicalphrases fixed to soundtrack listening context.','RawSwarm transliteration corrected to existingnativeగూడు; Clutch eggs notmechanicalclutch; Scalesపొలుసులు.','Unlisted rawpeople reading andyoungcaps light-color reading corrected to visibility andsmallmushroom context.'],'specific_retained_decisions':['Organic జీవరూపాలు is contextual visual-group label, not certified organic/farming; sourcegroup itself includescloud andvelvet. No inventedgameplay/materialproperty claim.','Persistentstate నిల్వ ఉండే స్థితి andRepeatable simulation పునరుత్పత్తి చేయగల అనుకరణ correctly mean durable state/reproducibility.','Creditgrant క్రెడిట్‌ల కేటాయింపు andreturnedcredits వాపసు చేసిన క్రెడిట్‌లు correctly describe service-credit journal, not financial loans.','Currentpublication/completion placeholders remain name slots; proposedcolon is grammar clarity, no numericplaceholder rewrite.','Neutral Apply target successfully assembles వర్తింపజేయండి: కార్మికుడు/యోధుడు/అన్వేషకుడు/గూడు withoutwrongdative ending.'],'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(P/'semantic-initial-112.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(P/'semantic-reviewed-initial-online.json').write_bytes(catalog.read_bytes())
print('initial_sha256',hashlib.sha256((P/'semantic-initial-112.json').read_bytes()).hexdigest(),'online_sha256',report['catalog_sha256']['online'])
