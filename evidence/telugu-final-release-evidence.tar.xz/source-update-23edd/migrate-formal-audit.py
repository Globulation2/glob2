"""Carry exact reviewed pairs into the new kit; never claim new full-catalog reads."""
import copy,datetime,hashlib,importlib.util,json,os
from pathlib import Path

old=Path('artifacts/localization-telugu').resolve();new=old/'source-update-23edd'
spec=importlib.util.spec_from_file_location('translation_program',Path('tools/localization/translation_program.py'))
tp=importlib.util.module_from_spec(spec);spec.loader.exec_module(tp)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def write(name,value):tp.write_json(new/name,value)
def ref(path):
 path=Path(path).resolve();return {'path':os.path.relpath(path,new),'sha256':sha(path)}
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def pair_sha(source,target):return hashlib.sha256(canonical({'source':source,'target':target})).hexdigest()
history_files=[old/'manifest.json',old/'reviews/te.json',old/'source/native.json',old/'source/online.json',old/'drafts/te/texts.te.txt',old/'drafts/te/te.json']
history={str(p):sha(p) for p in history_files}
om=load(old/'manifest.json');nm=load(new/'manifest.json');orecord=load(old/'reviews/te.json')
oldpaths=tp.catalog_paths(old,'te');newpaths=tp.catalog_paths(new,'te')
def targets(paths):
 native,errors=tp.CHECKER.read_table(paths['native']);assert not errors
 return {'native':native,'online':load(paths['online'])}
ot=targets(oldpaths);nt=targets(newpaths)
osrc={s:load(old/'source'/f'{s}.json') for s in ('native','online')}
nsrc={s:load(new/'source'/f'{s}.json') for s in ('native','online')}
hashes={s:sha(p) for s,p in newpaths.items()}
assert orecord['source_sha256']==om['source_sha256']
assert orecord['catalog_sha256']=={s:sha(p) for s,p in oldpaths.items()}
assert tp.sources()[-1]==nm['source_sha256']
assert hashes['native']=='083f5de5a369685e5a128361ca66d9ce339327c2f68d3f4bce13aaa99f93725c'
assert hashes['online']=='40b14cffd14c76cd5d4bb76c9b50b38c4fe548e7322bb1806a64d7d0318dca42'
assert len(nm['batches'])==43
old_batch={key:b['id'] for b in om['batches'] for key in b['keys']}
old_records={b['id']:b for b in orecord['batches']}
old_target_hashes=tp.batch_target_hashes(om,oldpaths)
checked_refs={}
def historical_ref(item):
 p=(old/item['path']).resolve()
 if p not in checked_refs:
  assert sha(p)==item['sha256'],f'Historical evidence changed: {p}'
  checked_refs[p]=ref(p)
 return checked_refs[p]
for b in om['batches']:
 record=old_records[b['id']];keys=set(b['keys'])
 assert record['source_sha256']==om['source_sha256'] and record['target_sha256']==old_target_hashes[b['id']]
 assert len({record[r] for r in ['author','reviewer','editor','adversarial_reviewer']})==4
 for field in ['reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys']:
  assert set(record[field])==keys and len(record[field])==len(keys)
 assert record['rechecked_by']==record['reviewer']
 for item in record['evidence']:historical_ref(item)
for item in orecord['evidence']:historical_ref(item)
carry={};added=[]
for surface in ('native','online'):
 assert set(osrc[surface])==set(ot[surface])
 assert set(nsrc[surface])==set(nt[surface])
 assert not(set(osrc[surface])-set(nsrc[surface]))
 for key,source in nsrc[surface].items():
  identity=surface+':'+key
  if key not in osrc[surface]:added.append(identity);continue
  assert source==osrc[surface][key] and nt[surface][key]==ot[surface][key],identity
  carry[identity]={'surface':surface,'key':key,'old_batch':old_batch[identity],
   'source_value_sha256':hashlib.sha256(canonical(source)).hexdigest(),
   'target_value_sha256':hashlib.sha256(canonical(nt[surface][key])).hexdigest(),
   'pair_sha256':pair_sha(source,nt[surface][key])}
assert len(carry)==6229 and set(added)=={'native:[stat win probability]','native:[stat win probability about]'}
author=load(new/'author-new-statistics.json');semantic=load(new/'semantic-new-statistics.json')
editor=load(new/'editor-new-statistics.json');adversary=load(new/'adversarial-new-statistics.json')
roles={'author':author['author'],'reviewer':semantic['reviewer'],'editor':editor['editor'],'adversarial_reviewer':adversary['reviewer']}
assert len(set(roles.values()))==4
for identity in added:
 key=identity.removeprefix('native:');target=nt['native'][key];source=nsrc['native'][key]
 assert author['final'][key]==target and author['english'][key]==source
 for report,field in [(semantic,'entries'),(editor,'entries'),(adversary,'entries_read')]:
  entry=next(e for e in report[field] if e['key']==key)
  assert entry['source']==source and entry['target']==target
assert semantic['status']=='PASS' and not semantic['requires_correction']
assert adversary['status'].startswith('PASS') and not adversary['findings']
fresh_refs=[ref(new/name) for name in ['author-new-statistics.json','semantic-new-statistics.json','editor-new-statistics.json','adversarial-new-statistics.json']]
proof={'source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'historical_source_sha256':om['source_sha256'],
 'historical_catalog_sha256':orecord['catalog_sha256'],'immutable_history_sha256':history,
 'unchanged_pairs':len(carry),'native_unchanged_pairs':3393,'online_unchanged_pairs':2836,
 'freshly_read_new_keys':added,'four_role_new_key_evidence':fresh_refs,
 'method':'Compare exact decoded source AND target values per key; transfer existing explicit four-role coverage only after validating historical batch hashes, key coverage, identities and evidence-file hashes. No new full-catalog read is claimed.',
 'pairs':carry,'historical_evidence_files_verified':[v for v in checked_refs.values()]}
write('audit-exact-pair-carry.json',proof)
new_target_hashes=tp.batch_target_hashes(nm,newpaths)
records=[]
for batch in nm['batches']:
 carried=[key for key in batch['keys'] if key in carry];fresh=[key for key in batch['keys'] if key in added]
 refs=[ref(new/'audit-exact-pair-carry.json')]
 if fresh:refs+=fresh_refs
 oldids=sorted({carry[key]['old_batch'] for key in carried})
 batchproof={'id':batch['id'],'source_sha256':nm['source_sha256'],'target_sha256':new_target_hashes[batch['id']],
  'carried_keys':carried,'actually_fresh_new_keys':fresh,'historical_batches':oldids,
  'historical_roles':{bid:{r:old_records[bid][r] for r in roles} for bid in oldids},
  'new_key_roles':roles if fresh else {},'evidence':refs,
  'method':'Exact source+target pair carry; current fresh role approvals apply only to the two added statistics keys.'}
 write('audit-batches/'+batch['id']+'.json',batchproof)
 record={'id':batch['id'],**roles,'source_sha256':nm['source_sha256'],'target_sha256':new_target_hashes[batch['id']],
  'reviewed_keys':batch['keys'],'edited_keys':batch['keys'],'rechecked_keys':batch['keys'],'rechecked_by':roles['reviewer'],
  'adversarial_reviewed_keys':batch['keys'],'review_method':batchproof['method'],
  'semantic_final_fresh_keys':fresh,'semantic_final_exact_carry_keys':carried,
  'evidence':[ref(new/('audit-batches/'+batch['id']+'.json'))]}
 records.append(record)
structural=tp.check_draft(new,'te');assert not structural['errors'] and not structural['untranslated']
accepted=copy.deepcopy(orecord['accepted_english']);assert {e['key'] for e in accepted}==set(structural['same_as_english_review_queue'])
assert len(accepted)==132 and all(e['key'] in carry and e['reason'].strip() for e in accepted)
write('audit-migration-structural.json',{'source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'result':structural,'accepted_english_count':132})
write('accepted-english-carry.json',{'source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'method':'All132 source-equal values and individual rationales carry via exact source+target pairs; no new source-equal entry.','historical_record':ref(old/'reviews/te.json'),'entries':accepted})
record={'locale':'te','source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'batches':records,
 'findings':copy.deepcopy(orecord['findings']),'language_brief':copy.deepcopy(orecord['language_brief']),
 'accepted_english':accepted,'gates':{},'evidence':[ref(old/'reviews/te.json'),ref(new/'audit-exact-pair-carry.json'),*fresh_refs],
 'review_coverage':{'source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'native_keys':3395,'online_keys':2836,
  'total_keys':6231,'source_batch_count':43,'exact_pair_carries':6229,'actually_fresh_new_key_reads':2,
  'new_keys':added,'four_distinct_roles':roles,'historical_coverage':orecord['review_coverage'],
  'method':'Historical6229-key reviews are preserved with exact pair equality; all4 roles actually reread/approve only the new2.'},
 'correction_evidence':{'historical_record':ref(old/'reviews/te.json'),'new_editor_correction':ref(new/'editor-new-statistics.json')},
 'certification':'Agent-reviewed; not native-human-certified',
 'release_readiness':'Linguistic coverage6231keys is complete through6229 explicit carries plus2 actual four-role reviews. First3gates carry/refresh with evidence. Rendering and platform gates remain pending final-source delta/runtime/package evidence.',
 'source_snapshot_note':{'manifest_preparation_revision':nm.get('revision'),'integrated_head':'467011984c7b0dd39a2b139fa49090f70418edd4','authority':'Exact manifest source_files and combined source hash; preparation revision is not relabeled as a fresh read.'}}
for name in tp.GATES:
 gate={'passed':False,'source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'evidence':[],
       'scope':'Pending final467/sourcebc991/catalog083f rendering or platform delta evidence; historical gate is not promoted.'}
 if name in ['language_brief','source_based_pilot']:
  oldgate=orecord['gates'][name];assert oldgate['passed'] is True
  refs=[historical_ref(item) for item in oldgate['evidence']]
  wrapper={'gate':name,'source_sha256':nm['source_sha256'],'catalog_sha256':hashes,'historical_gate':oldgate,
   'historical_evidence':refs,'exact_pair_proof':ref(new/'audit-exact-pair-carry.json'),'incremental_four_role_evidence':fresh_refs,
   'reason':'Same language variety/script/region and unchanged old pilot/source-target values. New statistics terms use existing Win chance/Alliance glossary and have actual four-role context review. No fresh fullpilot read is claimed.'}
  write('audit-'+name+'-carry.json',wrapper)
  gate.update(passed=True,evidence=[ref(new/('audit-'+name+'-carry.json')),ref(new/'audit-exact-pair-carry.json'),*fresh_refs],scope=wrapper['reason'])
 elif name=='structural':
  gate.update(passed=True,evidence=[ref(new/'audit-migration-structural.json'),ref(new/'accepted-english-carry.json'),ref(new/'audit-exact-pair-carry.json')],scope='Fresh new-kit structural check plus exact132 reviewed source-equal exceptions; no rendering inference.')
 record['gates'][name]=gate
write('reviews/te.json',record)
assert history=={str(p):sha(p) for p in history_files},'Oldkit mutated duringmigration'
issues=tp.audit_locale(new,nm,record,'te')
expected={name+' is pending or lacks evidence' for name in tp.GATES[3:]}
assert set(issues)==expected,issues
write('audit-migration-validation.json',{'source_sha256':nm['source_sha256'],'catalog_sha256':hashes,
 'historical_files_unchanged':True,'historical_file_sha256':history,'new_review_sha256':sha(new/'reviews/te.json'),
 'keys':6231,'carried':6229,'fresh_new':2,'batches':43,'accepted_english':132,
 'non_gate_issues':[],'expected_pending_gate_issues':issues,'validated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(json.dumps({'keys':6231,'carried':6229,'fresh':2,'batches':43,'pending':issues}))
