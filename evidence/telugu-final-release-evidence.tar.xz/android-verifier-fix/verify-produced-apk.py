#!/usr/bin/env python3
"""Strictly verify actual produced APK; retain candidate/final provenance separately."""
import argparse,hashlib,importlib.util,json,pathlib,subprocess,sys,time,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[3];p=argparse.ArgumentParser();p.add_argument('--verifier',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--phase',required=True);a=p.parse_args();sys.path.insert(0,str(ROOT/'scons'));sys.path.insert(0,str(ROOT/'mobile'))
from build_layout import build_identity
from dev_build import dependency_identity
from dev_paths import dependency_prefix
from mobile_toolchain import discover
from mobile_artifacts import verify_android_symbols
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
arch='arm64-v8a';base=ROOT/'build/android/device/arm64-v8a/24/client/release';apk=base/'android-project/app/build/outputs/apk/release/app-release-unsigned.apk';before=sha(apk)
sdk=pathlib.Path('/home/bradley/.local/share/glob2/development/toolchains/mobile/Linux-x86_64-8dbf18a4a97410f6b6a92b4a/android-sdk');spec=importlib.util.spec_from_file_location('reviewed_android_release_verifier',a.verifier.resolve());module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
digest=module.verify_apk(apk,arch,sdk,root=ROOT,require_dependency_manifest=True);assert digest==before
readelf=sdk/'ndk/28.2.13676358/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-readelf';build_id=verify_android_symbols(apk,base/'lib/libmain.so',arch,readelf)
identity=dependency_identity(build_identity({'target':'android','arch':arch,'release':1}));toolchain=discover(identity,{'android_sdk':str(sdk)});prefix=dependency_prefix(ROOT,identity,toolchain['fingerprint']);manifest=prefix/'manifest.json'
recording=pathlib.Path('/home/bradley/.local/share/glob2/development/dependencies/build-ae02ab1472affdf92efc49bd/prefix');notices=[]
with zipfile.ZipFile(apk) as z:
 index=z.read('assets/glob2-bundle/index.list').decode().splitlines();libraries=[n for n in z.namelist() if n.startswith('lib/') and n.endswith('.so')]
 for source in sorted((recording/'share/licenses/recording').iterdir()):
  assert source.is_file();member='assets/glob2-bundle/licenses/recording/'+source.name;data=z.read(member);assert data==source.read_bytes();notices.append({'member':member,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
assert sha(apk)==before;assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==revision;assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
r={'result':'Actual APK passes strict corrected verifier plus native symbol identity and resolved notices checks','phase':a.phase,'checked_checkout_revision':revision,'apk':str(apk),'apk_sha256':before,'apk_bytes':apk.stat().st_size,'verifier_source':str(a.verifier.resolve()),'verifier_source_sha256':sha(a.verifier.resolve()),'requires_dependency_manifest':True,'resolved_dependency_identity':identity,'resolved_dependency_prefix':str(prefix),'dependency_manifest_sha256':sha(manifest),'toolchain_fingerprint':toolchain['fingerprint'],'architecture':arch,'native_build_id':build_id,'packaged_native_libraries':libraries,'asset_index_entries':len(index)-1,'asset_index_digest':index[0],'resolved_recording_notices':notices,'recording_manifest_sha256':sha(recording/'recording-manifest.json'),'readelf':str(readelf),'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'producer_scope':'Actual E3 ordinary ARM64 --release --fdroid build: Gradle47tasks BUILD SUCCESSFUL; original whole wrapper returned1 onlyatwrong dependency-manifest lookup. Corrected strict verifier checks the unchanged produced APK here.','limits':['Candidate verification is not relabeled as a successful original wrapper run.','No physical Android-device or emulator startup/rendering pass.','No signing, upload or publication; strict F-Droid verifier requires unsigned APK.']};a.output.write_text(json.dumps(r,indent=2)+'\n');print('STRICT APK PASS',before,'bytes',r['apk_bytes'],'buildID',build_id,flush=True)
