"""Collect curated audit/runtime evidence after all final reports exist."""
from pathlib import Path
import json
P=Path(__file__).resolve().parent;U=P/'source-update-bc8';files=set()
def add(f):
 if f.is_file() and f.suffix in ('.json','.log','.txt','.xml','.png','.gz','.py','.cjs','.diff','.patch'):
  assert f.name not in ('state.json','lease.json','ledger.json')
  assert not any(x in f.parts for x in ('google','node_modules','sdl-prefix'))
  files.add(str(f.relative_to(P)))
for name in ['source-update-23edd','source-update-e9275']:
 kit=P/name
 for d in ['source','batches','drafts','reviews','audit-batches']:
  for f in (kit/d).rglob('*'):add(f)
 for f in kit.iterdir():add(f)
# The previous final inventory includes U1 visual evidence and source overlays.
for name in json.loads((P/'source-update-23edd/final-public-evidence-files.json').read_text()):add(P/name)
# Final current matrix/UI capture reports and fresh online evidence, excluding profiles/replays/BMPs.
for directory in [P/'source-update-e9275/rendering',P/'source-update-bc8/rendering',P/'online-integration-d48']:
 for f in directory.rglob('*'):
  if any(x in f.relative_to(directory).parts for x in ('profiles','frozen-inputs','early-d48ceb59','tutorials-9fb13466','tutorials-a43402ce','editor-contact','editor-crops')):continue
  add(f)
for prefix in ['u4-release-']:
 for f in (P/'native-release-smoke').glob(prefix+'*'):add(f)
for f in (P/'browser-runtime').rglob('*'):
 if not any(x in f.relative_to(P/'browser-runtime').parts for x in ('profiles','playwright-profile','node_modules','caddy-state')):add(f)
# Narrow explicit package reports (never SDKs, APKs, WASM or ELF payloads).
for pattern in ['*e2*.json','*e2*.log','*e2*.txt','*final*.json','*final*.log','*closure*.json']:
 for f in (P/'rendering').glob(pattern):add(f)
for pattern in ['*triage.json','required-font-language-cases-d48-e2.json','*e2*.json','*e2*.gz','*1321*.json']:
 for f in (P/'ci').glob(pattern):add(f)
for name in ['review.json','android-resolved-recording-notices.patch','tests-final-bounded.log','tests.log','editor-packaging-review.json','editor-packaging-evidence-addendum.json']:add(P/'android-notice-fix'/name)
for name in ['android-release-d48-native-complete-package-failed.json','android-release-d48ceb59-j10.log.gz']:add(P/'rendering'/name)
for directory in (P/'rendering').glob('frozen-web-final-*'):
 for name in ['snapshot-provenance.json','localization-payload.json']:add(directory/name)
for folder in ['modal-highlight-fix','android-verifier-fix']:
 for f in (P/folder).rglob('*'):
  if any(x in f.relative_to(P/folder).parts for x in ('before','after','unfixed-swimming-800-profile')):continue
  add(f)
add(P/'rendering/frozen-native-e3/preservation.json')
add(P/'native-release-smoke/drive-final-gui.py')
for name in ['run-browser-runtime.py','browser-runtime-check.cjs','publish-final-checkpoint.py','export-final-evidence.py','build-final-public-inventory.py']:add(P/name)
(U/'final-public-evidence-files.json').write_text(json.dumps(sorted(files),indent=2)+'\n')
print(len(files),'curated public evidence files')
