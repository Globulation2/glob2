"""Private native UI driver using the documented in-game MCP adapter."""
from pathlib import Path
import argparse,json,subprocess,sys,time,urllib.error,hashlib
import client,control
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
p=argparse.ArgumentParser();p.add_argument('phase',choices=['first','restart']);p.add_argument('--prefix',required=True);p.add_argument('--revision',required=True);p.add_argument('--verifier',type=Path);a=p.parse_args()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==a.revision
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip()
state=json.loads((BASE/'state.json').read_text());assert state['expected_source_revision']==a.revision and state['username_override'] is None
profile=Path(state['profile'])/'preferences.txt';expected='తెలుగు పరీక';typed='తెలుగు పరీక్ష';assert len(typed.encode())==37 and len(expected.encode())==31
result={'phase':a.phase,'revision':a.revision,'prefix':a.prefix,'actual_images':[]}
def capture(name):
 f=Path(client.capture(a.prefix+'-'+name));result['actual_images'].append({'path':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
def invoke(name,**kwargs):return control.invoke(name,dict(kwargs,capture_after=False))
def key(name,**kwargs):return invoke('ui_key',key=name,**kwargs)
def check(language,name):
 raw=profile.read_bytes();raw.decode('utf-8','strict');assert ('language='+language+'\n').encode() in raw;assert ('username='+name+'\n').encode() in raw
for attempt in range(45):
 try:client.rpc('initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'Final Telugu native GUI QA','version':'1'}});break
 except urllib.error.URLError as error:
  if not isinstance(error.reason,ConnectionRefusedError):raise
  time.sleep(1)
else:raise RuntimeError('Private app not ready after45 bounded connection retries')
if a.phase=='first':
 check('te','TeluguFinalProbe');capture('main');invoke('ui_click',x=150,y=547);capture('settings');invoke('ui_click',x=125,y=350);capture('player-ascii-fixture')
 invoke('ui_click',x=887,y=221);key('A',modifiers=['Left Ctrl']);invoke('ui_type_text',text=typed);key('Return');capture('name-after-typing');check('te',expected)
 language_files=[x for x in (ROOT/'data/texts.list.txt').read_text().splitlines() if x!='data/texts.keys.txt'];assert language_files[-1]=='data/texts.te.txt';english=language_files.index('data/texts.en.txt')
 invoke('ui_click',x=887,y=155);key('Home')
 for i in range(english):key('Down')
 key('Return');capture('english-with-telugu-name');check('en',expected)
 invoke('ui_click',x=887,y=137);key('End');key('Return');capture('telugu-restored');check('te',expected)
 invoke('ui_click',x=914,y=723);capture('main-final');invoke('ui_click',x=150,y=631)
 result.update(input=typed,input_utf8_bytes=37,actual_saved_name=expected,actual_saved_utf8_bytes=31,language_cycle=['te','en','te'],initial_fixture_name='TeluguFinalProbe')
else:
 check('te',expected);capture('restart-main');invoke('ui_click',x=150,y=547);invoke('ui_click',x=125,y=350);capture('restart-persisted-name');check('te',expected)
 assert a.verifier is not None;subprocess.run([sys.executable,str(a.verifier.resolve())],cwd=ROOT,check=True)
 invoke('ui_click',x=914,y=723);invoke('ui_click',x=150,y=631)
 result.update(restored_language='te',restored_username=expected,system_preference='en_US',username_override=None)
result['result']='Actual UI phase passed; parent separately verifies app normal exit'
(BASE/(a.prefix+'-'+a.phase+'-driver.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(result['result'])
