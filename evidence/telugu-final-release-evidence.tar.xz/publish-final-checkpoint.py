import hashlib,json,os,pathlib,subprocess,tarfile,tempfile
root=pathlib.Path.cwd();p=root/'artifacts/localization-telugu';before=subprocess.check_output(['git','status','--porcelain'])
metas=[json.loads((p/n).read_text()) for n in ('evidence-export.json','native-evidence-export.json')]+json.loads((p/'final-evidence-export.json').read_text())['archives']
for m in metas:
 a=p/m['file'];assert hashlib.sha256(a.read_bytes()).hexdigest()==m['sha256']
 with tarfile.open(a,'r:xz') as t:
  for line in t.extractfile('SHA256SUMS').read().decode().splitlines():
   h,n=line.split('  ',1);assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h,n
readme='# Telugu localization evidence\n\nSource PR: https://github.com/Globulation2/glob2/pull/1321\n\nAgent-reviewed, not native-human-certified. Each archive includes SHA256SUMS and exact source/producer identities. Extract the two historical checkpoints first, then all final packet parts, retaining relative paths. No credentials, raw API responses, SDKs or game executables are included.\n\n'
for m in metas:
 readme+=f"- [{m['file']}](evidence/{m['file']}): {m['bytes']:,} bytes, source `{m['source_revision']}`, SHA-256 `{m['sha256']}`.\n"
readme+='\nThe first packet preserves initial full-catalog linguistic review and online captures. The second preserves the original native font matrix, menus/gameplay/all tutorials, focused tests and optimized Linux checkpoint. The final packet adds source evolution and exact-pair review proofs, final current-data runtime/package evidence, independent visual reviews, cost reservations and explicit platform limits. Historical executions keep their actual producers; unchanged coverage is carried only through recorded equality proofs.\n'
previews=[
 ('native-main.png','native-release-smoke/u4-release-main.png','a43402ce84d4a111b7c55cc98da128ddaf8fb1b0','Optimized native Telugu menu'),
 ('tutorial-before.png','modal-highlight-fix/unfixed-swimming-800/tutorial-swimming-briefing.png','9fb134665c5082238e1cfad9541891499e8a4a72 +dirty diagnostic harness','Actual pre-fix briefing overlap'),
 ('tutorial-after.png','source-update-bc8/rendering/tutorials-2eafc9df/14-tutorial-swimming-800x600/tutorial-swimming-briefing.png','2eafc9df2c7a3fd9a2ea00c24f61af287a48812d','Actual corrected briefing'),
 ('online-phone.png','online-integration-d48/screenshots/phone/te-upload.png','d48ceb5978e803bc742fc51beacd94606a636574','Actual online phone map form; unchanged platform inputs carry to final head')]
preview_manifest=[]
readme+='\n## Selected actual captures\n\n'
for name,source,revision,caption in previews:
 data=(p/source).read_bytes();preview_manifest.append({'file':'evidence/previews/'+name,'source':source,'actual_producer':revision,'caption':caption,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 readme+=f'[{caption}](evidence/previews/{name}) — producer `{revision}`.\n\n'
with tempfile.TemporaryDirectory() as d:
 env=dict(os.environ,GIT_INDEX_FILE=str(pathlib.Path(d)/'index'))
 def git(*args,input=None):return subprocess.check_output(['git',*args],env=env,input=input).decode().strip()
 ref='refs/heads/codex/telugu-localization-evidence';parent=git('rev-parse',ref);git('read-tree',parent)
 files=[('README.md',readme.encode()),('evidence/native-manifest.json',(p/'native-evidence-export.json').read_bytes()),('evidence/final-manifest.json',(p/'final-evidence-export.json').read_bytes())]+[('evidence/'+m['file'],(p/m['file']).read_bytes()) for m in metas]
 files += [('evidence/previews/'+name,(p/source).read_bytes()) for name,source,revision,caption in previews]
 files.append(('evidence/preview-manifest.json',(json.dumps(preview_manifest,ensure_ascii=False,indent=2)+'\n').encode()))
 for n,data in files:
  blob=git('hash-object','-w','--stdin',input=data);git('update-index','--add','--cacheinfo','100644',blob,n)
 tree=git('write-tree');commit=git('commit-tree',tree,'-p',parent,input=b'Publish final Telugu review, runtime and release package evidence\n');git('update-ref',ref,commit,parent);print(commit)
assert subprocess.check_output(['git','status','--porcelain'])==before
