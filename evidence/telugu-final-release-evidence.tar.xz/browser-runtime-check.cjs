const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = process.cwd();
process.env.NODE_PATH = path.join(root, 'platform/node_modules');
require('node:module').Module._initPaths();
const playwright = require('@playwright/test');
const {waitForMainMenu,clickMainMenu,clickControl,clickSettingsDone} = require(path.join(root, 'browser/tests/main-menu.js'));
const out = path.join(root, 'artifacts/localization-telugu/browser-runtime');
fs.mkdirSync(out, {recursive:true});
const base = process.env.TELUGU_RUNTIME_URL || 'http://127.0.0.1:8879/play/';
const variants = (process.env.TELUGU_RUNTIME_VARIANTS || 'serial,threaded').split(',');
if (variants.some(x=>!['serial','threaded'].includes(x))) throw Error('Unknown runtime variant');
const resultFile = path.join(out,'results-'+variants.join('-')+'.json');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const expected = {
  font:hash(fs.readFileSync('data/fonts/scripts/NotoSansTelugu-Regular.ttf')),
  native:hash(fs.readFileSync('data/texts.te.txt')),
  nativeKeys:hash(fs.readFileSync('data/texts.keys.txt')),
  nativeEnglish:hash(fs.readFileSync('data/texts.en.txt')),
  online:hash(fs.readFileSync('platform/packages/i18n/locales/te.json')),
};
(async () => {
  const evidence = {base, expected, started:new Date().toISOString(), cases:[], limits:'Local production Caddy route only; no live CDN deployment or hosted artifact claim.'};
  matrix: for (const browserName of (process.env.TELUGU_RUNTIME_BROWSERS || 'chromium,firefox,webkit').split(',')) {
    for (const variant of variants) {
      const entry = {browserName,variant,started:new Date().toISOString(),errors:[],held:[],responses:[]};
      const wasmUrls = new Set();
      evidence.cases.push(entry);
      let browser,context,page,release,releaseTranslations;
      try {
        browser = await playwright[browserName].launch({headless:true});
        entry.browserVersion = browser.version();
        context = await browser.newContext({locale:'te-IN',viewport:{width:1200,height:900}});
        entry.freshContext = {initialCookies:(await context.cookies()).length,storage:'new nonpersistent browser context and browser process per case'};
        if (entry.freshContext.initialCookies !== 0) throw Error('Browser context is not fresh');
        await context.addCookies([{name:'glob2_locale',value:'te',url:base}]);
        page = await context.newPage();
        page.on('request', request => {if (/\.wasm(?:\?|$)/.test(request.url())) wasmUrls.add(request.url());});
        page.on('pageerror', e => entry.errors.push(String(e)));
        page.on('console', m => { if (/Can't load font|failed to load font|abort\(/i.test(m.text())) entry.errors.push(m.text()); });
        const gate = new Promise(resolve => {release = resolve;});
        const translationGate = new Promise(resolve => {releaseTranslations = resolve;});
        await page.route('**/assets/*.data', async route => {
          const name = new URL(route.request().url()).pathname.split('/').pop();
          if (/^translations(?:[.-])/.test(name)) {
            entry.held.push({name,at:new Date().toISOString()});
            await translationGate;
          } else if (!/^(core|game)(?:[.-])/.test(name)) {
            entry.held.push({name,at:new Date().toISOString()});
            await gate;
          }
          try {await route.continue();} catch {}
        });
        const url = new URL(base);
        url.searchParams.set('renderer','software');url.searchParams.set('threads',variant);
        await page.goto(url.href,{waitUntil:'domcontentloaded',timeout:120000});
        await page.waitForFunction(() => Boolean(globalThis.glob2Diagnostics),null,{timeout:120000});
        await page.waitForFunction(() => typeof FS !== 'undefined' &&
          FS.analyzePath('/data/fonts/scripts/NotoSansTelugu-Regular.ttf').exists &&
          glob2Diagnostics.snapshot().assets.core === 'ready',null,{timeout:180000});
        await playwright.expect.poll(() => entry.held.some(x=>/^translations[.-]/.test(x.name)),{timeout:60000}).toBe(true);
        entry.fontBeforeOptional = await page.evaluate(async () => ({
          at:new Date().toISOString(),state:glob2Diagnostics.snapshot(),
          sha256:Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',FS.readFile('/data/fonts/scripts/NotoSansTelugu-Regular.ttf')))).map(x=>x.toString(16).padStart(2,'0')).join(''),
        }));
        if (entry.fontBeforeOptional.sha256 !== expected.font) throw Error('Core font missing before optional packages');
        for (const [name,state] of Object.entries(entry.fontBeforeOptional.state.assets))
          if (!['core','game'].includes(name) && state === 'ready') throw Error('Optional package finished before core-font proof: '+name);
        entry.optionalReleasedAt = new Date().toISOString();
        releaseTranslations();release();
        await page.waitForFunction(() => glob2Diagnostics.snapshot().assets.translations === 'ready',null,{timeout:180000});
        await waitForMainMenu(page,{timeout:180000});
        await page.waitForFunction(() => Object.values(glob2Diagnostics.snapshot().controls).some(x=>/[\u0c00-\u0c7f]/.test(x.label || '')),null,{timeout:180000});
        entry.mainMenuAt = new Date().toISOString();
        entry.state = await page.evaluate(() => glob2Diagnostics.snapshot());
        entry.runtime = await page.evaluate(async () => {
          const digest = async bytes => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(x=>x.toString(16).padStart(2,'0')).join('');
          const launcherFonts = await document.fonts.load('20px "Glob2 Scripts"', 'తెలుగు');
          return {font:await digest(FS.readFile('/data/fonts/scripts/NotoSansTelugu-Regular.ttf')),
            native:await digest(FS.readFile('/data/texts.te.txt')),
            nativeKeys:await digest(FS.readFile('/data/texts.keys.txt')),
            nativeEnglish:await digest(FS.readFile('/data/texts.en.txt')),
            launcherFonts:launcherFonts.map(x=>({family:x.family,status:x.status,unicodeRange:x.unicodeRange})),
            locale:Glob2I18n.getLocale(),localeInventory:Glob2I18n.locales.map(({code,gameCode,name})=>({code,gameCode,name})),isolated:crossOriginIsolated,executionMode:Module.executionMode,
            labels:Object.values(glob2Diagnostics.snapshot().controls).map(x=>x.label).filter(Boolean)};
        });
        if (entry.runtime.locale !== 'te' || entry.runtime.executionMode !== variant) throw Error('Wrong locale or runtime variant');
        if (entry.runtime.localeInventory.length !== 38 || !entry.runtime.localeInventory.some(x=>x.code==='te' && x.gameCode==='te' && x.name==='తెలుగు') || !entry.runtime.localeInventory.some(x=>x.code==='nb')) throw Error('Final38-locale integration inventory is stale');
        if (entry.runtime.font !== expected.font || entry.runtime.native !== expected.native) throw Error('FS font/catalog hash mismatch');
        if (entry.runtime.nativeKeys !== expected.nativeKeys || entry.runtime.nativeEnglish !== expected.nativeEnglish)
          throw Error('FS native source key/English snapshot is stale');
        if (!entry.runtime.launcherFonts.length || entry.runtime.launcherFonts.some(x=>x.status !== 'loaded')) throw Error('Telugu launcher font is not loaded');
        if (!entry.runtime.labels.some(x=>/[\u0c00-\u0c7f]/.test(x))) throw Error('No Telugu game menu labels');
        if (variant === 'threaded' && !entry.runtime.isolated) throw Error('Threaded runtime is not isolated');
        if (!entry.held.length) throw Error('No optional package was held');
        for (const [relative,mime,expectedHash] of [
          ['fonts/NotoSansTelugu-Regular.ttf','font/ttf',expected.font],
          ['locales/te.json','application/json',expected.online],
          ['script-fonts.css','text/css',null]]) {
          const response = await context.request.get(new URL(relative,base).href,{headers:{'Accept-Encoding':'identity'}});
          const headers = response.headers();const bytes = await response.body();
          entry.responses.push({relative,status:response.status(),headers,sha256:hash(bytes)});
          if (response.status() !== 200 || headers['content-type'].split(';')[0] !== mime) throw Error('Wrong production asset MIME/status: '+relative);
          if (expectedHash && hash(bytes) !== expectedHash) throw Error('HTTP font/catalog hash mismatch: '+relative);
        }
        if (!wasmUrls.size) throw Error('No executable WebAssembly request observed');
        for (const url of wasmUrls) {
          const relative = new URL(url).pathname.slice(new URL(base).pathname.length);
          const payload = path.join(process.env.TELUGU_RUNTIME_DIR, relative);
          const response = await context.request.get(url,{headers:{'Accept-Encoding':'identity'}});
          const headers = response.headers(), actual = hash(await response.body()), expectedPayload = hash(fs.readFileSync(payload));
          entry.responses.push({relative,status:response.status(),headers,sha256:actual,packageFile:payload,expectedSha256:expectedPayload});
          if (actual !== expectedPayload || response.status() !== 200 || headers['content-type'].split(';')[0] !== 'application/wasm')
            throw Error('Executable WebAssembly MIME/bytes mismatch');
        }
        await page.screenshot({path:path.join(out,`${browserName}-${variant}.png`)});
        entry.menuVerifiedBeforeUsernameAt = new Date().toISOString();
        // Exercise the actual DOM-to-C++ Settings path that previously split a
        // Telugu codepoint at the network's32-byte username boundary.
        const input = 'తెలుగు పరీక్ష';
        let expectedPrefix = '';
        for (const codepoint of input) {
          if (Buffer.byteLength(expectedPrefix+codepoint,'utf8')>32) break;
          expectedPrefix += codepoint;
        }
        const readUsername = () => page.evaluate(() => {
          const file='/home/web_user/.glob2/preferences.txt';
          if (!FS.analyzePath(file).exists) return null;
          return new TextDecoder('utf-8',{fatal:true}).decode(FS.readFile(file)).match(/^username=(.*)$/m)?.[1] ?? null;
        });
        await clickMainMenu(page,'settings');
        await clickControl(page,'nav.5');await clickControl(page,'player.name');
        const fieldLabel = await page.evaluate(()=>Glob2I18n.t('Game text field'));
        let field = page.getByRole('textbox',{name:fieldLabel,exact:true});
        const initialFieldValue = await field.inputValue();
        const initialStoredUsername = await readUsername();
        if (initialFieldValue === expectedPrefix || initialStoredUsername === expectedPrefix)
          throw Error('Pre-existing Telugu username would invalidate fresh-input proof');
        const asciiBaseline = 'TeluguFinalProbe';
        await field.fill(asciiBaseline);await field.press('Enter');
        await playwright.expect.poll(readUsername,{timeout:30000}).toBe(asciiBaseline);
        const asciiStoredBeforeTelugu = await readUsername();
        await clickControl(page,'player.name');
        field = page.getByRole('textbox',{name:fieldLabel,exact:true});
        await playwright.expect(field).toHaveValue(asciiBaseline);
        await field.fill(input);await field.press('Enter');
        await playwright.expect.poll(readUsername,{timeout:30000}).toBe(expectedPrefix);
        await clickSettingsDone(page);await waitForMainMenu(page);
        entry.username = {initialFieldValue,initialStoredUsername,asciiBaseline,asciiStoredBeforeTelugu,input,inputBytes:Buffer.byteLength(input,'utf8'),expectedPrefix,
          prefixBytes:Buffer.byteLength(expectedPrefix,'utf8'),savedBeforeReload:await readUsername()};
        await page.reload({waitUntil:'domcontentloaded',timeout:120000});await waitForMainMenu(page,{timeout:180000});
        await playwright.expect.poll(readUsername,{timeout:30000}).toBe(expectedPrefix);
        entry.username.savedAfterReload = await readUsername();
        await clickMainMenu(page,'settings');await clickControl(page,'nav.5');await clickControl(page,'player.name');
        field = page.getByRole('textbox',{name:fieldLabel,exact:true});
        await playwright.expect(field).toHaveValue(expectedPrefix);
        entry.username.fieldAfterReload = await field.inputValue();
        await page.screenshot({path:path.join(out,`${browserName}-${variant}-username.png`)});
        if (entry.errors.length) throw Error('Browser errors: '+entry.errors.join('; '));
        entry.pass = true;
      } catch (error) {
        entry.pass = false;entry.failure = String(error.stack || error);
        if (page) try {entry.failureState = await page.evaluate(()=>globalThis.glob2Diagnostics?.snapshot());} catch {}
        if (page) try {await page.screenshot({path:path.join(out,`${browserName}-${variant}-failure.png`),timeout:10000});} catch {}
      } finally {
        releaseTranslations?.();release?.();
        await context?.close().catch(()=>{});await browser?.close().catch(()=>{});
        entry.finished = new Date().toISOString();
        fs.writeFileSync(resultFile,JSON.stringify(evidence,null,2)+'\n');
        console.log(JSON.stringify({browserName,variant,pass:entry.pass,failure:entry.failure}));
      }
      if (!entry.pass && process.env.TELUGU_RUNTIME_STOP_ON_FAILURE === '1') break matrix;
    }
  }
  evidence.finished = new Date().toISOString();
  evidence.requestedVariants = variants;
  evidence.allRequestedCasesPassed = evidence.cases.every(x=>x.pass);
  evidence.completeBrowserMatrix = evidence.cases.length === 6;
  evidence.pass = evidence.cases.length === 6 && evidence.cases.every(x=>x.pass);
  fs.writeFileSync(resultFile,JSON.stringify(evidence,null,2)+'\n');
  if (evidence.cases.some(x=>!x.pass)) process.exitCode = 1;
})();
