"""Run the Telugu WASM checks through the repository's actual Caddy /play route."""
import argparse,hashlib,importlib.util,json,os,socket,subprocess,time
from pathlib import Path

root=Path.cwd()
parser=argparse.ArgumentParser();parser.add_argument('package',type=Path);parser.add_argument('--provenance',required=True,type=Path)
args=parser.parse_args();package=args.package.resolve();assert (package/'index.html').is_file()
assert args.provenance.is_file(),'Producer evidence is required; package bytes alone do not prove a revision'
out=root/'artifacts/localization-telugu/browser-runtime';out.mkdir(parents=True,exist_ok=True)
suffix=os.environ.get('TELUGU_RUNTIME_VARIANTS','serial,threaded').replace(',','-')
assert suffix in ['serial','threaded','serial-threaded']
spec=importlib.util.spec_from_file_location('production_play_rules',root/'test/deployment/test_browser_font_types.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=(root/'deploy/Caddyfile').read_text();rules=module.play_rules(original)
with socket.socket() as reservation:
 reservation.bind(('127.0.0.1',0));port=reservation.getsockname()[1]
rules=rules.replace('root * /srv/play','root * '+json.dumps(str(package)))
config=out/('Caddyfile-'+suffix);config.write_text('{\nadmin off\n}\nhttp://127.0.0.1:'+str(port)+' {\n'+rules+'\n}\n')
caddy=root/'artifacts/localization-telugu/tools/caddy'
node=Path('/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node')
command=[str(node),str(root/'artifacts/localization-telugu/browser-runtime-check.cjs')]
metadata={'package':str(package),'producer_evidence':str(args.provenance.resolve()),
 'producer_evidence_sha256':hashlib.sha256(args.provenance.read_bytes()).hexdigest(),
 'original_Caddyfile_sha256':hashlib.sha256(original.encode()).hexdigest(),
 'server_config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),
 'caddy_version':subprocess.check_output([str(caddy),'version'],text=True).strip(),
 'command':command,'url':f'http://127.0.0.1:{port}/play/'}
(out/('host-provenance-'+suffix+'.json')).write_text(json.dumps(metadata,indent=2)+'\n')
env=os.environ.copy();env['TELUGU_RUNTIME_URL']=metadata['url'];env['TELUGU_RUNTIME_DIR']=str(package)
env['PATH']=str(node.parent)+':'+env['PATH']
with (out/('caddy-'+suffix+'.log')).open('w') as log:
 server_env=os.environ.copy();server_env['XDG_CONFIG_HOME']=str(out/'caddy-state/config');server_env['XDG_DATA_HOME']=str(out/'caddy-state/data')
 server=subprocess.Popen([str(caddy),'run','--config',str(config),'--adapter','caddyfile'],stdout=log,stderr=log,env=server_env)
 try:
  for _ in range(100):
   assert server.poll() is None,'Caddy exited; inspect browser-runtime/caddy.log'
   try:
    with socket.create_connection(('127.0.0.1',port),timeout=.1):break
   except OSError:time.sleep(.05)
  else:raise RuntimeError('Caddy did not start')
  result=subprocess.run(command,env=env)
 finally:
  server.terminate();server.wait(timeout=10)
raise SystemExit(result.returncode)
