#!/usr/bin/env python3
"""Require the actual expected pre-fix pixel regression; never a release pass."""
import hashlib,json,os,pathlib,signal,subprocess,time
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[2];REV='9fb134665c5082238e1cfad9541891499e8a4a72';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();B=ROOT/'build/linux/client/release/test/TranslationPreviewHarness';OUT=BASE/'unfixed-swimming-800';assert not OUT.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==REV
assert subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).splitlines()==['tools/TranslationPreviewHarness.cpp']
assert sha(ROOT/'tools/TranslationPreviewHarness.cpp')=='4110db1a0ef73caf6510d528b59cdb14ce6d310a67e61b14211c700c08bf6c07'
assert sha(ROOT/'src/hud/draw/GameGUIDraw.cpp')=='e03a6d7da3b4e48ed726c745a40e97473dd3196b4e3d8f43ef0d8c610b2c1d67'
overlay=ROOT/'artifacts/localization-telugu/source-update-bc8/rendering/final-9fb13466/overlays/full-overlay';binarysha=sha(B);assert binarysha=='c39ef6ac70a3ed9a72fdb418c8c9ffd48e70679e24a761e98ceff0f534f55051';env=dict(os.environ,SDL_VIDEODRIVER='x11',SDL_AUDIODRIVER='dummy',LP_NUM_THREADS='2',LD_LIBRARY_PATH=str(ROOT/'artifacts/localization-telugu/rendering/sdl-prefix/lib'),GLOB2_USER_DATA_DIR=str(BASE/'unfixed-swimming-800-profile'));env.pop('WAYLAND_DISPLAY',None);env.pop('GLOB2_MOBILE_UI',None)
cmd=['xvfb-run','-a','-s','-screen 0 1280x960x24',str(B),'game',str(ROOT),str(overlay),str(OUT),'800','600','tutorial:swimming'];start=time.time()
with (BASE/'unfixed-swimming-800.log').open('wb') as log:
 proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:rc=proc.wait(timeout=600)
 except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGTERM);proc.wait();raise
assert rc==1,('Expected actual ROI regression failure',rc)
p=OUT/'tutorial-swimming.json';d=json.loads(p.read_text());e=d['evidence_identity'];v=e['producer'];m=d['modal_highlight_comparison'];assert v['revision']==REV and v['dirty'];assert e['executable_sha256']==binarysha;assert '-O3' in(v['flags']['CCFLAGS']+' '+v['flags']['CXXFLAGS']);assert m['differing_pixels']>0 and m['restoration_differing_pixels']==0;assert m['baseline_roi_sha256']==m['restored_roi_sha256']!=m['probe_roi_sha256'];assert m['checksum_before']==m['checksum_after'];assert all(x['checksum_before_draw']==x['checksum_after_draw'] for x in d['captures']);assert sha(B)==binarysha
images=[{'path':str(p.relative_to(BASE)),'sha256':sha(p)} for p in sorted(OUT.glob('*.png'))];assert len(images)==3
r={'result':'EXPECTED pre-fix actual pixel regression reproduced; NOT a release/readiness pass','revision':REV,'dirty_producer':v,'binary':str(B),'binary_sha256':binarysha,'command':cmd,'returncode':rc,'seconds':time.time()-start,'actual_report_sha256':sha(p),'actual_images':images,'modal_highlight_comparison':m,'source_sha256':e['source_sha256'],'scope':['Actual swimming800 briefing and lesson remain intact.','One real legacy highlight was inserted/restored; actual arrow intersects actual modal bounds.','Baseline and restored modal RGBA hashes match; additional arrow changes real modal pixels before the fix.','All measured UI draws preserve simulation checksum.','Only test harness is dirty; production draw guard is still absent.']};(BASE/'unfixed-regression-proof.json').write_text(json.dumps(r,indent=2)+'\n');print('EXPECTED PIXEL FAILURE reproduced:',m['differing_pixels'],'changed modal pixels, restoration0',flush=True)
