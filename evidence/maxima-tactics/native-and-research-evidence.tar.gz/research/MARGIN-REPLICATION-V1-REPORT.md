# Independent commitment and arrival replication

144 complete games: 72 baseline and 72 with the same-enemy scoring bonus plus bounded 4,000-AI-timer-tick arrival grace. No forward buildings. Six generators, 18 fresh generator/map-seed clusters, both seats and two RNG seeds; exact maps shared. This uses the frozen older v8 research bundle and is not pooled with the factorial screen or the current-master placement study.

Baseline: 3 wins, 30 losses, 39 unresolved. Candidate: 3 wins, 27 losses, 42 unresolved. There was one gained win and one lost win. The original extra wins did not repeat as a net gain here. This does not establish equivalence; the paired win difference interval spans about -4.2 to +4.2 percentage points.

These are six/eight-player, large-map FFAs capped at 120,000 ticks with natural victory and no early adjudication. Their low absolute win rates do not estimate Maxima performance in ordinary matches.

| Paired candidate minus baseline | Difference [95% interval] | Available games / terrain clusters |
|---|---:|---:|
|Win rate|+0.000 [-4.167, +4.167] pp|72 / 18|
|Loss rate|-4.167 [-15.278, +8.333] pp|72 / 18|
|Own unresolved rate|+4.167 [-8.333, +16.667] pp|72 / 18|
|Advantage conversion|+0.000 [-12.000, +13.636] pp|23 / 10|
|Capped remaining time after baseline advantage|+830.609 [-250.000, +2493.130] ticks|23 / 10|
|Live-enemy switches per game|-1.750 [-2.500, -1.056] |72 / 18|
|Offensive attached combat|+0.462 [-0.146, +1.159] pp|66 / 18|
|Offensive attached flag travel|-0.165 [-2.790, +2.368] pp|66 / 18|
|Whole-army combat|-0.113 [-0.299, +0.059] pp|72 / 18|
|Whole-army medical travel|+1.450 [+0.333, +2.522] pp|72 / 18|
|Clinical departure followed by offensive combat|-4.607 [-9.151, -1.032] pp|65 / 18|
|Melee-class starvation per 100,000 warrior ticks|+0.250 [+0.075, +0.435] |72 / 18|

Intervals resample whole generator/map-seed clusters with their seats and RNG repetitions together. Secondary metrics are exploratory and correlated. Medical-return differences use only matched games with departures in both arms; denominator availability is explicit. Starvation is the engine melee-class death counter, not inferred from a missing unit.

## Reproducibility across terrain

| Mechanism | Clusters increasing / decreasing / tied |
|---|---:|
|Live-enemy switching|1 / 15 / 2|
|Medical travel|13 / 5 / 0|
|Clinical return fraction|8 / 10 / 0|
|Starvation rate|13 / 5 / 0|

The mean starvation-rate change is positive in all six generator groups; that directional consistency is descriptive, not six independent significance tests. Clinical-return direction is mixed across generators.

## Five whys: fewer switches did not produce more victories

1. Why are advantages still not consistently converted? The same baseline-defined advantage subset converted 3 of 23 games in both arms; 20 failed to win before the limit in each arm.
2. Why does better commitment not settle that? Switching fell by 1.75 per game, but whole-army combat did not rise. Offensive-flag combat improved only modestly with an interval spanning zero. Commitment is an intermediate mechanism.
3. Why can committed warriors still be ineffective? More warrior time went into food/healing travel (+1.45 pp, interval positive), and the fraction of clinical departures reaching offensive combat fell (paired -4.61 pp, interval negative).
4. Why does this fit the code? The commitment bonus changes target scores and the grace changes dwell/stall timing. Neither creates nearby feeding/healing capacity, moves support, nor guarantees a safe supplied path back to contact. Emergency overrides remain.
5. Why is placement the next bounded test? A dedicated supplied forward route could reduce this support burden while preserving commitment. That is a hypothesis, not proof that commitment caused every medical trip; economic development, enemy resistance and survival exposure can also change. The frozen current-master ring/corridor distance study directly tests the support hypothesis.

## Five whys: the marginal win signal did not replicate

1. Why no net extra wins? One fresh scenario changed unresolved to won while another changed won to unresolved.
2. Why not judge from the gained match? The paired difference across all 72 scenarios is zero, with wide uncertainty. Both discordant wins are Old Town; neither establishes a general terrain benefit.
3. Why can intermediate gains disagree with wins? Fewer redirects do not establish building damage or elimination, and long medical absences compete with assault time.
4. Why is this still unresolved? There are only 18 independent map clusters and only six total wins, despite 144 games. The advantage proxy also omits towers, geography, magic and local force placement.
5. What follows? Retain the small-gain hypothesis but require independent comparisons and service/damage evidence. Do not promote from this replication alone or declare a small effect absent.

## Discordant win scenarios (trace anchors, not the statistical argument)

- `old-town-560002-r4-g2026102607`: won to unresolved; [baseline artifacts](runs/margin-replication-v1-baseline-old-town-560002/old-town-560002-r4-g2026102607/result.json), [candidate artifacts](runs/margin-replication-v1-finalist-old-town-560002/old-town-560002-r4-g2026102607/result.json).
- `old-town-560003-r0-g2026102606`: unresolved to won; [baseline artifacts](runs/margin-replication-v1-baseline-old-town-560003/old-town-560003-r0-g2026102606/result.json), [candidate artifacts](runs/margin-replication-v1-finalist-old-town-560003/old-town-560003-r0-g2026102606/result.json).

All logs, saves, replay files and exact commands are retained in those run directories. The complete manifest and analysis retain every game. No default promotion. Linux x86_64 evidence only; other-platform checksum coverage and maintainer play-through remain unavailable.

[Full paired analysis](margin-replication-v1-analysis.json) · [Frozen manifest](margin-replication-v1-complete-manifest.json) · [Frozen rule](margin-replication-v1-rule.json)
