"""Read-only paired statistics extracted from the frozen probability analysis.
No legacy recorder, subprocess or command-line entrypoint is imported.
"""
from pathlib import Path
from collections import defaultdict,Counter
import json
import numpy as np
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'winprob-integral-v2'
SEED=2026102701
METRICS=['integrated_win_probability','late_integrated_win_probability','advantage_integrated_win_probability','terminal_probability','win','loss','unresolved']
def freeze(path,value):
 if path.exists():assert json.loads(path.read_text())==value,'Frozen analysis differs'
 else:path.write_text(json.dumps(value,indent=2)+'\n')
def interval(blocks):
    groups = defaultdict(list)
    for cluster, value in blocks:
        if value is not None:
            groups[cluster].append(value)
    groups = list(groups.values())
    if not groups:
        return dict(estimate=None, ci95=None, pairs=0, clusters=0)
    sums = np.array([sum(x) for x in groups])
    counts = np.array([len(x) for x in groups])
    estimate = float(sums.sum() / counts.sum())
    result = dict(estimate=estimate, ci95=None, pairs=int(counts.sum()), clusters=len(groups))
    if len(groups) > 1:
        picks = np.random.default_rng(SEED).integers(0, len(groups), (10000, len(groups)))
        draws = np.sort(sums[picks].sum(1) / counts[picks].sum(1))
        result.update(ci95=[float(draws[250]), float(draws[9750])], bootstrap_degenerate=bool(draws[0] == draws[-1]))
    return result

def comparisons(rows, reference):
    pairs = defaultdict(dict)
    for r in rows:
        assert r['arm'] not in pairs[r['pair']]
        pairs[r['pair']][r['arm']] = r
    labels = sorted({r['arm'] for r in rows})
    assert all((set(p) == set(labels) for p in pairs.values()))
    result = {}
    for candidate in labels:
        if candidate == reference:
            continue
        c = {}
        for key in METRICS:
            blocks = []
            missing = 0
            for p in pairs.values():
                a, b = (p[reference], p[candidate])
                assert a['cluster'] == b['cluster']
                if a[key] is None or b[key] is None:
                    missing += 1
                    continue
                blocks.append((a['cluster'], b[key] - a[key]))
            c[key] = dict(interval(blocks), unavailable_pairs=missing, positive_pairs=sum((v > 0 for _, v in blocks)), negative_pairs=sum((v < 0 for _, v in blocks)), tied_pairs=sum((v == 0 for _, v in blocks)))
        result[candidate] = c
    return result

def analyze(rows, campaign):
    reference = 'c0a0f0' if campaign == 'factorial' else 'baseline'
    labels = sorted({r['arm'] for r in rows})
    candidates = [a for a in labels if a != reference]
    pairs = defaultdict(dict)
    for r in rows:
        pairs[r['pair']][r['arm']] = r
    groups = defaultdict(list)
    for p in pairs.values():
        groups[p[reference]['cluster']].append([p[a]['integrated_win_probability'] - p[reference]['integrated_win_probability'] for a in candidates])
    vals = list(groups.values())
    sums = np.array([np.sum(x, axis=0) for x in vals])
    counts = np.array([len(x) for x in vals])
    estimate = sums.sum(0) / counts.sum()
    picks = np.random.default_rng(SEED).integers(0, len(vals), (10000, len(vals)))
    draws = sums[picks].sum(1) / counts[picks].sum(1)[:, None]
    radius = float(np.sort(np.max(np.abs(draws - estimate), axis=1))[9500])
    summary = {a: dict(games=sum((r['arm'] == a for r in rows)), outcomes=dict(Counter((r['outcome'] for r in rows if r['arm'] == a))), means={k: float(np.mean(v)) if (v := [r[k] for r in rows if r['arm'] == a and r[k] is not None]) else None for k in METRICS}) for a in labels}
    report = dict(campaign=campaign, reference=reference, arms=summary, versus_baseline=comparisons(rows, reference), by_generator={g: comparisons([r for r in rows if r['generator'] == g], reference) for g in sorted({r['generator'] for r in rows})}, simultaneous_primary=dict(radius=radius, contrasts={a: dict(estimate=float(v), ci95=[float(v - radius), float(v + radius)]) for a, v in zip(candidates, estimate)}), post_hoc=True, automatic_promotion=False)
    if 'commitment-arrival' in labels:
        report['versus_commitment_arrival'] = comparisons(rows, 'commitment-arrival')
    if campaign == 'placement-confirmation':
        report['interaction'] = interval([(p[reference]['cluster'], p['combined']['integrated_win_probability'] - p['commitment-arrival']['integrated_win_probability'] - p['placement']['integrated_win_probability'] + p['baseline']['integrated_win_probability']) for p in pairs.values()])
    report['ranking_by_integrated_probability'] = sorted(labels, key=lambda a: (-summary[a]['means']['integrated_win_probability'], a))
    result = dict(report=report, games=rows)
    freeze(OUT / f'{campaign}-analysis.json', result)
    lines = ['# Integrated win probability: ' + campaign, '', 'Existing published model; no refit. Fixed5120..120000tick integral, normalized to mean probability; actual wins/losses absorb1/0 after resolution. All repeats must match original checksums, outcomes and full warrior CSVs. Repeats do not increase sample size. This is a user-requested post-hoc endpoint; original selection rules and in-flight arms were preserved.', '', '|Arm|Games|W/L/U|Mean integrated probability|Change vs baseline, pp [95% interval]|', '|---|---:|---:|---:|---:|']
    for a, s in summary.items():
        o = s['outcomes']
        change = 'reference'
        if a != reference:
            c = report['versus_baseline'][a]['integrated_win_probability']
            change = f'{100 * c['estimate']:+.3f} [{100 * c['ci95'][0]:+.3f}, {100 * c['ci95'][1]:+.3f}]'
        lines.append(f'|{a}|{s['games']}|{o.get('won', 0)}/{o.get('lost', 0)}/{o.get('unresolved', 0)}|{s['means']['integrated_win_probability']:.3%}|{change}|')
    lines += ['', 'Pointwise intervals bootstrap whole generator/map-seed clusters; simultaneous primary bands, late-game and same-baseline-advantage integrals are in JSON. All games are equally weighted; time samples are not independent trials. Do not pool campaigns or source bases.', '', 'This score measures a lead sustained over time. It can reward a high-probability stalemate; it does not establish conversion speed, model calibration on these new maps, or a realized win-rate increase. Actual victories, unresolved games and the existing damage/contact diagnostics remain necessary. Original model validation used a mixed-format earlier campaign; it is not a new validation on these large FFAs.', '', 'All source data, command identities, 512-tick model curves and exact-repeat proofs are under the per-run recovery directories.']
    (OUT / f'{campaign}-report.md').write_text('\n'.join(lines) + '\n')
    print('ANALYSIS_COMPLETE', campaign, json.dumps({a: s['means']['integrated_win_probability'] for a, s in summary.items()}), flush=True)
