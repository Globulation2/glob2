# Maxima tactical combinations

Completed 576 full FFA games: eight combinations × 72 games, six generators, 18 terrain clusters, opposite seats and two simulation seeds. Every arm used the same frozen v8 executable/assets and exact matched map exports. Settings and analysis criteria were frozen before games completed.

C = soft enemy commitment; A = 4000 configured AI-timer arrival grace; F = dedicated forward inn and hospital pathway, ordinary construction first, standoff 24. Normal home building placement and emergency overrides remain intact.

| Combination | W/L/U | Baseline-defined advantage W/L/U | Win change, pp [95% CI] | Advantage conversion change, pp [95% CI] | Remaining time change, ticks [95% CI] |
|---|---:|---:|---|---|---|
| Baseline | 7/24/41 | 7/1/15 | reference | reference | reference |
| Forward services | 7/22/43 | 6/3/14 | +0.00 [-4.17, +4.17]; n=72, clusters=18 | -4.35 [-13.04, +0.00]; n=23, clusters=11 | +1804 [-664, +4733]; n=23, clusters=11 |
| Arrival grace | 7/25/40 | 6/5/12 | +0.00 [-4.17, +4.17]; n=72, clusters=18 | -4.35 [-13.04, +0.00]; n=23, clusters=11 | +2464 [-518, +6266]; n=23, clusters=11 |
| Arrival + forward | 8/26/38 | 8/4/11 | +1.39 [-2.78, +5.56]; n=72, clusters=18 | +4.35 [-9.09, +21.74]; n=23, clusters=11 | -1230 [-5834, +2757]; n=23, clusters=11 |
| Commitment | 8/25/39 | 8/3/12 | +1.39 [-2.78, +5.56]; n=72, clusters=18 | +4.35 [-8.70, +23.53]; n=23, clusters=11 | +893 [-5156, +6851]; n=23, clusters=11 |
| Commitment + forward | 7/24/41 | 6/3/14 | +0.00 [-5.56, +5.56]; n=72, clusters=18 | -4.35 [-17.24, +11.76]; n=23, clusters=11 | +140 [-1990, +2277]; n=23, clusters=11 |
| Commitment + arrival | 9/21/42 | 8/2/13 | +2.78 [+0.00, +8.33]; n=72, clusters=18 | +4.35 [+0.00, +15.79]; n=23, clusters=11 | +1432 [-4384, +7576]; n=23, clusters=11 |
| All three | 6/24/42 | 6/3/14 | -1.39 [-6.94, +2.78]; n=72, clusters=18 | -4.35 [-17.39, +10.53]; n=23, clusters=11 | +833 [-1298, +3347]; n=23, clusters=11 |

All time-to-victory observations include losses and tick caps. In the advantage subset every arm uses the same baseline-defined start time; an earlier victory receives 0 remaining ticks, a nonvictory receives the remaining tick limit. There is no candidate-survivor filtering. The army-power proxy omits towers, geography, magic and positioning and does not guarantee a win.

## Warrior effectiveness

| Combination | Offensive combat change, pp | Offensive transit change, pp | Clinical return-to-combat change, pp | Building damage/warrior-tick change |
|---|---|---|---|
| Forward services | +0.18 [-0.25, +0.62]; n=64, clusters=18 | -1.06 [-2.72, +0.21]; n=64, clusters=18 | -0.15 [-1.40, +1.01]; n=62, clusters=18 | -0.000020 [-0.000358, +0.000336]; n=72, clusters=18 |
| Arrival grace | +0.84 [-0.23, +2.02]; n=64, clusters=18 | -1.90 [-4.36, +0.46]; n=64, clusters=18 | -1.33 [-3.48, +0.78]; n=62, clusters=18 | -0.000842 [-0.001415, -0.000310]; n=72, clusters=18 |
| Arrival + forward | +0.89 [-0.16, +2.05]; n=64, clusters=18 | -2.38 [-4.97, +0.11]; n=64, clusters=18 | +0.03 [-2.27, +2.55]; n=62, clusters=18 | -0.000628 [-0.001285, -0.000039]; n=72, clusters=18 |
| Commitment | +0.57 [-0.15, +1.40]; n=64, clusters=18 | -1.28 [-3.41, +0.65]; n=64, clusters=18 | -0.61 [-2.44, +1.05]; n=62, clusters=18 | +0.000050 [-0.000731, +0.000866]; n=72, clusters=18 |
| Commitment + forward | +0.57 [-0.20, +1.47]; n=64, clusters=18 | -2.07 [-4.15, -0.12]; n=64, clusters=18 | -0.10 [-1.57, +1.41]; n=62, clusters=18 | +0.000403 [-0.000498, +0.001309]; n=72, clusters=18 |
| Commitment + arrival | +1.24 [+0.41, +2.16]; n=64, clusters=18 | -2.22 [-4.67, +0.27]; n=64, clusters=18 | -1.88 [-4.10, +0.26]; n=62, clusters=18 | -0.000539 [-0.001314, +0.000203]; n=72, clusters=18 |
| All three | +0.79 [-0.09, +1.77]; n=64, clusters=18 | -3.31 [-5.84, -0.94]; n=64, clusters=18 | -1.78 [-3.83, +0.37]; n=62, clusters=18 | -0.000665 [-0.001399, +0.000128]; n=72, clusters=18 |

Clinical return means actual offensive combat after a food/healing departure. Reassignment to a war flag alone does not count. Missing offensive or medical episodes are unavailable conditional measurements, not zeros. Provider use requires actual service entry; it does not quantify meals or healing delivered.

## Interactions

Pairwise interactions are differences-in-differences, averaged over the third control. A positive victory interaction means the combined effect exceeds the additive prediction; a negative time interaction means a larger reduction. These are screening estimates, subject to multiple comparisons. Each interaction requires every relevant cell in a matched scenario.

| Interaction | Win interaction, pp | Advantage conversion interaction, pp | Remaining time interaction, ticks |
|---|---|---|
| commitment x arrival | -0.69 [-4.86, +3.47]; n=72, clusters=18 | -2.17 [-18.42, +9.62]; n=23, clusters=11 | +901 [-700, +3091]; n=23, clusters=11 |
| commitment x forward | -3.47 [-9.03, +0.00]; n=72, clusters=18 | -10.87 [-28.95, +0.00]; n=23, clusters=11 | +269 [-5419, +6710]; n=23, clusters=11 |
| arrival x forward | -0.69 [-6.25, +4.17]; n=72, clusters=18 | +6.52 [+0.00, +17.65]; n=23, clusters=11 | -2672 [-6832, +527]; n=23, clusters=11 |
| commitment x arrival x forward | -4.17 [-11.11, +0.00]; n=72, clusters=18 | -13.04 [-32.14, +0.00]; n=23, clusters=11 | +5653 [-153, +12828]; n=23, clusters=11 |

## Does combining add anything beyond the strongest individual?

| Combination | Strongest constituent on this screen | Advantage conversion difference, pp | Remaining time difference, ticks |
|---|---|---|---|
| Arrival + forward | Forward services | +8.70 [+0.00, +23.53]; n=23, clusters=11 | -3034 [-7597, +411]; n=23, clusters=11 |
| Commitment + forward | Commitment | -8.70 [-22.22, +0.00]; n=23, clusters=11 | -753 [-8023, +6300]; n=23, clusters=11 |
| Commitment + arrival | Commitment | +0.00 [-15.00, +11.11]; n=23, clusters=11 | +538 [-310, +1831]; n=23, clusters=11 |
| All three | Commitment | -8.70 [-27.78, +7.69]; n=23, clusters=11 | -60 [-7723, +7561]; n=23, clusters=11 |

The strongest constituent was selected using these same screening results. These comparisons are exploratory. A combination that beats baseline does not necessarily improve upon its strongest ingredient.

## Selection and uncertainty

**No combination met the frozen screening gates. Defaults remain unchanged.**

| Combination | Failed screening gates |
|---|---|
| Forward services | advantage, no_overall_unresolved_increase, mechanism |
| Arrival grace | advantage, no_overall_loss_increase, no_generator_or_format_loss_increase_above_ten_pp |
| Arrival + forward | advantage, no_overall_loss_increase, no_generator_or_format_loss_increase_above_ten_pp |
| Commitment | advantage, no_overall_loss_increase, no_generator_or_format_loss_increase_above_ten_pp, mechanism |
| Commitment + forward | advantage, no_generator_or_format_loss_increase_above_ten_pp, mechanism |
| Commitment + arrival | advantage, no_overall_unresolved_increase |
| All three | advantage, no_overall_win_decline, no_overall_unresolved_increase |

The machine-readable report also contains simultaneous 95% centered cluster-bootstrap bands across the seven candidate-versus-baseline contrasts for overall victory, advantage conversion and capped remaining time. Pointwise intervals above are not familywise evidence. Zero-width intervals from all tied outcomes do not establish equivalence. No result was used to change parameters or stop the tournament.

## Terrain and format coverage

| Generator | Baseline | Forward services | Arrival grace | Arrival + forward | Commitment | Commitment + forward | Commitment + arrival | All three |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| amphitheatre | 0/2/10 | 0/2/10 | 0/4/8 | 0/4/8 | 0/3/9 | 0/3/9 | 0/3/9 | 0/3/9 |
| bastion-keys | 0/2/10 | 0/1/11 | 0/0/12 | 0/2/10 | 0/1/11 | 0/2/10 | 0/0/12 | 0/2/10 |
| hidden-oasis | 1/9/2 | 2/8/2 | 2/9/1 | 3/7/2 | 2/8/2 | 2/7/3 | 3/7/2 | 2/7/3 |
| maze | 0/3/9 | 0/2/10 | 0/3/9 | 0/3/9 | 0/2/10 | 0/1/11 | 0/3/9 | 0/3/9 |
| old-town | 6/4/2 | 5/5/2 | 5/4/3 | 5/5/2 | 5/5/2 | 4/5/3 | 6/4/2 | 4/5/3 |
| orchard-commons | 0/4/8 | 0/4/8 | 0/5/7 | 0/5/7 | 1/6/5 | 1/6/5 | 0/4/8 | 0/4/8 |

| Players | Baseline | Forward services | Arrival grace | Arrival + forward | Commitment | Commitment + forward | Commitment + arrival | All three |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 6 | 4/13/19 | 4/13/19 | 5/15/16 | 5/15/16 | 5/15/16 | 4/15/17 | 6/12/18 | 4/14/18 |
| 8 | 3/11/22 | 3/9/24 | 2/10/24 | 3/11/22 | 3/10/23 | 3/9/24 | 3/9/24 | 2/10/24 |

These FFA games pit Maxima against several opponents concurrently. They do not estimate a causal head-to-head effect against any one opponent. Small terrain strata are descriptive.

## Recurring mechanisms to audit

- Baseline: live-enemy switches per game=5.92; forward orders=0; observed provider identities=0; entered providers=0; actual recipients summed per game=0; mission finishes={'no_wave_target': 24, 'wave_emergency': 43, 'wave_failed': 30, 'colony_emergency': 31, 'no_target': 16, 'amphibious_handoff': 43, 'wave_handoff': 43}.
- Forward services: live-enemy switches per game=4.86; forward orders=135; observed provider identities=78; entered providers=72; actual recipients summed per game=903; mission finishes={'no_wave_target': 25, 'wave_emergency': 36, 'wave_failed': 26, 'no_target': 19, 'colony_emergency': 32, 'wave_handoff': 34, 'amphibious_handoff': 34}.
- Arrival grace: live-enemy switches per game=3.67; forward orders=0; observed provider identities=0; entered providers=0; actual recipients summed per game=0; mission finishes={'no_wave_target': 25, 'wave_emergency': 58, 'wave_failed': 23, 'no_target': 14, 'colony_emergency': 34, 'amphibious_handoff': 26, 'wave_handoff': 28}.
- Arrival + forward: live-enemy switches per game=3.31; forward orders=114; observed provider identities=68; entered providers=62; actual recipients summed per game=779; mission finishes={'no_wave_target': 29, 'wave_emergency': 31, 'wave_failed': 21, 'no_target': 20, 'colony_emergency': 21, 'amphibious_handoff': 27, 'wave_handoff': 28}.
- Commitment: live-enemy switches per game=2.19; forward orders=0; observed provider identities=0; entered providers=0; actual recipients summed per game=0; mission finishes={'no_wave_target': 21, 'wave_emergency': 50, 'wave_failed': 26, 'colony_emergency': 27, 'no_target': 17, 'amphibious_handoff': 34, 'wave_handoff': 35}.
- Commitment + forward: live-enemy switches per game=2.00; forward orders=124; observed provider identities=72; entered providers=68; actual recipients summed per game=904; mission finishes={'no_wave_target': 24, 'wave_emergency': 49, 'wave_failed': 23, 'colony_emergency': 31, 'no_target': 18, 'wave_handoff': 31, 'amphibious_handoff': 31}.
- Commitment + arrival: live-enemy switches per game=1.97; forward orders=0; observed provider identities=0; entered providers=0; actual recipients summed per game=0; mission finishes={'no_wave_target': 24, 'wave_emergency': 47, 'wave_failed': 27, 'colony_emergency': 36, 'no_target': 12, 'amphibious_handoff': 23, 'wave_handoff': 24}.
- All three: live-enemy switches per game=1.71; forward orders=126; observed provider identities=68; entered providers=61; actual recipients summed per game=859; mission finishes={'no_wave_target': 26, 'wave_emergency': 51, 'wave_failed': 22, 'colony_emergency': 20, 'no_target': 11, 'wave_handoff': 29, 'amphibious_handoff': 27}.

Lifecycle and seed-level diagnostics are supporting evidence. Causal claims about a specific battle require replay inspection; the statistical conclusions above use all planned matches.

## Reproduction and boundaries

- Frozen protocol: [design](factorial-v1-design.json), [configurations](factorial-v1-configs.json), [confirmation rule](factorial-v1-confirmation-rule.json).
- Inputs and results: [complete manifest](factorial-v1-complete-manifest.json), [analysis](factorial-v1-analysis.json), [campaign log](factorial-v1-campaign.log).
- Analysis checks: [synthetic contrast and endpoint tests](factorial-v1-analysis-tests.log).
- Experimental executable is the frozen save187/SIM99 research bundle; current shipping changes remain telemetry-only, save186/SIM98. This tournament does not imply the experimental policies are present in current source.
- Linux x86_64 release execution only. Cross-platform checksum comparisons and maintainer playthrough are not established by this campaign. See the earlier [verification](FINAL-VERIFICATION.json) for retained telemetry checks and existing fixture failures.


Execution began at 12 concurrent games. At 258 completed games, the user requested 8. The new coordinator adopted every in-flight simulation in place, allowed the count to fall to 8 and continued at 8; no match was restarted or discarded during this handoff. Any confirmation also uses 8. See [operational amendment](factorial-v1-concurrency8-operational-amendment.json), [handoff](factorial-v1-concurrency8-handoff.json) and [eight-game coordinator log](factorial-v1-campaign-concurrency8.log). Simulation threads, GPU setting, executable, strategy parameters, maps, seeds and analysis criteria stayed unchanged.

## Construction, recalls and delivery observations

| Arm | Forward offers / issuing games | Completed / issued | Destroyed during construction: sites / games / clusters | Colony-alarm mission finishes: events / games / clusters | Permanent streaming fallback: games / clusters |
|---|---|---|---|---|---|
| c0a0f0 | 0 / 0 | 0 / 0 | 0 / 0 / 0 | 74 / 34 / 16 | 31 / 15 |
| c0a0f1 | 56 / 32 | 78 / 135 | 28 / 11 / 9 | 68 / 35 / 15 | 27 / 13 |
| c0a1f0 | 0 / 0 | 0 / 0 | 0 / 0 / 0 | 92 / 34 / 15 | 24 / 12 |
| c0a1f1 | 57 / 30 | 66 / 114 | 18 / 9 / 7 | 52 / 28 / 14 | 21 / 12 |
| c1a0f0 | 0 / 0 | 0 / 0 | 0 / 0 / 0 | 77 / 32 / 14 | 27 / 11 |
| c1a0f1 | 57 / 28 | 72 / 124 | 17 / 8 / 6 | 80 / 30 / 14 | 25 / 10 |
| c1a1f0 | 0 / 0 | 0 / 0 | 0 / 0 / 0 | 83 / 31 / 15 | 28 / 12 |
| c1a1f1 | 57 / 27 | 67 / 126 | 23 / 9 / 7 | 71 / 28 / 13 | 22 / 12 |

Events repeat within games; these counts are descriptive. A recorded colony alarm does not prove a recall was correct or incorrect. Construction destruction does not identify the attacker or prove that site caused an outcome. Pending lifecycle states remain censored. See [full lifecycle audit](factorial-v1-lifecycle-audit.json).

## Additional correctness and execution evidence

All four newly combined policies passed identical-input 2,000-tick checksum repeats and 1,000-tick save/reload suffix comparisons on Linux x86_64. See [continuation proof](factorial-v1-continuation/proof.json). Runtime logs verified all 8 initial arm settings and all 4 loaded combination settings: [parameter audit](factorial-v1-runtime-parameter-audit.json).

The original coordinator stopped after 123 collected games. Those results were retained. Twelve partial attempts were archived and restarted from their exact original map/seat/RNG/configuration inputs, with no strategy or endpoint changes. Every fully persisted warrior-window record matched the retry prefix; this is sampled-timeline evidence, not a full per-tick checksum claim. See [resumption audit](factorial-v1-resume1-audit.json), [prefix proof](factorial-v1-resume1-prefix-proof.json), and [resumed campaign log](factorial-v1-campaign-resume1.log). Partial attempts are excluded from all full-game counts and statistics.

[Results chart](factorial-v1-results.png) · [Vector chart](factorial-v1-results.pdf)


## Interpretation and recurring failure chains

**Decision: none of these combinations earns promotion.** Commitment plus arrival grace is the most useful diagnostic lead: offensive fighting rises from 8.21% to 9.45% of offense-attached warrior time, with the same direction on all six generators, and live-enemy switches fall from 5.92 to 1.97 per game. However, only one additional baseline-advantage case ends in victory (8/23 versus 7/23), its capped remaining time rises by 1,432 ticks, and own unresolved games rise from 41 to 42. Its advantage-conversion interval includes zero. These results identify a mechanism worth understanding, rather than a validated improvement in finishing games.

The full combination lowers offensive transit from 69.03% to 65.72%, yet wins only 6/23 advantage cases and 6/72 overall, versus 7/23 and 7/72 for baseline. Reducing a travel measure is therefore insufficient as the optimization objective. Changes must also increase sustained useful damage and completed enemy eliminations. Losses, unresolved games and conditional measurement availability remain separate in the tables above.

The following five-whys chains distinguish observed repeated behavior from explanations supported by code, and from hypotheses still needing intervention tests. Seed examples are retrieval anchors, selected in sorted order across generators; they do not replace the complete matched statistics.

### 1. Fewer enemy changes still do not finish the campaign

1. Why are dominant armies not reliably finishing? Baseline converts only 7/23 proxy-advantage cases; commitment plus arrival converts 8/23 with no measured reduction in capped finishing time.
2. Why was commitment insufficient? It removes many switches, but does not force the army to deliver more sustained building damage: damage per warrior-tick changes by -0.000539, with a pointwise interval spanning zero.
3. Why can it still switch? The soft bonus competes with refreshed objective scores. The audit records 120 switches within active missions and 22 after mission resets in the commitment-plus-arrival arm.
4. Why do recalls also matter? Ending offense destroys flags and resets the tactical mission; prototype commitment applies only while that mission exists. Reset-associated switches occur in 17 games across 12 terrain clusters, but remain a minority of the 142 switches. Persistent intent alone cannot explain or repair the majority.
5. What is the actionable hypothesis? Evaluate continuity using actual damage, feasible reinforcement routes and target progress, while preserving emergency defense. Neither stronger commitment nor remembering an enemy across recalls is established as beneficial by these tests. Earlier hard commitment also had adverse results in its separate campaign.

Retrieval anchors for remaining within-mission switches: Amphitheatre 540001/r0/RNG2026102601; Bastion Keys 540002/r0/RNG2026102601; Hidden Oasis 540001/r0/RNG2026102601, all in c1a1f0. The complete classified switch list is in the lifecycle audit.

### 2. Giving arrivals longer to assemble improves arrival metrics but can reduce useful siege output

1. Why test grace? Armies can be recalled before enough healthy attackers reach the objective.
2. What changed repeatedly? Grace alone raises geometric arrival from 38.44% to 42.53%, in the same direction on all six generators.
3. Why is that not enough? Its building damage per warrior-tick falls from 0.006678 to 0.005836, a 12.6% decline; every generator's point estimate has the same direction. The aggregate pointwise interval for the difference is [-0.001415, -0.000310]. This is a secondary screening finding, not multiplicity-adjusted causal proof of a specific battle mechanism.
4. Why might waiting fail to become damage? The condition uses elapsed time and healthy proximity to the objective. Proximity does not establish that attackers have acquired a building, can sustain contact, or can defeat local defenders. Medical interruption and home emergencies still interrupt campaigns; baseline colony-alarm mission finishes occur in 34 games across 16 terrain clusters. Their correctness must be evaluated locally rather than inferred from global army size.
5. What should replace a blanket longer timer? A future intervention should distinguish travel, assembling, active damage and interrupted recovery, and test progress-aware continuation. These results weaken the tested blanket grace setting; they do not establish that every early retreat is justified or that all arrival-aware policies fail.

The arrival-only damage decline spans Amphitheatre, Bastion Keys, Hidden Oasis, Maze, Old Town and Orchard Commons, across the complete matched design. It is not selected from one failed siege.

### 3. Forward buildings are used, but do not yet form an effective recovery loop

1. Why build forward support? Warriors spend substantial time travelling for food or healing; proximity might shorten that interruption.
2. Did buildings actually serve soldiers? In the forward-only arm, 135 orders yield 78 provider identities and 72 entered providers, serving 903 distinct recipients summed per game. Those are actual entries, not assignment-only counts; recipients are not unique across the campaign.
3. Why not treat that as success? Actual clinical-departure-to-offensive-combat return changes by only -0.15 percentage points, interval [-1.40,+1.01]. Advantage conversion is 6/23 versus 7/23. Entries do not quantify meals, healing, or a completed round trip back into combat.
4. Where does the delivery chain break? Twenty-eight sites are destroyed during construction in 11 games across nine terrain clusters; another 25 orders reach CreateTimedOut and four remain SiteObserved. A timeout is a planner lifecycle observation, not proof that an enemy destroyed a building. The completed service endpoint also lacks a demonstrated combat-return improvement.
5. What is the bounded next hypothesis? Test a protected, reachable support corridor and cohort return-to-contact, rather than issuing more nearby service buildings. Construction survival, service availability and the return route need separate endpoints. This campaign does not determine which one dominates, and does not prove construction loss caused a particular defeat.

Construction-destruction anchors in c0a0f1: Amphitheatre 540001/r3/RNG2026102601 (five sites), Maze 540001/r0/RNG2026102602 (two), Old Town 540002/r0/RNG2026102601 (five). Full events and censored states are retained. Provider identities are observer registrations; lifecycle Completed events are a separate observation and differ by two sites in c0a1f1 and one in c1a1f1. Neither discrepancy changes actual-entry or primary outcome measurements.

Forward-only alarm arithmetic identifies three mission finishes in two games/two terrain clusters where forward-area threats supply the recorded threshold crossing while other recorded triggers are false. That is a snapshot dependency, not a simulated no-outpost counterfactual. It is insufficient to conclude that forward support generally causes false recalls or to weaken home defense.

### 4. Delivery failures can leave later campaigns in streaming mode

Baseline reaches permanent wave fallback in 31/72 games across 15/18 terrain clusters. This is a reproducible diagnostic pattern. The code increments failed-wave delivery when arrivals are below one third of launched units, and after four failures falls back to streaming. The existing counter prevents subsequent wave execution. A later change in routes, force mobility or support does not itself restore wave behavior. This explains why poor earlier delivery can constrain later delivery even after circumstances improve; it does not establish that streaming is worse in those later circumstances. A bounded retry after a documented condition change remains an untested intervention in this factorial, not a result to promote.

## Current-master and delivery boundary

The completed campaign uses the frozen research bundle based on 2c66ea850c92a526eba96ae8d04ef32d20fc6aa1. On final inspection, fetched master is ddfa81a40 and includes 5c691899d, which demolishes inaccessible Maxima buildings and refreshes the two previously failing checksum fixtures. That changes simulation behavior and potentially service availability. The campaign remains evidence for the frozen version; it does not measure these candidates on current master. Do not pool future matches on the new behavior with this campaign. The research bundle's SIM99 label also must not be confused with current master's independently advanced SIM99. Exact source and bundle identities disambiguate them.

Shipping changes remain telemetry-only in the isolated worktree; the base checkout is clean. A patch-application check on current master is recorded separately. Native integration validation against the newer building-management behavior remains outstanding before delivering a current-master code change. Historical checksum-fixture failures should not be described as current-master failures. Other operating systems, architectures and a maintainer play-through remain outside this evidence.

## Subsequent user-directed work

After reviewing these results, the user explicitly asked to tune forward placement and pursue marginal gains. The completed screen and its original gate decisions remain unchanged. Those gates do not block the newly authorized follow-up: an independent 144-game replication of commitment plus arrival is running on fresh 560001..560003 terrain seeds with the exact frozen v8 bundle. Small positive effects will be reported with their uncertainty rather than discarded for missing a five-percentage-point threshold.

A separate current-master placement study will compare geometric rings against a reachable friendly supply corridor at distances 12, 24 and 40. Its protocol is [forward-placement-v2-plan.json](forward-placement-v2-plan.json). It keeps ordinary home criteria intact, distinguishes tuning from fresh confirmation, and caps total concurrent games at eight. No placement benefit has yet been measured for the new implementation. Current source in the isolated worktree is now an experimental branch based on ddfa81a40, not the former telemetry-only delivery candidate; that earlier source remains snapshotted and stashed.
