# Integrated win probability: placement-tuning

Existing published model; no refit. Fixed5120..120000tick integral, normalized to mean probability; actual wins/losses absorb1/0 after resolution. All repeats must match original checksums, outcomes and full warrior CSVs. Repeats do not increase sample size. This is a user-requested post-hoc endpoint; original selection rules and in-flight arms were preserved.

|Arm|Games|W/L/U|Mean integrated probability|Change vs baseline, pp [95% interval]|
|---|---:|---:|---:|---:|
|baseline|24|2/9/13|34.675%|reference|
|commitment-arrival|24|1/8/15|33.665%|-1.011 [-7.955, +6.199]|
|corridor-12|24|2/9/13|30.786%|-3.890 [-9.896, +2.400]|
|corridor-24|24|2/8/14|33.570%|-1.105 [-8.614, +6.462]|
|corridor-40|24|2/8/14|32.713%|-1.962 [-9.111, +5.176]|
|ring-12|24|2/9/13|31.393%|-3.282 [-9.009, +2.719]|
|ring-24|24|2/8/14|32.988%|-1.687 [-8.609, +5.580]|
|ring-40|24|3/7/14|35.254%|+0.578 [-6.790, +7.850]|

Pointwise intervals bootstrap whole generator/map-seed clusters; simultaneous primary bands, late-game and same-baseline-advantage integrals are in JSON. All games are equally weighted; time samples are not independent trials. Do not pool campaigns or source bases.

This score measures a lead sustained over time. It can reward a high-probability stalemate; it does not establish conversion speed, model calibration on these new maps, or a realized win-rate increase. Actual victories, unresolved games and the existing damage/contact diagnostics remain necessary. Original model validation used a mixed-format earlier campaign; it is not a new validation on these large FFAs.

All source data, command identities, 512-tick model curves and exact-repeat proofs are under the per-run recovery directories.

[Probability curves and paired effects](placement-tuning-integrated-probability.png) · [Vector chart](placement-tuning-integrated-probability.pdf)

All six forward-placement arms also enable commitment plus arrival grace. Ring distance is geometric standoff; corridor distance follows a discovered walking/supply route. These are tuning results from24matched games per arm across12generator/map-seed clusters, not a new independent confirmation.

|Arm|Wins /24|Mean integrated probability|Mean end-horizon probability|
|---|---:|---:|---:|
|baseline|2|34.68%|42.92%|
|commitment-arrival|1|33.66%|40.70%|
|ring-12|2|31.39%|37.87%|
|ring-24|2|32.99%|41.90%|
|ring-40|3|35.25%|44.10%|
|corridor-12|2|30.79%|36.20%|
|corridor-24|2|33.57%|40.43%|
|corridor-40|2|32.71%|39.10%|

The probability integral averages the existing model fromtick5120to120000; early actual wins/losses absorb100%/0% for the remaining fixed horizon. It is not observed win rate. Its paired ring40-baseline interval is -6.79to+7.85pp around+0.58pp, versus -15.87to+16.39pp around+1.18pp for the final model snapshot. These are different estimands; the narrower integral interval does not prove a win-rate improvement. All primary simultaneous bands also contain zero.

Ring40 terrain point effects are positive only on HiddenOasis (+17.98pp); all five other generator means are negative. Exploratory leave-HiddenOasis-out sensitivity gives -2.90pp overall; that omission is diagnostic, not a preferred result. There are only two map seeds per generator, so individual generator effects are uncertain.

The economic end-ranking policy also gives different answers: tactical-only receives first-place credit45.83%of the time versus41.67%baseline, while actual wins fall2to1and integrated probability falls1.01pp. Economic top-place credit is not a natural victory. Full definitions and paired endpoint results are in placement-endpoint-comparison.json.

Interpretation: ring40remains a worthwhile marginal-gain candidate, but this screen does not show a broad improvement in keeping warriors fighting. Actual whole-army combat has no clear increase; ring40 offensive-transit point estimate is +0.82pp, and measured clinical return to combat is lower (an exploratory conditional endpoint). Positive model area alone is insufficient evidence of better victory conversion.
