# Tactical interpretation of integrated probability: placement-tuning

Complete matched campaign only. All differences are candidate minus baseline; pointwise95% intervals resample whole generator/map-seed clusters. The original model, scoring window and primary ranking are unchanged.

|Arm|Integrated probability, pp|Actual wins, pp|Whole-army combat, pp|Offensive transit, pp|Building damage /100000warrior ticks|
|---|---|---|---|---|---|
|commitment-arrival|-1.011 [-7.955, +6.199]; n=24|-4.167 [-12.500, +0.000]; n=24|-0.173 [-0.667, +0.225]; n=24|-1.046 [-4.453, +2.359]; n=21|+51.967 [-198.553, +270.180]; n=24|
|corridor-12|-3.890 [-9.896, +2.400]; n=24|+0.000 [+0.000, +0.000]; n=24|+0.046 [-0.589, +0.658]; n=24|-1.003 [-4.580, +2.462]; n=21|+9.406 [-249.659, +242.906]; n=24|
|corridor-24|-1.105 [-8.614, +6.462]; n=24|+0.000 [+0.000, +0.000]; n=24|-0.108 [-0.696, +0.483]; n=24|-0.166 [-4.851, +4.373]; n=21|+3.711 [-277.134, +279.062]; n=24|
|corridor-40|-1.962 [-9.111, +5.176]; n=24|+0.000 [+0.000, +0.000]; n=24|-0.202 [-0.742, +0.287]; n=24|+0.417 [-2.520, +3.381]; n=21|-23.165 [-261.765, +175.435]; n=24|
|ring-12|-3.282 [-9.009, +2.719]; n=24|+0.000 [+0.000, +0.000]; n=24|-0.028 [-0.603, +0.467]; n=24|-1.334 [-5.511, +2.476]; n=21|+23.326 [-236.826, +252.327]; n=24|
|ring-24|-1.687 [-8.609, +5.580]; n=24|+0.000 [+0.000, +0.000]; n=24|+0.021 [-0.650, +0.787]; n=24|-0.219 [-4.116, +3.434]; n=21|+80.108 [-227.812, +404.628]; n=24|
|ring-40|+0.578 [-6.790, +7.850]; n=24|+4.167 [+0.000, +12.500]; n=24|-0.054 [-0.690, +0.602]; n=24|+0.819 [-2.140, +3.877]; n=21|+34.278 [-247.019, +308.313]; n=24|

## Post-advantage and service evidence

|Arm|Probability after baseline advantage, pp|Advantage conversion, pp|Capped remaining ticks|Clinical return to combat, pp|
|---|---|---|---|---|
|commitment-arrival|-1.725 [-7.629, +1.453]; n=7|-14.286 [-50.000, +0.000]; n=7|+6294.571 [-864.000, +23039.000]; n=7|-4.399 [-9.360, +0.325]; n=21|
|corridor-12|-1.895 [-6.085, +1.349]; n=7|+0.000 [+0.000, +0.000]; n=7|+1910.857 [+0.000, +6421.333]; n=7|-3.512 [-8.176, +0.531]; n=21|
|corridor-24|+1.455 [-2.828, +9.811]; n=7|+0.000 [+0.000, +0.000]; n=7|+2724.571 [+0.000, +8928.000]; n=7|-4.000 [-8.569, -0.124]; n=21|
|corridor-40|-1.244 [-4.284, +1.514]; n=7|+0.000 [+0.000, +0.000]; n=7|+2395.429 [-864.000, +9392.000]; n=7|-3.659 [-8.376, +0.279]; n=21|
|ring-12|-1.880 [-6.038, +1.362]; n=7|+0.000 [+0.000, +0.000]; n=7|+1344.000 [+0.000, +4608.000]; n=7|-2.781 [-7.647, +1.462]; n=21|
|ring-24|-2.798 [-9.480, +1.354]; n=7|+0.000 [+0.000, +0.000]; n=7|+5673.143 [+0.000, +19514.667]; n=7|-3.095 [-7.825, +0.916]; n=21|
|ring-40|+6.327 [-2.467, +25.676]; n=7|+14.286 [+0.000, +50.000]; n=7|+1568.286 [-7614.400, +12973.200]; n=7|-4.548 [-9.053, -0.477]; n=21|

Availability differs for conditional metrics; missing exposure remains unavailable, not zero. Clinical return requires actual offensive combat after leaving food/healing service. Secondary intervals are exploratory and are not multiplicity-adjusted. Primary simultaneous bands remain in the main probability analysis.

Point-direction checks below highlight tradeoffs; they are not significance claims, causal explanations or automatic rejection gates. Small extra wins remain relevant. The model reads population, prestige, training capacity, explorers, starvation and attack share; geography and active enemy contact are not direct inputs.
- ring-40: Higher modeled progress with less whole-army combat time; probability alone does not establish better sustained fighting.

Do not infer that a high-probability stalemate is a finished campaign. Keep actual wins, unresolved rate, damage and combat availability visible alongside the smoother probability endpoint. Format-specific paired results and all denominator counts are in JSON. No campaigns or simulation source bases are pooled.
