# Integrated win probability: marginal-replication

Existing published model; no refit. Fixed5120..120000tick integral, normalized to mean probability; actual wins/losses absorb1/0 after resolution. All repeats must match original checksums, outcomes and full warrior CSVs. Repeats do not increase sample size. This is a user-requested post-hoc endpoint; original selection rules and in-flight arms were preserved.

|Arm|Games|W/L/U|Mean integrated probability|Change vs baseline, pp [95% interval]|
|---|---:|---:|---:|---:|
|baseline|72|3/30/39|29.990%|reference|
|finalist|72|3/27/42|27.981%|-2.010 [-6.208, +1.057]|

Pointwise intervals bootstrap whole generator/map-seed clusters; simultaneous primary bands, late-game and same-baseline-advantage integrals are in JSON. All games are equally weighted; time samples are not independent trials. Do not pool campaigns or source bases.

This score measures a lead sustained over time. It can reward a high-probability stalemate; it does not establish conversion speed, model calibration on these new maps, or a realized win-rate increase. Actual victories, unresolved games and the existing damage/contact diagnostics remain necessary. Original model validation used a mixed-format earlier campaign; it is not a new validation on these large FFAs.

All source data, command identities, 512-tick model curves and exact-repeat proofs are under the per-run recovery directories.

[Probability curves and paired effects](marginal-replication-integrated-probability.png) · [Vector chart](marginal-replication-integrated-probability.pdf)
