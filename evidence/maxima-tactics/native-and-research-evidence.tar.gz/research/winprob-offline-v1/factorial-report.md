# Factorial: saved-data probability approximation

No games were executed. Exact model inputs were extracted from original saved rings; gaps were linearly interpolated. This is an approximate secondary analysis, separate from the frozen dense endpoint. Intervals bootstrap map clusters and do not incorporate interpolation error.

|Arm|Games|W/L/U|Mean probability|Delta vs baseline, pp [95% cluster interval]|
|---|---:|---:|---:|---:|
|c0a0f0|72|7/24/41|33.074%|reference|
|c0a0f1|72|7/22/43|32.990%|-0.085 [-2.188, +1.988]|
|c0a1f0|72|7/25/40|32.437%|-0.637 [-4.270, +3.239]|
|c0a1f1|72|8/26/38|33.024%|-0.051 [-3.966, +4.081]|
|c1a0f0|72|8/25/39|32.297%|-0.778 [-3.579, +1.946]|
|c1a0f1|72|7/24/41|32.638%|-0.436 [-3.254, +2.846]|
|c1a1f0|72|9/21/42|33.817%|+0.743 [-2.980, +5.001]|
|c1a1f1|72|6/24/42|32.186%|-0.888 [-4.579, +2.920]|

C = same-enemy preference; A = 4000-tick arrival grace; F = older 24-tile forward services. This study does not test ring40. For empirical interpolation error on the complete192/144-game studies, see ../winprob-offline-audit/sparse-quadrature-audit.json. Tiny differences comparable with that error are unresolved.
