"""Read-only, research-save statistics extraction; never loads or advances a game.
Locate TeamStats by its exact full graph-history prefix from authoritative result.json,
then decode the saved 128-row detailed ring using the frozen source wire schema.
This is a bounded research extractor, not a general supported-save loader.
"""
import gzip,struct,json,hashlib
from pathlib import Path
u32=lambda v:struct.pack('>I',v&0xffffffff)
def varint(v):
 out=bytearray()
 while v>=128:out.append((v&127)|128);v>>=7
 out.append(v);return bytes(out)
def packed(values):
 assert 0<len(values)<=256
 v=[x&0xffffffff for x in values]
 if len(v)>1 and len(set(v))==1:mode,payload=1,u32(v[0])
 else:
  delta=bytearray(u32(v[0]));i=1
  while i<len(v):
   diff=(v[i]-v[i-1])&0xffffffff
   if diff==0:
    end=i+1
    while end<len(v) and v[end]==v[i-1]:end+=1
    delta+=b'\0'+varint(end-i);i=end
   else:delta+=varint(((diff<<1)^(-(diff>>31)))&0xffffffff);i+=1
  raw=b''.join(map(u32,v));mode,payload=(2,bytes(delta)) if len(delta)<len(raw) else (0,raw)
 return bytes([mode])+u32(len(payload))+payload
def history_bytes(history):
 out=bytearray(u32(len(history)))
 for start in range(0,len(history),256):
  rows=history[start:start+256]
  for col in range(6):out+=packed([row[col] for row in rows])
 return bytes(out)
class Reader:
 def __init__(self,b,p):self.b=b;self.p=p
 def ints(self,n):
  assert n>=0 and self.p+4*n<=len(self.b)
  a=list(struct.unpack_from('>'+str(n)+'i',self.b,self.p));self.p+=n*4;return a
 def one(self):return self.ints(1)[0]
 def vec(self,maximum=4096):
  n=self.one();assert 0<=n<=maximum
  return self.ints(n)
 def stat(self):
  d={};d['buildingCountByVariant']=self.vec()
  d['totalUnit']=self.one();d['numberUnitPerType']=self.vec(1024);types=len(d['numberUnitPerType']);assert types==3
  d['workersByConstructionLevel']=self.ints(4)
  d['totalFree']=self.one();d['isFree']=self.vec(1024)
  d['totalNeeded']=self.one();d['totalNeededPerLevel']=self.ints(4);d['totalBuilding']=self.one()
  d['numberBuildingPerType']=self.ints(13)
  d['numberBuildingPerTypePerLevel']=[self.ints(6) for _ in range(13)]
  for key in ['needFoodCritical','needFoodNoInns','needFood','needHeal','needNothing']:d[key]=self.one()
  d['upgradeState']=[self.ints(4) for _ in range(17)]
  n=self.one();assert n==types;d['upgradeStatePerType']=[[self.ints(4) for _ in range(17)] for _ in range(n)]
  for key in ['totalFood','totalFoodCapacity','totalUnitFoodable','totalUnitFooded','totalHP','totalAttackPower','totalDefensePower']:d[key]=self.one()
  d['happiness']=self.ints(4)
  for key in ['carriers','builders','meleeUnits','rangedUnits','scouts','idleCarriers','idleDefenders']:d[key]=self.one()
  assert d['totalUnit']==sum(d['numberUnitPerType']) and 0<=d['totalUnit']<=1024
  assert 0<=d['needFoodCritical']<=d['totalUnit'] and 0<=d['scouts']<=d['totalUnit']
  return d
def extract(save,result,tick):
 assert tick>=4096,'Pilot covers initialized full rings only'
 b=gzip.open(save,'rb').read();candidates=[]
 for team in result['teams']:
  count=max(0,(tick-1-result['resolved']['rules']['teamStatsDelay'])//512+1)
  history=team['history'][:count];assert len(history)==count,('Missing saved history',team['team'],tick,count,len(history))
  marker=history_bytes(history);offset=0;found=[]
  while True:
   offset=b.find(marker,offset)
   if offset<0:break
   try:
    r=Reader(b,offset+len(marker));index=r.one();smooth=r.one();assert 0<=index<128 and 0<=smooth<32
    rows=[r.stat() for _ in range(128)]
    found.append(dict(team=team['team'],offset=offset,index=index,smooth=smooth,rows=rows))
   except (AssertionError,struct.error):pass
   offset+=1
  candidates.append(found)
 # Strictly require unique team attribution for this pilot, no heuristic fallback.
 assert all(len(x)==1 for x in candidates),[[(z['offset'],z['team']) for z in x] for x in candidates]
 out=[x[0] for x in candidates];assert len({x['offset'] for x in out})==len(out)
 assert [x['offset'] for x in out]==sorted(x['offset'] for x in out),'Team block order mismatch'
 return out
if __name__=='__main__':
 import sys
 save=Path(sys.argv[1]);result=json.loads(Path(sys.argv[2]).read_text());tick=int(sys.argv[3]);out=extract(save,result,tick)
 checks=[]
 for t,x in zip(result['teams'],out):
  if tick==result['ticks']:
   actual=x['rows'][x['index']];expected=t['standard_statistics'];assert all(actual[k]==v for k,v in expected.items()),[k for k,v in expected.items() if actual[k]!=v]
   checks.append(dict(team=t['team'],all_result_stat_fields_match=True,fields=len(expected)))
 print(json.dumps(dict(save=str(save),tick=tick,teams=len(out),no_simulation=True,result_checks=checks,rings=[dict(team=x['team'],offset=x['offset'],index=x['index'],smooth=x['smooth'],latest=x['rows'][x['index']]) for x in out]),indent=2))
