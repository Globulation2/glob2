"""Prespecified sparse quadrature error audit on existing complete curves only.
Compare both linear and carry-forward approximations; do not change primary results.
"""
from pathlib import Path
import json,bisect,sys,collections,numpy as np
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R));from winprob_integral_v1 import area
START=5120;END=120000

def retained_ticks(curve,finish,delay=8,history_limit=120000):
 saves=sorted(set([t for t in range(15000,finish+1,15000)]+[finish]))
 return [t for t,p in curve if t==0 or (t<=history_limit and any(0<=((s-delay)//32-(t-delay+1)//32)<128 and t<s for s in saves))]
def integrate(points,start,end,terminal=None,value=None,linear=True):
 points=sorted(points);ts=[t for t,p in points];knots=sorted({start,end,*[t for t in ts if start<t<end],*[t for t in [terminal] if t is not None and start<t<end]})
 def pred(t):
  if terminal is not None and t>=terminal:return value
  j=bisect.bisect_right(ts,t)-1;assert j>=0
  if not linear or j==len(points)-1:return points[j][1]
  a,x=points[j];b,y=points[j+1];return x+(y-x)*(t-a)/(b-a)
 total=0
 for a,b in zip(knots,knots[1:]):
  if terminal is not None and a>=terminal:p=value;q=value
  elif linear:p=pred(a);q=pred(b) if terminal is None or b<terminal else pred(b-1e-7)
  else:p=pred(a);q=p
  total+=(b-a)*(p+q)/2
 return total/(1000*(end-start))

def main():
 report={}
 for campaign in ['placement-tuning','marginal-replication','factorial']:
  src=R/'winprob-integral-v2'/f'{campaign}-analysis.json'
  if not src.exists():continue
  rows=json.loads(src.read_text())['games'];comparisons=[]
  for row in rows:
   original=json.loads((R/row['original_directory']/'result.json').read_text());finish=original['ticks'];team=original['teams'][0];outcome=team['outcome'];terminal=None;value=None
   if outcome=='won':terminal=finish;value=1000
   elif outcome=='lost':terminal=team['eliminated_tick'] if team['eliminated_tick']>=0 else finish;value=0
   keep=set(retained_ticks(row['curve'],finish,original['resolved']['rules']['teamStatsDelay'],(min(len(t['history']) for t in original['teams'])-1)*512));points=[(t,p) for t,p in row['curve'] if t in keep];assert points
   exact=area(row['curve'],START,END,terminal,value)/(1000*(END-START));assert abs(exact-row['integrated_win_probability'])<1e-12
   c={k:row[k] for k in ['id','arm','pair','cluster']};c.update(dense=exact,retained_points=len(points),dense_points=len(row['curve']),linear=integrate(points,START,END,terminal,value),carry_forward=integrate(points,START,END,terminal,value,False));comparisons.append(c)
  byarm={};by_pair=collections.defaultdict(dict)
  for row in comparisons:by_pair[row['pair']][row['arm']]=row
  baseline='c0a0f0' if campaign=='factorial' else 'baseline'
  for arm in sorted({x['arm'] for x in comparisons}):
   subset=[x for x in comparisons if x['arm']==arm];v={};dense=np.mean([x['dense'] for x in subset])
   for method in ['linear','carry_forward']:
    errors=np.array([x[method]-x['dense'] for x in subset]);pairs=[(p[arm][method]-p[baseline][method])-(p[arm]['dense']-p[baseline]['dense']) for p in by_pair.values()]
    v[method]=dict(mean_probability=float(np.mean([x[method] for x in subset])),mean_game_error_pp=float(100*errors.mean()),mean_abs_game_error_pp=float(100*np.abs(errors).mean()),p95_abs_game_error_pp=float(100*np.quantile(np.abs(errors),.95)),paired_effect_error_pp=float(100*np.mean(pairs)))
   byarm[arm]=dict(games=len(subset),dense_mean_probability=float(dense),approximations=v)
  report[campaign]=dict(games=len(comparisons),arms=byarm,rankings={m:sorted(byarm,key=lambda a:-(byarm[a]['dense_mean_probability'] if m=='dense' else byarm[a]['approximations'][m]['mean_probability'])) for m in ['dense','linear','carry_forward']})
  (R/'winprob-offline-audit'/f'{campaign}-sparse-error-rows.json').write_text(json.dumps(comparisons,indent=2)+'\n')
 (R/'winprob-offline-audit/sparse-quadrature-audit.json').write_text(json.dumps(dict(no_simulations=True,description=__doc__,primary_endpoint_unchanged=True,campaigns=report),indent=2)+'\n')
 for campaign,d in report.items():
  print(campaign,'games',d['games'],'rankings',d['rankings'])
  for arm,x in d['arms'].items():
   print(arm,'dense',round(x['dense_mean_probability']*100,3),{m:{k:round(v,3) for k,v in z.items() if k.endswith('_pp')} for m,z in x['approximations'].items()})
if __name__=='__main__':main()
