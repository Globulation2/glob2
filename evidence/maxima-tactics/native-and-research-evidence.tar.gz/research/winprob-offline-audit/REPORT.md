# Reusing saved data for integrated win probability

Full-match rescoring has stopped. The published six-feature model and the existing exact 192-game placement and 144-game replication results are unchanged.

Original custom commands captured Maxima decisions and warrior activity but omitted `--telemetry team-timeline`. Those text logs lack every competitor's full periodic model inputs. Each saved checkpoint retains 128 recent detailed statistics rows, covering roughly 4,096 ticks; checkpoints are 15,000 ticks apart. The long graph history omits several model inputs. General gameplay critical hunger is not interchangeable with the model's needFoodCritical count.

The read-only extractor locates TeamStats by exact packed graph-history prefixes and reads the detailed rings directly. Final rows are checked against all original result statistics. Statistics publication delay is honored, including matches ending before their last scheduled sample was published. No game is loaded, advanced or replayed. Missing portions of probability curves are explicitly interpolated.

Correctness proof: 20 matches, every placement arm and terrain, both research source versions; 7,146 team samples; zero discrepancies in the six model inputs, alive status and fixed-point output. A full-length pilot recovered 64 of 235 timestamps from eight saves in about two seconds. This verifies extraction, not strategy efficacy.

Numerical audit across 336 already dense matches: linear interpolation's mean absolute per-game integration error was 0.590 percentage points; its 95th percentile absolute error was 1.825 points. Observed treatment-effect shifts were about 0.3 points or less. Ring40 remains the highest placement mean: +0.324 points estimated versus +0.578 exact. Some near-tied middle arms change order. Replication still favors baseline over commitment plus arrival grace. Linear interpolation was selected for approximation accuracy, not favorable strategy outcomes.

These errors matter for tiny improvements. Whole-cluster confidence intervals in the offline factorial report do not incorporate interpolation error. They cannot establish exact sub-percentage-point differences. Interpolated timestamps are not independent observations.

The remaining 576-game factorial is being scored from original saves under ../winprob-offline-v1/. Its forward-service switch used the older 24-tile policy, not ring40. This adds no independent games and does not block the accepted promotion. Future new tournaments must capture team-timeline from the beginning so compact GLOB2_WINPROB inputs and probabilities are retained.

Evidence: [extraction proof](multiple-source-extraction-proof.json), [numerical audit](sparse-quadrature-audit.json), [offline factorial method](../winprob-offline-v1/manifest.json). Failed prototype attempts are preserved alongside the scripts.
