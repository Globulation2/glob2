"""Approximate factorial integrals from original saves, with no game execution.
Exact retained inputs; linear interpolation only across missing probability times.
Numerical method selected by prediction error on already dense completed blocks,
never by which policy looks better. Keep dense reports unchanged.
"""
from pathlib import Path
import json,sys,concurrent.futures,time,traceback,bisect,hashlib
import numpy as np
from read_saved_stats import extract
from check_dense_overlap import slots_at
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R));from winprob_integral_v1 import published_model,W,metrics
import winprob_integral_statistics_v2 as stats
OUT=R/'winprob-offline-v1';OUT.mkdir(exist_ok=True)
MODEL=published_model()
ORIGINAL_ANALYSIS=json.loads((R/'factorial-v1-analysis.json').read_text())
ONSETS={x['pair']:x['combined_advantage_start'] for x in ORIGINAL_ANALYSIS['games'] if x['arm']=='c0a0f0'}
def score(run):
 dest=OUT/run['id'];dest.mkdir(exist_ok=True);path=dest/'score.json'
 if path.exists():return json.loads(path.read_text())
 root=R/run['directory'];result=json.loads((root/'result.json').read_text());end=result['ticks'];assert result['resolved']['save_version']==187
 assert all(t['history'][0]==[0]*6 for t in result['teams']),'Unverified nonzero initial state'
 # Zero initial cached statistics, observed at tick zero in every dense reference.
 points={0:1000//len(result['teams'])};checks=[]
 saves={tick:root/f'checkpoint-{tick}.game.gz' for tick in range(15000,end+1,15000)};saves[end]=root/'final.game.gz'
 for saved_tick,save in sorted(saves.items()):
  rings=extract(save,result,saved_tick);count=0
  for tick in range(max(512,(saved_tick-4096)//512*512),min(saved_tick,end//512*512+1),512):
   delay=result['resolved']['rules']['teamStatsDelay'];offset=(saved_tick-delay)//32-(tick-delay+1)//32
   if not 0<=offset<128 or any(tick//512>=len(t['history']) for t in result['teams']):continue
   slots=slots_at(rings,result,saved_tick,tick);prob=W.fixed_permille(MODEL,slots)[0]
   if tick in points:assert points[tick]==prob,'Overlapping checkpoints disagree'
   points[tick]=prob;count+=1
  if saved_tick==end:
   for team,ring in zip(result['teams'],rings):
    actual=ring['rows'][ring['index']];assert all(actual[k]==v for k,v in team['standard_statistics'].items()),'Final cached statistics differ from original result'
  checks.append(dict(save=save.name,samples=count))
 times=sorted(points);assert 0<=end//512*512-times[-1]<=512,'Unexpected terminal history gap'
 curve=[(tick,float(np.interp(tick,times,[points[t] for t in times]))) for tick in range(0,end//512*512+1,512)]
 old=R/'winprob-integral-v2/factorial'/run['id']/'score.json';dense_check=None
 if old.exists():
  reference=dict(json.loads(old.read_text())['curve']);assert all(reference[t]==p for t,p in points.items()),'Recovered input/probability differs from existing exact replay'
  dense_check=dict(exact_retained_probabilities_match=True,points=len(points))
 
 row={k:run[k] for k in ['id','pair','arm','cluster','generator','map_seed','rotation','game_seed']};row.update(metrics(curve,result,ONSETS[run['pair']]),original_directory=run['directory'],original_result_sha256=hashlib.sha256((root/'result.json').read_bytes()).hexdigest(),curve=curve,exact_points=sorted(points.items()),estimated=True,no_simulation=True,checkpoint_proof=checks,existing_dense_check=dense_check)
 path.write_text(json.dumps(row,indent=2)+'\n');return row

def main():
 runs=json.loads((R/'factorial-v1-complete-manifest.json').read_text())['runs'];start=time.monotonic()
 manifest=dict(method='Unchanged published fixed-point model at exact saved-ring points; linear probability interpolation across missing periods; original win/loss absorbing tails.',games=len(runs),no_game_execution=True,no_new_independent_games=True,source='Original frozen research 187 saves only; not published format187',offline_workers=4,initial_zero_statistics_checked_against_dense_references=True,primary_dense_reports_unchanged=True,numerical_error_reference='winprob-offline-audit/sparse-quadrature-audit.json')
 (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 rows=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  for row in pool.map(score,runs):
   rows.append(row)
   if len(rows)%24==0:print('OFFLINE_SCORED',len(rows),'/',len(runs),flush=True)
 arms={}
 for a in sorted({r['arm'] for r in rows}):
  subset=[r for r in rows if r['arm']==a];arms[a]=dict(games=len(subset),mean_integrated_probability=float(np.mean([r['integrated_win_probability'] for r in subset])),wins=sum(r['win'] for r in subset),losses=sum(r['loss'] for r in subset),unresolved=sum(r['unresolved'] for r in subset))
 comparisons=stats.comparisons(rows,'c0a0f0');report=dict(approximation=True,no_simulations=True,games=len(rows),arms=arms,versus_baseline=comparisons,elapsed_seconds=time.monotonic()-start)
 (OUT/'factorial-analysis.json').write_text(json.dumps(dict(report=report,games=rows),indent=2)+'\n')
 lines=['# Factorial: saved-data probability approximation','','No games were executed. Exact model inputs were extracted from original saved rings; gaps were linearly interpolated. This is an approximate secondary analysis, separate from the frozen dense endpoint. Intervals bootstrap map clusters and do not incorporate interpolation error.','','|Arm|Games|W/L/U|Mean probability|Delta vs baseline, pp [95% cluster interval]|','|---|---:|---:|---:|---:|']
 for a,s in arms.items():
  effect='reference'
  if a!='c0a0f0':
   c=comparisons[a]['integrated_win_probability'];effect=f"{100*c['estimate']:+.3f} [{100*c['ci95'][0]:+.3f}, {100*c['ci95'][1]:+.3f}]"
  lines.append(f"|{a}|{s['games']}|{s['wins']}/{s['losses']}/{s['unresolved']}|{s['mean_integrated_probability']:.3%}|{effect}|")
 lines+=['','C = same-enemy preference; A = 4000-tick arrival grace; F = older 24-tile forward services. This study does not test ring40. For empirical interpolation error on the complete192/144-game studies, see ../winprob-offline-audit/sparse-quadrature-audit.json. Tiny differences comparable with that error are unresolved.']
 (OUT/'factorial-report.md').write_text('\n'.join(lines)+'\n');print('ALL576_OFFLINE_SCORED_WITHOUT_SIMULATION',flush=True)
if __name__=='__main__':
 try:main()
 except BaseException as e:(OUT/'failure.json').write_text(json.dumps(dict(error=str(e),traceback=traceback.format_exc()),indent=2)+'\n');raise
