"""Fixed-model probability-curve recovery and integration; offline research only."""
from pathlib import Path
from collections import defaultdict
import bisect,gzip,hashlib,json,re,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]))
from tools import win_probability_model as W

def published_model():
 text=(ROOT.parents[1]/'src/team/stats/WinProbabilityModel.h').read_text()
 model={'intercept':float(re.search(r'WIN_PROBABILITY_INTERCEPT = ([-\d.e+]+);',text)[1]),'features':[]}
 assert W.to_fixed(model['intercept'])==int(re.search(r'WIN_PROBABILITY_INTERCEPT_FIXED = (-?\d+)LL;',text)[1])
 for name,transform in W.FINAL_FEATURES:
  constant=f'WIN_PROBABILITY_{name.upper()}_{transform.upper()}'
  value=float(re.search(constant+r' = ([-\d.e+]+);',text)[1])
  assert W.to_fixed(value)==int(re.search(constant+r'_FIXED = (-?\d+)LL;',text)[1])
  model['features'].append(dict(name=name,transform=transform,coefficient=value))
 return model

def trace(path,teams):
 samples=defaultdict(dict);model=published_model()
 opener=gzip.open if path.suffix=='.gz' else open
 with opener(path,'rt') as f:
  for line in f:
   if not line.startswith('GLOB2_WINPROB '):continue
   v={k:int(x) for k,x in (s.split('=',1) for s in line.split()[1:])};t=v['tick'];a=v['alliance']
   assert a not in samples[t],('Duplicate probability slot',t,a)
   samples[t][a]=v
 assert samples,'No model trace'
 output=[]
 for tick,values in sorted(samples.items()):
  assert set(values)==set(range(teams)),('Incomplete FFA slots',tick)
  slots=[dict(units=v['units'],prestige=v['prestige'],barracks=v['barracks'],explorers=v['explorers'],food_critical=v['foodCritical'],attack=v['attack'],alive=bool(v['alive'])) for a in range(teams) for v in [values[a]]]
  expected=W.fixed_permille(model,slots);observed=[values[a]['permille'] for a in range(teams)]
  assert expected==observed,('Published model/engine mismatch',tick,expected,observed)
  assert tick%512==0
  output.append((tick,observed[0]))
 ticks=[t for t,p in output]
 assert ticks==list(range(ticks[0],ticks[-1]+1,512)),'Missing periodic samples'
 return output

def area(samples,start,end,terminal_tick=None,terminal_permille=None):
 """Exact integer permille*ticks over a fixed horizon, with absorbing outcomes."""
 assert start<end
 times=[t for t,p in samples]
 assert times==sorted(set(times))
 assert all(0<=p<=1000 for t,p in samples)
 if terminal_tick is not None:assert terminal_permille in [0,1000]
 if terminal_tick is not None and terminal_tick<=start:return (end-start)*terminal_permille
 index=bisect.bisect_right(times,start)-1
 assert index>=0,'No probability at integration start'
 points={start,end}
 points.update(t for t,p in samples if start<t<end)
 if terminal_tick is not None and start<terminal_tick<end:points.add(terminal_tick)
 points=sorted(points);total=0
 for a,b in zip(points,points[1:]):
  if terminal_tick is not None and a>=terminal_tick:p=terminal_permille
  else:p=samples[bisect.bisect_right(times,a)-1][1]
  total+=(b-a)*p
 return total

def metrics(samples,result,onset=None):
 end=result['ticks'];own=next(t for t in result['teams'] if t['team']==0);outcome=own['outcome'];terminal=None;value=None
 assert samples[-1][0]==end//512*512,('Incomplete probability coverage',samples[-1][0],end)
 if outcome=='won':terminal=end;value=1000
 elif outcome=='lost':terminal=own['eliminated_tick'] if own['eliminated_tick']>=0 else end;value=0
 else:assert outcome=='unresolved' and end==120000,'Early unresolved game'
 score=lambda start:area(samples,start,120000,terminal,value)/(1000*(120000-start))
 primary=score(5120)
 return dict(integrated_win_probability=primary,probability_tick_area=primary*(120000-5120),late_integrated_win_probability=score(60000),advantage_integrated_win_probability=score(max(5120,onset)) if onset is not None else None,terminal_probability=value/1000 if terminal is not None and terminal<=120000 else samples[-1][1]/1000,win=int(outcome=='won'),loss=int(outcome=='lost'),unresolved=int(outcome=='unresolved'),samples=len(samples),outcome=outcome)
