from pathlib import Path
import subprocess,json,os,hashlib,sys,traceback,platform,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent;BUILD=Path('build/linux/client/release/client-full-direct-1111')
def run(name,command,env):
 path=P/name;assert not path.exists(),'Keep previous attempts'
 print('START',name,flush=True)
 with path.open('w') as f:subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('PASS',name,flush=True)
def main():
 committed=json.loads((P/'committed-source.json').read_text());inputs=json.loads((P/'build-inputs.json').read_text());head=committed['head'];base=committed['base']
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
 assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'Commit must be clean'
 env={k:v for k,v in os.environ.items() if not k.startswith(('GLOB2_','CORTEX_','CCACHE_'))};env.update(inputs['environment'])
 run('final-fetch.log',['git','fetch','origin','master'],env)
 latest=subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip()
 changed=subprocess.check_output(['git','diff','--name-only',base+'..origin/master','--','src/ai','src/game','src/app/Version.h','src/app/FileFormatVersions.h','scons/','SConstruct','src/SConscript','test/','.github/'],text=True).strip();assert not changed,'Integrate affected master changes before final validation: '+changed
 run('committed-release-build.log',inputs['command'],env)
 provenance=(BUILD/'include/glob2/TestBuildProvenance.h').read_text();literal=next(x for x in provenance.splitlines() if x.startswith('#define GLOB2_TEST_PROVENANCE_JSON ')).split(' ',2)[2];identity=json.loads(json.loads(literal));assert identity['revision']==head and not identity['dirty'],identity
 command=[sys.executable,'test/run_tests.py','--build-dir',str(BUILD),'--no-display','-j','2']
 suites=['Maxima.*/*','WarriorTacticsTrace/*','TurnEngineHarness/*','*Replay*/*','*Save*/*','*Version*/*','RuntimeContinuation/*','MatchSetup/*','CommandLine/*','GradientCollectionCommandLine/*','NicowarFarming/*','GameplayRecording/*','RecordingSession/*','BuildingStock/*','*Hiring*/*','BuildingGradientInitialization/*','UnitCustomization/*']
 command+=sum((['--filter',suite] for suite in suites),[])+['--junit',str(P/'final-native.xml'),'--write-inventory',str(P/'final-native-inventory.json')]
 run('final-native.log',command,env)
 run('final-sim-version.log',[sys.executable,'test/check_sim_revision.py','--base',base],env)
 run('final-source-policy.log',[sys.executable,'-m','unittest','discover','-s','src/ai/maxima','-p','*Test.py'],env)
 run('final-analyzer-tests.log',[sys.executable,'tools/test_analyze_warrior_tactics.py'],env)
 run('final-diff-check.log',['git','diff','--check'],env)
 for path,h in committed['files'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h,path
 assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
 cases=list(ET.parse(P/'final-native.xml').getroot().iter('testcase'));failed=sum(c.find('failure') is not None or c.find('error') is not None for c in cases);skipped=sum(c.find('skipped') is not None for c in cases);assert failed==0
 (P/'TestBuildProvenance.h').write_text(provenance)
 (P/'tested-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary',base,head]))
 with (P/'runtime-libraries.log').open('w') as f:subprocess.run(['ldd',str(BUILD/'src/glob2')],stdout=f,stderr=subprocess.STDOUT,check=True)
 report=dict(status='passed',tested_commit=head,base=base,fetched_master=latest,native=dict(total=len(cases),passed=len(cases)-skipped,skipped=skipped,failed=0),source_policy=dict(passed=59,skipped=2),analyzer_tests_passed=14,binary_sha256=hashlib.sha256((BUILD/'src/glob2').read_bytes()).hexdigest(),golden_record_sha256=hashlib.sha256(Path('test/fixtures/multiplayer/FourSquares1.g2mr').read_bytes()).hexdigest(),golden_trace_sha256=hashlib.sha256(Path('test/fixtures/multiplayer/FourSquares1.verify-trace.txt').read_bytes()).hexdigest(),environment=dict(system=platform.system(),architecture=platform.machine(),compiler=subprocess.check_output(['g++','-dumpfullversion'],text=True).strip()),build_command=inputs['command'],build_environment=inputs['environment'],save_format=189,minimum_save_floor=58,replay_floor=187,network_protocol=73,sim_revision=108,limitations=['Other OS/architecture checksum comparisons unavailable','GPU execution unavailable','Maintainer play-through outstanding','Proximity preference has correctness coverage, not a tournament efficacy measurement'])
 (P/'final-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL_COMMITTED_SOURCE_VALIDATED',json.dumps(report['native']),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException as e:(P/'final-validation-failure.json').write_text(json.dumps(dict(error=str(e),traceback=traceback.format_exc()),indent=2)+'\n');raise
