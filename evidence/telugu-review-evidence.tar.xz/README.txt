Telugu localization review evidence
Source revision: cd6a8005be458a440bfe42dd196fefce607bcf92
PR: https://github.com/Globulation2/glob2/pull/1321

Agent-reviewed, not native-human-certified. English source + final catalogs and exact per-key semantic, editorial, adversarial and changed-key recheck evidence are included. Historical records are explicitly retained; current catalog hashes are in reviews/te.json. SHA256SUMS verifies all included files.

This packet currently proves linguistic review and online desktop/phone visual QA. Native rendering, browser-game startup and platform-package gates remain pending until their actual evidence is added. Tests with environment failures are not claimed passed. Initial draft used Google Cloud Translation NMT. Raw API responses, credentials, project ID, copied third-party reference publications, local SDKs, build caches and binaries are excluded.
