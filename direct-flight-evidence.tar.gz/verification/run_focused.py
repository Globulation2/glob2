import concurrent.futures,json,subprocess
from pathlib import Path
out=Path('artifacts/direct-flight')
base=['python3','test/run_tests.py','--build-dir','/dev/shm/glob2-direct-air','--no-display','--exclude-tag','benchmark','--timeout','600']
engine=['GradientPreparation/*','UnitCustomization/*','TerrainProperties/*','TerrainHazardRouting/*','RuntimeResources/*','MapQuery/*','MapGradient*/*','GradientKernel/*','BuildingRoute*/*','Hiring*/*','ReplayStepCounter/*','GuardAreaBalance/*','BuildingProductionCombat/*','GradientPipeline/*','BuildingGradientInvalidation/*','TeamStatsSave/32 sampling phases*','JavaScriptCompatibility/Current simulation rejects*','TurnEngineHarness/the committed*']
unit=['MapQuery/*','PathGradient/*','*air movement*','*air lazy*','*authored air*']
tasks=[]
for name,binary,filters,jobs in [('focused','engine',engine,'6'),('unit','unit',unit,'1')]:
    command=base+['--binary',binary,'-j',jobs,'--junit',str(out/(name+'.xml')),'--artifacts',str(out/name),'--write-inventory',str(out/(name+'-inventory.json'))]
    for pattern in filters:command+=['--filter',pattern]
    tasks.append((name,command))
(out/'focused-commands.json').write_text(json.dumps(dict(tasks),indent=2))
def run(item):
    name,command=item
    with (out/(name+'.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    print(name,'exit',result.returncode,flush=True)
    return result.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    codes=list(pool.map(run,tasks))
raise SystemExit(any(codes))
