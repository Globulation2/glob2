from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
source=Path.cwd(); evidence=source/'artifacts/direct-flight'; publication=Path('/dev/shm/glob2-direct-air-publication'); publication.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
def results(name):
    root=ET.parse(evidence/name).getroot()
    result={key:int(root.attrib.get(key,0)) for key in ['tests','failures','errors','skipped']}
    assert result['tests'] and not result['failures'] and not result['errors'],result
    return result
summary={'head':head,'base':'486a2230a4ddb257ba9dee34d3aace05f2260d6f','engine':results('focused.xml'),'unit':results('unit.xml'),'determinism':json.loads((evidence/'determinism/summary.json').read_text()),'static_checks':['docs: 309 Markdown files, zero errors','sim revision and golden record match','generated preparation rules match','git diff --check origin/master passes']}
assert summary['determinism']['revision']==head
(evidence/'summary.json').write_text(json.dumps(summary,indent=2))
for name in ['summary.json','provenance.json','commands.txt','focused-commands.json','reconciliation.json','focused.xml','unit.xml']:
    shutil.copy2(evidence/name,publication/name)
shutil.copy2(evidence/'determinism/summary.json',publication/'determinism-summary.json')
archive=publication/'direct-flight-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(evidence.rglob('*')):
        rel=p.relative_to(evidence)
        if p.is_file() and not any(part in ('profile','profiles','__pycache__') for part in rel.parts):
            tar.add(p,arcname=str(Path('verification')/rel),recursive=False)
assert archive.stat().st_size<95_000_000
(publication/'README.md').write_text(f'''# PR 1196: direct flight qualification

Source: `{head}`, based on master `{summary['base']}`; prior PR head `522a89ff9`.

- Clean Linux x86_64 / GCC 13.3.0 development build of the game and both test binaries; `dev_fast=1`, `-O0 -g1`, no PCH/unity. No runtime dependency changes.
- {summary['engine']['tests']} focused engine cases and {summary['unit']['tests']} unit cases pass, with no failures, errors or skips. Coverage includes the nine new direct-flight cases, existing ablation golden, hiring/service/supplier policies, guard balancing, map edit/cache invalidation, released format126 migration, current save continuation, replay acceptance and the regenerated SIM-71 match golden.
- Ordinary 32-courier and constrained 64-flyer setups compare every per-tick aggregate and team/entity checksum byte for 128 ticks across 1/2/4/8 compute participants. Both resume identically at all eight publication offsets. Inputs, hashes, per-run commands, full sidecars and saves are in the archive.
- Static documentation, generated preparation rules, simulation-version and whitespace checks pass.

The archive retains exact commands, source/binary/dependency provenance, build logs, JUnit, case inventories, saves, checksum traces, and initial failures with their follow-up ledger. Initial fixture setup errors were corrected. The first broader run found an empty guard query overwriting invalid target coordinates; that production bug was repaired and the original ablation golden passes unchanged. Final results above are from the repaired clean revision.

No release performance measurement, hosted engine matrix, other-platform checksum comparison, GPU/NEON execution, visual testing or maintainer playtesting is claimed. Earlier PR performance results apply to the prior revision, not this patch.

Archive SHA-256: `{hashlib.sha256(archive.read_bytes()).hexdigest()}`.
''')
index=Path('/dev/shm/glob2-direct-air-publication.index'); env=dict(os.environ,GIT_INDEX_FILE=str(index))
def run(args,**kwargs):return subprocess.check_output(args,env=env,**kwargs).decode().strip()
run(['git','read-tree','--empty'])
for p in sorted(publication.iterdir()):
    if not p.is_file():continue
    oid=run(['git','hash-object','-w','--stdin'],input=p.read_bytes())
    run(['git','update-index','--add','--cacheinfo','100644',oid,p.name])
tree=run(['git','write-tree']); commit=run(['git','commit-tree',tree,'-m',f'Retain PR 1196 direct-flight verification for {head[:9]}'])
ref='refs/heads/evidence/pr1196-direct-flight-'+head[:9]
run(['git','update-ref',ref,commit,'0'*40])
result={'commit':commit,'ref':ref,'url':'https://github.com/Globulation2/glob2/tree/'+commit,'archive_bytes':archive.stat().st_size,'summary':summary}
Path('/dev/shm/glob2-direct-air-evidence-publication.json').write_text(json.dumps(result,indent=2))
subprocess.run(['git','push','origin',ref],check=True)
print(json.dumps({k:v for k,v in result.items() if k!='summary'},indent=2))
