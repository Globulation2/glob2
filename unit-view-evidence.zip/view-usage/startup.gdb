set pagination off
set breakpoint pending on
set $hits = 0
break SimulationSnapshot::Store::captureBoundary
commands
silent
set $hits = $hits + 1
printf "SNAPSHOT_REQUEST tick=%u mask=%u prior_calls=%lu\n", ((Game*)$rsi)->stepCounter, (unsigned int)$edx, ((SimulationSnapshot::Store*)$rdi)->metrics.requestCalls
if $hits <= 3
bt 5
end
if $hits >= 12
disable 1
end
continue
end
run
