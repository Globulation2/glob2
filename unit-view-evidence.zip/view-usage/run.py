from pathlib import Path
import os,json,subprocess,concurrent.futures,re,time
root=Path.cwd();out=root/'artifacts/movement-deep/view-usage';binary=root/'build/movement-release/src/glob2'
protocol=json.loads((root/'artifacts/movement-agreement/protocol.json').read_text())
def headless(case):
 name,initial,shadow=case;folder=out/name;folder.mkdir(exist_ok=True)
 env={k:v for k,v in os.environ.items() if not k.startswith('GLOB2_')};env['GLOB2_USER_DATA_DIR']=str(folder/'profile')
 cmd=[str(binary),'game','run','--load-game',str(initial),'--ticks','12000' if name.startswith('ai-') else '1024','--output-dir',str(folder),'--compute-threads','2','--gradient-backend','scalar']
 if shadow:cmd+=['--movement-agreement-delay','1']
 if name=='ai-symmetric-arena-1':cmd+=['--telemetry','checksums','--write-replay','--save','final']
 (folder/'command.json').write_text(json.dumps({'argv':cmd,'environment':{k:v for k,v in env.items() if k.startswith('GLOB2_')}}))
 with (folder/'run.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=900)
 print(name,flush=True)
cases=[('ai-'+g['name'],root/'artifacts/movement-agreement'/g['name']/'initial/final.game.gz',True) for g in protocol['games']]
cases += [('headless-'+f+('' if shadow else '-no-shadow'),root/'artifacts/movement-planning/fixtures'/f'{f}.game',shadow) for f in ['ordinary-control','large-colony'] for shadow in [True,False]]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(headless,cases))
for fixture in ['ordinary-control','large-colony','cortex-colony']:
 for selected in [False,True]:
  name='gui-'+fixture+('-selected' if selected else '-unselected');folder=out/name;folder.mkdir(exist_ok=True)
  save=root/(f'artifacts/compact-live/fixtures/{fixture}.game' if fixture=='cortex-colony' else f'artifacts/movement-planning/fixtures/{fixture}.game')
  env={k:v for k,v in os.environ.items() if not k.startswith(('GLOB2_','LIVE_','PROFILE_'))};env.update(SDL_VIDEODRIVER='x11',SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(folder/'profile'),PROFILE_SAVE=str(save),PROFILE_MODE='interactive',PROFILE_VISIBLE='1',PROFILE_FPS='60',LIVE_SPEED='0',LIVE_TICKS='512',LIVE_WARM_TICKS='32',LIVE_OUTPUT=str(folder/'observations.json'),PROFILE_SECONDS='30')
  if selected:env['PROFILE_SELECT']='unit'
  cmd=['xvfb-run','-a','-s','-screen 0 800x600x24',str(out/'view-probe'),'--renderer','software','--window-size','640x480','--compute-threads','2','--mute','--no-fullscreen']
  (folder/'command.json').write_text(json.dumps({'argv':cmd,'environment':{k:v for k,v in env.items() if k.startswith(('GLOB2_','LIVE_','PROFILE_','SDL_'))}}))
  with (folder/'run.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=240)
  print(name,flush=True)
