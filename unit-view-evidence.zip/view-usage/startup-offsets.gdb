set pagination off
set breakpoint pending on
set $hits = 0
break SimulationSnapshot::Store::captureBoundary
commands
silent
set $hits = $hits + 1
printf "SNAPSHOT_REQUEST tick=%u mask=%u prior_calls=%lu\n", *(unsigned int*)((char*)$rdx+121816), (unsigned int)$ecx, *(unsigned long*)((char*)$rsi+1552)
if $hits <= 12
bt 5
end
if $hits >= 12
disable 1
end
continue
end
run
