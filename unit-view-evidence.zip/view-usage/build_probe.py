from pathlib import Path
import json,shlex,subprocess,hashlib
root=Path.cwd();out=root/'artifacts/movement-deep/view-usage'
s=(root/'artifacts/compact-live/compact-live-probe.cpp').read_text()
s=s.replace('    const auto &captures=engine.gui.game.snapshots().metrics;', '''    const auto &captures=engine.gui.game.snapshots().metrics;
    printf("VIEW_USAGE observed=%llu core_only=%llu detail=%llu neither=%llu calls=%llu core_captures=%llu detail_captures=%llu core_bytes=%llu detail_bytes=%llu\\n",
        (unsigned long long)captures.observedTicks,(unsigned long long)captures.coreOnlyTicks,(unsigned long long)captures.detailTicks,(unsigned long long)captures.noUnitTicks,
        (unsigned long long)captures.requestCalls,(unsigned long long)captures.coreCaptures,(unsigned long long)captures.detailCaptures,
        (unsigned long long)captures.coreStateBytesCopied,(unsigned long long)captures.detailStateBytesCopied);''')
(out/'view-probe.cpp').write_text(s)
cmd=json.loads((root/'artifacts/compact-live/compact-compile.json').read_text())
old=str(root/'artifacts/compact-runtime/compact-source');oldbuild=str(root/'artifacts/compact-runtime/compact-release')
cmd=[a.replace(oldbuild,str(root/'build/movement-release')).replace(old,str(root)) for a in cmd]
cmd[cmd.index('-o')+1]=str(out/'view-probe.o');cmd[cmd.index('-c')+1]=str(out/'view-probe.cpp')
subprocess.run(cmd,check=True)
linkline=next(l for l in reversed((root/'artifacts/movement-deep/view-release-build.log').read_text().splitlines()) if l.startswith('g++ -o build/movement-release/src/glob2 '))
link=shlex.split(linkline);link[link.index('-o')+1]=str(out/'view-probe')
entries=[a for a in link if a.endswith('/Glob2.o') or a.endswith('/main.o')];assert len(entries)==1,entries
link=[str(out/'view-probe.o') if a==entries[0] else a for a in link]
link.append('-Wl,--wrap=_ZN6Engine14simulationStepEm');subprocess.run(link,check=True)
(out/'build.json').write_text(json.dumps({'compile':cmd,'link':link,'sha256':hashlib.sha256((out/'view-probe').read_bytes()).hexdigest()},indent=2))
