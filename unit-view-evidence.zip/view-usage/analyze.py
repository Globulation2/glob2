from pathlib import Path
import json,re,csv
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=Path(__file__).resolve().parent;rows=[]
for folder in sorted(out.iterdir()):
 if not folder.is_dir() or not folder.name.startswith(("ai-","headless-","gui-")):continue
 if folder.name.startswith('gui-'):
  text=(folder/'run.log').read_text();line=re.search(r'^VIEW_USAGE .*',text,re.M)
  if not line:continue
  m={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line[0])}
  live=re.search(r'^LIVE .*',text,re.M);detail={k:float(v) for k,v in re.findall(r'([a-zA-Z0-9_]+)=([\d.]+)',live[0])}
 else:
  if not (folder/'result.json').exists():continue
  r=json.loads((folder/'result.json').read_text());a=r['ai_pipeline']
  names={'observed':'observed_ticks','core_only':'core_only_ticks','detail':'detail_ticks','neither':'no_unit_ticks','calls':'request_calls','core_captures':'core_captures','detail_captures':'detail_captures','core_bytes':'core_state_bytes_copied','detail_bytes':'detail_state_bytes_copied'}
  m={k:a['snapshot_'+v] for k,v in names.items()};detail={'result_ticks':r['ticks']}
 assert m['observed']==m['core_only']+m['detail']+m['neither']
 rows.append({'case':folder.name,**m,**detail,'core_only_percent':100*m['core_only']/m['observed'],'detail_percent':100*m['detail']/m['observed'],'neither_percent':100*m['neither']/m['observed']})
(out/'samples.json').write_text(json.dumps(rows,indent=2));keys=sorted(set().union(*(r.keys() for r in rows)))
with (out/'samples.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
fig,ax=plt.subplots(figsize=(11,7));base=[0]*len(rows)
for field,label,color in [('core_only_percent','Core only','#1b9e77'),('detail_percent','Core + detail','#d95f02'),('neither_percent','No units','#7570b3')]:
 values=[r[field] for r in rows];ax.barh([r['case'] for r in rows],values,left=base,color=color,label=label);base=[a+b for a,b in zip(base,values)]
ax.set(xlim=(0,100),xlabel='Percent of distinct snapshot-requested logical ticks');ax.legend(loc='lower left',bbox_to_anchor=(0,1.01),ncol=3);ax.invert_yaxis();fig.suptitle('Unit requirements: union across all consumers within each tick',y=.99);fig.tight_layout(rect=(0,0,1,.93));fig.savefig(out/'unit-view-ticks.png',dpi=170)
print(json.dumps(rows,indent=2))
