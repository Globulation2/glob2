from pathlib import Path
import json,platform,subprocess,hashlib
root=Path(__file__).resolve().parent;rows=json.loads((root/'samples.json').read_text());by={r['case']:r for r in rows}
text='''# How often does a tick need unit details?

Measured source `fdca48059` (full SHA in metadata), base `277510840054b1416f2defd7d86fe1431dd0ddc0`. The two-layer core/detail layout is unchanged; no presentation subdivision or production movement adoption.

**The six real Cortex/Nicowar/Warrush games required details on every advancing gameplay tick.** Headless Null-AI movement-shadow runs required cores only on every advancing tick. Rendering without selection also uses cores only; selecting a unit adds details. Cortex already requires details, so selection adds no further unit capture in that case.

## Observed sessions

The following percentages use every distinct logical tick observed by the shared snapshot store, including initial/final observations. Requirements are normalized and ORed across all same-tick requests. Details imply cores. Repeated requests and requirement upgrades never multiply the tick denominator.

| Session | Observed ticks | Core only | Core + details | No unit requirement |
|---|---:|---:|---:|---:|
'''
for r in rows:text+=f"| {r['case']} | {r['observed']:,} | {r['core_only_percent']:.3f}% | {r['detail_percent']:.3f}% | {r['neither_percent']:.3f}% |\n"
text+='''
![Requested components per logical tick](unit-view-ticks.png)

Six headless AI runs load existing real-game states at tick 1 and advance to 12,000: 11,999 detail-requesting gameplay ticks per game, plus one final checksum-preparation observation with no unit requirement. The two headless Null-AI shadow fixtures advance from zero to 1,024: 1,024 core-only ticks, plus the checksum-preparation observation. This explains 99.992%/99.902% in the raw totals; it is not a rare gameplay tick that avoided the corresponding requirement. The terminal checksum-boundary mask and call stack were checked separately with GDB, using the Linux x86-64 return-value ABI and compiler-derived field offsets. Failed initial debugger setup attempts are retained but not used as evidence.

The six GUI runs are actual concurrent Engine sessions, 32 warmup + 512 measured advances at normal 30 TPS, presentation target 60 FPS, software/Xvfb at 640x480, two executor participants. Their 545 observed ticks include the initial world and the final tick. The 1,024-unit unselected colony requests cores on 539 ticks; the selected run requests details on 538. On the remaining ticks presentation preparation has not admitted a new unit-bearing observation. GUI admission depends on readiness and pacing, so these exact frequencies describe these sessions under recorded host load, not a universal distribution of human selection behavior. Ordinary GUI controls request their respective components on all 545 ticks. Cortex requests details on all 545 ticks, selected or unselected.

## Requests versus actual copying

The compact core is 132 authoritative bytes / 160 bytes with snapshot metadata. Details add 216 authoritative bytes per unit. The table counts actual component capture operations separately from requests; authoritative state bytes exclude indexes, relationship metadata, cargo sidecars and retained capacity.

| GUI case | Request calls | Core captures | Detail captures | Core state bytes | Detail state bytes |
|---|---:|---:|---:|---:|---:|
'''
for r in rows:
 if r['case'].startswith('gui-'):text+=f"| {r['case']} | {r['calls']:,} | {r['core_captures']:,} | {r['detail_captures']:,} | {r['core_bytes']:,} | {r['detail_bytes']:,} |\n"
text+='''
The unselected large colony copies **zero detail bytes**, versus approximately 119 MB in the selected run. At an equal unit/capture count, core-only authoritative copying omits 216 of 348 bytes (**62.07%**); the populated record payload omits 216 of 376 bytes (**57.45%**). These are unit byte ratios, not overall engine/runtime improvements. Actual session volumes differ slightly because presentation admission differs.

Cortex/Nicowar/Warrush request `Simulation` (with selected components removed in Warrush), which includes the normalized `Entities` aggregate and therefore details. The migrated unit-under-attack/defense scans still read compact cores; other AI decisions continue using details. **0% core-only does not mean no compact-core use.** It means details were also needed somewhere in that tick. Rendering and AI reuse the same captured cores; a selected panel on top of a full AI observation does not force another copy. Null-AI headless controls without shadow request no unit records on any of their 1,025 observed ticks. Building-only requests remain independent of unit requirements.

## Verification and limits

127 focused engine cases pass, one display-tagged case skipped by the explicit headless selection. Coverage includes snapshot union/upgrades/reset, compact records, planner delays/participants, scene extraction, gradients and affected AI observation cases. Release controls at two and four participants preserve per-tick checksums, replay bytes, replay checksum streams and decompressed final saves against the original reference. An initial control omitted `team-timeline`: it preserved checksums/replay but differed in 22 stored counter bytes (and the dependent SHA1). Restoring identical telemetry options makes the save byte-identical at both participant counts. The mismatched control is retained and is not used as a save-equivalence claim. All six measurement runs preserve reference initial/final checksums; they do not all record per-tick checksums.

No new runtime dependencies. No save/replay/network/SIM version change. Linux x86-64/GCC 15.2 only; macOS, Windows, browsers, GPU backends, human multiplayer/selection patterns and longer UI sessions are unavailable or unmeasured. Concurrent tournament activity is recorded; no new clean FPS/TPS or capture-time performance claim is made from these frequency runs. Prior reserved-core runtime evidence remains separate. Original movement gates are unchanged, production remains Stage A and disabled by default.

[Exact protocol](unit-view-protocol.md) · [Raw samples](unit-view-samples.csv) · [Metadata](unit-view-metadata.json) · [Commands/logs/fixtures/debugger controls](unit-view-evidence.zip)
'''
(root/'report.md').write_text(text)
base=Path.cwd();p=base/'artifacts/movement-agreement/protocol.json';comparisons=[]
for g in json.loads(p.read_text())['games']:
 a=json.loads((root/('ai-'+g['name'])/'result.json').read_text());b=json.loads((base/'artifacts/movement-agreement'/g['name']/'reference/result.json').read_text());comparisons.append({'game':g['name'],'initial':a['initialChecksum']==b['initialChecksum'],'final':a['finalChecksum']==b['finalChecksum']})
(root/'endpoint-checksums.json').write_text(json.dumps(comparisons,indent=2))
metadata={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'base':subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip(),'platform':platform.platform(),'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'release_binary_sha256':hashlib.sha256((base/'build/movement-release/src/glob2').read_bytes()).hexdigest(),'sampling':'Six real AI games; four Null-AI headless cases; six GUI sessions. Frequencies are exact observed counts; GUI readiness is load-dependent. No timing comparison.','test_command':"GLOB2_BUILD_DIR=build/movement-dev python3 test/run_tests.py --binary engine --filter WorldSnapshot/* --filter CompactUnitSnapshot/* --filter MovementPlanning/* --filter SceneExtract/* --filter GradientPreparation/* --filter WarrushObservation/* --filter CortexActionCoverage/* --no-display --junit artifacts/movement-deep/final-focused-tests.xml",'results':'127 pass; 1 display-tagged skip; matched canonical controls at participants 2 and 4 pass all four outputs','omissions':['macOS','Windows','browser serial/threaded','GPU backends','human multiplayer selection patterns'],'fixture_sha256':{str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [base/'artifacts/movement-planning/fixtures/ordinary-control.game',base/'artifacts/movement-planning/fixtures/large-colony.game',base/'artifacts/compact-live/fixtures/cortex-colony.game']}}
(root/'metadata.json').write_text(json.dumps(metadata,indent=2))
