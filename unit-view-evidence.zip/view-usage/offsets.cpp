#include "Game.h"
#include <cstdio>
#include <cstddef>
int main() { std::printf("%zu %zu\n",offsetof(Game,stepCounter),offsetof(SimulationSnapshot::Store,metrics)+offsetof(SimulationSnapshot::Store::Metrics,requestCalls)); }
