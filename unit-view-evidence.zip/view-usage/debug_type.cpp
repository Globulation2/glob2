#include "Game.h"
extern "C" Uint32 snapshotDebugTick(Game* game) { return game->stepCounter; }
