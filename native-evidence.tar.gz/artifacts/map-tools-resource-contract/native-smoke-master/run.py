#!/usr/bin/env python3
"""Finite nine actual CLI map requests. Default zero launch; no timings/builds."""
import argparse,copy,gzip,hashlib,importlib.util,json,math,os,pathlib,signal,subprocess,time
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def load(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def require(v,m):
 if not v:raise ValueError(m)
def write(p,v):pathlib.Path(p).write_text(json.dumps(v,indent=2)+'\n')
def gate(a,plan):
 approval=load(a);require(approval.get('root_approved') is True and approval['state']=='complete','root approval/source binding pending')
 require(approval['helper_sha256']==sha(__file__) and approval['plan_sha256']==sha(HERE/'plan.json'),'smoke source/plan drift')
 require(time.time()-approval['reviewed_unix_s']<=900,'fresh phase review required')
 require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==approval['source_commit'],'final source drift')
 require(subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip()==approval['source_tree'],'final tree drift')
 require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True),'final source dirty')
 receipt=load(approval['build_receipt']);require(sha(approval['build_receipt'])==approval['build_receipt_sha256'] and receipt['passed'] is True and receipt['source']==approval['source_commit'] and receipt['tree']==approval['source_tree'] and receipt['source_unchanged'] is True and receipt['exit']==0,'fresh final release receipt')
 app=receipt['outputs']['build/linux/client/release/src/glob2'];require(app['path']==approval['binary'] and app['sha256']==approval['binary_sha256']==sha(app['path']),'final binary binding')
 require({'tools/map_generation_study.py','tools/map_telemetry.py','src/app/cli/MapCommand.cpp','src/app/cli/MapStudy.cpp','tools/tournaments/resources.py','tools/tournaments/cli.py'}.issubset(approval['source_sha256']),'required source closure missing')
 for file,digest in approval['source_sha256'].items():require(sha(ROOT/file)==digest,'native/tool source drift')
 require(approval['runtime_library_sha256'],'current runtime libraries unbound')
 for file,digest in approval['runtime_library_sha256'].items():require(sha(file)==digest,'library drift')
 require(sha(plan['legacy_binary'])==plan['legacy_binary_sha256'],'old real binary drift')
 require(approval['legacy_library_sha256'],'old runtime libraries unbound')
 for file,digest in approval['legacy_library_sha256'].items():require(sha(file)==digest,'legacy library drift')
 return approval

def owned(argv,directory,env,cwd,timeout=180):
 require(not directory.exists(),'fresh child evidence required');directory.mkdir(parents=True)
 write(directory/'invocation.json',{'argv':argv,'cwd':str(cwd),'timeout_s':timeout,'scope':'functional map/request proof only; no timing claim'})
 proc=None;previous={}
 def interrupted(s,f):raise RuntimeError('interrupted '+str(s))
 for s in (signal.SIGINT,signal.SIGTERM,signal.SIGALRM):previous[s]=signal.signal(s,interrupted)
 try:
  with (directory/'stdout.log').open('xb') as stdout,(directory/'stderr.log').open('xb') as stderr:
   old=signal.pthread_sigmask(signal.SIG_BLOCK,set(previous))
   try:proc=subprocess.Popen(argv,cwd=cwd,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=lambda:signal.pthread_sigmask(signal.SIG_SETMASK,old))
   finally:signal.pthread_sigmask(signal.SIG_SETMASK,old)
   return proc.wait(timeout=timeout)
 except BaseException as error:
  old=signal.pthread_sigmask(signal.SIG_BLOCK,set(previous))
  try:
   if proc and proc.poll() is None:
    try:os.killpg(proc.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    proc.wait()
   write(directory/'failure.json',{'passed':False,'error':repr(error),'raw_preserved':True})
  finally:signal.pthread_sigmask(signal.SIG_SETMASK,old)
  raise
 finally:
  for s,h in previous.items():signal.signal(s,h)

def main():
 p=argparse.ArgumentParser();p.add_argument('--run',action='store_true');p.add_argument('--approval',type=pathlib.Path);a=p.parse_args()
 if not a.run:print(json.dumps({'launches':0,'map_cli_requests':9,'generation_service_calls_expected':8,'metadata_help_probes':2,'state':'ROOT_FINAL_SOURCE_BUILD_BINDING_PENDING'}));return
 require(a.approval,'approval required');plan=load(HERE/'plan.json');approvalhash=sha(a.approval);binding=gate(a.approval,plan);require(len(plan['requests'])==9,'finite inventory');out=HERE/'runs';require(not out.exists(),'no overwrite/retry');out.mkdir()
 spec=importlib.util.spec_from_file_location('map_smoke_resources',ROOT/'tools/map_generation_study.py');m=importlib.util.module_from_spec(spec)
 import sys
 sys.path.insert(0,str(ROOT/'tools'));spec.loader.exec_module(m)
 env={k:v for k,v in os.environ.items() if not k.startswith('GLOB2_')};env.update(SDL_VIDEO_DRIVER='dummy',SDL_AUDIO_DRIVER='dummy',SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_USER_DIR=str(out/'user'),GLOB2_USER_DATA_DIR=str(out/'user'))
 cli=out/'current-help';require(owned(['taskset','-c','15,31',binding['binary'],'help','--format','json'],cli,env,ROOT)==0,'current CLI discovery');description=load(cli/'stdout.log');require(m.classify_cli_capability(description)=='execution_profiles_v1','current contract missing')
 old=out/'legacy-help';require(owned(['taskset','-c','15,31',plan['legacy_binary'],'help','--format','json'],old,env,pathlib.Path(plan['legacy_root']))==0,'real old CLI discovery');require(m.classify_cli_capability(load(old/'stdout.log'))=='legacy_cli2','actual old binary does not expose legacyCLI2')
 records={}
 for q in plan['requests']:
  gate(a.approval,plan);require(sha(a.approval)==approvalhash,'approval drift');directory=out/q['id'];binary=plan['legacy_binary'] if q['kind']=='legacy_rejection' else binding['binary'];command=copy.deepcopy(q['args'])
  command=[str(directory/part[1:]) if part.startswith('@') else part for part in command]
  if q.get('profile') is not None:
   request=m.resource_request(q['profile'],plan['planning_memory_bytes'])
   if q['kind']!='legacy_rejection':
    commands=[c for c in description['commands'] if c['path']==q['command'] and c.get('available') is True];require(len(commands)==1,'actual command advertisement')
    names={o['name'] for o in commands[0]['options']};require({'--execution-profile','--memory-budget-bytes'}.issubset(names),'map options not advertised')
   command+=['--execution-profile',q['profile'],'--memory-budget-bytes',str(plan['planning_memory_bytes'])]
  else:request=None
  code=owned(['taskset','-c','15,31',binary,*command],directory,env,ROOT if q['kind']!='legacy_rejection' else pathlib.Path(plan['legacy_root']));require(code==q['expected_exit'],'unexpected native exit; raw retained '+q['id'])
  if q['kind']=='legacy_rejection':
   require(not (directory/'report.json').exists() and not (directory/'same.map.gz').exists(),'unsupported old request generated output')
   error=(directory/'stderr.log').read_text()+(directory/'stdout.log').read_text();require('execution-profile' in error and ('Unknown' in error or 'unknown' in error or 'unsupported' in error.lower()),'old actual option-rejection diagnostic absent');records[q['id']]={'passed':True,'actual_exit':code,'scope':'Real old CLI refuses unsupported explicitflag; no generation report/map artifact created.'};continue
  native=load(directory/q['report']);report=native if q['command']=='map generate' else native['map_report'];require(report['generation']['seed']==q['seed'] and report['generation']['generator']==q['generator'],'actual generation identity');raw_request=report['generation']['raw_request'];require([raw_request['width_exponent'],raw_request['height_exponent'],raw_request['teams'],raw_request['workers']]==q['expected_geometry'],'actual geometry/controller/workers differ');resource=m.validate_resource_report(native if q['command']=='map study' else report,request);require(resource['resolved_resources']['compute_participants']==1,'actual owner-only participant')
  if q['kind']=='refusal':
   require(report['report_type']=='generation_failure' and report['generation']['outcome']['success'] is False,'actual service refusal');require(report['generation']['outcome']['error']=='placement_failed','known placement error');require(resource is not None,'failure resource plan missing');records[q['id']]={'passed':True,'actual_exit':code,'resource_plan':resource,'generation':report['generation'],'raw_sha256':sha(directory/q['report'])};continue
  require(report['report_type']=='map' and report['generation']['outcome']['success'] is True,'actual generation success')
  if q['command']=='map study':require(native['status']=='completed' and native['rotations_verified'] is True,'study canonical rotation proof')
  mapfile=directory/q['map'];require(mapfile.is_file(),'native saved map missing');
  with gzip.open(mapfile,'rb') as saved:raw=saved.read(64*1024*1024+1)
  require(len(raw)<=64*1024*1024,'bounded map artifact');core=copy.deepcopy(report);core.pop('execution_resources',None)
  native_core=copy.deepcopy(native);native_core.pop('execution_resources',None)
  if q['command']=='map study':
   require(type(native['seconds']) in (int,float) and math.isfinite(native['seconds']) and native['seconds']>=0,'invalid observed study seconds')
   require(native['candidates']==0 and native['candidate_rolls']==[],'unexpected candidate search/timing records')
   native_core.pop('seconds')
  records[q['id']]={'passed':True,'actual_exit':code,'native_core':native_core,'resource_plan':resource,'map_file_sha256':sha(mapfile),'uncompressed_map_sha256':hashlib.sha256(raw).hexdigest(),'report_core':core,'raw_report_sha256':sha(directory/q['report'])}
  if q.get('same_as'):
   control=records[q['same_as']];require(records[q['id']]['uncompressed_map_sha256']==control['uncompressed_map_sha256'],'same-command mapbytes differ');require(core==control['report_core'],'report core differs; no broad filtering permitted');require(native_core==control['native_core'],'native report differs beyond predeclared metadata/study seconds')
 gate(a.approval,plan);require(sha(a.approval)==approvalhash,'final approval drift');write(out/'complete.json',{'passed':True,'source':binding['source_commit'],'tree':binding['source_tree'],'app_sha256':binding['binary_sha256'],'host_load_qualification':plan['host_load_qualification'],'comparison_policy':plan['comparison_policy'],'map_cli_requests':9,'actual_generation_service_calls':8,'real_legacy_rejections':1,'records':records,'scope':'Owner-only explicit6 intents, omitted same-command mapbytes/reportcore equality, real Swamp128 refusal2/4 provenance. No tiercalibration/RSS/device/performance claim.'})
if __name__=='__main__':main()
