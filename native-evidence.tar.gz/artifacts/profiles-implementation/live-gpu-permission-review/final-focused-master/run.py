#!/usr/bin/env python3
"""Finite build-bound focused tests; default zero launches, no build/retry."""
import argparse,fnmatch,hashlib,json,os,re,signal,subprocess,sys,time,xml.etree.ElementTree as E
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def verify(a):
 p=load(HERE/'plan.json');assert a['approved'] is True and a['runtime_correctness_approved'] is True and a['runtime_host_scope'] in ('quiet_host_correctness','shared_host_correctness')
 assert a['runner_sha256']==sha(__file__) and a['plan_sha256']==sha(HERE/'plan.json')
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==p['source']
 assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip()==p['tree']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
 assert sha(a['build_receipt'])==a['build_receipt_sha256'];b=load(a['build_receipt'])
 assert b['passed'] is True and b['source_unchanged'] is True and b['exit']==0 and b['source']==p['source'] and b['tree']==p['tree']
 assert b['argv']==load(p['build_plan'])['stages'][0]['argv']
 assert sha(p['build_plan'])==p['build_plan_sha256']
 assert sha(a['build_approval'])==a['build_approval_sha256'];ba=load(a['build_approval']);assert ba['source_commit']==p['source']
 for n,d in ba['source_sha256'].items():assert sha(ROOT/n)==d,n
 required={'build/linux/client/release/src/glob2','build/linux/client/release/test/glob2-unit-tests','build/linux/client/release/test/glob2-engine-tests'}
 assert set(b['outputs'])==required
 for n,v in b['outputs'].items():assert Path(v['path'])==ROOT/n and sha(ROOT/n)==v['sha256'],n
 assert a['dependency_sha256'],'Actual linked dependency hashes required before approval'
 for n,d in a['dependency_sha256'].items():assert sha(n)==d,n
 return p

def identity(pid):
 try:
  folder=Path('/proc')/str(pid);fields=(folder/'stat').read_text().rsplit(')',1)[1].split()
  uid=int(next(x for x in (folder/'status').read_text().splitlines() if x.startswith('Uid:')).split()[1])
  return {'pid':pid,'start':int(fields[19]),'uid':uid,'ppid':int(fields[1]),'pgid':int(fields[2]),'sid':int(fields[3]),'state':fields[0]}
 except (FileNotFoundError,ProcessLookupError):return None

def same(value):
 now=identity(value['pid'])
 return now if now and all(now[k]==value[k] for k in ('pid','start','uid','pgid','sid')) else None

def owned_cleanup(child,bound):
 record={'runner':bound,'scope':'PID/start/UID/PG/session bound ancestry; no name-based or foreign signalling','descendants':[],'signals':[]}
 try:
  now=same(bound)
  if now and now['state']!='Z':
   os.kill(bound['pid'],signal.SIGSTOP);record['signals'].append([bound['pid'],'SIGSTOP'])
   deadline=time.monotonic()+2
   while (now:=same(bound)) and now['state'] not in ('T','t','Z'):
    assert time.monotonic()<deadline,'Owned runner did not stop; no unbounded spawn inventory'
    time.sleep(.01)
  # Stopped runner cannot spawn another native case. Selected cases have threads,
  # not external children; retain ancestry snapshots for independently grouped cases.
  identities={}
  for folder in Path('/proc').iterdir():
   if folder.name.isdigit():
    value=identity(int(folder.name))
    if value:identities[value['pid']]=value
  owned={bound['pid']:bound};changed=True
  while changed:
   changed=False
   for pid,value in identities.items():
    if pid not in owned and value['ppid'] in owned:
     assert value['uid']==bound['uid'],'Unexpected descendant UID; refuse inference'
     owned[pid]=value;changed=True
  record['descendants']=[v for k,v in owned.items() if k!=bound['pid']]
  # Each child has an exact captured identity even when its PG differs from the
  # runner. PID signalling terminates all pthreads without touching foreign PGs.
  for value in reversed(record['descendants']):
   now=same(value)
   if now and now['state']!='Z':
    os.kill(value['pid'],signal.SIGKILL);record['signals'].append([value['pid'],'SIGKILL'])
  now=same(bound)
  if now and now['state']!='Z':os.kill(bound['pid'],signal.SIGKILL);record['signals'].append([bound['pid'],'SIGKILL'])
  child.wait(timeout=10)
  for value in record['descendants']:
   now=same(value);assert not now or now['state']=='Z','Owned descendant still active'
  record['passed']=True
 finally:record['runner_reaped']=child.poll() is not None
 return record

def invoke(argv,log,env):
 child=None;bound=None;blocked=(signal.SIGINT,signal.SIGTERM,signal.SIGALRM)
 oldmask=signal.pthread_sigmask(signal.SIG_BLOCK,blocked)
 try:
  with log.open('xb') as f:
   try:
    child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,
        preexec_fn=lambda:signal.pthread_sigmask(signal.SIG_SETMASK,oldmask))
    bound=identity(child.pid);assert bound and bound['uid']==os.getuid() and bound['pgid']==bound['sid']==child.pid
    signal.pthread_sigmask(signal.SIG_SETMASK,oldmask)
    return child.wait(timeout=1200)
   except BaseException:
    # Keep cleanup protected from a second interrupt until the owned runner is reaped.
    signal.pthread_sigmask(signal.SIG_BLOCK,blocked)
    if child and bound:write(log.with_suffix('.cleanup.json'),owned_cleanup(child,bound))
    elif child:
     child.kill();child.wait(timeout=10) # Unpublished direct Popen child only; no PID inference.
    raise
 finally:signal.pthread_sigmask(signal.SIG_SETMASK,oldmask)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');ap.add_argument('--approval',type=Path);args=ap.parse_args()
 if not args.run:print('{"launches":0}');return
 assert args.approval;a=load(args.approval);p=verify(a)
 def interrupted(s,f):raise RuntimeError('Focused controller interrupted '+str(s))
 for s in(signal.SIGTERM,signal.SIGINT,signal.SIGALRM):signal.signal(s,interrupted)
 env={k:v for k,v in os.environ.items() if not k.startswith('GLOB2_')}
 completed=[]
 for stage in p['stages']:
  verify(a);folder=HERE/stage['id'];folder.mkdir(exist_ok=False)
  base=['taskset','-c','3,4,19,20',sys.executable,'test/run_tests.py','--build-dir','build/linux/client/release','--binary',stage['role'],'--no-display','-j1']
  for pattern in stage['filters']:base+=['--filter',pattern]
  listing=base+['--list'];code=invoke(listing,folder/'listing.log',env);assert code==0
  text=(folder/'listing.log').read_text();labels=[line.strip() for line in text.splitlines() if '/' in line and not line.startswith('[run_tests]')];m=re.search(r'^(\d+) cases(?:,.*)?$',text,re.M);assert m and len(labels)==int(m[1])>0
  for pattern in stage['required']:assert any(fnmatch.fnmatchcase(label,pattern) for label in labels),pattern
  write(folder/'compiled-inventory.json',{'role':stage['role'],'labels':labels,'selected':len(labels),'display_omissions':re.findall(r'\d+ need a display',text)})
  argv=base+['--write-inventory',str(folder/'selection.json'),'--junit',str(folder/'junit.xml'),'--artifacts',str(folder/'raw')]
  code=invoke(argv,folder/'runner.log',env)
  receipt={'stage':stage['id'],'role':stage['role'],'argv':argv,'exit_code':code,'selected':len(labels),'approval_sha256':sha(args.approval),'build_receipt_sha256':a['build_receipt_sha256'],'source':p['source'],'runtime_host_scope':a['runtime_host_scope'],'passed':False}
  if (folder/'junit.xml').exists():
   x=E.parse(folder/'junit.xml');cases=list(x.iter('testcase'));receipt.update(executed=len(cases),failures=sum(len(list(t.iter('failure')))+len(list(t.iter('error'))) for t in cases),skipped=sum(len(list(t.iter('skipped'))) for t in cases),junit_sha256=sha(folder/'junit.xml'))
   receipt['passed']=code==0 and len(cases)==len(labels) and receipt['failures']==receipt['skipped']==0
  write(folder/'receipt.json',receipt);print(json.dumps(receipt),flush=True)
  assert receipt['passed'],'Stop on first failure; retain outputs, no retry'
  verify(a);completed.append(receipt)
 write(HERE/'complete.json',{'passed':True,'source':p['source'],'stages':completed,'scope':'Focused native correctness only. No platform/device/performance claims.'})
if __name__=='__main__':main()
