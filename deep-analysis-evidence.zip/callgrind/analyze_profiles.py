import re,json
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def parse(path):
 names={}; own=defaultdict(int); edges=defaultdict(lambda:[0,0]); current=None; target=None; call=None
 for line in path.read_text().splitlines():
  if line.startswith(('fn=','cfn=')):
   kind,val=line.split('=',1); m=re.match(r'\((\d+)\)(?: (.*))?$',val)
   if m:
    ident=int(m[1]);
    if m[2] is not None:names[ident]=m[2]
   else:
    ident=val;names[ident]=val
   if kind=='fn':current=ident
   else:target=ident
  elif line.startswith('calls='):call=int(line.split('=',1)[1].split()[0])
  elif re.match(r'^[0-9+*\-]',line):
   cols=line.split()
   if len(cols)<2:continue
   cost=int(cols[-1])
   if call is not None:
    edges[(current,target)][0]+=call;edges[(current,target)][1]+=cost;call=None
   else:own[current]+=cost
 nodes={names[n]:{'self_Ir':value,'inclusive_Ir':value} for n,value in own.items()}
 result=[]
 for (src,dst),(calls,cost) in edges.items():
  s=names[src];t=names[dst];nodes.setdefault(s,{'self_Ir':0,'inclusive_Ir':0})['inclusive_Ir']+=cost
  result.append({'caller':s,'callee':t,'calls':calls,'Ir':cost})
 return {'thread':int(re.search(r'^thread: (\d+)',path.read_text(),re.M)[1]),'total_self_Ir':sum(own.values()),'nodes':nodes,'edges':result}

reports={}
for label in ['reference','shadow-k1']:
 folder=ROOT/(label+'-symbols'); paths=sorted(folder.glob('callgrind.out.*-*'))
 if not paths:continue
 reports[label]=[parse(p) for p in paths]
(ROOT/'callgraph-data.json').write_text(json.dumps(reports,indent=2)+'\n')
for label,threads in reports.items():
 print('\n',label)
 for t in threads:
  print('THREAD',t['thread'],'total Ir',t['total_self_Ir'])
  for name,n in t['nodes'].items():
   if any(s in name for s in ['Store::captureBoundary','Shadow::boundary(','Planner::build(','Planner::plan(']):
    print(name,n)
  if t['thread']==1:
   for e in t['edges']:
    if 'Store::captureBoundary' in e['callee'] or ('SimulationSnapshot::capture(' in e['callee'] and 'Store::captureBoundary' in e['caller']):print('EDGE',e)
