import json,shlex,subprocess,concurrent.futures
from pathlib import Path
root=Path.cwd();out=root/'artifacts/movement-planning/deep-analysis';entries=json.loads((root/'build/movement-release/compile_commands.json').read_text())

def compile_file(relative,output,source=None):
 entry=next(e for e in entries if e['file'].endswith(relative));args=[a.replace('\\"','"') for a in shlex.split(entry['command']) if a!='-s'];args[args.index('-o')+1]=str(output);args.insert(args.index('-c')+1,'-g')
 if source is not None:
  copied=output.with_suffix('.cpp');copied.write_text(source);args[-1]=str(copied);args+=['-I'+str((root/relative).parent)]
 (output.with_suffix('.command.json')).write_text(json.dumps(args,indent=2)+'\n')
 subprocess.run(args,check=True,stdout=subprocess.DEVNULL);return relative,output

ai=(root/'src/game/GameAI.cpp').read_text().replace('#include "Player.h"','#include "Player.h"\n#include <valgrind/callgrind.h>\n#include <cstdio>')
needle=' const bool movement = !paused && movementShadow && movementShadow->planningEnabled();'
ai=ai.replace(needle,''' static bool profiled=false;
 if(!paused && stepCounter>=64 && !profiled) {
  profiled=true;CALLGRIND_START_INSTRUMENTATION;CALLGRIND_ZERO_STATS;
  std::fprintf(stderr,"PROFILE_BEGIN tick=%u unit_view_bytes=%zu building_view_bytes=%zu task_bytes=%zu\\n",unsigned(stepCounter),sizeof(SimulationSnapshot::UnitView),sizeof(SimulationSnapshot::BuildingView),sizeof(MovementPlanning::Task));
 }
'''+needle)
clean=['src/unit/planning/MovementPlanner.cpp','src/unit/planning/MovementShadow.cpp','src/engine/sim/snapshot/WorldCapture.cpp','src/engine/sim/snapshot/SnapshotStore.cpp']
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures=[pool.submit(compile_file,f,out/(Path(f).stem+'-debug.o')) for f in clean]
 futures.append(pool.submit(compile_file,'src/game/GameAI.cpp',out/'GameAI-window.o',ai))
 replacements=dict(f.result() for f in futures)
link=json.loads((root/'artifacts/movement-planning/fix-retest/symbol-link-command.json').read_text());link[2]=str(out/'glob2-window-profile')
for relative,obj in replacements.items():link[link.index('build/movement-release/'+relative[:-4]+'.o')]=str(obj)
(out/'window-link-command.json').write_text(json.dumps(link,indent=2)+'\n');subprocess.run(link,check=True)
print('Clean optimized source-line profiling binary ready',flush=True)
