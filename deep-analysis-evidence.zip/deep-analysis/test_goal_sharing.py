exec((__import__('pathlib').Path(__file__).parent/'build_probes.py').read_text().split("ai=(root/")[0])
source=(root/'src/unit/planning/MovementPlanner.cpp').read_text().replace('#include <tuple>','#include <tuple>\n#include <cstdio>')
trace=r'''
    std::fprintf(stderr,"SUGGEST unit=%u generation=%u sequence=%llu observation=%u publication=%u completion=%u epoch=%llu action=%llu x=%d y=%d mode=%u preferred=%u disposition=%u destination=%u dest_x=%d dest_y=%d supplier=%u supplier_generation=%u dirs=%u,%u,%u,%u,%u,%u,%u,%u\n",unsigned(request.task.unit.gid),unsigned(request.task.unit.generation),(unsigned long long)request.sequence,request.observationTick,request.publicationTick,request.expectedCompletionTick,(unsigned long long)request.epoch,(unsigned long long)request.actionGeneration,request.task.x,request.task.y,unsigned(request.mode),unsigned(result.preferred),unsigned(result.disposition),unsigned(bool(result.destination)),result.destination?result.destination->x:0,result.destination?result.destination->y:0,result.destination?unsigned(result.destination->supplier.gid):0,result.destination?unsigned(result.destination->supplier.generation):0,unsigned(result.directions[0]),unsigned(result.directions[1]),unsigned(result.directions[2]),unsigned(result.directions[3]),unsigned(result.directions[4]),unsigned(result.directions[5]),unsigned(result.directions[6]),unsigned(result.directions[7]));
'''
pos=source.rfind('    return result;');assert pos!=-1;source=source[:pos]+trace+source[pos:]
needle='            sharedTask.attached=request.task.attached; // supplier/home semantics'
sharing=r'''
            // Counterfactual: retain home identity only if it contributes stock goals.
            const auto* home=building(world,request.task.attached);
            const auto material=request.task.material;
            if(home && material>=0 && material<int(MaterialCount)
                && ((world.catalogs->typeDefinitions->at(home->typeNum).runtimeFetchesStockMask
                  | world.catalogs->typeDefinitions->at(home->typeNum).runtimeFetchesDirectStockMask) & (1u<<material))) {
                for(const auto& supplier:world.entities->buildings)
                    if(supplier.team==request.task.team && supplier.identity!=request.task.attached
                        && (supplier.availableSupplyMask & (1u<<material))) { sharedTask.attached=request.task.attached;break; }
            }
'''
assert needle in source
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 jobs=[pool.submit(compile_file,'src/unit/planning/MovementPlanner.cpp',out/'Planner-trace-control.o',source),pool.submit(compile_file,'src/unit/planning/MovementPlanner.cpp',out/'Planner-trace-shared.o',source.replace(needle,sharing))]
 objects=[j.result()[1] for j in jobs]
records={}
for label,obj in zip(['control','shared-goals'],objects):
 link=json.loads((root/'artifacts/movement-planning/fix-retest/symbol-link-command.json').read_text());link[2]=str(out/('glob2-'+label));link[link.index('build/movement-release/src/unit/planning/MovementPlanner.o')]=str(obj);subprocess.run(link,check=True)
 folder=out/label;folder.mkdir(exist_ok=False);cmd=json.loads((out/'causal/command.json').read_text());cmd[0]=link[2];cmd[cmd.index('--output-dir')+1]=str(folder);(folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (folder/'run.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 records[label]=sorted(line for line in (folder/'run.log').read_text().splitlines() if line.startswith('SUGGEST '))
 d=json.loads((folder/'result.json').read_text());print(label,'fields',d['movement_shadow']['planner_fields'],'visited',d['movement_shadow']['planner_visited'],'outputs',len(records[label]),'checksum',d['finalChecksum'],flush=True)
report={'same_suggestions':records['control']==records['shared-goals'],'suggestions_compared':len(records['control']),'limits':'One seed/fixture/K; diagnostic counterfactual, not production implementation. Native timing under compiler contention is excluded.'};(out/'goal-sharing-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(report);assert report['same_suggestions']
