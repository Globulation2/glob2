exec((__import__('pathlib').Path(__file__).parent/'build_probes.py').read_text().split("ai=(root/")[0])
planner=(root/'src/unit/planning/MovementPlanner.cpp').read_text().replace('#include <tuple>','#include <tuple>\n#include <cstdio>')
needle='    const auto here=view.index(request.task.x,request.task.y);'
probe=r'''
    struct FieldObservation { Key key; Uint64 blocks, goals, geometry, supplies; Uint32 tick; };
    struct Probe {
        Uint32 tick=~0u; Uint64 world=0,blocks=0,geometry=0,supplies=0;
        std::array<Uint64,MaterialCount> goals{};
        std::vector<Uint32> masks,amounts;
        std::vector<Uint8> blockers;
        std::vector<Uint16> kinds;
        std::vector<std::tuple<BuildingRef,int,int,int>> buildings;
        std::vector<std::pair<BuildingRef,Uint32>> stock;
        std::vector<FieldObservation> observations;
    };
    static std::array<Probe,Team::MAX_COUNT> probes;
    auto& probe=probes.at(request.task.team);
    if(probe.world!=world.worldIdentity){probe=Probe{};probe.world=world.worldIdentity;}
    if(probe.tick!=world.tick) {
        const auto n=std::size_t(world.width)*world.height;
        const bool initial=probe.masks.size()!=n;
        probe.masks.resize(n);probe.amounts.resize(n);probe.blockers.resize(n);probe.kinds.resize(n);
        Uint32 masksChanged=0,amountsChanged=0,blocksChanged=0,kindsChanged=0,changedMaterials=0;
        for(std::size_t i=0;i<n;++i) {
            const auto mask=MapState::materialMaskAt(view,i);
            const Uint8 block=MapState::resourceBlocksGround(view,i)|(MapState::resourceBlocksAir(view,i)<<1);
            const auto amount=view.resources[i].resource.amount;
            const auto kind=view.resources[i].resource.type;
            masksChanged+=initial || probe.masks[i]!=mask;
            amountsChanged+=initial || probe.amounts[i]!=amount;
            blocksChanged+=initial || probe.blockers[i]!=block;
            kindsChanged+=initial || probe.kinds[i]!=kind;
            changedMaterials|=probe.masks[i]^mask;
            if(!initial && probe.blockers[i]!=block)
                std::fprintf(stderr,"BLOCK_CHANGE tick=%u cell=%zu old_kind=%u new_kind=%u old_block=%u new_block=%u old_amount=%u new_amount=%u\n",world.tick,i,unsigned(probe.kinds[i]),unsigned(kind),unsigned(probe.blockers[i]),unsigned(block),probe.amounts[i],unsigned(amount));
            probe.masks[i]=mask;probe.amounts[i]=amount;probe.blockers[i]=block;probe.kinds[i]=kind;
        }
        if(blocksChanged)++probe.blocks;
        for(unsigned m=0;m<MaterialCount;++m)if(changedMaterials & (1u<<m))++probe.goals[m];
        std::vector<std::tuple<BuildingRef,int,int,int>> buildings;
        std::vector<std::pair<BuildingRef,Uint32>> stock;
        for(const auto& b:world.entities->buildings){buildings.emplace_back(b.identity,b.posX,b.posY,b.typeNum);stock.emplace_back(b.identity,b.availableSupplyMask);}
        const bool geometryChanged=buildings!=probe.buildings,supplyChanged=stock!=probe.stock;
        probe.geometry+=geometryChanged;probe.supplies+=supplyChanged;
        probe.buildings=std::move(buildings);probe.stock=std::move(stock);probe.tick=world.tick;
        std::fprintf(stderr,"SEMANTICS tick=%u resource_generation=%llu amount_cells=%u membership_cells=%u blocker_cells=%u kind_cells=%u geometry_changed=%u supply_changed=%u initial=%u\n",world.tick,(unsigned long long)world.mapGenerations[1],amountsChanged,masksChanged,blocksChanged,kindsChanged,unsigned(geometryChanged),unsigned(supplyChanged),unsigned(initial));
    }
'''
assert needle in planner;planner=planner.replace(needle,probe+'\n'+needle)
needle='            auto field=build(world,request,key);'
probe=r'''
            auto previous=std::find_if(probe.observations.rbegin(),probe.observations.rend(),[&](const auto& old){return old.key.task==key.task && old.key.mode==key.mode;});
            unsigned revisions=0;bool unnecessary=false;
            if(previous!=probe.observations.rend()) {
                const auto& old=previous->key;
                revisions=(old.world!=key.world) | ((old.terrain!=key.terrain)<<1) | ((old.resources!=key.resources)<<2)
                    | ((old.areas!=key.areas)<<3) | ((old.configuration!=key.configuration)<<4) | ((old.structures!=key.structures)<<5);
                const bool resourceGoal=request.mode==Mode::Resource;
                unnecessary=!(revisions & (1|2|8|16)) && previous->blocks==probe.blocks && previous->geometry==probe.geometry
                    && (!resourceGoal || (previous->supplies==probe.supplies && previous->goals==probe.goals.at(request.task.material)));
            }
            const bool cold=previous==probe.observations.rend();
            const auto visitedBefore=metrics.visited;
'''
assert needle in planner;planner=planner.replace(needle,probe+'\n'+needle+r'''
            std::fprintf(stderr,"FIELD tick=%u mode=%u material=%d home=%u target=%u resource_generation=%llu revisions=%u cold=%u inputs_unchanged=%u expanded=%llu\n",world.tick,unsigned(request.mode),request.task.material,unsigned(request.task.attached.gid),unsigned(request.task.target.gid),(unsigned long long)key.resources,revisions,unsigned(cold),unsigned(unnecessary),(unsigned long long)(metrics.visited-visitedBefore));
            probe.observations.push_back({key,probe.blocks,request.mode==Mode::Resource ? probe.goals.at(request.task.material) : 0,probe.geometry,probe.supplies,world.tick});
''')

needle='    if (heap.empty()) ++metrics.noGoals;'
seedprobe=r"""
    struct SeedObservation { Key key; std::vector<std::pair<Uint32,Uint32>> seeds; };
    static std::array<std::vector<SeedObservation>,Team::MAX_COUNT> seedHistory;
    std::vector<std::pair<Uint32,Uint32>> seeds;
    for(Uint32 i=0;i<n;++i)if(field.costs[i]==0)seeds.emplace_back(i,field.destinations[i]);
    auto& history=seedHistory.at(r.task.team);
    const auto same=std::find_if(history.rbegin(),history.rend(),[&](const auto& old) {
        return old.key.world==key.world && old.key.terrain==key.terrain && old.key.resources==key.resources
            && old.key.areas==key.areas && old.key.configuration==key.configuration && old.key.structures==key.structures
            && old.key.mode==key.mode && old.key.task.team==key.task.team && old.key.task.walk==key.task.walk
            && old.key.task.swim==key.task.swim && old.key.task.fly==key.task.fly && old.key.task.material==key.task.material
            && old.seeds==seeds;
    });
    std::fprintf(stderr,"SEEDS tick=%u mode=%u home=%u resource_generation=%llu cells=%zu duplicate=%u other_home=%u\n",world.tick,unsigned(r.mode),unsigned(r.task.attached.gid),(unsigned long long)key.resources,seeds.size(),unsigned(same!=history.rend()),unsigned(same!=history.rend() && same->key.task.attached!=key.task.attached));
    history.push_back({key,std::move(seeds)});
"""
planner=planner.replace(needle,seedprobe+'\n'+needle)

shadow=(root/'src/unit/planning/MovementShadow.cpp').read_text().replace('#include <tuple>','#include <tuple>\n#include <cstdio>')
shadow=shadow.replace('    const auto start=Clock::now();\n    auto batch=std::make_unique<Batch>();','    const auto start=Clock::now();\n    auto phaseStart=start;std::array<Uint64,6> phase{};\n    auto phaseEnd=[&](unsigned p){const auto now=Clock::now();phase[p]+=std::chrono::duration_cast<std::chrono::nanoseconds>(now-phaseStart).count();phaseStart=now;};\n    auto batch=std::make_unique<Batch>();')
shadow=shadow.replace('    for(const auto& unit:world.entities->units) {','    phaseEnd(0);\n    for(const auto& unit:world.entities->units) {')
shadow=shadow.replace('    std::sort(live.begin(),live.end());','    phaseEnd(1);\n    std::sort(live.begin(),live.end());')
shadow=shadow.replace('    std::vector<ComputeExecutor::Group> groups;','    phaseEnd(2);\n    std::vector<ComputeExecutor::Group> groups;')
shadow=shadow.replace('    if(!groups.empty()) {','    phaseEnd(3);\n    if(!groups.empty()) {')
shadow=shadow.replace('    admissionNs+=elapsed(start);peakBytes=std::max(peakBytes,retainedBytes());','    phaseEnd(4);\n    admissionNs+=elapsed(start);peakBytes=std::max(peakBytes,retainedBytes());\n    phaseEnd(5);\n    std::fprintf(stderr,"ADMISSION tick=%u setup_ns=%llu scan_ns=%llu prune_ns=%llu pack_ns=%llu submit_ns=%llu accounting_ns=%llu units=%zu\\n",world.tick,(unsigned long long)phase[0],(unsigned long long)phase[1],(unsigned long long)phase[2],(unsigned long long)phase[3],(unsigned long long)phase[4],(unsigned long long)phase[5],world.entities->units.size());')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(compile_file,'src/unit/planning/MovementPlanner.cpp',out/'MovementPlanner-probe.o',planner),pool.submit(compile_file,'src/unit/planning/MovementShadow.cpp',out/'MovementShadow-probe.o',shadow)]
 replacements=dict(f.result() for f in futures)
link=json.loads((root/'artifacts/movement-planning/fix-retest/symbol-link-command.json').read_text());link[2]=str(out/'glob2-causal-probe')
for relative,obj in replacements.items():link[link.index('build/movement-release/'+relative[:-4]+'.o')]=str(obj)
(out/'causal-link-command.json').write_text(json.dumps(link,indent=2)+'\n');subprocess.run(link,check=True)
print('Native causal probe ready',flush=True)
