exec((__import__('pathlib').Path(__file__).parent/'build_probes.py').read_text().split("ai=(root/")[0])
source=(root/'src/unit/planning/MovementShadow.cpp').read_text()
needle='''    std::vector<Uint16> live; live.reserve(world.entities->units.size());
    for(const auto& unit:world.entities->units) {
        live.push_back(unit.gid);
        auto& actor=actors[unit.gid];'''
replacement='''    auto current=actors.begin();
    for(const auto& unit:world.entities->units) {
        // Captures retain ascending global slot order.
        while(current!=actors.end() && current->first<unit.gid)current=actors.erase(current);
        if(current==actors.end() || current->first!=unit.gid)current=actors.try_emplace(current,unit.gid);
        auto& actor=(current++)->second;'''
assert needle in source;source=source.replace(needle,replacement)
needle='''    std::sort(live.begin(),live.end());
    for(auto it=actors.begin();it!=actors.end();) {
        if(!std::binary_search(live.begin(),live.end(),it->first))it=actors.erase(it);else ++it;
    }'''
assert needle in source;source=source.replace(needle,'    actors.erase(current,actors.end());')
source=source.replace('        if(modeOf(unit)==Mode::Pursuit)capturePursuitTarget(task,world);','        const auto mode=modeOf(unit);\n        if(mode==Mode::Pursuit)capturePursuitTarget(task,world);').replace('        auto mode=modeOf(unit); if(!mode)continue;','        if(!mode)continue;')
_,obj=compile_file('src/unit/planning/MovementShadow.cpp',out/'MovementShadow-iteration.o',source)
records={};control=sorted(line for line in (out/'control/run.log').read_text().splitlines() if line.startswith('SUGGEST '))
for label,planner in [('owner-iteration',out/'Planner-trace-control.o'),('combined',out/'Planner-trace-shared.o')]:
 link=json.loads((root/'artifacts/movement-planning/fix-retest/symbol-link-command.json').read_text());link[2]=str(out/('glob2-'+label));link[link.index('build/movement-release/src/unit/planning/MovementShadow.o')]=str(obj);link[link.index('build/movement-release/src/unit/planning/MovementPlanner.o')]=str(planner);subprocess.run(link,check=True)
 folder=out/label;folder.mkdir(exist_ok=False);cmd=json.loads((out/'causal/command.json').read_text());cmd[0]=link[2];cmd[cmd.index('--output-dir')+1]=str(folder);(folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (folder/'run.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 lines=sorted(line for line in (folder/'run.log').read_text().splitlines() if line.startswith('SUGGEST '));d=json.loads((folder/'result.json').read_text());records[label]={'same_suggestions':lines==control,'suggestions':len(lines),'fields':d['movement_shadow']['planner_fields'],'visited':d['movement_shadow']['planner_visited'],'checksum':d['finalChecksum']};print(label,records[label],flush=True);assert lines==control
(out/'owner-iteration-comparison.json').write_text(json.dumps(records,indent=2)+'\n')
# Profile the owner candidate without per-suggestion printing.
link=json.loads((out/'window-link-command.json').read_text());link[2]=str(out/'glob2-owner-window');link[link.index(str(out/'MovementShadow-debug.o'))]=str(obj);subprocess.run(link,check=True)
folder=out/'late-owner-candidate';folder.mkdir(exist_ok=False)
cmd=json.loads((out/'late-shadow/command.json').read_text());cmd[cmd.index(str(out/'glob2-window-profile'))]=link[2];cmd[cmd.index('--output-dir')+1]=str(folder);cmd=[('--callgrind-out-file='+str(folder/'callgrind.out.%p')) if arg.startswith('--callgrind-out-file=') else ('--log-file='+str(folder/'valgrind.log')) if arg.startswith('--log-file=') else arg for arg in cmd];(folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (folder/'run.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
print('Owner candidate Callgrind exit',r.returncode,flush=True)
