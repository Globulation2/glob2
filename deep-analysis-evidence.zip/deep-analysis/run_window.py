import json,subprocess
from pathlib import Path
root=Path.cwd();out=root/'artifacts/movement-planning/deep-analysis'
for variant,k in [('reference',0),('shadow',1)]:
 folder=out/('late-'+variant);folder.mkdir(exist_ok=False)
 cmd=['valgrind','--tool=callgrind','--instr-atstart=no','--separate-threads=yes','--callgrind-out-file='+str(folder/'callgrind.out.%p'),'--log-file='+str(folder/'valgrind.log'),str(out/'glob2-window-profile'),'game','run','--load-game',str(root/'artifacts/movement-planning/fixtures/large-colony.game'),'--ticks','128','--gradient-backend','cpu','--compute-threads','4','--output-dir',str(folder)]
 cmd+=['--movement-profile'] if k==0 else ['--movement-shadow','1']
 (folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (folder/'run.log').open('w') as log:completed=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 print(variant,'exit',completed.returncode,flush=True)
 if completed.returncode:break
