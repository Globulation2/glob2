from pathlib import Path
import json,collections,hashlib,platform
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
r=json.loads((p/'causal-data.json').read_text());seeds=r['SEEDS'];fields=r['FIELD'];assert len(seeds)==len(fields)==1086
for seed,field in zip(seeds,fields):assert all(seed[k]==field[k] for k in ['tick','mode','home','resource_generation'])
duplicates=sum(s['duplicate'] for s in seeds);duplicate_expanded=sum(f['expanded'] for s,f in zip(seeds,fields) if s['duplicate']);owner=json.loads((p/'owner-instructions-comparison.json').read_text());control=json.loads((p/'control/result.json').read_text());shared=json.loads((p/'shared-goals/result.json').read_text());candidate=json.loads((p/'owner-iteration-comparison.json').read_text())
summary={'source_revision':'3a3917757752fe64a2af9c1dc964c074794ebf3e','platform':platform.platform(),'ticks':128,'seed':713,'participants':4,'delay':1,'field_counts_by_mode':{'resource':258,'building':828},'field_miss_causes':{'first_goal':128,'resource_revision_changed':958},'semantically_unchanged_rebuilds':sum(f['inputs_unchanged'] for f in fields),'observed_block_changes':126,'block_change_detail':'126 wheat cells became empty on harvest; no observed additions in the captured planning inputs. Wheat blocks ground movement.','same_goal_resource_duplicates':duplicates,'duplicate_field_expanded_cells':duplicate_expanded,'goal_sharing':json.loads((p/'goal-sharing-comparison.json').read_text()),'owner_candidate':candidate,'owner_instructions':owner,'late_window':{'start_tick':64,'end_tick':127,'unit_scans':65536,'requests':3154,'units_per_request':65536/3154,'unit_view_bytes':384,'task_bytes':88,'unit_view_payload_bytes_per_tick':1024*384},'snapshot_capture_late_inclusive_Ir':{'reference':9526744,'shadow':27875882},'native_wall_phase_measurements':'Discarded for performance inference: unrelated compiler jobs were consuming multiple cores during collection. Instruction counts and output comparisons retained.','limits':['One preliminary colony seed and K=1','Probe-only source copies; production branch unchanged','No reliable new wall-time speedup, gate pass or memory-ceiling claim','Owner candidate depends on captured ascending GID order; lifecycle/slot-reuse and platform suites required before promotion','Goal-sharing candidate needs market/supplier and depletion tests before promotion','Profiling enables instrumentation at tick 64; includes the tail of work submitted before the window and final draining'],'suggestion_outputs_compared':7676}
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(1,3,figsize=(13,4.8))
a=axs[0];values=[owner['before']['inclusive_Ir']/1e6,owner['after']['inclusive_Ir']/1e6];a.bar([0,1],values,color=['#888888','#00876c'],width=.6)
for i,v in enumerate(values):a.text(i,v+1,f'{v:.2f} M',ha='center')
a.set(xticks=[0,1],xticklabels=['Current','Ordered traversal'],ylim=(0,61),ylabel='Boundary instructions (millions)',title='Owner traversal\n43.8% fewer instructions');a.grid(axis='y',alpha=.15);a.set_axisbelow(True)
a=axs[1];a.bar([0,1],[828,828],color='#2166ac',label='Building fields');a.bar([0,1],[16,16],bottom=[828,828],color='#00876c',label='Distinct resource fields');a.bar([0,1],[242,0],bottom=[844,844],color='#bd6318',label='Duplicate resource fields')
for i,v in enumerate([1086,844]):a.text(i,v+20,str(v),ha='center')
a.set(xticks=[0,1],xticklabels=['Current','Shared effective\ngoals'],ylim=(0,1250),ylabel='Fields built over 128 ticks',title='Effective goal sharing\n242 field builds removed');a.grid(axis='y',alpha=.15);a.set_axisbelow(True);a.legend(fontsize=8,frameon=False,loc='upper right')
a=axs[2];a.bar([0,1],[65536,3154],color=['#888888','#2166ac'],width=.6)
for i,v in enumerate([65536,3154]):a.text(i,v+1600,f'{v:,}',ha='center')
a.set(xticks=[0,1],xticklabels=['Units scanned','Requests submitted'],ylim=(0,76000),ylabel='Count during ticks 64–127',title='Admission still scans every unit\n20.8 scans per request');a.grid(axis='y',alpha=.15);a.set_axisbelow(True)
fig.suptitle('Deeper profiling finds two more concrete optimization candidates',fontsize=16,fontweight='bold',y=.98)
fig.text(.02,.025,'Isolated experiments · 1,024-worker colony · K=1 · all 7,676 suggestions match the control · instruction/work counts, not wall-time speedup',fontsize=9,color='#555555');fig.subplots_adjust(top=.73,bottom=.19,left=.055,right=.99,wspace=.5)
for ext in ['png','svg','pdf']:fig.savefig(p/('deep-findings.'+ext),dpi=175)
print(json.dumps(summary,indent=2))
