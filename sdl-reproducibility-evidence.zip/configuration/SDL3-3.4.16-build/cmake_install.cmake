# Install script for directory: /tmp/glob2-sdl3/sources/SDL3-3.4.16

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/tmp/glob2-sdl3/prefix")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/pkgconfig" TYPE FILE FILES "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/sdl3.pc")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  foreach(file
      "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libSDL3.so.0.4.16"
      "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libSDL3.so.0"
      )
    if(EXISTS "${file}" AND
       NOT IS_SYMLINK "${file}")
      file(RPATH_CHECK
           FILE "${file}"
           RPATH "\$ORIGIN")
    endif()
  endforeach()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/libSDL3.so.0.4.16"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/libSDL3.so.0"
    )
  foreach(file
      "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libSDL3.so.0.4.16"
      "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libSDL3.so.0"
      )
    if(EXISTS "${file}" AND
       NOT IS_SYMLINK "${file}")
      file(RPATH_CHANGE
           FILE "${file}"
           OLD_RPATH ":::::::"
           NEW_RPATH "\$ORIGIN")
      if(CMAKE_INSTALL_DO_STRIP)
        execute_process(COMMAND "/usr/bin/strip" "${file}")
      endif()
    endif()
  endforeach()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/libSDL3.so")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3/SDL3headersTargets.cmake")
    file(DIFFERENT _cmake_export_file_changed FILES
         "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3/SDL3headersTargets.cmake"
         "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/CMakeFiles/Export/35815d1d52a6ea1175d74784b559bdb6/SDL3headersTargets.cmake")
    if(_cmake_export_file_changed)
      file(GLOB _cmake_old_config_files "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3/SDL3headersTargets-*.cmake")
      if(_cmake_old_config_files)
        string(REPLACE ";" ", " _cmake_old_config_files_text "${_cmake_old_config_files}")
        message(STATUS "Old export file \"$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3/SDL3headersTargets.cmake\" will be replaced.  Removing files [${_cmake_old_config_files_text}].")
        unset(_cmake_old_config_files_text)
        file(REMOVE ${_cmake_old_config_files})
      endif()
      unset(_cmake_old_config_files)
    endif()
    unset(_cmake_export_file_changed)
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3" TYPE FILE FILES "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/CMakeFiles/Export/35815d1d52a6ea1175d74784b559bdb6/SDL3headersTargets.cmake")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3/SDL3sharedTargets.cmake")
    file(DIFFERENT _cmake_export_file_changed FILES
         "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3/SDL3sharedTargets.cmake"
         "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/CMakeFiles/Export/35815d1d52a6ea1175d74784b559bdb6/SDL3sharedTargets.cmake")
    if(_cmake_export_file_changed)
      file(GLOB _cmake_old_config_files "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3/SDL3sharedTargets-*.cmake")
      if(_cmake_old_config_files)
        string(REPLACE ";" ", " _cmake_old_config_files_text "${_cmake_old_config_files}")
        message(STATUS "Old export file \"$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3/SDL3sharedTargets.cmake\" will be replaced.  Removing files [${_cmake_old_config_files_text}].")
        unset(_cmake_old_config_files_text)
        file(REMOVE ${_cmake_old_config_files})
      endif()
      unset(_cmake_old_config_files)
    endif()
    unset(_cmake_export_file_changed)
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3" TYPE FILE FILES "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/CMakeFiles/Export/35815d1d52a6ea1175d74784b559bdb6/SDL3sharedTargets.cmake")
  if(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Rr][Ee][Ll][Ee][Aa][Ss][Ee])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3" TYPE FILE FILES "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/CMakeFiles/Export/35815d1d52a6ea1175d74784b559bdb6/SDL3sharedTargets-release.cmake")
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/SDL3" TYPE FILE FILES
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/SDL3Config.cmake"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/SDL3ConfigVersion.cmake"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/SDL3" TYPE FILE FILES
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_assert.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_asyncio.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_atomic.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_audio.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_begin_code.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_bits.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_blendmode.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_camera.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_clipboard.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_close_code.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_copying.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_cpuinfo.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_dialog.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_dlopennote.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_egl.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_endian.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_error.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_events.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_filesystem.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_gamepad.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_gpu.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_guid.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_haptic.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_hidapi.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_hints.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_init.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_intrin.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_iostream.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_joystick.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_keyboard.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_keycode.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_loadso.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_locale.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_log.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_main.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_main_impl.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_messagebox.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_metal.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_misc.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_mouse.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_mutex.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_oldnames.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_opengl.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_opengl_glext.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_opengles.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_opengles2.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_opengles2_gl2.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_opengles2_gl2ext.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_opengles2_gl2platform.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_opengles2_khrplatform.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_pen.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_pixels.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_platform.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_platform_defines.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_power.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_process.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_properties.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_rect.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_render.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_scancode.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_sensor.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_stdinc.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_storage.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_surface.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_system.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_thread.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_time.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_timer.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_touch.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_tray.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_version.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_video.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16/include/SDL3/SDL_vulkan.h"
    "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/include-revision/SDL3/SDL_revision.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/licenses/SDL3" TYPE FILE FILES "/tmp/glob2-sdl3/sources/SDL3-3.4.16/LICENSE.txt")
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
if(CMAKE_INSTALL_COMPONENT)
  if(CMAKE_INSTALL_COMPONENT MATCHES "^[a-zA-Z0-9_.+-]+$")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INSTALL_COMPONENT}.txt")
  else()
    string(MD5 CMAKE_INST_COMP_HASH "${CMAKE_INSTALL_COMPONENT}")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INST_COMP_HASH}.txt")
    unset(CMAKE_INST_COMP_HASH)
  endif()
else()
  set(CMAKE_INSTALL_MANIFEST "install_manifest.txt")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/tmp/glob2-sdl3/sources/SDL3-3.4.16-build/${CMAKE_INSTALL_MANIFEST}"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
