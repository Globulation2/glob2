# Native SDL dependency reconstruction

This read-only audit identifies the dependency source and configuration behind the
Linux resource-refactor validation libraries. No dependency was rebuilt or changed.
The patched SDL library used by both frozen arms is
`libSDL3.so.0.4.16`, SHA256
`ec183207ffb99e6273d6260b7fa2a515706209a5a8e043196019a01867af9228`.

## Available rebuild inputs

- The two installed `sdl3-manifest.json` files retain upstream archive URLs and
  exact SHA256 hashes: SDL 3.4.16, image 3.4.6, ttf 3.2.2, net 3.2.0 and WebP 1.6.0.
- `repository-inputs/` contains the pinned download/build helper, version lock,
  and repository patches. These are public in Globulation2/glob2; the PNG change
  was introduced in commit `42df42802f0a7ed8729fb221d5de419657aed2b3`:
  https://github.com/Globulation2/glob2/commit/42df42802f0a7ed8729fb221d5de419657aed2b3
  The helper and lock have no differences from that commit at audit time.
- `archive-source-changes.patch` is the complete observed delta between the
  checksum-verified release archives and retained source trees. It includes the
  three SDL fixes, ttf kerning fix, image linker quoting adjustment, and net helper
  portability rename. WebP has no changes. All archive files were compared; none
  were missing and there were no extra source files. The extracted source trees
  are release archives, not Git working trees; upstream `.git-hash` values, where
  present, are recorded in `manifest.json`.
- Applying the aggregate patch to fresh copies of the affected archive files
  reproduced every changed retained source file exactly. `patch-verification.txt`
  records that artifact-only check.
- `configuration/` retains the five CMake caches, compiler identification,
  per-target compile flags/link commands, install scripts and install manifests.
  Native configuration was Release, Unix Makefiles, `/usr/bin/cc`, GCC
  15.2.0 (Ubuntu 15.2.0-16ubuntu1), CMake 4.2.3, `-O3 -DNDEBUG`, shared SDL libraries,
  static WebP and install RUNPATH `$ORIGIN`. Consult the caches for all detected
  system features and dependency paths rather than treating this summary as exhaustive.
- `current-system-packages.tsv`, `os-release` and tool version output describe
  the audit host. The package inventory was collected during this audit, not
  retrospectively at the original build time.

## Safe fresh rebuild

Use a fresh directory, never either prefix used by an active validation campaign.
On a Linux x86_64 environment matching the recorded compiler/development packages:

```sh
BUNDLE=/absolute/path/to/extracted/sdl-reproducibility
WORK=/absolute/path/to/new-sdl-rebuild
mkdir -p "$WORK"
python3 "$BUNDLE/repository-inputs/scons/sdl3_dependencies.py" \
  --prefix "$WORK/prefix" --work "$WORK/sources" --jobs 8
```

The helper downloads and validates the pinned archives, applies the included
patches, and supplies the build configuration. Do not separately apply the
aggregate audit patch when using the helper. Compare the resulting CMake caches
with `configuration/`, accounting for relocated source/install paths. Point both
benchmark arms at the same rebuilt prefix with `GLOB2_SDL3_PREFIX` when building
and `LD_LIBRARY_PATH="$WORK/prefix/lib"` when running; retain the new runtime hashes.

The older `/tmp/glob2-sdl3/prefix` lacks only the PNG patch in its manifest. Its
image/net/ttf library bytes match the patched prefix exactly. The tested loader
resolves all four SDL libraries from the patched prefix first; the older prefix
is a fallback path. If the older unpatched SDL variant is specifically needed,
use the parent of the PNG commit's helper and patches, which omit that PNG fix,
in another fresh directory. Do not mix variants within a paired campaign.

## Binding retained build output to the tested library

The retained SDL build output has SHA256
`297e6408a842ecd3a60386fd832f1acf83a91896c9b6337a19036908d76cfc40`.
Its install script changes a single seven-byte RUNPATH placeholder `:::::::` to
`$ORIGIN`. Making only that substitution in memory yields bytes identical to the
installed patched library and its hash above. The install manifest points to the
patched prefix even though the original cache's default install prefix remains
the older path; this records installation with a prefix override. No unexplained
binary differences remain between this retained build output and the tested SDL.

## Limits

This is source/configuration reconstruction evidence, not a performed clean rebuild
or a claim of bit-for-bit reproducibility on a different host. The complete original
build environment and historical system-header package snapshot were not recorded
when these libraries were first built. CMake caches and current package versions
recover the available configuration; a reviewer must retain any differences in a
fresh environment and rerun matching checks. The existing paired-run manifests
remain authoritative for the actual loaded library bytes. System transitive
libraries are identified in those runtime manifests; their source packages are not
vendored here. No new patch or production change is required.
