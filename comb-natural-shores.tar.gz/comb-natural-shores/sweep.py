from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,json,random
out=Path('artifacts/comb-natural-shores/sweep');out.mkdir(exist_ok=True)
binary=str(Path('build/linux/client/debug/dev-dev_fast-true-linker-auto/src/glob2').resolve())
cases=[]
for w,h,teams in [(256,256,4),(512,256,4),(256,512,4),(512,512,8)]:
 for peninsulas in [2,3,4]:
  for wheat,wood in [(0,0),(0,300),(300,0),(300,300),(100,100)]:
   k=len(cases);amount=300 if k%2 else 0
   cases.append(dict(w=w,h=h,teams=teams,workers=1 if k%2 else 8,seed=101+k,options={'peninsulas':peninsulas,'wheat-amount':wheat,'wood-amount':wood,'stone-amount':amount,'fruit-amount':amount,'algae-amount':amount}))
rng=random.Random(1337)
for k in range(32):
 w,h=rng.choice([(256,256),(512,256),(256,512),(512,512)])
 cases.append(dict(w=w,h=h,teams=rng.randint(2,8 if w==h==512 else 4),workers=rng.randint(1,8),seed=1001+k,options={'peninsulas':rng.randint(2,4),**{name+'-amount':rng.randrange(13)*25 for name in ['wheat','wood','stone','fruit','algae']}}))
(out/'requests.json').write_text(json.dumps(cases,indent=2))
def run(item):
 k,c=item;name=f'{k:03d}';cmd=[binary,'map','generate','comb','--seed',str(c['seed']),'--width',str(c['w']),'--height',str(c['h']),'--teams',str(c['teams']),'--workers',str(c['workers']),'--report-file',str(out/(name+'.json'))]
 for key,value in c['options'].items():cmd+=['--set',f'{key}={value}']
 with (out/(name+'.log')).open('w') as log:
  try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 return {'case':k,'returncode':code}
with ThreadPoolExecutor(max_workers=4) as pool:
 results=list(pool.map(run,enumerate(cases)))
(out/'results.json').write_text(json.dumps(results,indent=2));bad=[r for r in results if r['returncode']]
print('Cases:',len(results),'failures:',len(bad),bad,flush=True)
