from PIL import Image
from collections import deque
import numpy as np
import sys,json

def analyse(path):
 im=np.array(Image.open(path).convert('RGB'));h,w=im.shape[:2]
 water=np.all(im==[0,64,255],axis=2)|np.all(im==[0,255,255],axis=2)
 pure=water&np.roll(water,-1,0)&np.roll(water,-1,1)&np.roll(np.roll(water,-1,0),-1,1)
 seen=np.zeros((h,w),bool);components=[]
 for y,x in zip(*np.where(pure)):
  if seen[y,x]:continue
  q=deque([(y,x)]);seen[y,x]=1;cells=[]
  while q:
   cy,cx=q.popleft();cells.append((cy,cx))
   for dy,dx in [(0,1),(0,-1),(1,0),(-1,0)]:
    ny,nx=(cy+dy)%h,(cx+dx)%w
    if pure[ny,nx] and not seen[ny,nx]:seen[ny,nx]=1;q.append((ny,nx))
  components.append(cells)
 inlet=sorted(components,key=len)[-2];reach=np.zeros((h,w),bool)
 for y,x in inlet:reach[y,x]=1
 crops={name:np.all(im==color,axis=2) for name,color in [('wheat',[255,255,0]),('wood',[0,64,0])]}
 counts={}
 for d in range(7):
  counts[d]={name:int((reach&mask).sum()) for name,mask in crops.items()}
  reach=np.logical_or.reduce([np.roll(np.roll(reach,dy,0),dx,1) for dy in [-1,0,1] for dx in [-1,0,1]])
 patch_counts={}
 for name,mask in {**crops,'combined':crops['wheat']|crops['wood']}.items():
  remaining=set(map(tuple,np.argwhere(mask&reach)));sizes=[]
  while remaining:
   todo=[remaining.pop()];size=0
   while todo:
    cy,cx=todo.pop();size+=1
    for dy in [-1,0,1]:
     for dx in [-1,0,1]:
      nxt=(cy+dy,cx+dx)
      if nxt in remaining:remaining.remove(nxt);todo.append(nxt)
   sizes.append(size)
  patch_counts[name]={'count':len(sizes),'tiles':sum(sizes)}
 return {'depth':counts,'patches':patch_counts}
if __name__=='__main__':
 for path in sys.argv[1:]:print(path,json.dumps(analyse(path)))
