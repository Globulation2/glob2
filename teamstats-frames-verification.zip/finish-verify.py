import os,time,subprocess,json
from pathlib import Path
root=Path('artifacts/teamstats/frames')
base=['python3','test/run_tests.py','--build-dir','build/darwin/client/debug/dev-dev_fast-true-linker-auto','--binary','all','--no-display','--timeout','600','-j','2']
with open(root/'repair-and-boundaries.log','w') as out:
 subprocess.run(base+['--filter','TeamStatsSave/32 sampling phases*','--filter','MatchSetup/*','--filter','ReplayStepCounter/*','--junit',str(root/'repair-and-boundaries.xml')],stdout=out,stderr=subprocess.STDOUT,check=True)
for update in [True,False]:
 name='golden-update' if update else 'golden-verify'
 with open(root/(name+'.log'),'w') as out:subprocess.run(base+['--filter','TurnEngineHarness/the committed*','--junit',str(root/(name+'.xml'))]+(['--update-fixtures'] if update else []),stdout=out,stderr=subprocess.STDOUT,check=True)
while 'scons: done building targets.' not in Path('/tmp/stats-frames-final-release-build.log').read_text():
 if 'scons: building terminated' in Path('/tmp/stats-frames-final-release-build.log').read_text():raise RuntimeError('release failed')
 time.sleep(2)
args=json.loads(Path('artifacts/teamstats/efficient/release-integrated-link-args.json').read_text());args[2]=str(root/'glob2-engine-tests');subprocess.run(args,check=True)
(root/'release/test').mkdir(parents=True,exist_ok=True)
link=root/'release/test/glob2-engine-tests'
if not link.exists():link.symlink_to('../../glob2-engine-tests')
with open(root/'release-correctness.log','w') as out:
 subprocess.run(['python3','test/run_tests.py','--build-dir',str(root/'release'),'--binary','engine','--no-display','--timeout','600','-j','2']+sum((['--filter',x+'/*'] for x in ['WorldSnapshot','TeamStatsPipeline','TeamStatsSave','AIPipeline']),[])+['--junit',str(root/'release-correctness.xml')],stdout=out,stderr=subprocess.STDOUT,check=True)
(root/'verification-ready').write_text('passed\n')
