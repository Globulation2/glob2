from pathlib import Path
import json,statistics,collections
root=Path('artifacts/teamstats/frames');rows=json.loads((root/'profiles.json').read_text())
summary=[];groups=collections.defaultdict(list)
for r in rows:
 parts=r['file'].split('-');kind,name,prof=parts[:3]
 key=(kind,name,prof,r.get('mode',''),r.get('ai',''),r.get('teams',0),r.get('workers',0),r['delay'])
 groups[key].append(r)
for key,rs in sorted(groups.items()):
 kind,name,prof,mode,ai,teams,workers,delay=key
 out=dict(kind=kind,binary=name,profiling=prof,mode=mode,ai=ai,teams=teams,workers=workers,delay=delay,trials=len(rs))
 for k in rs[0]:
  if k.endswith('_ns'):out[k.replace('_ns','_us_per_tick')]=statistics.median(r[k]/r['ticks']/1000 for r in rs)
 out['peak_leased_bytes']=max(r['peak_leased_bytes'] for r in rs)
 out['checksums']=sorted(set(r['checksum'] for r in rs));summary.append(out)
(root/'medians.json').write_text(json.dumps(summary,indent=2)+'\n')
# Profiling and readiness must not alter the final checksum for a fixed binary/configuration.
checks=collections.defaultdict(set)
for r in rows:
 if r['file'].startswith('advancing-'):
  name=r['file'].split('-')[1];checks[(name,r['ai'],r['teams'],r['workers'],r['delay'])].add(r['checksum'])
assert all(len(v)==1 for v in checks.values())
for name,ai,teams,workers,delay in checks:
 assert checks[(name,ai,teams,0,delay)]==checks[(name,ai,teams,2,delay)]
traces=collections.defaultdict(list)
for line in (root/'advancing-traces.log').read_text().splitlines():
 if line.startswith('STATS_TRACE '):
  r={k:int(v) for k,v in (s.split('=',1) for s in line.split()[1:])};traces[(r['ai'],r['teams'],r['delay'],r['workers'])].append((r['tick'],r['checksum']))
assert len(traces)==32
for key,trace in traces.items():
 assert len(trace)==520
 assert trace==traces[key[:3]+(0,)]
(root/'checksums.txt').write_text('32 configurations x 520 source ticks = 16640 full checksum records; all 16 zero/two-worker pairs match.\nAll profiling on/off and repeated-trial final checksums match within each binary/workload/delay.\n')
for r in summary:
 if r['profiling']=='profile1' and r['binary'] in ['before','after'] and ((r['kind']=='static' and r['mode']=='snapshot_delayed') or (r['kind']=='advancing' and r['workers']==2 and r['ai']=='numbi-castor' and r['delay']==8)):
  print(r)
