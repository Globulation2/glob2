import os,subprocess,json,time
from pathlib import Path
root=Path('artifacts/teamstats/frames')
while not (root/'verification-ready').exists():time.sleep(2)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_PERF_DISABLE='1',GLOB2_STATS_BENCHMARK='1',GLOB2_STATS_BENCHMARK_TICKS='2048',GLOB2_USER_DATA_DIR=str((root/'profile-user').resolve()))
for trial in range(5):
 for prof in [1,0]:
  e=dict(env,GLOB2_STATS_PROFILE=str(prof))
  for name in ['before','after']:
   binary=str((root/('before-engine-tests' if name=='before' else 'glob2-engine-tests')).resolve())
   for case,label in [('pipeline versus*','static'),('advancing match statistics timing*','advancing')]:
    with open(root/f'{label}-{name}-profile{prof}-{trial}.log','w') as out:
     subprocess.run([binary,'--test-suite=TeamStatsPipeline','--test-case='+case],env=e,stdout=out,stderr=subprocess.STDOUT,check=True)
with open(root/'advancing-traces.log','w') as out:
 subprocess.run([str((root/'glob2-engine-tests').resolve()),'--test-suite=TeamStatsPipeline','--test-case=advancing match statistics timing*'],env=dict(env,GLOB2_STATS_PROFILE='0',GLOB2_STATS_BENCHMARK_TICKS='520',GLOB2_STATS_BENCHMARK_CHECKSUM='1'),stdout=out,stderr=subprocess.STDOUT,check=True)
rows=[]
for path in root.glob('*-profile*-*.log'):
 for line in path.read_text().splitlines():
  if line.startswith(('STATS_BENCH ','STATS_ADVANCING ')):
   row=dict(x.split('=',1) for x in line.split()[1:]);row={k:int(v) if v.isdigit() else v for k,v in row.items()};row['file']=path.name;rows.append(row)
(root/'profiles.json').write_text(json.dumps(rows,indent=2)+'\n')
(root/'profiles-ready').write_text('passed\n')
