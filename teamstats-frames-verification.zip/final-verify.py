import subprocess,json,time
from pathlib import Path
root=Path('artifacts/teamstats/frames')
for kind in ['debug','release']:
 p=Path('/tmp/stats-frames-final-'+kind+'-build2.log')
 while 'scons: done building targets.' not in p.read_text():
  if 'scons: building terminated' in p.read_text():raise RuntimeError(kind+' build failed')
  time.sleep(2)
base=['python3','test/run_tests.py','--build-dir','build/darwin/client/debug/dev-dev_fast-true-linker-auto','--binary','all','--no-display','--timeout','600','-j','2']
with open(root/'final-native.log','w') as out:
 subprocess.run(base+sum((['--filter',x+'/*'] for x in ['TeamStatsPipeline','ReadOnlyPhase','WorldSnapshot','ComputeExecutor','SharedWorkerLifecycle','MatchSetup','ReplayStepCounter']),[])+['--filter','TeamStatsSave/32 sampling phases*','--filter','TurnEngineHarness/the committed*','--junit',str(root/'final-native.xml')],stdout=out,stderr=subprocess.STDOUT,check=True)
args=json.loads(Path('artifacts/teamstats/efficient/release-integrated-link-args.json').read_text());args[2]=str(root/'glob2-engine-tests');subprocess.run(args,check=True)
with open(root/'final-release.log','w') as out:
 subprocess.run(['python3','test/run_tests.py','--build-dir',str(root/'release'),'--binary','engine','--no-display','--timeout','600','-j','2']+sum((['--filter',x+'/*'] for x in ['WorldSnapshot','TeamStatsPipeline','TeamStatsSave','AIPipeline']),[])+['--junit',str(root/'final-release.xml')],stdout=out,stderr=subprocess.STDOUT,check=True)
(root/'verification-ready').write_text('passed\n')
