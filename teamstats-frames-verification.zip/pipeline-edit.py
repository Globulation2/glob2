from pathlib import Path
p=Path('src/team/stats/TeamStatsPipeline.h');s=p.read_text().replace('\tstruct Pending\n','\tstruct Pending;\n\tstruct Work { Pending* batch; unsigned team; };\n\tstruct Pending\n');s=s.replace('\t\tstd::vector<unsigned> phases;','\t\tstd::vector<unsigned> phases;\n\t\tstd::vector<Work> work;\n\t\tstd::vector<ComputeExecutor::Group> groups;\n\t\tstd::vector<std::shared_ptr<GameplayMeasurements>>* previous = nullptr;');s=s.replace('\tstd::vector<unsigned> phases;\n\tstatic void compute','\tstd::vector<unsigned> phases;\n\t// Each team lane alone accesses its continuation. Initialized before submission/restored after joins.\n\tstd::vector<std::shared_ptr<GameplayMeasurements>> previous;\n\tstatic void compute');p.write_text(s)
p=Path('src/team/stats/TeamStatsPipeline.cpp');s=p.read_text().replace('void TeamStatsPipeline::compute(void *context, size_t team)','void TeamStatsPipeline::compute(void *context, size_t)');s=s.replace('auto &batch = *static_cast<Pending *>(context);','auto &work = *static_cast<Work *>(context);\n    auto &batch = *work.batch;\n    const auto team = work.team;')
s=s.replace('batch.samples[team] =\n\t\t\tcomputeTeamStatsSample(snapshot, unsigned(team), batch.phases[team] == 31,\n                batch.smoothingWindows[team], true);','''auto storage = std::move(batch.samples[team].frame);
        auto sample = computeTeamStatsSample(snapshot, team, batch.phases[team] == 31,
                                            batch.smoothingWindows[team], true);
        TeamStats::completeMeasurements(sample, *(*batch.previous)[team]);
        if (!storage || !storage.unique()) storage=std::make_shared<GameplayMeasurements>();
        *storage=std::move(sample.measurements);
        sample.frame=std::move(storage);
        (*batch.previous)[team]=sample.frame;
        batch.samples[team]=std::move(sample);''')
s=s.replace('stats.applySample(std::move(batch.samples[t]), batch.due,','stats.publishFrame(batch.samples[t], batch.due,')
s=s.replace('if (phases.empty())\n\t\tfor (int t = 0; t < game.teamsCount(); ++t)\n\t\t\tphases.push_back(game.teams[t]->stats.samplingPhase());','''if (phases.empty())
        for (int t=0;t<game.teamsCount();++t) phases.push_back(game.teams[t]->stats.samplingPhase());
    if (previous.empty())
        for (int t=0;t<game.teamsCount();++t)
            previous.push_back(std::make_shared<GameplayMeasurements>(game.teams[t]->stats.measurements()));''')
s=s.replace('batch->phases = phases;','''batch->phases = phases;
    batch->previous=&previous;
    batch->work.resize(phases.size());
    batch->groups.resize(phases.size());
    for (unsigned t=0;t<phases.size();++t) {
        batch->work[t]={batch.get(),t};
        batch->groups[t]={1,{compute,&batch->work[t]},ComputeExecutor::StatisticsLaneBase+t};
    }''')
s=s.replace('compute(batch.get(), t);','compute(&batch->work[t], 0);')
s=s.replace('\t\tComputeExecutor::Group group{\n\t\t\tbatch->samples.size(), {compute, batch.get()}, ComputeExecutor::NoLane};\n','')
s=s.replace('executor.submit(std::span(&group, 1), ComputeExecutor::boundaryDue(batch->due),','executor.submit(batch->groups, ComputeExecutor::boundaryDue(batch->due),')
s=s.replace('const auto count = s->readCount("pending");','''for (unsigned t=0;t<teams;++t)
        previous.push_back(std::make_shared<GameplayMeasurements>(game.teams[t]->stats.measurements()));
    const auto count = s->readCount("pending");''')
s=s.replace('sample.measurements.births.size()', 'sample.measurementFrame().births.size()').replace('sample.measurements.variants.size()', 'sample.measurementFrame().variants.size()')
s=s.replace('\t\t\tb->samples.push_back(std::move(sample));','''            if (!sample.frame) {
                TeamStats::completeMeasurements(sample,*previous[t]);
                sample.frame=std::make_shared<GameplayMeasurements>(std::move(sample.measurements));
            }
            previous[t]=sample.frame;
            b->samples.push_back(std::move(sample));''')
p.write_text(s)
p=Path('src/team/stats/TeamStat.h');s=p.read_text().replace('    std::shared_ptr<GameplayMeasurements> frame;','    std::shared_ptr<GameplayMeasurements> frame;\n    const GameplayMeasurements& measurementFrame() const { return frame ? *frame : measurements; }');p.write_text(s)
p=Path('src/team/stats/TeamStatsPipelineTest.cpp');s=p.read_text().replace('if(name!="finalized")','if(name!="finalized" && name!="completeFrame")');p.write_text(s)
p=Path('src/app/Version.h');s=p.read_text().replace('#define VERSION_MINOR 157','#define VERSION_MINOR 158').replace('#define NET_PROTOCOL_VERSION 69','#define NET_PROTOCOL_VERSION 70');p.write_text(s)
p=Path('src/game/SimRevision.h');s=p.read_text().replace('#define SIM_REVISION 52','#define SIM_REVISION 53');p.write_text(s)
p=Path('src/replay/ReplayReader.h');s=p.read_text().replace('REPLAY_MINIMUM_VERSION_MINOR = 157','REPLAY_MINIMUM_VERSION_MINOR = 158');p.write_text(s)
