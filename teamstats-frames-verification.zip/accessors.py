from pathlib import Path
import re
p=Path('src/team/stats/TeamStat.h');s=p.read_text().replace('  GameplayMeasurements& measurements();','  // Cold legacy scans/load/fixture edits detach a retained immutable frame.\n  GameplayMeasurements& editMeasurements();');s=s.replace('GameplayMeasurements& events() { return collectionEnabled ? collectedMeasurements : measurements(); }','GameplayMeasurements& events() { return collectionEnabled ? collectedMeasurements : editMeasurements(); }');p.write_text(s)
p=Path('src/team/stats/TeamStat.cpp');s=p.read_text().replace('GameplayMeasurements& TeamStats::measurements()\n{\n    return','GameplayMeasurements& TeamStats::editMeasurements()\n{\n    if (publishedMeasurements && !publishedMeasurements.unique())\n        publishedMeasurements=std::make_shared<GameplayMeasurements>(*publishedMeasurements);\n    return');
for name in ['step','load','initializeMeasurements','beginMeasurementSnapshot','observeMeasurementUnit','observeMeasurementBuilding','observeLabour','sampleDefence','refreshMeasurements','sampleTraps','configureUnits']:
 start=s.index('TeamStats::'+name+'('); start=s.index('{',start); pos=start+1;depth=1
 while depth:
  if s[pos]=='{':depth+=1
  if s[pos]=='}':depth-=1
  pos+=1
 s=s[:start]+s[start:pos].replace('measurements()','editMeasurements()')+s[pos:]
p.write_text(s)
# Explicit fixture edits; all ordinary reads use the const accessor.
for p in list(Path('src').rglob('*Test.cpp'))+list(Path('src').rglob('*Harness.cpp'))+list(Path('test').rglob('*.cpp')):
 s=p.read_text();n=re.sub(r'(?m)^([^\n]*\bauto\s*&[^\n]*)(measurements\(\))',lambda m:m[1]+'editMeasurements()',s)
 # Direct assignments to measurement fields (exclude equality checks).
 n=re.sub(r'(measurements\(\))(?=(?:\.[\w]+|\[[^\]\n]*\])+\s*(?:=(?!=)|\+=|\+\+))','editMeasurements()',n)
 if n!=s:p.write_text(n)
