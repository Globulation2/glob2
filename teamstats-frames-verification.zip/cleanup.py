from pathlib import Path
p=Path('src/team/stats/TeamStat.cpp');s=p.read_text();start=s.index('\n\tconfigureUnits(catalog->size());',s.index('void TeamStats::applySample(TeamStatsSample &&'));end=s.index('\nvoid TeamStats::captureSmoothingWindow',start)
s=s[:start]+'''
    configureUnits(catalog->size());
    if (!sample.frame) {
        completeMeasurements(sample, measurements());
        sample.frame=std::make_shared<GameplayMeasurements>(std::move(sample.measurements));
    }
    publishFrame(sample, publicationTick, catalog);
}
'''+s[end:];p.write_text(s)
for name in ['src/team/stats/TeamStatsSaveHarness.cpp','src/team/stats/TeamLabourStatsTest.cpp']:
 p=Path(name);s=p.read_text().replace('loaded.measurements.', 'loaded.measurements().').replace('expected.measurements == actual.measurements','expected.measurements() == actual.measurements()');p.write_text(s)
