from pathlib import Path
p=Path('src/team/stats/TeamStatsPipeline.h');s=p.read_text().replace('\tstruct Pending;\n\tstruct Work { Pending* batch; unsigned team; };\n','').replace('\t\tstd::vector<Work> work;\n\t\tstd::vector<ComputeExecutor::Group> groups;\n','').replace('\t\tstd::atomic<unsigned> remaining{0};\n','').replace('// Each team lane alone accesses its continuation. Initialized before submission/restored after joins.','// One statistics lane owns frame continuation; seeded before submission or after loading.');p.write_text(s)
p=Path('src/team/stats/TeamStatsPipeline.cpp');s=p.read_text();start=s.index('void TeamStatsPipeline::compute(');end=s.index('SimulationSnapshot::Requirements TeamStatsPipeline::requirements',start)
s=s[:start]+'''void TeamStatsPipeline::compute(void *context, size_t)
{
    auto& batch=*static_cast<Pending*>(context);
    const auto snapshot=batch.snapshot;
    for (unsigned team=0;team<batch.samples.size();++team) {
        const auto start=batch.profile ? Clock::now() : Clock::time_point{};
        auto storage=std::move(batch.samples[team].frame);
        auto sample=computeTeamStatsSample(snapshot,team,batch.phases[team]==31,
                                          batch.smoothingWindows[team],true);
        TeamStats::completeMeasurements(sample,*(*batch.previous)[team]);
        if (!storage || storage.use_count()!=1) storage=std::make_shared<GameplayMeasurements>();
        *storage=std::move(sample.measurements);
        sample.frame=std::move(storage);
        (*batch.previous)[team]=sample.frame;
        batch.samples[team]=std::move(sample);
        if(batch.profile) batch.workerNs[team]=elapsed(start);
    }
    batch.snapshot={};
}
'''+s[end:]
a=s.index('    batch->work.resize');b=s.index('    batch->smoothingWindows.resize',a);s=s[:a]+s[b:]
s=s.replace('\tbatch->remaining.store(phases.size(), std::memory_order_relaxed);\n','')
s=s.replace('\t\tfor (unsigned t = 0; t < batch->samples.size(); ++t)\n\t\t\tcompute(&batch->work[t], 0);','\t\tcompute(batch.get(),0);')
s=s.replace('\t\tconst auto submissionStart = profiling ? Clock::now() : Clock::time_point{};','\t\tconst ComputeExecutor::Group group{1,{compute,batch.get()},ComputeExecutor::StatisticsLaneBase};\n\t\tconst auto submissionStart = profiling ? Clock::now() : Clock::time_point{};')
s=s.replace('executor.submit(batch->groups,','executor.submit(std::span(&group,1),')
p.write_text(s)
p=Path('docs/architecture/ai-observations.md');s=p.read_text().replace('only the completion synchronization needed to release their snapshot. Timed jobs','only executor completion synchronization needed to release their snapshot. Timed jobs').replace('spatial diagnostics on one dedicated executor lane per team. Different teams\nremain parallel; a team’s frames complete in source order without worker waits.','spatial diagnostics on one dedicated statistics executor lane. One job computes\nthe cheap team rows in team order, avoiding separate lane/group scheduling costs;\nbatches complete in source order without worker waits.');p.write_text(s)
p=Path('docs/ai/gameplay-statistics.md');s=p.read_text().replace('Each team’s executor lane then accumulates those deltas and retains the latest','The statistics batch job then accumulates those deltas and retains the latest');p.write_text(s)
