from pathlib import Path
import re
# Existing readers now dereference the published frame; legacy mutable callers use the same accessor.
for p in list(Path('src').rglob('*.cpp'))+list(Path('src').rglob('*.h'))+list(Path('test').rglob('*.cpp')):
 s=p.read_text(); n=re.sub(r'\bstats(?:\.|->)measurements\b(?!\s*\()',lambda m:m[0]+'()',s)
 if n!=s:p.write_text(n)
p=Path('src/team/stats/TeamStat.h');s=p.read_text().replace('  GameplayMeasurements measurements;','  GameplayMeasurements& measurements();\n  const GameplayMeasurements& measurements() const;',1)
s=s.replace(' : measurements;',' : measurements();')
s=s.replace('  void applySample(TeamStatsSample&&','  void publishFrame(TeamStatsSample&, Uint32 publicationTick);\n  static void completeMeasurements(TeamStatsSample&, const GameplayMeasurements& previous);\n  void applySample(TeamStatsSample&&',1)
s=s.replace('    bool collectionEnabled = false;','    GameplayMeasurements legacyMeasurements;\n    std::shared_ptr<GameplayMeasurements> publishedMeasurements;\n    bool collectionEnabled = false;')
s=s.replace('    GameplayMeasurements measurements;\n    std::vector<TeamStats::CoverageBuilding> coverage;','    GameplayMeasurements measurements;\n    // Complete immutable worker result; publication swaps ownership with a reusable old frame.\n    std::shared_ptr<GameplayMeasurements> frame;\n    std::vector<TeamStats::CoverageBuilding> coverage;')
p.write_text(s)
p=Path('src/team/stats/TeamStat.cpp');s=p.read_text()
# Do not change sample fields, field names, or print lambda's local argument.
start=s.index('  auto emit') if '  auto emit' in s else s.index('\tauto emit')
end=s.index('\n\tif (final)',start)
prefix=s[:start]; local=s[start:end]; suffix=s[end:]
def convert(t):
 return re.sub(r'"(?:[^"\\]|\\.)*"|(?<![\w.>])\bmeasurements\b(?!\s*\()',lambda m:m[0] if m[0].startswith('"') else 'measurements()',t)
s=convert(prefix)+local+convert(suffix)
# Global external reader edit already changed stats.measurements.
insert=s.index('void TeamStats::step(')
s=s[:insert]+'''GameplayMeasurements& TeamStats::measurements()
{
    return publishedMeasurements ? *publishedMeasurements : legacyMeasurements;
}
const GameplayMeasurements& TeamStats::measurements() const
{
    return publishedMeasurements ? *publishedMeasurements : legacyMeasurements;
}

'''+s[insert:]
# Complete the few delta/carried diagnostic fields on the worker, without copying events/instantaneous fields again.
insert=s.index('void TeamStats::applySample(const')
s=s[:insert]+'''void TeamStats::completeMeasurements(TeamStatsSample& sample, const GameplayMeasurements& previous)
{
    auto& next = sample.measurements;
    for (int i=0;i<GameplayMeasurements::LABOUR_ACTIVITIES;++i) next.labour[i]+=previous.labour[i];
    for (int j=0;j<GameplayMeasurements::LABOUR_JOBS;++j) {
        for(int p=0;p<GameplayMeasurements::LABOUR_PHASES;++p) next.filling[j][p]+=previous.filling[j][p];
        next.harvestDistance[j]+=previous.harvestDistance[j];
        next.harvestSamples[j]+=previous.harvestSamples[j];
    }
    next.eatWalkDistance+=previous.eatWalkDistance;
    next.eatWalkSamples+=previous.eatWalkSamples;
    if (!sample.periodic) {
        next.trappedUnits=previous.trappedUnits;
        next.lowHP=previous.lowHP;
        next.lowFood=previous.lowFood;
        copyEventField(next.trappedBuildings,previous.trappedBuildings);
        copyEventField(next.trappedTick,previous.trappedTick);
        copyEventField(next.warriors,previous.warriors);
        copyEventField(next.warriorLevels,previous.warriorLevels);
        copyEventField(next.warriorsHurt,previous.warriorsHurt);
        copyEventField(next.warriorsFlagged,previous.warriorsFlagged);
        copyEventField(next.warriorsInside,previous.warriorsInside);
        copyEventField(next.intruders,previous.intruders);
        copyEventField(next.intruderLevels,previous.intruderLevels);
        copyEventField(next.defenceTick,previous.defenceTick);
        for(size_t i=0;i<next.variants.size();++i)
            if(i<previous.variants.size()) copyEventField(next.variants[i].trapped,previous.variants[i].trapped);
    }
}

void TeamStats::publishFrame(TeamStatsSample& sample, Uint32 publicationTick)
{
    if (!sample.frame) throw std::logic_error("Missing completed statistics frame");
    if (needsMeasurementInitialization) {
        coverageStartTick=extendedCoverageStartTick=labourCoverageStartTick=sample.tick;
        needsMeasurementInitialization=false;
    }
    sourceTick=sample.tick;
    publishedTick=publicationTick;
    publishedMeasurements.swap(sample.frame);
    if (sample.periodic) {
        historySnapshot.reset();
        const auto& old=stats[statsIndex];
        endOfGameStats.emplace_back(old.totalUnit,old.totalBuilding,sample.prestige,old.totalHP,
                                   old.totalAttackPower,old.totalDefensePower);
        if (coverageBuildings!=sample.coverage) {
            coverageBuildings.swap(sample.coverage);
            ++coverageBuildingGeneration;
        }
        coverageBuildingTick=sample.tick;
        if (measurementHistory.empty() || measurementHistory.back().tick!=sample.tick)
            measurementHistory.push_back(measurements());
    }
    smoothedStats[smoothedIndex]=std::move(sample.smoothing);
    smoothedIndex=(smoothedIndex+1)%STATS_SMOOTH_SIZE;
    if (!sample.aggregate) return;
    if (smoothedIndex) throw std::logic_error("Statistics aggregate phase mismatch");
    // Older pending aggregates retain their exact owner reduction until publication.
    if (!sample.finalized) finishAggregate(sample.stat,sample.eligible,smoothedStats,*samplingCatalog);
    displaySnapshot.reset();
    statsIndex=(statsIndex+1)%STATS_SIZE;
    stats[statsIndex]=std::move(sample.stat);
}

'''+s[insert:]
# Older aggregate needs catalog supplied explicitly; don't depend on derived samplingCatalog.
s=s.replace('void TeamStats::publishFrame(TeamStatsSample& sample, Uint32 publicationTick)','void TeamStats::publishFrame(TeamStatsSample& sample, Uint32 publicationTick, const std::shared_ptr<const UnitCatalog>& catalog)')
s=s.replace('smoothedStats,*samplingCatalog);','smoothedStats,*catalog);')
# Serialize complete frames under a gated flag, preserving old raw layouts.
s=s.replace('measurementFields(stream, sample.measurements);','measurementFields(stream, sample.frame ? *sample.frame : sample.measurements);')
s=s.replace('stream->writeUint8(sample.periodic, "periodic");','stream->writeUint8(sample.periodic, "periodic");\n    stream->writeUint8(bool(sample.frame), "completeFrame");')
s=s.replace('sample.periodic = periodic;','sample.periodic = periodic;\n    const auto complete = versionMinor >= 158 ? stream->readUint8("completeFrame") : 0;\n    if (complete>1) throw std::runtime_error("Invalid complete statistics frame flag");')
s=s.replace('\n\treturn sample;\n}\n\nUint32 teamStatsCoreChecksum','\n    if (complete) sample.frame=std::make_shared<GameplayMeasurements>(std::move(sample.measurements));\n\treturn sample;\n}\n\nUint32 teamStatsCoreChecksum')
p.write_text(s)
p=Path('src/team/stats/TeamStat.h');s=p.read_text().replace('void publishFrame(TeamStatsSample&, Uint32 publicationTick);','void publishFrame(TeamStatsSample&, Uint32 publicationTick, const std::shared_ptr<const UnitCatalog>&);');p.write_text(s)
# Dedicated lanes do not share AI's player lanes, whose deadlines may differ.
p=Path('src/common/ComputeExecutor.h');s=p.read_text().replace('static constexpr unsigned Lanes = 32;','static constexpr unsigned StatisticsLaneBase = 32;\n\tstatic constexpr unsigned Lanes = 64;');p.write_text(s)
