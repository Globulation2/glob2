from pathlib import Path
import json,hashlib,zipfile,subprocess
root=Path('artifacts/teamstats/frames');rows=json.loads((root/'medians.json').read_text())
def pick(kind,name,prof='profile1',teams=0,ai='',delay=8,mode='snapshot_delayed',workers=0):
 return next(r for r in rows if r['kind']==kind and r['binary']==name and r['profiling']==prof and r['teams']==teams and r['ai']==ai and r['delay']==delay and (r['mode']==mode if kind=='static' else r['workers']==workers))
before=pick('static','before');after=pick('static','after')
cols=[('Shared snapshot capture','capture'),('Batch/window setup','allocation'),('Submission','submission'),('Publication','publication'),('Deadline wait','deadline_wait'),('Worker calculation (sum)','calculation'),('Owner total, profiled','owner')]
table='| Cost (µs/tick, both teams) | Before | Complete frames |\n| --- | ---: | ---: |\n'
for label,key in cols:table+=f"| {label} | {before[key+'_us_per_tick']:.3f} | {after[key+'_us_per_tick']:.3f} |\n"
adv='| AI teams | Publication before / after | Worker before / after | Owner, no profiling before / after |\n| --- | ---: | ---: | ---: |\n'
for teams in [2,4]:
 b=pick('advancing','before',teams=teams,ai='numbi-castor',workers=2);a=pick('advancing','after',teams=teams,ai='numbi-castor',workers=2)
 bn=pick('advancing','before','profile0',teams=teams,ai='numbi-castor',workers=2);an=pick('advancing','after','profile0',teams=teams,ai='numbi-castor',workers=2)
 adv+=f"| {teams} | {b['stats_publication_us_per_tick']:.3f} / {a['stats_publication_us_per_tick']:.3f} | {b['stats_worker_us_per_tick']:.3f} / {a['stats_worker_us_per_tick']:.3f} | {bn['owner_us_per_tick']:.3f} / {an['owner_us_per_tick']:.3f} |\n"
identity=json.loads((root/'final-source-provenance.json').read_text());binaryhashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'before-engine-tests',root/'glob2-engine-tests',root/'per-team-engine-tests']}
(root/'binary-sha256.json').write_text(json.dumps(binaryhashes,indent=2)+'\n')
text=f'''# Complete measurement frame verification

Final source: `{identity['revision']}` (clean); source tree SHA256 `{identity['sourceTreeSha256']}`. Base: `codex/mcp-test-portability` / `b1f1affb1ca39682c428003250ddac574a6608ed`. Fetched master: `277510840054b1416f2defd7d86fe1431dd0ddc0`; merge-tree preview is conflict-free. Master was fetched before final clean verification; unrelated gradient/rendering changes were not merged or rebased. This validates the feature branch on its recorded base, not execution of the newer master merge tree.

Workers construct complete measurements, including exact cumulative labour and retained periodic diagnostics. Publication swaps the frame pointer, installs consecutive raw-ring rows, and installs worker-finalized aggregates / appends periodic histories when due. Fixed deadlines, pause/read idempotence, K=0 behavior, event collection separation and omitted unpublished final samples remain. One ordered batch job computes the cheap team rows; AI uses separate executor lanes. Replaced frames return through existing batch storage, with shared retention preventing overwrite. No new pool. Old raw calculation remains an independent reference and cold migration path.

Save 158 stores a complete-frame flag; formats 155–157 are completed in source order without early publication. Older pending raw aggregates still retain their exact smoothing mode. Minimum save 58; replay floor 158; net protocol 70; SIM_REVISION 53; regenerated match record verifies.

## Clean final validation

- Native: 128 selected cases passed, no failures/skips (`final-native.xml`), covering executor, snapshots, read boundaries, frame pipeline, shared worker lifecycle, match/replay boundaries, 32-phase save/load/resave/text/corruption and golden record.
- Release: 78 passed, one display-only screenshot case skipped, no failures (`final-release.xml`), including all pipeline/save/AI cases. Full older 84/88 and format152 fixtures pass. Frame tests compare every measurement through tick519 for K=0/1/2/8 and zero/two workers, retain immutable prior frames, and exercise format157 deltas with nonzero baseline labour through load/resave/continued submission.
- `checksums.txt`: 32 advancing configurations ×520 ticks =16,640 full checksum records; all16 zero/two-worker pairs match. Profiling on/off and repeated-trial final checksums match within each binary/configuration. Full pending results are hashed; worker readiness is excluded.
- `sim-revision.log` verifies the gate/golden record. The initial broader run's stale version assertion (157/69) was repaired to158/70; final clean run repeats that full case successfully. Broader initial engine/MCP coverage and the resolved failure are retained in the archive.

Native macOS ARM64, Apple LLVM21, C++20. Debug: dev_fast=1, -O0 -g1; release: release=1, dev_fast=0, linker=default, -O3 (ordinary compiled game objects, focused engine-test link). Exact commands, build logs, link argv, compiler/provenance and test selection are archived. Runtime dependencies are the existing pinned SDL prefix plus Homebrew libraries; no dependency changes in this follow-up. GUI/GPU screenshots, Linux/Windows/browser/mobile per-tick execution, sanitizer and release packaging checks, hosted CI and maintainer gameplay review are not verified. The PR stays draft.

## Paired release profiling

Five paired trials, seed1234567, 2048 advancing ticks, profiling on/off, SDL dummy drivers, `GLOB2_PERF_DISABLE=1`. `profile.py` is the exact workload driver; `analyze.py` recomputes medians and validates checksums. The static world has two teams and256 total units; K=8 with two workers. Capture is the full shared consumer capture, not statistics-only cost. Publication excludes ticket joining/snapshot release/batch retirement, includes both teams and the amortized32/512 boundaries. Components are medians of separately timed regions and do not sum exactly to the median total. The remaining owner path includes ordinary completed joins and boundary/FIFO work; it is not individually attributed.

{table}

Without profiling: static owner {pick('static','before','profile0')['owner_us_per_tick']:.3f} → {pick('static','after','profile0')['owner_us_per_tick']:.3f} µs/tick. Published frame installation removed the bulk merge; total CPU work is not eliminated. Snapshot peak leased memory is {after['peak_leased_bytes']:,} bytes, matching the baseline. This metric excludes frame/ring storage.

Representative advancing worlds:256×256 map, two/four teams with128 starting units per team, stocked inn/swarm, fixed wheat/wood/stone, controlled or alternating Numbi/Castor AI, normal validated orders, AI order delay8. Workload code is `src/team/stats/TeamStatsPipelineTest.cpp`; saved rule delays0/1/2/8 and zero/two workers are all profiled. Values below use K=8 and two workers; all units µs/tick.

{adv}

The final host was measurably busier than earlier clean trials: static shared capture (unchanged code) varied substantially between paired binaries. These final wall-clock medians are not a reliable causal speedup estimate; earlier clean-source tables under serial-batch-before-copy-cleanup/ show publication near0.05µs and the original near0.87µs. The removed unused copy is a code-level reduction, not a separately quantified instruction-count result. No overall advancing-match speedup is established. Capture timings and whole-match totals include shared scheduling/cache/host effects and must not be attributed solely to this change. For each matching configuration, the AI order counts agree across binaries. Header/save-version changes alter across-version checksums; cross-worker equality is checked within each binary, not by comparing incompatible checksum versions. Short K=1/2 still exposes host/scheduler deadline waits (all configurations and costs in `medians.json`). Publication clock overhead is included; normal execution reads no clocks.

The first per-team ordered-lane implementation achieved ~0.057µs publication but ~2.4µs submission versus~1.3µs before. Those early three quiet paired trials are retained under `per-team-lanes/`; later partial/interrupted trials are not evidence for an improvement. A single ordered batch restored the executor's one-group fast path and removed the per-team snapshot-lifetime atomic. The frame storage is reused via the existing spare batch; no separate allocation pool was added. No updated Callgrind attribution is claimed for this follow-up.

Baseline code is commit `4b15aed8d` (the former0.87µs publication implementation), built just before committing; its logged source digest is exactly reproduced from that tree and its worktree representation by `baseline-source-identity.txt`. New clean binaries embed the final commit above. Binary SHA256s are in `binary-sha256.json`; executables are not included. Earlier trials are retained separately, but current tables/traces use final clean source/provenance. The final worker path also avoids moving the unused inline measurement arrays into pending rows and skips non-aggregate stat/eligibility transfers; those fields are omitted from serialization when no aggregate is due. Pre-cleanup measurements are retained under serial-batch-before-copy-cleanup/. Reproduction uses the existing compiler/dependencies, release targets in `build-release.py`, linked argv in `release-link-args.json`, and `profile.py`; ordinary debug commands use `PYTHONPATH="$PWD" python3 tools/dev_build.py engine-tests unit-tests` and `python3 test/run_tests.py` as recorded in the drivers.
'''
(root/'verification.md').write_text(text)
with zipfile.ZipFile(root/'teamstats-frames-verification.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in root.rglob('*'):
  if p.is_file() and p.suffix in ['.py','.log','.xml','.json','.txt','.md'] and 'profile-user' not in p.parts:
   z.write(p,p.relative_to(root))
 for p in [Path('artifacts/teamstats/cleanup/build-release.py'),Path('artifacts/teamstats/efficient/release-integrated-link-args.json')]:z.write(p,'reproduction/'+('release-link-args.json' if p.suffix=='.json' else p.name))
 for p in Path('/tmp').glob('stats-frames*build.log'):z.write(p,'build-logs/'+p.name)
(root/'archive-sha256.txt').write_text(hashlib.sha256((root/'teamstats-frames-verification.zip').read_bytes()).hexdigest()+'\n')
