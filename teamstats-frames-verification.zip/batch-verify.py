import subprocess,json
from pathlib import Path
root=Path('artifacts/teamstats/frames')
base=['python3','test/run_tests.py','--build-dir','build/darwin/client/debug/dev-dev_fast-true-linker-auto','--binary','all','--no-display','--timeout','600','-j','2']
with open(root/'batch-correctness.log','w') as out:
 subprocess.run(base+['--filter','TeamStatsPipeline/*','--filter','ReadOnlyPhase/*','--filter','WorldSnapshot/*','--filter','ComputeExecutor/*','--filter','SharedWorkerLifecycle/*','--filter','TurnEngineHarness/the committed*','--junit',str(root/'batch-correctness.xml')],stdout=out,stderr=subprocess.STDOUT,check=True)
args=json.loads(Path('artifacts/teamstats/efficient/release-integrated-link-args.json').read_text());args[2]=str(root/'glob2-engine-tests');subprocess.run(args,check=True)
with open(root/'batch-release-correctness.log','w') as out:
 subprocess.run(['python3','test/run_tests.py','--build-dir',str(root/'release'),'--binary','engine','--no-display','--timeout','600','-j','2']+sum((['--filter',x+'/*'] for x in ['WorldSnapshot','TeamStatsPipeline','TeamStatsSave','AIPipeline']),[])+['--junit',str(root/'batch-release-correctness.xml')],stdout=out,stderr=subprocess.STDOUT,check=True)
(root/'verification-ready').write_text('passed\n')
