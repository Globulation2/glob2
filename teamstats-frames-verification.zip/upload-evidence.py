from pathlib import Path
import subprocess,os
root=Path('artifacts/teamstats/frames')
def git(*args,env=None,input=None):return subprocess.check_output(['git',*args],env=env,input=input).decode().strip()
parent=git('rev-parse','origin/codex/teamstats-verification')
env=dict(os.environ,GIT_INDEX_FILE=str((root/'evidence-index').resolve()))
git('read-tree',parent,env=env)
for path,name in [(root/'verification.md','teamstats-frames-verification.md'),(root/'teamstats-frames-verification.zip','teamstats-frames-verification.zip')]:
 blob=git('hash-object','-w',str(path));git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
tree=git('write-tree',env=env)
commit=git('commit-tree',tree,'-p',parent,input=b'Attach complete-frame publication validation and paired release profiles\n')
subprocess.run(['git','push','origin',commit+':refs/heads/codex/teamstats-verification'],check=True)
(root/'evidence-commit.txt').write_text(commit+'\n')
print(commit)
