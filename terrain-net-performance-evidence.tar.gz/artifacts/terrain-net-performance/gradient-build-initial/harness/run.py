#!/usr/bin/env python3
"""Frozen pre-terrain versus final classic-gradient comparison, artifact only."""
from __future__ import annotations
import argparse
import hashlib
import io
import itertools
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
HARNESS = Path(__file__).resolve().parent
LEGACY = '934c3c588bea51ec7421152e15f5168b2aaf5502'
FINAL = '37d609766374e7efc1679d643c7d18cde84364ab'
FLAGS = ['-O3', '-fPIC', '-DNDEBUG', '-std=c++20', '-fno-lto']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def archive(revision, output, paths):
    archive_bytes = subprocess.check_output(['git', 'archive', revision, *paths], cwd=ROOT)
    output.mkdir(parents=True)
    with tarfile.open(fileobj=io.BytesIO(archive_bytes)) as files:
        files.extractall(output, filter='data')


def build(output, compiler):
    if (output / 'manifest.json').exists():
        raise RuntimeError('Existing manifest: use --run-only or a fresh output directory.')
    output.mkdir(parents=True, exist_ok=True)
    archive(LEGACY, output / 'legacy', ['src/field'])
    archive(FINAL, output / 'final', ['src/field', 'src/map/TerrainType.h', 'src/map/TerrainProperties.h'])
    source = output / 'harness'
    source.mkdir()
    for name in ('api.h', 'variant.cpp', 'driver.cpp', 'run.py'):
        (source / name).write_bytes((HARNESS / name).read_bytes())
    commands = []
    for variant in ('legacy', 'final'):
        command = [compiler, *FLAGS, '-I' + str(output / variant / 'src')]
        if variant == 'legacy':
            command.append('-DLEGACY')
        command += ['-c', str(source / 'variant.cpp'), '-o', str(output / (variant + '.o'))]
        subprocess.run(command, check=True)
        commands.append(command)
    command = [compiler, *FLAGS, '-c', str(source / 'driver.cpp'), '-o', str(output / 'driver.o')]
    subprocess.run(command, check=True)
    commands.append(command)
    binaries = {}
    for order in ('legacy-first', 'final-first'):
        objects = ('legacy', 'final') if order == 'legacy-first' else ('final', 'legacy')
        binary = output / ('classic-gradient-' + order)
        command = [compiler, *FLAGS, str(output / 'driver.o')]
        command += [str(output / (name + '.o')) for name in objects]
        command += ['-o', str(binary)]
        subprocess.run(command, check=True)
        commands.append(command)
        binaries[order] = dict(path=str(binary), sha256=sha(binary))
    common_files = [
        'GradientPropagation.h', 'GradientRelaxation.h', 'GradientCosts.h',
        'GradientWorkspace.h', 'Grid.h',
    ]
    common_proofs = {
        name: dict(legacy_sha256=sha(output / 'legacy/src/field' / name),
                   final_sha256=sha(output / 'final/src/field' / name),
                   byte_identical=(output / 'legacy/src/field' / name).read_bytes()
                   == (output / 'final/src/field' / name).read_bytes())
        for name in common_files
    }
    manifest = dict(
        legacy_revision=LEGACY, final_revision=FINAL,
        commands=commands, compiler=subprocess.check_output([compiler, '--version'], text=True),
        flags=FLAGS, counters_enabled=False, platform=platform.platform(),
        cpu_info=Path('/proc/cpuinfo').read_text(),
        binaries=binaries, identical_source_proofs=common_proofs,
        source_hashes={str(path.relative_to(output)): sha(path)
                       for folder in ('legacy', 'final', 'harness')
                       for path in sorted((output / folder).rglob('*')) if path.is_file()},
        notes=[
            'Historical and final source headers are unmodified git archives.',
            'Variant wrappers rename namespaces/types to avoid cross-version ODR coalescing.',
            'Both archived GradientBucket::COUNT values are compile-time asserted as 64.',
            'Shared layout reuses exact terrain input and output addresses; raw representations are copied outside timing.',
            'Each variant retains private queues: queue buffer addresses are not matched and are reported.',
            'Only original grass/sand/water costs are compared; new varied terrain has no legacy-equivalent workload.',
            'Every full result is checked against an independent heap oracle outside timing.',
        ],
    )
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')


def cases(suite):
    shapes = [(32, 32), (128, 128), (256, 256), (512, 512),
              (1, 31), (2, 17), (17, 31), (32, 128), (128, 256)]
    seeds = ('single', 'sparse', 'dense', 'deferred', 'blocked', 'all-blocked')
    caps = (127, 65491)
    if suite == 'smoke':
        shapes = [(32, 32), (1, 31), (17, 31)]
        seeds = ('deferred', 'blocked')
        caps = (127,)
    for (width, height), swim, seed, cap in itertools.product(shapes, range(7), seeds, caps):
        yield dict(width=width, height=height, swim=swim, seeds=seed, cap=cap)


def run(args):
    manifest = json.loads((args.output / 'manifest.json').read_text())
    orders = ('legacy-first', 'final-first') if args.link_order == 'both' else (args.link_order,)
    for order in orders:
        info = manifest['binaries'][order]
        if sha(info['path']) != info['sha256']:
            raise RuntimeError('Frozen binary hash changed: ' + order)
    destination = args.output / args.name
    destination.mkdir()
    matrix = list(cases(args.suite))
    (destination / 'run.json').write_text(json.dumps(dict(
        suite=args.suite, repeats=args.repeats, cpu=args.cpu, link_orders=orders,
        manifest_sha256=sha(args.output / 'manifest.json'), cases=matrix,
    ), indent=2) + '\n')
    summary = []
    with (destination / 'samples.jsonl').open('w') as raw:
        for index, case in enumerate(matrix):
            for order, layout in itertools.product(orders, ('shared', 'separate')):
                command = [manifest['binaries'][order]['path'], '--layout', layout,
                           '--repeats', str(args.repeats)]
                for key, value in case.items():
                    command += ['--' + key, str(value)]
                command = ['taskset', '-c', str(args.cpu), *command]
                load_before = os.getloadavg()
                result = subprocess.run(command, text=True, capture_output=True)
                if result.returncode:
                    raise RuntimeError(f'{command}\n{result.stderr}')
                rows = [json.loads(line) for line in result.stdout.splitlines()]
                for row in rows:
                    row['link_order'] = order
                    row['load_before'] = load_before
                    raw.write(json.dumps(row) + '\n')
                raw.flush()
                warm = [row for row in rows if row['repetition'] >= 0]
                before = statistics.median(row['cpu_ns'] for row in warm if row['implementation'] == 'legacy')
                after = statistics.median(row['cpu_ns'] for row in warm if row['implementation'] == 'final')
                pairs = []
                for repetition in range(args.repeats):
                    pair = {row['implementation']: row['cpu_ns'] for row in warm if row['repetition'] == repetition}
                    pairs.append(pair['final'] / pair['legacy'])
                summary.append(dict(case=case, layout=layout, link_order=order,
                                    legacy_cpu_ns=before, final_cpu_ns=after,
                                    ratio=after / before, median_pair_ratio=statistics.median(pairs),
                                    pair_ratios=pairs, command=command))
            if index % 20 == 0:
                print(f'{index + 1}/{len(matrix)} cases', flush=True)
    (destination / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--compiler', default='g++')
    parser.add_argument('--build-only', action='store_true')
    parser.add_argument('--run-only', action='store_true')
    parser.add_argument('--suite', choices=('smoke', 'full'), default='full')
    parser.add_argument('--repeats', type=int, default=11)
    parser.add_argument('--cpu', type=int, default=0)
    parser.add_argument('--name', default='measurements')
    parser.add_argument('--link-order', choices=('legacy-first', 'final-first', 'both'), default='both')
    args = parser.parse_args()
    args.output = args.output.resolve()
    if args.repeats < 11:
        parser.error('Use at least 11 alternating pairs, including smoke checks.')
    if not args.run_only:
        build(args.output, args.compiler)
    if not args.build_only:
        run(args)


if __name__ == '__main__':
    main()
