#include "api.h"
#include <algorithm>
#include <chrono>
#include <ctime>
#include <functional>
#include <iostream>
#include <limits>
#include <queue>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

namespace
{
constexpr std::uint16_t Goal = 65535, Unreached = 1, Blocked = 0;
constexpr int Cap = 65491;
using Clock = std::chrono::steady_clock;
std::uint64_t cpuNow()
{
    timespec value{};
    if (clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &value))
        throw std::runtime_error("process CPU clock unavailable");
    return std::uint64_t(value.tv_sec) * 1000000000 + value.tv_nsec;
}
std::uint64_t wallSince(Clock::time_point start)
{
    return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count();
}
std::uint64_t hash(const std::vector<std::uint16_t> &values)
{
    std::uint64_t result = 1469598103934665603ull;
    for (auto value : values) result = (result ^ value) * 1099511628211ull;
    return result;
}
struct Options
{
    int width = 128, height = 128, swim = 3, cap = Cap, repeats = 11;
    std::string seeds = "sparse", layout = "shared";
};
struct Fixture
{
    std::vector<std::uint16_t> types, sprites, seeds;
};
Fixture makeFixture(const Options &options)
{
    const auto n = std::size_t(options.width) * options.height;
    Fixture result{std::vector<std::uint16_t>(n), std::vector<std::uint16_t>(n),
        std::vector<std::uint16_t>(n, Unreached)};
    std::mt19937 random(72941);
    for (std::size_t i = 0; i < n; ++i)
    {
        const auto terrain = random() % 10;
        result.types[i] = terrain < 2 ? 0 : terrain < 4 ? 1 : 2;
        result.sprites[i] = terrain < 2 ? 256 : terrain < 4 ? 128 : 0;
        const auto sample = random();
        if (sample % 7 == 0 || (options.swim == 0 && result.types[i] == 0))
            result.seeds[i] = Blocked;
        if (options.seeds == "sparse" && i % (options.width * 17 + 13) == 0)
            result.seeds[i] = Goal;
        else if (options.seeds == "dense" && sample % 13 == 0)
            result.seeds[i] = Goal;
        else if (options.seeds == "deferred" && sample % 47 == 0)
        {
            constexpr int distances[] = {0, 1, 41, 42, 43, 63, 64, 65, 127, 511, 701, 65490, 65533};
            result.seeds[i] = Goal - distances[(sample >> 8) % std::size(distances)];
        }
        else if (options.seeds == "blocked")
        {
            // Narrow traversable lanes and separated islands stress obstacles.
            const auto x = i % options.width, y = i / options.width;
            if (x % 8 == 4 || y % 8 == 4) result.seeds[i] = Blocked;
        }
        else if (options.seeds == "all-blocked") result.seeds[i] = Blocked;
    }
    if (options.seeds != "all-blocked") result.seeds[0] = Goal;
    return result;
}
// Independent wide heap Dijkstra, using historical constants and explicit modulo
// wrapping rather than either source tree's costs/grid/queue implementation.
std::vector<std::uint16_t> oracle(const Fixture &fixture, const Options &options)
{
    constexpr unsigned Infinity = std::numeric_limits<unsigned>::max();
    constexpr unsigned WaterSteps[] = {0, 5, 7, 10, 13, 20, 30};
    std::vector<unsigned> distances(fixture.seeds.size(), Infinity);
    using Entry = std::pair<unsigned, std::size_t>;
    std::priority_queue<Entry, std::vector<Entry>, std::greater<Entry>> queue;
    for (std::size_t i = 0; i < distances.size(); ++i)
        if (fixture.seeds[i] > Unreached)
        {
            distances[i] = Goal - fixture.seeds[i];
            queue.emplace(distances[i], i);
        }
    while (!queue.empty())
    {
        const auto [distance, index] = queue.top(); queue.pop();
        if (distance > unsigned(options.cap)) break;
        if (distance != distances[index]) continue;
        const unsigned cardinal = options.swim && fixture.types[index] == 0
            ? WaterSteps[options.swim] : 10;
        const unsigned diagonal = cardinal * 14 / 10;
        const int x = index % options.width, y = index / options.width;
        for (int dy = -1; dy <= 1; ++dy) for (int dx = -1; dx <= 1; ++dx)
        {
            if (!dx && !dy) continue;
            const std::size_t next = std::size_t((y + dy + options.height) % options.height) * options.width
                + (x + dx + options.width) % options.width;
            const unsigned candidate = distance + (dx && dy ? diagonal : cardinal);
            if (fixture.seeds[next] == Blocked || candidate > unsigned(options.cap)
                || candidate >= distances[next]) continue;
            distances[next] = candidate;
            queue.emplace(candidate, next);
        }
    }
    auto result = fixture.seeds;
    for (std::size_t i = 0; i < result.size(); ++i)
        if (distances[i] != Infinity) result[i] = Goal - distances[i];
    return result;
}
struct Variant
{
    const char *name;
    void *(*create)();
    void (*destroy)(void *);
    WorkspaceInfo (*info)(void *);
    void (*run)(void *, std::uint16_t *, const std::uint16_t *, int, int, int, int, bool);
    void *workspace;
    ~Variant() { destroy(workspace); }
};
void run(const Options &options)
{
    const auto fixture = makeFixture(options);
    const auto expected = oracle(fixture, options);
    const auto n = fixture.seeds.size();
    std::vector<std::uint16_t> output[2]{std::vector<std::uint16_t>(n), std::vector<std::uint16_t>(n)};
    std::vector<std::uint16_t> terrain[2]{std::vector<std::uint16_t>(n), std::vector<std::uint16_t>(n)};
    Variant variants[] = {{"legacy", legacy_create, legacy_destroy, legacy_info, legacy_run, legacy_create()},
                         {"final", final_create, final_destroy, final_info, final_run, final_create()}};
    for (int repetition = -1; repetition < options.repeats; ++repetition)
        for (int order = 0; order < 2; ++order)
        {
            const unsigned which = (order + repetition + 2) % 2;
            auto &variant = variants[which];
            const unsigned allocation = options.layout == "shared" ? 0 : which;
            auto &values = output[allocation];
            auto &input = terrain[allocation];
            const auto initialize = Clock::now();
            const auto &representation = which ? fixture.types : fixture.sprites;
            std::copy(representation.begin(), representation.end(), input.begin());
            std::copy(fixture.seeds.begin(), fixture.seeds.end(), values.begin());
            const auto initializeNs = wallSince(initialize);
            const auto wallStart = Clock::now();
            const auto cpuStart = cpuNow();
            variant.run(variant.workspace, values.data(), input.data(), options.width,
                options.height, options.swim, options.cap, false);
            const auto cpuNs = cpuNow() - cpuStart;
            const auto wallNs = wallSince(wallStart);
            if (values != expected)
                throw std::runtime_error(std::string(variant.name) + " differs from independent oracle");
            const auto memory = variant.info(variant.workspace);
            std::cout << "{\"implementation\":\"" << variant.name << "\",\"repetition\":" << repetition
                << ",\"order\":" << order << ",\"width\":" << options.width << ",\"height\":" << options.height
                << ",\"swim\":" << options.swim << ",\"cap\":" << options.cap << ",\"seeds\":\"" << options.seeds
                << "\",\"layout\":\"" << options.layout << "\",\"cpu_ns\":" << cpuNs << ",\"wall_ns\":" << wallNs
                << ",\"initialization_ns\":" << initializeNs << ",\"field_hash\":\"" << hash(values)
                << "\",\"seed_hash\":\"" << hash(fixture.seeds) << "\",\"terrain_type_hash\":\"" << hash(fixture.types)
                << "\",\"terrain_sprite_hash\":\"" << hash(fixture.sprites) << "\",\"workspace_bytes\":" << memory.objectBytes
                << ",\"queue_retained_bytes\":" << memory.retainedBytes << ",\"bucket_count\":" << memory.bucketCount
                << ",\"output_address\":" << reinterpret_cast<std::uintptr_t>(values.data())
                << ",\"terrain_address\":" << reinterpret_cast<std::uintptr_t>(input.data())
                << ",\"workspace_address\":" << reinterpret_cast<std::uintptr_t>(variant.workspace)
                << ",\"first_queue_address\":" << memory.firstQueueAddress << "}\n";
        }
}
Options parse(int argc, char **argv)
{
    Options result;
    for (int i = 1; i < argc; ++i)
    {
        const std::string key = argv[i];
        if (++i >= argc) throw std::runtime_error("missing argument");
        const std::string value = argv[i];
        if (key == "--width") result.width = std::stoi(value);
        else if (key == "--height") result.height = std::stoi(value);
        else if (key == "--swim") result.swim = std::stoi(value);
        else if (key == "--cap") result.cap = std::stoi(value);
        else if (key == "--repeats") result.repeats = std::stoi(value);
        else if (key == "--seeds") result.seeds = value;
        else if (key == "--layout") result.layout = value;
        else throw std::runtime_error("unknown argument " + key);
    }
    if (result.width < 1 || result.height < 1 || result.width > 512 || result.height > 512
        || result.swim < 0 || result.swim > 6 || result.cap < 0 || result.cap > Cap || result.repeats < 1)
        throw std::runtime_error("invalid numeric parameter");
    if (result.layout != "shared" && result.layout != "separate") throw std::runtime_error("invalid layout");
    const std::vector<std::string> seeds{"single", "sparse", "dense", "deferred", "blocked", "all-blocked"};
    if (std::find(seeds.begin(), seeds.end(), result.seeds) == seeds.end()) throw std::runtime_error("invalid seeds");
    return result;
}
}
int main(int argc, char **argv)
{
    try { run(parse(argc, argv)); }
    catch (const std::exception &error) { std::cerr << error.what() << '\n'; return 1; }
}
