# Exact classic land-field endpoint comparison

Built from archived Git source/header trees at original `934c3c588bea51ec7421152e15f5168b2aaf5502` and final `37d609766374e7efc1679d643c7d18cde84364ab`. Current master source is not used. `manifest.json` records source archives, source/header and executable hashes, compiler, exact commands, and the frozen baseline compile database hash. Baseline dependency/configuration include directories are deliberately shared; both use the original `-O3` flags, with function/data sections and linker garbage collection to omit unrelated engine functions.

Commands from repository root:

```sh
python3 artifacts/terrain-net-performance/fertility/prepare.py
taskset -c 0-3 python3 artifacts/terrain-net-performance/fertility/smoke.py
# Run only after coordination with other benchmarks:
python3 artifacts/terrain-net-performance/fertility/run-pairs.py --cpu 15 --pairs 11 --repeats 9
```

Smoke checks compare the complete baseline and final output bytes with an independent direct 31×31 triangular-weight donor/mirrored-inhibitor oracle. Fixtures cover 1×1, 1×17, 7×5 and 32×32, five layouts, and all three explicit algorithm choices, for 60 cases. Each executable rebuilds twice per case, checking workspace reuse as well. Smoke timings are not performance evidence.

The timing runner alternates executable order for each pair, uses identical deterministic mask generation (historical fixture seed 78311), and logs every sample/address. Construction is measured separately from the first rebuild; the first rebuild includes allocations and metadata preparation. Subsequent rebuilds retain whatever workspace each actual implementation keeps. Input generation and output hashing/dumping are outside rebuild timing. Constructor timings are very small and dominated by timer/allocator overhead; prefer construction-plus-first-rebuild totals. The fixture deliberately does not pre-reserve hidden old workspace or artificially force final workspace retention. Input/output sizes match; addresses and allocator behavior are not forced equal. Separate process/heap allocation is a measurement limitation, recorded in CSV addresses. Hashing and CSV reporting between warm rebuilds use the same protocol for both variants.

`retained_bytes` includes the Field object plus capacities of all its owned vectors; it excludes allocator metadata and temporary peak allocations. It is not peak RSS or whole GrowthCache memory. Final implementation can retain less while allocating temporary scratch during rebuild.

This isolates binary water/sand **land fertility Field::rebuild** with identical outputs. It does not benchmark new aquatic growth, habitat/cache preparation, actual growth attempts or AI cache request frequency. It cannot be applied directly as a percentage of whole-game CPU.
