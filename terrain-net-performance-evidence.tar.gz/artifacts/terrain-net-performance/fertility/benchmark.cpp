#include <cstdint>
#include <vector>
#define private public
#include "map/FertilityField.h"
#undef private
#include <ctime>
#include <fstream>
#include <iostream>
#include <memory>
#include <random>
#include <stdexcept>
#include <string>

static std::uint64_t cpuNow()
{
    timespec value{};
    if (clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &value)) throw std::runtime_error("clock_gettime");
    return std::uint64_t(value.tv_sec) * 1000000000 + value.tv_nsec;
}
static std::uint64_t digest(const std::vector<std::uint32_t>& values)
{
    std::uint64_t result = 1469598103934665603ull;
    for (auto value : values) { result ^= value; result *= 1099511628211ull; }
    return result;
}
int main(int argc, char** argv)
{
    if (argc != 7) return 2;
    const int width = std::stoi(argv[1]), height = std::stoi(argv[2]);
    const int layout = std::stoi(argv[3]), repeats = std::stoi(argv[4]), path = std::stoi(argv[5]);
    if (width < 1 || height < 1 || width > 4096 || height > 4096 || layout < 0 || layout > 4 || repeats < 0 || repeats > 10000 || path < 0 || path > 2) return 2;
    std::vector<std::uint8_t> water(width * height), sand(width * height);
    std::mt19937 rng(78311);
    for (int y = 0; y < height; ++y)
        for (int x = 0; x < width; ++x)
        {
            const auto i = y * width + x;
            const auto r = rng() % 100;
            if (layout == 0) { water[i] = r < 2; sand[i] = r >= 2 && r < 5; }
            else if (layout == 1) { water[i] = x % 32 < 3; sand[i] = x % 32 == 3 || x % 32 == 31; }
            else if (layout == 2) { water[i] = r < 25; sand[i] = r >= 25 && r < 50; }
            else if (layout == 3) { water[i] = 0; sand[i] = 0; }
            else { water[i] = 1; sand[i] = 0; }
        }
    const auto constructionStart = cpuNow();
    auto field = std::make_unique<Fertility::Field>();
    const auto constructionNs = cpuNow() - constructionStart;
    std::cout << "width,height,layout,path,sample,construction_cpu_ns,rebuild_cpu_ns,retained_bytes,digest,water_address,sand_address,output_address\n";
    for (int sample = 0; sample <= repeats; ++sample)
    {
        const auto start = cpuNow();
        field->rebuild(width, height, water, sand, static_cast<Fertility::Path>(path));
        const auto elapsed = cpuNow() - start;
        std::size_t retained = sizeof(*field) + field->fertility.capacity() * sizeof(std::uint32_t);
#ifdef LEGACY_FIELD
        retained += (field->first.capacity() + field->second.capacity()) * sizeof(std::uint16_t);
        retained += (field->wrappedX.capacity() + field->wrappedY.capacity()) * sizeof(int);
#endif
        std::cout << width << ',' << height << ',' << layout << ',' << path << ',' << sample << ','
                  << (sample == 0 ? constructionNs : 0) << ',' << elapsed << ',' << retained << ',' << digest(field->values()) << ','
                  << static_cast<const void*>(water.data()) << ',' << static_cast<const void*>(sand.data()) << ','
                  << static_cast<const void*>(field->values().data()) << '\n';
    }
    const std::string prefix = argv[6];
    if (prefix != "-")
    {
        std::ofstream(prefix + ".water", std::ios::binary).write(reinterpret_cast<const char*>(water.data()), water.size());
        std::ofstream(prefix + ".sand", std::ios::binary).write(reinterpret_cast<const char*>(sand.data()), sand.size());
        std::ofstream(prefix + ".field", std::ios::binary).write(reinterpret_cast<const char*>(field->values().data()), field->values().size() * sizeof(std::uint32_t));
    }
}
