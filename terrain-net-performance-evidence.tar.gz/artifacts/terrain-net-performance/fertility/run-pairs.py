import argparse, csv, hashlib, io, json, os, pathlib, statistics, subprocess
parser = argparse.ArgumentParser()
parser.add_argument('--cpu', type=int, required=True)
parser.add_argument('--pairs', type=int, default=11)
parser.add_argument('--repeats', type=int, default=9)
args = parser.parse_args()
assert args.pairs > 0 and args.repeats > 0
out = pathlib.Path(__file__).resolve().parent
manifest_path = out / 'manifest.json'
manifest = json.loads(manifest_path.read_text())
if (out / 'timing-samples.json').exists():
    raise RuntimeError('Timing samples already exist; preserve them before rerunning.')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
(out / 'timing-run.json').write_text(json.dumps({'cpu': args.cpu, 'pairs': args.pairs, 'repeats': args.repeats, 'manifest_sha256': sha(manifest_path), 'runner_sha256': sha(pathlib.Path(__file__)), 'layouts': ['separate-process allocations; addresses recorded'], 'variants': manifest['revisions']}, indent=2)+'\n')
samples = []
for size in [128, 256, 512]:
    for layout in range(3):
        for pair in range(args.pairs):
            variants = ['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']
            pair_samples = {}
            for variant in variants:
                command = ['taskset', '-c', str(args.cpu), str(out / variant), str(size), str(size), str(layout), str(args.repeats), '0', '-']
                assert sha(out / variant) == manifest['variants'][variant]['binary_sha256']
                load_before = os.getloadavg()
                raw = subprocess.check_output(command, text=True)
                path = out / f'timing-{size}-{layout}-{pair}-{variant}.csv'
                path.write_text(raw)
                rows = list(csv.DictReader(io.StringIO(raw)))
                record = {'size': size, 'layout': layout, 'pair': pair, 'variant': variant, 'command': command, 'load_before': load_before, 'raw_file': str(path), 'raw_sha256': hashlib.sha256(raw.encode()).hexdigest(), 'first_rebuild_cpu_ns': int(rows[0]['rebuild_cpu_ns']), 'construction_and_first_cpu_ns': int(rows[0]['construction_cpu_ns']) + int(rows[0]['rebuild_cpu_ns']), 'warm_median_cpu_ns': statistics.median(int(row['rebuild_cpu_ns']) for row in rows[1:]), 'retained_bytes': int(rows[-1]['retained_bytes']), 'digest': rows[-1]['digest']}
                assert len({row['digest'] for row in rows}) == 1
                samples.append(record)
                pair_samples[variant] = record
                (out / 'timing-samples.json').write_text(json.dumps(samples, indent=2)+'\n')
            assert pair_samples['baseline']['digest'] == pair_samples['candidate']['digest']
summary = []
for size in [128, 256, 512]:
    for layout in range(3):
        chosen = [sample for sample in samples if sample['size'] == size and sample['layout'] == layout]
        groups = {variant: [sample for sample in chosen if sample['variant'] == variant] for variant in ['baseline', 'candidate']}
        row = {'size': size, 'layout': layout}
        for metric in ['construction_and_first_cpu_ns', 'warm_median_cpu_ns']:
            row[metric] = {variant: statistics.median(sample[metric] for sample in group) for variant, group in groups.items()}
            row[metric]['median_paired_candidate_over_baseline'] = statistics.median(c[metric]/b[metric] for b,c in zip(groups['baseline'],groups['candidate']))
        row['retained_bytes'] = {variant: group[-1]['retained_bytes'] for variant,group in groups.items()}
        summary.append(row)
(out / 'timing-summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
