# Accounting for changed simulation trajectories

This investigation compares pre-terrain revision `934c3c588bea51ec7421152e15f5168b2aaf5502` with the completed terrain implementation at `37d609766374e7efc1679d643c7d18cde84364ab`, before unrelated Markets V2/audio integration. Whole-game timings answer net CPU per simulated time under each version's behavior. They do not isolate architectural overhead when the simulations diverge.

## Existing evidence and limits

`artifacts/terrain-refactor/performance/samples.json` contains six historical original/refactor scenario-growth groups. Every group has different final checksums, including disabled growth. For example, disabled-growth allotments ends with 51 versus 54 units; last-treeline ends with 89 versus 79. All report 16,384 gradient jobs. Equal job counts, equal ticks, or disabling growth therefore do not produce equal work. These historical runs predate later optimizations and must not be presented as final performance.

`PerformanceTelemetry.h` documents diagnostic wall-clock scopes. Simulation unit/building scope calls count team passes, not objects processed. Path scopes are sampled (stride 64), while gradient scopes are unsampled. Summing nested inclusive scopes double-counts time; process CPU includes workers while a thread's wall-clock scope does not. There is no dedicated fertility rebuild or resource growth scope. Existing result files expose gradient jobs, publications, hiring entries, population snapshots and sampled team histories; none measures all work. TeamStat history is sampled every 512 ticks and cannot reconstruct exact unit-ticks. Growth outcome statistics omit unsuccessful probes and RNG consumption.

Do not divide total CPU by final population or gradient jobs and call the result architectural overhead. Normal-growth minus disabled-growth runtime also includes changed trajectories. Even exact unit-ticks and cell visits omit branch mix, cache locality, field extent, obstacles and invalidation churn. Regression against such counters can support an exploratory workload model; endogenous, correlated counters cannot establish causal overhead. Do not combine percentages from different benchmark suites by multiplication.

## Recommended evidence layers

1. **Actual endpoint games:** alternating original/final process-CPU samples with identical maps, orders and seeds; report per-scenario CPU/tick and population/work observables, clearly label trajectory differences. Multiple seeds help represent the changed behavior but cannot remove it.
2. **Exact-input component comparisons:** compare both implementations on frozen inputs and assert full output equality. Report preparation, propagation/rebuild and retained memory separately. Weight a captured corpus by observed request frequency only when the capture includes request types and sizes.
3. **Optional diagnostic counters:** instrument object visits, placement candidates/constraint checks, gradient cells/relaxations and growth attempts/cache misses in separate builds; use the uninstrumented binaries for final timing. These explain changes in workload, not a single definitive normalized overhead percentage.

## Best next comparisons beyond gradient propagation

### Classic land fertility field: immediately feasible

The existing `artifacts/terrain-refactor/performance/fertility.cpp` and `compile-fertility.py` compile original and final `Fertility::Field::rebuild` independently. Their interface accepts identical water/sand masks and produces Q16 land fertility. Re-run against the exact final source, not current master. Assert all output bytes, not only a hash. Include sparse donors, channels, dense masks, small wrapped dimensions and real map planes. Separate construction, first rebuild and reuse. Record source/compiler/input/binary hashes and allocations/retained memory where practical.

This is a clean implementation-cost comparison for the classic binary land field. It does not cover the new aquatic growth field, habitat planes, full GrowthCache construction or ongoing resource growth. Original whole games may request this land field at different frequencies from final games. Field speedups cannot be applied directly to total map CPU.

### AI source/obstacle preparation: feasible, additional harness work

`ai/shared_runtime/Gradient.cpp::Gradient::recalculate` and the Maxima counterpart scan cells to evaluate source/obstacle predicates before propagation. Capture dimensions, marker planes, terrain/cost profile, goal order, propagation cap and request category. This yields an exact propagation corpus, but excludes predicate evaluation and request frequency. To time preparation itself, capture map/entity query inputs and compare marker planes; where policies intentionally changed, label it identical-world input rather than identical-output work. Preserve scan order and source precedence. Capture requests from both old and new trajectories to avoid favoring one workload.

### Placement: feasible but substantially more involved

Maxima `BuildingOrder::score_location` combines footprint availability, flag-building checks, perimeter constraints, discovery and corner scores. `find_location` also has exact-position shortcuts and persistent cursor/best-score/budget state; strict score comparison preserves the first tied coordinate. A useful replay needs terrain/occupancy/discovery planes, buildings, team permissions, building type, constraint types/parameters, required gradient planes and ages, and cursor/best/budget state. Clone/reset mutable state and RNG before every trial. Loading a compatible frozen world into each binary then invoking a fixed query could simplify capture, with loading outside the timer. Assert score and chosen coordinates before calling it exact work.

A tape of precomputed callback answers only measures the loop around the predicates: it removes the terrain-property lookups being investigated and cannot establish total placement overhead.

### Growth: only narrower exact comparisons are honest

Original `Map::growResources` uses triangular water/sand probes and conditional random draws. The final path samples cached expected opportunities, including fractional/multiple attempts. Equal expected growth probabilities do not preserve draws, outcomes or future states. A fixed world and random tape can measure each algorithm's cost on the same starting input, but the output work and RNG consumption differ. Primitive habitat checks or matched resource increments can be compared exactly; forcing old decisions into final growth is an ablation, not the actual new algorithm.

Useful separate counters: cells visited, resource-bearing visits, opportunities, amount/expansion attempts and rejections, RNG draws, ecology invalidations and rebuilds. Preserve production RNG behavior in instrumentation.

## Benchmark-only legacy-behavior whole-engine build

A narrow experimental build is technically possible, but merely replacing growth or disabling new terrain does not restore the old trajectory. It would need old RNG consumption and growth decisions, AI source/obstacle policies, placement decisions, scheduling and any other behavior changes. Proving it requires every-tick state/order/route/RNG equality. The hybrid would exclude some of the very new computations whose cost is being estimated and introduce substantial maintenance/validation work.

Recommendation: do not begin a broad legacy-semantics hybrid now. First use endpoint games plus exact gradient/land-field comparisons. Only build a narrow ablation if profiling identifies a dominant, separable boundary and state clearly which new work it removes. Report real-game CPU, workload observables and exact-input component CPU side by side, rather than collapsing them into one adjusted percentage.
