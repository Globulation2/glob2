from pathlib import Path
import json,shlex,subprocess,hashlib,re
root=Path.cwd();out=root/'artifacts/terrain-net-performance/growth';fert=root/'artifacts/terrain-net-performance/fertility'
revs={'baseline':'934c3c588bea51ec7421152e15f5168b2aaf5502','candidate':'37d609766374e7efc1679d643c7d18cde84364ab'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def body(text,start):
 at=text.index('{',start);level=1;end=at+1
 while level:
  level+=(text[end]=='{')-(text[end]=='}');end+=1
 return text[at:end]
def method(text,signature):
 start=text.index(signature);return text[start:text.index('{',start)]+body(text,start)
manifest={'revisions':revs,'affinity':'0-3 compile/smoke only; timing withheld','method':'Exact source inner tile-visit body, fixed input indices. Mutation gate false only after probability/amount/direction branches. Real archived helpers, RNG and resource types; no Map instance or full engine objects linked.','variants':{}}
db=json.loads(Path('/tmp/glob2-terrain-baseline-build/compile_commands.json').read_text())
for name,rev in revs.items():
 src=fert/('source-'+name);assert (src/'src/map/Map.h').read_text()==subprocess.check_output(['git','show',rev+':src/map/Map.h'],text=True)
 step=(src/'src/map/MapStep.cpp').read_text();mh=(src/'src/map/Map.h').read_text()
 start=step.index('void Map::growResources(void)');loop=step.index('for (int x=' if name=='baseline' else 'for(int x=',start);visit=body(step,loop)
 visit=visit.replace('globalContainer->resourcesTypes','resourceTypes').replace('Fertility::applyGrowthOpportunities','apply')
 visit=visit.replace('const Resource &r = getResource(x, y);','const Resource &r = getResource(x, y);')
 if name=='baseline':
  visit=visit.replace('if (expand && (scarcity==1 || syncRand()%scarcity==0))','if(expand) GROWTH_COUNT(opportunities);\n if (expand && (scarcity==1 || syncRand()%scarcity==0))')
 code=['// Generated from exact revision '+rev,'#include "Fixture.h"']
 if name=='candidate':
  func=method(step,'void Fertility::applyGrowthOpportunities(').replace('void Fertility::applyGrowthOpportunities(Map& map','void apply(Fixture& map').replace('globalContainer->resourcesTypes','resourceTypes')
  func=func.replace('for(unsigned attempt=0;attempt<opportunities;++attempt)\n    {','for(unsigned attempt=0;attempt<opportunities;++attempt)\n    {\n GROWTH_COUNT(opportunities);')
  code.append('using Fertility::growthOpportunities;\n'+func)
 code.append('void Fixture::visit(int x,int y,int scarcity) '+visit)
 code.append('void Fixture::run(const std::vector<std::pair<int,int>>& indices,int scarcity,int batches) { for(int batch=0;batch<batches;++batch) for(const auto [x,y]:indices) visit(x,y,scarcity); }')
 helper=[]
 for sig in ['inline size_t coordToIndex(int x, int y) const','inline Uint16 getTerrain(int x, int y) const','const Resource& getResource(int x, int y) const','bool canResourcesGrow(int x, int y) const']:
  helper.append(method(mh,sig))
 if name=='baseline':
  helper += [method(mh,'bool isWater(int x, int y) const'),method(mh,'bool isSand(int x, int y) const')]
 helpers='\n'.join(helper).replace('return getTile(x, y).canResourcesGrow','GROWTH_COUNT(gates); return getTile(x, y).canResourcesGrow')
 # Older gate is a differently spelled direct tile return.
 if 'GROWTH_COUNT(gates)' not in helpers:
  gate=method(mh,'bool canResourcesGrow(int x, int y) const');helpers=helpers.replace(gate,gate.replace('{','{ GROWTH_COUNT(gates);',1))
 v=out/name;v.mkdir(exist_ok=True);(v/'Visit.cpp').write_text('\n'.join(code));(v/'Helpers.inc').write_text(helpers+'\n')
 compile_entry=next(x for x in db if x['file'].endswith('FertilityField.cpp'))
 base=shlex.split(compile_entry['command']);base+=['-ffunction-sections','-fdata-sections'];base.insert(1,'-I'+str(v));base.insert(1,'-I'+str(out))
 if name=='candidate':base.insert(1,'-DCANDIDATE')
 commands=[];objects=[]
 for unit,file in [('Utilities',src/'src/common/Utilities.cpp'),('Resources',src/'src/resource/Resources.cpp'),('Visit',v/'Visit.cpp'),('Harness',out/'harness.cpp')]:
  cmd=base.copy();obj=v/(unit+'.o');cmd[cmd.index('-o')+1]=str(obj)
  # Source argument appears before appended section flags.
  source_index=next(i for i,x in enumerate(cmd) if x.endswith('FertilityField.cpp'));cmd[source_index]=str(file)
  command=['taskset','-c','0-3',*cmd];commands.append(command)
  with (v/(unit+'.build.log')).open('w') as log:subprocess.run(command,cwd=src,stdout=log,stderr=subprocess.STDOUT,check=True)
  objects.append(str(obj))
 if name=='candidate':objects.append(str(fert/'candidate.o'))
 for counted in [False,True]:
  chosen=objects.copy()
  if counted:
   for unit,file in [('Visit',v/'Visit.cpp'),('Harness',out/'harness.cpp')]:
    cmd=base.copy();cmd.insert(1,'-DCOUNT_GROWTH');obj=v/(unit+'-counted.o');cmd[cmd.index('-o')+1]=str(obj);cmd[next(i for i,x in enumerate(cmd) if x.endswith('FertilityField.cpp'))]=str(file);command=['taskset','-c','0-3',*cmd];commands.append(command)
    with (v/(unit+'-counted.build.log')).open('w') as log:subprocess.run(command,cwd=src,stdout=log,stderr=subprocess.STDOUT,check=True)
    chosen[objects.index(str(v/(unit+'.o')))]=str(obj)
  binary=v/('counted' if counted else 'timed');command=['taskset','-c','0-3','g++','-Wl,--gc-sections',*chosen,'-o',str(binary)];commands.append(command)
  with (v/(binary.name+'.link.log')).open('w') as log:subprocess.run(command,cwd=src,stdout=log,stderr=subprocess.STDOUT,check=True)
 manifest['variants'][name]={'revision':rev,'cwd':str(src),'commands':commands,'binary_sha256':{n:sha(v/n) for n in ['timed','counted']},'source_sha256':{str(p.relative_to(src)):sha(p) for p in [src/'src/map/MapStep.cpp',src/'src/map/Map.h',src/'src/common/Utilities.cpp',src/'src/common/MersenneTwister.h',src/'src/resource/Resources.cpp']},'generated_sha256':{p.name:sha(p) for p in [v/'Visit.cpp',v/'Helpers.inc']}}
manifest['harness_sha256']=sha(out/'harness.cpp');manifest['fixture_sha256']=sha(out/'Fixture.h');manifest['cache_object_sha256']=sha(fert/'candidate.o');manifest['cache_object_manifest']='../fertility/manifest.json';(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
