"""Restricted fixed-input decisions only. Run after coordinator releases timing CPU."""
from pathlib import Path
import argparse, datetime, hashlib, json, math, random, statistics, subprocess, shutil, re

ROOT = Path(__file__).resolve().parent
VARIANTS = ('baseline', 'candidate')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path, obj): path.write_text(json.dumps(obj, indent=2) + '\n')
def parse_case(value):
    try:
        case = tuple(map(int, value.split(',')))
        assert len(case) == 5
        w,l,m,amount,scarcity = case
        assert 16 <= w <= 512 and w & (w-1) == 0
        assert l in range(3) and m in range(5) and amount > 0 and scarcity > 0
        return case
    except (ValueError, AssertionError):
        raise argparse.ArgumentTypeError('case must be WIDTH,LAYOUT(0..2),MODE(0..4),AMOUNT,SCARCITY')
def ci(values):
    rng = random.Random(67191)
    boot = sorted(statistics.median(rng.choices(values, k=len(values))) for _ in range(5000))
    return [boot[125], boot[4874]]

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--cpu', type=int, default=15)
p.add_argument('--pairs', type=int, default=11)
p.add_argument('--batches', type=int, help='override adaptive batch count')
p.add_argument('--minimum-visits', type=int, default=262144)
p.add_argument('--output', type=Path, required=True, help='new or empty output directory')
p.add_argument('--preset', choices=('representative','full'), default='representative')
p.add_argument('--amounts', default='1,5', help='natural default; 1,8 explicitly opts into non-natural stress')
p.add_argument('--case', type=parse_case, action='append', help='repeat to replace preset matrix')
p.add_argument('--plan-only', action='store_true', help='write reproducibility manifest without executing timings')
a = p.parse_args()
if a.pairs < 1 or a.minimum_visits < 1 or (a.batches is not None and a.batches < 1): p.error('counts must be positive')
amounts = tuple(map(int, a.amounts.split(',')))
if not amounts or min(amounts) < 1: p.error('amounts must be positive')
if a.output.exists() and any(a.output.iterdir()): p.error('output must be fresh: directory is nonempty')
a.output.mkdir(parents=True, exist_ok=True)
if a.case:
    cases = list(dict.fromkeys(a.case))
elif a.preset == 'representative':
    cases = [(w,l,m,n,1) for w in (128,512) for l in range(3) for m in range(4) for n in amounts]
    cases.append((128,0,4,1,1))
else:
    cases = [(w,l,m,n,s) for w in (32,128,512) for l in range(3) for m in range(5) for n in amounts for s in (1,4)]
hashes = {v: sha(ROOT/v/'timed') for v in VARIANTS}
smoke = json.loads((ROOT/'smoke.json').read_text())
assert len(smoke) == 240, 'run full instrumented/timed smoke first'
for variant in VARIANTS:
    for row in (r for r in smoke if r['variant'] == variant and r['build'] == 'timed'):
        peer = next(r for r in smoke if r['variant'] == variant and r['build'] == 'counted' and all(r[k] == row[k] for k in ('width','layout','resource_mode','amount','scarcity')))
        assert all(row[k] == peer[k] for k in ('input_hash','next_random','visits','occupied_visits'))
source_manifest = json.loads((ROOT/'manifest.json').read_text())
for variant in VARIANTS:
    assert hashes[variant] == source_manifest['variants'][variant]['binary_sha256']['timed']
compiler = Path(shutil.which('g++')).resolve()
libraries = {}
for variant in VARIANTS:
    output = subprocess.check_output(['ldd',str(ROOT/variant/'timed')],text=True)
    for path in re.findall(r'(/[^\s]+)', output):
        pth=Path(path)
        if pth.is_file(): libraries[str(pth.resolve())]=sha(pth)

plan = {
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Restricted source-extracted fixed-index decisions, saved growth gate false after probability/amount/direction; no mutation or full Map prelude.',
    'assertion_mode': 'Original production compile_commands flags; no additional NDEBUG definition.',
    'cpu':a.cpu, 'pairs':a.pairs, 'minimum_visits':a.minimum_visits, 'batches_override':a.batches,
    'cases':[dict(width=w,layout=l,resource_mode=m,amount=n,scarcity=s,batches=a.batches or math.ceil(a.minimum_visits/(w*w))) for w,l,m,n,s in cases],
    'binary_sha256':hashes,
    'artifact_sha256':{f:sha(ROOT/f) for f in ('run-pairs.py','prepare.py','Fixture.h','harness.cpp','smoke.py','smoke.json','manifest.json')},
    'source_build_manifest':source_manifest,
    'fertility_build_manifest':json.loads((ROOT.parent/'fertility/manifest.json').read_text()),
    'compiler':{'path':str(compiler),'sha256':sha(compiler),'version':subprocess.check_output([str(compiler),'--version'],text=True)},
    'linked_libraries_sha256':libraries,
    'assembly_review_sha256':sha(ROOT/'assembly/review.json'),
    'amounts_above_natural_max_are_stress':any(c[3]>5 for c in cases),
    'break_even_limits':'Field kernels only divided by restricted per-visit decision savings. Excludes Map cache donor gather, locking/acquisition, invalidation, scan loop/RNG, and successful mutations. Not full cache payback or game tick estimate.',
}
dump(a.output/'manifest.json', plan)
if a.plan_only:
    print(f'Prepared {len(cases)} cases without timings'); raise SystemExit
rows=[]
for case_index, spec in enumerate(cases):
    w,l,m,amount,scarcity=spec
    batches=a.batches or math.ceil(a.minimum_visits/(w*w))
    for repeat in range(a.pairs):
        pair={}
        for variant in (VARIANTS if repeat%2 == 0 else VARIANTS[::-1]):
            binary=ROOT/variant/'timed'
            before=sha(binary)
            assert before == hashes[variant], 'binary changed since plan'
            cmd=['taskset','-c',str(a.cpu),str(binary),str(w),str(l),str(m),str(amount),str(batches),str(1427+repeat),str(scarcity)]
            d=json.loads(subprocess.check_output(cmd,text=True))
            assert sha(binary) == before, 'binary changed during run'
            d.update(variant=variant,repeat=repeat,case_index=case_index,command=cmd,binary_sha256=before)
            pair[variant]=d; rows.append(d)
            dump(a.output/'samples.json',rows)
        assert pair['baseline']['input_hash']==pair['candidate']['input_hash']
        assert pair['baseline']['visits']==pair['candidate']['visits']
    print(case_index+1,'/',len(cases),flush=True)
summary=[]
for i,spec in enumerate(cases):
    w,l,m,amount,scarcity=spec
    g=[r for r in rows if r['case_index']==i]
    ns={v:statistics.median(r['cpu_ns']/r['visits'] for r in g if r['variant']==v) for v in VARIANTS}
    ratios=[]
    for repeat in range(a.pairs):
        pair={r['variant']:r for r in g if r['repeat']==repeat}
        ratios.append(pair['candidate']['cpu_ns']/pair['baseline']['cpu_ns'])
    cold=statistics.median(r['cache_fields_cold_cpu_ns'] for r in g if r['variant']=='candidate')
    delta=ns['baseline']-ns['candidate']
    summary.append(dict(width=w,layout=l,resource_mode=m,amount=amount,scarcity=scarcity,
        ns_per_fixed_visit=ns,ratio_of_marginal_medians=ns['candidate']/ns['baseline'],
        paired_cpu_ratios=ratios,median_paired_cpu_ratio=statistics.median(ratios),paired_median_bootstrap_ci95=ci(ratios),
        candidate_field_preparation_cpu_ns=cold,restricted_decision_field_only_break_even_visits=cold/delta if delta>0 else None))
dump(a.output/'summary.json',summary)
print('Completed; paired ratios are restricted decision costs, not whole-game speedups.')
