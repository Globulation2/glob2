// Generated from exact revision 934c3c588bea51ec7421152e15f5168b2aaf5502
#include "Fixture.h"
void Fixture::visit(int x,int y,int scarcity) {
			const Resource &r = getResource(x, y);
			if (r.type!=NO_RES_TYPE)
			{
				// we look around to see if there is any water :
				// TODO: uses UnderMap.
				int dwax=(syncRand()&0xF)-(syncRand()&0xF);
				int dway=(syncRand()&0xF)-(syncRand()&0xF);
				int wax1=x+dwax;
				int way1=y+dway;

				int wax2=x+dway*2;
				int way2=y+dwax*2;

				int wax3=x-dwax;
				int way3=y-dway;

				// alga, wood and wheat are limited by near underground. Others are not.
				bool expand=true;
				if (r.type == ALGA)
					expand = isWater(wax1, way1) && isSand(wax2, way2);
				else if (r.type == WOOD)
					expand = isWater(wax1, way1) && (!isSand(wax3, way3));
				else if (r.type == WHEAT)
					expand = isWater(wax1, way1) && (!isSand(wax3, way3));

				// Growth rate of wheat is 1/WHEAT_GROWTH_DIVISOR
				if(r.type == WHEAT && expand)
					if(syncRand() % WHEAT_GROWTH_DIVISOR != 0)
						expand = false;

				if(expand) GROWTH_COUNT(opportunities);
 if (expand && (scarcity==1 || syncRand()%scarcity==0))
				{
					if (r.amount<=(syncRand()&7))
					{
						// we grow resource:
						if(canResourcesGrow(x, y))
						{
							const int beforeType = r.type, beforeAmount = r.amount;
							incResource(x, y, beforeType, r.variety);
							recordNaturalGrowth(x,y,beforeType,beforeType,beforeAmount);
						}
					}
					else if (resourceTypes.get(r.type)->expendable)
					{
						// we extend resource:
						int dx, dy;
						Unit::dxDyFromDirection((syncRand()&7), &dx, &dy);
						int nx=x+dx;
						int ny=y+dy;
						if(canResourcesGrow(nx, ny))
						{
							const Resource &before = getResource(nx, ny);
							const int beforeType = before.type, beforeAmount = before.amount;
							incResource(nx, ny, r.type, r.variety);
							recordNaturalGrowth(nx,ny,r.type,beforeType,beforeAmount);
						}
					}
				}
			}
		}
void Fixture::run(const std::vector<std::pair<int,int>>& indices,int scarcity,int batches) { for(int batch=0;batch<batches;++batch) for(const auto [x,y]:indices) visit(x,y,scarcity); }