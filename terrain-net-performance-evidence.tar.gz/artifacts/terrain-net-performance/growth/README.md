# Fixed-input resource-growth decisions: preparation and limits

This is an **isolated, source-extracted decision benchmark**, not a full `Map::growResources` benchmark or a net game-performance result. Timing has deliberately not been run while the coordinator's game measurements are active. Smoke timings are not performance evidence.

## Exact source and retained computation

- Legacy revision: `934c3c588bea51ec7421152e15f5168b2aaf5502`.
- Final revision: `37d609766374e7efc1679d643c7d18cde84364ab`.
- `prepare.py` reads both frozen source archives made by the adjacent fertility experiment. It verifies each archived `Map.h` against `git show` for the exact revision.
- Each generated `Visit.cpp` contains the complete production inner tile-visit body from `MapStep.cpp`, selected by brace-balanced extraction. Final also contains the complete production `Fertility::applyGrowthOpportunities` body. There is no hand-written substitute for the probability arithmetic, rejection sampling, scarcity test, amount roll or expansion-direction decision.
- Frozen `Utilities.cpp` is compiled independently for each revision. Its real `SyncRandScope`, `syncRandEngine` and MT19937 implementation run with an explicitly bound stream, as in gameplay.
- Frozen `Resources.cpp` supplies the real resource metadata/accessor. `Tile` and `Resource` use the actual archived declarations (both measured Tile layouts are 36 bytes).
- Legacy wrapping, resource access, terrain probes and growth gate helpers are extracted directly from archived `Map.h`. Final uses its production cache `rate()` and field kernels from the exact `37d609766` object compiled by the fertility experiment. Header access control is opened solely to seed test cache storage; its storage layout is unchanged.
- Metadata/source/compile/binary hashes and commands are in `manifest.json`. The final field object's hash and build manifest are recorded there. No current-master `Map` objects or overwritten engine object files are linked.

The loop supplies the same fixed coordinate list and terrain/resource/amount inputs to both implementations. A common batch loop resides beside the extracted visits so the compiler can inline them; it replaces the production randomized tile-selection loop, whose cost and different RNG consumption are outside this measurement.

The only source adaptations within the visit paths are method/type qualification for the fixture, direct access to the actual read-only `ResourcesTypes` object instead of `globalContainer->resourcesTypes`, and optional counter hooks. Mutating methods abort if called. These adaptations and generated code are retained for inspection.

## Why inputs stay fixed without eliminating the decisions

Every tile's existing saved `canResourcesGrow` override is false. **That gate is tested after** the terrain probability, scarcity and amount decisions; expandable resources also compute a random direction before testing the target gate. The original branch order is retained. No mutation, harvest, unit movement or AI execution occurs between visits, so there is no changed-world trajectory contaminating the comparison.

This excludes successful `incResource` work, mutation-side terrain/resource/occupancy restrictions, bookkeeping in `recordNaturalGrowth`, and any terrain-permission work short-circuited by the false saved override. It does **not** time ordinary growth on an unrestricted live map.

`smoke.py` checked 60 cases (three terrain layouts; mixed/wood/wheat/algae/stone resource modes; amounts 1/5; scarcity 1/4), with baseline/final and timed/counter builds: 240 small runs pinned to CPUs 0–3. Inputs match across revisions, inputs remain unchanged, and instrumented/uninstrumented RNG states match **within each revision**. Cross-revision RNG states and opportunity counts deliberately do not match; the refactor changed its sampling method.

For example, one 32² river fixture with 864 occupied wood visits and amount 5 produced:

| Revision | RNG draws | Growth/extension gate calls |
| --- | ---: | ---: |
| Legacy | 3,583 | 79 |
| Final | 982 | 69 |

The corresponding wheat fixture used 3,557 versus 900 draws, with 24 versus 20 gate calls. These are **single-seed smoke work counts**, not a CPU-speed claim or growth-rate calibration. They demonstrate that the candidate benchmark performs real probability and attempt decisions. Timed-binary disassembly in `assembly/` confirms actual retained RNG calls and tile-byte gate loads (including final `cmpb $0x0,0x1e(%rdx)`), so these results do not rely solely on the instrumented binary. Both exact-source compilations preserve production assertion mode: preprocessing confirms `NDEBUG` is undefined in both; no benchmark-only `-DNDEBUG` was added. Stone also exposes removed useless legacy decisions: it consumed draws in the old loop even when no resource mutation could result.

## Running after the timing CPU is released

```sh
python3 artifacts/terrain-net-performance/growth/run-pairs.py --cpu 15 --pairs 11 --output artifacts/terrain-net-performance/growth/paired
```

The default representative preset has 49 cases: widths 128/512 × three terrain layouts × mixed/wood/wheat/algae × natural amounts 1/5 × scarcity 1, plus a sparse 128² stone control. Adaptive batches cover at least 262,144 visits (16 at 128²; one at 512²). `--preset full` opts into 180 cases across widths 32/128/512, all five resource modes, natural amounts 1/5 and scarcity 1/4. `--case 128,1,1,5,1` replaces the preset; repeat it for selected cases. `--amounts 1,8` explicitly selects non-natural boundary stress; real resource metadata caps the tested resource amounts at five. `--batches` overrides adaptive batching. Eleven alternating pairs vary the RNG seed while preserving each pair's exact input distribution. These runs must not overlap other timing work. `--plan-only` writes provenance without timings. The output directory must be new or empty. Each run verifies its binary hash before and after execution; manifests include compiler, library, source, harness, runner and smoke hashes. Summary JSON contains individual paired CPU ratios, their median and a bootstrap interval, separately from the ratio of marginal medians. The binaries also accept individual cases:

```text
baseline/timed WIDTH LAYOUT RESOURCE_MODE AMOUNT BATCHES SEED SCARCITY
candidate/timed WIDTH LAYOUT RESOURCE_MODE AMOUNT BATCHES SEED SCARCITY
```

Layouts: 0 sparse water/sand, 1 regular river banks, 2 dense mixed classic terrain. Resource modes: 0 mixed, 1 wood, 2 wheat, 3 algae, 4 stone. Placement respects classic habitats. Timed binaries have all counters disabled; counted binaries are for work accounting only.

`cpu_ns / visits` includes empty tile checks and all executed extracted decision work. `occupied_visits` permits a separate normalized view. Do not substitute one denominator for the other without labeling it.

Candidate field preparation is measured separately. It calls the exact final land/aquatic kernels and applies local multipliers, but donor/inhibition fixture assembly occurs outside that timer; the number is **not the complete real Map cache-rebuild cost**. Warm decision timing excludes that preparation. The runner's conditional break-even calculation divides this restricted preparation cost by the observed per-visit saving: it is a component-only scenario, not a claim about ticks or whole-game payback.

## What remains unidentified

This benchmark cannot determine the net CPU impact of the terrain refactor by itself. It excludes:

- Random row/column visitation and its extra RNG draws.
- `Map::resourceGrowthField` locking/acquisition, terrain revision checks, and the exact cache-building prelude.
- `rebuildGrowthCoverage`, game-rule checks, complete Map/Game object layout and cache interaction, and the global-container pointer indirection.
- Successful mutation, occupancy checks, habitat checks short-circuited by the false override, growth telemetry/statistics, or later effects on resource stocks and AI work.
- The distribution of actual attempted resource types/amounts over a changing game.

Natural amount-five fixtures exercise the expansion branch alongside the amount-one stacking branch. Any earlier amount-eight smoke numbers are historical stress measurements, excluded from the natural default matrix. Pure-field cold costs may overlap work already needed by AI fertility analysis; do not double-count them when combining experiments.

Full-game old/final runs necessarily evolve differently. The direct game measurements quantify observed totals; this fixed-input experiment can attribute a restricted decision-path change once independently timed. It cannot justify subtracting changed AI workload from whole-game CPU or inventing a single intrinsic overhead percentage.
