from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parent
rows=[]
for layout in range(3):
 for mode in range(5):
  for amount in (1,5):
   for scarcity in (1,4):
    pair={}
    for variant in ('baseline','candidate'):
     versions={}
     for build in ('timed','counted'):
      cmd=['taskset','-c','0-3',str(root/variant/build),'32',str(layout),str(mode),str(amount),'1','1427',str(scarcity)]
      r=subprocess.run(cmd,text=True,capture_output=True,check=True);d=json.loads(r.stdout);d.update(variant=variant,build=build,command=cmd);rows.append(d);versions[build]=d
     for key in ('input_hash','next_random','visits','occupied_visits'):
      assert versions['timed'][key]==versions['counted'][key],(variant,key)
     pair[variant]=versions['counted']
    assert pair['baseline']['input_hash']==pair['candidate']['input_hash']
    assert pair['baseline']['visits']==pair['candidate']['visits']==1024
assert sum(r['gates'] for r in rows if r['variant']=='candidate' and r['build']=='counted')>0
assert sum(r['opportunities'] for r in rows if r['variant']=='candidate' and r['build']=='counted')>0
(root/'smoke.json').write_text(json.dumps(rows,indent=2)+'\n')
print('PASS60fixed-inputcases;240runs; instrumented/timed RNGstateagreement; actualcandidate probability andgate work nonzero. No timing claims.')
