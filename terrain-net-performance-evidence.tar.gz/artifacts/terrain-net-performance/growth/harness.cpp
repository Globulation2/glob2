#include "Fixture.h"
#undef syncRand
#include <ctime>
#include <iostream>
#include <stdexcept>
#include <string>
#include <chrono>
Counts counts;
ResourcesTypes resourceTypes;
std::uint64_t cpuNow(){timespec t{};clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);return std::uint64_t(t.tv_sec)*1000000000+t.tv_nsec;}
int main(int argc,char**argv){try{
 if(argc!=8)throw std::runtime_error("usage: binary width layout resource-mode amount batches seed scarcity");
 const int w=std::stoi(argv[1]),layout=std::stoi(argv[2]),resourceMode=std::stoi(argv[3]),amount=std::stoi(argv[4]),batches=std::stoi(argv[5]),seed=std::stoi(argv[6]),scarcity=std::stoi(argv[7]);
 if(w<16||w>512||(w&(w-1))||layout<0||layout>2||resourceMode<0||resourceMode>4||amount<1||amount>8||batches<1||scarcity<1)throw std::runtime_error("invalid parameters");
 Fixture map;map.w=map.h=w;map.wMask=map.hMask=w-1;map.wDec=0;while((1<<map.wDec)<w)++map.wDec;const std::size_t n=w*w;map.tiles.resize(n);
#ifdef CANDIDATE
 map.types.resize(n);std::vector<std::int16_t> donor(n);std::vector<std::uint16_t> inhibition(n);
#endif
 MersenneTwister fixtureRandom(78311);std::uint64_t inputHash=1469598103934665603ULL,occupied=0;
 for(int y=0;y<w;++y)for(int x=0;x<w;++x){auto i=std::size_t(y)*w+x;auto r=fixtureRandom()%100;int t;
 if(layout==0)t=r<2?WATER:r<5?SAND:GRASS;
 else if(layout==1)t=x%32<3?WATER:(x%32==3||x%32==31)?SAND:GRASS;
 else t=r<20?WATER:r<35?SAND:GRASS;
 auto&tile=map.tiles[i];tile.terrain=t==WATER?256:t==SAND?128:0;tile.canResourcesGrow=0;
 int type=NO_RES_TYPE;if(t==WATER&&(resourceMode==0||resourceMode==3))type=ALGA;
 if(t==GRASS)type=resourceMode==1?WOOD:resourceMode==2?WHEAT:resourceMode==4?STONE:resourceMode==3?NO_RES_TYPE:int((i*37)%4);
 tile.resource.type=type;tile.resource.amount=type==NO_RES_TYPE?0:amount;tile.resource.variety=0;tile.resource.animation=0;
 if(type!=NO_RES_TYPE)++occupied;
 inputHash=(inputHash^tile.terrain)*1099511628211ULL;inputHash=(inputHash^tile.resource.getUint32())*1099511628211ULL;
#ifdef CANDIDATE
 map.types[i]=static_cast<TerrainType>(t);donor[i]=t==WATER?256:0;inhibition[i]=t==SAND?256:0;
#endif
 }
 const auto cold=cpuNow();
#ifdef CANDIDATE
 // Actual frozen production field kernels and local property values. This is
 // preparation only: Map cache locking/acquisition/coverage are out of scope.
 auto&cache=map.ecology;cache.localGrowth.assign(n,256);cache.growthHabitats.resize(n);
 for(std::size_t i=0;i<n;++i){const auto&p=terrainProperties(map.types[i]);cache.growthHabitats[i]=p.resourcesGrow?p.allowedResources:0;}
 cache.land.rebuildWeighted(w,w,donor,inhibition);cache.aquatic=Fertility::shoreGrowthField(w,w,donor,inhibition);cache.land.multiplyLocal(cache.localGrowth);cache.ready=true;
#endif
 const auto coldNs=cpuNow()-cold;
 std::vector<std::pair<int,int>> visits(n);for(std::size_t ordinal=0;ordinal<n;++ordinal){const auto i=(ordinal*541+17)&(n-1);visits[ordinal]={int(i%w),int(i/w)};}
 MersenneTwister engine(seed);SyncRandScope bound(engine);counts={};
 const auto wall=std::chrono::steady_clock::now();const auto start=cpuNow();
 map.run(visits,scarcity,batches);
 const auto ns=cpuNow()-start;const auto wallNs=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-wall).count();
 std::uint64_t after=1469598103934665603ULL;for(const auto&tile:map.tiles){after=(after^tile.terrain)*1099511628211ULL;after=(after^tile.resource.getUint32())*1099511628211ULL;}if(after!=inputHash)throw std::runtime_error("fixed input mutated");
 const auto next=::syncRand();std::cout<<"{\"width\":"<<w<<",\"layout\":"<<layout<<",\"resource_mode\":"<<resourceMode<<",\"amount\":"<<amount<<",\"scarcity\":"<<scarcity<<",\"seed\":"<<seed<<",\"batches\":"<<batches<<",\"visits\":"<<n*batches<<",\"occupied_visits\":"<<occupied*batches<<",\"input_hash\":\""<<inputHash<<"\",\"next_random\":"<<next<<",\"cpu_ns\":"<<ns<<",\"wall_ns\":"<<wallNs<<",\"cache_fields_cold_cpu_ns\":"<<coldNs<<",\"draws\":"<<counts.draws<<",\"opportunities\":"<<counts.opportunities<<",\"gates\":"<<counts.gates<<",\"tile_bytes\":"<<sizeof(Tile)<<",\"instrumented\":"
#ifdef COUNT_GROWTH
 <<"true"
#else
 <<"false"
#endif
 <<"}\n";
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
