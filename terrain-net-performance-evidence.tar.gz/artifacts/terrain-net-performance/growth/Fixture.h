#pragma once
#include <cstdint>
#include <vector>
#include <cassert>
#ifdef CANDIDATE
// Test-only access to cache storage; no field layout changes.
#define private public
#include "map/FertilityField.h"
#undef private
#endif
#include "Map.h"
#include "Unit.h"
#include "MapInternal.h"
#include "Utilities.h"
#include "RessourceType.h"
#include <cstdlib>
struct Counts {std::uint64_t draws=0,opportunities=0,gates=0;};
extern Counts counts;
extern ResourcesTypes resourceTypes;
#ifdef COUNT_GROWTH
#define GROWTH_COUNT(name) (++counts.name)
#else
#define GROWTH_COUNT(name) ((void)0)
#endif
inline Uint32 growthRandom() {GROWTH_COUNT(draws);return ::syncRand();}
struct Fixture;
void apply(Fixture&,int,int,std::uint32_t,int);
struct Fixture {
 int w,h,wMask,hMask,wDec;
 std::vector<Tile> tiles;
#ifdef CANDIDATE
 std::vector<TerrainType> types;
 Fertility::GrowthCache ecology;
 const TerrainProperties& terrainPropertiesAt(int x,int y) const {return terrainProperties(types[coordToIndex(x,y)]);}
#endif
 const Tile& getTile(int x,int y) const {return tiles[coordToIndex(x,y)];}
 #include "Helpers.inc"
 [[gnu::noinline]] bool incResource(int,int,int,int){std::abort();}
 [[gnu::noinline]] void recordNaturalGrowth(int,int,int,int,int){std::abort();}
 void visit(int x,int y,int scarcity);
 void run(const std::vector<std::pair<int,int>>&,int scarcity,int batches);
};
#define syncRand growthRandom
