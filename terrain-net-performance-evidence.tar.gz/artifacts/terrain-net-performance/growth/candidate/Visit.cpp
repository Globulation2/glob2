// Generated from exact revision 37d609766374e7efc1679d643c7d18cde84364ab
#include "Fixture.h"
using Fertility::growthOpportunities;
void apply(Fixture& map,int x,int y,std::uint32_t rate,int scarcity)
{
    static_assert(MersenneTwister::min()==0 && MersenneTwister::max()==UINT32_MAX);
    assert(scarcity>=1);
    const unsigned opportunities=growthOpportunities(rate,[]{return syncRand();});
    for(unsigned attempt=0;attempt<opportunities;++attempt)
    {
 GROWTH_COUNT(opportunities);
        if(scarcity!=1 && syncRand()%scarcity!=0) continue;
        // Re-read the source after each attempt: growth can change its amount.
        const Resource& resource=map.getResource(x,y);
        if(resource.type==NO_RES_TYPE) break;
        if(resource.amount<=(syncRand()&7))
        {
            if(map.canResourcesGrow(x,y))
            {
                const int type=resource.type, amount=resource.amount;
                map.incResource(x,y,type,resource.variety);
                map.recordNaturalGrowth(x,y,type,type,amount);
            }
        }
        else if(resourceTypes.get(resource.type)->expendable)
        {
            int dx,dy;
            Unit::dxDyFromDirection(syncRand()&7,&dx,&dy);
            const int nx=x+dx,ny=y+dy;
            if(map.canResourcesGrow(nx,ny))
            {
                const auto& before=map.getResource(nx,ny);
                const int oldType=before.type,oldAmount=before.amount,type=resource.type;
                map.incResource(nx,ny,type,resource.variety);
                map.recordNaturalGrowth(nx,ny,type,oldType,oldAmount);
            }
        }
    }
}
void Fixture::visit(int x,int y,int scarcity) {
            const auto& resource=getResource(x,y);
            if(resource.type!=NO_RES_TYPE)
                apply(*this,x,y,
                    ecology.rate(coordToIndex(x,y),resource.type),scarcity);
        }
void Fixture::run(const std::vector<std::pair<int,int>>& indices,int scarcity,int batches) { for(int batch=0;batch<batches;++batch) for(const auto [x,y]:indices) visit(x,y,scarcity); }