"""Descriptive fixed-input growth analysis; does not execute benchmark binaries."""
from pathlib import Path
import hashlib,json,math,statistics
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'representative-final'
summaries=json.loads((OUT/'summary.json').read_text())
samples=json.loads((OUT/'samples.json').read_text())
main=[r for r in summaries if r['resource_mode']<4]
assert len(main)==48 and len(samples)==49*11*2
assert all(not r['instrumented'] and r['visits']==262144 for r in samples)
for i in range(49):
 for repeat in range(11):
  pair={r['variant']:r for r in samples if r['case_index']==i and r['repeat']==repeat}
  assert all(pair['baseline'][k]==pair['candidate'][k] for k in ('input_hash','visits','occupied_visits','seed'))
def gm(rows):return math.exp(statistics.mean(math.log(r['median_paired_cpu_ratio'])for r in rows))
def group(rows):return {'cases':len(rows),'descriptive_equal_case_geomean_ratio':gm(rows),'min_median_ratio':min(r['median_paired_cpu_ratio']for r in rows),'max_median_ratio':max(r['median_paired_cpu_ratio']for r in rows),'ci_entirely_below_one':sum(r['paired_median_bootstrap_ci95'][1]<1 for r in rows),'ci_entirely_above_one':sum(r['paired_median_bootstrap_ci95'][0]>1 for r in rows)}
report={'scope':'restricted source-extracted decision path; no mutations/full Map cache acquisition; equal case weights are NOT game workload weights','source_hashes':{n:hashlib.sha256((OUT/n).read_bytes()).hexdigest()for n in ('manifest.json','samples.json','summary.json')},'all48':group(main),'mixed12':group([r for r in main if r['resource_mode']==0]),'groups':{},'size_and_mode':{},'partial_field_preparation_ms':{},'paired_ratio_note':'Within each case pair seeds1427..1437 vary; bootstrap resamples11pairedratios, so interval mixes seed variation and runtime noise and is not same-seed timing uncertainty. No multiple-comparison correction.','mixed_cases':[r for r in main if r['resource_mode']==0]}
for key in ('width','layout','resource_mode','amount'):
 report['groups'][key]={str(v):group([r for r in main if r[key]==v])for v in sorted({r[key]for r in main})}
for w in (128,512):
 report['size_and_mode'][str(w)]={str(m):group([r for r in main if r['width']==w and r['resource_mode']==m])for m in range(4)}
 vals=[r['cache_fields_cold_cpu_ns']/1e6 for r in samples if r['width']==w and r['variant']=='candidate' and r['resource_mode']<4]
 report['partial_field_preparation_ms'][str(w)]={'min':min(vals),'median':statistics.median(vals),'max':max(vals)}
report['cpu_ms_range']=[min(r['cpu_ns']for r in samples)/1e6,max(r['cpu_ns']for r in samples)/1e6]
report['wall_to_cpu']={'median':statistics.median(r['wall_ns']/r['cpu_ns']for r in samples),'max':max(r['wall_ns']/r['cpu_ns']for r in samples)}
report['stone_control']=summaries[-1]
(OUT/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
pct=lambda r:f'{(r-1)*100:+.1f}%'
lines=['# Fixed-input growth decision results','',
'**This is not an across-the-board improvement.** The 12 mixed-resource cases range from **'+pct(report['mixed12']['min_median_ratio'])+' to '+pct(report['mixed12']['max_median_ratio'])+' CPU**, comparing median paired final/legacy ratios. All six 128² mixed cases improve; four of six 512² mixed cases regress. The largest mixed regressions occur on river and dense layouts.', '',
'Forty-eight representative cases × eleven alternating baseline/final pairs, plus one stone control: 1,078 processes. Every process executes 262,144 fixed tile visits; logical inputs and occupied-visit counts match within pairs. The endpoint source is legacy934c3c588 versus final37d609766. Binaries have counters disabled and production assertion mode. `manifest.json`, `samples.json`, `summary.json`, `analysis.json` and `../assembly/review.json` retain provenance and raw evidence.', '',
'## Descriptive ratios, not game-weighted savings','',
'The equal-case geometric mean is **'+pct(report['all48']['descriptive_equal_case_geomean_ratio'])+' CPU** over the48 non-control cases and **'+pct(report['mixed12']['descriptive_equal_case_geomean_ratio'])+'** over the12 mixed cases. These are descriptive summaries of this chosen synthetic matrix; neither is a whole-game weighting or net terrain-refactor saving. The pure-stone control is kept separate ('+pct(summaries[-1]['median_paired_cpu_ratio'])+'); stone cannot grow, and the new path avoids useless old probability work.', '',
'| Width | Mixed | Wood | Wheat | Algae | All24 cases |','| --- | ---: | ---: | ---: | ---: | ---: |']
for w in (128,512):
 lines.append('| '+str(w)+'² | '+' | '.join(pct(report['size_and_mode'][str(w)][str(m)]['descriptive_equal_case_geomean_ratio'])for m in range(4))+' | '+pct(report['groups']['width'][str(w)]['descriptive_equal_case_geomean_ratio'])+' |')
lines+=['','Across all sizes/modes the layout summaries are sparse '+pct(report['groups']['layout']['0']['descriptive_equal_case_geomean_ratio'])+', river '+pct(report['groups']['layout']['1']['descriptive_equal_case_geomean_ratio'])+', dense '+pct(report['groups']['layout']['2']['descriptive_equal_case_geomean_ratio'])+'. Natural amount1/5 summaries are '+pct(report['groups']['amount']['1']['descriptive_equal_case_geomean_ratio'])+' / '+pct(report['groups']['amount']['5']['descriptive_equal_case_geomean_ratio'])+'. Amount does not explain the mixed size reversal.','',
'## Every mixed-resource case','',
'| Size | Layout | Amount | Median paired CPU change | Paired bootstrap95% interval |','| --- | --- | ---: | ---: | --- |']
for r in report['mixed_cases']:
 lo,hi=r['paired_median_bootstrap_ci95'];lines.append(f"| {r['width']}² | {('sparse','river','dense')[r['layout']]} | {r['amount']} | {pct(r['median_paired_cpu_ratio'])} | {pct(lo)} to {pct(hi)} |")
lines+=['','Of48 non-control cases,30 intervals lie below parity, six above parity, and12 overlap parity. The512² mixed amount1 river and both dense cases have intervals above parity; the river amount5 interval overlaps parity despite its positive median.', '',
'Intervals resample eleven paired ratios. Each pair uses a different seed (1427–1437), so the interval combines stochastic decision-work variation with runtime noise; it is not an estimate from eleven repeats of one exact RNG trace. They are unadjusted per-case intervals. The runner’s ratio of marginal medians is a different statistic and should not replace the paired median: the first128² sparse mixed case gives −50.6% using marginal medians versus −38.0% paired.', '',
'## Retained work and limits','',
'The real extracted production visit body, RNG, cache rate lookup, amount roll and expansion-direction decisions remain. Timed disassembly retains legacy/final RNG calls and dynamic growth-gate byte loads. Instrumented/timed smoke agrees on final RNG state within each version; it is not optimized to an empty loop. Every saved growth-permission bit is false only at the final gate, preventing mutations. This intentionally excludes successful resource mutation and telemetry, full Map cache locking/acquisition, donor gathering, random row/column visit selection and its RNG, and resulting changes to the world. Actual old/new opportunity counts and RNG sequences differ.', '',
'Field construction is outside the reported decision CPU. The separately measured final field-preparation medians are '+f"{report['partial_field_preparation_ms']['128']['median']:.2f}ms at128² and {report['partial_field_preparation_ms']['512']['median']:.2f}ms at512²"+' across non-control cases. This timer covers actual field kernels plus local/habitat preparation, but not complete Map cache construction/acquisition. Conditional break-even values in summary.json divide this partial preparation by marginal-median restricted decision savings; they are neither full-cache payback nor a game-tick estimate. Regressing cases have no positive decision saving to amortize construction.', '',
'## Why size/layout conclusions remain bounded','',
'- Adaptive batching means128² repeats the same full permutation16times, whereas512² makes one pass. Both count262,144 visits, but their cache reuse differs; this is not a controlled test of map size alone.',
'- The fixed permutation has stride541 cells. Both sides read36-byte tiles; the final path additionally reads resource-dependent field/habitat/local-growth arrays. Those retained cache planes occupy12Nbytes (192KiB at128²;3MiB at512²), versus tiles alone576KiB/9MiB, plus the common coordinate list128KiB/2MiB. Different per-resource array reads and cache locality are plausible contributors to the mixed512 reversal; this is a source-based hypothesis, not established causal profiling.',
'- Each process allocates separately; matching addresses are not enforced. ASLR/allocator layout, retained field-preparation buffers and extra final arrays may matter. The timing begins without a separate decision-loop warmup. The construction phase itself leaves different cache/thermal histories.',
'- Raw samples show substantial variation and occasional bimodality: dense512 amount1 baseline stays near24–25ms while final is21–22ms in two pairs and33–35ms in the others. Sparse128 first baseline is14.1ms versus roughly6–8ms later. Do not delete these samples post hoc; pair medians reduce, but do not eliminate, this concern.',
'- Coarse host bounds were satisfied (`../../growth-observation/observation.json`), but they do not establish isolated cores, stable frequency or absence of shared-cache/bandwidth contention. Short process CPU timings span roughly0.77–39.05ms. Wall/CPU proximity does not rule out on-CPU cache stalls or frequency shifts.', '',
'These observations support reporting scenario-dependent decision costs and motivate future controlled reuse/layout experiments. They do not prove that all live growth is faster, or explain a fixed percentage of whole-game CPU. No additional timing was run for this analysis.','']
(OUT/'REPORT.md').write_text('\n'.join(lines))
print('Wrote analysis.json and REPORT.md')
