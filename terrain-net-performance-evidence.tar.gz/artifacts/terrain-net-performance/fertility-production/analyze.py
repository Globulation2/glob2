"""Analyze production-entry land-field pairs; no binary-adapter control data."""
from pathlib import Path
import hashlib
import json
import math
import random
import statistics

ROOT = Path(__file__).resolve().parent
samples = json.loads((ROOT / 'timing-samples.json').read_text())
observation = json.loads((ROOT.parent / 'fertility-production-observation/observation.json').read_text())
assert observation['exit_status'] == 0 and observation['coarse_host_bounds_satisfied'] is True
assert max(h['load1'] for h in observation['host_samples']) <= 10
assert max(h['compilers'] for h in observation['host_samples']) <= 2
assert max(h['external_busy_percent'] for h in observation['sibling_windows']) <= 20
index = {}
for sample in samples:
    key = sample['size'], sample['layout'], sample['pair'], sample['variant']
    assert key not in index
    index[key] = sample
    raw = Path(sample['raw_file'])
    assert hashlib.sha256(raw.read_bytes()).hexdigest() == sample['raw_sha256']
wanted = {(size, layout, pair, variant) for size in (128,256,512) for layout in range(3) for pair in range(11) for variant in ('baseline','candidate')}
assert set(index) == wanted
report = []
for size in (128,256,512):
    for layout, label in enumerate(('sparse','striped','dense')):
        rows = {variant: [index[size,layout,pair,variant] for pair in range(11)] for variant in ('baseline','candidate')}
        assert len({row['digest'] for group in rows.values() for row in group}) == 1
        result = {'size':size, 'layout':label, 'pairs':11, 'digest':rows['baseline'][0]['digest']}
        for metric in ('warm_median_cpu_ns','construction_and_first_cpu_ns'):
            values = [math.log(after[metric]/before[metric]) for before,after in zip(rows['baseline'],rows['candidate'])]
            rng = random.Random(452811 + size * 10 + layout)
            draws = sorted(statistics.median(values[rng.randrange(11)] for _ in range(11)) for _ in range(10000))
            result[metric] = {'baseline_median_ms':statistics.median(row[metric] for row in rows['baseline'])/1e6,
                              'candidate_median_ms':statistics.median(row[metric] for row in rows['candidate'])/1e6,
                              'median_paired_change_percent':100*math.expm1(statistics.median(values)),
                              'paired_bootstrap_95_percent':[100*math.expm1(draws[int(q*(len(draws)-1))]) for q in (.025,.975)],
                              'pair_ratios':[math.exp(value) for value in values]}
        for metric in ('retained_bytes','input_bytes'):
            result[metric] = {}
            for variant, group in rows.items():
                assert len({row[metric] for row in group}) == 1
                result[metric][variant] = group[0][metric]
        result['plane_preparation_median_ms'] = {variant:statistics.median(row['plane_preparation_cpu_ns'] for row in group)/1e6 for variant,group in rows.items()}
        report.append(result)
summary = {'cases':report, 'method':'Per-case percentile bootstrap of eleven paired process-level log ratios; 10,000 draws. Warm observation per process is median of nine retained-workspace calls.',
           'ci_scope':'Unadjusted per-case/per-metric 95% intervals for these fixed inputs; not simultaneous intervals or population uncertainty. Nine inner warm calls are not treated as independent samples. Serial host drift and allocation effects are not corrected.',
           'host':{'coarse_bounds_passed':True,'maximum_load1':max(h['load1'] for h in observation['host_samples']), 'maximum_compilers':max(h['compilers'] for h in observation['host_samples']), 'maximum_sibling_window_busy_percent':max(h['external_busy_percent'] for h in observation['sibling_windows']), 'limitation':'Coarse sibling/compiler/load observations; no target-core external CPU attribution.'},
           'input_hashes':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ('timing-samples.json','timing-summary.json','timing-run.json','manifest.json','analyze.py')},
           'host_observation_sha256':hashlib.sha256((ROOT.parent/'fertility-production-observation/observation.json').read_bytes()).hexdigest()}
(ROOT/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['# Production-entry classic land-field results','',summary['method'],'',summary['ci_scope'],'',
       '| Map / fixture | Warm ms, old → final | Warm paired change [95% CI] | Construction + first ms, old → final | First paired change [95% CI] |',
       '| --- | ---: | ---: | ---: | ---: |']
def percent(value): return f'{value:+.1f}%'
def change(metric): return f"{percent(metric['median_paired_change_percent'])} [{percent(metric['paired_bootstrap_95_percent'][0])}, {percent(metric['paired_bootstrap_95_percent'][1])}]"
for result in report:
    warm,first = result['warm_median_cpu_ns'],result['construction_and_first_cpu_ns']
    lines.append(f"| {result['size']}² {result['layout']} | {warm['baseline_median_ms']:.3f} → {warm['candidate_median_ms']:.3f} | {change(warm)} | {first['baseline_median_ms']:.3f} → {first['candidate_median_ms']:.3f} | {change(first)} |")
lines += ['', 'Absolute times are separate variant medians; percentage estimates use matched pairs and therefore need not equal the ratio of displayed medians.', '',
          '| Map / fixture | Field retained bytes, old → final | Actual input-plane bytes, old → final |', '| --- | ---: | ---: |']
for result in report:
    memory,inputs=result['retained_bytes'],result['input_bytes']
    lines.append(f"| {result['size']}² {result['layout']} | {memory['baseline']} → {memory['candidate']} | {inputs['baseline']} → {inputs['candidate']} |")
lines += ['', 'Retained Field bytes exclude input planes, temporary peak allocations and allocator overhead. Original warm calls reuse owned scratch; final scratch is temporary and its allocation remains inside kernel timing.', '',
          'Original934c calls binary-mask Field::rebuild; final37d calls Field::rebuildWeighted with prebuilt Q8 inputs. Plane preparation is outside both kernel timers and separately logged; its common-mask conversion/copy is not Map property collection. Entire GrowthCache construction, aquatic fields, habitat/local-growth work, and cache request frequency are excluded.', '',
          'Earlier ecology optimization evidence used post-refactor42848408 as its baseline and prebuilt Q8 weighted calls on both sides. It measures a later optimization stage and cannot substitute for these pre-refactor-to-final results. The binary-adapter control timing was rejected by its host-load protocol and is excluded here.', '',
          f"Host observations passed: maximum load1 {summary['host']['maximum_load1']:.3f}, compiler count {summary['host']['maximum_compilers']}, sibling31 five-second busy {summary['host']['maximum_sibling_window_busy_percent']:.3f}%. This is observed coarse load bounding, not isolation."]
(ROOT/'analysis.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
