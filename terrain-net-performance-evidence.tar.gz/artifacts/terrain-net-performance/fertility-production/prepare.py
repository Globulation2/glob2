import hashlib, io, json, pathlib, shlex, subprocess, tarfile
root = pathlib.Path.cwd()
out = root / 'artifacts/terrain-net-performance/fertility-production'
revisions = {'baseline': '934c3c588bea51ec7421152e15f5168b2aaf5502', 'candidate': '37d609766374e7efc1679d643c7d18cde84364ab'}
compile_db = pathlib.Path('/tmp/glob2-terrain-baseline-build/compile_commands.json')
entry = next(x for x in json.loads(compile_db.read_text()) if x['file'].endswith('FertilityField.cpp'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
manifest = {'revisions': revisions, 'compiler': subprocess.check_output(['g++', '--version'], text=True), 'compile_database_sha256': sha(compile_db), 'benchmark_sha256': sha(out / 'benchmark.cpp'), 'affinity': '0-3 for compile and correctness smoke; timing withheld', 'variants': {}}
for name, revision in revisions.items():
    archive = subprocess.check_output(['git', 'archive', revision, 'src', 'libgag/include', 'libusl/src', 'third_party'])
    source = out / ('source-' + name)
    source.mkdir(exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar: tar.extractall(source, filter='data')
    args = shlex.split(entry['command'])
    args[args.index('-o') + 1] = str(out / (name + '.o'))
    args += ['-ffunction-sections', '-fdata-sections']
    build = ['taskset', '-c', '0-3', *args]
    subprocess.run(build, cwd=source, check=True)
    link = ['taskset', '-c', '0-3', 'g++', '-std=gnu++20', '-O3', '-Wl,--gc-sections', '-I' + str(source / 'src'), str(out / 'benchmark.cpp'), str(out / (name + '.o')), '-o', str(out / name)]
    if name == 'baseline': link += ['-DLEGACY_FIELD']
    subprocess.run(link, check=True)
    manifest['variants'][name] = {'archive_sha256': hashlib.sha256(archive).hexdigest(), 'compile_cwd': str(source), 'compile_command': build, 'link_command': link, 'source_sha256': sha(source / 'src/map/FertilityField.cpp'), 'header_sha256': sha(source / 'src/map/FertilityField.h'), 'binary_sha256': sha(out / name)}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Built both exact-revision fertility executables; no timing suite run.')
