import array, csv, hashlib, io, json, pathlib, subprocess, sys
out = pathlib.Path(__file__).resolve().parent
checks = []
for width, height in [(1, 1), (1, 17), (7, 5), (32, 32)]:
    for layout in range(5):
        expected = None
        for path in range(3):
            fields = []
            inputs = []
            for name in ['baseline', 'candidate']:
                prefix = out / f'smoke-{width}x{height}-{layout}-{path}-{name}'
                command = ['taskset', '-c', '0-3', str(out / name), str(width), str(height), str(layout), '1', str(path), str(prefix)]
                result = subprocess.run(command, check=True, capture_output=True, text=True)
                prefix.with_suffix('.csv').write_text(result.stdout)
                rows = list(csv.DictReader(io.StringIO(result.stdout)))
                assert len(rows) == 2 and rows[0]['digest'] == rows[1]['digest']
                fields.append(prefix.with_suffix('.field').read_bytes())
                inputs.append((prefix.with_suffix('.water').read_bytes(), prefix.with_suffix('.sand').read_bytes()))
            assert inputs[0] == inputs[1]
            if expected is None:
                water, sand = inputs[0]
                values = []
                for y in range(height):
                    for x in range(width):
                        value = 0
                        for dy in range(-15, 16):
                            for dx in range(-15, 16):
                                if water[((y+dy)%height)*width+(x+dx)%width] and not sand[((y-dy)%height)*width+(x-dx)%width]:
                                    value += (16-abs(dx))*(16-abs(dy))
                        values.append(value)
                expected = array.array('I', values).tobytes()
                assert array.array('I').itemsize == 4
            assert fields[0] == fields[1] == expected, (width, height, layout, path)
            checks.append({'width': width, 'height': height, 'layout': layout, 'path': path, 'water_sha256': hashlib.sha256(inputs[0][0]).hexdigest(), 'sand_sha256': hashlib.sha256(inputs[0][1]).hexdigest(), 'output_sha256': hashlib.sha256(expected).hexdigest(), 'baseline_candidate_oracle_bytes_equal': True})
(out / 'smoke.json').write_text(json.dumps({'checks': checks, 'cases': len(checks), 'rebuilds_per_binary_per_case': 2, 'byteorder': sys.byteorder, 'timing_status': 'correctness smoke only; timings not performance evidence', 'oracle': 'Direct 31x31 weighted triangular donor sum with mirrored inhibition, independent of production convolution/splat implementations'}, indent=2)+'\n')
print(f'{len(checks)} cases: baseline == candidate == independent oracle, byte-for-byte')
