# Classic land-field kernels at their production entrypoints

This experiment compares original `934c3c588bea51ec7421152e15f5168b2aaf5502` with final `37d609766374e7efc1679d643c7d18cde84364ab`. Both production implementations are compiled from separate unmodified source/header archives using the same frozen baseline compiler flags and dependencies.

The timed kernel calls differ intentionally to match actual producers:

- Original: `Fertility::Field::rebuild(width, height, uint8_water, uint8_sand)`.
- Final: `Fertility::Field::rebuildWeighted(width, height, int16_contributionQ8, uint16_inhibitionQ8)`.

Classic water contributes256; classic sand inhibits256. Identical classic terrain therefore produces identical full Q16 outputs. The final binary-mask compatibility adapter is not called. `candidate-entry-symbols.txt` confirms the linked final executable contains `rebuildWeighted` without `Field::rebuild`; the original executable contains `Field::rebuild`. The earlier binary-adapter control under `../fertility/` remains unchanged.

## Timing boundaries

Fixture masks are generated before all timers. Input planes are then prepared once: the original copies the common byte masks, while final converts those masks to its Q8 types. This has a separate `plane_preparation_cpu_ns` value on sample0 only. It is an illustrative common-mask conversion/copy measurement, **not Map property collection**, and must not be added to every subsequent kernel call. Actual producer input footprints (`input_bytes`) are2 bytes/cell original and4 bytes/cell final.

Field object allocation/construction is timed separately. Each `rebuild_cpu_ns` measures the actual kernel call, including its internal counting, adaptive selection, temporary allocations, convolution/accumulation and output conversion. Sample0 is the first rebuild; subsequent samples retain whatever workspace each production Field owns. Plane construction, hashes, result dumping and reporting are outside this timer. The existing runner reports construction-plus-first rebuild and median subsequent rebuilds separately.

Input/output sizes and contents are controlled; allocator addresses are recorded rather than forced equal. Input representations have intentionally different element widths. Separate process allocations, synthetic input preparation/cache state and tiny constructor-timer overhead remain limitations. `retained_bytes` includes the Field object and owned vector capacities, not allocator overhead, temporary peak memory or the input planes.

This isolates **classic land-field kernels with production input types**. It does not measure terrain-property gathering, aquatic fields, habitat data, local-growth multiplication, resource-growth attempts, cache validity/invalidation frequency or whole-game behavior. It is not a full ecology-cache reconstruction benchmark.

## Reproduction

```sh
python3 artifacts/terrain-net-performance/fertility-production/prepare.py
taskset -c 0-3 python3 artifacts/terrain-net-performance/fertility-production/smoke.py
# Only after coordinating with other timing runs:
python3 artifacts/terrain-net-performance/fertility-production/run-pairs.py --cpu 15 --pairs 11 --repeats 9
```

The smoke suite uses1×1,1×17,7×5 and32×32 fixtures, five layouts and all three algorithm selections:60 cases, two successive rebuilds per binary/case. Full baseline/final output bytes must equal an independent direct31×31 triangular donor/mirrored-inhibitor oracle. Input masks must also match. These small-run timings are correctness smoke data, not performance evidence.

The long runner covers128²,256² and512² fields with sparse, striped and dense fixtures, alternating baseline/candidate process order for11 pairs. It refuses to overwrite existing timing samples and checks binary hashes before each process. Raw CSVs, input/output digests, command lines, host load and hashes are retained. No long timing suite was run during preparation.
