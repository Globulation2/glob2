"""Linux counter arithmetic; interval interpolation is diagnostic, not isolation."""
from __future__ import annotations
import os
from pathlib import Path


def process_ticks(text):
    # comm can contain spaces and parentheses; everything after its final ')' is
    # the fixed-format suffix beginning at field 3 (state).
    fields = text[text.rindex(')') + 2:].split()
    return int(fields[11]) + int(fields[12])  # utime(14) + stime(15), all threads


def sample(pid, cpus, proc=Path('/proc'), monotonic=None):
    import time
    start = time.monotonic() if monotonic is None else monotonic()
    wanted = {f'cpu{cpu}': cpu for cpu in cpus}
    counters = {}
    for line in (proc / 'stat').read_text().splitlines():
        fields = line.split()
        if fields and fields[0] in wanted:
            values = list(map(int, fields[1:]))
            # guest/guest_nice are already included in user/nice; don't add twice.
            counters[wanted[fields[0]]] = {'total': sum(values[:8]), 'idle': values[3] + values[4]}
    if set(counters) != set(cpus):
        raise RuntimeError('Requested CPU counters are missing')
    ticks = process_ticks((proc / str(pid) / 'stat').read_text()) if pid is not None else 0
    end = time.monotonic() if monotonic is None else monotonic()
    return {'time': (start + end) / 2, 'read_span_seconds': end - start,
            'child_ticks': ticks, 'cpus': counters}


def interval(before, after, target, sibling):
    elapsed = after['time'] - before['time']
    child = after['child_ticks'] - before['child_ticks']
    if elapsed <= 0 or child < 0:
        raise RuntimeError('Nonmonotonic sample or child counter')
    result = {'start': before['time'], 'end': after['time'], 'seconds': elapsed,
              'child_ticks': child, 'cpus': {}}
    for cpu in (target, sibling):
        old, new = before['cpus'][cpu], after['cpus'][cpu]
        total, idle = new['total'] - old['total'], new['idle'] - old['idle']
        if total < 0 or idle < 0 or idle > total:
            raise RuntimeError('Invalid CPU counter delta')
        busy = total - idle
        raw_external = busy - child if cpu == target else busy
        result['cpus'][cpu] = {'total_ticks': total, 'busy_ticks': busy,
                              'raw_external_ticks': raw_external,
                              'external_ticks': max(0, raw_external)}
    return result


def window(intervals, cpu, seconds=5.0, final=False):
    if not intervals:
        return None
    end, first = intervals[-1]['end'], intervals[0]['start']
    if end - first < seconds and not final:
        return None
    begin = max(first, end - seconds)
    busy = total = 0.0
    for part in intervals:
        overlap = max(0.0, min(end, part['end']) - max(begin, part['start']))
        fraction = overlap / part['seconds']
        busy += part['cpus'][cpu]['external_ticks'] * fraction
        total += part['cpus'][cpu]['total_ticks'] * fraction
    if total <= 0:
        raise RuntimeError('Empty observed window')
    return {'start': begin, 'end': end, 'seconds': end - begin,
            'external_busy_percent': 100 * busy / total}


def observe_child(child, cpus, host, pause=None, get_sample=None, exited=None):
    """Read final counters before reaping; pidfd wakes promptly on child exit.

    WNOWAIT retains /proc/PID/stat. The caller captures a zero-child sample before
    launch to include startup ticks. One-second periodic sampling uses pidfd exit
    notification, avoiding a full polling-tail interval in the terminal sample.
    """
    import select
    get_sample = sample if get_sample is None else get_sample
    exited = (lambda pid: os.waitid(os.P_PID, pid, os.WEXITED | os.WNOHANG | os.WNOWAIT) is not None) if exited is None else exited
    descriptor = os.pidfd_open(child.pid) if pause is None else None
    if pause is None:
        pause = lambda seconds: select.select([descriptor], [], [], seconds)
    samples, hosts = [], []
    try:
        while True:
            pause(1.0)
            done = exited(child.pid)
            samples.append(get_sample(child.pid, cpus))
            hosts.append(host())
            if done:
                return samples, hosts, child.wait()
    finally:
        if descriptor is not None:
            os.close(descriptor)
