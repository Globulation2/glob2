from pathlib import Path
import os,json,subprocess,hashlib
root=Path(__file__).resolve().parent;plan=json.loads((root/'game-plan.json').read_text());out=root/'profiles';out.mkdir(exist_ok=True);records=[]
for name in plan['maps']:
 for variant,c in plan['variants'].items():
  dest=out/f'{name}-{variant}';dest.mkdir(exist_ok=True)
  cmd=['taskset','-c','3',c['binary'],'--run-game','--map-file',plan['maps'][name]['path'],'--game-seed','12345','--player','maxima','--player','nicowar','--ticks','16384','--rule','noGrowth=0','--compute-threads','1','--gradient-workers','0','--telemetry','team-timeline','--output-dir',str(dest)]
  env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy');env.pop('GLOB2_PERF_DISABLE',None)
  (dest/'inputs.json').write_text(json.dumps({'command':cmd,'cwd':c['cwd'],'binary_sha256':c['sha256'],'note':'Diagnostic scope CALL COUNTS only. Elapsed timings under external load are not performance evidence.'},indent=2)+'\n')
  if not (dest/'result.json').exists():
   with (dest/'run.log').open('w') as log:subprocess.run(cmd,cwd=c['cwd'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  d=json.loads((dest/'result.json').read_text());reference=json.loads((root/'games'/f'{name}-s12345-p0-{variant}'/'result.json').read_text())
  for k in ('initialChecksum','finalChecksum','teams','gradient_jobs','gradient_published','hiring_popped_entries'):assert d[k]==reference[k],(name,variant,k)
  scopes=[]
  for line in (dest/'run.log').read_text().splitlines():
   if line.startswith('GLOB2_PERF_FINAL '):
    values=dict(x.split('=',1) for x in line.split()[1:] if '=' in x)
    if all(k in values for k in ('scope','calls','samples','stride')):scopes.append({k:values[k] for k in ('scope','calls','samples','stride')})
  records.append({'map':name,'variant':variant,'scopes':scopes,'state_matches_uninstrumented':True});(root/'profile-counts.json').write_text(json.dumps(records,indent=2)+'\n');print(name,variant,len(scopes),flush=True)
