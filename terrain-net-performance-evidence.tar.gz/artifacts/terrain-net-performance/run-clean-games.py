"""Paired endpoint games with predeclared host-load rejection, never result-based filtering."""
from pathlib import Path
import hashlib,json,os,subprocess,time,statistics
ROOT=Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'game-plan.json').read_text())
OUT=ROOT/'clean-games';OUT.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
THRESHOLDS={'maximum_compiler_processes':2,'maximum_load1':10.,'maximum_sibling_mean_busy_percent':20.}
(ROOT/'clean-protocol.json').write_text(json.dumps({'thresholds':THRESHOLDS,'script_sha256':sha(__file__),'plan_sha256':sha(ROOT/'game-plan.json'),'decision':'Accept/reject both members solely on load samples; preserve all attempts. Never filter by speed or outcome.'},indent=2)+'\n')
def stat():
 vals=next(x.split()[1:] for x in Path('/proc/stat').read_text().splitlines() if x.startswith('cpu31 '));v=list(map(int,vals));return sum(v[:8]),v[3]+v[4]
def host():
 compilers=0
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:comm=(p/'comm').read_text().strip()
  except (FileNotFoundError,ProcessLookupError,PermissionError):continue
  if comm in {'cc1plus','cc1','clang','clang++','rustc','ld.lld','lld'}:compilers+=1
 return {'time':time.time(),'load1':os.getloadavg()[0],'compilers':compilers}
def good(h):return h['load1']<=THRESHOLDS['maximum_load1'] and h['compilers']<=THRESHOLDS['maximum_compiler_processes']
def quiet():
 while True:
  a=host();st=stat();time.sleep(2);b=host();en=stat();busy=100*(1-(en[1]-st[1])/max(1,en[0]-st[0]));b['sibling_busy_percent']=busy
  with (ROOT/'host-waits.jsonl').open('a') as f:f.write(json.dumps(b)+'\n')
  if good(a) and good(b) and busy<=THRESHOLDS['maximum_sibling_mean_busy_percent']:return
  print('WAIT host',b,flush=True);time.sleep(15)
rows=[];expected={};attempts=[]
keys=[(m,s) for m in PLAN['maps'] for s in PLAN['seeds']]
started=time.time()
for repeat in range(PLAN['pairs_per_scenario']):
 for offset in range(len(keys)):
  name,seed=keys[(offset+repeat)%len(keys)];attempt=0
  while True:
   quiet();attempt+=1;pair=[];accepted=True
   for variant in (('baseline','candidate') if repeat%2==0 else ('candidate','baseline')):
    c=PLAN['variants'][variant];assert sha(c['binary'])==c['sha256'];assert sha(PLAN['maps'][name]['path'])==PLAN['maps'][name]['sha256']
    dest=OUT/f'{name}-s{seed}-p{repeat}-a{attempt}-{variant}';dest.mkdir()
    cmd=['taskset','-c',str(PLAN['cpu']),c['binary'],'--run-game','--map-file',PLAN['maps'][name]['path'],'--game-seed',str(seed),'--player','maxima','--player','nicowar','--ticks',str(PLAN['ticks']),'--rule','noGrowth=0','--compute-threads','1','--gradient-workers','0','--benchmark-warmup',str(PLAN['warmup']),'--output-dir',str(dest)]
    env={'GLOB2_PERF_DISABLE':'1','SDL_VIDEODRIVER':'dummy','SDL_AUDIODRIVER':'dummy'}
    (dest/'inputs.json').write_text(json.dumps({'command':cmd,'cwd':c['cwd'],'binary_sha256':c['sha256'],'map_sha256':PLAN['maps'][name]['sha256'],'environment':env},indent=2)+'\n')
    samples=[host()];st=stat()
    with (dest/'run.log').open('w') as log:
     child=subprocess.Popen(cmd,cwd=c['cwd'],env=dict(os.environ,**env),stdout=log,stderr=subprocess.STDOUT)
     while child.poll() is None:time.sleep(1);samples.append(host())
     assert child.returncode==0, (dest,child.returncode)
    en=stat();busy=100*(1-(en[1]-st[1])/max(1,en[0]-st[0]));clean=all(good(h) for h in samples) and busy<=THRESHOLDS['maximum_sibling_mean_busy_percent'];accepted &= clean
    (dest/'host.json').write_text(json.dumps({'samples':samples,'sibling_mean_busy_percent':busy,'clean':clean},indent=2)+'\n')
    d=json.loads((dest/'result.json').read_text());assert d['ticks']==PLAN['ticks'];assert d['benchmark_measured_ticks']==PLAN['ticks']-PLAN['warmup']
    state={k:d[k] for k in ('initialChecksum','finalChecksum','teams','gradient_jobs','gradient_published','hiring_popped_entries')};key=(name,seed,variant)
    if key in expected:assert expected[key]==state,(key,'nondeterministic repeat')
    else:expected[key]=state
    pair.append({'map':name,'seed':seed,'pair':repeat,'attempt':attempt,'variant':variant,'cpu_ns_per_tick':d['benchmark_run_cpu_ns']/d['benchmark_measured_ticks'],'cpu_ns':d['benchmark_run_cpu_ns'],'measured_ticks':d['benchmark_measured_ticks'],'finalChecksum':d['finalChecksum'],'units':sum(t['units'] for t in d['teams']),'buildings':sum(t['buildings'] for t in d['teams']),'gradient_jobs':d['gradient_jobs'],'gradient_published':d['gradient_published'],'hiring_popped_entries':d['hiring_popped_entries'],'result_sha256':sha(dest/'result.json'),'directory':str(dest),'host_clean':clean})
   attempts.append({'map':name,'seed':seed,'pair':repeat,'attempt':attempt,'accepted':accepted,'runs':pair});(ROOT/'clean-attempts.json').write_text(json.dumps(attempts,indent=2)+'\n')
   if accepted:
    rows+=pair;(ROOT/'clean-game-samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(f'PASS {len(rows)//2}/99 pairs {name} seed{seed} repeat{repeat} elapsed{time.time()-started:.1f}s',flush=True);break
   print(f'REJECT host load only {name} seed{seed} repeat{repeat} attempt{attempt}',flush=True)
print('PASS complete clean-host timing matrix and repeated-state checks',flush=True)
