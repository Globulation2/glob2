"""Endpoint games with predeclared observed-load bounds; not CPU isolation."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
from bounded_host import interval, observe_child, sample, window

ROOT = Path(__file__).resolve().parent
PLAN_PATH = ROOT / 'game-plan.json'
PLAN = json.loads(PLAN_PATH.read_text())
TARGET, SIBLING = PLAN['cpu'], PLAN['sibling']
CPUS = (TARGET, SIBLING)
THRESHOLDS = {'maximum_compiler_processes': 2, 'maximum_load1': 10.0,
              'maximum_external_busy_percent': 20.0,
              'rolling_window_seconds': 5.0, 'preflight_seconds': 2.0}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def host():
    compilers = 0
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            name = (path / 'comm').read_text().strip()
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        compilers += name in {'cc1plus', 'cc1', 'clang', 'clang++', 'rustc', 'ld.lld', 'lld'}
    return {'time': time.time(), 'load1': os.getloadavg()[0], 'compilers': compilers}


def good_host(value):
    return (value['load1'] <= THRESHOLDS['maximum_load1']
            and value['compilers'] <= THRESHOLDS['maximum_compiler_processes'])


def quiet():
    while True:
        before_host, before = host(), sample(None, CPUS)
        time.sleep(THRESHOLDS['preflight_seconds'])
        after, after_host = sample(None, CPUS), host()
        part = interval(before, after, TARGET, SIBLING)
        windows = {cpu: window([part], cpu, final=True) for cpu in CPUS}
        accepted = good_host(before_host) and good_host(after_host) and all(
            value['external_busy_percent'] <= THRESHOLDS['maximum_external_busy_percent']
            for value in windows.values())
        record = {'before': before_host, 'after': after_host, 'core_windows': windows, 'accepted': accepted}
        with (ROOT / 'bounded-host-waits.jsonl').open('a') as stream:
            stream.write(json.dumps(record) + '\n')
        if accepted:
            return
        print('WAIT observed host load', json.dumps(record), flush=True)
        time.sleep(15)


def assess(before, samples, hosts):
    intervals, observations = [], []
    previous = before
    for index, current in enumerate(samples):
        intervals.append(interval(previous, current, TARGET, SIBLING))
        previous = current
        final = index == len(samples) - 1
        for cpu in CPUS:
            value = window(intervals, cpu, seconds=THRESHOLDS['rolling_window_seconds'], final=final)
            if value is not None:
                observations.append({'cpu': cpu, **value})
    accepted = all(good_host(value) for value in hosts) and all(
        value['external_busy_percent'] <= THRESHOLDS['maximum_external_busy_percent']
        for value in observations)
    return {'accepted': accepted, 'host_samples': hosts, 'initial_counters': before,
            'counter_samples': samples, 'intervals': intervals, 'windows': observations}


def main():
    # The monitor must not itself compete on either observed hardware thread.
    monitor_cpus = os.sched_getaffinity(0) - set(CPUS)
    if not monitor_cpus:
        raise RuntimeError('Run the monitor with affinity allowing a CPU other than target/sibling')
    os.sched_setaffinity(0, monitor_cpus)
    actual_siblings = Path(f'/sys/devices/system/cpu/cpu{TARGET}/topology/thread_siblings_list').read_text().strip()
    if actual_siblings != ','.join(map(str, sorted(CPUS))):
        raise RuntimeError('Frozen two-thread sibling topology differs: ' + actual_siblings)
    output = ROOT / 'bounded-games'
    output.mkdir()  # Never overwrite or silently resume a protocol/run.
    protocol = {'thresholds': THRESHOLDS, 'target_cpu': TARGET, 'sibling_cpu': SIBLING,
                'monitor_affinity': sorted(monitor_cpus), 'clock_ticks_per_second': os.sysconf('SC_CLK_TCK'),
                'script_sha256': sha(__file__), 'helper_sha256': sha(ROOT / 'bounded_host.py'),
                'plan_sha256': sha(PLAN_PATH), 'decision': 'Accept/reject both pair members solely from observed load; retain every attempt.',
                'limits': ['Observed-load-bounded, not CPU isolation or cache/frequency control.',
                           '/proc/stat and child counters are not atomic; raw negative residuals retained and clamped to zero for thresholding.',
                           'One-second samples; five-second rolling windows interpolate partially overlapping intervals.',
                           'Short runs use their complete observed interval; pidfd signals exit before final counters are sampled and process is reaped.',
                           'CPU counters cover setup and warmup as well as measurement; rolling windows limit long-run dilution.',
                           'Child aggregate utime+stime assumes all child threads remain pinned to target CPU; no descendant CPU is subtracted.',
                           'Compiler counts and load average are coarse controls, including benchmark contribution to load.']}
    (ROOT / 'bounded-protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
    rows, attempts, expected = [], [], {}
    scenarios = [(name, seed) for name in PLAN['maps'] for seed in PLAN['seeds']]
    start = time.time()
    for repeat in range(PLAN['pairs_per_scenario']):
        for offset in range(len(scenarios)):
            name, seed = scenarios[(offset + repeat) % len(scenarios)]
            attempt = 0
            while True:
                quiet()
                attempt += 1
                pair, accepted = [], True
                for variant in (('baseline', 'candidate') if repeat % 2 == 0 else ('candidate', 'baseline')):
                    config = PLAN['variants'][variant]
                    assert sha(config['binary']) == config['sha256']
                    assert sha(PLAN['maps'][name]['path']) == PLAN['maps'][name]['sha256']
                    destination = output / f'{name}-s{seed}-p{repeat}-a{attempt}-{variant}'
                    destination.mkdir()
                    command = ['taskset', '-c', str(TARGET), config['binary'], '--run-game', '--map-file', PLAN['maps'][name]['path'], '--game-seed', str(seed), '--player', 'maxima', '--player', 'nicowar', '--ticks', str(PLAN['ticks']), '--rule', 'noGrowth=0', '--compute-threads', '1', '--gradient-workers', '0', '--benchmark-warmup', str(PLAN['warmup']), '--output-dir', str(destination)]
                    environment = {'GLOB2_PERF_DISABLE': '1', 'SDL_VIDEODRIVER': 'dummy', 'SDL_AUDIODRIVER': 'dummy'}
                    (destination / 'inputs.json').write_text(json.dumps({'command': command, 'cwd': config['cwd'], 'binary_sha256': config['sha256'], 'map_sha256': PLAN['maps'][name]['sha256'], 'environment': environment}, indent=2) + '\n')
                    initial_host, before = host(), sample(None, CPUS)
                    with (destination / 'run.log').open('w') as log:
                        child = subprocess.Popen(command, cwd=config['cwd'], env=dict(os.environ, **environment), stdout=log, stderr=subprocess.STDOUT)
                        samples, hosts, status = observe_child(child, CPUS, host)
                    evidence = assess(before, samples, [initial_host, *hosts])
                    (destination / 'host.json').write_text(json.dumps(evidence, indent=2) + '\n')
                    assert status == 0, (destination, status)
                    accepted &= evidence['accepted']
                    result = json.loads((destination / 'result.json').read_text())
                    assert result['ticks'] == PLAN['ticks']
                    assert result['benchmark_measured_ticks'] == PLAN['ticks'] - PLAN['warmup']
                    state = {key: result[key] for key in ('initialChecksum', 'finalChecksum', 'teams', 'gradient_jobs', 'gradient_published', 'hiring_popped_entries')}
                    key = name, seed, variant
                    if key in expected:
                        assert expected[key] == state, (key, 'nondeterministic repeat')
                    else:
                        expected[key] = state
                    pair.append({'map': name, 'seed': seed, 'pair': repeat, 'attempt': attempt, 'variant': variant,
                                 'cpu_ns_per_tick': result['benchmark_run_cpu_ns'] / result['benchmark_measured_ticks'], 'cpu_ns': result['benchmark_run_cpu_ns'], 'measured_ticks': result['benchmark_measured_ticks'], 'finalChecksum': result['finalChecksum'], 'units': sum(team['units'] for team in result['teams']), 'buildings': sum(team['buildings'] for team in result['teams']), 'gradient_jobs': result['gradient_jobs'], 'gradient_published': result['gradient_published'], 'hiring_popped_entries': result['hiring_popped_entries'], 'result_sha256': sha(destination / 'result.json'), 'directory': str(destination), 'host_accepted': evidence['accepted']})
                attempts.append({'map': name, 'seed': seed, 'pair': repeat, 'attempt': attempt, 'accepted': accepted, 'runs': pair})
                (ROOT / 'bounded-attempts.json').write_text(json.dumps(attempts, indent=2) + '\n')
                if accepted:
                    rows += pair
                    (ROOT / 'bounded-game-samples.json').write_text(json.dumps(rows, indent=2) + '\n')
                    print(f'PASS {len(rows)//2}/{len(scenarios)*PLAN["pairs_per_scenario"]} observed-load-bounded pairs; elapsed {time.time()-start:.1f}s', flush=True)
                    break
                print(f'REJECT observed host load: {name}, seed {seed}, repeat {repeat}, attempt {attempt}', flush=True)


if __name__ == '__main__':
    main()
