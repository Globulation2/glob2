"""Observe one unchanged component command; coarse host checks, no automatic retry."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import subprocess
import time
from bounded_host import interval, observe_child, sample, window

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('game_monitor', ROOT / 'run-bounded-games.py')
monitor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(monitor)


def active_game_runners():
    names = {'run-games.py', 'run-clean-games.py', 'run-bounded-games.py', 'run-isolated-games.py'}
    for path in Path('/proc').iterdir():
        if not path.name.isdigit() or int(path.name) == os.getpid():
            continue
        try:
            if any(Path(os.fsdecode(arg)).name in names for arg in (path / 'cmdline').read_bytes().split(b'\0') if arg):
                return True
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.command[:1] == ['--']:
        args.command = args.command[1:]
    assert args.command, 'Pass an unchanged benchmark command after --'
    if active_game_runners():
        raise RuntimeError('Whole-game timing runner active; wait before component observation')
    allowed = os.sched_getaffinity(0) - set(monitor.CPUS)
    assert allowed, 'Observer needs a CPU outside target/sibling'
    os.sched_setaffinity(0, allowed)
    args.output.mkdir(parents=True)  # Every invocation needs a fresh evidence directory.
    protocol = {'command': args.command, 'cwd': str(Path.cwd()), 'thresholds': monitor.THRESHOLDS,
                'script_sha256': monitor.sha(__file__), 'helper_sha256': monitor.sha(ROOT / 'bounded_host.py'), 'monitor_sha256': monitor.sha(ROOT / 'run-bounded-games.py'),
                'monitor_affinity': sorted(allowed),
                'mode': 'Coarse whole-command observations; no target-CPU subtraction, command rewriting, per-leaf preflight, or automatic retry.',
                'limits': ['Sibling CPU31 plus compiler/load observations only; nested subprocess CPU is not attributed.',
                           'Command must select CPU15 for timed leaves itself; wrapper does not change affinity or arguments.',
                           'One-second samples and five-second sibling windows can miss short bursts; aggregate command duration is not a component timing.',
                           'Whole-command load rejection identifies potentially contaminated data; do not selectively remove fast/slow leaves.',
                           'Known game-runner detection is not an exclusive cross-tool lock.']}
    (args.output / 'protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
    # One preflight for the entire matrix, not thousands of tiny leaf commands.
    while True:
        before_host, before = monitor.host(), sample(None, monitor.CPUS)
        time.sleep(2)
        after, after_host = sample(None, monitor.CPUS), monitor.host()
        sibling = window([interval(before, after, *monitor.CPUS)], monitor.SIBLING, final=True)
        good = monitor.good_host(before_host) and monitor.good_host(after_host) and sibling['external_busy_percent'] <= monitor.THRESHOLDS['maximum_external_busy_percent']
        with (args.output / 'preflight.jsonl').open('a') as stream:
            stream.write(json.dumps({'before': before_host, 'after': after_host, 'sibling': sibling, 'accepted': good}) + '\n')
        if active_game_runners():
            raise RuntimeError('Whole-game runner started; component command was not launched')
        if good:
            break
        time.sleep(15)
    initial_host, before = monitor.host(), sample(None, monitor.CPUS)
    with (args.output / 'stdout.log').open('w') as stdout, (args.output / 'stderr.log').open('w') as stderr:
        child = subprocess.Popen(args.command, stdout=stdout, stderr=stderr)
        samples, hosts, status = observe_child(child, monitor.CPUS, monitor.host, get_sample=lambda pid, cpus: sample(None, cpus))
    parts, observations = [], []
    previous = before
    for index, current in enumerate(samples):
        parts.append(interval(previous, current, *monitor.CPUS))
        previous = current
        value = window(parts, monitor.SIBLING, final=index == len(samples)-1)
        if value is not None:
            observations.append(value)
    hosts.insert(0, initial_host)
    good = all(monitor.good_host(value) for value in hosts) and all(value['external_busy_percent'] <= monitor.THRESHOLDS['maximum_external_busy_percent'] for value in observations)
    result = {'exit_status': status, 'coarse_host_bounds_satisfied': good, 'host_samples': hosts, 'initial_counters': before, 'counter_samples': samples, 'sibling_windows': observations,
              'stdout_sha256': monitor.sha(args.output / 'stdout.log'), 'stderr_sha256': monitor.sha(args.output / 'stderr.log')}
    (args.output / 'observation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'exit_status': status, 'coarse_host_bounds_satisfied': good, 'retry': 'none'}))
    raise SystemExit(status if status else (0 if good else 2))


if __name__ == '__main__':
    main()
