"""Complete fixed-suite analysis; paired outcomes are never used for filtering."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import random
import statistics

ROOT = Path(__file__).resolve().parent


def analyze(plan, rows, attempts, protocol, read_host, bootstrap_samples=10000):
    count = plan['pairs_per_scenario']
    scenarios = [(name, seed) for name in plan['maps'] for seed in plan['seeds']]
    assert len(scenarios) * count == 99, 'Expected the planned 99-pair suite'
    wanted = {(name, seed, pair, variant) for name, seed in scenarios for pair in range(count) for variant in ('baseline', 'candidate')}
    indexed = {}
    for row in rows:
        key = row['map'], row['seed'], row['pair'], row['variant']
        assert key not in indexed, ('Duplicate sample', key)
        assert row['host_accepted'] is True, ('Rejected sample in analysis', key)
        assert math.isfinite(row['cpu_ns_per_tick']) and row['cpu_ns_per_tick'] > 0
        assert row['measured_ticks'] == plan['ticks'] - plan['warmup']
        assert math.isclose(row['cpu_ns_per_tick'], row['cpu_ns'] / row['measured_ticks'], rel_tol=1e-12)
        indexed[key] = row
    assert set(indexed) == wanted, 'Timing matrix incomplete or unexpected samples'
    accepted, rejected, seen_attempts, accepted_keys = [], [], set(), set()
    for attempt in attempts:
        key = attempt['map'], attempt['seed'], attempt['pair']
        assert key[:2] in scenarios and key[2] in range(count), ('Unexpected attempt', key)
        assert isinstance(attempt['attempt'], int) and attempt['attempt'] > 0
        attempt_key = *key, attempt['attempt']
        assert attempt_key not in seen_attempts, ('Duplicate attempt', attempt_key)
        seen_attempts.add(attempt_key)
        runs = attempt['runs']
        assert len(runs) == 2 and {run['variant'] for run in runs} == {'baseline', 'candidate'}
        assert all((run['map'], run['seed'], run['pair'], run['attempt']) == attempt_key for run in runs)
        assert attempt['accepted'] == all(run['host_accepted'] for run in runs)
        if attempt['accepted']:
            assert key not in accepted_keys, ('Multiple accepted attempts', key)
            accepted_keys.add(key)
            for run in runs:
                assert indexed[*key, run['variant']] == run, ('Sample differs from retained accepted attempt', key)
            accepted.append(attempt)
        else:
            rejected.append(attempt)
    assert len(accepted) == 99 and len(accepted_keys) == 99

    thresholds = protocol['thresholds']
    host_summary = {'accepted': {'runs': 0, 'maximum_load1': 0, 'maximum_compilers': 0, 'maximum_window_busy_percent_by_cpu': {}},
                    'rejected': {'runs': 0, 'maximum_load1': 0, 'maximum_compilers': 0, 'maximum_window_busy_percent_by_cpu': {}}}
    for group_name, group in [('accepted', accepted), ('rejected', rejected)]:
        summary = host_summary[group_name]
        for attempt in group:
            for run in attempt['runs']:
                host = read_host(run)
                assert host['accepted'] == run['host_accepted']
                summary['runs'] += 1
                for value in host['host_samples']:
                    summary['maximum_load1'] = max(summary['maximum_load1'], value['load1'])
                    summary['maximum_compilers'] = max(summary['maximum_compilers'], value['compilers'])
                assert host['windows'], 'Missing runtime windows'
                assert {int(value['cpu']) for value in host['windows']} == {protocol['target_cpu'], protocol['sibling_cpu']}, 'Missing observed CPU windows'
                for value in host['windows']:
                    cpu = str(value['cpu'])
                    summary['maximum_window_busy_percent_by_cpu'][cpu] = max(summary['maximum_window_busy_percent_by_cpu'].get(cpu, 0), value['external_busy_percent'])
                observed_acceptance = all(value['load1'] <= thresholds['maximum_load1'] and value['compilers'] <= thresholds['maximum_compiler_processes'] for value in host['host_samples']) and all(value['external_busy_percent'] <= thresholds['maximum_external_busy_percent'] for value in host['windows'])
                assert observed_acceptance == host['accepted'], 'Retained decision does not match recorded threshold observations'

    logs, scenario_reports = {}, []
    for name, seed in scenarios:
        pairs = [indexed[name, seed, pair, 'candidate']['cpu_ns_per_tick'] / indexed[name, seed, pair, 'baseline']['cpu_ns_per_tick'] for pair in range(count)]
        logs[name, seed] = [math.log(value) for value in pairs]
        populations = {variant: {field: indexed[name, seed, 0, variant][field] for field in ('units', 'buildings', 'gradient_jobs', 'gradient_published', 'hiring_popped_entries', 'finalChecksum')} for variant in ('baseline', 'candidate')}
        for variant in ('baseline', 'candidate'):
            for pair in range(count):
                assert all(indexed[name, seed, pair, variant][field] == value for field, value in populations[variant].items()), 'Repeat state/counters changed within variant'
        scenario_reports.append({'map': name, 'seed': seed, 'pairs': count, 'pair_ratios': pairs,
                                 'median_cpu_ns_per_tick': {variant: statistics.median(indexed[name, seed, pair, variant]['cpu_ns_per_tick'] for pair in range(count)) for variant in ('baseline', 'candidate')},
                                 'final_state_observables': populations})
    # Resample round IDs jointly across every scenario: paired baseline/final
    # observations and cross-scenario round covariance stay together. No claim
    # that successive rounds are independent, nor population generalization.
    rng = random.Random(72941)
    draws = [[rng.randrange(count) for _ in range(count)] for _ in range(bootstrap_samples)]
    medians = {key: statistics.median(values) for key, values in logs.items()}
    bootstrap = {key: [statistics.median(values[i] for i in ids) for ids in draws] for key, values in logs.items()}

    def aggregate(keys):
        distribution = sorted(statistics.mean(bootstrap[key][draw] for key in keys) for draw in range(bootstrap_samples))
        return {'scenario_count': len(keys), 'median_paired_geometric_change_percent': 100 * math.expm1(statistics.mean(medians[key] for key in keys)),
                'round_block_bootstrap_95_percent': [100 * math.expm1(distribution[int(q * (bootstrap_samples - 1))]) for q in (.025, .975)]}

    for entry in scenario_reports:
        entry.update(aggregate([(entry['map'], entry['seed'])]))
    by_map = [{'map': name, **aggregate([(name, seed) for seed in plan['seeds']])} for name in plan['maps']]
    by_seed = [{'seed': seed, **aggregate([(name, seed) for name in plan['maps']])} for seed in plan['seeds']]
    summed = 100 * (sum(row['median_cpu_ns_per_tick']['candidate'] for row in scenario_reports) / sum(row['median_cpu_ns_per_tick']['baseline'] for row in scenario_reports) - 1)
    rejection_by_scenario = [{'map': name, 'seed': seed, 'accepted_pairs': sum(a['map'] == name and a['seed'] == seed for a in accepted), 'rejected_attempts': sum(a['map'] == name and a['seed'] == seed for a in rejected)} for name, seed in scenarios]
    return {'definition': plan['primary_aggregate'], 'overall': aggregate(scenarios), 'per_map': by_map, 'per_seed': by_seed,
            'ratio_of_summed_scenario_medians_percent': summed, 'scenarios': scenario_reports,
            'attempts': {'accepted_pairs': len(accepted), 'rejected_pairs': len(rejected), 'total_pair_attempts': len(attempts), 'per_scenario': rejection_by_scenario},
            'runtime_host_observations': host_summary, 'predeclared_host_bounds': thresholds,
            'bootstrap': {'draws': bootstrap_samples, 'seed': 72941, 'resampling_unit': 'Complete round ID jointly across scenarios, preserving baseline/candidate pairing', 'scope': 'Conditional measurement variation of this fixed accepted suite; not population uncertainty over maps/seeds or a correction for serial host drift.'},
            'limitations': [*plan['limits'], *protocol['limits'], 'No trajectory, population, or workload normalization is performed.', 'Rejected observations remain evidence but do not enter timing estimates.', 'Round resampling does not account for dependence across consecutive rounds. Accepted attempts within a round may be separated by retries.', 'Host summaries validate recorded acceptance windows, not independent hardware-counter accuracy.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples', type=Path, default=ROOT / 'bounded-game-samples.json')
    parser.add_argument('--attempts', type=Path, default=ROOT / 'bounded-attempts.json')
    parser.add_argument('--protocol', type=Path, default=ROOT / 'bounded-protocol.json')
    parser.add_argument('--plan', type=Path, default=ROOT / 'game-plan.json')
    parser.add_argument('--output', type=Path, default=ROOT / 'bounded-game-summary.json')
    args = parser.parse_args()
    read = lambda path: json.loads(path.read_text())
    def read_host(run):
        directory = Path(run['directory'])
        assert hashlib.sha256((directory / 'result.json').read_bytes()).hexdigest() == run['result_sha256']
        return read(directory / 'host.json')
    protocol = read(args.protocol)
    assert hashlib.sha256(args.plan.read_bytes()).hexdigest() == protocol['plan_sha256']
    result = analyze(read(args.plan), read(args.samples), read(args.attempts), protocol, read_host)
    result['input_sha256'] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in (args.plan, args.samples, args.attempts, args.protocol, Path(__file__))}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
