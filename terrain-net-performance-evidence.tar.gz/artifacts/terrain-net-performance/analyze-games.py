from pathlib import Path
import json,statistics,math,random,hashlib
ROOT=Path(__file__).resolve().parent
plan=json.loads((ROOT/'game-plan.json').read_text()); rows=json.loads((ROOT/'game-samples.json').read_text())
pairs=plan['pairs_per_scenario']; keys=[(m,s) for m in plan['maps'] for s in plan['seeds']]
assert len(rows)==2*pairs*len(keys),'timing matrix incomplete'
group={}
for r in rows:
 key=(r['map'],r['seed'],r['pair'],r['variant']);assert key not in group;group[key]=r
logs={}; report=[]
for m,s in keys:
 ratios=[group[m,s,p,'candidate']['cpu_ns_per_tick']/group[m,s,p,'baseline']['cpu_ns_per_tick'] for p in range(pairs)];logs[m,s]=[math.log(x) for x in ratios]
 rng=random.Random(462811);boot=[statistics.median([logs[m,s][rng.randrange(pairs)] for _ in range(pairs)]) for _ in range(10000)];boot.sort()
 lo,hi=[100*math.expm1(boot[int(q*(len(boot)-1))]) for q in (.025,.975)]
 base=group[m,s,0,'baseline'];cand=group[m,s,0,'candidate']
 entry={'map':m,'seed':s,'pairs':pairs,'median_paired_cpu_change_percent':100*math.expm1(statistics.median(logs[m,s])),'paired_bootstrap_95_percent':[lo,hi],'median_cpu_ns_per_tick':{v:statistics.median(group[m,s,p,v]['cpu_ns_per_tick'] for p in range(pairs)) for v in ('baseline','candidate')},'final_units':{'baseline':base['units'],'candidate':cand['units']},'final_buildings':{'baseline':base['buildings'],'candidate':cand['buildings']},'gradient_jobs':{'baseline':base['gradient_jobs'],'candidate':cand['gradient_jobs']},'pair_ratios':ratios}
 report.append(entry)
# Resample complete rounds across scenarios together: retain cross-scenario
# covariance from time-varying host load. This CI describes this fixed suite.
rng=random.Random(72941);boot=[]
for _ in range(10000):
 ids=[rng.randrange(pairs) for _ in range(pairs)]
 boot.append(statistics.mean(statistics.median(logs[k][i] for i in ids) for k in keys))
boot.sort();agg=100*math.expm1(statistics.mean(statistics.median(logs[k]) for k in keys))
weighted=100*(sum(r['median_cpu_ns_per_tick']['candidate'] for r in report)/sum(r['median_cpu_ns_per_tick']['baseline'] for r in report)-1)
summary={'definition':plan['primary_aggregate'],'aggregate_change_percent':agg,'round_block_bootstrap_95_percent':[100*math.expm1(boot[int(q*(len(boot)-1))]) for q in (.025,.975)],'ratio_of_summed_scenario_medians_percent':weighted,'ci_scope':'Measurement variation of this fixed suite; does not establish a population estimate for all typical games.','scenarios':report,'input_sha256':hashlib.sha256((ROOT/'game-samples.json').read_bytes()).hexdigest(),'limitations':plan['limits']}
(ROOT/'game-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
