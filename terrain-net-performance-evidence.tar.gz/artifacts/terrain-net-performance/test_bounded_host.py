import unittest
from bounded_host import interval, observe_child, process_ticks, window


def point(t, total, target_busy, sibling_busy, child):
    return {'time': t, 'child_ticks': child, 'cpus': {15: {'total': total, 'idle': total-target_busy}, 31: {'total': total, 'idle': total-sibling_busy}}}


class MonitorTests(unittest.TestCase):
    def test_process_stat_spaces_parentheses(self):
        suffix = ['S'] + ['0'] * 20
        suffix[11], suffix[12] = '17', '9'
        self.assertEqual(process_ticks('123 (odd ) process) ' + ' '.join(suffix)), 26)

    def test_child_subtraction_and_negative_sampling_skew(self):
        part = interval(point(0, 0, 0, 0, 0), point(1, 100, 90, 30, 80), 15, 31)
        self.assertEqual(part['cpus'][15]['external_ticks'], 10)
        self.assertEqual(part['cpus'][31]['external_ticks'], 30)
        skew = interval(point(0, 0, 0, 0, 0), point(1, 100, 80, 0, 81), 15, 31)
        self.assertEqual(skew['cpus'][15]['external_ticks'], 0)
        self.assertEqual(skew['cpus'][15]['raw_external_ticks'], -1)

    def test_rolling_window_does_not_dilute_late_contention(self):
        parts = []
        for i in range(10):
            parts.append(interval(point(i, i*100, 0, max(0,i-5)*100, 0), point(i+1, (i+1)*100, 0, max(0,i-4)*100, 0), 15, 31))
        self.assertEqual(window(parts, 31)['external_busy_percent'], 100)
        self.assertIsNone(window(parts[:4], 31))
        self.assertEqual(window(parts[:4], 31, final=True)['external_busy_percent'], 0)

    def test_partial_interval_and_exact_threshold(self):
        parts = [interval(point(0,0,0,0,0), point(3,300,0,0,0),15,31), interval(point(3,300,0,0,0),point(6,600,0,100,0),15,31)]
        self.assertAlmostEqual(window(parts,31)['external_busy_percent'],20)

    def test_zero_tick_terminal_interval(self):
        parts = [interval(point(0,0,0,0,0), point(1,100,90,10,80),15,31),
                 interval(point(1,100,90,10,80), point(1.001,100,90,10,80),15,31)]
        self.assertAlmostEqual(window(parts,15,final=True)['external_busy_percent'],10)

    def test_final_sample_before_reap(self):
        events = []
        class Child:
            pid = 9
            def wait(self): events.append('wait'); return 0
        done = iter([False, True])
        def take(pid, cpus): events.append('sample'); return {'child_ticks': len(events)}
        samples, hosts, code = observe_child(Child(), (15,31), lambda: {}, pause=lambda _: events.append('sleep'), get_sample=take, exited=lambda _: next(done))
        self.assertEqual(events, ['sleep','sample','sleep','sample','wait'])
        self.assertEqual(len(samples),2)
        self.assertEqual(code,0)

if __name__ == '__main__': unittest.main()
