from pathlib import Path
import hashlib,json,os,subprocess,time,sys
ROOT=Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'game-plan.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=[]; expected={}; started=time.time()
# Rotate maps/seeds between pairs to distribute host drift across scenarios.
scenarios=[(m,s) for m in PLAN['maps'] for s in PLAN['seeds']]
for repeat in range(PLAN['pairs_per_scenario']):
 for offset in range(len(scenarios)):
  name,seed=scenarios[(offset+repeat)%len(scenarios)]
  for variant in (('baseline','candidate') if repeat%2==0 else ('candidate','baseline')):
   c=PLAN['variants'][variant]; assert sha(c['binary'])==c['sha256']
   dest=ROOT/'games'/f'{name}-s{seed}-p{repeat}-{variant}';dest.mkdir(exist_ok=True)
   cmd=['taskset','-c',str(PLAN['cpu']),c['binary'],'--run-game','--map-file',PLAN['maps'][name]['path'],'--game-seed',str(seed),'--player','maxima','--player','nicowar','--ticks',str(PLAN['ticks']),'--rule','noGrowth=0','--compute-threads','1','--gradient-workers','0','--benchmark-warmup',str(PLAN['warmup']),'--output-dir',str(dest)]
   inputs={'command':cmd,'cwd':c['cwd'],'binary_sha256':c['sha256'],'map_sha256':PLAN['maps'][name]['sha256'],'environment':{'GLOB2_PERF_DISABLE':'1','SDL_VIDEODRIVER':'dummy','SDL_AUDIODRIVER':'dummy'}}
   if (dest/'result.json').exists():
    prior=json.loads((dest/'inputs.json').read_text());assert prior['inputs']==inputs
   else:
    (dest/'inputs.json').write_text(json.dumps({'inputs':inputs,'load_average':os.getloadavg(),'time':time.time()},indent=2)+'\n')
    with (dest/'run.log').open('w') as log:subprocess.run(cmd,cwd=c['cwd'],env=dict(os.environ,**inputs['environment']),stdout=log,stderr=subprocess.STDOUT,check=True)
   d=json.loads((dest/'result.json').read_text());assert d['ticks']==PLAN['ticks'],d['termination'];assert d['benchmark_measured_ticks']==PLAN['ticks']-PLAN['warmup']
   # Different variants need not evolve identically, but every repeat must.
   state={k:d[k] for k in ('initialChecksum','finalChecksum','teams','gradient_jobs','gradient_published','hiring_popped_entries')}
   key=(name,seed,variant)
   if key in expected:assert expected[key]==state,(key,'nondeterministic repeat')
   else:expected[key]=state
   history=d['teams'];row={'map':name,'seed':seed,'pair':repeat,'variant':variant,'cpu_ns_per_tick':d['benchmark_run_cpu_ns']/d['benchmark_measured_ticks'],'cpu_ns':d['benchmark_run_cpu_ns'],'measured_ticks':d['benchmark_measured_ticks'],'finalChecksum':d['finalChecksum'],'units':sum(t['units'] for t in history),'buildings':sum(t['buildings'] for t in history),'gradient_jobs':d['gradient_jobs'],'gradient_published':d['gradient_published'],'hiring_popped_entries':d['hiring_popped_entries'],'result_sha256':sha(dest/'result.json')}
   rows.append(row);(ROOT/'game-samples.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(f'{len(rows)//2}/{len(scenarios)*PLAN["pairs_per_scenario"]} pairs {name} seed{seed} pair{repeat} elapsed{time.time()-started:.1f}s',flush=True)
print('PASS repeated within-variant state equality; complete timing matrix',flush=True)
