#pragma once
#include <cstddef>
#include <cstdint>

enum class Reader { Packed16, Eager, Snapshot };

struct WorkspaceInfo
{
    std::size_t objectBytes;
    std::size_t retainedBytes;
    std::size_t bucketCount;
    std::uintptr_t firstQueueAddress;
};

#define DECLARE_VARIANT(name) \
    extern "C" void *name##_create(); \
    extern "C" void name##_destroy(void *); \
    extern "C" WorkspaceInfo name##_info(void *); \
    extern "C" void name##_run(void *, std::uint16_t *, const void *, int, int, int, int, Reader, bool)
DECLARE_VARIANT(legacy);
DECLARE_VARIANT(final);
#undef DECLARE_VARIANT
