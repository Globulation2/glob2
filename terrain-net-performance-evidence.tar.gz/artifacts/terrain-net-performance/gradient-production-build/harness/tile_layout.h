#pragma once
#include <cstddef>
inline constexpr std::size_t LegacyTileBytes = 36;
inline constexpr std::size_t LegacyTerrainOffset = 0;
inline constexpr std::size_t LegacyTileAlignment = 4;
static_assert(LegacyTileAlignment <= 64);
