"""Explain changed workload with exact call counts, never timing correction."""
from pathlib import Path
import json
root=Path(__file__).resolve().parent
records=json.loads((root/'profile-counts.json').read_text())
group={(r['map'],r['variant']):{s['scope']:int(s['calls']) for s in r['scopes']} for r in records}
scopes=['gradient.building','gradient.building_resume','gradient.propagation','path.resource','path.building','path.point','path.area','path.direction']
rows=[]
for name in json.loads((root/'game-plan.json').read_text())['maps']:
 for scope in scopes:
  old=group[name,'baseline'].get(scope,0);new=group[name,'candidate'].get(scope,0)
  rows.append({'map':name,'scope':scope,'baseline_calls':old,'candidate_calls':new,'change_percent':100*(new/old-1) if old else None})
assert all(r['state_matches_uninstrumented'] for r in records)
(root/'work-count-summary.json').write_text(json.dumps({'seed':12345,'ticks':16384,'includes_warmup':True,'state_matches_uninstrumented':True,'counts':rows,'limits':'Calls are not cell counts or identical work. Diagnostic timings excluded. No normalization of whole-game CPU by these counts.'},indent=2)+'\n')
lines=['| Scenario | Operation calls | Before | After | Change |','| --- | --- | ---: | ---: | ---: |']
for row in rows:
 change=f'{row["change_percent"]:+.1f}%' if row['change_percent'] is not None else 'n/a'
 lines.append(f'| {row["map"]} | {row["scope"]} | {row["baseline_calls"]:,} | {row["candidate_calls"]:,} | {change} |')
(root/'work-count-table.md').write_text('\n'.join(lines)+'\n')
