# Observed-load-bounded endpoint runner

`run-bounded-games.py` is a new runner; it does not modify or resume the running `run-clean-games.py` experiment. It uses the same frozen game plan, nine map/seed scenarios, eleven alternating pairs, binaries, flags and within-version state checks.

Start only after coordinating/stopping other timing runners:

```sh
taskset -c 0-3 python3 artifacts/terrain-net-performance/run-bounded-games.py \
  > artifacts/terrain-net-performance/bounded-games.log 2>&1
```

The script refuses to reuse `bounded-games/`. It writes `bounded-protocol.json` before launching games, with script/helper/plan hashes, thresholds, topology, monitor affinity and counter units. Accepted rows go to `bounded-game-samples.json`; `bounded-attempts.json` and each attempt directory preserve accepted and rejected pairs. The input/result schema is compatible with the existing timing analysis, after selecting this sample file explicitly. No timing games were launched during preparation.

## Gate and samples

- Preflight: both CPU15 and sibling31 must have no more than 20% observed busy time over two seconds. Both endpoint load samples must have at most two recognized compiler/linker processes and load1 at most10.
- Runtime: sample CPU counters and aggregate child utime+stime approximately every second. Taskset exec keeps the child PID. Subtract child CPU ticks from CPU15 busy ticks to estimate competing work; measure CPU31 busy directly.
- Assess trailing five-second windows at each observation. Runs shorter than five seconds use their complete observed interval at exit. Partially overlapping intervals are proportionally weighted. Reject the whole pair if either member exceeds20% external busy time in an assessed window, or violates the predeclared compiler/load gate at any sample.
- Linux pidfd exit notification wakes the sampler promptly. `waitid(WNOWAIT)` leaves the child unreaped until its final `/proc/PID/stat` sample, avoiding lost final CPU ticks or a full polling-interval tail. The monitor excludes15/31 from its own affinity.

This is observed-load bounding, not isolation. CPU counters have tick granularity; reading CPU and process counters is not atomic. Raw negative residuals are saved and clamped to zero for gating. A terminal interval can contain no new ticks; it contributes no counter weight. Child pre-exec taskset overhead may briefly run on an inherited monitor CPU before affinity changes and is still included in aggregate child ticks. All subsequent child threads are assumed to inherit target affinity. Descendant process CPU is not subtracted. Frequency, shared caches/memory bandwidth, short unsampled bursts and imperfect attribution remain limitations. Setup/warmup are included in observation, although rolling windows prevent long idle spans from diluting later contention. Load average includes the benchmark itself. The runner never examines speed to decide acceptance.

## Checks

```sh
python3 artifacts/terrain-net-performance/test_bounded_host.py
```

Six synthetic tests cover process names containing spaces/parentheses, child subtraction and negative sampling skew, late contention in rolling windows, partial windows and the exact20% threshold, a zero-tick terminal interval, and final sampling before reaping. `bounded-monitor-tests.log` records the results. A separate50ms sleeping child pinned to CPU0 verified actual Linux pidfd/waitid final sampling; this was a monitor smoke check, not a performance benchmark.
