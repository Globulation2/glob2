// Compile twice against untouched archived source trees. Distinct namespace/type
// names keep historical and final definitions out of each other's ODR domains.
#include <bits/stdc++.h>
#include "api.h"
#ifdef LEGACY
#define gradient_kernel legacy_gradient_kernel
#define field legacy_field
#define GradientWorkspace LegacyGradientWorkspace
#define GradientBucket LegacyGradientBucket
#include "field/GradientPropagation.h"
#define PREFIX(name) legacy_##name
#else
#define gradient_kernel final_gradient_kernel
#define field final_field
#define GradientWorkspace FinalGradientWorkspace
#define GradientBucket FinalGradientBucket
#include "field/TerrainGradient.h"
#define PREFIX(name) final_##name
#endif

static_assert(GradientBucket::COUNT == 64);
static_assert(gradient_kernel::COST_LIMIT == 65491);
static_assert(gradient_kernel::LAND_STEPS.cardinal == 10);
static_assert(gradient_kernel::LAND_STEPS.diagonal == 14);
static_assert([] {
    constexpr unsigned expected[] = {0, 5, 7, 10, 13, 20, 30};
    for (unsigned i = 0; i < std::size(expected); ++i)
        if (gradient_kernel::WATER_STEP[i] != expected[i]) return false;
    return true;
}());
static_assert(sizeof(GradientWorkspace) == 2072);

extern "C" void *PREFIX(create)() { return new GradientWorkspace; }
extern "C" void PREFIX(destroy)(void *workspace)
{
    delete static_cast<GradientWorkspace *>(workspace);
}
extern "C" WorkspaceInfo PREFIX(info)(void *pointer)
{
    auto &workspace = *static_cast<GradientWorkspace *>(pointer);
    std::size_t bytes = workspace.deferredSeeds.capacity() * sizeof(std::pair<int, int>);
    std::uintptr_t firstAddress = 0;
    for (const auto &bucket : workspace.buckets)
    {
        bytes += bucket.cells.capacity() * sizeof(std::uint32_t);
        if (!firstAddress && bucket.cells.capacity())
            firstAddress = reinterpret_cast<std::uintptr_t>(bucket.cells.data());
    }
    return {sizeof(workspace), bytes, GradientBucket::COUNT, firstAddress};
}
extern "C" void PREFIX(run)(void *pointer, std::uint16_t *output,
    const std::uint16_t *terrain, int width, int height, int swim, int cap,
    bool modifiedCosts)
{
    auto &workspace = *static_cast<GradientWorkspace *>(pointer);
#ifdef LEGACY
    (void)modifiedCosts;
    gradient_kernel::propagateField(output, swim, cap, {width, height}, workspace,
        [terrain](std::size_t i) { return terrain[i] >= 256 && terrain[i] < 272; });
#else
    gradient_kernel::propagateTerrainField(output, swim, cap, {width, height}, workspace,
        [terrain](std::size_t i) { return static_cast<TerrainType>(terrain[i]); }, modifiedCosts);
#endif
}
