import copy
import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('analysis', Path(__file__).with_name('analyze-bounded-games.py'))
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)


def fixture():
    plan = {'maps': {'a': {}, 'b': {}, 'c': {}}, 'seeds': [1,2,3], 'pairs_per_scenario': 11, 'ticks': 100, 'warmup': 10, 'primary_aggregate': 'equal-weight geometric mean of paired scenario medians', 'limits': []}
    protocol = {'target_cpu':15, 'sibling_cpu':31, 'thresholds': {'maximum_load1':10, 'maximum_compiler_processes':2, 'maximum_external_busy_percent':20}, 'limits': []}
    rows, attempts = [], []
    for name in plan['maps']:
        for seed in plan['seeds']:
            for pair in range(11):
                runs = []
                for variant in ('baseline','candidate'):
                    cpu = (100 + pair) * (0.8 if variant == 'candidate' else 1)
                    runs.append({'map':name, 'seed':seed, 'pair':pair, 'variant':variant, 'attempt':1, 'host_accepted':True, 'cpu_ns_per_tick':cpu, 'cpu_ns':cpu*90, 'measured_ticks':90, 'units':5, 'buildings':2, 'gradient_jobs':100, 'gradient_published':100, 'hiring_popped_entries':0, 'finalChecksum':str(variant)})
                rows.extend(runs)
                attempts.append({'map':name, 'seed':seed, 'pair':pair, 'attempt':1, 'accepted':True, 'runs':runs})
    def read_host(run):
        return {'accepted':True, 'host_samples':[{'load1':3,'compilers':0}], 'windows':[{'cpu':15,'external_busy_percent':1},{'cpu':31,'external_busy_percent':2}]}
    return plan,rows,attempts,protocol,read_host


class AnalysisTests(unittest.TestCase):
    def test_known_ratio_and_groups(self):
        result = analysis.analyze(*fixture(),bootstrap_samples=20)
        self.assertAlmostEqual(result['overall']['median_paired_geometric_change_percent'],-20)
        self.assertEqual(result['attempts']['accepted_pairs'],99)
        self.assertEqual(len(result['per_map']),3)
        self.assertEqual(len(result['per_seed']),3)
        self.assertEqual(len(result['scenarios']),9)
        self.assertAlmostEqual(result['ratio_of_summed_scenario_medians_percent'],-20)

    def test_missing_and_duplicate_rows_rejected(self):
        data = list(fixture());data[1] = data[1][:-1]
        with self.assertRaises(AssertionError): analysis.analyze(*data,bootstrap_samples=1)
        data = list(fixture());data[1].append(data[1][0])
        with self.assertRaises(AssertionError): analysis.analyze(*data,bootstrap_samples=1)

    def test_rejected_sample_and_wrong_decision(self):
        data = list(fixture());data[1][0]['host_accepted'] = False
        with self.assertRaises(AssertionError): analysis.analyze(*data,bootstrap_samples=1)
        data = list(fixture());data[4] = lambda run: {'accepted':True,'host_samples':[{'load1':11,'compilers':0}],'windows':[{'cpu':15,'external_busy_percent':1}]}
        with self.assertRaises(AssertionError): analysis.analyze(*data,bootstrap_samples=1)

    def test_rejected_attempt_count(self):
        data = list(fixture())
        rejected = copy.deepcopy(data[2][0])
        rejected['accepted'] = False
        rejected['runs'][0]['host_accepted'] = False
        data[2][0]['attempt'] = 2
        for row in data[2][0]['runs']:
            row['attempt'] = 2
        data[2].insert(0, rejected)
        original_host = data[4]
        def read_host(run):
            result = original_host(run)
            if not run['host_accepted']:
                result['accepted'] = False
                result['host_samples'][0]['load1'] = 11
            return result
        data[4] = read_host
        result = analysis.analyze(*data,bootstrap_samples=20)
        self.assertEqual(result['attempts']['rejected_pairs'],1)
        self.assertEqual(result['attempts']['total_pair_attempts'],100)

    def test_round_bootstrap_preserves_covariance(self):
        data = list(fixture())
        for row in data[1]:
            if row['variant'] == 'candidate':
                ratio = 0.75 + row['pair'] * 0.05
                row['cpu_ns_per_tick'] = (100 + row['pair']) * ratio
                row['cpu_ns'] = row['cpu_ns_per_tick'] * 90
        result = analysis.analyze(*data,bootstrap_samples=50)
        self.assertEqual(result['overall']['round_block_bootstrap_95_percent'],result['scenarios'][0]['round_block_bootstrap_95_percent'])

if __name__ == '__main__': unittest.main()
