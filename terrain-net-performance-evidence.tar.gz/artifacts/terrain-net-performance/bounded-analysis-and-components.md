# Bounded-suite analysis and component observation

The original pilot analysis and timing scripts are unchanged. Run the separate final analysis only after all planned99 pairs have been accepted:

```sh
python3 artifacts/terrain-net-performance/analyze-bounded-games.py
```

It consumes `bounded-game-samples.json`, `bounded-attempts.json`, `bounded-protocol.json` and `game-plan.json`. It requires exactly the planned scenario/round/variant keys, checks accepted samples against retained accepted attempts, checks within-variant final observables, verifies result-file hashes, and verifies recorded host decisions against predeclared thresholds. Partial matrices and mixed accepted/rejected rows fail.

`bounded-game-summary.json` reports each map/seed scenario, per-map and per-seed aggregates, equal-weight overall geometric change, and the historical ratio of summed per-scenario CPU medians. Primary estimates use median paired log CPU ratios, then average scenario log estimates. Ten thousand bootstrap draws resample the same eleven round IDs jointly across all scenarios; baseline/candidate pairing and cross-scenario round covariance remain intact. It reports acceptance/rejection counts and accepted/rejected runtime load/compiler/core-window maxima.

Bootstrap intervals describe conditional measurement variation of this fixed accepted suite, not variation across the population of games. They do not correct dependence between adjacent rounds, gaps caused by retries, changed simulation trajectories or hardware/counter inaccuracies. Counts and population snapshots are descriptive; no posthoc workload normalization is performed. The host summary validates recorded windows, not the underlying monitor independently.

Five synthetic tests passed, covering a known20% improvement, group inventory, incomplete/duplicate/rejected samples, invalid host decisions, rejected-attempt accounting and perfect cross-scenario round correlation. See `test_bounded_analysis.py` and `bounded-analysis-tests.log`.

## Optional coarse component observer

`run-bounded-components.py` observes one unchanged whole-benchmark command. It does one preflight for the matrix, samples compiler count/load and sibling31, preserves stdout/stderr/counters, and never automatically retries. It intentionally does not subtract the Python orchestrator's CPU from target-core activity: that would miss native grandchildren. It refuses to dispatch while known whole-game runner scripts are active.

Example, only after the game suite has finished:

```sh
python3 artifacts/terrain-net-performance/run-bounded-components.py \
  --output artifacts/terrain-net-performance/component-observation-1 -- \
  python3 artifacts/terrain-net-performance/gradient/run.py \
  --output artifacts/terrain-net-performance/gradient-readers-build --run-only \
  --suite full --name observed-components-1 --cpu 15 --repeats 11
```

The command selects its own leaf affinity. The observer does not rewrite arguments or instrument the kernels. Its own affinity excludes15/31. Output directories must be fresh. Exit2 means coarse host bounds were exceeded; raw evidence remains and there is no automatic retry or selective leaf removal. Nonzero child exit is preserved.

These observations are weaker than the whole-game monitor: they do not attribute competing work on CPU15, and one-second samples/five-second sibling windows may miss brief interference. Aggregate command timing is not component CPU timing. Known-script process detection is not an exclusive system lock. No component command or performance measurement was launched while preparing these artifacts.
