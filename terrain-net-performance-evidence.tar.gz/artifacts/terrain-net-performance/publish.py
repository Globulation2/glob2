"""Publish research evidence on a dedicated branch; never touch product index/tree."""
from pathlib import Path
import hashlib,json,os,subprocess,tarfile,tempfile
root=Path.cwd(); evidence=root/'artifacts/terrain-net-performance'; out=evidence/'published';out.mkdir(exist_ok=True)
report=evidence/'REPORT.md';assert report.exists()
skip_roots={'runtime-final','published','__pycache__'}
extensions={'.md','.py','.log','.json','.jsonl','.xml','.txt','.csv','.checksums','.h','.cpp'}
files=[]
for p in evidence.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(evidence)
 if any(part in skip_roots or part in {'source-baseline','source-candidate','legacy','final'} for part in rel.parts):continue
 if p.suffix not in extensions or p.name=='REPORT-draft.md':continue
 files.append(p)
# Include actual fixed map inputs and frozen compile provenance, not only local paths.
plan=json.loads((evidence/'game-plan.json').read_text())
extra=[(Path(row['path']),f'inputs/maps/{name}.map.gz') for name,row in plan['maps'].items()]
extra += [(Path('/tmp/glob2-terrain-baseline-build/compile_commands.json'),'inputs/baseline-compile-commands.json'),(Path('/tmp/glob2-terrain-baseline-build/include/glob2/BuildConfig.h'),'inputs/baseline-BuildConfig.h')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
entries=[(p,str(p.relative_to(root))) for p in sorted(files)] + extra
manifest={name:{'sha256':sha(p),'bytes':p.stat().st_size} for p,name in entries}
manifest_path=out/'files.json';manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
archive=out/'terrain-net-performance-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for path,name in entries:tar.add(path,arcname=name)
 tar.add(manifest_path,arcname='files.json')
assert archive.stat().st_size <95*1024*1024,archive.stat().st_size
published=out/'REPORT.md';published.write_text(report.read_text()+f'\n[Raw evidence archive]({archive.name}), SHA-256 `{sha(archive)}`. Files remain outside product history. The archive includes raw samples, rejected attempts, monitors, source-extracted benchmark code, compiler/input hashes and fixed map inputs; large runtime asset trees and executable binaries are omitted. Rebuild source from the recorded revisions and reproduce the recorded compiler/dependency setup.\n')
details=[]
for name,source in [('FERTILITY.md','fertility-production/analysis.md'),('GROWTH.md','growth/representative-final/REPORT.md'),('GRADIENT.md','gradient-production-analysis/REPORT.md')]:
 target=out/name;target.write_bytes((evidence/source).read_bytes());details.append(target)
branch='codex/evidence-terrain-net-performance'
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],text=True).strip()
parent=remote.split()[0] if remote else None
if parent:subprocess.run(['git','fetch','origin',branch],check=True)
with tempfile.TemporaryDirectory(prefix='terrain-net-evidence-') as tmp:
 env=dict(os.environ,GIT_INDEX_FILE=str(Path(tmp)/'index'))
 def git(*args,input=None):return subprocess.check_output(['git',*args],env=env,input=input).decode().strip()
 git('read-tree',parent if parent else '--empty')
 for p in (published,archive,manifest_path,*details):
  blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo','100644',blob,p.name)
 tree=git('write-tree');args=['commit-tree',tree]
 if parent:args+=['-p',parent]
 commit=git(*args,input=b'Publish terrain endpoint CPU attribution evidence\n')
 subprocess.run(['git','push','origin',commit+':refs/heads/'+branch],check=True)
 (out/'commit.txt').write_text(commit+'\n')
 print('https://github.com/Globulation2/glob2/blob/'+commit+'/REPORT.md')
