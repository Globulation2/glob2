#include "Map.h"
#include <cstddef>
#include <cstdio>
#include <type_traits>
int main()
{
    static_assert(std::is_standard_layout_v<Tile>);
    std::printf("{\"tile_bytes\":%zu,\"tile_alignment\":%zu,\"terrain_offset\":%zu,\"terrain_bytes\":%zu,\"resource_bytes\":%zu}\n",
        sizeof(Tile), alignof(Tile), offsetof(Tile, terrain), sizeof(Tile::terrain), sizeof(Resource));
}
