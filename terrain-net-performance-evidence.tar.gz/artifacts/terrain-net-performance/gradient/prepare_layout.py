#!/usr/bin/env python3
"""Compile actual archived Map.h/Resource definitions with the baseline include environment."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
REVISION = '934c3c588bea51ec7421152e15f5168b2aaf5502'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--commands', type=Path, default=Path('/tmp/glob2-terrain-baseline-build/compile_commands.json'))
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True)
    entry = next(entry for entry in json.loads(args.commands.read_text())
                 if entry['file'].endswith('MapGradientPropagation.cpp'))
    checkout = Path(entry['directory'])
    # Both definitions are copied verbatim from Git. Dependencies use the exact
    # pre-terrain build include environment, whose Map and Resource are verified.
    inputs = {}
    for name in ('src/map/Map.h', 'src/resource/Ressource.h'):
        content = subprocess.check_output(['git', 'show', f'{REVISION}:{name}'], cwd=ROOT)
        if (checkout / name).read_bytes() != content:
            raise RuntimeError('Baseline checkout differs from archived definition: ' + name)
        target = args.output / Path(name).name
        target.write_bytes(content)
        inputs[name] = dict(sha256=sha(target), copy=str(target))
    probe = args.output / 'layout_probe.cpp'
    probe.write_bytes((HERE / 'layout_probe.cpp').read_bytes())
    flags = shlex.split(entry['command'])
    original_output = flags.index('-o')
    del flags[original_output:original_output + 2]
    flags.remove('-c')
    flags.remove(entry['file'])
    # The include at the front chooses archived Map.h/Ressource.h over the
    # matching checkout copies, while all transitively required engine headers
    # retain their original include directories and compiler configuration.
    command = [flags[0], '-I' + str(args.output), *flags[1:], str(probe),
               '-o', str(args.output / 'layout-probe')]
    subprocess.run(command, cwd=checkout, check=True)
    values = json.loads(subprocess.check_output([str(args.output / 'layout-probe')], text=True))
    manifest = dict(revision=REVISION, command=command, cwd=str(checkout),
                    source_inputs=inputs, probe_sha256=sha(probe),
                    binary_sha256=sha(args.output / 'layout-probe'),
                    compiler=subprocess.check_output([flags[0], '--version'], text=True),
                    compile_commands_sha256=sha(args.commands), values=values)
    (args.output / 'layout.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(values))


if __name__ == '__main__':
    main()
