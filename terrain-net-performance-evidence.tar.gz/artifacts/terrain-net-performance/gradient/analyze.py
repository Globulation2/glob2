#!/usr/bin/env python3
"""Validate/analyze the fixed classic-gradient matrix without running benchmarks."""
from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics

LEGACY = '934c3c588bea51ec7421152e15f5168b2aaf5502'
FINAL = '37d609766374e7efc1679d643c7d18cde84364ab'
# This reviewed driver checks the complete oracle vector before emitting a row.
ORACLE_DRIVER_SHA256 = '6ce3f610c769caf7ab1aed5684908014424606117cb896f4c8f30a73eb6e278f'
READERS = ('packed16-control', 'eager', 'snapshot')
LAYOUTS = ('shared', 'separate')
LINK_ORDERS = ('legacy-first', 'final-first')
IMPLEMENTATIONS = ('legacy', 'final')
CASE_KEYS = ('width', 'height', 'swim', 'seeds', 'cap')
COMBINATION_KEYS = (*CASE_KEYS, 'reader', 'layout', 'link_order')
FULL_CAP = 65491


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def case_key(value):
    return tuple(value[key] for key in CASE_KEYS)


def combination_key(value):
    return tuple(value[key] for key in COMBINATION_KEYS)


def expected_cases():
    shapes = ((32, 32), (128, 128), (256, 256), (512, 512),
              (1, 31), (2, 17), (17, 31), (32, 128), (128, 256))
    seeds = ('single', 'sparse', 'dense', 'deferred', 'blocked', 'all-blocked')
    return {(width, height, swim, seed, cap)
            for (width, height), swim, seed, cap in itertools.product(
                shapes, range(7), seeds, (127, FULL_CAP))}


def validate_provenance(build, measurement):
    run = load(measurement / 'run.json')
    manifest = load(build / 'manifest.json')
    require(run['suite'] == 'full' and run['repeats'] == 11,
            'Expected the complete full suite with exactly eleven warm pairs.')
    require(set(run['link_orders']) == set(LINK_ORDERS), 'Missing/unexpected link order.')
    require(set(run['readers']) == set(READERS), 'Missing/unexpected reader mode.')
    require(len(run['cases']) == 756 and {case_key(case) for case in run['cases']} == expected_cases(),
            'Unexpected or duplicate planned cases.')
    require(sha(build / 'manifest.json') == run['manifest_sha256'], 'Manifest hash changed.')
    require(manifest['legacy_revision'] == LEGACY and manifest['final_revision'] == FINAL,
            'Source revision mismatch.')
    require(manifest['assertions_enabled'] is True and manifest['counters_enabled'] is False,
            'Expected production assertions and uninstrumented timings.')
    require('-O3' in manifest['flags'] and '-fPIC' in manifest['flags']
            and not any(flag.startswith('-DNDEBUG') for flag in manifest['flags']), 'Wrong compiler flags.')
    for relative, digest in manifest['source_hashes'].items():
        require(sha(build / relative) == digest, 'Frozen source hash changed: ' + relative)
    for order in LINK_ORDERS:
        info = manifest['binaries'][order]
        require(sha(info['path']) == info['sha256'], 'Frozen binary hash changed: ' + order)
    require(manifest['source_hashes']['harness/driver.cpp'] == ORACLE_DRIVER_SHA256,
            'Oracle driver requires a fresh source-contract review.')
    require(run['active_runner_sha256'] == manifest['source_hashes']['harness/run.py'],
            'Active runner differs from the reviewed frozen runner.')
    assertions = load(build / 'assertion-mode.json')
    for variant in IMPLEMENTATIONS:
        audit = assertions[variant]
        require(audit['NDEBUG_defined'] is False and '__assert_fail' in audit['assert_macro'],
                'Assertions are not proven active: ' + variant)
        require(sha(build / (variant + '-macros.txt')) == audit['preprocessed_macros_sha256'],
                'Assertion macro audit hash changed.')
    return run, manifest


def validate_observation(directory, build, measurement, run):
    protocol = load(directory / 'protocol.json')
    outcome = load(directory / 'observation.json')
    require(outcome['exit_status'] == 0, 'Benchmark command did not complete successfully.')
    for name in ('stdout', 'stderr'):
        require(sha(directory / (name + '.log')) == outcome[name + '_sha256'],
                'Observer output hash changed: ' + name)
    command = protocol['command']
    argument = lambda key: command[command.index(key) + 1]
    require((Path(protocol['cwd']) / argument('--output')).resolve() == build.resolve(),
            'Observer monitored another build directory.')
    require(argument('--name') == measurement.name and int(argument('--cpu')) == run['cpu']
            and argument('--suite') == 'full' and int(argument('--repeats')) == 11,
            'Observer command does not match this measurement matrix.')
    hosts = outcome['host_samples']
    windows = outcome['sibling_windows']
    require(bool(hosts) and bool(windows), 'Missing runtime host observations.')
    limits = protocol['thresholds']
    accepted = (all(host['load1'] <= limits['maximum_load1']
                    and host['compilers'] <= limits['maximum_compiler_processes'] for host in hosts)
                and all(window['external_busy_percent'] <= limits['maximum_external_busy_percent']
                        for window in windows))
    require(accepted == outcome['coarse_host_bounds_satisfied'], 'Recorded host acceptance disagrees with bounds.')
    return dict(
        accepted_for_performance=accepted, exit_status=outcome['exit_status'],
        host_sample_count=len(hosts), sibling_window_count=len(windows),
        maximum_load1=max(host['load1'] for host in hosts),
        maximum_compilers=max(host['compilers'] for host in hosts),
        maximum_sibling_busy_percent=max(window['external_busy_percent'] for window in windows),
        failed_sibling_windows=sum(window['external_busy_percent'] > limits['maximum_external_busy_percent']
                                   for window in windows),
        thresholds=limits, protocol_sha256=sha(directory / 'protocol.json'),
        observation_sha256=sha(directory / 'observation.json'),
        limitations=protocol['limits'],
    )


def expected_reader_bytes(reader, implementation, cells):
    stride = 36 if reader == 'eager' and implementation == 'legacy' else (
        1 if reader == 'snapshot' and implementation == 'legacy' else 2)
    return stride, stride * cells


def read_rows(measurement):
    wanted = {(*case, reader, layout, order) for case, reader, layout, order in itertools.product(
        expected_cases(), READERS, LAYOUTS, LINK_ORDERS)}
    indexed = defaultdict(dict)
    case_hashes = {}
    count = 0
    with (measurement / 'samples.jsonl').open() as stream:
        for line in stream:
            row = json.loads(line)
            key = combination_key(row)
            require(key in wanted, 'Unexpected case/reader/layout/link-order sample.')
            sample = (row['repetition'], row['implementation'])
            require(sample[0] in range(-1, 11) and sample[1] in IMPLEMENTATIONS,
                    'Unexpected repetition or implementation.')
            require(sample not in indexed[key], 'Duplicate repetition/implementation sample.')
            expected_order = (IMPLEMENTATIONS.index(sample[1]) - sample[0] - 2) % 2
            require(row['order'] == expected_order, 'Alternating paired order changed.')
            for timing in ('cpu_ns', 'wall_ns'):
                require(isinstance(row[timing], int) and row[timing] > 0,
                        'Invalid timing observation: ' + timing)
            if 'oracle_passed' in row:
                require(row['oracle_passed'] is True, 'Explicit oracle failure flag.')
            hashes = tuple(row[name] for name in (
                'field_hash', 'seed_hash', 'terrain_type_hash', 'terrain_sprite_hash'))
            require(all(isinstance(digest, str) and digest.isdecimal() for digest in hashes),
                    'Missing/invalid field or input hashes.')
            base = key[:len(CASE_KEYS)]
            require(case_hashes.setdefault(base, hashes) == hashes,
                    'Inputs or full-field results differ across variants/readers/layouts/repeats.')
            cells = row['width'] * row['height']
            stride, footprint = expected_reader_bytes(row['reader'], sample[1], cells)
            allocation = max(expected_reader_bytes(row['reader'], variant, cells)[1]
                             for variant in IMPLEMENTATIONS) if row['layout'] == 'shared' else footprint
            require(row['reader_stride'] == stride and row['reader_bytes'] == footprint
                    and row['terrain_allocation_bytes'] == allocation, 'Reader memory layout mismatch.')
            require(row['workspace_bytes'] == 2072 and row['bucket_count'] == 64,
                    'Workspace size/ring changed.')
            indexed[key][sample] = row
            count += 1
    require(set(indexed) == wanted and len(wanted) == 9072, 'Incomplete measurement combination matrix.')
    expected_samples = {(repetition, variant) for repetition, variant in itertools.product(
        range(-1, 11), IMPLEMENTATIONS)}
    for key, rows in indexed.items():
        require(set(rows) == expected_samples and len(rows) == 24, 'Incomplete pair/repetition matrix.')
        for field in ('output_address', 'terrain_address'):
            addresses = {variant: {rows[repetition, variant][field] for repetition in range(-1, 11)}
                         for variant in IMPLEMENTATIONS}
            require(all(len(values) == 1 for values in addresses.values()), 'Buffers moved between repetitions.')
            overlap = bool(addresses['legacy'] & addresses['final'])
            require(overlap == (key[-2] == 'shared'), 'Shared/separate buffer address claim is false.')
        require(rows[-1, 'legacy']['workspace_address'] != rows[-1, 'final']['workspace_address'],
                'Expected private workspaces; address unexpectedly reused.')
    require(count == 217728, 'Expected 9072 combinations times 24 rows.')
    return indexed, count


def active_large(case):
    width, height, _, seeds, cap = case
    return width == height and width in (128, 256, 512) and cap == FULL_CAP \
        and seeds not in ('blocked', 'all-blocked')


def partition(case):
    width, height, _, seeds, cap = case
    if cap != FULL_CAP:
        return 'capped_controls'
    if seeds == 'all-blocked':
        return 'all_blocked_full_field'
    if seeds == 'blocked':
        return 'obstacle_separated_full_field'
    if width != height:
        return 'rectangular_and_thin_full_field'
    return 'active_full_field_' + str(width)


def paired_interval(ratios):
    """Exact quantiles of the empirical paired bootstrap median (odd n=11).

    Resampling an observed pair preserves identical work between variants. This
    describes repeated-solve variability only, assuming exchangeable pairs; it
    cannot correct serial host drift or generalize to a population of maps.
    """
    n = len(ratios)
    require(n == 11, 'Bootstrap median ranks calibrated to eleven pairs.')
    ordered = sorted(ratios)
    def quantile(q):
        for rank, value in enumerate(ordered, 1):
            probability = rank / n
            cdf = sum(math.comb(n, k) * probability ** k * (1 - probability) ** (n - k)
                      for k in range(n // 2 + 1, n + 1))
            if cdf >= q:
                return value
        return ordered[-1]
    return [quantile(.025), quantile(.975)]


def analyze_combinations(indexed, summary, host_accepted):
    recorded = {}
    for row in summary:
        key = (*case_key(row['case']), row['reader'], row['layout'], row['link_order'])
        require(key not in recorded, 'Duplicate summary entry.')
        recorded[key] = row
    require(set(recorded) == set(indexed), 'Summary and raw matrix differ.')
    reports = []
    for key in sorted(indexed):
        rows = indexed[key]
        medians = {variant: statistics.median(rows[repetition, variant]['cpu_ns'] for repetition in range(11))
                   for variant in IMPLEMENTATIONS}
        pairs = [rows[repetition, 'final']['cpu_ns'] / rows[repetition, 'legacy']['cpu_ns']
                 for repetition in range(11)]
        ratio = medians['final'] / medians['legacy']
        previous = recorded[key]
        require(previous['legacy_cpu_ns'] == medians['legacy']
                and previous['final_cpu_ns'] == medians['final'], 'Summary medians disagree with raw rows.')
        require(math.isclose(previous['ratio'], ratio, rel_tol=1e-12)
                and math.isclose(previous['median_pair_ratio'], statistics.median(pairs), rel_tol=1e-12)
                and len(previous['pair_ratios']) == 11
                and all(math.isclose(a, b, rel_tol=1e-12) for a, b in zip(previous['pair_ratios'], pairs)),
                'Summary ratios disagree with raw paired observations.')
        report = dict(zip(COMBINATION_KEYS, key))
        eligible = active_large(key[:len(CASE_KEYS)])
        interval = paired_interval(pairs) if host_accepted and eligible else None
        report.update(
            median_cpu_ns=medians, ratio_of_medians=ratio, paired_ratios=pairs,
            median_paired_ratio=statistics.median(pairs),
            paired_median_empirical_bootstrap_95_interval=interval,
            interval_status=('reported for matched active full-field work' if interval else
                             'suppressed: coarse runtime host bounds failed' if not host_accepted else
                             'not reported for boundary/capped/blocked/small controls'),
            partition=partition(key[:len(CASE_KEYS)]), active_large_full_field=eligible,
            legacy_reader_bytes=rows[0, 'legacy']['reader_bytes'],
            final_reader_bytes=rows[0, 'final']['reader_bytes'],
            retained_queue_bytes={variant: rows[10, variant]['queue_retained_bytes'] for variant in IMPLEMENTATIONS},
        )
        reports.append(report)
    return reports


def aggregates(reports):
    buckets = defaultdict(list)
    for row in reports:
        groups = ['full_matrix', row['partition']]
        if row['active_large_full_field']:
            groups.append('active_full_field_large')
            groups.append('active_large_uniform_profiles' if row['swim'] in (0, 3)
                          else 'active_large_terrain_reading_profiles')
        for group in groups:
            buckets[row['reader'], row['layout'], row['link_order'], group].append(row)
    result = []
    for (reader, layout, order, group), values in sorted(buckets.items()):
        total = {variant: sum(row['median_cpu_ns'][variant] for row in values) for variant in IMPLEMENTATIONS}
        ratio = total['final'] / total['legacy']
        result.append(dict(reader=reader, layout=layout, link_order=order, group=group,
                           case_count=len(values), summed_case_median_cpu_ns=total,
                           cost_weighted_ratio=ratio, change_percent=(ratio - 1) * 100,
                           aggregate_interval=None))
    return result


def sensitivity(aggregate_rows):
    by_group = defaultdict(list)
    for row in aggregate_rows:
        by_group[row['reader'], row['group']].append(row)
    result = []
    for (reader, group), entries in sorted(by_group.items()):
        require(len(entries) == 4, 'Expected all four allocation/link-layout strata.')
        values = {row['layout'] + '/' + row['link_order']: row['cost_weighted_ratio'] for row in entries}
        result.append(dict(reader=reader, group=group, stratified_ratios=values,
                           spread_percentage_points=100 * (max(values.values()) - min(values.values())),
                           crosses_no_change=min(values.values()) <= 1 <= max(values.values())))
    return result


def markdown(report):
    accepted = report['accepted_for_performance']
    lines = [
        '# Classic gradient equivalent-work analysis', '',
        '**' + ('Coarse host bounds passed; results remain conditional microbenchmarks.' if accepted else
                'EXPLORATORY ONLY: runtime host bounds failed. These timings are not accepted performance evidence.') + '**', '',
        f"Validated {report['validation']['raw_rows']:,} rows across 9,072 combinations: 756 cases, three readers, "
        'two allocation layouts and two link orders. Each has eleven alternating warm pairs plus two workspace-cold solves.', '',
        'Every full field passed the frozen driver’s unconditional independent oracle comparison before its row was emitted. '
        'Raw rows did not record an explicit oracle-pass flag; the verified driver hash and completed matrix establish this contract.', '',
        'Ratios below 1 indicate lower final CPU time. Each aggregate is sum(final case median CPU) / '
        'sum(legacy case median CPU). The four layout strata remain separate; there is no pooled headline speedup.', '',
        '| Reader | Workload group | Buffers | Link order | Cases | Final / legacy CPU | Change |',
        '| --- | --- | --- | --- | ---: | ---: | ---: |',
    ]
    shown = {'full_matrix', 'active_full_field_large', 'active_full_field_128',
             'active_full_field_256', 'active_full_field_512'}
    for row in report['aggregates']:
        if row['group'] in shown:
            lines.append(f"| {row['reader']} | {row['group']} | {row['layout']} | {row['link_order']} | "
                         f"{row['case_count']} | {row['cost_weighted_ratio']:.4f} | {row['change_percent']:+.2f}% |")
    host = report['runtime_host_observation']
    lines += ['', 'Host observation: ' +
              f"{host['host_sample_count']} samples; maximum load {host['maximum_load1']:.2f}, "
              f"compiler processes {host['maximum_compilers']}, sibling busy {host['maximum_sibling_busy_percent']:.2f}%; "
              f"{host['failed_sibling_windows']} sibling windows exceeded the recorded bound.", '',
              'The JSON report retains all partitions, every paired ratio, all layout sensitivity comparisons, '
              'source/binary evidence hashes and the host protocol outcome. Paired intervals are suppressed when host bounds fail. '
              'Otherwise they are reported only for matched active square full-field cases at 128²–512². No aggregate interval '
              'is invented by treating unrelated workloads or code layouts as interchangeable samples.', '',
              'Active large fields use full propagation, exclude both obstacle-separated and entirely blocked controls, '
              'and include single/sparse/dense/deferred seeds. Capped, rectangular/thin, blocked and 32² fixtures are separately identified. '
              'Swimming classes 0 and 3 avoid terrain reads and are additionally separated in JSON.', '',
              'Queue addresses remain private and unmatched. Input/output addresses match only in shared-buffer mode. '
              'Snapshot creation and caller buffer copies are excluded from propagation CPU, and their separate preparation timings '
              'are illustrative one-shot metadata. These are classic equivalent-work fields, not new-terrain comparisons, '
              'and they imply no whole-game speedup.', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', type=Path, required=True)
    parser.add_argument('--measurement', default='final-measurements')
    parser.add_argument('--observation', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    build = args.build.resolve()
    measurement = build / args.measurement
    require((measurement / 'summary.json').exists(), 'Incomplete benchmark: summary.json is absent.')
    run, manifest = validate_provenance(build, measurement)
    host = validate_observation(args.observation, build, measurement, run)
    indexed, count = read_rows(measurement)
    cases = analyze_combinations(indexed, load(measurement / 'summary.json'), host['accepted_for_performance'])
    aggregate_rows = aggregates(cases)
    report = dict(
        accepted_for_performance=host['accepted_for_performance'],
        status='accepted under coarse host bounds' if host['accepted_for_performance'] else 'exploratory: coarse runtime host bounds failed',
        validation=dict(raw_rows=count, combinations=len(cases), cases=756, warm_pairs_per_combination=11,
                        oracle_contract_verified=True, per_row_oracle_flags_recorded=False,
                        oracle_evidence='Known driver hash; unconditional full-vector oracle equality before every row; complete successful matrix.',
                        oracle_driver_sha256=ORACLE_DRIVER_SHA256, assertions_enabled=True,
                        input_and_output_hashes_match=True, matrix_and_summary_match=True),
        provenance=dict(legacy_revision=LEGACY, final_revision=FINAL, flags=manifest['flags'],
                        compiler=manifest['compiler'], binaries=manifest['binaries'],
                        manifest_sha256=sha(build / 'manifest.json'), run_sha256=sha(measurement / 'run.json'),
                        samples_sha256=sha(measurement / 'samples.jsonl'), summary_sha256=sha(measurement / 'summary.json'),
                        active_runner_sha256=run['active_runner_sha256'], analysis_sha256=sha(__file__)),
        runtime_host_observation=host, aggregates=aggregate_rows,
        layout_sensitivity=sensitivity(aggregate_rows), cases=cases,
        uncertainty=dict(method='Exact 2.5%/97.5% quantiles of the empirical paired-bootstrap median ratio, n=11.',
                         unit='A paired legacy/final solve of the same exact field, in one fixed reader/allocation/link-layout stratum.',
                         scope='Conditional repeated-solve variation, assuming exchangeable pairs; no correction for serial host drift.',
                         eligibility='Only predefined active square full-cap fields >=128², and only if runtime host bounds passed.',
                         aggregate_intervals='Not reported: no invented global rounds or pooling across different work/code-layout units.'),
        limits=['No whole-game inference or comparison of new-terrain semantics to the legacy engine.',
                'Queues are private and their allocation addresses are unmatched.',
                'Shared mode matches input/output addresses; separate mode does not.',
                'Reader memory footprints are not total map memory or measured bandwidth.',
                'Propagation timings exclude caller copies and snapshot construction.',
                'Cold means workspace-cold, not CPU-cache cold.',
                'No performance acceptance can be inferred from oracle correctness alone.'],
    )
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / 'analysis.json').write_text(json.dumps(report, indent=2) + '\n')
    (args.output / 'REPORT.md').write_text(markdown(report))
    print(json.dumps(dict(status=report['status'], raw_rows=count, combinations=len(cases), output=str(args.output))))


if __name__ == '__main__':
    main()
