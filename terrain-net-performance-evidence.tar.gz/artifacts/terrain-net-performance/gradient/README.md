# Equivalent-work classic gradient comparison

This artifact isolates classic full-field gradient CPU work from game trajectories.
It compares actual archived source from:

- Pre-terrain engine: `934c3c588bea51ec7421152e15f5168b2aaf5502`.
- Final terrain/gradient implementation: `37d609766374e7efc1679d643c7d18cde84364ab`.

It does not compare road/ice or other new movement behavior against the old engine;
there is no equivalent old-engine workload for those semantics.

## What is actually compiled

`run.py` archives each revision's headers without modifying them. Two separate
translation units include the historical `GradientPropagation.h` and the final
`TerrainGradient.h`. Wrapper macros give internal namespaces and workspace types
different identities, preventing ODR/linker coalescing between versions. Both
compile with `-O3 -fPIC -std=c++20 -fno-lto`, with benchmark counters disabled.
`NDEBUG` is not defined: assertions stay enabled, matching the original engine's
production assertion mode. `assertion-mode.json` and the per-variant macro dumps
verify the active `assert` macro for both compiled source contexts. Earlier
`gradient-build`/`gradient-readers-build` artifacts define `NDEBUG`; retain them
only as explicitly different assertion-mode controls, not production measurements.
No SDL, game binary or current checkout headers are involved in the main harness.

The legacy wrapper calls archived `propagateField`; the final wrapper calls
archived `propagateTerrainField` with the stable terrain ID lookup and runtime
`modifiedCosts=false`. Reader dispatch occurs once outside propagation, producing
separate callback instantiations. There is no runtime per-cell reader switch.

Three reader modes distinguish a kernel control from production storage:

| Reader | Legacy callback | Final callback |
| --- | --- | --- |
| `packed16-control` | Packed 16-bit sprite, range water test (`>=256 && <272`). This is a control, not production eager storage. | Packed 16-bit terrain identity. |
| `eager` | The terrain member at its actual 36-byte `Tile` stride and offset 0, then the historical range test. | Packed 16-bit terrain identity. |
| `snapshot` | Packed 8-bit water flag, as used by legacy queued/lazy searches. | Packed 16-bit terrain identity, as used by final queued/lazy searches. |

`prepare_layout.py` compiled the archived `Map.h` and `Ressource.h` definitions
using the frozen baseline build's include environment. The resulting native layout
is `sizeof(Tile)=36`, `alignof(Tile)=4`, `offsetof(Tile,terrain)=0`, with a 2-byte
terrain member and 4-byte resource. Probe command, source/binary hashes and results
are retained in `../gradient-layout/layout.json`; both original definitions were
verified against Git before compiling. The main harness imports these measured
constants. Tile reads use constant-offset `memcpy`, allowing a native unaligned
16-bit load without inventing or type-punning a `Tile` object.

The manifest proves that `GradientPropagation.h`, `GradientRelaxation.h`,
`GradientWorkspace.h` and `Grid.h` are byte-identical between these revisions.
`GradientCosts.h` replaces the literal 30 with an equal named constant, while
`GradientBucket.h` changes its constant expression. Compile-time assertions in
both variants verify all seven water costs, 10/14 land costs, the propagation cap
and 64 queue buckets. Wrapper workspace size is asserted
as 2,072 bytes on this native x86-64 build. All archived sources, wrapper sources,
commands, compiler information and linked binaries are hashed in the manifest.

Two binaries reverse the legacy/final object link order to expose code placement
sensitivity. They use the same driver object. Do not collapse layout disagreements
into a precision claim about a small speed difference.

## Work and timing protocol

The full matrix has 756 cases before reader, allocation and link-order repetitions:

- 32², 128², 256² and 512² fields.
- 1×31, 2×17, 17×31, 32×128 and 128×256 toroidal fixtures.
- All seven swimming classes.
- Single, sparse, dense, deferred, obstacle-separated and entirely blocked seeds.
- A cap of 127 and the historical full cap of 65,491.

A fixed `mt19937(72941)` fixture creates the same classic grass/sand/water world and
encoded field for both solvers. Deferred seeds include costs near bucket boundaries
and beyond the propagation cap. An independent heap Dijkstra uses explicit modulo
wrapping and explicit historical cardinal/diagonal costs. Every complete result
must equal its entire oracle vector, including supplied seeds beyond the cap;
hashes alone are not used as the correctness check.

Repetition -1 is the first **workspace-cold** solve for each private workspace;
it does not establish cold CPU caches. The following eleven (or more) repetitions
alternate which implementation runs first. Both are in one
process. CPU and elapsed time include the complete propagation call, including
seed initialization inside the kernel and any queue allocation. Copying caller
seeds and terrain into the selected buffers is separately reported as
`initialization_ns`. Oracle calculation, full vector comparisons, hashes and JSON
serialization are outside the timed region.

With `layout=shared`, both implementations use exactly the same input terrain and
output field addresses. Raw terrain storage is aligned to 64 bytes and sized to
hold the larger representation; the appropriate representation is copied before
timing. With `layout=separate`, each input allocation is sized to its own actual
representation. Both modes perform the same copies before timing, and record
addresses, allocation bytes, reader stride and reader footprint. These fields are
storage footprints, not measured memory-traffic counters or total `Map` memory.

For a 512² field, legacy eager readers span 9 MiB of Tile storage versus 512 KiB
for the final terrain plane. Legacy snapshots occupy 256 KiB versus 512 KiB for
final snapshots. Final maps still hold other Tile data; this is an access-layout
comparison, not a claim that total map memory decreased.

Snapshot byte-plane creation is timed separately once per process/case: legacy
extracts water flags from the Tile-strided source; final copies the terrain plane.
The source footprint and `snapshot_preparation_ns` are reported. This illustrative
one-shot includes plane allocation/conversion, but excludes shared-pointer control
blocks and locking. It is outside propagation timings and is repeated as metadata
on every row, so it must not be summed as per-query work. Non-snapshot modes have
no snapshot construction and report zero. Actual snapshot amortization depends on
the owning map/search lifetime; this full-field harness does not model it.

**Queues remain private per implementation.** This preserves the actual archived
workspace types without unsafe type-punning. Queue buffers are not address-matched;
workspace and first occupied queue addresses plus retained bytes are recorded.
This is a limitation of the experiment, not a shared-queue claim. Both link orders
and allocation layouts should be considered when interpreting differences.

Thin and entirely blocked fixtures are chiefly correctness controls and can be
timer-overhead dominated. Report them separately from representative map-size
performance. Field medians are not a prediction of a whole-game speedup.

## Commands

Reproduce the layout probe (already performed; requires the frozen baseline
checkout and its compile database/dependencies):

```sh
taskset -c 0-3 python3 artifacts/terrain-net-performance/gradient/prepare_layout.py \
  --output artifacts/terrain-net-performance/gradient-layout
```

Build frozen objects/binaries only (already performed):

```sh
taskset -c 0-3 python3 artifacts/terrain-net-performance/gradient/run.py \
  --output artifacts/terrain-net-performance/gradient-production-build --build-only
```

Production assertion-mode smoke test (42 cases × 3 reader modes × 2 allocation
layouts × 2 link orders, 11 alternating warm pairs plus workspace-cold solves):

```sh
taskset -c 0 python3 artifacts/terrain-net-performance/gradient/run.py \
  --output artifacts/terrain-net-performance/gradient-production-build --run-only \
  --suite smoke --name smoke --cpu 0
```

Full measurement **has not been started**; coordinate host load first:

```sh
taskset -c 0 python3 artifacts/terrain-net-performance/gradient/run.py \
  --output artifacts/terrain-net-performance/gradient-production-build --run-only \
  --suite full --name final-measurements --cpu 0 --repeats 11
```

The default runs all three readers and both link orders. Use `--reader eager`,
`--reader snapshot` or `--reader packed16-control` to isolate a reader. Use
`--link-order legacy-first` or `final-first` to select one link order. Reusing an existing measurement directory is rejected. Results are
raw `samples.jsonl`, a case matrix plus frozen manifest and active runner hashes
in `run.json`, and per-case medians/paired ratios/commands in `summary.json`. Per-case host load is
recorded; CPU affinity does not imply an exclusive machine. No host security
settings or hardware performance counter configuration are changed.
