#!/usr/bin/env python3
"""Analysis contracts only; never launches benchmark binaries."""
import statistics
import unittest
from analyze import (CASE_KEYS, active_large, analyze_combinations, expected_cases,
                     paired_interval, partition, sensitivity)


class AnalysisTest(unittest.TestCase):
    def fixture(self):
        case = (128, 128, 1, 'sparse', 65491)
        key = (*case, 'eager', 'shared', 'legacy-first')
        rows = {}
        for repetition in range(-1, 11):
            for variant, multiplier in [('legacy', 2), ('final', 1)]:
                rows[repetition, variant] = dict(cpu_ns=(10 + repetition) * multiplier,
                                                reader_bytes=32768, queue_retained_bytes=4096)
        summary = dict(case=dict(zip(CASE_KEYS, case)), reader='eager', layout='shared',
                       link_order='legacy-first', legacy_cpu_ns=30, final_cpu_ns=15,
                       ratio=.5, median_pair_ratio=.5, pair_ratios=[.5] * 11)
        return {key: rows}, [summary]

    def test_complete_fixed_case_inventory_and_disjoint_partitions(self):
        cases = expected_cases()
        self.assertEqual(len(cases), 756)
        self.assertEqual(sum(active_large(case) for case in cases), 84)
        counts = {name: sum(partition(case) == name for case in cases)
                  for name in {partition(case) for case in cases}}
        self.assertEqual(sum(counts.values()), 756)
        self.assertEqual(counts['capped_controls'], 378)
        self.assertEqual(counts['all_blocked_full_field'], 63)
        self.assertEqual(counts['obstacle_separated_full_field'], 63)

    def test_host_rejection_suppresses_intervals_without_discarding_pairs(self):
        indexed, summary = self.fixture()
        result = analyze_combinations(indexed, summary, False)[0]
        self.assertEqual(result['paired_ratios'], [.5] * 11)
        self.assertIsNone(result['paired_median_empirical_bootstrap_95_interval'])
        self.assertIn('host bounds failed', result['interval_status'])
        accepted = analyze_combinations(indexed, summary, True)[0]
        self.assertEqual(accepted['paired_median_empirical_bootstrap_95_interval'], [.5, .5])

    def test_summary_ratio_drift_and_duplicate_entries_are_rejected(self):
        indexed, summary = self.fixture()
        with self.assertRaisesRegex(ValueError, 'Duplicate'):
            analyze_combinations(indexed, summary + summary, True)
        summary[0]['pair_ratios'][4] = .75
        with self.assertRaisesRegex(ValueError, 'raw paired'):
            analyze_combinations(indexed, summary, True)

    def test_intervals_stay_paired_and_do_not_accept_wrong_pair_counts(self):
        values = [1 / value for value in range(1, 12)]
        lower, upper = paired_interval(values)
        self.assertLess(lower, statistics.median(values))
        self.assertGreater(upper, statistics.median(values))
        self.assertEqual(paired_interval(list(reversed(values))), [lower, upper])
        with self.assertRaises(ValueError):
            paired_interval(values[:-1])

    def test_layout_sign_reversal_is_exposed_instead_of_pooled(self):
        rows = [dict(reader='eager', group='active_full_field_large', layout=layout,
                     link_order=order, cost_weighted_ratio=ratio)
                for (layout, order), ratio in zip(
                    [('shared', 'legacy-first'), ('shared', 'final-first'),
                     ('separate', 'legacy-first'), ('separate', 'final-first')],
                    [.97, 1.01, .96, .99])]
        result = sensitivity(rows)[0]
        self.assertTrue(result['crosses_no_change'])
        self.assertAlmostEqual(result['spread_percentage_points'], 5)
        self.assertEqual(len(result['stratified_ratios']), 4)
        with self.assertRaises(ValueError):
            sensitivity(rows[:-1])


if __name__ == '__main__':
    unittest.main()
