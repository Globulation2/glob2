#!/usr/bin/env python3
"""Draft paired process-window/scoped CPU analysis; does not launch workloads."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics

T9 = 2.2621571627409915
EXPECTED = set(range(10))
COMBINED = 'native_policy_and_controller'
COMPARISONS = {
    'production_candidate_over_master': ('production-master', 'production-candidate'),
    'diagnostic_off_candidate_over_master': ('master-off', 'candidate-off'),
    'diagnostic_on_candidate_over_master': ('master-on', 'candidate-on'),
    'master_observer_on_over_off_same_binary': ('master-off', 'master-on'),
    'candidate_observer_on_over_off_same_binary': ('candidate-off', 'candidate-on'),
    'master_diagnostic_off_over_original_production': ('production-master', 'master-off'),
    'candidate_diagnostic_off_over_original_production': ('production-candidate', 'candidate-off'),
}
CAVEATS = [
    'Draft diagnostic analysis, not performance acceptance; these scenarios are fixed tick windows, not ten full matches.',
    'CLOCK_PROCESS_CPUTIME_ID benchmark_run_cpu_ns is the comparable process-window CPU metric across all modes. Whole-process wait4 CPU and run elapsed time are reported separately.',
    'Scope exclusive CPU includes clock/probe overhead. Scope boundaries/nesting and binary layout differ from production; measured scoped CPU is not an exact allocation of production CPU. On/off same-binary ratios estimate observer cost, while diagnostic-off/original-production ratios estimate diagnostic build/layout effects; neither makes a universal subtraction correction.',
    'native_policy and controller_other are combined because first-pass native scope nesting was inconsistent. The combined total retains all CPU once; it does not restore other missing/wrong scope boundaries.',
    'Main thread is identified independently in each run by nonzero owner_step_other calls, never by slot number. Other slots are workers, not inferred individual AI/gradient roles. Only scoped CPU can be grouped; process-envelope residual cannot be assigned to threads.',
    'Accounting residual is process-envelope CPU minus all exclusive scoped CPU; it includes uninstrumented work, probe boundaries, thread startup/shutdown and clock mismatch. It is not necessarily idle/wait CPU. Main/worker scoped totals exclude that residual.',
    'Intervals are paired Student t on ten repeat IDs 0..9, df=9: logs for geometric CPU ratios, arithmetic differences for scoped CPU deltas. Warmup repeat -1 is excluded. Incomplete groups get no ten-pair interval. Thermal drift/order effects, correlated runs and multiple category comparisons remain limitations.',
    'Final checksum agreement is evidence for these fixed windows only; it does not prove gameplay equivalence beyond them or cross-platform determinism.',
]


def stats(values, log=False):
    n = len(values)
    if not n:
        return {'pairs': 0, 'complete_ten_pairs': False}
    x = [math.log(v) for v in values] if log else values
    mean = statistics.mean(x)
    complete = n == 10
    half = T9 * statistics.stdev(x) / math.sqrt(n) if complete else None
    transform = math.exp if log else lambda v: v
    return {'pairs': n, 'complete_ten_pairs': complete,
            'geometric_mean_ratio' if log else 'mean_delta': transform(mean),
            'paired_t95_df9': [transform(mean-half), transform(mean+half)] if complete else None,
            'pair_values': values}


def scope_data(row):
    attr = row.get('attribution')
    if not attr:
        return None
    mains = [t['slot'] for t in attr['threads'] if t['scopes'].get('owner_step_other', {}).get('calls', 0) > 0]
    if len(mains) != 1:
        raise ValueError('expected exactly one OwnerStep thread: ' + str(mains))
    groups = {g: {'cpu_ns': Counter(), 'calls': Counter()} for g in ('all', 'main', 'workers')}
    for thread in attr['threads']:
        kind = 'main' if thread['slot'] == mains[0] else 'workers'
        for name, measurement in thread['scopes'].items():
            name = COMBINED if name in ('native_policy', 'controller_other') else name
            cpu, calls = measurement['exclusive_cpu_ns'], measurement['calls']
            if cpu < 0 or calls < 0:
                raise ValueError('negative scope measurement')
            for g in ('all', kind):
                groups[g]['cpu_ns'][name] += cpu
                groups[g]['calls'][name] += calls
    total = sum(groups['all']['cpu_ns'].values())
    return {'main_slot': mains[0], 'groups': groups, 'envelope_cpu_ns': attr['process_window_cpu_ns'],
            'scope_cpu_ns': total, 'scope_calls': sum(groups['all']['calls'].values()),
            'residual_cpu_ns': attr['process_window_cpu_ns']-total,
            'envelope_minus_benchmark_run_cpu_ns': attr['process_window_cpu_ns']-row['result']['benchmark_run_cpu_ns'],
            'windows': attr['windows']}


def matching_work(a, b):
    keys = ('ticks', 'benchmark_measured_ticks', 'initialChecksum', 'game_seed', 'termination')
    return all(a['result'].get(k) == b['result'].get(k) for k in keys) and \
        a['result'].get('finalChecksum') == b['result'].get('finalChecksum')


def analyze(path):
    raw = path.read_bytes() # immutable prefix while sweep keeps appending
    lines = raw.splitlines(keepends=True)
    rows = []
    tail = False
    for i, line in enumerate(lines):
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            if i == len(lines)-1 and not line.endswith(b'\n'):
                tail = True
            else:
                raise
    indexed = defaultdict(dict)
    checksums = defaultdict(lambda: defaultdict(set))
    duplicates = []
    for r in rows:
        checksums[r['scenario']][r['variant']].add(r['result'].get('finalChecksum'))
        if r['repeat'] < 0:
            continue
        key = (r['scenario'], r['variant'])
        if r['repeat'] in indexed[key]:
            duplicates.append([*key, r['repeat']])
        indexed[key][r['repeat']] = r
    if duplicates:
        raise ValueError('duplicate measured repeat IDs: ' + str(duplicates))
    scenarios = {}
    for scenario in sorted({r['scenario'] for r in rows}):
        variants = {}
        for s, variant in sorted(indexed):
            if s != scenario:
                continue
            rr = [indexed[(s, variant)][i] for i in sorted(EXPECTED & indexed[(s, variant)].keys())]
            sd = [scope_data(r) for r in rr if r.get('attribution')]
            item = {'repeat_ids': [r['repeat'] for r in rr], 'missing_repeat_ids': sorted(EXPECTED-indexed[(s, variant)].keys()),
                    'run_window_cpu_s': [r['result']['benchmark_run_cpu_ns']/1e9 for r in rr],
                    'whole_process_cpu_s': [r['cpu_s'] for r in rr],
                    'run_elapsed_s': [r['result']['run_ns']/1e9 for r in rr],
                    'whole_process_elapsed_s': [r['wall_s'] for r in rr]}
            if sd:
                item['accounting'] = [{k:v for k,v in d.items() if k != 'groups'} for d in sd]
                item['scope_cpu_s_mean'] = {g: {k: statistics.mean(d['groups'][g]['cpu_ns'].get(k,0)/1e9 for d in sd)
                    for k in sorted(set().union(*(d['groups'][g]['cpu_ns'].keys() for d in sd)))} for g in ('all','main','workers')}
                item['scope_calls_mean'] = {g: {k: statistics.mean(d['groups'][g]['calls'].get(k,0) for d in sd)
                    for k in sorted(set().union(*(d['groups'][g]['calls'].keys() for d in sd)))} for g in ('all','main','workers')}
                item['grouped_scoped_cpu_s_mean'] = {g:statistics.mean(sum(d['groups'][g]['cpu_ns'].values())/1e9 for d in sd) for g in ('all','main','workers')}
                item['mean_residual_cpu_s'] = statistics.mean(d['residual_cpu_ns']/1e9 for d in sd)
                item['sum_residual_cpu_ns'] = sum(d['residual_cpu_ns'] for d in sd)
                item['sum_envelope_cpu_ns'] = sum(d['envelope_cpu_ns'] for d in sd)
                item['sum_scope_cpu_ns'] = sum(d['scope_cpu_ns'] for d in sd)
                item['sum_scope_calls'] = sum(d['scope_calls'] for d in sd)
            variants[variant] = item
        comparisons = {}
        for label,(base,candidate) in COMPARISONS.items():
            aa, bb = indexed[(scenario,base)], indexed[(scenario,candidate)]
            ids = sorted(EXPECTED & aa.keys() & bb.keys())
            invalid = [i for i in ids if not matching_work(aa[i],bb[i]) or any(r['result'].get('status') != 'completed' for r in (aa[i],bb[i]))]
            valid = [i for i in ids if i not in invalid]
            item = {'denominator': base, 'numerator': candidate, 'repeat_ids': valid, 'invalid_work_repeat_ids': invalid,
                'missing_pair_repeat_ids': sorted(EXPECTED-set(ids)),
                'process_window_cpu_ratio': stats([bb[i]['result']['benchmark_run_cpu_ns']/aa[i]['result']['benchmark_run_cpu_ns'] for i in valid],True),
                'whole_process_cpu_ratio': stats([bb[i]['cpu_s']/aa[i]['cpu_s'] for i in valid],True),
                'run_elapsed_ratio': stats([bb[i]['result']['run_ns']/aa[i]['result']['run_ns'] for i in valid],True)}
            if label == 'diagnostic_on_candidate_over_master' and valid:
                pairdata = [(scope_data(aa[i]),scope_data(bb[i])) for i in valid]
                if not all(a and b for a,b in pairdata):
                    raise ValueError('diagnostic-on attribution missing')
                item['category_exclusive_cpu_delta_s'] = {}
                item['grouped_scoped_cpu_delta_s'] = {}
                for g in ('all','main','workers'):
                    names = sorted(set().union(*(d['groups'][g]['cpu_ns'].keys() for pair in pairdata for d in pair)))
                    item['category_exclusive_cpu_delta_s'][g] = {name:stats([(b['groups'][g]['cpu_ns'].get(name,0)-a['groups'][g]['cpu_ns'].get(name,0))/1e9 for a,b in pairdata]) for name in names}
                    item['grouped_scoped_cpu_delta_s'][g] = stats([(sum(b['groups'][g]['cpu_ns'].values())-sum(a['groups'][g]['cpu_ns'].values()))/1e9 for a,b in pairdata])
                item['accounting_residual_delta_s'] = stats([(b['residual_cpu_ns']-a['residual_cpu_ns'])/1e9 for a,b in pairdata])
            comparisons[label] = item
        checksum = {v:sorted(values,key=lambda x:str(x)) for v,values in checksums[scenario].items()}
        scenarios[scenario] = {'variants': variants, 'comparisons': comparisons,
            'final_checksum_by_variant_including_warmups': checksum,
            'all_modes_and_revisions_same_final_checksum':len(set().union(*checksums[scenario].values()))==1}
    metadata = path.parent/'measurement-metadata.json'
    return {'status':'draft','input':str(path.resolve()),'input_prefix_sha256':hashlib.sha256(raw).hexdigest(),
            'input_bytes':len(raw),'complete_json_rows':len(rows),'ignored_incomplete_tail':tail,
            'required_repeat_ids':sorted(EXPECTED),'interval_t_df9':T9,
            'provenance':json.loads(metadata.read_text()) if metadata.exists() else None,
            'scenarios':scenarios,'caveats':CAVEATS}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('measurements',type=Path)
    ap.add_argument('--output',required=True,type=Path)
    args=ap.parse_args()
    result=analyze(args.measurements)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'draft','rows':result['complete_json_rows'],'output':str(args.output),'scenarios':list(result['scenarios'])}))

if __name__=='__main__':main()
