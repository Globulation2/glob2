#include "Attribution.h"
#include <chrono>
int main(){constexpr unsigned n=1000000;auto t=CPUAttribution::now();for(unsigned i=0;i<n;++i)(void)CPUAttribution::now();auto cost=CPUAttribution::now()-t;std::printf("thread clock mean ns: %.3f\n",double(cost)/n);CPUAttribution::begin();t=CPUAttribution::now();for(unsigned i=0;i<n;++i){CPUAttribution::Scope s(CPUAttribution::Kind::Controller);}cost=CPUAttribution::now()-t;CPUAttribution::end();std::printf("scope loop mean ns: %.3f\n",double(cost)/n);}
