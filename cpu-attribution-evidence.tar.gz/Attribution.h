#pragma once
#include <array>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstdint>
#include <stdexcept>
#include <unistd.h>
namespace CPUAttribution {
enum class Kind : unsigned { OwnerStep, Simulation, CaptureOther, CaptureMap, CaptureEntities, CapturePreparation, CaptureResourceFields, SnapshotMetrics, LeaseAcquire, LeaseRetire, Scheduler, WorkerDispatch, AIWrapper, Controller, Facade, Receipt, NativeObserve, NativePolicy, JSHistory, JSServices, JSRuntime, JSPrepare, JSScript, JSResult, HostQuery, Gradient, Count };
inline constexpr const char* names[]={"owner_step_other","simulation_other","capture_other","capture_map_arrays","capture_entities_and_teams","capture_preparation","capture_resource_fields","snapshot_memory_metrics","lease_acquire","lease_retire","scheduler_and_publication","worker_dispatch","ai_wrapper","controller_other","facade","receipts_and_intent","native_observation","native_policy","js_history","js_services","js_runtime_other","js_runtime_prepare","js_script_call","js_result_serialization","js_host_query","gradient"};
inline bool enabled(){static const bool value=std::getenv("GLOB2_CPU_ATTRIBUTION")!=nullptr;return value;}
inline std::uint64_t now(){timespec t{};if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t))std::abort();return std::uint64_t(t.tv_sec)*1000000000ull+t.tv_nsec;}
inline std::uint64_t processNow(){timespec t{};if(clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t))std::abort();return std::uint64_t(t.tv_sec)*1000000000ull+t.tv_nsec;}
struct Counters {std::array<std::uint64_t,unsigned(Kind::Count)> cpu{},calls{};};
struct Registry {
 std::array<Counters,128> threads{};std::atomic<unsigned> next{0};std::atomic<bool> recording{false};std::uint64_t processStart=0,processEnd=0;unsigned windows=0;
 ~Registry(){if(!enabled()||!windows)return;std::fprintf(stderr,"CPU_ATTRIBUTION {\"process_window_cpu_ns\":%llu,\"windows\":%u,\"threads\":[",(unsigned long long)(processEnd-processStart),windows);for(unsigned i=0;i<next;++i){if(i)std::fputc(',',stderr);std::fprintf(stderr,"{\"slot\":%u,\"scopes\":{",i);for(unsigned j=0;j<unsigned(Kind::Count);++j){if(j)std::fputc(',',stderr);std::fprintf(stderr,"\"%s\":{\"exclusive_cpu_ns\":%llu,\"calls\":%llu}",names[j],(unsigned long long)threads[i].cpu[j],(unsigned long long)threads[i].calls[j]);}std::fputs("}}",stderr);}std::fputs("]}\n",stderr);}
};
inline Registry registry;
inline Counters& counter(){thread_local Counters* c=[](){auto i=registry.next.fetch_add(1);if(i>=registry.threads.size())std::abort();return &registry.threads[i];}();return *c;}
struct Scope;inline thread_local Scope* parent=nullptr;
struct Scope {
 Kind kind;bool active;std::uint64_t start=0,children=0;Scope* previous=nullptr;
 explicit Scope(Kind k):kind(k),active(enabled()&&registry.recording.load(std::memory_order_relaxed)&&(!parent||parent->kind!=k)){if(active){(void)counter();previous=parent;parent=this;start=now();}}
 ~Scope(){if(!active)return;const auto elapsed=now()-start;parent=previous;if(previous)previous->children+=elapsed;if(registry.recording.load(std::memory_order_relaxed)){auto& c=counter();c.cpu[unsigned(kind)]+=elapsed>=children?elapsed-children:0;++c.calls[unsigned(kind)];}}
 Scope(const Scope&)=delete;
};
inline void begin(){if(!enabled())return;if(registry.windows++)std::abort();registry.processStart=processNow();registry.recording.store(true);}
inline void end(){if(!enabled())return;registry.recording.store(false);registry.processEnd=processNow();}
}
