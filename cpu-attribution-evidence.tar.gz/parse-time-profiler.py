#!/usr/bin/env python3
"""Resolve xctrace time-profile references and attribute Running sample weights."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

BLOCKING_LEAVES = ('__psynch_cvwait', '__psynch_mutexwait', '__ulock_wait', '__ulock_wait2',
                   'semaphore_wait_trap', 'semaphore_timedwait_trap', 'mach_msg_trap',
                   'mach_msg2_trap', 'kevent', 'kevent64', 'poll', 'select', 'nanosleep',
                   '__semwait_signal', 'pthread_cond_wait', 'pthread_cond_timedwait')
STARTUP_MARKERS = ('GlobalContainer::', 'Engine::initGame', 'Engine::init', 'Engine::prepareRun',
                   'Game::load', 'Map::load', 'Race::load', 'BuildingsTypes::load',
                   'Engine::Engine', 'Game::Game', 'Game::init(',
                   'dyld4::prepare', 'dyld4::APIs::runAllInitializersForMain', 'dlopen')
OUTPUT_MARKERS = ('Engine::finishSession', 'Engine::teardownSession', 'Headless::writeJson',
                  'Headless::playersAndTeamsJson', 'Engine::saveInitialGameState',
                  'HeadlessRunner::manifest', 'ReplayWriter::finish')
ENGINE_MARKERS = ('Engine::stepSession', 'Engine::advanceSession', 'Engine::executeOrders',
                  'Engine::gatherAndAdvanceOrders', 'Engine::runOneGameSession', 'Engine::run()',
                  'Game::syncStep', 'Game::step', 'Map::step', 'AIEngine::Executor::work',
                  'AIEngine::Pipeline::', 'AI::decide', 'ComputeExecutor::',
                  'MapGradientPipeline::', 'GradientPipeline::')
CAVEATS = [
    'Weights are statistical Time Profiler Running-sample weights, not exact process CPU accounting or elapsed time.',
    'Inclusive functions overlap; never add inclusive percentages. Each function is counted once per stack even under recursion.',
    'Blocking leaf samples are conservatively excluded even if tagged Running. Their weights describe sampled boundaries, not measured wait duration; a little syscall transition CPU may also be excluded.',
    'Startup/engine/output classification uses visible stack markers. Inlining, truncated/unresolved stacks and prologue/epilogue work can cause unknown attribution; no simulation tick or exact phase boundary is inferred.',
    'A single short sampled probe is noisy and adjacent samples/threads are correlated. Sample counts and one-sample resolution are provided; they are not confidence intervals or paired regression evidence.',
]


class Resolver:
    def __init__(self, tree):
        self.ids = {}
        for node in tree.iter():
            identity = node.get('id')
            if identity:
                if identity in self.ids:
                    raise ValueError('duplicate XML id: ' + identity)
                self.ids[identity] = node
        self.refs = 0

    def resolve(self, node):
        if node is None:
            raise ValueError('missing column or referenced node')
        seen = set()
        while node.get('ref'):
            ref = node.get('ref')
            if ref in seen or ref not in self.ids:
                raise ValueError('cyclic or unresolved ref: ' + ref)
            seen.add(ref); self.refs += 1
            node = self.ids[ref]
        return node

    def scalar(self, node):
        return (self.resolve(node).text or '').strip()

    def frame(self, node):
        node = self.resolve(node)
        binary = self.resolve(node.find('binary')) if node.find('binary') is not None else None
        return (binary.get('name', 'unknown') if binary is not None else 'unknown',
                node.get('name', node.get('addr', 'unknown')),
                binary.get('UUID', '') if binary is not None else '')


def classification(names):
    if any(any(marker in name for marker in OUTPUT_MARKERS) for name in names):
        return 'output_or_teardown'
    if any(any(marker in name for marker in STARTUP_MARKERS) for name in names):
        return 'startup_or_load'
    if any(any(marker in name for marker in ENGINE_MARKERS) for name in names):
        return 'engine'
    return 'unknown_phase'


def blocking(name):
    # Symbol names may have a compiler suffix, but avoid substring matching a
    # caller merely because it mentions a future/wait somewhere in a template.
    return any(name == token or name.startswith(token + '(') or name.startswith(token + '$') for token in BLOCKING_LEAVES)


def top_rows(counter, counts, total, limit):
    return [{'binary': binary, 'binary_uuid': uuid, 'function': function,
             'sampled_weight_ns': weight, 'sampled_weight_ms': weight / 1e6,
             'percent_of_group_weight': weight * 100 / total if total else None,
             'samples': counts[(binary, function, uuid)]}
            for (binary, function, uuid), weight in counter.most_common(limit)]


def analyze(path, top=30, pid=None, start_ns=None, end_ns=None):
    tree = ET.parse(path).getroot(); resolver = Resolver(tree)
    groups = defaultdict(lambda: {'weight_ns': 0, 'samples': 0, 'missing_stack_samples': 0,
                                   'exclusive': Counter(), 'inclusive': Counter(),
                                   'exclusive_counts': Counter(), 'inclusive_counts': Counter()})
    states, state_weights = Counter(), Counter()
    threads = defaultdict(lambda: Counter())
    skipped = Counter(); wait_weights = Counter(); wait_counts = Counter()
    running_weight = 0; running_samples = 0; weights = Counter(); times = []
    for table in tree.findall('node'):
        schema = table.find('schema')
        if schema is None or schema.get('name') != 'time-profile':
            continue
        columns = [col.findtext('mnemonic') for col in schema.findall('col')]
        required = {'time', 'thread', 'process', 'thread-state', 'weight', 'stack'}
        if not required <= set(columns):
            raise ValueError('time-profile schema lacks required columns')
        for row in table.findall('row'):
            if len(row) != len(columns):
                raise ValueError('row length differs from schema')
            cells = dict(zip(columns, row))
            time = int(resolver.scalar(cells['time']))
            if (start_ns is not None and time < start_ns) or (end_ns is not None and time >= end_ns):
                skipped['outside_time_window'] += 1; continue
            process = resolver.resolve(cells['process'])
            process_pid = resolver.scalar(process.find('pid'))
            if pid is not None and process_pid != str(pid):
                skipped['other_pid'] += 1; continue
            state = resolver.scalar(cells['thread-state'])
            weight = int(resolver.scalar(cells['weight']))
            if weight < 0:
                raise ValueError('negative sample weight')
            states[state] += 1; state_weights[state] += weight
            if state != 'Running':
                skipped['non_running'] += 1; continue
            running_weight += weight; running_samples += 1; weights[weight] += 1; times.append(time)
            thread = resolver.resolve(cells['thread']).get('fmt', 'unknown thread')
            thread_key = process_pid + ': ' + thread
            stack = resolver.resolve(cells['stack'])
            frames = [resolver.frame(f) for f in stack.findall('frame')]
            if frames and blocking(frames[0][1]):
                wait_weights[frames[0]] += weight; wait_counts[frames[0]] += 1
                threads[thread_key]['excluded_blocking_leaf_weight_ns'] += weight
                threads[thread_key]['excluded_blocking_leaf_samples'] += 1
                continue
            threads[thread_key]['attributed_running_weight_ns'] += weight
            threads[thread_key]['attributed_running_samples'] += 1
            names = [f[1] for f in frames]
            phase = classification(names) if frames else 'unknown_phase'
            for group_name in ('all_nonblocking_running', phase):
                group = groups[group_name]; group['weight_ns'] += weight; group['samples'] += 1
                if not frames:
                    group['missing_stack_samples'] += 1; continue
                group['exclusive'][frames[0]] += weight; group['exclusive_counts'][frames[0]] += 1
                for frame in set(frames):
                    group['inclusive'][frame] += weight; group['inclusive_counts'][frame] += 1
    result_groups = {}
    for name, g in groups.items():
        result_groups[name] = {'sampled_weight_ns': g['weight_ns'], 'sampled_weight_ms': g['weight_ns'] / 1e6,
            'samples': g['samples'], 'missing_stack_samples': g['missing_stack_samples'],
            'one_equal_weight_sample_resolution_percent': 100 / g['samples'] if g['samples'] else None,
            'top_exclusive': top_rows(g['exclusive'], g['exclusive_counts'], g['weight_ns'], top),
            'top_inclusive': top_rows(g['inclusive'], g['inclusive_counts'], g['weight_ns'], top),
            'top_domain_inclusive': top_rows(
                Counter({frame: weight for frame, weight in g['inclusive'].items()
                         if frame[0] == 'glob2' and frame[1].startswith(('SimulationSnapshot::', 'AIEngine::', 'AI::', 'Cortex::', 'AICortex::', 'Engine::', 'Game::', 'Map::', 'GradientPipeline::', 'AISharedRuntime::', 'Cabino::', 'AINumbi::', 'AIWarrush::', 'AICastor::'))}),
                g['inclusive_counts'], g['weight_ns'], top)}
    return {'source': str(path.resolve()), 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'xml_definitions': len(resolver.ids), 'references_resolved': resolver.refs,
            'selection': {'pid': pid, 'start_ns': start_ns, 'end_ns_exclusive': end_ns},
            'state_samples': dict(states), 'state_weight_ns': dict(state_weights), 'skipped_rows': dict(skipped),
            'running_samples_before_blocking_exclusion': running_samples,
            'running_weight_ns_before_blocking_exclusion': running_weight,
            'excluded_blocking_leaf_samples': sum(wait_counts.values()),
            'excluded_blocking_leaf_weight_ns': sum(wait_weights.values()),
            'excluded_blocking_leaves': top_rows(wait_weights, wait_counts, running_weight, top),
            'sample_weight_distribution_ns': dict(weights),
            'sample_time_min_ns': min(times) if times else None, 'sample_time_max_ns': max(times) if times else None,
            'threads': {name: dict(values) for name, values in threads.items()},
            'phase_markers': {'startup': STARTUP_MARKERS, 'engine': ENGINE_MARKERS, 'output': OUTPUT_MARKERS},
            'groups': result_groups, 'caveats': CAVEATS}


def render(result):
    lines = ['Time Profiler Running-sample attribution',
             f"Source SHA256: {result['source_sha256']}",
             f"Running rows: {result['running_samples_before_blocking_exclusion']}; blocking-leaf rows excluded: {result['excluded_blocking_leaf_samples']}",
             f"Running weight: {result['running_weight_ns_before_blocking_exclusion'] / 1e6:.1f} ms; excluded blocking boundary weight: {result['excluded_blocking_leaf_weight_ns'] / 1e6:.1f} ms"]
    for name in ('startup_or_load', 'engine', 'output_or_teardown', 'unknown_phase', 'all_nonblocking_running'):
        g = result['groups'].get(name)
        if not g:
            continue
        lines += ['', f"{name}: {g['sampled_weight_ms']:.1f} ms / {g['samples']} samples"]
        for kind in ('top_exclusive', 'top_domain_inclusive', 'top_inclusive'):
            lines += [kind + ' (inclusive values overlap):' if kind.endswith('inclusive') else kind + ':']
            for row in g[kind][:15]:
                function = row['function']
                if len(function) > 230:
                    function = function[:227] + '...'
                lines.append(f"  {row['percent_of_group_weight']:6.2f}% {row['sampled_weight_ms']:8.1f} ms {row['samples']:5} samples {row['binary']}: {function}")
    lines += ['', 'Limits:'] + ['- ' + text for text in result['caveats']]
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('xml', type=Path)
    parser.add_argument('--output', type=Path, required=True, help='JSON report path; sibling .txt contains readable tables')
    parser.add_argument('--top', type=int, default=30)
    parser.add_argument('--pid', type=int)
    parser.add_argument('--start-s', type=float)
    parser.add_argument('--end-s', type=float)
    args = parser.parse_args()
    if args.top < 1 or (args.start_s is not None and args.end_s is not None and args.end_s <= args.start_s):
        parser.error('positive top and increasing time window required')
    result = analyze(args.xml, args.top, args.pid,
                     int(args.start_s * 1e9) if args.start_s is not None else None,
                     int(args.end_s * 1e9) if args.end_s is not None else None)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    args.output.with_suffix('.txt').write_text(render(result))
    print(render(result))


if __name__ == '__main__':
    main()
