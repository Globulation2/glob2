import json,hashlib,pathlib,re
p=pathlib.Path(__file__).resolve().parent
read=lambda name:json.loads((p/name).read_text())
write=lambda name,v:(p/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
h=lambda v:hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
changes=read('fourth-applied-changes.json');prior=read('editor-review.json');sources={s:read(f'source/{s}.json') for s in ('native','online')}
reasons={
'[no ressources growth areas]':'Kawasan tanpa pertumbuhan naturally names designated no-growth areas; the old Tiada wording could mean there are no such areas.',
'[Search fields]':'Cari medan is the action to search telemetry fields; medan carian would instead identify search input fields.',
'[stat cleared about]':'The relative clause Sumber yang dibuang describes resources removed/destroyed while clearing, without implying relocation.',
'[ruleset elite ranks description]':'Terlatih sejak awal clearly states the initially trained unit state; tanpa latihan lanjut preserves the subsequent training restriction.',
'[library This release has no passing checks for this engine.]':'Semakan yang lulus is grammatical Malaysian usage for successful validation checks and agrees with the semakan terminology.',
'[lesson swimming title]':'Sumber dalam air locates harvestable resources in water; sumber air would instead mean water sources.',
'[lesson walking-training build hint]':'Natural parallel laluan masuk/laluan keluar preserves entry and exit, and peluasan kemudian expresses later expansion. Litar Larian, materials and builder assignment remain intact.',
'[lesson walking-training build help]':'Concise parallel access-route wording preserves the need for perimeter space and later expansion, with consistent Litar Larian terminology.',
'[music Import a downloaded music ZIP or the three Opus tracks. Metadata and cover art are read from Calm; no extra files are required.]':'Trek Tenang identifies the same localized Calm selector while retaining exact ZIP/Opus workflow and embedded metadata/cover meaning.',
'Fit':'Muatkan pada paparan is a clear zoom-to-fit command; sesuai described suitability and did not express this action.',
'Resolution: {slot0}{slot1}':'In Moderation.tsx this is the report outcome, so Penyelesaian is correct rather than display-resolution Resolusi. Adjacent slots deliberately preserve date suffix formatting.',
'check needs':'In ValidationPanel.tsx the enclosing Malay template already supplies memerlukan perhatian. Count + semakan + memerlukan perhatian forms a grammatical sentence without duplicate verb.',
'checks need':'Malay count nouns need no English-style plural change; semakan composes with the enclosing memerlukan perhatian for any failed count.'}
entries=[];batches=[]
for c in changes:
 key=c['surface']+':'+c['key'];reason=reasons.get(c['key'])
 if reason is None:
  assert c['key'].startswith('[online ')
  reason='Accepted compact Gregorian calendar abbreviation attested by Malay CLDR and independently reproduced by Intl.DateTimeFormat(ms-MY). Consistent with the abbreviated English date labels and browser short-date convention.'
 en=sources[c['surface']][c['key']]
 assert sorted(re.findall(r'\{[^{}]+\}|%\d+',en))==sorted(re.findall(r'\{[^{}]+\}|%\d+',c['value']))
 entries.append(dict(c,id=key,source=en,decision='accepted',reason=reason,value_sha256=hashlib.sha256(c['value'].encode()).hexdigest()))
for b in prior['batches']:
 d=read('edited-batches/'+b['id']+'.json');cs=[c for c in changes if c['surface']+':'+c['key'] in d['values']]
 if not cs:continue
 assert h(d['values'])==d['target_sha256'];old=dict(d['values'])
 for c in cs:
  key=c['surface']+':'+c['key'];assert old[key]==c['value'];old[key]=c['old']
 reconstructed=h(old);assert reconstructed==b['proposed_sha256']
 batches.append({'id':b['id'],'source_sha256':d['source_sha256'],'previous_editor_proposed_sha256':b['proposed_sha256'],'reconstructed_previous_sha256':reconstructed,'renewed_target_sha256':d['target_sha256'],'changed_keys':[c['surface']+':'+c['key'] for c in cs],'carryforward_proof':'Restored the exact supplied old values in the current immutable edited-batch mapping and hashed canonical JSON (ensure_ascii=False, sort_keys=True, default separators). Reconstructed hash equals the prior independently read editor proposed_sha256; therefore every unmodified value is identical. New hash computed from all current values matches snapshot target_sha256.','unchanged_keys_carried_forward':len(old)-len(cs),'proof_passed':True})
assert len(entries)==21 and len(batches)==12
exceptions=read('editor-accepted-english.json');key='native:[online jul]';assert not any(e['key']==key for e in exceptions)
exceptions.append({'key':key,'value':'Jul','reason':'Jul is the standard Malay abbreviated Gregorian month name in Unicode CLDR, independently verified against the gregorian/format/abbreviated month7 entry and Intl.DateTimeFormat(ms-MY,{month:short,timeZone:UTC}). The English-identical spelling is legitimate in this compact date label; ordinary full-name Malay is Julai.','editor':'malay_editor','decision':'accepted after independent focused editorial recheck','source_url':'https://raw.githubusercontent.com/unicode-org/cldr/main/common/main/ms.xml'})
write('editor-accepted-english.json',exceptions)
write('editor-fourth-recheck.json',{'editor':'malay_editor','certification':'Agent-reviewed; not native-human-certified','source_sha256':prior['source_sha256'],'scope':'Focused rereading of all21 fourth-pass changes against frozen English source, exact current edited-batch snapshots and relevant UI call sites. Previously read unchanged entries carried forward only through explicit reconstruction proof.','entries':entries,'renewed_batches':batches,'english_exception':{'key':key,'value':'Jul','decision':'accepted','accepted_english_count':len(exceptions),'source_url':'https://raw.githubusercontent.com/unicode-org/cldr/main/common/main/ms.xml','consulted_passage':'Gregorian monthContext=format monthWidth=abbreviated: July Jul and August Ogo. Weekdays abbreviated: Ahd, Isn, Sel, Rab, Kha, Jum, Sab.','runtime_confirmation':{'command':'Intl.DateTimeFormat(ms-MY, {month:short/weekday:short,timeZone:UTC})','July':'Jul','August':'Ogo','weekdays':['Ahd','Isn','Sel','Rab','Kha','Jum','Sab']}},'integration_review':{'files':['platform/apps/web/src/music/Library.tsx','platform/apps/web/src/components/studio/Studio.tsx'],'decision':'accepted','reason':'Music uploads use canonical calm/building/combat/cover identifiers for endpoint paths and uploaded state while translating visible labels and inspection moods. CreditPanel translates domain labels in heading and aria label; plural selection receives available balance rather than the domain string. No new source keys introduced.','validation_scope':'Independent source inspection only; parent reports 16 music and22 studio regression checks passed.'},'findings':[],'further_edits':[],'token_errors':[],'unresolved_uncertainty':[],'status':'All21 amendments accepted; all12 reconstruction proofs passed; Jul exception added to editor-accepted-english.json.'})
print('Accepted21 changes; renewed12 batch hashes;187 accepted English exceptions;0 findings')
