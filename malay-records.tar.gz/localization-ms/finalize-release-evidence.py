"""Bind selected release coverage to actual final source and immutable evidence."""
import argparse, hashlib, json, os, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
R=Path.cwd();K=R/'artifacts/localization-ms-final-191';V=R/'artifacts/localization-ms/validation'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='e18cb7223f2784ff0c952260b26b01fc89af34c2'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
record=json.loads((K/'reviews/ms.json').read_text());source=record['source_sha256'];catalog=record['catalog_sha256']
for key,path in [('native',R/'data/texts.ms.txt'),('online',R/'platform/packages/i18n/locales/ms.json')]:assert hashlib.sha256(path.read_bytes()).hexdigest()==catalog[key]
def evidence(name):
 path=V/name
 assert path.is_file(),path
 return {'path':os.path.relpath(path,K),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
common=['final-layout-source-scope.json','native-final-layout-scope-proof.json','../master191-supplement/final-render-source-bridge.json','../master191-supplement/online-component-carryforward.json','../master191-supplement/font-policy-carryforward.json']
visual=['font-coverage-master191.json','native191-menu-font-visual-review.json','native191-tutorial-visual-review.json','native191-root-selected-visual-review.json','native-final-layout-statistics-visual-review.json','native-final-layout-root-visual-review.json','web-final-review.json']
refs={
 'desktop_rendering':common+visual+['native-final-layout-validation-result.json'],
 'phone_rendering':common+visual+['gallery191-gesture-control-assessment.json','gallery-final-layout-run-results.json'],
 'browser_startup':['browser-master191-runtime-summary.json','browser-master191-package.json','browser-master191-refresh-result.json','browser-master191-root-visual-review.json'],
 'native_platforms':common+['native-final-layout-validation-result.json','final191-native-validation-result.json','package-source-selection-master191.json'],
 'browser_platforms':['browser-master191-runtime-summary.json','browser-master191-package.json','browser-unit-master191-final.log','known-baseline-browser-failures-master191.json','browser-master191-renderer-source-proof.json','browser-master191-root-visual-review.json'],
 'mobile_platforms':common+['package-source-selection-master191.json','native-final-layout-statistics-visual-review.json','browser-master191-runtime-summary.json','browser-master191-root-visual-review.json'],
}
scopes={
 'desktop_rendering':'Actual Linux game menus/tutorials and final live statistics; production online desktop renders. Full6342+supplement16 font matrices have exact unchanged-input proofs, not relabelled producers.',
 'phone_rendering':'Actual compact Linux menus/tutorials/final statistics at100/150%; production online phone renders. Shared late game-gallery construction assertion retained, no complete phone-gallery claim.',
 'browser_startup':'Final release serial/threaded package with actual translated game startup, persisted Settings and catalog verification, using explicit final producer receipts.',
 'native_platforms':'Selected release coverage: Linux actual runtime/build/compatibility; Linux/Android/iOS source package selections. Windows/macOS/Android/iOS runtime execution is unverified locally. Passed means this stated selected coverage, not all supported OS execution.',
 'browser_platforms':'Selected final release serial/threaded execution across Chromium, Firefox and WebKit with independently compared canonical traces; online production component proof. Three known stale-fixture unit failures remain recorded, not counted as passes.',
 'mobile_platforms':'Selected release coverage: actual compact Linux UI, browser phone emulation and Android/iOS catalog/font source selection. No actual Android/iOS device installation/runtime claim. Passed means this stated selected coverage only.',
}
# The root must inspect authoritative browser outcomes before executing this binder.
for gate,names in refs.items():
 record['gates'][gate]={'passed':True,'source_sha256':source,'catalog_sha256':catalog,'evidence':[evidence(n) for n in names],'coverage':scopes[gate],'tested_revision':head,'acceptance':'Selected relevant coverage with explicit omissions, following repository verification policy.'}
record['limits']=[x for x in record['limits'] if x!='Six rendering/startup/platform gates remain pending.']
record['limits'] += ['Final selected coverage is source/hash-bound. Native Windows/macOS/Android/iOS execution remains unverified; compact Linux and browser emulation are separate.','Shared late phone-gallery assertion and three baseline stale browser fixtures remain explicit; no success is inferred for them.','Firefox threaded WebGL2 captures are blank in both English and Malay in this headless environment; software rendering is visibly verified. No compositor root-cause or original-base execution claim. WebKit default worker-WebGL probe falls back to serial; actual threaded software is verified.']
record['limits']=list(dict.fromkeys(record['limits']))
if not a.execute:
 print(json.dumps({'revision':head,'gates':{k:len(v) for k,v in refs.items()},'execute':False},indent=2));raise SystemExit()
(K/'reviews/ms.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
result=subprocess.run(['python3','tools/localization/translation_program.py','status','--output',str(K),'--locale','ms'],text=True,capture_output=True)
(K/'final-release-audit.log').write_text(result.stdout+result.stderr)
assert result.returncode==0,(result.stdout,result.stderr)
print(result.stdout)
