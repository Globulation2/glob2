"""Join independently supplied records, refusing missing coverage or stale hashes."""
import hashlib,importlib.util,json
from pathlib import Path
r=Path(__file__).resolve().parent;root=r.parents[1]
s=importlib.util.spec_from_file_location('t',root/'tools/localization/translation_program.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t)
def read(name):return json.loads((r/name).read_text())
def index(name):return {b['id']:b for b in read(name)['batches']}
m=read('manifest.json');paths=t.catalog_paths(r,'ms');hashes={k:t.digest(p.read_bytes()) for k,p in paths.items()};targets=t.batch_target_hashes(m,paths)
a=index('author-review.json');s=index('semantic-review.json');e=index('editor-review.json');f=index('final-recheck.json');adv={**index('adversarial-review.json'),**index('online-adversarial-review.json')};renew={b['id']:b['renewed_target_sha256'] for b in read('editor-fourth-recheck.json')['renewed_batches']};extra=read('editor-final-disclaimer-recheck.json');renew[extra['batch']]=extra['final_snapshot_sha256']
old=read('reviews/ms.json');batches=[]
for b in m['batches']:
 id=b['id'];expected=set(b['keys'])
 for rec,field in [(a[id],'authored_keys'),(s[id],'reviewed_keys'),(e[id],'edited_keys'),(f[id],'rechecked_keys'),(adv[id],'adversarial_reviewed_keys')]:
  assert len(rec[field])==len(expected) and set(rec[field])==expected,(id,field)
  assert rec['source_sha256']==m['source_sha256'],id
 assert f[id]['target_sha256']==adv[id]['target_sha256']==targets[id],id
 assert renew.get(id,e[id]['proposed_sha256'])==targets[id],('editor final target',id)
 for records,folder in [(s,'authored-batches'),(e,'semantic-batches')]:
  value=records[id].get('input_target_sha256',records[id]['target_sha256']);assert value==read(f'{folder}/{id}.json')['target_sha256'],('original reviewed snapshot',id)
 people=[a[id]['author'],s[id]['reviewer'],e[id]['editor'],adv[id]['adversarial_reviewer']];assert len(set(people))==4,people
 batches.append({'id':id,'author':people[0],'reviewer':people[1],'editor':people[2],'adversarial_reviewer':people[3],'source_sha256':m['source_sha256'],'target_sha256':targets[id],'reviewed_keys':s[id]['reviewed_keys'],'edited_keys':e[id]['edited_keys'],'rechecked_keys':f[id]['rechecked_keys'],'rechecked_by':f[id]['rechecked_by'],'adversarial_reviewed_keys':adv[id]['adversarial_reviewed_keys']})
files=['author-review.json','semantic-review.json','editor-review.json','editor-focused-recheck.json','editor-fourth-recheck.json','editor-final-disclaimer-recheck.json','final-recheck.json','fourth-focused-semantic-recheck.json','adversarial-review.json','adversarial-native-renewal.json','online-adversarial-review.json','online-adversarial-final-complete.json']
record={'locale':'ms','source_sha256':m['source_sha256'],'catalog_sha256':hashes,'batches':batches,'findings':[],'accepted_english':read('accepted-english-final.json'),'language_brief':read('language-brief.json'),'gates':old['gates'],'independent_records':[{'path':name,'sha256':t.digest((r/name).read_bytes())} for name in files],'limits':['Agent-reviewed; not native-human-certified.','Linguistic records reflect full original readings plus explicitly proven unchanged-value carryforward and focused final rechecks.','Platform/rendering gates require separate actual evidence; no approval is inferred from filled catalogs.']}
t.write_json(r/'reviews/ms.json',record)
print('Verified independent coverage and final hashes:',len(batches),'batches',sum(len(b['reviewed_keys']) for b in batches),'keys')
print('Pending release audit:',t.audit_locale(r,m,record,'ms'))
