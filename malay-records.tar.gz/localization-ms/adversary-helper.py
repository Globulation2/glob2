import json,sys,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent;m=json.loads((r/'manifest.json').read_text())
for name in sys.argv[1:]:
 b=next(b for b in m['batches'] if b['id']==name);s=json.loads((r/'edited-batches'/f'{name}.json').read_text());source=json.loads((r/b['path']).read_text());print('\nBATCH',name,s['target_sha256'])
 for e in source['entries']:print(json.dumps([e['key'],e['source'],s['values'][e['id']]],ensure_ascii=False,separators=(',',':')))
