const path=require('node:path'),fs=require('node:fs'),cp=require('node:child_process');
const {test,expect}=require('@playwright/test');
const root=path.resolve(__dirname,'../../../..');
const {gameURL,waitForMainMenu,clickMainMenu}=require(path.join(root,'browser/tests/main-menu'));
for(const {locale,renderer} of [{locale:'ms',renderer:'webgl2'},{locale:'en',renderer:'webgl2'},{locale:'ms',renderer:'software'}]) test(`Firefox threaded settled ${locale} ${renderer} Settings presentation`,async({page,browser},info)=>{
 const errors=[];page.on('pageerror',error=>errors.push(String(error)));
 const base=String(info.project.use.baseURL);await page.context().addCookies([{name:'glob2_locale',value:locale,url:base}]);
 const url=new URL(gameURL(),base);url.searchParams.set('threads','threaded');url.searchParams.set('renderer',renderer);
 await page.goto(url.pathname+url.search);await waitForMainMenu(page,{timeout:120000});
 expect(await page.evaluate(()=>Module.executionMode)).toBe('threaded');
 const captures=[];
 async function capture(name,waitMs){const started=Date.now();await page.waitForTimeout(waitMs);const file=info.outputPath(name+'.png');await page.screenshot({path:file});const pixels=JSON.parse(cp.execFileSync('python3',['-c','from PIL import Image;import json,sys;im=Image.open(sys.argv[1]).convert("RGB");print(json.dumps({"colors":len(im.getcolors(im.width*im.height) or []),"extrema":im.getextrema()}))',file],{encoding:'utf8'}));captures.push({name,waitMs,elapsedMs:Date.now()-started,...pixels,diagnostics:await page.evaluate(()=>glob2Diagnostics.snapshot())});return pixels;}
 await capture(locale+'-firefox-threaded-menu-settled-2s',2000);
 await clickMainMenu(page,'settings');await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().screen),{timeout:60000}).toContain('SettingsScreen');
 await capture(locale+'-firefox-threaded-settings-settled-2s',2000);
 const final=await capture(locale+'-firefox-threaded-settings-settled-7s',5000);
 fs.writeFileSync(info.outputPath('presentation.json'),JSON.stringify({locale,renderer,browserVersion:browser.version(),errors,captures},null,2)+'\n');
 expect(final.colors,'actual presented Settings screenshot must contain diverse rendered pixels').toBeGreaterThan(32);
});
