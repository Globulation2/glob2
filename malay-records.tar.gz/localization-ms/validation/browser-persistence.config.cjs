const path=require('node:path');
const base=require('./browser-validation.config.cjs');
module.exports={...base,testDir:path.join(__dirname,'browser-extra'),testMatch:'*.spec.cjs',timeout:180000,
  outputDir:path.join(__dirname,'browser-master191-persistence-results'),
  reporter:[['list'],['json',{outputFile:path.join(__dirname,'browser-master191-persistence-results.json')}]],
  use:{...base.use,locale:'en-US'},
};
