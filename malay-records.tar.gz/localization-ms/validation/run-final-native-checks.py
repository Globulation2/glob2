from pathlib import Path
import sys,json,subprocess,time,fnmatch,xml.etree.ElementTree as ET
sys.path.insert(0,'test');from build_provenance import source_identity
b=Path('artifacts/localization-ms/validation');d=json.loads((b/'locale-integration-current-state.json').read_text());filters=list(dict.fromkeys(d['queuedFinalNativeFilters']));before=source_identity();assert before['revision']=='c2b3cd5a71af2cfa52345e245c063475003c4577' and not before['dirty']
out=b/'final-native';out.mkdir(exist_ok=True)
command=['python3','test/run_tests.py','--build-dir','build/linux/client/debug/dev-dev_fast-true-linker-auto','--binary','all','-j4','--display-jobs','1','--junit',str(out/'junit.xml'),'--artifacts',str(out/'artifacts'),'--write-inventory',str(out/'inventory.json')]
for f in filters:command.extend(['--filter',f])
(out/'command.json').write_text(json.dumps({'command':command,'sourceBefore':before},indent=2)+'\n');start=time.monotonic();code=subprocess.call(command);after=source_identity();root=ET.parse(out/'junit.xml').getroot();cases=[x.attrib['classname']+'/'+x.attrib['name'] for x in root.iter('testcase')];coverage={f:sum(fnmatch.fnmatchcase(x,f) for x in cases) for f in filters};result={'command':command,'exitCode':code,'seconds':time.monotonic()-start,'sourceBefore':before,'sourceAfter':after,'sourceStable':before==after,'junitSummary':root.attrib,'filterCoverage':coverage};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True);assert before==after;assert all(coverage.values()),coverage;sys.exit(code)
