const path=require('node:path');
const base=require('./browser-validation.config.cjs');
module.exports={...base,
 outputDir:path.join(__dirname,'browser-determinism-results'),
 reporter:[['list'],[path.join(__dirname,'browser-match-evidence-reporter.cjs')],['json',{outputFile:path.join(__dirname,'browser-determinism-results.json')}],['html',{outputFolder:path.join(__dirname,'browser-determinism-report'),open:'never'}]],
};
