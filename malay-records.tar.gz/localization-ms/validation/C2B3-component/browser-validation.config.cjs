const path = require('node:path');
const root = path.resolve(__dirname, '../../..');
const base = require(path.join(root, 'browser/playwright.config.js'));
module.exports = {
  ...base,
  testDir: path.join(root, 'browser/tests'),
  outputDir: path.join(__dirname, 'browser-results'),
  reporter: [['list'], ['json', {outputFile:path.join(__dirname, 'browser-results.json')}], ['html', {outputFolder:path.join(__dirname,'browser-report'),open:'never'}]],
  use: {...base.use, baseURL:'http://127.0.0.1:8897'},
  webServer: {
    command:'python3 browser/serve.py 8897 --bind 127.0.0.1 --directory build/emscripten/client/release',
    cwd:root, url:'http://127.0.0.1:8897', reuseExistingServer:false,
  },
};
