import hashlib,json,subprocess,time
from pathlib import Path
R=Path.cwd();P=R/'artifacts/localization-ms/validation';out=R/'build/emscripten/client/release';start=json.load(open(P/'browser-final-start.json'));result=json.load(open(P/'browser-final-result.json'));assert result['exit_code']==0
files=[p for p in out.iterdir() if p.is_file() and p.suffix in ('.html','.js','.wasm','.css','.data')]
for directory in ('assets','fonts','locales','licenses','threaded'):
 files.extend(p for p in (out/directory).rglob('*') if p.is_file() and ('obj' not in p.parts) and (directory!='threaded' or (len(p.relative_to(out/'threaded').parts)==1 and p.suffix in ('.html','.js','.wasm','.css','.data'))))
files=sorted(set(files));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files];git=lambda *x:subprocess.check_output(['git',*x],text=True).strip();head=git('rev-parse','HEAD');changes=git('diff','--name-only',start['revision'],head).splitlines();span=json.load(open(P/'browser-approved-source-span.json'));assert set(changes)<=set(span['changed_paths']+span['fixture_followup_allowed']),changes
for file in ['index.js','index.wasm','threaded/index.js','threaded/index.wasm','locales/ms.json']:
 assert any(x['path']==file for x in rows),file
assert sha(out/'locales/ms.json')==sha(R/'platform/packages/i18n/locales/ms.json')
assert sha(out/'i18n.js')==sha(R/'browser/i18n.js')
assert sha(out/'runtime-assets/data/texts.ms.txt')==sha(R/'data/texts.ms.txt')
refresh=json.load(open(P/'browser-final-refresh-result.json'));assert refresh['exit_code']==0
record={'producer':start,'incremental_final_producer':refresh,'result':result,'captured_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'native_ms_staging_sha256':sha(out/'runtime-assets/data/texts.ms.txt'),'source_at_capture':head,'source_changes_after_start':changes,'package_files':rows,'coverage':'Both serial and threaded release runtime, launcher and worker files, lazy data packages, fonts, online catalogs, notices. Object/dependency/staging trees excluded.'};(P/'browser-final-package.json').write_text(json.dumps(record,indent=2)+'\n');print('Captured',len(rows),'packaged files',sum(x['bytes'] for x in rows),'bytes')
