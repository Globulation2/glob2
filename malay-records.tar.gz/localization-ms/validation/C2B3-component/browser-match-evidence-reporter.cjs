const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'../../..');
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
module.exports=class MatchEvidenceReporter {
  onTestEnd(test,result) {
    if(!test.title.includes('verifies the committed match record')) return;
    const variant=test.title.includes('(threaded)')?'threaded':'serial';
    const project=test.parent.project().name;
    const output=path.join(__dirname,'browser-match-evidence',project,variant);
    fs.mkdirSync(output,{recursive:true});
    const record={test:test.title,project,variant,status:result.status,durationMs:result.duration,
      fixtureSha256:sha(path.join(root,'test/fixtures/multiplayer/FourSquares1.g2mr')),
      canonicalTraceSha256:sha(path.join(root,'test/fixtures/multiplayer/FourSquares1.verify-trace.txt')),
      packageReceiptSha256:sha(path.join(__dirname,'browser-final-package.json')),
      nodeVersion:process.version,files:[],errors:result.errors.map(error=>error.message)};
    // The stock test writes this shared export only after its verdict, threading
    // and exact per-tick assertions pass. Copy it before the next sequential case.
    // Failed cases never adopt a previous case's shared output as new evidence.
    if(result.status==='passed') {
      const source=path.join(root,'artifacts/browser-determinism/wasm',variant==='threaded'?'verify-threaded':'');
      for(const file of ['verify-match.checksums.txt','verify-match.verdict.json','verify-match.log']) {
        fs.copyFileSync(path.join(source,file),path.join(output,file));
        record.files.push({file,bytes:fs.statSync(path.join(output,file)).size,sha256:sha(path.join(output,file))});
      }
      record.actualTraceSha256=sha(path.join(output,'verify-match.checksums.txt'));
      record.exactCanonicalTraceMatch=record.actualTraceSha256===record.canonicalTraceSha256;
    }
    fs.writeFileSync(path.join(output,'provenance.json'),JSON.stringify(record,null,2)+'\n');
  }
};
