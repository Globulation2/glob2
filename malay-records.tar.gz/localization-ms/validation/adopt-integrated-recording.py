from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

root = Path.cwd()
base = root / "artifacts/localization-ms/validation"
candidate = json.loads((base / "recording-integrated-candidate.json").read_text())
source = Path(candidate["prefix"])
destination = base / "recording/prefix"
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert not Path("/proc/962086").exists(), "Initial native build still consumes this prefix"
sys.path.insert(0, str(root / "scons"))
from dev_store import Lease

with Lease(source.parent):
    manifest = json.loads((source / "recording-manifest.json").read_text())
    assert manifest == candidate["manifest"]
    identity = manifest["identity"]
    assert identity["recipe"] == sha(root / "scons/recording_dependencies.py")
    lock = json.loads((root / "scons/recording-versions.json").read_text())
    assert identity["versions"] == {name: lock[name] for name in ("ffmpeg", "x264", "nv-codec-headers")}
    assert identity["configuration"] == 3 and identity["video_codec"] == "h264"
    assert identity["flags"] == [[], []] and identity["opus"] is None
    assert identity["compiler"] == subprocess.check_output(["gcc", "--version"], text=True)
    assert len(manifest["archives"]) == 6
    for name, digest in manifest["archives"].items():
        assert sha(source / "lib" / name) == digest, name
    shared = json.loads((source / ".shared-install.json").read_text())
    tools = {}
    for name in ("gcc", "g++", "ar", "ranlib", "cmake", "make", "nasm", "pkg-config"):
        spec = shared["identity"]["tools"][name]
        path = shutil.which(name)
        assert sha(path) == spec["binary"], name
        tools[name] = {"path": path, "sha256": sha(path)}
    original = {str(path.relative_to(source)): sha(path)
                for path in source.rglob("*") if path.is_file()}
    shutil.copytree(source, destination, dirs_exist_ok=True, symlinks=True)
    relocated = []
    for path in destination.rglob("*"):
        if path.is_file() and path.suffix in (".pc", ".cmake", ".la"):
            before = path.read_text()
            after = before.replace(str(source), str(destination))
            if after != before:
                path.write_text(after)
                relocated.append(str(path.relative_to(destination)))
    (destination / ".shared-install.json").unlink(missing_ok=True)
    for name, digest in original.items():
        if name not in relocated and name != ".shared-install.json":
            assert sha(destination / name) == digest, name
    (base / "recording-integrated-reuse-provenance.json").write_text(json.dumps({
        "source_prefix": str(source), "destination_prefix": str(destination),
        "manifest": manifest, "verified_current_tools": tools,
        "source_files_sha256": original, "relocated_metadata": relocated,
        "notes": "Current merged-master H264 recording profile, exact full identity and archive/tool hashes verified. Adopted only after initial native build exited; include/library paths preserved."
    }, indent=2) + "\n")
print("Adopted current exact H264 recording profile", flush=True)
sys.path.insert(0, str(root / "test"))
from build_provenance import source_identity
identity = source_identity(root)
encoded = json.dumps(identity, indent=2) + "\n"
(base / "native-post-build-source-before.json").write_text(encoded)
(base / ("native-source-before-" + identity["revision"][:10] + "-" +
         identity["sourceTreeSha256"][:12] + ".json")).write_text(encoded)
print("Retained frozen source identity before integration SCons", flush=True)
