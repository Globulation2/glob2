const path=require('node:path');
const base=require('./browser-persistence.config.cjs');
module.exports={...base,testDir:path.join(__dirname,'browser-phone-final'),testMatch:'malay-phone.spec.cjs',
 outputDir:path.join(__dirname,'browser-master191-phone-final-results'),
 reporter:[['list'],['json',{outputFile:path.join(__dirname,'browser-master191-phone-final-results.json')}]],
};
