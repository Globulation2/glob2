const path=require('node:path');const base=require('./browser-validation.config.cjs');
module.exports={...base,use:{...base.use,baseURL:'http://127.0.0.1:8898'},webServer:{...base.webServer,command:base.webServer.command.replace('8897','8898'),url:'http://127.0.0.1:8898'},testDir:path.join(__dirname,'browser-visual-extra'),testMatch:'*.spec.cjs',timeout:180000,
 outputDir:path.join(__dirname,'browser-master191-visual-extra-results'),reporter:[['list'],['json',{outputFile:path.join(__dirname,'browser-master191-visual-extra-results.json')}]]};
