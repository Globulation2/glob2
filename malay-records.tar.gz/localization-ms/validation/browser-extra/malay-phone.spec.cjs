const path=require('node:path');
const fs=require('node:fs');
const {test,expect}=require('@playwright/test');
const root=path.resolve(__dirname,'../../../..');
const {gameURL,waitForMainMenu,clickMainMenu,clickControl}=require(path.join(root,'browser/tests/main-menu'));
test.use({viewport:{width:390,height:844},deviceScaleFactor:2,isMobile:true,hasTouch:true,locale:'ms-MY'});
test('phone Malay settings renders the actual game at DPR2',async ({page,browserName,browser},info)=>{
  test.skip(browserName!=='chromium','Focused actual phone capture uses Chromium.');
  const base=String(info.project.use.baseURL);
  expect((await page.context().cookies()).some(cookie=>cookie.name==='glob2_locale')).toBe(false);
  const url=new URL(gameURL(),base);url.searchParams.set('threads','serial');
  await page.goto(url.pathname+url.search);
  await expect.poll(()=>page.evaluate(()=>globalThis.Glob2I18n?.getLocale()),{timeout:60000}).toBe('ms');
  await expect(page.locator('html')).toHaveAttribute('lang','ms');
  await expect(page.locator('html')).toHaveAttribute('dir','ltr');
  // Touch-first onboarding asks for audio before offering the introduction.
  await expect.poll(()=>page.evaluate(()=>{const s=glob2Diagnostics.snapshot();return Boolean(s.controls['audio.silence']?.enabled)||String(s.screen).includes('IntroductionOfferScreen')||String(s.screen).includes('MainMenuScreen');}),{timeout:120000}).toBe(true);
  if(await page.evaluate(()=>Boolean(glob2Diagnostics.snapshot().controls['audio.silence']?.enabled))) await clickControl(page,'audio.silence');
  await waitForMainMenu(page,{timeout:120000});
  await expect.poll(()=>page.evaluate(()=>Object.values(glob2Diagnostics.snapshot().controls).some(x=>x.label==='Tetapan'))).toBe(true);
  expect(await page.evaluate(()=>Module.executionMode)).toBe('serial');
  await clickMainMenu(page,'settings');
  await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().screen),{timeout:60000}).toContain('SettingsScreen');
  await page.waitForTimeout(1000);
  await page.locator('#canvas').screenshot({path:info.outputPath('ms-phone-dpr2-settings.png')});
  const evidence=await page.evaluate(()=>({
    navigator:{language:navigator.language,languages:[...navigator.languages]},documentLanguage:document.documentElement.lang,cookie:document.cookie,
    dpr:devicePixelRatio,viewport:{width:innerWidth,height:innerHeight},
    canvas:{width:document.querySelector('#canvas').width,height:document.querySelector('#canvas').height},
    overflow:document.documentElement.scrollWidth-document.documentElement.clientWidth,
    executionMode:Module.executionMode,threadFallback:Module.threadFallback,diagnostics:glob2Diagnostics.snapshot(),locale:Glob2I18n.getLocale(),
  }));
  expect(evidence.dpr).toBe(2);expect(evidence.overflow).toBeLessThanOrEqual(1);
  const provenance=JSON.stringify({...evidence,browserName,browserVersion:browser.version(),nodeVersion:process.version},null,2);
  fs.writeFileSync(info.outputPath('ms-phone-provenance.json'),provenance+'\n');
  await info.attach('ms-phone-provenance.json',{body:provenance,contentType:'application/json'});
});
