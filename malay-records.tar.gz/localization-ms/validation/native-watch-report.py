from pathlib import Path
l=Path('artifacts/localization-ms/validation/native-master190-build.log').read_text().splitlines()
c=[x.split(' -o ',1)[1].split(' ',1)[0] for x in l if '/usr/bin/ccache g++ -o ' in x]
print('alive',Path('/proc/2666755').exists(),'commands',len(c),'last',c[-1:])
print('errors',[x for x in l if 'error:' in x][-2:])
r=Path('build/linux/client/debug/dev-dev_fast-true-linker-auto')
initial={'test/TranslationPreviewHarness':1793488739589988829,'test/glob2-engine-tests':1793491058153586054,'src/mobile-gallery':None,'src/glob2':None,'test/glob2-unit-tests':None}
print('changed',[x for x,t in initial.items() if (r/x).exists() and (r/x).stat().st_mtime_ns!=t])
if not Path('/proc/2666755').exists():print('tail',l[-3:])
