import original from './web-final-7133.config.mjs';
export default {...original,testMatch:'web-final-72433-runner.spec.ts'};
