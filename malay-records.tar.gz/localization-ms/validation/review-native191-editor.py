import json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
obs={
'desktop-screen-main/main.png':'All main actions readable within buttons; custom game, online, campaign/load/tutorial and lower controls fit. Latin text and menu icons intact.',
'desktop-screen-settings/settings.png':'Display headings/helpers clear; Perisian visible; scale value wraps in its selector; footer Selesai visible. Scrollable lower art setting partially below viewport as expected.',
'desktop-screen-settings-audio/settings-audio.png':'Audio mute checkbox, two sliders and two-line random-music selector fit. Automatic-save footer and Selesai clearly visible; no missing-footer finding.',
'desktop-screen-settings-player/settings-player.png':'Actual Bahasa Melayu locale selector fits in full beside Bahasa; name field and helper text clear; footer controls fit.',
'desktop-screen-lobby/lobby.png':'Map/settings headings and parameters fit; long preview instruction wraps naturally; bottom Back/Play buttons visible. Empty preview with Menjana pratonton… is a captured pending state, not proof of completed generation.',
'desktop-screen-lobby-players/lobby-players.png':'Four player rows and team/AI selectors fit; full Numbi helper prose readable; footer controls visible; authored player name retained.'}
seen={}
for rel,note in obs.items():
 p=R/'native-191'/rel;seen[rel]={'path':'native-191/'+rel,'sha256':H(p),'observations':[note]}
# These exact images were actually viewed before this script was written.
for viewport in ['desktop','phone']:
 p=R/'catalog-font-matrix191-supplement'/f'{viewport}-matrix-all/font-20-scale-2-page-001.png';seen[str(p.relative_to(R))]={'path':str(p.relative_to(R)),'sha256':H(p),'observations':['All16 supplemental Malay captions actually inspected; clear Latin glyphs including ellipsis/em dash and ampersand, no visible clipping or overlap. '+('Long missing-reading sentence is complete on one line.' if viewport=='desktop' else 'Long missing-reading sentence wraps naturally to two lines; all remaining captions fit.')],'kind':'supplement_font_page'}
(R/'native191-editor-seen-images.json').write_text(json.dumps(seen,ensure_ascii=False,indent=2)+'\n')
