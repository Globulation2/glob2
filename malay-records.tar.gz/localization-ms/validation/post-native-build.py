from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd();pid=962086
print("Waiting for current native harness/engine build PID",pid,flush=True)
while Path("/proc",str(pid)).exists():time.sleep(5)
harness=root/"build/linux/client/debug/dev-dev_fast-true-linker-auto/test/TranslationPreviewHarness"
if not harness.is_file():
 print("Post-native targets skipped: required native harness did not link; inspect native-build.log",flush=True);sys.exit(1)
subprocess.check_call([sys.executable,str(root/"artifacts/localization-ms/validation/adopt-integrated-recording.py")],cwd=root)
env=dict(os.environ,GLOB2_SDL3_PREFIX=str(root/"artifacts/localization-ms/validation/sdl3/prefix"),GLOB2_RECORDING_PREFIX=str(root/"artifacts/localization-ms/validation/recording/prefix"))
command=["python3","tools/dev_build.py",*json.loads((root/"artifacts/localization-ms/validation/post-native-targets.json").read_text()),"-j8"]
print("Building",command,flush=True)
sys.exit(subprocess.call(command,env=env,cwd=root))
