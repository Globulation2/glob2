const path = require('node:path');
const root = path.resolve(__dirname, '../../..');
const base = require(path.join(root, 'browser/playwright.config.js'));
module.exports = {
  ...base,
  // The download gate performs two cold starts; prior release took78s.
  timeout:180000,
  testDir: path.join(__dirname, 'browser-master191-stock-tests'),
  outputDir: path.join(__dirname, 'browser-master191-staged-results'),
  reporter: [['list'], ['json', {outputFile:path.join(__dirname, 'browser-master191-staged-results.json')}], ['html', {outputFolder:path.join(__dirname,'browser-master191-staged-report'),open:'never'}]],
  use: {...base.use, baseURL:'http://127.0.0.1:8897'},
  webServer: {
    command:'python3 browser/serve.py 8897 --bind 127.0.0.1 --directory build/emscripten/client/release',
    cwd:root, url:'http://127.0.0.1:8897', reuseExistingServer:false,
  },
};
