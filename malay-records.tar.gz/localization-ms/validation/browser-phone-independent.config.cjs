const path=require('node:path');
const base=require('./browser-persistence.config.cjs');
module.exports={...base,use:{...base.use,baseURL:'http://127.0.0.1:8898'},webServer:{...base.webServer,command:base.webServer.command.replace('8897','8898'),url:'http://127.0.0.1:8898'},testMatch:'malay-phone.spec.cjs',
 outputDir:path.join(__dirname,'browser-master191-phone-results'),
 reporter:[['list'],['json',{outputFile:path.join(__dirname,'browser-master191-phone-results.json')}]],
};
