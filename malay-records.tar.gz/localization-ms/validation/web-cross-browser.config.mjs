import original from '/home/bradley/.codex/worktrees/545f/glob2/platform/apps/web/e2e/playwright.config.ts';
const directory = '/home/bradley/.codex/worktrees/545f/glob2';
export default {
  ...original,
  testDir: `${directory}/platform/apps/web/e2e`,
  outputDir: `${directory}/artifacts/localization-ms/validation/web-cross-browser-results`,
  projects: ['chromium', 'firefox', 'webkit'].flatMap(browserName => [
    {name:`${browserName}-desktop`, use:{browserName, viewport:{width:1280,height:860}}},
    {name:`${browserName}-phone`, use:{browserName, viewport:{width:393,height:727}}},
  ]),
  webServer: {...original.webServer, cwd:`${directory}/platform/apps/web`},
};
