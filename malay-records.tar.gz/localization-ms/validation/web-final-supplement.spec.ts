import {test, expect} from '/home/bradley/.codex/worktrees/545f/glob2/platform/node_modules/@playwright/test/index.mjs';
import {readFileSync,mkdirSync,appendFileSync} from 'node:fs';
import {resolve} from 'node:path';
import '/home/bradley/.codex/worktrees/545f/glob2/platform/apps/web/e2e/malay.spec.ts';
const root='/home/bradley/.codex/worktrees/545f/glob2';
const ms=JSON.parse(readFileSync(`${root}/platform/packages/i18n/locales/ms.json`,'utf8'));
const output=`${root}/artifacts/localization-ms/validation/web-phone-paint-final`;
test('final Malay registry and verdict captions render in real app',async({page,context,request,baseURL},info)=>{
  test.skip(!info.project.name.startsWith('chromium-'),'Heavy3D label evidence scoped to Chromium desktop/phone; baseline12routes covers all6projects.');
  test.setTimeout(360000);
  await context.addCookies([{name:'glob2_locale',value:'ms',url:baseURL!}]);
  const seed=await(await request.get('/__seed')).json();
  async function capture(name:string){
    await page.evaluate('document.fonts.ready');
    const overflow=await page.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth');
    expect(overflow,`${name} viewport fit`).toBeLessThanOrEqual(1);
    mkdirSync(output,{recursive:true});
    await page.screenshot({path:resolve(output,`${info.project.name}-ms-${name}.png`),fullPage:true});
    appendFileSync(resolve(output,'fit-observations.jsonl'),JSON.stringify({project:info.project.name,name,overflow})+'\n');
  }
  await page.goto('/ais');
  const theme=page.getByTestId('theme-toggle');
  const themeLabel=await theme.getAttribute('aria-label');
  expect(themeLabel).toContain('Tukar tema');
  expect(themeLabel).not.toContain('Change theme');
  for(const k of ['Rush','Defensive','Economy','Expansion','Experimental','Beginner-friendly'])
    await expect(page.getByRole('button',{name:ms[k],exact:true})).toBeVisible();
  await capture('ai-tags');
  await context.addCookies([{name:'glob2_session',value:seed.userSession,url:baseURL!}]);
  await page.goto('/skins');
  await page.getByRole('button',{name:ms['New skin'],exact:true}).click();
  await expect(page.getByLabel(ms['Skin name'])).toBeEnabled();
  for(const k of ['Worker','Warrior','Explorer','Swarm'])
    await expect(page.getByRole('group',{name:ms['Model to paint']}).getByRole('button',{name:ms[k],exact:true})).toBeVisible();
  for(const k of ['Walk','Swim','Harvest'])
    await expect(page.getByRole('group',{name:ms['Pose']}).getByRole('button',{name:ms[k],exact:true})).toBeVisible();
  await capture('skin-animation');
  await page.getByRole('button',{name:ms['Material'],exact:true}).click();
  await expect(page.getByRole('radiogroup',{name:ms['Material']}).first()).toBeVisible();
  const paintFit=await page.locator('.skin-tool-options').evaluate(el=>{
    const rect=node=>{const r=node.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom,right:r.right};};
    const box=rect(el.closest('.skin-toolbox'));
    const buttons=[...el.querySelectorAll('.skin-segment button')].map(button=>{
      const range=document.createRange();range.selectNodeContents(button);const text=rect(range);
      return {label:button.textContent,button:rect(button),text,inside:text.y>=box.y&&text.bottom<=box.bottom&&text.x>=box.x&&text.right<=box.right};
    });
    const palette=el.querySelector('.skin-material-groups');
    return {toolbox:box,buttons,palette:rect(palette),paletteOverflow:palette.scrollWidth-palette.clientWidth};
  });
  appendFileSync(resolve(output,'paint-mode-fit.jsonl'),JSON.stringify({project:info.project.name,...paintFit})+'\n');
  expect(paintFit.buttons).toHaveLength(2);
  expect(paintFit.buttons.every(button=>button.inside),'Warna/Bahan text must be within toolbox clip').toBe(true);
  expect(paintFit.paletteOverflow,'Material palette fits its own width').toBeLessThanOrEqual(1);
  await capture('skin-materials');
  const wood=page.getByRole('radio',{name:ms['Wood'],exact:true});
  await wood.click();
  await expect(wood).toHaveAttribute('aria-checked','true');
  await page.getByRole('button',{name:ms['Color'],exact:true}).click();
  await page.getByRole('button',{name:ms['Material'],exact:true}).click();
  await expect(wood).toHaveAttribute('aria-checked','true');
  const swarm=page.getByRole('group',{name:ms['Model to paint']}).getByRole('button',{name:ms['Swarm'],exact:true});
  await swarm.focus();
  await swarm.press('Enter');
  async function shapeHit(locale:string){
    const diagnostic=await page.locator('.skin-shape-button').evaluate(el=>{
      const r=el.getBoundingClientRect(),s=getComputedStyle(el),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);
      return {bounds:{x:r.x,y:r.y,width:r.width,height:r.height},centerHit:hit?.outerHTML.slice(0,500),isButtonHit:hit===el||!!hit&&el.contains(hit),zIndex:s.zIndex,transform:s.transform,visibility:s.visibility,pointerEvents:s.pointerEvents};
    });
    appendFileSync(resolve(output,'shape-hit-diagnostics.jsonl'),JSON.stringify({project:info.project.name,locale,...diagnostic})+'\n');
    await capture(`skin-shape-button-${locale}`);
  }
  await shapeHit('ms');
  if(info.project.name.endsWith('desktop')){
    await page.getByTestId('language-selector').selectOption('en');
    await shapeHit('en');
    await page.getByTestId('language-selector').selectOption('ms');
  }
  await expect.poll(()=>page.locator('.skin-shape-button').evaluate(el=>{
    const r=el.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);
    return hit===el||!!hit&&el.contains(hit);
  })).toBe(true);
  await page.locator('.skin-shape-button').click();
  const shapes=page.getByRole('dialog',{name:ms['Swarm shape'],exact:true});
  for(const k of ['Classic','Crown','Clutch','Toadstool','Coral','Skep','Bloom'])
    await expect(shapes.getByText(ms[k],{exact:true})).toBeVisible();
  const fit=await shapes.evaluate(el=>{
    const r=el.getBoundingClientRect();
    const cards=[...el.querySelectorAll('.skin-shape-grid button')].map(card=>{
      const b=card.getBoundingClientRect();return {text:card.textContent,x:b.x,right:b.right,width:b.width,inside:b.x>=r.x&&b.right<=r.right};
    });
    return {dialog:{x:r.x,right:r.right,width:r.width},overflow:el.scrollWidth-el.clientWidth,cards};
  });
  appendFileSync(resolve(output,'shape-dialog-fit.jsonl'),JSON.stringify({project:info.project.name,...fit})+'\n');
  expect(fit.overflow,'Shape dialog content should fit its own width').toBeLessThanOrEqual(1);
  expect(fit.cards).toHaveLength(7);
  expect(fit.cards.every(card=>card.inside),'All7 shape cards fit inside modal').toBe(true);
  await capture('skin-shapes');
 });
test('final Malay verdict music guidance and admin labels render',async({page,context,request,baseURL},info)=>{
  test.skip(!info.project.name.startsWith('chromium-'),'Targeted metadata evidence on Chromium desktop/phone.');
  await context.addCookies([{name:'glob2_locale',value:'ms',url:baseURL!}]);
  const seed=await(await request.get('/__seed')).json();
  async function capture(name:string){
    await page.evaluate('document.fonts.ready');
    const overflow=await page.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth');
    expect(overflow,`${name} viewport fit`).toBeLessThanOrEqual(1);
    mkdirSync(output,{recursive:true});
    await page.screenshot({path:resolve(output,`${info.project.name}-ms-${name}.png`),fullPage:true});
    appendFileSync(resolve(output,'fit-observations.jsonl'),JSON.stringify({project:info.project.name,name,overflow})+'\n');
  }
  await page.goto(`/matches/${seed.featuredMatch}`);
  await page.getByText(ms['Verification and connection details'],{exact:true}).click();
  await expect(page.getByText(ms['The server replayed this match and every player’s game agreed with it.'],{exact:true})).toBeVisible();
  await capture('match-verdict');
  const categories=['score','format','loudness','seam','repetition','alignment','contrast','noise','balance','audibility','dropout'];
  await page.route('**/api/v1/music/malay-review-fixture',route=>route.fulfill({json:{
    id:'malay-review-fixture',ownerId:'review-fixture-author',status:'published',
    metadata:{title:'Malay review fixture',artist:'Test author',description:'Authored fixture text',license:'CC0-1.0',credits:'Fixture only',sources:[],aiGenerated:false},
    createdAt:'2026-01-01T00:00:00Z',frames:48000,tracks:[],warnings:[],coverUrl:null,
    likes:0,downloads:0,liked:false,hidden:false,error:null,
    validation:categories.map(label=>({id:label,label,attempt:1,status:'warn',measures:[]})),
  }}));
  await page.goto('/music/malay-review-fixture');
  await expect(page.getByText(ms['Listen for the musical structure and development.'],{exact:true})).toBeVisible();
  await expect(page.getByText(ms['Check that building and combat feel distinct from calm.'],{exact:true})).toBeVisible();
  await capture('music-guidance');
  await context.addCookies([{name:'glob2_session',value:seed.adminSession,url:baseURL!}]);
  await page.goto('/admin/accounts');
  await expect(page.getByTestId('admin-account').first()).toBeVisible();
  await capture('admin-accounts');
  await page.goto('/admin/finances');
  await expect(page.locator('main')).toContainText(ms['Finances']);
  await expect(page.getByRole('option',{name:ms['Live payments'],exact:true})).toHaveAttribute('value','live');
  await expect(page.getByRole('option',{name:ms['Test payments'],exact:true})).toHaveAttribute('value','test');
  await expect(page.getByRole('option',{name:ms['Unclassified payments'],exact:true})).toHaveAttribute('value','unclassified');
  const totals=await page.locator('main p').allTextContents();
  const usd=totals.find(text=>text.startsWith('USD:'))?.replace(/\s/g,'');
  const jpy=totals.find(text=>text.startsWith('JPY:'))?.replace(/\s/g,'');
  expect(usd).toContain('USD123.45');
  expect(usd).toContain('USD10.00');
  expect(usd).toContain('USD113.45');
  expect(jpy).toContain('JPY500');
  await expect(page.locator('main')).toContainText(ms['Map Studio']);
  await expect(page.locator('main')).toContainText(ms['Credit grant']);
  await expect(page.locator('main')).toContainText(ms['Returned credits']);
  await capture('admin-finances');
});
