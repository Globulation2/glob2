from pathlib import Path
import hashlib
import json
import mmap
import os
import sys

path = Path(sys.argv[1]).resolve()
digest = hashlib.sha256()
producers = []
with path.open("rb") as stream:
    before = os.fstat(stream.fileno())
    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(chunk)
    with mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as memory:
        offset = 0
        while True:
            offset = memory.find(b'{"compiler":', offset)
            if offset < 0:
                break
            end = memory.find(b"\0", offset)
            if 0 < end - offset < 1024 * 1024:
                try:
                    value = json.loads(memory[offset:end])
                    if all(key in value for key in ("revision", "sourceTreeSha256", "compiler", "flags")):
                        producers.append(value)
                except (UnicodeError, ValueError):
                    pass
            offset += 1
    key = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns)
    assert key(before) == key(os.fstat(stream.fileno())) == key(path.stat()), "Binary changed while reading"
print(json.dumps({"path": str(path), "sha256": digest.hexdigest(),
                  "embeddedProducers": producers}, indent=2))
