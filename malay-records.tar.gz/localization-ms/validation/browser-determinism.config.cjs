const path=require('node:path');
const base=require('./browser-validation.config.cjs');
module.exports={...base,
 testDir:path.resolve(__dirname,'../../../browser/tests'),
 outputDir:path.join(__dirname,'browser-master191-determinism-results'),
 reporter:[['list'],[path.join(__dirname,'browser-match-evidence-reporter.cjs')],['json',{outputFile:path.join(__dirname,'browser-master191-determinism-results.json')}],['html',{outputFolder:path.join(__dirname,'browser-master191-determinism-report'),open:'never'}]],
};
