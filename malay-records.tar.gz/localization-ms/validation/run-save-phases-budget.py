from pathlib import Path
import subprocess,json,time,sys,os,xml.etree.ElementTree as E
sys.path.insert(0,'test');from build_provenance import source_identity
b=Path('artifacts/localization-ms/validation/final-save-phases-budget');b.mkdir(exist_ok=True);before=source_identity();assert not before['dirty'] and before['revision']=='c2b3cd5a71af2cfa52345e245c063475003c4577';cmd=['python3','test/run_tests.py','--build-dir','build/linux/client/debug/dev-dev_fast-true-linker-auto','--binary','engine','--filter','TeamStatsSave/32 sampling phases*','-j1','--timeout','600','--junit',str(b/'junit.xml'),'--artifacts',str(b/'artifacts')];snapshots=[];start=time.monotonic()
with (b/'case.log').open('w') as log:
 process=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
 while process.poll() is None:
  for p in Path('/proc').iterdir():
   if not p.name.isdigit():continue
   try:
    c=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()
    if c.startswith(str(Path.cwd()/'build/linux/client/debug/dev-dev_fast-true-linker-auto/test/glob2-engine-tests')) and '-tc=32 sampling phases' in c:
     raw=(p/'stat').read_text();s=raw[raw.rfind(')')+2:].split();hz=os.sysconf('SC_CLK_TCK');up=float(Path('/proc/uptime').read_text().split()[0]);snapshots.append({'pid':int(p.name),'cpuSeconds':(int(s[11])+int(s[12]))/hz,'elapsedSeconds':up-int(s[19])/hz,'observedAtSeconds':time.monotonic()-start})
   except (OSError,ValueError,UnicodeError):pass
  (b/'resource-progress.json').write_text(json.dumps(snapshots,indent=2)+'\n');time.sleep(5)
after=source_identity();xml=E.parse(b/'junit.xml').getroot();r={'command':cmd,'exitCode':process.returncode,'seconds':time.monotonic()-start,'sourceBefore':before,'sourceAfter':after,'sourceStable':before==after,'junitSummary':xml.attrib,'resourceSnapshots':snapshots,'reasonForExplicitBudget':'Two retained default120s attempts timed out; this focused rerun keeps every test assertion and gives a measured600s development-binary wall budget'};(b/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='resourceSnapshots'},indent=2));assert before==after;sys.exit(process.returncode)
