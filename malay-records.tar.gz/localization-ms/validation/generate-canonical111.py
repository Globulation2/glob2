"""Regenerate canonical111 only with the completed, exact191 native producer."""
from pathlib import Path
import sys,json,os,subprocess,hashlib,time,shutil,xml.etree.ElementTree as ET
sys.path.insert(0,'test')
from build_provenance import source_identity,build_issues
from check_sim_revision import record_sim_version,load_sim_version
R=Path.cwd();V=R/'artifacts/localization-ms/validation';O=V/'golden111';O.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result=read(V/'native-master191-build-result.json');assert result['exitCode']==0 and result['sourceStable'];before=source_identity(R);assert before==result['sourceAfter'] and not before['dirty'];assert before['revision']=='11d72bf8c881b5db07c33feaa251aef326c15c84'
binary=R/'build/linux/client/debug/dev-dev_fast-true-linker-auto/test/glob2-engine-tests';producer=read(V/'native-master191-engine-producer.json') if (V/'native-master191-engine-producer.json').exists() else json.loads(subprocess.check_output([sys.executable,str(V/'read-native-producer.py'),str(binary)],text=True));assert len(producer['embeddedProducers'])==1;assert not build_issues(producer['embeddedProducers'][0],before)
paths=['test/fixtures/multiplayer/FourSquares1.g2mr','test/fixtures/multiplayer/FourSquares1.verify-trace.txt'];backup=V/'golden-master-bc8-sim110';backup.mkdir(exist_ok=True)
for name in paths:
 p=R/name;assert p.read_bytes()==subprocess.check_output(['git','show','bc8fb2c2bda69af14a7a6c5ed5ca1dfed7575ddb:'+name]);shutil.copyfile(p,backup/p.name)
env=dict(os.environ);env['LD_LIBRARY_PATH']=':'.join([str(V/'sdl3/prefix/lib'),str(V/'recording/prefix/lib'),env.get('LD_LIBRARY_PATH','')]);cmd=[sys.executable,'test/run_tests.py','--build-dir','build/linux/client/debug/dev-dev_fast-true-linker-auto','--binary','engine','--update-fixtures','--timeout','600','--filter','TurnEngineHarness/the committed*','--junit',str(O/'junit.xml'),'--artifacts',str(O/'artifacts'),'--write-inventory',str(O/'inventory.json')];start=time.monotonic();(O/'command.json').write_text(json.dumps({'command':cmd,'sourceBefore':before,'binary':str(binary),'binarySha256':sha(binary),'producer':producer},indent=2)+'\n')
with (O/'process.log').open('w') as f:code=subprocess.call(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
assert code==0,code;junit=ET.parse(O/'junit.xml').getroot();assert int(junit.attrib['tests'])==1 and int(junit.attrib.get('failures',0))==0 and int(junit.attrib.get('errors',0))==0,junit.attrib;changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();assert changed and set(changed)<=set(paths),changed
sim=load_sim_version();key=sim.sim_version_key(R);assert sim.sim_revision(R)==111 and key.startswith('191-');assert record_sim_version((R/paths[0]).read_bytes())==key
C=V/'final-canonical-111';C.mkdir(exist_ok=True)
for name in paths:shutil.copyfile(R/name,C/Path(name).name)
report={'producerSource':before,'command':cmd,'exitCode':code,'seconds':time.monotonic()-start,'junitSummary':junit.attrib,'changedPaths':changed,'simRevision':111,'saveFormat':191,'simVersion':key,'recordSha256':sha(R/paths[0]),'traceSha256':sha(R/paths[1]),'recordBytes':(R/paths[0]).stat().st_size,'traceBytes':(R/paths[1]).stat().st_size,'actualNativeWriter':True,'manualFixturePatch':False,'limits':'Actual canonical producer case only. Final ordinary verification, English/Malay CLI and browser trace comparisons are separate.'};(V/'golden111-update-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
