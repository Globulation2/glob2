from pathlib import Path
import subprocess,json,hashlib,time,sys
sys.path.insert(0,'test');from build_provenance import source_identity
R=Path.cwd();V=R/'artifacts/localization-ms/validation';before=source_identity();assert before['revision']=='e18cb7223f2784ff0c952260b26b01fc89af34c2' and not before['dirty'];binary=R/'build/linux/client/debug/dev-dev_fast-true-linker-auto/src/mobile-gallery';sha=hashlib.sha256(binary.read_bytes()).hexdigest();results=[]
for scale,name in [(100,'gallery-final-layout'),(150,'gallery-final-layout-large')]:
 command=[str(V/'venv/bin/python'),str(R/'artifacts/localization-ms/capture-gallery.py'),'--binary',str(binary),'--output',str(V/name),'--modes','game','--workers','2','--text-size',str(scale)];start=time.monotonic()
 with (V/(name+'.log')).open('w') as log:code=subprocess.call(command,stdout=log,stderr=subprocess.STDOUT)
 results.append({'textSizePercent':scale,'command':command,'exitCode':code,'seconds':time.monotonic()-start,'captureManifest':name+'/capture-run.json' if (V/name/'capture-run.json').exists() else None});(V/'gallery-final-layout-run-results.json').write_text(json.dumps({'source':before,'binarySha256':sha,'attempts':results,'limits':'Each gallery task retains its actual return code and captured states. The same late construction-order assertion also observed in English control is not counted as a successful complete gallery run; selected actual topic images can still receive independent visual review.'},indent=2)+'\n');assert source_identity()==before and hashlib.sha256(binary.read_bytes()).hexdigest()==sha
print(json.dumps(results,indent=2),flush=True)
