import original from './web-final-7133.config.mjs';
export default {...original,
projects:original.projects.filter(project=>project.name==='chromium-phone'),
outputDir:'/home/bradley/.codex/worktrees/545f/glob2/artifacts/localization-ms/validation/web-phone-paint-final-results',
};
