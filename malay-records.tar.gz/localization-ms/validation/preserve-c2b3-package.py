import json,hashlib,tarfile,time,shutil
from pathlib import Path
R=Path.cwd();P=R/'artifacts/localization-ms/validation';archive=P/'C2B3-component';archive.mkdir(exist_ok=True);manifest=json.load(open(P/'browser-final-package.json'));assert manifest['source_at_capture']=='c2b3cd5a71af2cfa52345e245c063475003c4577';total=sum(row['bytes'] for row in manifest['package_files']);assert total<=512*1024*1024;assert shutil.disk_usage(P).free>total*2+1024*1024*1024
base=R/'build/emscripten/client/release';target=archive/'release-web-package.tar.gz'
with tarfile.open(target,'w:gz',compresslevel=6) as tar:
 for row in manifest['package_files']:
  f=base/row['path'];assert f.stat().st_size==row['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==row['sha256'],row['path'];tar.add(f,arcname=row['path'],recursive=False)
record={'revision':manifest['source_at_capture'],'files':len(manifest['package_files']),'uncompressed_bytes':total,'archive_bytes':target.stat().st_size,'archive_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'completed_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'status':'Component release package preserved; QA results recorded separately, not evidence for later191 integration'};(archive/'package-preservation.json').write_text(json.dumps(record,indent=2)+'\n');shutil.copyfile(P/'browser-final-package.json',archive/'browser-final-package.json');print(json.dumps(record),flush=True)
