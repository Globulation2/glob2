from pathlib import Path
import json,hashlib,subprocess,datetime,shutil
p=Path('artifacts/localization-ms/validation');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();load=lambda f:json.loads(Path(f).read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='e18cb7223f2784ff0c952260b26b01fc89af34c2';assert not subprocess.check_output(['git','status','--porcelain'],text=True)
pkg=load(p/'browser-master191-package.json');assert pkg['source_at_capture']==head
root=Path('build/emscripten/client/release')
for f in pkg['package_files']:assert (root/f['path']).stat().st_size==f['bytes'] and sha(root/f['path'])==f['sha256'],f['path']
def cases(suites):
 out=[]
 for s in suites:
  out.extend(cases(s.get('suites',[])))
  for spec in s.get('specs',[]):
   for t in spec['tests']:
    r=t['results'][-1];out.append({'title':spec['title'],'project':t['projectName'],'status':r['status'],'durationMs':r['duration'],'errors':[e.get('message','') for e in r.get('errors',[])]})
 return out
groups={}
for name,filename in [('staged','browser-master191-staged-results.json'),('original_persistence','browser-master191-persistence-results.json'),('webkit_supported_software','browser-master191-webkit-software-results.json'),('phone_final','browser-master191-phone-final-results.json'),('canonical','browser-master191-determinism-results.json'),('firefox_visual_controls','browser-master191-visual-extra-results.json')]:
 f=p/filename;d=load(f);groups[name]={'report':str(f),'sha256':sha(f),'stats':d['stats'],'cases':cases(d['suites'])}
assert groups['staged']['stats']['expected']==8 and groups['staged']['stats']['skipped']==1
assert groups['original_persistence']['stats']['expected']==5 and groups['original_persistence']['stats']['unexpected']==1
assert groups['webkit_supported_software']['stats']['expected']==2
assert groups['phone_final']['stats']['expected']==1
assert groups['canonical']['stats']['expected']==6
assert groups['firefox_visual_controls']['stats']['expected']==1 and groups['firefox_visual_controls']['stats']['unexpected']==2
canonical=[]
for f in sorted((p/'browser-master191-match-evidence').rglob('provenance.json')):
 d=load(f);assert d['status']=='passed' and d['exactCanonicalTraceMatch'];assert d['fixtureSha256']=='a7f8d0d3f220c1d51980ea213fb45c8b3d7dc8e99be8e3fcc887578a9ed7cd10'
 assert load(f.parent/'verify-match.verdict.json')['verdict']=='verified';d['provenance']=str(f);d['provenanceSha256']=sha(f);canonical.append(d)
assert len(canonical)==6
visual=[]
for f in sorted((p/'browser-master191-visual-extra-results').rglob('presentation.json')):
 d=load(f);visual.append({'locale':d['locale'],'renderer':d['renderer'],'record':str(f),'sha256':sha(f),'captures':[{'name':c['name'],'colors':c['colors'],'waitMs':c['waitMs'],'elapsedMs':c['elapsedMs'],'effectiveMode':c['diagnostics']['executionMode'],'effectiveRenderer':c['diagnostics']['renderer']} for c in d['captures']]})
soft=next(f for f in (p/'browser-master191-visual-extra-results').rglob('presentation.json') if load(f)['renderer']=='software');spng=soft.parent/'ms-firefox-threaded-settings-settled-7s.png';shutil.copy2(spng,p/'browser-master191-firefox-threaded-software-settings.png')
phone=load(p/'browser-master191-phone-provenance.json');assert phone['locale']=='ms' and phone['navigator']['language']=='ms-MY' and phone['cookie']=='' and phone['dpr']==2 and phone['overflow']==0
persist=load(p/'browser-master191-persistence-provenance.json');assert len(persist['cases'])==6
summary={'owner':'cloud_tooling','finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tested_revision':head,'working_tree_clean':True,'source_sha256':'822cf8613451177b0e2fa803451eaf2308168f21f4d04b7af2aa36cfe64bc3fc','status':'completed; supported release paths pass, explicit shared headless worker-WebGL visual limit retained','release_package':{'receipt':str(p/'browser-master191-package.json'),'sha256':sha(p/'browser-master191-package.json'),'file_count':len(pkg['package_files']),'bytes':sum(f['bytes'] for f in pkg['package_files']),'all_file_hashes_rechecked_after_qa':True,'initial_producer_revision':'11d72bf8c881b5db07c33feaa251aef326c15c84','final_refresh':str(p/'browser-master191-refresh-result.json'),'final_refresh_sha256':sha(p/'browser-master191-refresh-result.json'),'ui_cpp_changed_and_explicitly_rebuilt_both_variants':True},'groups':groups,'actual_persistence':persist,'canonical_six_cases':canonical,'phone':{'provenance':str(p/'browser-master191-phone-provenance.json'),'sha256':sha(p/'browser-master191-phone-provenance.json'),'screenshot':str(p/'browser-master191-phone-dpr2-settings.png'),'screenshot_sha256':sha(p/'browser-master191-phone-dpr2-settings.png'),'visual_inspection':'Actual 390x844 DPR2 Settings canvas: readable Malay wrapping, controls and Selesai footer visible; normal vertical scroll-region clipping; no missing glyphs or horizontal overflow. Audio and hand preference screens driven by real taps before introduction/menu; navigator ms-MY selected Malay without cookie.'},'firefox_visual_controls':visual,'firefox_supported_visual':{'screenshot':str(p/'browser-master191-firefox-threaded-software-settings.png'),'sha256':sha(p/'browser-master191-firefox-threaded-software-settings.png'),'inspection':'Actual threaded software renderer Malay Settings is visibly readable, control captions and descriptions fit, no missing glyphs or horizontal text clipping.'},'limitations_and_preserved_failures':[
'Firefox155 headless threaded WebGL2 screenshots remain uniform background after real Settings interaction and bounded7s waits, both Malay and exact same-source/binary English control. These two pixel assertions failed and are retained; no claim that default worker-WebGL visual output was verified. Actual threaded software Malay Settings pixels pass. Precise compositor/rendering cause not established.',
'WebKit26.6 default threaded route falls back to serial with literal reason worker shared memory unavailable. Isolated/SAB/OffscreenCanvas available; webgl2 worker probe fails, software probe passes. Actual supported software-threaded UI-save/reload passed with strict effective-mode guard. Stock staged names indicate requested variants only.',
'One stock Firefox direct-preference-write download-gate test intentionally skipped; actual game Settings durable-save/reload tests passed in both effective variants.',
'Two older0ab Chromium cold-start readiness timeouts retained under MASTER191-before-overview-fix as genuine failures. Final e18 first-visits passed with a bounded120s local helper budget and unchanged stock input/assertions; per-call actual timings logged.',
'Initial copied-test module-scope configuration failure retained under MASTER191-harness-module-scope-failure; no product tests executed in that attempt.',
'Original phone intro-only harness timed out on legitimate Malay audio onboarding, retained under MASTER191-phone-unhandled-audio-onboarding. Audio-only replacement was explicitly interrupted when next hand-preference state was identified. Final actual audio+hand+intro flow passed; no shipping change needed.',
'Browser testing covers Linux headless installed Chromium153/Firefox155/WebKit26.6 releases and browser engine Wasm variants, not physical mobile devices or other host operating systems.'
],'readiness_adaptation':str(p/'browser-master191-readiness-adaptation.json')}
(p/'browser-master191-runtime-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'summary':str(p/'browser-master191-runtime-summary.json'),'sha256':sha(p/'browser-master191-runtime-summary.json'),'package_files':len(pkg['package_files']),'canonical_cases':len(canonical),'actual_persistence_cases':len(persist['cases']),'final_phone':groups['phone_final']['stats']},indent=2))
