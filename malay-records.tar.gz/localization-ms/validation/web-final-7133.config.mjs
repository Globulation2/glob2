import original from './web-cross-browser.config.mjs';
export default {...original,
use:{...original.use,actionTimeout:30000},
testDir:'/home/bradley/.codex/worktrees/545f/glob2/artifacts/localization-ms/validation',
testMatch:'web-final-supplement.spec.ts',
outputDir:'/home/bradley/.codex/worktrees/545f/glob2/artifacts/localization-ms/validation/web-final-72433-results',
webServer:{...original.webServer,command:'PATH=/usr/lib/chatgpt/resources/cua_node/bin:$PATH node /home/bradley/.codex/worktrees/545f/glob2/artifacts/localization-ms/validation/server-final-7133.ts'},
};
