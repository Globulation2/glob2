import json,hashlib,subprocess
from pathlib import Path
from PIL import Image
v=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
observations={
(100,'desktop','overview'):'Gambaran keseluruhan wraps cleanly at the word boundary into two lines in the narrow overview tab. Koloni/Populasi, growth reading, Buka sejarah penuh, food/wellbeing labels and Kerja & pembinaan visible without overlap.',
(100,'desktop','colony'):'All five topic labels fit. Pergerakan darat, Unit yang dilahirkan/hilang, Pertumbuhan populasi and Pertukaran pihak bersih remain legible; longer value placement wraps to next line within sidebar.',
(100,'desktop','economy'):'Bagaimana pekerja menghabiskan masa mereka wraps into three readable lines; 24.2% sits below without collision. Idle-worker, workload and carrying labels visible with coherent word wraps.',
(100,'desktop','military'):'Attack/defence/hitpoint/damage readings fit; Unit yang terkorban dalam pertempuran wraps at word boundaries. No text overlaps values.',
(100,'desktop','world'):'Pertumbuhan sumber berhampiran koloni and merentasi peta wrap coherently; rates, immobilized-unit percentage and cleared resources remain readable. Graph content below belongs to scroll region.',
(100,'phone','overview'):'Gambaran keseluruhan fits one line in first tab. Two topic rows and initial population/growth readings are unobscured; lower chart is outside visible scroll viewport.',
(100,'phone','colony'):'All five topic labels fit; Populasi, Pergerakan darat and Unit yang dilahirkan with their readings visible and separated from bottom toolbar.',
(100,'phone','economy'):'Long worker-time description fits on one line with24.2% at right; idle-worker and workload readings visible, no overlap.',
(100,'phone','military'):'Topic labels and Kekuatan serangan/pertahanan/Jumlah mata ketahanan readings fit across sheet, with values right-aligned.',
(100,'phone','world'):'Long nearby-colony and map-wide resource-growth labels fit on single lines with rates at right; immobilized-unit row remains readable above bottom toolbar.',
(150,'desktop','overview'):'Overview button breaks mid-word into Gambara / n / keseluruh / an over four lines. No glyph loss or overlap, but poor readability. Population growth wraps to two word-bounded lines; full-history button fits.',
(150,'desktop','colony'):'Same four-line mid-word overview-tab defect remains visible. Colony rows wrap at word boundaries and numbers sit on following lines without collision. Scroll region limits content shown.',
(150,'desktop','economy'):'Same overview-tab mid-word defect. Worker-time description wraps into Bagaimana / pekerja / menghabiskan / masa mereka, with24.2% on own line; idle-worker/workload labels wrap coherently.',
(150,'desktop','military'):'Same overview-tab mid-word defect. Attack/defence/hitpoint labels wrap into ordinary words with separated values; bottom damage row continues beyond scroll viewport rather than overlapping footer.',
(150,'desktop','world'):'Same overview-tab mid-word defect. Nearby-colony resource-growth label occupies four word-bounded lines and value sits below; map-wide label wraps into three lines; remaining content is scroll-clipped normally.',
(150,'phone','overview'):'Gambaran / keseluruhan wraps into two complete words, with no mid-word split. Population and population-growth rows remain visible; chart below viewport.',
(150,'phone','colony'):'Five topic labels fit, overview in two complete-word lines; Populasi and Pergerakan darat readings remain separated and legible.',
(150,'phone','economy'):'Worker-time description wraps into two complete-word lines, with24.2% right-aligned inside expanded row; no collision with label or bottom toolbar.',
(150,'phone','military'):'Topic labels fit; attack and defence labels/readings remain legible on single lines. Additional rows are below the reduced scroll viewport.',
(150,'phone','world'):'Nearby-colony resource growth wraps before koloni into two complete-word lines;1236/min remains right-aligned with enough space. Lower rows are outside scroll viewport.'}
records=[];bindings=[]
for n,percent in [('gallery-191',100),('gallery-191-large',150)]:
 root=v/n;mp=root/'capture-run.json';m=json.loads(mp.read_text());assert m['revision']=='0ab1c502952e3d81416ab985d9ff235e13683735'
 binding={'path':str(mp),'sha256':sha(mp.read_bytes()),'source_identity':m['source_identity'],'binary':m['binary'],'binary_sha256':m['binary_sha256'],'jobs':[]}
 for surface in ['desktop','phone']:
  j=next(j for j in m['jobs'] if j['label']=='game-'+surface);assert j['source_and_binary_stable'] and j['text_size_percent']==percent
  log=root/j['label']/'capture.log';logtext=log.read_text();prefs=root/j['label']/'profile/preferences.txt';pt=prefs.read_text();assert 'language=ms' in pt and 'textSizePercent='+str(percent) in pt
  binding['jobs'].append({'label':j['label'],'returncode':j['returncode'],'text_size_percent':percent,'source_and_binary_stable':True,'capture_log_sha256':sha(log.read_bytes()),'profile_preferences_sha256':sha(prefs.read_bytes()),'preference_language':'ms'})
  for topic in ['overview','colony','economy','military','world']:
   rel=j['label']+'/game-statistics-topic-'+topic+'.png';f=root/rel;actual=sha(f.read_bytes());assert next(x['sha256'] for x in j['images'] if x['path']==rel)==actual;assert 'CAPTURE game-statistics-topic-'+topic+' ' in logtext
   records.append({'path':str(f),'sha256':actual,'dimensions':list(Image.open(f).size),'text_size_percent':percent,'surface':surface,'topic':topic,'reviewer':'malay_adversary','actual_pixels_inspected':True,'observation':observations[(percent,surface,topic)],'result':'readability_issue' if percent==150 and surface=='desktop' else 'visible_content_acceptable'})
 bindings.append(binding)
control=v/'gallery-191-english-control/capture-run.json';cm=json.loads(control.read_text());cj=cm['jobs'][0];cl=v/'gallery-191-english-control/game-phone/capture.log';assert cj['returncode']==1 and cm['binary_sha256']==bindings[0]['binary_sha256'];assert 'Gesture fixture did not produce exactly one construction order' in cl.read_text()
rev='0ab1c502952e3d81416ab985d9ff235e13683735';catalog=subprocess.check_output(['git','show',rev+':data/texts.ms.txt'])
r={'identity':'malay_adversary','scope':'Actual pixel review of20 requested statistics-topic images, five topics times desktop/compact-phone times100/150% text. Only visible screenshot content assessed; no full gallery success claim.','bindings':bindings,'source_catalog':{'revision':rev,'path':'data/texts.ms.txt','sha256':sha(catalog)},'images':records,'findings':[{'severity':'minor','surface':'desktop','text_size_percent':150,'affected_images':5,'observation':'Gambaran keseluruhan breaks mid-word into Gambara/n/keseluruh/an in the half-width topic button. It is fully present but hard to read.','reported_to_root_before_edit_proposal':True,'status':'open','source_edits_made':False}],'gesture_limit':{'ms_phone_job_returncodes':[1,1],'english_control_manifest_sha256':sha(control.read_bytes()),'english_control_log_sha256':sha(cl.read_bytes()),'same_binary':True,'english_phone_job_returncode':1,'same_terminal_assertion':'Gesture fixture did not produce exactly one construction order','interpretation':'All requested topic states were captured earlier. Same-binary English also reaches the late gesture assertion, so failure is not exclusive to Malay; underlying cause remains unproven. These earlier images remain usable visual evidence. Full phone gallery did not pass.'},'limits':['Linux software/dummy SDL presentation captures; compact phone is not Android/iOS device execution.','No interaction/scrollability claims from screenshots alone.','No source, binary, capture or runtime mutations performed by this reviewer.']}
(v/'native191-statistics-topic-visual-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print('Recorded',len(records),'images; one shared desktop150% readability finding; phone gesture failure independently reproduced in English manifest/log.')
