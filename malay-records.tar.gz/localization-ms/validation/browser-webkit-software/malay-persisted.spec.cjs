const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const {test,expect} = require('@playwright/test');
const root = path.resolve(__dirname,'../../../..');
const {gameURL,waitForMainMenu,clickMainMenu,clickSettingsDone} = require(path.join(root,'browser/tests/main-menu'));
for (const variant of ['serial','threaded']) {
  test(`Malay natural saved preference survives English launcher reload (${variant})`,async ({page,browser,browserName},info) => {
    const base=String(info.project.use.baseURL);
    await page.context().addCookies([{name:'glob2_locale',value:'ms',url:base}]);
    const url=new URL(gameURL(),base);
    url.searchParams.set('threads',variant);url.searchParams.set('renderer','software');
    await page.goto(url.pathname+url.search);
    await waitForMainMenu(page,{timeout:120000});
    expect(await page.evaluate(()=>Module.executionMode)).toBe(variant);
    const expectedNative=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'data/texts.ms.txt'))).digest('hex');
    const runtimeNative=await page.evaluate(()=>FS.readFile('/data/texts.ms.txt',{encoding:'utf8'}));
    const actualNative=crypto.createHash('sha256').update(runtimeNative,'utf8').digest('hex');
    expect(actualNative).toBe(expectedNative);
    const labels=()=>page.evaluate(()=>Object.values(glob2Diagnostics.snapshot().controls).map(x=>x.label));
    await expect.poll(labels,{timeout:60000}).toContain('Tetapan');
    // Closing the real settings screen uses the game's own durable save path.
    await clickMainMenu(page,'settings');
    await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().screen)).toContain('SettingsScreen');
    await clickSettingsDone(page);
    await waitForMainMenu(page,{timeout:120000});
    // Observe the game's own preference write; never fabricate its language setting.
    await expect.poll(()=>page.evaluate(()=>{
      const name='/home/web_user/.glob2/preferences.txt';
      return FS.analyzePath(name).exists?FS.readFile(name,{encoding:'utf8'}):'';
    }),{timeout:60000}).toContain('language=ms\n');
    await page.waitForTimeout(1500);
    await page.context().clearCookies();
    await page.reload();
    await waitForMainMenu(page,{timeout:120000});
    await expect.poll(()=>page.evaluate(()=>Glob2I18n.getLocale())).toBe('en');
    await expect.poll(labels,{timeout:60000}).toContain('Tetapan');
    await page.screenshot({path:info.outputPath(`ms-${variant}-persisted.png`)});
    const record=await page.evaluate(()=>({
      executionMode:Module.executionMode,threadFallback:Module.threadFallback,locale:Glob2I18n.getLocale(),runtime:glob2Diagnostics.snapshot(),
      preferences:FS.readFile('/home/web_user/.glob2/preferences.txt',{encoding:'utf8'}),
    }));
    const provenance=JSON.stringify({...record,nativeMalaySha256:actualNative,browserName:info.project.name,browserVersion:browser.version(),nodeVersion:process.version},null,2);
    fs.writeFileSync(info.outputPath('natural-persistence.json'),provenance+'\n');
    await info.attach('natural-persistence.json',{body:provenance,contentType:'application/json'});
  });
}
