import {chromium} from '/home/bradley/.codex/worktrees/545f/glob2/platform/node_modules/playwright/index.mjs';
import {readFileSync,writeFileSync} from 'node:fs';
const root='/home/bradley/.codex/worktrees/545f/glob2';
const output=root+'/artifacts/localization-ms/validation';
const ms=JSON.parse(readFileSync(root+'/platform/packages/i18n/locales/ms.json','utf8'));
const base='http://127.0.0.1:4285';
const seed=await(await fetch(base+'/__seed')).json();
const browser=await chromium.launch({headless:true});
try{
 const context=await browser.newContext({viewport:{width:393,height:727}});
 await context.addCookies([{name:'glob2_locale',value:'ms',url:base},{name:'glob2_session',value:seed.userSession,url:base}]);
 const page=await context.newPage();
 page.setDefaultTimeout(60000);
 await page.goto(base+'/skins');
 await page.getByRole('button',{name:ms['New skin'],exact:true}).focus();
 await page.getByRole('button',{name:ms['New skin'],exact:true}).press('Enter');
 await page.getByRole('button',{name:ms['Material'],exact:true}).click();
 await page.getByRole('radiogroup',{name:ms['Material']}).first().waitFor();
 const bounds=await page.locator('.skin-tool-options').evaluate(el=>{
   const rect=node=>{const r=node.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom};};
   return{toolbox:rect(el.closest('.skin-toolbox')),options:rect(el),children:[...el.children].map(child=>({className:child.className,rect:rect(child),display:getComputedStyle(child).display,alignSelf:getComputedStyle(child).alignSelf})),buttons:[...el.querySelectorAll('.skin-segment button')].map(button=>{const range=document.createRange();range.selectNodeContents(button);return{text:button.textContent,rect:rect(button),textRect:rect(range),visible:getComputedStyle(button).visibility};})};
 });
 writeFileSync(output+'/paint-mode-diagnostic-before.json',JSON.stringify(bounds,null,2)+'\n');
 await page.screenshot({path:output+'/paint-mode-diagnostic-before.png',fullPage:true});
}finally{await browser.close();}
