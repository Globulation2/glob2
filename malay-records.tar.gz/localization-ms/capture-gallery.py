"""Isolated Malay editor/generator/inspector captures; native Linux only."""
import argparse,hashlib,json,os,subprocess,time,importlib.util
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from PIL import Image
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--modes',default='editor,generators,game');p.add_argument('--viewports',default='desktop,phone');p.add_argument('--workers',type=int,default=2);p.add_argument('--text-size',type=int,default=100);p.add_argument('--locale',choices=['ms','en'],default='ms');a=p.parse_args();assert a.text_size in [100,150];root=Path.cwd();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);base=root/'artifacts/localization-ms/validation';binary=a.binary.resolve()
spec=importlib.util.spec_from_file_location('capture_provenance',root/'test/build_provenance.py');provenance=importlib.util.module_from_spec(spec);spec.loader.exec_module(provenance);frozen=provenance.source_identity(root)
report={'source_identity':frozen,'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'jobs':[],'limits':['Actual Linux run. Compact phone presentation is not Android/iOS execution.']}
def run(job):
 before=provenance.source_identity(root);binary_before=hashlib.sha256(binary.read_bytes()).hexdigest()
 if before!=frozen or binary_before!=report['binary_sha256']:raise RuntimeError('Source or gallery producer changed before capture')
 mode,name,w,h=job;label=mode+'-'+name;directory=out/label;directory.mkdir(parents=True,exist_ok=True);profile=directory/'profile';profile.mkdir(exist_ok=True);(profile/'preferences.txt').write_text(f'language={a.locale}\ntextSizePercent={a.text_size}\n');
 if mode=='generators':
  fixture=base/'gallery-swamp-library-fixture.json';(profile/'generators').mkdir(exist_ok=True);(profile/'generators/library.json').write_bytes(fixture.read_bytes())
 env=dict(os.environ,SDL_VIDEO_DRIVER='dummy',SDL_VIDEODRIVER='dummy',SDL_AUDIO_DRIVER='dummy',SDL_RENDER_DRIVER='software',SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(profile));env['GLOB2_GALLERY_'+mode.upper()+'_ONLY']='1';env['LD_LIBRARY_PATH']=':'.join([str(base/'sdl3/prefix/lib'),str(base/'recording/prefix/lib'),env.get('LD_LIBRARY_PATH','')]);cmd=[str(binary),str(w),str(h),'desktop' if name=='desktop' else 'compact'];start=time.monotonic()
 with (directory/'capture.log').open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
 images=[]
 for source in profile.rglob('*.bmp'):
  target=directory/(source.stem+'.png')
  with Image.open(source) as image:image.save(target)
  images.append({'path':str(target.relative_to(out)),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
 after=provenance.source_identity(root);binary_after=hashlib.sha256(binary.read_bytes()).hexdigest()
 return {'source_before':before,'source_after':after,'binary_before':binary_before,'binary_after':binary_after,'source_and_binary_stable':before==after and binary_before==binary_after,'label':label,'command':cmd,'returncode':r.returncode,'text_size_percent':a.text_size,'locale':a.locale,'seconds':round(time.monotonic()-start,2),'images':images,'environment':{k:v for k,v in env.items() if k.startswith('GLOB2_GALLERY_') or k in ['GLOB2_USER_DATA_DIR','SDL_VIDEODRIVER','SDL_RENDER_DRIVER']}}
jobs=[(mode,name,w,h) for mode in a.modes.split(',') for name,w,h in [('desktop',1280,800),('phone',844 if mode=='game' else 390,390 if mode=='game' else 844)] if name in a.viewports.split(',')]
failed=0
with ThreadPoolExecutor(max_workers=a.workers) as pool:
 for future in as_completed([pool.submit(run,j) for j in jobs]):
  result=future.result();report['jobs'].append(result);(out/'capture-run.json').write_text(json.dumps(report,indent=2)+'\n');print(result['label'],result['returncode'],len(result['images']),flush=True)
  if result['returncode'] or not result['source_and_binary_stable']:failed=result['returncode'] or 99
raise SystemExit(failed)
