import json,re,importlib.util,hashlib
from pathlib import Path
R=Path.cwd();P=R/'artifacts/localization-ms/ai-tags';proposal=json.load(open(P/'proposal.json'));initial=json.load(open(P/'initial-draft.json'))
s=importlib.util.spec_from_file_location('program',R/'tools/localization/translation_program.py');M=importlib.util.module_from_spec(s);s.loader.exec_module(M)
mapcodes=dict(re.findall(r"code:\s*'([^']+)'\s*,\s*gameCode:\s*'([^']+)'",(R/'platform/packages/i18n/src/locales.ts').read_text()))
rush={'ar':'هجوم مبكر','pt-BR':'Ataque inicial','ca':'Atac inicial','cs':'Časný útok','de':'Früher Angriff','da':'Tidligt angreb','es':'Ataque temprano','eo':'Frua atako','eu':'Eraso goiztiarra','fa':'حملهٔ زودهنگام','fr':'Attaque précoce','el':'Πρώιμη επίθεση','hu':'Korai támadás','it':'Attacco iniziale','nl':'Vroege aanval','pl':'Wczesny atak','pt-PT':'Ataque inicial','ro':'Atac timpuriu','ru':'Ранняя атака','sl':'Zgodnji napad','sk':'Skorý útok','sr-Cyrl':'Рани напад','fi':'Varhainen hyökkäys','sv':'Tidig attack','tr':'Erken saldırı','zh-Hant':'速攻型','zh-Hans':'速攻型','uk':'Рання атака','id':'Serangan awal','vi':'Tấn công sớm','ja':'速攻','ko':'속공형','hi':'शुरुआती हमला','ur':'ابتدائی حملہ','sw':'Shambulio la mapema','ms':'Serangan pantas'}
overrides={
 'pt-BR':{'Defensive':'Defensivo','Beginner-friendly':'Adequado para iniciantes'},
 'pt-PT':{'Defensive':'Defensivo','Beginner-friendly':'Adequado para principiantes'},
 'ca':{'Defensive':'Defensiu','Beginner-friendly':'Apte per a principiants'},
 'cs':{'Defensive':'Obranné'},
 'es':{'Defensive':'Defensivo','Beginner-friendly':'Apto para principiantes'},
 'fa':{'Expansion':'گسترش قلمرو'},
 'fr':{'Defensive':'Défensif','Experimental':'Expérimental','Beginner-friendly':'Adapté aux débutants'},
 'el':{'Defensive':'Αμυντικό','Experimental':'Πειραματικό','Beginner-friendly':'Κατάλληλο για αρχάριους'},
 'it':{'Defensive':'Difensivo','Beginner-friendly':'Adatto ai principianti'},
 'pl':{'Defensive':'Obronny','Experimental':'Eksperymentalny'},
 'ro':{'Defensive':'Defensiv','Experimental':'Experimental','Beginner-friendly':'Potrivit pentru începători'},
 'ru':{'Expansion':'Расширение'},
 'sl':{'Defensive':'Obrambno','Experimental':'Poskusno'},
 'sk':{'Defensive':'Obranné','Experimental':'Experimentálne'},
 'uk':{'Expansion':'Розширення'},
 'ms':{'Defensive':'Bertahan'},
}
translations={};refs={};edits=[]
for locale in initial['translations']:
 path=R/'data'/f'texts.{mapcodes[locale]}.txt';native,_=M.CHECKER.read_table(path)
 final={k:native['['+k+']'] for k in initial['keys']};final['Rush']=rush[locale];final.update(overrides.get(locale,{}));translations[locale]=final
 refs[locale]={'path':str(path.relative_to(R)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'balanced':json.load(open(R/f'platform/packages/i18n/locales/{locale}.json'))['Balanced']}
 for key,value in final.items():
  if not value.strip():raise ValueError((locale,key))
  before=initial['translations'][locale][key]
  if before!=value:edits.append({'locale':locale,'key':key,'initial':before,'value':value,'reason':('Use early military-attack meaning, not haste or the rush plant.' if key=='Rush' else 'Align the AI strategy category with native gameplay terminology and the existing Balanced register/gender; avoid literal or grammatical machine errors.')})
record={'author':'cloud_tooling','role':'author','source_sha256':initial['source_sha256'],'initial_draft_sha256':hashlib.sha256((P/'initial-draft.json').read_bytes()).hexdigest(),'context':proposal['context'],'translations':translations,'references':refs,'authored_keys':[locale+':'+key for locale in translations for key in initial['keys']],'edits':edits,'unresolved_uncertainty':[],'limitations':['Agent author reconciliation, not native-human certification. Independent semantic, editorial and adversarial reviews still required.']}
(P/'authored-tags.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
(P/'authored.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print('Authored',len(record['authored_keys']),'edits',len(edits))
