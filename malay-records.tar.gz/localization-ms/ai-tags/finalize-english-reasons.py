import json
from pathlib import Path
P=Path(__file__).resolve().parent;a=json.load(open(P/'authored-final.json'));langs={'pt-BR':'Brazilian Portuguese','ca':'Catalan','cs':'Czech','de':'German','da':'Danish','es':'Spanish','fr':'French','it':'Italian','nl':'Dutch','pl':'Polish','pt-PT':'European Portuguese','ro':'Romanian','sl':'Slovenian','sk':'Slovak','sv':'Swedish','tr':'Turkish','id':'Indonesian','sw':'Swahili','ms':'Malay'}
reasons={
'Expansion':'The established noun for expansion also denotes territorial growth in this AI strategy tag; the spelling is shared with English.',
'Experimental':'The standard adjective for an experimental controller has this spelling in the target language and fits the AI category.',
'Metal':'This is the ordinary target-language material noun for metal, appropriate to the metallic skin group.',
'Mineral':'This is the ordinary target-language noun for a mineral, appropriate to the stone/crystal material group.',
'Lava':'This is the established target-language term for lava and agrees with the existing native terrain label.',
'Coral':'This is the target-language noun for coral, matching the physical branching coral shape rather than a proper name.',
'Finances':'This is the ordinary plural noun for finances used for the administration finance tab.',
'Audit':'This is an established target-language administrative/technical audit noun, used here for the audit tab rather than a verb.',
'Chrome':'French “chrome” names the chromium material/finish; it is a translated material name, not the browser brand.',
'Cartoon':'Dutch uses the established loanword “cartoon” for this drawn visual style.',
'Accounts':'Dutch uses “accounts” for online user accounts; this is the account-administration tab rather than financial ledgers.',
'Organic':'Romanian “organic” is the standard adjective for organic appearance, agreeing with the material group.',
'1 week':'Dutch uses “week” for the duration unit, so the numeral and noun happen to match English exactly.'}
rows=[]
for locale,values in a['translations'].items():
 for key,value in values.items():
  if key==value:
   assert locale in langs and key in reasons,(locale,key)
   rows.append({'locale':locale,'key':key,'value':value,'reason':langs[locale]+': '+reasons[key]})
(P/'author-accepted-english-final.json').write_text(json.dumps({'author':'cloud_tooling','role':'author','source_sha256':a['source_sha256'],'entries':rows},ensure_ascii=False,indent=2)+'\n');print(len(rows),'individual retentions')
