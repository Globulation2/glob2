import json,sys,pathlib
p=pathlib.Path(__file__).resolve().parent;d=json.load(open(p/'authored-final.json'))
for l in sys.argv[1:]:
 print('LOCALE',l)
 for i,(k,v) in enumerate(d['translations'][l].items()):print(str(i)+' '+v)
