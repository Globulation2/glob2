import json,hashlib,importlib.util
from pathlib import Path
R=Path.cwd();P=R/'artifacts/localization-ms/ai-tags';old=R/'artifacts/localization-ms';new=R/'artifacts/localization-ms-final'
spec=importlib.util.spec_from_file_location('program',R/'tools/localization/translation_program.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
def read(p):return json.load(open(p))
def h(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
records=[];keys=[]
for surface in ['native','online']:
 s=read(old/'source'/f'{surface}.json');n=read(new/'source'/f'{surface}.json')
 if surface=='native':
  a,_=M.CHECKER.read_table(old/'drafts/ms/texts.ms.txt');b,_=M.CHECKER.read_table(new/'drafts/ms/texts.ms.txt')
 else:a=read(P/'malay-before.json');b=read(new/'drafts/ms/ms.json')
 assert all(n[k]==v for k,v in s.items());assert all(b[k]==a[k] for k in s)
 keys.extend(surface+':'+k for k in s);records.append({'surface':surface,'count':len(s),'source_subset_sha256':h(s),'target_subset_sha256':h({k:a[k] for k in s}),'source_unchanged':True,'target_unchanged':True})
q=read(P/'proposal.json');assert len(keys)==6229
out={'identity':'cloud_tooling','role':'author','authorized_carryforward':True,'original_source_sha256':q['original_source_sha256'],'new_source_sha256':q['new_source_sha256'],'original_authored_keys':keys,'records':records,'new_keys_not_in_carryforward':q['keys'],'scope':'Carry forward my original author reconciliation only for the 6,229 exactly unchanged English/Malay source/target pairs independently compared here; new 95 labels are separately authored against their final input. This is not a new review of old text and not semantic/editor/adversarial approval.'}
(P/'author-carryforward-final.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(records)
