import importlib.util,json,hashlib
from pathlib import Path
R=Path.cwd();P=R/'artifacts/localization-ms/ai-tags';proposal=json.loads((P/'proposal.json').read_text())
s=importlib.util.spec_from_file_location('cloud',R/'tools/localization/cloud_draft.py');C=importlib.util.module_from_spec(s);s.loader.exec_module(C)
keys=proposal['keys'];locales=[locale for locale in proposal['locales'] if locale not in ('en','ms')]
assert len(locales)==35 and len(keys)==6
aliases={'pt-BR':'pt','zh-Hans':'zh-CN','zh-Hant':'zh-TW','sr-Cyrl':'sr'}
project='bradley-personal-20261027';rows={};records={}
for locale in locales:
 body=C.payload(project,aliases.get(locale,locale),keys)
 identity={'source_sha256':proposal['new_source_sha256'],'locale':locale,'request':body}
 path=P/'provider-records'/f'{locale}.json'
 if path.exists():
  data=json.loads(path.read_text());assert data['identity']==identity
 else:
  data={'identity':identity,'response':C.translate(project,body)};C.atomic_json(path,data)
 values=data['response'].get('translations',[])
 if len(values)!=6 or any(not isinstance(v,dict) or not isinstance(v.get('translatedText'),str) or not v['translatedText'].strip() for v in values):raise ValueError('Malformed response: '+locale)
 rows[locale]={key:C.restore(value['translatedText'],{}) for key,value in zip(keys,values)}
 records[locale]={'path':str(path.relative_to(R)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 print(locale,flush=True)
ms=json.loads((R/proposal['refresh_kit']/'drafts/ms/ms.json').read_text());rows['ms']={k:ms[k] for k in keys}
for path in sorted((R/proposal['refresh_kit']/'cloud/ms').glob('*.json')):
 if path.name=='summary.json':continue
 records['ms']={'path':str(path.relative_to(R)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
C.atomic_json(P/'initial-draft.json',{'source_sha256':proposal['new_source_sha256'],'project':project,'model':'general/nmt','source_language':'en','target_aliases':aliases,'keys':keys,'provider_records':records,'translations':rows})
print('Complete',sum(len(v) for v in rows.values()),flush=True)
