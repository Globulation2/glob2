import json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;R=Path.cwd()
def read(name):return json.load(open(P/name))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def subset(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(name,value):(P/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
q=read('proposal.json');raw=read('initial-draft-final.json');tags=read('authored-tags.json');fixed=read('author-fixed-edits.json');last=read('author-final-edits.json');ms75=read('ms-author-fixed.json')['translations'];ms14=read('ms-author-final.json')['translations'];locales=list(raw['translations']);assert len(locales)==36 and len(raw['keys'])==95
assert set(read('author-fixed-read-locales.json'))==set(locales)
assert set(read('author-final-read-locales.json'))==set(locales)
translations={};edits=[];records=[]
for locale in locales:
 a=dict(raw['translations'][locale]);a.update(tags['translations'][locale]);a.update({q['phase_two_keys'][int(i)]:v for i,v in fixed.get(locale,{}).items()});a.update({q['phase_three_keys'][int(i)]:v for i,v in last.get(locale,{}).items()})
 if locale=='ms':a.update(ms75);a.update(ms14)
 assert set(a)==set(raw['keys']) and all(isinstance(v,str) and v.strip() for v in a.values())
 translations[locale]=a
 records.append({'locale':locale,'authored_keys':list(a),'source_subset_sha256':subset({k:k for k in a}),'initial_target_subset_sha256':subset(raw['translations'][locale]),'authored_target_subset_sha256':subset(a),'references':{'native_exact_sha256':sha(P/'native-exact-references.json'),'online_catalog_sha256':sha(R/f'platform/packages/i18n/locales/{locale}.json')}})
 for key,value in a.items():
  before=raw['translations'][locale][key]
  if before!=value:edits.append({'locale':locale,'key':key,'initial':before,'value':value,'reason':('Reconcile with AI strategy, validator, networking, physical appearance, musical-listening, administration, server-verification or animation-preview context and existing native/platform terminology; correct context-dependent NMT sense or grammar.')})
identical={l:[k for k,v in a.items() if k==v] for l,a in translations.items()}
write('authored-final.json',{'author':'cloud_tooling','role':'author','source_sha256':q['new_source_sha256'],'initial_draft_sha256':sha(P/'initial-draft-final.json'),'translations':translations,'authored_keys':[l+':'+k for l in locales for k in raw['keys']],'locale_records':records,'edits':edits,'contexts':q['contexts'],'input_records':{n:sha(P/n) for n in ['initial-draft.json','initial-draft-fixed.json','initial-draft-final.json','authored-tags.json','author-fixed-edits.json','author-final-edits.json','ms-author-fixed.json','ms-author-final.json']},'limitations':['Agent author reconciliation across all 36 target locales; not native-human certification. Separate semantic, editorial and adversarial reviews remain required.','Existing unrelated translations were used as references and were not rewritten. Some old non-Malay music mood labels are awkward; new guidance quotes the existing displayed names so users can identify the actual controls.'],'unresolved_uncertainty':[]})
write('author-english-identities-final.json',identical)
print('Authored',sum(map(len,translations.values())),'values;',len(edits),'context corrections;',sum(map(len,identical.values())),'English identities')
