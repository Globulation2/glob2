import json,hashlib,sys
from pathlib import Path
r=Path(__file__).resolve().parent;d=json.loads((r/'authored-final.json').read_text());keys=json.loads((r/'proposal.json').read_text())['keys'];loc=sys.argv[2]
if sys.argv[1]=='show':
 for l in sys.argv[2:]:
  print('LOCALE',l)
  for i,k in enumerate(keys):print(f'{i}:{d["translations"][l][k]}')
elif sys.argv[1]=='mark':
 p=r/'adversarial-final.json';v=json.loads(p.read_text()) if p.exists() else {'adversarial_reviewer':'malay_online_adversary','role':'independent fourth supplemental review','source_sha256':d['source_sha256'],'author_input_sha256':hashlib.sha256((r/'authored-final.json').read_bytes()).hexdigest(),'locale_records':[],'proposals':[],'unresolved_uncertainty':[],'certification':'Agent-reviewed; not native-human-certified'}
 for l in sys.argv[2:]:
  v['locale_records']=[x for x in v['locale_records'] if x['locale']!=l]+[{'locale':l,'adversarial_reviewed_keys':keys,'target_sha256':hashlib.sha256(json.dumps(d['translations'][l],ensure_ascii=False,sort_keys=True).encode()).hexdigest()}]
 p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
elif sys.argv[1]=='edit':
 p=r/'adversarial-final.json';v=json.loads(p.read_text());k=keys[int(sys.argv[3])];v['proposals']=[x for x in v['proposals'] if not(x['locale']==loc and x['key']==k)]+[{'locale':loc,'key':k,'old_value':d['translations'][loc][k],'value':sys.argv[4],'reason':sys.argv[5],'severity':'minor'}];p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
