import json,copy,hashlib,pathlib
p=pathlib.Path(__file__).parent
read=lambda f:json.loads((p/f).read_text())
a=read('authored-final.json'); out=copy.deepcopy(a['translations']); accepted={}; rejected=[]
for role,edits in [('semantic',read('semantic-edits.json')),('editor',read('editor-final.json')['edits']),('adversarial',read('adversarial-final.json')['proposals'])]:
 for e in edits:
  loc,key=e['locale'],e['key'];old=e.get('old',e.get('old_value'));assert a['translations'][loc][key]==old
  if role=='semantic' and key=='This match is not checked.':
   rejected.append(dict(e,decision='Rejected: not_applicable, distinct from pending; retain author policy semantics.'));continue
  val=e['value']
  if loc=='ro' and key.startswith('Your input delay:'):val=read('editor-context-resolution.json')['romanian_resolution']['value']
  k=(loc,key)
  if k in accepted:assert accepted[k]['value']==val
  else:accepted[k]={'locale':loc,'key':key,'old':old,'value':val,'reviewers':[],'reasons':[]}
  accepted[k]['reviewers'].append(role);accepted[k]['reasons'].append(e.get('reason',e.get('context')));out[loc][key]=val
changed=[{'locale':l,'key':k,'old':v,'value':out[l][k]} for l,d in a['translations'].items() for k,v in d.items() if out[l][k]!=v]
assert len(changed)==len(accepted)
r={'source_sha256':a['source_sha256'],'translations':out,'accepted_edits':list(accepted.values()),'rejected_edits':rejected,'changed_count':len(changed),'unchanged_new_value_count':3420-len(changed),'certification':'Agent-reviewed; not native-human-certified'}
(p/'reviewed-candidate.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(len(changed),'changed; candidate sha',hashlib.sha256((p/'reviewed-candidate.json').read_bytes()).hexdigest())
