import pathlib,json,hashlib
p=pathlib.Path(__file__).resolve().parent;root=p.parents[2]
read=lambda f:json.loads((p/f).read_text())
c=read('reviewed-candidate.json');a=read('authored-final.json');entries=read('author-accepted-english-final.json')['entries']
for name in ['semantic-focused-final.json','editor-focused-final.json','adversarial-focused-final.json']:
 d=read(name);assert d['source_sha256']==c['source_sha256'];print(name,'loaded')
english=json.loads((root/'platform/packages/i18n/locales/en.json').read_text());sharedpath=root/'platform/packages/i18n/shared-values.json';shared=json.loads(sharedpath.read_text())
actual={(l,k) for l,d in c['translations'].items() for k,v in d.items() if v==english[k]};approved={(e['locale'],e['key']) for e in entries};assert actual==approved,(actual-approved,approved-actual)
proof=[]
for loc,values in c['translations'].items():
 path=root/f'platform/packages/i18n/locales/{loc}.json';old=json.loads(path.read_text());assert not(set(old)&set(values)),loc
 new={**old,**values};assert set(new)==set(english);assert all(new[k]==v for k,v in old.items())
 path.write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n')
 shared[loc]=sorted(set(shared.get(loc,[]))|{k for l,k in actual if l==loc})
 proof.append({'locale':loc,'old_keys_unchanged':len(old),'added_keys':len(values),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
sharedpath.write_text(json.dumps(shared,ensure_ascii=False,indent=2)+'\n')
ms=root/'platform/packages/i18n/locales/ms.json';draft=root/'artifacts/localization-ms-final/drafts/ms';(draft/'ms.json').write_bytes(ms.read_bytes());(draft/'online.json').write_bytes(ms.read_bytes())
(draft/'native.json').write_bytes((root/'artifacts/localization-ms/drafts/ms/native.json').read_bytes())
(p/'applied-data-proof.json').write_text(json.dumps({'source_sha256':c['source_sha256'],'catalogs':proof,'approved_new_english_matches':len(actual),'old_values_changed':0},indent=2)+'\n')
print('Applied',len(proof),'catalogs; allold values unchanged; English exceptions',len(actual))
