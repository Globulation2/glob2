import json,sys,hashlib,html
from pathlib import Path
P=Path(__file__).resolve().parent
q=json.load(open(P/'proposal.json'));ks=q['phase_two_keys']
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def raw(locale):
 if locale=='ms':
  data=json.load(open(P.parent.parent/'localization-ms-fixed-metadata/drafts/ms/ms.json'));return {k:data[k] for k in ks}
 data=json.load(open(P/'provider-records-fixed'/f'{locale}.json'))
 return {k:html.unescape(v['translatedText']) for k,v in zip(ks,data['response']['translations'])}
mode=sys.argv[1]
if mode=='read':
 refs=json.load(open(P/'native-exact-references.json'))
 for locale in sys.argv[2:]:
  print('\nLOCALE',locale)
  for i,(key,value) in enumerate(raw(locale).items()):
   reference=refs.get(key,{}).get('translations',{}).get(locale)
   print(str(i)+'='+value+((' | native='+str(reference)) if reference else ''))
if mode=='edits':
 edits=json.load(sys.stdin);path=P/'author-fixed-edits.json';all=json.load(open(path)) if path.exists() else {}
 for locale,changes in edits.items():all.setdefault(locale,{}).update(changes)
 write(path,all)
if mode=='mark':
 path=P/'author-fixed-read-locales.json';all=json.load(open(path)) if path.exists() else [];write(path,list(dict.fromkeys(all+sys.argv[2:])))
