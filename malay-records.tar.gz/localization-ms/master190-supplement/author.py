import json,hashlib,importlib.util
from pathlib import Path
R=Path.cwd();P=R/'artifacts/localization-ms/master190-supplement';q=json.load(open(P/'proposal.json'));s=importlib.util.spec_from_file_location('program',R/'tools/localization/translation_program.py');M=importlib.util.module_from_spec(s);s.loader.exec_module(M)
def write(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def h(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
kit=R/'artifacts/localization-ms-final-190';raw,_=M.CHECKER.read_table(kit/'drafts/ms/texts.ms.txt');raw={k:raw[k] for k in q['keys']};records=[]
for p in sorted((kit/'cloud/ms').glob('*.json')):
 if p.name!='summary.json':records.append({'path':str(p.relative_to(R)),'sha256':sha(p)})
write('initial-draft.json',{'author':'cloud_tooling','role':'machine_draft','source_sha256':q['source_sha256'],'project':'bradley-personal-20261027','model':'general/nmt','sources':q['sources'],'translations':{'ms':raw},'provider_records':records})
values={'[stat win probability]':'Kebarangkalian menang','[stat win probability about]':'Anggaran peluang perikatan anda menang. Sampel diambil sepanjang perlawanan. Sekutu berkongsi satu kebarangkalian. Model ini dilatih menggunakan perlawanan AI; anggaran tidak mengambil kira kedudukan atau langkah yang dirancang. Fail simpanan lama mungkin mempunyai sejarah yang tidak lengkap.'}
write('authored.json',{'author':'cloud_tooling','role':'author','source_sha256':q['source_sha256'],'initial_draft_sha256':sha(P/'initial-draft.json'),'translations':{'ms':values},'authored_keys':['native:'+k for k in q['keys']],'source_subset_sha256':h(q['sources']),'initial_target_subset_sha256':h(raw),'authored_target_subset_sha256':h(values),'edits':[{'surface':'native','key':k,'initial':raw[k],'value':v,'reason':'Use existing Perikatan and kebarangkalian menang terminology, distinguish training on AI games from running inside one, and translate older saves as stored game files rather than rescues. Preserve sampling, shared-alliance probability and every training/input/history limitation.'} for k,v in values.items() if raw[k]!=v],'contexts':q['contexts'],'references':{'data/texts.ms.txt':sha(R/'data/texts.ms.txt'),'src/team/stats/TeamStatChart.cpp':sha(R/'src/team/stats/TeamStatChart.cpp'),'src/team/stats/MetricCatalog.cpp':sha(R/'src/team/stats/MetricCatalog.cpp')},'limitations':['Author reconciliation only; independent semantic, editorial and adversarial reviews still required.'],'unresolved_uncertainty':[]})
write('author-accepted-english.json',{'author':'cloud_tooling','role':'author','source_sha256':q['source_sha256'],'entries':[]})
old=R/'artifacts/localization-ms-final-admin';new=kit;rows=[];ids=[]
for surface in ['native','online']:
 a=json.load(open(old/'source'/f'{surface}.json'));b=json.load(open(new/'source'/f'{surface}.json'));assert all(b[k]==v for k,v in a.items())
 if surface=='native':x,_=M.CHECKER.read_table(old/'drafts/ms/texts.ms.txt');y,_=M.CHECKER.read_table(new/'drafts/ms/texts.ms.txt')
 else:x=json.load(open(old/'drafts/ms/ms.json'));y=json.load(open(new/'drafts/ms/ms.json'));assert (old/'drafts/ms/ms.json').read_bytes()==(new/'drafts/ms/ms.json').read_bytes()
 assert all(y[k]==x[k] for k in a);rows.append({'surface':surface,'count':len(a),'source_subset_sha256':h(a),'target_subset_sha256':h({k:x[k] for k in a}),'source_unchanged':True,'target_unchanged':True});ids.extend(surface+':'+k for k in a)
assert len(ids)==6340
write('author-carryforward.json',{'identity':'cloud_tooling','role':'author','authorized_carryforward':True,'old_source_sha256':q['old_source_sha256'],'new_source_sha256':q['source_sha256'],'previous_approved_keys':ids,'records':rows,'online_target_file_bytes_identical':True,'online_target_file_sha256':sha(old/'drafts/ms/ms.json'),'new_native_keys_not_in_carryforward':q['keys'],'scope':'Exact unchanged source/target subset proof for prior approved 6,340 entries. Carry forward the author role for unchanged text; two new native entries are separately authored here. This is not semantic/editor/adversarial approval.'})
print('MS2 authored; old6340 exact source/target carry-forward passes.')
