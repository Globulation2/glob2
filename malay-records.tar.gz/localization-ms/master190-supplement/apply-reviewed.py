from pathlib import Path
import importlib.util,json,hashlib
root=Path.cwd();p=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('t',root/'tools/localization/translation_program.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t)
a=json.loads((p/'authored.json').read_text());m=json.loads((root/'artifacts/localization-ms-final-190/manifest.json').read_text());assert a['source_sha256']==m['source_sha256']
for f,field in [('semantic-review.json','guarded_proposals'),('editor-review.json','guarded_proposals'),('adversarial-review.json','proposals')]:
 d=json.loads((p/f).read_text());assert d['source_sha256']==m['source_sha256'] and not d[field]
d=json.loads((p/'native-adversarial-review.json').read_text());assert d['source_sha256']==m['source_sha256']
path=root/'data/texts.ms.txt';oldbytes=path.read_bytes();old,e=t.CHECKER.read_table(path);assert not e and len(old)==3393
new=a['translations']['ms'];assert len(new)==2 and not(set(old)&set(new));en,e=t.CHECKER.read_table(root/'data/texts.en.txt');assert not e
keys=list(en);assert set(keys)==set(old)|set(new)
assert ''.join(k+'\n'+old[k]+'\n' for k in keys if k in old).encode()==oldbytes
values={**old,**new};path.write_text(''.join(k+'\n'+values[k]+'\n' for k in keys));kit=root/'artifacts/localization-ms-final-190/drafts/ms';(kit/'texts.ms.txt').write_bytes(path.read_bytes());(kit/'native.json').write_text(json.dumps({k:values[k] for k in keys},ensure_ascii=False,indent=2)+'\n');(kit/'online.json').write_bytes((root/'platform/packages/i18n/locales/ms.json').read_bytes())
incomplete=root/'data/texts.incomplete.txt';lines=incomplete.read_text().splitlines();assert lines.count('*data/texts.ms.txt')==1;incomplete.write_text('\n'.join('data/texts.ms.txt' if x=='*data/texts.ms.txt' else x for x in lines)+'\n')
(p/'applied-data-proof.json').write_text(json.dumps({'source_sha256':m['source_sha256'],'old_native3393_values_unchanged':True,'removed2pairs_reconstructs_old_file_bytes':True,'old_native_sha256':hashlib.sha256(oldbytes).hexdigest(),'new_native_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'online_byteidentical_to_approved6340_stage':(kit/'ms.json').read_bytes()==(root/'artifacts/localization-ms-final-admin/drafts/ms/ms.json').read_bytes(),'new_keys':list(new),'locale_marked_complete':True},indent=2)+'\n')
print('Applied2; native3395complete; online2947unchanged; oldnative3393bytes reconstructexact')
