import subprocess,json,hashlib,importlib.util
from pathlib import Path
R=Path.cwd();P=R/'artifacts/localization-ms/master191-supplement'
spec=importlib.util.spec_from_file_location('cloud',R/'tools/localization/cloud_draft.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def table(s):
 d={};key=None
 for l in s.splitlines():
  if l.startswith('[') and l.endswith(']'):key=l;d[key]=[]
  elif key:d[key].append(l)
 return {k:'\n'.join(v).strip() for k,v in d.items()}
x=table(subprocess.check_output(['git','show','HEAD:data/texts.en.txt'],text=True));y=table(subprocess.check_output(['git','show','origin/master:data/texts.en.txt'],text=True));sources={k:v for k,v in y.items() if k not in x or x[k]!=v};assert len(sources)==16
h=hashlib.sha256(json.dumps(sources,sort_keys=True,ensure_ascii=False).encode()).hexdigest();m.atomic_json(P/'sources.json',{'base':'c2b3cd5a71af2cfa52345e245c063475003c4577','upstream':subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip(),'source_subset_sha256':h,'sources':sources})
protected=[m.protect(v) for v in sources.values()];body=m.payload('bradley-personal-20261027','ms',[p[0] for p in protected]);result=m.translate('bradley-personal-20261027',body);m.atomic_json(P/'provider-response.json',result)
values={k:m.restore(row['translatedText'],p[1]) for k,row,p in zip(sources,result['translations'],protected)};m.atomic_json(P/'initial-draft.json',{'role':'machine_draft','project':'bradley-personal-20261027','model':'general/nmt','source_subset_sha256':h,'sources':sources,'translations':values});print(json.dumps(values,ensure_ascii=False,indent=2))
