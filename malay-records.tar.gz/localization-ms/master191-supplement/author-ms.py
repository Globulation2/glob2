from pathlib import Path
import json,hashlib,subprocess
R=Path.cwd();P=R/'artifacts/localization-ms/master191-supplement';q=json.load(open(P/'sources.json'));raw=json.load(open(P/'initial-draft.json'));v=dict(raw['translations']);v.update({'[stats topic overview]':'Gambaran keseluruhan','[stats map overlays]':'Tindanan peta','[stats missing readings]':'— Belum ada bacaan direkodkan. Pilih statistik untuk butiran lanjut.','[lush_grass]':'Rumput subur','[dune_sand]':'Pasir gumuk'})
reasons={
'[stats topic overview]':'Use the established overview noun phrase with sentence case for the topic tab, not title case.',
'[stats topic economy]':'Ekonomi matches the existing native Economy label; this is a statistics topic.',
'[stats topic world]':'Dunia describes the world/map statistics topic alongside colony/economy/military.',
'[stats work construction]':'Kerja & pembinaan labels the idle-worker/blocked-building overview section; retain the short ampersand heading.',
'[stats defence]':'Pertahanan matches existing native Defense/defense-overlay terminology.',
'[stats history]':'Lihat sejarah is the history-view action/accessibility label, using sentence case without changing the older key.',
'[stats waiting]':'Preserve pending-statistics meaning and the source ellipsis character.',
'[stats unit details]':'Butiran unit is an ordinary details action for units, consistent with the current unit vocabulary.',
'[stats map overlays]':'Use Tindanan, already used by No overlay, Starvation overlay, Damage overlay, Defense overlay and Fertility overlay; this is an overlay action, not a separate terrain-layer type.',
'[stats topic]':'Topik is the short label for the statistics topic selector.',
'[stats full history]':'Buka sejarah penuh explicitly opens the full metric-history view rather than a compact inline chart.',
'[stats missing readings]':'Keep the leading dash, absence of recorded readings so far, and instruction to select a statistic. Shorten the passive wording for the new inline statistics panel.',
'[lush_grass]':'Rumput subur is a concise terrain-swatch label, retaining the existing Rumput noun and lush appearance.',
'[dry_grass]':'Rumput kering keeps the existing grass noun and dry appearance distinction.',
'[dune_sand]':'Pasir gumuk avoids the NMT repetition Pasir bukit pasir while retaining sand as the material. DBP PRPM lists gumuk pasir as the Malaysian sand-dune term; the existing Bukit pasir labels denote the dune itself.',
'[pale_sand]':'Pasir pucat keeps sand as the material and distinguishes its pale colour, not a new gameplay resource.'}
sha=lambda b:hashlib.sha256(b).hexdigest();canonical=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode());refs={'current_native_catalog':{'path':'data/texts.ms.txt','sha256':sha((R/'data/texts.ms.txt').read_bytes())},'upstream_stats':{'revision':q['upstream'],'path':'src/hud/InGameStatistics.cpp','sha256':sha(subprocess.check_output(['git','show',q['upstream']+':src/hud/InGameStatistics.cpp']))},'upstream_terrain':{'revision':q['upstream'],'path':'data/terrain/tileset.json','sha256':sha(subprocess.check_output(['git','show',q['upstream']+':data/terrain/tileset.json']))},'dune_terminology':{'url':'https://prpm.dbp.gov.my/Cari1?d=115704&keyword=pasir','finding':'DBP PRPM identifies gumuk pasir as the Malaysian sand-dune term in its terminology table; the concise material label here is Pasir gumuk.'}}
out={'author':'cloud_tooling','role':'author','base':q['base'],'upstream':q['upstream'],'source_subset_sha256':q['source_subset_sha256'],'sources':q['sources'],'initial_draft_sha256':sha((P/'initial-draft.json').read_bytes()),'translations':v,'authored_keys':['native:'+k for k in v],'initial_target_subset_sha256':canonical(raw['translations']),'authored_target_subset_sha256':canonical(v),'per_key_review':[{'key':k,'source':q['sources'][k],'initial':raw['translations'][k],'value':value,'reason':reasons[k],'edited':value!=raw['translations'][k]} for k,value in v.items()],'references':refs,'accepted_english':[],'unresolved_uncertainty':[],'limitations':['Author reconciliation only, not independent semantic/editor/adversarial approval. The terrain label is a material name; visual swatches and existing gameplay profile IDs remain unchanged.']}
assert set(v)==set(q['sources']) and len(v)==16;assert all(q['sources'][k]!=v[k] for k in v);(P/'authored.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('Authored MS16, edits',sum(x['edited'] for x in out['per_key_review']))
