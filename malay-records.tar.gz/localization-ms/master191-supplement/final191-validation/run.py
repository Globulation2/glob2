"""Prepared read-only191 validation; --execute only after root's final build/fixture handoff."""
import argparse
import fnmatch
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
BASE = Path(__file__).resolve().parent
PLAN = json.loads((BASE / 'filters.json').read_text())
BUILD = ROOT / 'build/linux/client/debug/dev-dev_fast-true-linker-auto'
VALIDATION = ROOT / 'artifacts/localization-ms/validation'
sys.path.insert(0, str(ROOT / 'test'))
from build_provenance import source_identity, build_issues
from check_sim_revision import record_sim_version, load_sim_version


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def no_native_builder():
    for process in Path('/proc').iterdir():
        if not process.name.isdigit():
            continue
        try:
            command = (process / 'cmdline').read_bytes().replace(b'\0', b' ').decode()
            if '/usr/bin/scons ' in command and 'target=web' not in command and (process / 'cwd').resolve() == ROOT:
                raise RuntimeError('Native SCons is still active: ' + process.name)
        except (OSError, UnicodeError):
            pass


def snapshot(expected_head):
    no_native_builder()
    source = source_identity()
    assert source['revision'] == expected_head and not source['dirty'], source
    paths = {'preview': 'test/TranslationPreviewHarness', 'engine': 'test/glob2-engine-tests',
             'unit': 'test/glob2-unit-tests', 'gallery': 'src/mobile-gallery', 'glob2': 'src/glob2'}
    binaries = {}
    for name, relative in paths.items():
        path = BUILD / relative
        if name in ('preview', 'engine', 'unit'):
            result = subprocess.run([sys.executable, str(VALIDATION / 'read-native-producer.py'), str(path)],
                                    check=True, text=True, stdout=subprocess.PIPE)
            receipt = json.loads(result.stdout)
            assert len(receipt['embeddedProducers']) == 1
            assert not build_issues(receipt['embeddedProducers'][0], source), receipt
        else:
            receipt = {'path': str(path), 'sha256': digest(path), 'embeddedProducers': [],
                       'provenanceNote': 'No embedded producer; root final five-target SCons receipt validates inputs; stable hashes plus real CLI sim key/trace checked here'}
        binaries[name] = receipt
    sim = load_sim_version()
    assert sim.sim_revision(ROOT) == 111
    key = sim.sim_version_key(ROOT)
    record = ROOT / 'test/fixtures/multiplayer/FourSquares1.g2mr'
    assert record_sim_version(record.read_bytes()) == key, 'Canonical111 fixture is not current'
    assert key.startswith('191-'), key
    return {'source': source, 'binaries': binaries, 'simKey': key,
            'recordSha256': digest(record), 'traceSha256': digest(ROOT / 'test/fixtures/multiplayer/FourSquares1.verify-trace.txt')}


def environment(display=False):
    env = dict(os.environ)
    for key in ('DISPLAY', 'WAYLAND_DISPLAY', 'SDL_VIDEO_DRIVER', 'SDL_VIDEODRIVER'):
        env.pop(key, None)
    env['LD_LIBRARY_PATH'] = ':'.join([str(VALIDATION / 'sdl3/prefix/lib'),
                                     str(VALIDATION / 'recording/prefix/lib'), env.get('LD_LIBRARY_PATH', '')])
    env['SDL_AUDIODRIVER'] = 'dummy'
    if display:
        env['SDL_VIDEO_DRIVER'] = 'x11'
    return env


def inventory(before, output):
    cases = []
    policy_excluded = []
    for name in ('engine', 'unit'):
        binary = before['binaries'][name]['path']
        listed = subprocess.run([binary, '-r=xml', '-ltc'], check=True, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=environment())
        (output / (name + '-listing.xml')).write_text(listed.stdout)
        for item in ET.fromstring(listed.stdout).iter('TestCase'):
            label = item.get('testsuite', '') + '/' + item.get('name', '')
            if '[benchmark]' in item.get('name', ''):
                policy_excluded.append({'label': label, 'binary': name, 'reason': 'Standard test/run_tests.py excludes benchmark cases unless --tag benchmark is requested'})
                continue
            if any(fnmatch.fnmatchcase(label.lower(), f.lower()) for f in PLAN['filters']):
                cases.append({'label': label, 'binary': name, 'file': item.get('filename'),
                              'line': item.get('line'), 'display': bool(re.search(r'\[display(?::[^]]*)?\]', item.get('name', '')))})
    labels = [item['label'] for item in cases]
    assert len(labels) == len(set(labels)), 'Duplicate selected labels'
    coverage = {f: sum(fnmatch.fnmatchcase(x.lower(), f.lower()) for x in labels) for f in PLAN['filters']}
    assert all(coverage.values()), coverage
    assert all(name in labels for name in PLAN['requiredNamedCases'])
    result = {'cases': cases, 'filterCoverage': coverage, 'actualSelectedCount': len(cases),
              'displayCount': sum(item['display'] for item in cases), 'source': before['source'],
              'standardPolicyExcluded': policy_excluded}
    write(output / 'actual-inventory.json', result)
    return result


def checks(before, output):
    selected = inventory(before, output)
    commands, evidence = [], {}
    for display in (False, True):
        name = 'display-x11' if display else 'headless'
        directory = output / name
        directory.mkdir(exist_ok=True)
        command = [sys.executable, 'test/run_tests.py', '--build-dir', str(BUILD), '--binary', 'all',
                   '-j1' if display else '-j4', '--display-jobs', '1', '--timeout', '600',
                   '--tag' if display else '--exclude-tag', 'display', '--junit', str(directory / 'junit.xml'),
                   '--artifacts', str(directory / 'artifacts'), '--write-inventory', str(directory / 'inventory.json')]
        for pattern in PLAN['filters']:
            command.extend(['--filter', pattern])
        started = time.monotonic()
        with (directory / 'process.log').open('w') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=environment(display))
        commands.append({'command': command, 'exitCode': result.returncode, 'seconds': time.monotonic() - started,
                         'environment': {'SDL_VIDEO_DRIVER': 'x11' if display else None,
                                         'DISPLAY': None, 'WAYLAND_DISPLAY': None, 'displayJobs': 1, 'timeoutSeconds': 600}})
        if (directory / 'junit.xml').is_file():
            for case in ET.parse(directory / 'junit.xml').getroot().iter('testcase'):
                label = case.get('classname', '') + '/' + case.get('name', '')
                evidence[label] = {'junit': str(directory / 'junit.xml'), 'seconds': case.get('time'),
                                   'passed': not any(case.findall(tag) for tag in ('failure', 'error', 'skipped'))}
    expected = {item['label'] for item in selected['cases']}
    result = {'commands': commands, 'caseEvidence': evidence, 'selectedCount': len(expected),
              'allPassed': set(evidence) == expected and all(x['passed'] for x in evidence.values()) and all(x['exitCode'] == 0 for x in commands)}
    write(output / 'checks-result.json', result)
    return result['allPassed']


def cli(before, output):
    binary = before['binaries']['glob2']['path']
    info = subprocess.run([binary, 'info', 'sim-version', '--format', 'json'], check=True,
                          text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=environment())
    version = json.loads(info.stdout)
    assert f"{version['versionMinor']}-{version['netProtocol']}-{version['dataHash']}" == before['simKey']
    golden = (ROOT / 'test/fixtures/multiplayer/FourSquares1.verify-trace.txt').read_bytes()
    result = {'simVersion': version, 'runs': []}
    env = environment()
    env.update(SDL_VIDEODRIVER='dummy', SDL_RENDER_DRIVER='software')
    for locale in ('en', 'ms'):
        directory = output / locale
        profile = directory / 'profile'
        profile.mkdir(parents=True, exist_ok=True)
        preferences = profile / 'preferences.txt'
        preferences.write_text('language=' + locale + '\n')
        command = [binary, 'match', 'verify', 'test/fixtures/multiplayer/FourSquares1.g2mr',
                   '--map-file', 'maps/FourSquares1.map.gz', '--output-dir', str(directory), '--compute-threads', '1']
        started = time.monotonic()
        with (directory / 'process.log').open('w') as log:
            completed = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
        verdict = json.loads((directory / 'verdict.json').read_text()) if (directory / 'verdict.json').exists() else {}
        trace = (directory / 'checksums.txt').read_bytes() if (directory / 'checksums.txt').exists() else b''
        entry = {'localePreference': locale, 'command': command, 'exitCode': completed.returncode,
                 'seconds': time.monotonic() - started, 'verdict': verdict,
                 'traceSha256': hashlib.sha256(trace).hexdigest(), 'traceMatchesGolden': trace == golden,
                 'persistedLocaleVerified': '\nlanguage=' + locale + '\n' in '\n' + preferences.read_text()}
        result['runs'].append(entry)
        write(output / 'cli-result.json', result)
    result['allPassed'] = all(r['exitCode'] == 0 and r['verdict'].get('verdict') == 'verified' and
                             r['traceMatchesGolden'] and r['persistedLocaleVerified'] for r in result['runs'])
    write(output / 'cli-result.json', result)
    return result['allPassed']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--phase', choices=('inventory', 'checks', 'cli', 'all'), default='checks')
    parser.add_argument('--output', type=Path, default=VALIDATION / 'final191')
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({'status': 'PREPARED; no native execution', 'phase': args.phase, 'plan': PLAN}, indent=2))
        return 0
    output = args.output.resolve() / args.phase
    output.mkdir(parents=True, exist_ok=True)
    assert not (output / 'result.json').exists(), 'Choose a fresh output directory for each attempt'
    before = snapshot(args.expected_head)
    write(output / 'before.json', before)
    ok = True
    try:
        if args.phase == 'inventory':
            inventory(before, output)
        if args.phase in ('checks', 'all'):
            ok = checks(before, output)
        if args.phase in ('cli', 'all'):
            ok = cli(before, output) and ok
    except BaseException as error:
        ok = False
        write(output / 'failure.json', {'type': type(error).__name__, 'message': str(error)})
        raise
    finally:
        after = snapshot(args.expected_head)
        stable = before == after
        write(output / 'result.json', {'sourceAndBinariesBefore': before, 'sourceAndBinariesAfter': after,
                                       'stable': stable, 'phasePassed': ok, 'timeoutReason': PLAN['timeoutReason']})
        assert stable, 'Source or executed binary identity changed during validation'
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
