"""Prepare reviewable conflict resolutions without modifying the checkout."""
import subprocess,re,json
from pathlib import Path
P=Path(__file__).resolve().parent;tree=(P/'merge-tree-preview.txt').read_text().splitlines()[0];out=P/'resolved';out.mkdir(exist_ok=True)
def show(ref,path):return subprocess.check_output(['git','show',ref+':'+path],text=True)
paths=list(dict.fromkeys(l.split('\t')[-1] for l in (P/'merge-tree-preview.txt').read_text().splitlines() if '\t' in l));base='0d54ef3a99384059e68e78f03f774e062031a3ca'
def mergejson(b,o,t,where=''):
 if o==t:return o
 if o==b:return t
 if t==b:return o
 if all(isinstance(v,dict) for v in [b,o,t]):
  z={}
  for k in dict.fromkeys([*t,*o]):
   if k not in b:
    if k in o and k in t:assert o[k]==t[k],where+'/'+k
    z[k]=o.get(k,t.get(k))
   elif k not in o:z[k]=t[k]
   elif k not in t:z[k]=o[k]
   else:z[k]=mergejson(b[k],o[k],t[k],where+'/'+k)
  return z
 if all(isinstance(v,list) for v in [b,o,t]):
  assert all(v in o and v in t for v in b),where
  return list(dict.fromkeys([*t,*o]))
 raise ValueError('Unresolved JSON conflict '+where)
def chunk(path,a,b):
 if path in ['data/texts.list.txt','data/texts.incomplete.txt']:return b+a
 if path=='libgag/src/TrueTypeFont.cpp':return a.replace('Swahili and Malay','Swahili, Bokmål and Malay').replace('language == "sw" || language == "ms"','language == "sw" || language == "nb" || language == "ms"')
 if path=='libgag/src/FontKerningTest.cpp':
  return a+b if 'std::string(code) ==' in a else a.replace('"sw", "ms"','"sw", "nb", "ms"')
 if path=='platform/packages/i18n/src/locales.ts':
  return b+"    dir: 'ltr',\n  },\n  {\n"+a
 if path=='platform/packages/i18n/test/runtime.test.ts':
  return a.replace("    expect(new Set(locales.map((l) => l.gameCode)).size)","    expect(locales).toContainEqual({code: 'nb',gameCode: 'nb',name: 'Norsk bokmål',dir: 'ltr'});\n    expect(new Set(locales.map((l) => l.gameCode)).size)")
 if path=='src/app/SystemLanguageTest.cpp':return a+'\t}\n\n'+b if 'TEST_CASE' in a else b
 if path=='src/scripting/sgsl/LegacyScriptCoverageTest.cpp':
  if '#include' in a:return ''.join(dict.fromkeys((a+b).splitlines(keepends=True)))
  return a+'        }\n    }\n\n'+b
 if path=='src/ui/settings/SettingsScreenGeneral.cpp':return b
 if path=='tools/localization/translation_program.py':return b.replace("'su', 'nb')","'su', 'nb', 'ms')")
 if path=='docs/development/ui-framework.md':
  if a.startswith('For a gcloud'):return a+'\n'+b
  return 'Script-layout locales, Swahili, Norwegian Bokmål and Malay draw high-DPI text\nat the authored width used by wrapping and hit testing. The complete\nhigh-resolution bitmap is resampled into that destination; font hinting at a\nlarger raster size must not make a fitted line overflow its layout. Legacy\nLatin locales retain their existing geometry.\n'
 raise ValueError(path)
for path in paths:
 if path=='test/fixtures/multiplayer/FourSquares1.g2mr':continue
 if path=='browser/i18n.js':s=show('HEAD',path) # regenerate from merged source afterward
 elif path.endswith('.json'):
  d=mergejson(json.loads(show(base,path)),json.loads(show('HEAD',path)),json.loads(show('origin/master',path)));s=json.dumps(d,ensure_ascii=False,indent=2)+'\n'
 else:
  s=show(tree,path);pattern=r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> origin/master\n';s=re.sub(pattern,lambda m:chunk(path,m[1],m[2]),s,flags=re.M|re.S)
 if path=='src/scripting/sgsl/LegacyScriptCoverageTest.cpp':
  s=s.replace('#include <vector>\n#include <StringTable.h>\n#include <Toolkit.h>', '#include <vector>')
 assert '<<<<<<<' not in s and '>>>>>>>' not in s,path
 p=out/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
print('Prepared',len(paths)-1,'reviewable text resolutions; checkout untouched.')
