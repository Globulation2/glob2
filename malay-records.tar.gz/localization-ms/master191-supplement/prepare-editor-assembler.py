from pathlib import Path
p=Path('artifacts/localization-ms-final-190/assemble-review.py');s=p.read_text()
s=s.replace('master190','master191').replace('localization-ms-final-admin','localization-ms-final-190')
s=s.replace('6340','__OLD_COUNT__').replace('6342','6358').replace('__OLD_COUNT__','6342')
s=s.replace("q=read(P/'proposal.json')","q=read(P/'sources.json')")
s=s.replace(";extra_adv=read(P/'adversarial-review.json')",'')
start=s.index("assert m['source_sha256']==")
end=s.index("paths=t.catalog_paths",start)
s=s[:start]+'''# New global manifest is established only after the integrated source is frozen.
assert old['source_sha256']==om['source_sha256']=='51ddb8193640b09ecfbe713de190326a5569975313d24d707b3ac655f24d6350'
assert m['source_sha256']!=om['source_sha256']
assert a['source_subset_sha256']==s['source_subset_sha256']==e['source_subset_sha256']==adv['source_subset_sha256']==hd(a['sources'])
newvalues=a['translations'];newids={'native:'+k for k in newvalues};assert len(newids)==16
''' + s[end:]
s=s.replace("'Final2 targets", "'Final16 targets")
start=s.index('# Fourth native record');end=s.index('oldnative,errors=',start)
s=s[:start]+'''# New sixteen entries have three actual independent readers, each hash-bound.
advid=adv['identity'];assert advid=='malay_adversary'
assert set(adv['adversarial_reviewed_keys'])==newids
assert adv['input_file_sha256']==fh(P/'authored.json')
assert adv['target_subset_sha256']==hc(newvalues)
assert not adv['edits'] and not adv['findings'] and not adv['unresolved_uncertainty']
''' + s[end:]
s=s.replace('new2','new16').replace('new2','new16').replace('new keys; represent','new keys; represent').replace('the2 new','the16 new').replace('Two exact','Sixteen exact')
s=s.replace("'37 languages × 2947", "'38 languages × 2947").replace("'Built launcher runtime and 37 catalogs'", "'Built launcher runtime and 38 catalogs'")
start=s.index('files=[');end=s.index(';independent=[',start)
s=s[:start]+'''files=[O/'reviews/ms.json',O/'linguistic-normalization-proof.json',O/'structural-normalization-proof.json',P/'sources.json',P/'initial-draft.json',P/'authored.json',P/'semantic-review.json',P/'editor-review.json',P/'native-adversarial-review.json',P/'nb-editor-review.json',P/'nb-editor-final-recheck.json',P/'nb-native-editor-review.json']''' +s[end:]
s=s.replace('removing_new2_pairs','removing_new16_pairs').replace('new2_applied','new16_applied').replace('new2 probability tooltip entries','new16 statistics/terrain entries').replace('new2 native entries','new16 native entries').replace('new2 entries','new16 entries').replace('new2 independent','new16 independent')
s=s.replace('Original Malaysian Rumi brief remains valid; new2 probability tooltip entries independently checked against exact source and existing Perikatan terminology.', 'Original Malaysian Rumi brief remains valid; new16 statistics/terrain entries independently checked against exact source and existing statistics/overlay/material terminology.')
s=s.replace('probability tooltip entries independently checked against exact source and existing Perikatan terminology', 'statistics/terrain entries independently checked against exact source and existing statistics/overlay/material terminology')
s=s.replace('All earlier0ac/7133/72433 full readings', 'All earlier0ac/7133/72433/51ddb full readings')
s=s.replace('Static unchanged web component proof does not certify master191 WASM/SIM110 startup or native rendering.', 'Supplemental NB111 online/NB16 native independent reviews do not certify the complete prior NB catalog. No final191 runtime or pixel approval is inferred from unchanged values.')
s=s.replace('new16 probability tooltip entries', 'new16 statistics/terrain entries').replace('old6342 byteproof plus new2', 'old6342 byteproof plus new16')
Path('artifacts/localization-ms-final-191/assemble-review.py').write_text(s)
