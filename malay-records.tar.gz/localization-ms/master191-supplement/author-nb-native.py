from pathlib import Path
import json,hashlib
P=Path('artifacts/localization-ms/master191-supplement');raw=json.load(open(P/'nb-native-initial-draft.json'));source=json.load(open(P/'sources.json'));v=dict(raw['translations']);v.update({'[stats work construction]':'Arbeid og bygging','[stats missing readings]':'— Ingen registrert avlesning ennå. Velg en statistikk for detaljer.'})
reasons={
'[stats topic overview]':'Oversikt is the concise ordinary overview-topic label.',
'[stats topic economy]':'Økonomi exactly matches the existing native Economy label.',
'[stats topic world]':'Verden denotes the world/map statistics topic alongside colony/economy/military.',
'[stats work construction]':'Use the ordinary building-process noun bygging for idle-worker/blocked-building statistics, rather than an engineering construction object.',
'[stats defence]':'Forsvar matches the existing native Defense and Defense overlay terminology.',
'[stats history]':'Vis historikk exactly matches the existing native history action; this is metric history, not a narrative story.',
'[stats waiting]':'Preserve pending statistics and the source ellipsis character.',
'[stats unit details]':'Enhetsdetaljer identifies details of the existing Enheter game entities.',
'[stats map overlays]':'Kartoverlegg uses the existing native overlegg term from Ingen overlegg/Forsvarsoverlegg.',
'[stats topic]':'Emne is a concise topic-selector label.',
'[stats full history]':'Åpne hele historikken clearly opens the full metric-history view rather than only its inline preview.',
'[stats missing readings]':'Retain absent recorded readings so far and metric-selection instruction; restore the source em dash instead of the NMT en dash.',
'[lush_grass]':'Frodig gress describes the lush terrain-swatch appearance and retains the existing Gress noun.',
'[dry_grass]':'Tørt gress retains the grass noun and dry appearance distinction.',
'[dune_sand]':'Dynesand is the compact sand-material label, consistent with existing Sand and Sanddyne terminology; avoid a separated/repeated sand compound.',
'[pale_sand]':'Blek sand denotes pale-coloured sand appearance, not a different resource or gameplay property.'}
sha=lambda b:hashlib.sha256(b).hexdigest();h=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode());assert set(v)==set(source['sources']) and len(v)==16
out={'author':'cloud_tooling','role':'author','locale':'nb','surface':'native','base':source['base'],'upstream':source['upstream'],'source_subset_sha256':source['source_subset_sha256'],'sources':raw['sources'],'initial_draft_sha256':sha((P/'nb-native-initial-draft.json').read_bytes()),'translations':v,'authored_keys':['native:'+k for k in v],'initial_target_subset_sha256':h(raw['translations']),'authored_target_subset_sha256':h(v),'per_key_review':[{'key':k,'source':raw['sources'][k],'initial':raw['translations'][k],'value':value,'reason':reasons[k],'edited':value!=raw['translations'][k]} for k,value in v.items()],'references':{'upstream_native_nb_snapshot':{'path':str(P/'upstream-native-nb.txt'),'sha256':sha((P/'upstream-native-nb.txt').read_bytes()),'anchors':{'Defense':'Forsvar','Economy':'Økonomi','Units':'Enheter','view history':'Vis historikk','No overlay':'Ingen overlegg','Defense overlay':'Forsvarsoverlegg','grass':'Gress','sand':'Sand','theme dune':'Sanddyne','stat construction':'Fullført byggearbeid'}},'upstream_context':'src/hud/InGameStatistics.cpp and data/terrain/tileset.json at the stated upstream revision were read for the MS/NB16 context.'},'accepted_english':[],'unresolved_uncertainty':[],'limitations':['Author reconciliation only; all16 native pairs read, not independent semantic/editor/adversarial approval. Primary NB3395 values were not modified.']}
assert all(raw['sources'][k]!=v[k] for k in v);(P/'nb-native-authored.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('Authored NB native16; edits',sum(x['edited'] for x in out['per_key_review']))
