from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;read=lambda n:json.loads((P/n).read_text());fh=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();hd=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest();hc=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();a=read('terrain-gaps-authored.json');assert hc(a['sources'])==a['source_subset_sha256'];assert hc(a['translations'])==a['authored_target_subset_sha256']
reasons={
'hi':{
'[lush_grass]':'हरी-भरी is the idiomatic paired adjective for lush green growth; घास retains the existing grass material noun.',
'[dry_grass]':'सूखी agrees with feminine घास and directly describes dry grass appearance.',
'[dune_sand]':'टीलों की रेत correctly makes sand the head noun and dunes the association. This fixes the raw draft which named sand dunes themselves; existing टीला and रेत vocabulary retained.',
'[pale_sand]':'हल्के रंग की explicitly qualifies colour as light, avoiding low weight implied by bare हल्की. रेत remains the material noun; no whiteness is asserted.'},
'ur':{
'[lush_grass]':'سرسبز is the natural lush-green adjective with existing گھاس; concise and appropriate to the grass appearance swatch.',
'[dry_grass]':'سوکھی گھاس naturally names dried grass and has correct feminine adjective agreement.',
'[dune_sand]':'ٹیلے کی ریت names the dune-associated sand material with the existing ٹیلہ and ریت terms. The head is sand, matching a paint material rather than a dune object.',
'[pale_sand]':'ہلکے رنگ کی ریت explicitly describes light colour and retains feminine agreement; avoids interpreting light as low weight, without falsely specifying white.'},
'sw':{
'[lush_grass]':'Nyasi mbichi is the natural fresh/green grass contrast to Nyasi kavu, appropriate to the dark-green lush preview; no game fertility claim is added.',
'[dry_grass]':'Nyasi kavu is concise dry grass with correct noun-class adjective form and existing Nyasi material vocabulary.',
'[dune_sand]':'Mchanga wa matuta makes sand the material head and dunes the association. Matuta matches the existing dune captions and fixes the tautological raw sand-of-sand draft.',
'[pale_sand]':'Mchanga wa rangi hafifu naturally indicates sand of a pale/faint colour; appropriate to beige preview rather than the raw draft specifying white. Material remains Mchanga.'}}
entries=[]
for locale,values in a['translations'].items():
 assert set(values)==set(a['sources'])==set(reasons[locale])
 for k,v in values.items():entries.append({'locale':locale,'surface':'native','key':k,'source':a['sources'][k],'value':v,'source_value_sha256':hashlib.sha256(a['sources'][k].encode()).hexdigest(),'target_value_sha256':hashlib.sha256(v.encode()).hexdigest(),'decision':'accepted','reason':reasons[locale][k]})
refs=[]
for locale in a['translations']:
 p=Path('data/texts.'+locale+'.txt');ls=p.read_text().splitlines();anchors={k:ls[ls.index(k)+1] for k in ['[grass]','[sand]','[theme dune]','[Dunes and mesas]']};refs.append({'path':str(p),'sha256':fh(p),'actually_read_anchors':anchors})
refs.append({'path':'data/terrain/tileset.json','sha256':fh(Path('data/terrain/tileset.json')),'actually_read_context':'Four material keys/profile/preview RGB definitions: lush_grass [26,100,50], dry_grass [120,123,52], dune_sand [202,150,85], pale_sand [210,201,168]. Appearance labels do not change underlying sand profiles or simulation.'})
out={'identity':'malay_editor','role':'independent editorial review','certification':'Agent-reviewed; not native-human-certified','source_subset_sha256':hc(a['sources']),'target_subset_sha256':hc(a['translations']),'input_file':'artifacts/localization-ms/master191-supplement/terrain-gaps-authored.json','input_file_sha256':fh(P/'terrain-gaps-authored.json'),'initial_draft_file_sha256':fh(P/'terrain-gaps-initial-draft.json'),'hash_convention':'Source and target subsets sorted UTF8 JSON compact separators; per-value exact UTF8 bytes.','reviewed_keys':[x['locale']+':native:'+x['key'] for x in entries],'reviewed_count':12,'entries':entries,'references':refs,'guarded_proposals':[],'edits':[],'accepted_english':[],'unresolved_uncertainty':[],'live_edits':False,'limits':['Actual reading of all12 new HI/UR/SW source/target pairs and listed existing glossary anchors only; no full prior-catalog reread claimed.','Rendering of Devanagari/Urdu and right-to-left layout require separate pixel/runtime evidence.'],'status':'All12 accepted; colour/material distinctions and existing terminology retained.'};assert len(entries)==12;(P/'terrain-gaps-editor-review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('All12 accepted with per-key reasons/source/target hashes and actual glossary/context references.')
