"""Apply only reviewed additions after resolving the191 integration."""
import importlib.util,json,hashlib
from pathlib import Path
R=Path.cwd();P=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('program',R/'tools/localization/translation_program.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t)
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();proof={'native':[]}
for locale,author in [('ms','authored.json'),('nb','nb-native-authored.json')]:
 p=R/f'data/texts.{locale}.txt';oldraw=p.read_bytes();old,errors=t.CHECKER.read_table(p);assert not errors and len(old)==3395;new=read(P/author)['translations'];assert len(new)==16 and not set(old)&set(new)
 p.write_bytes(oldraw+''.join(k+'\n'+v+'\n' for k,v in new.items()).encode());actual,errors=t.CHECKER.read_table(p);assert not errors and len(actual)==3411 and all(actual[k]==v for k,v in old.items())
 reconstructed=p.read_bytes()
 for k,v in new.items():
  pair=(k+'\n'+v+'\n').encode();assert reconstructed.count(pair)==1;reconstructed=reconstructed.replace(pair,b'',1)
 assert reconstructed==oldraw
 proof['native'].append({'locale':locale,'old_values':len(old),'new_values':len(new),'old_bytes_sha256':sha(oldraw),'new_bytes_sha256':sha(p.read_bytes()),'removing_reviewed16_pairs_reconstructs_old_bytes':True,'author_sha256':sha((P/author).read_bytes())})
p=R/'platform/packages/i18n/locales/nb.json';old=read(p);assert len(old)==2836;new=read(P/'nb-authored-v2.json')['translations'];assert len(new)==111 and not set(old)&set(new);values={**old,**new};p.write_text(json.dumps(dict(sorted(values.items())),ensure_ascii=False,indent=2)+'\n');assert all(read(p)[k]==v for k,v in old.items());proof['online']={'locale':'nb','old_values':len(old),'new_values':len(new),'old_values_unchanged':True,'old_values_sha256':sha(json.dumps(old,ensure_ascii=False,sort_keys=True).encode()),'new_file_sha256':sha(p.read_bytes()),'final_author_sha256':sha((P/'nb-authored-v2.json').read_bytes())}
p=R/'platform/packages/i18n/shared-values.json';d=read(p);accepted=read(P/'nb-authored-v2.json')['accepted_english'];print('accepted record type',type(accepted).__name__)
keys=[]
for entry in accepted:
 key=entry.get('key');assert key and entry.get('reason');key=key.removeprefix('online:');assert new[key]==key;keys.append(key)
assert set(keys)=={'Mineral','Lava','Fly'};d['nb']=sorted(set(d['nb'])|set(keys));p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');proof['online']['english_cognates']=accepted
p=R/'data/texts.incomplete.txt';lines=p.read_text().splitlines();assert lines.count('data/texts.ms.txt')==1 and lines.count('data/texts.nb.txt')==1
(P/'applied-data-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('Applied reviewed MS16/NB16/NBonline111; old values exact.')
