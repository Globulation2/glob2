import json,hashlib,subprocess
from pathlib import Path
p=Path(__file__).parent

def sha(b):return hashlib.sha256(b).hexdigest()
def h(v):return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
ms=json.loads((p/'authored.json').read_text());nb1=json.loads((p/'nb-authored.json').read_text());nb=json.loads((p/'nb-authored-v2.json').read_text())
msreasons='''Complete overview noun phrase; sentence case suits topic selector.
Established economy noun for the economic statistics topic.
World topic remains distinct from colony and economy.
Names both work and construction; preserves the compact ampersand heading.
Defence noun matches existing Pertahanan overlay vocabulary.
Action Lihat suits history accessibility label, rather than implying saved-game history.
Pending statistics message retains the ellipsis and waiting meaning.
Unit details uses established Butiran and unit vocabulary.
Tindanan matches existing map-overlay labels; does not imply new terrain layer.
Topik labels the selector, not a simulation metric.
Buka explicitly opens the complete history view.
Belum preserves not-yet availability; instruction to select a statistic and leading dash remain.
Rumput subur describes lush visual appearance; does not add fertility mechanics.
Rumput kering describes dry grass appearance without changing resource behaviour.
Pasir gumuk is concise dune-associated sand material; avoids duplicated pasir and preserves dune distinction.
Pasir pucat describes pale sand colour, distinct from dune sand.'''.splitlines()
nbreasons='''Early attack names the AI rush strategy and matches native tag.
Defensive strategy adjective matches native terminology.
Economy strategy matches native Økonomi.
Expansion strategy retained as ordinary Norwegian loanword.
Experimental adjective matches native tag.
Beginner-friendly compound is idiomatic and preserves target audience.
File and API-profile check retains file/API concepts without inventing a format.
Coordinated compound preserves syntax and profile restrictions.
Oppstart and tilbakekallsfunksjon preserve startup and callback concepts.
Persistent state is vedvarende tilstand, distinct from persistent storage.
Fixed seed value makes deterministic seeded gameplay explicit.
Repeterbar preserves repeatable simulation, without stronger correctness claim.
Save and resume actions preserve both halves of continuation check.
Good connection quality matches native God.
Fair connection quality is middle-grade Middels, not fairness.
Poor connection quality is Dårlig, not financial poverty.
Round-trip time, player/relay endpoints, prematch probe and approximate regional estimate all preserved.
Delay is ordinary Forsinkelse, suitable network heading.
Input delay remains click-to-action for everyone; half ping plus jitter buffer preserved.
Behind-clock meaning, normal under-one-second including delay and slow threshold from 2 s all preserved.
Classic glossy finish is klassisk blank, preserving sheen rather than emptiness.
Basics category is Grunnleggende.
Matte finish is Matt, paired with glossy rather than a carpet.
Riveted metal retains visible fasteners.
Metal material label is Metall.
Hairy visual material is Hårete.
Organic material category is Organisk.
Tegneseriestil conveys cartoon rendering style, not a comic document.
Woven fabric retains weave and cloth.
Craft category uses Håndverk.
Seigflytende slim conveys viscous goo rather than watery liquid.
Wet material category is Våt.
Wood material is Tre rather than forest.
Stone material is Stein.
Mineral is a legitimate identical Norwegian material word.
Scales means animal Skjell, not measurement scales.
Leather is Lær, not learning.
Crystal material is Krystall.
Lava is a legitimate identical Norwegian geology word.
Chrome material is Krom rather than browser product.
Carbon fibre compound is Karbonfiber.
Velvet fabric is Fløyel.
Honeycomb is Vokskake, a bee-comb visual material.
Ice is Is, matching native terrain.
Cloud is Sky, matching native name.
Hammered finish is Hamret metall, distinct from riveted metal.
Candy is Sukkertøy, preserving sweet appearance.
Slime is Slim, distinct from extra-viscous goo label.
KI-spiller matches existing Norwegian KI abbreviation and player compound.
Finanser labels the finance administration section.
Kontoer means accounts, not accounting entries.
Revisjonslogg accurately identifies audit-log navigation in administration.
One hour retains singular time unit.
One day retains singular day unit.
One week retains singular week unit.
Thirty days retains numeric value and plural unit.
Mest spilt matches existing native popularity label.
Music review instruction preserves listening for structure and development.
All three moods must play correctly; not an instruction to compose moods.
Unexpected volume jumps between moods remain the listening target.
Click, gap and abrupt change at repeat boundary all retained.
Short musical phrases repeating mechanically remain the specific defect.
Switching music mood and listening for timing/harmony changes both retained.
Building/combat/calm explicitly use existing Bygging/Kamp/Rolig mood names.
Quiet-passage hiss and scratchiness both retained as audio defects.
Muddy bass and harsh high frequencies remain separate listening targets.
Calm passages must remain audible alongside game sound.
Unexpected note truncation is preserved as an audio defect.
Worker matches native Arbeider role.
Warrior matches native Kriger role.
Explorer matches native Utforsker role.
Swarm matches native Sverm building name.
Classic appearance matches native Klassisk.
Crown appearance is Krone.
Clutch is Eggkull in egg-cluster skin context, not a mechanical clutch.
Toadstool skin is Sopp; does not invent toxicity mechanics.
Broad cap and small young mushrooms both preserved in appearance description.
Coral appearance is Korall.
Skep is explicitly a woven beehive, not a generic basket.
Coiled hive, supporting stand and viewer-facing entrance all retained.
Bloom skin is Blomst, suitable flower-shaped appearance.
Public visibility retains catalog listing.
Unlisted visibility retains anyone-with-link access, not privacy.
Private visibility limits access to the owner.
Server replay and all players agreeing are preserved as matching game states.
Current checking and ratings changing only after verification remain explicit.
Player divergence and authoritative server result both preserved.
Failure to reproduce means no rating changes, not necessarily a player loss.
Present passive kontrolleres ikke conveys not-applicable checking policy, distinct from not-yet-checked pending state.
Incomplete check, temporary absence of rating changes and administrator retry all retained.
Walk action is Gå.
Swim action is Svømme.
Harvest action is Høste, not construction work.
Fight action is Slåss.
Fly action is Fly, a legitimate identical Norwegian infinitive.
Live payments explicitly means real money, distinct from test mode.
Testbetalinger clearly labels test payments.
Unclassified payments remain unclassified rather than unpaid.
Current reporting period is Gjeldende periode.
Previous reporting period is Forrige periode.
Credit grant is an allocation of existing Kreditter currency.
Returned credits retain return meaning, without implying a new purchase.
Financial dispute is Tvist.
Closed dispute is Tvist avsluttet, not a resolved-in-user-favour claim.
Started matches are Startede kamper, preserving event-count semantics.
Completed matches are Fullførte kamper.
Cancelled matches are Avlyste kamper, distinct from finished games.
Publications label preserves value0 exactly and moves count after colon for natural Norwegian.
Recorded downloads retains recorded qualification and value0 exactly.
Completion-time label preserves value0 and seconds unit.
Completion samples are recorded completion measurements; value0 remains exact.'''.splitlines()
assert len(msreasons)==16 and len(nbreasons)==111
assert len(ms['translations'])==16 and len(nb['translations'])==111
changes={k:(nb1['translations'][k],v) for k,v in nb['translations'].items() if v!=nb1['translations'][k]}
assert changes=={'This match is not checked.':('Denne kampen er ikke kontrollert.','Denne kampen kontrolleres ikke.')}
reconstructed=dict(nb['translations']);reconstructed['This match is not checked.']=nb1['translations']['This match is not checked.'];assert reconstructed==nb1['translations'];assert h(reconstructed)==nb1['authored_target_subset_sha256']
refs={}
for l in ['da','sv','de']:
 raw=Path('platform/packages/i18n/locales/'+l+'.json').read_bytes();d=json.loads(raw);refs[l]={'catalog_sha256':sha(raw),'exact_new_keys_available':sum(k in d for k in nb['sources']),'compared_existing_anchors':{k:d.get(k) for k in ['AI','Calm','Building','Combat','Public','Private','Credits','Rating','Replay','Match','Overview']}}
for name,a,reasons,locale,surface in [('native-adversarial-review.json',ms,msreasons,'ms','native'),('nb-adversarial-review.json',nb,nbreasons,'nb','online')]:
 inp=p/('authored.json' if locale=='ms' else 'nb-authored-v2.json');assert sha(json.dumps(a['sources'],ensure_ascii=False,sort_keys=True).encode())==a['source_subset_sha256'];assert h(a['translations'])==a['authored_target_subset_sha256']
 rows=[{'key':surface+':'+k,'source':a['sources'][k],'value':v,'decision':'accept','reason':reason} for (k,v),reason in zip(a['translations'].items(),reasons)]
 report={'identity':'malay_adversary','role':'independent_adversarial_reviewer','locale':locale,'scope':'Only the new supplement keys; actual full reading of all listed source/target pairs, no claim to re-read earlier catalogs.','upstream':a['upstream'],'input_path':str(inp),'input_file_sha256':sha(inp.read_bytes()),'source_subset_sha256':a['source_subset_sha256'],'source_subset_hash_format':'JSON ensure_ascii=False, sort_keys=True, default separators','target_subset_sha256':h(a['translations']),'adversarial_reviewed_keys':[x['key'] for x in rows],'reviewed_count':len(rows),'per_key_review':rows,'findings':[],'edits':[],'unresolved_uncertainty':[],'reference_evidence':{'native_context':'Read upstream InGameStatistics.cpp topic/section/history/details/missing-reading uses and terrain tileset keys/previews; read existing Malay overlay/grass/sand vocabulary and NB native role/tag/quality anchors.','online_context':'Read protocol AI check labels, Match.tsx verdict mapping (not_applicable distinct from pending) and admin metric names.','ms_reference_catalog_sha256':sha(Path('platform/packages/i18n/locales/ms.json').read_bytes()),'comparison_catalogs':refs,'availability_limit':'All 111 corresponding DA/SV/DE values were read from current comparison catalogs; upstream catalogs lack these additions, so existing upstream anchors were checked separately. Malay authored Pasir gumuk was assessed as a dune-associated material label; DBP fetch in this pass timed out, so no new external-source verification claim.'},'certification':'Agent-reviewed; not native-human-certified'}
 if locale=='nb':report['focused_amendment_renewal']={'initial_whole_read_input_sha256':sha((p/'nb-authored.json').read_bytes()),'initial_whole_read_keys':111,'focused_re_read_key':'online:This match is not checked.','old_value':changes['This match is not checked.'][0],'new_value':changes['This match is not checked.'][1],'unchanged_values_verified':110,'reconstructed_initial_target_subset_sha256':h(reconstructed),'initial_recorded_target_subset_sha256':nb1['authored_target_subset_sha256'],'proof':'Restoring only this amended value exactly reproduces all 111 original values and original recorded target subset hash. Re-read amended present-passive wording in not_applicable source context.'}
 (p/name).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(name,len(rows),report['input_file_sha256'],report['target_subset_sha256'])
