import json,hashlib,importlib.util
from pathlib import Path
p=Path(__file__).parent;ip=p/'terrain-gaps-authored.json';a=json.loads(ip.read_text());init=p/'terrain-gaps-initial-draft.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def h(v):return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
spec=importlib.util.spec_from_file_location('c','data/check_translations.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
refs={}
for l in ['hi','ur','sw']:
 path=Path('data/texts.'+l+'.txt');d,e=c.read_table(path);assert not e;refs[l]={'file_sha256':sha(path.read_bytes()),'anchors':{k:d[k] for k in ['[grass]','[sand]','[theme dune]','[Dunes and mesas]']}}
assert sha(init.read_bytes())==a['initial_draft_sha256'];assert h(a['sources'])==a['source_subset_sha256'];assert h(a['translations'])==a['authored_target_subset_sha256']
reasons={
'hi':['हरी-भरी conveys lush green growth with established घास grass noun; appropriate appearance description.','सूखी agrees with घास and conveys dry grass without additional simulation effects.','टीलों की रेत means dune-associated sand; correct material head रेत rather than API dunes-as-objects रेत के टीले.','हल्के रंग की explicitly specifies pale colour rather than possible low-weight हल्की; retains रेत.'],
'ur':['سرسبز conveys lush green vegetation with established گھاس grass noun.','سوکھی گھاس is ordinary dry grass, with correct adjective/noun agreement.','ٹیلے کی ریت retains sand material and dune association, consistent with native ریت کا ٹیلہ.','ہلکے رنگ کی clarifies light colour rather than physical weight; retains established ریت.'],
'sw':['Nyasi mbichi contrasts fresh green grass with dry grass; appearance remains clear without gameplay fertility assertion.','Nyasi kavu is ordinary dry grass, preserving established Nyasi.','Mchanga wa matuta retains sand as head noun with existing matuta dune vocabulary; repairs API tautological sand of sand.','Mchanga wa rangi hafifu conveys pale muted colour rather than pure white; suits light-beige preview better than API mweupe.']}
rows=[]
for l,values in a['translations'].items():
 for (k,v),reason in zip(values.items(),reasons[l]):rows.append({'key':l+':native:'+k,'locale':l,'source':a['sources'][k],'value':v,'decision':'accept','reason':reason})
assert len(rows)==12
r={'identity':'malay_adversary','role':'independent_adversarial_reviewer','surface':'native','scope':'Actual independent reading of these 12 English/HI/UR/SW source-target pairs and API draft, with native glossary anchors and terrain context inspected in preceding MS/NB reviews. No claim to review older full catalogs.','input_file_sha256':sha(ip.read_bytes()),'initial_draft_file_sha256':sha(init.read_bytes()),'source_subset_sha256':h(a['sources']),'target_subset_sha256':h(a['translations']),'hash_format':'JSON ensure_ascii=False sort_keys=True compact separators','per_locale_target_subset_sha256':{l:h(v) for l,v in a['translations'].items()},'adversarial_reviewed_keys':[x['key'] for x in rows],'reviewed_count':12,'per_key_review':rows,'findings':[],'edits':[],'unresolved_uncertainty':[],'references':{'actual_native_glossaries':refs,'terrain_manifest_file_sha256':sha(Path('data/terrain/tileset.json').read_bytes()),'terrain_context':'Same appearance/material keys inspected previously; dune_sand preview202,150,85 and pale_sand210,201,168 describe tan/beige rather than pure white. No rendered glyph/layout assessment in this linguistic pass.'},'certification':'Agent-reviewed; not native-human-certified'}
(p/'terrain-gaps-adversarial-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(r['input_file_sha256'],r['target_subset_sha256'])
