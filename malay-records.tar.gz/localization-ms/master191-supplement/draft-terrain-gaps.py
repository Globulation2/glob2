import importlib.util,json
from pathlib import Path
R=Path.cwd();P=R/'artifacts/localization-ms/master191-supplement';s=importlib.util.spec_from_file_location('cloud',R/'tools/localization/cloud_draft.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
sources={k:v for k,v in json.load(open(P/'sources.json'))['sources'].items() if k in ['[lush_grass]','[dry_grass]','[dune_sand]','[pale_sand]']};translations={}
for locale in ['hi','ur','sw']:
 protected=[m.protect(v) for v in sources.values()];response=m.translate('bradley-personal-20261027',m.payload('bradley-personal-20261027',locale,[p[0] for p in protected]));m.atomic_json(P/f'terrain-gaps-{locale}-provider-response.json',response);translations[locale]={k:m.restore(row['translatedText'],p[1]) for k,row,p in zip(sources,response['translations'],protected)}
m.atomic_json(P/'terrain-gaps-initial-draft.json',{'role':'machine_draft','project':'bradley-personal-20261027','model':'general/nmt','sources':sources,'translations':translations});print(json.dumps(translations,ensure_ascii=False,indent=2))
