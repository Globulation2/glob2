from pathlib import Path
import json
P=Path(__file__).resolve().parent;R=Path.cwd();out=P/'resolved'
p=R/'tools/MobileGalleryHarness.cpp';s=p.read_text();s=s.replace('#include "GameGUITouch.h"','#include "GameGUITouch.h"\n#include "InGameStatistics.h"');needle='\t\tcapture("game-tactical-tools");\n';assert s.count(needle)==1
code='''		// Capture the real topic layout in every presentation before returning
		// to the fixture's normal tools and overlay states.
		gui.touch->lensOpen = false;
		gui.touch->panelOpen = false;
		gui.touch->statsOpen = !desktopPresentation;
		for (const auto &[topic, name] : {
			std::pair{InGameStatisticsPanel::Topic::Overview, "overview"},
			std::pair{InGameStatisticsPanel::Topic::Colony, "colony"},
			std::pair{InGameStatisticsPanel::Topic::Economy, "economy"},
			std::pair{InGameStatisticsPanel::Topic::Military, "military"},
			std::pair{InGameStatisticsPanel::Topic::World, "world"}})
		{
			gui.statistics().selectTopic(topic);
			capture(std::string("game-statistics-topic-") + name);
		}
		gui.statistics().selectTopic(InGameStatisticsPanel::Topic::Overview);
		gui.touch->statsOpen = false;
'''
s=s.replace(needle,needle+code);target=out/'tools/MobileGalleryHarness.cpp';target.parent.mkdir(exist_ok=True,parents=True);target.write_text(s)
p=R/'tools/mobile_gallery/catalog.json';d=json.loads(p.read_text());anchor=next(i for i,x in enumerate(d['screens']) if x['id']=='game-stats-sheet')
for name,title in reversed([('overview','Overview'),('colony','Colony'),('economy','Economy'),('military','Military'),('world','World')]):
 d['screens'].insert(anchor+1,{'id':'game-statistics-topic-'+name,'title':'In-game statistics: '+title.lower(),'description':'The real statistics '+name+' topic in the desktop sidebar or compact phone sheet, using the shared production panel.','group':d['screens'][anchor]['group']})
target=out/'tools/mobile_gallery/catalog.json';target.parent.mkdir(exist_ok=True,parents=True);target.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print('Prepared five actual statistics topic captures; checkout unchanged.')
