"""Compare the completed real-font matrices; never treat raw raster width as draw width."""
import argparse,json,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('before',type=Path);p.add_argument('after',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args();old=json.loads(a.before.read_text());new=json.loads(a.after.read_text());identity=lambda row:(row['surface'],row['key'],row.get('branch',''),row['size'],row['scale']);idx={identity(s):s for s in new['samples']};before_bad=[];fixed=[];unmatched=[]
for s in old['samples']:
 for line in s['lines']:
  if line['drawn_fits_width'] and line['drawn_fits_height']:continue
  before_bad.append((s,line));target=idx.get(identity(s));candidates=[v for v in target['lines'] if v['text']==line['text']] if target else []
  if len(candidates)!=1:unmatched.append({'sample':identity(s),'text':line['text'],'matches':len(candidates)});continue
  v=candidates[0];fixed.append({'sample':identity(s),'text':line['text'],'before_drawn_width':line['drawn_width'],'after_drawn_width':v['drawn_width'],'after_drawn_fits_width':v['drawn_fits_width'],'after_drawn_fits_height':v['drawn_fits_height'],'after_page':v['png']})
report={'before_manifest_sha256':hashlib.sha256(a.before.read_bytes()).hexdigest(),'after_manifest_sha256':hashlib.sha256(a.after.read_bytes()).hexdigest(),'before_draw_diagnostics':len(before_bad),'matched_diagnostics':len(fixed),'after_resolved_count':sum(x['after_drawn_fits_width'] and x['after_drawn_fits_height'] for x in fixed),'unmatched':unmatched,'cases':fixed,'limits':'Before matrix used the baseline executable/catalog; final matrix uses final producer and expanded catalog. The old values compared here are unchanged. Raw raster metrics can remain wider while actual authored draw destinations now fit.'};a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ['cases','limits']});assert not unmatched and report['after_resolved_count']==len(before_bad)
