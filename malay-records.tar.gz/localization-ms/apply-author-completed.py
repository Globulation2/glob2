import importlib.util,json
from pathlib import Path
r=Path(__file__).resolve().parent; root=r.parents[1]
s=importlib.util.spec_from_file_location('t',root/'tools/localization/translation_program.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t)
m=json.loads((r/'manifest.json').read_text()); done=set(json.loads((r/'author-reviewed-batches.json').read_text())); edits=json.loads((r/'author-edits.json').read_text()); log=r/'applied-author-batches.json'; applied=json.loads(log.read_text()) if log.exists() else {}; paths=t.catalog_paths(r,'ms'); target={'native':t.CHECKER.read_table(paths['native'])[0],'online':json.loads(paths['online'].read_text())}; count=0
for b in m['batches']:
 if b['id'] not in done or b['id'] in applied:continue
 ids=set(b['keys'])
 for e in edits:
  if e['surface']+':'+e['key'] in ids:target[e['surface']][e['key']]=e['value'];count+=1
 subset={id:target[id.split(':',1)[0]][id.split(':',1)[1]] for id in b['keys']}; h=t.digest(json.dumps(subset,sort_keys=True,ensure_ascii=False).encode()); t.write_json(r/'authored-batches'/f"{b['id']}.json",{'id':b['id'],'source_sha256':m['source_sha256'],'target_sha256':h,'values':subset});applied[b['id']]=h
paths['native'].write_text(''.join(k+'\n'+v+'\n' for k,v in target['native'].items()),encoding='utf-8');t.write_json(paths['online'],target['online']);t.write_json(log,applied);print('Authored snapshots',len(applied),'new corrections',count)
