from pathlib import Path
import hashlib
import json
import sys

root = Path.cwd()
sys.path.insert(0, str(root))
sys.path.insert(0, str(root / 'test'))
from tools.package_assets import source_files
from scons.web_assets import plan, contents
from build_provenance import source_identity

base = root / 'artifacts/localization-ms/validation'
before = source_identity()
assert before['revision'] == '11d72bf8c881b5db07c33feaa251aef326c15c84' and not before['dirty'], before
expected = {
    'data/texts.ms.txt': '089342b616992ec2bad3328083a8e0061b6fe96321547422aac96e5235acc153',
    'platform/packages/i18n/locales/ms.json': 'eb18efdc85988b0379ad0c33affd880e4be83651d9955be9b0f3d772a5d03064',
}
fonts = sorted(p.relative_to(root).as_posix() for p in (root / 'data/fonts').rglob('*.ttf'))
font_hashes = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in fonts}
receipt = {
    'validation': 'Actual source selection functions only; no package build, release or device execution claim',
    'command': 'python3 artifacts/localization-ms/check-package-selection-master191.py',
    'sourceBefore': before,
    'simRevision': 111,
    'saveVersion': 191,
    'platforms': {},
    'existingRuntimeFontSourceSha256': font_hashes,
    'catalog_sha256': {},
    'scope_limit': 'OS/store descriptive metadata remains outside the agreed in-game/browser/online/server-page scope; this proof covers selected catalogs, inventories and existing runtime fonts.',
}
for platform in ('linux', 'android', 'ios'):
    files = {p.relative_to(root).as_posix() for p in source_files(root, platform)}
    selected_fonts = [name for name in fonts if name in files]
    values = {
        'source_asset_count': len(files),
        'malay_catalog_selected': 'data/texts.ms.txt' in files,
        'language_inventory_selected': 'data/texts.list.txt' in files,
        'primary_font_selected': 'data/fonts/sans.ttf' in files,
        'all_existing_runtime_fonts_selected': set(fonts).issubset(files),
        'selected_runtime_fonts': selected_fonts,
    }
    assert all(values[k] for k in ('malay_catalog_selected', 'language_inventory_selected', 'primary_font_selected', 'all_existing_runtime_fonts_selected')), values
    receipt['platforms'][platform] = values
packages, skipped, substitutes = plan(root)
path = 'data/texts.ms.txt'
full = (root / path).read_bytes()
stub = contents(root, 'core', path, substitutes)
assert path in packages['core'] and path in packages['translations']
assert b'Bahasa Melayu' in stub and len(stub) < len(full)
assert contents(root, 'translations', path, substitutes) == full
assert 'data/fonts/sans.ttf' in packages['core']
assert all(name in packages['core'] for name in fonts if name.startswith('data/fonts/scripts/'))
core_font = contents(root, 'core', 'data/fonts/sans.ttf', substitutes)
assert core_font
receipt['platforms']['browser'] = {
    'malay_stub_in_core': True,
    'stubBytes': len(stub),
    'full_malay_catalog_in_translations': True,
    'fullCatalogBytes': len(full),
    'online_catalog_available': (root / 'platform/packages/i18n/locales/ms.json').is_file(),
    'existing_primary_font_in_core': True,
    'all_existing_script_fonts_in_core': True,
    'primary_font_core_substitute': substitutes.get(('core', 'data/fonts/sans.ttf'), substitutes.get('data/fonts/sans.ttf')),
    'primary_font_core_bytes': len(core_font),
    'primary_font_core_sha256': hashlib.sha256(core_font).hexdigest(),
}
for name, wanted in expected.items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    assert actual == wanted, (name, actual)
    receipt['catalog_sha256'][name] = actual
receipt['sourceAfter'] = source_identity()
receipt['sourceStable'] = before == receipt['sourceAfter']
assert receipt['sourceStable']
out = base / 'package-source-selection-master191.json'
out.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'source': before, 'platforms': receipt['platforms'], 'catalog_sha256': receipt['catalog_sha256'], 'sourceStable': True}, indent=2))
