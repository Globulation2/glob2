"""Capture final full-catalog matrix, menus and all current tutorial lessons."""
import argparse,hashlib,json,os,subprocess,time,importlib.util
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
r=Path(__file__).resolve().parent;root=r.parents[1]
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--only',choices=['matrix','screens','game','ui']);p.add_argument('--workers',type=int,default=3);p.add_argument('--viewport',choices=['all','desktop','phone'],default='all');p.add_argument('--draft-dir',type=Path);p.add_argument('--labels',help='Comma-separated isolated job labels for focused refreshes');a=p.parse_args();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);draft=(a.draft_dir or r/'drafts/ms').resolve();jobs=[]
for name,w,h,mobile in [('desktop',1280,800,False),('phone',390,844,True)]:
 jobs.append(('matrix',name,w,h,mobile,100,None))
 for screen in ['main','settings','settings-audio','settings-player','lobby','lobby-players']:jobs.append(('screen',name,w,h,mobile,100,screen))
lessons=[json.loads((root/e['definition']).read_text())['id'] for e in json.loads((root/'scripts/tutorials/catalog.json').read_text())]
for name,w,h,mobile in [('desktop',1280,800,False),('phone-landscape',844,390,True)]:
 for kind in ['gameplay',*['tutorial:'+id for id in lessons]]:jobs.append(('game',name,w,h,mobile,100,kind))
for screen in ['main','settings']:jobs.append(('screen','phone-large-text',390,844,True,150,screen))
jobs.append(('game','phone-large-text',844,390,True,150,'tutorial:introduction'))
spec=importlib.util.spec_from_file_location('capture_provenance',root/'test/build_provenance.py');provenance=importlib.util.module_from_spec(spec);spec.loader.exec_module(provenance)
frozen=provenance.source_identity(root)
producers=[]
for line in subprocess.check_output(['strings',str(a.binary.resolve())],text=True,errors='replace').splitlines():
 if line.startswith('{"compiler"'):
  try:
   value=json.loads(line)
   if 'sourceTreeSha256' in value:producers.append(value)
  except json.JSONDecodeError:pass
if len(producers)!=1:raise RuntimeError('Cannot uniquely identify compiled preview provenance')
issues=provenance.build_issues(producers[0],frozen)
if issues:raise RuntimeError('; '.join(issues))
report={'producer':producers[0],'source_identity':frozen,'binary':str(a.binary.resolve()),'binary_sha256':hashlib.sha256(a.binary.read_bytes()).hexdigest(),'jobs':[],'limits':['Native Linux execution; phone dimensions/presentation do not establish Android/iOS execution.']}
jobs=[job for job in jobs if (not a.only or (a.only=='ui' and job[0]!='matrix') or job[0]==({'screens':'screen'}.get(a.only,a.only))) and (a.viewport=='all' or job[1].startswith(a.viewport))]
if a.labels:
 selected=set(a.labels.split(','));jobs=[job for job in jobs if '-'.join([job[1],job[0],(job[6] or 'all').replace(':','-')]) in selected]
 if len(jobs)!=len(selected):raise RuntimeError('Unknown capture label')
def capture(job):
 mode,name,w,h,mobile,scale,screen=job
 before=provenance.source_identity(root);binary_before=hashlib.sha256(a.binary.read_bytes()).hexdigest()
 if before!=frozen or binary_before!=report['binary_sha256']:raise RuntimeError('Source or producer changed before capture; refresh provenance before continuing')
 label='-'.join([name,mode,(screen or 'all').replace(':','-')]);directory=out/label;directory.mkdir(exist_ok=True);profile=out/'profiles'/label;profile.mkdir(parents=True,exist_ok=True);(profile/'preferences.txt').write_text(f'language=ms\ntextSizePercent={scale}\n')
 env=dict(os.environ);env.update(GLOB2_MOBILE_UI='1' if mobile else '0',GLOB2_USER_DATA_DIR=str(profile),SDL_VIDEO_DRIVER='dummy',SDL_VIDEODRIVER='dummy',SDL_AUDIO_DRIVER='dummy',SDL_AUDIODRIVER='dummy',SDL_RENDER_DRIVER='software');env['LD_LIBRARY_PATH']=':'.join([str(r/'validation/sdl3/prefix/lib'),str(r/'validation/recording/prefix/lib'),env.get('LD_LIBRARY_PATH','')]);cmd=[str(a.binary.resolve()),mode,str(root),str(draft),str(directory),str(w),str(h)]+([screen] if screen else [])
 start=time.monotonic()
 with (directory/'capture.log').open('w') as log:result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=3600 if mode=='matrix' else 900)
 after=provenance.source_identity(root);binary_after=hashlib.sha256(a.binary.read_bytes()).hexdigest()
 return {'source_before':before,'source_after':after,'binary_before':binary_before,'binary_after':binary_after,'source_and_binary_stable':before==after and binary_before==binary_after,'label':label,'command':cmd,'width':w,'height':h,'compact':mobile,'textSizePercent':scale,'returncode':result.returncode,'seconds':round(time.monotonic()-start,2)}
with ThreadPoolExecutor(max_workers=a.workers) as pool:
 for future in as_completed([pool.submit(capture,job) for job in jobs]):
  result=future.result();report['jobs'].append(result)
  (out/'capture-run.json').write_text(json.dumps(report,indent=2)+'\n');print(result['label'],result['returncode'],flush=True)
  if result['returncode'] or not result['source_and_binary_stable']:raise SystemExit(result['returncode'] or 99)
