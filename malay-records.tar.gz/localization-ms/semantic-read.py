import json,sys
from pathlib import Path
p=Path(__file__).parent
source={s:json.load(open(p/f'source/{s}.json')) for s in ['native','online']}
for b in sys.argv[1:]:
 d=json.load(open(p/f'authored-batches/{b}.json'));print('\nBATCH',b,d['target_sha256'])
 for n,(k,v) in enumerate(d['values'].items()):
  surf,key=k.split(':',1); en=source[surf][key]
  print(f'{n} {key} | {en} => {v}')
