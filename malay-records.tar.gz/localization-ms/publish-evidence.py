"""Publish prepared review files through a private index, preserving the checkout."""
import argparse,hashlib,json,os,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--expected-head',required=True);p.add_argument('--branch',default='codex/malay-language-evidence');p.add_argument('--execute',action='store_true');a=p.parse_args();R=Path.cwd();folder=a.input.resolve();assert folder.is_dir() and folder.is_relative_to(R/'artifacts');assert a.branch.startswith('codex/')
def git(*args,env=None,input=None):return subprocess.check_output(['git',*args],env=env,input=input,text=True).strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert git('rev-parse','HEAD')==a.expected_head;assert not git('status','--porcelain');assert a.expected_head in (folder/'README.md').read_text();files=sorted(x for x in folder.rglob('*') if x.is_file());assert files and all(x.resolve().is_relative_to(folder) for x in files);assert all(x.stat().st_size<100*1024*1024 for x in files)
index_path=Path(git('rev-parse','--git-path','index')).resolve();before_index=sha(index_path);rows=[{'path':str(x.relative_to(folder)),'bytes':x.stat().st_size,'sha256':sha(x)} for x in files];plan={'source_head':a.expected_head,'branch':a.branch,'files':rows,'total_bytes':sum(x['bytes'] for x in rows),'execute':a.execute};print(json.dumps(plan,indent=2),flush=True)
if not a.execute:raise SystemExit(0)
ref='refs/heads/'+a.branch;old=subprocess.run(['git','rev-parse','--verify',ref],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True);parent=old.stdout.strip() if old.returncode==0 else None
worktrees=git('worktree','list','--porcelain');assert ('branch '+ref) not in worktrees.splitlines(),'Evidence branch is checked out; choose another evidence branch.'
with tempfile.TemporaryDirectory(prefix='malay-evidence-index-',dir=R/'artifacts/localization-ms') as temporary:
 env=dict(os.environ,GIT_INDEX_FILE=str(Path(temporary)/'index'));git('read-tree','--empty',env=env)
 for path in files:
  blob=git('hash-object','-w',str(path));name=str(path.relative_to(folder));git('update-index','--add','--cacheinfo','100644,'+blob+','+name,env=env)
 tree=git('write-tree',env=env);args=['commit-tree',tree]
 if parent:args+=['-p',parent]
 commit=git(*args,input='Publish Malay localization review evidence for '+a.expected_head+'\n')
 git('update-ref',ref,commit,parent or '0'*40)
assert sha(index_path)==before_index,'Main index changed unexpectedly';assert git('rev-parse','HEAD')==a.expected_head;assert not git('status','--porcelain');subprocess.check_call(['git','push','origin',ref+':'+ref]);result={**plan,'evidence_commit':commit,'main_index_sha256':before_index,'checkout_preserved':True};(R/'artifacts/localization-ms/validation/evidence-publication-result.json').write_text(json.dumps(result,indent=2)+'\n');print('Published immutable evidence commit '+commit,flush=True)
