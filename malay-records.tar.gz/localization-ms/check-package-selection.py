import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root));from tools.package_assets import source_files
from scons.web_assets import plan,contents
r=root/'artifacts/localization-ms/validation';p=r/'package-source-selection-final.json';v=json.loads(p.read_text());v['revision']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for platform in ['linux','android','ios']:
 files={p.relative_to(root).as_posix() for p in source_files(root,platform)}
 v['platforms'][platform]={'source_asset_count':len(files),'malay_catalog_selected':'data/texts.ms.txt' in files,'language_inventory_selected':'data/texts.list.txt' in files}
 assert all(v['platforms'][platform][k] for k in ['malay_catalog_selected','language_inventory_selected'])
packages,skipped,substitutes=plan(root);path='data/texts.ms.txt';stub=contents(root,'core',path,substitutes)
assert path in packages['core'] and path in packages['translations'];assert b'Bahasa Melayu' in stub;assert len(stub)<len((root/path).read_bytes());assert contents(root,'translations',path,substitutes)==(root/path).read_bytes()
v['catalog_sha256']={path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in ['data/texts.ms.txt','platform/packages/i18n/locales/ms.json']};v['platforms']['browser']={'malay_stub_in_core':True,'full_malay_catalog_in_translations':True,'online_catalog_available':(root/'platform/packages/i18n/locales/ms.json').is_file()};p.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v['platforms'],indent=2))
