import json,re,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
hashval=lambda v:hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
manifest=read(P/'manifest.json');raw={s:read(P/f'author-{s}-snapshot.json') for s in ('native','online')};effective=json.loads(json.dumps(raw))
for item in read(P/'author-edits.json'):effective[item['surface']][item['key']]=item['value']
reasons={
'%0 / %1 HP · %2':'The first two placeholders show current and maximum HP, with a third status value; HP is the established health abbreviation and all values are supplied at runtime.',
'AI':'AI is the recognized technical abbreviation for artificial intelligence; keeping it matches the named game feature and controller labels.',
'JavaScript':'JavaScript is the programming language proper name; translating it would misidentify the supported file language.',
'Globulation 2':'Globulation 2 is the game product name and must remain recognizable.',
'Globulation 2 Discord':'Globulation 2 and Discord are product/service names in this community link.',
'Hive Mind':'Hive Mind is the named commander feature; keeping its product name matches the account and credit interfaces.',
'OpenGL':'OpenGL is the graphics API identifier, not prose.',
'Audio':'Audio is also the standard Malay loanword for the sound settings category.',
'Editor':'Editor is used in Malay for an editing application; this is the map-editor menu label.',
'Hospital':'Hospital is the ordinary Malay word for the healing building.',
'HP':'HP is the existing hit-point abbreviation shown alongside game bars and numbers.',
'numlock':'numlock names the physical keyboard key; retaining its marking helps players identify it.',
'numlock':'numlock names the physical keyboard key; retaining its marking helps players identify it.',
'Plum':'Plum is the Malay loanword for the plum fruit; this preserves the specific fruit rather than introducing a different species.',
'tab':'tab is the keyboard key name, matching its physical label.',
'FFA':'FFA is the free-for-all format abbreviation shown in game setups.',
'Magenta':'Magenta is also the Malay name for this color.',
'Everglades':'Everglades names the generator inspired by that wetland region; preserve its proper geographical name.',
'Polder':'Polder is the established international name for this reclaimed-land form and the corresponding generator.',
'Veteran':'Veteran is a Malay loanword meaning experienced; suitable for the starting-unit skill preset.',
'Emoji':'Emoji is the standard borrowed term for the pictorial characters.',
'Asia':'Asia has the same geographical name in Malay.',
'Oceania':'Oceania is retained as the recognized regional name in the continent selector.',
'Bajada':'Bajada names the specific geographical landform and its generator; it is retained as a technical geographical label.',
'Playa':'Playa names the dry lake-bed landform in the generator controls; retain this precise geographical term.',
'Mesas':'Mesas names the flat-topped landform control; this is a technical geographical label.',
'Import':'Import is the Malay software action for bringing files into the application.',
'Menu':'Menu is also the Malay interface term for a command menu.',
'Slot':'Slot is the Malay loanword for an allocated player/interface position.',
'Ping':'Ping is the networking latency term; translating the protocol-related label would reduce clarity.',
'Jan':'Jan is the conventional Malay short form of Januari.',
'Feb':'Feb is the conventional Malay short form of Februari.',
'Apr':'Apr is the conventional Malay short form of April.',
'Jun':'Jun is the Malay month name and short form for June.',
'Sep':'Sep is the conventional Malay short form of September.',
'Nov':'Nov is the conventional Malay short form of November.',
'Import JavaScript AI':'Import is the Malay file action; JavaScript and AI identify the source language and controller type.',
'Blitz':'Blitz is the short named ruleset preset, retained as its recognizable name.',
'Lava':'Lava is the ordinary Malay geological word for molten rock.',
'Set':'Set is also the Malay noun for a collection/package in the content library.',
'Import ZIP':'Import is the Malay file action and ZIP is the archive format identifier.',
'Tag':'Tag is the software metadata loanword used for search labels.',
'Port':'Port is the established networking term; this setting is a TCP listening port.',
'Tutorial':'Tutorial is also a common Malay software/learning term for guided lessons.',
'JSON':'JSON is the file/data format acronym and must remain unchanged.',
'Moderator':'Moderator is the accepted Malay loanword for the community moderation role.',
'OK':'OK is the conventional confirmation button label also used in Malay interfaces.',
'Pose':'Pose is retained as the animation/modeling pose term in the skin preview.',
'Status':'Status is also the standard Malay word for an operation state.',
'Studio':'Studio is the Malay loanword for a creative workspace.',
'V':'V is the compact version marker on the music composition workspace, not an English sentence.',
'b-':'b- is a technical abbreviated identifier prefix, not translatable prose.',
'1.0.0':'1.0.0 is a semantic-version value; its digits and separators must remain exact.',
'/ais/favourites':'/ais/favourites is the application route path; translating its segments breaks navigation.',
'/ais/mine':'/ais/mine is the application route path; translating its segments breaks navigation.',
'public, max-age=604800':'public, max-age=604800 is an HTTP Cache-Control value; preserve the literal syntax.',
'text/html; charset=utf-8':'text/html; charset=utf-8 is a MIME type and charset value; preserve the protocol literal.',
'Import .js':'Import is the Malay action and .js is the required filename extension.',
'Import JavaScript':'Import is the Malay action and JavaScript is the programming language proper name.',
'Edit {value0}':'Edit is a familiar Malay software verb and {value0} is the runtime object name.',
}
for name in ('Castor','Maxima','Cortex','Nicowar','Numbi','Econo','Warrush','Cabino','Toubib'):
 reasons[name]=f'{name} is the named AI/controller identity, shared with source descriptions and opponent selectors; it is a proper name.'
for name in ('CC BY','CC BY 4.0','CC BY-SA 4.0','CC-BY-4.0','CC-BY-SA-4.0','CC0','CC0 1.0','CC0-1.0'):
 reasons[name]=f'{name} is the exact Creative Commons license name/identifier; preserve it for correct attribution and legal identification.'
accepted=[]
sources={s:read(P/f'source/{s}.json') for s in ('native','online')}
for b in manifest['batches']:
 for id in b['keys']:
  s,k=id.split(':',1);original=sources[s][k];value=effective[s][k]
  variants={'other':value} if isinstance(value,str) else value
  for category,text in variants.items():
   source=original if isinstance(original,str) else original.get(category)
   if not text.strip() or text!=source:continue
   reason=reasons.get(text)
   if not reason and re.fullmatch(r'f\d+',text):reason=f'{text} is a physical function-key label; the displayed key name must match the keyboard.'
   if not reason:
    residue=re.sub(r'%\d+|\{[A-Za-z][A-Za-z0-9_]*\}','',text)
    prefixes={'alt-':'The alt- modifier prefix names the physical Alt key.','meta-':'The meta- modifier prefix names the physical Meta key.','HP ≤25/50/75%':'HP and the threshold expression show exact health percentages.','CPU %':'CPU and percent express measured processor load.','sim ':'sim is the compact simulation-version marker.','AI: ':'AI labels a controller type.','Ok: ':'Ok is the common Malay confirmation response.','P //':'P is the compact diagnostic display prefix.','A · V':'A and V are compact asset/version markers.','B':'B is the compact building/version marker.','HTTP ':'HTTP is the protocol acronym.','JavaScript · ':'JavaScript identifies the source programming language.','Status: ':'Status is also the Malay word for an operation state.','V · ':'V is the compact version marker.','r · ':'r is the compact revision marker.','v':'v is the compact version marker.'}
    if residue in prefixes:reason=prefixes[residue]+' Runtime values retain their source placeholders.'
    elif not re.search(r'[A-Za-z]',residue):reason=f'The value {text!r} contains only runtime placeholders, numbers and/or interface symbols; there is no English prose to translate and its formatting is intentional.'
    elif re.fullmatch(r'[\s\d×/%·]+',re.sub(r'\b(?:min|s|KB)\b','',residue)) and re.search(r'\b(?:min|s|KB)\b',residue):reason=f'{text!r} is a numeric quantity using the standard min/s/KB unit symbol; preserve the runtime value and international unit.'
    elif residue=='/min':reason='/min is the compact per-minute unit notation; min is the Malay minute abbreviation too.'
   if not reason:raise ValueError(('Need individual reason',id,text,residue))
   accepted.append({'key':id+('/'+category if category!='other' else ''),'reason':reason})
write(P/'author-accepted-english.json',accepted)
review={'identity':'cloud_tooling','role':'author','source_sha256':manifest['source_sha256'],
 'input_snapshots':{s:{'path':f'author-{s}-snapshot.json','sha256':hashlib.sha256((P/f'author-{s}-snapshot.json').read_bytes()).hexdigest()} for s in raw},
 'references':['language-brief.json','data/texts.id.txt','data/texts.fr.txt','data/texts.de.txt'],
 'method':'Read every source/target pair in all 43 frozen batches, including optional blank lines, plural objects, long AI descriptions and every lesson/help paragraph. Correct machine errors and align terminology. This is an author reconciliation, not independent linguistic approval.',
 'batches':[], 'findings':[], 'limitations':['Agent-authored/reviewed; not native-human-certified. Independent reviewer and editor passes are still required.'],
 'accepted_english':accepted}
read_batches=set(read(P/'author-reviewed-batches.json'))
for b in manifest['batches']:
 if b['id'] not in read_batches:raise ValueError('Batch not marked read: '+b['id'])
 original={id:raw[id.split(':',1)[0]][id.split(':',1)[1]] for id in b['keys']}
 final={id:effective[id.split(':',1)[0]][id.split(':',1)[1]] for id in b['keys']}
 review['batches'].append({'id':b['id'],'author':'cloud_tooling','source_sha256':manifest['source_sha256'],
                          'input_target_sha256':hashval(original),'proposed_target_sha256':hashval(final),'authored_keys':b['keys']})
write(P/'author-review.json',review)
print('batches',len(review['batches']),'authored_keys',sum(len(b['authored_keys']) for b in review['batches']),'accepted_english',len(accepted))
