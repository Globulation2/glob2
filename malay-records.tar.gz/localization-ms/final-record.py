import json,sys
from pathlib import Path
p=Path(__file__).parent;rpath=p/'final-recheck.json';r=json.load(open(rpath)) if rpath.exists() else {'rechecked_by':'malay_brief','certification':'Agent-reviewed; not native-human-certified','batches':[],'findings':[]}
for batchid in sys.argv[1:]:
 d=json.load(open(p/f'edited-batches/{batchid}.json'));assert not any(b['id']==batchid for b in r['batches'])
 r['batches'].append({'id':batchid,'rechecked_by':'malay_brief','source_sha256':d['source_sha256'],'target_sha256':d['target_sha256'],'rechecked_keys':list(d['values']),'method':'Read every final edited Malay value against the previously reviewed frozen English source/context, independently rechecking meaning and prior semantic/editorial corrections. No native-human certification.'})
rpath.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');(p/'final-rechecked-batches.json').write_text(json.dumps([b['id'] for b in r['batches']],indent=2)+'\n')
if not (p/'final-recheck-edits.json').exists():(p/'final-recheck-edits.json').write_text('[]\n')
print(len(r['batches']),sum(len(b['rechecked_keys']) for b in r['batches']))
