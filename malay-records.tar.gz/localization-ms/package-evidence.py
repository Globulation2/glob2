"""Publish a bounded, hash-indexed review kit; never include dependency binaries."""
import argparse,hashlib,json,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parent;boundary=root.parent;out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);files=set()
def add(path):
 path=path.resolve()
 if path.name in {'root-state.json','root-work-current.json'}:return
 # Provider caches and intermediate editorial work stay local (ui-framework guide).
 if any(part in {'cloud','google','authored-batches','semantic-batches','edited-batches'} for part in path.relative_to(boundary).parts):return
 if path.suffix=='.json' and any(label in path.stem for label in ['provider-response','initial-draft','authored','-edits','-proposals','-snapshot']):return
 if path.is_file() and path.is_relative_to(boundary) and not path.is_relative_to(out):files.add(path)
for pattern in ['*.json','*.py','*.log']:
 for path in root.glob(pattern):add(path)
for name in ['ai-tags','admin-supplement','master190-supplement','master191-supplement','source','batches','drafts','reviews']:
 for path in (root/name).rglob('*'):
  if path.suffix in ['.json','.txt','.py','.cjs','.ts']:add(path)
for kit in ['localization-ms-final','localization-ms-final-admin','localization-ms-final-190','localization-ms-final-191']:
 for path in (boundary/kit).rglob('*'):
  if path.suffix in ['.json','.txt','.py','.log']:add(path)
excluded={'venv','sdl3','recording','profiles','profile','node_modules','runtime-assets','web-cross-browser-results','web-browser-results','master-80596-frontend'}
validation=root/'validation'
for path in validation.rglob('*'):
 relative=path.relative_to(validation)
 if any(part in excluded for part in relative.parts):continue
 if path.suffix in ['.json','.log','.txt','.py','.mjs','.cjs','.ts','.html','.xml','.g2mr'] or 'baseline-browser-fixtures' in relative.parts:add(path)
for name in ['sdl3/prefix/sdl3-manifest.json','recording/prefix/recording-manifest.json']:add(validation/name)
# Publish final screen states and the exact historical images cited by reviews.
# Gallery pixels are bounded; its complete capture manifest retains every hash.
for name in ['native-191','native-after-golden','web-final-72433','web-phone-paint-final','web-final-7133-before-shape-fix','web-root-reviewed-31566','web-root-reviewed-final','native-interim','gallery-generator-fixed','gallery-editor-isolated','browser-phone-results','browser-persistence-results','browser-startup-results','browser-master191-phone-results','browser-master191-persistence-results','browser-master191-staged-results','MASTER191-before-overview-fix']:
 for path in (validation/name).rglob('*.png'):add(path)
# Final runtime groups can add supported-renderer diagnostics; retain their actual pixels.
for directory in validation.glob('browser-master191-*-results'):
 if directory.is_dir():
  for path in directory.rglob('*.png'):add(path)
gallery_inventory=[]
for directory in sorted([directory for stage in ['gallery-final','gallery-191','gallery-191-large','gallery-final-layout','gallery-final-layout-large'] for directory in (validation/stage).glob('*')]):
 pages=sorted(directory.glob('*.png'))
 chosen={pages[i] for i in sorted({0,len(pages)//2,len(pages)-1})} if pages else set()
 chosen.update(path for path in pages if any(tag in path.stem for tag in ['win-probability','stats-sheet','statistics-topic','tactical-tools']))
 for path in pages:
  gallery_inventory.append({'path':str(path.relative_to(boundary)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'selected':path in chosen})
 for path in chosen:add(path)
def strings(value):
 if isinstance(value,str):yield value
 elif isinstance(value,dict):
  for child in value.values():yield from strings(child)
 elif isinstance(value,list):
  for child in value:yield from strings(child)
for record in [*root.glob('*review*.json'),*validation.glob('*review*.json'), validation/'native-final-layout-validation-result.json']:
 for value in strings(json.loads(record.read_text())):
  if value.endswith('.png'):
   for candidate in [root/value,record.parent/value,root.parents[1]/value]:
    if candidate.is_file():add(candidate)
(out/'image-publication-policy.json').write_text(json.dumps({'scope':'Final191 screenshots plus exact review-cited historical pixels; older fullnative capture manifests/hashes remain, with only reviewed historical pixels selected. Gallery keeps first/middle/last and statistics/tool states per job; full capture-run manifests retain all measured/captured hashes. Omitted gallery pixels are not claimed as visually inspected or published.','gallery_inventory':gallery_inventory},indent=2)+'\n')
# Full font manifests remain in the kit. Keep first/middle/last pages at every
# size/scale, plus the five exact pages independently inspected on the baseline.
font_inventory=[];selected=[]
for directory in sorted(validation.glob('*font-matrix*')):
 for manifest in directory.rglob('font-matrix.json'):
  add(manifest);pages=sorted(manifest.parent.glob('font-*-page-*.png'));groups={}
  for path in pages:
   prefix=path.name.split('-page-')[0];groups.setdefault(prefix,[]).append(path)
   font_inventory.append({'path':str(path.relative_to(boundary)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
  for group in groups.values():
   for index in sorted({0,len(group)//2,len(group)-1}):add(group[index]);selected.append(str(group[index].relative_to(boundary)))
for name in ['font-10-scale-2-page-019.png','font-10-scale-2-page-002.png','font-10-scale-2-page-107.png','font-13-scale-2-page-019.png','font-20-scale-2-page-019.png']:
 add(validation/'catalog-font-matrix/phone-matrix-all'/name)
(out/'font-page-inventory.json').write_text(json.dumps({'all_completed_matrix_pages':font_inventory,'bounded_representative_pages':selected,'note':'Only selected PNG pages are published. Full matrix JSON records every measured sample; selected pixels support visual review, not an assertion that every raster page was visually inspected.'},indent=2)+'\n')
def group(path):
 relative=str(path.relative_to(boundary))
 if 'font-matrix' in relative:return 'font-matrices'
 if path.suffix=='.png':
  if any(x in relative for x in ['web-','shape-','phone-paint']):return 'online-pixels'
  if any(x in relative for x in ['browser-','staged-assets']):return 'browser-pixels'
  return 'native-final-pixels' if any(x in relative for x in ['/native-191/','/gallery-final-layout']) else 'native-historical-pixels'
 return 'records'
index=[{'path':str(path.relative_to(boundary)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'archive':'malay-'+group(path)+'.tar.gz'} for path in sorted(files)]
(out/'file-index.json').write_text(json.dumps(index,indent=2)+'\n')
archives=[]
for label in sorted({group(path) for path in files}):
 archive=out/('malay-'+label+'.tar.gz')
 with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
  selected_files=sorted(path for path in files if group(path)==label)
  for path in selected_files:tar.add(path,arcname=str(path.relative_to(boundary)),recursive=False)
  if label=='records':
   for path in [out/'font-page-inventory.json',out/'file-index.json',out/'image-publication-policy.json']:tar.add(path,arcname='localization-ms/'+path.name,recursive=False)
 size=archive.stat().st_size
 if size>80*1024*1024:raise RuntimeError('Archive '+label+' exceeds80MiB limit; split deliberately, never silently drop evidence')
 archives.append({'path':archive.name,'files':len(selected_files),'bytes':size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()})
summary={'files':len(files),'uncompressed_bytes':sum(x['bytes'] for x in index),'archives':archives,'partition_policy':'All selected files are present exactly once across natural records/font/native-final/native-historical/online/browser archives; each archive is bounded to80MiB. Raw provider caches and intermediate editorial working files remain local.'}
(out/'archive-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
