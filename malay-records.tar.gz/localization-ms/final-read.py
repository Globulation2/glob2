import json,sys
from pathlib import Path
p=Path(__file__).parent
for b in sys.argv[1:]:
 d=json.load(open(p/f'edited-batches/{b}.json'));print('\nFINAL',b,d['target_sha256'])
 for n,(k,v) in enumerate(d['values'].items()): print(n,k.split(':',1)[1],'=>',v)
