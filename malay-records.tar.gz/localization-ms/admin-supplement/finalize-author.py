import json,hashlib,re
from pathlib import Path
P=Path(__file__).resolve().parent;R=Path.cwd();read=lambda n:json.load(open(P/n));q=read('proposal.json');raw=read('initial-draft.json');manual=read('author-edits.json');ms=read('authored-ms.json')['translations']['ms'];keys=q['keys'];locales=list(raw['translations']);assert len(locales)==36 and set(read('author-read-locales.json'))==set(locales)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def h(a):return hashlib.sha256(json.dumps(a,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
reasons={0:'Production real-money payment mode, not live streaming, direct or real-time processing.',2:'Historical payments lack a classification, not a customer status or secrecy classification.',5:'Administrative allocation of game/service credits, not a bank loan or subsidy.',6:'Unused reserved credits are returned, without implying cash reimbursement.',7:'Payment/credit dispute event; use a noun rather than an imperative verb.',8:'Dispute is closed; do not imply a won/lost or successfully resolved outcome.',9:'Count of started game matches; use the existing localized match noun and a metric caption.',10:'Count of completed game matches; use the existing localized match noun and a metric caption.',11:'Count of cancelled game matches; use the existing localized match noun and a metric caption.',12:'Library display name is interpolated, not a numeric count or a publisher/book title.',13:'Recorded download events/counters, not audiovisual recording, a subject doing the recording or transfer progress.',14:'Measured successful completion duration in seconds; preserve the existing completion terminology and the product-name placeholder.',15:'Measured completion samples/observations, not examples of how to finish or media samples.'}
translations={};edits=[];records=[];retentions=[]
for locale in locales:
 values=dict(raw['translations'][locale]);values.update({keys[int(i)]:v for i,v in manual.get(locale,{}).items()})
 if locale=='ms':values.update(ms)
 assert set(values)==set(keys)
 for key,value in values.items():
  assert isinstance(value,str) and value.strip();assert sorted(re.findall(r'\{[a-zA-Z][a-zA-Z0-9_]*\}',key))==sorted(re.findall(r'\{[a-zA-Z][a-zA-Z0-9_]*\}',value)),(locale,key,value)
  if key==value:retentions.append({'locale':locale,'key':key,'value':value})
  if value!=raw['translations'][locale][key]:edits.append({'locale':locale,'key':key,'initial':raw['translations'][locale][key],'value':value,'reason':reasons.get(keys.index(key),'Use an idiomatic reporting-window or localized administration-caption form consistent with existing terms.')})
 translations[locale]=values;records.append({'locale':locale,'authored_keys':keys,'source_subset_sha256':h({k:k for k in keys}),'initial_target_subset_sha256':h(raw['translations'][locale]),'authored_target_subset_sha256':h(values),'existing_catalog_reference_sha256':sha(R/f'platform/packages/i18n/locales/{locale}.json')})
assert not retentions,retentions
write('authored.json',{'author':'cloud_tooling','role':'author','source_sha256':q['source_sha256'],'initial_draft_sha256':sha(P/'initial-draft.json'),'translations':translations,'authored_keys':[l+':'+k for l in locales for k in keys],'locale_records':records,'edits':edits,'contexts':q['contexts'],'references':['platform/apps/web/src/admin/presentation.ts','platform/apps/web/src/admin/Finances.tsx','Existing per-locale Match, Purchase, Refund, Credits and Average successful completion time labels','Malay terminology audit read only after initial Cloud API draft'],'limitations':['Agent author reconciliation across all 36 targets, not native-human certification. Separate independent semantic, editorial and adversarial reviews are still required.'],'unresolved_uncertainty':[]})
write('author-accepted-english.json',{'author':'cloud_tooling','role':'author','source_sha256':q['source_sha256'],'entries':retentions,'note':'No authored whole value is English-identical; no exemptions requested.'})
# Author output only goes into the separate review kit, never the live catalog.
p=R/'artifacts/localization-ms-final-admin/drafts/ms/ms.json';d=json.load(open(p));before={k:v for k,v in d.items() if k not in keys};d.update(translations['ms']);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');assert before=={k:v for k,v in d.items() if k not in keys}
print('Authored',sum(map(len,translations.values())),'values;',len(edits),'context corrections; no English identities')
