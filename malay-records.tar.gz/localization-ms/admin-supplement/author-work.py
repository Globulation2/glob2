import json,sys,importlib.util
from pathlib import Path
P=Path(__file__).resolve().parent;R=Path.cwd();q=json.load(open(P/'proposal.json'));keys=q['keys'];s=importlib.util.spec_from_file_location('cloud',R/'tools/localization/cloud_draft.py');C=importlib.util.module_from_spec(s);s.loader.exec_module(C)
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
if sys.argv[1]=='read':
 for locale in sys.argv[2:]:
  print('\nLOCALE',locale)
  data=json.load(open(P/'provider-records'/f'{locale}.json'))['response']['translations'];old=json.load(open(R/f'platform/packages/i18n/locales/{locale}.json'));print('existingMatch/Purchase/Refund:',*[str(old.get(k)) for k in ['Match','Purchase','Refund']])
  for i,(k,v) in enumerate(zip(keys,data)):print(str(i)+'='+C.restore(v['translatedText'],C.protect(k)[1]))
if sys.argv[1]=='edits':
 path=P/'author-edits.json';all=json.load(open(path)) if path.exists() else {}
 for locale,edits in json.load(sys.stdin).items():all.setdefault(locale,{}).update(edits)
 write(path,all)
if sys.argv[1]=='mark':
 path=P/'author-read-locales.json';all=json.load(open(path)) if path.exists() else [];write(path,list(dict.fromkeys(all+sys.argv[2:])))
