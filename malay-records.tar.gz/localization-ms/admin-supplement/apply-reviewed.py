import json,hashlib,shutil
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[2];read=lambda f:json.loads((p/f).read_text());c=read('reviewed-candidate.json');a=read('authored.json')
for f in ['semantic-focused-final.json','editor-focused-final.json','adversarial-focused-final.json']:
 d=read(f);assert d['source_sha256']==c['source_sha256'];print('Finalfocusedrecord:',f)
en=json.loads((root/'platform/packages/i18n/locales/en.json').read_text());assert len(en)==2947;proof=[]
for l,values in c['translations'].items():
 path=root/f'platform/packages/i18n/locales/{l}.json';old=json.loads(path.read_text());assert len(old)==2931 and not(set(old)&set(values));new={**old,**values};assert set(new)==set(en);assert all(new[k]==v for k,v in old.items());assert all(v!=en[k] for k,v in values.items());path.write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n');proof.append({'locale':l,'old_keys_unchanged':len(old),'new_keys':len(values),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
draft=root/'artifacts/localization-ms-final-admin/drafts/ms';ms=root/'platform/packages/i18n/locales/ms.json';(draft/'ms.json').write_bytes(ms.read_bytes());(draft/'online.json').write_bytes(ms.read_bytes());prior=root/'artifacts/localization-ms-final/drafts/ms'
for f in ['texts.ms.txt','native.json']:assert (draft/f).read_bytes()==(prior/f).read_bytes()
(p/'applied-data-proof.json').write_text(json.dumps({'source_sha256':c['source_sha256'],'catalogs':proof,'old_values_changed':0,'new_english_matches':0,'total_new_values':576},indent=2)+'\n');print('Applied576newvalues; allpriorvaluesunchanged')
