import json,copy,hashlib
from pathlib import Path
p=Path(__file__).parent;read=lambda f:json.loads((p/f).read_text());a=read('authored.json');out=copy.deepcopy(a['translations']);edits={};resolutions=[]
for role,rows in [('semantic',read('semantic-edits.json')),('editor',read('editor-edits.json')),('adversarial',read('adversarial-review.json')['proposals'])]:
 for e in rows:
  loc,key=e['locale'],e['key'];old=e.get('old',e.get('old_value'));assert old==a['translations'][loc][key]
  value=e['value']
  if loc=='de' and key=='Matches cancelled':
   value='Abgesagte Matches'
   if role=='editor':resolutions.append({'locale':loc,'key':key,'editor_proposal':e['value'],'value':value,'reason':'Prefer semantic reviewer pre-start cancellation wording over annulment: cancelled match is distinct from an aborted running match; generic old Cancelled label remains unchanged.'})
  k=(loc,key)
  if k in edits:assert edits[k]['value']==value
  else:edits[k]={'locale':loc,'key':key,'old':old,'value':value,'reviewers':[],'reasons':[]}
  edits[k]['reviewers'].append(role);edits[k]['reasons'].append(e.get('reason',e.get('context')));out[loc][key]=value
changed=sum(out[l][k]!=v for l,d in a['translations'].items() for k,v in d.items());assert changed==len(edits)==15
r={'source_sha256':a['source_sha256'],'author_input_sha256':hashlib.sha256((p/'authored.json').read_bytes()).hexdigest(),'translations':out,'accepted_edits':list(edits.values()),'resolutions':resolutions,'changed_count':changed,'unchanged_count':576-changed,'certification':'Agent-reviewed; not native-human-certified'};(p/'reviewed-candidate.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(hashlib.sha256((p/'reviewed-candidate.json').read_bytes()).hexdigest())
