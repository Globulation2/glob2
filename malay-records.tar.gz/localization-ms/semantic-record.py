import json,sys
from pathlib import Path
p=Path(__file__).parent
batchid=sys.argv[1];edits=json.loads(sys.argv[2]);d=json.load(open(p/f'authored-batches/{batchid}.json'))
rpath=p/'semantic-review.json';r=json.load(open(rpath)) if rpath.exists() else {'reviewer':'malay_brief','certification':'Agent-reviewed; not native-human-certified','batches':[],'findings':[]}
epath=p/'semantic-edits.json';all_edits=json.load(open(epath)) if epath.exists() else []
for key,value,reason in edits:
 id=next(k for k in d['values'] if k.split(':',1)[1]==key);surface=id.split(':',1)[0]
 all_edits.append({'surface':surface,'key':key,'value':value})
 r['findings'].append({'key':id,'severity':'major' if reason.startswith('MAJOR:') else 'minor','state':'proposed','reason':reason,'input':d['values'][id],'proposed':value,'batch':batchid})
r['batches'].append({'id':batchid,'reviewer':'malay_brief','source_sha256':d['source_sha256'],'target_sha256':d['target_sha256'],'reviewed_keys':list(d['values']),'method':'Read every exact English source and immutable authored Malay value; checked meaning, gameplay context, Malaysian usage, glossary and formatting. Proposed edits recorded separately; no final recheck claimed.'})
rpath.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');epath.write_text(json.dumps(all_edits,ensure_ascii=False,indent=2)+'\n');(p/'semantic-reviewed-batches.json').write_text(json.dumps([b['id'] for b in r['batches']],indent=2)+'\n')
print(batchid,len(d['values']),'read;',len(edits),'proposals')
