import json,sys,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent;m=json.loads((r/'manifest.json').read_text());path=r/'adversarial-review.json';d=json.loads(path.read_text()) if path.exists() else {'identity':'malay_adversary','source_sha256':m['source_sha256'],'certification':'Agent-reviewed; not native-human-certified','batches':[],'findings':[]}
for name in sys.argv[1:]:
 b=next(b for b in m['batches'] if b['id']==name);s=json.loads((r/'edited-batches'/f'{name}.json').read_text());actual=hashlib.sha256(json.dumps(s['values'],ensure_ascii=False,sort_keys=True).encode()).hexdigest();assert actual==s['target_sha256'];record={'id':name,'adversarial_reviewer':'malay_adversary','source_sha256':m['source_sha256'],'target_sha256':actual,'adversarial_reviewed_keys':b['keys']};d['batches']=[x for x in d['batches'] if x['id']!=name]+[record]
path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');(r/'adversarial-reviewed-batches.json').write_text(json.dumps([x['id'] for x in d['batches']],indent=2)+'\n')
if not (r/'adversarial-edits.json').exists():(r/'adversarial-edits.json').write_text('[]\n')
print('Recorded',len(d['batches']),'read batches')
