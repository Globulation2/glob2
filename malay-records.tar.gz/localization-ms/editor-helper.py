import json,sys,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent;m=json.loads((r/'manifest.json').read_text());sources={s:json.loads((r/f'source/{s}.json').read_text()) for s in ['native','online']}
for name in sys.argv[1:]:
 parts=name.split(':');name=parts[0];start=int(parts[1]) if len(parts)>1 else 0;end=int(parts[2]) if len(parts)>2 else 10000;p=r/'semantic-batches'/f'{name}.json';d=json.loads(p.read_text());print('BATCH',name,d['target_sha256'])
 for id,v in list(d['values'].items())[start:end]:
  surf,key=id.split(':',1);en=sources[surf][key];print(json.dumps(([key,v] if isinstance(en,str) and key.strip('[]').casefold()==en.casefold() else [key,en,v]),ensure_ascii=False))
