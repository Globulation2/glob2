"""Read-only batch display: invoke with batch ID after author completion."""
import hashlib, importlib.util, json, sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
kit=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('program',root/'tools/localization/translation_program.py')
program=importlib.util.module_from_spec(spec);spec.loader.exec_module(program)
manifest=json.loads((kit/'manifest.json').read_text())
paths=program.catalog_paths(kit,'ms')
values={'native':program.CHECKER.read_table(paths['native'])[0], 'online':json.loads(paths['online'].read_text())}
refs=json.loads((kit/'reference-catalogs.json').read_text())
selected=next(batch for batch in manifest['batches'] if batch['id']==sys.argv[1])
batch=json.loads((kit/selected['path']).read_text())
print('BATCH',selected['id'],'source',manifest['source_sha256'],'target',program.batch_target_hashes(manifest,paths)[selected['id']])
for entry in batch['entries']:
 key=entry['key'];surface=batch['surface'];target=values[surface][key]
 print(json.dumps({'id':entry['id'],'en':entry['source'],'ms':target},ensure_ascii=False))
 if '--refs' in sys.argv:
  print(json.dumps({language:catalogs[surface].get(key) for language,catalogs in refs.items()},ensure_ascii=False))
