import json,sys,importlib.util
from pathlib import Path
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('program',P.parents[1]/'tools/localization/translation_program.py');M=importlib.util.module_from_spec(sp);sp.loader.exec_module(M)
manifest=json.load(open(P/'manifest.json'))
rows=[]
for b in manifest['batches']:
 for id in b['keys']:
  surface,key=id.split(':',1);rows.append((b['id'],surface,key))
mode=sys.argv[1]
if mode=='snapshot':
 surface=sys.argv[2]
 values=M.CHECKER.read_table(P/'drafts/ms/texts.ms.txt')[0] if surface=='native' else json.load(open(P/'drafts/ms/ms.json'))
 M.write_json(P/f'author-{surface}-snapshot.json',values)
if mode=='read':
 sources={s:json.load(open(P/f'source/{s}.json')) for s in ('native','online')}
 targets={s:json.load(open(P/f'author-{s}-snapshot.json')) for s in ('native','online') if (P/f'author-{s}-snapshot.json').exists()}
 for i in range(int(sys.argv[2]),int(sys.argv[3])):
  b,s,k=rows[i]
  source=sources[s][k]
  value=targets[s][k]
  print(f'{i} {source} => {value}')
if mode=='edits':
 changes=json.load(sys.stdin)
 path=P/'author-edits.json';all=json.load(open(path)) if path.exists() else []
 for idx,value in changes.items():
  b,s,k=rows[int(idx)];all=[x for x in all if not(x['surface']==s and x['key']==k)];all.append({'surface':s,'key':k,'value':value})
 M.write_json(path,all)
if mode=='mark':
 path=P/'author-reviewed-batches.json'; reviewed=json.load(open(path)) if path.exists() else []
 reviewed.extend(manifest['batches'][int(i)]['id'] for i in sys.argv[2:]);M.write_json(path,list(dict.fromkeys(reviewed)))
if mode=='index':
 n=0
 for i,b in enumerate(manifest['batches']):print(i,b['id'],n,n+len(b['keys']));n+=len(b['keys'])
