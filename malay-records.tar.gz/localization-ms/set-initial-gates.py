import hashlib,importlib.util,json
from pathlib import Path
r=Path(__file__).resolve().parent;root=r.parents[1];s=importlib.util.spec_from_file_location('t',root/'tools/localization/translation_program.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t)
m=json.loads((r/'manifest.json').read_text());p=r/'reviews/ms.json';v=json.loads(p.read_text());assert t.sources()[4]==m['source_sha256'];assert v['catalog_sha256']=={k:t.digest(x.read_bytes()) for k,x in t.catalog_paths(r,'ms').items()}
for canonical,draft in [('data/texts.ms.txt','drafts/ms/texts.ms.txt'),('platform/packages/i18n/locales/ms.json','drafts/ms/ms.json'),('browser/locales/ms.json','drafts/ms/ms.json')]:assert (root/canonical).read_bytes()==(r/draft).read_bytes(),canonical
checks={'validation/native-strict-final.log':'0 structural errors','validation/native-translation-tests-final.log':'\nOK\n','validation/workflow-tests-final.log':'\nOK\n','validation/cloud-tests-final.log':'\nOK\n','validation/online-strict-final.log':'inventory, parameters and plural forms passed'}
for name,marker in checks.items():assert marker in (r/name).read_text(),name
for gate,files,note in [
 ('language_brief',['language-brief.json','editor-reference-notes.json','adversarial-reference-notes.json'],'Primary-source variety/script/terminology brief; no unresolved linguistic uncertainty.'),
 ('source_based_pilot',['pilot-keys.json','pilot-review.json','pilot-recheck.json','final-recheck.json'],'98-key source-based pilot preceded bulk drafting. Final versions of those entries are covered by complete final rechecks.'),
 ('structural',list(checks)+['accepted-english-final.json','validation/frozen-final-inputs.json'],'Official native and online inventory/token/plural/source checks plus exact individually reviewed English exceptions; rendering/platform execution are separate gates.')]:
 v['gates'][gate]={'passed':True,'source_sha256':m['source_sha256'],'catalog_sha256':v['catalog_sha256'],'evidence':[{'path':n,'sha256':t.digest((r/n).read_bytes())} for n in files],'coverage':note}
t.write_json(p,v);print('Established language brief, pilot and structural gates. Remaining:',t.audit_locale(r,m,v,'ms'))
