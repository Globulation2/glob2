import json,hashlib,sys
from pathlib import Path
r=Path(__file__).resolve().parent
n=int(sys.argv[2]);bid=f'online-online-{n:03}'
s=json.loads((r/f'edited-batches/{bid}.json').read_text()); b=json.loads((r/f'batches/{bid}.json').read_text())
assert hashlib.sha256(json.dumps(s['values'],ensure_ascii=False,sort_keys=True).encode()).hexdigest()==s['target_sha256']
if sys.argv[1]=='show':
 print(bid,s['target_sha256'])
 for i,e in enumerate(b['entries']):print(f"{i} {e['source']} => {s['values'][e['id']]}")
elif sys.argv[1]=='mark':
 p=r/'online-adversarial-review.json';d=json.loads(p.read_text()) if p.exists() else {'identity':'malay_online_adversary','certification':'Agent-reviewed; not native-human-certified','source_sha256':s['source_sha256'],'batches':[],'findings':[]}
 d['batches']=[x for x in d['batches'] if x['id']!=bid]+[{'id':bid,'adversarial_reviewer':'malay_online_adversary','source_sha256':s['source_sha256'],'target_sha256':s['target_sha256'],'adversarial_reviewed_keys':[e['id'] for e in b['entries']]}]
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');(r/'online-adversarial-reviewed-batches.json').write_text(json.dumps([x['id'] for x in d['batches']],indent=2)+'\n')
elif sys.argv[1]=='edit':
 i=int(sys.argv[3]);p=r/'online-adversarial-edits.json';d=json.loads(p.read_text()) if p.exists() else [];e=b['entries'][i];d=[x for x in d if x['key']!=e['key']];d.append({'surface':'online','key':e['key'],'value':sys.argv[4],'reason':sys.argv[5],'severity':'minor'});p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
