"""Normalize master191's sixteen native labels without inventing older rereads."""
import importlib.util,json,hashlib
from collections import defaultdict
from pathlib import Path
R=Path(__file__).resolve().parent;O=R.with_name('localization-ms-final-190');L=R.with_name('localization-ms');P=L/'master191-supplement';ROOT=R.parents[1]
spec=importlib.util.spec_from_file_location('program',ROOT/'tools/localization/translation_program.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
read=lambda p:json.loads(p.read_text());write=lambda p,v:t.write_json(p,v);fh=lambda p:t.digest(p.read_bytes());hd=lambda v:t.digest(json.dumps(v,ensure_ascii=False,sort_keys=True).encode());hc=lambda v:t.digest(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def ev(p):
 if p.is_relative_to(R):name=str(p.relative_to(R))
 elif p.is_relative_to(O):name='../localization-ms-final-190/'+str(p.relative_to(O))
 else:name='../localization-ms/'+str(p.relative_to(L))
 return {'path':name,'sha256':fh(p)}
m=read(R/'manifest.json');assert len(read(R/'source/native.json'))==3411 and len(read(R/'source/online.json'))==2947; om=read(O/'manifest.json');old=read(O/'reviews/ms.json');a=read(P/'authored.json');s=read(P/'semantic-review.json');e=read(P/'editor-review.json');adv=read(P/'native-adversarial-review.json');q=read(P/'sources.json')
# New global manifest is established only after the integrated source is frozen.
assert old['source_sha256']==om['source_sha256']=='51ddb8193640b09ecfbe713de190326a5569975313d24d707b3ac655f24d6350'
assert m['source_sha256']!=om['source_sha256']
assert a['source_subset_sha256']==s['source_subset_sha256']==e['source_subset_sha256']==adv['source_subset_sha256']==hd(a['sources'])
newvalues=a['translations'];newids={'native:'+k for k in newvalues};assert len(newids)==16
paths=t.catalog_paths(R,'ms');hashes={k:fh(v) for k,v in paths.items()};native,errors=t.CHECKER.read_table(paths['native']);assert not errors;targets={'native':native,'online':read(paths['online'])};assert {k:native[k] for k in newvalues}==newvalues,'Final16 targets do not match reviewed authored snapshot'
assert s['input_sha256']==e['input_file_sha256']==fh(P/'authored.json');assert set(s['reviewed_keys'])==set(e['reviewed_keys'])==newids;assert s['target_subset_sha256']==e['target_subset_sha256']==a['authored_target_subset_sha256']==hc(newvalues)
assert not s['guarded_proposals'] and not e['guarded_proposals'] and not s['unresolved_uncertainty'] and not e['unresolved_uncertainty']
# New sixteen entries have three actual independent readers, each hash-bound.
advid=adv['identity'];assert advid=='malay_adversary'
assert set(adv['adversarial_reviewed_keys'])==newids
assert adv['input_file_sha256']==fh(P/'authored.json')
assert adv['target_subset_sha256']==hc(newvalues)
assert not adv['edits'] and not adv['findings'] and not adv['unresolved_uncertainty']
oldnative,errors=t.CHECKER.read_table(O/'drafts/ms/texts.ms.txt');assert not errors;oldtargets={'native':oldnative,'online':read(O/'drafts/ms/ms.json')};oldby={b['id']:b for b in old['batches']};oldkeys={};batchproof=[];sourceproof=[]
for b in om['batches']:
 subset={id:targets[id.split(':',1)[0]][id.split(':',1)[1]] for id in b['keys']};assert hd(subset)==oldby[b['id']]['target_sha256']
 for id,v in subset.items():
  surf,k=id.split(':',1);assert id not in oldkeys;oldkeys[id]=oldby[b['id']];assert v==oldtargets[surf][k];assert json.dumps(v,ensure_ascii=False).encode()==json.dumps(oldtargets[surf][k],ensure_ascii=False).encode()
 batchproof.append({'id':b['id'],'keys':b['keys'],'old_approved_target_sha256':oldby[b['id']]['target_sha256'],'new_extracted_target_sha256':hd(subset),'exact_unchanged':True})
assert len(oldkeys)==6342
for surf in ['native','online']:
 os=read(O/'source'/f'{surf}.json');ns=read(R/'source'/f'{surf}.json');assert all(ns[k]==v for k,v in os.items());sourceproof.append({'surface':surf,'old_count':len(os),'old_source_subset_sha256':hd(os),'new_old_source_subset_sha256':hd({k:ns[k] for k in os}),'old_target_subset_sha256':hd(oldtargets[surf]),'new_old_target_subset_sha256':hd({k:targets[surf][k] for k in os}),'byte_values_identical':True})
raw_native=paths['native'].read_bytes()
for key,value in newvalues.items():
 pair=(key+'\n'+value+'\n').encode();assert raw_native.count(pair)==1;raw_native=raw_native.replace(pair,b'',1)
assert raw_native==(O/'drafts/ms/texts.ms.txt').read_bytes()
assert set(read(R/'source/native.json'))-set(read(O/'source/native.json'))==set(newvalues);assert read(R/'source/online.json')==read(O/'source/online.json');assert fh(paths['online'])==fh(O/'drafts/ms/ms.json')
# Each normalized key keeps its original reader ownership. A fourth reviewer may
# differ for the16 new keys; represent a real per-key union instead of forging one
# reviewer who supposedly read a whole mixed batch.
bh=t.batch_target_hashes(m,paths);batches=[];all_fourth_keys=set()
for b in m['batches']:
 keys=b['keys'];carried=[k for k in keys if k in oldkeys];added=[k for k in keys if k not in oldkeys];assert set(added)<=newids;groups=defaultdict(list)
 for id in carried:groups[oldkeys[id]['adversarial_reviewer']].append(id)
 for id in added:groups[advid].append(id)
 assert set().union(*(set(v) for v in groups.values()))==set(keys);assert all(who not in ['cloud_tooling','malay_brief','malay_editor'] for who in groups);all_fourth_keys.update(keys)
 record={'id':b['id'],'author':'cloud_tooling','reviewer':'malay_brief','editor':'malay_editor','source_sha256':m['source_sha256'],'target_sha256':bh[b['id']],'reviewed_keys':keys,'edited_keys':keys,'rechecked_keys':keys,'rechecked_by':'malay_brief','adversarial_reviewed_keys':keys,'adversarial_reviews':[{'reviewer':who,'keys':covered} for who,covered in groups.items()],'provenance':{'old_unchanged_keys':carried,'new_master191_keys':added,'old_coverage':'Original approved6342 independent readings/focused reviews carried through exact source/target byte proofs; no new old-text full reread.','new_coverage':'Sixteen exact authored native Malay values independently read and accepted by semantic/editor/fourth reviewers; final applied strings exactly match each accepted input hash.','fourth_coverage_mode':'per-key reviewer ownership, including any distinct new native reviewer'}}
 if len(groups)==1:record['adversarial_reviewer']=next(iter(groups))
 batches.append(record)
assert len(batches)==44 and len(all_fourth_keys)==6358 and sum(len(b['reviewed_keys']) for b in batches)==6358
accepted=old['accepted_english'];assert len(accepted)==190 and not any(q['sources'][k]==v for k,v in newvalues.items());checked=t.check_draft(R,'ms');assert not checked['errors'] and not checked['untranslated'];assert set(checked['same_as_english_review_queue'])=={x['key'] for x in accepted};write(R/'accepted-english-final.json',accepted);write(R/'draft-structural-check.json',checked)
assert fh(ROOT/'data/texts.ms.txt')==hashes['native'] and fh(ROOT/'platform/packages/i18n/locales/ms.json')==hashes['online'];assert t.sources(ROOT)[-1]==m['source_sha256']
assert '0 structural errors' in (R/'native-strict-normalization.log').read_text();assert '38 languages × 2947 messages: inventory, parameters and plural forms passed' in (R/'online-strict-normalization.log').read_text();assert 'Built launcher runtime and 38 catalogs' in (R/'browser-catalog-normalization.log').read_text()
files=[O/'reviews/ms.json',O/'linguistic-normalization-proof.json',O/'structural-normalization-proof.json',P/'sources.json',P/'initial-draft.json',P/'authored.json',P/'semantic-review.json',P/'editor-review.json',P/'native-adversarial-review.json',P/'nb-editor-review.json',P/'nb-editor-final-recheck.json',P/'nb-native-editor-review.json'];independent=[ev(p) for p in files]
linguistic={'identity':'malay_editor','role':'provenance assembler, not substitute reviewer','source_sha256':m['source_sha256'],'catalog_sha256':hashes,'old_source_sha256':om['source_sha256'],'old6342_source_target_proofs':sourceproof,'old44_approved_batch_proofs':batchproof,'raw_native_old_file_reconstructed_after_removing_new16_pairs':True,'reconstructed_old_native_file_sha256':t.digest(raw_native),'old_keys_carried_forward':6342,'new_native_keys':list(newids),'total_keys':6358,'batches':44,'all_keys_have_fourth_review_coverage':True,'new_target_subset_sha256':hc(newvalues),'new16_applied_values_match_all_accepted_inputs':True,'independent_records':independent,'limits':['All earlier0ac/7133/72433/51ddb full readings and focused records preserved unchanged.','Carryforward is exact equality and prior approval; no fresh full reading of old6342.','Supplemental NB111 online/NB16 native independent reviews do not certify the complete prior NB catalog. No final191 runtime or pixel approval is inferred from unchanged values.','Agent-reviewed; not native-human-certified.']};write(R/'linguistic-normalization-proof.json',linguistic)
structural={'source_sha256':m['source_sha256'],'catalog_sha256':hashes,'catalogs_match_live_files':True,'checks':[{'command':'python3 data/check_translations.py --strict','exit_code':0,'evidence':ev(R/'native-strict-normalization.log')},{'command':'Node24 packages/i18n/scripts/check.ts','cwd':'platform','exit_code':0,'evidence':ev(R/'online-strict-normalization.log')},{'command':'Node24 packages/i18n/scripts/build-browser.ts --check','cwd':'platform','exit_code':0,'evidence':ev(R/'browser-catalog-normalization.log')}],'draft_check':ev(R/'draft-structural-check.json'),'limits':'Inventory/tokens/plurals/invariants/browser catalog consistency only, not visual or execution approval.'};write(R/'structural-normalization-proof.json',structural)
gates={g:{'passed':False,'evidence':[],'reason':'Pending final source/catalog-bound actual capture or platform execution evidence.'} for g in t.GATES};base={'passed':True,'source_sha256':m['source_sha256'],'catalog_sha256':hashes}
gates['language_brief']=dict(base,evidence=[ev(L/'language-brief.json'),ev(L/'editor-reference-notes.json'),ev(R/'linguistic-normalization-proof.json')],coverage='Original Malaysian Rumi brief remains valid; new16 statistics/terrain entries independently checked against exact source and existing statistics/overlay/material terminology. No unresolved linguistic concerns.')
gates['source_based_pilot']=dict(base,evidence=[ev(L/'pilot-keys.json'),ev(L/'pilot-review.json'),ev(L/'pilot-recheck.json'),ev(R/'linguistic-normalization-proof.json')],coverage='Original98-key pilot predates bulk drafting; its source/final targets remain inside exact unchanged6342. New16 native entries have independent source-based full readings. No new original pilot claimed.')
gates['structural']=dict(base,evidence=[ev(R/'structural-normalization-proof.json'),ev(R/'draft-structural-check.json'),ev(R/'accepted-english-final.json'),ev(R/'native-strict-normalization.log'),ev(R/'online-strict-normalization.log'),ev(R/'browser-catalog-normalization.log')],coverage='Fresh official native/online checks plus generated-browser consistency, draft structural check and190 individual prior exact English matches. New16 entries do not add any English matches.')
record={'locale':'ms','source_sha256':m['source_sha256'],'catalog_sha256':hashes,'batches':batches,'findings':[],'accepted_english':accepted,'language_brief':old['language_brief'],'gates':gates,'independent_records':independent+[ev(R/'linguistic-normalization-proof.json')],'limits':linguistic['limits']+['Six rendering/startup/platform gates remain pending.']};write(R/'reviews/ms.json',record);issues=t.audit_locale(R,m,record,'ms');assert set(issues)=={g+' is pending or lacks evidence' for g in t.GATES[3:]},issues;write(R/'normalization-audit.json',{'source_sha256':m['source_sha256'],'catalog_sha256':hashes,'linguistic_and_structural_issues':[],'remaining_gate_issues':issues,'batches':44,'keys':6358,'english_exceptions':190,'status':'Linguistic/structural provenance passes; six actual rendering/execution gates remain pending.'});print('Normalized44batches/6358keys; old6342 byteproof plus new16 independent accepted reads;190exceptions; first3gates pass, six capture/execution gates pending.')
