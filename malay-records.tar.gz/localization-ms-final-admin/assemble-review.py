"""Normalize final admin expansion using exact approved-value carryforward."""
import hashlib,importlib.util,json
from pathlib import Path
R=Path(__file__).resolve().parent;O=R.with_name('localization-ms-final');L=R.with_name('localization-ms');A=L/'admin-supplement';ROOT=R.parents[1]
spec=importlib.util.spec_from_file_location('program',ROOT/'tools/localization/translation_program.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
read=lambda p:json.loads(p.read_text());write=lambda p,v:t.write_json(p,v);h=lambda v:t.digest(json.dumps(v,sort_keys=True,ensure_ascii=False).encode());fh=lambda p:t.digest(p.read_bytes())
def ev(p):
 if p.is_relative_to(R):name=str(p.relative_to(R))
 elif p.is_relative_to(O):name='../localization-ms-final/'+str(p.relative_to(O))
 else:name='../localization-ms/'+str(p.relative_to(L))
 return {'path':name,'sha256':fh(p)}
m=read(R/'manifest.json');om=read(O/'manifest.json');prior=read(O/'reviews/ms.json');c=read(A/'reviewed-candidate.json');author=read(A/'authored.json');sem=read(A/'semantic-review.json');editor=read(A/'editor-review.json');adv=read(A/'adversarial-review.json');sf=read(A/'semantic-focused-final.json');ef=read(A/'editor-focused-final.json');af=read(A/'adversarial-focused-final.json')
assert m['source_sha256']==c['source_sha256']=='72433ad6bba0a0b9ad19a663d9a468b7bc7f3e73b4470fba0f5faf136d93b3c0';assert om['source_sha256']==prior['source_sha256']=='7133fb32983f02d38c9dace2dc6c799abe9c447e1449c7be0016a5d6182bd0ab';assert fh(A/'reviewed-candidate.json')=='1011f6d3fa514c0d06861a57e4205e07e1e9da145d6a4c1d52819eaedf40e1a8'
paths=t.catalog_paths(R,'ms');hashes={s:fh(p) for s,p in paths.items()};native,errors=t.CHECKER.read_table(paths['native']);assert not errors;targets={'native':native,'online':read(paths['online'])};newkeys=set(author['translations']['ms']);assert len(newkeys)==16;assert {k:targets['online'][k] for k in newkeys}==c['translations']['ms'],'Final target does not yet match approved candidate'
# Verify full independent readings and final amendment evidence; no relabelled rereads.
assert author['author']=='cloud_tooling' and sem['identity']=='malay_brief' and editor['identity']=='malay_editor' and adv['adversarial_reviewer']=='malay_online_adversary'
assert len({author['author'],sem['identity'],editor['identity'],adv['adversarial_reviewer']})==4
assert len(author['translations'])==36 and all(len(v)==16 for v in author['translations'].values())
for d in [author,sem,editor,adv,sf,ef,af]:assert d['source_sha256']==m['source_sha256']
assert sem['input_file_sha256']==editor['input_file_sha256']==fh(A/'authored.json');assert adv['author_input_sha256']==fh(A/'authored.json')
assert sf['candidate_input_sha256']==fh(A/'reviewed-candidate.json')
for d in [ef,af]:assert d['candidate_file_sha256']==fh(A/'reviewed-candidate.json')
assert sf['changed_count']==15 and sf['unchanged_new_values']==561 and not sf['pending_proposals'] and not sf['unresolved_uncertainty']
assert af['focused_changed_values_read']==15 and af['unchanged_values_verified']==561 and not af['unresolved_findings']
assert set(next(x for x in sem['coverage'] if x['locale']=='ms')['reviewed_keys'])=={'online:'+k for k in newkeys};assert set(next(x for x in editor['locale_records'] if x['locale']=='ms')['reviewed_keys'])==newkeys;assert set(next(x for x in adv['locale_records'] if x['locale']=='ms')['adversarial_reviewed_keys'])==newkeys
assert editor['reviewed_target_value_count']==576 and sem['reviewed_value_count']==576
assert ef['accepted'] and ef['changed_value_count']==15 and ef['unchanged_value_count']==561 and not ef['concerns']
assert not author['unresolved_uncertainty'] and not sem['unresolved_uncertainty'] and not editor['unresolved_uncertainty'] and not adv['uncertainty']
# Always independently compare all576 candidate strings and reconstruct the authored
# input, even when agent evidence uses differently named fields.
changed=[];same=0;restored={l:dict(v) for l,v in c['translations'].items()}
for l,vs in author['translations'].items():
 assert set(c['translations'][l])==set(vs)
 for k,v in vs.items():
  nv=c['translations'][l][k]
  if nv!=v:changed.append([l,k]);restored[l][k]=v
  else:assert nv.encode()==v.encode();same+=1
assert len(changed)==15 and same==561 and restored==author['translations'];assert h(restored)==h(author['translations'])
# Proof each of the6324 previously approved source/target pairs is exactly unchanged.
oldnative,errors=t.CHECKER.read_table(O/'drafts/ms/texts.ms.txt');assert not errors;oldtargets={'native':oldnative,'online':read(O/'drafts/ms/ms.json')};oldby={b['id']:b for b in prior['batches']};oldkeys={};proof=[];sourceproof=[]
for b in om['batches']:
 vals={id:targets[id.split(':',1)[0]][id.split(':',1)[1]] for id in b['keys']};assert h(vals)==oldby[b['id']]['target_sha256']
 for id,v in vals.items():
  s,k=id.split(':',1);assert id not in oldkeys;oldkeys[id]=oldby[b['id']];assert v==oldtargets[s][k];assert json.dumps(v,ensure_ascii=False).encode()==json.dumps(oldtargets[s][k],ensure_ascii=False).encode()
 proof.append({'original_batch':b['id'],'original_approved_target_sha256':oldby[b['id']]['target_sha256'],'new_extracted_target_sha256':h(vals),'keys':b['keys'],'exact_unchanged':True})
assert len(oldkeys)==6324
for s in ['native','online']:
 os=read(O/'source'/f'{s}.json');ns=read(R/'source'/f'{s}.json');assert all(ns[k]==v for k,v in os.items());sourceproof.append({'surface':s,'old_count':len(os),'old_source_subset_sha256':h(os),'new_source_old_subset_sha256':h({k:ns[k] for k in os}),'old_final_target_subset_sha256':h(oldtargets[s]),'new_target_old_subset_sha256':h({k:targets[s][k] for k in os}),'unchanged':True})
assert set(read(R/'source/online.json'))-set(read(O/'source/online.json'))==newkeys
assert fh(O/'drafts/ms/texts.ms.txt')==fh(paths['native'])
# Author/semantic/editor/adversarial carry records remain linked, not overwritten.
ac=read(A/'author-carryforward-final.json');ec=read(A/'editor-carryforward-final.json');sc=read(A/'semantic-carryforward.json');assert ac['authorized_carryforward'] and ec['authorized_carryforward'];assert ac['new_source_sha256']==ec['new_source_sha256']==m['source_sha256'];assert adv['carryforward']['old_values_unchanged'] and adv['carryforward']['old_total_keys']==6324 and adv['carryforward']['to_source_sha256']==m['source_sha256']
bh=t.batch_target_hashes(m,paths);batches=[]
for b in m['batches']:
 keys=b['keys'];carried=[k for k in keys if k in oldkeys];added=[k for k in keys if k not in oldkeys];assert all(k.startswith('online:') and k[7:] in newkeys for k in added)
 people={'author':'cloud_tooling','reviewer':'malay_brief','editor':'malay_editor','adversarial_reviewer':'malay_adversary' if b['id'].startswith('native-') else 'malay_online_adversary'}
 for id in carried:
  for role,name in people.items():assert oldkeys[id][role]==name
 batches.append(dict(id=b['id'],**people,source_sha256=m['source_sha256'],target_sha256=bh[b['id']],reviewed_keys=keys,edited_keys=keys,rechecked_keys=keys,rechecked_by=people['reviewer'],adversarial_reviewed_keys=keys,provenance={'unchanged_prior_approved_keys':carried,'new_admin_keys':added,'prior_coverage':'Original full independent readings, subsequent focused rechecks and exact-value carryforward from prior7133 normalized6324. No fresh old-text reread.','new_coverage':'Four independent full16-key readings across36locales;15 merged focused amendments and561 UTF8-identical unchanged supplementary values.'}))
assert len(batches)==44 and sum(len(b['reviewed_keys']) for b in batches)==6340
# No new exact English matches. Keep the prior190 individual exceptions unchanged.
accepted=prior['accepted_english'];assert len(accepted)==190 and not any(k==v for vs in c['translations'].values() for k,v in vs.items());checked=t.check_draft(R,'ms');assert not checked['errors'] and not checked['untranslated'];assert set(checked['same_as_english_review_queue'])=={e['key'] for e in accepted};write(R/'accepted-english-final.json',accepted);write(R/'draft-structural-check.json',checked)
assert fh(ROOT/'data/texts.ms.txt')==hashes['native'] and fh(ROOT/'platform/packages/i18n/locales/ms.json')==hashes['online'];assert t.sources(ROOT)[-1]==m['source_sha256']
# Structural gate needs actual post-application read-only command results.
assert '0 structural errors' in (R/'native-strict-normalization.log').read_text();assert '37 languages × 2947 messages: inventory, parameters and plural forms passed' in (R/'online-strict-normalization.log').read_text();assert 'Built launcher runtime and 37 catalogs' in (R/'browser-catalog-normalization.log').read_text()
files=[O/'reviews/ms.json',O/'linguistic-normalization-proof.json',O/'structural-normalization-proof.json',A/'author-carryforward-final.json',A/'semantic-carryforward.json',A/'editor-carryforward-final.json',A/'authored.json',A/'author-accepted-english.json',A/'semantic-review.json',A/'semantic-focused-final.json',A/'editor-review.json',A/'editor-focused-final.json',A/'adversarial-review.json',A/'adversarial-focused-final.json',A/'reviewed-candidate.json',A/'applied-data-proof.json'];independent=[ev(p) for p in files]
linguistic={'identity':'malay_editor','role':'provenance assembler, not substitute reviewer','source_sha256':m['source_sha256'],'catalog_sha256':hashes,'original_source_sha256':om['source_sha256'],'original6324_source_target_byteproof':sourceproof,'original44_effective_batch_proofs':proof,'original_reviewed_pairs_carried':6324,'new_source_keys':16,'new_locales_read':36,'new_total_values_read':576,'merged_changes_rechecked':15,'unchanged_supplement_values':561,'new_manifest_batches':44,'normalized_total_keys':6340,'independent_records':independent,'limits':['Original0ac/7133 records preserved unchanged; full-read lineage follows their referenced artifacts.','Carryforward is exact source/target equality plus existing approval, not a new full reread.','Original native adversarial identity retained from prior approval and byte-identical native source/target, not relabelled as a new agent review.','Agent-reviewed; not native-human-certified.']};write(R/'linguistic-normalization-proof.json',linguistic)
structural={'source_sha256':m['source_sha256'],'catalog_sha256':hashes,'catalogs_match_live_files':True,'checks':[{'command':'python3 data/check_translations.py --strict','exit_code':0,'evidence':ev(R/'native-strict-normalization.log')},{'command':'Node24 packages/i18n/scripts/check.ts','cwd':'platform','exit_code':0,'evidence':ev(R/'online-strict-normalization.log')},{'command':'Node24 packages/i18n/scripts/build-browser.ts --check','cwd':'platform','exit_code':0,'evidence':ev(R/'browser-catalog-normalization.log')}],'draft_check':ev(R/'draft-structural-check.json'),'limits':'Inventory/placeholders/plural/invariants/generated-catalog consistency only; rendering/runtime/platform gates separate.'};write(R/'structural-normalization-proof.json',structural)
gates={g:{'passed':False,'evidence':[],'reason':'Pending final source/catalog-bound actual rendering or platform evidence.'} for g in t.GATES};base={'passed':True,'source_sha256':m['source_sha256'],'catalog_sha256':hashes}
gates['language_brief']=dict(base,evidence=[ev(L/'language-brief.json'),ev(L/'editor-reference-notes.json'),ev(R/'linguistic-normalization-proof.json')],coverage='Original Malaysian Rumi brief plus new admin context review. Old6324 exactly unchanged; new16 independently read; no unresolved substantive findings.')
gates['source_based_pilot']=dict(base,evidence=[ev(L/'pilot-keys.json'),ev(L/'pilot-review.json'),ev(L/'pilot-recheck.json'),ev(R/'linguistic-normalization-proof.json')],coverage='Original98-key pilot preceded bulk drafting. Its sources/final targets are inside proven unchanged6324. New16 admin entries received separate complete independent review; no new original pilot claimed.')
gates['structural']=dict(base,evidence=[ev(R/'structural-normalization-proof.json'),ev(R/'draft-structural-check.json'),ev(R/'accepted-english-final.json'),ev(R/'native-strict-normalization.log'),ev(R/'online-strict-normalization.log'),ev(R/'browser-catalog-normalization.log')],coverage='Fresh official strict native/online checks and generated browser consistency plus draft structural validation and190 exact individually justified English matches. No new whole-English matches in admin16.')
record={'locale':'ms','source_sha256':m['source_sha256'],'catalog_sha256':hashes,'batches':batches,'findings':[],'accepted_english':accepted,'language_brief':prior['language_brief'],'gates':gates,'independent_records':independent+[ev(R/'linguistic-normalization-proof.json')],'limits':linguistic['limits']+['Six rendering/startup/platform gates remain pending until separate final execution evidence.']};write(R/'reviews/ms.json',record);issues=t.audit_locale(R,m,record,'ms');assert set(issues)=={g+' is pending or lacks evidence' for g in t.GATES[3:]},issues;write(R/'normalization-audit.json',{'source_sha256':m['source_sha256'],'catalog_sha256':hashes,'linguistic_and_structural_issues':[],'remaining_gate_issues':issues,'normalized_batches':44,'normalized_keys':6340,'english_exceptions':190,'status':'Linguistic/structural normalization passes; six execution/rendering gates intentionally pending.'});print('Normalized44batches/6340keys: prior6324 byteproof +16newfour-role reviews;190exceptions; first3gates pass, six execution/rendering gates pending.')
