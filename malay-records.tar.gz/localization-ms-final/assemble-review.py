"""Normalize provenance across a frozen source expansion; never invent rereads."""
import hashlib,importlib.util,json
from pathlib import Path
R=Path(__file__).resolve().parent;O=R.with_name('localization-ms');A=O/'ai-tags';ROOT=R.parents[1]
spec=importlib.util.spec_from_file_location('t',ROOT/'tools/localization/translation_program.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
read=lambda p:json.loads(p.read_text());write=lambda p,v:t.write_json(p,v);h=lambda v:t.digest(json.dumps(v,sort_keys=True,ensure_ascii=False).encode());fh=lambda p:t.digest(p.read_bytes())
def evidence(p):return {'path':str(p.relative_to(R)) if p.is_relative_to(R) else '../localization-ms/'+str(p.relative_to(O)),'sha256':fh(p)}
def idx(d,field='batches'):return {b['id']:b for b in d[field]}
m=read(R/'manifest.json');oldm=read(O/'manifest.json');old=read(O/'reviews/ms.json');candidate=read(A/'reviewed-candidate.json');assert m['source_sha256']==candidate['source_sha256']=='7133fb32983f02d38c9dace2dc6c799abe9c447e1449c7be0016a5d6182bd0ab'
assert oldm['source_sha256']==old['source_sha256']=='0ac44b4cdfb03e688983d6e3fb1e484cca57589665bff19c5c65388e649b292a'
assert fh(A/'reviewed-candidate.json')=='e2a2afcc58424ff9c0ded3a510470a7810fe71a5d172f487c10cb1b5d580df19'
paths=t.catalog_paths(R,'ms');hashes={s:fh(p) for s,p in paths.items()};native,errors=t.CHECKER.read_table(paths['native']);assert not errors;targets={'native':native,'online':read(paths['online'])};batchhash=t.batch_target_hashes(m,paths)
# Author expansion, independent supplementary full readings, then final amendment checks.
auth=read(A/'authored-final.json');sem=read(A/'semantic-final.json');editor=read(A/'editor-final.json');adversary=read(A/'adversarial-final.json');sf=read(A/'semantic-focused-final.json');ef=read(A/'editor-focused-final.json');af=read(A/'adversarial-focused-final.json');newkeys=set(auth['translations']['ms']);assert len(newkeys)==95
assert {k:targets['online'][k] for k in newkeys}==candidate['translations']['ms']
assert set(newkeys)==set(editor['reviewed_source_keys'])
for doc in [auth,sem,editor,adversary,sf,ef,af]:assert doc['source_sha256']==m['source_sha256']
assert sem['input_file_sha256']==ef['author_file_sha256']==fh(A/'authored-final.json')
for doc in [sf,ef,af]:assert doc['candidate_file_sha256']==fh(A/'reviewed-candidate.json')
assert set(next(x for x in sem['coverage'] if x['locale']=='ms')['reviewed_keys'])=={'online:'+k for k in newkeys}
assert set(next(x for x in editor['locale_records'] if x['locale']=='ms')['reviewed_keys'])==newkeys
assert set(next(x for x in adversary['locale_records'] if x['locale']=='ms')['adversarial_reviewed_keys'])==newkeys
assert ef['accepted'] and ef['unchanged_value_count']==3398 and ef['changed_value_count']==22 and not ef['concerns']
assert sf['changed_count']==22 and sf['unchanged_new_values']==3398 and not sf['pending_proposals'] and not sf['unresolved_substantive_concerns']
assert af['focused_changed_values_read']==22 and af['unchanged_values_verified']==3398 and not af['unresolved_findings']
assert not auth['unresolved_uncertainty'] and not editor['unresolved_uncertainty'] and not adversary['unresolved_uncertainty']
# Initial semantic record retains explicit legacy-label/native-human caveats; final
# focused record resolves substantive concerns. Preserve these as limits, not erase them.
# Verify original distinct full-reading identities/coverage, effective editor renewals,
# all old final byte values and each independent author's carryforward authorization.
ac=read(A/'author-carryforward-final.json');sc=read(A/'semantic-final-carryforward.json');ec=read(O/'editor-carryforward-final.json');anc=read(A/'adversarial-native-carryforward-final.json');aoc=read(O/'online-adversarial-carryforward-final.json')
assert ac['authorized_carryforward'] and ec['authorized_carryforward'] and anc['authorized'];assert aoc['original_online_full_read_keys_carried_forward']==2836
for doc,key in [(ac,'new_source_sha256'),(sc,'new_source_sha256'),(ec,'new_source_sha256'),(anc,'expanded_source_sha256'),(aoc,'new_source_sha256')]:assert doc[key]==m['source_sha256']
oldrecords=idx(old);rawa=idx(read(O/'author-review.json'));raws=idx(read(O/'semantic-review.json'));rawe=idx(read(O/'editor-review.json'));rawf=idx(read(O/'final-recheck.json'));rawadv={**idx(read(O/'adversarial-review.json')),**idx(read(O/'online-adversarial-review.json'))};effective={k:v['proposed_sha256'] for k,v in rawe.items()};effective.update({b['id']:b['renewed_target_sha256'] for b in read(O/'editor-fourth-recheck.json')['renewed_batches']});disclaimer=read(O/'editor-final-disclaimer-recheck.json');effective[disclaimer['batch']]=disclaimer['final_snapshot_sha256']
oldtargets={'native':{},'online':{}};oldkeyrecord={};oldproof=[]
for b in oldm['batches']:
 bid=b['id'];expected=set(b['keys']);rec=oldrecords[bid];snapshot=read(O/'edited-batches'/f'{bid}.json');current_subset={k:targets[k.split(':',1)[0]][k.split(':',1)[1]] for k in b['keys']}
 assert h(current_subset)==h(snapshot['values'])==snapshot['target_sha256']==rec['target_sha256']==effective[bid]
 for doc,field in [(rawa[bid],'authored_keys'),(raws[bid],'reviewed_keys'),(rawe[bid],'edited_keys'),(rawf[bid],'rechecked_keys'),(rawadv[bid],'adversarial_reviewed_keys')]:assert set(doc[field])==expected and len(doc[field])==len(expected)
 assert len({rec['author'],rec['reviewer'],rec['editor'],rec['adversarial_reviewer']})==4
 for id,v in snapshot['values'].items():
  s,k=id.split(':',1);assert id not in oldkeyrecord;oldkeyrecord[id]=rec;oldtargets[s][k]=v;assert targets[s][k]==v;assert json.dumps(targets[s][k],ensure_ascii=False).encode()==json.dumps(v,ensure_ascii=False).encode()
 oldproof.append({'original_batch':bid,'keys':b['keys'],'original_approved_target_sha256':rec['target_sha256'],'current_extracted_target_sha256':h(current_subset),'exact_unchanged':True})
assert len(oldkeyrecord)==6229
sourceproof=[]
for s in ('native','online'):
 os=read(O/'source'/f'{s}.json');ns=read(R/'source'/f'{s}.json');assert set(os)==set(oldtargets[s]);assert all(ns[k]==v for k,v in os.items())
 sourceproof.append({'surface':s,'old_count':len(os),'old_source_subset_sha256':h(os),'new_source_old_subset_sha256':h({k:ns[k] for k in os}),'old_final_target_subset_sha256':h(oldtargets[s]),'new_target_old_subset_sha256':h({k:targets[s][k] for k in os}),'source_and_target_byteproof_passed':True})
assert set(read(R/'source/online.json'))-set(read(O/'source/online.json'))==newkeys
assert set(ac['original_authored_keys'])==set(ec['original_reviewed_keys'])==set(oldkeyrecord)
# The new manifest repartitions online keys; map provenance by actual key, not batch IDs.
batches=[]
for b in m['batches']:
 bid=b['id'];keys=b['keys'];original=[k for k in keys if k in oldkeyrecord];added=[k for k in keys if k not in oldkeyrecord];assert all(k.startswith('online:') and k[7:] in newkeys for k in added)
 people={'author':'cloud_tooling','reviewer':'malay_brief','editor':'malay_editor','adversarial_reviewer':'malay_adversary' if bid.startswith('native-') else 'malay_online_adversary'}
 for k in original:
  for role,name in people.items():assert oldkeyrecord[k][role]==name
 batches.append(dict(id=bid,**people,source_sha256=m['source_sha256'],target_sha256=batchhash[bid],reviewed_keys=keys,edited_keys=keys,rechecked_keys=keys,rechecked_by=people['reviewer'],adversarial_reviewed_keys=keys,provenance={'original_unchanged_keys':original,'new_supplement_keys':added,'original_coverage':'Original independent full readings plus explicit unchanged source/target comparison and authorized carryforward; not a fresh reread.','new_coverage':'95-key full author/semantic/editor/adversarial readings,22 merged focused checks and3398 unchanged supplement values across36locales.'}))
assert len(batches)==44 and sum(len(b['reviewed_keys']) for b in batches)==6324
# Exact individual English exceptions: original187 plus only3 Malay supplement words.
accepted=list(old['accepted_english']);supp=[e for e in editor['accepted_english'] if e['locale']=='ms'];assert {e['key'] for e in supp}=={'Mineral','Lava','Audit'}
for e in supp:accepted.append({'key':'online:'+e['key'],'reason':e['editor_assessment'],'reviewers':['cloud_tooling','malay_brief','malay_editor','malay_online_adversary']})
assert len(accepted)==190 and len({x['key'] for x in accepted})==190
checked=t.check_draft(R,'ms');assert not checked['errors'] and not checked['untranslated'];assert set(checked['same_as_english_review_queue'])=={e['key'] for e in accepted}
write(R/'accepted-english-final.json',accepted);write(R/'draft-structural-check.json',checked)
# Bind observed read-only official checks to the exact live=final-draft catalog hashes.
assert fh(ROOT/'data/texts.ms.txt')==hashes['native'];assert fh(ROOT/'platform/packages/i18n/locales/ms.json')==hashes['online'];assert t.sources(ROOT)[-1]==m['source_sha256']
assert '0 structural errors' in (R/'native-strict-normalization.log').read_text();assert '37 languages × 2931 messages: inventory, parameters and plural forms passed' in (R/'online-strict-normalization.log').read_text();assert 'Built launcher runtime and 37 catalogs' in (R/'browser-catalog-normalization.log').read_text()
validation={'source_sha256':m['source_sha256'],'catalog_sha256':hashes,'checks':[{'command':'python3 data/check_translations.py --strict','cwd':'repository root','exit_code':0,'evidence':evidence(R/'native-strict-normalization.log')},{'command':'/usr/lib/chatgpt/resources/cua_node/bin/node packages/i18n/scripts/check.ts','cwd':'platform','node_version':'v24.22.1','exit_code':0,'evidence':evidence(R/'online-strict-normalization.log')},{'command':'/usr/lib/chatgpt/resources/cua_node/bin/node packages/i18n/scripts/build-browser.ts --check','cwd':'platform','node_version':'v24.22.1','exit_code':0,'evidence':evidence(R/'browser-catalog-normalization.log')}],'draft_check':evidence(R/'draft-structural-check.json'),'catalogs_match_live_files':True,'limits':'Read-only inventory, placeholder, plural, invariant and generated-browser consistency checks. Not rendering/runtime/platform execution.'};write(R/'structural-normalization-proof.json',validation)
files=[O/'reviews/ms.json',O/'author-review.json',O/'semantic-review.json',O/'editor-review.json',O/'editor-focused-recheck.json',O/'editor-fourth-recheck.json',O/'editor-final-disclaimer-recheck.json',O/'final-recheck.json',O/'fourth-focused-semantic-recheck.json',O/'adversarial-review.json',O/'adversarial-native-renewal.json',O/'online-adversarial-review.json',O/'online-adversarial-final-complete.json',O/'online-adversarial-carryforward-final.json',O/'editor-carryforward-final.json',A/'author-carryforward-final.json',A/'semantic-final-carryforward.json',A/'adversarial-native-carryforward-final.json',A/'authored-final.json',A/'author-accepted-english-final.json',A/'semantic-final.json',A/'semantic-accepted-english-final.json',A/'semantic-focused-final.json',A/'editor-final.json',A/'editor-context-resolution.json',A/'editor-focused-final.json',A/'adversarial-final.json',A/'adversarial-focused-final.json',A/'reviewed-candidate.json',A/'applied-data-proof.json']
proof={'source_sha256':m['source_sha256'],'catalog_sha256':hashes,'identity':'malay_editor','role':'provenance assembler; not a substitute reviewer','original_source_sha256':oldm['source_sha256'],'original_full_read_pairs':6229,'original_source_target_byteproof':sourceproof,'original_effective_batch_proofs':oldproof,'new_source_keys':95,'new_locales_independently_read':36,'new_total_target_values':3420,'semantic_original_caveats_preserved':sem['unresolved_uncertainty'],'semantic_final_substantive_concerns':sf['unresolved_substantive_concerns'],'new_final_amendments_rechecked':22,'new_unchanged_values_byte_identical':3398,'normalized_new_manifest_batches':44,'normalized_total_keys':6324,'independent_records':[evidence(p) for p in files],'limits':['Original0ac records preserved untouched. No new full old-text reading claimed.','Normalization follows existing full readings, exact carryforward and focused final rechecks.','Agent-reviewed; not native-human-certified.']};write(R/'linguistic-normalization-proof.json',proof)
gates={g:{'passed':False,'evidence':[],'reason':'Pending final source/catalog-bound actual rendering or platform evidence.'} for g in t.GATES}
base={'passed':True,'source_sha256':m['source_sha256'],'catalog_sha256':hashes}
gates['language_brief']=dict(base,evidence=[evidence(O/'language-brief.json'),evidence(O/'editor-reference-notes.json'),evidence(R/'linguistic-normalization-proof.json')],coverage='Existing primary-source Malaysian Rumi brief remains applicable. Old6229 entries exactly unchanged; new95 entries independently read with contextual constraints and no unresolved substantive findings.')
gates['source_based_pilot']=dict(base,evidence=[evidence(O/'pilot-keys.json'),evidence(O/'pilot-review.json'),evidence(O/'pilot-recheck.json'),evidence(R/'linguistic-normalization-proof.json')],coverage='Original98-key source-based pilot preceded bulk drafting. Pilot sources/final values are part of independently proven unchanged6229. New95 entries additionally received full independent supplemental readings and final focused checks; no new original pilot claimed.')
gates['structural']=dict(base,evidence=[evidence(R/'structural-normalization-proof.json'),evidence(R/'draft-structural-check.json'),evidence(R/'accepted-english-final.json'),evidence(R/'native-strict-normalization.log'),evidence(R/'online-strict-normalization.log'),evidence(R/'browser-catalog-normalization.log')],coverage='Fresh official native strict and online inventory/parameters/plurals/invariants checks, browser-generated catalog consistency, draft structural check and190 individually justified exact English matches. Rendering/runtime execution separate.')
record={'locale':'ms','source_sha256':m['source_sha256'],'catalog_sha256':hashes,'batches':batches,'findings':[],'accepted_english':accepted,'language_brief':old['language_brief'],'gates':gates,'independent_records':[evidence(p) for p in files]+[evidence(R/'linguistic-normalization-proof.json')],'limits':proof['limits']+['All6 rendering/startup/platform gates remain pending until final execution/capture evidence.']};write(R/'reviews/ms.json',record)
issues=t.audit_locale(R,m,record,'ms');expected={g+' is pending or lacks evidence' for g in t.GATES[3:]};assert set(issues)==expected,issues
write(R/'normalization-audit.json',{'source_sha256':m['source_sha256'],'catalog_sha256':hashes,'linguistic_and_structural_issues':[],'remaining_gate_issues':issues,'normalized_batches':44,'normalized_keys':6324,'english_exceptions':190,'status':'Linguistic and structural provenance passes; only6 explicitly pending execution/rendering gates remain.'})
print('Normalized44batches/6324keys; old6229 byteproof + new95 independent reviews.190 individually accepted English matches. First3gates pass;6render/platform gates pending.')
print(json.dumps(issues,ensure_ascii=False,indent=2))
