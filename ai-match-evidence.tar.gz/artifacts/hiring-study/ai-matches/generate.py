import subprocess,json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent;p.joinpath('maps').mkdir(exist_ok=True)
b=Path('build/darwin/client/release/dev-linker-auto/src/glob2').resolve();rows=[]
for g in ['river','islands','swamp']:
 for seed in [713,2017,4093,8191]:
  name=f'{g}-{seed}';dest=p/'maps'/name
  cmd=[str(b),'map','generate',g,'--seed',str(seed),'--width','256','--height','256','--teams','8','--output',str(dest)+'.map','--report-file',str(dest)+'.json']
  with Path(str(dest)+'.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
  file=Path(str(dest)+'.map.gz');rows.append({'name':name,'generator':g,'map_seed':seed,'game_seed':seed+100000,'command':cmd,'returncode':r.returncode,'map':str(file),'sha256':hashlib.sha256(file.read_bytes()).hexdigest() if file.exists() else None})
  print(name,r.returncode,flush=True)
(p/'maps.json').write_text(json.dumps(rows,indent=2))
