from pathlib import Path
import json,subprocess,os
p=Path(__file__).resolve().parent;out=p/'diagnostics';out.mkdir(exist_ok=False)
for case in json.load(open(p/'maps.json'))[::4]:
 for mode in ['original','pool']:
  dest=out/f"{case['name']}-{mode}";cmd=[str(p/'glob2-trial'),'game','run','--map-file',case['map'],'--game-seed',str(case['game_seed']),'--ticks','16384','--benchmark-warmup','4096','--compute-threads','4','--gpu','off','--output-dir',str(dest),'--telemetry','hiring-stats','--telemetry','team-timeline']
  for _ in range(8):cmd+=['--player','nicowar']
  env=os.environ.copy();env.pop('GLOB2_ISOLATED_LIVE_HIRING',None)
  if mode=='pool':env['GLOB2_ISOLATED_LIVE_HIRING']='1';cmd+=['--hiring-schedule','4:4:128:combined','--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds','--hiring-execution','pool']
  with dest.with_suffix('.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
  print(case['name'],mode,json.load(open(dest/'isolated-live.json')),flush=True)
