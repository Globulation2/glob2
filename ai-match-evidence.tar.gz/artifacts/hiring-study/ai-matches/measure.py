from pathlib import Path
import json,subprocess,os,time,hashlib,platform
p=Path(__file__).resolve().parent;b=p/'glob2-trial';out=p/'measurements';out.mkdir(exist_ok=False)
cases=json.load(open(p/'maps.json'));assert len(cases)==12 and all(c['returncode']==0 for c in cases)
def busy():
 lines=subprocess.check_output(['ps','-axo','command'],text=True).splitlines()
 return any((l.startswith('/Applications/Xcode') and 'clang -cc1 ' in l) or (l.startswith('/') and ' -c ' not in l and ('engine-tests ' in l or 'unit-tests ' in l or '--test-suite=' in l or '--test-case=' in l or ' -tc=' in l)) or (l.startswith('/opt/homebrew/') and ' test/run_tests.py ' in l) for l in lines)
meta={'route_bootstrap':'Existing lazy building field initialized with buildingAvailable at footprint; does not call full-field buildingGradient. Only scheduled admitted teams prepare fields.', 'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'host':platform.platform(),'binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'protocol':'Broad screen: 12 generated256x256maps, eight Nicowar players, same seeds per pair,16384ticks including4096 warmup, n4, original versus isolated live material consumer K4/R4/vacancies+2. One process warmup per map/mode and three rotated paired repetitions. Diagnostics/checksum exports/saves disabled in timing. Whole measured-window elapsed includes end drains; early termination recorded. Host-overlapped pairs retained/excluded. This is exploratory, not the ten-repeat acceptance pass. Attractions/flying carriers retain original hiring.'}
(out/'metadata.json').write_text(json.dumps(meta,indent=2))
with (out/'samples.jsonl').open('w') as log:
 for rep in [-1,0,1,2]:
  order=cases[rep%len(cases):]+cases[:rep%len(cases)]
  for case in order:
   attempt=0
   while True:
    while busy():print('waiting for external host build/test activity',flush=True);time.sleep(10)
    rows=[]
    for mode in (['original','pool'] if (rep+cases.index(case))%2==0 else ['pool','original']):
     dest=out/f"{case['name']}-{mode}-r{rep}-a{attempt}";cmd=[str(b),'game','run','--map-file',case['map'],'--game-seed',str(case['game_seed']),'--ticks','16384','--benchmark-warmup','4096','--compute-threads','4','--gpu','off','--output-dir',str(dest)]
     for _ in range(8):cmd+=['--player','nicowar']
     env=os.environ.copy();env.pop('GLOB2_ISOLATED_LIVE_HIRING',None)
     if mode=='pool':
      env['GLOB2_ISOLATED_LIVE_HIRING']='1';cmd+=['--hiring-schedule','4:4:128:combined','--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds','--hiring-execution','pool']
     active=busy();start=time.monotonic()
     with dest.with_suffix('.log').open('w') as f:
      proc=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
      while proc.poll() is None:
       active|=busy();time.sleep(.25)
       if time.monotonic()-start>600:proc.terminate();proc.wait();break
     row={'case':case['name'],'repetition':rep,'attempt':attempt,'mode':mode,'command':cmd,'returncode':proc.returncode,'host_activity_detected':active,'result':json.load(open(dest/'result.json')) if (dest/'result.json').exists() else None,'trial':json.load(open(dest/'isolated-live.json')) if (dest/'isolated-live.json').exists() else None,'economy':json.load(open(dest/'economy-ledger.json')) if (dest/'economy-ledger.json').exists() else None};rows.append(row)
    rejected=any(r['host_activity_detected'] for r in rows)
    for r in rows:r['rejected_pair']=rejected;log.write(json.dumps(r)+'\n');log.flush()
    if rejected:print('excluded host overlap',case['name'],rep,attempt,flush=True);attempt+=1;continue
    print('pair',case['name'],rep,[(r['mode'],r['returncode'],r['result']['benchmark_run_cpu_ns'] if r['result'] else None,r['trial']['measured_elapsed_ns'] if r['trial'] else None) for r in rows],flush=True);break
