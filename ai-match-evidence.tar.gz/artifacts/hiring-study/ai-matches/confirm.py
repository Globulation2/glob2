from pathlib import Path
import json,subprocess,os,time
p=Path(__file__).resolve().parent;b=p/'glob2-trial';out=p/'confirmation';out.mkdir(exist_ok=False)
cases=[c for c in json.load(open(p/'maps.json')) if c['name'] in ['islands-713','swamp-8191']]
def busy():
 lines=subprocess.check_output(['ps','-axo','command'],text=True).splitlines()
 return any((l.startswith('/Applications/Xcode') and 'clang -cc1 ' in l) or (l.startswith('/') and ' -c ' not in l and ('engine-tests ' in l or 'unit-tests ' in l or '--test-suite=' in l or '--test-case=' in l or ' -tc=' in l)) for l in lines)
(out/'metadata.json').write_text(json.dumps({'selection':'Post-screen confirmation of islands713 and swamp8191; extend the same fixed-case paired samples from3to10, no general population inference. Same binary, map, game seed, warmup and fixed schedule; original process warmup runs retained in screen.','protocol':'Seven additional alternating paired repetitions, diagnostics off, n4,16384ticks including4096warmup, end drains included; reject overlapping detected host builds/tests.'},indent=2))
with (out/'samples.jsonl').open('w') as log:
 for rep in range(3,10):
  for case in cases if rep%2 else list(reversed(cases)):
   attempt=0
   while True:
    while busy():print('waiting for external host activity',flush=True);time.sleep(10)
    rows=[]
    for mode in ['original','pool'] if rep%2 else ['pool','original']:
     dest=out/f"{case['name']}-{mode}-r{rep}-a{attempt}";cmd=[str(b),'game','run','--map-file',case['map'],'--game-seed',str(case['game_seed']),'--ticks','16384','--benchmark-warmup','4096','--compute-threads','4','--gpu','off','--output-dir',str(dest)]
     for _ in range(8):cmd+=['--player','nicowar']
     env=os.environ.copy();env.pop('GLOB2_ISOLATED_LIVE_HIRING',None)
     if mode=='pool':env['GLOB2_ISOLATED_LIVE_HIRING']='1';cmd+=['--hiring-schedule','4:4:128:combined','--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds','--hiring-execution','pool']
     active=busy()
     with dest.with_suffix('.log').open('w') as f:
      proc=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
      while proc.poll() is None:active|=busy();time.sleep(.25)
     row={'case':case['name'],'repetition':rep,'attempt':attempt,'mode':mode,'command':cmd,'returncode':proc.returncode,'host_activity_detected':active,'result':json.load(open(dest/'result.json')) if (dest/'result.json').exists() else None,'trial':json.load(open(dest/'isolated-live.json')) if (dest/'isolated-live.json').exists() else None,'economy':json.load(open(dest/'economy-ledger.json')) if (dest/'economy-ledger.json').exists() else None};rows.append(row)
    rejected=any(r['host_activity_detected'] for r in rows)
    for r in rows:r['rejected_pair']=rejected;log.write(json.dumps(r)+'\n');log.flush()
    if rejected:attempt+=1;print('rejected overlap',case['name'],rep,flush=True);continue
    print(case['name'],rep,[(r['mode'],r['returncode'],r['trial']['measured_elapsed_ns'] if r['trial'] else None) for r in rows],flush=True);break
