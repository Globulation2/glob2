from pathlib import Path
import json,shlex,subprocess
p=Path(__file__).resolve().parent;old=Path('artifacts/hiring-study/live-measurement').resolve()
(p/'LiveHiringTrial.h').write_text((old/'LiveHiringTrial.h').read_text())
for name in ['Step.cpp','HiringStudy.cpp','TeamStep.cpp']:
 s=(old/name).read_text()
 if name=='Step.cpp':
  s=s.replace('if(LiveHiringTrial::active) {','if(LiveHiringTrial::active && !type->runtimeFlyingCarriers) {',1)
  s=s.replace('// This harness only permits material-only buildings. Surrounding quotas,','// Material consumer only; attractions and flying carriers retain original search.\n  // Surrounding quotas,')
 (p/name).write_text(s)
s=Path('src/game/GameAI.cpp').read_text();s='#include "LiveHiringTrial.h"\n#include "Team.h"\n#include "Unit.h"\n#include "Building.h"\n#include <span>\n'+s
key=' auto world=worldSnapshots.captureBoundary(*this,requirements);'
prep=''' LiveHiringTrial::Scope scope(LiveHiringTrial::Capture);
 if(LiveHiringTrial::active && HiringStudy::requirements(*this,paused)) {
  for(int t=0;t<teamsCount();++t) {
   if(stepCounter%4!=unsigned(t)%4)continue; // Fixed K4/R4 trial admission.
   unsigned classes=0;for(const auto* u:teams[t]->liveUnits.entries())if(!u->performance[FLY])classes|=1u<<u->swimClass();
   for(auto* b:std::span(teams[t]->myBuildings,Building::MAX_COUNT))if(b && b->buildingState==Building::ALIVE &&
      !b->type->runtimeFlyingCarriers && b->desiredMaxUnitWorking>0 && b->unitsWorking.size()<unsigned(b->desiredMaxUnitWorking)) {
    bool demand=false;for(unsigned m=0;m<MaterialCount;++m)demand|=b->materialDeliveryNeed(m)>0;
    if(!demand)continue;
    for(int c=0;c<SWIM_CLASS_COUNT;++c)if(classes&(1u<<c)) {
     int ignoredDistance=0;
     const_cast<Game*>(this)->map.buildingAvailable(b,c,b->posX,b->posY,&ignoredDistance,BuildingRoute::Footprint);
     for(unsigned m=0;m<MaterialCount;++m)if(b->materialDeliveryNeed(m)>0)
      const_cast<Game*>(this)->map.getMaterialGradientSlot(t,m,c,b->fetchesFromMarkets(),b);
    }
   }
  }
 }
 auto world=worldSnapshots.captureBoundary(*this,requirements);'''
assert key in s;s=s.replace(key,prep);(p/'GameAI.cpp').write_text(s)
s=Path('src/app/cli/Headless.cpp').read_text();s='#include "LiveHiringTrial.h"\n'+s
key='\t\tglobals.load();\n\t\tEngine engine;'
replace='''        LiveHiringTrial::active=std::getenv("GLOB2_ISOLATED_LIVE_HIRING")!=nullptr;
        LiveHiringTrial::collect=HiringDiagnostics::enabled();
        if(LiveHiringTrial::active && (one(options,"--hiring-schedule","")!="4:4:128:combined" || options.count("--save") || one(options,"--replay","false")=="true"))
            throw std::invalid_argument("Isolated live trial requires schedule and forbids saves/replay");
        LiveHiringTrial::ns.fill(0);LiveHiringTrial::examined=LiveHiringTrial::missing=LiveHiringTrial::rejected=LiveHiringTrial::destinationFailures=LiveHiringTrial::hires=0;
\t\tglobals.load();
\t\tEngine engine;'''
assert key in s;s=s.replace(key,replace)
s=s.replace('uint64_t setupCpu=0,runCpu=0,measureStart=0;','uint64_t setupCpu=0,runCpu=0,measureStart=0;\n        auto measuredWallStart=std::chrono::steady_clock::time_point{};')
s=s.replace('if(benchmarkWarmup==0) measureStart=processCpuNs();','if(benchmarkWarmup==0){measureStart=processCpuNs();measuredWallStart=std::chrono::steady_clock::now();}')
s=s.replace('if(!measureStart && engine.gui.game.stepCounter>=start) measureStart=processCpuNs();','''if(!measureStart && engine.gui.game.stepCounter>=start) {
                    measureStart=processCpuNs();measuredWallStart=std::chrono::steady_clock::now();
                    LiveHiringTrial::ns.fill(0);LiveHiringTrial::examined=LiveHiringTrial::missing=LiveHiringTrial::rejected=LiveHiringTrial::destinationFailures=LiveHiringTrial::hires=0;
                }''')
key='\t\tconst auto runEnd = std::chrono::steady_clock::now();'
replace=key+'''\n        {std::ofstream trial(output/"isolated-live.json");
         trial << "{\\"material_only\\":true,\\"active\\":" << (LiveHiringTrial::active?"true":"false")
          << ",\\"measured_elapsed_ns\\":" << (benchmark?std::chrono::duration_cast<std::chrono::nanoseconds>(runEnd-measuredWallStart).count():0)
          << ",\\"owner_hiring_ns\\":" << LiveHiringTrial::ns[LiveHiringTrial::Tasks]
          << ",\\"capture_submit_ns\\":" << LiveHiringTrial::ns[LiveHiringTrial::Capture]
          << ",\\"publication_ns\\":" << LiveHiringTrial::ns[LiveHiringTrial::Publication]
          << ",\\"material_hires\\":" << LiveHiringTrial::hires << ",\\"suggestions_examined\\":" << LiveHiringTrial::examined
          << ",\\"missing_lists\\":" << LiveHiringTrial::missing << ",\\"rejections\\":" << LiveHiringTrial::rejected
          << ",\\"destination_failures\\":" << LiveHiringTrial::destinationFailures << "}";
        }'''
assert key in s;s=s.replace(key,replace)
ledger='''        { nlohmann::json ledger=nlohmann::json::array();
          for(int t=0;t<engine.gui.game.teamsCount();++t) {
           const auto& m=engine.gui.game.teams[t]->stats.measurements;Uint64 births=0,starvation=0,otherDeaths=0,completed=0;
           for(unsigned u=0;u<engine.gui.game.teams[t]->stats.unitTypeCount;++u){births+=m.births[u];starvation+=m.deaths[u][GameplayMeasurements::STARVATION];for(int c=0;c<GameplayMeasurements::DEATH_CAUSES;++c)if(c!=GameplayMeasurements::STARVATION)otherDeaths+=m.deaths[u][c];}
           for(const auto& b:m.variants)for(int l=0;l<3;++l)completed+=b.completed[l];
           ledger.push_back({{"team",t},{"births",births},{"starvation_deaths",starvation},{"other_deaths",otherDeaths},{"completed_construction",completed},{"harvested",m.harvested}});
          }
          std::ofstream(output/"economy-ledger.json")<<ledger.dump(2);
        }
'''
s=s.replace('\t\tconst auto saveCpuStart=benchmark?processCpuNs():0;',ledger+'\t\tconst auto saveCpuStart=benchmark?processCpuNs():0;')
(p/'Headless.cpp').write_text(s)
s=Path('src/engine/EngineRun.cpp').read_text()
key='\t}\n\t// advanceStep inserts the local order.'
replacement='''        if(std::getenv("GLOB2_ISOLATED_TRACE") && !headlessOutput.empty())
            std::ofstream(headlessOutput+"/world.checksums",std::ios::app)
                << gui.game.stepCounter << ' ' << gui.game.checkSum(nullptr,nullptr,nullptr,true) << '\\n';
\t}
\t// advanceStep inserts the local order.'''
assert key in s;s=s.replace(key,replacement,1);(p/'EngineRun.cpp').write_text(s)
log=Path('artifacts/hiring-study/quotas/integrated-build.log').read_text().splitlines()+Path('artifacts/hiring-study/planner-final/after-build.log').read_text().splitlines()
commands=[];replacements={}
for source in ['src/building/Step.cpp','src/building/HiringStudy.cpp','src/team/TeamStep.cpp','src/game/GameAI.cpp','src/app/cli/Headless.cpp','src/engine/EngineRun.cpp']:
 line=next(l for l in log if l.startswith('/opt/homebrew/bin/ccache g++ ') and l.endswith(' '+source));args=shlex.split(line)
 args[args.index('-o')+1]=str(p/(Path(source).stem+'.o'));args[-1]=str(p/Path(source).name)
 args=[a.replace('\\"','"') if a.startswith('-D') else a for a in args];args+=['-I'+str(p)];commands.append(args)
 replacements['build/darwin/client/release/dev-linker-auto/'+source[:-4]+'.o']=str(p/(Path(source).stem+'.o'))
link=shlex.split(next(l for l in log if l.startswith('g++ -o build/darwin/client/release/dev-linker-auto/src/glob2 ')))
link=[replacements.get(a,a) for a in link];link[link.index('-o')+1]=str(p/'glob2-trial')
(p/'compile-commands.json').write_text(json.dumps(commands,indent=2));(p/'link-command.json').write_text(json.dumps(link,indent=2))
for c in commands:subprocess.run(c,check=True)
subprocess.run(link,check=True)
