import hashlib,json,os,pwd,signal,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=ROOT/'artifacts/resource-followup'
sys.path.insert(0,str(BASE/'final-campaign'));import run_final_timing as campaign
OUT=BASE/'v2-isolated-frequency';OUT.mkdir(exist_ok=False)
os.environ['LD_LIBRARY_PATH']=campaign.LIBS
before=campaign.input_snapshot({'v2-priority'});(OUT/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
scenarios=json.loads((BASE/'priority-recovery/priority-windows.json').read_text())['scenarios']
report={'scope':'Separate instrumented process-tree counters including launcher/startup, not frequency of prior paired timing observations and not performance acceptance. Exclusive CPU partition and performance governors audited separately. Concurrent evidence packaging outside the partition is permitted for this diagnostic.','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'runs':[]}
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def interrupted(sig,frame):raise InterruptedError(f'signal {sig}')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGHUP,interrupted)
try:
 for scenario in scenarios:
  for arm in ('merged','reuse-v2'):
   dest=OUT/(arm+'-'+scenario['id']);dest.mkdir();perf=dest/'perf-stat.csv'
   engine=[str(campaign.BINS[arm]),'--run-game',*scenario['args'],'--benchmark-warmup','0','--output-dir',str(dest/'run')]
   command=['sudo','-n','perf','stat','-x',';','-e','cycles,task-clock,instructions,context-switches,cpu-migrations','-o',str(perf),'--','sudo','-n','-u',pwd.getpwuid(os.getuid()).pw_name,'env','LD_LIBRARY_PATH='+campaign.LIBS,'GLOB2_USER_DIR='+str(dest/'profile'),'GLOB2_USER_DATA_DIR='+str(dest/'profile'),*engine]
   row={'arm':arm,'scenario':scenario['id'],'command':command,'cwd':str(campaign.ROOTS[arm])};report['runs'].append(row);save()
   with (dest/'run.log').open('x') as log:
    child=subprocess.Popen(command,cwd=campaign.ROOTS[arm],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:code=child.wait(timeout=300)
    finally:
     if child.poll() is None:
      subprocess.run(['sudo','-n','kill','-INT','--','-'+str(child.pid)],check=False)
      try:child.wait(timeout=10)
      except subprocess.TimeoutExpired:
       subprocess.run(['sudo','-n','kill','-KILL','--','-'+str(child.pid)],check=True);child.wait()
   row['returncode']=code
   if code:raise RuntimeError('Counter child failed')
   subprocess.run(['sudo','-n','chown',f'{os.getuid()}:{os.getgid()}',str(perf)],check=True)
   result=json.loads((dest/'run/result.json').read_text());expected=int(scenario['args'][scenario['args'].index('--ticks')+1])-scenario['start_tick']
   if result['benchmark_measured_ticks']!=expected:raise RuntimeError('Incomplete window')
   counters={}
   for line in perf.read_text().splitlines():
    f=line.split(';')
    if len(f)>=5 and f[2] in ('cycles','task-clock','instructions','context-switches','cpu-migrations'):counters[f[2]]={'value':float(f[0]),'unit':f[1],'running_percent':float(f[4])}
   if len(counters)!=5 or any(x['running_percent']<99.9 for x in counters.values()) or counters['task-clock']['unit']!='msec':raise RuntimeError('Missing/multiplexed counters or unexpected unit')
   row.update(counters=counters,effective_GHz=counters['cycles']['value']/(counters['task-clock']['value']*1e6),measured_ticks=expected);save()
 report['status']='complete'
finally:
 after=campaign.input_snapshot({'v2-priority'});(OUT/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');report['inputs_unchanged']=before==after;save()
 if before!=after:raise RuntimeError('Diagnostic inputs changed')
print(json.dumps([{'arm':r['arm'],'scenario':r['scenario'],'effective_GHz':r['effective_GHz'],'instructions':r['counters']['instructions']['value']} for r in report['runs']],indent=2))
