from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json
out=Path('artifacts/honeycomb-open-cells/sweep');out.mkdir(exist_ok=True)
binary=str(Path('artifacts/honeycomb-open-cells/after-glob2').resolve())
cases=[]
for w,h,teams in [(128,128,2),(128,256,4),(256,128,4),(256,256,4),(512,256,8),(256,512,8),(512,512,16)]:
 for shape in [0,1,2]:
  for amount in [0,100,300]:
   cases.append(dict(width=w,height=h,teams=teams,seed=5,options={'block-shape':shape,'stone-amount':amount}))
(out/'requests.json').write_text(json.dumps(cases,indent=2))
def run(item):
 k,c=item;name=f'{k:03d}';cmd=[binary,'map','generate','honeycomb-isle','--width',str(c['width']),'--height',str(c['height']),'--teams',str(c['teams']),'--seed',str(c['seed']),'--report-file',str(out/(name+'.json'))]
 for key,value in c['options'].items():cmd+=['--set',f'{key}={value}']
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 return {'case':k,'returncode':r.returncode}
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,enumerate(cases)))
(out/'results.json').write_text(json.dumps(results,indent=2));bad=[r for r in results if r['returncode']];print('Cases',len(results),'failures',bad,flush=True)
