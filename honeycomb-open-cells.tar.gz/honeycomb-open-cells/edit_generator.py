from pathlib import Path
p=Path('src/map/generator/generators/HoneycombIsleGenerator.cpp');s=p.read_text()
s=s.replace('edge and line the river; the blocks inside are ruins, stone outlines broken open onto the street\n// and filled with rubble that has grown over, with a few open squares, crater gardens round flooded\n// bomb craters, and the shell of a landmark at the middle (a stadium, a cathedral or a station)\n// with an orchard growing in it.','edge and line the river; the blocks inside contain overgrown rubble, with a few open squares,\n// crater gardens round flooded bomb craters, and an open orchard at the middle.')
s=s.replace('and cutting through a ruin opens a way into a neighbour\'s flank. Stone outlines cannot be\n// cleared, so the ruins keep their shape and only their gaps and fill change hands. The bridges are','and cutting through a ruin opens a way into a neighbour\'s flank. Blocks have no stone liners,\n// so clearing rubble opens the whole block. The bridges are')
s=s.replace('WellYard,     // the cistern in front of the home block\'s middle, nothing else standing\n\tWalledCellar, // the same well, with the back half of the block\'s outline still standing\n\tGardenCourt,  // the well on the street between the two blocks, stone posts round its court','WellYard,    // the cistern in front of the home block\'s middle\n\tGardenCourt, // the well on the street between the two blocks')
a=s.index('enum LandmarkDesign');b=s.index('\nstruct Plot',a)
s=s[:a]+'const char *const kHomeDesignNames[] = {"well-yard", "garden-court"};\n'+s[b:]
s=s.replace('int homeDesign = 0, landmarkDesign = 0, bridges = 0;','int homeDesign = 0, bridges = 0;')
s=s.replace('\tL.landmarkDesign = int(context.bounded("honeycomb-isle-landmark-design", kLandmarkDesigns));\n','').replace('\tL.telemetry.choice("honeycomb-isle.landmark-design", kLandmarkDesignNames[L.landmarkDesign]);\n','')
a=s.index('\t// An edge\'s midpoint on a cell\'s outline:');b=s.index('\tconst auto nearPoint',a);s=s[:a]+s[b:]
s=s.replace('// Homes: a garden round the cistern and the design\'s standing stone.','// Homes: open gardens round the cistern, without stone walls or posts.').replace('\tconst double gap = o.streetWidth / 2.0 + 2.2;\n','')
a=s.index('\t\tif (L.homeDesign == WalledCellar)');b=s.index('\n\t}\n\n\t// Craters:',a);s=s[:a]+s[b:]
s=s.replace('// The landmark\'s stone and the orchard at its heart, which grows with the fruit amount.','// The central orchard is open grass, without stone rings, pillars or platforms.')
a=s.index('\t\tstd::vector<ShapePoint> gates;',s.index('// The central orchard'));b=s.index('\t\t\tif (nearPoint(i, centre, orchardRadius))',a)
s=s[:a]+'''		for (int i : tilesOf[c])
		{
			if (!interior[i])
				continue;
'''+s[b:]
s=s.replace('\t\t\t\tL.stone[i] = 0;\n','')
a=s.index('\t// Ruins and collapsed blocks: outlines with gaps, and rubble.');b=s.index('\t// The rubble control',a)
s=s[:a]+'''	// Ruins and collapsed blocks contain rubble, with open edges instead of stone outlines.
	const std::vector<int> fill = periodicNoise(t.w, t.h, 4, context.stream("honeycomb-isle-fill"));
	const std::vector<int> chunks = periodicNoise(t.w, t.h, 2, context.stream("honeycomb-isle-chunks"));
	std::vector<unsigned char> rubbleGround(n, 0);
	for (int c = 0; c < cells; ++c)
	{
		if (L.kind[c] != Block::Ruin && L.kind[c] != Block::Collapsed)
			continue;
		for (int i : tilesOf[c])
			if (interior[i] && depth[i] >= (L.kind[c] == Block::Ruin ? 2 : 1))
				rubbleGround[i] = 1;
	}
'''+s[b:]
s=s.replace('// at a wood amount of 0 the ruins stand empty.','// at a wood amount of 0 the blocks stand empty.')
s=s.replace('// Standing stone and rubble go down before the colonies: neither is ever on a home.','// Scattered masonry and rubble go down before the colonies: neither is ever on a home.')
s=s.replace('outlineGaps(r.option("outline-gaps")), craters(r.option("crater-gardens")),','craters(r.option("crater-gardens")),')
s=s.replace('"Honeycomb isle",\n\t\t3,','"Honeycomb isle",\n\t\t// Revision 4: hexagons by default, open cell edges and an unenclosed orchard.\n\t\t4,')
s=s.replace('2, ControlGroup::Terrain)\n\t\t\t .withSearchValues({0, 1})','1, ControlGroup::Terrain)\n\t\t\t .withSearchValues({0, 1})',1)
s=s.replace('\t\t GeneratorControl{"outline-gaps", "Outline gaps", 0, 100, 10, 40, ControlGroup::Terrain}\n\t\t\t .withSearchRange(20, 70),\n','')
s=s.replace('// chunks in the rubble: ruin and landmark outlines are structural and stand at 0.','// chunks in the rubble and the single statues in open squares.')
p.write_text(s)
p=Path('src/map/generator/generators/HoneycombIsleGenerator.h');s=p.read_text().replace('rubble, outlineGaps, craters','rubble, craters');p.write_text(s)
