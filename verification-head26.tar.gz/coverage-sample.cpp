#include "TerrainMaterials.h"
#include <nlohmann/json.hpp>
#include <fstream>
#include <chrono>
#include <iostream>
int main() {
 std::ifstream file("data/terrain/tileset.json"); nlohmann::json document; file >> document;
 auto catalog=TerrainVisual::Catalog::parse(document);
 auto start=std::chrono::steady_clock::now(); uint64_t digest=14695981039346656037ull;
 for(unsigned configuration=0;configuration<256;++configuration) {
  TerrainVisual::Recipe recipe; recipe.width=recipe.height=16; recipe.x=15;recipe.y=9;
  for(int y=0;y<4;++y)for(int x=0;x<4;++x) recipe.samples[y*4+x]=(configuration>>(2*((x&1)+2*(y&1))))&3;
  TerrainVisual::PreparedCoverage prepared(catalog,recipe);
  for(int scale:{1,2,4})for(int y=0;y<32*scale;++y)for(int x=0;x<32*scale;++x){
   auto pixel=prepared.at((x*256+128)/scale,(y*256+128)/scale);
   for(int k=0;k<4;++k){digest=(digest^pixel.material[k])*1099511628211ull;digest=(digest^pixel.weight[k])*1099511628211ull;}
  }
 }
 std::cout << digest << " " << std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count() << " seconds\n";
}
