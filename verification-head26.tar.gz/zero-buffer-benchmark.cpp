#include <valarray>
#include <memory>
#include <chrono>
#include <cstdio>
volatile unsigned char sink;
int main(){constexpr int bytes=4194304; for(int mode=0;mode<2;++mode){auto start=std::chrono::steady_clock::now();for(int i=0;i<100;++i){if(mode){std::unique_ptr<char[]> p(new char[bytes]());sink=p[bytes-1];}else{std::valarray<char> p((char)0,bytes);sink=p[bytes-1];}}auto end=std::chrono::steady_clock::now();printf("%s %.3f seconds\n",mode?"value-initialized array":"valarray",std::chrono::duration<double>(end-start).count());}}
