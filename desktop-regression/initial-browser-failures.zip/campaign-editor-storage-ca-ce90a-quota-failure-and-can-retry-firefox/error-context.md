# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: campaign-editor-storage.spec.js >> campaign authoring retains the editor on quota failure and can retry
- Location: tests/campaign-editor-storage.spec.js:36:1

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator:  locator('input[aria-label="Game text field"]')
Expected: ""
Received: "No Name"
Timeout:  30000ms

Call log:
  - Expect "toHaveValue" locator('input[aria-label="Game text field"]') with timeout 30000ms
  - waiting for locator('input[aria-label="Game text field"]')
    63 × locator resolved to <input type="text" autocomplete="off" spellcheck="false" aria-label="Game text field"/>
       - unexpected value "No Name"

```

```yaml
- textbox "Game text field": No Name
```

# Test source

```ts
  21  |   add('tutorial', compact ? 30 : 38);
  22  |   y += compact ? 12 : 18;
  23  |   add('yog', compact ? 28 : 34);
  24  |   y += 4 + (compact ? 12 : 18);
  25  |   const utilityH = compact ? 28 : 32;
  26  |   const utilityW = Math.floor(w / 2) - 4;
  27  |   for (const [index, name] of ['settings', 'editor', 'credits', 'quit'].entries()) {
  28  |     entries[name] = {
  29  |       x: x + (index % 2) * (Math.floor(w / 2) + 4) + Math.floor(utilityW / 2),
  30  |       y: y + Math.floor(index / 2) * (utilityH + 4) + Math.floor(utilityH / 2),
  31  |     };
  32  |   }
  33  |   return entries[action];
  34  | };
  35  | 
  36  | exports.gameURL = () => {
  37  |   const entry = process.env.GLOB2_TEST_ENTRY_PATH || '/';
  38  |   const renderer = process.env.GLOB2_TEST_RENDERER;
  39  |   if (!renderer) return entry;
  40  |   if (!['software', 'webgl2'].includes(renderer)) {
  41  |     throw new Error('Unknown test renderer: ' + renderer);
  42  |   }
  43  |   const url = new URL(entry, 'http://localhost');
  44  |   url.searchParams.set('renderer', renderer);
  45  |   return url.pathname + url.search;
  46  | };
  47  | 
  48  | exports.clickMainMenu = async (page, action) => {
  49  |   const {width, height} = page.viewportSize();
  50  |   const touch = await page.evaluate(() => Boolean(Module.presentationMetrics?.touch));
  51  |   if (touch || width < 640 || height < 480) {
  52  |     const names=['custom','campaign','load','tutorial','yog','settings','editor','credits','quit'];
  53  |     const index=names.indexOf(action),available=Math.min(width,640)-16;
  54  |     const columns=available>=456 ? 2 : 1;
  55  |     const buttonWidth=(available-(columns-1)*8)/columns;
  56  |     return page.locator('#canvas').click({position:{
  57  |       x:(width-Math.min(width,640))/2+8+(index%columns)*(buttonWidth+8)+buttonWidth/2,
  58  |       y:56+Math.floor(index/columns)*56+24},delay:80});
  59  |   }
  60  |   return page.locator('#canvas').click({position: point(width, height, action), delay: 80});
  61  | };
  62  | 
  63  | // Mirrors SettingsScreen::layout()'s panel/footer math (src/SettingsScreenLayout.cpp)
  64  | // for the footer's two buttons. Assumes the footer status line stays on one
  65  | // line, which holds at every viewport this suite resizes to while Settings
  66  | // is open; a panel narrower than ~500px could wrap it and shift these.
  67  | const settingsFooter = (width, height) => {
  68  |   const panelW = Math.min(width - 32, 960);
  69  |   const panelH = Math.min(height - 32, 720);
  70  |   const panelX = Math.floor((width - panelW) / 2);
  71  |   const panelY = Math.floor((height - panelH) / 2);
  72  |   const footH = 64;
  73  |   const footerX = panelX, footerY = panelY + panelH - footH, footerW = panelW;
  74  |   const doneX = footerX + footerW - 112, doneY = footerY + 12;
  75  |   return {
  76  |     done: {x: doneX + 48, y: doneY + 20},
  77  |     // Always visible, and always closes Settings in one click regardless of
  78  |     // any save failure — see SettingsScreen::abandon().
  79  |     cancel: {x: doneX - 52, y: doneY + 20},
  80  |   };
  81  | };
  82  | exports.settingsFooter = settingsFooter;
  83  | exports.clickSettingsDone = (page) => {
  84  |   const {width, height} = page.viewportSize();
  85  |   return page.locator('#canvas').click({position: settingsFooter(width, height).done, delay: 80});
  86  | };
  87  | exports.clickSettingsCancel = (page) => {
  88  |   const {width, height} = page.viewportSize();
  89  |   return page.locator('#canvas').click({position: settingsFooter(width, height).cancel, delay: 80});
  90  | };
  91  | 
  92  | // Mirrors CustomGameScreen::renderLobby()'s "start" button rect
  93  | // (src/CustomGameScreen.cpp). Starting also prepares the selected landscape
  94  | // if its preview is still pending.
  95  | exports.clickCustomGameStart = (page) => {
  96  |   const {width, height} = page.viewportSize();
  97  |   const w = Math.min(width - 32, 1120), x = Math.floor((width - w) / 2);
  98  |   return page.locator('#canvas').click({position: {x: x + w - 165 + 82, y: height - 52 + 17}, delay: 80});
  99  | };
  100 | 
  101 | // The unscrolled Players & Teams rows share this geometry at every viewport.
  102 | exports.clickCustomAIProfile = (page, colony) => {
  103 |   const {width} = page.viewportSize();
  104 |   const w = Math.min(width - 32, 1120), x = Math.floor((width - w) / 2);
  105 |   const rowHeight = w < 760 ? 80 : 100;
  106 |   return page.locator('#canvas').click({
  107 |     position: {x: x + w - 150 + 64, y: 85 + 42 + colony * rowHeight + 42 + 14}, delay: 80,
  108 |   });
  109 | };
  110 | 
  111 | // Exercise the visible editing surface with actual mouse and keyboard events.
  112 | // Filling the DOM value directly would miss focus, deletion and key routing bugs.
  113 | exports.editTextField = async (page, value, password = false) => {
  114 |   const {expect} = require('@playwright/test');
  115 |   const field = page.locator(password ? 'input[aria-label="Password"]' : 'input[aria-label="Game text field"]');
  116 |   await field.click();
  117 |   await expect(field).toBeFocused();
  118 |   await field.press('Home');
  119 |   await field.press('Shift+End');
  120 |   await field.press('Delete');
> 121 |   await expect(field).toHaveValue('');
      |                       ^ Error: expect(locator).toHaveValue(expected) failed
  122 |   await field.pressSequentially(value);
  123 |   await expect(field).toHaveValue(value);
  124 |   if (password) await expect(field).toHaveAttribute('type', 'password');
  125 | };
  126 | 
```