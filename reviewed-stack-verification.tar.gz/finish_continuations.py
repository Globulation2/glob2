from pathlib import Path
import json,subprocess,time,os
root=Path.cwd();p=root/'artifacts/gpu-merge-review'
while not (p/'fixtures-complete.json').exists():time.sleep(5)
env={**os.environ,'VK_DRIVER_FILES':'/usr/share/vulkan/icd.d/nvidia_icd.json','VK_INSTANCE_LAYERS':'VK_LAYER_KHRONOS_validation','VK_LAYER_ENABLES':'VK_VALIDATION_FEATURE_ENABLE_SYNCHRONIZATION_VALIDATION_EXT'}
command=['python3',str(p/'run_continuations.py')]
with (p/'continuations.log').open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
if r.returncode:raise SystemExit('continuation failed')
rows=json.loads((p/'continuations/runs.json').read_text());assert len(rows)==12 and all(r['exit']==0 and r['checksums_match'] and r['saves_match'] for r in rows)
matches=json.loads((p/'matches/runs.json').read_text());assert len(matches)==12 and all(r['exit']==0 and r['trace_matches_golden'] for r in matches)
receipt={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'base':'85b02d2f1dbda56fc7b40d4b941140d762188a26','unit':'164 cases,706829 assertions, API/sync validation','engine':30,'matches':12,'continuations':12,'continuation_command':command,'initial_legacy_save_failure':'Baseline and candidate both reject saved versions below159 due to master policy; current-version fixture regenerated'}
(p/'correctness-complete.json').write_text(json.dumps(receipt,indent=2)+'\n');print('current-format continuations passed',flush=True)
