from pathlib import Path
import json,os,subprocess,time
root=Path.cwd();out=root/'artifacts/gpu-merge-review/continuations';out.mkdir(exist_ok=True)
binary=root/'build/gpu-offload-correctness/src/glob2'; source=root/'artifacts/gpu-merge-review/fixtures/river128-game/checkpoint-4096.game.gz'
rows=[];baseline=None;baseline_save=None
for backend,algorithm in [('cpu','buckets'),('vulkan','frozen8'),('vulkan','jacobi')]:
 for count in [1,2,4,8]:
  name=f'{backend}-{algorithm}-{count}';dest=out/name
  env={**os.environ,'VK_DRIVER_FILES':'/usr/share/vulkan/icd.d/nvidia_icd.json','GLOB2_GRADIENT_DIAGNOSTICS':'1','GLOB2_TEST_ARTIFACTS':str(out/name/'proofs')}
  command=[str(binary),'game','run','--load-game',str(source),'--ticks','4608','--compute-threads',str(count),'--gradient-backend',backend,'--gradient-algorithm',algorithm,'--gradient-verify','off','--telemetry','checksums','--save','final','--output-dir',str(dest)]
  start=time.monotonic()
  with (out/(name+'.log')).open('w') as log:
   run=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
  row=dict(name=name,command=command,exit=run.returncode,elapsed=time.monotonic()-start)
  if run.returncode==0:
   result=json.loads((dest/'result.json').read_text());checks=(dest/'world.checksums').read_bytes()
   save=(dest/'final.game.gz').read_bytes()
   if baseline is None:baseline=checks;baseline_save=save
   row.update(checksums_match=checks==baseline,saves_match=save==baseline_save,gpu_fields=result['gradient_gpu_fields'],verified=result['gradient_verified'],fallbacks=result['gradient_cpu_fallbacks'])
  rows.append(row);(out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(name,run.returncode,row.get('gpu_fields'),row.get('checksums_match'),flush=True)
  if run.returncode:raise SystemExit(run.returncode)
