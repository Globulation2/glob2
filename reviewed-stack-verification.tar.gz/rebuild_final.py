from pathlib import Path
import time,subprocess,os
root=Path.cwd();old=root/'artifacts/gpu-validation-offload';p=root/'artifacts/gpu-merge-review'
for name in ['review-dev-build.log','review-release-build.log']:
 while True:
  s=(old/name).read_text()
  if 'scons: ***' in s:raise SystemExit('Previous build failed: '+name)
  if 'scons: done building targets.' in s:break
  time.sleep(5)
env={**os.environ,'GLOB2_SDL3_PREFIX':'/home/bradley/glob2/build/sdl3/prefix'}
commands=[('final-dev-build',['python3','tools/dev_build.py','--build=build/gpu-offload-correctness','-j4','unit-tests','engine-tests','build/gpu-offload-correctness/src/glob2']),('final-release-build',['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','client_profile=full','--build=build/gpu-offload-release','-j4','build/gpu-offload-release/src/glob2'])]
for name,command in commands:
 with (p/(name+'.log')).open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 if r.returncode:raise SystemExit(name+' failed')
 print(name,'complete',flush=True)
(p/'final-build-complete.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
