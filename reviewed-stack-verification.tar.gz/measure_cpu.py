from pathlib import Path
import os,json,subprocess,time,hashlib,statistics,math
from scipy.stats import t
root=Path.cwd();p=root/'artifacts/gpu-merge-review';m=p/'frozen-cpu-manifest.json'
while not m.exists():time.sleep(5)
manifest=json.loads(m.read_text());out=p/'cpu-pairs';out.mkdir(exist_ok=True)
for ref in manifest['references'].values():assert hashlib.sha256(Path(ref['binary']).read_bytes()).hexdigest()==ref['sha256']
for f in manifest['fixtures']:assert hashlib.sha256(Path(f['path']).read_bytes()).hexdigest()==f['sha256']
compiler_names={'cc1plus','lto1','clang','clang++','rustc','cargo','collect2','ld','ld.bfd','ld.gold','lld'}
def compiling():
 for d in Path('/proc').iterdir():
  if d.name.isdigit():
   try:
    if (d/'comm').read_text().strip() in compiler_names:return True
   except OSError:pass
 return False
rows=[];discarded=[];env={**os.environ,'GLOB2_GRADIENT_DIAGNOSTICS':'0','GLOB2_GRADIENT_VERIFY':'0','GLOB2_VULKAN_VERIFY_TRANSFERS':'0','VK_DRIVER_FILES':'/usr/share/vulkan/icd.d/nvidia_icd.json'}
for pair in range(8):
 for fixture in manifest['fixtures']:
  for count in [1,2,4,8]:
   attempt=0
   while True:
    while compiling():time.sleep(5)
    attempt+=1;pending=[];bad=False
    for revision in (['before','after'] if pair%2==0 else ['after','before']):
     if compiling():bad=True;break
     dest=out/f'{pair}-{fixture["name"]}-{count}-{revision}-attempt{attempt}'
     command=[manifest['references'][revision]['binary'],'game','run','--load-game',fixture['path'],'--ticks',str(fixture['tick']+fixture['window_ticks']),'--benchmark-warmup',str(fixture['warmup_ticks']),'--compute-threads',str(count),'--gradient-backend','cpu','--gradient-algorithm','buckets','--gradient-verify','off','--output-dir',str(dest)]
     with dest.with_suffix('.log').open('w') as log:
      start=time.monotonic_ns();next_probe=0;child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
      while True:
       pid,status,usage=os.wait4(child.pid,os.WNOHANG)
       now=time.monotonic_ns()
       if now>=next_probe:
        if compiling():bad=True
        next_probe=now+500_000_000
       if pid:
        if compiling():bad=True
        break
       time.sleep(.005)
      child.returncode=os.waitstatus_to_exitcode(status);elapsed=time.monotonic_ns()-start
     if child.returncode:raise RuntimeError(f'benchmark failed: {dest}')
     r=json.loads((dest/'result.json').read_text());assert r['gradient_gpu_fields']==0
     assert r['benchmark_measured_ticks']==fixture['window_ticks']-fixture['warmup_ticks']
     pending.append({'pair':pair,'fixture':fixture['name'],'count':count,'revision':revision,'attempt':attempt,'command':command,'elapsed_ns':elapsed,'whole_cpu_ns':round((usage.ru_utime+usage.ru_stime)*1e9),'cpu_per_tick':(usage.ru_utime+usage.ru_stime)*1e9/fixture['window_ticks'],'window_cpu_per_tick':r['benchmark_run_cpu_ns']/r['benchmark_measured_ticks'],'checksum':r['finalChecksum'],'tick_p95_ns':r['tick_p95_ns'],'gpu_fields':r['gradient_gpu_fields'],'max_rss_kib':usage.ru_maxrss})
     if bad:break
    if bad:
     discarded.append({'pair':pair,'fixture':fixture['name'],'count':count,'attempt':attempt,'reason':'compiler activity'});(out/'discarded.json').write_text(json.dumps(discarded,indent=2)+'\n');continue
    assert len(pending)==2 and pending[0]['checksum']==pending[1]['checksum'];rows+=pending;(out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');break
 print('complete cohort pair',pair+1,'runs',len(rows),flush=True)
def compare(b,a):
 differences=[x-y for x,y in zip(b,a)];base=statistics.mean(b);mean=statistics.mean(differences);half=float(t.ppf(.975,len(b)-1))*statistics.stdev(differences)/math.sqrt(len(b));return {'before_mean':base,'after_mean':statistics.mean(a),'savings_pct':100*mean/base,'paired_95_ci_pct':[100*(mean-half)/base,100*(mean+half)/base]}
summary={'pairs':8,'runs':len(rows),'checksum_pairs_equal':len(rows)//2,'by_count':{},'fixtures':{},'qualification':'CPU-only isolation comparison; not GPU offload qualification'}
for count in [1,2,4,8]:
 summary['by_count'][str(count)]={}
 for metric in ['cpu_per_tick','window_cpu_per_tick']:
  cohorts={rev:[sum(r[metric]*next(f['weight'] for f in manifest['fixtures'] if f['name']==r['fixture']) for r in rows if r['pair']==pair and r['count']==count and r['revision']==rev) for pair in range(8)] for rev in ['before','after']}
  summary['by_count'][str(count)][metric]=compare(cohorts['before'],cohorts['after'])
for fixture in manifest['fixtures']:
 for count in [1,2,4,8]:
  paired={rev:sorted([r for r in rows if r['fixture']==fixture['name'] and r['count']==count and r['revision']==rev],key=lambda r:r['pair']) for rev in ['before','after']}
  summary['fixtures'][f'{fixture["name"]}-{count}']={**compare([r['cpu_per_tick'] for r in paired['before']],[r['cpu_per_tick'] for r in paired['after']]),'median_elapsed_change_pct':100*(statistics.median(r['elapsed_ns'] for r in paired['after'])/statistics.median(r['elapsed_ns'] for r in paired['before'])-1)}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary['by_count'],indent=2),flush=True)
