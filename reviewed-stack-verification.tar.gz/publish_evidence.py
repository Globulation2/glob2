from pathlib import Path
import json,time,subprocess,os,tarfile,hashlib
root=Path.cwd();p=root/'artifacts/gpu-merge-review'
while not (p/'cpu-pairs/summary.json').exists():time.sleep(5)
summary=json.loads((p/'cpu-pairs/summary.json').read_text());manifest=json.loads((p/'frozen-cpu-manifest.json').read_text());assert summary['runs']==576 and summary['checksum_pairs_equal']==288
receipt={'source':manifest['references']['after']['source'],'base':manifest['references']['before']['source'],'CPU_only_measurements':summary,'unit_cases':164,'unit_assertions':706829,'engine_cases':30,'golden_matches':12,'continuations':12,'CPU_source_and_binary_isolation':'cpu-source-isolation.json and cpu-binary-isolation.json','GPU_offload_qualification':False,'review_findings_fixed':['CPU default/trace disabled profiling TLS and per-capture environment probes','Confirmed GPU mismatches could recover on evidence/status/callback failure'],'limits':['Native Linux x86_64 only','NVIDIA Vulkan execution required in tests','OpenCL physical execution and actual threaded browser WebGPU unverified','Physical device-loss and other OS/device combinations unqualified','Opaque driver allocations not an audited resident preparation memory gate']}
(p/'verification-summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
e=root/'artifacts/gpu-experiment-evidence';a=e/'reviewed-stack-verification.tar.gz'
with tarfile.open(a,'w:gz') as tar:
 for f in p.rglob('*'):
  if f.is_file() and 'frozen' not in f.relative_to(p).parts:tar.add(f,arcname=str(f.relative_to(p)))
 for name in ['master-release-build.log','review-release-build.log','review-dev-build.log']:
  f=root/'artifacts/gpu-validation-offload'/name;tar.add(f,arcname='initial-builds/'+name)
receipt['archive_sha256']=hashlib.sha256(a.read_bytes()).hexdigest();m=e/'reviewed-stack-verification.json';m.write_text(json.dumps(receipt,indent=2)+'\n')
env={**os.environ,'GIT_INDEX_FILE':str(e/'review-verification.index')};branch='refs/heads/codex/gpu-gradient-cost-evidence';parent=subprocess.check_output(['git','rev-parse',branch],text=True).strip();subprocess.run(['git','read-tree',parent],env=env,check=True)
for f in [a,m]:
 blob=subprocess.check_output(['git','hash-object','-w',str(f)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo',f'100644,{blob},{f.name}'],env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree,'-p',parent],input='Record final reviewed GPU stack CPU isolation and compatibility verification\n',text=True).strip();subprocess.run(['git','update-ref',branch,commit,parent],check=True);subprocess.run(['git','push','origin','codex/gpu-gradient-cost-evidence'],check=True)
link=f'https://github.com/Globulation2/glob2/blob/{commit}/{m.name}'
text=['Final reviewed stack verification at '+receipt['source']+' on base '+receipt['base']+'. Three-agent review fixed disabled CPU profiling overhead and fatal GPU proof-reporting gaps; refactored repeated GPU proof setup, cleaned comments and durable docs.','', 'CPU source audit: snapshot tree, preparation, seeding, scheduling, propagation and compatibility gates match master. Optimized ordinary/trace CPU executions have no new profile calls or profiling TLS. CPU CLI/drain skip new diagnostic work.','', '| CPU-only count | Total CPU savings | Paired 95% interval |','|---|---:|---:|']
for count,s in summary['by_count'].items():
 v=s['cpu_per_tick'];ci=v['paired_95_ci_pct'];text.append(f"| {count} | {v['savings_pct']:.3f}% | {ci[0]:.3f}–{ci[1]:.3f}% |")
text+=['','Eight alternating release pairs over nine frozen saves, counts 1/2/4/8, diagnostics/shadow disabled, same GCC13.3 and full -O3 -g flags/dependency prefixes. Total process CPU includes startup/exit; window CPU includes required job drain. Each process sampled for compiler interference before/during/after; interrupted comparison retried and clean earlier comparisons retained. All288 paired final checksums match.','', '164 focused unit cases /706,829 assertions with required NVIDIA Vulkan and API/sync validation;30 isolated engine cases;12 golden per-tick match traces;12 continuations with exact checksum and final-save bytes. Native Linux coverage only; actual browser/OpenCL/device-loss/other-platform qualification incomplete. No new backend/default/resident enablement. Prior GPU-offload CPU qualification failed and remains explicit.','', f'[Accessible raw logs, commands, snapshots, saves, checksums, profiles, manifests and measured results]({link}); sibling reviewed-stack-verification.tar.gz contains raw evidence.']
f=p/'pr-verification-comment.md';f.write_text('\n'.join(text)+'\n');subprocess.run(['gh','pr','comment','1172','--body-file',str(f)],check=True)
(p/'published-verification.json').write_text(json.dumps({'commit':commit,'receipt':link},indent=2)+'\n');print('published',link,flush=True)
