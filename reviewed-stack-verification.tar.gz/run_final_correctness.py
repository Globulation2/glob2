from pathlib import Path
import subprocess,time,json,os
root=Path.cwd();p=root/'artifacts/gpu-merge-review';log=p/'final-dev-build.log'
while True:
 s=log.read_text() if log.exists() else ''
 if 'scons: ***' in s:raise SystemExit('Development build failed')
 if 'scons: done building targets.' in s:break
 time.sleep(5)
env={**os.environ,'VK_DRIVER_FILES':'/usr/share/vulkan/icd.d/nvidia_icd.json','GLOB2_REQUIRE_VULKAN':'1','VK_INSTANCE_LAYERS':'VK_LAYER_KHRONOS_validation','VK_LAYER_ENABLES':'VK_VALIDATION_FEATURE_ENABLE_SYNCHRONIZATION_VALIDATION_EXT','GLOB2_BUILD_DIR':str(root/'build/gpu-offload-correctness'),'GLOB2_TEST_ARTIFACTS':str(p/'proofs')}
commands=[('unit',[str(root/'build/gpu-offload-correctness/test/glob2-unit-tests'),'-ts=RuntimeGradientBackend,GradientPreparationContract,OpenCLGradient,GradientPipeline,PathGradient,GlobalGradient,ComputeExecutor,FieldGradient']),('engine',['python3','test/run_tests.py','--binary','engine','--no-display','--filter','GradientBackendSwitch/*','--filter','GradientPreparation/*','--junit',str(p/'engine.xml')]),('matches',['python3',str(p/'run_matches.py')]),('continuations',['python3',str(p/'run_continuations.py')])]
receipt=[]
for name,command in commands:
 with (p/(name+'.log')).open('w') as out:r=subprocess.run(command,env=env,stdout=out,stderr=subprocess.STDOUT)
 receipt.append({'name':name,'command':command,'exit':r.returncode})
 if r.returncode:raise SystemExit(f'{name} failed')
 if name=='matches':
  rows=json.loads((p/'matches/runs.json').read_text());assert len(rows)==12 and all(r['exit']==0 and r['trace_matches_golden'] for r in rows);assert all(r.get('gpu_accepted',True) for r in rows)
 if name=='continuations':
  rows=json.loads((p/'continuations/runs.json').read_text());assert len(rows)==12 and all(r['exit']==0 and r['checksums_match'] and r['saves_match'] for r in rows)
 print(name,'passed',flush=True)
(p/'correctness-complete.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'commands':receipt,'matches':12,'continuations':12},indent=2)+'\n')
