from pathlib import Path
import time,json,hashlib,shutil,subprocess
root=Path.cwd();p=root/'artifacts/gpu-merge-review';logs=root/'artifacts/gpu-validation-offload'
for name in ['master-release-build.log','final-release-build.log']:
 folder=logs if name=='master-release-build.log' else p
 while True:
  s=(folder/name).read_text() if (folder/name).exists() else ''
  if 'scons: ***' in s:raise SystemExit('Build failed: '+name)
  if 'scons: done building targets.' in s:break
  time.sleep(5)
refs={'before':{'source':'85b02d2f1dbda56fc7b40d4b941140d762188a26','built_binary':'/home/bradley/.codex/worktrees/gpu-review-cpu-baseline/glob2/build/gpu-review-baseline/src/glob2'},'after':{'source':subprocess.check_output(['git','rev-parse','43549c185dcaceb13da25eb9a08d8e23f528f0a8'],text=True).strip(),'built_binary':str(root/'build/gpu-offload-release/src/glob2')}}
for revision,ref in refs.items():
 dest=p/'frozen'/revision/'glob2';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ref['built_binary'],dest);ref['binary']=str(dest);ref['sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
while not (p/'fixtures-complete.json').exists():time.sleep(5)
plan=json.loads((p/'cpu-protocol-plan.json').read_text());plan['references']=refs
for fixture in plan['fixtures']:fixture['path']=str(root/fixture['path'])
plan['compiler']=subprocess.check_output(['g++','--version'],text=True).splitlines()[0];plan['platform']=subprocess.check_output(['uname','-a'],text=True).strip();plan['dependency_prefixes']=['/home/bradley/glob2/build/sdl3/prefix','/home/bradley/.local/share/glob2/development/dependencies/build-6b62ea86279899032d0eabbb/prefix'];plan['host_diagnostics']='off';plan['shadow_verification']='off';plan['timing_unit']='total CPU across all game threads per tick, including startup/exit; benchmark CPU includes required drain'
while not (p/'correctness-complete.json').exists():time.sleep(5)
(p/'frozen-cpu-manifest.json').write_text(json.dumps(plan,indent=2)+'\n');print('frozen CPU binaries',flush=True)
