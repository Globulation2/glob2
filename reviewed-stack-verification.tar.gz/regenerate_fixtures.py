from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();p=root/'artifacts/gpu-merge-review';binary='/home/bradley/.codex/worktrees/gpu-review-cpu-baseline/glob2/build/gpu-review-baseline/src/glob2';rows=[];fixtures=[]
for size in [128,256,512]:
 dest=p/'fixtures'/f'river{size}-game';dest.parent.mkdir(parents=True,exist_ok=True);mapfile=root/'artifacts/gpu-cost/fixtures'/f'river{size}.map.gz'
 cmd=[binary,'game','run','--map-file',str(mapfile),'--player','castor','--player','castor','--game-seed','98731','--win-condition','opponents','--ticks','16384','--compute-threads','8','--gradient-backend','cpu','--gradient-algorithm','buckets','--gradient-verify','off','--save','initial','--save','every:4096','--save','final','--output-dir',str(dest)]
 with dest.with_suffix('.log').open('w') as log:r=subprocess.run(cmd,env={**os.environ,'GLOB2_GRADIENT_DIAGNOSTICS':'0'},stdout=log,stderr=subprocess.STDOUT)
 if r.returncode:raise SystemExit(f'fixture generation failed: {dest}')
 rows.append({'command':cmd,'source':'85b02d2f1dbda56fc7b40d4b941140d762188a26','map_sha256':hashlib.sha256(mapfile.read_bytes()).hexdigest(),'game_seed':98731,'exit':r.returncode})
 for label,tick,filename in [('early',0,'initial.game.gz'),('middle',4096,'checkpoint-4096.game.gz'),('late',16384,'checkpoint-16384.game.gz')]:
  f=dest/filename;fixtures.append({'name':f'river-{size}-{label}','size':size,'tick':tick,'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'window_ticks':4096,'warmup_ticks':512,'weight':1/9,'workload':'Castor changing-world candidate; current save format159, same map inputs and seeds'})
 print('generated',size,flush=True)
(p/'fixture-generation.json').write_text(json.dumps(rows,indent=2)+'\n');plan=json.loads((p/'cpu-protocol-plan.json').read_text());plan['fixtures']=fixtures;plan['fixture_refresh_reason']='Master85 intentionally raises saved-game floor to159; legacy frozen saves cannot load in unmodified master or candidate';(p/'cpu-protocol-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(p/'fixtures-complete.json').write_text(json.dumps({'fixtures':fixtures},indent=2)+'\n')
