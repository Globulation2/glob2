from pathlib import Path
import subprocess,json,time,hashlib,os,platform
root=Path('/home/bradley/glob2-hiring-profile-20261013'); data=root/'artifacts/hiring-profile'; out=data/'version-key-benchmark';out.mkdir(exist_ok=False)
while not (data/'version-key-timing/finished.json').exists():time.sleep(1)
assert json.loads((data/'version-key-timing/finished.json').read_text())['status']=='complete'
binaries={a:data/b for a,b in [('regions','glob2-regions-control'),('versions','glob2-version-keys')]}
meta={'sources':{'regions':'b27cf7553b115b5d54de9e6b6ddfd25eefb2fa3f','versions':'fb2b6174c72213016af7f4e9f4b03a638f62a7bd'},'binary_sha256':{a:hashlib.sha256(b.read_bytes()).hexdigest() for a,b in binaries.items()},'host':platform.platform(),'protocol':{'participants':4,'repetitions':10,'rotated_order':True,'windows':{'initial':4096,'colony':[4096,6144]},'exports':'none; result.json only','warmup':'one untimed process per arm/window','benchmark_warmup':0,'comparison':'same cached policy, custom fingerprints versus existing version keys'}}
(out/'metadata.json').write_text(json.dumps(meta,indent=2))
def cmd(arm,window,dest):
 c=[str(binaries[arm]),'game','run','--ticks',str(4096 if window=='initial' else 6144),'--benchmark-warmup','0','--compute-threads','4','--gpu','off','--output-dir',str(dest)]
 if window=='colony':c+=['--load-game',str(data/'common-checkpoint/final.game.gz')]
 else:c+=['--map-file',str(data/'river-713.map.gz'),'--game-seed','100713']+['--player','nicowar']*8
 return c
def activity():return subprocess.check_output(['ps','-eo','pid,pcpu,comm','--sort=-pcpu'],text=True)
try:
 with (out/'samples.jsonl').open('w') as stream:
  for rep in range(-1,10):
   for wi,window in enumerate(['initial','colony'] if rep%2==0 else ['colony','initial']):
    for arm in (['regions','versions'] if (rep+wi)%2==0 else ['versions','regions']):
     dest=out/f'{window}-{arm}-{rep}';c=cmd(arm,window,dest);before=activity();started=time.time()
     (out/'progress.json').write_text(json.dumps({'repetition':rep,'window':window,'arm':arm,'started':started}))
     with dest.with_suffix('.log').open('w') as log:p=subprocess.run(c,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=900)
     row={'repetition':rep,'window':window,'arm':arm,'command':c,'returncode':p.returncode,'elapsed_s':time.time()-started,'host_before':before,'host_after':activity(),'load_after':os.getloadavg(),'result':json.loads((dest/'result.json').read_text()) if (dest/'result.json').exists() else None}
     stream.write(json.dumps(row)+'\n');stream.flush()
     if p.returncode:raise RuntimeError('Failed timing attempt retained')
 (out/'finished.json').write_text(json.dumps({'finished':time.time(),'status':'complete'}))
except BaseException as e:
 (out/'finished.json').write_text(json.dumps({'finished':time.time(),'status':'failed','error':str(e)}));raise
