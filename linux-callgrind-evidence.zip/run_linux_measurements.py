#!/usr/bin/env python3
import subprocess, pathlib, json, time, os, hashlib
root=pathlib.Path('/dev/shm/glob2-recruitment-profile')
os.chdir(root)
out=root/'artifacts/recruitment-measurements';out.mkdir(parents=True,exist_ok=True)
try:
 (out/'.started').open('x').close()
except FileExistsError:
 print('Measurement sequence already started; exiting duplicate launcher.',flush=True)
 raise SystemExit(0)
env=os.environ.copy();env.update(GLOB2_SDL3_PREFIX='/home/bradley/glob2/build/sdl3/prefix',PYTHONPATH=str(root))
binary=root/'build/recruitment-profile/src/glob2'
def run(args,name,extra=None):
 print(time.strftime('%H:%M:%S'),name,flush=True)
 e=env.copy();e.update(extra or {})
 with (out/(name+'.log')).open('w') as f:
  r=subprocess.run([str(x) for x in args],env=e,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError((name,r.returncode))
def measure(label):
 dest=out/label;dest.mkdir(exist_ok=True)
 common=['game','run','--load-game',root/'midgame24k.game.gz','--compute-threads','8','--gpu','off','--ticks','25153','--telemetry','checksums','--save','final']
 run([binary,*common,'--output-dir',dest/'native'],label+'-native',{'GLOB2_CHECKSUM_SIDECAR':'1'})
 run(['valgrind','--tool=callgrind','--instr-atstart=no','--separate-threads=yes','--callgrind-out-file='+str(dest/'callgrind.%p'),binary,*common,'--output-dir',dest/'profile'],label+'-callgrind')
 (dest/'identity.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'begin_tick':24128,'end_tick':25152,'ticks':1024,'command':[str(x) for x in common]},indent=2))
measure('optimized')
run(['python3','test/run_tests.py','--build-dir','build/recruitment-profile','--binary','engine','--filter','BuildingMaterialDemand/*','--filter','Hiring*/*','--filter','FetchHiringScore/*','--filter','UnitContinuation/*','--filter','InnSwap/*','--no-display','-j2','--artifacts',out/'tests'],'linux-tests')
run(['git','checkout','--detach','64c792a61c4b5a7cdbfc49f33e7c846127645056'],'checkout-base')
run(['scons','release=1','retain_symbols=1','CXXFLAGS=-g1','--build=build/recruitment-profile','-j3','build/recruitment-profile/src/glob2'],'base-build')
measure('base')
comparison={}
for name in ['world.checksums','snapshot.checksums']:
 a=(out/'base/native'/name).read_bytes();b=(out/'optimized/native'/name).read_bytes()
 comparison[name]={'identical':a==b,'sha256':hashlib.sha256(a).hexdigest()}
import gzip
comparison['final_save']={'identical':gzip.decompress((out/'base/native/final.game.gz').read_bytes())==gzip.decompress((out/'optimized/native/final.game.gz').read_bytes())}
(out/'behavior-comparison.json').write_text(json.dumps(comparison,indent=2))
assert all(v['identical'] for v in comparison.values()),comparison
for label in ['base','optimized']:
 profiles=list((out/label).glob('callgrind.*-01'))
 assert len(profiles)==1,profiles
 run(['python3',root/'parse_callgrind.py',profiles[0],out/(label+'-owner.json')],label+'-parse')
print('MEASUREMENTS COMPLETE',flush=True)
