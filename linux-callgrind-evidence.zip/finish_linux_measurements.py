from pathlib import Path
import os,subprocess,time,json,hashlib,gzip
root=Path('/dev/shm/glob2-recruitment-profile');os.chdir(root)
out=root/'artifacts/recruitment-measurements'
log=out/'base-build.log'
while True:
 s=log.read_text() if log.exists() else ''
 if 'scons: done building targets.' in s:break
 if 'scons: building terminated' in s:raise RuntimeError('base build failed')
 time.sleep(5)
binary=root/'build/recruitment-profile/src/glob2'
def run(args,name):
 print(time.strftime('%H:%M:%S'),name,flush=True)
 with (out/(name+'.log')).open('w') as f:
  subprocess.run([str(x) for x in args],stdout=f,stderr=subprocess.STDOUT,check=True)
common=['game','run','--load-game',root/'midgame24k.game.gz','--compute-threads','8','--gpu','off','--ticks','25153','--save','final']
run([binary,*common,'--telemetry','checksums','--output-dir',out/'base/native'],'base-native')
dest=out/'base-clean';dest.mkdir(exist_ok=True)
run(['valgrind','--tool=callgrind','--instr-atstart=no','--separate-threads=yes','--callgrind-out-file='+str(dest/'callgrind.%p'),binary,*common,'--output-dir',dest/'game'],'base-clean-callgrind')
comparison={}
for name in ['world.checksums','snapshot.checksums']:
 a=(out/'base/native'/name).read_bytes();b=(out/'optimized/native'/name).read_bytes()
 comparison[name]={'identical':a==b,'sha256':hashlib.sha256(a).hexdigest()}
comparison['final_save']={'identical':gzip.decompress((out/'base/native/final.game.gz').read_bytes())==gzip.decompress((out/'optimized/native/final.game.gz').read_bytes())}
(out/'behavior-comparison.json').write_text(json.dumps(comparison,indent=2))
assert all(v['identical'] for v in comparison.values()),comparison
for label in ['base','optimized']:
 p=out/(label+'-clean')
 profiles=list(p.glob('callgrind.*-01'));assert len(profiles)==1,profiles
 run(['python3',root/'parse_callgrind.py',profiles[0],out/(label+'-clean-owner.json')],label+'-clean-parse')
 d=json.loads((out/(label+'-clean-owner.json')).read_text())
 totals=[int(x.split()[1]) for x in profiles[0].read_text().splitlines() if x.startswith('totals:')]
 assert totals==[d['self_total']],(totals,d['self_total'])
a=json.loads((out/'base-clean-owner.json').read_text());b=json.loads((out/'optimized-clean-owner.json').read_text())
summary={'base_commit':'64c792a61c4b5a7cdbfc49f33e7c846127645056','optimized_commit':'0e36aee51be98cc297d3f6a72fe6438209d0eb9a','begin_tick':24128,'end_tick':25152,'ticks':1024,'base_ir':a['self_total'],'optimized_ir':b['self_total'],'reduction_percent':100*(1-b['self_total']/a['self_total']),'behavior':comparison,'base_binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'optimized_binary_sha256':hashlib.sha256((out/'glob2-optimized').read_bytes()).hexdigest()}
summary['function_comparison']=[]
af={x['function']:x['ir'] for x in a['functions']};bf={x['function']:x['ir'] for x in b['functions']}
for name in sorted(set(af)|set(bf),key=lambda k:af.get(k,0)-bf.get(k,0),reverse=True):
 summary['function_comparison'].append({'function':name,'base_ir':af.get(name,0),'optimized_ir':bf.get(name,0),'saved_ir':af.get(name,0)-bf.get(name,0)})
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print('MEASUREMENTS COMPLETE',json.dumps({k:v for k,v in summary.items() if k!='function_comparison'}),flush=True)
