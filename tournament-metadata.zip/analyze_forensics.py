import pathlib,json,collections,csv,hashlib,gzip
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=pathlib.Path(__file__).resolve().parent;old=root.parent/'movement-agreement';out=root/'analysis';out.mkdir(exist_ok=True)
rows=[];checks=[];reference_hash={}
def digest(p):
 with (gzip.open(p,'rb') if p.suffix=='.gz' else p.open('rb')) as f:return hashlib.file_digest(f,'sha256').hexdigest()
for game in json.loads((old/'protocol.json').read_text())['games']:
 for f in ['world.checksums','game.replay','game.replay.checksums','final.game.gz']:reference_hash[game['name'],f]=digest(old/game['name']/'reference'/f)
 for delay in range(9):
  for early in ([False,True] if delay==1 else [False]):
   name=game['name']+f'-k{delay}'+('-early' if early else '')
   p=root/'forensics'/name/'result.json'
   if not p.exists():continue
   r=json.loads(p.read_text());m=r['movement_shadow'];pair={'game':game['name'],'delay':delay,'early':early,'ticks':r['ticks'],'matches':{}}
   for f in ['world.checksums','game.replay','game.replay.checksums','final.game.gz']:pair['matches'][f]=digest(p.parent/f)==reference_hash[game['name'],f]
   checks.append(pair)
   for team in range(2):
    for mode in ['idle','explore','resource','building','clearing','pursuit']:
     prefix=f'team_{team}_{mode}_';rows.append({'game':game['name'],'delay':delay,'early':early,'team':team,'mode':mode,**{k[len(prefix):]:v for k,v in m.items() if k.startswith(prefix)}})
(out/'canonical-comparisons.json').write_text(json.dumps(checks,indent=2));(out/'forensics.json').write_text(json.dumps(rows,indent=2))
keys=sorted(set().union(*(r.keys() for r in rows)))
with (out/'forensics.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def aggregate(delay=1,early=False,mode=None):
 c=collections.Counter()
 for r in rows:
  if r['delay']==delay and r['early']==early and (mode is None or r['mode']==mode):c.update({k:v for k,v in r.items() if isinstance(v,int) and k not in ['team','delay','early']})
 return c
def pct(c,a,b):return 100*c[a]/c[b] if c[b] else np.nan
summary=[{'delay':d,**dict(aggregate(d))} for d in range(9)];(out/'summary.json').write_text(json.dumps(summary,indent=2))
original=json.loads((old/'observations.json').read_text())
def original_aggregate(delay,mode=None):
 c=collections.Counter()
 for r in original:
  if r['delay']==delay and (mode is None or r['mode']==mode):c.update({k:v for k,v in r.items() if isinstance(v,int) and k not in ['team','delay']})
 return c
fig,axes=plt.subplots(1,3,figsize=(14,4.5))
for ax,a,b,title in [(axes[0],'agreement_direction_equal','agreement_compared','Exact direction/stay agreement'),(axes[1],'agreement_compared','agreement_opportunities','Usable comparison coverage'),(axes[2],'agreement_observation_age_ticks','agreement_compared','Mean input age (ticks)')]:
 for label,fn in [('Original prototype',original_aggregate),('Revised + completion refresh',aggregate)]:
  ax.plot(range(9),[(pct(fn(d),a,b) if ax!=axes[2] else fn(d)[a]/fn(d)[b]) for d in range(9)],'o-',label=label)
 ax.set(title=title,xlabel='Configured delay (ticks)',xticks=range(9));ax.grid(alpha=.2);ax.legend(fontsize=8)
fig.suptitle('Same six reference games: policy fixes and bounded refresh\nCoverage and input age must accompany agreement; gameplay remains unchanged');fig.tight_layout();fig.savefig(out/'revised-delay.png',dpi=170);plt.close(fig)
modes=['idle','explore','resource','building','pursuit'];x=np.arange(len(modes));fig,axes=plt.subplots(1,2,figsize=(12,4.5))
for ax,a,b,title in [(axes[0],'agreement_direction_equal','agreement_compared','Conditional exact agreement at K=1'),(axes[1],'agreement_compared','agreement_opportunities','Usable coverage at K=1')]:
 for i,(name,fn) in enumerate([('Original',lambda m:original_aggregate(1,m)),('Policy fixes; old admission',lambda m:aggregate(1,True,m)),('Policy fixes + refresh',lambda m:aggregate(1,False,m))]):ax.bar(x+(i-1)*.25,[pct(fn(m),a,b) for m in modes],width=.25,label=name)
 ax.set(xticks=x,xticklabels=modes,ylim=(0,100),title=title,ylabel='Percent');ax.legend(fontsize=8);ax.grid(axis='y',alpha=.2)
fig.tight_layout();fig.savefig(out/'revised-modes.png',dpi=170);plt.close(fig)
causes=['equal_route_cost','worse_route_cost','better_route_cost','unknown_route_cost','wander','exploration','geometric','move_stay'];c=aggregate();fig,ax=plt.subplots(figsize=(10,5));ax.barh(causes[::-1],[c['disagreement_'+k] for k in causes[::-1]]);ax.set(xlabel='Disagreement count',title='Remaining K=1 differences, classified on the proposal’s own field\nDifferent goal models and stale fields prevent interpreting cost alone as path quality');fig.tight_layout();fig.savefig(out/'disagreement-causes.png',dpi=170);plt.close(fig)
print('canonical',sum(all(c['matches'].values()) for c in checks),'/',len(checks))
for mode in modes:
 c=aggregate(mode=mode);e=aggregate(early=True,mode=mode);p=original_aggregate(1,mode)
 print(mode,'original',round(pct(p,'agreement_direction_equal','agreement_compared'),2),'fixed early',round(pct(e,'agreement_direction_equal','agreement_compared'),2),'late',round(pct(c,'agreement_direction_equal','agreement_compared'),2),'coverage',round(pct(c,'agreement_compared','agreement_opportunities'),2),'random',c['random_wander_compared'],c['random_wander_agree'],'patrol',c['guard_patrol_compared'],c['guard_patrol_agree'],'fresh_worse',c['fresh_probe_worse_cost'])
print('overall',dict(c:=aggregate()))
