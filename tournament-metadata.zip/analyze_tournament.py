from pathlib import Path
import json,sys,csv,collections
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root.parent.parent/'tools'))
from tournaments.game_telemetry import parse
out=root/'tournament-analysis';out.mkdir(exist_ok=True)
protocol=json.loads((root/'tournament/protocol.json').read_text());H=protocol['analysis_horizon'];rows=[];teamrows=[]
for job in protocol['jobs']:
 folder=root/'tournament'/job['id']
 if not (folder/'complete.json').exists():continue
 complete=json.loads((folder/'complete.json').read_text())
 if complete['status']!='completed':continue
 result=json.loads((folder/'result.json').read_text());chosen={};econ={};move={};research={}
 with (folder/'run.log').open() as log:
  for line in log:
   if line.startswith(('GLOB2_MEASURE ','GLOB2_ECON ')):
    prefix,r=parse(line)
    if r['tick']<=H:
     dest=chosen if prefix=='GLOB2_MEASURE' else econ
     if r['team'] not in dest or dest[r['team']]['tick']<=r['tick']:dest[r['team']]=r
   elif line.startswith('GLOB2_MOVEMENT_OBSERVATION '):
    r={k:int(v) for k,v in (s.split('=',1) for s in line.split()[1:])};move[r['team'],r['type']]=r
   elif line.startswith('GLOB2_MOVEMENT_RESEARCH '):research={k:int(v) for k,v in (s.split('=',1) for s in line.split()[1:])}
 if len(chosen)!=2 or len(econ)!=2:raise ValueError('missing horizon telemetry '+job['id'])
 combined=collections.Counter()
 for team,r in chosen.items():
  for k,v in r.items():
   if isinstance(v,int) and k not in ['team','tick','final']:combined[k]+=v
  teamrows.append({'job':job['id'],'arm':job['arm'],'team':team,'ai':job['players'][team],**r})
 worker_ticks=sum(v for k,v in combined.items() if k.startswith(('labour_', 'filling_')) and k!='labour_coverage_start')
 walking=sum(v for k,v in combined.items() if k.startswith('filling_') and k.rsplit('_',1)[-1] in ['0','2'])
 worker_moves=sum(r['moves'] for (team,kind),r in move.items() if kind==0)
 damage=sum(v for k,v in combined.items() if k.startswith('damageDealt_') and k.endswith('_0'))
 exposure=min(result['ticks'],H)
 def rate(a,b):return a/b if b else np.nan
 food=combined['delivered_1'] # MaterialId::Food, checked against Material.h.
 row={**job,'ticks':result['ticks'],'termination':result['termination'],'horizon_exposure':exposure,'unresolved':result['unresolved'],'worker_ticks':worker_ticks,'food_delivery':food,'worker_moves':worker_moves,'adopted':research.get('adopted',0),'eligible':research.get('eligible',0),
 'food_delivered_per_1000_worker_ticks':1000*rate(food,worker_ticks),
 'transport_walk_fraction':rate(walking,worker_ticks),
 'meal_walk_fraction':rate(combined['labour_1'],worker_ticks),
 'idle_worker_fraction':rate(combined['labour_0'],worker_ticks),
 'worker_starvation_per_1000_worker_ticks':1000*rate(combined['deaths_0_1'],worker_ticks),
 'unit_damage_per_1000_ticks':1000*rate(damage,exposure),
 'worker_moves_per_food_delivery':rate(worker_moves,food),
 'population_at_horizon':sum(r['workers']+r['warriors']+r['explorers'] for r in econ.values())}
 rows.append(row)
(out/'game-observations.json').write_text(json.dumps(rows,indent=2,allow_nan=True));(out/'team-telemetry.json').write_text(json.dumps(teamrows,indent=2))
if len(rows)!=len(protocol['jobs']):print('INCOMPLETE',len(rows),'of',len(protocol['jobs']));sys.exit(0)
keys=sorted(set().union(*(r.keys() for r in rows)))
with (out/'game-observations.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
endpoints=protocol['primary_endpoints'];families=protocol['families'];rng=np.random.default_rng(20261013);B=20000;results=[]
# Resample entire map clusters, independently in each arm within generator strata.
# This is conservative for the shared map inventory; gameplay seeds are unpaired.
# Permutation exchanges whole map clusters within generator, not teams/actions.
for metric in endpoints:
 by={};finitecounts={}
 for family in families:
  for arm in ['before','after']:
   groups=collections.defaultdict(list)
   for r in rows:
    if r['family']==family and r['arm']==arm and (metric=='worker_moves_per_food_delivery' or np.isfinite(r[metric])):
     groups[r['map_seed']].append([r['worker_moves'],r['food_delivery']] if metric=='worker_moves_per_food_delivery' else [r[metric],1])
   by[family,arm]=[np.asarray(v) for _,v in sorted(groups.items())]
 for arm in ['before','after']:finitecounts[arm]=int(sum((metric=='worker_moves_per_food_delivery' or np.isfinite(r[metric])) for r in rows if r['arm']==arm))
 def value(values):
  a=np.asarray(values);return np.sum(a[:,0])/np.sum(a[:,1])
 arm_mean={a:value([v for family in families for cluster in by[family,a] for v in cluster]) for a in ['before','after']}
 observed=arm_mean['after']-arm_mean['before'];boot=np.empty(B);permutation=np.empty(B)
 for b in range(B):
  samples={a:[] for a in ['before','after']};perms={a:[] for a in ['before','after']}
  for family in families:
   for a in ['before','after']:
    clusters=by[family,a]
    for i in rng.integers(len(clusters),size=len(clusters)):samples[a].extend(clusters[i])
   clusters=by[family,'before']+by[family,'after'];order=rng.permutation(len(clusters));cut=len(by[family,'before'])
   for i in order[:cut]:perms['before'].extend(clusters[i])
   for i in order[cut:]:perms['after'].extend(clusters[i])
  boot[b]=value(samples['after'])-value(samples['before']);permutation[b]=value(perms['after'])-value(perms['before'])
 p=(1+np.sum(np.abs(permutation)>=abs(observed)))/(B+1)
 lo,hi=np.quantile(boot,[.025,.975]);results.append({'metric':metric,'before':arm_mean['before'],'after':arm_mean['after'],'difference':observed,'ci95':[float(lo),float(hi)],'p_raw':float(p),'counts':finitecounts,'relative_percent':100*observed/arm_mean['before'] if arm_mean['before'] else None})
ordered=sorted(range(len(results)),key=lambda i:results[i]['p_raw']);running=0
for rank,i in enumerate(ordered):running=max(running,min(1,(len(results)-rank)*results[i]['p_raw']));results[i]['p_holm']=float(running);results[i]['significant_holm_05']=bool(running<.05)
(out/'statistics.json').write_text(json.dumps({'bootstrap_draws':B,'seed':20261013,'method':protocol['analysis'],'results':results},indent=2))
fig,axes=plt.subplots(2,4,figsize=(15,8))
for ax,r in zip(axes.flat,results):
 ax.errorbar([0],[r['difference']],yerr=[[r['difference']-r['ci95'][0]],[r['ci95'][1]-r['difference']]],fmt='o',color='#c62828' if r['significant_holm_05'] else '#1565c0',capsize=5)
 ax.axhline(0,color='#999',lw=1);ax.set(xticks=[],title=r['metric'].replace('_',' '));ax.set_ylabel('After − before');ax.text(.03,.03,f"Holm p={r['p_holm']:.4g}",transform=ax.transAxes);ax.grid(axis='y',alpha=.2)
fig.suptitle('120 independent-seed games per arm; 40 maps, three AI matchups\nMap-cluster bootstrap 95% intervals. Red: Holm-adjusted p < 0.05. Conditional-step research build.',fontsize=12);fig.tight_layout();fig.savefig(out/'tournament-effects.png',dpi=170);plt.close(fig)
print('COMPLETE',len(rows),'games');print(json.dumps(results,indent=2))
