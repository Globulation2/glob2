import pathlib,subprocess,os,json,hashlib,random,concurrent.futures,threading,time,gzip,sys
root=pathlib.Path(__file__).resolve().parent;outroot=root/'tournament';outroot.mkdir(exist_ok=True)
binary=root/'glob2-research';rng=random.Random(20261013)
families=['symmetric-arena','river','isles','swamp','fingerprint','maze','stone-highlands','canals']
matchups=[['cortex','warrush'],['cortex','nicowar'],['nicowar','warrush']]
jobs=[]
for fi,family in enumerate(families):
 for mi in range(5):
  map_seed=55001+fi*1000+mi
  for matchup,players in enumerate(matchups):
   players=players[::-1] if (mi+matchup)%2 else players
   for arm in ['before','after']:
    jobs.append({'id':f'{family}-{mi}-{matchup}-{arm}','family':family,'map_seed':map_seed,'map_index':mi,'matchup':matchup,'players':players,'arm':arm,'game_seed':rng.randrange(1,2**31)})
rng.shuffle(jobs)
protocol={'kind':'unmatched aggregate conditional-step research tournament','games_per_arm':120,'maps':40,'families':families,'matchups':matchups,'independent_gameplay_seeds':True,'seed':20261013,'ticks':30000,'analysis_horizon':12288,'compute_threads':2,'slots':6,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'scope':'Both arms use the separately patched research binary. Before retains reference movement with shadow only; after replaces usable final travel steps after unchanged serial preparation. Original movement is fallback for missing/rejected suggestions. No live match rule, save/replay export or production adoption.','primary_endpoints':['food_delivered_per_1000_worker_ticks','transport_walk_fraction','meal_walk_fraction','idle_worker_fraction','worker_starvation_per_1000_worker_ticks','unit_damage_per_1000_ticks','worker_moves_per_food_delivery','population_at_horizon'],'analysis':'Descriptive arm means, unpaired stratified permutation tests, map-cluster bootstrap confidence intervals, Holm correction for eight primary endpoints; AI/map strata preserved. Both teams form one game observation. No action/team pseudoreplication. Ended games carry their last state as absorbing at horizon; exposure records explicit. Secondary outcomes exploratory.','jobs':jobs}
(outroot/'protocol.json').write_text(json.dumps(protocol,indent=2))
lock=threading.Lock();completed=0
slots=list(range(6));available=threading.Condition()
def acquire():
 with available:
  while not slots:available.wait()
  return slots.pop()
def release(s):
 with available:slots.append(s);available.notify()
def run(job):
 global completed
 out=outroot/job['id'];out.mkdir(exist_ok=True)
 if (out/'complete.json').exists():return json.loads((out/'complete.json').read_text())
 slot=acquire();cpus=[4+slot*2,5+slot*2]
 env={k:v for k,v in os.environ.items() if not k.startswith('GLOB2_')}
 env['GLOB2_USER_DATA_DIR']=str(out/'user-data');env['GLOB2_PERF_DISABLE']='1'
 if job['arm']=='after':env['GLOB2_MOVEMENT_RESEARCH_STEP']='1'
 args=[str(binary),'game','run','--generator',job['family'],'--map-seed',str(job['map_seed']),'--game-seed',str(job['game_seed']),'--set','width=7','--set','height=7','--set','teams=2','--set','workers=8',*[a for p in job['players'] for a in ['--player',p]],'--ticks','30000','--movement-agreement-delay','1','--telemetry','team-timeline','--output-dir',str(out),'--compute-threads','2','--gradient-backend','scalar']
 command=['taskset','-c',','.join(map(str,cpus)),*args]
 (out/'command.json').write_text(json.dumps({'argv':command,'environment':{k:v for k,v in env.items() if k.startswith('GLOB2_')},'job':job},indent=2))
 start=time.monotonic()
 try:
  with (out/'run.log').open('w') as f:p=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
  record={'job':job,'exit_code':p.returncode,'elapsed_s':time.monotonic()-start,'cpus':cpus}
  if p.returncode==0 and (out/'result.json').exists():record['status']='completed'
  else:record['status']='failed'
  (out/'complete.json').write_text(json.dumps(record,indent=2))
  with lock:
   completed+=1
   with (outroot/'progress.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
   print(completed,'/',len(jobs),job['id'],record['status'],round(record['elapsed_s'],1),flush=True)
  return record
 except subprocess.TimeoutExpired:
  record={'job':job,'status':'timeout','elapsed_s':time.monotonic()-start};(out/'complete.json').write_text(json.dumps(record,indent=2));return record
 finally:release(slot)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:results=list(pool.map(run,jobs))
(outroot/'completion.json').write_text(json.dumps(results,indent=2))
print('TOTAL',len(results),{k:sum(r['status']==k for r in results) for k in ['completed','failed','timeout']},flush=True)
