from pathlib import Path
import shlex,subprocess,json,hashlib
root=Path(__file__).resolve().parent
source=Path('src/unit/UnitGeometry.cpp').read_text()
source=source.replace('#include "Utilities.h"','#include "Utilities.h"\n#include "GlobalContainer.h"\n#include <cstdlib>\n#include <cstdio>')
observer=r"""
namespace {
struct MovementObservationTotals {
    struct Row { Uint64 actions=0,moves=0,cost=0; };
    Row total[32][4]{},horizon[32][4]{};Uint32 lastTick=0;bool frozen=false;
    ~MovementObservationTotals(){for(int team=0;team<32;++team)for(int type=0;type<4;++type)if(total[team][type].actions){
        const auto h=frozen?horizon[team][type]:total[team][type];const auto a=total[team][type];
        std::printf("GLOB2_MOVEMENT_OBSERVATION team=%d type=%d horizon=12288 source_tick=%u actions=%llu moves=%llu cost=%llu final_actions=%llu final_moves=%llu final_cost=%llu\n",team,type,frozen?12288:lastTick+1,(unsigned long long)h.actions,(unsigned long long)h.moves,(unsigned long long)h.cost,(unsigned long long)a.actions,(unsigned long long)a.moves,(unsigned long long)a.cost);
    }}
};
MovementObservationTotals& movementObservations(){static MovementObservationTotals value;return value;}
struct ObserveUnitAction {
    Unit& unit;int x,y;
    explicit ObserveUnitAction(Unit& u):unit(u),x(u.core.posX),y(u.core.posY){
        auto& s=movementObservations();const auto tick=u.owner->game->stepCounter;
        if(tick>=12288 && !s.frozen){for(int t=0;t<32;++t)for(int k=0;k<4;++k)s.horizon[t][k]=s.total[t][k];s.frozen=true;}
        s.lastTick=tick;
    }
    ~ObserveUnitAction(){
        if(unit.core.isDead)return;
        const auto movement=unit.core.movement;
        if(movement!=Unit::MOV_RANDOM_GROUND && movement!=Unit::MOV_RANDOM_FLY && movement!=Unit::MOV_GOING_TARGET && movement!=Unit::MOV_FLYING_TARGET && movement!=Unit::MOV_GOING_DX_DY)return;
        const int dx=std::abs(unit.core.posX-x),dy=std::abs(unit.core.posY-y);
        const bool changedX=dx!=0,changedY=dy!=0;
        if(std::min(dx,unit.owner->map->getW()-dx)>1 || std::min(dy,unit.owner->map->getH()-dy)>1)return;
        auto& r=movementObservations().total[unit.owner->teamNumber][std::min(3,int(unit.core.typeNum))];
        ++r.actions;r.moves+=changedX||changedY;r.cost+=changedX&&changedY?20:changedX||changedY?14:0;
    }
};
}
"""
source=source.replace('void Unit::endOfAction(void)\n{',observer+'\nvoid Unit::endOfAction(void)\n{\n    ObserveUnitAction observation(*this);')
needle='{ MovementPlanning::PhaseScope phase(MovementPlanning::Phase::Action); handleAction(); }'
replacement='''{
        MovementPlanning::PhaseScope phase(MovementPlanning::Phase::Action);
        // LOCAL RESEARCH PATCH ONLY. Not compiled into the PR/production binary.
        static const bool research=std::getenv("GLOB2_MOVEMENT_RESEARCH_STEP")!=nullptr;
        struct ResearchCounters {
            Uint64 eligible=0,adopted=0,stays=0;Uint64 byMode[6]{};
            ~ResearchCounters(){if(eligible)std::printf("GLOB2_MOVEMENT_RESEARCH eligible=%llu adopted=%llu stays=%llu idle=%llu explore=%llu resource=%llu building=%llu clearing=%llu pursuit=%llu\\n",
                (unsigned long long)eligible,(unsigned long long)adopted,(unsigned long long)stays,
                (unsigned long long)byMode[0],(unsigned long long)byMode[1],(unsigned long long)byMode[2],(unsigned long long)byMode[3],(unsigned long long)byMode[4],(unsigned long long)byMode[5]);}
        };
        static ResearchCounters researchCounts;
        const auto mode=MovementPlanning::modeOf(core);
        const bool travel=mode && (core.movement==MOV_RANDOM_GROUND || core.movement==MOV_RANDOM_FLY || core.movement==MOV_GOING_TARGET || core.movement==MOV_FLYING_TARGET || core.movement==MOV_GOING_DX_DY);
        const auto proposed=research && globalContainer->runNoX && travel ? diagnostic->preparedDirection(*this) : std::optional<Uint8>{};
        if(travel)++researchCounts.eligible;
        if(proposed) {
            ++researchCounts.adopted;++researchCounts.byMode[unsigned(*mode)];researchCounts.stays+=*proposed==8;
            // Keep authoritative service/target/claim transitions and movement
            // kind. Only replace the committed step; preserve terrain clocks,
            // occupancy order and the normal visibility update in syncStep.
            dxDyFromDirection(*proposed,&core.dx,&core.dy);
            owner->map->clearImmobileUnit(core.posX,core.posY);
            handleActionGoingDxDy();
            if((core.movement==MOV_RANDOM_GROUND || core.movement==MOV_RANDOM_FLY) && !core.dx && !core.dy)
                owner->map->clearImmobileUnit(core.posX,core.posY);
        } else handleAction();
    }'''
assert source.count(needle)==1
source=source.replace(needle,replacement)
(root/'UnitGeometryResearch.cpp').write_text(source)
compile_line=None;link_line=None
for logfile in [Path('artifacts/movement-agreement/sweep-release-build.log'),Path('artifacts/movement-deep/release-build.log'),Path('artifacts/movement-deep/release-build-final.log')]:
 for line in logfile.read_text().splitlines():
  if line.startswith('g++ -o ') and '-c ' in line and line.endswith(' src/unit/UnitGeometry.cpp'):compile_line=line
  if line.startswith('g++ -o build/movement-release/src/glob2 '):link_line=line
assert compile_line and link_line
cmd=shlex.split(compile_line);cmd[cmd.index('-o')+1]=str(root/'UnitGeometryResearch.o');cmd[-1]=str(root/'UnitGeometryResearch.cpp')
subprocess.run(cmd,check=True)
link=shlex.split(link_line);link[link.index('-o')+1]=str(root/'glob2-research')
link=[str(root/'UnitGeometryResearch.o') if x=='build/movement-release/src/unit/UnitGeometry.o' else x for x in link]
subprocess.run(link,check=True)
(root/'research-build.json').write_text(json.dumps({'compile':cmd,'link':link,'patch_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'binary_sha256':hashlib.sha256((root/'glob2-research').read_bytes()).hexdigest(),'warning':'Unversioned local headless research patch. No online use, no replay/save export, no production adoption. Conditional final-step replacement after reference serial preparation. Not a whole planned-movement implementation.'},indent=2))
