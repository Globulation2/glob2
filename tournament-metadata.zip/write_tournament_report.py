from pathlib import Path
import json,collections
root=Path(__file__).resolve().parent;s=json.loads((root/'tournament-analysis/statistics.json').read_text());rows=json.loads((root/'tournament-analysis/game-observations.json').read_text())
t='''# Aggregate gameplay tournament: conditional planned-step adoption

**Recommendation: fail; do not adopt this movement policy.** In this local research build, food delivery per worker time falls 30.36%, worker starvation per worker time rises 66.19%, and actual worker moves per food delivery rise 19.20%. These effects are significant after Holm correction across eight prespecified endpoints. Improved conditional direction agreement on unchanged histories is insufficient evidence of acceptable gameplay.

This is a separate headless, unversioned research executable, not production movement or a complete implementation of the planned subsystem. Both arms run the same frozen binary (`f476f788eabcc5996310bec54d342c40a437125ffb1559f77d090b6384f5a541`, policy source `9edaadfc459c9de84c14f5f02c93548a08c9af0a`). The before arm runs reference movement with shadow planning. The after arm conditionally replaces final travel steps after original medical/activity/displacement/movement preparation; invalid or missing suggestions use reference actions. Service, target acquisition, claims, harvesting, delivery, attack and entry/exit handlers remain serial. Replaced movement actions skip reference movement RNG draws. The trial therefore measures this conditional policy including RNG divergence, not a clean isolated change to route fields or a full live implementation. No production experiment is enabled and no trial saves/replays are exported.

## Complete cohort and method

**240/240 games completed successfully**, 120 independent gameplay seeds per arm, 40 maps across eight generator families, three balanced/rotated AI matchups per map: Cortex/Warrush, Cortex/Nicowar and Nicowar/Warrush. Both teams receive the same policy in a game; this is not an old-vs-new head-to-head win-rate comparison. The frozen protocol declared a 30,000 tick cap and a 12,288 tick analysis horizon before running. Initial states/maps, commands, binary hashes and logs are archived. Match seeds are independent between arms; the map/AI inventory and position rotation are balanced.

One game is one statistical observation, with both teams combined. Bootstrap resamples whole map clusters independently in each arm within generator strata (20,000 draws). Unpaired permutations exchange map clusters within generator strata (20,000 draws). This is an exchangeability-based comparison, not exact randomization inference on matched trajectories; independently bootstrapping the shared map inventory is conservative for common map effects. Random seed 20261013. Eight primary comparisons receive Holm correction. Intervals below are **marginal 95%**, not simultaneous familywise intervals; a marginal interval near zero need not agree with Holm-adjusted significance. Endpoint sample counts are 120 per arm. Nonsignificance does not establish equivalence.

## Results

| Prespecified endpoint | Before | After | Relative point change | After − before, marginal 95% CI | Holm p |
|---|---:|---:|---:|---|---:|
'''
for r in s['results']:
 lo,hi=r['ci95'];t+=f"| {r['metric'].replace('_',' ')} | {r['before']:.6g} | {r['after']:.6g} | {r['relative_percent']:+.2f}% | {r['difference']:+.6g} [{lo:+.6g}, {hi:+.6g}] | {r['p_holm']:.6g} |\n"
t+='''
![Gameplay effect intervals](tournament-effects.png)

Food and starvation are economy regressions. The move/delivery ratio is actual observed worker cell moves divided by food deliveries, pooled as a ratio of totals; it includes workers' other travel and is not a direct resource-route path-length measure. Reduced idle and meal-walk fractions are not automatically benefits when the population and food economy deteriorate. Lower unit damage coincides with fewer units and cannot establish better combat behavior. The transport-walk comparison is not significant after multiplicity correction.

Worker-time denominators combine the mutually exclusive recorded labour/filling categories. Food is `MaterialId::Food` (index 1, not wood index 0). Existing telemetry's geometric distance-to-building fields are not actual travel distances and were not used as such. A separate non-mutating observer counts wrapped cell moves at action completion. Zero-food games would remain in the ratio-of-total calculation; none occur at the horizon in this cohort. Games ending before the horizon retain their final state as absorbing; rates use explicit observed exposure. Early resolutions are retained, not discarded.

'''
for arm in ['before','after']:
 a=[r for r in rows if r['arm']==arm];t+=f"- **{arm}:** {dict(collections.Counter(r['termination'] for r in a))}; {sum(r['ticks']<12288 for r in a)} games ended before the analysis horizon; {sum(r['adopted'] for r in a):,} adopted / {sum(r['eligible'] for r in a):,} eligible final travel actions over entire games.\n"
t+='''
## Interpretation and limits

The results reject the assumption that remaining disagreements are harmless conflict resolution. They do not isolate the cause of the economy loss. Remaining known goal-model differences (building perimeter versus footprint, flag/clearing radius and combat approach semantics), waiting/suffix behavior under congestion and changed wandering/RNG trajectories need separate controlled ablations before another adoption trial. No claim that worse pathfinding alone caused these changes.

Six concurrent processes used disjoint CPU affinities (two executor participants each), not exclusive core reservation. Host builds overlapped part of execution; all games completed within the retained process deadline. Counts and logical outcomes are the subject of this study. Different histories/populations/termination and uncontrolled host activity make wall-time comparisons unsuitable for performance claims.

Linux x86-64 only. These AI/map populations do not cover all original workload classes or human play. Cross-platform adopted execution, save/resume, replay/network compatibility, footage review, independent path-quality oracles and allocator-inclusive memory/performance qualification are unverified. The conditional patch is not a shipping trial and retains synchronous fallback searches. None of the original Stage A/B/C gates or thresholds are relaxed or qualified. Production remains shadow-only and disabled by default; keep the PR draft.

[Protocol](tournament-protocol.json) · [Statistics](tournament-statistics.json) · [Game observations](tournament-game-observations.csv) · [Evidence metadata/scripts](tournament-metadata.zip)

Raw logs, results and generated maps are split by generator:
'''
for family in json.loads((root/'tournament/protocol.json').read_text())['families']:t+=f"- [{family}](tournament-{family}.zip)\n"
(root/'tournament-report.md').write_text(t)
p=root/'deep-report.md';old=p.read_text();old+='''
## Completed gameplay result

[The 240-game conditional-step tournament](tournament-report.md) finds significant economy regressions: food delivery/worker time −30.36%, starvation/worker time +66.19%, worker moves/food delivery +19.20%. **Do not adopt the current policy.** Lower disagreement is not a gameplay-equivalence result. Goal fidelity, congestion/waiting and wandering/RNG effects require further isolated investigation. [Charts and raw evidence](tournament-report.md).

Final integration source `fdca48059e632268f0b814abba25afc60e2370f0`, unchanged base after delivery fetch. 127 focused native cases pass, one explicitly skipped display case. Two/four-participant release controls match checksums, replay/checksum streams and decompressed saves with matched options. [Unit-view request frequency follow-up](unit-view-report.md) includes those logs and controls. Other supported platforms remain unavailable.
''';p.write_text(old)
