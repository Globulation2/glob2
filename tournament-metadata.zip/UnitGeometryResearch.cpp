// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#include "Unit.h"
#include "Game.h"
#include "unit/planning/MovementShadow.h"
#include "Team.h"
#include "Map.h"

#include "Building.h"

#include "Utilities.h"
#include "GlobalContainer.h"
#include <cstdlib>
#include <cstdio>

void Unit::setNewValidDirectionGround(void)
{
	assert(!performance(FLY));
	int i=0;
	bool swim=(performance(SWIM)>0);
	Uint32 me=owner->me;
	while ( i<8 && ((!performance(WALK) && !owner->map->terrainPropertiesAt(core.posX+core.dx,core.posY+core.dy).swimmable) || !owner->map->isFreeForGroundUnit(core.posX+core.dx, core.posY+core.dy, swim, me)))
	{
		core.direction=(core.direction+1)&UNIT_DIRECTION_MASK;
		dxDyFromDirection();
		i++;
	}
	if (i==UNIT_DIRECTION_COUNT)
	{
		core.direction=UNIT_DIRECTION_NONE;
		dxDyFromDirection();
	}
}

void Unit::setNewValidDirectionAir(void)
{
	assert(performance(FLY));
	int i=0;
	while ( i<8 && !owner->map->isFreeForAirUnit(core.posX+core.dx, core.posY+core.dy))
	{
		core.direction=(core.direction+1)&UNIT_DIRECTION_MASK;
		dxDyFromDirection();
		i++;
	}
	if (i==UNIT_DIRECTION_COUNT)
	{
		core.direction=UNIT_DIRECTION_NONE;
		core.dx=0;
		core.dy=0;
	}
}

void Unit::flyToTarget()
{
	assert(performance(FLY));
    if (owner->map->hasAirTerrainConstraints())
    {
        core.dx = core.dy = 0;
        owner->map->pathfindAirPointToPoint(core.posX,core.posY,core.targetX,core.targetY,&core.dx,&core.dy);
        directionFromDxDy();
        return;
    }
	int ldx=core.targetX-core.posX;
	int ldy=core.targetY-core.posY;
	simplifyDirection(ldx, ldy, &core.dx, &core.dy);
	directionFromDxDy();
	Map *map=owner->map;
	if (map->isFreeForAirUnit(core.posX+core.dx, core.posY+core.dy))
		return;
	int cDirection=core.direction;
	core.direction=(cDirection+1)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if (map->isFreeForAirUnit(core.posX+core.dx, core.posY+core.dy))
		return;
	core.direction=(cDirection+7)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if (map->isFreeForAirUnit(core.posX+core.dx, core.posY+core.dy))
		return;
	core.direction=(cDirection+2)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if (map->isFreeForAirUnit(core.posX+core.dx, core.posY+core.dy))
		return;
	core.direction=(cDirection+6)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if (map->isFreeForAirUnit(core.posX+core.dx, core.posY+core.dy))
		return;
	core.direction=(cDirection+3)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if (map->isFreeForAirUnit(core.posX+core.dx, core.posY+core.dy))
		return;
	core.direction=(cDirection+5)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if (map->isFreeForAirUnit(core.posX+core.dx, core.posY+core.dy))
		return;
	core.direction=(cDirection+4)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if (map->isFreeForAirUnit(core.posX+core.dx, core.posY+core.dy))
		return;
	core.dx=0;
	core.dy=0;
	core.direction=UNIT_DIRECTION_NONE;
	if (verbose)
		printf("guid=(%d) flyto failed pos=(%d, %d) \n", core.gid, core.posX, core.posY);
}


void Unit::escapeGroundTarget()
{
	int ldx=core.posX-core.targetX;
	int ldy=core.posY-core.targetY;
	simplifyDirection(ldx, ldy, &core.dx, &core.dy);
	directionFromDxDy();
	bool canSwim=performance(SWIM);
	Map *map=owner->map;
	if ((performance(WALK) || map->terrainPropertiesAt(core.posX+core.dx,core.posY+core.dy).swimmable) && map->isFreeForGroundUnitNoForbidden(core.posX+core.dx, core.posY+core.dy, canSwim))
		return;
	int cDirection=core.direction;
	core.direction=(cDirection+1)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if ((performance(WALK) || map->terrainPropertiesAt(core.posX+core.dx,core.posY+core.dy).swimmable) && map->isFreeForGroundUnitNoForbidden(core.posX+core.dx, core.posY+core.dy, canSwim))
		return;
	core.direction=(cDirection+7)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if ((performance(WALK) || map->terrainPropertiesAt(core.posX+core.dx,core.posY+core.dy).swimmable) && map->isFreeForGroundUnitNoForbidden(core.posX+core.dx, core.posY+core.dy, canSwim))
		return;
	core.direction=(cDirection+2)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if ((performance(WALK) || map->terrainPropertiesAt(core.posX+core.dx,core.posY+core.dy).swimmable) && map->isFreeForGroundUnitNoForbidden(core.posX+core.dx, core.posY+core.dy, canSwim))
		return;
	core.direction=(cDirection+6)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if ((performance(WALK) || map->terrainPropertiesAt(core.posX+core.dx,core.posY+core.dy).swimmable) && map->isFreeForGroundUnitNoForbidden(core.posX+core.dx, core.posY+core.dy, canSwim))
		return;
	core.direction=(cDirection+3)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if ((performance(WALK) || map->terrainPropertiesAt(core.posX+core.dx,core.posY+core.dy).swimmable) && map->isFreeForGroundUnitNoForbidden(core.posX+core.dx, core.posY+core.dy, canSwim))
		return;
	core.direction=(cDirection+5)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if ((performance(WALK) || map->terrainPropertiesAt(core.posX+core.dx,core.posY+core.dy).swimmable) && map->isFreeForGroundUnitNoForbidden(core.posX+core.dx, core.posY+core.dy, canSwim))
		return;
	core.direction=(cDirection+4)&UNIT_DIRECTION_MASK;
	dxDyFromDirection();
	if ((performance(WALK) || map->terrainPropertiesAt(core.posX+core.dx,core.posY+core.dy).swimmable) && map->isFreeForGroundUnitNoForbidden(core.posX+core.dx, core.posY+core.dy, canSwim))
		return;
	core.dx=0;
	core.dy=0;
	core.direction=UNIT_DIRECTION_NONE;
	if (verbose)
		printf("guid=(%d) escapeGroundTarget failed pos=(%d, %d) \n", core.gid, core.posX, core.posY);
}


namespace {
struct MovementObservationTotals {
    struct Row { Uint64 actions=0,moves=0,cost=0; };
    Row total[32][4]{},horizon[32][4]{};Uint32 lastTick=0;bool frozen=false;
    ~MovementObservationTotals(){for(int team=0;team<32;++team)for(int type=0;type<4;++type)if(total[team][type].actions){
        const auto h=frozen?horizon[team][type]:total[team][type];const auto a=total[team][type];
        std::printf("GLOB2_MOVEMENT_OBSERVATION team=%d type=%d horizon=12288 source_tick=%u actions=%llu moves=%llu cost=%llu final_actions=%llu final_moves=%llu final_cost=%llu\n",team,type,frozen?12288:lastTick+1,(unsigned long long)h.actions,(unsigned long long)h.moves,(unsigned long long)h.cost,(unsigned long long)a.actions,(unsigned long long)a.moves,(unsigned long long)a.cost);
    }}
};
MovementObservationTotals& movementObservations(){static MovementObservationTotals value;return value;}
struct ObserveUnitAction {
    Unit& unit;int x,y;
    explicit ObserveUnitAction(Unit& u):unit(u),x(u.core.posX),y(u.core.posY){
        auto& s=movementObservations();const auto tick=u.owner->game->stepCounter;
        if(tick>=12288 && !s.frozen){for(int t=0;t<32;++t)for(int k=0;k<4;++k)s.horizon[t][k]=s.total[t][k];s.frozen=true;}
        s.lastTick=tick;
    }
    ~ObserveUnitAction(){
        if(unit.core.isDead)return;
        const auto movement=unit.core.movement;
        if(movement!=Unit::MOV_RANDOM_GROUND && movement!=Unit::MOV_RANDOM_FLY && movement!=Unit::MOV_GOING_TARGET && movement!=Unit::MOV_FLYING_TARGET && movement!=Unit::MOV_GOING_DX_DY)return;
        const int dx=std::abs(unit.core.posX-x),dy=std::abs(unit.core.posY-y);
        const bool changedX=dx!=0,changedY=dy!=0;
        if(std::min(dx,unit.owner->map->getW()-dx)>1 || std::min(dy,unit.owner->map->getH()-dy)>1)return;
        auto& r=movementObservations().total[unit.owner->teamNumber][std::min(3,int(unit.core.typeNum))];
        ++r.actions;r.moves+=changedX||changedY;r.cost+=changedX&&changedY?20:changedX||changedY?14:0;
    }
};
}

void Unit::endOfAction(void)
{
    ObserveUnitAction observation(*this);
auto* diagnostic = owner->game->movementDiagnostics();
    if (!diagnostic) {
        handleMedical();
        if (core.isDead) return;
        handleActivity(); handleDisplacement(); handleMovement(); handleAction();
        return;
    }
    struct Completion { MovementPlanning::Shadow* diagnostic; Unit& unit;
        ~Completion() { if(diagnostic)diagnostic->completeAction(unit); } } completion{diagnostic,*this};
    MovementPlanning::DiagnosticBinding binding(diagnostic ? diagnostic->counters(*this) : nullptr);
    {
        MovementPlanning::PhaseScope phase(MovementPlanning::Phase::Transitions);
        handleMedical();
        if (core.isDead) return;
        handleActivity();
    }
    { MovementPlanning::PhaseScope phase(MovementPlanning::Phase::Displacement); handleDisplacement(); }
    { MovementPlanning::PhaseScope phase(MovementPlanning::Phase::Direction); handleMovement(); }
    if (diagnostic) diagnostic->observe(*this);
    {
        MovementPlanning::PhaseScope phase(MovementPlanning::Phase::Action);
        // LOCAL RESEARCH PATCH ONLY. Not compiled into the PR/production binary.
        static const bool research=std::getenv("GLOB2_MOVEMENT_RESEARCH_STEP")!=nullptr;
        struct ResearchCounters {
            Uint64 eligible=0,adopted=0,stays=0;Uint64 byMode[6]{};
            ~ResearchCounters(){if(eligible)std::printf("GLOB2_MOVEMENT_RESEARCH eligible=%llu adopted=%llu stays=%llu idle=%llu explore=%llu resource=%llu building=%llu clearing=%llu pursuit=%llu\n",
                (unsigned long long)eligible,(unsigned long long)adopted,(unsigned long long)stays,
                (unsigned long long)byMode[0],(unsigned long long)byMode[1],(unsigned long long)byMode[2],(unsigned long long)byMode[3],(unsigned long long)byMode[4],(unsigned long long)byMode[5]);}
        };
        static ResearchCounters researchCounts;
        const auto mode=MovementPlanning::modeOf(core);
        const bool travel=mode && (core.movement==MOV_RANDOM_GROUND || core.movement==MOV_RANDOM_FLY || core.movement==MOV_GOING_TARGET || core.movement==MOV_FLYING_TARGET || core.movement==MOV_GOING_DX_DY);
        const auto proposed=research && globalContainer->runNoX && travel ? diagnostic->preparedDirection(*this) : std::optional<Uint8>{};
        if(travel)++researchCounts.eligible;
        if(proposed) {
            ++researchCounts.adopted;++researchCounts.byMode[unsigned(*mode)];researchCounts.stays+=*proposed==8;
            // Keep authoritative service/target/claim transitions and movement
            // kind. Only replace the committed step; preserve terrain clocks,
            // occupancy order and the normal visibility update in syncStep.
            dxDyFromDirection(*proposed,&core.dx,&core.dy);
            owner->map->clearImmobileUnit(core.posX,core.posY);
            handleActionGoingDxDy();
            if((core.movement==MOV_RANDOM_GROUND || core.movement==MOV_RANDOM_FLY) && !core.dx && !core.dy)
                owner->map->clearImmobileUnit(core.posX,core.posY);
        } else handleAction();
    }
}

// NOTE : position 0 is top left (-1, -1) then run clockwise

void Unit::directionFromDxDy(void)
{
	const int tab[3][3]={	{0, 1, 2},
							{7, 8, 3},
							{6, 5, 4} };
	assert(core.dx>=-1);
	assert(core.dx<=1);
	assert(core.dy>=-1);
	assert(core.dy<=1);
	core.direction=tab[core.dy+1][core.dx+1];
}

void Unit::dxDyFromDirection(void)
{
	dxDyFromDirection(core.direction,&core.dx,&core.dy);
}

int Unit::swimClass() const
{
	return Map::swimClass(performance(WALK), performance(SWIM));
}

int Unit::directionFromDxDy(int dx, int dy)
{
	const int tab[3][3]={	{0, 1, 2},
							{7, 8, 3},
							{6, 5, 4} };
	assert(dx>=-1);
	assert(dx<=1);
	assert(dy>=-1);
	assert(dy<=1);
	return tab[dy+1][dx+1];
}

void Unit::simplifyDirection(int ldx, int ldy, int *cdx, int *cdy)
{
	int mapW=owner->map->getW();
	int mapH=owner->map->getH();
	if (ldx>(mapW>>1))
		ldx-=mapW;
	else if (ldx<-(mapW>>1))
		ldx+=mapW;
	if (ldy>(mapH>>1))
		ldy-=mapH;
	else if (ldy<-(mapH>>1))
		ldy+=mapH;

        /* We consider a cell to be vertical or horizontal in
           direction (rather than diagonal) if it is 2.41 times more
           vertical than horizontal, or vice versa.  This is because
           the halfway point between 45 degrees and 90 degrees is 67.5
           degrees and sin(67.5 deg) / cos(67.5 deg) =
           2.41421356237. */
	if ((100 * abs(ldx)) > (241 * abs(ldy)))
	{
		*cdx=SIGN(ldx);
		*cdy=0;
	}
	else if ((100 * abs(ldy)) > (241 * abs(ldx)))
	{
		*cdx=0;
		*cdy=SIGN(ldy);
	}
	else
	{
		*cdx=SIGN(ldx);
		*cdy=SIGN(ldy);
	}
}
