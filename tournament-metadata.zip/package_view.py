from pathlib import Path
import zipfile,json,hashlib,shutil
root=Path(__file__).resolve().parent;src=root/'view-usage';pub=root.parent.parent/'docs/.work/compact-core-evidence-publish'
files=[]
for p in src.rglob('*'):
 if not p.is_file():continue
 if any(v.startswith(('profile','debug-profile')) for v in p.relative_to(src).parts):continue
 if p.suffix in ['.o'] or p.name in ['view-probe','debug-cli','offsets']:continue
 if p.name in ['world.checksums','game.replay','game.replay.checksums','final.game.gz']:continue
 files.append(p)
files += [src/'canonical-matched-control'/name for name in ['world.checksums','game.replay','game.replay.checksums','final.game.gz']]
files += [src/'ai-symmetric-arena-1/final.game.gz']
files += [p for p in root.glob('*') if p.is_file() and (p.name.startswith(('view-','final-focused-','docs-delivery','fetch-master-delivery')) or p.name in ['research-reference-control-comparison.json','build-affinity.json']) and p.suffix in ['.log','.xml','.json']]
# Include the exact loaded GUI/Null fixtures; real-game initial states are already in agreement-*.zip.
fixtures=[root.parent/'movement-planning/fixtures/ordinary-control.game',root.parent/'movement-planning/fixtures/large-colony.game',root.parent/'compact-live/fixtures/cortex-colony.game']
dest=pub/'unit-view-evidence.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,str(p.relative_to(root)))
 for p in fixtures:z.write(p,'fixtures/'+p.name)
with zipfile.ZipFile(dest) as z:assert z.testzip() is None
assert dest.stat().st_size<99*1024*1024
for source,target in [('report.md','unit-view-report.md'),('protocol.md','unit-view-protocol.md'),('samples.csv','unit-view-samples.csv'),('samples.json','unit-view-samples.json'),('metadata.json','unit-view-metadata.json'),('unit-view-ticks.png','unit-view-ticks.png')]:shutil.copy2(src/source,pub/target)
(pub/'unit-view-archive-verification.json').write_text(json.dumps({'file':dest.name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'crc_valid':True},indent=2))
print(dest.name,dest.stat().st_size)
