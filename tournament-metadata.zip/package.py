from pathlib import Path
import zipfile,json,hashlib,shutil
root=Path(__file__).resolve().parent;pub=root.parent.parent/'docs/.work/compact-core-evidence-publish';verify=[]
def archive(name,paths):
 dest=pub/name
 with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in paths:z.write(p,str(p.relative_to(root)))
 with zipfile.ZipFile(dest) as z:assert z.testzip() is None
 assert dest.stat().st_size<99*1024*1024,(name,dest.stat().st_size)
 verify.append({'file':name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'crc_valid':True})
small=[p for p in root.glob('*.py')]+[root/'UnitGeometryResearch.cpp',root/'research-build.json',root/'forensic-protocol.json']
small += list((root/'analysis').glob('*'))
for folder in (root/'forensics').iterdir():
 if folder.is_dir():small += [p for p in folder.iterdir() if p.name in ['result.json','command.json','trace.csv','run.log','progress.jsonl','artifacts.json']]
small += [p for p in (root/'research-reference-control').iterdir() if p.name in ['result.json','command.json','run.log','comparison.json']]
archive('movement-deep-evidence.zip',small)
for f in ['revised-delay.png','revised-modes.png','disagreement-causes.png']:shutil.copy2(root/'analysis'/f,pub/f)
shutil.copy2(root/'deep-report.md',pub/'deep-report.md')
(pub/'movement-deep-archive-verification.json').write_text(json.dumps(verify,indent=2))
print(json.dumps(verify),flush=True)
