import pathlib,json,os,subprocess,concurrent.futures,time
root=pathlib.Path(__file__).resolve().parent
p=json.loads((root.parent/'movement-agreement/protocol.json').read_text())
binary=root/'glob2-revised-shadow'
def run(task):
 game,delay,refresh,probe=task;name=game['name']+f'-k{delay}'+('-early' if not refresh else '')
 out=root/'forensics'/name;out.mkdir(parents=True,exist_ok=True)
 env={k:v for k,v in os.environ.items() if not k.startswith('GLOB2_')};env['GLOB2_USER_DATA_DIR']=str(out/'profile');env['GLOB2_MOVEMENT_AGREEMENT_TRACE']=str(out/'trace.csv')
 if not refresh:env['GLOB2_MOVEMENT_NO_REFRESH']='1'
 if probe:env['GLOB2_MOVEMENT_EXPLAIN']='1'
 initial=root.parent/'movement-agreement'/game['name']/'initial/final.game.gz'
 cmd=[str(binary),'game','run','--load-game',str(initial),'--ticks','12000','--movement-agreement-delay',str(delay),'--telemetry','team-timeline','--telemetry','checksums','--save','final','--write-replay','--output-dir',str(out),'--compute-threads','4','--gradient-backend','scalar']
 (out/'command.json').write_text(json.dumps({'argv':cmd,'environment':{k:v for k,v in env.items() if k.startswith('GLOB2_')}}))
 start=time.monotonic()
 with (out/'run.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=900)
 print(name,round(time.monotonic()-start,1),flush=True)
# Reproduce complete delay sweep and six fixed-policy/old-admission ablations.
tasks=[(g,d,True,d==1) for g in p['games'] for d in range(9)] + [(g,1,False,True) for g in p['games']]
(root/'forensic-protocol.json').write_text(json.dumps({'tasks':[(g['name'],d,r,p) for g,d,r,p in tasks],'source':'revised shadow planner; original reference movement always authoritative','probe':'first 256 comparisons per team/mode; diagnostic only, not representative random samples'},indent=2))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(run,tasks))
