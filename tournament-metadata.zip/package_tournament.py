from pathlib import Path
import json,zipfile,hashlib,shutil,concurrent.futures
root=Path(__file__).resolve().parent;pub=root.parent.parent/'docs/.work/compact-core-evidence-publish';protocol=json.loads((root/'tournament/protocol.json').read_text())
def archive(family):
 dest=pub/('tournament-'+family+'.zip');files=[]
 for job in protocol['jobs']:
  if job['family']!=family:continue
  folder=root/'tournament'/job['id'];files += [p for p in folder.rglob('*') if p.is_file() and 'profile' not in p.relative_to(folder).parts]
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in files:z.write(p,str(p.relative_to(root)))
 with zipfile.ZipFile(dest) as z:assert z.testzip() is None
 assert dest.stat().st_size<99*1024*1024
 return {'file':dest.name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'crc_valid':True}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:verification=list(pool.map(archive,protocol['families']))
files=[p for p in root.glob('*.py')]+[root/'UnitGeometryResearch.cpp',root/'research-build.json',root/'research-reference-control-comparison.json',root/'tournament/protocol.json',root/'tournament/analysis-clarifications.json',root/'tournament/progress.jsonl',root/'tournament/completion.json',root/'tournament-analysis-final.log']+list((root/'tournament-analysis').glob('*'))
dest=pub/'tournament-metadata.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,str(p.relative_to(root)))
with zipfile.ZipFile(dest) as z:assert z.testzip() is None
verification.append({'file':dest.name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'crc_valid':True})
for source,target in [(root/'tournament-report.md','tournament-report.md'),(root/'tournament-analysis/tournament-effects.png','tournament-effects.png'),(root/'tournament-analysis/statistics.json','tournament-statistics.json'),(root/'tournament-analysis/game-observations.csv','tournament-game-observations.csv'),(root/'tournament/protocol.json','tournament-protocol.json'),(root/'deep-report.md','deep-report.md')]:shutil.copy2(source,pub/target)
(pub/'tournament-archive-verification.json').write_text(json.dumps(verification,indent=2));print(json.dumps(verification),flush=True)
