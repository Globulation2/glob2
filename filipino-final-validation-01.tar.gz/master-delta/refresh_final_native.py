"""Finish own stale candidate, then validate the final clean source exactly once."""
from pathlib import Path
import subprocess,os,signal,json,hashlib,time
r=Path.cwd();k=r/'artifacts/filipino-localization';expected='0019984e7e86492a58bdbd82b3071f6489e889f9';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected
deadline=time.monotonic()+900
while Path('/proc/2548157').exists():
 if time.monotonic()>deadline:raise RuntimeError('Own gracefully interruptedcandidate didnotfinish within15minutes')
 time.sleep(2)
log=k/'native-final-master-build.log'
record={'scope':'Oldcandidate intentionallyinterrupted to startclean finalsource incremental build; no oldcandidatepassclaimed.','candidate_log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'interruption_evidence':'native-candidate-interruption.json'}
(k/'native-final-master-candidate-complete.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,GLOB2_SDL3_PREFIX=str(k/'sdl-reused'),LD_LIBRARY_PATH=str(k/'sdl-reused/lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''),SDL_VIDEO_DRIVER='x11');[env.pop(n,None) for n in ['DISPLAY','WAYLAND_DISPLAY','XAUTHORITY']]
record={'revision':expected,'commands':[],'candidate_provenance':'native-final-master-candidate-complete.json'}
commands=[('native-final-editor-build',['python3','tools/dev_build.py','translation-preview-harness','engine-tests','-j10']),('native-final-editor-focused',['python3','test/run_tests.py','--build-dir','build/linux/client/debug/dev-dev_fast-true-linker-auto','--binary','engine','--filter','SystemLanguage/*','--filter','FontKerning/*','--filter','EditorPresentation/*','--filter','Settings/large Filipino touch footers*','--display-jobs','1','-j','4','--timeout','300','--artifacts',str(k/'native-final-editor-focused'),'--junit',str(k/'native-final-editor-junit.xml')])]
for name,args in commands:
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected and not subprocess.check_output(['git','status','--porcelain'],text=True),'Source changed; refuse mislabeled final evidence'
 start=time.monotonic()
 with (k/(name+'.log')).open('w') as out:q=subprocess.run(args,env=env,stdout=out,stderr=subprocess.STDOUT)
 record['commands'].append({'name':name,'argv':args,'exit_code':q.returncode,'seconds':time.monotonic()-start,'log':name+'.log','log_sha256':hashlib.sha256((k/(name+'.log')).read_bytes()).hexdigest()});(k/'native-final-editor-results.json').write_text(json.dumps(record,indent=2)+'\n');print(name,q.returncode,flush=True)
 if q.returncode:raise SystemExit(q.returncode)
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected and not subprocess.check_output(['git','status','--porcelain'],text=True),'Source changed during final command'
