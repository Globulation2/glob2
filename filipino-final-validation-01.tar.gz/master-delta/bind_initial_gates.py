from pathlib import Path
import json,hashlib,copy
K=Path('artifacts/filipino-localization');F=K/'final-kit';p=F/'reviews/fil.json';x=json.loads(p.read_text());source=x['source_sha256'];hashes=x['catalog_sha256']
def ev(rel):
 q=F/rel;assert q.is_file();return {'path':rel,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}
(F/'master-delta/gates-before-binding.json').write_text(json.dumps(x['gates'],indent=2)+'\n')
common=['master-delta/source-target-carry.json','master-delta/independent-aggregate-audit-clean.json','master-delta/author-review.json','master-delta/meaning-review.json','master-delta/editor-review.json','master-delta/meaning-final-review.json','master-delta/adversarial-review.json','reviews/fil-provenance.json']
for n,paths,scope in [
 ('language_brief',['linguistic/meaning-brief.json']+common,'Contemporary Filipino brief applies to unchanged6229source/target values;2newstatistics entries directly reviewed by four identities with individual AI/save term rationales.'),
 ('source_based_pilot',['linguistic/pilot-meaning-review.json','google/fil/summary.json','../master-delta/request.json','../master-delta/response.json','../master-delta/attempts.jsonl']+common,'Original source-based pilot and original60Google calls remain historical; separate61strequest drafts2newmaster entries and allfourroles approve final delta. No repeatedfullcorpus call/read implied.'),
 ('structural',['../master-data-results.json','../master-strict.log','../master-translations.log','../master-font-coverage.log','draft-check.json','../structural-final-results.json']+common,'Current46a7strictnative contracts,10translationregressions andfull/startupfontglyph checks pass. Onlineplural/interpolation contracts unchanged; original37locale/40i18n checks carry unchangedonlineinputs.'),
 ('mobile_platforms',['../master-data-results.json','../master-mobile-android.log','../master-mobile-ios.log','../mobile-assets-tests.log']+common,'Actual46a7Android/iOS asset exports,7871files each, verify currentf5efcatalog/inventories/font/notices;4assetcontracts unchanged. Packaging-only coverage; native Android/iOS binaries/emulators/devices unverified.')]:
 x['gates'][n]={'passed':True,'source_sha256':source,'catalog_sha256':hashes,'scope':scope,'evidence':[ev(v) for v in paths]}
 if n=='mobile_platforms':x['gates'][n]['unverified']=['No nativeAndroid/iOS compilation or device/emulator execution. Phone browser/native Linux captures are separate coverage.']
p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
