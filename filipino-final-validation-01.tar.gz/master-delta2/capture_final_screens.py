from pathlib import Path
import subprocess,os,json,hashlib,time
r=Path.cwd();k=r/'artifacts/filipino-localization';rev='fff6667d1ed63c799e5065ca7d12373e1305f1d4';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==rev and not subprocess.check_output(['git','status','--porcelain'],text=True)
b=k/'rendering/bin/TranslationPreviewHarness-final-fff'
while not (k/'rendering/native-final-full-matrix/process.log').exists(): time.sleep(5)
draft=k/'final-kit2/drafts/fil';out=k/'rendering/native-final-screens';out.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();record={'revision':rev,'binary_sha256':sha(b),'scope':'Fresh finalFFF real-engine native software settings/gameplay screens. Forcedphone dimensions are not physicalmobile execution.','commands':[]}
for mode,name,w,h,phone in [('screen','settings',1280,860,False),('game','gameplay',1280,860,False),('game','gameplay',390,844,True)]:
 folder=out/(('phone' if phone else 'desktop')+'-'+name);folder.mkdir(exist_ok=True);args=[str(b),mode,str(r),str(draft),str(folder),str(w),str(h),name];env=dict(os.environ,SDL_VIDEO_DRIVER='dummy',SDL_VIDEODRIVER='dummy',SDL_RENDER_DRIVER='software',SDL_AUDIODRIVER='dummy',GLOB2_MOBILE_UI='1' if phone else '0',GLOB2_USER_DATA_DIR=str(folder/'profile'),LD_LIBRARY_PATH=str(k/'sdl-reused/lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''));start=time.monotonic()
 with (folder/'process.log').open('wb') as log:q=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 row={'argv':args,'exit_code':q.returncode,'seconds':time.monotonic()-start,'folder':str(folder.relative_to(k))};record['commands'].append(row);(out/'capture-manifest.json').write_text(json.dumps(record,indent=2)+'\n');assert q.returncode==0
 m=json.loads((folder/(name+'.json')).read_text());assert m['evidence_identity']['producer']['revision']==rev and m['evidence_identity']['producer']['dirty'] is False and m['evidence_identity']['executable_sha256']==record['binary_sha256'];row['files_sha256']={p.name:sha(p) for p in folder.iterdir() if p.is_file()};(out/'capture-manifest.json').write_text(json.dumps(record,indent=2)+'\n');print('CAPTURED',folder.name,flush=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==rev and not subprocess.check_output(['git','status','--porcelain'],text=True)
