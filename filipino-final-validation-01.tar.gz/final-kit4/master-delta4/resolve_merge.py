from pathlib import Path
import subprocess,re,json
R=Path.cwd();OLD='81e09c3b646c7055e1281bf84d2471a84d890f8f';M='1bb5155e96b61144583466a00041fb1d04fc9def';assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],text=True).strip()==M
get=lambda ref,p:subprocess.check_output(['git','show',ref+':'+p],text=True)
def save(p,s):Path(p).write_text(s)
def resolve(p,callback):
 s=Path(p).read_text();n=0
 def sub(m):
  nonlocal n
  n+=1;return callback(m.group(1),m.group(2),n)
 s=re.sub(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> origin/master\n',sub,s,flags=re.S|re.M);assert '<<<<<<<'not in s,p;save(p,s)
for p in ['data/texts.hi.txt','data/texts.nb.txt','data/texts.sw.txt','data/texts.ur.txt']:save(p,get(M,p))
for p in ['data/texts.list.txt','data/texts.incomplete.txt']:
 s=get(M,p);assert 'data/texts.fil.txt'not in s;save(p,s+'data/texts.fil.txt\n')
resolve('docs/development/ui-framework.md',lambda a,b,n:a+'\n'+b if n==1 else b.replace('Script-layout locales, Swahili, Norwegian Bokmål and Malay','Script-layout locales, Filipino, Swahili, Norwegian Bokmål and Malay'))
resolve('libgag/src/FontKerningTest.cpp',lambda a,b,n:b.replace('"ms", "ur"','"ms", "fil", "ur"'))
# Real Filipino long-Latin sample outside the conflict already auto-merged.
assert 'Nagtatayo at nagsasanay habang pinapanatili' in Path('libgag/src/FontKerningTest.cpp').read_text()
resolve('libgag/src/TrueTypeFont.cpp',lambda a,b,n:b.replace('Swahili, Bokmål and Malay','Swahili, Filipino, Bokmål and Malay').replace('language == "ms";','language == "ms" || language == "fil";'))
p='platform/packages/i18n/src/index.ts';resolve(p,lambda a,b,n:b.replace("language === 'sw' || language === 'ms'","language === 'sw' || language === 'ms' || language === 'fil' || language === 'tl'") if n==1 else a+b)
p='platform/packages/i18n/src/locales.ts';s=get(M,p);needle="  {\n    code: 'nb',";assert s.count(needle)==1;s=s.replace(needle,"  {\n    code: 'fil',\n    gameCode: 'fil',\n    name: 'Filipino',\n    dir: 'ltr',\n  },\n"+needle);save(p,s)
resolve('platform/packages/i18n/test/runtime.test.ts',lambda a,b,n:a+'  });\n'+b if n==1 else b.replace("  it('contains unique game catalog mappings including Malay'","  it('contains unique game catalog mappings including Filipino and Malay'")+'    expect(locales).toContainEqual({ code: \'fil\', gameCode: \'fil\', name: \'Filipino\', dir: \'ltr\' });\n')
resolve('src/app/SystemLanguageTest.cpp',lambda a,b,n:a+'\t}\n'+b)
resolve('src/ui/settings/SettingsScreenTest.cpp',lambda a,b,n:a+'\n'+b)
p='platform/apps/web/e2e/i18n.spec.ts';ours=get(OLD,p);start=ours.index("test.describe('Filipino browser preference'");save(p,get(M,p)+'\n'+ours[start:])
p='test/translation_shared_values.json';ours=json.loads(get(OLD,p));master=json.loads(get(M,p));assert 'texts.fil.txt'not in master['shared_vocabulary'];master['shared_vocabulary']['texts.fil.txt']=ours['shared_vocabulary']['texts.fil.txt'];save(p,json.dumps(master,ensure_ascii=False,indent=2)+'\n')
# Generated file will be recreated using the combined language inventory below.
save('browser/i18n.js',get(M,'browser/i18n.js'))
print('Resolved17trackedconflicts; generatedi18n/fontfingerprints next; merge notcommittedyet')
