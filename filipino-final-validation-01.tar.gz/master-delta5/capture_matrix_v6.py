from pathlib import Path
import subprocess,os,json,hashlib,time,gzip,threading
r=Path.cwd();k=r/'artifacts/filipino-localization';expected=__import__('sys').argv[1];deadline=time.monotonic()+14400
while True:
 p=k/'native-v6-focused-builder/producer-cd187eb0173e/build-receipt.json'
 if p.exists():
  x=json.loads(p.read_text())
  if x.get('status')=='built-focused-only':
   assert x['source']['revision']==expected and all(c['exit_code']==0 for c in x['commands']),'Focused current production build failed/stale';break
 if time.monotonic()>deadline:raise RuntimeError('Final build wait4hour bound exceeded')
 time.sleep(2)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected and not subprocess.check_output(['git','status','--porcelain'],text=True)
binary=r/'build/linux/client/debug/dev-dev_fast-true-linker-auto/test/TranslationPreviewHarness';derived=k/'rendering/bin/TranslationPreviewHarness-final-v6';subprocess.run(['strip','--strip-debug','-o',str(derived),str(binary)],check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();out=k/'rendering/native-final-v6-full-matrix';out.mkdir(exist_ok=True);draft=k/'final-kit5/drafts/fil';env=dict(os.environ,SDL_VIDEO_DRIVER='dummy',SDL_VIDEODRIVER='dummy',SDL_RENDER_DRIVER='software',SDL_AUDIODRIVER='dummy',LD_LIBRARY_PATH=str(k/'sdl-reused/lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''),GLOB2_USER_DATA_DIR=str(out/'profile'))
args=[str(derived),'matrix',str(r),str(draft),str(out),'390','844'];record={'revision':expected,'actual_original_binary_sha256':sha(binary),'derived_binary_sha256':sha(derived),'derivation':'strip --strip-debug; runtime code preserved','argv':args,'input_sha256':{n:sha(draft/n) for n in ['native.json','online.json','metadata.json']}}
start=time.monotonic()
with (out/'process.log').open('wb') as log:
 p=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=2100)
record.update(exit_code=p.returncode,seconds=time.monotonic()-start);assert p.returncode==0
m=json.loads((out/'font-matrix.json').read_text());s=m['samples'];assert m['evidence_identity']['producer']['revision']==expected and m['evidence_identity']['producer']['dirty'] is False;assert m['evidence_identity']['executable_sha256']==record['derived_binary_sha256'];assert len(s)==38316
missing=[{'key':v['key'],'surface':v['surface'],'branch':v['branch'],'size':v['size'],'scale':v['scale']} for v in s if not v['has_glyphs']];fit=[{'key':v['key'],'surface':v['surface'],'line':l} for v in s for l in v['lines'] if not l['drawn_fits_width'] or not l['drawn_fits_height']];raw=sum(not l['fits_width'] or not l['fits_height'] for v in s for l in v['lines']);pages={p.name:sha(p) for p in out.glob('*.png')};record.update(samples=len(s),missing_glyphs=missing,drawn_fit_failures=fit,raw_raster_diagnostics=raw,png_sha256=pages,manifest_sha256=sha(out/'font-matrix.json'),limits=['Complete current-source diagnostic matrix, with literal catalog tokens/escapes. Representative pixels independently reviewed separately; no claim of38316individual visual inspections.','NativeLinux software renderer; physicalmobile/otherOS coverage not implied.']);(out/'current-matrix-proof.json').write_text(json.dumps(record,indent=2)+'\n');assert not missing and not fit;assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected and not subprocess.check_output(['git','status','--porcelain'],text=True);print('PASS finalv6fullmatrix',len(s),len(pages),flush=True)
