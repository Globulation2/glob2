from pathlib import Path
import subprocess,json,hashlib,functools,importlib.util,unittest,time,inspect,sys
R=Path.cwd();K=R/'artifacts/filipino-localization';H='2430012b570077bc27ea3ad7c0d761e63a30f5a1';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==H;assert subprocess.run(['git','diff','--quiet']).returncode==0
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();oldlog=K/'web-roundtrip-243.log'
if oldlog.exists():(K/'web-roundtrip-243-attempt0-interrupted.log').write_bytes(oldlog.read_bytes())
files=set(['browser/derive_assets.py','browser/assets/sources.json','test/build_system/test_web_assets.py','scons/web_assets.py','tools/package_assets.py','tools/image_encoding.json']);files.update(p.as_posix() for p in (R/'data').glob('texts.*.txt'));recorded=json.loads((R/'browser/assets/sources.json').read_text())
for target,entry in recorded.items():files.add(target);files.add(entry['source'])
files=sorted(files);before={p:sha(p) for p in files};t=time.monotonic();s=importlib.util.spec_from_file_location('web_assets_test',R/'test/build_system/test_web_assets.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);original=m.web_assets.derived_assets;function_source=inspect.getsource(original);misses={}
@functools.lru_cache(maxsize=16)
def cached(root,lossy=True,images=True):
 value=original(root,lossy,images);misses[(str(Path(root).resolve()),lossy,images)]=dict(value);return value
m.web_assets.derived_assets=cached
suite=unittest.TestSuite([m.WebAssetPackageTests('test_packages_round_trip_and_are_content_addressed')]);log=K/'web-roundtrip-243.log';running={'revision':H,'input_sha256_before':before,'wrapper_source_sha256':sha(__file__),'memoized_function_source_sha256':hashlib.sha256(function_source.encode()).hexdigest()};(K/'web-roundtrip-243-running.json').write_text(json.dumps(running,indent=2)+'\n')
with log.open('w') as f:result=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
uncached_rechecks=[]
for key,value in misses.items():
 actual=original(Path(key[0]),key[1],key[2]);uncached_rechecks.append({'arguments':key,'uncached_before_return':value,'uncached_after_return':actual,'equal':actual==value})
after={p:sha(p) for p in files};out={**running,'revision_at_start':H,'revision_at_finish':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_tracked_clean_after':subprocess.run(['git','diff','--quiet']).returncode==0,'execution_label':'Actualrealpackageroundtriptestwithartifact-ownedmemoizationofpurederived_assetslookuponly; NOTunmodifiedtestexecution.','real_case':'WebAssetPackageTests.test_packages_round_trip_and_are_content_addressed','exit_code':0 if result.wasSuccessful() else 1,'tests_run':result.testsRun,'seconds':time.monotonic()-t,'input_sha256_after':after,'uncached_before_after_return_rechecks':uncached_rechecks,'memoization_scope':'Onlystartupfont/imageprovenancelookupcached; allfunctionsource/config/catalogname/sourceasset/derivedassetinputsclosurehashbeforeafter. derived_assetsdoesnotreadgeneratedspritefiles; real2packagebuilds,contents,manifestsandassertionsunchanged.','cache_info':str(cached.cache_info()),'python':sys.version,'interrupted_attempt0':'Stoppedbeforefirstpackagebuildcompletiontostrengthenproof; exit130/notpass; logpreserved.','log':log.name,'log_sha256':sha(log)}
out['stable_input_closure']=before==after and all(x['equal'] for x in uncached_rechecks) and out['source_tracked_clean_after'];(K/'web-roundtrip-243-results.json').write_text(json.dumps(out,indent=2)+'\n');assert out['stable_input_closure'];print(json.dumps({'exit_code':out['exit_code'],'seconds':out['seconds'],'cache':out['cache_info'],'stable':out['stable_input_closure']}),flush=True)
