import { createRequire } from 'node:module';
import { createServer, request } from 'node:http';
import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
const root=process.cwd();
const {execFileSync}=await import('node:child_process');
const expectedRevision=process.argv[2];if(!expectedRevision)throw Error('Expected final revision argument required');
const sourceIdentity=()=>({revision:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),status:execFileSync('git',['status','--porcelain','--untracked-files=no'],{encoding:'utf8'}).trim()});
const before=sourceIdentity();if(before.revision!==expectedRevision||before.status)throw Error('Not clean expected final source');
const require=createRequire(root+'/platform/package.json');
const {chromium}=require('@playwright/test');
const {createHarness,RealtimeClient,SIM,postJson}=await import(root+'/platform/apps/api/test/support.ts');
const {simVersionKey}=await import(root+'/platform/packages/protocol/src/index.ts');
const out=root+'/artifacts/filipino-localization/final-web-v8/ssr';if(existsSync(out))throw Error('Refuse existing SSR output');mkdirSync(out);
const h=await createHarness();let proxy,browser,client;
const record={source_revision:expectedRevision,source_before:before,helper_sha256:createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex'),kind:'actual API routes from isolated test harness, actual shared design assets',routes:[],screenshots:[],checks:[],limits:['Public guest and room fixtures only; no external identity provider or production credentials.','Phone viewport is Chromium390x844, not an actual Android/iOS device.','Screenshots verify these fixture states, not every auth/invite state.']};
try {
 await h.database.db.insertInto('engine_agents').values({id:'fil-ssr-fixture',sim_version:simVersionKey(SIM),kinds:['generate-map','validate-map','render-preview','verify-match'],build:'fake'}).execute();
 const a=await h.start({origin:'http://127.0.0.1:45241',instance:{auth:{providers:[],local:{enabled:true}}}});
 proxy=createServer((req,res)=>{const u=new URL(req.url,a.url);const p=request(u,{method:req.method,headers:req.headers},r=>{res.writeHead(r.statusCode,r.headers);r.pipe(res)});p.on('error',e=>{res.statusCode=502;res.end(String(e))});req.pipe(p)});await new Promise(resolve=>proxy.listen(45241,'127.0.0.1',resolve));
 const session=await (await postJson(a.url+'/api/v1/auth/guest',{platform:'desktop'})).json();
 client=await RealtimeClient.connect(a.url);await client.hello(session.tokens.accessToken,SIM);
 const room=(await client.ok('room.create',{name:'Filipino visual fixture',visibility:'link'})).room;
 const paths=['/signin','/j/'+room.code,'/j/ZZZZZZZZ'];
 for(const header of ['fil','tl-PH','en-PH','fil-Tglg']){const r=await fetch('http://127.0.0.1:45241/signin',{headers:{'accept-language':header}});const body=await r.text();const lang=body.match(/<html lang="([^"]+)"/)?.[1];const expected=['fil','tl-PH'].includes(header)?'fil':'en';if(lang!==expected)throw Error(header+' => '+lang);record.checks.push({accept_language:header,html_lang:lang,status:r.status});}
 for(const [cookie,header,expected] of [['fil','en','fil'],['en','tl-PH','en']]){const r=await fetch('http://127.0.0.1:45241/signin',{headers:{cookie:'glob2_locale='+cookie,'accept-language':header}});const body=await r.text();if(!body.includes('<html lang="'+expected+'"'))throw Error('cookie precedence');record.checks.push({cookie:'glob2_locale='+cookie,accept_language:header,html_lang:expected});}
 browser=await chromium.launch({headless:true});
 for(const [viewport,width,height] of [['desktop',1280,860],['phone',390,844]]){
 const context=await browser.newContext({viewport:{width,height},locale:'tl-PH'});const page=await context.newPage();
 for(const [i,path] of paths.entries()){const response=await page.goto('http://127.0.0.1:45241'+path);await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(200);const name=['signin','invite','unknown-invite'][i];const file=out+'/'+viewport+'-'+name+'.png';await page.screenshot({path:file,fullPage:true});const meta=await page.evaluate(()=>({lang:document.documentElement.lang,dir:document.documentElement.dir,width:innerWidth,scrollWidth:document.documentElement.scrollWidth,font: getComputedStyle(document.body).fontFamily,text:document.body.innerText}));if(meta.lang!=='fil'||meta.scrollWidth>meta.width)throw Error('locale/overflow '+file);writeFileSync(out+'/'+viewport+'-'+name+'.html',await page.content());record.screenshots.push({path:file.slice(root.length+1),sha256:createHash('sha256').update(readFileSync(file)).digest('hex'),viewport:{width,height},http_status:response.status(),route:path,meta});}
 await context.addCookies([{name:'glob2_locale',value:'en',url:'http://127.0.0.1:45241'}]);await page.goto('http://127.0.0.1:45241/signin');if(await page.locator('html').getAttribute('lang')!=='en')throw Error('en cookie');await context.addCookies([{name:'glob2_locale',value:'fil',url:'http://127.0.0.1:45241'}]);await page.reload();if(await page.locator('html').getAttribute('lang')!=='fil')throw Error('fil cookie');await page.reload();if(await page.locator('html').getAttribute('lang')!=='fil')throw Error('reload persistence');record.checks.push({viewport,cookie_persistence:'EN then FIL override and FIL reload passed'});await context.close();}
 record.status='capture and HTTP checks passed; visual review pending';
} catch(error){record.status='failed';record.error=String(error.stack||error);throw error;} finally{record.source_after=sourceIdentity();if(browser)await browser.close();if(client)client.close();if(proxy)await new Promise(resolve=>proxy.close(resolve));await h.close();writeFileSync(out+'/capture.json',JSON.stringify(record,null,2)+'\n');}
if(record.source_after.revision!==expectedRevision||record.source_after.status)throw Error('Source changed during SSR capture');
console.log('SSR capture complete:',record.screenshots.length,'screenshots',record.checks.length,'checks; isolated harness cleaned up.');
