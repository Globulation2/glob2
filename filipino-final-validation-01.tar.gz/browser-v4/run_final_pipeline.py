from pathlib import Path
import argparse,subprocess,time,json,os,hashlib,uuid,datetime
R=Path(__file__).resolve().parents[3];K=R/'artifacts/filipino-localization';BASE=Path(__file__).resolve().parent;O=None
p=argparse.ArgumentParser();p.add_argument('--revision',required=True);p.add_argument('--build-receipt',type=Path,required=True);p.add_argument('--build-log',type=Path,required=True);args=p.parse_args();deadline=time.monotonic()+10800
while True:
 if args.build_receipt.exists():
  d=json.loads(args.build_receipt.read_text())
  if d['status']!='building':assert d['status']=='passed' and d['source']['revision']==args.revision,d;break
 if time.monotonic()>deadline:raise SystemExit('Build did not finish within3h')
 time.sleep(1)
def identity():
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();dirty=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=R,text=True).strip();assert head==args.revision and not dirty,(head,dirty);return head
identity();O=BASE/('attempt-'+args.revision[:8]+'-'+uuid.uuid4().hex[:12]);O.mkdir();print('ATTEMPT '+str(O),flush=True);(O/'attempt.json').write_text(json.dumps({'revision':args.revision,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'build_receipt':str(args.build_receipt),'build_receipt_sha256':hashlib.sha256(args.build_receipt.read_bytes()).hexdigest(),'pipeline_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256((BASE/'capture_extra.js').read_bytes()).hexdigest()},indent=2)+'\n');server=json.loads((BASE/'server.json').read_text());proc=Path('/proc')/str(server['pid']);assert proc.exists() and (proc/'cwd').resolve()==R and b'browser/serve.py' in (proc/'cmdline').read_bytes()
env=dict(os.environ,PATH='/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH'],GLOB2_TEST_URL='http://127.0.0.1:45221',GLOB2_TEST_BUILD_DIR=str(R/'build/emscripten/client/release'),PLAYWRIGHT_JSON_OUTPUT_NAME=str(O/'playwright-results.json'))
steps=[]
def run(name,argv,cwd=R,timeout=1800):
 before=identity();start=time.monotonic();log=O/(name+'.log')
 with log.open('x') as stream:result=subprocess.run(argv,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
 row={'name':name,'command':argv,'cwd':str(cwd),'source_before':before,'source_after':identity(),'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};steps.append(row);(O/'validation-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit('Stage failed; preserve evidence and inspect before any retry: '+name)
for mode,dpr in [('serial',2),('threaded',1)]:
 run('legacy150-'+mode,['node',str(BASE/'capture_extra.js'),'out='+str(O/('legacy150-'+mode)),'phone=1','mode='+mode,'dpr='+str(dpr),'phase=editor-probe','renderer=webgl2','interactive=1'],timeout=4800)
for mode,dpr in [('serial',2),('threaded',1)]:
 run('hud150-'+mode,['node',str(BASE/'capture_extra.js'),'out='+str(O/('hud150-'+mode)),'phone=1','mode='+mode,'dpr='+str(dpr),'phase=building-select','renderer=webgl2','text150=1','waitClick=1'])
run('hud100',['node',str(BASE/'capture_extra.js'),'out='+str(O/'hud100'),'phone=1','mode=serial','dpr=1','phase=hud100','renderer=webgl2','text100=1'])
run('filipino-four-cases',['npx','--no-install','playwright','test','tests/filipino.spec.js','--project=chromium','--reporter=line,json','--output='+str(O/'playwright')],R/'browser',3000)
run('building-statistics',['node',str(BASE/'capture_extra.js'),'out='+str(O/'building-statistics'),'phone=0','mode=serial','dpr=1','phase=building-select','waitClick=1','stats=1'])
run('packaging',['python3',str(K/'packaging/verify_browser_v4.py'),'--revision',args.revision,'--build-log',str(args.build_log),'--output',str(O/'packaging'),'--static',str(O/'static-release'),'--font-base','1bb5155e96b61144583466a00041fb1d04fc9def','--require-glyphs','--require-http','--caddy',str(K/'packaging/bin/caddy')])
print('Final source-bound pipeline finished; inspect actual stage records and images before approving gates.',flush=True)
