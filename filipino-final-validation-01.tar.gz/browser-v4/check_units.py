"""Run current units and independently reproduce known replay-fixture failures on frozen master."""
from pathlib import Path
import argparse,subprocess,json,hashlib,re,time,os
R=Path(__file__).resolve().parents[3]
p=argparse.ArgumentParser();p.add_argument('--revision',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();O=a.output.resolve();O.mkdir()
H=lambda b:hashlib.sha256(b).hexdigest()
def git(*x):return subprocess.check_output(['git',*x],cwd=R)
def clean():assert git('rev-parse','HEAD').decode().strip()==a.revision and not git('status','--porcelain','--untracked-files=no').strip()
clean();node='/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';base='1bb5155e96b61144583466a00041fb1d04fc9def';B=O/'baseline-1bb';B.mkdir();paths=['browser/unit/replay-fixture.test.js','browser/tests/fixtures/cross-replay.replay','browser/tests/fixtures/generator-studio-trace.json','browser/tests/fixtures/studio-trace.json','src/replay/ReplayReader.h','src/app/Version.h','src/game/SimRevision.h'];inputs=[]
for name in paths:
 data=git('show',base+':'+name);f=B/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data);inputs.append({'path':name,'baseline_sha256':H(data),'current_sha256':H((R/name).read_bytes()),'identical':data==(R/name).read_bytes()})
def run(cmd,cwd,label):
 start=time.monotonic();out=O/(label+'.log')
 with out.open('x') as log:r=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 text=out.read_text();return {'command':cmd,'cwd':str(cwd),'exit_code':r.returncode,'seconds':time.monotonic()-start,'log_sha256':H(out.read_bytes()),'failed_tests':re.findall(r'^not ok \d+ - (.*)$',text,re.M),'counts':dict(re.findall(r'^# (tests|pass|fail) (\d+)$',text,re.M))}
b=run([node,'--test','--test-reporter=tap','browser/unit/replay-fixture.test.js'],B,'baseline');c=run([node,'--test','--test-reporter=tap',*[str(x.relative_to(R)) for x in sorted((R/'browser/unit').glob('*.test.js'))]],R,'current');clean()
expected=set(b['failed_tests']);known_only=b['exit_code']==1 and len(expected)==3 and c['exit_code']==1 and set(c['failed_tests'])==expected and all(x['identical'] for x in inputs)
status='passed' if c['exit_code']==0 else 'existing_baseline_failures_only' if known_only else 'unresolved_failure'
(O/'receipt.json').write_text(json.dumps({'status':status,'revision':a.revision,'baseline_revision':base,'inputs':inputs,'baseline':b,'current':c,'limits':'Exact isolated seven-file baseline probe; no baseline full build or assertion edits.'},indent=2)+'\n');print(status)
raise SystemExit(0 if status!='unresolved_failure' else 1)
