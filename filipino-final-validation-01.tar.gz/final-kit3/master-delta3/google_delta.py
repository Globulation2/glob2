from pathlib import Path
import importlib.util,json,subprocess,hashlib,time
spec=importlib.util.spec_from_file_location('gd','tools/localization/google_draft.py');gd=importlib.util.module_from_spec(spec);spec.loader.exec_module(gd)
p=Path('artifacts/filipino-localization/master-delta3');master=subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip();assert master=='bc8fb2c2bda69af14a7a6c5ed5ca1dfed7575ddb'
old=gd.PROGRAM.CHECKER.read_table(Path('data/texts.en.txt'))[0];raw=subprocess.check_output(['git','show',master+':data/texts.en.txt'],text=True).splitlines();new=dict(zip(raw[::2],raw[1::2],strict=True));native={k:v for k,v in new.items() if k not in old};assert len(native)==4 and all(new[k]==v for k,v in old.items());contents=[gd.protect(v) for v in native.values()];request=gd.request_payload('bradley-personal-20261027','fil',contents)
gd.atomic_json(p/'source.json',{'master':master,'entries':native});gd.atomic_json(p/'request.json',request)
response=p/'response.json'
if not response.exists():
 chars=sum(map(len,contents));assert 4.6442+chars*gd.RATE<8;gd.append_attempt(p/'attempts.jsonl',{'id':str(time.time_ns()),'characters':chars,'estimated_usd':chars*gd.RATE,'request_sha256':hashlib.sha256((p/'request.json').read_bytes()).hexdigest(),'status':'reserved-before-request'});gd.atomic_json(response,gd.request_google('bradley-personal-20261027','fil',contents))
r=json.loads(response.read_text());target={key:gd.restore(native[key],item['translatedText']) for key,item in zip(native,r['translations'],strict=True)};gd.atomic_json(p/'draft.json',target);print(json.dumps(target,ensure_ascii=False,indent=2))
