from pathlib import Path
import subprocess,os,json,hashlib,time
r=Path.cwd();k=r/'artifacts/filipino-localization';rev='f0f003572e0c204f6d1c16063a9852cf3ade7bf1';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==rev and not subprocess.check_output(['git','status','--porcelain'],text=True)
deadline=time.monotonic()+10800
while True:
 prior=k/'native-243-results.json'
 if prior.exists():
  data=json.loads(prior.read_text())
  if data.get('commands'):
   assert data['commands'][0]['exit_code']==0,'Inspect preceding build failure'
   break
 if time.monotonic()>deadline:raise RuntimeError('Priorbuild wait3hour bound exceeded')
 time.sleep(2)
base=dict(os.environ,GLOB2_SDL3_PREFIX=str(k/'sdl-reused'),LD_LIBRARY_PATH=str(k/'sdl-reused/lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''));[base.pop(n,None) for n in ['DISPLAY','WAYLAND_DISPLAY','XAUTHORITY']];display=dict(base,SDL_VIDEO_DRIVER='x11');dummy=dict(base,SDL_VIDEO_DRIVER='dummy',SDL_VIDEODRIVER='dummy');record={'revision':rev,'commands':[]}
build=['python3','tools/dev_build.py','translation-preview-harness','engine-tests','-j10']
common=['python3','test/run_tests.py','--build-dir','build/linux/client/debug/dev-dev_fast-true-linker-auto','--binary','engine']
ui=common+sum((['--filter',s] for s in ['SystemLanguage/*','FontKerning/*','EditorPresentation/*','Settings/large Filipino touch footers*','GameGUITouch/live statistics hide post-game probability*','GUIInteractionCoverage/statistics topics history*','GUIInteractionCoverage/statistics sheet scroll*','TerrainPresentation/whole-cell layers preserve software terrain caching*','TerrainPresentation/whole-cell layers preserve OpenGL terrain caching*']),[])+['--display-jobs','1','-j','4','--timeout','600','--artifacts',str(k/'native-f0f-focused'),'--junit',str(k/'native-f0f-focused-junit.xml')]
units=common+sum((['--filter',s] for s in ['TerrainMaterials/*','TerrainPresentation/*','SpriteSheets/*']),[])+['--no-display','-j','4','--timeout','180','--artifacts',str(k/'native-f0f-render-units'),'--junit',str(k/'native-f0f-render-units-junit.xml')]
for name,args,env in [('native-f0f-build',build,base),('native-f0f-focused',ui,display),('native-f0f-render-units',units,dummy)]:
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==rev and not subprocess.check_output(['git','status','--porcelain'],text=True)
 start=time.monotonic()
 with (k/(name+'.log')).open('wb') as log:q=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 record['commands'].append({'name':name,'argv':args,'exit_code':q.returncode,'seconds':time.monotonic()-start,'log':name+'.log','log_sha256':hashlib.sha256((k/(name+'.log')).read_bytes()).hexdigest()});(k/'native-f0f-results.json').write_text(json.dumps(record,indent=2)+'\n');print(name,q.returncode,flush=True)
 if q.returncode:raise SystemExit(q.returncode)
