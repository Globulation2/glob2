import json,hashlib,pathlib,subprocess
p=pathlib.Path('artifacts/filipino-localization/master-delta6')
h=lambda b:hashlib.sha256(b).hexdigest()
s=json.loads((p/'source.json').read_text())
a=json.loads((p/'author-final.json').read_text())
r=[
'Camera looks from the front of the model; tanaw avoids an opinion reading.',
'Rear camera direction preserved, consistent with the other views.',
'Left camera direction preserved rather than a departure action.',
'Right camera direction preserved rather than correctness.',
'Empty animation action is a fixed pose, not necessarily standing; nakapirming accurately conveys nonanimated.',
'Musical artist attribution in publication metadata; artista remains broad enough for the credited performer.',
'Admin match activity series counts started matches; completed action label fits the neighboring completed/cancelled series, not a timestamp.',
'Account count grouped per day, not account age or daily charge.',
'Multiplayer matches grouped per day; laban correctly avoids lexical tugma.',
'Guest account type preserved without claiming anonymous browsing creates no account.',
'Registered account category preserved.',
'New soundtrack composer target; soundtrack is established product terminology.',
'Wait for the active request to finish; no instruction to cancel or resubmit.',
'Generation unavailable does not revoke access to saved music; accessible retained as can open.',
'Available Music credit is an eligibility requirement for both chat and building; no claim chat itself spends it.',
'Explicit zero discussion cost, one available music credit eligibility, automatic creation, charge only on delivery, and all three moods are retained.',
'Built-in idea title preserves moss and morning light, without altering user-authored project names.',
'Woodland warmth, flute/harp, plucked strings, wandering returning melody, and combat additions of quiet drums/bassoon counterline all preserved.',
'De-susi conveys a small clockwork mechanism rather than a garden physically made from clocks; built-in imaginative idea title.',
'Rounded synth timbre becomes buo ang tunog rather than circular geometry; unhurried curious character, answering melody, deeper growing-colony pulse preserved.',
'Built-in waltz suggestion for rain preserved; waltz is the named musical dance form.',
'Recorder explicitly a wind instrument, sparse phrases include breathing rests, building is Pagtatayo mood, and low strings add warm combat timbre; not generation steps.',
'Generation disabled while saved projects remain openable; no deletion or access restriction implied.',
'Available Map credit gates both chat and building; map product category explicit.',
'Free discussion versus one-credit eligibility and delivery charge distinguished; automatic creation retained for map product.',
'Ongoing saving of the user project, with ellipsis retained; not a command to save.',
'Unavailable generation only, without adding claims about all service availability.',
'Terrain product category translated as lupain; discussion cost, eligibility, automatic build and on-delivery charge all separately preserved.',
'Fixed server preset stripes, not an authored design name; guhit matches stripe appearance.',
'Fixed server preset spots, not an authored design name; batik matches spot appearance.',
'Fallback only when name is empty; cosmetic skin loan avoids anatomical balat; existing nonempty names retained.'
]
assert len(a)==len(r)==31 and set(a)==set(s['entries'])
ctx=['platform/apps/web/src/pages/music-studio/ideas.ts','platform/apps/web/src/messages.ts','platform/apps/web/src/music/Library.tsx','platform/apps/web/src/admin/Overview.tsx','platform/apps/web/src/skins/labels.ts','platform/apps/web/src/skins/SkinLibrary.tsx','platform/apps/web/src/pages/Skins.tsx','platform/apps/web/src/pages/music-studio/Workspace.tsx','platform/apps/web/src/pages/studio/StudioWorkspace.tsx','platform/apps/web/src/pages/TerrainStudio.tsx']
record={'reviewer':'/root/meaning_reviewer','stage':'independent first meaning review; all31 actual source/author pairs read','source_revision':s['merge_revision'],'source_program_sha256':s['source_sha256'],'source_snapshot_sha256':h((p/'source.json').read_bytes()),'author_target_snapshot_sha256':h((p/'author-final.json').read_bytes()),'reviewed_ids':['online:'+k for k in a],'entries':[{'id':'online:'+k,'source':s['entries'][k],'source_value_sha256':h(s['entries'][k].encode()),'target':v,'target_value_sha256':h(v.encode()),'status':'approved','rationale':why} for (k,v),why in zip(a.items(),r)],'findings':[],'unresolved_major':0,'unresolved_critical':0,'unresolved_uncertainty':[],'accepted_english':[],'context_files_sha256':{f:h(pathlib.Path(f).read_bytes()) for f in ctx},'context_scope':'Actual relevant excerpts and complete ideas.ts; whole-file hashes bind context, not a claim of whole-file code review. Spanish and Indonesian camera/static/music/preset labels and existing Filipino credit/mood terms consulted. Fixed presets handled separately from design names; preset-only SkinLibrary branch directly read.','intentional_english_terms':{'pose':'Established animation/editor pose term, not standing-only.','account':'Existing online account terminology.','soundtrack':'Named music product consistent with existing UI.','chat':'Existing online action loan; eligible conversation may be free.','save':'Existing save action loan used with Filipino aspect affixes.','mood':'Three established music mood variants; individual names translated.','bassoon':'Exact musical instrument, distinct from bass register.','synth pad':'Specific sustained electronic timbre; descriptive Filipino modifier avoids geometry.','waltz':'Specific musical dance form; genre retained.','folk':'Musical genre descriptor.','recorder':'Specific flute-like instrument, explicitly disambiguated by plawtang.','kalimba':'Named musical instrument.','Skin':'Established cosmetic product loan, avoids anatomical reading.'},'limits':['Exactly31 new entries read; no fresh reread of prior6359 entries claimed.','Agent-reviewed meaning pass; no native-speaker or runtime visual approval claimed.','No tracked edits or paid requests by reviewer.']}
(p/'meaning-review.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(record['author_target_snapshot_sha256'],len(record['entries']))
