"""Assemble only after all31 direct stage records and final committed sources exist.
Artifact-only; no approval inference and no tracked file mutation. Not a test runner.
"""
from pathlib import Path
import copy,hashlib,importlib.util,json,shutil,subprocess
R=Path.cwd();K=R/'artifacts/filipino-localization';O=K/'final-kit5';F=K/'final-kit6';D=K/'master-delta6'
spec=importlib.util.spec_from_file_location('T',R/'tools/localization/translation_program.py');T=importlib.util.module_from_spec(spec);spec.loader.exec_module(T)
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();textsha=lambda t:hashlib.sha256(t.encode()).hexdigest();write=T.write_json
assert not F.exists(),'Refuse existing kit6'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True),'Require final clean committed source'
source_delta=read(D/'source.json')['entries'];author=read(D/'author-final.json');final=read(D/'final.json');assert len(final)==31 and set(final)==set(author)==set(source_delta)
ids=['online:'+key for key in source_delta]
roles=[('author-review.json','/root/draft_editor',author),('meaning-review.json','/root/meaning_reviewer',author),('editor-review.json','/root/language_editor',final),('meaning-final-review.json','/root/meaning_reviewer',final),('adversarial-review.json','/root/adversarial_reviewer',final)]
# Validate every direct entry rather than accepting a blanket stage envelope.
records={}
def target_value(entry):
 for name in ['author_final','final_value','target','final_target','translation']:
  if isinstance(entry.get(name),str):return entry[name]
 raise AssertionError('Missing direct target value: '+str(entry.get('id')))
def target_hash(entry):
 for name in ['final_value_sha256','target_value_sha256','final_target_sha256','target_sha256']:
  if isinstance(entry.get(name),str):return entry[name]
 raise AssertionError('Missing direct target hash: '+str(entry.get('id')))
for name,identity,stage in roles:
 v=read(D/name);assert v.get('identity',v.get('reviewer'))==identity,name
 entries=v.get('entries',[]);assert len(entries)==31 and {e['id'] for e in entries}==set(ids),name
 for e in entries:
  key=e['id'].split(':',1)[1];assert e['source']==source_delta[key] and e['source_value_sha256']==textsha(source_delta[key]),(name,key,'source')
  assert target_value(e)==stage[key] and target_hash(e)==textsha(stage[key]),(name,key,'stage target')
 if name in ['meaning-final-review.json','adversarial-review.json']:
  assert not v.get('unresolved_uncertainty'),name
  for e in entries:assert 'approv' in str(e.get('status','')).lower(),(name,e['id'],'not individually approved')
  for finding in v.get('findings',[]):assert finding.get('state',finding.get('status')) in ['resolved','closed','approved'],(name,'open finding')
 records[name]=v
keys,native,online,files,source=T.sources(R);oldmanifest=read(O/'manifest.json');oldsource=read(O/'source/online.json');oldnative=read(O/'source/native.json');oldtarget=read(O/'drafts/fil/online.json');oldnativetarget=read(O/'drafts/fil/native.json');target=read(R/'platform/packages/i18n/locales/fil.json');nativetarget,errors=T.CHECKER.read_table(R/'data/texts.fil.txt')
assert not errors and native==oldnative and nativetarget==oldnativetarget
assert sha(R/'data/texts.fil.txt')=='287f03d772739957b96fc86ddc7fcc7073e4580436dd63fd2078ab1137d42827'
assert target==dict(oldtarget,**final) and online==dict(oldsource,**source_delta)
assert len(native)==3412 and len(online)==2978 and source=='013211b6f2bee9da8f4e9bb990d49fb18c99fedec710ed23603d12875f0960c5'
assert len(oldmanifest['batches'])==48
assert all(files[p]==oldmanifest['source_files'][p] for p in T.SOURCE_PATHS if p!='platform/packages/i18n/locales/en.json')
oldofficial=read(O/'reviews/fil.json');assert sha(O/'drafts/fil/texts.fil.txt')==oldofficial['catalog_sha256']['native'];assert sha(O/'drafts/fil/fil.json')==oldofficial['catalog_sha256']['online']
# Check all prerequisites before copying; preserve original kit5 and all stage files.
shutil.copytree(O,F,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));shutil.copytree(D,F/'master-delta6');B=F/'master-delta6/before';B.mkdir()
for src,name in [(F/'manifest.json','manifest.json'),(F/'source/online.json','source-online.json'),(F/'drafts/fil/online.json','target-online.json'),(F/'drafts/fil/fil.json','target-online-catalog.json'),(F/'reviews/fil.json','official.json'),(F/'reviews/fil-provenance.json','provenance.json')]:shutil.copyfile(src,B/name)
def ev(p):return {'path':str(p.relative_to(F)),'sha256':sha(p)}
manifest=copy.deepcopy(oldmanifest);bid='online-master-delta-006';manifest.update(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_sha256=source,source_files=files,native_keys=len(native),online_keys=len(online));manifest['batches'].append({'id':bid,'path':'batches/'+bid+'.json','keys':ids});write(F/'manifest.json',manifest);write(F/'source/online.json',online)
for batch in oldmanifest['batches']:
 p=F/batch['path'];v=read(p);v['source_sha256']=source;v['source_carry_forward']='master-delta6/source-target-carry.json';write(p,v)
write(F/'batches'/(bid+'.json'),{'id':bid,'source_sha256':source,'surface':'online','domain':'online','context':'Skin studio view angles, static poses and colony patterns; music metadata and built-in editable starter examples; admin charts; generation eligibility and credit delivery contracts. Preserve existing authored user content, application identifiers and numerical rules.','entries':[{'id':'online:'+key,'key':key,'source':source_delta[key]} for key in source_delta]})
write(F/'drafts/fil/online.json',target);shutil.copyfile(R/'platform/packages/i18n/locales/fil.json',F/'drafts/fil/fil.json');paths=T.catalog_paths(F,'fil');hashes={s:sha(p) for s,p in paths.items()};meta=read(F/'drafts/fil/metadata.json');meta.update(source_sha256=source,source_revision=manifest['revision'],catalog_sha256=hashes);write(F/'drafts/fil/metadata.json',meta)
rolefiles=[v[0] for v in roles];changes=[key for key in final if final[key]!=author[key]]
proof={'scope':'All6359 previous source/target values unchanged exactly:3412native+2947online. New31online entries have direct five-stage records from four distinct identities. Actual author/final changes recorded individually; no fresh whole-catalog read claimed.','source_before_sha256':oldmanifest['source_sha256'],'source_after_sha256':source,'catalog_before_sha256':oldofficial['catalog_sha256'],'catalog_after_sha256':hashes,'unchanged_native_ids':['native:'+key for key in native],'unchanged_online_ids':['online:'+key for key in oldsource],'added_ids':ids,'author_stage_sha256':sha(F/'master-delta6/author-final.json'),'final_stage_sha256':sha(F/'master-delta6/final.json'),'actual_editorial_changed_ids':['online:'+key for key in changes],'stage_values':[{'id':'online:'+key,'source_sha256':textsha(source_delta[key]),'author_sha256':textsha(author[key]),'final_sha256':textsha(final[key]),'author':author[key],'final':final[key],'edited_after_author':key in changes} for key in final],'before_evidence':[ev(B/n) for n in ['manifest.json','source-online.json','target-online.json','target-online-catalog.json','official.json','provenance.json']],'direct_reviews':[ev(F/'master-delta6'/n) for n in rolefiles]};write(F/'master-delta6/source-target-carry.json',proof)
record=read(F/'reviews/fil.json');prov=read(F/'reviews/fil-provenance.json');targets=T.batch_target_hashes(manifest,paths)
for batch in record['batches']:
 assert batch['target_sha256']==targets[batch['id']],'Existing48batch target hash changed'
 batch['source_sha256']=source;batch.setdefault('provenance',{})['online_delta6_source_carry']=ev(F/'master-delta6/source-target-carry.json')
record['batches'].append({'id':bid,'source_sha256':source,'target_sha256':targets[bid],'author':'/root/draft_editor','reviewer':'/root/meaning_reviewer','editor':'/root/language_editor','rechecked_by':'/root/meaning_reviewer','adversarial_reviewer':'/root/adversarial_reviewer','reviewed_keys':ids,'edited_keys':ids,'rechecked_keys':ids,'adversarial_reviewed_keys':ids,'provenance':{'scope':'edited_keys means actual complete editorial-pass coverage; exact changed subset and all31individual stage hashes are separately recorded.','source_carry':ev(F/'master-delta6/source-target-carry.json'),'direct_reviews':[ev(F/'master-delta6'/n) for n in rolefiles]}})
# Accept new source-equal exceptions only if individually justified in direct final records.
checked=T.check_draft(F,'fil');assert not checked['errors'] and not checked['untranslated'];accepted={v['key']:v for v in record.get('accepted_english',[])}
for name in ['editor-review.json','meaning-final-review.json','adversarial-review.json']:
 for v in records[name].get('accepted_english',[]):
  key=v.get('key',v.get('id'));reason=v.get('reason',v.get('rationale'));assert key in ids and isinstance(reason,str) and reason.strip();accepted[key]={'key':key,'reason':reason,'direct_stage':name}
queue=set(checked['same_as_english_review_queue']);assert queue<=set(accepted),'New English-equal entry lacks individual rationale';record['accepted_english']=[accepted[key] for key in accepted if key in queue]
prov.update(source_sha256=source,catalog_sha256=hashes);prov.setdefault('role_evidence',[]).extend(ev(F/'master-delta6'/n) for n in rolefiles);prov.setdefault('post_review_deltas',[]).append(ev(F/'master-delta6/source-target-carry.json'));prov['method']+='31new online master keys received five direct stage reads by four identities; previous6359values carried by exact source/target equality.';write(F/'reviews/fil-provenance.json',prov);record.update(source_sha256=source,catalog_sha256=hashes,provenance=ev(F/'reviews/fil-provenance.json'))
assert len(record['gates'])==9
for gate in record['gates'].values():gate['passed']=False;gate['invalidated_by']='Master0a5d4f68 Tamil extraction and31newonline keys require refreshed source, website, browser, asset and rendering evidence. Prior matrix/screens/runtime receipts preserve actual producers and may carry only exact unaffected inputs. No gate approval inferred by assembly.'
write(F/'reviews/fil.json',record);write(F/'reviews/fil-pre-runtime-gates.json',record);rows=len(native)+sum(len(v) if isinstance(v,dict) else 1 for v in online.values());assert len(manifest['batches'])==49 and len(native)+len(online)==6390 and rows==6417
print(json.dumps({'source':source,'hashes':hashes,'keys':6390,'variants':rows,'matrix_samples_expected':rows*9,'batches':49,'actual_after_author_changed':len(changes),'gates_invalidated':9}))
