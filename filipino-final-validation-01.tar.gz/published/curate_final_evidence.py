#!/usr/bin/env python3
"""Prepare bounded final evidence from explicit plan; never publishes or changes reviews."""
from pathlib import Path,PurePosixPath
import argparse,gzip,hashlib,json,shutil,tarfile
ROOT=Path(__file__).resolve().parents[3];K=ROOT/'artifacts/filipino-localization';PUB=K/'published'
BASE_TREES=['source','batches','google','author','editor','linguistic','adversary','reviews','drafts','final-kit','master-delta','final-kit2','master-delta2','final-kit3','master-delta3','final-kit4','master-delta4','final-kit5','master-delta5','final-kit6','master-delta6']
FORBIDDEN={'.git','node_modules','__pycache__','profile','profiles','trace','traces','cache','caches','bin','lib','include','runtime-assets','assets','db','database','build'}
EXTENSIONS=('.json','.jsonl','.txt','.md','.log','.log.gz','.json.gz','.jsonl.gz','.txt.gz','.xml','.png','.diff','.py','.sh','.cpp','.h','.ts','.tsx')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def safe(p,reviewed_scripts=None):
 rel=p.relative_to(K);assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(K.resolve()),p
 assert not set(rel.parts)&FORBIDDEN and not any(x.endswith('-assets') for x in rel.parts),p
 assert p.name!='ROOT-STATE.json',p
 if not p.name.endswith(EXTENSIONS):
  assert p.suffix in {'.js','.mjs'} and reviewed_scripts is not None and str(rel) in reviewed_scripts,p
  assert p.stat().st_size<=128*1024 and sha(p)==reviewed_scripts[str(rel)],'Unreviewed or oversized capture script '+str(rel)
 assert p.stat().st_size<=60*1024**2,'Per-file60MiB bound exceeded: '+str(rel)
 return p

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('plan',type=Path);ap.add_argument('--build',action='store_true',help='Default only validates; explicitly build archive after all gate/evidence updates finish.');a=ap.parse_args();plan=json.loads(a.plan.read_text());files=set();omitted=[];reviewed_scripts={e['path']:e['sha256'] for e in plan.get('reviewed_scripts',[])}
 assert plan.get('final_receipts_frozen') is True,'Root must finish/freeze final evidence first'
 assert not plan.get('pending_gates') and not plan.get('unresolved_reference_discrepancies'), 'Pending gates or unresolved historical reference discrepancy'
 external=plan.get('external_archive_index');assert external, 'External archive reconciliation index required'
 external_path=K/external['path'];assert sha(external_path)==external['sha256'];external_data=json.loads(external_path.read_text());external_members=set()
 for archive in external_data['archives']:
  assert sha(K/archive['archive'])==archive['sha256'], 'External archive changed'
  external_members.update((e['kit_relative_path'],e['sha256']) for e in archive['entries'])
 existing_archives=[p for p in PUB.glob('*.tar.gz') if not p.name.startswith('filipino-final-validation')]
 assert sum(p.stat().st_size for p in existing_archives)+plan.get('archive_parts',3)*60*1024**2<=256*1024**2, '256MiB combined archive campaign bound'
 for name in BASE_TREES:
  root=K/name
  if name in {'final-kit4','master-delta4','final-kit5','master-delta5','final-kit6','master-delta6'} and not root.is_dir():
   assert plan.get('authoritative_kit','final-kit3') not in {name, name.replace('master-delta','final-kit')},root
   continue
  assert root.is_dir(),root
  for p in root.rglob('*'):
   if not p.is_file():continue
   rel=p.relative_to(K)
   if set(rel.parts)&FORBIDDEN or p.suffix in {'.pyc','.lock'} or p.name in {'ROOT-STATE.json','.lock'}:omitted.append(str(rel));continue
   p=safe(p,reviewed_scripts)
   if (str(rel),sha(p)) in external_members:omitted.append({'path':str(rel),'sha256':sha(p),'reason':'Exact bytes in pinned published archive index'});continue
   files.add(p)
 policy=plan.get('positive_png_omission_policy');assert policy, 'Explicit historical positive omission policy required'
 policy_path=K/policy['path'];assert sha(policy_path)==policy['sha256'];omissions=json.loads(policy_path.read_text())['omitted_superseded_positive_pngs'];omit_by_path={e['path']:e for e in omissions}
 for rel,e in omit_by_path.items():
  assert rel.endswith('.png') and all(word not in rel.lower() for word in ['failure','failed','error']), 'Negative image cannot be omitted'
  assert not any(token in rel for token in ['native-final-v8','final-web-v8','attempt-c35','desktop-c35','postgame-c35','native-test-artifacts']), 'Current image cannot be omitted'
  assert sha(K/rel)==e['sha256'], 'Omitted historical source changed'
  for proof in e['superseded_by']:assert sha(K/proof['path'])==proof['sha256'], 'Superseding proof changed'
 files={p for p in files if str(p.relative_to(K)) not in omit_by_path}
 omitted.extend(omissions)
 for e in plan['extra_files']:
  rel=PurePosixPath(e['path']);assert not rel.is_absolute() and '..' not in rel.parts
  p=safe(K/str(rel),reviewed_scripts);assert sha(p)==e['sha256'],'Pinned final evidence changed '+str(rel)
  if str(rel) not in omit_by_path:files.add(p)
 assert 1<=len(files)<=5000,'File count bound'
 total=sum(p.stat().st_size for p in files);unique_payload={}
 for p in sorted(files):unique_payload.setdefault((sha(p),p.stat().st_size),p)
 unique_bytes=sum(size for digest,size in unique_payload)
 assert unique_bytes<=512*1024**2 and total<=768*1024**2,'512MiB unique physical payload /768MiB logical-path bound'

 assert shutil.disk_usage(PUB).free>2*total+60*1024**2,'Insufficient campaign free space'
 # Pin aggregate reviews and final evidence before reading payload bytes. No implicit signoff.
 for e in plan['frozen_receipts']:
  p=K/e['path'];assert sha(p)==e['sha256'],'Frozen receipt changed '+e['path']
 entries=[{'path':str(p.relative_to(K)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
 summary={'mode':'build' if a.build else 'validate-only','files':len(entries),'payload_bytes':total,'unique_payload_bytes':unique_bytes,'logical_payload_limit_bytes':768*1024**2,'deduplication':'Exact SHA256+size duplicate members are regular tar hardlinks to an earlier included member; all kit-relative paths remain extractable.','plan_sha256':sha(a.plan),'archive_limit_bytes':60*1024**2,'uncompressed_limit_bytes':512*1024**2}
 if not a.build:print(json.dumps(summary));return
 # Assign complete identical-payload groups to one part, so no hardlink crosses archives.
 groups={}
 for e in entries:groups.setdefault((e['sha256'],e['bytes']),[]).append(e)
 parts=plan.get('archive_parts',3);assert parts==3
 loads=[0]*parts;part_entries=[[] for _ in range(parts)]
 for identity,group in sorted(groups.items(),key=lambda item:(-item[0][1],item[0][0])):
  sample=K/group[0]['path'];data=sample.read_bytes()
  weight=len(data) if sample.suffix in {'.png','.gz'} else len(gzip.compress(data,compresslevel=1,mtime=0))
  part=min(range(parts),key=lambda i:loads[i]);loads[part]+=weight;part_entries[part].extend(group)
 preflight={'part_compressed_weight_estimates':loads,'per_part_preflight_limit_bytes':58*1024**2,'per_part_hard_limit_bytes':60*1024**2,'part_count':parts,'passed':all(n<=58*1024**2 for n in loads),'method':'Exact PNG/gzip sizes, gzip level1 estimate for each unique text payload; whole SHA+size groups stay in one bin. 2MiB perpart tar/gzip margin.'}
 assert preflight['passed'], 'Preflight exceeds58MiB; no archive written'
 preflight_path=PUB/'final-archive-weight-preflight.json';assert not preflight_path.exists();preflight_path.write_text(json.dumps(preflight,indent=2)+'\n')
 archives=[];created=[]
 try:
  for number,selection in enumerate(part_entries,1):
   selection.sort(key=lambda e:e['path']);archive=PUB/f'filipino-final-validation-{number:02d}.tar.gz';assert not archive.exists(),'Refuse to overwrite frozen archive'
   created.append(archive)
   with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=6,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    written_payload={}
    for e in selection:
     p=K/e['path'];assert sha(p)==e['sha256'],'Evidence changed during archive '+e['path']
     info=tar.gettarinfo(str(p),arcname=e['path']);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
     identity=(e['sha256'],e['bytes'])
     if identity in written_payload:
      info.type=tarfile.LNKTYPE;info.linkname=written_payload[identity];info.size=0;tar.addfile(info)
     else:
      with p.open('rb') as f:tar.addfile(info,f)
      written_payload[identity]=e['path']
     assert raw.tell()<=60*1024**2,'Compressed60MiB part bound exceeded'
   assert archive.stat().st_size<=60*1024**2,'Compressed60MiB part bound exceeded'
   with tarfile.open(archive,'r|gz') as tar:
    seen={};count=0
    for member in tar:
     assert count<len(selection),'Unexpected extra archive member'
     e=selection[count];assert member.name==e['path'],'Archive path mismatch'
     if member.isfile():
      assert member.size==e['bytes'],'Archive payload size mismatch'
      payload=tar.extractfile(member);digest=hashlib.sha256();actual_bytes=0
      while True:
       chunk=payload.read(1024*1024)
       if not chunk:break
       digest.update(chunk);actual_bytes+=len(chunk)
      assert actual_bytes==e['bytes'] and digest.hexdigest()==e['sha256'],'Extraction hash mismatch'
     else:
      assert member.islnk() and member.size==0 and member.linkname in seen,'Unsafe archive hardlink'
      assert seen[member.linkname]==(e['sha256'],e['bytes']),'Hardlink payload mismatch'
     seen[member.name]=(e['sha256'],e['bytes']);count+=1
    assert count==len(selection),'Missing archive member'
   for e in selection:e['archive']=archive.name
   archives.append({'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(selection),'sequential_extraction_hash_verification':'passed for every regular payload and safe earlier same-size/SHA hardlink'})
  assert sum(a['members'] for a in archives)==len(entries) and len({e['path'] for e in entries})==len(entries),'Global archive coverage mismatch'
  assert sum(p.stat().st_size for p in existing_archives)+sum(a['bytes'] for a in archives)<=256*1024**2,'256MiB combined archive campaign bound'
  for e in plan['frozen_receipts']:assert sha(K/e['path'])==e['sha256'],'Frozen receipt changed during archive'
 except BaseException:
  for archive in created:archive.unlink(missing_ok=True)
  raise
 manifest=dict(summary,archives=archives,archive_layout='Three bounded independent tar.gz parts. Extract all three into the same kit directory; no cross-part hardlinks.',weight_preflight=preflight,compressed_campaign_limit_bytes=256*1024**2,positive_png_omission_policy=policy,archive_bytes=sum(a['bytes'] for a in archives),kit_relative_paths=True,entries=entries,omitted_excluded_paths=omitted,authoritative_kit=plan.get('authoritative_kit'),inventory=plan.get('inventory'),compressed_historical_payloads=plan.get('compressed_historical_payloads',[]),excluded_hash_references=plan.get('excluded_hash_references',[]),external_archive_index=external,externally_archived_exact_payloads=plan.get('externally_archived_exact_payloads',[]),frozen_receipts=plan['frozen_receipts'],curator_sha256=sha(Path(__file__)),scope=plan['scope'],limits=plan['limits'])
 (PUB/'final-validation-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'archives':archives,'files':len(entries),'combined_final_bytes':manifest['archive_bytes']}))
if __name__=='__main__':main()
