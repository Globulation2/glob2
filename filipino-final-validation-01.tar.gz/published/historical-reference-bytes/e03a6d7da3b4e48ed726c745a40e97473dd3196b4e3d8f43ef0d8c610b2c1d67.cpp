#include "tutorial/TutorialGuidance.h"
#include "hive/HiveDialog.h"
#include "render/scene/SceneExtract.h"
#include "render/UnitMotion.h"
#include <RenderStateScope.h>
#include <PerformanceTelemetry.h>
#include "MapZoomControls.h"
#include "ConnectionOverlay.h"
#include "DynamicClouds.h"
// SPDX-License-Identifier: GPL-3.0-or-later
#include "InGameStatistics.h"
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#include "../render/MapCopies.h"
#include <iostream>
#include <algorithm>
#include <cmath>

#include <ApplicationHost.h>
#include <FormatableString.h>
#include <StringTable.h>
#include <Toolkit.h>

#include "Game.h"
#include "GameGUI.h"
#include "IntBuildingType.h"
#include "TeamStatChart.h"
#include "GameGUITouch.h"
#include "HudUnitConversionIcon.h"
#include "GameGUIInternal.h"
#include "GlobalContainer.h"
#include "PanelButtonHit.h"
#include "Player.h"
#include "ReplayReader.h"
#include "SoundMixer.h"
#include "TeamDisplay.h"
#include "Unit.h"
#include "VoiceRecorder.h"

void GameGUI::drawPanelButtons(int y)
{
	if (!globalContainer->isViewingGame())
	{
		if (!(hiddenGUIElements & HIDABLE_BUILDINGS_LIST))
		{
			if (((selectionMode==NO_SELECTION) || (selectionMode==TOOL_SELECTION)) && (displayMode==CONSTRUCTION_VIEW))
				drawPanelButton(y, 0, NB_VIEWS, 1);
			else
				drawPanelButton(y, 0, NB_VIEWS, 0);
		}

		if (!(hiddenGUIElements & HIDABLE_FLAGS_LIST))
		{
			if (((selectionMode==NO_SELECTION) || (selectionMode==TOOL_SELECTION) || (selectionMode==BRUSH_SELECTION)) && (displayMode==FLAG_VIEW))
				drawPanelButton(y, 1, NB_VIEWS, 29);
			else
				drawPanelButton(y, 1, NB_VIEWS, 28);
		}

		if (!(hiddenGUIElements & HIDABLE_TEXT_STAT))
		{
			if ((selectionMode==NO_SELECTION) && (displayMode==STAT_TEXT_VIEW))
				drawPanelButton(y, 2, NB_VIEWS, 3);
			else
				drawPanelButton(y, 2, NB_VIEWS, 2);
		}

		if (!(hiddenGUIElements & HIDABLE_GFX_STAT))
		{
			if ((selectionMode==NO_SELECTION) && (displayMode==STAT_GRAPH_VIEW))
				drawPanelButton(y, 3, NB_VIEWS, 5);
			else
				drawPanelButton(y, 3, NB_VIEWS, 4);
		}
	}
	else
	{
		if (replayDisplayMode==RDM_REPLAY_VIEW)
			drawPanelButton(y, 0, RDM_NB_VIEWS, 48);
		else
			drawPanelButton(y, 0, RDM_NB_VIEWS, 49);

		if (replayDisplayMode==RDM_STAT_TEXT_VIEW)
			drawPanelButton(y, 1, RDM_NB_VIEWS, 3);
		else
			drawPanelButton(y, 1, RDM_NB_VIEWS, 2);

		if (replayDisplayMode==RDM_STAT_GRAPH_VIEW)
			drawPanelButton(y, 2, RDM_NB_VIEWS, 5);
		else
			drawPanelButton(y, 2, RDM_NB_VIEWS, 4);
	}

	if(highlights.find(HighlightUnderMinimapIcon) != highlights.end())
	{
		arrowPositions.push_back(HighlightArrowPosition(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH-36, y, 38));
	}
}

void GameGUI::drawPanelButton(int y, int pos, int numButtons, int sprite)
{
	int dec = (RIGHT_MENU_WIDTH - numButtons*PANEL_BUTTON_WIDTH)/2;

    const int x = globalContainer->gfx->getW()-RIGHT_MENU_WIDTH + dec + pos*PANEL_BUTTON_WIDTH;
    globalContainer->gfx->drawSprite(x, y, globalContainer->gamegui, sprite);
    if (sprite == 4 || sprite == 5) {
        // Retain the classic button ring, replacing its obsolete graph glyph.
        const auto &theme = Glob2UI::inGameTheme();
        GAGGUI::ui::SurfaceCanvas canvas(*globalContainer->gfx, theme,
            GAGGUI::ui::resolvePresentation(*globalContainer->gfx, theme.touchTextScale));
        canvas.fillRounded({x + 5, y + 5, 22, 22}, 11, theme.palette.panel);
        canvas.drawIcon({x + 7, y + 7, 18, 18}, *Glob2UI::uiIcon(Glob2UI::UIIcon::Map), theme.palette.ink);
    }
}

void GameGUI::drawValueAlignedRight(int y, int v)
{
	FormattableString s("%0");
	s.arg(v);
	int len = globalContainer->littleFont->getStringWidth(s.c_str());
	globalContainer->gfx->drawString(globalContainer->gfx->getW()-len-2, y, globalContainer->littleFont, s.c_str());
}

void GameGUI::drawCosts(const int materials[MaterialCount], Font *font, int& ypos)
{
	int shown=0;
	for (unsigned i=0; i<MaterialCount; i++)
	{
		if (i>=8 && (!materials[i] || !drawnScene().materialVisible(i))) continue;
		globalContainer->gfx->drawString(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH+4+(shown&1)*64, ypos+(shown/2)*12,
			font, FormattableString("%0: %1").arg(getMaterialName(i)).arg(materials[i]).c_str());
		++shown;
	}
	ypos += ((shown+1)/2)*12;
}

void GameGUI::drawCheckButton(int x, int y, std::string caption, bool isSet)
{
	globalContainer->gfx->drawRect(x, y, 16, 16, Color::white);
	if(isSet)
	{
		globalContainer->gfx->drawLine(x+4, y+4, x+12, y+12, Color::white);
		globalContainer->gfx->drawLine(x+12, y+4, x+4, y+12, Color::white);
	}
	globalContainer->gfx->drawString(x+20, y, globalContainer->littleFont, caption);
}


void GameGUI::drawRadioButton(int x, int y, bool isSet)
{
	if(isSet)
	{
		globalContainer->gfx->drawSprite(x, y, globalContainer->gamegui, 20);
	}
	else
	{
		globalContainer->gfx->drawSprite(x, y, globalContainer->gamegui, 19);
	}
}

void GameGUI::drawPanel(void)
{
	PERF_SCOPE_TIME(Panel);
	// ensure we have a valid selection and associate pointers (with a simulation
	// thread, threadedClientStep checks the immutable PresentationFrame)
	if (!simulationThreaded)
		checkSelection();

	// set the clipping rectangle
	globalContainer->gfx->setClipRect(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH, 128, RIGHT_MENU_WIDTH, globalContainer->gfx->getH()-128);

	// Draw the selected panel background.
	if (!globalContainer->settings.translucentPanels)
		globalContainer->gfx->drawFilledRect(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH, 133, RIGHT_MENU_WIDTH, globalContainer->gfx->getH()-128, 0, 0, 0);
	else
		globalContainer->gfx->drawFilledRect(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH, 133, RIGHT_MENU_WIDTH, globalContainer->gfx->getH()-128, 0, 0, 40, 180);

	if(highlights.find(HighlightRightSidePanel) != highlights.end())
	{
		arrowPositions.push_back(HighlightArrowPosition(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH-36, globalContainer->gfx->getH()/2, 38));
	}

	// draw the panel selection buttons
	drawPanelButtons(YPOS_BASE_DEFAULT-32);

	dispatchSelectionPanel();
}

void GameGUI::dispatchSelectionPanel(void)
{
	switch(selectionMode)
	{
	case BUILDING_SELECTION:
		drawBuildingInfos();
		break;
	case UNIT_SELECTION:
		drawUnitInfos();
		break;
	case RESOURCE_SELECTION:
		drawResourceInfos();
		break;
	default:
		if (!globalContainer->isViewingGame())
			dispatchDisplayModePanel();
		else
			dispatchReplayDisplayModePanel();
		break;
	}
}

void GameGUI::dispatchDisplayModePanel(void)
{
	switch(displayMode)
	{
	case CONSTRUCTION_VIEW:
		drawChoice(YPOS_BASE_CONSTRUCTION, buildingsChoiceName, buildingsChoiceState);
		break;
	case FLAG_VIEW:
		drawFlagView();
		break;
	case STAT_TEXT_VIEW:
		drawStatisticsPage(YPOS_BASE_STAT);
		break;
	case STAT_GRAPH_VIEW:
		drawTextCenter(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH, YPOS_BASE_STAT, "[stats map overlays]");
		drawCheckButton(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH+8, YPOS_BASE_STAT+28, Toolkit::getStringTable()->getString("[Starving Map]"), showStarvingMap);
		drawCheckButton(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH+8, YPOS_BASE_STAT+52, Toolkit::getStringTable()->getString("[Damaged Map]"), showDamagedMap);
		drawCheckButton(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH+8, YPOS_BASE_STAT+76, Toolkit::getStringTable()->getString("[Defense Map]"), showDefenseMap);
		drawCheckButton(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH+8, YPOS_BASE_STAT+100, Toolkit::getStringTable()->getString("[Fertility Map]"), showFertilityMap);
		break;
	default:
		std::cout << "Was not expecting displayMode" << displayMode;
		assert(false);
	}
}

void GameGUI::dispatchReplayDisplayModePanel(void)
{
	switch(replayDisplayMode)
	{
	case RDM_REPLAY_VIEW:
		drawReplayPanel();
		break;
	case RDM_STAT_TEXT_VIEW:
        drawStatisticsPage(YPOS_BASE_STAT);
		break;
	case RDM_STAT_GRAPH_VIEW:
		globalContainer->gfx->drawString(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH+15, YPOS_BASE_STAT+5, globalContainer->littleFont, FormattableString("%0 %1").arg(Toolkit::getStringTable()->getString("[watching:]")).arg(displayPlayerName(*localTeam)).c_str());
		drawTextCenter(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH, YPOS_BASE_STAT+15, "[stats map overlays]");
		drawCheckButton(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH+8, YPOS_BASE_STAT+43, Toolkit::getStringTable()->getString("[Starving Map]"), showStarvingMap);
		drawCheckButton(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH+8, YPOS_BASE_STAT+67, Toolkit::getStringTable()->getString("[Damaged Map]"), showDamagedMap);
		drawCheckButton(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH+8, YPOS_BASE_STAT+91, Toolkit::getStringTable()->getString("[Defense Map]"), showDefenseMap);
		drawCheckButton(globalContainer->gfx->getW()-RIGHT_MENU_WIDTH+8, YPOS_BASE_STAT+115, Toolkit::getStringTable()->getString("[Fertility Map]"), showFertilityMap);
		break;
	default:
		std::cout << "Was not expecting replayDisplayMode" << replayDisplayMode;
		assert(false);
	}
}

GameGUI::TopBarLayout GameGUI::topBarLayout() const
{
	TopBarLayout layout;
	for (int i = 0; i < 3; ++i)
		layout.values[i] = std::to_string(teamStats->getFreeUnits(i) -
			(i == 0 ? teamStats->getWorkersNeeded() : 0)) + "/" +
			std::to_string(teamStats->getTotalUnits(i));
	const auto &colony = drawnScene().panels.local.state();
	layout.values[3] = std::to_string(colony.prestige);
	layout.values[4] = std::to_string(colony.unitConversionGained);
	layout.values[5] = std::to_string(colony.unitConversionLost);
	const auto rate = tickRate.rate();
	layout.values[6] = rate ? TickRateMeter::format(*rate) : "-";
	// Measure complete icon/value groups. Keep real gutters even when large
	// counters require the compact bar's contents to shrink to fit.
	auto *font = globalContainer->littleFont;
	std::array<double, 7> widths;
	double total = 0;
	for (int i = 0; i < 7; ++i)
	{
		const double icon = i < 4 ? 16 : i < 6 ? 36 : 0;
		const double text = i == 6 ? std::max(font->getStringWidth(layout.values[i]),
			font->getStringWidth("999.9")) : font->getStringWidth(layout.values[i]);
		widths[i] = icon + (icon ? 6 : 0) + text;
		total += widths[i];
	}
	const double speed = canChangeGameSpeed() ? TOP_BAR_SPEED_WIDTH : 0;
	const double available = globalContainer->gfx->getW() - RIGHT_MENU_WIDTH - 20;
	constexpr double gutter = 14;
	layout.scale = std::clamp((available - 6 * gutter - speed) / total, .1, 1.);
	double x = 10 + std::max(0., (available - total * layout.scale - 6 * gutter - speed) / 2);
	for (int i = 0; i < 7; ++i)
	{
		layout.x[i] = std::round(x);
		x += widths[i] * layout.scale + gutter;
	}
	return layout;
}

int GameGUI::topBarSpeedX() const
{
	return int(topBarLayout().x[6]);
}

void GameGUI::drawTopScreenBar(void)
{
    if (touch->usesHUD()) return;
	// bar background
	if (!globalContainer->settings.translucentPanels)
		globalContainer->gfx->drawFilledRect(0, 0, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH, 16, 0, 0, 0);
	else
		globalContainer->gfx->drawFilledRect(0, 0, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH, 16, 0, 0, 40, 180);

	// draw unit stats
	Uint8 redC[]={200, 0, 0};
	Uint8 greenC[]={0, 200, 0};
	Uint8 whiteC[]={200, 200, 200};
	Uint8 yellowC[]={200, 200, 0};
	Uint8 actC[3];
	int free;

	const auto layout = topBarLayout();
	auto *gfx = globalContainer->gfx;
	auto *font = globalContainer->littleFont;
	const auto &colony = drawnScene().panels.local.state();
	const double scale = layout.scale;
	const auto drawValue = [&](int index, double x) {
		SDL_Rect clip{0, 0, gfx->getW() - RIGHT_MENU_WIDTH, 16};
		gfx->setUITransform(scale, x, (16 - font->getStringHeight("Ag") * scale) / 2, &clip);
		gfx->drawString(0, 0, font, layout.values[index]);
		gfx->setUITransform(); gfx->setClipRect();
	};
	int dec;

	globalContainer->unitmini->setBaseColor(presentationColor(drawnScene().panels.local.state().color));
	for (int i=0; i<3; i++)
	{
		dec = int(layout.x[i]);
		free = teamStats->getFreeUnits(i);
		// worker is a special case
		if (i==0)
			free -= teamStats->getWorkersNeeded();
		if (free<0)
			memcpy(actC, redC, sizeof(redC));
		else if (free>0)
			memcpy(actC, greenC, sizeof(greenC));
		else
			memcpy(actC, whiteC, sizeof(whiteC));

		const double spriteScale = 16 * scale / std::max(globalContainer->unitmini->getW(i), globalContainer->unitmini->getH(i));
		SDL_Rect iconClip{dec, 0, int(std::ceil(16 * scale)), 16};
		gfx->setUITransform(spriteScale, dec + (16 * scale - globalContainer->unitmini->getW(i) * spriteScale) / 2,
			(16 - globalContainer->unitmini->getH(i) * spriteScale) / 2, &iconClip);
		gfx->drawSprite(0, 0, globalContainer->unitmini, i);
		gfx->setUITransform(); gfx->setClipRect();
		globalContainer->littleFont->pushStyle(Font::Style(Font::STYLE_NORMAL, actC[0], actC[1], actC[2]));
		drawValue(i, dec + 22 * scale);
		globalContainer->littleFont->popStyle();

		// Tutorial highlight arrow for this counter. The sprite, the free/total
		// counter, and the arrow position above all key off the unit-type index
		// i (WORKER=0, EXPLORER=1, WARRIOR=2 from UnitConsts.h); the matching
		// highlight id must too. This table keeps that pairing in one place so it
		// cannot be silently swapped. Indices follow the UnitConsts ordering,
		// NOT the Highlight* enum's numeric order (which lists explorer/warrior
		// the other way around), so the mapping is spelled out explicitly.
		static const int highlightForUnitType[3] = {
			HighlightWorkersWorkingFreeStat,   // i == WORKER
			HighlightExplorersWorkingFreeStat, // i == EXPLORER
			HighlightWarriorsWorkingFreeStat,  // i == WARRIOR
		};
		if(highlights.find(highlightForUnitType[i]) != highlights.end())
		{
			arrowPositions.push_back(HighlightArrowPosition(int(dec + 22 * scale), 32, 39));
		}

	}

	// Same primary prestige value and secondary victory progress as touch.
	touch->drawPrestigeIcon({layout.x[3] + 8 * scale, 8}, 16 * scale);
	drawValue(3, layout.x[3] + 22 * scale);
	const auto &match = drawnScene().panels.hud;
	if (match.state().prestigeWinCondition && match.state().prestigeToReach > 0)
	{
		const double width = (22 + font->getStringWidth(layout.values[3])) * scale;
		const double progress = std::clamp(double(match.totalPrestige()) / match.state().prestigeToReach, 0., 1.);
		gfx->drawFilledRect(int(layout.x[3]), 14, int(width), 2, Color(80, 70, 55));
		gfx->drawFilledRect(int(layout.x[3]), 14, int(width * progress), 2, Color(232, 194, 107));
	}
	for (int side = 0; side < 2; ++side)
	{
		const double x = layout.x[4 + side];
		unitConversionIcon->draw(gfx, globalContainer->unitmini,
			{x, (16 - 16 * scale) / 2, 36 * scale, 16 * scale}, presentationColor(colony.color), side == 0);
		drawValue(4 + side, x + 42 * scale);
	}

	// draw the speed control and the simulation tick rate
	dec = int(layout.x[6]);
	if (canChangeGameSpeed())
	{
		const int lit = litSpeedChevrons();
		for (int i=0; i<GameSpeedControl::CHEVRONS; i++)
		{
			const Color color = i<lit ? Color(0, 200, 0) : Color(80, 80, 80);
			for (int thickness=0; thickness<2; thickness++)
			{
				const int x = dec+i*TOP_BAR_CHEVRON_PITCH+thickness;
				globalContainer->gfx->drawLine(x, 3, x+4, 7, color);
				globalContainer->gfx->drawLine(x+4, 7, x, 11, color);
			}
		}
		dec += TOP_BAR_SPEED_WIDTH;
	}
	const int shortfall = tickRateShortfall();
	memcpy(actC, shortfall==0 ? whiteC : shortfall==1 ? yellowC : redC, sizeof(actC));
	globalContainer->littleFont->pushStyle(Font::Style(Font::STYLE_NORMAL, actC[0], actC[1], actC[2]));
	drawValue(6, dec);
	globalContainer->littleFont->popStyle();

	// draw window bar
	int pos=globalContainer->gfx->getW()-RIGHT_MENU_WIDTH-16;
	for (int i=0; i<pos; i+=32)
	{
		globalContainer->gfx->drawSprite(i, 16, globalContainer->gamegui, 16);
	}
	for (int i=16; i<globalContainer->gfx->getH(); i+=32)
	{
		globalContainer->gfx->drawSprite(pos+12, i, globalContainer->gamegui, 17);
	}


	int index;
	// draw main menu button
	if (inGameMenu == IGM_MAIN)
		index = 7;
	else
		index = 6;
	globalContainer->gfx->drawSprite(pos, IGM_MAIN_MENU_ICON_Y, globalContainer->gamegui, index);

	// draw alliance button
	if ( !(hiddenGUIElements & HIDABLE_ALLIANCE) )
	{
		if (inGameMenu == IGM_ALLIANCE)
			index = 44;
		else
			index = 45;
		globalContainer->gfx->drawSprite(pos, IGM_ALLIANCE_ICON_Y, globalContainer->gamegui, index);
	}

	// draw objectives button
	if (inGameMenu == IGM_OBJECTIVES)
		index = 46;
	else
		index = 47;
	globalContainer->gfx->drawSprite(pos, IGM_OBJECTIVES_ICON_Y, globalContainer->gamegui, index);

	if(highlights.find(HighlightMainMenuIcon) != highlights.end())
	{
		arrowPositions.push_back(HighlightArrowPosition(pos-32, 32, 43));
	}
}

void GameGUI::drawOverlayInfos(void)
{
	PERF_SCOPE_TIME(Overlay);
	if (!torusView.active())
	{
		updateCamera();
		GAGCore::MapTransformScope mapPass(*globalContainer->gfx, camera.zoom, camera.offsetX-camera.fractionX()*camera.zoom, camera.offsetY-camera.fractionY()*camera.zoom, SDL_Rect{int(camera.offsetX), std::max(16, int(camera.offsetY)), int(camera.visibleW()*camera.zoom), int(camera.visibleH()*camera.zoom)-std::max(0,16-int(camera.offsetY))});

		if (selectionMode==TOOL_SELECTION)
		{
			globalContainer->gfx->setClipRect(0, 0, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH, globalContainer->gfx->getH());
			globalContainer->gfx->drawMapCopies(drawnScene().map.getW()*32,drawnScene().map.getH()*32,drawnScene().map.viewportWidth(),drawnScene().map.viewportHeight(),[&](){ toolManager.drawTool(int(MapCamera::wrap(mapMouseX(mouseX),drawnScene().map.getW()*32)), int(MapCamera::wrap(mapMouseY(mouseY),drawnScene().map.getH()*32)), localTeamNo, viewportX, viewportY, inputState.modifiers()); });
		}
		// The phone HUD previews strokes as cells under the finger; its mouse
		// position is never updated by touch, so the hover cursor would be stale.
		else if (selectionMode==BRUSH_SELECTION && !touch->usesHUD())
		{
			globalContainer->gfx->setClipRect(0, 0, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH, globalContainer->gfx->getH());
			globalContainer->gfx->drawMapCopies(drawnScene().map.getW()*32,drawnScene().map.getH()*32,drawnScene().map.viewportWidth(),drawnScene().map.viewportHeight(),[&](){ toolManager.drawTool(int(MapCamera::wrap(mapMouseX(mouseX),drawnScene().map.getW()*32)), int(MapCamera::wrap(mapMouseY(mouseY),drawnScene().map.getH()*32)), localTeamNo, viewportX, viewportY, inputState.modifiers()); });
		}
		else if (selectionMode==BUILDING_SELECTION && drawnScene().panels.building.valid)
		{
			const SceneBuildingPanel* selBuild=&drawnScene().panels.building;
			const SceneMap &sceneMap = drawnScene().map;
			globalContainer->gfx->setClipRect(0, 0, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH, globalContainer->gfx->getH());
			int centerX, centerY;
			drawnScene().map.buildingPosToCursor(displayedPosX(*selBuild), displayedPosY(*selBuild),  selBuild->type->width, selBuild->type->height, &centerX, &centerY, viewportX, viewportY);
			const int radius = selBuild->type->width*16;
			forEachMapCopy(centerX-radius, centerY-radius, centerX+radius, centerY+radius,
				drawnScene().map.getW()*32, drawnScene().map.getH()*32, drawnScene().map.viewportWidth(),
				drawnScene().map.viewportHeight(), [&](int dx, int dy) {
				if (selBuild->owner().number==localTeamNo)
					globalContainer->gfx->drawCircle(centerX+dx, centerY+dy, selBuild->type->width*16, 0, 0, 190);
				else if ((drawnScene().panels.local.state().allies) & (selBuild->owner().mask))
					globalContainer->gfx->drawCircle(centerX+dx, centerY+dy, selBuild->type->width*16, 255, 196, 0);
				else if (!selBuild->type->isVirtual)
					globalContainer->gfx->drawCircle(centerX+dx, centerY+dy, selBuild->type->width*16, 190, 0, 0);
			});

			// draw a white circle around units that are working at building
			if ((showUnitWorkingToBuilding)
				&& ((selBuild->owner().allies) &(Team::teamNumberToMask(localTeamNo))))
			{
				for (UnitRef worker : drawnScene().entities.selectedBuilding.unitsWorking)
				{
					const SnapshotUnit *unit = drawnScene().entities.unit(worker.gid);
					if (!unit || unit->identity!=worker)
						continue;
					int px, py;
					sceneMap.mapCaseToDisplayable(unit->posX, unit->posY, &px, &py, viewportX, viewportY);
					int deltaLeft=255-drawnUnitDelta(*unit, view.render.unitMotion);
					if (unit->action<BUILD)
					{
						px-=(unit->dx*deltaLeft)>>3;
						py-=(unit->dy*deltaLeft)>>3;
					}
					forEachMapCopy(px, py, px+32, py+32, drawnScene().map.getW()*32, drawnScene().map.getH()*32,
						drawnScene().map.viewportWidth(), drawnScene().map.viewportHeight(), [&](int dx, int dy) {
							globalContainer->gfx->drawCircle(px+16+dx, py+16+dy, 16, 255, 255, 255, 180);
						});
				}
			}
		}
		else if (selectionMode==RESOURCE_SELECTION)
		{
			int resource = selectionResource();
			int rx = resource & drawnScene().map.getMaskW();
			int ry = resource >> drawnScene().map.getShiftW();
			int px, py;
			drawnScene().map.mapCaseToDisplayable(rx, ry, &px, &py, viewportX, viewportY);
			globalContainer->gfx->setClipRect(0, 0, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH, globalContainer->gfx->getH());
			forEachMapCopy(px, py, px+32, py+32, drawnScene().map.getW()*32, drawnScene().map.getH()*32,
				drawnScene().map.viewportWidth(), drawnScene().map.viewportHeight(), [&](int dx, int dy) {
					globalContainer->gfx->drawCircle(px+16+dx, py+16+dy, 16, 0, 0, 190);
				});
		}


	}
	// draw message List
	// Feed rows are clickable only where they were drawn this frame.
	eventFeedHits.clear();
	// Suppress the "[waiting for X]" notice until the wait has lasted longer
	// than this many GUI steps, so brief network hiccups don't flash the box.
	constexpr int WAIT_NOTICE_DEBOUNCE_STEPS = 2;
	const SceneHud &hud = drawnScene().panels.hud;
    const Uint32 waitingMask = clientEvents.waitingMask();
	// Turn games show every player's connection in the panel instead (ConnectionOverlay).
	const std::vector<std::string> connectionLines = connectionNotice && !connectionOverlay ? connectionNotice() : std::vector<std::string>();
	if (!connectionLines.empty())
	{
		// Same box as the waiting notice below, one line per connection state.
		const int lines = static_cast<int>(connectionLines.size());
		globalContainer->gfx->drawFilledRect(32, 32, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH-64, 22+lines*20, 0, 0, 140, 127);
		globalContainer->gfx->drawRect(32, 32, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH-64, 22+lines*20, 255, 255, 255);
		for (int i = 0; i < lines; ++i)
			globalContainer->gfx->drawString(44, 44+i*20, globalContainer->standardFont, connectionLines[i].c_str());
	}
	else if (!connectionOverlay && waitingMask && anyPlayerWaitedTimeFor>WAIT_NOTICE_DEBOUNCE_STEPS)
	{
		int nbap=0; // Number of away players
		Uint32 pm=1;
		Uint32 apm=waitingMask;
		for(int pi=0; pi<int(hud.state().players.size()); pi++)
		{
			if (pm&apm)
				nbap++;
			pm=pm<<1;
		}

		globalContainer->gfx->drawFilledRect(32, 32, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH-64, 22+nbap*20, 0, 0, 140, 127);
		globalContainer->gfx->drawRect(32, 32, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH-64, 22+nbap*20, 255, 255, 255);
		pm=1;
		int pnb=0;
		for(int pi2=0; pi2<int(hud.state().players.size()); pi2++)
		{
			if (pm&apm)
			{
				globalContainer->gfx->drawString(44, 44+pnb*20, globalContainer->standardFont, FormattableString(Toolkit::getStringTable()->getString("[waiting for %0]")).arg(hud.state().players[pi2].name).c_str());
				pnb++;
			}
			pm=pm<<1;
		}
	}
	else
	{
		int ymesg = 32;
		int yinc = 0;
		// The connection panel sits at the top left of the map in turn games; the
		// messages (a departure, chat notices) start below it, not under its header.
		if (connectionOverlay)
		{
			const SDL_Rect panel = connectionOverlay->panelBounds();
			if (panel.h > 0 && panel.x < 32 + 200)
				ymesg = std::max(ymesg, panel.y + panel.h + 12);
		}

		// Preserve authored messages from ordinary SGSL scenarios and old saves.
		auto tutorialLineStep = [&](const std::vector<std::string> &lines) {
			int step = std::max(20, globalContainer->standardFont->getStringHeight(""));
			for (const auto &line : lines)
				step = std::max(step, globalContainer->standardFont->getStringHeight(line));
			return step;
		};
		if (hud.state().legacyScriptTextShown && !touch->usesHUD())
		{
			std::vector<std::string> lines;
			setMultiLine(hud.state().legacyScriptText, &lines);
			const int lineStep = tutorialLineStep(lines);
			globalContainer->gfx->drawFilledRect(24, ymesg-8, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH-64+16, lines.size()*lineStep+16, 0,0,0,128);
			for (unsigned i=0; i<lines.size(); i++)
			{
				globalContainer->gfx->drawString(32, ymesg+yinc, globalContainer->standardFont, lines[i].c_str());
				yinc += lineStep;
			}

			if (swallowSpaceKey)
			{
				const auto prompt = Toolkit::getStringTable()->getString("[press space]");
				const int promptStep = std::max(lineStep, globalContainer->standardFont->getStringHeight(prompt));
				globalContainer->gfx->drawFilledRect(24, ymesg+yinc+8, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH-64+16, promptStep, 0,0,0,128);
				globalContainer->gfx->drawString(32, ymesg+yinc, globalContainer->standardFont, prompt);
				yinc += promptStep;
			}
			yinc += 8;
		}

		// show script text
		if (!scriptText.empty() && !touch->usesHUD())
		{
			std::vector<std::string> lines;
			setMultiLine(scriptText, &lines);
			const int lineStep = tutorialLineStep(lines);
			globalContainer->gfx->drawFilledRect(24, ymesg+yinc-8, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH-64+16, lines.size()*lineStep+16, 0,0,0,128);
			for (unsigned i=0; i<lines.size(); i++)
			{
				globalContainer->gfx->drawString(32, ymesg+yinc, globalContainer->standardFont, lines[i].c_str());
				yinc += lineStep;
			}
		}

		// show script counter
		if (hud.state().legacyScriptTimer)
		{
			globalContainer->gfx->drawString(globalContainer->gfx->getW()-165, ymesg, globalContainer->standardFont, FormattableString("%0").arg(hud.state().legacyScriptTimer).c_str());
			yinc = std::max(yinc, 32);
		}

		ymesg += yinc+2;

		ymesg = drawEventFeed(32, ymesg);
		if (touch->usesHUD())
		{
			const auto area = touch->notificationBounds();
			const SDL_Rect clip{int(area.x), int(area.y), int(area.w), int(area.h)};
			GAGCore::UITransformScope text(*globalContainer->gfx,
				1.15 * globalContainer->gfx->textUnitsPerPoint(), area.x, ymesg, &clip);
			messageManager.drawAllGameMessages(0, 0);
		}
		else
			messageManager.drawAllGameMessages(32, ymesg);
	}

	// display map mark
	globalContainer->gfx->setClipRect();
	if (touch->usesHUD())
		markManager.drawMainView(viewportX, viewportY, drawnScene(), &camera);
	else
		markManager.drawAll(localTeamNo, globalContainer->gfx->getW()-RIGHT_MENU_WIDTH+20, 10, 128, viewportX, viewportY, drawnScene(), &camera);

	// display text if placing a building
	if(!touch->usesHUD() && selectionMode == TOOL_SELECTION && toolManager.getBuildingName() != "")
	{
		globalContainer->standardFont->pushStyle(Font::Style(Font::STYLE_NORMAL, Color(255,255,255)));
		globalContainer->gfx->drawString(10, globalContainer->gfx->getH()-100, globalContainer->standardFont,  Toolkit::getStringTable()->getString("[Building Tool Line Explanation]"), 0, 75);
		globalContainer->gfx->drawString(10, globalContainer->gfx->getH()-100+12, globalContainer->standardFont,  Toolkit::getStringTable()->getString("[Building Tool Box Explanation]"), 0, 75);
		globalContainer->standardFont->popStyle();
	}

	// Draw icon if transmitting
	if (globalContainer->voiceRecorder->recordingNow)
		globalContainer->gfx->drawSprite(5, globalContainer->gfx->getH()-50, globalContainer->gamegui, 24);

	// Draw which players are transmitting voice
	int xinc = 42;
	for(int p=0; p<Team::MAX_COUNT; ++p)
	{
		if(globalContainer->mix->isPlayerTransmittingVoice(p) && p < int(hud.state().players.size()))
		{
			const SimulationSnapshot::Session::Player &player = hud.state().players[p];
			const GAGCore::Color playerColor = presentationColor(drawnScene().entities.teams[player.teamNumber].color);
			if(xinc==42)
			{
				globalContainer->gamegui->setBaseColor(playerColor);
				globalContainer->gfx->drawSprite(42, globalContainer->gfx->getH()-55, globalContainer->gamegui, 30);
				xinc += 47;
			}
			int height = globalContainer->standardFont->getStringHeight(player.name.c_str());

			globalContainer->standardFont->pushStyle(Font::Style(Font::STYLE_NORMAL, playerColor));
			globalContainer->gfx->drawString(xinc, globalContainer->gfx->getH()-35-height/2, globalContainer->standardFont, player.name);
			xinc += globalContainer->standardFont->getStringWidth(player.name.c_str()) + 5;
			globalContainer->standardFont->popStyle();
		}
	}

	if(!scrollableText)
		messageManager.drawAllChatMessages(32, globalContainer->gfx->getH() - 165);

	// Draw the bar continuing number of units, game speed, etc...
	drawTopScreenBar();
}

void GameGUI::drawInGameMenu(void)
{
	if (gameMenuScreen)
		gameMenuScreen->draw(SDL_GetTicks());
}

void GameGUI::drawInGameTextInput(void)
{
	if (typingInputScreen)
		typingInputScreen->draw(SDL_GetTicks());
}

void GameGUI::drawInGameScrollableText(void)
{
	if (scrollableText)
		scrollableText->draw(SDL_GetTicks());
}

void GameGUI::drawAll(int team)
{
	PERF_SCOPE_TIME(Render);
	// Apply any simulation notices not consumed yet and resolve the selection
	// for the renderer (view.selectedBuilding/selectedUnit). With a simulation
	// thread, that happens in threadedClientStep against the immutable PresentationFrame.
	if (!simulationThreaded)
		consumeClientEvents();
	clientRequests.publishViewport(viewportX, viewportY, int(camera.visibleW() / 32), int(camera.visibleH() / 32));
	clientRequests.publishOverlay(static_cast<Uint8>(showStarvingMap ? OverlayArea::Starving
		: showDamagedMap ? OverlayArea::Damage
		: showDefenseMap ? OverlayArea::Defence
		: showFertilityMap ? OverlayArea::Fertility
		: OverlayArea::None));
	// The engine publishes the same immutable frame on serial and threaded hosts.
	if (!publishedScene && !frameScene.map.getW()) return;
	const PresentationFrame &scene = drawnScene();
	view.scene = &scene;
    updateTutorial();
	view.render.zonesEmphasised = selectionMode==BRUSH_SELECTION;
	view.render.minimumZoom = camera.minimumZoom();
	view.render.unitMotion = globalContainer->settings.unitInterpolation && !gamePaused && !hardPause
		? unitMotionFraction(scene, SDL_GetTicks()) : 0.f;
	const Uint64 clock = tickClock;
	tickRate.sample(Uint32(SDL_GetTicks()), Uint32(clock), Uint32(clock >> 32));
	// Panels, the top bar and the statistics pages draw the scene's copy of the stats.
	teamStats = scene.panels.localStats.get();
	toolManager.setDrawnScene(&scene);
    view.displayedAreas=&toolManager.displayedAreas();
    globalContainer->gfx->beginFrame(GraphicContext::FrameMode::FullRedraw);
	updateCamera();
	globalContainer->gfx->setClipRect();
	globalContainer->gfx->drawFilledRect(0,0,globalContainer->gfx->getW(),globalContainer->gfx->getH(),0,0,32);
    if (touch) touch->prepareDraw();
    const int sidebar=touch->usesHUD() ? 0 : RIGHT_MENU_WIDTH;
	// draw the map
	Uint32 drawOptions =	(drawHealthFoodBar ? Game::DRAW_HEALTH_FOOD_BAR : 0) |
								(drawPathLines ?  Game::DRAW_PATH_LINE : 0) |
								(drawAccessibilityAids ? Game::DRAW_ACCESSIBILITY : 0 ) |
								((selectionMode==TOOL_SELECTION) ? Game::DRAW_BUILDING_RECT : 0) |
								((showStarvingMap) ? Game::DRAW_OVERLAY : 0) |
								((showDamagedMap) ? Game::DRAW_OVERLAY : 0) |
								((showDefenseMap) ? Game::DRAW_OVERLAY : 0) |
								((showFertilityMap) ? Game::DRAW_OVERLAY : 0) |
								((globalContainer->isViewingGame() && !globalContainer->replayShowFog) ? Game::DRAW_WHOLE_MAP : 0) |
								Game::DRAW_AREA;

	arrowPositions.clear();
	const bool drewTorus = torusView.active() &&
		torusView.draw(scene,this,localTeamNo, drawOptions, viewportX, viewportY,
			globalContainer->gfx->getW()-sidebar, globalContainer->gfx->getH(),
			camera.zoom, camera.fractionX(), camera.fractionY());
	GAGCore::ApplicationHost::overviewDrawn(drewTorus, drewTorus && torusView.overviewSettled());
	if (!drewTorus)
	{
		const int cloudGridLimit = DynamicClouds::gridLimitForZoom(scene.map.getW(), scene.map.getH(),
			globalContainer->settings.cloudPatchSize, camera.zoom);
		GAGCore::MapTransformScope mapPass(*globalContainer->gfx, camera.zoom, camera.offsetX-camera.fractionX()*camera.zoom, camera.offsetY-camera.fractionY()*camera.zoom, SDL_Rect{int(camera.offsetX), std::max(16, int(camera.offsetY)), int(camera.visibleW()*camera.zoom), int(camera.visibleH()*camera.zoom)-std::max(0,16-int(camera.offsetY))});
		std::set<Uint16> visibleBuildings;
		if (globalContainer->settings.translucentPanels)
			globalContainer->gfx->setClipRect();
		else
			globalContainer->gfx->setClipRect(0, 16, globalContainer->gfx->getW()-sidebar, globalContainer->gfx->getH()-16);
		game.drawMap(0, 0, int(std::ceil(camera.visibleW()+camera.fractionX())), int(std::ceil(camera.visibleH()+camera.fractionY())), 0, 0, viewportX, viewportY, localTeamNo, view, drawOptions,
			globalContainer->settings.buildingParticles ? &visibleBuildings : nullptr, &buildingGuiState, gamePaused, cloudGridLimit);
		if (globalContainer->settings.buildingParticles)
		{
			generateNewParticles(&visibleBuildings);
			drawParticles(!gamePaused);
		}

		///Draw ghost buildings
		if (!globalContainer->isViewingGame()) ghostManager.drawAll(drawnScene(), viewportX, viewportY, localTeamNo,
            std::ceil(camera.visibleW()+camera.fractionX()), std::ceil(camera.visibleH()+camera.fractionY()));

	}
	// if paused, tint the game area
	if (gamePaused)
	{
		std::string s;

		if (globalContainer->replaying && globalContainer->replayReader->isFinished())
		{
			s = Toolkit::getStringTable()->getString("[replay ended]");
		}
		else
		{
			globalContainer->gfx->drawFilledRect(0, 0, globalContainer->gfx->getW()-sidebar, globalContainer->gfx->getH(), 0, 0, 0, 20);
			s = Toolkit::getStringTable()->getString("[Paused]");
		}

		// Network matches say who paused and, with a pause budget, how long is left.
		std::string detail;
		if (networkMatch.active && !globalContainer->replaying)
		{
			const PauseState state = pauseState ? pauseState() : PauseState();
			const int holder = state.pausedBy;
			const std::string name = holder >= 0 && size_t(holder) < scene.panels.hud.state().players.size()
										 ? scene.panels.hud.state().players[holder].name : std::string();
			if (state.limited && holder >= 0 && state.pauserSecondsLeft >= 0)
			{
				const Uint32 left = Uint32(state.pauserSecondsLeft);
				detail = FormattableString(Toolkit::getStringTable()->getString("[pause by %0 resumes in %1]"))
							 .arg(name).arg(FormattableString("%0:%1").arg(left / 60).arg(left % 60, 2, 10, '0'));
			}
			else if (!name.empty())
				detail = FormattableString(Toolkit::getStringTable()->getString("[pause by %0]")).arg(name);
		}
		// Above whatever covers the bottom of the map: the phone HUD's action bar,
		// or the classic 80-pixel margin.
		int bottom = globalContainer->gfx->getH() - 80;
		int left = 0, width = globalContainer->gfx->getW() - sidebar;
		if (touch->usesHUD())
		{
			const auto ui = touch->hudLayout();
			left = int(ui.world.x);
			width = int(ui.world.w);
			bottom = int(ui.world.y + ui.world.h) - globalContainer->menuFont->getStringHeight(s.c_str()) -
					 (detail.empty() ? 0 : globalContainer->standardFont->getStringHeight(detail.c_str())) - 16;
		}
		const int w = globalContainer->menuFont->getStringWidth(s);
		const int h = globalContainer->menuFont->getStringHeight(s.c_str());
		const int dw = detail.empty() ? 0 : globalContainer->standardFont->getStringWidth(detail.c_str());
		const int dh = detail.empty() ? 0 : globalContainer->standardFont->getStringHeight(detail.c_str());
		// A dark backing keeps the label readable over bright terrain.
		const int boxW = std::max(w, dw) + 32;
		globalContainer->gfx->drawFilledRect(left + (width - boxW) / 2, bottom - 6, boxW, h + dh + 12, 0, 0, 0, 140);
		globalContainer->gfx->drawString(left + (width - w) / 2, bottom, globalContainer->menuFont, s);
		if (!detail.empty())
			globalContainer->gfx->drawString(left + (width - dw) / 2, bottom + h, globalContainer->standardFont, detail);
	}

	// draw the panel
	globalContainer->gfx->setClipRect();
	if (!touch->usesHUD()) drawPanel();

	// draw the minimap
	drawOptions = 0;

	globalContainer->gfx->setClipRect();
    if (!touch->usesHUD())
	minimap.draw(drawnScene(), localTeamNo, viewportX, viewportY, int(std::ceil(camera.visibleW()/32)), int(std::ceil(camera.visibleH()/32)) );

	// draw the progress bar if this is a replay
	if (globalContainer->replaying && !touch->usesHUD()) drawReplayProgressBar();

	// draw the top bar and other infos
	globalContainer->gfx->setClipRect();
	drawOverlayInfos();
    touch->drawHUD();
	if (connectionOverlay)
	{
		const double unit = globalContainer->gfx->logicalUnitsPerPoint();
		SDL_Rect area{0, 16, globalContainer->gfx->getW()-sidebar, globalContainer->gfx->getH()-16};
		if (touch->usesHUD())
		{
			// Under the status strip, away from the thumb corner (layout is in drawable pixels).
			const auto ui = touch->hudLayout();
			area = {int(ui.world.x), int(ui.status.y+ui.status.h), int(ui.world.w), int(ui.world.y+ui.world.h-ui.status.y-ui.status.h)};
			// Narrow portrait phones wrap the status strip onto a second row.
			if (ui.world.h > ui.world.w)
			{
				area.y += int(28*unit);
				area.h -= int(28*unit);
			}
		}
		connectionOverlay->draw(touch->usesHUD(), area, unit);
	}

	if ((torusView.enabled() || !torusView.active()) && !touch->usesHUD()) drawMapZoomControls(camera, true, true);
	// draw menu if any
	if (inGameMenu)
	{
		globalContainer->gfx->setClipRect();
		drawInGameMenu();
	}

	if(hiveCards && !inGameMenu && !scrollableText && globalContainer->settings.hiveMindEnabled){hiveCards->setComposerOpen(bool(typingInputScreen));hiveCards->draw(SDL_GetTicks());}

	// draw input box if any
	if (typingInputScreen)
	{
		globalContainer->gfx->setClipRect();
		drawInGameTextInput();
	}
	if (scrollableText)
		drawInGameScrollableText();

	// draw the highlight arrows
	for(int i=0; i<(int)arrowPositions.size(); ++i)
	{
		globalContainer->gfx->drawSprite(arrowPositions[i].x, arrowPositions[i].y, globalContainer->gamegui, arrowPositions[i].sprite);

	}
    if (touch) { touch->drawControls();touch->drawKeyboardFocus(); }
    if (!activeDialog()) Tutorial::drawDestination(*this);
    if (tutorialGuidance && !activeDialog() && !typingInputScreen) tutorialGuidance->draw(SDL_GetTicks());
}

void GameGUI::drawButton(int x, int y, std::string caption, int r, int g, int b, bool doLanguageLookup)
{
	globalContainer->gfx->drawSprite(x+8, y, globalContainer->gamegui, 12);
	globalContainer->gfx->drawFilledRect(x+17, y+3, 94, 10, r, g, b);

	std::string textToDraw;
	if (doLanguageLookup)
		textToDraw=Toolkit::getStringTable()->getString(caption);
	else
		textToDraw=caption;
	int len=globalContainer->littleFont->getStringWidth(textToDraw);
	int h=globalContainer->littleFont->getStringHeight(textToDraw);
	globalContainer->gfx->drawString(x+17+((94-len)>>1), y+((16-h)>>1), globalContainer->littleFont, textToDraw);
}

void GameGUI::drawBlueButton(int x, int y, std::string caption, bool doLanguageLookup)
{
	drawButton(x,y,caption,128,128,192,doLanguageLookup);
}

void GameGUI::drawRedButton(int x, int y, std::string caption, bool doLanguageLookup)
{
	drawButton(x,y,caption,192,128,128,doLanguageLookup);
}

void GameGUI::drawTextCenter(int x, int y, std::string caption)
{
	std::string text;

	text=Toolkit::getStringTable()->getString(caption);
	int dec=(RIGHT_MENU_WIDTH-globalContainer->littleFont->getStringWidth(text))>>1;
	globalContainer->gfx->drawString(x+dec, y, globalContainer->littleFont, text);
}

// Draws a two-channel scrollbox bar. `valueLocal` is the local/pending value the
// user has dialed in (drawn as the lighter localBar); `act` is the simulation-
// confirmed value (drawn as the darker actualBar on top). When the two agree
// the actualBar fully overlays the localBar; while an order is in flight they
// differ briefly. `max` is the divisor for both channels.
void GameGUI::drawScrollBox(int x, int y, int valueLocal, int act, int max)
{
	//scrollbar borders
	globalContainer->gfx->setClipRect(x+8, y, 112, 16);
	globalContainer->gfx->drawSprite(x+8, y, globalContainer->gamegui, 9);

	//localBar
	int size=(valueLocal*92)/max;
	globalContainer->gfx->setClipRect(x+18, y, size, 16);
	globalContainer->gfx->drawSprite(x+18, y+3, globalContainer->gamegui, 10);

	//actualBar
	size=(act*92)/max;
	globalContainer->gfx->setClipRect(x+18, y, size, 16);
	globalContainer->gfx->drawSprite(x+18, y+4, globalContainer->gamegui, 11);

	globalContainer->gfx->setClipRect();
}

void GameGUI::drawXPProgressBar(int x, int y, int act, int max)
{
	globalContainer->gfx->setClipRect(x+8, y, 112, 16);

	globalContainer->gfx->setClipRect(x+18, y, 92, 16);
	globalContainer->gfx->drawSprite(x+18, y+3, globalContainer->gamegui, 10);

	globalContainer->gfx->setClipRect(x+18, y, (act*92)/max, 16);
	globalContainer->gfx->drawSprite(x+18, y+4, globalContainer->gamegui, 11);

	globalContainer->gfx->setClipRect();
}

InGameStatisticsPanel &GameGUI::statistics()
{
    if (!statisticsPanel) {
        statisticsPanel = std::make_unique<InGameStatisticsPanel>(*this);
        if (!globalContainer->runNoX) statisticsPanel->attach(*globalContainer->gfx);
    }
    statisticsPanel->sync(drawnScene(), localTeamNo, globalContainer->isViewingGame(), globalContainer->liveSpectating);
    return *statisticsPanel;
}

bool GameGUI::statisticsVisible() const
{
    if (touch && touch->usesHUD()) return touch->needsStatisticsHistory();
    return selectionMode == NO_SELECTION && (globalContainer->isViewingGame()
        ? replayDisplayMode == RDM_STAT_TEXT_VIEW : displayMode == STAT_TEXT_VIEW);
}

void GameGUI::drawStatisticsPanel(GAGGUI::ui::Rect bounds)
{
    auto &panel = statistics();
    panel.setBounds(bounds);
    panel.drawEmbedded(*globalContainer->gfx, Uint32(SDL_GetTicks()));
}

namespace {
GAGGUI::ui::Rect statisticsSidebarBounds(const MapCamera &camera, int y, bool showZoom)
{
    auto *gfx = globalContainer->gfx;
    const auto zoom = mapZoomControlsLayout(camera, true, true);
    const int bottom = showZoom && zoom.height ? zoom.y - 4 : gfx->getH();
    return {gfx->getW() - RIGHT_MENU_WIDTH, y, RIGHT_MENU_WIDTH, std::max(0, bottom - y)};
}
}

void GameGUI::drawStatisticsPage(int y)
{
    drawStatisticsPanel(statisticsSidebarBounds(camera, y, torusView.enabled() || !torusView.active()));
}

bool GameGUI::handleStatisticsEvent(const SDL_Event &event)
{
    if (!statisticsVisible() || activeDialog()) return false;
    auto &panel = statistics();
    const bool mobile = touch && touch->usesHUD();
    if (event.type == SDL_EVENT_KEY_DOWN && (event.key.key == SDLK_ESCAPE || event.key.key == SDLK_AC_BACK) && !panel.host().popupOpen()) {
        panel.cancelEmbeddedInput(); panel.host().focus("", false);
        if (mobile) touch->closeStatistics();
        // Desktop Escape retains its normal in-game menu action.
        return mobile;
    }
    if (mobile) {
        const auto body = touch->statisticsContentRect();
        panel.setBounds({int(body.x), int(body.y), int(body.w), int(body.h)});
    } else panel.setBounds(statisticsSidebarBounds(camera, YPOS_BASE_STAT, torusView.enabled() || !torusView.active()));
    panel.host().layoutIfNeeded();
    if (!panel.routeEvent(event)) return false;
    viewportSpeedX = viewportSpeedY = 0;
    mapPanPushed = false;
    return true;
}

SceneRequest GameGUI::sceneRequest(bool includeTiming)
{
	SceneRequest request;
	request.localTeam = localTeamNo;
    request.includeTelemetry = inGameMenu == IGM_TELEMETRY;
    request.includeHistory = ((!activeDialog() && statisticsVisible()) || inGameMenu == IGM_STATISTICS);
	request.spectating = globalContainer->isViewingGame();
	request.view = clientRequests.latest();
	if (selectionMode == BUILDING_SELECTION)
		if (const BuildingRef *b = std::get_if<BuildingRef>(&selection))
			request.selectedBuilding = *b;
	if (selectionMode == UNIT_SELECTION)
		if (const UnitRef *u = std::get_if<UnitRef>(&selection))
			request.selectedUnit = *u;
    {
        Uint32 units=0, buildings=0;
        if(highlights.contains(HighlightWorkers)) units|=1u<<WORKER;
        if(highlights.contains(HighlightExplorers)) units|=1u<<EXPLORER;
        if(highlights.contains(HighlightWarriors)) units|=1u<<WARRIOR;
        for(int i=0;i<IntBuildingType::NB_BUILDING;++i)
            if(highlights.contains(HighlightBuildingOnMap+i)) buildings|=1u<<i;
        request.highlights=std::pair{units,buildings};
    }
	if (includeTiming) { request.tickTime = lastTickTime; request.tickInterval = tickInterval; }
	return request;
}

void GameGUI::threadedClientStep(const std::vector<SDL_Event>& events, Uint64 now)
{
	toolManager.setDrawnScene(&drawnScene());
	// Keep the original client event ordering against the displayed PresentationFrame.
	consumeClientEvents();
	checkSelection();
	step(events, now);
}

Game *GameGUI::replayTelemetryGame()
{
	return &game;
}
