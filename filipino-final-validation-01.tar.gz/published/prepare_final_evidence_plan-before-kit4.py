#!/usr/bin/env python3
"""Prepare a bounded evidence plan; never build/publish archives or mutate reviews.

Default writes an UNFROZEN candidate; --freeze requires an exact clean revision and
nine passed gates. JS inclusion requires an explicit previously reviewed SHA.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess

K = Path(__file__).resolve().parents[1]
F = K / 'final-kit3'
P = K / 'published'
FORBIDDEN = {'.git', 'profiles', 'profile', 'node_modules', 'trace', 'traces',
             'runtime-assets', 'assets', 'bin', 'lib', 'include', 'db', 'database',
             '__pycache__', 'cache', 'caches'}
SUFFIX = ('.json', '.jsonl', '.md', '.log', '.log.gz', '.txt', '.txt.gz',
          '.json.gz', '.jsonl.gz', '.xml', '.png', '.diff', '.py', '.sh')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--revision', required=True, help='Exact 40-hex final source revision')
    ap.add_argument('--tag', required=True, help='Evidence directory/filename tag')
    ap.add_argument('--browser-dir', help='Kit-relative actual browser evidence directory (including unique attempt folder); defaults to browser-final-TAG')
    ap.add_argument('--matrix-tag', help='Actual matrix producer tag; defaults to --tag. Use 6980 only with explicit unchanged-input carry proof.')
    ap.add_argument('--freeze', action='store_true')
    ap.add_argument('--reviewed-script', action='append', default=[], metavar='PATH=SHA256',
                    help='Explicit hash-pinned JS/MJS allowlist after actual source review')
    args = ap.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}', args.revision), 'Full source revision required'
    assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', args.tag), 'Unsafe tag'
    matrix_tag = args.matrix_tag or args.tag
    assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', matrix_tag), 'Unsafe matrix tag'
    reviewed_scripts = {}
    for spec in args.reviewed_script:
        name, digest = spec.rsplit('=', 1)
        assert re.fullmatch(r'[0-9a-f]{64}', digest)
        q = (K / name).resolve()
        assert q.is_relative_to(K) and q.suffix in {'.js', '.mjs'} and q.stat().st_size <= 128 * 1024
        assert sha(q) == digest, 'Reviewed script changed: ' + name
        reviewed_scripts[str(q.relative_to(K))] = digest

    review = json.loads((F / 'reviews/fil.json').read_text())
    assert len(review['gates']) == 9
    pending = [name for name, gate in review['gates'].items() if gate.get('passed') is not True]
    observed_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    observed_status = subprocess.check_output(['git', 'status', '--porcelain'], text=True)
    if args.freeze:
        assert observed_head == args.revision and not observed_status, 'Exact clean final source required'
        assert not pending, 'Pending actual runtime gates: ' + ', '.join(pending)

    files, pinned, excluded, queue = set(), {}, [], []
    reference_discrepancies = []

    def allowed(p):
        return (p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(K)
                and not set(p.relative_to(K).parts) & FORBIDDEN
                and not any(x.endswith('-assets') for x in p.relative_to(K).parts)
                and p.name != 'ROOT-STATE.json' and p.stat().st_size <= 64 * 1024**2
                and (p.name.endswith(SUFFIX) or str(p.relative_to(K)) in reviewed_scripts))

    def add(p, expected=None):
        p = p.resolve()
        if not allowed(p):
            excluded.append(str(p))
            return
        if expected:
            assert sha(p) == expected, 'Referenced evidence changed: ' + str(p)
            pinned[str(p.relative_to(K))] = expected
        if p not in files:
            files.add(p)
            if p.suffix == '.json' and p.name != 'font-matrix.json':
                queue.append(p)

    def tree(name):
        root = K / name
        assert root.is_dir(), 'Missing final evidence directory: ' + str(root)
        for p in root.rglob('*'):
            if p.is_file() and allowed(p):
                add(p)

    for name in ['reviews/fil.json', 'reviews/fil-provenance.json',
                 'master-delta3/independent-aggregate-audit.json']:
        q = F / name
        add(q, sha(q))
    for gate in review['gates'].values():
        for e in gate.get('evidence', []):
            q = (F / e['path']).resolve()
            assert q.is_file() and sha(q) == e['sha256'], 'Gate reference mismatch: ' + e['path']
            add(q, e['sha256'])

    tag = args.tag
    browser_dir = args.browser_dir or f'browser-final-{tag}'
    browser_path = (K / browser_dir).resolve()
    assert not Path(browser_dir).is_absolute() and '..' not in Path(browser_dir).parts and browser_path.is_relative_to(K), 'Unsafe browser directory'
    for d in ['final-web-243', browser_dir, f'native-{tag}-focused',
              f'native-{tag}-render-units', f'rendering/native-final-{tag}-screens']:
        tree(d)
    for pat in [f'native-{tag}*', f'browser-{tag}*', f'data-{tag}*', f'final-{tag}*',
                f'{tag}-*', f'web-roundtrip-{tag}*', f'roundtrip_{tag}.py',
                'native-243*', 'browser-243*', 'data-243*', 'final-243*',
                'mobile-243*', 'mobile-*-243-export.log', 'mobile-*-243-assets.json',
                'web-roundtrip-243*', 'roundtrip_243.py', 'data-f0f*', 'final-f0f*',
                'web-roundtrip-f0f*', 'roundtrip_f0f.py', 'f0f-*',
                'mobile-*-f0f-assets.json', 'browser-hud-verified*', 'native-fixture-final*', 'native-fixture-x11-final*',
                'native-hud-fixture-diagnostic*', 'final-pending-fix-*']:
        for q in K.glob(pat):
            if q.is_file() and allowed(q):
                add(q)
    matrix = K / f'rendering/native-final-{matrix_tag}-full-matrix'
    for name in ['font-matrix.json', 'current-matrix-proof.json', 'catalog-source-binding.json', 'process.log']:
        q = matrix / name
        assert q.is_file(), q
        add(q)
    # Preserve negative startup/editor evidence and its narrow actual 6980 closure.
    # JSON traversal adds referenced pixels, never every historical matrix page.
    for pat in [f'*{tag}*.json', '*f0f*.json', '*6980*legacy*.json', '*6980*producer-binding*.json']:
        for q in (K / 'visual').glob(pat):
            add(q)
    # Matrix pixel review stays tied to the actual producer, even when current UI differs.
    matrix_review = K / 'visual' / f'native-final-matrix-review-{matrix_tag}.json'
    if matrix_review.is_file():
        add(matrix_review, sha(matrix_review))
    if matrix_tag != tag:
        carry_reviews = list((K / 'visual').glob(f'*{tag}*matrix*carry*.json'))
        assert carry_reviews, 'Distinct matrix producer requires an explicit current-tag matrix carry review'
        for q in carry_reviews:
            add(q, sha(q))
    for name in ['browser-final-f0f/threaded-startup-finding.json',
                 'browser-final-6980/gameplay-phone150-nav-finding.json',
                 'published/prepare_final_evidence_plan.py',
                 'published/final-evidence-planner-preparation-review.json']:
        q = K / name
        assert q.is_file(), q
        add(q)
    for name, digest in reviewed_scripts.items():
        add(K / name, digest)

    def resolve_ref(value, origin, expected):
        q = Path(value)
        candidates = [q] if q.is_absolute() else [origin.parent / q, F / q, K / q]
        if value.startswith('artifacts/filipino-localization/'):
            candidates.insert(0, K / value.removeprefix('artifacts/filipino-localization/'))
        candidates += [matrix / q, K / 'visual' / q]
        existing = list(dict.fromkeys(p.resolve() for p in candidates if p.is_file()))
        if expected:
            matching = [p for p in existing if sha(p) == expected]
            if existing and not matching:
                # Historical receipts can deliberately pin superseded source/aggregate
                # bytes. Never silently substitute current bytes for those hashes.
                reference_discrepancies.append({'origin': str(origin.relative_to(K)),
                                                'reference': value, 'expected_sha256': expected,
                                                'action': 'not substituted; root must reconcile historical reference'})
            return matching[0] if matching else None
        return existing[0] if existing else None

    def refs(value, origin):
        if isinstance(value, dict):
            for name, item in value.items():
                if name in {'path', 'png', 'file', 'image', 'original_bmp', 'viewed_lossless_png', 'log', 'manifest'} and isinstance(item, str):
                    expected = value.get('sha256') if name == 'path' else value.get(name + '_sha256')
                    if not isinstance(expected, str) or not re.fullmatch(r'[0-9a-f]{64}', expected):
                        expected = None
                    q = resolve_ref(item, origin, expected)
                    if q is not None:
                        add(q, expected)
                refs(item, origin)
        elif isinstance(value, list):
            for item in value:
                refs(item, origin)

    while queue:
        q = queue.pop()
        refs(json.loads(q.read_text()), q)
    entries = [{'path': str(q.relative_to(K)), 'sha256': sha(q)} for q in sorted(files)]
    assert len(entries) <= 5000 and sum(q.stat().st_size for q in files) <= 512 * 1024**2
    plan = {'final_receipts_frozen': args.freeze, 'revision': args.revision, 'tag': tag, 'matrix_actual_producer_tag': matrix_tag,
            'actual_browser_evidence_directory': browser_dir,
            'observed_head': observed_head, 'observed_dirty': bool(observed_status),
            'pending_gates': pending,
            'reviewed_scripts': [{'path': n, 'sha256': d} for n, d in sorted(reviewed_scripts.items())],
            'extra_files': entries,
            'frozen_receipts': [{'path': n, 'sha256': d} for n, d in sorted(pinned.items())],
            'excluded_reference_paths': sorted(set(excluded)),
            'reference_discrepancies_for_explicit_root_review': reference_discrepancies,
            'scope': f'Authoritative final-kit3 6247-key source/target envelope and four-role carry histories; actual {tag} native/browser runtime and current tag visual receipts; matrix actual producer {matrix_tag} with explicit carry when different; scoped 243 website input carry; historical negative f0f evidence and actual 6980 editor closure retained by producer.',
            'limits': ['Agent-reviewed, no human language certification.',
                       'Linux/Chromium only; physical Android/iOS and native Windows/macOS not claimed.',
                       'Original four-role histories are included by curator BASE_TREES; this plan closes current runtime/gate references without inventing new linguistic reads.',
                       'Complete matrix measurements/page hashes retained; actual independently reviewed representative PNGs selected, not every generated matrix page.',
                       'Historical failures and prior producer revisions remain explicitly historical; old editor closure does not close separate gameplay findings.',
                       'Candidate selection is not publication approval. Root must review exact path closure, privacy scan, bounds and archive extraction hashes before publishing.']}
    out = P / f'final-{tag}-evidence-plan.json'
    assert not out.exists(), 'Refuse to overwrite an existing plan; preserve historical bytes'
    out.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'plan': str(out), 'frozen': args.freeze, 'extra_files': len(entries),
                      'pinned_receipts': len(pinned), 'pending_gates': pending,
                      'note': 'No archive built or published. Curator rejects unfrozen candidates.'}))


if __name__ == '__main__':
    main()
