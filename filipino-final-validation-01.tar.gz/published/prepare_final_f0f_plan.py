"""Select final evidence only after explicit freeze; does not build or publish archives."""
from pathlib import Path
import argparse,hashlib,json,subprocess
K=Path(__file__).resolve().parents[1];F=K/'final-kit3';P=K/'published';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
FORBIDDEN={'profiles','profile','node_modules','trace','traces','runtime-assets','assets','bin','lib','include','db','database','__pycache__'}
SUFFIX=('.json','.jsonl','.md','.log','.log.gz','.txt','.xml','.png','.diff','.py')
def add_tree(name,files):
 root=K/name
 assert root.is_dir(),root
 for p in root.rglob('*'):
  if p.is_file() and not set(p.relative_to(K).parts)&FORBIDDEN and p.name.endswith(SUFFIX):files.add(p)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--freeze',action='store_true');args=ap.parse_args();assert args.freeze,'Explicit --freeze required after all processes and reviews finish'
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='f0f003572e0c204f6d1c16063a9852cf3ade7bf1';assert not subprocess.check_output(['git','status','--porcelain'],text=True)
 review=json.loads((F/'reviews/fil.json').read_text());assert len(review['gates'])==9 and all(v.get('passed') is True for v in review['gates'].values()),'All actual final gates must pass first'
 files=set();frozen=[]
 for p in [F/'reviews/fil.json',F/'reviews/fil-provenance.json',F/'master-delta3/independent-aggregate-audit.json']:
  files.add(p);frozen.append({'path':str(p.relative_to(K)),'sha256':sha(p)})
 for gate in review['gates'].values():
  for e in gate['evidence']:
   p=(F/e['path']).resolve();assert p.is_file() and sha(p)==e['sha256'],'Gate evidence changed '+e['path'];files.add(p);frozen.append({'path':str(p.relative_to(K)),'sha256':sha(p)})
 for d in ['final-web-243','browser-final-f0f','native-f0f-focused','native-f0f-render-units','rendering/native-final-f0f-screens']:add_tree(d,files)
 # Root-level current and retained predecessor receipts/logs. No raw exports or executables.
 for pat in ['native-f0f*','native-243*','browser-f0f*','browser-243*','data-f0f*','data-243*','final-243*','mobile-243*','mobile-*-243-export.log','web-roundtrip-243*','web-roundtrip-f0f*','roundtrip_243.py','roundtrip_f0f.py','final-f0f*','f0f-*','mobile-*-243-assets.json','mobile-*-f0f-assets.json','final-pending-fix-*']:
  for p in K.glob(pat):
   if p.is_file() and p.name.endswith(SUFFIX):files.add(p)
 # Explicit complete measurement file, proof, and binding; select pixels via actual visual reviews below.
 for n in ['font-matrix.json','current-matrix-proof.json','catalog-source-binding.json','process.log']:files.add(K/'rendering/native-final-f0f-full-matrix'/n)
 for p in (K/'visual').glob('*f0f*.json'):
  files.add(p)
  x=json.loads(p.read_text())
  def refs(v):
   if isinstance(v,dict):
    for name,val in v.items():
     if name in {'path','png','file','image'} and isinstance(val,str):
      q=Path(val)
      if q.is_absolute() and q.is_relative_to(K):candidate=q
      elif val.startswith('artifacts/filipino-localization/'):candidate=K/val.removeprefix('artifacts/filipino-localization/')
      else:candidate=K/val
      if not candidate.is_file() and val.endswith('.png'):
       for folder in [K/'rendering/native-final-f0f-full-matrix',K/'visual']:
        if (folder/val).is_file():candidate=folder/val;break
      if candidate.is_file() and candidate.suffix=='.png':files.add(candidate.resolve())
     refs(val)
   elif isinstance(v,list):
    for val in v:refs(val)
  refs(x)
 # Packaging final reports are gate-pinned; recursively referenced JSON/text receipts may be added explicitly by root to the generated plan.
 reviewed_scripts=[]
 for n in ['browser-final-f0f/capture_extra.js','final-web-243/capture-ssr.mjs']:
  q=K/n;assert q.is_file() and q.stat().st_size<=128*1024
  files.add(q);reviewed_scripts.append({'path':n,'sha256':sha(q)})
 entries=[]
 for p in sorted(files):
  assert p.is_file() and p.resolve().is_relative_to(K.resolve()),p
  assert not set(p.relative_to(K).parts)&FORBIDDEN,p
  entries.append({'path':str(p.relative_to(K)),'sha256':sha(p)})
 plan={'final_receipts_frozen':True,'reviewed_scripts':reviewed_scripts,'extra_files':entries,'frozen_receipts':frozen,'scope':'Authoritative final-kit3 6247-key envelope, source/target carry proofs, four independent role histories, Google receipts, actual finalf0f native/browser runtime and packaging, plus explicitly scoped website input carry from243.','limits':['Agent-reviewed, no native-human language certification.','Local runtime Linux/Chromium only; physical Android/iOS and Windows/macOS not claimed.','Three browser fixture-version failures reproduced from current master; explicit no-display native exclusions retained.','Complete37644sample measurement data and allpagehashes; representative actualmatrix PNGs selected by independentreview, not everygeneratedpage included.','Historical22/001/FFF/243 receipts remain identified by actual producer.']};out=P/'final-f0f-evidence-plan.json';out.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan':str(out),'extra_files':len(entries),'pinned_gate_receipts':len(frozen),'note':'Root must review the complete candidate list and fill any package manifest/current data report files missing from naming patterns before curator --build.'}))
if __name__=='__main__':main()
