"""Apply exactly two approved captions only after controller HOLD; preserve provenance."""
import datetime,hashlib,json,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[3];K=ROOT/'artifacts/filipino-localization';S=K/'author/compact-labels'
def digest(b):return hashlib.sha256(b).hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def apply():
 hold=K/'rendering/matrix-hold.json';assert hold.is_file(),'Explicit controller HOLD evidence required'
 h=json.loads(hold.read_text());pid=h['controller_pid'];assert not pathlib.Path('/proc',str(pid)).exists(),'Controller still exists: wait for safe hold confirmation'
 S.mkdir(parents=True,exist_ok=True);assert not (S/'author-delta.json').exists(),'Already applied; refusing replay'
 old='5c86dff4c8e9fb03c89bae1185740767dfc56959003e55e81c3bb84479531f61'
 changes={'[Rules]':('Mga Panuntunan','Mga tuntunin'),'[Editor tools]':('Mga Kagamitan','Mga tool')}
 paths=[ROOT/'data/texts.fil.txt',K/'drafts/fil/texts.fil.txt'];raw=paths[0].read_bytes();assert digest(raw)==old and paths[1].read_bytes()==raw
 newraw=raw
 for key,(before,after) in changes.items():
  for role in ['meaning','editor']:
   proposal=K/f'linguistic/compact-{"rules" if key=="[Rules]" else "tools"}-{role}.json';p=json.loads(proposal.read_text());assert (p.get('approved_target') or p.get('proposed'))==after
  needle=(key+'\n'+before+'\n').encode();assert newraw.count(needle)==1;newraw=newraw.replace(needle,(key+'\n'+after+'\n').encode())
 npath=K/'drafts/fil/native.json';native=json.loads(npath.read_text());original=dict(native);assert len(native)==3393
 for key,(before,after) in changes.items():assert native[key]==before;native[key]=after
 assert {key for key in native if native[key]!=original[key]}==set(changes)
 snapshots={'drafts/fil/texts.fil.txt':'native-before.txt','drafts/fil/native.json':'native-before.json','drafts/fil/metadata.json':'metadata-before.json','reviews/fil.json':'official-before.json','reviews/fil-provenance.json':'provenance-before.json','drafts/fil/fil.json':'online-before.json'}
 for relative,name in snapshots.items():
  p=S/name;assert not p.exists();p.write_bytes((K/relative).read_bytes())
 for p in paths:p.write_bytes(newraw)
 write(npath,native);meta=json.loads((K/'drafts/fil/metadata.json').read_text());assert meta['catalog_sha256']['native']==old;meta['catalog_sha256']['native']=digest(newraw);write(K/'drafts/fil/metadata.json',meta)
 (S/'native-after.txt').write_bytes(newraw)
 source=json.loads((K/'source/native.json').read_text());online=json.loads((K/'drafts/fil/fil.json').read_text());assert len(online)==2836
 manifest=json.loads((K/'manifest.json').read_text());batchkeys={b['id']:b['keys'] for b in manifest['batches']}
 entries=[{'key':'native:'+key,'source':source[key],'source_value_sha256':digest(source[key].encode()),'before':before,'before_value_sha256':digest(before.encode()),'after':after,'after_value_sha256':digest(after.encode())} for key,(before,after) in changes.items()]
 record={'identity':'/root/draft_editor','scope':'Actual author reread/edit of two compact UI labels only; no fresh full-catalog reading','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head_before_edit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_sha256':meta['source_sha256'],'catalog_before_sha256':old,'catalog_after_sha256':digest(newraw),'online_sha256_unchanged':meta['catalog_sha256']['online'],'changes':entries,'read_and_edited_keys':['native:'+key for key in changes],'unchanged_native_keys':['native:'+key for key in native if key not in changes],'unchanged_native_count':3391,'unchanged_online_keys':['online:'+key for key in online],'unchanged_online_count':2836,'affected_batches':[bid for bid,keys in batchkeys.items() if set(keys)&{'native:'+key for key in changes}],'proof':'Every native value compared against immutable native-before.json; exactly the two specified IDs differ. Online bytes preserved and all2836 IDs retained. Historical full-review records remain unmodified; carry-forward applies only to identical values.','rationale':{'native:[Rules]':'Shorter plural game-rules caption preserves meaning while avoiding Panuntuna/n wrapping in compact118px phone lobby tab.','native:[Editor tools]':'Mga marks plural; uninflected software loan tool names navigation utilities precisely and fits established technical register. English Tools source is general software utilities despite historical Editor tools key. Individual intentional loan rationale independently approved by meaning/editor proposal evidence.'},'snapshots':{name:digest((S/name).read_bytes()) for name in [*snapshots.values(),'native-after.txt']},'hold_evidence':{'path':'rendering/matrix-hold.json','sha256':digest(hold.read_bytes())},'pending':['Explicit final two-key meaning/editor/adversarial rereads','Actual targeted lobby/gameplay and fullmatrix recapture','Root invalidation/refresh of old-native-hash gates and regenerated assets']}
 write(S/'author-delta.json',record);print(json.dumps({'native_sha256':digest(newraw),'record':str(S/'author-delta.json'),'affected_batches':record['affected_batches']}))
if __name__=='__main__':apply()
