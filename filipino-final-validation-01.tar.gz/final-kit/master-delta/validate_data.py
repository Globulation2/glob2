from pathlib import Path
import subprocess,os,json,time,hashlib,concurrent.futures
r=Path.cwd();k=r/'artifacts/filipino-localization';rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();env=dict(os.environ,GLOB2_SDL3_PREFIX=str(k/'sdl-reused'),LD_LIBRARY_PATH=str(k/'sdl-reused/lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''))
commands=[('master-strict',['python3','data/check_translations.py','--strict']),('master-translations',['python3','test/test_translations.py']),('master-font-coverage',['python3','test/test_font_coverage.py'])]+[('master-mobile-'+p,['python3','tools/package_assets.py','--platform',p,'--output',str(k/('mobile-'+p+'-master-assets')),'--jobs','2']) for p in ['android','ios']]
def run(x):
 name,args=x;start=time.monotonic()
 with (k/(name+'.log')).open('w') as log:q=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 out={'name':name,'argv':args,'exit_code':q.returncode,'seconds':time.monotonic()-start,'log':name+'.log','log_sha256':hashlib.sha256((k/(name+'.log')).read_bytes()).hexdigest()}
 if name.startswith('master-mobile-') and not q.returncode:
  folder=Path(args[5]);files=['data/texts.fil.txt','data/texts.list.txt','data/texts.incomplete.txt','data/fonts/sans.ttf']+['data/fonts/LICENSE-'+v+'.txt' for v in ['DejaVu','Droid','HarfBuzz','Noto']];out['verified_files_sha256']={n:hashlib.sha256((folder/n).read_bytes()).hexdigest() for n in files};assert all((folder/n).read_bytes()==(r/n).read_bytes() for n in files);out['file_count']=sum(p.is_file() for p in folder.rglob('*'))
 return out
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:results=list(pool.map(run,commands))
(k/'master-data-results.json').write_text(json.dumps({'revision':rev,'commands':results},indent=2)+'\n');print([(a['name'],a['exit_code']) for a in results]);assert all(not a['exit_code'] for a in results)
