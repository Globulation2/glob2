from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[4];K=ROOT/'artifacts/filipino-localization';F=K/'final-kit';sys.path.insert(0,str(ROOT/'tools/localization'));import translation_program as P
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=lambda v:hashlib.sha256(v.encode()).hexdigest();issues=[];checks=[]
def check(ok,label):checks.append({'check':label,'passed':bool(ok)});issues.extend([] if ok else [label])
m=read(F/'manifest.json');r=read(F/'reviews/fil.json');prov=read(F/'reviews/fil-provenance.json');proof=read(F/'master-delta/source-target-carry.json');oldsrc=read(K/'source/native.json');oldonline=read(K/'source/online.json');oldtarget=read(K/'drafts/fil/native.json');oldonlinetarget=read(K/'drafts/fil/online.json');newsrc=read(F/'source/native.json');newonline=read(F/'source/online.json');newtarget=read(F/'drafts/fil/native.json');newonlinetarget=read(F/'drafts/fil/online.json');final=read(F/'master-delta/final.json');newkeys=set(final)
check(len(oldsrc)==3393 and len(oldonline)==2836,'Original6229entry inventory')
check(set(newsrc)-set(oldsrc)==newkeys and set(newkeys)=={'[stat win probability]','[stat win probability about]'} and not(set(oldsrc)-set(newsrc)),'Only2new source IDs')
check(all(newsrc[k]==v for k,v in oldsrc.items()) and newonline==oldonline,'All6229original English sources exactly unchanged')
check(all(newtarget[k]==v for k,v in oldtarget.items()) and set(newtarget)==set(oldtarget)|newkeys and newonlinetarget==oldonlinetarget,'All6229original target values exactly unchanged')
check(all(newtarget[k]==v for k,v in final.items()),'Both new final values match actual independent review snapshot')
check(set(proof['unchanged_native_ids'])=={'native:'+k for k in oldsrc} and len(proof['unchanged_native_ids'])==3393 and set(proof['unchanged_online_ids'])=={'online:'+k for k in oldonline} and len(proof['unchanged_online_ids'])==2836,'Carry proof IDs exact and unique')
keys,ns,os,files,source=P.sources(ROOT);paths=P.catalog_paths(F,'fil');catalog={s:sha(p) for s,p in paths.items()}
check(source==m['source_sha256']==r['source_sha256']==prov['source_sha256']==proof['source_after_sha256']=='bc991eb1ba24f28d201f75fa68af1d6e49832512b814466100c394fa79c37549','Current source contract hash exact')
check(catalog==r['catalog_sha256']==prov['catalog_sha256']==proof['catalog_after_sha256'] and catalog['native']=='f5efc208ae90bc5349b9f347ffe280899b02703f38060bfb0d9728de9d4440a5' and catalog['online']=='99ed554f753390682d437318e20ed9d7ddbd54fbe2c798df41b42d4fb3fb2446','Final catalog file hashes exact')
check(ns==newsrc and os==newonline and files==m['source_files'],'Final snapshot matches installed source contracts')
check(sha(ROOT/'data/texts.fil.txt')==catalog['native'],'Installed native catalog matches final snapshot')
oldm=read(K/'manifest.json');check(all(files[n]==oldm['source_files'][n] for n in P.SOURCE_PATHS if n not in ['data/texts.en.txt','data/texts.keys.txt']),'Online plural/invariant/source contracts unchanged')
expected={b['id']:set(b['keys']) for b in m['batches']};check(len(expected)==len(m['batches'])==len(r['batches'])==44,'Exactly44source/review batches')
flat=[k for b in m['batches'] for k in b['keys']];allids={'native:'+k for k in newsrc}|{'online:'+k for k in newonline};check(len(flat)==len(set(flat))==6231 and set(flat)==allids,'All6231IDs covered exactly once')
th=P.batch_target_hashes(m,paths)
for b in r['batches']:
 bid=b['id'];check(b['target_sha256']==th[bid] and b['source_sha256']==source,bid+': exact new envelope hash')
 people=[b[x] for x in ['author','reviewer','editor','adversarial_reviewer']];check(len(set(people))==4,bid+': four distinct identities')
 for field in ['reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys']:check(len(b[field])==len(set(b[field])) and set(b[field])==expected[bid],bid+': '+field+' coverage')
 check(b['rechecked_by']==b['reviewer'],bid+': meaning reviewer final recheck')
# Full audit checks expected pending gates but cannot approve them.
audit=P.audit_locale(F,m,r,'fil');pending=[g+' is pending or lacks evidence' for g in P.GATES];check(sorted(audit)==sorted(pending),'Tool audit has exactly9 intentionally pending gates and no linguistic/schema issues')
checked=P.check_draft(F,'fil');accepted=r['accepted_english'];check(len(accepted)==265 and {x['key'] for x in accepted}==set(checked['same_as_english_review_queue']),'All265English matches have exact individual exceptions')
check(accepted==read(K/'reviews/fil.json')['accepted_english'],'265English exception records unchanged from verified historical aggregate')
reviewers={'author-review.json':'/root/draft_editor','meaning-review.json':'/root/meaning_reviewer','editor-review.json':'/root/language_editor','meaning-final-review.json':'/root/meaning_reviewer','adversarial-review.json':'/root/adversarial_reviewer'};direct=[]
for name,identity in reviewers.items():
 path=F/'master-delta'/name;v=read(path);check(v.get('identity',v.get('reviewer'))==identity,name+': actual identity');rows={e['id']:e for e in v['entries']};check(set(rows)=={'native:'+k for k in final},name+': exact2IDs')
 for key,value in final.items():
  e=rows['native:'+key];check(e['source']==newsrc[key] and e['source_value_sha256']==h(newsrc[key]) and e.get('final_value_sha256',e.get('target_value_sha256'))==h(value) and e.get('author_final',e.get('final_value',e.get('final_target',e.get('final'))))==value,name+': actual source/target value and hash '+key)
  if name!='author-review.json':check(e.get('status')=='approved',name+': actual approval '+key)
 direct.append({'path':str(path.relative_to(F)),'sha256':sha(path),'identity':identity})
refs=[]
def walk(v,where):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=Path(v['path']);p=p if p.is_absolute() else F/p;ok=p.is_file() and sha(p)==v['sha256'];refs.append({'at':where,'path':v['path'],'sha256':v['sha256'],'passed':ok});check(ok,where+': referenced evidence SHA')
  for k,x in v.items():walk(x,where+'.'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):walk(x,where+'['+str(i)+']')
walk(prov,'provenance');walk(proof,'source-target-carry');walk(r['language_brief'],'language-brief');walk(r['provenance'],'current-review-provenance')
for b in r['batches']:walk(b.get('provenance',{}),'batch:'+b['id'])
check(len(prov['role_evidence'])==20 and all(x in prov['role_evidence'] for x in [{'path':e['path'],'sha256':e['sha256']} for e in direct]),'Current provenance includes all5new direct role receipts plus15historical records')
check(all(g['passed'] is False for g in r['gates'].values()),'All gate objects intentionally pending; no release approval inferred')
ancestor=subprocess.run(['git','merge-base','--is-ancestor','0d54ef3a99384059e68e78f03f774e062031a3ca','HEAD']).returncode==0;check(ancestor,'Actual master0d54 ancestor of current checkout')
result={'identity':'/root/adversarial_reviewer','status':'pass; aggregate linguistic provenance/schema only, release gates intentionally pending' if not issues else 'issues found','issues':issues,'checks':checks,'snapshot_evidence':[{'path':str(p.relative_to(F)),'sha256':sha(p)} for p in [F/'manifest.json',F/'reviews/fil.json',F/'reviews/fil-provenance.json',F/'master-delta/source-target-carry.json']],'source_sha256':source,'catalog_sha256':catalog,'total_ids':6231,'unchanged_original_ids':6229,'new_directly_reviewed_ids':2,'batch_count':44,'english_exception_count':265,'role_evidence_count':len(prov['role_evidence']),'direct_new_reviews':direct,'evidence_reference_checks':refs,'expected_pending_gates':list(P.GATES),'actual_checkout_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tracked_status':subprocess.check_output(['git','status','--porcelain'],text=True).splitlines(),'historical_envelopes':'Original role receipts retain old source/catalog hashes and their actual full reads. Current44batch envelopes update source contracts through exact6229source+target carry; only2newIDs have direct new reads. No old fullread is relabeled current and no fresh6231entry human/agent reading is claimed.','limits':['Audit compares snapshots, coverage, hashes and role records; does not redo linguistic reading of original6229entries.','Nine pending gates are expected and remain untouched. Native/browser/platform rendering and integration evidence are separately scoped by root.']}
result['prior_negative_audit']={'path':'master-delta/independent-aggregate-audit.json','sha256':sha(F/'master-delta/independent-aggregate-audit.json'),'resolution':'Original frozen Google tree supplied byte-for-byte; formerly missing two relative evidence paths now resolve to their already-pinned hashes. No review record modified.'};P.write_json(F/'master-delta/independent-aggregate-audit-clean.json',result);print(json.dumps({'status':result['status'],'issues':issues,'checks':len(checks),'reference_checks':len(refs)}))
