// SPDX-License-Identifier: GPL-3.0-or-later
#include "InGameStatistics.h"
#include "tutorial/TutorialGuidance.h"
#include <Environment.h>
#include "EngineFixtures.h"
#include "ScopedEnvironment.h"
#include <nlohmann/json.hpp>
#include <string>
#include <sstream>
#include <memory>
#include <algorithm>
#include <iostream>
#include <utility>
#include <tuple>
#include <iterator>
#include <cmath>
#include <cstdlib>
#include "Engine.h"
#include <set>
#include "GameGUITouch.h"
#include <MapCamera.h>
#include <HostViewport.h>
#include "InGameTouchTheme.h"
#include "GameGUIDialog.h"
#include "tutorial/TutorialGuidance.h"
#include "LoadSaveDialog.h"
#include "GameGUIInternal.h"
#include "GameUtilities.h"
#include <Toolkit.h>
#include <InterfacePresentation.h>
#include <TrueTypeFont.h>
#include <StringTable.h>
#include "GlobalContainer.h"
#include "Order.h"
#include "Unit.h"
#include "Player.h"
#include "ReplayWriter.h"
#include "ReplayReader.h"
#include "usl.h"
#include "native.h"
#include "CampaignSelectorScreen.h"
#include "CampaignMenuScreen.h"
#include "ChooseMapScreen.h"
#include "CustomGameScreen.h"
#include "NewMapScreen.h"
#include "SettingsScreen.h"
#include "EndGameScreen.h"

#include "MapEdit.h"
#include "MapEditorScreen.h"
#include "CampaignEditor.h"
#include "ScriptEditorScreen.h"
#include "PhoneEditor.h"
#include "MapEditDialog.h"
#include <ScreenStack.h>
#include <BinaryStream.h>
#include <filesystem>
#include <fstream>
#include <SDL3_net/SDL_net.h>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <source_location>

static void require(bool condition, const char *message)
{
	GLOB2_REQUIRE(condition, message);
}

// Exercise the portable renderer's first draw and alternating touch transforms.
// Layout metrics stay authored; raster/font caches must survive scale changes.
static void verifyTouchFontRaster()
{
	struct Probe : GAGCore::TrueTypeFont
	{
		Probe() : TrueTypeFont("data/fonts/sans.ttf", 13) {}
		float scale() const { return renderScale; }
		unsigned misses() const { return cacheMiss; }
		size_t fonts() const { return rasterFonts.size(); }
	} font;
	auto *gfx = globalContainer->gfx;
	const std::string text = "Workers 123";
	const int width = font.getStringWidth(text), height = font.getStringHeight(text);
	auto draw = [&](float scale)
	{
		gfx->setUITransform(scale, 10, 10);
		gfx->drawString(0, 0, &font, text);
		require(font.getStringWidth(text) == width && font.getStringHeight(text) == height,
				"Sharper font raster must not change layout metrics");
		gfx->setUITransform();
	};
	draw(2);
	require(font.scale() >= 2, "First portable draw must rasterize at the transformed resolution");
	draw(1);
	draw(2);
	const auto misses = font.misses();
	const auto fonts = font.fonts();
	draw(1);
	draw(2);
	require(font.misses() == misses && font.fonts() == fonts,
			"Alternating UI scales must reuse glyph and font caches");
	GAGCore::DrawableSurface offscreen(width, height);
	offscreen.drawString(0, 0, &font, text);
	// Measurement no longer pre-rasterizes the authored size. Its first actual
	// offscreen draw may create that bitmap; subsequent draws must reuse it.
	const auto offscreenMisses = font.misses();
	offscreen.drawString(0, 0, &font, text);
	require(font.misses() == offscreenMisses, "Logical offscreen text must reuse the authored raster");
}
class GameGUITouchHarness
{
  public:
	static void semanticControls()
	{
		using namespace GAGGUI::ui;
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Semantic", 0, BasePlayer::P_LOCAL);
		REQUIRE(gui.loadFromHeaders(map, players, true, true));
		gui.localTeamNo = gui.localPlayer = 0;
		gui.adjustLocalTeam();
		gui.game.map.setMapDiscovered();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		globalContainer->gfx->setResponsiveViewport(true, 800, 600);
		auto &touch = *gui.touch;
		gui.clearSelection();
		gui.displayMode = GameGUI::CONSTRUCTION_VIEW;
		touch.panelOpen = false;
		glob2test::drawGUI(gui, 0);
		auto act = [&](const std::string &key, SemanticAction action = {})
		{
			std::string error;
			const bool applied = gui.hudInspectionHost().act(key, action, error);
			INFO(error);
			CHECK(applied);
		};
		act("touch/navigation/buildings");
		CHECK(touch.panelOpen);
		std::string item;
		for (const auto &control : touch.describeControls())
			if (control.enabled && control.key.starts_with("touch/palette/") && control.role == "button")
			{ item = control.key; break; }
		REQUIRE_FALSE(item.empty());
		act(item);
		CHECK(gui.selectionMode == GameGUI::TOOL_SELECTION);
		std::string error;
		CHECK_FALSE(gui.hudInspectionHost().act("touch/placement/confirm", {}, error));
		act("touch/placement/cancel");
		act("touch/navigation/tools");
		REQUIRE(touch.lensVisible());
		act("touch/lens/50");
		CHECK(touch.peekOpen);
		CHECK_FALSE(gui.hudInspectionHost().find("touch/navigation/menu"));
		act("touch/peek/done");
		act("touch/lens/3");
		REQUIRE(touch.statsOpen);
		auto &panel = gui.statistics();
        gui.inspectionHosts();
        REQUIRE(panel.host().find("stats/topic/2"));
        REQUIRE(panel.host().act("stats/topic/2", {}, error));
        CHECK(panel.topic() == InGameStatisticsPanel::Topic::Economy);
		act("touch/statistics/sheet", {ActionKind::Scroll, -80});
		CHECK(touch.statsOpen);
		act("touch/statistics/sheet", {ActionKind::Scroll, 0});
		CHECK(touch.statsOpen);
		const int pull = int(std::ceil(80 * globalContainer->gfx->logicalUnitsPerPoint()));
		act("touch/statistics/sheet", {ActionKind::Scroll, pull});
		CHECK_FALSE(touch.statsOpen);
		CHECK(touch.statsDrag == 0);
		act("touch/lens/3");
		act("touch/statistics/close");
		// Placement confirmation is bound to the tool and exact pending world
		// position, although its visible label/rectangle remain unchanged.
		gui.setSelection(GameGUI::TOOL_SELECTION, const_cast<char *>("inn"));
		touch.previewType = "inn";
		touch.preview = GAGCore::ViewPoint{320, 320};
		auto command = semanticDispatch();
		const auto snapshot = gui.hudInspectionHost().inspect();
		command->surface = snapshot.instance;
		command->key = "touch/placement/confirm";
		command->action = {};
		std::function<void(const std::vector<ControlSnapshot> &)> find = [&](const auto &nodes)
		{
			for (const auto &node : nodes)
			{
				if (node.key == command->key) command->revision = node.revision;
				find(node.children);
			}
		};
		find(snapshot.controls);
		REQUIRE(command->revision > 0);
		touch.preview->x += 32;
		CHECK(gui.hudInspectionHost().event(command->event()));
		CHECK_FALSE(command->error.empty());
		CHECK(gui.getOrder()->getOrderType() == ORDER_NULL);
		act("touch/placement/cancel");
		int slot = 0;
		while (gui.localTeam->myBuildings[slot]) ++slot;
		auto *building = new Building(0, 0, slot, gui.game.buildingsTypes.getTypeNum("inn", 0, false),
			gui.localTeam, &gui.game.buildingsTypes, 1, 1);
		gui.localTeam->attachBuilding(slot, building);
		gui.setSelection(GameGUI::BUILDING_SELECTION, building);
		touch.panelOpen = true;
		glob2test::drawGUI(gui, 0);
		std::string workers;
		int before = 0;
		for (const auto &control : touch.describeControls())
			if (control.key.starts_with("touch/building/") && control.key.find("/6/") != std::string::npos &&
				std::find(control.actions.begin(), control.actions.end(), ActionKind::SetValue) != control.actions.end())
			{ workers = control.key; before = std::get<int>(control.value); break; }
		REQUIRE_FALSE(workers.empty());
		const int requested = before > 0 ? before - 1 : 1;
		act(workers, {ActionKind::SetValue, requested});
		CHECK(gui.getOrder()->getOrderType() == ORDER_MODIFY_BUILDING);
		CHECK(gui.getOrder()->getOrderType() == ORDER_NULL);
		CHECK_FALSE(gui.hudInspectionHost().act(workers, {ActionKind::SetValue, building->type->semantics.assignmentLimit + 1}, error));
		CHECK(gui.getOrder()->getOrderType() == ORDER_NULL);
		globalContainer->liveSpectating = true;
		CHECK_FALSE(gui.hudInspectionHost().act(workers, {ActionKind::SetValue, before}, error));
		CHECK(gui.getOrder()->getOrderType() == ORDER_NULL);
		// Live spectators get the same view-only tactical operations as replays.
		// This is deliberately not a replay, to exercise the ownership gate.
		REQUIRE_FALSE(globalContainer->replaying);
		gui.clearSelection();
		gui.displayMode = GameGUI::STAT_TEXT_VIEW;
		touch.panelOpen = true;
		touch.panelScroll = 0;
		glob2test::drawGUI(gui, 0);
		std::string fog;
		for (const auto &control : touch.describeControls())
			if (control.key.starts_with("touch/tactical/31/")) { fog = control.key; break; }
		REQUIRE_FALSE(fog.empty());
		const bool beforeFog = globalContainer->replayShowFog;
		act(fog);
		CHECK(bool(globalContainer->replayShowFog) != beforeFog);
		CHECK(gui.getOrder()->getOrderType() == ORDER_NULL);
		globalContainer->liveSpectating = false;
	}

	static void occludedControls()
	{
		using namespace GAGGUI::ui;
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Ownership", 0, BasePlayer::P_LOCAL);
		REQUIRE(gui.loadFromHeaders(map, players, true, true));
		gui.localTeamNo = gui.localPlayer = 0;
		gui.adjustLocalTeam();
		gui.game.map.setMapDiscovered();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		auto *gfx = globalContainer->gfx;
		gfx->setResponsiveViewport(true, 800, 600);
		auto &touch = *gui.touch;
		gui.displayMode = GameGUI::CONSTRUCTION_VIEW;
		touch.panelOpen = false;
		glob2test::drawGUI(gui, 0);
		auto cover = [&](Rect r)
		{
			auto lesson = std::make_shared<Tutorial::Model>();
			lesson->lessonId = "ownership"; lesson->stepId = "covered"; lesson->count = 1;
			lesson->title = lesson->instruction = lesson->touchInstruction = "[intro help]";
			gui.tutorialGuidance = std::make_unique<Tutorial::Guidance>([](int) {});
			gui.tutorialGuidance->model(lesson);
			gui.tutorialGuidance->attach(*gfx);
			auto &host = gui.tutorialGuidance->host();
			host.setAvailable([r](const auto &, const auto &) { return r; });
			host.setPlacement([](Size, Rect area) { return area; });
			host.invalidate(); host.layoutIfNeeded();
		};
		const auto button = gui.hudInspectionHost().bounds("touch/navigation/buildings");
		REQUIRE(button.w > 0);
		cover({button.x + button.w / 2, button.y, button.w - button.w / 2, button.h});
		std::string error;
		CHECK_FALSE(gui.hudInspectionHost().act("touch/navigation/buildings", {}, error));
		touch.interfaceTap({double(button.x + button.w / 4), double(button.center().y)});
		CHECK_FALSE(touch.panelOpen); // Uncovered half follows the same conservative eligibility.
		const auto keyboard = touch.keyboardTargets();
		auto targetKey = [&](const ViewRect &r)
		{ return touch.pointerControlKey({r.x + r.w / 2, r.y + r.h / 2}); };
		for (size_t i = 0; i < keyboard.size(); ++i)
			if (targetKey(keyboard[i]) == "touch/navigation/buildings") touch.keyboardFocus = int(i);
		REQUIRE(touch.focusedControlKey() == "touch/navigation/buildings");
		auto focusedState = [&]()
		{
			std::optional<ControlSnapshot> focused;
			std::function<void(const std::vector<ControlSnapshot> &)> visit = [&](const auto &nodes)
			{
				for (const auto &node : nodes)
				{
					if (node.focused) focused = node;
					visit(node.children);
				}
			};
			visit(gui.hudInspectionHost().inspect().controls);
			return focused;
		};
		const auto obscuredFocus = focusedState();
		REQUIRE(obscuredFocus);
		CHECK(obscuredFocus->key == "touch/navigation/buildings");
		CHECK(obscuredFocus->blocked); // Keep real legacy focus visible even after another surface covers it.
		SDL_Event tab{}; tab.type = SDL_EVENT_KEY_DOWN; tab.key.key = SDLK_TAB;
		CHECK(touch.process(tab));
		const auto advancedFocus = focusedState();
		REQUIRE(advancedFocus);
		CHECK(advancedFocus->key != obscuredFocus->key);
		CHECK_FALSE(advancedFocus->blocked);
		CHECK(advancedFocus->key == touch.focusedControlKey());
		CHECK(touch.keyboardTargets().size() == keyboard.size()); // Filtering preserves authored target order and geometry.
		cover({0, 0, gfx->getW(), gfx->getH()});
		CHECK(touch.process(tab));
		CHECK(touch.keyboardFocus == -1);
		CHECK_FALSE(focusedState());
		gui.tutorialGuidance.reset();
		// Statistics temporarily hides guidance, so the sheet header remains
        // actionable even if the suspended lesson occupied the same pixels.
		touch.statsOpen = true;
		const auto sheet = touch.statsLayout();
		const auto sheetBounds = gui.hudInspectionHost().bounds("touch/statistics/sheet");
		REQUIRE(sheetBounds.w > 20);
		cover({sheetBounds.right() - 10, sheetBounds.y, 10, sheetBounds.h});
		CHECK(gui.hudInspectionHost().act("touch/statistics/sheet", {ActionKind::Scroll, 100}, error));
        CHECK_FALSE(touch.statsOpen);
        touch.statsOpen = true;
		const auto start = sheet.title;
		for (const auto type : {SDL_EVENT_FINGER_DOWN, SDL_EVENT_FINGER_MOTION, SDL_EVENT_FINGER_UP})
		{
			SDL_Event finger{}; finger.type = type;
			finger.tfinger.touchID = 83; finger.tfinger.fingerID = 1;
			finger.tfinger.x = float(start.x + start.w / 2) / gfx->getW();
			finger.tfinger.y = float(start.y + start.h / 2 + (type == SDL_EVENT_FINGER_DOWN ? 0 : 80 * gfx->logicalUnitsPerPoint())) / gfx->getH();
			CHECK(touch.process(finger));
		}
		CHECK_FALSE(touch.statsOpen);
		CHECK(touch.statsDrag == 0);
		touch.statsOpen = false;
		touch.cancel();
		gui.tutorialGuidance.reset();
		REQUIRE(gui.hudInspectionHost().act("touch/navigation/buildings", {}, error));
		REQUIRE(touch.panelOpen);
		const auto scroll = gui.hudInspectionHost().bounds("touch/palette/scroll");
		REQUIRE(scroll.w > 0);
		cover({scroll.x + scroll.w / 2, scroll.y, scroll.w - scroll.w / 2, scroll.h});
		const double offset = touch.panelScroll;
		SDL_Event wheel{}; wheel.type = SDL_EVENT_MOUSE_WHEEL;
		wheel.wheel.mouse_x = scroll.x + scroll.w / 4; wheel.wheel.mouse_y = scroll.center().y;
		wheel.wheel.y = -3;
		CHECK(touch.process(wheel));
		CHECK(touch.panelScroll == offset);
		SDL_Event page{}; page.type = SDL_EVENT_KEY_DOWN; page.key.key = SDLK_PAGEDOWN;
		CHECK(touch.process(page));
		CHECK(touch.panelScroll == offset);
		gui.tutorialGuidance.reset();
		int slot = 0;
		while (gui.localTeam->myBuildings[slot]) ++slot;
		auto *building = new Building(0, 0, slot, gui.game.buildingsTypes.getTypeNum("inn", 0, false),
			gui.localTeam, &gui.game.buildingsTypes, 1, 1);
		gui.localTeam->attachBuilding(slot, building);
		gui.setSelection(GameGUI::BUILDING_SELECTION, building);
		touch.panelOpen = true;
		glob2test::drawGUI(gui, 0);
		REQUIRE(touch.usesDial());
		const auto at = touch.dialActionPoint(6, 0, 0);
		const auto region = touch.dialRegionAt(at);
		REQUIRE(region);
		REQUIRE(region->part == GameGUITouch::DialRegion::Arc);
		const auto key = touch.buildingControlKey(region->action, region->part);
		const auto arc = gui.hudInspectionHost().bounds(key);
		const int width = std::max(1, arc.w / 4);
		const Rect obscured{at.x < arc.center().x ? arc.right() - width : arc.x, arc.y, width, arc.h};
		REQUIRE_FALSE(obscured.contains(Point{int(at.x), int(at.y)}));
		cover(obscured);
		CHECK_FALSE(gui.hudInspectionHost().act(key, {ActionKind::SetValue, 2}, error));
		touch.heldActionKind = 6; touch.heldActionValue = 0; touch.heldActionConfirmation = false;
		touch.interfaceTap(at);
		SDL_Event down{}; down.type = SDL_EVENT_FINGER_DOWN;
		down.tfinger.touchID = 81; down.tfinger.fingerID = 1;
		CHECK(touch.processAllocationPointer(down, at));
		CHECK_FALSE(touch.allocation);
		CHECK(gui.getOrder()->getOrderType() == ORDER_NULL);
		gui.tutorialGuidance.reset(); touch.cancel();
		gui.setSelection(GameGUI::BRUSH_SELECTION);
		gui.toolManager.activateZoneTool(GameGUIToolManager::Forbidden);
		gui.brush.defaultSelection();
		glob2test::drawGUI(gui, 0);
		const Rect coveredMap{300, 180, 64, 64};
		cover(coveredMap);
		const auto checksum = gui.game.checkSum();
		for (const auto type : {SDL_EVENT_FINGER_DOWN, SDL_EVENT_FINGER_MOTION, SDL_EVENT_FINGER_UP})
		{
			SDL_Event finger{}; finger.type = type; finger.tfinger.touchID = 82; finger.tfinger.fingerID = 1;
			finger.tfinger.x = float(coveredMap.center().x) / gfx->getW();
			finger.tfinger.y = float(coveredMap.center().y) / gfx->getH();
			CHECK(touch.process(finger));
		}
		CHECK(gui.game.checkSum() == checksum);
		CHECK(gui.getOrder()->getOrderType() == ORDER_NULL);
		gui.tutorialGuidance.reset(); touch.cancel(); gui.clearSelection();
		// Resize the actual window: responsive viewport arguments are minimum
		// logical dimensions, so changing those alone does not make it shorter.
		// At this compact landscape size the floating palette covers part of the
		// scenario message; the earlier, taller fixture leaves them disjoint.
		const int oldWidth = gfx->getW(), oldHeight = gfx->getH();
		gfx->setResponsiveViewport(true, 640, 360);
		auto *window = SDL_GetWindowFromID(gfx->windowID());
		REQUIRE(SDL_SetWindowSize(window, 640, 360));
		REQUIRE(SDL_SyncWindow(window));
		SDL_Event resize{};
		resize.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
		GAGCore::GraphicContext::translateMouseEvent(&resize);
		gui.viewportResized(oldWidth, oldHeight, gfx->getW(), gfx->getH());
		REQUIRE(gfx->getW() == 640);
		REQUIRE(gfx->getH() == 360);
		REQUIRE_FALSE(touch.layout().persistentPanel);
		gui.scriptText = std::string(30, 'x') + "\n" + std::string(30, 'y') + "\n" + std::string(30, 'z');
		gui.swallowSpaceKey = true;
		touch.panelOpen = false;
		glob2test::drawGUI(gui, 0);
		const auto lower = touch.describeControls();
		for (const auto &control : lower)
			if (control.key.starts_with("touch/scenario-message/"))
				REQUIRE(gui.hudInspectionHost().find(control.key));
		REQUIRE(gui.hudInspectionHost().act("touch/navigation/buildings", {}, error));
		REQUIRE(touch.panelOpen);
		const auto panel = touch.layout().panel;
		const Rect above{int(panel.x), int(panel.y), int(panel.w), int(panel.h)};
		bool checked = false;
		for (const auto &control : lower)
			if (control.key.starts_with("touch/scenario-message/") && control.bounds.intersects(above))
			{
				checked = true;
				CHECK_FALSE(gui.hudInspectionHost().find(control.key));
				CHECK_FALSE(gui.hudInspectionHost().act(control.key, {control.actions.front(), 32}, error));
			}
		CHECK(checked);
	}

	static void editorRailOwnership()
	{
		using namespace GAGCore;
		// The bounded opt-in must preserve old geometry where it fits, including
		// the mirrored Undo chip, while widening rather than shrinking targets.
		auto contains = [](ViewRect outer, ViewRect inner)
		{
			return inner.w > 0 && inner.h > 0 && inner.x >= outer.x - 0.001 &&
				inner.y >= outer.y - 0.001 && inner.x + inner.w <= outer.x + outer.w + 0.001 &&
				inner.y + inner.h <= outer.y + outer.h + 0.001;
		};
		for (double unit : {1., 1.25, 2.})
			for (bool left : {false, true})
				for (bool undo : {false, true})
					for (auto size : {std::pair{552., 124.}, std::pair{552., 360.}, std::pair{552., 400.}, std::pair{552., 1000.}})
					{
						const ViewRect area{8 * unit, 56 * unit, size.first * unit, size.second * unit};
						const auto rail = BrushHUD::boundedLayout(area, left, unit, true, true, undo);
						REQUIRE(rail.detents.size() == BrushTool::BRUSH_COUNT);
						for (auto rect : rail.detents)
						{
							CHECK(contains(area, rect));
							CHECK(rect.h >= InGameTouchTheme::brushRailMinimumCell * unit);
						}
						CHECK(contains(area, rail.mode));
						CHECK(contains(area, rail.pan));
						if (undo) CHECK(contains(area, rail.undo));
						if (size.second >= 360)
						{
							const auto old = BrushHUD::layout(area, left, unit, true, true, undo);
							for (size_t i = 0; i < rail.detents.size(); ++i)
							{
								CHECK(rail.detents[i].x == old.detents[i].x);
								CHECK(rail.detents[i].y == old.detents[i].y);
								CHECK(rail.detents[i].w == old.detents[i].w);
								CHECK(rail.detents[i].h == old.detents[i].h);
							}
							for (auto pair : {std::pair{rail.mode, old.mode}, std::pair{rail.pan, old.pan},
								std::pair{rail.undo, old.undo}, std::pair{rail.rail, old.rail}})
							{
								CHECK(pair.first.x == pair.second.x); CHECK(pair.first.y == pair.second.y);
								CHECK(pair.first.w == pair.second.w); CHECK(pair.first.h == pair.second.h);
							}
						}
					}
		CHECK(BrushHUD::boundedLayout({0, 0, 4, 4}, false, 1, true, true, true).detents.empty());
		CHECK(BrushHUD::boundedLayout({0, 0, 400, 400}, false, 0, true, true, true).detents.empty());
		auto *gfx = globalContainer->gfx;
		// Exercise the clipped painter against deliberately overflowing legacy
		// geometry: font transforms and the touched-size preview must retain the
		// owner clip, rather than resetting it between primitives.
		std::unique_ptr<SDL_Surface, decltype(&SDL_DestroySurface)> pixels(
			SDL_CreateSurface(568, 320, SDL_PIXELFORMAT_RGBA32), SDL_DestroySurface);
		REQUIRE(pixels);
		const ViewRect canvas{0, 48, 568, 140};
		// Fractional empty clips must not round outward to a one-pixel stripe.
		gfx->drawToSurface(pixels.get(), 1, [&]
		{
			// Offscreen passes begin in map mode; this painter belongs to the UI.
			gfx->endMapTransform();
			gfx->drawFilledRect(0, 0, 568, 320, Color(17, 23, 29));
			BrushHUD::State state;
			state.figure = 7; state.touched = 7;
			state.modeLabel = "Paint"; state.panLabel = "Pan"; state.undoLabel = "Undo";
			BrushHUD::draw(BrushHUD::layout({8, 56, 552, 124}, false, 1, true, true, true),
				state, {500.25, 0.25, 0, 319.5});
		});
		for (int y = 0; y < 320; y += 4)
			for (int x = 0; x < 568; x += 4)
			{
				Uint8 r, g, b, a;
				REQUIRE(SDL_ReadSurfacePixel(pixels.get(), x, y, &r, &g, &b, &a));
				CHECK(r == 17); CHECK(g == 23); CHECK(b == 29);
			}
		gfx->drawToSurface(pixels.get(), 1, [&]
		{
			// Offscreen passes begin in map mode; this painter belongs to the UI.
			gfx->endMapTransform();
			gfx->drawFilledRect(0, 0, 568, 320, Color(17, 23, 29));
			BrushHUD::State state;
			state.figure = 7; state.touched = 7;
			state.modeLabel = "Paint"; state.panLabel = "Pan"; state.undoLabel = "Undo";
			BrushHUD::draw(BrushHUD::layout({8, 56, 552, 124}, false, 1, true, true, true), state, canvas);
		});
		for (int y = 0; y < 320; y += 4)
			for (int x = 0; x < 568; x += 4)
				if (!canvas.contains({double(x), double(y)}))
				{
					Uint8 r, g, b, a;
					REQUIRE(SDL_ReadSurfacePixel(pixels.get(), x, y, &r, &g, &b, &a));
					CHECK(r == 17); CHECK(g == 23); CHECK(b == 29);
				}
		MapEdit editor;
		REQUIRE(editor.load("maps/balanced.map"));
		editor.phone = std::make_unique<PhoneEditor>(editor);
		auto &touch = *editor.phone;
		editor.preparePresentation();
		const int savedThumb = globalContainer->settings.thumbSide;
		const float savedScale = gfx->getUiScale();
		struct Restore
		{
			GraphicContext *gfx; int thumb; float scale;
			~Restore() { globalContainer->settings.thumbSide = thumb; gfx->setUiScale(scale); }
		} restore{gfx, savedThumb, savedScale};
		Uint32 ticks = 1000;
		auto finger = [&](Uint32 type, ViewPoint point)
		{
			SDL_Event event{}; event.type = type;
			event.tfinger.timestamp = SDL_MS_TO_NS(ticks += 400);
			event.tfinger.touchID = 29; event.tfinger.fingerID = 1;
			event.tfinger.x = point.x / gfx->getW(); event.tfinger.y = point.y / gfx->getH();
			REQUIRE(touch.event(event));
		};
		auto tap = [&](ViewPoint point) { finger(SDL_EVENT_FINGER_DOWN, point); finger(SDL_EVENT_FINGER_UP, point); };
		auto centre = [](ViewRect rect) { return ViewPoint{rect.x + rect.w / 2, rect.y + rect.h / 2}; };
		for (float scale : {1.f, 1.25f, 1.5f})
			for (auto size : {std::pair{320, 568}, std::pair{568, 320}, std::pair{568, 216}})
				for (int side : {int(Settings::THUMB_RIGHT), int(Settings::THUMB_LEFT)})
				{
					INFO("Requested " << size.first << "x" << size.second << " scale=" << scale << " thumb=" << side);
					// Keep authored viewport sizes fixed while varying native output
					// scaling; normalized real finger events must still hit the model.
					const bool scaleSet = gfx->setUiScale(scale);
					const std::string scaleError = SDL_GetError();
					INFO("Scale setter=" << scaleSet << " SDL error=" << scaleError);
					REQUIRE(scaleSet);
					// A fixed logical canvas intentionally survives raw OS window
					// resizing. Use the application's immediate viewport boundary.
					const bool resized = gfx->resizeViewport(int(size.first * scale), int(size.second * scale));
					const std::string resizeError = SDL_GetError();
					INFO("Viewport setter=" << resized << " SDL error=" << resizeError);
					REQUIRE(resized);
					SDL_Window *window = SDL_GetWindowFromID(gfx->windowID());
					globalContainer->settings.thumbSide = side;
					touch.chooseMode(0); editor.performAction("select water"); touch.prepare();
					const double unit = gfx->logicalUnitsPerPoint();
					int windowWidth = 0, windowHeight = 0, pixelWidth = 0, pixelHeight = 0;
					SDL_GetWindowSize(window, &windowWidth, &windowHeight);
					SDL_GetWindowSizeInPixels(window, &pixelWidth, &pixelHeight);
					const int logicalWidth = gfx->getW(), logicalHeight = gfx->getH();
					const auto initialSafe = touch.safe, initialContent = touch.content, initialMap = touch.mapButton();
					const bool initialTools = touch.tools, initialMapShown = touch.showsMapButton();
					INFO("Actual logical=" << logicalWidth << "x" << logicalHeight << " window=" << windowWidth << "x" << windowHeight
						<< " pixels=" << pixelWidth << "x" << pixelHeight << " unit=" << unit << " uiScale=" << gfx->getUiScale());
					REQUIRE(logicalWidth == size.first);
					REQUIRE(logicalHeight == size.second);
					INFO("Initial safe=" << initialSafe.x << "," << initialSafe.y << "," << initialSafe.w << "," << initialSafe.h
						<< " content=" << initialContent.x << "," << initialContent.y << "," << initialContent.w << "," << initialContent.h
						<< " tools=" << initialTools << " MapShown=" << initialMapShown << " Map=" << initialMap.x << "," << initialMap.y
						<< "," << initialMap.w << "," << initialMap.h);
					CHECK_FALSE((touch.showsMapButton() && !contains(touch.content, touch.mapButton())));
					if (size.second == 216) REQUIRE_FALSE(touch.showsMapButton());
					const ViewPoint done{touch.safe.x + touch.safe.w * 7 / 8, touch.safe.y + 22 * unit};
					REQUIRE(touch.hit(done) == -5);
					tap(done);
					REQUIRE(editor.selectionMode == MapEdit::PlaceNothing);
					REQUIRE_FALSE(touch.pan);
					editor.performAction("select sand"); touch.prepare();
					if (touch.rail().detents.empty())
					{
						// The ordinary selected-tab toggle is also inspectable: callers
						// can free map space without guessing another coordinate.
						if (side == Settings::THUMB_LEFT)
						{
							const auto targets = touch.controlTargets();
							const auto tab = std::find_if(targets.begin(), targets.end(), [](const auto &target)
								{ return target.control.key == "tray/mode/0"; });
							REQUIRE(tab != targets.end());
							const auto &box = tab->control.bounds;
							tap({box.x + box.w / 2., box.y + box.h / 2.});
						}
						else
						{
							std::string error;
							REQUIRE(touch.inspectionHost().act("tray/mode/0", {}, error));
						}
						REQUIRE_FALSE(touch.tools);
						touch.prepare();
						REQUIRE(touch.showsMapButton());
						CHECK(contains(touch.content, touch.mapButton()));
					}
					const auto rail = touch.rail();
					const auto finalSafe = touch.safe, finalContent = touch.content, finalMap = touch.mapButton();
					INFO("Final safe=" << finalSafe.x << "," << finalSafe.y << "," << finalSafe.w << "," << finalSafe.h
						<< " content=" << finalContent.x << "," << finalContent.y << "," << finalContent.w << "," << finalContent.h
						<< " tools=" << touch.tools << " MapShown=" << touch.showsMapButton() << " Map=" << finalMap.x << "," << finalMap.y
						<< "," << finalMap.w << "," << finalMap.h << " railCount=" << rail.detents.size()
						<< " modeBar=" << touch.modeBar.x << "," << touch.modeBar.y << "," << touch.modeBar.w << "," << touch.modeBar.h
						<< " palette=" << touch.paletteMode << " chips=" << touch.chips.size());
					REQUIRE(rail.detents.size() == BrushTool::BRUSH_COUNT);
					for (unsigned i = 0; i < BrushTool::BRUSH_COUNT; ++i)
					{
						REQUIRE(contains(touch.content, rail.detents[i]));
						std::string error;
						REQUIRE(touch.inspectionHost().act("editor/brush/shape/" + std::to_string(i), {}, error));
						CHECK(editor.brush.getFigure() == i);
					}
					for (const auto &target : touch.controlTargets())
						if (target.control.key.starts_with("editor/brush/"))
							CHECK(target.control.clip.has_value());
					tap(centre(rail.detents[2])); CHECK(editor.brush.getFigure() == 2);
					finger(SDL_EVENT_FINGER_DOWN, centre(rail.detents[0]));
					CHECK(editor.brush.getFigure() == 0); CHECK(touch.railTouched == 0);
					finger(SDL_EVENT_FINGER_MOTION, done);
					CHECK(editor.brush.getFigure() == 0); // The header never scrubs the rail.
					finger(SDL_EVENT_FINGER_MOTION, centre(rail.detents[7]));
					CHECK(editor.brush.getFigure() == 7); CHECK(touch.railTouched == 7);
					finger(SDL_EVENT_FINGER_UP, centre(rail.detents[7]));
					CHECK(touch.railTouched == -1); CHECK(editor.brush.getFigure() == 7);
					tap(centre(rail.pan)); CHECK(touch.pan);
					tap(centre(rail.pan)); CHECK_FALSE(touch.pan);
					const auto mode = editor.brush.getType(); tap(centre(rail.mode));
					CHECK(editor.brush.getType() != mode);
				}
		// A real Undo on a narrow, short canvas must not steal the opposite
		// Map button. Exercise both callbacks through the ordinary touch path.
		for (int side : {int(Settings::THUMB_RIGHT), int(Settings::THUMB_LEFT)})
		{
			REQUIRE(gfx->setUiScale(1));
			const bool resized = gfx->resizeViewport(320, 320);
			const std::string resizeError = SDL_GetError();
			INFO("Undo viewport setter=" << resized << " SDL error=" << resizeError);
			REQUIRE(resized);
			REQUIRE(gfx->getW() == 320); REQUIRE(gfx->getH() == 320);
			globalContainer->settings.thumbSide = side;
			touch.chooseMode(3); editor.performAction("select forbidden zone"); touch.prepare();
			editor.updateCamera(); editor.brush.setFigure(0);
			std::optional<std::pair<ViewPoint, ViewPoint>> stroke;
			const double unit = gfx->logicalUnitsPerPoint();
			for (int row = 1; row < 4 && !stroke; ++row)
				for (double x = touch.content.x + 8 * unit;
					x + 24 * unit < touch.content.x + touch.content.w && !stroke; x += 24 * unit)
				{
					const ViewPoint a{x, touch.content.y + touch.content.h * row / 4};
					const ViewPoint b{x + 20 * unit, a.y};
					if (touch.hit(a) == -1 && touch.hit(b) == -1) stroke = std::pair{a, b};
				}
			REQUIRE(stroke);
			const auto [wx, wy] = editor.camera.screenToWorld(stroke->first.x, stroke->first.y);
			const int tx = int(std::floor(wx / 32)) & editor.game.map.wMask;
			const int ty = int(std::floor(wy / 32)) & editor.game.map.hMask;
			const auto before = editor.game.map.getTile(tx, ty).forbidden;
			editor.brush.setType(before & (1u << editor.team) ? BrushTool::MODE_DEL : BrushTool::MODE_ADD);
			finger(SDL_EVENT_FINGER_DOWN, stroke->first);
			finger(SDL_EVENT_FINGER_MOTION, stroke->second);
			finger(SDL_EVENT_FINGER_UP, stroke->second);
			REQUIRE(touch.undo.has_value());
			editor.preparePresentation();
			const auto rail = touch.rail();
			REQUIRE(rail.detents.size() == BrushTool::BRUSH_COUNT);
			REQUIRE(rail.undo.w >= InGameTouchTheme::brushRailMinimumCell * unit);
			REQUIRE(touch.showsMapButton());
			const auto map = touch.mapButton();
			CHECK(contains(touch.content, map));
			auto overlaps = [](ViewRect a, ViewRect b)
			{ return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h; };
			for (const auto &rect : rail.detents) CHECK_FALSE(overlaps(rect, map));
			for (auto rect : {rail.mode, rail.pan, rail.undo}) CHECK_FALSE(overlaps(rect, map));
			REQUIRE(touch.hit(centre(map)) == -305);
			tap(centre(map)); CHECK(touch.peekOpen); CHECK(touch.undo.has_value());
			std::string error;
			REQUIRE(touch.inspectionHost().act("editor/peek/done", {}, error));
			REQUIRE(touch.inspectionHost().act("editor/show-minimap", {}, error));
			CHECK(touch.peekOpen); CHECK(touch.undo.has_value());
			tap(centre(touch.peekButtons().front())); REQUIRE_FALSE(touch.peekOpen);
			REQUIRE(touch.hit(centre(rail.undo)) == -213);
			tap(centre(rail.undo)); CHECK_FALSE(touch.undo.has_value()); CHECK_FALSE(touch.peekOpen);
			CHECK(editor.game.map.getTile(tx, ty).forbidden == before);
		}
	}

	static void editorInteractions()
	{
		MapEdit editor;
		require(editor.load("maps/balanced.map"), "Editor touch fixture loads");
		editor.phone = std::make_unique<PhoneEditor>(editor);
		auto &touch = *editor.phone;
		auto *gfx = globalContainer->gfx;
		touch.chooseMode(0);
		touch.prepare();
		editor.updateCamera();
		// Separate interactions are further apart than the double-tap window.
		const Uint32 separateTouchStep = 400;
		Uint32 editorTicks = 1000, editorTickStep = separateTouchStep;
		auto finger = [&](Uint32 kind, int id, GAGCore::ViewPoint p)
		{
			SDL_Event event{};
			event.type = kind;
			event.tfinger.timestamp = SDL_MS_TO_NS(editorTicks += editorTickStep);
			event.tfinger.touchID = 19;
			event.tfinger.fingerID = id;
			event.tfinger.x = p.x / gfx->getW();
			event.tfinger.y = p.y / gfx->getH();
			touch.event(event);
		};
		const GAGCore::ViewPoint start{touch.content.x + 96, touch.content.y + 48};
		const GAGCore::ViewPoint finish{start.x + 64, start.y + 32};
		editor.performAction("select sand");
		auto checksum = [&] { return editor.game.checkSum(nullptr, nullptr, nullptr, true); };
		auto before = checksum();
		finger(SDL_EVENT_FINGER_DOWN, 1, start);
		finger(SDL_EVENT_FINGER_MOTION, 1, finish);
		touch.draw();
		require(checksum() == before,
				"Editor paint preview mutated terrain before completing the stroke");
		finger(SDL_EVENT_FINGER_UP, 1, finish);
		require(checksum() != before, "Completed editor paint stroke failed to apply");
		editor.performAction("select water");
		before = checksum();
		finger(SDL_EVENT_FINGER_DOWN, 1, start);
		finger(SDL_EVENT_FINGER_MOTION, 1, finish);
		finger(SDL_EVENT_FINGER_DOWN, 2, {finish.x + 48, finish.y});
		finger(SDL_EVENT_FINGER_UP, 2, {finish.x + 48, finish.y});
		finger(SDL_EVENT_FINGER_UP, 1, finish);
		require(checksum() == before, "Second finger committed an unfinished editor paint stroke");
		finger(SDL_EVENT_FINGER_DOWN, 1, start);
		finger(SDL_EVENT_FINGER_MOTION, 1, finish);
		SDL_Event focus{};
		focus.type = SDL_EVENT_WINDOW_RESIZED;
		focus.type = SDL_EVENT_WINDOW_FOCUS_LOST;
		touch.event(focus);
		finger(SDL_EVENT_FINGER_UP, 1, finish);
		require(checksum() == before, "Focus loss committed an unfinished editor paint stroke");
		{
			// A painted tap waits one double-tap window, as it may begin a zoom.
			finger(SDL_EVENT_FINGER_DOWN, 1, start);
			finger(SDL_EVENT_FINGER_UP, 1, start);
			require(checksum() == before && touch.deferred,
					"Editor paint tap must wait for the double-tap window");
			SDL_Delay(InGameTouchTheme::doubleTapWindowMs + 20);
			touch.draw();
			require(!touch.deferred && checksum() != before,
					"Editor paint tap must land after the double-tap window");
			// Two quick taps reset the zoom and paint nothing.
			before = checksum();
			const double u = gfx->logicalUnitsPerPoint();
			editor.camera.setZoom(1.5, finish.x, finish.y);
			editorTicks += separateTouchStep;
			editorTickStep = 50;
			finger(SDL_EVENT_FINGER_DOWN, 1, finish);
			finger(SDL_EVENT_FINGER_UP, 1, finish);
			finger(SDL_EVENT_FINGER_DOWN, 1, finish);
			finger(SDL_EVENT_FINGER_UP, 1, finish);
			editorTickStep = separateTouchStep;
			SDL_Delay(InGameTouchTheme::doubleTapWindowMs + 20);
			touch.draw();
			require(std::abs(editor.camera.zoom - 1) < 0.001 && checksum() == before,
					"Editor double tap must reset zoom instead of painting");
			// Tap, press again and drag up: one-finger zoom, still without painting.
			globalContainer->settings.oneFingerZoomDirection = Settings::ONE_FINGER_ZOOM_UP_IN;
			editorTicks += separateTouchStep;
			editorTickStep = 50;
			finger(SDL_EVENT_FINGER_DOWN, 1, finish);
			finger(SDL_EVENT_FINGER_UP, 1, finish);
			finger(SDL_EVENT_FINGER_DOWN, 1, finish);
			finger(SDL_EVENT_FINGER_MOTION, 1,
				   {finish.x, finish.y - GAGCore::TouchInput::zoomDoublingPoints / 2 * u});
			require(touch.touch.zoomDragging(), "Editor zoom drag must show its readout");
			finger(SDL_EVENT_FINGER_UP, 1,
				   {finish.x, finish.y - GAGCore::TouchInput::zoomDoublingPoints / 2 * u});
			editorTickStep = separateTouchStep;
			SDL_Delay(InGameTouchTheme::doubleTapWindowMs + 20);
			touch.draw();
			require(std::abs(editor.camera.zoom - std::sqrt(2.0)) < 0.01 && checksum() == before,
					"Editor one-finger zoom must follow the finger without painting");
			globalContainer->settings.oneFingerZoomDirection = Settings::ONE_FINGER_ZOOM_PLATFORM;
			editor.zoomMap(std::log(1.0 / editor.camera.zoom) / std::log(1.1), finish.x, finish.y);
		}
		touch.chooseMode(2);
		touch.prepare();
		editor.updateCamera();
		// The inn's placeable variant ("building/inn.0.site"), the real tray hit area.
		const auto inn = std::find_if(touch.rows.begin(), touch.rows.end(),
									  [](const auto &row) { return row.id.starts_with("building/inn."); });
		require(inn != touch.rows.end(), "The building tray offers the inn card");
		const auto icon = inn->rect;
		const GAGCore::ViewPoint source{icon.x + icon.w / 2, icon.y + icon.h / 2};
		const int type =
			editor.game.buildingsTypes.getTypeNum("inn", editor.buildingLevel, false);
		auto *building = editor.game.buildingsTypes.get(type);
		// The bundled map may open over sea; put a known legal footprint in
		// view before exercising the gesture, without changing map contents.
		bool room = false;
		for (int y = 0; y < editor.game.map.getH() && !room; ++y)
			for (int x = 0; x < editor.game.map.getW(); ++x)
			{
				int bx, by;
				if (editor.game.checkRoomForBuilding(x, y, building, &bx, &by, editor.team, false))
				{
					int dx, dy;
					editor.game.map.cursorToBuildingPos(
						editor.mapMouseX(touch.content.x + touch.content.w / 2),
						editor.mapMouseY(touch.content.y + touch.content.h / 2 -
										 40 * gfx->logicalUnitsPerPoint()),
						building->width, building->height, &dx, &dy, 0, 0);
					editor.viewportX = (x - dx) & editor.game.map.wMask;
					editor.viewportY = (y - dy) & editor.game.map.hMask;
					room = true;
					break;
				}
			}
		require(room, "Editor map has no legal building footprint");
		editor.updateCamera();
		GAGCore::ViewPoint destination{};
		bool found = false;
		for (int y = touch.content.y + 48 * gfx->logicalUnitsPerPoint();
			 y < touch.content.y + touch.content.h - 8 && !found; y += 8)
			for (int x = touch.content.x + 16; x < touch.content.x + touch.content.w - 16; x += 8)
			{
				int mx, my, bx, by;
				editor.game.map.cursorToBuildingPos(
					editor.mapMouseX(x), editor.mapMouseY(y - 40 * gfx->logicalUnitsPerPoint()),
					building->width, building->height, &mx, &my, editor.viewportX,
					editor.viewportY);
				if (editor.game.checkRoomForBuilding(mx, my, building, &bx, &by, editor.team,
													 false))
				{
					destination = {double(x), double(y)};
					found = true;
					break;
				}
			}
		require(found, "No visible valid editor placement fixture");
		auto count = [&]
		{
			int count = 0;
			for (int t = 0; t < editor.game.mapHeader.getNumberOfTeams(); ++t)
				count += editor.game.teams[t]->liveBuildings.size();
			return count;
		};
		auto drag = [&](GAGCore::ViewPoint end)
		{
			finger(SDL_EVENT_FINGER_DOWN, 1, source);
			finger(SDL_EVENT_FINGER_MOTION, 1, destination);
			finger(SDL_EVENT_FINGER_UP, 1, end);
		};
		const int countBefore = count();
		drag(destination);
		require(count() == countBefore + 1,
				"Editor valid building drag must place exactly one building");
		drag(destination);
		require(count() == countBefore + 1, "Editor invalid occupied drop placed another building");
		drag(source);
		require(count() == countBefore + 1, "Editor UI drop placed a building");
		finger(SDL_EVENT_FINGER_DOWN, 1, source);
		finger(SDL_EVENT_FINGER_MOTION, 1, destination);
		finger(SDL_EVENT_FINGER_DOWN, 2, start);
		finger(SDL_EVENT_FINGER_UP, 1, destination);
		finger(SDL_EVENT_FINGER_UP, 2, start);
		require(count() == countBefore + 1, "Second finger committed an interrupted editor drag");
		auto tap = [&](GAGCore::ViewPoint p)
		{
			finger(SDL_EVENT_FINGER_DOWN, 1, p);
			finger(SDL_EVENT_FINGER_UP, 1, p);
		};
		touch.chooseMode(0);
		editor.performAction("select water");
		touch.prepare();
		const double u = gfx->logicalUnitsPerPoint();
		tap({touch.safe.x + touch.safe.w * 7 / 8, touch.safe.y + 22 * u});
		require(editor.selectionMode == MapEdit::PlaceNothing && !touch.pan,
				"Done did not return editor to selection");
		auto centre = [](const GAGCore::ViewRect &r) { return GAGCore::ViewPoint{r.x + r.w / 2, r.y + r.h / 2}; };
		editor.performAction("select sand");
		touch.prepare();
		{
			// The brush rail on the thumb edge: sizes, Pan, and Erase, which
			// reverts sand to grass.
			const auto rail = touch.rail();
			require(rail.detents.size() == BrushTool::BRUSH_COUNT && rail.mode.w > 0 && rail.pan.w > 0,
					"Editor rail offers sizes, Pan and Erase for sand");
			tap(centre(rail.detents[2]));
			require(editor.brush.getFigure() == 2, "Editor rail tap selects a size");
			finger(SDL_EVENT_FINGER_DOWN, 1, centre(rail.detents[0]));
			require(editor.brush.getFigure() == 0 && touch.railTouched == 0, "Touching a rail size selects it at once");
			finger(SDL_EVENT_FINGER_MOTION, 1, centre(rail.detents[7]));
			require(editor.brush.getFigure() == 7 && touch.railTouched == 7, "Scrubbing the editor rail changes the size");
			touch.draw();
			gfx->printScreen("touch-editor-rail.bmp");
			gfx->nextFrame();
			finger(SDL_EVENT_FINGER_UP, 1, centre(rail.detents[7]));
			require(touch.railTouched == -1 && editor.brush.getFigure() == 7, "Releasing the editor rail keeps the size");
			tap(centre(rail.pan));
			require(touch.pan, "The editor rail head switches to Pan");
			tap(centre(rail.pan));
			require(!touch.pan, "Editor Pan toggles off");
		}
		{
			// Zone strokes can be undone, restoring the tiles exactly.
			editor.performAction("select forbidden zone");
			touch.prepare();
			require(touch.rail().mode.w > 0, "Zones offer Paint/Erase on the rail");
			editor.brush.setFigure(6);
			const GAGCore::ViewPoint a{touch.content.x + touch.content.w / 3, touch.content.y + touch.content.h / 2},
				b{a.x + 40 * u, a.y};
			const auto [wx, wy] = editor.camera.screenToWorld(a.x, a.y);
			const int cx = int(std::floor(wx / 32)), cy = int(std::floor(wy / 32));
			auto zones = [&]
			{
				std::vector<Uint32> v;
				for (int dy = -3; dy <= 3; ++dy)
					for (int dx = -3; dx <= 6; ++dx)
						v.push_back(editor.game.map.getTile((cx + dx) & editor.game.map.wMask,
															 (cy + dy) & editor.game.map.hMask).forbidden);
				return v;
			};
			const auto zonesBefore = zones();
			finger(SDL_EVENT_FINGER_DOWN, 1, a);
			finger(SDL_EVENT_FINGER_MOTION, 1, b);
			finger(SDL_EVENT_FINGER_UP, 1, b);
			require(zones() != zonesBefore && touch.undo && touch.rail().undo.w > 0,
					"An editor zone stroke changes the map and offers Undo");
			touch.draw();
			gfx->printScreen("touch-editor-undo.bmp");
			gfx->nextFrame();
			tap(centre(touch.rail().undo));
			require(zones() == zonesBefore && !touch.undo, "Editor Undo restores the zone exactly");
			finger(SDL_EVENT_FINGER_DOWN, 1, a);
			finger(SDL_EVENT_FINGER_MOTION, 1, b);
			finger(SDL_EVENT_FINGER_UP, 1, b);
			require(bool(touch.undo), "A second zone stroke offers Undo");
			touch.undo->expires = 0;
			touch.draw();
			require(!touch.undo, "Editor Undo expires");
			editor.brush.setFigure(7);
		}
		touch.chooseMode(2);
		editor.mouseX = destination.x;
		editor.mouseY = destination.y - 40 * u;
		editor.performAction("select map building");
		// Direct fixture actions bypass MapEdit::drawMap, which publishes the
		// Scene before either the dock or phone inspector reads selected entities.
		editor.preparePresentation();
		touch.prepare();
		INFO("Editor panel=" << editor.panelMode << " selected=" << editor.selectedBuildingGID
			 << " live selection=" << bool(editor.view.selectedBuilding)
			 << " published entity=" << bool(editor.view.scene && editor.view.scene->entities.building(editor.selectedBuildingGID))
			 << " binding rows=" << editor.buildingEditRows.size()
			 << " presentation rows=" << touch.properties.size());
		require(touch.inspecting() && !touch.properties.empty(),
				"Selected building has no contextual property rows");
		auto property = touch.properties.front();
		const int oldValue = property.value->currentValue();
		editor.hasMapBeenModified = false;
		tap({property.rect.x + 22 * u, property.rect.y + 46 * u});
		editor.preparePresentation(); // Read back the frame after the human edit.
		require(property.value->currentValue() == std::max(0, oldValue - 1) &&
					editor.hasMapBeenModified,
				"Inspector step did not change named property or mark draft modified");
		tap({touch.inspector.x + touch.inspector.w - 26 * u, touch.inspector.y + 26 * u});
		require(!touch.inspecting() && touch.paletteMode == 2,
				"Closing inspector did not restore palette");
		{
			// The editor's Map button opens the map peek: drag steers, buttons zoom,
			// a tap outside closes it, and the map's contents never change.
			touch.chooseMode(0);
			touch.prepare();
			require(touch.showsMapButton(), "The editor shows its Map button");
			const auto before = checksum();
			tap(centre(touch.mapButton()));
			require(touch.peekOpen && !touch.showsMapButton(), "The Map button opens the editor peek");
			touch.draw();
			const auto peek = touch.peekRect();
			const GAGCore::ViewPoint a{peek.x + peek.w * .3, peek.y + peek.h * .3}, b{peek.x + peek.w * .7, peek.y + peek.h * .6};
			finger(SDL_EVENT_FINGER_DOWN, 1, a);
			finger(SDL_EVENT_FINGER_MOTION, 1, b);
			const int dragX = editor.viewportX, dragY = editor.viewportY;
			touch.navigatePeek(b);
			require(editor.viewportX == dragX && editor.viewportY == dragY, "Dragging in the editor peek steers the view");
			touch.navigatePeek(a);
			require(editor.viewportX != dragX || editor.viewportY != dragY, "Editor peek fixture moves the view");
			finger(SDL_EVENT_FINGER_UP, 1, b);
			touch.draw();
			gfx->printScreen("touch-editor-peek.bmp");
			gfx->nextFrame();
			const double zoom = editor.camera.zoom;
			tap(centre(touch.peekButtons()[2]));
			require(editor.camera.zoom > zoom && touch.peekOpen, "Editor peek + zooms in");
			tap(centre(touch.peekButtons()[1]));
			const GAGCore::ViewPoint outside{touch.content.x + 4 * u, touch.content.y + 4 * u};
			require(!peek.contains(outside), "Outside fixture must miss the editor peek");
			tap(outside);
			require(!touch.peekOpen && checksum() == before, "A tap outside closes the peek without editing the map");
		}
		{
			// Terrain strokes remove things, so they offer no Undo.
			touch.chooseMode(0);
			editor.performAction("select sand");
			touch.prepare();
			const GAGCore::ViewPoint a{touch.content.x + 24 * u, touch.content.y + touch.content.h - 24 * u};
			finger(SDL_EVENT_FINGER_DOWN, 1, a);
			finger(SDL_EVENT_FINGER_MOTION, 1, {a.x + 32 * u, a.y});
			finger(SDL_EVENT_FINGER_UP, 1, {a.x + 32 * u, a.y});
			require(!touch.undo && touch.rail().undo.w == 0, "Terrain strokes offer no Undo");
		}
		{
			// Tray cards come from the brush catalogue: registry resources (silica,
			// locked behind foundation resources on this legacy map), imported
			// terrain, catalogue group variants, the fertility overlay and Teams.
			auto showRow = [&](const std::string &id)
			{
				editor.preparePresentation();
				touch.prepare();
				int i = touch.rowOf(id);
				if (i < 0)
					return GAGCore::ViewPoint{-1, -1};
				touch.offset = std::clamp(touch.rows[i].x - 4 * u, 0., touch.maximum);
				touch.prepare();
				i = touch.rowOf(id);
				return centre(touch.rows[i].rect);
			};
			// The bundled map carries the legacy resources; give it the current
			// registry, as importing definitions in the editor does.
			editor.importResourceFile("data/resources/registry.json");
			editor.fertilityRequested = false;
			touch.chooseMode(1);
			const auto silica = showRow("resource/silica");
			require(silica.x >= 0, "The resource tray lists the registry's silica");
			require(touch.chips.size() > 1, "Resource groups have header chips");
			const auto *silicaEntry = editor.findBrush("resource/silica");
			const bool wasLocked = silicaEntry && silicaEntry->locked;
			const auto revision = editor.catalogRevision();
			tap(silica);
			require(editor.currentBrushId() == "resource/silica",
					"Tapping a locked registry resource enables it and selects it");
			require(editor.experimentEnabled("foundation-resources"), "Silica's experiment is carried by the map");
			if (wasLocked)
			{
				// This interaction also runs in German and Japanese. Check the
				// active message's fixed text around the experiment-name slot.
				const std::string message = GAGCore::Toolkit::getStringTable()->getString("[Enabled %0 for this map]");
				const auto slot = message.find("%0");
				require(slot != std::string::npos, "Experiment enablement message names its experiment");
				require(editor.catalogRevision() != revision &&
							editor.lastStatus().size() > message.size() - 2 &&
							editor.lastStatus().starts_with(message.substr(0, slot)) &&
							editor.lastStatus().ends_with(message.substr(slot + 2)),
						"Enabling an experiment rebuilds the tray and says so");
			}
			touch.draw();
			gfx->printScreen("touch-editor-tray-resources.bmp");
			gfx->nextFrame();
			// A catalogue group variant and imported terrain.
			touch.chooseMode(0);
			touch.prepare();
			require(touch.chips.size() > 1, "Terrain groups have header chips");
			std::string variant;
			for (const auto &group : editor.brushCatalog())
				if (group.section == BrushSection::Terrain && group.key != "classic" && group.key != "custom")
					for (const auto &entry : group.entries)
						if (variant.empty() && (group.entries.size() > 1 || entry.locked))
							variant = entry.id;
			require(!variant.empty(), "The catalogue offers a terrain group variant");
			tap(showRow(variant));
			require(editor.currentBrushId() == variant,
					"A group variant card selects that variant, enabling its experiment when locked");
			editor.game.map.importTerrainDefinitions(
				R"({"schemaVersion":1,"terrains":[{"key":"example:tray","name":"Tray terrain with a long imported name","base":"grass","properties":{"groundSpeedQ8":192},"appearance":"sand"}]})");
			const auto custom = showRow("terrain/example:tray");
			require(custom.x >= 0, "Imported terrain appears in the tray at once");
			{
				const auto &row = touch.rows[touch.rowOf("terrain/example:tray")];
				require(row.lines.size() == 2 && row.lines[0].find("Tray") == 0,
						"Long names wrap onto two lines instead of truncating");
			}
			tap(custom);
			require(editor.currentBrushId() == "terrain/example:tray", "The imported terrain card selects it");
			// Group chips jump along the strip.
			const int last = int(touch.chips.size()) - 1;
			tap(centre(touch.chips[0].rect));
			touch.prepare();
			const double before = touch.offset;
			for (int i = 0; i < 2 * last && touch.activeChip() != last; ++i)
			{
				const int target = std::min(last, touch.activeChip() + 1);
				tap(centre(touch.chips[target].rect));
				touch.prepare();
			}
			if (touch.activeChip() != last || touch.offset <= before)
				std::printf("Chip jump: active=%d last=%d offset=%g before=%g maximum=%g\n", touch.activeChip(), last,
							touch.offset, before, touch.maximum);
			require(touch.activeChip() == last && touch.offset > before, "Tapping chips jumps to their groups");
			// The fertility overlay toggles from the tray.
			editor.isFertilityOn = false;
			tap(showRow("tool/fertility"));
			require(editor.isFertilityOn && editor.needsFertility(), "The fertility card turns the overlay on");
			editor.fertilityRequested = false;
			// Painting since the overlay was computed makes the card offer a refresh.
			editor.fertilityStale = true;
			{
				const auto stale = showRow("tool/fertility");
				require(touch.rows[touch.rowOf("tool/fertility")].lines.front() != "Fertility Map" &&
							editor.fertilityOverlayStale(),
						"A stale fertility overlay relabels its card");
				tap(stale);
				require(editor.isFertilityOn && editor.needsFertility(), "Tapping a stale fertility card refreshes it");
				editor.fertilityRequested = false;
				editor.fertilityStale = false;
			}
			touch.draw();
			gfx->printScreen("touch-editor-tray-terrain.bmp");
			gfx->nextFrame();
			tap(showRow("tool/fertility"));
			require(!editor.isFertilityOn && !editor.needsFertility(), "The fertility card turns the overlay off");
			// Teams are a mode of the bar.
			touch.prepare();
			tap({touch.modeBar.x + touch.modeBar.w * 9 / 10, touch.modeBar.y + touch.modeBar.h / 2});
			require(editor.panelMode == MapEdit::Teams && touch.paletteMode == 4, "The mode bar reaches Teams");
			touch.chooseMode(0);
			editor.performAction("unselect");
		}
		std::puts(
			"PASS: editor buffered paint, focus/second-finger cancellation, one-building drag "
			"and invalid/UI drops, catalogue tray cards");
	}

	static void editorAreaNameInteractions()
	{
		auto *gfx = globalContainer->gfx;
		auto dialogTap = [&](GAGGUI::ui::UIDialog &dialog, const std::string &key)
		{
			dialog.draw(0);
			const auto r = dialog.host().bounds(key);
			SDL_Event finger{};
			finger.type = SDL_EVENT_FINGER_DOWN;
			finger.tfinger.touchID = 31;
			finger.tfinger.fingerID = 1;
			finger.tfinger.x = float(r.x + r.w / 2) / gfx->getW();
			finger.tfinger.y = float(r.y + r.h / 2) / gfx->getH();
			dialog.event(finger);
			finger.type = SDL_EVENT_FINGER_UP;
			dialog.event(finger);
		};
		AskForTextInput area("[Change Area Name]", "Northern passage");
		area.attach(*gfx);
		area.draw(0);
		require(!area.host().editing().empty(), "Area name dialog must focus its entry on open");
		SDL_Event composition{};
		composition.type = SDL_EVENT_TEXT_EDITING;
		composition.edit.text = "\xC3\xA9";
		area.event(composition);
		SDL_Event enter{};
		enter.type = SDL_EVENT_KEY_DOWN;
		enter.key.key = SDLK_RETURN;
		area.event(enter);
		require(!area.finished() && area.draft() == "Northern passage",
				"Area IME submitted provisional text");
		SDL_Event text{};
		text.type = SDL_EVENT_TEXT_INPUT;
		text.text.text = "\xC3\xA9";
		area.event(text);
		dialogTap(area, "ok");
		require(area.finished() && area.result() == AskForTextInput::OK &&
					area.getText() == "Northern passage\xC3\xA9",
				"Area touch confirmation lost native UTF-8 edits");
		AskForTextInput cancelled("[Change Area Name]", "Original");
		cancelled.attach(*gfx);
		cancelled.draw(0);
		cancelled.event(text);
		enter.key.key = SDLK_ESCAPE;
		cancelled.event(enter);
		require(cancelled.finished() && cancelled.result() == AskForTextInput::CANCEL &&
					cancelled.getText() == "Original",
				"Cancelling area name committed draft");
		std::cout << "PASS: editor area name IME, touch confirmation and cancellation\n";
	}

	static void editorFileInteractions()
	{
		auto *gfx = globalContainer->gfx;
		auto finger = [&](GAGGUI::ui::UIDialog &dialog, Uint32 kind, int id, GAGCore::ViewPoint p)
		{
			SDL_Event event{};
			event.type = kind;
			event.tfinger.touchID = 29;
			event.tfinger.fingerID = id;
			event.tfinger.x = p.x / gfx->getW();
			event.tfinger.y = p.y / gfx->getH();
			dialog.event(event);
		};
		auto tap = [&](GAGGUI::ui::UIDialog &dialog, const std::string &key)
		{
			dialog.draw(0);
			const auto r = dialog.host().bounds(key);
			const GAGCore::ViewPoint p{r.x + r.w / 2., r.y + r.h / 2.};
			finger(dialog, SDL_EVENT_FINGER_DOWN, 1, p);
			finger(dialog, SDL_EVENT_FINGER_UP, 1, p);
		};
		LoadSaveDialog save("maps", "map", false, "Save map", "touch-file-fixture", glob2FilenameToName,
							glob2NameToFilename);
		save.attach(*gfx);
		save.draw(0);
		gfx->printScreen(("localized-file-" +
						  std::to_string(GAGCore::Toolkit::getStringTable()->getLang()) + "-" +
						  std::to_string(gfx->getW()) + ".bmp")
							 .c_str());
		gfx->nextFrame();
		const double u = gfx->logicalUnitsPerPoint();
		for (const auto key : {"name", "cancel", "ok"})
		{
			const auto r = save.host().bounds(key);
			require(r.y >= 0 && r.y + r.h <= gfx->getH() && r.h >= 44 * u,
					"File dialog controls escape the viewport or the touch target");
		}
		tap(save, "name");
		SDL_Event composition{};
		composition.type = SDL_EVENT_TEXT_EDITING;
		composition.edit.text = "\xC3\xA9";
		save.event(composition);
		SDL_Event enter{};
		enter.type = SDL_EVENT_KEY_DOWN;
		enter.key.key = SDLK_RETURN;
		save.event(enter);
		require(!save.finished() && std::string(save.getName()) == "touch-file-fixture",
				"Filename IME confirmation submitted a save or committed provisional text");
		tap(save, "name");
		SDL_Event text{};
		text.type = SDL_EVENT_TEXT_INPUT;
		text.text.text = "\xC3\xA9";
		save.event(text);
		const std::string draft = "touch-file-fixture\xC3\xA9";
		require(std::string(save.getName()) == draft,
				"Native filename input lost its UTF-8 committed text");
		tap(save, "ok");
		require(save.finished() && save.result() == LoadSaveDialog::OK &&
					std::string(save.getFileName()) == glob2NameToFilename("maps", draft, "map"),
				"Touch save did not use the existing filename conversion and confirmation path");
		save.showSaveFailure();
		save.draw(0);
		require(!save.finished() && save.filePresentation().failed &&
					!save.filePresentation().status.empty() && std::string(save.getName()) == draft,
				"Save failure lost its draft or visible retry state");
		tap(save, "ok");
		require(save.finished() && save.result() == LoadSaveDialog::OK,
				"Retry did not reuse the original save command");
		struct Pending final : GAGCore::ApplicationHost::Persistence
		{
			GAGCore::ApplicationHost::PersistenceState value =
				GAGCore::ApplicationHost::PersistenceState::Pending;
			GAGCore::ApplicationHost::PersistenceState state() const override { return value; }
		};
		auto pending = std::make_unique<Pending>();
		auto *operation = pending.get();
		save.beginPersistence(std::move(pending));
		save.draw(0);
		tap(save, "name");
		save.event(text);
		tap(save, "cancel");
		require(!save.finished() && std::string(save.getName()) == draft && !save.pollPersistence(),
				"Busy file dialog accepted editing/cancellation or completed a pending save");
		operation->value = GAGCore::ApplicationHost::PersistenceState::Failed;
		require(!save.pollPersistence() && save.filePresentation().failed,
				"Persistence failure did not return the file view to its retry state");

		LoadSaveDialog load("maps", "map", true, "Load map", nullptr, glob2FilenameToName, glob2NameToFilename);
		load.attach(*gfx);
		load.draw(0);
		const auto model = load.filePresentation();
		INFO("File-list fixture: " << model.files.size() << " entries, selection " << model.selected);
		INFO("Fixture source: " << glob2test::sourceRoot() << ", source maps exist: "
			 << std::filesystem::exists(glob2test::sourceRoot() / "maps/balanced.map.gz"));
		require(model.files.size() > 1 && model.selected == -1, "File interaction fixture requires a file list");
		const auto list = load.host().bounds("files");
		require(list.h >= 44 * u, "File list must keep full touch rows");
		const GAGCore::ViewPoint bottom{list.x + 20 * u, list.y + list.h - 10 * u};
		const GAGCore::ViewPoint top{bottom.x, list.y + 10 * u};
		finger(load, SDL_EVENT_FINGER_DOWN, 1, bottom);
		finger(load, SDL_EVENT_FINGER_MOTION, 1, top);
		finger(load, SDL_EVENT_FINGER_UP, 1, top);
		require(load.filePresentation().selected == -1 && !load.finished(),
				"Swiping the file list selected a map or confirmed a load");
		load.selectPresentedFile(1);
		require(std::string(load.getName()) == model.files[1] && !load.finished(),
				"Selecting a file row did not select its semantic filename without loading");
		tap(load, "ok");
		require(load.finished() && load.result() == LoadSaveDialog::OK,
				"Explicit Load did not confirm the selected file");
		std::puts("PASS: file dialog UTF-8/IME, shared filename commands, busy/error retry "
				  "and scrolling");
	}
	static void minimapMarks()
	{
		struct Restore
		{
			std::optional<GAGCore::SafeInsets> insets = GAGCore::mobileSafeInsetsForTesting;
			~Restore() { GAGCore::mobileSafeInsetsForTesting = insets; }
		} restore;
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Marks", 0, BasePlayer::P_LOCAL);
		require(gui.loadFromHeaders(map, players, true, true), "Minimap mark fixture loads");
		gui.localTeamNo = gui.localPlayer = 0;
		gui.adjustLocalTeam();
		gui.game.map.setMapDiscovered();
		auto *gfx = globalContainer->gfx;
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		GAGCore::mobileSafeInsetsForTesting = GAGCore::SafeInsets{12, 28, 12, 16};
		gfx->setResponsiveViewport(true, 800, 600);
		const GAGCore::Color marker(255, 1, 253);
		// Read native output pixels so this checks the final transform and clip,
		// including high-DPI output, rather than repeating projection arithmetic.
		auto inspect = [&](const std::string &name, GAGCore::ViewRect bounds, bool isolated, bool visible)
		{
			std::shared_ptr<SDL_Surface> image;
			bool completed = false;
			std::string error;
			const auto capture = gfx->requestMemoryCapture([&](auto pixels, auto, auto why) {
				image = std::move(pixels); error = std::move(why); completed = true;
			});
			gfx->nextFrame();
			const auto deadline = SDL_GetTicks() + 5000;
			while (!completed && SDL_GetTicks() < deadline)
			{
				gfx->beginRenderFrame();
				SDL_Delay(1);
			}
			if (!completed) gfx->cancelMemoryCapture(capture);
			INFO(error);
			REQUIRE(image);
			const auto path = std::filesystem::path(SDL_getenv_unsafe("GLOB2_USER_DATA_DIR")) / name;
			REQUIRE(SDL_SaveBMP(image.get(), path.string().c_str()));
			const auto *format = SDL_GetPixelFormatDetails(image->format);
			REQUIRE(format->bytes_per_pixel == 4);
			INFO(name);
			// Minimap clips are integer logical rectangles, rounded outwards
			// again when mapped to native pixels by the renderer.
			const int left = int(std::floor(int(bounds.x) * double(image->w) / gfx->getW()));
			const int top = int(std::floor(int(bounds.y) * double(image->h) / gfx->getH()));
			const int right = int(std::ceil((int(bounds.x) + int(bounds.w)) * double(image->w) / gfx->getW()));
			const int bottom = int(std::ceil((int(bounds.y) + int(bounds.h)) * double(image->h) / gfx->getH()));
			int inside = 0, outside = 0, above = 0;
			for (int y = 0; y < image->h; ++y)
				for (int x = 0; x < image->w; ++x)
				{
					const auto *line = reinterpret_cast<const Uint32 *>(static_cast<const Uint8 *>(image->pixels) + y * image->pitch);
					Uint8 r, g, b;
					SDL_GetRGB(line[x], format, nullptr, &r, &g, &b);
					if (r != marker.r || g != marker.g || b != marker.b) continue;
					if (x >= left && x < right && y >= top && y < bottom) ++inside;
					else ++outside;
					if (y < top) ++above;
				}
			CHECK((inside > 0) == visible);
			if (isolated) CHECK(outside == 0);
			else CHECK(above == 0); // No desktop-position pulses above the mobile minimap.
		};
		for (const auto [width, height] : {std::pair{360, 720}, {720, 360}})
		{
			const int oldW = gfx->getW(), oldH = gfx->getH();
			SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
			REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())));
			SDL_Event resize{};
			resize.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
			GAGCore::GraphicContext::translateMouseEvent(&resize);
			gui.viewportResized(oldW, oldH, gfx->getW(), gfx->getH());
			glob2test::drawGUI(gui, 0);
			const auto &team = gui.drawnScene().entities.teams[0];
			gui.markManager = MarkManager{};
			gui.markManager.addMark(Mark(team.startX, team.startY, marker, 30));
			gui.markManager.addMark(Mark((team.startX - gui.drawnScene().map.getW() / 2) & gui.drawnScene().map.getMaskW(), team.startY, marker, 30));
			glob2test::drawGUI(gui, 0);
			const std::string shape = width < height ? "portrait" : "landscape";
			inspect("marks-" + shape + ".bmp", gui.touch->minimapRect(), false, true);
			gfx->nextFrame();
			gfx->drawFilledRect(0, 0, gfx->getW(), gfx->getH(), GAGCore::Color(0, 0, 0));
			gui.touch->drawMinimap();
			inspect("marks-clipped-" + shape + ".bmp", gui.touch->minimapRect(), true, true);
			gfx->nextFrame();
			gfx->drawFilledRect(0, 0, gfx->getW(), gfx->getH(), GAGCore::Color(0, 0, 0));
			gui.touch->peekOpen = true;
			gui.touch->drawPeek();
			inspect("marks-peek-" + shape + ".bmp", gui.touch->peekRect(), true, true);
			gui.touch->peekOpen = false;
			gfx->nextFrame();
		}
		const auto &team = gui.drawnScene().entities.teams[0];
		gui.markManager = MarkManager{};
		gui.markManager.addMark(Mark(team.startX, team.startY, marker, 2));
		gui.markManager.drawMainView(gui.viewportX, gui.viewportY, gui.drawnScene(), &gui.camera);
		gfx->drawFilledRect(0, 0, gfx->getW(), gfx->getH(), GAGCore::Color(0, 0, 0));
		gui.touch->drawMinimap();
		gui.touch->drawMinimap();
		inspect("marks-repeat.bmp", gui.touch->minimapRect(), true, true);
		gfx->nextFrame();
		gui.markManager.drawMainView(gui.viewportX, gui.viewportY, gui.drawnScene(), &gui.camera);
		gfx->drawFilledRect(0, 0, gfx->getW(), gfx->getH(), GAGCore::Color(0, 0, 0));
		gui.touch->drawMinimap();
		inspect("marks-expired.bmp", gui.touch->minimapRect(), true, false);
		gfx->nextFrame();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
	}

	static void spectatorBuildings()
	{
		struct Restore
		{
			bool replay = globalContainer->replaying, live = globalContainer->liveSpectating;
			~Restore() { globalContainer->replaying = replay; globalContainer->liveSpectating = live; }
		} restore;
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(2);
		players.getBasePlayer(0) = BasePlayer(0, "Viewer", 0, BasePlayer::P_LOCAL);
		players.getBasePlayer(1) = BasePlayer(1, "Other colony", 1, BasePlayer::P_AI);
		require(gui.loadFromHeaders(map, players, true, true), "Spectator fixture loads");
		gui.localTeamNo = gui.localPlayer = 0;
		gui.adjustLocalTeam();
		gui.game.map.setMapDiscovered();
		gui.gamePaused = false;
		auto *gfx = globalContainer->gfx;
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		gfx->setResponsiveViewport(true, 800, 600);
		Uint64 now = 20000;
		auto finger = [&](Uint32 type, GAGCore::ViewPoint point) {
			SDL_Event event{};
			event.type = type;
			event.tfinger.timestamp = SDL_MS_TO_NS(now);
			event.tfinger.touchID = 7;
			event.tfinger.fingerID = 1;
			event.tfinger.x = float(point.x / gfx->getW());
			event.tfinger.y = float(point.y / gfx->getH());
			gui.processEvent(&event);
			now += 30;
		};
		for (int owner : {0, 1})
		for (const char *name : {"swarm", "warflag", "clearingflag"})
		{
			auto *team = gui.game.teams[owner];
			int slot = 0;
			while (team->myBuildings[slot]) ++slot;
			auto *building = new Building(0, 0, Building::GIDfrom(slot, owner), gui.game.buildingsTypes.getTypeNum(name, 0, false),
				team, &gui.game.buildingsTypes, 1, 1);
			team->attachBuilding(slot, building);
			building->maxUnitWorking = 7;
			building->priority = 1;
			building->unitStayRange = 11;
			building->minLevelToFlag = 2;
			building->minWorkerLevelToFlag = 2;
			building->ratio[0] = 2; building->ratio[1] = 3; building->ratio[2] = 5;
			for (bool replay : {false, true})
			for (const auto [width, height] : {std::pair{360, 720}, {720, 360}, {800, 600}})
			{
				globalContainer->replaying = replay;
				globalContainer->liveSpectating = !replay;
				GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", width == 800 ? "touch-auto" : "1", 1);
				const int oldW = gfx->getW(), oldH = gfx->getH();
				SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
				REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())));
				SDL_Event resize{};
				resize.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
				GAGCore::GraphicContext::translateMouseEvent(&resize);
				gui.viewportResized(oldW, oldH, gfx->getW(), gfx->getH());
				gui.setSelection(GameGUI::BUILDING_SELECTION, building);
				gui.touch->panelOpen = true;
				glob2test::drawGUI(gui, 0);
				CHECK((gfx->getW() < gfx->getH()) == (width < height));
				const auto rows = gui.touch->buildingActions();
				REQUIRE_FALSE(rows.empty());
				CHECK(std::any_of(rows.begin(), rows.end(), [](const auto &row) { return row.kind == 6; }));
				CHECK(std::any_of(rows.begin(), rows.end(), [](const auto &row) { return row.kind == 7; }));
				const auto *panel = gui.touch->inspectedBuilding();
				REQUIRE(panel);
				CHECK(gui.displayedMaxUnitWorking(*panel) == 7);
				CHECK(gui.displayedPriority(*panel) == 1);
				if (std::string(name) == "swarm")
				{
					CHECK(gui.touch->dialRatios() == std::array<int, 3>{2, 3, 5});
					CHECK(std::count_if(rows.begin(), rows.end(), [](const auto &row) { return row.kind == 0; }) == 3);
					CHECK_FALSE(gui.touch->buildingInventory(gui.touch->layout()).cells.empty());
				}
				else
				{
					CHECK(gui.displayedUnitStayRange(*panel) == 11);
					CHECK(std::any_of(rows.begin(), rows.end(), [](const auto &row) { return row.kind == 8; }));
					const int kind = std::string(name) == "warflag" ? 2 : 12;
					CHECK(std::any_of(rows.begin(), rows.end(), [kind](const auto &row) {
						return row.kind == kind && row.value == 2 && row.selected;
					}));
				}
				CHECK(gui.touch->keyboardTargets().size() == 7); // Toolbar and close only.
				std::vector<GAGCore::ViewPoint> controls;
				if (gui.touch->usesDial())
					for (const auto &region : gui.touch->dialRegions())
					{
						const auto &g = gui.touch->dialLayout(gui.touch->layout()).geometry;
						controls.push_back(region.ring < 0 ? GAGCore::ViewPoint{region.box.x + region.box.w / 2,
							region.box.y + region.box.h / 2} : TouchDial::point(g, g.rings[region.ring].middle(),
							(region.from + region.to) / 2));
					}
				else
					for (size_t i = 0; i < rows.size(); ++i)
					{
						const auto box = gui.touch->buildingActionRect(i);
						if (gui.touch->panelContent().contains({box.x + box.w / 2, box.y + box.h / 2}))
							controls.push_back({box.x + box.w - 16, box.y + box.h / 2});
					}
				REQUIRE_FALSE(controls.empty());
				const auto checksum = gui.game.checkSum();
				for (const auto point : controls)
				{
					// The first tap can switch pointer mode; the second must also be inert.
					for (int tap = 0; tap < 2; ++tap)
					{
						finger(SDL_EVENT_FINGER_DOWN, point);
						finger(SDL_EVENT_FINGER_UP, point);
					}
					finger(SDL_EVENT_FINGER_DOWN, point);
					finger(SDL_EVENT_FINGER_MOTION, {point.x - 10, point.y + 10});
					CHECK_FALSE(gui.touch->allocation.has_value());
					finger(SDL_EVENT_FINGER_UP, {point.x - 10, point.y + 10});
					SDL_Event mouse{};
					mouse.type = SDL_EVENT_MOUSE_BUTTON_DOWN;
					mouse.button.button = SDL_BUTTON_LEFT;
					mouse.button.x = float(point.x); mouse.button.y = float(point.y);
					for (int click = 0; click < 2; ++click)
					{
						mouse.type = SDL_EVENT_MOUSE_BUTTON_DOWN;
						gui.processEvent(&mouse);
						mouse.type = SDL_EVENT_MOUSE_BUTTON_UP;
						gui.processEvent(&mouse);
					}
				}
				CHECK(gui.orderQueue.empty());
				CHECK(gui.buildingGuiState.empty());
				CHECK_FALSE(gui.touch->confirmDestroy);
				CHECK(gui.game.checkSum() == checksum);
				CHECK(gui.selectionMode == GameGUI::BUILDING_SELECTION);
				if (owner == 1 && !replay)
					gfx->printScreen(std::string("spectator-") + name + "-" + std::to_string(width) + ".bmp");
				gfx->nextFrame();
				gui.touch->cancel();
			}
		}
		const auto header = gui.touch->allocationRect();
		gui.touch->interfaceTap({header.x + header.w - 24 * gfx->logicalUnitsPerPoint(), header.y + header.h / 2});
		CHECK(gui.selectionMode == GameGUI::NO_SELECTION);
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
	}

	static void inventory()
	{
		struct Restore
		{
			double text = GAGCore::userTextScale;
			~Restore() { GAGCore::userTextScale = text; }
		} restore;
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Inventory", 0, BasePlayer::P_LOCAL);
		require(gui.loadFromHeaders(map, players, true, true), "Inventory fixture loads");
		gui.localTeamNo = gui.localPlayer = 0;
		gui.adjustLocalTeam();
		gui.game.map.setMapDiscovered();
		auto *gfx = globalContainer->gfx;
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		gfx->setResponsiveViewport(true, 800, 600);
		int slot = 0;
		for (const auto &[name, site] : {std::pair{"swarm", false}, {"inn", false}, {"swarm", true}})
		{
			while (gui.localTeam->myBuildings[slot]) ++slot;
			auto *building = new Building(0, 0, slot, gui.game.buildingsTypes.getTypeNum(name, 0, site),
				gui.localTeam, &gui.game.buildingsTypes, 1, 1);
			gui.localTeam->attachBuilding(slot, building);
			int count = 0;
			for (int material = 0; material < MaterialCount; ++material)
				if (building->type->maxMaterial[material] > 0)
				{
					building->setMaterial(material, count++ % 2 ? 0 : building->type->maxMaterial[material] / 2);
				}
			REQUIRE(count > 0);
			gui.setSelection(GameGUI::BUILDING_SELECTION, building);
			gui.touch->panelOpen = true;
			CHECK(gui.touch->buildingInventory(gui.touch->layout()).cells.empty());
			for (const auto [width, height] : {std::pair{360, 720}, {720, 360}, {800, 600}})
			{
				GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", width == 800 ? "touch-auto" : "1", 1);
				const int oldW = gfx->getW(), oldH = gfx->getH();
				SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
				REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())));
				SDL_Event resize{};
				resize.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
				GAGCore::GraphicContext::translateMouseEvent(&resize);
				gui.viewportResized(oldW, oldH, gfx->getW(), gfx->getH());
				for (const double text : {1., 1.5})
				{
					GAGCore::userTextScale = text;
					glob2test::drawGUI(gui, 0);
					const auto ui = gui.touch->layout();
					const auto inventory = gui.touch->buildingInventory(ui);
					const auto hud = gui.touch->hudLayout(ui);
					const double unit = gfx->logicalUnitsPerPoint();
					for (const auto &cell : hud.cells)
						CHECK(cell.h == doctest::Approx(40 * unit));
					CHECK(hud.stats.y + hud.stats.h == doctest::Approx(hud.cells[4].y + hud.cells[4].h));
					CHECK(hud.identity.y == doctest::Approx(hud.stats.y + hud.stats.h + 4 * unit));
					if (hud.cells[3].y > hud.cells[0].y)
					{
						CHECK(hud.cells[3].x == doctest::Approx(hud.cells[0].x));
						CHECK(hud.cells[3].w == doctest::Approx(hud.cells[0].w));
						CHECK(hud.cells[4].x == doctest::Approx(hud.cells[1].x));
						CHECK(hud.cells[4].x + hud.cells[4].w == doctest::Approx(hud.cells[2].x + hud.cells[2].w));
					}
					CHECK(inventory.cells.size() == count);
					CHECK(inventory.bounds.y == doctest::Approx(gui.touch->allocationRect().y + gui.touch->allocationRect().h));
					size_t index = 0;
					for (int material = 0; material < MaterialCount; ++material)
						if (building->type->maxMaterial[material] > 0)
						{
							const auto &[cell, label] = inventory.cells.at(index++);
							CHECK(label == std::string(getMaterialName(material)) + " " + std::to_string(building->material(material)) +
								"/" + std::to_string(building->type->maxMaterial[material]));
							CHECK(cell.y + cell.h <= ui.actions.y);
							CHECK(gui.touch->interfaceRegion({cell.x + cell.w / 2, cell.y + cell.h / 2}) == 3);
							const auto lines = gui.touch->pointLines(label, cell.w, .8).size();
							CHECK(cell.h >= lines * globalContainer->standardFont->getStringHeight("Ag") * .8 * gfx->textUnitsPerPoint());
						}
					if (ui.persistentPanel)
						CHECK(gui.touch->panelContent().y >= inventory.bounds.y + inventory.bounds.h);
					else
						CHECK(gui.touch->notificationBounds().y >= inventory.bounds.y + inventory.bounds.h);
					if (!ui.persistentPanel && !gui.touch->usesDial())
						CHECK(ui.panel.y >= inventory.bounds.y + inventory.bounds.h);
					else if (gui.touch->usesDial())
					{
						const auto dial = gui.touch->dialLayout(ui);
						CHECK(TouchDial::point(dial.geometry, dial.geometry.rings[0].outer, dial.geometry.sweepEnd).y >=
							inventory.bounds.y + inventory.bounds.h);
					}
					gfx->printScreen(std::string("inventory-") + name + (site ? "-site-" : "-") +
						std::to_string(width) + "-" + std::to_string(int(text * 100)) + ".bmp");
					gfx->nextFrame();
					gui.touch->confirmDestroy = true;
					glob2test::drawGUI(gui, 0);
					const auto choices = gui.touch->buildingActions();
					REQUIRE(choices.size() == 2);
					CHECK(choices[0].kind == 4);
					CHECK(choices[1].kind == 5);
					if (!gui.touch->usesDial())
					{
						const auto content = gui.touch->panelContent();
						for (size_t i = 0; i < choices.size(); ++i)
						{
							const auto box = gui.touch->buildingActionRect(i);
							CHECK(box.y >= content.y);
							CHECK(box.y + box.h <= content.y + content.h);
						}
					}
					gui.touch->confirmDestroy = false;
				}
			}
			const auto allies = gui.localTeam->allies;
			gui.localTeam->allies = 0;
			glob2test::drawGUI(gui, 0);
			CHECK(gui.touch->buildingInventory(gui.touch->layout()).cells.empty());
			gui.localTeam->allies = allies;
		}
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
	}

	static void tutorialTypography()
	{
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Tutorial typography", 0, BasePlayer::P_LOCAL);
		require(gui.loadFromHeaders(map, players, true, true), "Tutorial typography fixture loads");
		const auto checksum = gui.game.checkSum();
		GAGCore::TrueTypeFont font("data/fonts/sans.ttf", 13);
		auto *strings = GAGCore::Toolkit::getStringTable();
		struct Restore
		{
			GAGCore::Font *font = globalContainer->standardFont;
			double text = GAGCore::userTextScale;
			int language = GAGCore::Toolkit::getStringTable()->getLang();
			bool stringsReplaced = false;
			std::string mobile = SDL_getenv_unsafe("GLOB2_MOBILE_UI") ? SDL_getenv_unsafe("GLOB2_MOBILE_UI") : "";
			~Restore() {
				GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", mobile.c_str(), 1);
				globalContainer->standardFont = font;
				GAGCore::userTextScale = text;
				if (stringsReplaced) GAGCore::Toolkit::getStringTable()->load("data/texts.list.txt");
				GAGCore::Toolkit::getStringTable()->setLang(language);
			}
		} restore;
		globalContainer->standardFont = &font;
		GAGCore::userTextScale = 1;
		gui.scriptText = "alpha\n\nbeta";
		gui.touch->prepareScenarioMessage();
		CHECK(gui.touch->scenarioMessageLines == std::vector<std::string>{"alpha", "", "beta"});
		CHECK(gui.touch->scenarioMessageLineStep == 24);
		gui.touch->scenarioMessageCollapsed = true;
		gui.touch->prepareScenarioMessage();
		CHECK(gui.touch->scenarioMessageCollapsed); // unchanged content preserves player collapse
		strings->setLang(strings->getLangCode("de"));
		gui.touch->prepareScenarioMessage();
		CHECK_FALSE(gui.touch->scenarioMessageCollapsed); // same text, different locale invalidates
		strings->setLang(restore.language);

		gui.scriptText = "क्षि";
		gui.touch->prepareScenarioMessage();
		const int small = gui.touch->scenarioMessageLineStep;
		// An indivisible real-font conjunct wider than the slot must remain
		// whole. Reload the SAME font object to expose metric-cache invalidation.
		REQUIRE(font.load("data/fonts/sans.ttf", 1000));
		gui.touch->prepareScenarioMessage();
		CHECK(gui.touch->scenarioMessageLines == std::vector<std::string>{"क्षि"});
		CHECK(gui.touch->scenarioMessageLineStep > small);
		CHECK(gui.touch->scenarioMessageLineStep >= font.getStringHeight("क्षि"));
		CHECK(font.getStringWidth("क्षि") > gui.touch->scenarioMessageWidth);
		GAGCore::userTextScale = 1.5;
		gui.touch->prepareScenarioMessage();
		CHECK(gui.touch->scenarioMessagePitch() == doctest::Approx(gui.touch->scenarioMessageLineStep * 1.5));
		const double unit = globalContainer->gfx->logicalUnitsPerPoint();
		CHECK(gui.touch->scenarioMessageMaximum() == doctest::Approx(std::max(0.0,
			gui.touch->scenarioMessageLines.size() * gui.touch->scenarioMessagePitch() - gui.touch->scenarioMessageRect().h / unit + 16)));
		gui.swallowSpaceKey = true;
		CHECK(gui.touch->scenarioMessageFooterHeight() >= gui.touch->scenarioMessageFontHeight * 1.5 + 16);
		// Exercise real input separately from the large synthetic-extent check.
		// A normal Latin26px font at1.5x gives a footer taller than the legacy
		//48pt target, so tapping its upper area detects stale hit geometry.
		REQUIRE(font.load("data/fonts/sans.ttf", 26));
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		gui.localTeamNo = gui.localPlayer = 0;
		gui.adjustLocalTeam();
		gui.touch->panelOpen = false;
		gui.scriptText.clear();
		for (int line = 0; line < 20; ++line)
			gui.scriptText += "Scroll this instruction without acknowledging it.\n";
		gui.setIsSpaceSet(false);
		glob2test::drawGUI(gui, 0);
		const auto tutorial = gui.touch->scenarioMessageRect();
		REQUIRE(tutorial.h > 0);
		REQUIRE(gui.touch->scenarioMessageMaximum() > 0);
		Uint64 now = 20000;
		auto finger = [&](Uint32 type, double x, double y) {
			SDL_Event event{};
			event.type = type;
			event.tfinger.timestamp = SDL_MS_TO_NS(now += 40);
			event.tfinger.touchID = 7;
			event.tfinger.fingerID = 1;
			event.tfinger.x = float(x / globalContainer->gfx->getW());
			event.tfinger.y = float(y / globalContainer->gfx->getH());
			gui.processEvent(&event);
		};
		const double x = tutorial.x + 20 * unit, startY = tutorial.y + 40 * unit;
		finger(SDL_EVENT_FINGER_DOWN, x, startY);
		finger(SDL_EVENT_FINGER_MOTION, x, startY - 24 * unit);
		finger(SDL_EVENT_FINGER_UP, x, startY - 24 * unit);
		CHECK_FALSE(gui.isSpaceSet());
		CHECK(gui.touch->scenarioMessageScroll > 0);
		gui.touch->stopScrolling();
		const double footer = gui.touch->scenarioMessageFooterHeight() * unit;
		REQUIRE(footer > 48 * unit);
		const double ackY = tutorial.y + tutorial.h - footer + 4 * unit;
		REQUIRE(ackY < tutorial.y + tutorial.h - 48 * unit);
		const auto controls = gui.touch->describeControls();
		const auto continueControl = std::find_if(controls.begin(), controls.end(), [](const auto &control) {
			return control.key == "touch/scenario-message/continue";
		});
		REQUIRE(continueControl != controls.end());
		CHECK(continueControl->bounds.contains(GAGGUI::ui::Point{int(x), int(ackY)}));
		now += 500;
		finger(SDL_EVENT_FINGER_DOWN, x, ackY);
		finger(SDL_EVENT_FINGER_UP, x, ackY);
		CHECK(gui.isSpaceSet());
		gui.setIsSpaceSet(false);
		std::string semanticError;
		REQUIRE(gui.hudInspectionHost().act("touch/scenario-message/continue", {}, semanticError));
		CHECK(gui.isSpaceSet());
		// Find an actual cramped font/layout combination, rather than assuming
		// a viewport leaves less room than the requested footer. Geometry,
		// painting and both input paths must stay within that remaining panel.
		bool cramped = false;
		for (int size = 28; size <= 200; size += 2)
		{
			REQUIRE(font.load("data/fonts/sans.ttf", size));
			gui.touch->prepareScenarioMessage();
			const auto panel = gui.touch->scenarioMessageRect();
			if (panel.w > 40 * unit && panel.h > 4 * unit &&
				panel.h < gui.touch->scenarioMessageFooterHeight() * unit)
			{
				cramped = true;
				break;
			}
		}
		REQUIRE(cramped);
		glob2test::drawGUI(gui, 0);
		const auto crampedPanel = gui.touch->scenarioMessageRect();
		const auto crampedContinue = gui.touch->scenarioMessageContinueRect();
		REQUIRE(crampedContinue.h > 0);
		CHECK(crampedContinue.y == doctest::Approx(crampedPanel.y));
		CHECK(crampedContinue.h == doctest::Approx(crampedPanel.h));
		CHECK(crampedPanel.y + crampedPanel.h <= gui.touch->layout().actions.y);
		const auto crampedControls = gui.touch->describeControls();
		const auto crampedTarget = std::find_if(crampedControls.begin(), crampedControls.end(), [](const auto &control) {
			return control.key == "touch/scenario-message/continue";
		});
		REQUIRE(crampedTarget != crampedControls.end());
		CHECK(crampedTarget->bounds.y >= int(std::floor(crampedPanel.y)));
		CHECK(crampedTarget->bounds.y + crampedTarget->bounds.h <= int(std::ceil(crampedPanel.y + crampedPanel.h)));
		CHECK(std::none_of(crampedControls.begin(), crampedControls.end(), [](const auto &control) {
			return control.key == "touch/scenario-message/collapse";
		}));
		gui.setIsSpaceSet(false);
		now += 500;
		const double crampedX = crampedContinue.x + crampedContinue.w / 2,
			crampedY = crampedContinue.y + crampedContinue.h / 2;
		finger(SDL_EVENT_FINGER_DOWN, crampedX, crampedY);
		finger(SDL_EVENT_FINGER_UP, crampedX, crampedY);
		CHECK(gui.isSpaceSet());
		gui.setIsSpaceSet(false);
		REQUIRE(gui.hudInspectionHost().act("touch/scenario-message/continue", {}, semanticError));
		CHECK(gui.isSpaceSet());
		gui.touch->scenarioMessageCollapsed = true;
		const auto crampedCollapsed = gui.touch->scenarioMessageRect();
		CHECK(crampedCollapsed.y + crampedCollapsed.h <= gui.touch->layout().actions.y);
		CHECK(crampedCollapsed.h >= 0);
		gui.touch->scenarioMessageCollapsed = false;
		// Activate Urdu in an isolated two-language fixture, without registering
		// any unfinished catalog. Use the actual authored collapsed label.
		glob2test::TempDir labels("tutorial-urdu");
		GAGCore::Toolkit::getFileManager()->addDir(labels.path.string());
		std::ofstream(labels.path / "tutorial.keys.txt") << "[language-code]\n[scenario messages]\n";
		std::ofstream(labels.path / "tutorial.list.txt") << "tutorial.keys.txt\ntutorial.en.txt\ntutorial.ur.txt\n";
		std::ofstream(labels.path / "tutorial.en.txt") << "[language-code]\nen\n[scenario messages]\nMessages ▸\n";
		std::ofstream(labels.path / "tutorial.ur.txt") << "[language-code]\nur\n[scenario messages]\nپیغامات ▸\n";
		restore.stringsReplaced = true;
		REQUIRE(strings->load("tutorial.list.txt"));
		strings->setLang(strings->getLangCode("ur"));
		REQUIRE(font.load("data/fonts/sans.ttf", 13));
		gui.scriptText = "instruction";
		gui.touch->prepareScenarioMessage();
		gui.touch->scenarioMessageCollapsed = true;
		const auto collapsed = gui.touch->scenarioMessageRect();
		const auto label = strings->getString("[scenario messages]");
		const double labelHeight = font.getStringHeight(label) * 1.15 * 1.5 * unit;
		CHECK(collapsed.h >= labelHeight + 16 * unit);
		CHECK(collapsed.h >= 48 * unit);
		CHECK(collapsed.contains({collapsed.x + 1, collapsed.y + labelHeight}));
		CHECK(gui.game.checkSum() == checksum);
	}

	static void navigationTypography()
	{
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Navigation typography", 0, BasePlayer::P_LOCAL);
		require(gui.loadFromHeaders(map, players, true, true), "Navigation fixture loads");
		const auto checksum = gui.game.checkSum();
		struct CountingFont : GAGCore::TrueTypeFont {
			using TrueTypeFont::TrueTypeFont;
			unsigned widthCalls = 0;
			unsigned clusterCalls = 0;
			int getStringWidth(const std::string text) override {
				++widthCalls;
				return TrueTypeFont::getStringWidth(text);
			}
			std::vector<std::size_t> getStringClusterEnds(const std::string &text) override {
				++clusterCalls;
				return TrueTypeFont::getStringClusterEnds(text);
			}
		} font("data/fonts/sans.ttf", 13);
		auto *strings = GAGCore::Toolkit::getStringTable();
		struct Restore {
			GAGCore::Font *font = globalContainer->standardFont;
			double text = GAGCore::userTextScale;
			int language = GAGCore::Toolkit::getStringTable()->getLang();
			std::string mobile = SDL_getenv_unsafe("GLOB2_MOBILE_UI") ? SDL_getenv_unsafe("GLOB2_MOBILE_UI") : "";
			~Restore() {
				GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", mobile.c_str(), 1);
				globalContainer->standardFont = font;
				GAGCore::userTextScale = text;
				GAGCore::Toolkit::getStringTable()->load("data/texts.list.txt");
				GAGCore::Toolkit::getStringTable()->setLang(language);
			}
		} restore;
		glob2test::TempDir labels("navigation-urdu");
		GAGCore::Toolkit::getFileManager()->addDir(labels.path.string());
		const char *keys[] = {"[Build]", "[Flags]", "[Editor tools]", "[Goals]", "[Teams]", "[Menu]",
			"[Pause]", "[Speed]"};
		const char *urdu[] = {"تعمیر", "جھنڈے", "آلات", "اہداف", "ٹیمیں", "مینیو", "توقف", "رفتار"};
		std::ofstream keyFile(labels.path / "navigation.keys.txt"),
			en(labels.path / "navigation.en.txt"), ur(labels.path / "navigation.ur.txt");
		keyFile << "[language-code]\n";
		en << "[language-code]\nen\n";
		ur << "[language-code]\nur\n";
		for (int i = 0; i < 8; ++i) {
			keyFile << keys[i] << '\n';
			en << keys[i] << '\n' << std::string(keys[i]).substr(1, std::strlen(keys[i]) - 2) << '\n';
			ur << keys[i] << '\n' << urdu[i] << '\n';
		}
		keyFile.close(); en.close(); ur.close();
		std::ofstream(labels.path / "navigation.list.txt") <<
			"navigation.keys.txt\nnavigation.en.txt\nnavigation.ur.txt\n";
		REQUIRE(strings->load("navigation.list.txt"));
		strings->setLang(strings->getLangCode("ur"));
		globalContainer->standardFont = &font;
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		auto *gfx = globalContainer->gfx;
		gfx->setResponsiveViewport(true, 390, 844);
		CHECK(gfx->getW() == 390);
		CHECK(gfx->getH() == 844);
		const auto unit = gfx->logicalUnitsPerPoint();
		for (double growth : {1.0, 1.5}) {
			GAGCore::userTextScale = growth;
			const auto ui = gui.touch->layout();
			(void)gui.touch->measureNavigation(ui.actions.w / unit).height;
			const unsigned calls = font.widthCalls;
			const unsigned clusters = font.clusterCalls;
			REQUIRE(calls > 0);
			for (int repeat = 0; repeat < 10; ++repeat)
				(void)gui.touch->measureNavigation(ui.actions.w / unit).height;
			CHECK(font.widthCalls == calls + 10 * 6); // Only six whole-caption probes per cache hit.
			CHECK(font.clusterCalls == clusters); // Wrapping/shaping is not repeated on a cache hit.
			CHECK(ui.actions.h > 48 * unit);
			CHECK(ui.actions.y + ui.actions.h == doctest::Approx(ui.safe.y + ui.safe.h));
			CHECK(ui.world.y + ui.world.h == doctest::Approx(ui.actions.y));
			for (int i = 0; i < 6; ++i) {
				const auto rect = gui.touch->navigationLabelRect(ui, i);
				const auto text = gui.touch->navigationLabel(i);
				const auto lines = gui.touch->pointLines(text, rect.w, .86);
				const int height = gui.touch->navigationLabelLineHeight(lines);
				CHECK(rect.h + .001 >= lines.size() * height * .86 * gfx->textUnitsPerPoint());
				CHECK(rect.y + rect.h + 4 * unit <= ui.safe.y + ui.safe.h + .001);
				CHECK(gui.touch->interfaceRegion({rect.x + rect.w / 2, rect.y + rect.h / 2}) == 10 + i);
				gui.touch->drawPointLabel(rect, text, .86, false, height);
			}
			gfx->nextFrame();
			CHECK(gui.game.checkSum() == checksum);
		}
		// Real HarfBuzz cluster boundaries, not a codepoint-counting double:
		// an Indic conjunct larger than the available slot must remain whole.
		const std::string conjunct = "क्षि";
		CHECK(font.getStringClusterEnds(conjunct) == std::vector<std::size_t>{conjunct.size()});
		CHECK(font.getStringWidth(conjunct) > 1);
		CHECK(gui.touch->pointLines(conjunct, 1, .86) == std::vector<std::string>{conjunct});
		CHECK(gui.touch->pointLines(conjunct + "\n\n" + conjunct, 1, .86) ==
			std::vector<std::string>{conjunct, "", conjunct});
		CHECK(gui.touch->pointLines("alpha  beta\n\ngamma", 10000, .86) ==
			std::vector<std::string>{"alpha  beta", "", "gamma"});
		const auto oldHeight = gui.touch->layout().actions.h;
		const auto beforeReload = font.widthCalls;
		REQUIRE(font.load("data/fonts/sans.ttf", 20)); // Same pointer, changed metrics.
		CHECK(gui.touch->layout().actions.h > oldHeight);
		CHECK(font.widthCalls > beforeReload + 6);
		const auto beforeResize = font.widthCalls;
		(void)gui.touch->measureNavigation(240).height;
		CHECK(font.widthCalls > beforeResize + 6);
		const auto beforeReplay = font.widthCalls;
		const bool replaying = globalContainer->replaying;
		globalContainer->replaying = !replaying;
		(void)gui.touch->measureNavigation(240).height;
		globalContainer->replaying = replaying;
		CHECK(font.widthCalls > beforeReplay + 6);
		const auto beforeLanguage = font.widthCalls;
		strings->setLang(strings->getLangCode("en"));
		(void)gui.touch->measureNavigation(240).height;
		CHECK(font.widthCalls > beforeLanguage + 6);
		strings->setLang(strings->getLangCode("ur"));
	}

	static void filipinoNavigationTypography()
	{
		struct Restore
		{
			double text = GAGCore::userTextScale;
			int language = GAGCore::Toolkit::getStringTable()->getLang();
			~Restore() {
				GAGCore::userTextScale = text;
				GAGCore::Toolkit::getStringTable()->setLang(language);
			}
		} restore;
		glob2test::ScopedEnvironment mobile("GLOB2_MOBILE_UI", "1");
		auto *strings = GAGCore::Toolkit::getStringTable();
		strings->setLang(strings->getLangCode("fil"));
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Filipino navigation", 0, BasePlayer::P_LOCAL);
		require(gui.loadFromHeaders(map, players, true, true), "Filipino navigation fixture loads");
		gui.localTeamNo = gui.localPlayer = 0;
		gui.adjustLocalTeam();
		const auto checksum = gui.game.checkSum();
		auto *gfx = globalContainer->gfx;
		gfx->setResponsiveViewport(true, 390, 844);
		REQUIRE(gfx->getW() == 390);
		REQUIRE(gfx->getH() == 844);
		auto checkNavigation = [&](int expectedColumns) {
			const auto ui = gui.touch->layout();
			const double unit = gfx->logicalUnitsPerPoint();
			CHECK(gui.touch->measureNavigation(ui.actions.w / unit).columns == expectedColumns);
			const auto targets = gui.touch->keyboardTargets();
			REQUIRE(targets.size() >= 6);
			for (int i = 0; i < 6; ++i)
			{
				CAPTURE(i);
				const auto button = gui.touch->navigationButtonRect(ui, i);
				const auto rect = gui.touch->navigationLabelRect(ui, i);
				const auto text = gui.touch->navigationLabel(i);
				const auto lines = gui.touch->pointLines(text, rect.w, .86);
				{
					InGameTouchTheme::TextStyle style(globalContainer->standardFont);
					std::istringstream words(text);
					for (std::string word; words >> word;)
					{
						CHECK(globalContainer->standardFont->getStringWidth(word) <=
							rect.w / (.86 * gfx->textUnitsPerPoint()) - 8 + .001);
						CHECK(std::any_of(lines.begin(), lines.end(), [&](const auto &line) {
							return line.find(word) != std::string::npos;
						}));
					}
				}
				const auto centre = GAGCore::ViewPoint{button.x + button.w / 2, button.y + button.h / 2};
				CHECK(gui.touch->interfaceRegion(centre) == 10 + i);
				const char *keys[] = {"buildings", "flags", "tools", "objectives", "alliance", "menu"};
				const std::string key = std::string("touch/navigation/") + keys[i];
				const auto exposed = gui.hudInspectionHost().bounds(key);
				CHECK(exposed.x == int(std::floor(button.x)));
				CHECK(exposed.y == int(std::floor(button.y)));
				CHECK(exposed.w == int(std::ceil(button.x + button.w)) - exposed.x);
				CHECK(exposed.h == int(std::ceil(button.y + button.h)) - exposed.y);
				CHECK(gui.touch->pointerControlKey(centre) == key);
				CHECK(targets[i].x == doctest::Approx(button.x));
				CHECK(targets[i].y == doctest::Approx(button.y));
				CHECK(targets[i].w == doctest::Approx(button.w));
				CHECK(targets[i].h == doctest::Approx(button.h));
				CHECK(rect.y >= button.y);
				CHECK(rect.y + rect.h <= button.y + button.h + .001);
			}
			CHECK(ui.world.y + ui.world.h == doctest::Approx(ui.actions.y));
			CHECK(gui.game.checkSum() == checksum);
			return ui;
		};
		GAGCore::userTextScale = 1;
		const auto normal = checkNavigation(6);
		CHECK(normal.actions.h == doctest::Approx(64 * gfx->logicalUnitsPerPoint()));
		GAGCore::userTextScale = 1.5;
		const auto enlarged = checkNavigation(3);
		CHECK(enlarged.actions.h >= 96 * gfx->logicalUnitsPerPoint());
		glob2test::drawGUI(gui, 0);
		gfx->printScreen(glob2test::artifactDirFromWorkingDirectory() + "/filipino-hud-navigation-large.bmp");
		gfx->nextFrame();
		const int oldW = gfx->getW(), oldH = gfx->getH();
		SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), 844, 390);
		REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())));
		SDL_Event resized{};
		resized.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
		GAGCore::GraphicContext::translateMouseEvent(&resized);
		gfx->setResponsiveViewport(true, 844, 390);
		gui.viewportResized(oldW, oldH, gfx->getW(), gfx->getH());
		REQUIRE(gfx->getW() == 844);
		REQUIRE(gfx->getH() == 390);
		checkNavigation(6);
	}

	static void notifications()
	{
		struct Restore
		{
			std::optional<GAGCore::SafeInsets> insets = GAGCore::mobileSafeInsetsForTesting;
			double text = GAGCore::userTextScale;
			~Restore() { GAGCore::mobileSafeInsetsForTesting = insets; GAGCore::userTextScale = text; }
		} restore;
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Notifications", 0, BasePlayer::P_LOCAL);
		require(gui.loadFromHeaders(map, players, true, true), "Notification fixture loads");
		gui.localTeamNo = gui.localPlayer = 0;
		gui.adjustLocalTeam();
		gui.game.map.setMapDiscovered();
		auto *gfx = globalContainer->gfx;
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		GAGCore::mobileSafeInsetsForTesting = GAGCore::SafeInsets{12, 28, 12, 16};
		gfx->setResponsiveViewport(true, 800, 600);
		for (const auto [width, height] : {std::pair{360, 720}, {720, 360}})
		{
			const int oldW = gfx->getW(), oldH = gfx->getH();
			SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
			REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())));
			SDL_Event resize{};
			resize.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
			GAGCore::GraphicContext::translateMouseEvent(&resize);
			gui.viewportResized(oldW, oldH, gfx->getW(), gfx->getH());
			for (const double textSize : {1., 1.5})
			{
				GAGCore::userTextScale = textSize;
				gui.eventFeed.clear(0);
				gui.eventFeed.ingest({GEUnitUnderAttack, WORKER, 0, 20, 25,
					"Your workers are under attack near the swimming pool. Send reinforcements to defend your colony!",
					GAGCore::Color(255, 100, 100)}, SDL_GetTicks(), [](int, int, int, int) { return 10000; });
				gui.eventFeed.ingest({GEBuildingCompleted, Uint32(gui.game.buildingsTypes.getTypeNum("swarm", 0, false)), 0, 12, 14, "The swarm is finished.",
					GAGCore::Color(110, 255, 130)}, SDL_GetTicks(), [](int, int, int, int) { return 10000; });
				glob2test::drawGUI(gui, 0);
				const auto area = gui.touch->notificationBounds();
				const auto hud = gui.touch->hudLayout(gui.touch->layout());
				CHECK(area.y > hud.minimap.y + hud.minimap.h);
				CHECK(area.y > hud.stats.y + hud.stats.h);
				REQUIRE_FALSE(gui.eventFeedHits.empty());
				CHECK(gui.eventFeedHits.size() == 2);
				for (const auto &hit : gui.eventFeedHits)
				{
					CHECK(hit.x >= area.x - 1);
					CHECK(hit.y >= area.y - 1);
					CHECK(hit.x + hit.w <= area.x + area.w + 1);
					CHECK(hit.y + hit.h <= area.y + area.h + 1);
					CHECK(hit.h >= (std::max(18, globalContainer->standardFont->getStringHeight("Ag")) + 8) *
						.8 * gfx->textUnitsPerPoint() - 1);
				}
				// The single-line card uses the same .8 normal text role as the
				// building title/inventory, with room for the icon and vertical padding.
				CHECK(gui.eventFeedHits.front().h == int(std::ceil(
					(std::max(18, globalContainer->standardFont->getStringHeight("Ag")) + 8) *
					.8 * gfx->textUnitsPerPoint())));
				const auto hit = gui.eventFeedHits.front();
				CHECK(gui.handleEventFeedClick(hit.x + hit.w / 2, hit.y + hit.h / 2));
				gfx->printScreen(std::string("notifications-") + (width < height ? "portrait-" : "landscape-") +
					std::to_string(int(textSize * 100)) + ".bmp");
				gfx->nextFrame();
				// Exercise differently colored conversion icons alongside a local
				// worker, so captures expose any team-color leakage between rows.
				gui.eventFeed.clear(0);
				for (const auto [type, subject, label] : {
					std::tuple{GEUnitUnderAttack, Uint32(WORKER), "Your worker is under attack."},
					std::tuple{GEUnitLostConversion, Uint32(0), "A worker joined another team."},
					std::tuple{GEUnitGainedConversion, Uint32(1), "A worker joined your team."}})
					gui.eventFeed.ingest({type, subject, 0, 20, 25, label, GAGCore::Color(110, 255, 130)},
						SDL_GetTicks(), [](int, int, int, int) { return 10000; });
				glob2test::drawGUI(gui, 0);
				gfx->printScreen(std::string("notification-team-icons-") + (width < height ? "portrait-" : "landscape-") +
					std::to_string(int(textSize * 100)) + ".bmp");
				gfx->nextFrame();
			}
		}
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
		gui.drawEventFeed(32, 34);
		REQUIRE_FALSE(gui.eventFeedHits.empty());
		CHECK(gui.eventFeedHits.front().x == 32);
		CHECK(gui.eventFeedHits.front().y == 34);
		CHECK(gui.eventFeedHits.front().h == 20);
	}

	static void run()
	{
		{
			Usl interpreter;
			auto *constant = new NativeValue<int>(&interpreter.heap, 42);
			interpreter.setConstant("retained", constant);
			for (int cycle = 0; cycle < 100; ++cycle)
			{
				interpreter.run(1);
				require(std::find(interpreter.heap.values.begin(), interpreter.heap.values.end(),
								  constant) != interpreter.heap.values.end(),
						"Repeated script collection retains bridge constants");
				require(interpreter.getConstant("retained") == constant,
						"Script constant remains accessible");
			}
		}
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Touch", 0, BasePlayer::P_LOCAL);
		require(gui.loadFromHeaders(map, players, true, true), "Fixture load failed");
        // Keep IDs above one byte and multi-material missing art in the real UI fixture.
        using Json = nlohmann::json;
        Json additions = Json::array();
        for (unsigned i = 0; i < 300; ++i)
        {
            additions.push_back({{"key", "touch:visual-" + std::to_string(i)},
                {"properties", {{"ecology", "land"}, {"blocksGround", true}}},
                {"yields", {{"food", {{"capacity", 9}, {"initial", 2}, {"consumption", "one"}}},
                            {"paper", {{"capacity", 6}, {"initial", 4}, {"consumption", "one"}}}}},
                {"presentation", {{"name", "Mixed resource without artwork"},
                    // Only the highest ID needs missing-art coverage. Failed sprites are
                    // retried synchronously, so repeating that path for all 300 IDs
                    // needlessly stalls each registry switch in the rendering matrix.
                    {"sprite", i == 299 ? "data/gfx/touch-fixture-missing-resource" : "data/gfx/ressource"}, {"minimap", {255, 0, 255}},
                    {"levels", Json::array({{{"stock", 0}, {"variants", Json::array({{{"frame", 0}, {"weight", 1}}})}}})}}}});
        }
        gui.game.map.installResourceDefinitions(Json{{"schemaVersion", 1}, {"resources", additions}}.dump());
        const int mixedResource = int(gui.game.map.resourceRegistry().size()) - 1;
        require(mixedResource > 255, "Custom resource fixture exceeds byte identifiers");
		gui.localTeamNo = 0;
		gui.localPlayer = 0;
		gui.adjustLocalTeam();
		gui.viewportX = gui.viewportY = 0;
		{
			globalContainer->replayWriter = std::make_unique<ReplayWriter>();
			auto &writer = *globalContainer->replayWriter;
			writer.init("", gui);
			require(writer.write("replays/touch-empty.replay"),
					"An unfinished in-memory replay can be exported");
			{
				ReplayReader empty;
				require(empty.loadReplay("replays/touch-empty.replay"),
						"Replay export retains the final buffered header byte");
			}
			for (int i = 0; i < 100; ++i)
				writer.advanceStep();
			writer.finish();
			require(writer.write("replays/touch-preview.replay"), "Replay fixture writes");
			const auto position = writer.getBuffer()->getPosition();
			const auto blocked =
				std::filesystem::path(SDL_getenv_unsafe("GLOB2_USER_DATA_DIR")) / "replays/blocked.replay";
			std::filesystem::create_directories(blocked);
			{
				std::ofstream marker(blocked / "keep");
				marker << "preserve";
			}
			require(!writer.write(blocked.string()),
					"Replay replacement failure returns false without asserting");
			require(std::filesystem::exists(blocked / "keep") &&
						writer.getBuffer()->getPosition() == position,
					"Failed replay write preserves destination and live buffer position");
			std::filesystem::remove(blocked / "keep");
			std::filesystem::remove(blocked);
			require(writer.write(blocked.string()) && writer.getBuffer()->getPosition() == position,
					"Replay retries after a failed replacement");
			std::ifstream original(std::filesystem::path(SDL_getenv_unsafe("GLOB2_USER_DATA_DIR")) /
									   "replays/touch-preview.replay",
								   std::ios::binary);
			std::ifstream retried(blocked, std::ios::binary);
			require(std::string(std::istreambuf_iterator<char>(original), {}) ==
						std::string(std::istreambuf_iterator<char>(retried), {}),
					"Replay retry produces identical bytes");
			original.close();
			retried.close();
			std::filesystem::remove(blocked);
		}

		const auto checksum = gui.game.checkSum();
		Uint32 touchTicks = 1000;
		// Separate interactions are further apart than the double-tap window
		// (measured from a release to the next press); double-tap cases lower it.
		const Uint32 separateTouchStep = 400;
		Uint32 touchTickStep = separateTouchStep;
		// Begin a quick sequence (double tap) well after the previous interaction.
		auto quickTouches = [&]
		{
			touchTicks += separateTouchStep;
			touchTickStep = 50;
		};
		auto finger = [&](Uint32 type, int id, float x, float y)
		{
			SDL_Event event{};
			event.type = type;
			event.tfinger.timestamp = SDL_MS_TO_NS(touchTicks += touchTickStep);
			event.tfinger.touchID = 7;
			event.tfinger.fingerID = id;
			event.tfinger.x = x / globalContainer->gfx->getW();
			event.tfinger.y = y / globalContainer->gfx->getH();
			gui.processEvent(&event);
		};
		auto tap = [&](float x, float y)
		{
			finger(SDL_EVENT_FINGER_DOWN, 1, x, y);
			finger(SDL_EVENT_FINGER_UP, 1, x, y);
		};
		auto flag = [&]
		{ gui.setSelection(GameGUI::TOOL_SELECTION, const_cast<char *>("warflag")); };
		auto noOrder = [&](int line = __builtin_LINE())
		{
			require(!gui.toolManager.getOrder(),
					("Navigation or preview emitted a tool order (harness line " + std::to_string(line) + ")")
						.c_str());
		};
		const int innType = gui.game.buildingsTypes.getPlaceableTypeNum("inn");
		require(innType >= 0, "The stock catalog must expose a placeable inn");
		const std::string innChoice = gui.game.buildingsTypes.get(innType)->key;
        gui.prepareLocalPresentation();
		tap(760, 208);
		require(gui.selectionMode == GameGUI::TOOL_SELECTION &&
					gui.toolManager.getBuildingName() == innChoice,
				"A tool must be selectable from its real sidebar hit area without mouse hover");
		noOrder();
		gui.clearSelection();
		finger(SDL_EVENT_FINGER_DOWN, 1, 160, 160);
		finger(SDL_EVENT_FINGER_MOTION, 1, 166, 160);
		finger(SDL_EVENT_FINGER_UP, 1, 166, 160);
		require(gui.viewportX == 0, "Sub-threshold movement must not pan");
		finger(SDL_EVENT_FINGER_DOWN, 1, 160, 160);
		finger(SDL_EVENT_FINGER_MOTION, 1, 224, 160);
		finger(SDL_EVENT_FINGER_UP, 1, 224, 160);
		require(gui.viewportX == gui.game.map.getW() - 2,
				"Dragging must pan across the toroidal seam");
		flag();
		tap(200, 200);
		noOrder();
		require(gui.touch->hasPreview(), "Placement tap must retain a preview");
		const int before = gui.viewportX;
		finger(SDL_EVENT_FINGER_DOWN, 1, 200, 200);
		finger(SDL_EVENT_FINGER_DOWN, 2, 300, 200);
		finger(SDL_EVENT_FINGER_MOTION, 1, 264, 200);
		finger(SDL_EVENT_FINGER_MOTION, 2, 364, 200);
		finger(SDL_EVENT_FINGER_UP, 2, 364, 200);
		finger(SDL_EVENT_FINGER_UP, 1, 264, 200);
		require(gui.viewportX == ((before - 2) & gui.game.map.getMaskW()),
				"Two fingers must pan while placing");
		noOrder();
		require(gui.hudInspectionHost().find("touch/placement/confirm") != nullptr,
				"Desktop touch confirmation exposes its shared semantic control");
		tap(100, 576);
		auto order = std::dynamic_pointer_cast<OrderCreate>(gui.toolManager.getOrder());
		require(bool(order), "Confirmation must emit the shared create order");
		require(gui.selectionMode == GameGUI::NO_SELECTION,
				"Confirmed placement must exit preview mode");
		noOrder();
		gui.clearSelection();
		const double oldZoom = gui.camera.zoom;
		finger(SDL_EVENT_FINGER_DOWN, 1, 200, 200);
		finger(SDL_EVENT_FINGER_DOWN, 2, 300, 200);
		finger(SDL_EVENT_FINGER_MOTION, 2, 350, 200);
		finger(SDL_EVENT_FINGER_UP, 2, 350, 200);
		finger(SDL_EVENT_FINGER_UP, 1, 200, 200);
		require(std::abs(gui.camera.zoom - oldZoom * 1.5) < 0.001,
				"Pinch uses the shared camera zoom");
		noOrder();
		// Within one double tap of the limit, so the tap has to clamp.
		gui.camera.setZoom(MapCamera::MAX_ZOOM * 0.6, 200, 200);
		// The camera was moved directly; keep the GUI's tile origin in step with it.
		gui.viewportX = gui.camera.tileX();
		gui.viewportY = gui.camera.tileY();
		const auto tapAnchor = gui.camera.screenToWorld(200, 200);
		touchTickStep = 50;
		tap(200, 200);
		tap(200, 200);
		touchTickStep = separateTouchStep;
		require(std::abs(gui.camera.zoom - MapCamera::MAX_ZOOM) < 0.001,
				"Double tap zooms in up to the camera limit");
		const auto restoredAnchor = gui.camera.screenToWorld(200, 200);
		require(std::abs(MapCamera::wrap(tapAnchor.first, gui.camera.mapWidth) -
					MapCamera::wrap(restoredAnchor.first, gui.camera.mapWidth)) < 0.001 &&
					std::abs(MapCamera::wrap(tapAnchor.second, gui.camera.mapHeight) -
					MapCamera::wrap(restoredAnchor.second, gui.camera.mapHeight)) < 0.001,
				"Double tap keeps the tapped world position anchored");
		gui.zoomMap(std::log(1.0 / gui.camera.zoom) / std::log(1.1), 200, 200);
		gui.clearSelection();
		bool foundEmptyGround = false;
		for (int y = 80; y < 480 && !foundEmptyGround; y += 32)
			for (int x = 80; x < 560 && !foundEmptyGround; x += 32)
			{
				const auto world = gui.camera.screenToWorld(x, y);
				const int tileX = int(MapCamera::wrap(world.first, gui.camera.mapWidth)) / 32;
				const int tileY = int(MapCamera::wrap(world.second, gui.camera.mapHeight)) / 32;
				if (gui.game.map.getBuilding(tileX, tileY) != NOGBID ||
					gui.game.map.getGroundUnit(tileX, tileY) != NOGUID ||
					gui.game.map.getAirUnit(tileX, tileY) != NOGUID)
					continue;
				bool flagHere = false;
				for (auto *flagBuilding : gui.localTeam->virtualBuildings)
					flagHere |= gui.displayedPosX(*flagBuilding) == tileX &&
						gui.displayedPosY(*flagBuilding) == tileY;
				if (flagHere) continue;
				foundEmptyGround = true;
				gui.camera.setZoom(1.7, x, y);
				gui.viewportX = gui.camera.tileX();
				gui.viewportY = gui.camera.tileY();
				gui.mouseX = x; gui.mouseY = y;
				gui.updateCamera();
				const auto wheelAnchor = gui.camera.screenToWorld(x, y);
				SDL_Event wheel{};
				wheel.type = SDL_EVENT_MOUSE_WHEEL;
				wheel.wheel.y = -1;
                wheel.wheel.mouse_x=x; wheel.wheel.mouse_y=y;
#if SDL_VERSION_ATLEAST(2,0,18)
				wheel.wheel.y = -1;
#endif
				gui.processEvent(&wheel);
				require(gui.camera.zoom < 1.7, "Wheel on empty map zooms without Alt");
				GAGCore::GestureScrollEvent nativeMap;
				nativeMap.sequence = 301; nativeMap.phase = GAGCore::ScrollGesturePhase::Began;
				nativeMap.x = x; nativeMap.y = y; nativeMap.logical = true; nativeMap.wheelY = -1;
				const double nativeZoom = gui.camera.zoom;
				auto nativeEvent = GAGCore::gestureScrollEvent(nativeMap);
				gui.processEvent(&nativeEvent);
				require(gui.camera.zoom < nativeZoom, "An unclaimed native map gesture retains wheel zoom");
				const auto afterWheel = gui.camera.screenToWorld(x, y);
				require(std::abs(MapCamera::wrap(wheelAnchor.first, gui.camera.mapWidth) -
						MapCamera::wrap(afterWheel.first, gui.camera.mapWidth)) < 0.001 &&
					std::abs(MapCamera::wrap(wheelAnchor.second, gui.camera.mapHeight) -
						MapCamera::wrap(afterWheel.second, gui.camera.mapHeight)) < 0.001,
					"Wheel zoom keeps the cursor's world position anchored");
			}
		require(foundEmptyGround, "Fixture needs empty ground for wheel zoom");
		flag();
		tap(240, 240);
		const auto position = gui.camera.screenToWorld(240, 240);
		require(gui.touch->preview && std::abs(gui.touch->preview->x - position.first) < 1.01 &&
					std::abs(gui.touch->preview->y - position.second) < 1.01,
				"Placement preview tracks world coordinates after fractional pan and zoom");
		tap(480, 576);
		noOrder();
		flag();
		tap(200, 200);
		tap(480, 576);
		noOrder();
		require(gui.selectionMode == GameGUI::NO_SELECTION, "Cancel must exit placement");
		flag();
		tap(220, 220);
		// The first point is in Confirm, the second just outside the strip.
		finger(SDL_EVENT_FINGER_DOWN, 1, 100, 554);
		finger(SDL_EVENT_FINGER_UP, 1, 100, 550);
		noOrder();
		require(gui.touch->hasPreview(), "Crossing a control boundary must not place or cancel");
		finger(SDL_EVENT_FINGER_DOWN, 1, 100, 576);
		gui.suspendInput();
		finger(SDL_EVENT_FINGER_UP, 1, 100, 576);
		noOrder();
		require(gui.touch->hasPreview(),
				"Suspension retains preview but cancels held confirmation");
		tap(220, 220);
		gui.localTeam->noMoreBuildingSitesCountdown = 1;
        gui.game.snapshots().invalidateBoundary();
        gui.prepareLocalPresentation();
		tap(100, 576);
		noOrder();
		require(gui.touch->hasPreview(), "Failed validation must retain the preview");
		gui.localTeam->noMoreBuildingSitesCountdown = 0;
        gui.game.snapshots().invalidateBoundary();
        gui.prepareLocalPresentation();
		gui.suspendInput();
		flag();
		finger(SDL_EVENT_FINGER_DOWN, 1, 200, 200);
		gui.clearSelection();
		finger(SDL_EVENT_FINGER_UP, 1, 200, 200);
		noOrder();
		require(!gui.touch->hasPreview(), "Mode changes must cancel an owned gesture");
		flag();
		tap(200, 200);
		SDL_Event synthetic{};
		synthetic.type = SDL_EVENT_MOUSE_BUTTON_UP;
		synthetic.button.which = SDL_TOUCH_MOUSEID;
		synthetic.button.button = SDL_BUTTON_LEFT;
		synthetic.button.x = 200;
		synthetic.button.y = 200;
		gui.step({synthetic}, SDL_GetTicks());
		require(gui.getOrder()->getOrderType() == ORDER_NULL,
				"Synthesized mouse release must not place");
		noOrder();
		gui.suspendInput();
		gui.setSelection(GameGUI::BRUSH_SELECTION);
		gui.toolManager.activateZoneTool(GameGUIToolManager::Forbidden);
		gui.brush.defaultSelection();
		finger(SDL_EVENT_FINGER_DOWN, 1, 200, 200);
		finger(SDL_EVENT_FINGER_MOTION, 1, 232, 200);
		finger(SDL_EVENT_FINGER_DOWN, 2, 300, 200);
		noOrder(); // A second finger cancels the unfinished stroke.
		finger(SDL_EVENT_FINGER_MOTION, 1, 296, 200);
		finger(SDL_EVENT_FINGER_UP, 2, 300, 200);
		finger(SDL_EVENT_FINGER_UP, 1, 296, 200);
		noOrder();
		finger(SDL_EVENT_FINGER_DOWN, 1, 240, 240);
		gui.suspendInput();
		noOrder(); // Focus suspension must not commit an unfinished stroke.
		finger(SDL_EVENT_FINGER_UP, 1, 240, 240);
		noOrder();
		flag();
		tap(220, 220);
		globalContainer->replaying = true;
		tap(100, 576);
		noOrder();
		globalContainer->replaying = false;
		gui.suspendInput();
		flag();
		tap(200, 200);
		finger(SDL_EVENT_FINGER_DOWN, 1, 100, 576);
		gui.viewportResized(800, 600, 600, 800);
		finger(SDL_EVENT_FINGER_UP, 1, 100, 576);
		noOrder();
		require(gui.touch->hasPreview(), "Rotation retains preview but cancels held confirmation");
		finger(SDL_EVENT_FINGER_DOWN, 1, 200, 200);
		SDL_Event focus{};
		focus.type = SDL_EVENT_WINDOW_RESIZED;
		focus.type = SDL_EVENT_WINDOW_FOCUS_LOST;
		gui.processEvent(&focus);
		finger(SDL_EVENT_FINGER_UP, 1, 200, 200);
		noOrder();
		require(!gui.touch->hasPreview(), "Focus loss must clear owned pointers");
		focus.type = SDL_EVENT_WINDOW_FOCUS_GAINED;
		gui.processEvent(&focus);
		tap(200, 200);
		glob2test::drawGUI(gui,0);
		globalContainer->gfx->printScreen("touch-placement.bmp");
		globalContainer->gfx->nextFrame();
		auto *capture = SDL_LoadBMP(
			(std::string(SDL_getenv_unsafe("GLOB2_USER_DATA_DIR")) + "/touch-placement.bmp").c_str());
		require(capture && SDL_BYTESPERPIXEL(capture->format) == 4,
				"Placement screenshot must be captured");
		Uint8 r, g, b;
		const auto pixel = static_cast<Uint32 *>(static_cast<void *>(
			static_cast<char *>(capture->pixels) + (capture->h - 10) * capture->pitch))[10];
		SDL_GetRGB(pixel, SDL_GetPixelFormatDetails(capture->format), SDL_GetSurfacePalette(capture), &r, &g, &b);
		SDL_DestroySurface(capture);
		require(g > r + 20, "Confirm must be visibly drawn over the world");
		require(gui.game.checkSum() == checksum,
				"Touch navigation and queued orders must not mutate simulation state");
		gui.game.map.setMapDiscovered(); // Expose terrain for this rendering fixture only.
		const auto hudChecksum = gui.game.checkSum();
		gui.clearSelection();
		gui.suspendInput();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		auto *gfx = globalContainer->gfx;
		gfx->setResponsiveViewport(true, 800, 600);
		for (auto [width, height] : {std::pair{320, 568}, {568, 320}})
		{
			const int oldW = gfx->getW(), oldH = gfx->getH();
			SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
			GLOB2_REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())), "Window resize must settle before layout assertions");
			SDL_Event resize{};
			resize.type = SDL_EVENT_WINDOW_RESIZED;
			resize.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
			GAGCore::GraphicContext::translateMouseEvent(&resize);
			gui.viewportResized(oldW, oldH, gfx->getW(), gfx->getH());
			tap(100, 200); // Activate touch after the resize cancellation.
			const float unit = gfx->logicalUnitsPerPoint();
			gui.clearSelection();
			const bool portrait = width < height;
			const double gap = InGameTouchTheme::gap * unit;
			auto about = [](double a, double b) { return std::abs(a - b) < 0.5; };
			for (int side : {int(Settings::THUMB_RIGHT), int(Settings::THUMB_LEFT)})
			{
				// Toolboxes rise from the corner opposite the thumb, in both orientations.
				globalContainer->settings.thumbSide = side;
				const bool left = side == Settings::THUMB_RIGHT;
				gui.displayMode = GameGUI::FLAG_VIEW;
				gui.touch->panelOpen = true;
				gui.touch->panelScroll = 0;
				gui.touch->clampScroll();
				auto ui = gui.touch->layout();
				auto content = gui.touch->panelContent();
				const auto firstFlag = gui.touch->paletteItemRect(0);
				for (size_t i = 0; i < gui.touch->paletteItems().size(); ++i)
				{
					const auto box = gui.touch->paletteItemRect(i);
					require(box.x >= content.x && box.y >= content.y && box.x + box.w <= content.x + content.w &&
								box.y + box.h <= content.y + content.h,
							"All flags and zones must fit in the visible rail");
					require(portrait ? box.x == firstFlag.x : box.y == firstFlag.y,
							"Flags and zones form one column in portrait and one row in landscape");
				}
				require(about(ui.panel.y + ui.panel.h, ui.actions.y), "The rail rises from the toolbar");
				require(about(left ? ui.panel.x - ui.safe.x : ui.safe.x + ui.safe.w - ui.panel.x - ui.panel.w,
							 InGameTouchTheme::railInset * unit),
						"The rail hugs the opposite edge, clear of the back-gesture strip");
				require(about(firstFlag.y + firstFlag.h + gap, content.y + content.h) &&
							about(left ? firstFlag.x - gap : firstFlag.x + firstFlag.w + gap,
								 left ? content.x : content.x + content.w),
						"The first choice sits nearest the toolbox corner");
				const auto mini = gui.touch->minimapRect();
				require(ui.panel.y >= mini.y + mini.h - 0.5, "The rail leaves the minimap visible");
				require((gui.touch->confirmRect().x > gui.touch->cancelRect().x) == left,
						"Placement OK follows the thumb side");
				gui.displayMode = GameGUI::CONSTRUCTION_VIEW;
				gui.touch->panelScroll = 0;
				gui.touch->clampScroll();
				ui = gui.touch->layout();
				const int columns = gui.touch->paletteColumns(ui);
				require(columns == (portrait ? 2 : 4), "Buildings use a two-column rail in portrait");
				const auto b0 = gui.touch->paletteItemRect(0), b1 = gui.touch->paletteItemRect(1),
						   above = gui.touch->paletteItemRect(columns);
				require(b1.y == b0.y && (left ? b1.x > b0.x : b1.x < b0.x),
						"The second choice sits beside the first, toward the screen centre");
				require(above.x == b0.x && above.y < b0.y, "Later rows rise above the first");
				gui.touch->prepareDraw();
				const int updates = gui.touch->gestureExclusionUpdates;
				gui.touch->prepareDraw();
				require(gui.touch->gestureExclusionUpdates == updates &&
							gui.touch->gestureExclusion.size() == 1 &&
							about(gui.touch->gestureExclusion[0].x, ui.panel.x) &&
							about(gui.touch->gestureExclusion[0].h, ui.panel.h),
						"The rail is excluded from system edge gestures, synchronised only on change");
				const std::string suffix = std::string(side == Settings::THUMB_RIGHT ? "right-thumb-" : "left-thumb-") +
					(portrait ? "portrait.bmp" : "landscape.bmp");
				auto capture = [&](const char *kind) {
					glob2test::drawGUI(gui,0);
					gfx->printScreen((std::string("opposite-") + kind + "-" + suffix).c_str());
					gfx->nextFrame();
				};
				capture("build");
				gui.displayMode = GameGUI::FLAG_VIEW;
				capture("flags");
				gui.setSelection(GameGUI::BRUSH_SELECTION);
				const auto rail = gui.touch->brushHUD().rail;
				require(about(left ? rail.x - ui.safe.x : ui.safe.x + ui.safe.w - rail.x - rail.w,
					InGameTouchTheme::railInset * unit), "The zone toolbox sits opposite either thumb");
				capture("zones");
				gui.clearSelection();
				gui.displayMode = GameGUI::STAT_TEXT_VIEW;
				gui.touch->lensOpen = true;
				const auto lens = gui.touch->lensRects(gui.touch->layout()).front();
				require(about(left ? lens.x - ui.safe.x : ui.safe.x + ui.safe.w - lens.x - lens.w,
					InGameTouchTheme::railInset * unit), "The tools toolbox sits opposite either thumb");
				capture("tools");
				gui.touch->lensOpen = false;
				gui.displayMode = GameGUI::CONSTRUCTION_VIEW;
				gui.touch->panelOpen = true;
			}
			globalContainer->settings.thumbSide = Settings::THUMB_RIGHT;
			{
				// A rail taller than its space scrolls toward the thumb: dragging it
				// down reveals the higher rows. Pad the list so it overflows.
				const auto names = gui.buildingsChoiceName;
				const auto states = gui.buildingsChoiceState;
				while (gui.buildingsChoiceName.size() < 24)
				{
					gui.buildingsChoiceName.push_back("inn");
					gui.buildingsChoiceState.push_back(true);
				}
				gui.displayMode = GameGUI::CONSTRUCTION_VIEW;
				gui.touch->panelScroll = 0;
				gui.touch->clampScroll();
				auto content = gui.touch->panelContent();
				const size_t count = gui.touch->paletteItems().size();
				const auto top = gui.touch->paletteItemRect(count - 1);
				require(top.y < content.y, "Padded rail fixture must overflow");
                // Queued/remote wheels carry their own pointer. Put the OS cursor
                // elsewhere to catch consumers that substitute polled mouse state.
                SDL_WarpMouseInWindow(SDL_GetWindowFromID(gfx->windowID()), 5, 5);
                SDL_Event wheel{}; wheel.type=SDL_EVENT_MOUSE_WHEEL;
                wheel.wheel.mouse_x=content.x+content.w/2;
                wheel.wheel.mouse_y=content.y+content.h/2;
                wheel.wheel.y=-gui.touch->paletteScrollSign();
                gui.processEvent(&wheel);
                require(gui.touch->panelScroll>0, "Wheel must scroll the supplied HUD position, independently of the OS pointer");
                gui.touch->panelScroll=0; gui.touch->clampScroll();
				{
					const double before = gui.touch->panelScroll;
					finger(SDL_EVENT_FINGER_DOWN, 1, content.x + content.w / 2, content.y + 8 * unit);
					finger(SDL_EVENT_FINGER_MOTION, 1, content.x + content.w / 2, content.y + 60 * unit);
					finger(SDL_EVENT_FINGER_UP, 1, content.x + content.w / 2, content.y + 60 * unit);
					require(gui.touch->panelScroll > before &&
								gui.touch->paletteItemRect(count - 1).y > top.y,
							"Dragging an overflowing rail down reveals its higher rows");
					gui.touch->panelScroll = 1e6;
					gui.touch->clampScroll();
					require(gui.touch->paletteItemRect(count - 1).y >= content.y - 0.5,
							"A fully scrolled rail shows its top row");
				}
				gui.buildingsChoiceName = names;
				gui.buildingsChoiceState = states;
				gui.touch->panelScroll = 0;
				noOrder();
			}
			gui.touch->panelOpen = false;
			gui.touch->prepareDraw();
			require(gui.touch->gestureExclusion.empty(), "A closed rail releases its gesture exclusion");
			gui.displayMode = GameGUI::FLAG_VIEW;
			gui.touch->panelOpen = true;
			gui.touch->panelScroll = 0;
			glob2test::drawGUI(gui,0);
			gfx->printScreen(width < height ? "touch-flags-portrait.bmp"
											: "touch-flags-landscape.bmp");
			gfx->nextFrame();
			gui.touch->panelOpen = false;
			tap(gfx->getW() / 12.0f, gfx->getH() - 24 * unit);
			require(gui.touch->usesHUD(), "Phone HUD must be active");
			require(gui.displayMode == GameGUI::CONSTRUCTION_VIEW,
					"Visible Build control routes to construction");
			glob2test::drawGUI(gui,0);
			gfx->printScreen(width < height ? "touch-hud-portrait.bmp" : "touch-hud-landscape.bmp");
			gfx->nextFrame();
			int targetX, targetY, centerX, centerY;
			gui.minimap.convertToMap(gfx->getW() - 80, 64, targetX, targetY);
			gui.minimapMouseToPos(gfx->getW() - 80, 64, &centerX, &centerY, true);
			const auto world = gui.touch->worldBounds();
			require(centerX == gui.camera.tileX() && centerY == gui.camera.tileY(),
					"Minimap navigation uses the shared normalized camera");
			{
				// Dragging on the HUD minimap steers the camera live, clamped at its edge.
				const double originX = gui.camera.originX, originY = gui.camera.originY;
				const auto mini = gui.touch->minimapRect();
				const GAGCore::ViewPoint from{mini.x + mini.w * 0.25, mini.y + mini.h * 0.25},
					to{mini.x + mini.w * 0.75, mini.y + mini.h * 0.7},
					outside{mini.x - 60 * unit, mini.y + mini.h * 0.5};
				finger(SDL_EVENT_FINGER_DOWN, 1, from.x, from.y);
				finger(SDL_EVENT_FINGER_MOTION, 1, to.x, to.y);
				const int dragX = gui.viewportX, dragY = gui.viewportY;
				gui.touch->navigateMinimap(to);
				require(gui.viewportX == dragX && gui.viewportY == dragY,
						"Minimap drag must follow the finger");
				gui.touch->navigateMinimap(from);
				require(gui.viewportX != dragX || gui.viewportY != dragY,
						"Minimap drag fixture must move the camera");
				finger(SDL_EVENT_FINGER_MOTION, 1, outside.x, outside.y);
				const int edgeX = gui.viewportX, edgeY = gui.viewportY;
				gui.touch->navigateMinimap(mini.clamp(outside));
				require(gui.viewportX == edgeX && gui.viewportY == edgeY,
						"Leaving the minimap must clamp the drag to its edge");
				finger(SDL_EVENT_FINGER_UP, 1, outside.x, outside.y);
				noOrder();
				const int oldX = gui.viewportX, oldY = gui.viewportY;
				gui.camera.originX = originX;
				gui.camera.originY = originY;
				gui.camera.normalize();
				gui.viewportX = gui.camera.tileX();
				gui.viewportY = gui.camera.tileY();
				gui.viewportChanged(oldX, gui.viewportX, oldY, gui.viewportY);
			}
			// A visible map spot with nothing selectable around it.
			auto emptyGround = [&](std::source_location at = std::source_location::current())
			{
                auto emptyTile = [&](int cx, int cy) {
                    for (int dy = -1; dy <= 1; ++dy)
                        for (int dx = -1; dx <= 1; ++dx) {
                            const int mx=cx+dx, my=cy+dy;
                            if (gui.game.map.getBuilding(mx,my)!=NOGBID || gui.game.map.isResource(mx,my) ||
                                gui.game.map.getGroundUnit(mx,my)!=NOGUID || gui.game.map.getAirUnit(mx,my)!=NOGUID)
                                return false;
                        }
                    return true;
                };
                std::optional<GAGCore::ViewPoint> mapSpot;
				for (double y = world.y + 48 * unit; y < world.y + world.h - 24 * unit; y += 16 * unit)
					for (double x = world.x + 24 * unit; x < world.x + world.w - 24 * unit; x += 16 * unit)
					{
						if (gui.touch->interfaceRegion({x, y}) != 0) continue;
                        if (!mapSpot) mapSpot=GAGCore::ViewPoint{x,y};
						const int cx = gui.mapMouseX(int(x)) / 32 + gui.viewportX,
								  cy = gui.mapMouseY(int(y)) / 32 + gui.viewportY;
                        if (emptyTile(cx,cy)) return GAGCore::ViewPoint{x,y};
					}
                // Earlier navigation and desktop framing can leave only occupied
                // terrain outside an open phone sheet. Reframe this input fixture
                // onto existing clear terrain, without changing the map or orders.
                if (mapSpot) for (int cy=0;cy<gui.game.map.getH();++cy)
                    for (int cx=0;cx<gui.game.map.getW();++cx) if (emptyTile(cx,cy)) {
                        gui.camera.originX=cx*32+16-(mapSpot->x-gui.camera.offsetX)/gui.camera.zoom;
                        gui.camera.originY=cy*32+16-(mapSpot->y-gui.camera.offsetY)/gui.camera.zoom;
                        gui.camera.normalize();
                        gui.viewportX=gui.camera.tileX();gui.viewportY=gui.camera.tileY();
                        gui.prepareLocalPresentation();
                        return *mapSpot;
                    }
                throw std::runtime_error("No empty ground visible in the phone world at line " + std::to_string(at.line()));
			};
			{
				const auto checksum = gui.game.checkSum();
				const auto dismissalCamera = gui.camera;
				for (int menu = 0; menu < 5; ++menu)
				{
					gui.clearSelection();
					gui.touch->panelOpen = menu < 2 || menu == 4;
					gui.touch->lensOpen = menu == 2 || menu == 3;
					gui.touch->statsOpen = menu == 3;
					gui.touch->showStatistics = menu == 4;
					gui.displayMode = menu == 0 ? GameGUI::CONSTRUCTION_VIEW : menu == 1 ? GameGUI::FLAG_VIEW : GameGUI::STAT_TEXT_VIEW;
					gui.touch->restorePalette = false;
					if (menu == 2)
					{
						const auto from = emptyGround();
						finger(SDL_EVENT_FINGER_DOWN, 1, from.x, from.y);
						finger(SDL_EVENT_FINGER_MOTION, 1, from.x + 32 * unit, from.y);
						finger(SDL_EVENT_FINGER_UP, 1, from.x + 32 * unit, from.y);
						require(gui.touch->lensOpen, "Panning the map must not dismiss Tools");
						gui.touch->stopScrolling();
					}
					const auto spot = emptyGround();
					glob2test::drawGUI(gui,0);
					const std::string name = std::string("dismiss-") + std::to_string(menu) + (portrait ? "-portrait" : "-landscape");
					gfx->printScreen(name + "-before.bmp");
					gfx->nextFrame();
					tap(spot.x, spot.y);
					glob2test::drawGUI(gui,0); // Include deferred inspector restoration.
					require(!gui.touch->panelOpen && !gui.touch->lensOpen && !gui.touch->statsOpen &&
						!gui.touch->peekOpen && !gui.touch->showStatistics && !gui.touch->restorePalette &&
						gui.selectionMode == GameGUI::NO_SELECTION, "A blank-map tap dismisses every transient panel");
					gfx->printScreen(name + "-after.bmp");
					gfx->nextFrame();
					noOrder();
				}
				require(gui.game.checkSum() == checksum, "Panel dismissal does not change the simulation");
				gui.camera = dismissalCamera;
				gui.viewportX = gui.camera.tileX();
				gui.viewportY = gui.camera.tileY();
				gui.displayMode = GameGUI::CONSTRUCTION_VIEW;
			}
			{
				// Resource taps inspect the tile instead of falling through to Tools.
				gui.clearSelection();
				gui.touch->panelOpen = false;
				gui.touch->lensOpen = false;
				const auto spot = emptyGround();
				const int tx = (gui.mapMouseX(int(spot.x)) / 32 + gui.viewportX) & gui.game.map.getMaskW();
				const int ty = (gui.mapMouseY(int(spot.y)) / 32 + gui.viewportY) & gui.game.map.getMaskH();
				auto resource = gui.game.map.getResource(tx, ty);
				const auto saved = resource;
				for (int type : {WOOD, WHEAT, 8, 9, 10, 11, mixedResource})
				{
					resource.type = type;
					resource.variety = 0;
					resource.amount = 3;
					gui.game.map.replaceResource(tx, ty, resource);
                    if (type == mixedResource)
                    {
                        const auto index = gui.game.map.coordToIndex(tx, ty);
                        gui.game.map.setMaterialAmount(index, MaterialId::Food, 2);
                        gui.game.map.setMaterialAmount(index, MaterialId::Paper, 4);
                    }
                    gui.prepareLocalPresentation();
					tap(spot.x, spot.y);
					require(gui.touch->inspectingResource(), "Tapping a resource opens its inspector");
					glob2test::drawGUI(gui,0);
					const auto info = gui.touch->resourceInfo();
                    const auto id = static_cast<ResourceId>(type);
                    const auto& catalog = gui.game.map.resourceRegistry();
                    std::string expectedAmount;
                    for (unsigned material = 0; material < MaterialCount; ++material)
                    {
                        const auto& yield = catalog.yields(id)[material];
                        if (!yield.capacity) continue;
                        if (!expectedAmount.empty()) expectedAmount += "\n";
                        expectedAmount += getMaterialName(material) + ": " +
                            (yield.consumption == ResourceConsumption::Infinite ? std::string("∞") :
                             std::to_string(gui.game.map.materialAmountAtSlot(gui.game.map.coordToIndex(tx,ty),material)) + "/" + std::to_string(yield.capacity));
                    }
                    require(info && info->name == getResourceDisplayName(catalog.presentation(id).name) && info->amount == expectedAmount,
                        "Resource inspection shows registry name and all material stocks");
					const auto panel = gui.touch->layout().panel;
					const auto hud = gui.touch->hudLayout(gui.touch->layout());
					auto nearlyEqual = [](double a, double b) { return std::abs(a - b) < .5; };
					require(nearlyEqual(panel.x, hud.stats.x) && nearlyEqual(panel.w, hud.stats.w) &&
						nearlyEqual(panel.y, hud.stats.y + hud.stats.h + 4 * unit) &&
						panel.y >= hud.stats.y + hud.stats.h &&
						nearlyEqual(panel.h, InGameTouchTheme::inspectorHeader * unit) && !gui.touch->lensVisible(),
						"Resource identity shares the building header geometry below stats");
					require(gui.touch->interfaceRegion({panel.x + 4 * unit, panel.y + panel.h / 2}) == 3,
						"Resource header consumes taps before the map");
					gfx->printScreen(std::string("resource-") + std::to_string(type) + "-" + (portrait ? "portrait.bmp" : "landscape.bmp"));
					gfx->nextFrame();
					tap(panel.x + panel.w / 2, panel.y + panel.h * .7);
					require(!gui.touch->statsOpen && !gui.touch->showStatistics && gui.touch->inspectingResource(),
						"Tapping resource information cannot activate the tactical menu");
					noOrder();
					const auto close = gui.touch->readOnlyCloseRect();
					tap(close.x + close.w / 2, close.y + close.h / 2);
					gui.touch->prepareDraw();
					require(gui.selectionMode == GameGUI::NO_SELECTION && !gui.touch->panelOpen,
						"Closing resource info dismisses the panel");
				}
				tap(spot.x, spot.y);
				const auto bar = gui.touch->layout().actions;
				tap(bar.x + bar.w * 2.5 / 6, bar.y + bar.h / 2);
				glob2test::drawGUI(gui,0);
				require(gui.touch->lensVisible() && !gui.touch->inspectingResource(), "Tools consistently opens the lens strip after resource inspection");
				tap(bar.x + bar.w * 2.5 / 6, bar.y + bar.h / 2);
				tap(spot.x, spot.y);
				gui.game.map.replaceResource(tx, ty, saved);
				glob2test::drawGUI(gui,0);
				require(!gui.touch->inspectingResource(), "A depleted resource stops being inspected");
				gui.clearSelection();
				gui.touch->panelOpen = false;
				gui.touch->lensOpen = false;
			}
			{
				// One-finger zoom: tap, press again and drag; direction follows settings.
				gui.clearSelection();
				gui.touch->panelOpen = false;
				const auto spot = emptyGround();
				const double travel = GAGCore::TouchInput::zoomDoublingPoints / 2 * unit;
				auto wrapped = [&](std::pair<double, double> a, std::pair<double, double> b)
				{
					return std::abs(MapCamera::wrap(a.first, gui.camera.mapWidth) -
									MapCamera::wrap(b.first, gui.camera.mapWidth)) < 1 &&
						   std::abs(MapCamera::wrap(a.second, gui.camera.mapHeight) -
									MapCamera::wrap(b.second, gui.camera.mapHeight)) < 1;
				};
				// A completed double tap zooms in around its map point, even at a seam.
				const auto savedCamera = gui.camera;
				for (double initial : {0.75, 1.0, 2.0, MapCamera::MAX_ZOOM})
				{
					gui.camera = savedCamera;
					gui.camera.setZoom(initial, spot.x, spot.y);
					gui.viewportX = gui.camera.tileX();
					gui.viewportY = gui.camera.tileY();
					if (initial != 1.0)
					{
						gui.camera.originX = gui.camera.mapWidth - 8;
						gui.camera.originY = gui.camera.mapHeight - 8;
					}
					gui.viewportX = gui.camera.tileX();
					gui.viewportY = gui.camera.tileY();
					gui.updateCamera();
					const auto zoomSpot = spot;
					const double before = gui.camera.zoom;
					const auto anchor = gui.camera.screenToWorld(zoomSpot.x, zoomSpot.y);
					if (initial == 1.0)
					{
						glob2test::drawGUI(gui,0);
						gfx->printScreen(width < height ? "touch-double-tap-before-portrait.bmp"
														: "touch-double-tap-before-landscape.bmp");
						gfx->nextFrame();
					}
					quickTouches();
					tap(zoomSpot.x, zoomSpot.y);
					tap(zoomSpot.x, zoomSpot.y);
					touchTickStep = separateTouchStep;
					require(std::abs(gui.camera.zoom - std::min(before * 2, MapCamera::MAX_ZOOM)) < 1e-9,
							"Double tap doubles zoom and stays at the maximum instead of resetting");
					require(wrapped(anchor, gui.camera.screenToWorld(zoomSpot.x, zoomSpot.y)),
							"Double tap keeps the tapped world point anchored across map seams");
					noOrder();
					std::cout << "PASS double tap " << width << "x" << height << ": " << before
							  << " -> " << gui.camera.zoom << "; world anchor preserved\n";
					if (initial == 1.0)
					{
						glob2test::drawGUI(gui,0);
						gfx->printScreen(width < height ? "touch-double-tap-after-portrait.bmp"
														: "touch-double-tap-after-landscape.bmp");
						gfx->nextFrame();
					}
					gui.clearSelection();
					gui.touch->panelOpen = false;
				}
				gui.camera = savedCamera;
				gui.viewportX = gui.camera.tileX();
				gui.viewportY = gui.camera.tileY();
				gui.updateCamera();
				auto armedPress = [&]
				{
					gui.camera.setZoom(1, spot.x, spot.y);
                    gui.viewportX = gui.camera.tileX();
                    gui.viewportY = gui.camera.tileY();
					quickTouches();
					tap(spot.x, spot.y);
					finger(SDL_EVENT_FINGER_DOWN, 1, spot.x, spot.y);
				};
				for (int direction : {int(Settings::ONE_FINGER_ZOOM_UP_IN), int(Settings::ONE_FINGER_ZOOM_DOWN_IN)})
				{
					globalContainer->settings.oneFingerZoomDirection = direction;
					armedPress();
					const auto anchor = gui.camera.screenToWorld(spot.x, spot.y);
					const double end =
						spot.y + (direction == Settings::ONE_FINGER_ZOOM_UP_IN ? -travel : travel);
					finger(SDL_EVENT_FINGER_MOTION, 1, spot.x, end);
					require(gui.touch->gesture.zoomDragging(),
							"One-finger zoom must show its readout while dragging");
					if (direction == Settings::ONE_FINGER_ZOOM_UP_IN)
					{
						glob2test::drawGUI(gui,0);
						gfx->printScreen(width < height ? "touch-zoom-drag-portrait.bmp"
														: "touch-zoom-drag-landscape.bmp");
						gfx->nextFrame();
					}
					finger(SDL_EVENT_FINGER_UP, 1, spot.x, end);
					touchTickStep = separateTouchStep;
					require(std::abs(gui.camera.zoom - std::sqrt(2.0)) < 0.01,
							"One-finger zoom must follow the direction setting");
					require(wrapped(anchor, gui.camera.screenToWorld(spot.x, spot.y)),
							"One-finger zoom keeps the pressed world position anchored");
					noOrder();
				}
				globalContainer->settings.oneFingerZoomDirection = Settings::ONE_FINGER_ZOOM_UP_IN;
				armedPress();
				finger(SDL_EVENT_FINGER_MOTION, 1, spot.x, spot.y - travel / 2);
				double partial = gui.camera.zoom;
				require(partial > 1.01, "One-finger zoom fixture must zoom");
				finger(SDL_EVENT_FINGER_DOWN, 2, spot.x + 80 * unit, spot.y);
				finger(SDL_EVENT_FINGER_UP, 2, spot.x + 80 * unit, spot.y);
				finger(SDL_EVENT_FINGER_MOTION, 1, spot.x, spot.y - travel * 1.5);
				finger(SDL_EVENT_FINGER_UP, 1, spot.x, spot.y - travel * 1.5);
				touchTickStep = separateTouchStep;
				require(std::abs(gui.camera.zoom - partial) < 1e-9, "A second finger must end one-finger zoom");
				armedPress();
				finger(SDL_EVENT_FINGER_MOTION, 1, spot.x, spot.y - travel / 2);
				partial = gui.camera.zoom;
				SDL_Event lost{};
				lost.type = SDL_EVENT_WINDOW_RESIZED;
				lost.type = SDL_EVENT_WINDOW_FOCUS_LOST;
				gui.processEvent(&lost);
				finger(SDL_EVENT_FINGER_MOTION, 1, spot.x, spot.y - travel * 1.5);
				finger(SDL_EVENT_FINGER_UP, 1, spot.x, spot.y - travel * 1.5);
				lost.type = SDL_EVENT_WINDOW_FOCUS_GAINED;
				gui.processEvent(&lost);
				touchTickStep = separateTouchStep;
				require(std::abs(gui.camera.zoom - partial) < 1e-9 && !gui.touch->gesture.zoomDragging(),
						"Focus loss must end one-finger zoom");
				// A tap followed quickly by a sideways drag from the same spot still pans.
				armedPress();
				const int panX = gui.viewportX;
				finger(SDL_EVENT_FINGER_MOTION, 1, spot.x + 64 * unit, spot.y);
				finger(SDL_EVENT_FINGER_UP, 1, spot.x + 64 * unit, spot.y);
				touchTickStep = separateTouchStep;
				require(gui.viewportX != panX && std::abs(gui.camera.zoom - 1) < 1e-9,
						"A sideways drag after a tap must pan, not zoom");
				globalContainer->settings.oneFingerZoomDirection = Settings::ONE_FINGER_ZOOM_PLATFORM;
                // Keep later gesture scenarios independent of the pan above.
				gui.camera = savedCamera;
				gui.viewportX = gui.camera.tileX();
				gui.viewportY = gui.camera.tileY();
				noOrder();
			}
			{
				// A painted tap waits one double-tap window, since it may begin a zoom.
				auto brush = [&]
				{
					gui.setSelection(GameGUI::BRUSH_SELECTION);
					gui.toolManager.activateZoneTool(GameGUIToolManager::Forbidden);
					gui.brush.defaultSelection();
				};
				gui.prepareLocalPresentation();
			auto forbidden = [&]
				{ return bool(std::dynamic_pointer_cast<OrderAlterForbidden>(gui.toolManager.getOrder())); };
				auto drain = [&] { while (gui.toolManager.getOrder()) {} };
				brush();
				const auto spot = emptyGround();
				tap(spot.x, spot.y);
				require(bool(gui.touch->deferredStroke), "A paint tap must wait for the double-tap window");
				noOrder();
				SDL_Delay(InGameTouchTheme::doubleTapWindowMs + 20);
				gui.touch->prepareDraw();
				require(forbidden(), "A paint tap must land after the double-tap window");
				drain();
				gui.camera.setZoom(1.5, spot.x, spot.y);
				gui.viewportX = gui.camera.tileX();
				gui.viewportY = gui.camera.tileY();
				quickTouches();
				tap(spot.x, spot.y);
				tap(spot.x, spot.y);
				touchTickStep = separateTouchStep;
				require(!gui.touch->deferredStroke, "A double tap while painting must not paint");
				require(std::abs(gui.camera.zoom - 3) < 0.001,
						("A double tap while painting must zoom in (zoom " + std::to_string(gui.camera.zoom) + ")").c_str());
				SDL_Delay(InGameTouchTheme::doubleTapWindowMs + 20);
				gui.touch->prepareDraw();
				noOrder();
				gui.zoomMap(std::log(1.0 / gui.camera.zoom) / std::log(1.1), int(spot.x), int(spot.y));
				gui.brush.setFigure(6); // 3x3, so the footprint capture is legible.
				finger(SDL_EVENT_FINGER_DOWN, 1, spot.x, spot.y);
				finger(SDL_EVENT_FINGER_MOTION, 1, spot.x + 40 * unit, spot.y);
				require(gui.touch->stroke.points.size() == 2, "Stroke buffers its points until release");
				glob2test::drawGUI(gui,0);
				gfx->printScreen(width < height ? "touch-stroke-portrait.bmp" : "touch-stroke-landscape.bmp");
				gfx->nextFrame();
				noOrder(); // The preview never paints.
				finger(SDL_EVENT_FINGER_UP, 1, spot.x + 40 * unit, spot.y);
				require(forbidden(), "A painted drag must not wait");
				drain();
				tap(spot.x, spot.y);
				const auto bar = gui.touch->controls();
				tap(bar.x + bar.w * 7 / 8, bar.y + bar.h / 2);
				require(forbidden(), "A held paint tap must land before Done leaves the brush");
				require(gui.selectionMode == GameGUI::NO_SELECTION, "Done must leave the brush");
				drain();
				brush();
				tap(spot.x, spot.y);
				gui.brush.setFigure((gui.brush.getFigure() + 1) % BrushTool::BRUSH_COUNT);
				SDL_Delay(InGameTouchTheme::doubleTapWindowMs + 20);
				gui.touch->prepareDraw();
				noOrder();
				require(!gui.touch->deferredStroke, "A held tap must be dropped when its brush changes");
				gui.clearSelection();
			}
			{
				// The brush rail: sizes, Paint/Erase and Pan under the thumb, plus undo.
				auto brush = [&]
				{
					gui.setSelection(GameGUI::BRUSH_SELECTION);
					gui.toolManager.activateZoneTool(GameGUIToolManager::Forbidden);
					gui.brush.defaultSelection();
				};
				auto drain = [&] { while (gui.toolManager.getOrder()) {} };
				auto centre = [](const GAGCore::ViewRect &r) { return GAGCore::ViewPoint{r.x + r.w / 2, r.y + r.h / 2}; };
				brush();
				auto rail = gui.touch->brushHUD();
				require(rail.detents.size() == BrushTool::BRUSH_COUNT && rail.mode.w > 0 && rail.pan.w > 0,
						"The rail offers every brush size, Paint/Erase and Pan");
				require(rail.detents.front().y > rail.detents.back().y,
						"The smallest brush sits lowest, nearest the thumb");
				const auto ui = gui.touch->layout();
				require(rail.rail.x + rail.rail.w <= ui.safe.x + ui.safe.w && rail.rail.y + rail.rail.h <= ui.actions.y &&
							rail.rail.y >= gui.touch->minimapRect().y + gui.touch->minimapRect().h,
						"The rail sits opposite the thumb between the minimap and the toolbar");
				auto p = centre(rail.detents[7]);
				tap(p.x, p.y);
				require(gui.brush.getFigure() == 7, "Tapping a rail size selects it");
				p = centre(rail.detents[0]);
				finger(SDL_EVENT_FINGER_DOWN, 1, p.x, p.y);
				require(gui.brush.getFigure() == 0 && gui.touch->railTouched == 0,
						"Touching a rail size selects it at once");
				const auto to = centre(rail.detents[5]);
				finger(SDL_EVENT_FINGER_MOTION, 1, to.x, to.y);
				require(gui.brush.getFigure() == 5 && gui.touch->railTouched == 5,
						"Scrubbing along the rail changes the size");
				glob2test::drawGUI(gui,0);
				gfx->printScreen(width < height ? "touch-brush-rail-portrait.bmp" : "touch-brush-rail-landscape.bmp");
				gfx->nextFrame();
				finger(SDL_EVENT_FINGER_UP, 1, to.x, to.y);
				require(gui.touch->railTouched == -1, "Releasing the rail hides the magnified size");
				noOrder();
				p = centre(rail.mode);
				tap(p.x, p.y);
				require(gui.brush.getType() == BrushTool::MODE_DEL, "The rail foot switches to Erase");
				tap(p.x, p.y);
				require(gui.brush.getType() == BrushTool::MODE_ADD, "The rail foot switches back to Paint");
				// Pan mode: one finger moves the map without painting.
				p = centre(rail.pan);
				tap(p.x, p.y);
				require(gui.touch->brushPan, "The rail head switches to Pan");
				const auto spot = emptyGround();
				const int panX = gui.viewportX;
				finger(SDL_EVENT_FINGER_DOWN, 1, spot.x, spot.y);
				finger(SDL_EVENT_FINGER_MOTION, 1, spot.x + 64 * unit, spot.y);
				finger(SDL_EVENT_FINGER_UP, 1, spot.x + 64 * unit, spot.y);
				require(gui.viewportX != panX, "Pan mode moves the map with one finger");
				noOrder();
				tap(p.x, p.y);
				require(!gui.touch->brushPan, "Pan mode toggles off");
				// A stroke held at a map edge pans and keeps painting.
				gui.brush.setFigure(0);
				const auto area = gui.touch->worldBounds();
				const GAGCore::ViewPoint edge{area.x + area.w - 6 * unit, area.y + area.h / 2};
				require(gui.touch->interfaceRegion(edge) == 0, "Edge fixture must be on the map");
				finger(SDL_EVENT_FINGER_DOWN, 1, edge.x - 30 * unit, edge.y);
				finger(SDL_EVENT_FINGER_MOTION, 1, edge.x, edge.y);
				require(bool(gui.touch->strokeHold), "A painting contact is held for edge panning");
				const int beforeEdge = gui.viewportX;
				const size_t points = gui.touch->stroke.points.size();
				gui.touch->strokeHold->lastUpdate = SDL_GetTicks() - 100;
				gui.touch->prepareDraw();
				require(gui.viewportX != beforeEdge && gui.touch->stroke.points.size() > points,
						"Holding a stroke at the edge pans and extends the stroke");
				noOrder();
				finger(SDL_EVENT_FINGER_UP, 1, edge.x, edge.y);
				require(bool(std::dynamic_pointer_cast<OrderAlterForbidden>(gui.toolManager.getOrder())),
						"The panned stroke paints on release");
				drain();
				// Undo reverts exactly the cells the stroke changed.
				gui.zoomMap(std::log(1.0 / gui.camera.zoom) / std::log(1.1), int(spot.x), int(spot.y));
				gui.brush.setFigure(6); // 3x3
				const auto target = emptyGround();
				auto &map = gui.game.map;
				const int cx = ((gui.mapMouseX(int(target.x)) + gui.viewportX * 32) >> 5) & map.getMaskW(),
						  cy = ((gui.mapMouseY(int(target.y)) + gui.viewportY * 32) >> 5) & map.getMaskH();
				auto index = [&](int dx, int dy) { return size_t(map.coordToIndex((cx + dx) & map.getMaskW(), (cy + dy) & map.getMaskH())); };
				std::vector<bool> saved;
				for (int dy = -1; dy <= 1; ++dy)
					for (int dx = -1; dx <= 1; ++dx)
					{
						saved.push_back(map.isForbidden(cx + dx, cy + dy, gui.localTeam->me));
						if (dy == -1) map.addForbidden(cx + dx, cy + dy, gui.localTeamNo);
						else map.removeForbidden(cx + dx, cy + dy, gui.localTeamNo);
					}
                // Supersede the unexecuted previews left by earlier rail gestures.
                Utilities::BitArray seedMask;
                seedMask.resize(9);
                for (size_t i = 0; i < 9; ++i) seedMask.set(i, true);
                gui.toolManager.trackPaint(GameGUIToolManager::makeZoneOrder(
                    GameGUIToolManager::Forbidden, gui.localTeamNo, BrushTool::MODE_DEL,
                    cx - 1, cy - 1, 3, 3, seedMask));
                seedMask.resize(3);
                for (size_t i = 0; i < 3; ++i) seedMask.set(i, true);
                gui.toolManager.trackPaint(GameGUIToolManager::makeZoneOrder(
                    GameGUIToolManager::Forbidden, gui.localTeamNo, BrushTool::MODE_ADD,
                    cx - 1, cy - 1, 3, 1, seedMask));
				gui.prepareLocalPresentation();
				gui.orderQueue.clear();
				finger(SDL_EVENT_FINGER_DOWN, 1, target.x, target.y);
				finger(SDL_EVENT_FINGER_MOTION, 1, target.x + 12 * unit, target.y); // A drag commits at once.
				finger(SDL_EVENT_FINGER_UP, 1, target.x + 12 * unit, target.y);
				drain();
				require(bool(gui.touch->zoneUndo) && gui.touch->brushHUD().undo.w > 0,
						"A stroke that changed zones offers Undo");
				glob2test::drawGUI(gui,0);
				gfx->printScreen(width < height ? "touch-brush-undo-portrait.bmp" : "touch-brush-undo-landscape.bmp");
				gfx->nextFrame();
				p = centre(gui.touch->brushHUD().undo);
				tap(p.x, p.y);
				require(!gui.touch->zoneUndo && !gui.orderQueue.empty(), "Undo sends its orders once");
				std::set<size_t> reverted;
				for (const auto &order : gui.orderQueue.snapshot())
				{
					auto inverse = std::dynamic_pointer_cast<OrderAlterForbidden>(order);
					require(inverse && inverse->type == BrushTool::MODE_DEL && inverse->teamNumber == gui.localTeamNo,
							"Undo removes the forbidden zone it added");
					for (int y = 0; y < inverse->maxY - inverse->minY; ++y)
						for (int x = 0; x < inverse->maxX - inverse->minX; ++x)
							if (inverse->mask.get(size_t(y * (inverse->maxX - inverse->minX) + x)))
								reverted.insert(size_t(map.coordToIndex((inverse->centerX + inverse->minX + x) & map.getMaskW(),
																			(inverse->centerY + inverse->minY + y) & map.getMaskH())));
				}
				std::set<size_t> expected;
				for (int dy = 0; dy <= 1; ++dy)
					for (int dx = -1; dx <= 1; ++dx)
						expected.insert(index(dx, dy));
				// The drag also covered the next column; those cells count only if they changed.
				for (auto cell : reverted)
					require(!gui.toolManager.displayedViewForZone(GameGUIToolManager::Forbidden).get(cell), "Undo restores the displayed zones");
				for (auto cell : expected)
					require(reverted.count(cell), "Undo reverts every cell the stroke changed");
				for (int dx = -1; dx <= 1; ++dx)
					require(!reverted.count(index(dx, -1)) && gui.toolManager.displayedViewForZone(GameGUIToolManager::Forbidden).get(index(dx, -1)),
							"Undo leaves cells that were forbidden before the stroke");
				gui.orderQueue.clear();
				// A stroke that changes nothing offers no undo; undo expires; a cancelled stroke leaves none.
				tap(target.x, target.y);
				SDL_Delay(InGameTouchTheme::doubleTapWindowMs + 20);
				gui.touch->prepareDraw();
				drain();
				require(bool(gui.touch->zoneUndo), "Fixture stroke offers Undo");
				gui.touch->zoneUndo->expires = 0;
				gui.touch->prepareDraw();
				require(!gui.touch->zoneUndo, "Undo expires");
				tap(target.x, target.y);
				SDL_Delay(InGameTouchTheme::doubleTapWindowMs + 20);
				gui.touch->prepareDraw();
				drain();
				require(!gui.touch->zoneUndo, "A stroke that changes nothing offers no Undo");
				gui.brush.setType(BrushTool::MODE_DEL);
				finger(SDL_EVENT_FINGER_DOWN, 1, target.x, target.y);
				finger(SDL_EVENT_FINGER_MOTION, 1, target.x + 20 * unit, target.y);
				finger(SDL_EVENT_FINGER_DOWN, 2, target.x + 90 * unit, target.y);
				finger(SDL_EVENT_FINGER_UP, 2, target.x + 90 * unit, target.y);
				finger(SDL_EVENT_FINGER_UP, 1, target.x + 20 * unit, target.y);
				noOrder();
				require(!gui.touch->zoneUndo, "A cancelled stroke leaves no Undo");
				size_t k = 0;
				for (int dy = -1; dy <= 1; ++dy)
					for (int dx = -1; dx <= 1; ++dx)
						if (saved[k++]) map.addForbidden(cx + dx, cy + dy, gui.localTeamNo);
						else map.removeForbidden(cx + dx, cy + dy, gui.localTeamNo);
				gui.prepareLocalPresentation();
				gui.brush.defaultSelection();
				gui.clearSelection();
				require(!gui.touch->zoneUndo && !gui.touch->brushPan, "Leaving the brush forgets Undo and Pan");
			}
			{
				// Tools opens the lens strip; lenses run the tactical actions.
				auto centre = [](const GAGCore::ViewRect &r) { return GAGCore::ViewPoint{r.x + r.w / 2, r.y + r.h / 2}; };
				gui.clearSelection();
				gui.displayMode = GameGUI::CONSTRUCTION_VIEW;
				gui.touch->panelOpen = false;
				gui.touch->lensOpen = false;
				const auto bar = gui.touch->layout().actions;
				tap(bar.x + bar.w * 2.5f / 6, bar.y + bar.h / 2);
				require(gui.touch->lensVisible(), "Tools opens the lens strip");
				const auto ui = gui.touch->layout();
				const auto rects = gui.touch->lensRects(ui);
				const auto items = gui.touch->lenses();
				auto at = [&](int action)
				{
					for (size_t i = 0; i < items.size(); ++i)
						if (items[i].action == action)
							return centre(rects[i]);
					throw std::runtime_error("Missing lens");
				};
				const auto mini = gui.touch->minimapRect();
				for (const auto &r : rects)
					require(r.x >= ui.safe.x && r.x + r.w <= ui.safe.x + ui.safe.w && r.y + r.h <= ui.actions.y &&
								r.y >= mini.y + mini.h,
							"Lenses sit between the minimap and the toolbar");
				require(std::abs(rects[0].y + rects[0].h - (ui.actions.y - 8 * unit)) < 1 &&
							rects[0].x < ui.safe.x + 24 * unit,
						"The first lens sits opposite the thumb corner");
				const auto checksum = gui.game.checkSum();
				bool *flags[] = {&gui.showStarvingMap, &gui.showDamagedMap, &gui.showDefenseMap, &gui.showFertilityMap};
				for (int k = 0; k < 4; ++k)
				{
					const auto p = at(20 + k);
					tap(p.x, p.y);
					for (int j = 0; j < 4; ++j)
						require(*flags[j] == (j == k), "Overlay lenses are mutually exclusive");
				}
				glob2test::drawGUI(gui,0);
				gfx->printScreen(width < height ? "touch-lenses-portrait.bmp" : "touch-lenses-landscape.bmp");
				gfx->nextFrame();
				gui.touch->lensOpen = false;
				glob2test::drawGUI(gui,0);
				gfx->printScreen(width < height ? "touch-legend-portrait.bmp" : "touch-legend-landscape.bmp");
				gfx->nextFrame();
				gui.touch->lensOpen = true;
				auto p = at(-10);
				tap(p.x, p.y);
				require(!gui.showStarvingMap && !gui.showDamagedMap && !gui.showDefenseMap && !gui.showFertilityMap,
						"The No overlay lens clears overlays");
				const bool bars = gui.drawHealthFoodBar;
				p = at(6);
				tap(p.x, p.y);
				require(gui.drawHealthFoodBar != bars, "The health bar lens toggles bars");
				tap(p.x, p.y);
				require(gui.drawHealthFoodBar == bars && gui.touch->lensVisible(), "Lenses stay open while toggled");
				noOrder();
				require(gui.orderQueue.empty() && gui.game.checkSum() == checksum, "Lenses change no simulation state");
				// The statistics lens opens a sheet with the team's history chart.
				p = at(3);
				tap(p.x, p.y);
				require(gui.touch->statsOpen && !gui.touch->lensVisible(), "The statistics lens opens the sheet");
                require(std::none_of(gui.statistics().metrics().begin(), gui.statistics().metrics().end(),
                    [](const auto &m) { return m.winProbability; }), "Live players cannot see hidden-state win probabilities");
				const auto stats = gui.touch->statsLayout();
                require(stats.body.h >= 100 * unit && stats.sheet.y + stats.sheet.h <= ui.actions.y + 0.5,
                        "The sheet sits above the toolbar with room for statistics");
                glob2test::drawGUI(gui, 0);
                auto &panel = gui.statistics();
                require(panel.topic() == InGameStatisticsPanel::Topic::Overview, "Statistics starts on Overview");
                panel.selectTopic(InGameStatisticsPanel::Topic::Economy);
                glob2test::drawGUI(gui, 0);
                require(panel.host().find("stats/metric/idle workers") != nullptr, "Economy exposes worker time");
                panel.selectTopic(InGameStatisticsPanel::Topic::Overview);
				glob2test::drawGUI(gui,0);
				gfx->printScreen(width < height ? "touch-stats-portrait.bmp" : "touch-stats-landscape.bmp");
				gfx->nextFrame();
				finger(SDL_EVENT_FINGER_DOWN, 1, centre(stats.title).x, centre(stats.title).y);
				finger(SDL_EVENT_FINGER_MOTION, 1, centre(stats.title).x, centre(stats.title).y + 80 * unit);
				require(!gui.touch->statsOpen, "Pulling the sheet past its threshold closes it during the drag");
				finger(SDL_EVENT_FINGER_UP, 1, centre(stats.title).x, centre(stats.title).y + 80 * unit);
				require(!gui.touch->statsOpen && gui.touch->lensVisible(), "Pulling the sheet down closes it");
				tap(p.x, p.y);
				tap(centre(stats.close).x, centre(stats.close).y);
				require(!gui.touch->statsOpen, "The sheet's close button closes it");
				noOrder();
				require(gui.orderQueue.empty() && gui.game.checkSum() == checksum, "Statistics change no simulation state");
				// The map lens opens the peek: drag to steer, buttons zoom, outside closes.
				p = at(50);
				tap(p.x, p.y);
				require(gui.touch->peekOpen && !gui.touch->lensVisible(), "The map lens opens the map peek");
				glob2test::drawGUI(gui,0); // Builds the peek's minimap.
				const auto peek = gui.touch->peekRect();
				require(peek.w >= 200 * unit || peek.w >= ui.world.h - 120 * unit, "The map peek is large");
				const GAGCore::ViewPoint a{peek.x + peek.w * .3, peek.y + peek.h * .3}, b{peek.x + peek.w * .7, peek.y + peek.h * .6};
				finger(SDL_EVENT_FINGER_DOWN, 1, a.x, a.y);
				finger(SDL_EVENT_FINGER_MOTION, 1, b.x, b.y);
				const int dragX = gui.viewportX, dragY = gui.viewportY;
				gui.touch->navigatePeek(b);
				require(gui.viewportX == dragX && gui.viewportY == dragY, "Dragging in the peek steers the camera");
				gui.touch->navigatePeek(a);
				require(gui.viewportX != dragX || gui.viewportY != dragY, "Peek drag fixture moves the camera");
				finger(SDL_EVENT_FINGER_UP, 1, b.x, b.y);
				glob2test::drawGUI(gui,0);
				gfx->printScreen(width < height ? "touch-peek-portrait.bmp" : "touch-peek-landscape.bmp");
				gfx->nextFrame();
				const auto buttons = gui.touch->peekButtons();
				gui.updateCamera();
				gui.camera.setZoom(1, gfx->getW() / 2, gfx->getH() / 2);
				gui.viewportX = gui.camera.tileX();
				gui.viewportY = gui.camera.tileY();
				tap(centre(buttons[2]).x, centre(buttons[2]).y);
				require(std::abs(gui.camera.zoom - InGameTouchTheme::peekZoomStep) < 0.01, "Peek + zooms in");
				tap(centre(buttons[1]).x, centre(buttons[1]).y);
				require(std::abs(gui.camera.zoom - 1) < 0.01 && gui.touch->peekOpen, "Peek − zooms out");
				const GAGCore::ViewPoint outside{ui.world.x + 8 * unit, ui.world.y + 8 * unit};
				require(!peek.contains(outside), "Outside fixture must miss the peek");
				tap(outside.x, outside.y);
				require(!gui.touch->peekOpen && !gui.touch->lensVisible(), "A tap outside dismisses the peek and its underlying tools");
				noOrder();
				// A still press on the minimap opens the peek; its release does nothing.
				gui.touch->lensOpen = false;
				finger(SDL_EVENT_FINGER_DOWN, 1, centre(mini).x, centre(mini).y);
				gui.touch->minimapPress = SDL_GetTicks() - 1000;
				gui.touch->prepareDraw();
				require(gui.touch->peekOpen, "A still press on the minimap opens the map peek");
				const int heldX = gui.viewportX, heldY = gui.viewportY;
				finger(SDL_EVENT_FINGER_UP, 1, centre(mini).x, centre(mini).y);
				require(gui.touch->peekOpen && gui.viewportX == heldX && gui.viewportY == heldY,
						"Releasing the press neither navigates nor closes the peek");
				SDL_Event focus{};
				focus.type = SDL_EVENT_WINDOW_RESIZED;
				focus.type = SDL_EVENT_WINDOW_FOCUS_LOST;
				gui.processEvent(&focus);
				focus.type = SDL_EVENT_WINDOW_FOCUS_GAINED;
				gui.processEvent(&focus);
				require(!gui.touch->peekOpen, "Focus loss closes the peek");
				gui.displayMode = GameGUI::CONSTRUCTION_VIEW;
				gui.touch->panelOpen = true; // The palette state the following cases start from.
				noOrder();
			}
			auto ui = gui.touch->layout();
			const int cameraX = gui.viewportX, cameraY = gui.viewportY;
			finger(SDL_EVENT_FINGER_DOWN, 1, ui.panel.x + 2 * unit, ui.panel.y + 70 * unit);
			finger(SDL_EVENT_FINGER_MOTION, 1, ui.panel.x + 2 * unit, ui.panel.y + 30 * unit);
			finger(SDL_EVENT_FINGER_UP, 1, ui.panel.x + 2 * unit, ui.panel.y + 30 * unit);
			require(gui.viewportX == cameraX && gui.viewportY == cameraY,
					"Panel scrolling must not pan the world");
			noOrder();
			const auto inn =
				std::find(gui.buildingsChoiceName.begin(), gui.buildingsChoiceName.end(), innChoice) -
				gui.buildingsChoiceName.begin();
			require(inn < static_cast<decltype(inn)>(gui.buildingsChoiceName.size()),
					"The touch palette must contain the catalog's placeable inn");
			gui.touch->panelScroll = 0;
			gui.touch->clampScroll();
			const auto palette = gui.touch->paletteItemRect(inn);
			tap(palette.x + palette.w / 2, palette.y + palette.h / 2);
			require(gui.selectionMode == GameGUI::TOOL_SELECTION &&
						gui.toolManager.getBuildingName() == innChoice,
					"Labeled touch palette must select the same building after rotation");
			noOrder();
			gui.clearSelection();
			gui.scriptText =
				"Build an inn to feed your workers. Drag the panel to find more buildings. "
				"Select a building, choose a location, and confirm when you are ready.\n"
				"This long instruction remains readable after rotating the phone.";
			gui.swallowSpaceKey = true;
			gui.setIsSpaceSet(false);
			glob2test::drawGUI(gui,0);
			gfx->printScreen(width < height ? "touch-scenario-message-portrait.bmp"
											: "touch-scenario-message-landscape.bmp");
			gfx->nextFrame();
			finger(SDL_EVENT_FINGER_DOWN, 1, 30 * unit, 80 * unit);
			finger(SDL_EVENT_FINGER_MOTION, 1, 30 * unit, 60 * unit);
			finger(SDL_EVENT_FINGER_UP, 1, 30 * unit, 60 * unit);
			require(!gui.isSpaceSet(), "Scrolling scenario text must not acknowledge it");
			const auto message = gui.touch->scenarioMessageRect();
			tap(message.x + 20 * unit, message.y + message.h - 24 * unit);
			require(gui.isSpaceSet(), "Scenario message acknowledgment uses the shared Space action");
			gui.scriptText.clear();
			gui.swallowSpaceKey = false;
		}
		require(gui.game.checkSum() == hudChecksum,
				"HUD interaction must not mutate the simulation");
		// Both input patterns must reach the identical construction operation.
		// Flags have no resource cost and are convenient placement fixtures.
		gui.clearSelection();
		gui.touch->cancel();
		gui.displayMode = GameGUI::FLAG_VIEW;
		gui.touch->panelOpen = true;
		gui.touch->panelScroll = 0;
		glob2test::drawGUI(gui,0);
		gfx->nextFrame();
		const auto icon = gui.touch->paletteItemRect(1);
		const float iconX = icon.x + icon.w / 2, iconY = icon.y + icon.h / 2;
		const float dropX = 120, dropY = 190;
		finger(SDL_EVENT_FINGER_DOWN, 1, iconX, iconY);
		require(gui.touch->placement.has_value(),
				"Palette press starts an owned placement session");
		noOrder();
		finger(SDL_EVENT_FINGER_MOTION, 99, dropX, dropY);
		finger(SDL_EVENT_FINGER_UP, 99, dropX, dropY);
		require(gui.touch->placement.has_value(),
				"Unknown contact motion and release do not steal placement ownership");
		noOrder();
		finger(SDL_EVENT_FINGER_MOTION, 1, dropX, dropY);
		noOrder();
		require(gui.touch->showsBuildPalette(),
				"Active placement retains palette composition for persistent layouts");
		glob2test::drawGUI(gui,0);
		gfx->printScreen("touch-drag-preview.bmp");
		gfx->nextFrame();
		finger(SDL_EVENT_FINGER_UP, 1, dropX, dropY);
		auto dragged = std::dynamic_pointer_cast<OrderCreate>(gui.toolManager.getOrder());
		require(bool(dragged), "Valid palette drag commits one order on release");
		noOrder();
		require(gui.touch->panelOpen && gui.selectionMode == GameGUI::NO_SELECTION,
				"Drag restores the repeated-placement palette");
		gui.ghostManager.removeBuilding(dragged->posX, dragged->posY);
		tap(iconX, iconY);
		noOrder();
		require(gui.selectionMode == GameGUI::TOOL_SELECTION,
				"Palette tap selects preview-and-confirm");
		tap(dropX, dropY - 48 * gfx->logicalUnitsPerPoint());
		noOrder();
		const auto confirm = gui.touch->confirmRect(), cancelBox = gui.touch->cancelRect();
		require(confirm.x > cancelBox.x && confirm.y == cancelBox.y &&
					confirm.x + confirm.w <= gui.touch->controls().x + gui.touch->controls().w + 0.5,
				"Phone placement puts OK on the thumb side of the bar");
		tap(confirm.x + confirm.w / 2, confirm.y + confirm.h / 2);
		auto tapped = std::dynamic_pointer_cast<OrderCreate>(gui.toolManager.getOrder());
		require(tapped && std::memcmp(tapped->getData(), dragged->getData(),
									  dragged->getDataLength()) == 0,
				"Tap and drag serialize equivalent construction commands");
		noOrder();
		gui.ghostManager.removeBuilding(tapped->posX, tapped->posY);
		gui.touch->panelOpen = true;
		finger(SDL_EVENT_FINGER_DOWN, 1, iconX, iconY);
		finger(SDL_EVENT_FINGER_MOTION, 1, dropX, dropY);
		finger(SDL_EVENT_FINGER_UP, 1, iconX, iconY);
		noOrder();
		require(gui.touch->panelOpen, "Dropping back onto the source palette cancels construction");
		finger(SDL_EVENT_FINGER_DOWN, 1, iconX, iconY);
		finger(SDL_EVENT_FINGER_MOTION, 1, dropX, dropY);
		finger(SDL_EVENT_FINGER_DOWN, 2, dropX + 30, dropY);
		finger(SDL_EVENT_FINGER_UP, 1, dropX, dropY);
		finger(SDL_EVENT_FINGER_UP, 2, dropX + 30, dropY);
		noOrder();
		require(!gui.touch->placement && gui.touch->panelOpen,
				"Second finger cancels palette placement without a release tap");
		gui.localTeam->noMoreBuildingSitesCountdown = 1;
        gui.game.snapshots().invalidateBoundary();
        gui.prepareLocalPresentation();
		finger(SDL_EVENT_FINGER_DOWN, 1, iconX, iconY);
		finger(SDL_EVENT_FINGER_MOTION, 1, dropX, dropY);
		finger(SDL_EVENT_FINGER_UP, 1, dropX, dropY);
		noOrder();
		gui.localTeam->noMoreBuildingSitesCountdown = 0;
        gui.game.snapshots().invalidateBoundary();
        gui.prepareLocalPresentation();
		gui.clearSelection();
		for (bool drag : {false, true})
		{
			gui.clearSelection();
			gui.touch->panelOpen = true;
			gui.displayMode = GameGUI::FLAG_VIEW;
			const auto source = gui.touch->paletteItemRect(1);
			const auto bounds = gui.touch->world();
			const double x = bounds.x + 2, y = bounds.y + bounds.h / 2;
			if (drag)
			{
				finger(SDL_EVENT_FINGER_DOWN, 1, source.x + source.w / 2, source.y + source.h / 2);
				finger(SDL_EVENT_FINGER_MOTION, 1, x, y);
			}
			else
			{
				tap(source.x + source.w / 2, source.y + source.h / 2);
				finger(SDL_EVENT_FINGER_DOWN, 1, x, y);
			}
			auto &session = drag ? gui.touch->placement : gui.touch->placementHold;
			require(bool(session), "Both placement patterns own a held contact");
			gui.camera.originX = 0;
			gui.viewportX = 0;
			session->lastUpdate = SDL_GetTicks() - 100;
			gui.touch->advancePlacement();
			require(gui.camera.originX > gui.game.map.getW() * 16,
					"Stationary edge hold pans and wraps across the toroidal boundary");
			noOrder();
			// Hovering over UI suspends panning even if the contact began on the map.
			const auto toolbar = gui.touch->layout().actions;
			finger(SDL_EVENT_FINGER_MOTION, 1, x, toolbar.y + toolbar.h / 2);
			const double overUI = gui.camera.originX;
			session->lastUpdate = SDL_GetTicks() - 100;
			gui.touch->advancePlacement();
			require(gui.camera.originX == overUI, "Placement never pans while over UI");
			finger(SDL_EVENT_FINGER_MOTION, 1, x, y);
			if (!drag)
			{
				finger(SDL_EVENT_FINGER_UP, 1, x, y);
				const double released = gui.camera.originX;
				gui.touch->advancePlacement();
				require(!gui.touch->placementHold && gui.camera.originX == released,
						"Preview release stops panning and still requires confirmation");
				noOrder();
				finger(SDL_EVENT_FINGER_DOWN, 1, x, y);
			}
			finger(SDL_EVENT_FINGER_DOWN, 2, x + 30, y);
			const double stopped = gui.camera.originX;
			gui.touch->advancePlacement();
			require(!gui.touch->placementHold && !gui.touch->placement &&
						gui.camera.originX == stopped,
					"Second finger stops placement edge panning");
			finger(SDL_EVENT_FINGER_UP, 1, x, y);
			finger(SDL_EVENT_FINGER_UP, 2, x + 30, y);
			noOrder();
			gui.touch->cancel();
		}
		gui.touch->panelOpen = false;
		auto fixture = [&](const char *name, int slot)
		{
			while (slot < Building::MAX_COUNT && gui.localTeam->myBuildings[slot]) ++slot;
			require(slot < Building::MAX_COUNT, "Action fixture has a free building slot");
			auto *b = new Building(0, 0, slot, gui.game.buildingsTypes.getTypeNum(name, 0, false),
				gui.localTeam, &gui.game.buildingsTypes, 1, 1);
			gui.localTeam->attachBuilding(slot, b);
			return b;
		};
		auto *building = fixture("inn", 2);
		require(building->type->maxUnitWorking > 0, "Allocation fixture must accept workers");
		auto actionPoint = [&](int kind, int value, int side = 0)
		{
			// The selected snapshot (including stocks) must exist before choosing
			// between the dial and the row layout used by the rendered frame.
			glob2test::drawGUI(gui, 0);
			if (gui.touch->usesDial())
			{
				// The phone dial uses the same action regions as rendering.
				glob2test::drawGUI(gui,0);
				gfx->nextFrame();
				const auto p = gui.touch->dialActionPoint(kind, value, side);
				require(p.x >= 0, ("Building action must be on the dial: kind " +
					std::to_string(kind) + " value " + std::to_string(value) +
					" side " + std::to_string(side)).c_str());
				return p;
			}
			for (int attempt = 0; attempt < 30; ++attempt)
			{
				glob2test::drawGUI(gui,0);
				gfx->nextFrame();
				const auto rows = gui.touch->buildingActions();
				const auto found =
					std::find_if(rows.begin(), rows.end(), [&](const auto &row)
								 { return row.kind == kind && (kind == 7 || row.value == value); });
				require(found != rows.end(), ("Building action must be available: kind " + std::to_string(kind) +
					" value " + std::to_string(value) + " viewport " + std::to_string(gfx->getW()) + "x" +
					std::to_string(gfx->getH()) + " selection " + std::to_string(gui.selectionMode)).c_str());
				const auto r = gui.touch->panelContent();
				const double u = gfx->logicalUnitsPerPoint();
				const auto box = gui.touch->buildingActionRect(std::distance(rows.begin(), found));
				const double top = box.y;
				if (top >= r.y && top + box.h <= r.y + r.h)
					return GAGCore::ViewPoint{kind == 7  ? box.x + (value + 1.5) * box.w / 3
											  : side < 0 ? box.x + 24 * u
											  : side > 0 ? box.x + box.w - 24 * u
														 : box.x + box.w / 2,
											  top + box.h - 22 * u};
				const float x = r.x + r.w / 2, y = r.y + r.h / 2;
				const float delta = (top < r.y ? 1 : -1) * std::min(r.h / 3, 56 * u);
				finger(SDL_EVENT_FINGER_DOWN, 1, x, y);
				finger(SDL_EVENT_FINGER_MOTION, 1, x, y + delta);
				finger(SDL_EVENT_FINGER_UP, 1, x, y + delta);
			}
			throw std::runtime_error("Building action must be reachable by scrolling");
		};
		auto pressAction = [&](int kind, int value = 0, int side = 0)
		{
			auto p = actionPoint(kind, value, side);
			tap(p.x, p.y);
		};
		auto *rangeFlag = fixture("warflag", 3);
		{
			const auto savedCamera = gui.camera;
			const int savedX = gui.viewportX, savedY = gui.viewportY;
			const auto savedFlags = gui.localTeam->virtualBuildings;
			gui.localTeam->virtualBuildings = {rangeFlag};
			rangeFlag->posX = rangeFlag->posY = 2;
            gui.game.snapshots().invalidateBoundary();
            gui.prepareLocalPresentation();
			gui.view.mouseUnit = UnitRef();
			{
				// The reach is 30 points in the middle of the screen and grows to 36
				// at its edges and corners, where thumbs are least accurate.
				const double unit = gfx->logicalUnitsPerPoint();
				const double w = gfx->getW(), h = gfx->getH();
				auto close = [](double a, double b) { return std::abs(a - b) < 1e-6; };
				require(close(gui.flagReachAt(w / 2, h / 2), InGameTouchTheme::flagReach) ||
							std::min(w, h) / 2 < InGameTouchTheme::flagReachEdgeBand * unit,
						"Flags reach 30 points in the middle of the screen");
				require(close(gui.flagReachAt(0, h / 2), InGameTouchTheme::flagReachEdge) &&
							close(gui.flagReachAt(w, h), InGameTouchTheme::flagReachEdge),
						"Flags reach 36 points at the screen's edges and corners");
				const double halfway = gui.flagReachAt(w / 2, InGameTouchTheme::flagReachEdgeBand / 2 * unit);
				require(close(halfway, (InGameTouchTheme::flagReach + InGameTouchTheme::flagReachEdge) / 2) ||
							w / 2 < InGameTouchTheme::flagReachEdgeBand * unit,
						"The reach grows linearly across the edge band");
				require(gui.flagReachAt(w / 2, 10 * unit) > gui.flagReachAt(w / 2, 60 * unit),
						"Closer to the edge reaches further");
			}
			for (double zoom : {.33, .5, 1.})
			{
				gui.camera.zoom = zoom;
				gui.updateCamera();
				gui.camera.originX = gui.camera.originY = 0;
				gui.viewportX = gui.viewportY = 0;
				gui.updateCamera();
				const auto center = gui.camera.worldToScreen(80, 80);
				const double unit = gfx->logicalUnitsPerPoint();
				const int x = int(center.first + 20 * unit), y = int(center.second);
				const int mapX = gui.mapMouseX(x) / 32 + gui.viewportX;
				const int mapY = gui.mapMouseY(y) / 32 + gui.viewportY;
				require(gui.game.map.getBuilding(mapX, mapY) == NOGBID,
						"Flag halo fixture needs ground outside buildings");
				gui.clearSelection();
				gui.handleMapClick(x, y, SDL_BUTTON_LEFT);
				require(gui.selectionMode == GameGUI::BUILDING_SELECTION &&
							gui.selectionBuilding() == rangeFlag && !gui.selectionPushed,
						"Near flag clicks select across zoom levels without starting a move");
				SDL_MouseButtonEvent release{};
				release.button = SDL_BUTTON_LEFT;
				release.x = x;
				release.y = y;
				gui.handleMouseButtonUp(release);
				require(gui.orderQueue.empty(), "Forgiving flag selection must not move the flag");
				gui.game.map.setBuilding(mapX, mapY, 1, 1, building->gid);
                gui.prepareLocalPresentation();
				gui.clearSelection();
				gui.handleMapClick(x, y, SDL_BUTTON_LEFT);
				require(gui.selectionMode == GameGUI::BUILDING_SELECTION &&
							gui.selectionBuilding() == building,
						"Expanded flag hits must not steal direct building selection");
				gui.game.map.setBuilding(mapX, mapY, 1, 1, NOGBID);
                gui.prepareLocalPresentation();
				// 28 points is inside the reach anywhere on screen, 40 beyond it everywhere.
				gui.clearSelection();
				gui.handleMapClick(int(center.first + 28 * unit), y, SDL_BUTTON_LEFT);
				require(gui.selectionMode == GameGUI::BUILDING_SELECTION && gui.selectionBuilding() == rangeFlag,
						"A click 28 points from a flag selects it at every zoom");
				gui.clearSelection();
				gui.handleMapClick(int(center.first + 40 * unit), y, SDL_BUTTON_LEFT);
				require(gui.selectionMode != GameGUI::BUILDING_SELECTION,
						"Clicks outside the halo must not select a flag");

				// The larger target belongs to touch presentation only. Check
				// both a near miss and an exact desktop hit at every zoom.
				GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
				gui.clearSelection();
				gui.updateCamera();
				// Switching presentation preserves the camera centre; reset the
				// fixture origin so the flag stays inside the desktop viewport.
				gui.camera.originX = gui.camera.originY = 0;
				gui.viewportX = gui.viewportY = 0;
				const auto desktopCenter = gui.camera.worldToScreen(80, 80);
				gui.handleMapClick(int(desktopCenter.first + 20 * unit), int(desktopCenter.second),
								   SDL_BUTTON_LEFT);
				require(gui.selectionMode != GameGUI::BUILDING_SELECTION,
						"Desktop must not use the touch flag selection halo");
				gui.clearSelection();
				gui.handleMapClick(int(desktopCenter.first), int(desktopCenter.second),
								   SDL_BUTTON_LEFT);
				require(gui.selectionMode == GameGUI::BUILDING_SELECTION &&
							gui.selectionBuilding() == rangeFlag && gui.selectionPushed,
						"Desktop exact flag hits retain selection and dragging");
				gui.clearSelection();
				GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
				gui.updateCamera();
			}
			gui.camera.zoom = 1;
			gui.viewportX = gui.game.map.getW() - 2;
			gui.viewportY = 0;
			gui.camera.originX = gui.viewportX * 32.;
			gui.camera.originY = 0;
			rangeFlag->posX = gui.game.map.getW() - 1;
            gui.game.snapshots().invalidateBoundary();
            gui.prepareLocalPresentation();
			require(gui.game.map.getBuilding(0, 2) == NOGBID, "Seam fixture needs empty ground");
			gui.clearSelection();
			gui.handleMapClick(int(gui.camera.offsetX + 69), int(gui.camera.offsetY + 80),
							   SDL_BUTTON_LEFT);
			require(gui.selectionMode == GameGUI::BUILDING_SELECTION &&
						gui.selectionBuilding() == rangeFlag,
					"Expanded flag selection crosses the toroidal seam");
			rangeFlag->posX = rangeFlag->posY = 0;
			gui.localTeam->virtualBuildings = savedFlags;
			gui.clearSelection();
			gui.camera = savedCamera;
			gui.viewportX = savedX;
			gui.viewportY = savedY;
		}

		require(rangeFlag->type->defaultUnitStayRange && rangeFlag->type->maxUnitWorking,
				"Flag fixture needs range and workers");
		gui.orderQueue.clear();
		for (auto [width, height] : {std::pair{320, 568}, {568, 320}})
		{
			const int oldW = gfx->getW(), oldH = gfx->getH();
			SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
			GLOB2_REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())), "Window resize must settle before layout assertions");
			SDL_Event resized{};
			resized.type = SDL_EVENT_WINDOW_RESIZED;
			resized.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
			GAGCore::GraphicContext::translateMouseEvent(&resized);
			gui.viewportResized(oldW, oldH, gfx->getW(), gfx->getH());
			const float unit = gfx->logicalUnitsPerPoint();
			// A completed empty-map tap dismisses inspection without returning to
			// the previous palette, in both phone orientations.
			for (bool paletteWasOpen : {false, true})
			{
				gui.setSelection(GameGUI::BUILDING_SELECTION, building);
				gui.touch->panelOpen = true;
				gui.touch->restorePalette = true;
				gui.touch->previousPanelOpen = paletteWasOpen;
				gui.touch->previousDisplayMode = gui.displayMode;
				gui.touch->prepareDraw();
				bool dismissed = false;
				for (int y = 80; y < gfx->getH() - 80 && !dismissed; y += 32)
					for (int x = 16; x < gfx->getW() && !dismissed; x += 32)
					{
						if (gui.touch->interfaceRegion({double(x), double(y)}) != 0)
							continue;
						const int mx = gui.mapMouseX(x) / 32 + gui.viewportX;
						const int my = gui.mapMouseY(y) / 32 + gui.viewportY;
						if (gui.game.map.getBuilding(mx, my) != NOGBID ||
							gui.game.map.isResource(mx, my) ||
							gui.game.map.getGroundUnit(mx, my) != NOGUID ||
							gui.game.map.getAirUnit(mx, my) != NOGUID)
							continue;
						tap(x, y);
						gui.touch->prepareDraw();
						require(gui.selectionMode == GameGUI::NO_SELECTION,
								"Empty map tap must dismiss the building inspector");
						require(!gui.touch->panelOpen && !gui.touch->restorePalette && gui.orderQueue.empty(),
								"Dismissal must close the previous palette without issuing an order");
						dismissed = true;
					}
				require(dismissed, "Inspector dismissal fixture needs exposed empty terrain");
			}
			gui.touch->panelOpen = false;
			gui.setSelection(GameGUI::BUILDING_SELECTION, building);
			// Selection opens the inspector; Tools now explicitly replaces it.
			gui.touch->panelOpen = true;
			auto workerPoint = actionPoint(6, 0, 1);
			const float plusX = workerPoint.x, rowY = workerPoint.y;
			const int before = gui.displayedMaxUnitWorking(*building),
					  authoritative = building->maxUnitWorking;
			const auto simulation = gui.game.checkSum();
			tap(plusX, rowY);
			tap(plusX, rowY);
			require(gui.orderQueue.size() == 2,
					"Two allocation taps must queue exactly two orders");
			auto first = std::dynamic_pointer_cast<OrderModifyBuilding>(gui.orderQueue.front());
			gui.orderQueue.pop_front();
			auto second = std::dynamic_pointer_cast<OrderModifyBuilding>(gui.orderQueue.front());
			gui.orderQueue.pop_front();
			require(first && second && first->gid == building->gid &&
						first->numberRequested == before + 1 &&
						second->numberRequested == before + 2,
					"Rapid allocation taps use pending values and the shared order format");
			require(building->maxUnitWorking == authoritative && gui.game.checkSum() == simulation,
					"Allocation UI must not change authoritative simulation state");
			// Drag along the worker slider: the phone dial's outer arc, or the row track.
			GAGCore::ViewPoint slideFrom, slideTo;
			int slideValue = -1;
			if (gui.touch->usesDial())
			{
				const auto g = gui.touch->dialLayout(gui.touch->layout()).geometry;
				const auto regions = gui.touch->dialRegions();
				const auto arc = std::find_if(regions.begin(), regions.end(), [](const auto &r)
											  { return r.part == GameGUITouch::DialRegion::Arc && r.action.kind == 6; });
				require(arc != regions.end(), "The dial has a worker slider");
				slideFrom = TouchDial::point(g, g.rings[arc->ring].middle(), (arc->from + arc->to) / 2);
				slideTo = TouchDial::point(g, g.rings[arc->ring].middle(), arc->to - 2);
				slideValue = TouchDial::value(arc->to - 2, arc->sliderFrom, arc->sliderTo, arc->maximum);
			}
			else
			{
				const auto track = gui.touch->buildingActionRect(0);
				slideFrom = {track.x + track.w / 2, rowY};
				slideTo = {track.x + track.w - 60 * unit, rowY};
			}
			finger(SDL_EVENT_FINGER_DOWN, 1, slideFrom.x, slideFrom.y);
			finger(SDL_EVENT_FINGER_MOTION, 1, slideTo.x, slideTo.y);
			require(gui.touch->allocation && gui.orderQueue.empty(),
					"Slider drag previews without intermediate orders");
			if (gui.touch->usesDial())
			{
				glob2test::drawGUI(gui,0);
				gfx->printScreen(width < height ? "touch-dial-drag-portrait.bmp" : "touch-dial-drag-landscape.bmp");
				gfx->nextFrame();
			}
			finger(SDL_EVENT_FINGER_UP, 1, slideTo.x, slideTo.y);
			require(!gui.touch->allocation && gui.orderQueue.size() == 1,
					"Slider release sends exactly one allocation order");
			if (slideValue >= 0)
			{
				auto slid = std::dynamic_pointer_cast<OrderModifyBuilding>(gui.orderQueue.front());
				require(slid && slid->numberRequested == slideValue,
						"The dial requests the worker count under the thumb");
			}
			gui.orderQueue.clear();
			finger(SDL_EVENT_FINGER_DOWN, 1, slideFrom.x, slideFrom.y);
			finger(SDL_EVENT_FINGER_MOTION, 1, slideTo.x, slideTo.y);
			finger(SDL_EVENT_FINGER_DOWN, 2, slideFrom.x, slideFrom.y);
			finger(SDL_EVENT_FINGER_UP, 1, slideTo.x, slideTo.y);
			finger(SDL_EVENT_FINGER_UP, 2, slideFrom.x, slideFrom.y);
			require(!gui.touch->allocation && gui.orderQueue.empty(),
					"Second finger cancels slider without an order");
			glob2test::drawGUI(gui,0);
			gfx->printScreen(width < height ? "touch-allocation-portrait.bmp"
											: "touch-allocation-landscape.bmp");
			gfx->nextFrame();
			gui.prepareLocalPresentation();
            REQUIRE(gui.inputBuildingPanel());
            gui.requestWorkerAllocation(*gui.inputBuildingPanel(), MAX_UNIT_WORKING);
			gui.orderQueue.clear();
			tap(plusX, rowY);
			require(gui.orderQueue.empty(), "Allocation at maximum must not queue duplicates");
			finger(SDL_EVENT_FINGER_DOWN, 1, plusX, rowY);
			gui.clearSelection();
			finger(SDL_EVENT_FINGER_UP, 1, plusX, rowY);
			require(gui.orderQueue.empty(), "Selection changes cancel held allocation gestures");
			gui.setSelection(GameGUI::BUILDING_SELECTION, building);
			gui.prepareLocalPresentation();
            REQUIRE(gui.inputBuildingPanel());
            gui.requestWorkerAllocation(*gui.inputBuildingPanel(), 0);
			gui.orderQueue.clear();
			pressAction(6, 0, -1);
			require(gui.orderQueue.empty(), "Allocation at zero must not queue duplicates");
			for (int priority : {-1, 0, 1})
			{
				pressAction(7, priority);
				require(gui.orderQueue.size() == 1, "Priority tap emits exactly one order");
				auto order = std::dynamic_pointer_cast<OrderChangePriority>(gui.orderQueue.front());
				gui.orderQueue.clear();
				require(order && order->gid == building->gid && order->priority == priority,
						"Priority uses the shared order format");
				pressAction(7, priority);
				require(gui.orderQueue.empty(), "Selected pending priority is a no-op");
			}
			require(gui.game.checkSum() == simulation,
					"Priority changes stay outside authoritative state");
			glob2test::drawGUI(gui,0);
			gfx->printScreen(width < height ? "touch-priority-portrait.bmp"
											: "touch-priority-landscape.bmp");
			gfx->nextFrame();
			gui.setSelection(GameGUI::BUILDING_SELECTION, rangeFlag);
			const int rangeBefore = gui.displayedUnitStayRange(*rangeFlag);
			const auto rangeChecksum = gui.game.checkSum();
			pressAction(8, 0, 1);
			pressAction(8, 0, 1);
			require(gui.orderQueue.size() == 2, "Rapid range taps queue two orders");
			for (int delta : {1, 2})
			{
				auto order = std::dynamic_pointer_cast<OrderModifyFlag>(gui.orderQueue.front());
				gui.orderQueue.pop_front();
				require(order && order->gid == rangeFlag->gid &&
							order->range == rangeBefore + delta,
						"Range uses pending values and shared orders");
			}
			glob2test::drawGUI(gui,0);
			gfx->printScreen(width < height ? "touch-range-portrait.bmp"
											: "touch-range-landscape.bmp");
			gfx->nextFrame();
			gui.prepareLocalPresentation();
            REQUIRE(gui.inputBuildingPanel());
            gui.requestFlagRange(*gui.inputBuildingPanel(), rangeFlag->type->maxUnitStayRange);
			gui.orderQueue.clear();
			pressAction(8, 0, 1);
			require(gui.orderQueue.empty(), "Maximum range is a no-op");
			gui.prepareLocalPresentation();
            REQUIRE(gui.inputBuildingPanel());
            gui.requestFlagRange(*gui.inputBuildingPanel(), 0);
			gui.orderQueue.clear();
			pressAction(8, 0, -1);
			require(gui.orderQueue.empty(), "Zero range is a no-op");
			finger(SDL_EVENT_FINGER_DOWN, 1, plusX, rowY);
			gui.setSelection(GameGUI::BUILDING_SELECTION, building);
			finger(SDL_EVENT_FINGER_UP, 1, plusX, rowY);
			require(gui.orderQueue.empty(),
					"Changing selected buildings cancels held range controls");
			require(gui.game.checkSum() == rangeChecksum,
					"Range controls preserve authoritative state");
			tap(gfx->getW() * 5.5f / 6, gfx->getH() - 24 * unit);
			require(gui.inGameMenu == GameGUI::IGM_MAIN, "Toolbar opens the in-game pause menu");
			glob2test::drawGUI(gui,0);
			gfx->printScreen(width < height ? "touch-pause-portrait.bmp"
											: "touch-pause-landscape.bmp");
			gfx->nextFrame();
			require(bool(gui.gameMenuScreen), "Pause menu dialog must exist");
			const auto back = gui.gameMenuScreen->host().bounds("return");
			const float returnX = back.x + back.w / 2, returnY = back.y + back.h / 2;
			finger(SDL_EVENT_FINGER_DOWN, 1, returnX, returnY);
			finger(SDL_EVENT_FINGER_MOTION, 1, returnX + 20 * unit, returnY);
			finger(SDL_EVENT_FINGER_UP, 1, returnX + 20 * unit, returnY);
			require(gui.inGameMenu == GameGUI::IGM_MAIN,
					"A dragged pause button must not activate");
			SDL_Event mouse{};
			mouse.type = SDL_EVENT_MOUSE_BUTTON_DOWN;
			mouse.button.button = SDL_BUTTON_LEFT;
			mouse.button.x = int(returnX);
			mouse.button.y = int(returnY);
			gui.processEvent(&mouse);
			mouse.type = SDL_EVENT_MOUSE_BUTTON_UP;
			gui.processEvent(&mouse);
			require(!gui.inGameMenu, "Mouse activates the same visible Return control");
			tap(gfx->getW() * 5.5f / 6, gfx->getH() - 24 * unit);
			glob2test::drawGUI(gui,0);
			finger(SDL_EVENT_FINGER_DOWN, 1, returnX, returnY);
			finger(SDL_EVENT_FINGER_DOWN, 2, returnX, returnY);
			finger(SDL_EVENT_FINGER_UP, 2, returnX, returnY);
			finger(SDL_EVENT_FINGER_UP, 1, returnX, returnY);
			require(
				gui.inGameMenu == GameGUI::IGM_MAIN,
				"Switching back to touch consumes the whole gesture before accepting an action");
			glob2test::drawGUI(gui,0);
			gfx->nextFrame();
			tap(returnX, returnY);
			require(gui.inGameMenu == GameGUI::IGM_NONE && gui.orderQueue.empty(),
					"Return resumes without leaking a world order");
			tap(gfx->getW() * 2.5f / 6,
				gfx->getH() - 24 * unit); // Close the inspector before the next orientation.
			gui.clearSelection();
		}

		int workerSlot = 0;
		while (workerSlot < Unit::MAX_COUNT && gui.localTeam->myUnits[workerSlot])
			++workerSlot;
		require(workerSlot < Unit::MAX_COUNT, "Repair fixture has a free worker slot");
		gui.localTeam->attachUnit(workerSlot, new Unit(0, 0, workerSlot, WORKER, gui.localTeam, 3));
		bool constructionSpace = false;
		for (int y = 0; y < gui.game.map.getH() && !constructionSpace; ++y)
			for (int x = 0; x < gui.game.map.getW() && !constructionSpace; ++x)
			{
				building->posX = x;
				building->posY = y;
				constructionSpace = building->isHardSpaceForBuildingSite(Building::REPAIR) &&
									building->isHardSpaceForBuildingSite(Building::UPGRADE);
			}
		require(constructionSpace, "Fixture has space for repair and upgrade");

		auto *swarm = fixture("swarm", 4);
		auto *clearing = fixture("clearingflag", 5);
		auto *exploring = fixture("explorationflag", 6);
		auto *wall = fixture("stonewall", 7);
		auto openActions = [&](Building *b)
		{
			gui.setSelection(GameGUI::BUILDING_SELECTION, b);
			gui.touch->panelOpen = true;
			glob2test::drawGUI(gui,0);
			gui.touch->actionScroll = 0;
			gui.orderQueue.clear();
		};
		auto checkFallbackHeader = [&] {
			const auto ui = gui.touch->layout();
			const auto hud = gui.touch->hudLayout(ui);
			const auto header = gui.touch->allocationRect();
			auto approx = [](double a, double b) { return std::abs(a - b) < .5; };
			require(approx(header.x, hud.stats.x) && approx(header.w, hud.stats.w) &&
				approx(header.y, hud.stats.y + hud.stats.h + 4 * gfx->logicalUnitsPerPoint()) &&
				header.y >= hud.stats.y + hud.stats.h,
				"Row fallback keeps the compact identity below stats beside the minimap");
			const auto content = gui.touch->panelContent();
			require(approx(content.y, ui.panel.y) && approx(content.h, ui.panel.h),
				"Fallback rows use their full panel; identity consumes no row space");
			const GAGCore::ViewPoint close{header.x + header.w - 24 * gfx->logicalUnitsPerPoint(),
				header.y + header.h / 2};
			require(gui.touch->interfaceRegion(close) == 38 &&
				gui.touch->interfaceRegion({header.x + 4, header.y + header.h / 2}) == 3,
				"The detached fallback title and close button both own their input");
			return close;
		};
		for (auto [width, height] : {std::pair{400, 320}, {320, 568}, {568, 320}, {844, 390}})
		{
			const int oldW = gfx->getW(), oldH = gfx->getH();
			SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
			GLOB2_REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())), "Window resize must settle before layout assertions");
			SDL_Event resized{};
			resized.type = SDL_EVENT_WINDOW_RESIZED;
			resized.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
			GAGCore::GraphicContext::translateMouseEvent(&resized);
			gui.viewportResized(oldW, oldH, gfx->getW(), gfx->getH());
			openActions(swarm);
			if (width == 400)
			{
				gui.touch->confirmDestroy = true;
				glob2test::drawGUI(gui,0);
				const auto packed = gui.touch->dialChips(gui.touch->dialLayout(gui.touch->layout()));
				require(packed.fits || !gui.touch->usesDial(),
					"Confirmation chips must fit before the dial can be used");
				if (!gui.touch->usesDial()) checkFallbackHeader();
				const auto rows = gui.touch->buildingActions();
				require(std::any_of(rows.begin(), rows.end(), [](const auto &r) { return r.kind == 5; }),
					"The fallback retains the Cancel confirmation action");
				gfx->printScreen("building-confirmation-row-fallback.bmp");
				gfx->nextFrame();
				pressAction(5);
				require(!gui.touch->confirmDestroy && gui.orderQueue.empty(),
					"Cancel stays reachable through the fallback without issuing an order");
				continue;
			}
			if (width == 568)
			{
				const auto oldInsets = GAGCore::mobileSafeInsetsForTesting;
				GAGCore::mobileSafeInsetsForTesting = GAGCore::SafeInsets{24, 20, 24, 20};
				const auto constrained = gui.touch->layout();
				require(!gui.touch->usesDial(), "Short safe viewport falls back to the row inspector");
				const auto fallbackClose = checkFallbackHeader();
				const auto mini = gui.touch->minimapRect();
				require(constrained.panel.y >= mini.y + mini.h &&
					constrained.panel.y + constrained.panel.h <= constrained.actions.y &&
					constrained.panel.x >= constrained.safe.x &&
					constrained.panel.x + constrained.panel.w <= constrained.safe.x + constrained.safe.w,
					"Fallback inspector clears the minimap, toolbar and safe gutters");
				const auto content = gui.touch->panelContent();
				require(content.h > 0 && gui.touch->buildingActionsHeight(content.w / gfx->logicalUnitsPerPoint()) *
					gfx->logicalUnitsPerPoint() > content.h, "Constrained actions use the existing scrollable rows");
				glob2test::drawGUI(gui,0);
				gfx->printScreen("building-header-safe-fallback.bmp");
				gfx->nextFrame();
				tap(fallbackClose.x, fallbackClose.y);
				require(gui.selectionMode == GameGUI::NO_SELECTION && gui.orderQueue.empty(),
					"The compact fallback title close dismisses without an order");
				GAGCore::mobileSafeInsetsForTesting = oldInsets;
				openActions(swarm);
			}
			if (gui.touch->usesDial())
			{
				const auto ui = gui.touch->layout();
				const auto hud = gui.touch->hudLayout(ui);
				const auto identity = gui.touch->allocationRect();
				const auto dialGeometry = gui.touch->dialLayout(ui).geometry;
				require(TouchDial::point(dialGeometry, dialGeometry.rings[0].outer, dialGeometry.sweepEnd).y >=
						hud.minimap.y + hud.minimap.h,
						"The occupied allocation arc clears the inspector minimap bounds");
				auto approx = [](double a, double b) { return std::abs(a - b) < .5; };
				require(approx(identity.x, hud.stats.x) && approx(identity.w, hud.stats.w),
						"Building identity aligns with the rendered stats width");
				require(approx(identity.y, hud.stats.y + hud.stats.h + 4 * gfx->logicalUnitsPerPoint()) &&
						identity.y >= hud.stats.y + hud.stats.h && identity.x + identity.w < hud.minimap.x,
						"Building identity follows the stats without unused vertical space");
				const auto overlaps = [](const auto &a, const auto &b) {
					return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
				};
				for (int stat = 0; stat < 6; ++stat)
				{
					const auto cell = gui.touch->statRect(hud, stat);
					require(!overlaps(cell, identity) && !overlaps(cell, hud.minimap),
						"Stat artwork clears the identity and minimap input regions");
					for (int other = stat + 1; other < 6; ++other)
						require(!overlaps(cell, gui.touch->statRect(hud, other)), "Stat readouts do not overlap");
				}
				const double pointUnit = gfx->logicalUnitsPerPoint();
				const GAGCore::ViewPoint close{identity.x + identity.w - 24 * pointUnit, identity.y + identity.h / 2};
				require(gui.touch->interfaceRegion(close) == 38, "Moved identity close target follows its drawing");
				gfx->printScreen(width < height ? "building-header-portrait.bmp" : width > 600 ? "building-header-wide.bmp" : "building-header-landscape.bmp");
				gfx->nextFrame();
				tap(close.x, close.y);
				require(gui.selectionMode == GameGUI::NO_SELECTION && gui.orderQueue.empty(), "Moved close dismisses without an order");
				openActions(swarm);
				const auto dial = gui.touch->dialLayout(ui);
				const auto inventory = gui.touch->buildingInventory(ui).bounds;
				require(approx(inventory.x, dial.header.x) && approx(inventory.w, dial.header.w) &&
					approx(inventory.y, dial.header.y + dial.header.h),
					"Material inventory aligns directly below the building header");
				if (width > height)
					require(TouchDial::point(dial.geometry, dial.geometry.rings[0].outer, dial.geometry.sweepEnd).y >= inventory.y + inventory.h,
						"The landscape dial clears the header readouts on either thumb side");
				const auto regions = gui.touch->dialRegions();
				require(regions.size() >= 3 + 3 + 3,
						"Swarm dial offers workers, three production buttons and fixed priority");
				for (const auto &region : regions)
				{
					const auto &box = region.box;
					require(box.x >= ui.safe.x - 0.5 && box.x + box.w <= ui.safe.x + ui.safe.w + 0.5 &&
								box.y >= ui.safe.y - 0.5 && box.y + box.h <= ui.actions.y + 0.5,
							("Every dial control lies inside the safe area above the toolbar (kind " +
							 std::to_string(region.action.kind) + " part " + std::to_string(int(region.part)) +
							 " box " + std::to_string(box.x) + "," + std::to_string(box.y) + " " +
							 std::to_string(box.w) + "x" + std::to_string(box.h) + " safe " +
							 std::to_string(ui.safe.x) + "," + std::to_string(ui.safe.y) + " " +
							 std::to_string(ui.safe.w) + "x" + std::to_string(ui.safe.h) + " bar " +
							 std::to_string(ui.actions.y) + ")")
								.c_str());
					const auto g = gui.touch->dialLayout(ui).geometry;
					const auto centre =
						region.ring < 0 ? GAGCore::ViewPoint{box.x + box.w / 2, box.y + box.h / 2}
										: TouchDial::point(g, g.rings[region.ring].middle(), (region.from + region.to) / 2);
					require(gui.touch->interfaceRegion(centre) == 3, "Every dial control answers touch");
				}
				// The Thumb side setting mirrors the dial into the bottom-left corner.
				globalContainer->settings.thumbSide = Settings::THUMB_LEFT;
				glob2test::drawGUI(gui,0);
				const auto mirrored = gui.touch->dialLayout(gui.touch->layout());
				require(approx(mirrored.header.x, identity.x) && approx(mirrored.header.y, identity.y) &&
						approx(mirrored.header.w, identity.w), "Header stays aligned with stats for either thumb side");
				gfx->printScreen(width < height ? "building-header-left-portrait.bmp" : width > 600 ? "building-header-left-wide.bmp" : "building-header-left-landscape.bmp");
				gfx->nextFrame();
				require(mirrored.geometry.mirrored && std::abs(mirrored.geometry.center.x - ui.safe.x) < 0.5,
						"A left thumb mirrors the dial into the bottom-left corner");
				for (const auto &region : gui.touch->dialRegions())
					require(region.box.x >= ui.safe.x - 0.5 && region.box.x + region.box.w <= ui.safe.x + ui.safe.w + 0.5,
							"Mirrored dial controls stay on screen");
				gfx->printScreen(width < height ? "touch-dial-left-portrait.bmp" : "touch-dial-left-landscape.bmp");
				gfx->nextFrame();
				globalContainer->settings.thumbSide = Settings::THUMB_RIGHT;
				glob2test::drawGUI(gui,0);
				const auto priority = gui.touch->dialActionPoint(7, 0, 0);
				for (auto *other : {building, rangeFlag, clearing, exploring})
				{
					openActions(other);
					for (const auto &region : gui.touch->dialRegions())
					{
						if (region.action.kind == 6)
							require(region.ring == 0, "Assigned units stay on the outermost ring");
						if (region.action.kind == 7)
							require(region.ring == 1, "Priority stays immediately inside assigned units");
						if (region.action.kind == 0 || region.action.kind == 8)
							require(region.ring == 2, "Production and flag range use the third ring");
						if (region.action.kind == 2 || region.action.kind == 12 || region.action.kind == 11)
							require(region.ring == 3 && region.part == GameGUITouch::DialRegion::Radio,
								"Flag requirements use radio segments on the fourth ring");
						if (region.action.kind == 1)
							require(region.ring == 4 && region.part == GameGUITouch::DialRegion::Toggle,
								"Clearing materials use toggle segments on the fifth ring");
					}
					const auto p = gui.touch->dialActionPoint(7, 0, 0);
					require(std::hypot(p.x - priority.x, p.y - priority.y) < .01,
							"Priority stays at the same position for every building");
				}
				openActions(swarm);
			}
			else
			{
				const auto content = gui.touch->panelContent();
				const auto inventory = gui.touch->buildingInventory(gui.touch->layout()).bounds;
				require(content.h > 0 && content.y >= inventory.y + inventory.h,
					"Fallback controls use the remaining height below inventory");
				const auto destroy = actionPoint(4, 0);
				const auto action = gui.touch->actionAt(destroy);
				require(action && action->kind == 4,
					"The last fallback action stays reachable by scrolling");
				openActions(swarm);
			}
			gfx->printScreen(width < height ? "touch-swarm-portrait.bmp"
											: "touch-swarm-landscape.bmp");
			const auto checksum = gui.game.checkSum();
			if (gui.touch->usesDial())
			for (int thumbSide : {int(Settings::THUMB_RIGHT), int(Settings::THUMB_LEFT)})
			{
				globalContainer->settings.thumbSide = thumbSide;
				glob2test::drawGUI(gui,0);
				const auto dial = gui.touch->dialLayout(gui.touch->layout());
				const auto close = dial.destroy;
				const GAGCore::ViewPoint center{close.x + close.w / 2, close.y + close.h / 2};
				require(gui.touch->interfaceRegion(center) == 3 &&
					gui.touch->interfaceRegion({close.x + 1, close.y + 1}) == 0 &&
					std::hypot(center.x - dial.geometry.center.x, center.y - dial.geometry.center.y) + close.w / 2 <
						dial.geometry.rings[4].inner * dial.geometry.unit,
					"Circular destroy is reachable inside the hollow dial and its corners remain map");
				const auto targets = gui.touch->keyboardTargets();
				require(std::any_of(targets.begin(), targets.end(), [&](const auto &box) {
					return box.x == close.x && box.y == close.y && box.w == close.w && box.h == close.h;
				}), "Circular destroy participates in keyboard focus");
				tap(center.x, center.y);
				require(gui.selectionMode == GameGUI::BUILDING_SELECTION && gui.touch->confirmDestroy && gui.orderQueue.empty() &&
					gui.game.checkSum() == checksum, "Circular destroy opens confirmation without sending a destruction order");
				const auto confirmation = gui.touch->dialRegions();
				require(confirmation.size() == 2 && std::all_of(confirmation.begin(), confirmation.end(),
					[](const auto &region) { return region.ring == 2 && region.part == GameGUITouch::DialRegion::Segment &&
						(region.action.kind == 4 || region.action.kind == 5); }),
					"Confirmation replaces all dial controls with Cancel and Destroy on the middle ring");
				pressAction(5);
				require(!gui.touch->confirmDestroy && gui.orderQueue.empty(), "Destroy confirmation can be canceled on either thumb side");
				const auto confirmationLayout = gui.touch->layout();
				for (const auto outside : {
					TouchDial::point(dial.geometry, dial.geometry.rings[0].middle(),
						(dial.geometry.sweepStart + dial.geometry.sweepEnd) / 2),
					GAGCore::ViewPoint{confirmationLayout.safe.x + confirmationLayout.safe.w / 2, confirmationLayout.safe.y + 160 * dial.geometry.unit},
					GAGCore::ViewPoint{confirmationLayout.actions.x + confirmationLayout.actions.w / 2, confirmationLayout.actions.y + confirmationLayout.actions.h / 2}})
				{
					pressAction(4);
					tap(outside.x, outside.y);
					require(!gui.touch->confirmDestroy && gui.orderQueue.empty() &&
						gui.selectionMode == GameGUI::BUILDING_SELECTION && gui.game.checkSum() == checksum,
						"Outside confirmation taps restore the controls without activating the map, toolbar or worker arc");
				}
				openActions(swarm);
				gui.pendingFor(swarm->gid).pendingRatio = std::array<int, 3>{0, 0, 0};
				for (int type = 0; type < 3; ++type)
				{
					for (int expected : {1, 2, 3, 5, 0})
					{
						const auto before = gui.displayedRatio(*swarm);
						pressAction(0, type);
						auto after = before;
						after[type] = expected;
						require(gui.orderQueue.size() == 1 && gui.displayedRatio(*swarm) == after,
							"Production button cycles presets and preserves other weights");
						const auto order = std::dynamic_pointer_cast<OrderModifySwarm>(gui.orderQueue.front());
						require(order && order->gid == swarm->gid && order->ratio[type] == expected,
							"Production buttons use the existing swarm order");
						gui.orderQueue.clear();
					}
				}
				gui.pendingFor(swarm->gid).pendingRatio = std::array<int, 3>{4, 8, 16};
				pressAction(0, 0);
				pressAction(0, 1);
				pressAction(0, 2);
				require(gui.orderQueue.size() == 3 && gui.displayedRatio(*swarm) == std::array<int, 3>{5, 0, 0},
					"Legacy weights advance to a preset without changing untouched weights");
				gui.orderQueue.clear();
				gui.pendingFor(swarm->gid).pendingRatio = std::array<int, 3>{5, 0, 2};
				const auto g = gui.touch->dialLayout(gui.touch->layout()).geometry;
				for (const auto &region : gui.touch->dialRegions())
					if (region.part == GameGUITouch::DialRegion::RatioButton)
					{
						require(region.ring == 2, "Swarm ratio buttons occupy the third ring on either thumb side");
						const auto weights = gui.displayedRatio(*swarm);
						const double expected = (g.sweepEnd - g.sweepStart) * (weights[region.action.value] + 1) / 10;
						require(std::abs(region.to - region.from - expected) < .001,
							"Arc button widths use weight plus one, including zero");
					}
				const auto held = gui.touch->dialActionPoint(0, 1, 0);
				finger(SDL_EVENT_FINGER_DOWN, 1, held.x, held.y);
				require(gui.orderQueue.empty() && !gui.touch->allocation, "Production down does not drag or send an order");
				gui.suspendInput();
				finger(SDL_EVENT_FINGER_UP, 1, held.x, held.y);
				require(gui.orderQueue.empty(), "Interrupted production tap sends no order");
				const auto other = gui.touch->dialActionPoint(0, 2, 0);
				finger(SDL_EVENT_FINGER_DOWN, 1, held.x, held.y);
				finger(SDL_EVENT_FINGER_DOWN, 2, other.x, other.y);
				finger(SDL_EVENT_FINGER_UP, 1, held.x, held.y);
				finger(SDL_EVENT_FINGER_UP, 2, other.x, other.y);
				require(gui.orderQueue.empty(), "A second finger cancels the production tap");
				const auto regions = gui.touch->dialRegions();
				require(std::none_of(regions.begin(), regions.end(),
					[](const auto &region) { return region.action.kind == 10; }), "The redundant Pause button is absent");
				pressAction(0, 0);
				for (int i = 0; i < 3; ++i) pressAction(0, 2);
				require(gui.displayedRatio(*swarm) == std::array<int, 3>{0, 0, 0}, "Cycling every ratio to zero stops production");
				gui.orderQueue.clear();
				pressAction(0, 2);
				require(gui.displayedRatio(*swarm) == std::array<int, 3>{0, 0, 1}, "A zero button resumes production");
				gui.orderQueue.clear();
				gui.pendingFor(swarm->gid).pendingRatio = std::array<int, 3>{5, 0, 2};
				glob2test::drawGUI(gui,0);
				gfx->printScreen(thumbSide == Settings::THUMB_LEFT
					? (width < height ? "touch-proportions-left-portrait.bmp" : "touch-proportions-left-landscape.bmp")
					: (width < height ? "touch-proportions-portrait.bmp" : "touch-proportions-landscape.bmp"));
				gfx->nextFrame();
				std::cout << "PASS fixed priority and cycling production buttons " << width << "x" << height << " thumb=" << thumbSide << "\n";
			}
			globalContainer->settings.thumbSide = Settings::THUMB_RIGHT;

			require(gui.game.checkSum() == checksum, "Ratio UI does not mutate the simulation");
			glob2test::drawGUI(gui,0);
			gfx->printScreen(width < height ? "touch-actions-portrait.bmp"
											: "touch-actions-landscape.bmp");
			gfx->nextFrame();
			openActions(clearing);
			for (int resource = 0; resource < BASIC_COUNT; ++resource)
				if (resource != STONE)
				{
					const bool before = gui.displayedClearingResource(*clearing, resource);
					pressAction(1, resource);
					pressAction(1, resource);
					require(gui.orderQueue.size() == 2,
							"Clearing toggles each queue exactly one order");
					for (bool value : {!before, before})
					{
						auto order = std::dynamic_pointer_cast<OrderModifyClearingFlag>(
							gui.orderQueue.front());
						gui.orderQueue.pop_front();
						require(order && order->gid == clearing->gid &&
									order->clearingMaterials[resource] == value,
								"Clearing toggle uses pending state");
					}
				}
			for (auto *flag : {rangeFlag, exploring, clearing})
			{
				openActions(flag);
				const bool explorer = flag == exploring;
				const int count = explorer ? EXPLORATION_FLAG_OPTION_COUNT : NB_UNIT_LEVELS;
				for (int level = 0; level < count; ++level)
				{
					const int previous = explorer ? int(gui.displayedExplorersRequireBombing(*flag))
						: flag == clearing ? gui.displayedMinWorkerLevelToFlag(*flag) : gui.displayedMinLevelToFlag(*flag);
					pressAction(explorer ? 11 : flag == clearing ? 12 : 2, level);
					require(gui.orderQueue.size() == size_t(previous != level),
							"Requirement changes suppress no-ops");
					if (previous != level)
					{
						auto order = std::dynamic_pointer_cast<OrderModifyMinLevelToFlag>(
							gui.orderQueue.front());
						gui.orderQueue.clear();
						require(order && order->gid == flag->gid && order->minLevelToFlag == level &&
									order->targetRole == (explorer ? 1 : flag == clearing ? 2 : 0),
								"Flag requirement preserves its role-specific shared order format");
					}
				}
			}
			openActions(wall);
			require(gui.touch->allocationRect().h ==
						InGameTouchTheme::inspectorHeader * gfx->logicalUnitsPerPoint(),
					"Unified inspector retains its identity header");
			pressAction(4);
			require(gui.orderQueue.empty() && gui.touch->confirmDestroy,
					"Destroy first enters confirmation");
			pressAction(5);
			require(gui.orderQueue.empty() && !gui.touch->confirmDestroy,
					"Destruction can be canceled");
			pressAction(4);
			pressAction(4);
			require(gui.orderQueue.size() == 1 &&
						std::dynamic_pointer_cast<OrderDelete>(gui.orderQueue.front()),
					"Confirmed destruction emits one shared order");
			gui.orderQueue.clear();
			auto p = actionPoint(4, 0);
			finger(SDL_EVENT_FINGER_DOWN, 1, p.x, p.y);
			wall->buildingState = Building::WAITING_FOR_DESTRUCTION;
			finger(SDL_EVENT_FINGER_UP, 1, p.x, p.y);
			require(gui.orderQueue.empty(), "A state transition cancels the held action");
			pressAction(4);
			require(gui.orderQueue.size() == 1 &&
						std::dynamic_pointer_cast<OrderCancelDelete>(gui.orderQueue.front()),
					"Pending destruction can be canceled by touch");
			gui.orderQueue.clear();
			wall->buildingState = Building::ALIVE;
			openActions(building);
			for (bool repair : {true, false})
			{
				building->hp = building->type->hpMax - (repair ? 1 : 0);
				const auto stateBefore = gui.game.checkSum();
                glob2test::drawGUI(gui,0);
                if (gui.touch->usesDial()) {
                    const auto regions = gui.touch->dialRegions();
                    const auto construction = std::find_if(regions.begin(), regions.end(),
                        [](const auto &region) { return region.action.kind == 3; });
                    require(construction != regions.end() &&
                        construction->part == GameGUITouch::DialRegion::Segment && construction->ring == 3,
                        "Repair and upgrade occupy a radial construction lane, never a chip");
                    require(std::count_if(regions.begin(), regions.end(),
                        [](const auto &region) { return region.action.kind == 3; }) == 1,
                        "Construction has exactly one radial target");
                    // Queue before painting; GPU presentation clears its backbuffer.
                    gfx->printScreen((std::string("touch-construction-") + (repair ? "repair-" : "upgrade-") +
                        std::to_string(width) + ".bmp").c_str());
                    glob2test::drawGUI(gui,0);
                    gfx->nextFrame();
                }
				pressAction(3);
				require(gui.orderQueue.size() == 1, "Repair/upgrade starts with exactly one order");
				auto order = std::dynamic_pointer_cast<OrderConstruction>(gui.orderQueue.front());
				require(order && order->gid == building->gid,
						"Repair/upgrade uses shared construction order");
				gui.orderQueue.clear();
				require(gui.game.checkSum() == stateBefore,
						"Construction requests do not mutate simulation");
			}
			// Fortress HP and disabled upgrades must agree between the extracted scene
			// and live action validation, while keeping damaged buildings repairable.
			gui.game.gameHeader.setBuildingHpLevel(1);
			gui.game.gameHeader.setUnitUpgradesDisabled(true);
			building->hp = building->getEffectiveMaxHp();
			openActions(building);
			const auto forbidden = gui.touch->buildingActions();
			require(std::none_of(forbidden.begin(), forbidden.end(), [](const auto& a) {return a.kind==3;}),
				"Healthy fortress buildings offer neither repair nor disabled upgrade");
			building->hp -= 1;
			pressAction(3);
			require(gui.orderQueue.size()==1 && std::dynamic_pointer_cast<OrderConstruction>(gui.orderQueue.front()),
				"Damaged fortress buildings remain repairable with upgrades disabled");
			gui.orderQueue.clear();
			gui.game.gameHeader.setBuildingHpLevel(0);
			gui.game.gameHeader.setUnitUpgradesDisabled(false);
			building->hp = building->type->hpMax - 1;
			auto repairPoint = actionPoint(3, 0);
			finger(SDL_EVENT_FINGER_DOWN, 1, repairPoint.x, repairPoint.y);
			building->hp = building->type->hpMax;
            gui.game.snapshots().invalidateBoundary();
            gui.prepareLocalPresentation();
			finger(SDL_EVENT_FINGER_UP, 1, repairPoint.x, repairPoint.y);
			require(gui.orderQueue.empty(), "Healing must not turn a held Repair into Upgrade");
			for (auto state : {Building::REPAIR, Building::UPGRADE})
			{
				building->constructionResultState = state;
				pressAction(3);
				require(
					gui.orderQueue.size() == 1 &&
						std::dynamic_pointer_cast<OrderCancelConstruction>(gui.orderQueue.front()),
					"Construction cancellation uses shared order");
				gui.orderQueue.clear();
			}
			building->constructionResultState = Building::NO_CONSTRUCTION;
			gui.clearSelection();
			gui.touch->panelOpen = false;
		}
		{
			// Spacious tablets keep the side panel's rows; only compact phones get the dial.
			GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "touch-spacious", 1);
			const int oldW = gfx->getW(), oldH = gfx->getH();
			SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), 1024, 768);
			GLOB2_REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())), "Window resize must settle before layout assertions");
			SDL_Event resized{};
			resized.type = SDL_EVENT_WINDOW_RESIZED;
			resized.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
			GAGCore::GraphicContext::translateMouseEvent(&resized);
			gui.viewportResized(oldW, oldH, gfx->getW(), gfx->getH());
			openActions(swarm);
			require(gui.touch->layout().persistentPanel && !gui.touch->usesDial() &&
						gui.touch->buildingActionRect(0).w > 0,
					"Spacious layouts keep the rectangular inspector");
			const auto checksum = gui.game.checkSum();
			gui.pendingFor(swarm->gid).pendingRatio = std::array<int, 3>{6, 2, 2};
			for (int type = 0; type < NB_UNIT_TYPE; ++type)
			{
				const auto before = gui.displayedRatio(*swarm);
				pressAction(0, type, 1);
				pressAction(0, type, 1);
				require(gui.orderQueue.size() == 2,
						"Rapid production taps queue exactly two orders");
				for (int delta : {1, 2})
				{
					auto order =
						std::dynamic_pointer_cast<OrderModifySwarm>(gui.orderQueue.front());
					gui.orderQueue.pop_front();
					require(order && order->gid == swarm->gid,
							"Production uses the shared order and building");
					for (int i = 0; i < NB_UNIT_TYPE; ++i)
						require(order->ratio[i] == before[i] + (i == type ? delta : 0),
								"Ratio edits preserve other pending values");
				}
				auto values = gui.displayedRatio(*swarm);
				values[type] = MAX_RATIO_RANGE;
				gui.pendingFor(swarm->gid).pendingRatio = values;
				pressAction(0, type, 1);
				require(gui.orderQueue.empty(), "Maximum ratio tap emits no order");
				values[type] = 0;
				gui.pendingFor(swarm->gid).pendingRatio = values;
				pressAction(0, type, -1);
				require(gui.orderQueue.empty(), "Zero ratio tap emits no order");
			}
			require(gui.game.checkSum() == checksum, "Spacious ratio editing only queues orders");
			gui.clearSelection();
			gui.touch->panelOpen = false;
			GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		}

		for (const auto *key : {"[Actions]", "[Info]", "[Minimap]", "[Fast forward]",
								"[Hide keyboard]", "[shutdown save failed]", "[menu]",
								"[Editor tools]", "[Editor map]", "[Pan map]", "[Edit map]"})
			require(!GAGCore::Toolkit::getStringTable()->getString(key).empty(),
					"New interface translations must not be blank");

		auto tr = [](const char *key)
		{ return std::string(GAGCore::Toolkit::getStringTable()->getString(key)); };
		auto pressDialog = [&](const std::string &key)
		{
			auto *dialog = gui.activeDialog();
			require(dialog != nullptr, ("No dialog for action: " + key).c_str());
			glob2test::drawGUI(gui,0);
			gfx->nextFrame();
			dialog->host().scrollIntoView(key);
			glob2test::drawGUI(gui,0);
			gfx->nextFrame();
			const auto r = dialog->host().bounds(key);
			tap(r.x + r.w / 2, r.y + r.h / 2);
		};
		const auto dialogGameHeader = gui.game.gameHeader;
		std::array<Player *, 4> dialogPlayers{};
		for (int i = 1; i < 4; ++i)
		{
			require(gui.game.teams[i], "Teams dialog fixture needs three rival teams");
			dialogPlayers[i] = gui.game.players[i];
			gui.game.players[i] = new Player(i, "Rival colony " + std::to_string(i), gui.game.teams[i], BasePlayer::P_IP);
			gui.game.gameHeader.getBasePlayer(i) = BasePlayer(i, "Rival colony " + std::to_string(i), i, BasePlayer::P_IP);
		}
		gui.game.gameHeader.setNumberOfPlayers(4);
		gui.game.gameHeader.setAllyTeamsFixed(true);
		for (auto [width, height] : {std::pair{320, 568}, {568, 320}, {1024, 768}})
		{
			SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
			GLOB2_REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())), "Window resize must settle before layout assertions");
			SDL_Event resized{};
			resized.type = SDL_EVENT_WINDOW_RESIZED;
			resized.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
			GAGCore::GraphicContext::translateMouseEvent(&resized);
			gui.viewportResized(800, 600, gfx->getW(), gfx->getH());
			gui.openMainMenu();
			pressDialog("options");
			require(gui.inGameMenu == GameGUI::IGM_OPTION, "Phone menu opens options");
			pressDialog("text-size/2");
			require(globalContainer->settings.textSizePercent == 150 && GAGCore::userTextScale == 1.5,
					"Text size applies from the options dialog");
			pressDialog("text-size/0");
			require(globalContainer->settings.textSizePercent == 100 && GAGCore::userTextScale == 1,
					"Text size restores");
			const bool muted = globalContainer->settings.mute;
			pressDialog("mute");
			require(globalContainer->settings.mute != muted, "Mute toggles from the options dialog");
			pressDialog("mute");
			pressDialog("ok");
			require(!gui.inGameMenu, "Options footer remains reachable");
			gui.openDialog(GameGUI::IGM_OBJECTIVES, std::make_unique<InGameObjectivesScreen>(&gui, false));
			auto checkModal = [&](const char *name) {
				glob2test::drawGUI(gui,0);
				auto *dialog = gui.activeDialog();
				const auto panel = dialog->panelBounds();
				const auto &p = dialog->presentation();
				const auto area = p.dialog;
				const int margin = p.pt(16);
				require(panel.x >= area.x + margin && panel.y >= area.y + margin &&
					panel.right() <= area.right() - margin && panel.bottom() <= area.bottom() - margin,
					"Gameplay modals leave a 16-point outer gutter on every side");
				std::cout << "Modal " << name << " screen=" << width << "x" << height
					<< " panel=" << panel.x << "," << panel.y << "," << panel.w << "," << panel.h << "\n";
				gfx->printScreen((std::string("inset-") + name + "-" + std::to_string(width) + "x" + std::to_string(height) + ".bmp").c_str());
				gfx->nextFrame();
			};
			checkModal("objectives");
			auto *objectives = static_cast<InGameObjectivesScreen *>(gui.gameMenuScreen.get());
			const int hintsTab = gui.game.missionBriefing.empty() ? 1 : 2;
			pressDialog("objectives/tab/" + std::to_string(hintsTab));
			require(objectives->tab() == InGameObjectivesScreen::HINTS, "Objectives tabs switch by touch");
			checkModal("hints");
			require(objectives->panelBounds().h < objectives->presentation().dialog.h * .8,
				"A short hints page sizes to its content");
			pressDialog("ok");
			require(!gui.inGameMenu, "Objectives tabs and footer work by touch");
			gui.openDialog(GameGUI::IGM_ALLIANCE, std::make_unique<InGameAllianceScreen>(&gui));
			checkModal("teams");
			pressDialog("ok");
			require(!gui.inGameMenu, "Teams footer remains reachable inside the margins");
			const auto savedHints = gui.game.gameHints;
			for (int i = 0; i < 24; ++i)
				gui.game.gameHints.addNewHint("A long mission hint with enough detail to wrap across multiple lines on a phone.", false, 1);
			gui.game.snapshots().invalidateBoundary();
            gui.prepareLocalPresentation();
            GAGCore::userTextScale = 1.5;
			gui.openDialog(GameGUI::IGM_OBJECTIVES, std::make_unique<InGameObjectivesScreen>(&gui, false));
			static_cast<InGameObjectivesScreen *>(gui.gameMenuScreen.get())->showTab(InGameObjectivesScreen::HINTS);
			checkModal("long-hints-large-text");
			require(gui.activeDialog()->host().find("objectives/scroll")->scrollMaximum() > 0,
				"Long hints scroll within the inset dialog");
			pressDialog("ok");
			gui.game.gameHints = savedHints;
            gui.game.snapshots().invalidateBoundary();
            gui.prepareLocalPresentation();
			gui.openDialog(GameGUI::IGM_ALLIANCE, std::make_unique<InGameAllianceScreen>(&gui));
			checkModal("teams-large-text");
			auto *teams = static_cast<InGameAllianceScreen *>(gui.gameMenuScreen.get());
			const auto chatBefore = teams->getChatMask();
			pressDialog("ally/3/C");
			require(teams->getChatMask() == (chatBefore ^ (1u << 3)), "The last rival remains reachable by scrolling at large text size");
			pressDialog("ally/3/C");
			pressDialog("ok");
			GAGCore::userTextScale = 1;
			if (width == 568)
			{
				GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
				gui.openDialog(GameGUI::IGM_ALLIANCE, std::make_unique<InGameAllianceScreen>(&gui));
				checkModal("desktop-short-teams");
				require(gui.activeDialog()->host().find("ally/scroll")->scrollMaximum() > 0,
					"Short classic Teams dialogs scroll their table and legend");
				pressDialog("ok");
				require(!gui.inGameMenu, "Short classic Teams keeps its footer reachable");
				GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
			}
			if (width == 1024)
			{
				GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
				gui.openDialog(GameGUI::IGM_OBJECTIVES, std::make_unique<InGameObjectivesScreen>(&gui, false));
				checkModal("desktop-objectives");
				require(gui.activeDialog()->panelBounds().h < gui.activeDialog()->presentation().dialog.h / 2,
					"Short desktop objectives also size to their content");
				pressDialog("ok");
				gui.openDialog(GameGUI::IGM_ALLIANCE, std::make_unique<InGameAllianceScreen>(&gui));
				checkModal("desktop-teams");
				pressDialog("ok");
				GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
			}

			gui.openDialog(GameGUI::IGM_SAVE,
						   std::make_unique<LoadSaveDialog>("games", "game", false, tr("[save game]"), "Phone",
															glob2FilenameToName, glob2NameToFilename));
			pressDialog("name");
			SDL_Event text{};
			text.type = SDL_EVENT_TEXT_INPUT;
			text.text.text = "2";
			gui.processEvent(&text);
			require(std::string(static_cast<LoadSaveDialog *>(gui.gameMenuScreen.get())->getName()) == "Phone2",
					"Save filename edits through the dialog");
			pressDialog("cancel");
			require(!gui.inGameMenu, "Save cancellation is always reachable");
			{
				// A networked (online) match: no Load or Save, and leaving asks first.
				const auto saved = gui.networkMatch;
				gui.networkMatch = {true, true, true, false};
				gui.orderQueue.clear();
				gui.openMainMenu();
				glob2test::drawGUI(gui,0);
				gfx->nextFrame();
				require(!gui.gameMenuScreen->host().find("load") && !gui.gameMenuScreen->host().find("save"),
						"An online match offers neither Load nor Save");
				pressDialog("quit");
				require(gui.inGameMenu == GameGUI::IGM_CONFIRM_LEAVE && gui.orderQueue.empty() && !gui.flushOutgoingAndExit,
						"Leaving an online match asks first and sends nothing yet");
				gfx->printScreen("leave-confirm-" + std::to_string(width) + ".bmp");
				pressDialog("cancel");
				require(gui.inGameMenu == GameGUI::IGM_MAIN && gui.orderQueue.empty(),
						"Keep playing returns to the menu without leaving");
				pressDialog("quit");
				pressDialog("confirm");
				require(!gui.inGameMenu && gui.flushOutgoingAndExit && gui.orderQueue.size() == 1 &&
							gui.orderQueue.front()->getOrderType() == ORDER_PLAYER_QUIT_GAME,
						"Confirming leaves with the player's quit order");
				gui.flushOutgoingAndExit = false;
				gui.orderQueue.clear();
				gui.networkMatch = saved;
			}
			gui.touch->menuAction(1);
			require(bool(gui.typingInputScreen), "Tactical chat action opens the composer");
			glob2test::drawGUI(gui,0);
			gfx->nextFrame();
			for (const auto &key : {"send", "close"})
			{
				const auto r = gui.typingInputScreen->host().bounds(key);
				require(r.w >= 48 * gfx->logicalUnitsPerPoint() &&
							r.h >= 48 * gfx->logicalUnitsPerPoint(),
						"Chat icons retain 48-point tap targets");
				require(!gui.typingInputScreen->host().find(key)->accessibleText().empty(),
						"Chat icons retain translated names");
			}
			gfx->printScreen("chat-icons-" + std::to_string(width) + ".bmp");
			SDL_Event composition{};
			composition.type = SDL_EVENT_TEXT_EDITING;
			composition.edit.text = "provisional";
			gui.processEvent(&composition);
			SDL_Event enter{};
			enter.type = SDL_EVENT_KEY_DOWN;
			enter.key.key = SDLK_RETURN;
			gui.orderQueue.clear();
			gui.processEvent(&enter);
			require(gui.typingInputScreen && gui.typingInputScreen->getText().empty() &&
						gui.orderQueue.empty(),
					"IME candidate confirmation must not send chat or mutate the committed draft");
			text = {};
			text.type = SDL_EVENT_TEXT_INPUT;
			text.text.text = "Hello";
			gui.processEvent(&text);
			gui.orderQueue.clear();
			pressDialog("send");
			require(!gui.typingInputScreen && gui.orderQueue.size() == 1 &&
						std::dynamic_pointer_cast<MessageOrder>(gui.orderQueue.front()),
					"Chat sends once through shared orders");
			gui.orderQueue.clear();
			gui.touch->menuAction(1);
			gui.processEvent(&text);
			pressDialog("close");
			require(!gui.typingInputScreen && gui.orderQueue.empty(),
					"Closing the chat draft sends no message");
		}

		for (int i = 1; i < 4; ++i)
		{
			delete gui.game.players[i];
			gui.game.players[i] = dialogPlayers[i];
		}
		gui.game.gameHeader = dialogGameHeader;

		{
			GAGGUI::ScreenStack stack(*gfx);
			auto results = std::make_unique<EndGameScreen>(&gui);
			auto *view = results.get();
			stack.push(std::move(results));
			stack.frame(SDL_GetTicks(), {});
			require(!view->host().interactiveNodes().empty(), "Results exposes the shared chart controls");
			SDL_Event key{};
			key.type = SDL_EVENT_KEY_DOWN;
			if (view->host().find("group"))
			{
				// Narrow layouts pick a group, then a metric of that group.
				view->activateResultControl(100);
				require(view->metricPickerOpen(), "Metric selector opens an explicit dropdown");
				key.key.key = SDLK_END;
				view->handleExecutionEvent(key);
				key.key.key = SDLK_RETURN;
				view->handleExecutionEvent(key);
				require(view->selectedMetric >= 0 && view->metric()->group == Stats::Group::Score && !view->metricPickerOpen(),
						"Every group of metrics is selectable from the picker");
				view->activateResultControl(103);
				require(view->metricPickerOpen(), "The metrics of the group open in their own list");
				key.key.key = SDLK_ESCAPE;
				view->handleExecutionEvent(key);
				stack.frame(SDL_GetTicks(), {});
			}
			else
			{
				// Wide layouts list every metric beside the chart.
				auto *row = view->host().find("metric/1");
				require(row, "Results lists the metrics beside the chart");
				view->host().tapAt({row->bounds.x + row->bounds.w / 2, row->bounds.y + row->bounds.h / 2});
				require(view->selectedMetric == 1 && !view->metricPickerOpen(), "A listed metric is selected directly");
			}
			if (!view->teams.empty())
			{
				const int team = view->teams.front().teamNum;
				view->activateResultControl(200);
				view->selectMetric(1);
				for (size_t i = 0; i < view->teams.size(); ++i)
					if (view->teams[i].teamNum == team)
						require(!view->teams[i].enabled,
								"Metric changes preserve team filtering across sorting");
			}
			view->activateResultControl(101);
			require(view->expandedChart, "Chart expansion is available");
			stack.frame(SDL_GetTicks(), {});
			// Enter confirms a metric while its picker is open (checked above),
			// but retains the desktop finish shortcut on the results screen itself.
			key.key.key = SDLK_RETURN;
			view->handleExecutionEvent(key);
			require(!view->isExecutionRunning(), "Enter closes results after chart interaction");
			stack.frame(SDL_GetTicks(), {});
		}

		// Labels may change length and word order; action IDs and queued orders must not.
		auto *strings = GAGCore::Toolkit::getStringTable();
		const int originalLanguage = strings->getLang();
		gui.setSelection(GameGUI::BUILDING_SELECTION, building);
		gui.touch->panelOpen = true;
		glob2test::drawGUI(gui,0); // building actions describe the drawn scene
		const auto originalActions = gui.touch->buildingActions();
		const auto originalOrders = gui.orderQueue.size();
		const auto originalChecksum = gui.game.checkSum();
		for (const char *language : {"de", "ja"})
		{
			strings->setLang(strings->getLangCode(language));
			for (auto [width, height] : {std::pair{320, 568}, {568, 320}})
			{
				const int oldWidth = gfx->getW(), oldHeight = gfx->getH();
				SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
				GLOB2_REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())), "Window resize must settle before layout assertions");
				SDL_Event resize{};
				resize.type = SDL_EVENT_WINDOW_RESIZED;
				resize.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
				GAGCore::GraphicContext::translateMouseEvent(&resize);
				gui.viewportResized(oldWidth, oldHeight, gfx->getW(), gfx->getH());
				glob2test::drawGUI(gui,0);
				const auto actions = gui.touch->buildingActions();
				require(actions.size() == originalActions.size(),
						"Localization changed building actions");
				for (size_t i = 0; i < actions.size(); ++i)
					require(actions[i].kind == originalActions[i].kind &&
								actions[i].value == originalActions[i].value,
							"Localization changed building action dispatch");
				const std::string suffix = std::string(language) + "-" + std::to_string(width);
				gfx->printScreen(("localized-inspector-" + suffix + ".bmp").c_str());
				gfx->nextFrame();
				gui.clearSelection();
				gui.touch->showStatistics = true;
				gui.displayMode = GameGUI::STAT_TEXT_VIEW;
				gui.touch->panelOpen = true;
				glob2test::drawGUI(gui,0);
				gfx->printScreen(("localized-statistics-" + suffix + ".bmp").c_str());
				gfx->nextFrame();
				gui.touch->showStatistics = false;
				gui.setSelection(GameGUI::BUILDING_SELECTION, building);
				editorInteractions();
				editorFileInteractions();
				editorAreaNameInteractions();
				ScriptEditorScreen script(&gui.game);
				script.attach(*gfx);
				gfx->drawFilledRect(0, 0, gfx->getW(), gfx->getH(), GAGCore::Color(0, 0, 0));
				script.draw(0);
				gfx->printScreen(("localized-keyboard-" + suffix + ".bmp").c_str());
				gfx->nextFrame();
				GAGGUI::ScreenStack resultsStack(*gfx);
				auto results = std::make_unique<EndGameScreen>(&gui);
				auto *resultsView = results.get();
				resultsStack.push(std::move(results));
				gfx->printScreen("localized-results-" + suffix + ".bmp");
				resultsStack.frame(SDL_GetTicks(), {});
				resultsView->selectMetric(0);
				resultsView->activateResultControl(101);
				require(resultsView->expandedChart, "Localized results retain chart expansion");
				gfx->printScreen("localized-chart-" + suffix + ".bmp");
				resultsStack.frame(SDL_GetTicks(), {});
			}
		}
		strings->setLang(originalLanguage);
		require(gui.orderQueue.size() == originalOrders && gui.game.checkSum() == originalChecksum,
				"Localized presentation mutated game state or queued commands");
		gui.clearSelection();
		std::puts("PASS localized German/Japanese inspectors and editor interactions in both phone "
				  "orientations");

		globalContainer->replayReader = std::make_unique<ReplayReader>();
		require(globalContainer->replayReader->loadReplay("replays/touch-preview.replay"),
				"Replay reader loads");
		globalContainer->replaying = true;
		globalContainer->replayVisibleTeams = 0xffffffff;
		auto replayMap = Engine::loadMapHeader("replays/touch-preview.replay");
		require(gui.loadFromHeaders(replayMap, players, true, true, false,
									"replays/touch-preview.replay"),
				"Replay world loads");
		gui.localTeamNo = 0;
		gui.localPlayer = 0;
		gui.adjustLocalTeam();
		for (auto [width, height] : {std::pair{320, 568}, {568, 320}})
		{
			SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
			GLOB2_REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())), "Window resize must settle before layout assertions");
			SDL_Event resized{};
			resized.type = SDL_EVENT_WINDOW_RESIZED;
			resized.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
			GAGCore::GraphicContext::translateMouseEvent(&resized);
			gui.viewportResized(800, 600, gfx->getW(), gfx->getH());
			glob2test::drawGUI(gui,0);
			gfx->nextFrame();
			const auto before = gui.game.checkSum();
			const double unit = gfx->logicalUnitsPerPoint(), y = gfx->getH() - 24 * unit;
			gui.gamePaused = false;
			globalContainer->replayFastForward = false;
			gui.orderQueue.clear();
			tap(gfx->getW() / 12.0, y);
			require(gui.gamePaused, "Replay toolbar pauses");
			tap(gfx->getW() / 4.0, y);
			require(!gui.gamePaused && globalContainer->replayFastForward,
					"Replay speed resumes fast playback");
			tap(gfx->getW() / 4.0, y);
			require(!globalContainer->replayFastForward, "Replay speed returns to normal");
			gui.touch->menuAction(30);
			require(globalContainer->replayFastForward,
					"Replay menu speed uses shared playback state");
			require(gui.orderQueue.empty() && !gui.toolManager.getOrder() &&
						gui.game.checkSum() == before,
					"Replay controls issue no simulation orders");
			if (gui.inGameMenu)
				gui.closeDialog();
		}
		globalContainer->replaying = false;
		globalContainer->replayReader.reset();
		{
			// Executed for real, a stroke and then its undo leave the authoritative
			// zones exactly as they were, including cells forbidden beforehand.
			gui.clearSelection();
			gui.setSelection(GameGUI::BRUSH_SELECTION);
			gui.toolManager.activateZoneTool(GameGUIToolManager::Forbidden);
			gui.brush.defaultSelection();
			gui.brush.setFigure(7); // 5x5
			auto &map = gui.game.map;
			const int cx = 40, cy = 40;
			for (int dy = -2; dy <= 2; ++dy)
			{
				map.addForbidden(cx - 2, cy + dy, gui.localTeamNo);

			}
			gui.prepareLocalPresentation();
			auto forbidden = [&]
			{
				std::vector<bool> v;
				for (int dy = -4; dy <= 4; ++dy)
					for (int dx = -4; dx <= 4; ++dx)
						v.push_back(map.isForbidden(cx + dx, cy + dy, gui.localTeam->me));
				return v;
			};
			const auto before = forbidden();
			TouchStrokeSession stroke;
			stroke.points = {{cx * 32.0 + 16, cy * 32.0 + 16}};
			stroke.team = gui.localTeamNo;
			stroke.zone = GameGUIToolManager::Forbidden;
			stroke.figure = 7;
			stroke.mode = BrushTool::MODE_ADD;
			gui.touch->replayStroke(stroke);
			std::vector<std::shared_ptr<Order>> forward;
			while (auto order = gui.toolManager.getOrder())
				forward.push_back(order);
			require(!forward.empty() && gui.touch->zoneUndo, "Stroke fixture emits orders and offers Undo");
			const auto inverse = gui.touch->zoneUndo->orders;
			auto execute = [&](const std::vector<std::shared_ptr<Order>> &orders)
			{
				for (const auto &order : orders)
				{
					order->sender = gui.localPlayer;
					gui.game.executeOrder(order, gui.localPlayer);
				}
			};
			execute(forward);
			bool painted = true;
			for (int dy = -2; dy <= 2; ++dy)
				for (int dx = -2; dx <= 2; ++dx)
					painted = painted && map.isForbidden(cx + dx, cy + dy, gui.localTeam->me);
			require(painted, "The executed stroke forbids its whole footprint");
			execute(inverse);
			require(forbidden() == before, "The executed undo restores the zones that existed before the stroke");
			gui.touch->zoneUndo.reset();
			gui.clearSelection();
		}
		editorInteractions();
		editorFileInteractions();
		editorAreaNameInteractions();
	}

	// Touch scroll physics in a match: the map coasts after a flick and wraps
	// across the seam, a touch or suspendInput stops it, the phone build palette
	// coasts and rubber-bands, a mouse drag has no momentum, and nothing reaches
	// the simulation. Time is explicit: event timestamps and gui.step(now).
	// Flags move by dragging them on touch. A contact on a flag, or within the
	// 30-point reach that selects flags, carries the flag and never pans the map;
	// a tap still selects; a second finger or an interruption puts the flag back.
	static void unitSelection()
	{
		GameGUI gui;
		auto header = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Touch", 0, BasePlayer::P_LOCAL);
		require(gui.loadFromHeaders(header, players, true, true), "Unit fixture loads");
		gui.localTeamNo = gui.localPlayer = 0;
		gui.adjustLocalTeam();
		auto *gfx = globalContainer->gfx;
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		gfx->setResponsiveViewport(true, 800, 600);
		auto &map = gui.game.map;
		for (int y = 30; y < 50; ++y)
			for (int x = 30; x < 50; ++x) {
				map.setVertexTerrain(x,y,GRASS);
				map.setNoResource(x,y,1);
			}
		auto *worker = gui.game.addUnit(40,40,0,WORKER,0,255,0,0);
		require(worker, "Isolated worker exists");
        gui.prepareLocalPresentation();
		globalContainer->replaying = true;
		globalContainer->replayShowFog = false;
		Uint32 now = 40000;
		auto finger = [&](Uint32 type, double x, double y) {
			SDL_Event e{}; e.type = type; e.tfinger.timestamp = SDL_MS_TO_NS(now += 400);
			e.tfinger.touchID = 7; e.tfinger.fingerID = 1;
			e.tfinger.x = x/gfx->getW(); e.tfinger.y = y/gfx->getH(); gui.processEvent(&e);
		};
		auto tap = [&](double x,double y) {finger(SDL_EVENT_FINGER_DOWN,x,y); finger(SDL_EVENT_FINGER_UP,x,y);};
		for (auto [width,height] : {std::pair{390,844},std::pair{844,390}}) {
			SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()),width,height);
			require(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())), "Unit fixture resize settles");
			SDL_Event resize{}; resize.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
			GAGCore::GraphicContext::translateMouseEvent(&resize);
			gui.viewportResized(800,600,gfx->getW(),gfx->getH());
			for (double zoom : {.33,.5,1.}) {
				gui.clearSelection(); gui.touch->cancel(); gui.touch->panelOpen = false;
				gui.camera.zoom = zoom;
				gui.updateCamera();
				gui.camera.originX = 40*32+16-gfx->getW()/2./gui.camera.zoom;
				gui.camera.originY = 40*32+16-(gfx->getH()/2.)/gui.camera.zoom;
				gui.viewportX = gui.camera.tileX(); gui.viewportY = gui.camera.tileY(); gui.updateCamera();
				const auto c = std::pair{gfx->getW()/2.,gfx->getH()/2.};
				const double scale = gfx->logicalUnitsPerPoint();
				require(gui.touch->unitAt({c.first+28*scale,c.second}).empty(), "Near tap misses exact sprite");
				require(gui.touch->unitAt({c.first+28*scale,c.second},30) == Game::refOf(worker), "30 point halo works at every zoom");
				require(gui.touch->unitAt({c.first+32*scale,c.second},30).empty(), "Outside unit halo stays empty");
				globalContainer->replayShowFog = true; globalContainer->replayVisibleTeams = 0;
				require(gui.touch->unitAt({c.first,c.second},30).empty(), "Fog-hidden unit cannot be picked");
				globalContainer->replayShowFog = false;
				tap(c.first+28*scale,c.second);
				require(gui.selectionMode == GameGUI::UNIT_SELECTION && gui.selectionUnit() == worker, "Real near-unit touch selects unit");
				glob2test::drawGUI(gui,0);
				require(gui.drawnScene().panels.unit.valid && gui.touch->unitInfoRows().size() >= 7, "Selected unit has scene-backed stats");
				const auto ui = gui.touch->layout();
				const auto identity = gui.touch->allocationRect();
				const auto hud = gui.touch->hudLayout(ui);
				auto nearlyEqual = [](double a, double b) { return std::abs(a - b) < .5; };
				require(nearlyEqual(identity.x, hud.stats.x) && nearlyEqual(identity.w, hud.stats.w) &&
					nearlyEqual(identity.y, hud.stats.y + hud.stats.h + 4 * gfx->logicalUnitsPerPoint()) &&
					identity.y >= hud.stats.y + hud.stats.h && ui.panel.y >= identity.y + identity.h,
					"Unit identity shares the selection header and stays separate from statistics");
				const auto values = gui.touch->unitInfoRows();
				require(values.front().second == "200 / 200" && values.back().second.find("8") != std::string::npos,
					"Structured stats preserve health and ability values");
				tap(identity.x + 8 * scale, identity.y + identity.h / 2);
				require(gui.selectionUnit() == worker, "Unit header consumes taps without changing selection");
				if (zoom == .5) { gfx->printScreen(width<height ? "unit-portrait.bmp" : "unit-landscape.bmp"); gfx->nextFrame(); }
				const auto panel = gui.touch->layout().panel;
				tap(panel.x+panel.w/2,panel.y+70*scale);
				require(gui.selectionMode == GameGUI::UNIT_SELECTION && !gui.touch->showStatistics, "Stats body does not dispatch tactical menu actions");
				finger(SDL_EVENT_FINGER_DOWN,panel.x+panel.w/2,panel.y+panel.h-10*scale);
				finger(SDL_EVENT_FINGER_MOTION,panel.x+panel.w/2,panel.y+55*scale);
				finger(SDL_EVENT_FINGER_UP,panel.x+panel.w/2,panel.y+55*scale);
				glob2test::drawGUI(gui,0);
				if (zoom == .5) { gfx->printScreen(width<height ? "unit-portrait-scrolled.bmp" : "unit-landscape-scrolled.bmp"); gfx->nextFrame(); }
				const auto close = gui.touch->readOnlyCloseRect();
				tap(close.x + close.w / 2, close.y + close.h / 2);
				require(gui.selectionMode == GameGUI::NO_SELECTION && !gui.touch->panelOpen, "Close dismisses unit stats");
				const auto origin = gui.camera.originX;
				finger(SDL_EVENT_FINGER_DOWN,c.first+28*scale,c.second);
				finger(SDL_EVENT_FINGER_MOTION,c.first+70*scale,c.second);
				finger(SDL_EVENT_FINGER_UP,c.first+70*scale,c.second);
				require(gui.selectionMode == GameGUI::NO_SELECTION && gui.camera.originX != origin, "Near-unit drag pans instead of selecting");
				gui.touch->stopScrolling();
				require(gui.orderQueue.empty(), "Inspection never issues simulation orders");
			}
		}
		// The presented snapshot can differ from the live unit between ticks.
		// Smooth motion must shift both the exact rectangle and forgiving halo.
		gui.camera.zoom = 1;
		gui.camera.originX = 40 * 32 + 16 - gfx->getW() / 2.;
		gui.camera.originY = 40 * 32 + 16 - gfx->getH() / 2.;
		gui.viewportX = gui.camera.tileX(); gui.viewportY = gui.camera.tileY(); gui.updateCamera();
		glob2test::drawGUI(gui,0);
		{
            PresentationFrame displayed=gui.drawnScene();
            auto mutableEntities=std::make_shared<SimulationSnapshot::Entities>(*displayed.world.entities);
            auto shown=std::find_if(mutableEntities->units.begin(),mutableEntities->units.end(),
                [&](const auto& u){return u.gid==worker->gid;});
            require(shown!=mutableEntities->units.end(),"Motion fixture has a drawn worker");
            shown->action=WALK;shown->dx=1;shown->dy=0;shown->delta=0;shown->speed=128;
            displayed.world.entities=mutableEntities;
            SceneExtractor().prepare(displayed.world,gui.sceneRequest(),displayed);
			const auto *previousScene = gui.view.scene;
			const float previousMotion = gui.view.render.unitMotion;
			gui.view.scene = &displayed;
			gui.view.render.unitMotion = 1;
			const double reachUnit = gfx->logicalUnitsPerPoint();
			const GAGCore::ViewPoint visibleCenter{gfx->getW() / 2. - 15, gfx->getH() / 2.};
			require(gui.touch->unitAt({visibleCenter.x - 14, visibleCenter.y}) == Game::refOf(worker),
				"Exact touch follows the last rendered smooth-motion rectangle");
			require(gui.touch->unitAt({visibleCenter.x - 28 * reachUnit, visibleCenter.y}, 30) == Game::refOf(worker),
				"Unit halo follows the last rendered smooth-motion centre");
			require(gui.touch->unitAt({visibleCenter.x - 32 * reachUnit, visibleCenter.y}, 30).empty(),
				"Smooth motion does not enlarge the 30-point halo");
			++shown->scriptIdentity;
            shown->identity.generation=shown->scriptIdentity;
			require(gui.touch->unitAt(visibleCenter,30)==shown->identity,
                "Selection resolves the displayed identity; command admission validates it on the owner");
			gui.view.scene = previousScene;
			gui.view.render.unitMotion = previousMotion;
		}
		// A crowded tile uses visual draw order, and a nearby exact hit beats a halo.
		auto *flyer = gui.game.addUnit(40,40,0,EXPLORER,0,255,0,0);
		require(flyer, "Flying unit overlaps the worker");
		gui.camera.zoom = 1;
		gui.camera.originX = 40*32+16-gfx->getW()/2.;
		gui.camera.originY = 40*32+16-gfx->getH()/2.;
		gui.viewportX = gui.camera.tileX(); gui.viewportY = gui.camera.tileY(); gui.updateCamera();
		const GAGCore::ViewPoint center{gfx->getW()/2.,gfx->getH()/2.};
		glob2test::drawGUI(gui,0); // Newly created units must be presented before they can be picked.
		require(gui.touch->unitAt(center,30) == Game::refOf(flyer), "Direct airborne sprite wins draw order over ground unit");
		auto *nearby = gui.game.addUnit(42,40,0,WORKER,0,255,0,0);
		require(nearby, "Nearby worker exists");
		glob2test::drawGUI(gui,0);
		require(gui.touch->unitAt({center.x+64,center.y},30) == Game::refOf(nearby), "Exact unit beats neighbouring halo");
		// A neighbouring resource is a direct target, not empty halo ground.
		map.setResourceByIndex(41, 40, WHEAT, 0);
		map.setMapDiscovered(41, 40, gui.localTeam->me);
        gui.prepareLocalPresentation();
		gui.touch->select({center.x + 28, center.y});
		require(gui.selectionMode == GameGUI::RESOURCE_SELECTION,
			"A unit halo cannot steal a direct discovered-resource tap");
		glob2test::drawGUI(gui,0);
		// Replacing a read-only card with a building is not navigation back to
		// a toolbox. Its explicit close must leave the map unobstructed too.
		const int innType = gui.game.buildingsTypes.getTypeNum("inn", 0, false);
		auto *inspected = gui.game.addBuilding(44, 40, innType, 0);
		require(inspected, "Read-only transition fixture has a building");
		const auto buildingPoint = gui.camera.worldToScreen(
			(inspected->posX + inspected->type->width / 2.) * 32,
			(inspected->posY + inspected->type->height / 2.) * 32);
		for (bool resource : {false, true})
		{
			gui.touch->select({center.x + (resource ? 28 : 0), center.y});
			glob2test::drawGUI(gui,0);
			require(gui.touch->inspectingReadOnly() && gui.touch->panelOpen,
				"Transition starts with an open read-only inspector");
			gui.touch->select({buildingPoint.first, buildingPoint.second});
			glob2test::drawGUI(gui,0);
			require(gui.selectionMode == GameGUI::BUILDING_SELECTION && gui.selectionBuilding() == inspected,
				"Building selection replaces the read-only inspector");
			const auto title = gui.touch->allocationRect();
			const double target = 48 * gfx->logicalUnitsPerPoint();
			tap(title.x + title.w - target / 2, title.y + title.h / 2);
			glob2test::drawGUI(gui,0); // Include deferred palette restoration.
			require(gui.selectionMode == GameGUI::NO_SELECTION && !gui.touch->panelOpen &&
				!gui.touch->restorePalette && !gui.touch->lensVisible(),
				"Closing a building reached from a read-only inspector cannot reopen a toolbox");
			require(gui.orderQueue.empty(), "Inspector transitions never issue simulation orders");
		}
		// Explicit navigation takes precedence over both deferred building
		// restoration and invalidation by a client step before the next draw.
		globalContainer->replaying = false;
		for (bool invalidated : {false, true})
			for (int button = 0; button < 3; ++button)
			{
				gui.touch->dismissMapPanels();
				if (invalidated)
				{
					map.setResourceByIndex(41, 40, WHEAT, 0);
                    gui.prepareLocalPresentation();
					gui.touch->select({center.x + 28, center.y});
					glob2test::drawGUI(gui,0);
					map.setNoResource(41, 40, 1);
                    gui.prepareLocalPresentation();
					gui.checkSelection();
					require(gui.touch->readOnlyPanelShown && gui.selectionMode == GameGUI::NO_SELECTION,
						"Client invalidation precedes toolbar navigation");
				}
				else
				{
					gui.setSelection(GameGUI::BUILDING_SELECTION, inspected);
					gui.touch->panelOpen = gui.touch->restorePalette = true;
					gui.touch->previousPanelOpen = false;
					gui.touch->previousDisplayMode = GameGUI::STAT_TEXT_VIEW;
					glob2test::drawGUI(gui,0);
				}
				const auto bar = gui.touch->layout().actions;
				tap(bar.x + bar.w * (button + .5) / 6, bar.y + bar.h / 2);
				glob2test::drawGUI(gui,0);
				require(gui.selectionMode == GameGUI::NO_SELECTION && !gui.touch->restorePalette &&
					!gui.touch->readOnlyPanelShown, "Navigation consumes inspector lifecycle state");
				require(button == 2 ? gui.touch->lensVisible() :
					gui.touch->panelOpen && gui.displayMode ==
						(button == 0 ? GameGUI::CONSTRUCTION_VIEW : GameGUI::FLAG_VIEW),
					"Chosen toolbox survives the next draw after inspector navigation");
			}
		gui.touch->dismissMapPanels();
		globalContainer->replaying = true;
		map.setResourceByIndex(41, 40, WHEAT, 0);
		for (int inspector = 0; inspector < 3; ++inspector)
		{
			gui.touch->dismissMapPanels();
			if (inspector == 0)
			{
				gui.setSelection(GameGUI::BUILDING_SELECTION, inspected);
				gui.touch->restorePalette = true;
				gui.touch->previousPanelOpen = false;
				gui.touch->previousDisplayMode = GameGUI::CONSTRUCTION_VIEW;
			}
			else if (inspector == 1)
				gui.setSelection(GameGUI::UNIT_SELECTION, worker);
			else
				gui.setSelection(GameGUI::RESOURCE_SELECTION, unsigned(map.coordToIndex(41, 40)));
			gui.touch->panelOpen = true;
			glob2test::drawGUI(gui,0);
			const auto bar = gui.touch->layout().actions;
			tap(bar.x + bar.w * 4.5 / 6, bar.y + bar.h / 2);
			glob2test::drawGUI(gui,0);
			require(gui.selectionMode == GameGUI::NO_SELECTION && gui.touch->statsOpen &&
                !gui.touch->panelOpen && gui.displayMode == GameGUI::STAT_TEXT_VIEW &&
                !gui.touch->restorePalette && !gui.touch->readOnlyPanelShown,
                "Replay statistics replace every inspector and survive the next draw");
		}
		gui.touch->dismissMapPanels();
		gui.touch->select({center.x + 28, center.y});
		glob2test::drawGUI(gui,0);
		map.setNoResource(41, 40, 1);
		gui.prepareLocalPresentation();
		gui.checkSelection();
		gui.touch->prepareDraw();
		require(!gui.touch->panelOpen && !gui.touch->restorePalette,
			"Pre-draw resource invalidation dismisses its read-only panel");
		gui.setSelection(GameGUI::UNIT_SELECTION,worker);
		gui.touch->panelOpen = true;
		glob2test::drawGUI(gui,0);
		const int id = Unit::GIDtoID(worker->gid);
		gui.localTeam->detachUnit(id);
		gui.game.snapshots().invalidateBoundary();
		gui.prepareLocalPresentation();
		gui.checkSelection(); // Threaded client steps invalidate before prepareDraw.
		gui.touch->prepareDraw();
		require(gui.selectionMode == GameGUI::NO_SELECTION && !gui.touch->panelOpen, "Removed unit dismisses its inspector");
		gui.localTeam->attachUnit(id, worker);
		gui.game.snapshots().invalidateBoundary();
		globalContainer->replaying = false;
		globalContainer->replayShowFog = true;
	}

	static void flagDragging()
	{
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Touch", 0, BasePlayer::P_LOCAL);
		require(gui.loadFromHeaders(map, players, true, true), "Fixture load failed");
		gui.localTeamNo = 0;
		gui.localPlayer = 0;
		gui.adjustLocalTeam();
		gui.prepareLocalPresentation();
		auto *gfx = globalContainer->gfx;
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		gfx->setResponsiveViewport(true, 800, 600);
		auto resizeWindow = [&](int width, int height)
		{
			const int oldW = gfx->getW(), oldH = gfx->getH();
			SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
			SDL_Event resize{};
			resize.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
			GAGCore::GraphicContext::translateMouseEvent(&resize);
			gui.viewportResized(oldW, oldH, gfx->getW(), gfx->getH());
		};
		Uint32 now = 20000;
		auto finger = [&](Uint32 type, int id, double x, double y)
		{
			SDL_Event event{};
			event.type = type;
			event.tfinger.timestamp = SDL_MS_TO_NS(now);
			event.tfinger.touchID = 7;
			event.tfinger.fingerID = id;
			event.tfinger.x = float(x / gfx->getW());
			event.tfinger.y = float(y / gfx->getH());
			gui.processEvent(&event);
			now += 16;
		};
		auto &gameMap = gui.game.map;
		const int warflag = gui.game.buildingsTypes.getTypeNum("warflag", 0, false);
		for (const auto &[width, height] : {std::pair{390, 844}, std::pair{844, 390}})
		{
			resizeWindow(width, height);
			require(gui.touch->usesHUD(), "Phone HUD must be active");
			gui.clearSelection();
			gui.touch->cancel();
			gui.orderQueue.clear();
			gui.camera.zoom = 1;
			gui.camera.originX = gui.camera.originY = 0;
			gui.updateCamera();
			gui.viewportX = gui.camera.tileX();
			gui.viewportY = gui.camera.tileY();
			const double unit = gfx->logicalUnitsPerPoint();
			const auto area = gui.touch->worldBounds();
			// Open ground in the middle of the view: no building or unit within two
			// tiles, so both the exact grab and the forgiving reach apply.
			auto tileAt = [&](double x, double y)
			{
				return std::pair{((gui.mapMouseX(int(x)) >> 5) + gui.viewportX) & gameMap.getMaskW(),
								 ((gui.mapMouseY(int(y)) >> 5) + gui.viewportY) & gameMap.getMaskH()};
			};
			auto clear = [&](int tx, int ty)
			{
				for (int dy = -2; dy <= 2; ++dy)
					for (int dx = -2; dx <= 2; ++dx)
						if (gameMap.getBuilding(tx + dx, ty + dy) != NOGBID ||
							gameMap.getGroundUnit(tx + dx, ty + dy) != NOGUID ||
							gameMap.getAirUnit(tx + dx, ty + dy) != NOGUID)
							return false;
				return true;
			};
			// Search outward from the middle, keeping every drag below at least
			// five tiles from the view's edges, where a held flag pans the map.
			const double reach = 5 * 32 * gui.camera.zoom;
			auto inside = [&](double x, double y)
			{
				for (double dx : {-reach, 0., reach})
					for (double dy : {-reach, 0., reach})
						if (!area.contains({x + dx, y + dy}) || gui.touch->interfaceRegion({x + dx, y + dy}) != 0)
							return false;
				return true;
			};
			int fx = -1, fy = -1;
			for (int ring = 0; ring <= 10 && fx < 0; ++ring)
				for (int oy = -ring; oy <= ring && fx < 0; ++oy)
					for (int ox = -ring; ox <= ring && fx < 0; ++ox)
					{
						if (std::max(std::abs(ox), std::abs(oy)) != ring)
							continue;
						const double x = area.x + area.w / 2 + ox * 32 * gui.camera.zoom;
						const double y = area.y + area.h / 2 + oy * 32 * gui.camera.zoom;
						if (!inside(x, y))
							continue;
						const auto [tx, ty] = tileAt(x, y);
						if (clear(tx, ty))
							fx = tx, fy = ty;
					}
			require(fx >= 0, "Flag fixture needs open ground in view");
			Building *flag = gui.game.addBuilding(fx, fy, warflag, 0);
			require(flag && std::find(gui.localTeam->virtualBuildings.begin(),
									  gui.localTeam->virtualBuildings.end(),
									  flag) != gui.localTeam->virtualBuildings.end(),
					"The fixture flag is one of the player's flags");
            if (!gui.drawnScene().world.occupancy)
                require(!gui.touch->grabbableFlag({area.x+area.w/2,area.y+area.h/2}),"Input before the first frame cannot dereference an absent world");
            gui.prepareLocalPresentation();
			const double tile = 32 * gui.camera.zoom;
			auto centre = [&]()
			{
				// The copy of the flag in view, across the map's wrap.
				const double w = gameMap.getW() * 32., h = gameMap.getH() * 32.;
				const auto c = gui.camera.worldToScreen(
					gui.camera.originX + MapCamera::wrap(gui.displayedPosX(*flag) * 32 + 16 - gui.camera.originX, w),
					gui.camera.originY + MapCamera::wrap(gui.displayedPosY(*flag) * 32 + 16 - gui.camera.originY, h));
				return GAGCore::ViewPoint{c.first, c.second};
			};
			auto moves = [&]()
			{
				std::vector<std::shared_ptr<OrderMoveFlag>> result;
				for (const auto &order : gui.orderQueue.snapshot())
					if (order->getOrderType() == ORDER_MOVE_FLAG)
						result.push_back(std::static_pointer_cast<OrderMoveFlag>(order));
				return result;
			};
			// Lands the queued move as the simulation would, so the next case
			// starts from settled state.
			auto settle = [&]()
			{
				for (const auto &move : moves())
				{
					flag->posX = move->x;
					flag->posY = move->y;
				}
				gui.orderQueue.clear();
				gui.buildingGuiState.erase(flag->gid);
                gui.game.snapshots().invalidateBoundary();
                gui.prepareLocalPresentation();
			};
			auto camera = [&]() { return std::pair{gui.camera.originX, gui.camera.originY}; };
			const auto checksum = gui.game.checkSum();

			// A drag that starts on the flag carries it three tiles; the map stays put.
			auto start = centre();
			auto cameraBefore = camera();
			finger(SDL_EVENT_FINGER_DOWN, 1, start.x, start.y);
			for (int i = 1; i <= 6; ++i)
				finger(SDL_EVENT_FINGER_MOTION, 1, start.x + i * tile / 2, start.y);
			require(gui.displayedPosX(*flag) == ((fx + 3) & gameMap.getMaskW()) &&
						gui.displayedPosY(*flag) == fy,
					"The flag follows the finger while it is dragged");
			require(camera() == cameraBefore, "Dragging a flag must not pan the map");
			finger(SDL_EVENT_FINGER_UP, 1, start.x + 3 * tile, start.y);
			auto queued = moves();
			require(queued.size() == 1 && queued[0]->gid == flag->gid &&
						queued[0]->x == ((fx + 3) & gameMap.getMaskW()) && queued[0]->y == fy &&
						queued[0]->drop,
					"Releasing the flag sends one dropped move to where it was carried");
			require(camera() == cameraBefore, "Releasing a flag must not pan the map");
			require(gui.selectionMode == GameGUI::NO_SELECTION, "Carrying a flag does not open its inspector");
			require(gui.game.checkSum() == checksum, "Moves wait in the order queue like any command");
			settle();
			const int afterX = flag->posX;

			// Within the reach, the grab keeps its offset: no jump to the finger.
			start = centre();
			const GAGCore::ViewPoint beside{start.x + 18 * unit, start.y};
			require(tileAt(beside.x, beside.y) != std::pair{flag->posX, flag->posY} ||
						18 * unit < tile / 2,
					"Near-grab fixture");
			cameraBefore = camera();
			finger(SDL_EVENT_FINGER_DOWN, 1, beside.x, beside.y);
			for (int i = 1; i <= 4; ++i)
				finger(SDL_EVENT_FINGER_MOTION, 1, beside.x, beside.y + i * tile / 2);
			finger(SDL_EVENT_FINGER_UP, 1, beside.x, beside.y + 2 * tile);
			queued = moves();
			require(queued.size() == 1 && queued[0]->x == afterX &&
						queued[0]->y == ((fy + 2) & gameMap.getMaskH()) && queued[0]->drop,
					"A grab just beside the flag carries it by the finger's travel");
			require(camera() == cameraBefore, "A grab beside the flag must not pan the map");
			settle();

			// 28 points from the flag still grabs it anywhere on screen; 40 never does.
			start = centre();
			require(gui.touch->grabbableFlag({start.x + 28 * unit, start.y})->gid == flag->gid,
					"A contact 28 points from a flag grabs it");
			require(!gui.touch->grabbableFlag({start.x + 40 * unit, start.y}),
					"A contact 40 points from a flag pans instead");

			// A small wobble below the tap threshold is still a tap: it selects.
			start = centre();
			finger(SDL_EVENT_FINGER_DOWN, 1, start.x, start.y);
			finger(SDL_EVENT_FINGER_MOTION, 1, start.x + 2 * unit, start.y);
			finger(SDL_EVENT_FINGER_UP, 1, start.x + 2 * unit, start.y);
			require(moves().empty(), "A tap on a flag sends no move");
			require(gui.selectionMode == GameGUI::BUILDING_SELECTION && gui.selectionBuilding() == flag,
					"A tap on a flag still selects it");
			gui.clearSelection();
			now += 1000; // Leave the double-tap window.

			// Straight after a tap, a drag on the flag still carries the flag.
			start = centre();
			finger(SDL_EVENT_FINGER_DOWN, 1, start.x, start.y);
			finger(SDL_EVENT_FINGER_UP, 1, start.x, start.y);
			gui.clearSelection();
			cameraBefore = camera();
			const double zoom = gui.camera.zoom;
			finger(SDL_EVENT_FINGER_DOWN, 1, start.x, start.y);
			for (int i = 1; i <= 4; ++i)
				finger(SDL_EVENT_FINGER_MOTION, 1, start.x, start.y - i * tile / 2);
			finger(SDL_EVENT_FINGER_UP, 1, start.x, start.y - 2 * tile);
			require(gui.camera.zoom == zoom && camera() == cameraBefore,
					"A drag on a flag after a tap carries the flag, not a one-finger zoom");
			queued = moves();
			require(queued.size() == 1 && queued[0]->y == fy, "That drag carries the flag back up");
			settle();
			now += 1000;

			// A drag well away from any flag pans the map as before.
			start = centre();
			cameraBefore = camera();
			const GAGCore::ViewPoint away{start.x, start.y + 60 * unit};
			require(!gui.touch->grabbableFlag(away), "Pan fixture lies outside the flag's reach");
			finger(SDL_EVENT_FINGER_DOWN, 1, away.x, away.y);
			for (int i = 1; i <= 4; ++i)
				finger(SDL_EVENT_FINGER_MOTION, 1, away.x + i * 20 * unit, away.y);
			finger(SDL_EVENT_FINGER_UP, 1, away.x + 80 * unit, away.y);
			require(camera() != cameraBefore, "Dragging open ground still pans the map");
			require(moves().empty(), "Panning the map moves no flag");
			gui.touch->stopScrolling();
			gui.camera.originX = cameraBefore.first;
			gui.camera.originY = cameraBefore.second;
			gui.viewportX = gui.camera.tileX();
			gui.viewportY = gui.camera.tileY();
			now += 1000;

			// A second finger while carrying puts the flag back and ignores the touch.
			start = centre();
			const int homeX = flag->posX, homeY = flag->posY;
			finger(SDL_EVENT_FINGER_DOWN, 1, start.x, start.y);
			for (int i = 1; i <= 4; ++i)
				finger(SDL_EVENT_FINGER_MOTION, 1, start.x + i * tile / 2, start.y);
			require(gui.displayedPosX(*flag) != homeX, "The flag was being carried");
			cameraBefore = camera();
			finger(SDL_EVENT_FINGER_DOWN, 2, start.x - 80 * unit, start.y + 80 * unit);
			queued = moves();
			require(queued.size() == 1 && queued[0]->x == homeX && queued[0]->y == homeY && queued[0]->drop,
					"A second finger returns the flag to where it was grabbed");
			finger(SDL_EVENT_FINGER_MOTION, 1, start.x + 4 * tile, start.y);
			finger(SDL_EVENT_FINGER_MOTION, 2, start.x - 40 * unit, start.y + 40 * unit);
			finger(SDL_EVENT_FINGER_UP, 1, start.x + 4 * tile, start.y);
			finger(SDL_EVENT_FINGER_UP, 2, start.x - 40 * unit, start.y + 40 * unit);
			require(moves().size() == 1 && camera() == cameraBefore,
					"The rest of a cancelled carry neither moves the flag nor the map");
			settle();

			// Losing focus mid-carry returns the flag too.
			start = centre();
			finger(SDL_EVENT_FINGER_DOWN, 1, start.x, start.y);
			for (int i = 1; i <= 4; ++i)
				finger(SDL_EVENT_FINGER_MOTION, 1, start.x, start.y + i * tile / 2);
			SDL_Event focus{};
			focus.type = SDL_EVENT_WINDOW_FOCUS_LOST;
			gui.touch->process(focus);
			queued = moves();
			require(queued.size() == 1 && queued[0]->x == homeX && queued[0]->y == homeY,
					"An interrupted carry returns the flag");
			require(!gui.touch->flagDrag, "An interrupted carry ends");
			finger(SDL_EVENT_FINGER_UP, 1, start.x, start.y + 2 * tile);
			settle();

			// Spectators never carry flags: their drag pans the map.
			globalContainer->liveSpectating = true;
			require(!gui.touch->grabbableFlag(centre()), "A spectator cannot grab a flag");
			globalContainer->liveSpectating = false;
			require(gui.touch->grabbableFlag(centre())->gid == flag->gid, "The player can grab the flag");

			// Held at the map's edge, the carried flag pans the map and rides along.
			start = centre();
			const GAGCore::ViewPoint edge{area.x + 6 * unit, start.y};
			require(gui.touch->interfaceRegion(edge) == 0, "Edge fixture must be on the map");
			finger(SDL_EVENT_FINGER_DOWN, 1, start.x, start.y);
			for (int i = 1; i <= 8; ++i)
				finger(SDL_EVENT_FINGER_MOTION, 1, start.x + (edge.x - start.x) * i / 8, start.y);
			require(gui.touch->flagDrag && gui.touch->flagDrag->dragging, "The flag is carried to the edge");
			const int beforeEdge = gui.viewportX;
			const int carriedX = gui.displayedPosX(*flag);
			// Edge panning caps each frame at 100 ms. Advance four frames so
			// the assertion crosses a tile regardless of the initial camera offset.
			for (int frame = 0; frame < 4; ++frame)
			{
				gui.touch->flagDrag->lastUpdate = SDL_GetTicks() - 100;
				gui.touch->prepareDraw();
			}
			require(gui.viewportX != beforeEdge, "Holding a carried flag at the edge pans the map");
			require(gui.displayedPosX(*flag) != carriedX, "The flag rides along as the map pans");
			finger(SDL_EVENT_FINGER_UP, 1, edge.x, edge.y);
			queued = moves();
			require(queued.size() == 1 && queued[0]->drop && queued[0]->x == gui.displayedPosX(*flag),
					"The flag lands where the edge pan took it");
			settle();

			gui.localTeam->virtualBuildings.remove(flag);
			gui.localTeam->detachBuilding(Building::GIDtoID(flag->gid));
			delete flag;
		}
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
		resizeWindow(800, 600);
	}

	static void scrollPhysics()
	{
		GameGUI gui;
		auto map = Engine::loadMapHeader("maps/balanced.map");
		GameHeader players;
		players.setNumberOfPlayers(1);
		players.getBasePlayer(0) = BasePlayer(0, "Touch", 0, BasePlayer::P_LOCAL);
		require(gui.loadFromHeaders(map, players, true, true), "Fixture load failed");
		gui.localTeamNo = 0;
		gui.localPlayer = 0;
		gui.adjustLocalTeam();
		gui.viewportX = gui.viewportY = 0;
		gui.prepareLocalPresentation();
		gui.updateCamera();
		auto *gfx = globalContainer->gfx;
		const double mapWidth = gui.game.map.getW() * 32.0;
		Uint64 now = 5000;
		auto finger = [&](Uint32 type, float x, float y)
		{
			SDL_Event event{};
			event.type = type;
			event.tfinger.timestamp = SDL_MS_TO_NS(now);
			event.tfinger.touchID = 7;
			event.tfinger.fingerID = 1;
			event.tfinger.x = x / gfx->getW();
			event.tfinger.y = y / gfx->getH();
			gui.processEvent(&event);
		};
		auto frame = [&](Uint64 ms)
		{
			now += ms;
			gui.step({}, now);
		};
		// Four moves 16 ms apart, then an immediate release.
		auto flick = [&](float x, float y, float dx, float dy)
		{
			finger(SDL_EVENT_FINGER_DOWN, x, y);
			for (int i = 1; i <= 4; ++i)
			{
				frame(16);
				finger(SDL_EVENT_FINGER_MOTION, x + dx * i, y + dy * i);
			}
			finger(SDL_EVENT_FINGER_UP, x + dx * 4, y + dy * 4);
		};
		auto placeCamera = [&](double x, double y)
		{
			gui.camera.originX = x;
			gui.camera.originY = y;
			gui.camera.normalize();
			gui.viewportX = gui.camera.tileX();
			gui.viewportY = gui.camera.tileY();
		};
		const auto checksum = gui.game.checkSum();
		require(!gui.touch->scrollAnimating(), "Nothing moves before a gesture");
		// Tap jitter must not become a fling, even when it crosses the pan slop.
		for (const auto delta : {ViewPoint{0, 0}, ViewPoint{1, 0}, ViewPoint{3, 0}, ViewPoint{2, 2}})
		{
			placeCamera(gui.localTeam->startPosX * 32.0 - 200, gui.localTeam->startPosY * 32.0 - 200);
			frame(500); // separate taps from the double-tap gesture
			flick(400, 300, delta.x, delta.y);
			const auto released = gui.camera;
			if (delta.x == 3)
			{
				glob2test::drawGUI(gui,0);
				gfx->printScreen("momentum-jitter-released.bmp");
				gfx->nextFrame();
			}
			frame(100);
			if (delta.x == 3)
			{
				glob2test::drawGUI(gui,0);
				gfx->printScreen("momentum-jitter-later.bmp");
				gfx->nextFrame();
			}
			std::cout << "Jitter travel=" << std::hypot(delta.x, delta.y) * 4
				<< " coast=" << gui.camera.originX - released.originX << ","
				<< gui.camera.originY - released.originY << "\n";
			require(!gui.touch->scrollAnimating(), "Small touch jitter must not launch momentum");
			require(std::abs(gui.camera.originX - released.originX) < 1e-6 &&
				std::abs(gui.camera.originY - released.originY) < 1e-6,
				"A short touch stays at its release position");
		}
		// Total path length is not intent: repeated jitter can travel far while
		// remaining within a small radius of the original contact.
		frame(500);
		finger(SDL_EVENT_FINGER_DOWN, 400, 300);
		for (int i = 0; i < 8; ++i)
		{
			frame(16);
			finger(SDL_EVENT_FINGER_MOTION, i % 2 ? 390 : 410, 300);
		}
		finger(SDL_EVENT_FINGER_UP, 390, 300);
		require(!gui.touch->scrollAnimating(), "Oscillating jitter does not accumulate fling eligibility");
		for (const auto delta : {ViewPoint{4, 0}, ViewPoint{3, 3}})
		{
			flick(400, 300, delta.x, delta.y);
			require(gui.touch->scrollAnimating(), "A deliberate swipe at the threshold still coasts");
			// Catching that coast and making a short movement must not inherit
			// the previous gesture's eligibility.
			flick(400, 300, 3, 0);
			require(!gui.touch->scrollAnimating(), "Each touch must independently cross the dead zone");
		}
		// Fling intent is measured on the display, even when the same motion
		// travels very different distances through the world at different zooms.
		const double originalZoom = gui.camera.zoom;
		for (double zoom : {gui.camera.minimumZoom(), MapCamera::MAX_ZOOM})
		{
			gui.camera.setZoom(zoom, 400, 300);
			placeCamera(1000, 1000);
			frame(500);
			flick(400, 300, 3, 0);
			require(!gui.touch->scrollAnimating(), "Zoom must not amplify jitter into fling intent");
			flick(400, 300, 4, 0);
			require(gui.touch->scrollAnimating(), "Zoom must not shrink a deliberate swipe below the threshold");
			gui.touch->stopScrolling();
		}
		gui.camera.setZoom(originalZoom, 400, 300);
		// A rightward flick moves the origin left; from 300 px it coasts past zero.
		placeCamera(300, 300);
		flick(400, 300, 40, 0);
		require(gui.touch->scrollAnimating(), "A flick keeps the map coasting");
		double previous = gui.camera.originX, travelled = 0;
		int frames = 0;
		bool wrapped = false;
		while (gui.touch->scrollAnimating() && frames < 600)
		{
			frame(16);
			++frames;
			const double delta = MapCamera::wrap(previous - gui.camera.originX, mapWidth);
			require(delta >= 0 && delta < mapWidth / 2, "Coasting keeps the flick's direction");
			require(gui.viewportX == (gui.camera.tileX() & gui.game.map.getMaskW()),
					"The tile viewport follows the camera while coasting");
			if (gui.camera.originX > previous)
				wrapped = true;
			travelled += delta;
			previous = gui.camera.originX;
		}
		require(frames > 1 && frames < 600, "Coasting ends on its own");
		require(travelled > 200, "Coasting carries the map well past the drag");
		require(wrapped, "Coasting crosses the toroidal seam");
		require(gui.game.checkSum() == checksum, "Coasting never touches the simulation");
		// A touch catches the map where it is and is not a pan.
		placeCamera(1000, 300);
		flick(400, 300, 40, 0);
		frame(16);
		require(gui.touch->scrollAnimating(), "The map coasts again");
		finger(SDL_EVENT_FINGER_DOWN, 400, 300);
		require(!gui.touch->scrollAnimating(), "A finger stops the coasting map");
		const double held = gui.camera.originX;
		frame(100);
		require(std::abs(gui.camera.originX - held) < 1e-6, "The stopped map stays under the finger");
		finger(SDL_EVENT_FINGER_MOTION, 412, 300);
		frame(80); // the finger rests before lifting
		finger(SDL_EVENT_FINGER_UP, 412, 300);
		frame(16);
		require(!gui.touch->scrollAnimating(), "A finger that rests before lifting leaves no momentum");
		require(std::abs(MapCamera::wrap(held - gui.camera.originX, mapWidth) - 12) < 1e-6, "The drag after the stop still pans");
		// A substantial drag followed by a stop must not coast from lift jitter.
		for (Uint64 pause : {24, 64, 80, 1000})
		{
			frame(500);
			finger(SDL_EVENT_FINGER_DOWN, 400, 300);
			for (int i = 1; i <= 4; ++i)
			{
				frame(16);
				finger(SDL_EVENT_FINGER_MOTION, 400 + 20 * i, 300);
			}
			frame(pause);
			finger(SDL_EVENT_FINGER_MOTION, 481, 300);
			frame(16);
			finger(SDL_EVENT_FINGER_MOTION, 482, 300);
			finger(SDL_EVENT_FINGER_UP, 482, 300);
			const auto released = gui.camera;
			frame(100);
			require(!gui.touch->scrollAnimating(), "Lift jitter after a long drag must not fling");
			require(std::abs(gui.camera.originX - released.originX) < 1e-6 &&
					std::abs(gui.camera.originY - released.originY) < 1e-6,
					"The map stays at the drag release position");
		}
		// Suspending input stops coasting too.
		flick(400, 300, 0, 40);
		frame(16);
		require(gui.touch->scrollAnimating(), "A vertical flick coasts");
		gui.suspendInput();
		require(!gui.touch->scrollAnimating(), "suspendInput stops coasting");
		const double suspended = gui.camera.originY;
		frame(100);
		require(std::abs(gui.camera.originY - suspended) < 1e-6, "Nothing moves after suspendInput");
		require(gui.game.checkSum() == checksum, "Touch navigation leaves the simulation alone");

		// The phone HUD: the build palette coasts, rubber-bands and springs back.
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "1", 1);
		gfx->setResponsiveViewport(true, 800, 600);
		auto resizeWindow = [&](int width, int height)
		{
			const int oldW = gfx->getW(), oldH = gfx->getH();
			SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()), width, height);
			GLOB2_REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())), "Window resize must settle before layout assertions");
			SDL_Event resize{};
			resize.type = SDL_EVENT_WINDOW_RESIZED;
			resize.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
			GAGCore::GraphicContext::translateMouseEvent(&resize);
			gui.viewportResized(oldW, oldH, gfx->getW(), gfx->getH());
		};
		resizeWindow(568, 320);
		require(gui.touch->usesHUD(), "Phone HUD must be active");
		gui.clearSelection();
		gui.displayMode = GameGUI::CONSTRUCTION_VIEW;
		gui.touch->panelOpen = true;
		gui.touch->panelScroll = 0;
		gui.touch->clampScroll();
		// The phone panel is sized to its palette, so its range is the end itself:
		// pulling stretches the palette past the end and releasing springs back.
		const double maximum = gui.touch->panelAxis.axis.maximum();
		const auto panel = gui.touch->panelContent();
		// The panel's left margin has no palette items, whose touch starts a placement.
		const float px = float(panel.x + 1), py = float(panel.y + panel.h / 2);
		// The thumb rail fills from the bottom, so its content follows the finger with the
		// opposite sign; mirroring the finger keeps every check about the same end.
		const double sign = gui.touch->paletteScrollSign();
		auto along = [&](double offset) { return float(py + offset * sign); };
		require(gui.touch->interfaceRegion({px, py}) == 3, "The panel margin is the panel region");
		for (float y : {along(60), py, along(-30), along(40), along(-40)})
			require(!gui.touch->paletteItemAt({px, y}), "The gestures avoid palette items");
		// Mac gestures capture the HUD even when the pointer later crosses the map.
		const double nativeUnit = gfx->logicalUnitsPerPoint();
		GAGCore::GestureScrollEvent native;
		native.sequence = 101; native.x = px; native.y = py; native.logical = true;
		native.phase = GAGCore::ScrollGesturePhase::Began; native.timestamp = SDL_MS_TO_NS(now);
		auto nativeEvent = GAGCore::gestureScrollEvent(native);
		gui.processEvent(&nativeEvent);
		const double zoomBeforeNative = gui.camera.zoom;
		native.phase = GAGCore::ScrollGesturePhase::Changed;
		native.dy = -40 * nativeUnit * sign;
		native.x = 400; native.y = 100;
		nativeEvent = GAGCore::gestureScrollEvent(native);
		gui.processEvent(&nativeEvent);
		require(gui.touch->panelScroll > maximum, "Native HUD scrolling stretches at its end");
		require(gui.camera.zoom == zoomBeforeNative, "A captured HUD gesture cannot zoom the map");
		native.phase = GAGCore::ScrollGesturePhase::Ended; native.dy = 0;
		nativeEvent = GAGCore::gestureScrollEvent(native); gui.processEvent(&nativeEvent);
		native.phase = GAGCore::ScrollGesturePhase::None; native.momentum = GAGCore::ScrollGesturePhase::Began;
		native.dy = -100 * nativeUnit * sign;
		const double nativeStretch = gui.touch->panelScroll;
		nativeEvent = GAGCore::gestureScrollEvent(native); gui.processEvent(&nativeEvent);
		require(gui.touch->panelScroll == nativeStretch, "Native momentum does not add another HUD overshoot");
		for (int i = 0; i < 600 && gui.touch->scrollAnimating(); ++i) frame(16);
		require(gui.touch->panelScroll == maximum, "The native HUD spring settles at the boundary");
		gui.touch->cancel(); gui.touch->panelScroll = 0; gui.touch->clampScroll();
		finger(SDL_EVENT_FINGER_DOWN, px, along(60));
		frame(16);
		finger(SDL_EVENT_FINGER_MOTION, px, py);
		require(gui.touch->panelScroll > maximum, "Pulling past the end stretches the palette");
		require(gui.touch->panelScroll < maximum + 60, "The stretch is shorter than the finger's move");
		const double stretched = gui.touch->panelScroll;
		frame(16);
		finger(SDL_EVENT_FINGER_MOTION, px, along(-30));
		require(gui.touch->panelScroll > stretched, "Pulling further stretches further");
		frame(80); // the finger rests before lifting
		finger(SDL_EVENT_FINGER_UP, px, along(-30));
		require(gui.touch->scrollAnimating(), "Released stretched content springs back");
		frames = 0;
		previous = gui.touch->panelScroll;
		while (gui.touch->scrollAnimating() && frames++ < 600)
		{
			frame(16);
			require(gui.touch->panelScroll >= maximum, "The spring never overshoots back");
			require(gui.touch->panelScroll <= previous + 1e-9, "The spring only returns");
			previous = gui.touch->panelScroll;
		}
		require(frames < 600, "The spring settles");
		require(gui.touch->panelScroll == maximum, "The palette settles at its end");
		// A flick reaches the end at once and hands its speed to the spring.
		flick(px, along(40), 0, float(-20 * sign));
		require(gui.touch->scrollAnimating(), "A flick keeps the palette moving");
		bool overshot = false;
		frames = 0;
		while (gui.touch->scrollAnimating() && frames++ < 600)
		{
			frame(16);
			require(gui.touch->panelScroll >= maximum, "The flick never leaves the range on the wrong side");
			require(gui.touch->panelScroll < maximum + panel.h, "The flick's stretch stays inside the panel");
			overshot = overshot || gui.touch->panelScroll > maximum;
		}
		require(overshot && frames < 600, "The flick overshoots the end and settles");
		require(gui.touch->panelScroll == maximum, "The palette rests at its end after the flick");
		// A touch mid-bounce holds the stretch, and lifting lets it finish.
		flick(px, along(40), 0, float(-20 * sign));
		frame(16);
		require(gui.touch->panelScroll > maximum && gui.touch->scrollAnimating(), "mid-bounce");
		finger(SDL_EVENT_FINGER_DOWN, px, along(0));
		require(!gui.touch->scrollAnimating(), "A touch stops the bounce");
		const double caught = gui.touch->panelScroll;
		frame(100);
		require(gui.touch->panelScroll == caught, "The stopped palette holds its stretch");
		finger(SDL_EVENT_FINGER_UP, px, along(0));
		require(gui.touch->scrollAnimating(), "Lifting lets the stretch spring back");
		frames = 0;
		while (gui.touch->scrollAnimating() && frames++ < 600)
			frame(16);
		require(gui.touch->panelScroll == maximum, "The palette returns to its end");
		// A mouse drag (a synthetic finger) scrolls the palette without momentum.
		auto mouse = [&](Uint32 type, int x, int y)
		{
			SDL_Event event{};
			event.type = type;
			event.common.timestamp = SDL_MS_TO_NS(now);
			if (type == SDL_EVENT_MOUSE_MOTION)
			{
				event.motion.x = x;
				event.motion.y = y;
				event.motion.state = SDL_BUTTON_LMASK;
			}
			else
			{
				event.button.button = SDL_BUTTON_LEFT;
				event.button.x = x;
				event.button.y = y;
			}
			gui.processEvent(&event);
		};
		gui.touch->panelScroll = 0;
		gui.touch->clampScroll();
		mouse(SDL_EVENT_MOUSE_BUTTON_DOWN, int(px), int(along(40)));
		for (int i = 1; i <= 4; ++i)
		{
			frame(16);
			mouse(SDL_EVENT_MOUSE_MOTION, int(px), int(along(40 - 20 * i)));
		}
		mouse(SDL_EVENT_MOUSE_BUTTON_UP, int(px), int(along(-40)));
		require(gui.touch->panelScroll == maximum, "A mouse drag neither stretches nor coasts");
		require(!gui.touch->scrollAnimating(), "A mouse drag has no momentum");
		require(gui.selectionMode == GameGUI::NO_SELECTION, "Panel gestures never start a placement");
		require(gui.game.checkSum() == checksum, "HUD scrolling leaves the simulation alone");
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
		resizeWindow(800, 600);
	}

	// The phone editor: touch pans move the camera by the finger distance (no
	// whole-tile steps), the map coasts and wraps after a flick, a pinch zooms
	// by the finger ratio, and the tool tray coasts.
	static void editorScrollPhysics()
	{
		MapEdit editor;
		require(editor.load("maps/balanced.map"), "Editor fixture loads");
		editor.phone = std::make_unique<PhoneEditor>(editor);
		auto &touch = *editor.phone;
		auto *gfx = globalContainer->gfx;
		const double unit = gfx->logicalUnitsPerPoint();
		touch.chooseMode(0);
		touch.prepare();
		editor.updateCamera();
		Uint32 tick = 9000;
		auto finger = [&](Uint32 kind, int id, GAGCore::ViewPoint p)
		{
			SDL_Event event{};
			event.type = kind;
			event.tfinger.timestamp = SDL_MS_TO_NS(tick);
			event.tfinger.touchID = 19;
			event.tfinger.fingerID = id;
			event.tfinger.x = p.x / gfx->getW();
			event.tfinger.y = p.y / gfx->getH();
			touch.event(event);
		};
		auto frame = [&](Uint32 ms)
		{
			tick += ms;
			touch.advance(tick);
		};
		auto placeCamera = [&](double x, double y)
		{
			editor.updateCamera();
			editor.camera.originX = x;
			editor.camera.originY = y;
			editor.camera.normalize();
			editor.viewportX = editor.camera.tileX();
			editor.viewportY = editor.camera.tileY();
		};
		const double mapWidth = editor.game.map.getW() * 32.0;
		auto checksum = [&] { return editor.game.checkSum(nullptr, nullptr, nullptr, true); };
		const auto before = checksum();
		const GAGCore::ViewPoint start{touch.content.x + touch.content.w / 2,
									   touch.content.y + touch.content.h / 2};
		// A short drag pans by exactly the finger distance.
		placeCamera(300, 300);
		finger(SDL_EVENT_FINGER_DOWN, 1, start);
		frame(16);
		finger(SDL_EVENT_FINGER_MOTION, 1, {start.x + 10 * unit, start.y});
		require(std::abs(MapCamera::wrap(300 - editor.camera.originX, mapWidth) - 10 * unit) < 1e-6,
				"A ten point drag pans the editor map by ten points");
		require(editor.viewportX == (editor.camera.tileX() & editor.game.map.wMask),
				"The editor tile viewport follows its camera");
		frame(80);
		finger(SDL_EVENT_FINGER_UP, 1, {start.x + 10 * unit, start.y});
		require(!touch.animating(), "A finger that rests before lifting leaves no momentum");
		// A flick coasts, wraps across the seam and stops; terrain is untouched.
		placeCamera(200, 300);
		finger(SDL_EVENT_FINGER_DOWN, 1, start);
		for (int i = 1; i <= 4; ++i)
		{
			frame(16);
			finger(SDL_EVENT_FINGER_MOTION, 1, {start.x + 40 * unit * i, start.y});
		}
		finger(SDL_EVENT_FINGER_UP, 1, {start.x + 160 * unit, start.y});
		require(touch.animating(), "A flick keeps the editor map coasting");
		double previous = editor.camera.originX;
		int frames = 0;
		bool wrapped = false;
		while (touch.animating() && frames < 600)
		{
			frame(16);
			++frames;
			const double delta = MapCamera::wrap(previous - editor.camera.originX, mapWidth);
			require(delta >= 0 && delta < mapWidth / 2, "Editor coasting keeps its direction");
			require(editor.viewportX == (editor.camera.tileX() & editor.game.map.wMask),
					"The editor tile viewport follows the coasting camera");
			if (editor.camera.originX > previous)
				wrapped = true;
			previous = editor.camera.originX;
		}
		require(frames > 1 && frames < 600 && wrapped, "Editor coasting wraps and ends on its own");
		require(checksum() == before, "Coasting never touches the map data");
		// A touch catches the map where it is.
		placeCamera(1000, 300);
		finger(SDL_EVENT_FINGER_DOWN, 1, start);
		for (int i = 1; i <= 4; ++i)
		{
			frame(16);
			finger(SDL_EVENT_FINGER_MOTION, 1, {start.x + 40 * unit * i, start.y});
		}
		finger(SDL_EVENT_FINGER_UP, 1, {start.x + 160 * unit, start.y});
		frame(16);
		require(touch.animating(), "The editor map coasts again");
		finger(SDL_EVENT_FINGER_DOWN, 1, start);
		require(!touch.animating(), "A finger stops the coasting editor map");
		const double held = editor.camera.originX;
		frame(100);
		require(std::abs(editor.camera.originX - held) < 1e-6, "The stopped editor map stays put");
		finger(SDL_EVENT_FINGER_MOTION, 1, {start.x + 12 * unit, start.y});
		frame(80);
		finger(SDL_EVENT_FINGER_UP, 1, {start.x + 12 * unit, start.y});
		require(!touch.animating(), "A rested release leaves the editor map still");
		// A pinch zooms by the finger ratio.
		editor.camera.zoom = 1;
		finger(SDL_EVENT_FINGER_DOWN, 1, start);
		finger(SDL_EVENT_FINGER_DOWN, 2, {start.x + 100, start.y});
		frame(16);
		finger(SDL_EVENT_FINGER_MOTION, 2, {start.x + 150, start.y});
		require(std::abs(editor.camera.zoom - 1.5) < 0.01, "A 1.5x pinch zooms the editor map 1.5x");
		finger(SDL_EVENT_FINGER_UP, 2, {start.x + 150, start.y});
		finger(SDL_EVENT_FINGER_UP, 1, start);
		touch.cancel();
		// The tool tray: pulling past its end stretches it and releasing springs
		// back; a flick overshoots the end and settles there; a mouse drag does
		// neither. The catalogue's terrain cards overflow the tray, so the
		// fixture starts scrolled to the end and pulls on the last card.
		touch.chooseMode(0);
		touch.prepare();
		const double trayEnd = touch.maximum;
		touch.offset = trayEnd;
		touch.prepare();
		GAGCore::GestureScrollEvent native;
		native.sequence = 201; native.logical = true;
		native.x = touch.cardBar.x + 20 * unit; native.y = touch.cardBar.y + 20 * unit;
		native.phase = GAGCore::ScrollGesturePhase::Began; native.timestamp = SDL_MS_TO_NS(tick);
		touch.event(GAGCore::gestureScrollEvent(native));
		native.phase = GAGCore::ScrollGesturePhase::Changed;
		native.dx = -40 * unit; native.dy = -1;
		touch.event(GAGCore::gestureScrollEvent(native));
		require(touch.offset > trayEnd, "A horizontal Mac gesture stretches the editor tray");
		native.phase = GAGCore::ScrollGesturePhase::Ended; native.dx = native.dy = 0;
		touch.event(GAGCore::gestureScrollEvent(native));
		for (int i = 0; i < 600 && touch.animating(); ++i) frame(16);
		require(touch.offset == trayEnd, "The native editor tray spring settles");
		// A vertical gesture is an alternative input for the horizontal tray.
		native.sequence++; native.phase = GAGCore::ScrollGesturePhase::Began;
		touch.event(GAGCore::gestureScrollEvent(native));
		native.phase = GAGCore::ScrollGesturePhase::Changed; native.dy = -30 * unit;
		touch.event(GAGCore::gestureScrollEvent(native));
		require(touch.offset > trayEnd, "Vertical Mac input also scrolls the editor tray");
		touch.cancel();
		native.phase = GAGCore::ScrollGesturePhase::None; native.momentum = GAGCore::ScrollGesturePhase::Began;
		require(touch.event(GAGCore::gestureScrollEvent(native)), "A cancelled tray consumes its momentum tail");
		require(touch.offset == trayEnd, "Cancelled native input cannot restart tray movement");

		const auto row = touch.rows.back().rect;
		const GAGCore::ViewPoint at{row.x + row.w / 2, row.y + row.h / 2};
		require(touch.hit(at) == int(touch.rows.size()) - 1, "The gesture starts on the last tray item");
		finger(SDL_EVENT_FINGER_DOWN, 1, at);
		frame(16);
		finger(SDL_EVENT_FINGER_MOTION, 1, {at.x - 40 * unit, at.y});
		require(touch.offset > trayEnd && touch.offset < trayEnd + 40 * unit,
				"Pulling past the end stretches the tray by less than the finger moved");
		const double stretched = touch.offset;
		frame(16);
		finger(SDL_EVENT_FINGER_MOTION, 1, {at.x - 70 * unit, at.y});
		require(touch.offset > stretched, "Pulling further stretches the tray further");
		frame(80);
		finger(SDL_EVENT_FINGER_UP, 1, {at.x - 70 * unit, at.y});
		require(touch.animating(), "The released tray springs back");
		frames = 0;
		double last = touch.offset;
		while (touch.animating() && frames++ < 600)
		{
			frame(16);
			require(touch.offset >= trayEnd && touch.offset <= last + 1e-9, "The tray spring only returns");
			last = touch.offset;
		}
		require(frames < 600 && touch.offset == trayEnd, "The tray settles at its end");
		touch.prepare();
		require(touch.offset == trayEnd, "Layout keeps the tray at its end");
		finger(SDL_EVENT_FINGER_DOWN, 1, at);
		for (int i = 1; i <= 4; ++i)
		{
			frame(16);
			finger(SDL_EVENT_FINGER_MOTION, 1, {at.x - 20 * unit * i, at.y});
		}
		finger(SDL_EVENT_FINGER_UP, 1, {at.x - 80 * unit, at.y});
		require(touch.animating(), "A flick keeps the tray moving");
		bool overshot = false;
		frames = 0;
		while (touch.animating() && frames++ < 600)
		{
			frame(16);
			require(touch.offset >= trayEnd && touch.offset < trayEnd + touch.tray.w, "The flick's stretch stays inside the tray");
			overshot = overshot || touch.offset > trayEnd;
		}
		require(overshot && frames < 600 && touch.offset == trayEnd, "The flick overshoots the end and settles there");
		// A mouse drag on the tray (device -1) neither stretches nor coasts.
		SDL_Event mouse{};
		mouse.type = SDL_EVENT_MOUSE_BUTTON_DOWN;
		mouse.common.timestamp = SDL_MS_TO_NS(tick);
		mouse.button.button = SDL_BUTTON_LEFT;
		mouse.button.x = int(at.x);
		mouse.button.y = int(at.y);
		touch.event(mouse);
		for (int i = 1; i <= 4; ++i)
		{
			frame(16);
			SDL_Event motion{};
			motion.type = SDL_EVENT_MOUSE_MOTION;
			motion.common.timestamp = SDL_MS_TO_NS(tick);
			motion.motion.x = int(at.x - 20 * unit * i);
			motion.motion.y = int(at.y);
			touch.event(motion);
			require(touch.offset == trayEnd, "A mouse drag past the end does not stretch the tray");
		}
		mouse.type = SDL_EVENT_MOUSE_BUTTON_UP;
		mouse.common.timestamp = SDL_MS_TO_NS(tick);
		mouse.button.x = int(at.x - 80 * unit);
		touch.event(mouse);
		require(!touch.animating() && touch.offset == trayEnd, "A mouse drag has no momentum");
		require(checksum() == before, "Tray scrolling never touches the map data");
	}
	static void scaledDialogInput()
	{
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 1600, .height = 1200,
		                                  .screenFlags = 0};
		glob2test::HeadlessGlobals globals(options);
		auto *gfx = globalContainer->gfx;
		REQUIRE(gfx->setUiScale(2));
		GAGCore::GestureScrollEvent native;
		native.sequence = 401; native.x = 200; native.y = 200; native.dx = 3.25; native.dy = 7.75;
		float fromX = 200, fromY = 200, toX = 203.25f, toY = 207.75f;
		GAGCore::GraphicContext::translateMouseCoordinates(fromX, fromY);
		GAGCore::GraphicContext::translateMouseCoordinates(toX, toY);
		auto nativeEvent = GAGCore::gestureScrollEvent(native);
		GAGCore::GraphicContext::translateMouseEvent(&nativeEvent);
		auto translated = *GAGCore::scrollGesture(nativeEvent);
		require(std::abs(translated.dx - (toX - fromX)) < .001 &&
			std::abs(translated.dy - (toY - fromY)) < .001,
			"Native deltas use the same window-to-logical transform as pointer positions");
		require(translated.logical, "Native coordinate conversion is marked complete");
		GAGCore::GraphicContext::translateMouseEvent(&nativeEvent);
		require(GAGCore::scrollGesture(nativeEvent)->dy == translated.dy,
			"Repeated dispatch does not scale a native sample twice");

		GameGUI gui;
		gui.openDialog(GameGUI::IGM_SAVE, std::make_unique<LoadSaveDialog>(
			"games", "game", false, "Save game", "Scaled", glob2FilenameToName, glob2NameToFilename));
		auto *dialog = gui.gameMenuScreen.get();
		dialog->draw(0);
		const auto bounds = dialog->host().bounds("name");
		SDL_Event event{};
		event.type = SDL_EVENT_MOUSE_BUTTON_DOWN;
		event.button.button = SDL_BUTTON_LEFT;
		// GameGUI::step has already converted these to logical coordinates.
		event.button.x = bounds.x + bounds.w / 2;
		event.button.y = bounds.y + bounds.h / 2;
		gui.processEvent(&event);
		event.type = SDL_EVENT_MOUSE_BUTTON_UP;
		gui.processEvent(&event);
		REQUIRE(dialog->host().editing() == "name");
		event = {};
		event.type = SDL_EVENT_TEXT_INPUT;
		event.text.text = "2";
		gui.processEvent(&event);
		REQUIRE(std::string(static_cast<LoadSaveDialog *>(dialog)->getName()) == "Scaled2");
	}
    static void compactTutorialStatistics()
    {
        glob2test::ScopedEnvironment mobile("GLOB2_MOBILE_UI", "1");
        glob2test::HeadlessGlobals globals({.display=true, .loadStrings=true, .width=320, .height=640,
            .screenFlags=GAGCore::GraphicContext::PORTABLEGPU});
        auto *strings=GAGCore::Toolkit::getStringTable();
        const int previousLanguage=strings->getLang();
        struct RestoreLanguage { GAGCore::StringTable *strings; int value;
            ~RestoreLanguage(){strings->setLang(value);} } restore{strings,previousLanguage};
        strings->setLang(strings->getLangCode("bn"));
        globals->settings.setTextSizePercent(150);
        // Use the public fixture loader with the packaged lesson's authored
        // players, team associations and AI configuration, as campaign init does.
        GameGUI gui;
        const auto source=(glob2test::sourceRoot()/Tutorial::IntroductionMap).string();
        auto map=Engine::loadMapHeader(source);
        auto players=Engine::loadGameHeader(source);
        REQUIRE(map.getNumberOfTeams()==2);
        REQUIRE(players.getNumberOfPlayers()==2);
        REQUIRE(players.getBasePlayer(0).name=="Your colony");
        REQUIRE(players.getBasePlayer(1).name=="Practice colony");
        // Missions and the tutorial play as authored: never with experiments.
        if (!map.getIsSavedGame()) players.getExperiments().clear();
        REQUIRE(gui.loadFromHeaders(map,players,true,true,false,source));
        gui.localPlayer=0; gui.localTeamNo=players.getBasePlayer(0).teamNumber;
        gui.adjustLocalTeam();
        gui.game.setWaitingOnMask(0);
        for(int tick=0;tick<64;++tick)gui.game.step(0);
        glob2test::drawGUI(gui,0);
        auto *card=gui.tutorialGuidance.get(); REQUIRE(card);
        const auto lesson=Tutorial::view(gui.drawnScene().panels.hud.state()); REQUIRE(lesson);
        const auto tap=[&](GAGGUI::ui::Rect r) {
            SDL_Event e{};e.type=SDL_EVENT_MOUSE_BUTTON_DOWN;e.button.button=SDL_BUTTON_LEFT;
            e.button.x=r.x+r.w/2;e.button.y=r.y+r.h/2;gui.processEvent(&e);
            e.type=SDL_EVENT_MOUSE_BUTTON_UP;gui.processEvent(&e);
        };
        tap(card->host().bounds("intro/collapse")); glob2test::drawGUI(gui,0);
        CHECK_FALSE(card->host().find("intro/instruction"));
        const auto compact=card->panelBounds();
        REQUIRE(card->host().find("intro/title"));
        CHECK(card->host().bounds("intro/title").h<=card->host().bounds("intro/collapse").h);
        CHECK(compact.h<100);
        card->host().focus("intro/help",true);
        gui.touch->lensOpen=true;
        gui.selectionMode=GameGUI::NO_SELECTION; gui.displayMode=GameGUI::STAT_TEXT_VIEW;
        glob2test::drawGUI(gui,0);
        REQUIRE(gui.touch->lensVisible()); CHECK(gui.touch->obscuresTutorial());
        CHECK_FALSE(card->host().keyboardFocused());
        gui.touch->lensOpen=false; gui.touch->peekOpen=true;
        glob2test::drawGUI(gui,0); CHECK(gui.touch->obscuresTutorial());
        gui.touch->peekOpen=false; CHECK_FALSE(gui.touch->obscuresTutorial());
        card->host().focus("intro/help",true);
        gui.touch->menuAction(3); glob2test::drawGUI(gui,0);
        REQUIRE(gui.touch->statsOpen);
        CHECK_FALSE(card->host().keyboardFocused());
        const auto sheet=gui.touch->statsLayout();
        const auto mini=gui.touch->minimapRect();
        const GAGCore::ViewPoint overlap{mini.x+mini.w-3, std::min(mini.y+mini.h-3,sheet.title.y+sheet.title.h-2)};
        REQUIRE(mini.contains(overlap)); REQUIRE(sheet.sheet.contains(overlap));
        CHECK(gui.touch->interfaceRegion(overlap)==48);
        const auto cameraX=gui.viewportX,cameraY=gui.viewportY;
        gui.touch->interfaceTap(overlap);
        CHECK(gui.viewportX==cameraX); CHECK(gui.viewportY==cameraY);
        auto *gfx=globalContainer->gfx;
        // Request an actual backend readback; completedFrame may still refer
        // to the unused software surface with the programmable renderer.
        const auto capture=glob2test::profileDir()/"compact-bn-statistics.bmp";
        gfx->printScreen(capture.filename().string());
        gfx->nextFrame();
        REQUIRE(std::filesystem::exists(capture));
        std::unique_ptr<SDL_Surface,decltype(&SDL_DestroySurface)> pixels(SDL_LoadBMP(capture.string().c_str()),SDL_DestroySurface);
        REQUIRE(pixels);
        Uint8 r=0,g=0,b=0,a=0;
        REQUIRE(SDL_ReadSurfacePixel(pixels.get(),int(overlap.x),int(overlap.y),&r,&g,&b,&a));
        const auto paper=InGameTouchTheme::readout();
        const int tolerance=257-paper.a;
        CHECK(std::abs(int(r)-int(paper.r))<=tolerance);
        CHECK(std::abs(int(g)-int(paper.g))<=tolerance);
        CHECK(std::abs(int(b)-int(paper.b))<=tolerance);
        CHECK(glob2test::retainFromProfile(".bmp")==1);
        auto &panel=gui.statistics();
        for(int topic=0;topic<5;++topic) {
            tap(panel.host().bounds("stats/topic/"+std::to_string(topic)));
            glob2test::drawGUI(gui,0);
            CHECK(panel.topic()==InGameStatisticsPanel::Topic(topic));
        }
        gui.touch->closeStatistics();glob2test::drawGUI(gui,0);
        REQUIRE(gui.tutorialGuidance.get()==card);
        CHECK_FALSE(card->host().find("intro/instruction"));
        CHECK(card->panelBounds()==compact);
        CHECK(Tutorial::view(gui.drawnScene().panels.hud.state())==lesson);
        tap(card->host().bounds("intro/collapse"));glob2test::drawGUI(gui,0);
        CHECK(card->host().find("intro/instruction"));
        auto title=card->host().find("intro/title");REQUIRE(title);
        CHECK(title->accessibleText()==std::to_string(lesson->index+1)+" / "+std::to_string(lesson->count)+"  "+Glob2UI::tr(lesson->title));
    }
	static void liveStatisticsProbability()
    {
        glob2test::HeadlessGlobals globals({.display=true, .loadStrings=true, .width=360, .height=720,
            .screenFlags=GAGCore::GraphicContext::PORTABLEGPU});
        REQUIRE(NET_Init());
        struct NetworkCleanup { ~NetworkCleanup() { NET_Quit(); } } network;
        glob2test::ScopedEnvironment mobile("GLOB2_MOBILE_UI", "1");
        GameGUI gui;
        auto map = Engine::loadMapHeader("maps/balanced.map");
        GameHeader players;
        players.setNumberOfPlayers(1);
        players.getBasePlayer(0) = BasePlayer(0, "Touch", 0, BasePlayer::P_LOCAL);
        REQUIRE(gui.loadFromHeaders(map, players, true, true));
        gui.localTeamNo=gui.localPlayer=0;
        gui.adjustLocalTeam();
        gui.localTeam->stats.recordWinProbability(0, 900, "visibility-test");
        auto *gfx=globalContainer->gfx;
        gfx->setResponsiveViewport(true,800,600);
        for (auto [width,height] : {std::pair{360,720},std::pair{720,360}})
        {
            const int oldW=gfx->getW(),oldH=gfx->getH();
            SDL_SetWindowSize(SDL_GetWindowFromID(gfx->windowID()),width,height);
            REQUIRE(SDL_SyncWindow(SDL_GetWindowFromID(gfx->windowID())));
            SDL_Event resize{};resize.type=SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
            GAGCore::GraphicContext::translateMouseEvent(&resize);
            gui.viewportResized(oldW,oldH,gfx->getW(),gfx->getH());
            gui.prepareLocalPresentation();
            const auto checksum=gui.game.checkSum();
            gui.touch->menuAction(3);
            REQUIRE(gui.touch->statsOpen);
            auto &panel = gui.statistics();
            REQUIRE_FALSE(panel.metrics().empty());
            CHECK(std::none_of(panel.metrics().begin(), panel.metrics().end(),
                [](const auto &m){return m.winProbability;}));
            panel.selectTopic(InGameStatisticsPanel::Topic::World);
            panel.update(0);
            CHECK_FALSE(panel.host().find("stats/metric/win probability"));
            glob2test::drawGUI(gui,0);
            CHECK(gui.game.checkSum()==checksum);
            const auto screenshot="live-stats-"+std::to_string(width)+"x"+std::to_string(height)+".bmp";
            gfx->printScreen(screenshot);
            gfx->nextFrame();
            REQUIRE(std::filesystem::exists(glob2test::profileDir()/screenshot));
            gui.touch->statsOpen=false;
        }
        CHECK(glob2test::retainFromProfile(".bmp")==2);
    }
};
TEST_SUITE("GameGUITouch")
{
	TEST_CASE("compact input and semantics reject partially obscured targets and covered map gestures [display]")
	{
		glob2test::HeadlessGlobals globals({.display = true, .loadStrings = true, .width = 700, .height = 520,
			.screenFlags = GAGCore::GraphicContext::PORTABLEGPU});
		REQUIRE(NET_Init());
		GameGUITouchHarness::occludedControls();
		NET_Quit();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
	}

	TEST_CASE("compact semantic controls share navigation placement and building order validation [display]")
	{
		glob2test::HeadlessGlobals globals({.display = true, .loadStrings = true, .width = 700, .height = 520,
			.screenFlags = GAGCore::GraphicContext::PORTABLEGPU});
		REQUIRE(NET_Init());
		GameGUITouchHarness::semanticControls();
		NET_Quit();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
	}
    GLOB2_TEST_CASE("compact Bengali tutorial yields to statistics and covers the minimap", "[display][artifacts]")
    {
        GameGUITouchHarness::compactTutorialStatistics();
    }
    GLOB2_TEST_CASE("live statistics hide post-game probability across topics", "[display][artifacts]")
    {
        GameGUITouchHarness::liveStatisticsProbability();
    }

	GLOB2_TEST_CASE("attack marks follow mobile minimaps without extra lifetime ticks", "[display][artifacts]")
	{
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 800, .height = 600,
			.screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		REQUIRE(NET_Init());
		GameGUITouchHarness::minimapMarks();
		NET_Quit();
		glob2test::retainFromProfile(".bmp");
	}

	GLOB2_TEST_CASE("tutorial wrapping preserves shaped clusters and refreshes font metrics", "[display]")
	{
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 800, .height = 600,
			.screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		REQUIRE(NET_Init());
		GameGUITouchHarness::tutorialTypography();
		NET_Quit();
	}

	GLOB2_TEST_CASE("phone navigation contains actual Urdu labels at normal and enlarged text sizes", "[display]")
	{
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 390, .height = 844,
			.screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		REQUIRE(NET_Init());
		GameGUITouchHarness::navigationTypography();
		NET_Quit();
	}

	GLOB2_TEST_CASE("Filipino navigation keeps whole words and shared targets at enlarged text sizes", "[display][artifacts]")
	{
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 390, .height = 844,
			.screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		options.beforeLoad = [](GlobalContainer &globals) { globals.settings.language = "fil"; };
		glob2test::HeadlessGlobals globals(options);
		REQUIRE(NET_Init());
		GameGUITouchHarness::filipinoNavigationTypography();
		NET_Quit();
	}

	GLOB2_TEST_CASE("notifications clear system gutters and HUD at mobile text sizes", "[display][artifacts]")
	{
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 800, .height = 600,
			.screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		REQUIRE(NET_Init());
		GameGUITouchHarness::notifications();
		NET_Quit();
		glob2test::retainFromProfile(".bmp");
	}

	GLOB2_TEST_CASE("curved labels retain physical glyph detail and reuse their cache", "[display][artifacts]")
	{
		glob2test::GlobalsOptions options{.display = true, .width = 800, .height = 650,
			.screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		struct Probe : GAGCore::TrueTypeFont
		{
			Probe() : TrueTypeFont("data/fonts/sans.ttf", 13) {}
			std::vector<float> requested;
			std::unique_ptr<GAGCore::DrawableSurface> rasterizeString(const std::string &text, float scale) override
			{
				requested.push_back(scale);
				return TrueTypeFont::rasterizeString(text, scale);
			}
		} font;
		auto *gfx = globalContainer->gfx;
		TouchDial::Painter painter;
		for (const double unit : {1., 2.})
			for (const bool mirrored : {false, true})
			{
				gfx->drawFilledRect(0, 0, 800, 650, GAGCore::Color(20, 15, 30));
				TouchDial::Geometry geometry;
				geometry.center = {mirrored ? 0. : 800., 650.};
				geometry.unit = unit;
				geometry.mirrored = mirrored;
				const TouchDial::Ring ring{260, 292};
				painter.fill(geometry, ring.inner, ring.outer, 5, 85, GAGCore::Color(53, 32, 75));
				auto draw = [&] {
					painter.label(geometry, ring, 15, 65, "Cancel Upgrade", &font, unit, GAGCore::Color(255, 239, 204),
						nullptr, 0, nullptr, true);
				};
				draw();
				REQUIRE_FALSE(font.requested.empty());
				CHECK(font.requested.back() == doctest::Approx(2 * unit * gfx->getRasterScale()));
				const auto calls = font.requested.size();
				draw();
				CHECK(font.requested.size() == calls);
				gfx->setUITransform(unit, 20, 20);
				gfx->drawString(0, 0, &font, "Cancel Upgrade");
				gfx->setUITransform();
				gfx->printScreen(std::string("curved-label-") + std::to_string(int(unit)) + (mirrored ? "-left.bmp" : "-right.bmp"));
				gfx->nextFrame();
			}
		glob2test::retainFromProfile(".bmp");
	}

	GLOB2_TEST_CASE("spectators inspect building controls without editing their configuration", "[display][artifacts]")
	{
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 800, .height = 600,
		                                  .screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		REQUIRE(NET_Init());
		GameGUITouchHarness::spectatorBuildings();
		NET_Quit();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
		glob2test::retainFromProfile(".bmp");
	}

	GLOB2_TEST_CASE("building inventory shows material stocks below the mobile title", "[display][artifacts]")
	{
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 800, .height = 600,
		                                  .screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		REQUIRE(NET_Init());
		GameGUITouchHarness::inventory();
		NET_Quit();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
		glob2test::retainFromProfile(".bmp");
	}

	GLOB2_TEST_CASE("scaled gameplay dialog input is translated once", "[display]")
	{
		GameGUITouchHarness::scaledDialogInput();
	}

	GLOB2_TEST_CASE("unit taps have a zoom independent halo and show unit stats", "[display][artifacts]")
	{
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 800, .height = 600,
		                                  .screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		REQUIRE(NET_Init());
		GameGUITouchHarness::unitSelection();
		NET_Quit();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
		glob2test::retainFromProfile(".bmp");
	}
	GLOB2_TEST_CASE("a touch on or near a flag drags the flag; not the map", "[display]")
	{
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 800, .height = 600,
		                                  .screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		REQUIRE(NET_Init());
		GameGUITouchHarness::flagDragging();
		NET_Quit();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
	}
	GLOB2_TEST_CASE("touch scroll momentum on the map; the HUD palette and the editor", "[display]")
	{
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 800, .height = 600,
		                                  .screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		REQUIRE(NET_Init());
		GameGUITouchHarness::scrollPhysics();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
		GameGUITouchHarness::editorScrollPhysics();
		NET_Quit();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
	}
	TEST_CASE("bounded editor brush rails preserve header ownership and every visible size [display][artifacts]")
	{
		glob2test::ScopedEnvironment mobile("GLOB2_MOBILE_UI", "1");
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 568, .height = 320,
			.screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		GameGUITouchHarness::editorRailOwnership();
	}

	TEST_CASE("localized phone editor interactions preserve contextual properties [display][artifacts]")
	{
		glob2test::ScopedEnvironment mobile("GLOB2_MOBILE_UI", "1");
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 320, .height = 568,
			.screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		auto *strings = GAGCore::Toolkit::getStringTable();
		strings->setLang(strings->getLangCode("de"));
		GameGUITouchHarness::editorInteractions();
		glob2test::retainFromProfile(".bmp");
	}

	TEST_CASE("actual gameplay touch; toroidal pan; preview; confirmation; validation; cancellation and duplicate suppression [display][artifacts][writes-preferences]")
	{
		// Exercise the legacy mouse sidebar first, even on touch-capable hosts;
		// run() explicitly switches to the phone presentation for the touch cases.
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 800, .height = 600,
		                                  .screenFlags = GAGCore::GraphicContext::PORTABLEGPU};
		glob2test::HeadlessGlobals globals(options);
		REQUIRE(NET_Init());
		verifyTouchFontRaster();
		GameGUITouchHarness::run();
		NET_Quit();
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", "0", 1);
		glob2test::retainFromProfile(".bmp");
		std::puts("PASS: actual gameplay touch, toroidal pan, preview, confirmation, validation, "
				  "cancellation and duplicate suppression");
	}
}
