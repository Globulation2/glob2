// SPDX-License-Identifier: GPL-3.0-or-later

// The editor's live presentation (MapEditPresentation.h): phones and small
// windows get the tray, tablets and desktops the dock; resizing or rotating
// switches between them without committing unfinished strokes or losing the
// brush; a mouse wheel over the tray scrolls it and over the map zooms.

#include "EngineFixtures.h"
#include "MapEdit.h"
#include "MapEditPresentation.h"
#include "PhoneEditor.h"
#include "EditorDialogs.h"
#include <ui/Host.h>
#include <nlohmann/json.hpp>
#include "Race.h"
#include <InterfacePresentation.h>
#include <SDL3/SDL.h>
#ifdef HAVE_OPENGL
#include <SDL3/SDL_opengl.h>
#endif
#include <array>
#include <optional>
#include <sstream>
#include <cmath>
#include <string>
#include <vector>

namespace
{
using GAGCore::PresentationPreference;

GAGCore::ResolvedPresentation resolved(double width, double height, bool touch,
									   PresentationPreference preference = PresentationPreference::Automatic)
{
	GAGCore::InputCapabilities input;
	input.touch = touch;
	input.pointer = input.hover = !touch;
	return GAGCore::resolvePresentation(preference, {width, height, 1, {}, 0}, input);
}

// Process-wide presentation state and GLOB2_MOBILE_UI, restored on exit so
// other cases keep the legacy (unresolved) behaviour.
struct PresentationScope
{
	GAGCore::ViewportMetrics viewport = GAGCore::presentationViewport;
	GAGCore::InputCapabilities input = GAGCore::presentationInput;
	GAGCore::ResolvedPresentation state = GAGCore::presentationState;
	PresentationPreference preference = GAGCore::presentationPreference;
	double textScale = GAGCore::userTextScale;
	std::optional<std::string> mobile;
	PresentationScope()
	{
		if (const char *value = SDL_getenv_unsafe("GLOB2_MOBILE_UI"))
			mobile = value;
		glob2test::unsetEnv("GLOB2_MOBILE_UI");
		GAGCore::presentationPreference = PresentationPreference::Automatic;
	}
	~PresentationScope()
	{
		if (mobile)
			glob2test::setEnv("GLOB2_MOBILE_UI", mobile->c_str());
		else
			glob2test::unsetEnv("GLOB2_MOBILE_UI");
		GAGCore::presentationViewport = viewport;
		GAGCore::presentationInput = input;
		GAGCore::presentationState = state;
		GAGCore::presentationPreference = preference;
		GAGCore::userTextScale = textScale;
	}
	static void host(double width, double height, bool touch)
	{
		GAGCore::InputCapabilities input;
		input.touch = touch;
		input.pointer = input.hover = !touch;
		GAGCore::updatePresentation({width, height, 1, {}, 0}, input);
	}
};

const GAGGUI::ui::Node *findNode(const GAGGUI::ui::Node &node, const std::string &key)
{
	if (node.key == key)
		return &node;
	for (const auto &child : node.children)
		if (child)
			if (const auto *found = findNode(*child, key))
				return found;
	return nullptr;
}

void blank(MapEdit &editor)
{
	editor.game.map.setSize(5, 5, GRASS);
	editor.game.map.setGame(&editor.game);
	editor.game.addTeam();
	editor.game.teams[0]->race.loadDefault();
	for (int y = 0; y < 32; ++y)
		for (int x = 0; x < 32; ++x)
			editor.game.map.clearImmobileUnit(x, y);
	editor.viewportX = 0;
	editor.viewportY = 0;
	editor.updateCamera();
	editor.minimap.setMapSize(editor.game.map.getW(), editor.game.map.getH());
    editor.preparePresentation();
}
} // namespace

TEST_SUITE("EditorPresentation")
{
	TEST_CASE("software phones retain the tray with enlarged Filipino text [display][artifacts]")
	{
		PresentationScope scope;
		glob2test::setEnv("GLOB2_MOBILE_UI", "1");
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true,
			.width = 390, .height = 844, .screenFlags = 0};
		options.beforeLoad = [](GlobalContainer &globals) {
			globals.settings.language = "fil";
			globals.settings.setTextSizePercent(150);
		};
		glob2test::HeadlessGlobals globals(options);
		auto *gfx = globalContainer->gfx;
		REQUIRE(gfx->backendSwitchStatus().active == GAGCore::RendererBackend::Software);
		REQUIRE_FALSE(gfx->hasPortableRenderer());
		PresentationScope::host(390, 844, true);
		MapEdit editor;
		blank(editor);
		editor.beginEditing();
		REQUIRE(editor.usesPhone());
		CHECK(editor.dockWidth() == 0);
		auto &phone = *editor.phone;
		phone.chooseMode(0);
		phone.prepare();
		auto checkExposedGeometry = [&] {
			auto &host = phone.inspectionHost();
			auto check = [&](const std::string &key, GAGCore::ViewRect expected, int target) {
				CAPTURE(key);
				const auto exposed = host.bounds(key);
				CHECK(exposed.x == int(std::floor(expected.x)));
				CHECK(exposed.y == int(std::floor(expected.y)));
				CHECK(exposed.w == int(std::ceil(expected.x + expected.w)) - exposed.x);
				CHECK(exposed.h == int(std::ceil(expected.y + expected.h)) - exposed.y);
				CHECK(phone.hit({expected.x + expected.w / 2, expected.y + expected.h / 2}) == target);
			};
			const char *keys[] = {"menu", "team", "level", "selection"};
			for (int i = 0; i < 4; ++i)
				check(std::string("editor/") + keys[i], phone.headerButtons[i], -2 - i);
			for (int i = 0; i < phone.modeCount; ++i)
				check("tray/mode/" + std::to_string(i), phone.modeRect(i), -10 - i);
		};
		checkExposedGeometry();
		// Four narrow columns still split Koponan: balance three buttons above two.
		const double lineHeight = globalContainer->standardFont->getStringHeight("Ag") * gfx->textUnitsPerPoint();
		CHECK(phone.modeColumns == 3);
		CHECK(phone.modeBar.h >= 4 * lineHeight);
		const std::vector<std::vector<const char *>> words{{"Lupain"}, {"Mga", "likas", "na", "yaman"},
			{"Mga", "Gusali"}, {"Mga", "Bandila"}, {"Mga", "Koponan"}};
		for (int i = 0; i < 5; ++i)
		{
			const auto rect = phone.modeRect(i);
			for (const auto *word : words[i])
				CHECK(globalContainer->standardFont->getStringWidth(word) * gfx->textUnitsPerPoint() <= rect.w - 9 * gfx->logicalUnitsPerPoint());
			CHECK(phone.hit({rect.x + rect.w / 2, rect.y + rect.h / 2}) == -10 - i);
		}
		CHECK(phone.modeRect(3).w == phone.modeBar.w / 2);
		CHECK(phone.modeRect(4).x + phone.modeRect(4).w == phone.modeBar.x + phone.modeBar.w);
		CHECK(phone.content.y - phone.safe.y >= 2 * lineHeight + 8 * gfx->logicalUnitsPerPoint());
		CHECK(phone.cardBar.y >= phone.modeBar.y + phone.modeBar.h);
		CHECK(phone.content.y + phone.content.h <= phone.modeBar.y);
		CHECK(phone.mapButton().w >= globalContainer->standardFont->getStringWidth("Minimap") *
			gfx->textUnitsPerPoint() + 8 * gfx->logicalUnitsPerPoint());
		for (const char *terrain : {"lush_grass", "dry_grass", "dune_sand", "pale_sand"})
		{
			CAPTURE(terrain);
			editor.performAction(std::string("select terrain ") + terrain);
			CHECK(editor.currentBrushId() == std::string("terrain/") + terrain);
			phone.prepare();
			checkExposedGeometry();
			std::istringstream caption(phone.headerLabels()[2]);
			for (std::string word; caption >> word;)
				CHECK(globalContainer->standardFont->getStringWidth(word) * gfx->textUnitsPerPoint() <=
					phone.headerButtons[2].w - 9 * gfx->logicalUnitsPerPoint());
			for (int i = 0; i < 4; ++i)
			{
				const auto button = phone.headerButtons[i];
				CHECK(phone.hit({button.x + button.w / 2, button.y + button.h / 2}) == -2 - i);
			}
		}
		editor.performAction("select terrain grass");
		globalContainer->settings.setTextSizePercent(100);
		phone.prepare();
		checkExposedGeometry();
		CHECK(phone.modeColumns == 5);
		CHECK(phone.modeBar.h == 44 * gfx->logicalUnitsPerPoint());
		CHECK(phone.content.y - phone.safe.y == 48 * gfx->logicalUnitsPerPoint());
		for (int i = 0; i < 4; ++i)
		{
			CHECK(phone.headerButtons[i].x == doctest::Approx(phone.safe.x + i * phone.safe.w / 4));
			CHECK(phone.headerButtons[i].y == phone.safe.y);
			CHECK(phone.headerButtons[i].w == doctest::Approx(phone.safe.w / 4));
		}
		globalContainer->settings.setTextSizePercent(150);
		phone.prepare();
		const int grass = phone.rowOf("terrain/grass");
		REQUIRE(grass >= 0);
		const auto card = phone.rows[grass].rect;
		for (Uint32 type : {SDL_EVENT_MOUSE_BUTTON_DOWN, SDL_EVENT_MOUSE_BUTTON_UP})
		{
			SDL_Event event{};
			event.type = type;
			event.button.button = SDL_BUTTON_LEFT;
			event.button.which = 1;
			event.button.x = float(card.x + card.w / 2);
			event.button.y = float(card.y + card.h / 2);
			editor.advanceEditing({event}, 0);
		}
		CHECK(editor.currentBrushId() == "terrain/grass");
		gfx->setClipRect();
		editor.drawEditing();
		phone.peekOpen = true;
		editor.drawEditing();
		phone.peekOpen = false;
		editor.drawEditing();
		int x, y, width, height;
		gfx->getClipRect(&x, &y, &width, &height);
		CHECK(x == 0); CHECK(y == 0);
		CHECK(width == gfx->getW()); CHECK(height == gfx->getH());
		gfx->printScreen(glob2test::artifactDirFromWorkingDirectory() + "/filipino-software-editor-large.bmp");
		editor.drawEditing();
	}

#ifdef HAVE_OPENGL
	TEST_CASE("legacy GL phone labels retain visible clipped ink away from the origin [display][artifacts]")
	{
		PresentationScope scope;
		glob2test::setEnv("GLOB2_MOBILE_UI", "1");
		glob2test::GlobalsOptions options{.display = true, .loadStrings = true,
			.width = 390, .height = 844, .screenFlags = GAGCore::GraphicContext::USEGPU};
		options.beforeLoad = [](GlobalContainer &globals) {
			globals.settings.language = "fil";
			globals.settings.setTextSizePercent(150);
		};
		glob2test::HeadlessGlobals globals(options);
		auto *gfx = globalContainer->gfx;
		REQUIRE(gfx->backendSwitchStatus().active == GAGCore::RendererBackend::LegacyGL);
		gfx->setResponsiveViewport(true, 800, 600);
		PresentationScope::host(390, 844, true);
		MapEdit editor;
		blank(editor);
		editor.beginEditing();
		REQUIRE(editor.usesPhone());
		auto &phone = *editor.phone;
		const double unit = gfx->logicalUnitsPerPoint();
		const std::array<GAGCore::ViewRect, 2> boxes{{
			{120 * unit, 180 * unit, 160 * unit, 48 * unit},
			{110 * unit, 285 * unit, 52 * unit, 48 * unit}}};
		REQUIRE(globalContainer->standardFont->getStringWidth("Minimap") * gfx->textUnitsPerPoint() >
			boxes[1].w - 8 * unit); // This caption must actually reach the clip edge.
		gfx->setClipRect();
		gfx->drawFilledRect(0, 0, gfx->getW(), gfx->getH(), GAGCore::Color(0, 0, 0));
		phone.label(boxes[0], "Pumili");
		phone.label(boxes[1], "Minimap");
		GAGCore::Sprite::flushBatches(gfx);
		glFinish();
		GLint viewport[4]{};
		glGetIntegerv(GL_VIEWPORT, viewport);
		REQUIRE(viewport[2] > 0);
		REQUIRE(viewport[3] > 0);
		std::vector<unsigned char> pixels(std::size_t(viewport[2]) * viewport[3] * 4);
		glReadPixels(viewport[0], viewport[1], viewport[2], viewport[3], GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
		std::array<unsigned, 2> ink{};
		unsigned escapedInk = 0;
		for (int y = 0; y < viewport[3]; ++y)
			for (int x = 0; x < viewport[2]; ++x)
			{
				const auto offset = (std::size_t(y) * viewport[2] + x) * 4;
				if (pixels[offset] <= 30 && pixels[offset + 1] <= 30 && pixels[offset + 2] <= 30)
					continue;
				const GAGCore::ViewPoint point{(x + .5) * gfx->getW() / viewport[2],
					(viewport[3] - y - .5) * gfx->getH() / viewport[3]};
				bool inside = false;
				for (std::size_t i = 0; i < boxes.size(); ++i)
				{
					// One logical pixel tolerates drawable rounding at the scissor edge.
					const GAGCore::ViewRect clip{boxes[i].x + 4 * unit - 1, boxes[i].y - 1,
						boxes[i].w - 8 * unit + 2, boxes[i].h + 2};
					if (clip.contains(point)) { ++ink[i]; inside = true; }
				}
				if (!inside) ++escapedInk;
			}
		CHECK(ink[0] > 20);
		CHECK(ink[1] > 20);
		CHECK(escapedInk == 0);
		gfx->printScreen(glob2test::artifactDirFromWorkingDirectory() + "/filipino-legacy-phone-label-clipping.bmp");
		gfx->nextFrame();
	}
#endif

	TEST_CASE("the editor presentation table follows room and overrides")
	{
		struct Case
		{
			double width, height;
			bool touch;
			std::optional<PresentationPreference> forced;
			PresentationPreference preference;
			EditorPresentation expected;
		};
		const auto Phone = EditorPresentation::Phone, Dock = EditorPresentation::Dock;
		const auto Auto = PresentationPreference::Automatic, Compact = PresentationPreference::Compact,
				   Spacious = PresentationPreference::Spacious;
		const std::optional<PresentationPreference> none;
		const Case cases[] = {
			// Tablets and touch laptops dock; phones in either orientation use the tray.
			{1024, 768, true, none, Auto, Dock},
			{768, 1024, true, none, Auto, Phone},
			{1366, 768, true, none, Auto, Dock},
			{390, 844, true, none, Auto, Phone},
			{844, 390, true, none, Auto, Phone},
			{932, 430, true, none, Auto, Phone},
			// Pointer windows: the same room rule.
			{1280, 720, false, none, Auto, Dock},
			{1024, 600, false, none, Auto, Dock},
			{800, 600, false, none, Auto, Dock},
			{779, 600, false, none, Auto, Phone},
			{1024, 479, false, none, Auto, Phone},
			{640, 480, false, none, Auto, Phone},
			// The player's preference.
			{1024, 768, true, none, Compact, Phone},
			{1920, 1080, false, none, Compact, Phone},
			{700, 420, false, none, Spacious, Dock},
			{768, 1024, true, none, Spacious, Dock},
			{844, 390, true, none, Spacious, Phone},
			{600, 800, false, none, Spacious, Phone},
			// GLOB2_MOBILE_UI: 1 forces the tray, 0/touch-spacious the dock,
			// touch-auto the automatic rule regardless of the preference.
			{1920, 1080, false, Compact, Auto, Phone},
			{390, 844, true, Spacious, Auto, Dock},
			{390, 844, true, Spacious, Compact, Dock},
			{1024, 768, true, Auto, Compact, Dock},
			{844, 390, true, Auto, Spacious, Phone},
		};
		for (const auto &c : cases)
		{
			CAPTURE(c.width);
			CAPTURE(c.height);
			CAPTURE(c.touch);
			const auto choice =
				chooseEditorPresentation(resolved(c.width, c.height, c.touch, c.forced.value_or(c.preference)), c.forced,
										 c.preference);
			CHECK(choice.presentation == c.expected);
			CHECK(choice.touchTargets == c.touch);
		}
		// A touch-* override sizes dock targets for fingers on any host.
		CHECK(chooseEditorPresentation(resolved(1024, 768, false), PresentationPreference::Spacious,
									   PresentationPreference::Automatic, true)
				  .touchTargets);
		// Safe-area insets and the interface scale shrink the room.
		GAGCore::InputCapabilities touch{true, false, false, false};
		const auto inset = GAGCore::resolvePresentation(PresentationPreference::Automatic,
														{1024, 768, 1, {0, 0, 0, 300}, 0}, touch);
		CHECK(chooseEditorPresentation(inset, std::nullopt).presentation == EditorPresentation::Phone);
		const auto scaled =
			GAGCore::resolvePresentation(PresentationPreference::Automatic, {1280, 800, 2, {}, 0}, touch);
		CHECK(chooseEditorPresentation(scaled, std::nullopt).presentation == EditorPresentation::Phone);
	}

	TEST_CASE("live presentation follows the resolved host and GLOB2_MOBILE_UI")
	{
		PresentationScope scope;
		// Unresolved hosts keep the legacy rule: the tray only where forms adapt.
		GAGCore::presentationState = {};
		CHECK(currentEditorPresentation().presentation == EditorPresentation::Dock);
		PresentationScope::host(1024, 768, true);
		CHECK(currentEditorPresentation() == EditorPresentationChoice{EditorPresentation::Dock, true});
		PresentationScope::host(390, 844, true);
		CHECK(currentEditorPresentation().presentation == EditorPresentation::Phone);
		glob2test::setEnv("GLOB2_MOBILE_UI", "0");
		CHECK(currentEditorPresentation().presentation == EditorPresentation::Dock);
		glob2test::setEnv("GLOB2_MOBILE_UI", "1");
		PresentationScope::host(1920, 1080, false);
		CHECK(currentEditorPresentation().presentation == EditorPresentation::Phone);
		glob2test::setEnv("GLOB2_MOBILE_UI", "touch-spacious");
		CHECK(currentEditorPresentation() == EditorPresentationChoice{EditorPresentation::Dock, true});
		glob2test::unsetEnv("GLOB2_MOBILE_UI");
		GAGCore::presentationPreference = PresentationPreference::Compact;
		PresentationScope::host(1920, 1080, false);
		CHECK(currentEditorPresentation().presentation == EditorPresentation::Phone);
	}

	TEST_CASE("resizing mid-stroke switches presentation and keeps the brush [display]")
	{
		PresentationScope scope;
		glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{
			.display = true, .width = 1024, .height = 768, .screenFlags = GAGCore::GraphicContext::PORTABLEGPU});
		auto *gfx = globalContainer->gfx;
		REQUIRE(gfx->hasPortableRenderer());
		PresentationScope::host(1024, 768, true);
		MapEdit editor;
		blank(editor);
		editor.beginEditing();
		CHECK(editor.presentation() == EditorPresentation::Dock);
		CHECK_FALSE(editor.syncPresentation());
		CHECK(editor.wantsResponsiveViewport()); // Touch hosts keep point-sized layouts.
		editor.performAction("select resource wheat");
		REQUIRE(editor.currentBrushId() == "resource/wheat");
		const auto panel = editor.panelMode;
		editor.brush.setFigure(3);
		// A desktop stroke in progress.
		editor.mouseX = 200;
		editor.mouseY = 200;
		editor.performAction("terrain drag start");
		REQUIRE(editor.isDraggingTerrain);
		auto resize = [&](double width, double height, bool touch)
		{
			// What MapEditorScreen does when ScreenStack reports a new viewport.
			PresentationScope::host(width, height, touch);
			editor.suspendInput();
			editor.viewportResized(gfx->getW(), gfx->getH(), gfx->getW(), gfx->getH());
			editor.drawEditing();
		};
		resize(390, 844, true);
		CHECK(editor.presentation() == EditorPresentation::Phone);
		CHECK(editor.usesPhone());
		CHECK_FALSE(editor.isDraggingTerrain);
		CHECK(editor.lastPlacementX == -1);
		CHECK(editor.currentBrushId() == "resource/wheat");
		CHECK(editor.panelMode == panel);
		CHECK(editor.brush.getFigure() == 3);
		// A tray stroke in progress, then rotation.
		auto &phone = *editor.phone;
		phone.prepare();
		const auto checksum = editor.game.checkSum(nullptr, nullptr, nullptr, true);
		auto finger = [&](Uint32 type, GAGCore::ViewPoint p)
		{
			SDL_Event event{};
			event.type = type;
			event.tfinger.touchID = 31;
			event.tfinger.fingerID = 1;
			event.tfinger.timestamp = SDL_GetTicksNS();
			event.tfinger.x = float(p.x / gfx->getW());
			event.tfinger.y = float(p.y / gfx->getH());
			editor.advanceEditing({event}, 0);
		};
		const GAGCore::ViewPoint a{phone.content.x + phone.content.w / 3, phone.content.y + phone.content.h / 2};
		finger(SDL_EVENT_FINGER_DOWN, a);
		finger(SDL_EVENT_FINGER_MOTION, {a.x + 60, a.y});
		CHECK_FALSE(editor.phone->stroke.empty());
		resize(844, 390, true);
		REQUIRE(editor.usesPhone());
		CHECK(editor.phone->stroke.empty());
		finger(SDL_EVENT_FINGER_UP, {a.x + 60, a.y});
		CHECK(editor.game.checkSum(nullptr, nullptr, nullptr, true) == checksum);
		CHECK(editor.currentBrushId() == "resource/wheat");
		// Back to a pointer window: the dock, with the same brush.
		editor.phone->stroke.push_back(a); // Even a stray buffered point is dropped.
		resize(1280, 720, false);
		CHECK(editor.presentation() == EditorPresentation::Dock);
		CHECK_FALSE(editor.usesPhone());
		CHECK(editor.currentBrushId() == "resource/wheat");
		CHECK(editor.panelMode == panel);
		CHECK(editor.game.checkSum(nullptr, nullptr, nullptr, true) == checksum);
		CHECK_FALSE(editor.wantsResponsiveViewport());
		// A building selected on the dock stays selected on the tray.
		editor.performAction("switch to building view");
		const BrushEntry *first = nullptr;
		for (const auto &group : editor.brushCatalog())
			if (group.section == BrushSection::Buildings && !group.entries.empty() && !first)
				first = &group.entries.front();
		REQUIRE(first);
		const std::string building = first->id;
		editor.performAction(first->action);
		REQUIRE(editor.currentBrushId() == building);
		resize(390, 844, true);
		CHECK(editor.usesPhone());
		CHECK(editor.currentBrushId() == building);
		editor.phone->prepare();
		CHECK(editor.phone->paletteMode == 2);
		CHECK(editor.phone->rowOf(building) >= 0);
	}

	TEST_CASE("a small pointer window uses the tray and the wheel zooms over the map [display]")
	{
		PresentationScope scope;
		glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{
			.display = true, .width = 700, .height = 520, .screenFlags = GAGCore::GraphicContext::PORTABLEGPU});
		auto *gfx = globalContainer->gfx;
		REQUIRE(gfx->hasPortableRenderer());
		PresentationScope::host(gfx->getW(), gfx->getH(), false);
		MapEdit editor;
		blank(editor);
		editor.beginEditing();
		REQUIRE(editor.usesPhone());
		auto &phone = *editor.phone;
		phone.chooseMode(0);
		phone.prepare();
		REQUIRE(phone.maximum > 0);
		auto wheel = [&](GAGCore::ViewPoint p, float steps)
		{
			SDL_Event event{};
			event.type = SDL_EVENT_MOUSE_WHEEL;
			event.wheel.y = steps;
			event.wheel.direction = SDL_MOUSEWHEEL_NORMAL;
			event.wheel.mouse_x = float(p.x);
			event.wheel.mouse_y = float(p.y);
			editor.advanceEditing({event}, 0);
		};
		editor.updateCamera();
		const double zoom = editor.camera.zoom;
		wheel({phone.cardBar.x + phone.cardBar.w / 2, phone.cardBar.y + phone.cardBar.h / 2}, -2);
		CHECK(phone.offset > 0);
		CHECK(editor.camera.zoom == doctest::Approx(zoom));
		const double offset = phone.offset;
		wheel({phone.content.x + phone.content.w / 2, phone.content.y + phone.content.h / 2}, 1);
		CHECK(phone.offset == doctest::Approx(offset));
		CHECK(editor.camera.zoom > zoom);
		// A mouse click on a card selects it, in logical coordinates.
		phone.offset = 0;
		phone.prepare();
		const int grass = phone.rowOf("terrain/grass");
		REQUIRE(grass >= 0);
		const auto card = phone.rows[grass].rect;
		for (Uint32 type : {SDL_EVENT_MOUSE_BUTTON_DOWN, SDL_EVENT_MOUSE_BUTTON_UP})
		{
			SDL_Event event{};
			event.type = type;
			event.button.button = SDL_BUTTON_LEFT;
			event.button.which = 1;
			event.button.x = float(card.x + card.w / 2);
			event.button.y = float(card.y + card.h / 2);
			editor.advanceEditing({event}, 0);
		}
		CHECK(editor.currentBrushId() == "terrain/grass");
	}

	TEST_CASE("decision cards fit the phone tray presentation in both orientations [display][artifacts]")
	{
		for (const auto &[width, height] : {std::pair{390, 844}, std::pair{844, 390}})
		{
			CAPTURE(width);
			PresentationScope scope;
			glob2test::setEnv("GLOB2_MOBILE_UI", "1");
			glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.display = true,
																		 .loadStrings = true,
																		 .width = width,
																		 .height = height,
																		 .screenFlags = GAGCore::GraphicContext::PORTABLEGPU});
			auto *gfx = globalContainer->gfx;
			// MapEditorScreen's viewport policy, as the gallery applies it.
			gfx->setResponsiveViewport(true, 800, 600);
			PresentationScope::host(width, height, true);
			MapEdit editor;
			blank(editor);
			editor.beginEditing();
			REQUIRE(editor.usesPhone());
			editor.mapHasBeenModified();
			for (const char *action : {"open load screen", "quit editor"})
			{
				CAPTURE(action);
				editor.performAction(action);
				editor.advanceEditing({}, 1000);
				REQUIRE(editor.confirmation());
				editor.drawEditing();
				auto *card = editor.confirmation();
				REQUIRE(card->host().root());
				const GAGGUI::ui::Rect surface{0, 0, gfx->getW(), gfx->getH()};
				const double unit = gfx->logicalUnitsPerPoint();
				for (std::size_t i = 0; i < card->choiceCount(); ++i)
				{
					const auto *choice = findNode(*card->host().root(), "choice/" + std::to_string(i));
					REQUIRE(choice);
					const auto b = choice->bounds;
					CHECK(b.x >= surface.x);
					CHECK(b.y >= surface.y);
					CHECK(b.x + b.w <= surface.w);
					CHECK(b.y + b.h <= surface.h);
					CHECK(b.h >= int(40 * unit));
				}
				const std::string name = std::string("editor-card-") + (action[0] == 'o' ? "load-" : "quit-") +
										 std::to_string(width) + "x" + std::to_string(height) + ".bmp";
				gfx->printScreen(glob2test::artifactDirFromWorkingDirectory() + "/" + name);
				editor.drawEditing(); // The frame's end writes the capture.
				card->choose(card->cancelChoice());
				SDL_Event poll{};
				poll.type = SDL_EVENT_USER;
				editor.delegateMenu(poll);
				CHECK_FALSE(editor.confirmation());
			}
		}
	}
	TEST_CASE("compact controls share semantic and human selection scroll clipping and modal ownership [display]")
	{
		using namespace GAGGUI::ui;
		PresentationScope scope;
		glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{
			.display = true, .width = 700, .height = 520, .screenFlags = GAGCore::GraphicContext::PORTABLEGPU});
		PresentationScope::host(700, 520, false);
		MapEdit editor;
		blank(editor);
		editor.beginEditing();
		REQUIRE(editor.usesPhone());
		auto &phone = *editor.phone;
		auto dispatch = [&](const std::string &key, SemanticAction action)
		{
			auto &host = phone.inspectionHost();
			REQUIRE(host.find(key));
			std::string error;
			const bool applied = host.act(key, action, error);
			INFO(error);
			CHECK(applied);
		};
		dispatch("tray/mode/0", {ActionKind::Activate, {}});
		CHECK(phone.paletteMode == 0);
		// Browser consumers keep numeric tray keys and the tray's owning root,
		// while MCP inspects the complete compact surface in the same frame.
		const auto legacy = nlohmann::json::parse(diagnosticJSON(phone.browserControls()));
		CHECK(legacy.at("root").at("x") == int(phone.modeBar.x));
		CHECK(legacy.at("root").at("y") == int(phone.modeBar.y));
		CHECK(legacy.at("root").at("w") == int(phone.modeBar.w));
		CHECK(legacy.at("root").at("h") == int(phone.modeBar.h + phone.tray.h));
		CHECK_FALSE(legacy.at("controls").contains("editor/menu"));
		for (int i = 0; i < phone.modeCount; ++i)
		{
			const auto &control = legacy.at("controls").at("tray/mode/" + std::to_string(i));
			CHECK(control.at("label") == "");
		}
		for (const auto &row : phone.rows)
		{
			const auto &control = legacy.at("controls").at("tray/" + row.id);
			CHECK(control.at("x") == int(row.rect.x));
			CHECK(control.at("w") == int(row.rect.w));
			std::string label = row.lines.empty() ? std::string{} : row.lines.front();
			std::erase_if(label, [](unsigned char c) { return c < 0x20; });
			CHECK(control.at("label") == label);
		}
		REQUIRE(phone.inspectionHost().find("editor/map"));
		CHECK(phone.inspectionHost().find("editor/map")->supportedActions().empty());
		dispatch("tray/terrain/grass", {ActionKind::Activate, {}});
		CHECK(editor.currentBrushId() == "terrain/grass");
		// Human input uses the same model and activation path.
		phone.prepare();
		const auto grass = phone.inspectionHost().bounds("tray/terrain/grass").center();
		CHECK(phone.hit({double(grass.x), double(grass.y)}) == phone.rowOf("terrain/grass"));
		phone.clearTool();
		for (const auto type : {SDL_EVENT_MOUSE_BUTTON_DOWN, SDL_EVENT_MOUSE_BUTTON_UP})
		{
			SDL_Event event{};
			event.type = type;
			event.button.which = 1;
			event.button.button = SDL_BUTTON_LEFT;
			event.button.x = grass.x;
			event.button.y = grass.y;
			editor.advanceEditing({event}, SDL_GetTicks());
		}
		CHECK(editor.currentBrushId() == "terrain/grass");
		const auto before = phone.inspectionHost().inspect();
		dispatch("tray/scroll", {ActionKind::Scroll, 100000});
		CHECK(phone.offset == doctest::Approx(phone.maximum));
		std::string error;
		CHECK_FALSE(phone.inspectionHost().act("tray/terrain/grass", {ActionKind::Activate, {}}, error));
		CHECK_FALSE(error.empty());
		dispatch("tray/scroll", {ActionKind::Scroll, -100000});
		CHECK(phone.offset == 0);
		// Opening the map peek transfers ownership: palette targets disappear.
		dispatch("editor/show-minimap", {ActionKind::Activate, {}});
		CHECK(phone.peekOpen);
		CHECK_FALSE(phone.inspectionHost().find("tray/mode/0"));
		CHECK(phone.inspectionHost().find("editor/minimap"));
		dispatch("editor/peek/done", {ActionKind::Activate, {}});
		CHECK_FALSE(phone.peekOpen);
		dispatch("editor/menu", {ActionKind::Activate, {}});
		REQUIRE(editor.activeDialog());
		const auto owners = editor.inspectionHosts();
		REQUIRE(owners.size() == 1);
		CHECK(owners.front() == &editor.activeDialog()->host());
		CHECK(owners.front()->inspect().instance != before.instance);
	}

	TEST_CASE("compact semantic terrain cards use mainline brushes without experiment unlocks [display]")
	{
		using namespace GAGGUI::ui;
		PresentationScope scope;
		glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{
			.display = true, .width = 700, .height = 520, .screenFlags = GAGCore::GraphicContext::PORTABLEGPU});
		PresentationScope::host(700, 520, false);
		MapEdit editor;
		blank(editor);
		editor.beginEditing();
		REQUIRE(editor.usesPhone());
		auto &phone = *editor.phone;
		std::string error;
		REQUIRE(phone.inspectionHost().act("tray/mode/0", {ActionKind::Activate, {}}, error));
		phone.prepare(); // The mode action invalidates the layout; inspect its next frame.
		const int row = phone.rowOf("terrain/hedge");
		REQUIRE(row >= 0);
		const int reveal = int(std::ceil(phone.rows[row].rect.x - phone.cardBar.x));
		REQUIRE(phone.inspectionHost().act("tray/scroll", {ActionKind::Scroll, reveal}, error));
		auto &host = phone.inspectionHost();
		REQUIRE(host.find("tray/terrain/hedge"));
		CHECK(editor.game.gameHeader.getExperiments().empty());
		REQUIRE(host.act("tray/terrain/hedge", {ActionKind::Activate, {}}, error));
		CHECK(editor.currentBrushId() == "terrain/hedge");
		CHECK_FALSE(editor.activeDialog());
		CHECK(editor.game.gameHeader.getExperiments().empty());
	}

	TEST_CASE("compact inspector values use shared bindings and entity-specific keys [display]")
	{
		using namespace GAGGUI::ui;
		PresentationScope scope;
		glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{
			.display = true, .width = 700, .height = 520, .screenFlags = GAGCore::GraphicContext::PORTABLEGPU});
		PresentationScope::host(700, 520, false);
		MapEdit editor;
		blank(editor);
		editor.beginEditing();
		REQUIRE(editor.usesPhone());
		editor.performAction("set place building selection inn");
		editor.mouseX = 10 * 32 + 16;
		editor.mouseY = 10 * 32 + 16;
		editor.performAction("place building");
		editor.performAction("unselect");
		editor.performAction("select map building");
		REQUIRE(editor.panelMode == MapEdit::BuildingEditor);
		editor.preparePresentation();
		auto &phone = *editor.phone;
		auto &host = phone.inspectionHost();
		const std::string key = "editor/inspect/" + std::to_string(editor.selectedBuildingGID) + "/hp";
		REQUIRE(host.find(key));
		auto *value = editor.buildingHPScrollBox;
		const int hp = value->currentValue();
		REQUIRE(hp > 1);
		std::string error;
		CHECK(host.act(key, {ActionKind::SetValue, hp - 1}, error));
		editor.preparePresentation();
		CHECK(value->currentValue() == hp - 1);
		CHECK_FALSE(phone.inspectionHost().act(key, {ActionKind::SetValue, value->maximumValue() + 1}, error));
		CHECK(value->currentValue() == hp - 1);
		CHECK(phone.inspectionHost().act(key + "/plus", {ActionKind::Activate, {}}, error));
		editor.preparePresentation();
		CHECK(value->currentValue() == hp);
		// A recycled entity slot with identical presentation must still retire
		// its old target. Model a new allocation's generation without changing
		// any label, value or rectangle.
		auto command = semanticDispatch();
		const auto snapshot = phone.inspectionHost().inspect();
		command->surface = snapshot.instance;
		command->key = key;
		command->action = {ActionKind::SetValue, hp - 1};
		std::function<void(const std::vector<ControlSnapshot> &)> find = [&](const auto &nodes)
		{
			for (const auto &node : nodes)
			{
				if (node.key == key) command->revision = node.revision;
				find(node.children);
			}
		};
		find(snapshot.controls);
		REQUIRE(command->revision > 0);
		REQUIRE(editor.view.selectedBuilding);
		++editor.view.selectedBuilding->scriptIdentity;
		editor.game.invalidateObservation();
		editor.preparePresentation();
		CHECK(phone.inspectionHost().event(command->event()));
		CHECK_FALSE(command->error.empty());
		CHECK(value->currentValue() == hp);
		CHECK(phone.inspectionHost().act("editor/inspector/scroll", {ActionKind::Scroll, 100000}, error));
		CHECK(phone.inspectorScroll == doctest::Approx(phone.inspectorMaximum));
		CHECK(phone.inspectionHost().act("editor/inspector/close", {ActionKind::Activate, {}}, error));
		CHECK_FALSE(phone.inspectionHost().find(key));
	}

}
