# Trimmed background checksums

Implemented a smaller routine path following the original checksum budget. The worker callback now performs **37–57% fewer instructions than the original synchronous checksum** in the sampled local workloads. Whole-engine instruction counts remain within about 0.6% of the original. Native timings are broadly near the original budget, with enough variance that they do not establish a universal speedup.

## What changed

- Replace canonical packing and XXH64 with direct field XOR/rotate mixing. Retain the existing entity RNG fingerprints.
- Restore the original selected entity facts, relationship counts and attachment/target presence. Remove extra captured continuation fields, relationship identity walks, pending-project walks, authored building/rule walks and broad team-state walks. Preserve cheap unit/resource/terrain catalog fingerprints.
- Local/AI-only games skip map-cell checks. Remote sessions sample only the original captured map subset every 32 ticks: terrain vertices, resource values/may-grow, building/ground/air occupancy, forbidden/farm masks and referenced stock. No visibility, fertility, immobile, guard/clear or source-count expansion.
- Preserve remote replay coverage from recorded player types before playback substitutes AI_NONE controllers. This policy remains fixed for remote sessions.
- Delete the custom 64-bit hash implementation, map digest caches and configuration-prefix cache; remove the unused WordChecksum bulk API additions. The implementation shrinks from 414 lines plus its custom hash header to 187 lines.
- Keep worker execution, two-tick delivery, bounded slots/results and immediate input release. With no workers, compute immediately and delay only scalar delivery. No new snapshot payload is captured. Deep live-world checks remain explicit developer diagnostics.

This intentionally follows the original non-cryptographic mixing approach and its collision limitations. It does not reproduce the old checksum bytes: uncaptured state stays outside the routine tier, and the already-pending format 168 / protocol 72 / sim revision 67 boundary separates the new scheme. Deep diagnostic behavior is unchanged.

## Callgrind

Optimized release objects, with checksum/headless copies rebuilt using `-O3 -g` and relinked without stripping. Only artifact source copies contain warmup-boundary Valgrind start/stop requests; production has no Valgrind dependency. Serial controls avoid worker-spin instruction noise. These are instruction counts (Ir), not elapsed time or cycles. Small/arena early windows: 128 total / 32 warmup; later: 1152 total / 1024 warmup. Large late-game window: 3712 total / 3584 warmup. Final drain is included; slight boundary-sample shifts remain. Full commands, compiler/link arguments, copied source, raw profiles and annotations are retained.

| Workload/window | Original checksum Ir | Trimmed checksum Ir | Reduction | Whole-engine Ir change |
| --- | ---: | ---: | ---: | ---: |
| Small / 2 teams / early | 714,070 | 352,800 | 50.6% | +0.10% |
| Small / 2 teams / late | 1,412,106 | 839,016 | 40.6% | +0.48% |
| Arena / 11 teams / early | 4,928,939 | 2,126,538 | 56.9% | -0.09% |
| Arena / 11 teams / late | 7,891,705 | 3,811,284 | 51.7% | -0.61% |
| Large / 4 teams / late-game | 4,838,820 | 3,067,958 | 36.6% | -0.55% |

[callgrind-summary.json](callgrind-summary.json) holds the exact profile locations. The previous implementation expanded map coverage in local games and changed the mixer; it was not simply an offload of the old workload. That expansion is removed here. The original still covered some live state absent from snapshots, so the compared checksum functions are not identical coverage.

## Native release timing

72 sequential runs: three balanced-order repetitions × four workloads × 1/4 participants × original/previous/trimmed. Original is the unchanged release binary from HEAD 987c953698bb3f0bfd1078184773075ba3313091. Previous is the retained schema 2 release executable. Binary/source hashes are in [environment.json](environment.json). No builds, tests or profilers ran concurrently with native timing. CPU sums all threads and excludes warmup; elapsed includes warmup/teardown. No deep diagnostics, recording or compute telemetry.

All compilation, profiling, game tests and timing used CPUs **9–15 and 25–31**. [Observed thread affinity](observed-affinity.json) confirms the running process threads stayed there. Governor remained schedutil. Shared package/cache/memory effects from other machine activity remain possible. Small/large 4096 total / 512 warmup; arena 2048 / 256; scripted 512 / 64. Three repetitions leave substantial uncertainty; [summary.json](summary.json) includes ranges and approximate paired log-ratio 95% t intervals.

### Owner plus three workers: three-run medians

| Workload | Original CPU µs/tick | Previous snapshot CPU | Trimmed CPU | CPU vs original | Elapsed vs original |
| --- | ---: | ---: | ---: | ---: | ---: |
| Small / 2 teams | 177.95 | 181.29 | 175.94 | -1.1% | -4.1% |
| Large / 4 teams | 338.76 | 353.37 | 358.32 | +5.8% | +5.0% |
| Arena / 11 teams | 1813.80 | 1765.98 | 1825.53 | +0.6% | -2.3% |
| Scripted / 2 teams | 13035.39 | 12462.53 | 12368.28 | -5.1% | -4.0% |

The initial large/four-worker median suggested +5.8%CPU. We retained those samples and ran ten more matched old/new pairs. Across **all 13 pairs**, the paired geometric-mean difference is **+0.54%**, with an approximate 95% interval of **−3.64% to +4.91%**. The ten new pairs alone averaged −0.74%. This does not establish a repeatable regression or speedup. See [large-combined.json](large-combined.json) and [large-pairs/measurements.json](large-pairs/measurements.json). The later-game large Callgrind sample also performs less checksum and whole-engine work.

### Serial control: three-run medians

| Workload | Original CPU µs/tick | Previous snapshot CPU | Trimmed CPU | CPU vs original |
| --- | ---: | ---: | ---: | ---: |
| Small / 2 teams | 99.25 | 103.39 | 93.99 | -5.3% |
| Large / 4 teams | 258.38 | 267.61 | 258.97 | +0.2% |
| Arena / 11 teams | 1670.87 | 1695.56 | 1676.27 | +0.3% |
| Scripted / 2 teams | 10894.46 | 10456.88 | 10315.66 | -5.3% |

## Verification

- [14 focused cases](tests-snapshot/results.xml) pass: original coverage/exclusions, map policy and projections, padding/address independence, stock-slot normalization, save/load, live-world/direct reference equivalence, changing work-slot data, missing/fallback metadata, failure propagation and worker deadline behavior.
- [172 broader cases](tests-integration/results.xml) pass: executor, snapshot/read phase, replay and acceptance boundaries, networking/reload/pauses/hostile orders, and JavaScript/save compatibility. Golden match regenerated and then verified. [Sim revision guard](sim-revision.log) passes.
- [Worker equivalence](worker-delivery/4/verified.json): exact routine/deep traces, saves and replay bytes match at 1/2/4 participants. All 258 four-participant checksum callbacks ran on worker IDs 1/2/3, none on owner 0.
- [Full deep equivalence](deep-equivalence.log): every deep world hash and detailed team/unit/building checksum field matches the original for 8192 small, 8192 large, 4096 arena and 1024 scripted ticks.
- [JavaScript corpus](javascript.log): both complete frozen profiles, exact 1/4-worker save/replay bytes and six saved continuations pass.
- Regenerated browser replay fixture and [local playback](browser-playback/results.xml) pass 1500 ticks. [Remote replay playback](remote-playback/results.xml) separately passes, exercising preserved map-checksum policy after controller substitution.
- `git diff --check` passes. Save floor 58 remains supported. Runtime behavior has not been verified on Windows/macOS/mobile or actual browser engines; graphical FPS, gameplay feel and packaging were not tested. Evidence applies to the current working tree on the recorded HEAD. Fetched master 486a2230a4ddb257ba9dee34d3aace05f2260d6f was not merged into this worktree.

