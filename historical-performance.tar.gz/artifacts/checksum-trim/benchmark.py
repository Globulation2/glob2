from pathlib import Path
import runpy,json,statistics
b=runpy.run_path('artifacts/checksum-performance/benchmark.py')
out=Path.cwd()/'artifacts/checksum-trim/native';out.mkdir(exist_ok=True)
b['run'].__globals__['OUT']=out
b['BINS']['previous']=Path.cwd()/'artifacts/checksum-callgrind/glob2-final'
rows=[]
for rep in range(3):
 for scenario,ticks,warmup in [('small2',4096,512),('large4',4096,512),('arena11',2048,256),('scripted2',512,64)]:
  for workers in (1,4):
   for version in (('before','previous','after'),('after','before','previous'),('previous','after','before'))[rep]:
    rows.append(b['run'](scenario,version,workers,rep,ticks,warmup))
(out/'measurements.json').write_text(json.dumps(rows,indent=2)+'\n')
for scenario in b['SCENARIOS']:
 for workers in (1,4):
  print('SUMMARY',scenario,workers,{v:statistics.median(r['cpu_us_per_tick'] for r in rows if r['scenario']==scenario and r['workers']==workers and r['version']==v) for v in ('before','previous','after')},flush=True)
