from pathlib import Path
import runpy,json,statistics,math
b=runpy.run_path('artifacts/checksum-performance/benchmark.py')
out=Path.cwd()/'artifacts/checksum-trim/large-pairs';out.mkdir(exist_ok=True)
b['run'].__globals__['OUT']=out
rows=[]
for rep in range(10):
 for version in (('before','after') if rep%2==0 else ('after','before')):
  rows.append(b['run']('large4',version,4,rep,4096,512))
(out/'measurements.json').write_text(json.dumps(rows,indent=2)+'\n')
a=[r['cpu_us_per_tick'] for r in rows if r['version']=='after'];before=[r['cpu_us_per_tick'] for r in rows if r['version']=='before']
logs=[math.log(x/y) for x,y in zip(a,before)];m=statistics.mean(logs);delta=2.262157*statistics.stdev(logs)/math.sqrt(10)
print('PAIRED CPU',100*math.expm1(m),'95%',[100*math.expm1(m-delta),100*math.expm1(m+delta)],flush=True)
