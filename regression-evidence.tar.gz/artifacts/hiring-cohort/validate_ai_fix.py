from pathlib import Path
import subprocess,json,shlex,os,hashlib
p=Path(__file__).resolve().parent;root=Path.cwd();out=p/'ai-fix-validation';out.mkdir(exist_ok=True)
database=json.load(open(root/'build/linux/client/release/dev-linker-auto/compile_commands.json'));e=next(e for e in database if str(e['file']).endswith('src/ai/nicowar/Attack.cpp'));args=e.get('arguments') or shlex.split(e['command']);obj=args[args.index('-o')+1];args[args.index('-o')+1]=str(out/'Attack-fixed.o');index=next(i for i,a in enumerate(args) if a.endswith('src/ai/nicowar/Attack.cpp'));args[index]=str(p/'Attack-fixed.cpp');subprocess.run(args,check=True)
link=json.load(open(p/'link-command-private.json'));link=[a for a in link if a!='-s'];link=[str(out/'Attack-fixed.o') if a==obj else a for a in link];link[link.index('-o')+1]=str(out/'glob2-cohort-ai-fixed');subprocess.run(link,check=True)
(p/'ai-fix-validation-commands.json').write_text(json.dumps({'compile':args,'link':link},indent=2))
j=next(j for j in json.load(open(p/'manifest.json'))['games'] if j['id']=='river-nicowar-019');records=[]
for n in [1,4]:
 env=os.environ.copy();env.update(SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='dummy',GLOB2_ISOLATED_LIVE_HIRING='1',GLOB2_ISOLATED_TRACE='1');dest=out/f'cached-{n}'
 cmd=['prlimit','--as=4294967296','--cpu=180','--',str(out/'glob2-cohort-ai-fixed'),'game','run','--map-file',str(root/j['map']),'--game-seed',str(j['game_seed']),'--ticks','32768','--benchmark-warmup','0','--compute-threads',str(n),'--gpu','off','--output-dir',str(dest),'--hiring-schedule','4:4:128:combined','--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds','--hiring-execution','pool']
 for ai in j['players']:cmd+=['--player',ai]
 with (out/f'cached-{n}.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 row={'participants':n,'command':cmd,'returncode':r.returncode,'diagnostic_only':True};assert r.returncode==0
 result=json.load(open(dest/'result.json'));row['ticks']=result['ticks'];trace=(dest/'world.checksums').read_bytes();row['trace_sha256']=hashlib.sha256(trace).hexdigest();assert len(trace.splitlines())==result['ticks'];records.append(row)
assert records[0]['trace_sha256']==records[1]['trace_sha256']
(out/'verification.json').write_text(json.dumps({'passed':True,'scope':'Isolated cached-consumer regression over original cohort runtime, only tracked Attack.cpp replaced. Separate diagnostics, not cohort replacements or clean production build.','source_sha256':hashlib.sha256((p/'Attack-fixed.cpp').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((out/'glob2-cohort-ai-fixed').read_bytes()).hexdigest(),'runs':records},indent=2));print('Fixed failing-seed validation passed',flush=True)
