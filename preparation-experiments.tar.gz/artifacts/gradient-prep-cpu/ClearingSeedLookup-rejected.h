// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "field/GradientPreparationRules.h"
#include "field/GradientConstants.h"
#include <array>

namespace gradient_preparation
{
// Enumerate the generated integer predicate's Boolean inputs once. Forbidden
// paint is handled by the caller; an open placeholder defers terrain lookup.
inline constexpr auto clearingSeedLookup = []
{
	std::array<std::array<std::uint16_t, 256>, 2> result{};
	for (unsigned farm = 0; farm < 2; ++farm)
		for (unsigned key = 0; key < 256; ++key)
			result[farm][key] =
				std::uint16_t(rules::clearSeed(0, key & 16, key & 1, key & 32, GRADIENT_UNREACHABLE,
											   key & 4, key & 8, key & 64, key & 128, farm));
	return result;
}();
} // namespace gradient_preparation
