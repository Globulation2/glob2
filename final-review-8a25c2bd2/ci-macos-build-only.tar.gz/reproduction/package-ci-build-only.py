#!/usr/bin/env python3
"""Package final CI build evidence without relabeling virtual-merge checkout bytes."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
FINAL = ROOT / 'artifacts/rebase-validation/final'
OUTPUT = FINAL / 'package-staging'
INTEGRATED = Path('/tmp/glob2-pr478-merge-final')
sys.path.insert(0, str(INTEGRATED / 'test'))
from build_provenance import source_identity
HEAD = '53d16aa37ae35748bf5b1458f79d0eba55fb3ab5'
MERGE = '41fd3a584a4ede4c47101a0000c5c83cc72d0fc7'
SOURCE_HASH = '60f140b19fbb3bd5dd2a82433435b911fb4b8f7575062d58d1df330c999a80b4'
p = argparse.ArgumentParser()
p.add_argument('--lane', required=True, choices=('macos', 'android'))
a = p.parse_args()


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def guard():
    s = source_identity(INTEGRATED)
    assert s['revision'] == HEAD and s['sourceTreeSha256'] == SOURCE_HASH, s
    assert s['dirty'] is False and s['sourceStatus'] == [], s


guard()
head = json.loads((FINAL / 'ci-final-head-commit.json').read_text())
merge = json.loads((FINAL / 'ci-final-pr-merge-commit.json').read_text())
assert head['sha'] == HEAD and merge['sha'] == MERGE
assert HEAD in [parent['sha'] for parent in merge['parents']]
assert head['commit']['tree']['sha'] == merge['commit']['tree']['sha']
name = 'ci-' + a.lane + '-build-only'
status = json.loads((FINAL / (name + '-status.json')).read_text())
assert status['headSha'] == HEAD and status['status'] == 'completed' and status['conclusion'] == 'success'
logs = FINAL / (name + '.log')
text = logs.read_text()
assert MERGE in text and 'HEAD is now at 41fd3a5' in text
artifacts = json.loads((FINAL / (name + '-artifacts.json')).read_text())['artifacts']
manifest = {'headRevision': HEAD, 'ciActualCheckoutRevision': MERGE,
            'headAndCheckoutGitTree': head['commit']['tree']['sha'],
            'associatedNormalizedSourceTreeSha256': SOURCE_HASH,
            'sourceAssociation': 'Logs show actual virtual-merge checkout41fd; GitHub commit API shows its complete Git tree equals53d. Local clean53d source identity supplies the matching normalized tree hash. Checkout revision is retained, not relabeled.',
            'workflowRunId': status['databaseId'], 'workflowRunUrl': status['url'],
            'status': 'BUILD ONLY', 'buildConclusion': 'success',
            'sharedJavaScriptCorpusExecuted': False, 'determinismAcceptance': False,
            'physicalDeviceAcceptance': False, 'storePublication': False,
            'jobs': status['jobs'], 'publishedArtifacts': artifacts,
            'publishedArtifactDigestsAreZipDigests': True,
            'uploadedExecutableArchivesDuplicated': False,
            'directCompiledProducerProvenanceAvailable': False}
if a.lane == 'macos':
    assert not artifacts
    assert any(j['name'] == 'Sign and upload to App Store Connect' and j['conclusion'] == 'skipped' for j in status['jobs'])
    manifest.update(validationDetail='Successful production build and map-generator CLI listing smoke only. Sandbox packaging, signing and App Store upload skipped.',
                    executableSha256=None,
                    executableDigestLimitation='Run uploaded no executable artifacts and printed no executable digest.',
                    compilerVersionLimitation='No compiler --version output; exact compiler drivers, flags, Xcode/runner-image lines and workflow retained in logs/config.')
else:
    assert len(status['jobs']) == 3 and all(j['conclusion'] == 'success' for j in status['jobs'])
    manifest['validationDetail'] = 'All three unsigned release APK builds/package checks passed. x86_64 workflow also performs its ordinary APK emulator smoke; the shared JavaScript corpus and physical-device acceptance are not executed by this workflow.'
    manifest['diagnosticZipDigestsVerified'] = []
    for artifact in artifacts:
        if artifact['name'].endswith('-diagnostics'):
            abi = artifact['name'][len('android-'):-len('-diagnostics')]
            zip_path = FINAL / ('ci-android-' + abi + '-diagnostics.zip')
            assert 'sha256:' + sha(zip_path) == artifact['digest'], zip_path
            manifest['diagnosticZipDigestsVerified'].append({'artifactId': artifact['id'], 'sha256': sha(zip_path)})
    assert len(manifest['diagnosticZipDigestsVerified']) == 3
clean = re.sub(r'\x1b\[[0-9;]*m', '', text)
compile_lines = [line for line in clean.splitlines() if re.search(r'\b(?:gcc|g\+\+|clang(?:\+\+)?|[^ ]+-clang\+\+) -o ', line)]
config = {'compilerCommandsObserved': compile_lines,
          'runnerAndToolVersionLines': [line for line in clean.splitlines() if any(token in line for token in ('Runner Image', 'Image:', 'Included Software:', 'Xcode ', 'Build version ', 'clang version', 'xcodebuild -version'))],
          'workflowPath': '.github/workflows/' + ('mac-app-store.yml' if a.lane == 'macos' else 'mobile.yml'),
          'directCompiledProducerProvenanceAvailable': False}
config_path = FINAL / (name + '-config.json')
config_path.write_text(json.dumps(config, indent=2) + '\n')
manifest_path = OUTPUT / (name + '.package-manifest.json')
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
members = {}


def include(path, arc):
    assert path.is_file() and not path.is_symlink(), path
    arc = str(arc)
    assert arc not in members, arc
    members[arc] = path


for path in [manifest_path, config_path, logs,
             FINAL / (name + '-status.json'), FINAL / (name + '-artifacts.json'),
             FINAL / 'ci-final-head-commit.json', FINAL / 'ci-final-pr-merge-commit.json']:
    include(path, path.name)
include(INTEGRATED / config['workflowPath'], 'workflow.yml')
include(Path(__file__).resolve(), 'reproduction/package-ci-build-only.py')
include(INTEGRATED / 'test/build_provenance.py', 'reproduction/build_provenance.py')
if a.lane == 'android':
    for path in sorted((FINAL / 'ci-android-build-only-diagnostics').rglob('*')):
        if path.is_file():
            include(path, path.relative_to(FINAL))
    for path in sorted(FINAL.glob('ci-android-*-diagnostics.zip')):
        include(path, path.name)
original = {arc: {'repositoryPath': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
            for arc, path in sorted(members.items())}
archive = OUTPUT / (name + '.tar.gz')
with tarfile.open(archive, 'w:gz') as f:
    for arc, path in sorted(members.items()):
        f.add(path, arcname=arc, recursive=False)
assert archive.stat().st_size < 95 * 1024 * 1024
with tarfile.open(archive, 'r:gz') as f:
    assert len(f.getmembers()) == len(members)
    for item in f.getmembers():
        assert item.isfile() and item.name in members
        h = hashlib.sha256()
        data = f.extractfile(item)
        for block in iter(lambda: data.read(1024 * 1024), b''):
            h.update(block)
        assert h.hexdigest() == original[item.name]['sha256'], item.name
        assert item.size == original[item.name]['bytes'], item.name
        assert sha(members[item.name]) == original[item.name]['sha256'], item.name
guard()
proof = {'headRevision': HEAD, 'ciActualCheckoutRevision': MERGE,
         'associatedNormalizedSourceTreeSha256': SOURCE_HASH,
         'status': 'BUILD ONLY', 'physicalDeviceAcceptance': False, 'storePublication': False,
         'archive': archive.name, 'archiveBytes': archive.stat().st_size,
         'archiveSha256': sha(archive), 'verifiedFileCount': len(members), 'files': original}
(OUTPUT / (name + '.files.json')).write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({key: proof[key] for key in ('archive', 'archiveBytes', 'archiveSha256', 'verifiedFileCount')}))
