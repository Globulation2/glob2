const path = require('node:path');
const config = require('/workspace/browser/playwright.config.js');
module.exports = {...config,
  testDir: '/workspace/browser/tests',
  outputDir: '/workspace/artifacts/firefox-therig/playwright-results',
  reporter: [['list'],['html',{outputFolder:'/workspace/artifacts/firefox-therig/playwright-report',open:'never'}]],
};
