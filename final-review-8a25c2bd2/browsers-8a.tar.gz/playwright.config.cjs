const base = require("/Users/bradley/.codex/worktrees/d912/glob2/browser/playwright.config.js");
module.exports = {...base, testDir: "/Users/bradley/.codex/worktrees/d912/glob2/browser/tests",
 outputDir: "/Users/bradley/.codex/worktrees/d912/glob2/artifacts/rebase-validation/final/browser-playwright-results",
 reporter: [['list'], ['html', {outputFolder: "/Users/bradley/.codex/worktrees/d912/glob2/artifacts/rebase-validation/final/browser-playwright-report", open: 'never'}]],
};
