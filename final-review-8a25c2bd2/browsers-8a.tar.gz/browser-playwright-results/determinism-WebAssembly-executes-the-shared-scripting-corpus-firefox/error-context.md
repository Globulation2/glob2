# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: determinism.spec.js >> WebAssembly executes the shared scripting corpus
- Location: tests/determinism.spec.js:59:1

# Error details

```
Test timeout of 600000ms exceeded.
```

```
TimeoutError: page.waitForFunction: Timeout 550000ms exceeded.
```

# Test source

```ts
  4   | const crypto = require('node:crypto');
  5   | 
  6   | // Run the compiled engine with the same fixture and orders as the native CI
  7   | // lanes. A minimal host supplies CLI arguments without changing the game shell.
  8   | test('WebAssembly produces a complete per-tick simulation trace', async ({page}, info) => {
  9   |   const root = path.resolve(__dirname, '../..');
  10  |   const fixture = fs.readFileSync(path.join(root, 'games/cross-replay.game.gz'));
  11  |   await page.route('**/determinism.html', route => route.fulfill({
  12  |     contentType: 'text/html',
  13  |     body: `<!doctype html><canvas id="canvas"></canvas><script>
  14  |       window.engineLog = [];
  15  |       var Module = {
  16  |         noInitialRun: true,
  17  |         canvas: document.getElementById('canvas'),
  18  |         print: message => engineLog.push(String(message)),
  19  |         printErr: message => engineLog.push(String(message)),
  20  |         preRun: [function() {
  21  |           ENV.GLOB2_REPLAY_PATH = '/tmp/wasm.replay';
  22  |           ENV.GLOB2_CHECKSUM_SIDECAR = '1';
  23  |           FS.writeFile('/tmp/initial.game.gz', Uint8Array.from(atob('${fixture.toString('base64')}'), c => c.charCodeAt(0)));
  24  |         }],
  25  |         onRuntimeInitialized() {
  26  |           Module.callMain(['--nox', '/tmp/initial.game.gz', '1500', '1']);
  27  |           // Avoid millions of individually serialized Playwright values.
  28  |           // Chunk the conversion so large traces do not overflow the call stack.
  29  |           const bytes = FS.readFile('/tmp/wasm.replay.checksums');
  30  |           let binary = '';
  31  |           for (let offset = 0; offset < bytes.length; offset += 32768) {
  32  |             binary += String.fromCharCode(...bytes.subarray(offset, offset + 32768));
  33  |           }
  34  |           window.simulationTrace = btoa(binary);
  35  |         }
  36  |       };
  37  |     </script><script src="/index.js"></script>`,
  38  |   }));
  39  |   await page.goto('/determinism.html');
  40  |   await page.waitForFunction(() => typeof window.simulationTrace === 'string');
  41  |   const trace = Buffer.from(await page.evaluate(() => window.simulationTrace), 'base64');
  42  |   expect(trace.length).toBeGreaterThan(1000);
  43  |   fs.mkdirSync(info.outputDir, {recursive: true});
  44  |   fs.writeFileSync(info.outputPath('wasm.replay.checksums'), trace);
  45  |   const output = path.join(root, 'artifacts/browser-determinism/wasm');
  46  |   fs.mkdirSync(output, {recursive: true});
  47  |   fs.writeFileSync(path.join(output, 'wasm.replay.checksums'), trace);
  48  |   fs.writeFileSync(path.join(output, 'run.log'), (await page.evaluate(() => window.engineLog)).join('\n'));
  49  |   fs.writeFileSync(path.join(output, 'manifest.json'), JSON.stringify({
  50  |     fixture: 'games/cross-replay.game.gz', seed: 42, ticks: 1500,
  51  |     fixture_sha256: crypto.createHash('sha256').update(fixture).digest('hex'),
  52  |     trace_sha256: crypto.createHash('sha256').update(trace).digest('hex'),
  53  |   }, null, 2) + '\n');
  54  | });
  55  | 
  56  | // The same production-runtime cases and realistic engine observations used by
  57  | // desktop and mobile harnesses. Golden comparisons occur inside C++, not in a
  58  | // JavaScript reimplementation of the engine or its math.
  59  | test('WebAssembly executes the shared scripting corpus', async ({page}, info) => {
  60  |   test.setTimeout(600000);
  61  |   const root = path.resolve(__dirname, '../..');
  62  |   const output=path.join(root,'artifacts/browser-determinism/script-corpus',info.project.name);
  63  |   // Remove only this case's previous exports, so a new successful manifest
  64  |   // cannot accidentally certify artifacts left by an earlier execution.
  65  |   fs.rmSync(output,{recursive:true,force:true});
  66  |   fs.mkdirSync(output,{recursive:true});
  67  |   const progress=[];
  68  |   page.on('console',message=>{progress.push(message.text());
  69  |     fs.appendFileSync(path.join(output,'progress.log'),message.text()+'\n');});
  70  |   page.on('pageerror',error=>{progress.push(String(error));
  71  |     fs.appendFileSync(path.join(output,'progress.log'),String(error)+'\n');});
  72  |   await page.route('**/script-corpus.html', route => route.fulfill({contentType:'text/html', body:`
  73  |     <!doctype html><canvas id="canvas"></canvas><script>
  74  |     window.engineLog=[]; window.corpusExit=null;
  75  |     var Module={noInitialRun:true,canvas:document.getElementById('canvas'),
  76  |       print:m=>{engineLog.push(String(m));console.log(String(m));},
  77  |       printErr:m=>{engineLog.push(String(m));console.error(String(m));},
  78  |       onExit:code=>window.corpusExit=code,
  79  |       onAbort:reason=>{window.corpusError=String(reason);window.corpusDone=true;},
  80  |       preRun:[()=>{
  81  |         FS.mkdirTree('/evidence/profile');
  82  |         ENV.GLOB2_TEST_SOURCE_ROOT='/'; ENV.GLOB2_USER_DATA_DIR='/evidence/profile';
  83  |         ENV.GLOB2_TEST_ARTIFACTS_ROOT='/evidence/corpus';
  84  |       }],
  85  |       onRuntimeInitialized(){
  86  |         try { const result=Module.callMain(['--test-suite=JavaScript*','--reporters=junit','--out=/evidence/tests.xml']);
  87  |           if(window.corpusExit===null) window.corpusExit=result??0;
  88  |         } catch(error){window.corpusError=String(error);}
  89  |         const files={};
  90  |         function collect(directory){for(const name of FS.readdir(directory)){
  91  |           if(name==='.'||name==='..'||name==='profile')continue;
  92  |           const file=directory+'/'+name;
  93  |           if(FS.isDir(FS.stat(file).mode)){collect(file);continue;}
  94  |           const bytes=FS.readFile(file); let binary='';
  95  |           for(let offset=0;offset<bytes.length;offset+=32768)
  96  |             binary+=String.fromCharCode(...bytes.subarray(offset,offset+32768));
  97  |           files[file.substring('/evidence/'.length)]=btoa(binary);
  98  |         }}
  99  |         collect('/evidence');window.corpusFiles=files;window.corpusDone=true;
  100 |       }};
  101 |     </script><script src="/script-tests.js"></script>`}));
  102 |   await page.goto('/script-corpus.html');
  103 |   let waitError;
> 104 |   try {await page.waitForFunction(()=>window.corpusDone===true,null,{timeout:550000});}
      |                   ^ TimeoutError: page.waitForFunction: Timeout 550000ms exceeded.
  105 |   catch(error){waitError=error;}
  106 |   // Retain partial logs and any exported data before reporting a timeout.
  107 |   // An unresponsive page must not prevent the host from retaining its evidence.
  108 |   let collectionTimer;
  109 |   const result=await Promise.race([
  110 |     page.evaluate(()=>({exit:window.corpusExit,error:window.corpusError,
  111 |       files:window.corpusFiles||{},log:window.engineLog})).catch(error=>
  112 |         ({exit:null,error:String(error),files:{},log:progress})),
  113 |     new Promise(resolve=>{collectionTimer=setTimeout(()=>resolve({exit:null,
  114 |       error:'Timed out collecting page evidence',files:{},log:progress}),waitError?5000:60000);})]);
  115 |   clearTimeout(collectionTimer);
  116 |   for(const [relative,base64] of Object.entries(result.files)){
  117 |     const destination=path.join(output,relative);
  118 |     fs.mkdirSync(path.dirname(destination),{recursive:true});
  119 |     fs.writeFileSync(destination,Buffer.from(base64,'base64'));
  120 |   }
  121 |   fs.writeFileSync(path.join(output,'run.log'),result.log.join('\n'));
  122 |   const source=JSON.parse(require('node:child_process').execFileSync('python3',
  123 |     [path.join(root,'test/build_provenance.py')],{cwd:root,encoding:'utf8'}));
  124 |   const hash=file=>require('node:crypto').createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  125 |   const build=path.join(root,'build/emscripten/client/release');
  126 |   const fixtures={};
  127 |   for(const file of fs.readdirSync(path.join(root,'test/fixtures/javascript'))){
  128 |     const target=path.join(root,'test/fixtures/javascript',file);
  129 |     if(fs.statSync(target).isFile())fixtures[file]=hash(target);
  130 |   }
  131 |   let producer, provenanceError;
  132 |   try {producer=JSON.parse(fs.readFileSync(path.join(output,'corpus/build-provenance.json'),'utf8'));}
  133 |   catch(error){provenanceError=String(error);}
  134 |   const provenanceIssues=provenanceError ? ['Missing or invalid executed-binary build provenance: '+provenanceError]
  135 |     : ['revision','dirty','sourceTreeSha256'].filter(key=>producer[key]!==source[key])
  136 |       .map(key=>'Executed binary differs from runner source: '+key);
  137 |   fs.writeFileSync(path.join(output,'manifest.json'),JSON.stringify({...source,build:producer||null,provenanceIssues,
  138 |     browser:info.project.name,browserVersion:page.context().browser().version(),
  139 |     toolchain:JSON.parse(fs.readFileSync(path.join(root,'browser/toolchain.json'))),
  140 |     buildIdentity:JSON.parse(fs.readFileSync(path.join(build,'identity.json'))),
  141 |     binaries:Object.fromEntries(['script-tests.js','script-tests.wasm','script-tests.data']
  142 |       .map(file=>[file,hash(path.join(build,file))])),fixtureHashes:fixtures,
  143 |     command:'playwright test determinism.spec.js --grep "shared scripting corpus"',
  144 |     exit:result.exit,error:result.error,files:Object.keys(result.files)},null,2)+'\n');
  145 |   if(waitError)throw waitError;
  146 |   expect(provenanceIssues).toEqual([]);
  147 |   expect(result.error).toBeUndefined();
  148 |   expect(result.exit).toBe(0);
  149 |   expect(Object.keys(result.files).some(name=>name.endsWith('numeric-profile1.value'))).toBeTruthy();
  150 |   expect(Object.keys(result.files).some(name=>name.endsWith('realistic-economy-3.value'))).toBeTruthy();
  151 | });
  152 | 
```