#!/usr/bin/env python3
"""Package cross-compiled ARM binaries without claiming device execution."""
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'test'))
from build_provenance import source_identity, build_issues
REVISION = '8a25c2bd2440e99246171967a31c68dc15917f95'
SOURCE_HASH = '1540813995310acf88924c167bbb9c80525eb9d5cd7fe4a421d8e7ee5b49a991'
FINAL = ROOT / 'artifacts/rebase-validation/final'
OUTPUT = FINAL / 'package-staging'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def guard():
    source = source_identity(ROOT)
    assert source['revision'] == REVISION and source['sourceTreeSha256'] == SOURCE_HASH, source
    assert source['dirty'] is False and source['sourceStatus'] == [], source
    return source


for lane, abi, machine, elf_class in [('arm64', 'arm64-v8a', 183, 2),
                                       ('armv7', 'armeabi-v7a', 40, 1)]:
    source = guard()
    build = ROOT / ('build/android/device/' + abi + '/24/client/release')
    header = build / 'include/glob2/TestBuildProvenance.h'
    token = re.search(r'#define GLOB2_TEST_PROVENANCE_JSON (".*")', header.read_text())
    assert token, header
    producer_text = json.loads(token.group(1))
    producer = json.loads(producer_text)
    assert not build_issues(producer, source), producer
    log = FINAL / ('android-' + lane + '-build.log')
    assert log.read_text().rstrip().endswith('scons: done building targets.'), log
    binaries = []
    for name in ('glob2-unit-tests', 'glob2-engine-tests'):
        binary = build / 'tests' / name
        data = binary.read_bytes()
        assert data[:4] == b'\x7fELF' and data[4] == elf_class and data[5] == 1, binary
        assert struct.unpack_from('<H', data, 18)[0] == machine, binary
        assert producer_text.encode() in data, 'Compiled producer string absent: ' + str(binary)
        binaries.append({'repositoryPath': str(binary.relative_to(ROOT)),
                         'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                         'elfClass': elf_class, 'elfMachine': machine,
                         'compiledProducerStringVerified': True,
                         'executed': False})
    compiler = Path(producer['compiler'])
    compiler_version = subprocess.check_output([str(compiler), '--version'], text=True)
    name = 'android-' + lane + '-compile-only'
    manifest = dict(source, lane=name, abi=abi, api=24, status='COMPILE ONLY',
                    producerBuild=producer, binaries=binaries,
                    compilerVersion=compiler_version, compilerDriverSha256=sha(compiler),
                    buildCompletionMarkerVerified=True, runtimeExecuted=False,
                    acceptanceEligible=False, physicalDeviceAcceptance=False,
                    comparableArtifactCount=0,
                    limitation='Successful cross-compilation and embedded producer identity verified. No physical-device runtime, numeric, simulation or continuation acceptance is claimed.',
                    fixtureHashes={str(path.relative_to(ROOT)): sha(path)
                                   for path in sorted((ROOT / 'test/fixtures/javascript').rglob('*'))
                                   if path.is_file()})
    manifest_path = OUTPUT / (name + '.manifest.json')
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    members = {'COMPILE-ONLY-MANIFEST.json': manifest_path,
               'build.log': log, 'build-config/TestBuildProvenance.h': header,
               'build-config/BuildConfig.h': build / 'include/glob2/BuildConfig.h',
               'reproduction/package-android-arm-compile-only.py': Path(__file__).resolve(),
               'reproduction/test/build_provenance.py': ROOT / 'test/build_provenance.py',
               'reproduction/mobile/android_device_tests.py': ROOT / 'mobile/android_device_tests.py',
               'reproduction/scons/javascript.py': ROOT / 'scons/javascript.py',
               'reproduction/mobile/android.py': ROOT / 'mobile/android.py'}
    original = {arc: {'repositoryPath': str(path.relative_to(ROOT)),
                      'sha256': sha(path), 'bytes': path.stat().st_size}
                for arc, path in sorted(members.items())}
    archive = OUTPUT / (name + '.tar.gz')
    with tarfile.open(archive, 'w:gz') as stream:
        for arc, path in sorted(members.items()):
            stream.add(path, arcname=arc, recursive=False)
    assert archive.stat().st_size < 95 * 1024 * 1024
    with tarfile.open(archive, 'r:gz') as stream:
        assert len(stream.getmembers()) == len(members)
        for item in stream.getmembers():
            assert item.isfile() and item.name in members
            digest = hashlib.sha256()
            data = stream.extractfile(item)
            for block in iter(lambda: data.read(1024 * 1024), b''):
                digest.update(block)
            assert digest.hexdigest() == original[item.name]['sha256'], item.name
            assert item.size == original[item.name]['bytes'], item.name
            assert sha(members[item.name]) == original[item.name]['sha256'], item.name
    for binary in binaries:
        assert sha(ROOT / binary['repositoryPath']) == binary['sha256']
    guard()
    proof = dict(revision=REVISION, sourceTreeSha256=SOURCE_HASH, status='COMPILE ONLY',
                 runtimeExecuted=False, physicalDeviceAcceptance=False,
                 archive=archive.name, archiveBytes=archive.stat().st_size,
                 archiveSha256=sha(archive), verifiedFileCount=len(members), files=original)
    (OUTPUT / (name + '.files.json')).write_text(json.dumps(proof, indent=2) + '\n')
    print(json.dumps({key: proof[key] for key in ('archive', 'archiveBytes', 'archiveSha256', 'verifiedFileCount', 'status')}), flush=True)
