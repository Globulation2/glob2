const config=require('/workspace/browser/playwright.config.js');
module.exports={...config,testDir:'/workspace/browser/tests',outputDir:'/workspace/artifacts/browser-linux/playwright-results',reporter:[['list'],['html',{outputFolder:'/workspace/artifacts/browser-linux/playwright-report',open:'never'}]]};
