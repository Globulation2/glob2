#!/bin/bash
set -euo pipefail
cd /workspace
git config --global --add safe.directory /workspace
mkdir -p artifacts/web-linux
python3 -m pip install scons==4.11.1
{
  uname -a
  cat /etc/os-release
  python3 --version
  em++ --version
  scons --version
  git rev-parse HEAD
  git status --porcelain
  python3 test/build_provenance.py
} | tee artifacts/web-linux/environment.log
python3 test/build_provenance.py > artifacts/web-linux/source-before.json
scons target=web release=1 web-tests build/emscripten/client/release/index.html -j16 2>&1 | tee artifacts/web-linux/build.log
python3 test/build_provenance.py > artifacts/web-linux/source-after.json
sha256sum build/emscripten/client/release/index.* > artifacts/web-linux/bundle-hashes.txt
