import pathlib,re,json,hashlib
p=pathlib.Path('/workspace')
h=p/'build/emscripten/client/release/include/glob2/TestBuildProvenance.h'
raw=re.search(r'#define GLOB2_TEST_PROVENANCE_JSON (.*)',h.read_text()).group(1)
b=json.loads(json.loads(raw))
assert b['revision']=='53d16aa37ae35748bf5b1458f79d0eba55fb3ab5' and b['dirty'] is False and b['sourceTreeSha256']=='60f140b19fbb3bd5dd2a82433435b911fb4b8f7575062d58d1df330c999a80b4'
assert json.loads(raw).encode() in (p/'build/emscripten/client/release/script-tests.wasm').read_bytes()
files={f.name:{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}for f in (p/'build/emscripten/client/release').glob('*')if f.is_file() and(f.name.startswith('index.') or f.name.startswith('script-tests.'))}
assert len(files)==8
out={'build':b,'files':files}
(p/'artifacts/browser-linux/served-bundle.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
