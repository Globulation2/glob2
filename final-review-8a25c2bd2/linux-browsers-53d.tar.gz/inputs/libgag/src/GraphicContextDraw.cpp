// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#include "GraphicContextPrivate.h"
#include "OpaqueRectangleBatch.h"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <exception>
#include <stdexcept>
#include <vector>

namespace GAGCore
{
    namespace
    {
        // Rendering is confined to the active context's presentation thread.
        // Scratch storage is reused across bars and bounded by the flush limit.
        class RectangleBatchState
        {
        public:
            static constexpr size_t maxRectangles = 4096;

            bool owns(const GraphicContext *context) const { return owner == context; }

            void begin(GraphicContext *context)
            {
                if (owner) throw std::logic_error("Rectangle batch scopes cannot nest");
                owner = context;
            }

            bool append(float x, float y, float w, float h, const Color &color, RenderBackend *backend)
            {
                const bool startsSubmission = quads.empty();
                renderer = backend;
                quads.push_back({x, y, w, h, color});
                if (quads.size() == maxRectangles) flush();
                return startsSubmission;
            }

            void flush()
            {
                if (quads.empty()) return;
                if (renderer)
                {
                    vertices.clear();
                    vertices.reserve(quads.size() * 6);
                    for (const auto &quad : quads)
                    {
                        const SDL_Color color{quad.color.r, quad.color.g, quad.color.b, 255};
                        const SDL_Vertex a{{quad.x, quad.y}, color, {}},
                                         b{{quad.x + quad.w, quad.y}, color, {}},
                                         c{{quad.x + quad.w, quad.y + quad.h}, color, {}},
                                         d{{quad.x, quad.y + quad.h}, color, {}};
                        vertices.insert(vertices.end(), {a, b, c, a, c, d});
                    }
                    renderer->triangles(vertices);
                }
#ifdef HAVE_OPENGL
                else
                {
                    glState.doBlend(false);
                    glState.doTexture(false);
                    glBegin(GL_QUADS);
                    for (const auto &quad : quads)
                    {
                        // Emscripten interleaves immediate-mode attributes: each
                        // vertex needs a color entry, even when a quad is uniform.
                        const auto vertex = [&](float x, float y) {
                            glColor3ub(quad.color.r, quad.color.g, quad.color.b);
                            glVertex2f(x, y);
                        };
                        vertex(quad.x, quad.y);
                        vertex(quad.x + quad.w, quad.y);
                        vertex(quad.x + quad.w, quad.y + quad.h);
                        vertex(quad.x, quad.y + quad.h);
                    }
                    glEnd();
                }
#endif
                quads.clear();
            }

            void discard() noexcept
            {
                quads.clear();
                vertices.clear();
                owner = nullptr;
                renderer = nullptr;
            }

            void finish()
            {
                try { flush(); }
                catch (...) { discard(); throw; }
                discard();
            }

        private:
            struct Quad { float x, y, w, h; Color color; };
            GraphicContext *owner = nullptr;
            RenderBackend *renderer = nullptr;
            std::vector<Quad> quads;
            std::vector<SDL_Vertex> vertices;
        };

        RectangleBatchState rectangleBatch;
    }

    OpaqueRectangleBatch::OpaqueRectangleBatch(GraphicContext *context)
    {
        bool enabled = context->hasPortableRenderer();
#ifdef HAVE_OPENGL
        enabled = enabled || (context->getOptionFlags() & GraphicContext::USEGPU);
#endif
        if (enabled)
        {
            rectangleBatch.begin(context);
            active = true;
        }
    }

    OpaqueRectangleBatch::~OpaqueRectangleBatch() noexcept(false)
    {
        if (!active) return;
        // A failed drawing operation has already aborted this pass. Discard its
        // queued geometry instead of risking a second exception during unwinding.
        if (std::uncaught_exceptions() > 0) rectangleBatch.discard();
        else rectangleBatch.finish();
    }

	void GraphicContext::beginMapTransform(float zoom,float x,float y,int cx,int cy,int cw,int ch)
	{
        if (zoom!=1 || x!=0 || y!=0) beginSoftwareTransform();
        if (renderer) {
            assert(!mapTransformActive);
            mapTranslateX=x; mapTranslateY=y; mapTransformActive=true; mapScale=zoom;
            mapClipX=cx; mapClipY=cy; mapClipW=cw; mapClipH=ch;
            SDL_Rect bounds{cx,cy,cw,ch}; renderer->transform(zoom,x,y,&bounds); return;
        }
#ifdef HAVE_OPENGL
		if(!(optionFlags & USEGPU))return;
		assert(!mapTransformActive);
		Sprite::flushBatches(this);
		mapTranslateX=x;mapTranslateY=y;mapTransformActive=true;mapScale=zoom;mapClipX=cx;mapClipY=cy;mapClipW=cw;mapClipH=ch;
		glPushMatrix();glTranslatef(x,y,0);glScalef(zoom,zoom,1);setClipRect(cx,cy,cw,ch);
#endif
	}
	void GraphicContext::endMapTransform()
	{
        if (renderer) { renderer->transform(1,0,0,nullptr); mapTransformActive=false; mapScale=1; endSoftwareTransform(); setClipRect(); return; }
#ifdef HAVE_OPENGL
		if(!mapTransformActive)return;
		Sprite::flushBatches(this);
		glPopMatrix();mapTransformActive=false;mapScale=1;setClipRect();
#endif
	}

    void GraphicContext::drawMapCopies(int pw,int ph,int vw,int vh,const std::function<void()> &draw)
    {
        draw();
        if (renderer && pw>0 && ph>0) {
            SDL_Rect bounds{mapClipX,mapClipY,mapClipW,mapClipH};
            periodicCopy=true;
            for(int y=-1;y<=vh/ph+1;++y) for(int x=-1;x<=vw/pw+1;++x) {
                if(x==0 && y==0) continue;
                mapCopyTranslateX=x*pw*mapScale; mapCopyTranslateY=y*ph*mapScale;
                renderer->transform(mapScale,mapTranslateX+mapCopyTranslateX,mapTranslateY+mapCopyTranslateY,&bounds);
                draw();
            }
            renderer->transform(mapScale,mapTranslateX,mapTranslateY,&bounds);
            mapCopyTranslateX=mapCopyTranslateY=0; periodicCopy=false; return;
        }
#ifdef HAVE_OPENGL
        if(!(optionFlags & USEGPU) || pw<=0 || ph<=0)return;
        Sprite::flushBatches(this);
        periodicCopy=true;
        for(int y=-1;y<=vh/ph+1;++y)for(int x=-1;x<=vw/pw+1;++x)
        {
            if(x==0 && y==0)continue;
            mapCopyTranslateX=x*pw*mapScale; mapCopyTranslateY=y*ph*mapScale;
            glPushMatrix();glTranslatef(x*pw,y*ph,0);
            draw();Sprite::flushBatches(this);glPopMatrix();
        }
        mapCopyTranslateX=mapCopyTranslateY=0; periodicCopy=false;
#endif
    }

    void GraphicContext::drawMapBoundary(int x1, int y1, int x2, int y2, const Color& color)
    {
        assert(x1 == x2 || y1 == y2);
        // Snap in the actual raster target, then return to world coordinates.
        // Include periodic-copy translation: wrapped maps need the same pixel
        // alignment as the primary pass, even at fractional zoom and DPI.
        const float raster = softwareTransform ? 1.f : rasterScale();
        const float scale = mapTransformActive ? mapScale : 1.f;
        const float pixelsPerWorld = raster * scale;
        const float offsetX = mapTransformActive ? (mapTranslateX + mapCopyTranslateX) * raster : 0;
        const float offsetY = mapTransformActive ? (mapTranslateY + mapCopyTranslateY) * raster : 0;
        const float left = std::round(std::min(x1, x2) * pixelsPerWorld + offsetX);
        const float top = std::round(std::min(y1, y2) * pixelsPerWorld + offsetY);
        const float right = std::round(std::max(x1, x2) * pixelsPerWorld + offsetX);
        const float bottom = std::round(std::max(y1, y2) * pixelsPerWorld + offsetY);
        const float stroke = std::max(1.f, std::round(pixelsPerWorld));
        // SDL's software geometry rasterizer truncates transformed coordinates.
        // Avoid a world->screen->world round trip there: tiny float errors can
        // otherwise move a snapped edge back across a pixel boundary.
        if (renderer && mapTransformActive)
        {
            const float x=left/raster, y=top/raster;
            const float rightEdge=(right+stroke)/raster, bottomEdge=(bottom+stroke)/raster;
            const SDL_Color ink{color.r,color.g,color.b,color.a};
            const SDL_Vertex a{{x,y},ink,{}}, b{{rightEdge,y},ink,{}},
                             c{{rightEdge,bottomEdge},ink,{}}, d{{x,bottomEdge},ink,{}};
            const SDL_Vertex vertices[]{a,b,c,a,c,d};
            renderer->screenTriangles(vertices);
            return;
        }
        // Inclusive ends join perpendicular edges and adjacent tile segments.
        drawFilledRect((left-offsetX)/pixelsPerWorld, (top-offsetY)/pixelsPerWorld,
                       (right-left+stroke)/pixelsPerWorld,
                       (bottom-top+stroke)/pixelsPerWorld, color);
    }

    void GraphicContext::beginScreenOverlay(int &x,int &y,int &sx,int &sy,int &sw,int &sh)
    {
        if (renderer && mapTransformActive) {
            x=x*mapScale+mapTranslateX; y=y*mapScale+mapTranslateY;
            sx=mapClipX; sy=mapClipY; sw=mapClipW; sh=mapClipH;
            SDL_Rect bounds{sx,sy,sw,sh}; renderer->transform(1,0,0,&bounds);
            overlayScale=mapScale; mapScale=1; return;
        }
#ifdef HAVE_OPENGL
        if(!mapTransformActive)return;
        Sprite::flushBatches(this);
        x=x*mapScale+mapTranslateX;y=y*mapScale+mapTranslateY;
        sx=mapClipX;sy=mapClipY;sw=mapClipW;sh=mapClipH;
        glPushMatrix();glScalef(1/mapScale,1/mapScale,1);glTranslatef(-mapTranslateX,-mapTranslateY,0);
        overlayScale=mapScale;mapScale=1;
#endif
    }
    void GraphicContext::endScreenOverlay()
    {
        if (renderer && mapTransformActive) {
            mapScale=overlayScale; SDL_Rect bounds{mapClipX,mapClipY,mapClipW,mapClipH};
            renderer->transform(mapScale,mapTranslateX,mapTranslateY,&bounds); return;
        }
#ifdef HAVE_OPENGL
        if(!mapTransformActive)return;
        Sprite::flushBatches(this);glPopMatrix();mapScale=overlayScale;
#endif
    }

	// GL rasterises lines at a width in the target's pixels, which the viewport
	// transform does not scale the way it scales filled geometry.
	void GraphicContext::setScaledLineWidth(float width)
	{
		#ifdef HAVE_OPENGL
		glLineWidth(width * rasterScale() * mapScale);
		#endif
	}

	void GraphicContext::setClipRect(int x, int y, int w, int h)
	{
#ifdef HAVE_OPENGL
        if (uiTransformActive && !renderer && (optionFlags & USEGPU)) {
            SDL_Rect transformed{int(std::floor(x*uiTransformScale+uiTransformX)),int(std::floor(y*uiTransformScale+uiTransformY)),
                int(std::ceil(w*uiTransformScale)),int(std::ceil(h*uiTransformScale))};
            SDL_Rect clipped{}; SDL_IntersectRect(&transformed,&uiBounds,&clipped);
            x=clipped.x;y=clipped.y;w=clipped.w;h=clipped.h;
        }
#endif
		if(mapTransformActive){x=mapClipX;y=mapClipY;w=mapClipW;h=mapClipH;}
		DrawableSurface::setClipRect(x, y, w, h);
		if (nativeSoftware) SDL_SetClipRect(sdlsurface, nullptr);
        if (renderer) renderer->clip(mapTransformActive ? nullptr : &clipRect);
		#ifdef HAVE_OPENGL
		if (_gc->optionFlags & GraphicContext::USEGPU)
		{
			glState.doScissor(true);
			// glScissor operates in drawable pixels; scale from logical coordinates,
			// through the same letterbox as the viewport (see applyGLViewport())
			int sx = clipRect.x, sy = getH() - clipRect.y - clipRect.h, sw = clipRect.w, sh = clipRect.h;
			if (drawableW && (drawableW != getW() || drawableH != getH()))
			{
				float scale;
				int offX, offY;
				glLetterbox(scale, offX, offY);
				sx = static_cast<int>(sx * scale + 0.5f) + offX;
				sy = static_cast<int>(sy * scale + 0.5f) + offY;
				sw = static_cast<int>(sw * scale + 0.5f);
				sh = static_cast<int>(sh * scale + 0.5f);
			}
			if (nativeDesktop)
			{
				const double xScale=double(drawableW)/getW(), yScale=double(drawableH)/getH();
				sx=int(std::lround(clipRect.x*xScale)); sy=int(std::lround((getH()-clipRect.y-clipRect.h)*yScale));
				sw=int(std::lround((clipRect.x+clipRect.w)*xScale))-sx;
				sh=int(std::lround((getH()-clipRect.y)*yScale))-sy;
			}
			glScissor(sx, sy, sw, sh);
		}
		#endif
	}

	void GraphicContext::setClipRect(void)
	{
#ifdef HAVE_OPENGL
        if (uiTransformActive && !renderer && (optionFlags & USEGPU)) {
            uiTransformActive=false;
            setClipRect(uiBounds.x,uiBounds.y,uiBounds.w,uiBounds.h);
            uiTransformActive=true; return;
        }
#endif
		if(mapTransformActive){setClipRect(mapClipX,mapClipY,mapClipW,mapClipH);return;}
		DrawableSurface::setClipRect();
		clipRect = SDL_Rect{0,0,getW(),getH()};
        if (renderer) renderer->clip(nullptr);
		#ifdef HAVE_OPENGL
		if (_gc->optionFlags & GraphicContext::USEGPU)
			glState.doScissor(false);
		#endif
	}

	// drawing, reimplementation for GL

	void GraphicContext::drawPixel(int x, int y, const Color& color)
	{
        if (renderer) { drawPixel(float(x), float(y), color); return; }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
			GraphicContext::drawPixel(static_cast<float>(x), static_cast<float>(y), color);
		else
		#endif
			DrawableSurface::drawPixel(x, y, color);
	}

	void GraphicContext::drawPixel(float x, float y, const Color& color)
	{
        if (renderer) { drawFilledRect(x, y, 1.0f, 1.0f, color); return; }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
			drawFilledRect(x, y, 1.0f, 1.0f, color);
		else
		#endif
			DrawableSurface::drawPixel(static_cast<int>(x), static_cast<int>(y), color);
	}


	void GraphicContext::drawRect(int x, int y, int w, int h, const Color& color)
	{
        if (renderer) { drawRect(float(x), float(y), float(w), float(h), color); return; }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
			GraphicContext::drawRect(static_cast<float>(x), static_cast<float>(y), static_cast<float>(w), static_cast<float>(h), color);
		else
		#endif
			DrawableSurface::drawRect(x, y, w, h, color);
	}

	void GraphicContext::drawRect(float x, float y, float w, float h, const Color& color)
	{
        if (renderer) {
            if (w <= 0 || h <= 0) return;
            drawFilledRect(x,y,w,1.0f,color);
            if (h > 1) drawFilledRect(x,y+h-1,w,1.0f,color);
            if (h > 2) { drawFilledRect(x,y+1,1.0f,h-2,color); if(w > 1) drawFilledRect(x+w-1,y+1,1.0f,h-2,color); }
            return;
        }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
		{
			if (rectangleBatch.owns(this)) rectangleBatch.flush();
			// state change
			glState.blendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glState.doBlend(true);
			glState.doTexture(false);
			setScaledLineWidth(1.0f);

			// draw
			++drawCalls;
			if (color.a < 255)
				glColor4ub(color.r, color.g, color.b, color.a);
			else
				glColor3ub(color.r, color.g, color.b);
			glBegin(GL_LINES);
			glVertex2f(x, y);     glVertex2f(x+w, y);
			glVertex2f(x+w, y);   glVertex2f(x+w, y+h);
			glVertex2f(x+w, y+h); glVertex2f(x, y+h);
			glVertex2f(x, y+h);   glVertex2f(x, y);
			glEnd();
		}
		else
		#endif
			DrawableSurface::drawRect(static_cast<int>(x), static_cast<int>(y), static_cast<int>(w), static_cast<int>(h), color);
	}


	void GraphicContext::drawFilledRect(int x, int y, int w, int h, const Color& color)
	{
        if (renderer) { drawFilledRect(float(x), float(y), float(w), float(h), color); return; }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
			GraphicContext::drawFilledRect(static_cast<float>(x), static_cast<float>(y), static_cast<float>(w), static_cast<float>(h), color);
		else
		#endif
			DrawableSurface::drawFilledRect(x, y, w, h, color);
	}

	void GraphicContext::drawFilledRect(float x, float y, float w, float h, const Color& color)
	{
        if (rectangleBatch.owns(this))
        {
            if (renderer && (w <= 0 || h <= 0)) return;
            if (color.a == Color::ALPHA_OPAQUE)
            {
                if (rectangleBatch.append(x, y, w, h, color, renderer.get())) ++drawCalls;
                return;
            }
            rectangleBatch.flush();
        }
        if (renderer) {
            if (w <= 0 || h <= 0) return;
            SDL_Color c{color.r,color.g,color.b,color.a};
            SDL_Vertex a{{x,y},c,{0,0}}, b{{x+w,y},c,{0,0}}, d{{x,y+h},c,{0,0}}, e{{x+w,y+h},c,{0,0}};
            const SDL_Vertex vertices[] = {a,b,e,a,e,d};
            renderer->triangles(vertices); return;
        }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
		{
			// state change
			if (color.a < 255)
				glState.doBlend(true);
			else
				glState.doBlend(false);
			glState.doTexture(false);

			// draw
			++drawCalls;
			if (color.a < 255)
				glColor4ub(color.r, color.g, color.b, color.a);
			else
				glColor3ub(color.r, color.g, color.b);
			glBegin(GL_QUADS);
			glVertex2f(x, y);
			glVertex2f(x+w, y);
			glVertex2f(x+w, y+h);
			glVertex2f(x, y+h);
			glEnd();
		}
		else
		#endif
			DrawableSurface::drawFilledRect(static_cast<int>(x), static_cast<int>(y), static_cast<int>(w), static_cast<int>(h), color);
	}


	void GraphicContext::drawLine(int x1, int y1, int x2, int y2, const Color& color)
	{
        if (renderer) { drawLine(float(x1), float(y1), float(x2), float(y2), color); return; }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
			GraphicContext::drawLine(static_cast<float>(x1), static_cast<float>(y1), static_cast<float>(x2), static_cast<float>(y2), color);
		else
		#endif
			DrawableSurface::drawLine(x1, y1, x2, y2, color);
	}

	void GraphicContext::drawLine(float x1, float y1, float x2, float y2, const Color& color)
	{
        if (renderer) {
            float dx=x2-x1, dy=y2-y1, length=std::hypot(dx,dy);
            if (length == 0) { drawPixel(x1,y1,color); return; }
            float nx=-dy/(2*length), ny=dx/(2*length);
            SDL_Color c{color.r,color.g,color.b,color.a};
            SDL_Vertex a{{x1+nx,y1+ny},c,{0,0}}, b{{x2+nx,y2+ny},c,{0,0}}, d{{x1-nx,y1-ny},c,{0,0}}, e{{x2-nx,y2-ny},c,{0,0}};
            const SDL_Vertex vertices[] = {a,b,e,a,e,d};
            renderer->triangles(vertices); return;
        }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
		{
			// state change
			glState.blendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glState.doBlend(true);
			glState.doTexture(false);

			// Drivers only antialias 1 px lines, so a scaled line is built from
			// several 1 px smooth lines spread across the scaled thickness.
			const float scale = rasterScale();
			const int passes = std::max(1, static_cast<int>(std::ceil(scale)));
			float nx = 0.0f, ny = 0.0f;
			if (passes > 1)
			{
				const float ddx = x2 - x1, ddy = y2 - y1;
				const float len = std::sqrt(ddx * ddx + ddy * ddy);
				if (len > 0.0f)
				{
					nx = -ddy / len;
					ny = ddx / len;
				}
			}
			glLineWidth(1.0f);

			// draw
			++drawCalls;
			if (color.a < 255)
			{
				// the passes overlap, so each carries the alpha that composes back to the requested one
				const float a = 1.0f - std::pow(1.0f - color.a / 255.0f, 1.0f / passes);
				glColor4ub(color.r, color.g, color.b, static_cast<Uint8>(a * 255.0f + 0.5f));
			}
			else
				glColor3ub(color.r, color.g, color.b);
			glBegin(GL_LINES);
			for (int i = 0; i < passes; ++i)
			{
				// offsets in target pixels from -(scale-1)/2 to +(scale-1)/2, mapped back to logical units
				const float off = passes > 1 ? ((scale - 1.0f) * (static_cast<float>(i) / (passes - 1) - 0.5f)) / scale : 0.0f;
				glVertex2f(x1 + nx * off, y1 + ny * off);
				glVertex2f(x2 + nx * off, y2 + ny * off);
			}
			glEnd();
		}
		else
		#endif
			DrawableSurface::drawLine(static_cast<int>(x1), static_cast<int>(y1), static_cast<int>(x2), static_cast<int>(y2), color);
	}


	void GraphicContext::drawCircle(int x, int y, int radius, const Color& color)
	{
        if (renderer) { drawCircle(float(x), float(y), float(radius), color); return; }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
			drawCircle(static_cast<float>(x), static_cast<float>(y), static_cast<float>(radius), color);
		else
		#endif
			DrawableSurface::drawCircle(x, y, radius, color);
	}

	void GraphicContext::drawCircle(float x, float y, float radius, const Color& color)
	{
        if (renderer) {
            if (radius <= 0) return;
            int segments=std::max(12, int(std::ceil(radius*2)));
            for(int i=0;i<segments;++i) {
                float a=2*M_PI*i/segments, b=2*M_PI*(i+1)/segments;
                drawLine(x+radius*std::cos(a),y+radius*std::sin(a),x+radius*std::cos(b),y+radius*std::sin(b),color);
            }
            return;
        }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
		{
			glState.doBlend(true);
			glState.doTexture(false);
			setScaledLineWidth(2.0f);

			double tot = radius;
			double fx = x;
			double fy = y;
			double fray = radius;

			++drawCalls;
			if (color.a < 255)
				glColor4ub(color.r, color.g, color.b, color.a);
			else
				glColor3ub(color.r, color.g, color.b);
			glBegin(GL_LINES);
			for (int i=0; i<tot; i++)
			{
				double angle0 = (2*M_PI*(double)i)/((double)tot);
				double angle1 = (2*M_PI*(double)(i+1))/((double)tot);
				glVertex2f(fx+fray*sin(angle0), fy+fray*cos(angle0));
				glVertex2f(fx+fray*sin(angle1), fy+fray*cos(angle1));
			}
			glEnd();
			setScaledLineWidth(1.0f);
		}
		else
		#endif
			DrawableSurface::drawCircle(static_cast<int>(x), static_cast<int>(y), static_cast<int>(radius), color);
	}

	// compat... this is there because it sems gcc is not able to do function overloading with several levels of inheritance
	void GraphicContext::drawPixel(int x, int y, Uint8 r, Uint8 g, Uint8 b, Uint8 a)
	{
		drawPixel(x, y, Color(r, g, b, a));
	}

	void GraphicContext::drawRect(int x, int y, int w, int h, Uint8 r, Uint8 g, Uint8 b, Uint8 a)
	{
		drawRect(x, y, w, h, Color(r, g, b, a));
	}

	void GraphicContext::drawFilledRect(int x, int y, int w, int h, Uint8 r, Uint8 g, Uint8 b, Uint8 a)
	{
		drawFilledRect(x, y, w, h, Color(r, g, b, a));
	}

	void GraphicContext::drawLine(int x1, int y1, int x2, int y2, Uint8 r, Uint8 g, Uint8 b, Uint8 a)
	{
		drawLine(x1, y1, x2, y2, Color(r, g, b, a));
	}

	// Axis-aligned 1 px lines are drawn as exact 1x l quads in GL mode: a GL_LINES
	// primitive keeps an integer device width, so at a fractional fullscreen scale
	// adjacent lines (charts, sliders, training bars) leave gaps between them.
	void GraphicContext::drawVertLine(int x, int y, int l, Uint8 r, Uint8 g, Uint8 b, Uint8 a)
	{
        if (renderer) { drawFilledRect(x,y,1, l,Color(r,g,b,a)); return; }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
			drawFilledRect(x, y, 1, l, Color(r, g, b, a));
		else
		#endif
			 _drawVertLine(x, y, l, Color(r, g, b, a));
	}

	void GraphicContext::drawVertLine(int x, int y, int l, const Color& color)
	{
        if (renderer) { drawFilledRect(x,y,1, l,color); return; }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
			drawFilledRect(x, y, 1, l, color);
		else
		#endif
			 _drawVertLine(x, y, l, color);
	}

	void GraphicContext::drawHorzLine(int x, int y, int l, Uint8 r, Uint8 g, Uint8 b, Uint8 a)
	{
        if (renderer) { drawFilledRect(x,y,l, 1,Color(r,g,b,a)); return; }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
			drawFilledRect(x, y, l, 1, Color(r, g, b, a));
		else
		#endif
			_drawHorzLine(x, y, l, Color(r, g, b, a));
	}

	void GraphicContext::drawHorzLine(int x, int y, int l, const Color& color)
	{
        if (renderer) { drawFilledRect(x,y,l, 1,color); return; }
		#ifdef HAVE_OPENGL
		if (optionFlags & GraphicContext::USEGPU)
			drawFilledRect(x, y, l, 1, color);
		else
		#endif
			_drawHorzLine(x, y, l, color);
	}

	void GraphicContext::drawCircle(int x, int y, int radius, Uint8 r, Uint8 g, Uint8 b, Uint8 a)
	{
		drawCircle(x, y, radius, Color(r, g, b, a));
	}
}
