#!/usr/bin/env python3
"""Actual AI, workers and continuation of the genuine upstream format-124 save."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'test'))
from build_provenance import source_identity
from check_telemetry_simulation import detailed_ticks
from check_javascript import complete_ticks, compare_payloads

parser = argparse.ArgumentParser()
parser.add_argument('--binary', type=Path, required=True)
parser.add_argument('--arch', choices=('arm64', 'x86_64'), required=True)
parser.add_argument('--revision', required=True)
parser.add_argument('--source-hash', required=True)
args = parser.parse_args()
binary = args.binary.resolve()
origin = ROOT / 'artifacts/rebase-validation/master124-origin'
output = ROOT / ('artifacts/rebase-validation/final/master124-macos-' + args.arch)
output.mkdir(parents=True, exist_ok=False)
fixture = ROOT / 'test/fixtures/javascript/master-v124-experiments.game.gz'
baseline = (origin / 'baseline128/game.replay.checksums').read_bytes()
classification_root = ROOT / 'artifacts/rebase-validation/final/master124-upstream-resume-classification'
classification = json.loads((classification_root / 'classification.json').read_text())
upstream_resumed = (classification_root / 'upstream124/resumed64/game.replay.checksums').read_bytes()
upstream_checkpoint = classification_root / 'upstream124/workers1/checkpoint-64.game.gz'
assert classification['upstreamRevision'] == '723590eccd7d3ec5495214e78635b69233491a98'
assert classification['candidateRevision'] == args.revision
assert hashlib.sha256(upstream_resumed).hexdigest() == classification['upstreamResumeSha256']
manifest = source_identity(ROOT)
assert manifest['revision'] == args.revision and manifest['sourceTreeSha256'] == args.source_hash
assert manifest['dirty'] is False and manifest['sourceStatus'] == []
manifest.update(binarySha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                fixtureSha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),
                origin=json.loads((origin / 'manifest.json').read_text()),
                inheritedContinuationClassification=classification,
                upstreamCheckpointSha256=hashlib.sha256(upstream_checkpoint.read_bytes()).hexdigest(), commands=[], checks=[])
assert manifest['fixtureSha256'] == manifest['origin']['fixtureSha256']


def run(name, saved, workers):
    directory = output / name
    argv = [str(binary), '--run-game', '--load-game', str(saved), '--ticks', '128',
            '--compute-threads', str(workers), '--telemetry', 'checksums',
            '--replay', 'true', '--save', 'every:64', '--save', 'final',
            '--output-dir', str(directory)]
    manifest['commands'].append(argv)
    with (output / (name + '.log')).open('w') as log:
        subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    return (directory / 'game.replay.checksums').read_bytes()


serial = run('workers1', fixture, 1)
assert serial == baseline, 'Complete fresh-load upstream checksum sidecar changed'
a, b = complete_ticks(baseline), complete_ticks(serial)
assert len(a) == len(b) == 128 and a.keys() == b.keys()
xors = {int.from_bytes(a[t][4:8], 'little') ^ int.from_bytes(b[t][4:8], 'little') for t in a}
assert xors == {0}, xors
assert run('workers4', fixture, 4) == serial
for filename in ('game.replay', 'game.replay.checksums', 'final.game.gz'):
    assert (output / 'workers1' / filename).read_bytes() == (output / 'workers4' / filename).read_bytes()
resumed = run('resumed64', output / 'workers1/checkpoint-64.game.gz', 4)
tail = complete_ticks(resumed)
assert len(tail) == 64 and tail.keys() == {t for t in b if t >= 64}
assert detailed_ticks(resumed) == detailed_ticks(upstream_resumed)
original_resume_records = complete_ticks(upstream_resumed)
resume_xors = {int.from_bytes(original_resume_records[t][4:8], 'little') ^ int.from_bytes(record[4:8], 'little') for t, record in tail.items()}
assert resume_xors == {0x00800000}, resume_xors
# Preserve the released Castor boot restart after reload, including its known
# first staffing difference at85 from uninterrupted execution.
assert next(t for t in tail if detailed_ticks(serial)[t] != detailed_ticks(resumed)[t]) == 85
assert run('resumed-upstream124', upstream_checkpoint, 4) == upstream_resumed
assert source_identity(ROOT) == {key: manifest[key] for key in source_identity(ROOT)}
assert hashlib.sha256(binary.read_bytes()).hexdigest() == manifest['binarySha256']
manifest['checks'] = ['actual AI 128 ticks match entire upstream checksum sidecar exactly',
                      'new125 resume matches all upstream resumed entity fields; only header aggregate XOR00800000',
                      'loading original124 checkpoint matches complete upstream resumed sidecar bytes',
                      'inherited Castor continuation differs from uninterrupted at85; behavior preserved',
                      'one/four workers exact same-platform output']
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('PASS: master124 actual AI, all128 exact upstream records, workers1/4 and released continuation behavior64')
