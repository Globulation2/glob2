#!/usr/bin/env python3
"""Package only the final reviewed Mac/runtime emulator evidence, without deleting it."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tarfile
import argparse

ROOT = Path.cwd()
EVIDENCE = ROOT / 'artifacts/rebase-validation/final'
OUTPUT = EVIDENCE / 'package-staging'
parser = argparse.ArgumentParser()
parser.add_argument('--revision', required=True)
parser.add_argument('--source-hash', required=True)
parser.add_argument('--groups', nargs='+', choices=('macos-arm64','macos-x86_64','android-emulator'))
args = parser.parse_args()
REVISION = args.revision
SOURCE_HASH = args.source_hash
sys.path.insert(0, str(ROOT / 'test'))
from build_provenance import source_identity
from check_javascript_evidence import inventory, provenance, provenance_issues

GROUPS = {
 'macos-arm64': {
  'corpus': 'macos-arm64',
  'build': 'build/darwin/client/release',
  'paths': ['macos-arm64', 'macos-arm64-build.log', 'macos-arm64-corpus.log',
            'continuation-macos-arm64', 'continuation-macos-arm64.log',
            'compatibility-macos-arm64', 'compatibility-macos-arm64.log',
            'comparisons/macos-cli-continuation-and-released.json'],
 },
 'macos-x86_64': {
  'corpus': 'macos-x86_64',
  'build': 'build/macos-x86-tests',
  'paths': ['macos-x86_64', 'macos-x86_64-build-config.json',
            'macos-x86_64-final-build.log', 'macos-x86_64-corpus.log',
            'macos-x86_64-comparison.log', 'comparisons/macos-x86_64.json',
            'continuation-macos-x86_64', 'continuation-macos-x86_64.log',
            'compatibility-macos-x86_64', 'compatibility-macos-x86_64.log',
            'comparisons/macos-cli-continuation-and-released.json',
            'build-history'],
  'history': ['macos-x86_64-build.log', 'macos-x86_64-handoff-precompile.log',
              'macos-x86_64-handoff-precompile-retry.log',
              'macos-x86_64-harness-precompile.log', 'macos-x86_64-env-precompile.log'],
 },
 'android-emulator': {
  'corpus': 'android-x86_64-emulator',
  'build': 'build/android/device/x86_64/24/client/release',
  'paths': ['android-x86_64-emulator', 'android-x86_64-build.log',
            'android-x86_64-emulator-properties.txt', 'android-x86_64-emulator-config.json',
            'android-x86_64-emulator-run.log', 'android-x86_64-emulator-cleanup.log',
            'android-x86_64-emulator-boot.log', 'android-x86_64-emulator-environment.log',
            'android-x86_64-emulator-start.log', 'android-x86_64-emulator-tunnel.log',
            'android-x86_64-emulator-tunnel.pid', 'android-x86_64-emulator-comparison.log',
            'comparisons/android-x86_64-emulator.json'],
  'history': ['android-x86_64-space-rebuild.log'],
 },
}

for arch in ('arm64', 'x86_64'):
 GROUPS['macos-' + arch]['paths'].extend(['master124-macos-' + arch, 'master124-macos-' + arch + '.log', 'master124-upstream-resume-classification'])

def sha(path):
 digest = hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda: stream.read(1024 * 1024), b''):
   digest.update(block)
 return digest.hexdigest()

def guard_source():
 actual = source_identity(ROOT)
 assert actual['revision'] == REVISION, actual
 assert actual['dirty'] is False and actual['sourceStatus'] == [], actual
 assert actual['sourceTreeSha256'] == SOURCE_HASH, actual


def prepare(name, group):
 corpus = EVIDENCE / group['corpus']
 manifest = provenance(corpus)
 assert manifest['revision'] == REVISION and manifest['dirty'] is False, corpus
 assert manifest['sourceTreeSha256'] == SOURCE_HASH, corpus
 assert not provenance_issues(manifest, manifest), corpus
 assert len(inventory(corpus)) == 60, corpus
 binary_proofs = []
 for test in manifest['tests']:
  if name == 'android-emulator':
   binary = ROOT / group['build'] / 'tests' / test['name']
   expected = test['binarySha256']
  else:
   binary = ROOT / group['build'] / 'test' / test['binary']
   expected = test['sha256']
  assert sha(binary) == expected, binary
  binary_proofs.append({'repositoryPath': str(binary.relative_to(ROOT)),
                        'sha256': expected, 'bytes': binary.stat().st_size,
                        'executedBinarySha256': test.get('executedBinarySha256', expected)})
 if name.startswith('macos-'):
  for kind in ('continuation', 'compatibility', 'master124'):
   path = EVIDENCE / (kind + '-' + name) / 'manifest.json'
   cli = json.loads(path.read_text())
   assert cli['revision'] == REVISION, path
   if 'dirty' in cli: assert cli['dirty'] is False, path
   binary = ROOT / group['build'] / 'src/glob2'
   assert sha(binary) == cli['binarySha256'], binary
  binary_proofs.append({'repositoryPath': str(binary.relative_to(ROOT)),
                        'sha256': sha(binary), 'bytes': binary.stat().st_size})
 else:
  config = json.loads((EVIDENCE / 'android-x86_64-emulator-config.json').read_text())
  assert config['revision'] == REVISION and config['sourceTreeSha256'] == SOURCE_HASH
  assert config['sourceDirty'] is False and config['bootCompleted'] is True
  assert config['serial'] == 'emulator-5584' and config['abi'] == 'x86_64'
 members = {}
 def include(source, archive_path):
  assert source.is_file() and not source.is_symlink(), source
  archive_path = str(archive_path)
  assert archive_path not in members, archive_path
  members[archive_path] = source
 for helper in ('run-owned-final.py', 'check-master124-cli.py', 'package-owned-final.py'):
  include(ROOT / 'artifacts/rebase-validation' / helper, Path('inputs/reproduction') / helper)
 for entry in group['paths']:
  path = EVIDENCE / entry
  assert path.exists(), path
  if path.is_dir():
   for child in sorted(path.rglob('*')):
    if child.is_file() and child.name != 'upstream723-source.tar.gz': include(child, child.relative_to(EVIDENCE))
  else: include(path, path.relative_to(EVIDENCE))
 for entry in group.get('history', []):
  path = ROOT / 'artifacts/review-final' / entry
  assert path.is_file(), path
  include(path, Path('build-history') / path.name)
 fixture_hashes = manifest.get('fixtureHashes', manifest.get('fixtureAndRuntimeHashes', {}))
 for path, expected in fixture_hashes.items():
  assert sha(ROOT / path) == expected, path
 for path in sorted((ROOT / 'test/fixtures/javascript').rglob('*')):
  if path.is_file(): include(path, Path('inputs') / path.relative_to(ROOT))
 if name.startswith('macos-'):
  for child in sorted((ROOT / 'artifacts/rebase-validation/master124-origin').rglob('*')):
   if child.is_file() and child.suffix in ('.json', '.checksums', '.log'):
    include(child, Path('inputs/master124-origin') / child.relative_to(ROOT / 'artifacts/rebase-validation/master124-origin'))
 if name.startswith('macos-'):
  released = json.loads((EVIDENCE / ('compatibility-' + name) / 'manifest.json').read_text())
  for path, expected in released['fixtureHashes'].items():
   original = ROOT / path
   assert sha(original) == expected, path
   include(original, Path('inputs') / path)
 comparison = EVIDENCE / 'comparisons' / (group['corpus'] + '.json')
 if comparison.exists():
  report = json.loads(comparison.read_text())
  assert report['candidateRevision'] == REVISION and report['referenceRevision'] == REVISION
  assert report['acceptanceEligible'] and report['comparedArtifacts'] == 60
  assert not report['provenanceIssues'] and not report['differences']
 for command_file in sorted(EVIDENCE.glob('*command.json')):
  if name in command_file.name or (name == 'android-emulator' and 'android-x86_64-emulator' in command_file.name):
   include(command_file, command_file.relative_to(EVIDENCE))
 proof = {'revision': REVISION, 'sourceTreeSha256': SOURCE_HASH, 'dirty': False,
          'group': name, 'comparableArtifactCount': 60, 'binaryHashesVerified': binary_proofs,
          'sourceEvidenceDirectory': 'artifacts/rebase-validation/final',
          'externalInputs': ([{'repositoryPath': 'artifacts/rebase-validation/final/master124-upstream-resume-classification/upstream723-source.tar.gz', 'sha256': sha(EVIDENCE / 'master124-upstream-resume-classification/upstream723-source.tar.gz'), 'bytes': (EVIDENCE / 'master124-upstream-resume-classification/upstream723-source.tar.gz').stat().st_size, 'reason': 'Upstream source archive is published once separately rather than duplicating94MiB in both Mac evidence bundles.'}] if name.startswith('macos-') else []),
          'buildHistory': 'Prior compile/toolchain commands are retained separately; final acceptance is established by the final clean producer provenance and executed binary hashes.',
          'files': {arc: {'repositoryPath': str(path.relative_to(ROOT)),
                          'bytes': path.stat().st_size, 'sha256': sha(path)}
                    for arc, path in sorted(members.items())}}
 proof_path = OUTPUT / (name + '.package-manifest.json')
 proof_path.write_text(json.dumps(proof, indent=2) + '\n')
 include(proof_path, 'PACKAGE-MANIFEST.json')
 return members


def package(name, group):
 guard_source()
 members = prepare(name, group)
 original = {arc: {'repositoryPath': str(path.relative_to(ROOT)), 'sha256': sha(path),
                   'bytes': path.stat().st_size} for arc, path in sorted(members.items())}
 archive = OUTPUT / (name + '.tar.gz')
 with tarfile.open(archive, 'w:gz') as tar:
  for arc, path in sorted(members.items()): tar.add(path, arcname=arc, recursive=False)
 assert archive.stat().st_size < 95 * 1024 * 1024, archive
 with tarfile.open(archive, 'r:gz') as tar:
  contents = tar.getmembers()
  assert len(contents) == len(members)
  for member in contents:
   assert member.isfile() and member.name in members, member.name
   digest = hashlib.sha256()
   stream = tar.extractfile(member)
   for block in iter(lambda: stream.read(1024 * 1024), b''): digest.update(block)
   assert digest.hexdigest() == original[member.name]['sha256'], member.name
   assert sha(members[member.name]) == original[member.name]['sha256'], member.name
   assert member.size == original[member.name]['bytes'], member.name
 guard_source()
 proof = {'revision': REVISION, 'sourceTreeSha256': SOURCE_HASH, 'group': name,
          'archive': archive.name, 'archiveBytes': archive.stat().st_size,
          'archiveSha256': sha(archive), 'verifiedFileCount': len(members),
          'files': original}
 (OUTPUT / (name + '.files.json')).write_text(json.dumps(proof, indent=2) + '\n')
 print(json.dumps({key: proof[key] for key in ('group', 'archiveBytes', 'archiveSha256', 'verifiedFileCount')}), flush=True)

if __name__ == '__main__':
 OUTPUT.mkdir(exist_ok=True)
 guard_source()
 for name, group in GROUPS.items():
  if not args.groups or name in args.groups: package(name, group)
