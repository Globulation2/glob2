#!/usr/bin/env python3
"""Run owned final Mac evidence only for an explicitly frozen clean source."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'test'))
from build_provenance import source_identity
from check_javascript_evidence import inventory, payload, provenance

parser = argparse.ArgumentParser()
parser.add_argument('--revision', required=True)
parser.add_argument('--source-hash', required=True)
parser.add_argument('--stage', choices=('rosetta', 'arm-cli', 'comparisons'), required=True)
args = parser.parse_args()
EVIDENCE = ROOT / 'artifacts/rebase-validation/final'
EVIDENCE.mkdir(parents=True, exist_ok=True)


def guard():
    actual = source_identity(ROOT)
    assert actual['revision'] == args.revision, actual
    assert actual['sourceTreeSha256'] == args.source_hash, actual
    assert actual['dirty'] is False and actual['sourceStatus'] == [], actual
    return actual


def command(argv, log):
    guard()
    (EVIDENCE / (log + '.command.json')).write_text(json.dumps(argv, indent=2) + '\n')
    with (EVIDENCE / log).open('w') as stream:
        subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=True)
    guard()


def cli(arch, build):
    binary = str(ROOT / build / 'src/glob2')
    for script, directory in [('check_javascript.py', 'continuation'),
                              ('check_telemetry_simulation.py', 'compatibility')]:
        name = directory + '-macos-' + arch
        command(['python3', 'test/' + script, binary, '--output',
                 'artifacts/rebase-validation/final/' + name], name + '.log')


guard()
if args.stage == 'rosetta':
    config = json.loads((ROOT / 'artifacts/review-final/macos-x86_64-build-config.json').read_text())
    config.update(guard(), sourceDirty=False)
    for wrapper in config['wrappers'].values():
        assert hashlib.sha256(Path(wrapper['path']).read_bytes()).hexdigest() == wrapper['sha256']
    (EVIDENCE / 'macos-x86_64-build-config.json').write_text(json.dumps(config, indent=2) + '\n')
    command(['scons', 'release=1', 'tests', 'build/macos-x86-tests/src/glob2',
             '--build=build/macos-x86-tests',
             'CC=' + str(ROOT / 'build/macos-x86-tools/bin/cc'),
             'CXX=' + str(ROOT / 'build/macos-x86-tools/bin/cxx'), '-j4'],
            'macos-x86_64-final-build.log')
    command(['python3', 'test/check_javascript_corpus.py', '--build-dir', 'build/macos-x86-tests',
             '--output', 'artifacts/rebase-validation/final/macos-x86_64'],
            'macos-x86_64-corpus.log')
    assert len(inventory(EVIDENCE / 'macos-x86_64')) == 60
    cli('x86_64', Path('build/macos-x86-tests'))
elif args.stage == 'arm-cli':
    cli('arm64', Path('build/darwin/client/release'))
else:
    assert len(inventory(EVIDENCE / 'macos-arm64')) == 60
    command(['python3', 'test/check_javascript_evidence.py',
             'artifacts/rebase-validation/final/macos-arm64',
             'artifacts/rebase-validation/final/macos-x86_64', '--output',
             'artifacts/rebase-validation/final/comparisons/macos-x86_64.json'],
            'macos-x86_64-comparison.log')
    report = {'revision': args.revision, 'sourceTreeSha256': args.source_hash,
              'compared': [], 'mismatches': [], 'saveMetadataExcluded': 'MapHeader SHA1 only'}
    for kind in ('continuation', 'compatibility', 'master124'):
        a, b = [EVIDENCE / (kind + '-macos-' + arch) for arch in ('arm64', 'x86_64')]
        for directory in (a, b):
            manifest = json.loads((directory / 'manifest.json').read_text())
            assert manifest['revision'] == args.revision
        for original in sorted(a.rglob('*')):
            if not original.is_file() or not original.name.endswith(('.checksums', '.game.gz', '.replay')):
                continue
            candidate = b / original.relative_to(a)
            assert candidate.is_file(), candidate
            x, y = original.read_bytes(), candidate.read_bytes()
            if original.name.endswith('.game.gz'):
                x, y = payload(x), payload(y)
            name = kind + '/' + str(original.relative_to(a))
            report['compared'].append({'path': name, 'sha256': hashlib.sha256(x).hexdigest()})
            if x != y:
                report['mismatches'].append(name)
    for arch, build in [('arm64', Path('build/darwin/client/release')),
                        ('x86_64', Path('build/macos-x86-tests'))]:
        digest = hashlib.sha256((ROOT / build / 'src/glob2').read_bytes()).hexdigest()
        for kind in ('continuation', 'compatibility', 'master124'):
            manifest = json.loads((EVIDENCE / (kind + '-macos-' + arch) / 'manifest.json').read_text())
            assert manifest['binarySha256'] == digest
    (EVIDENCE / 'comparisons/macos-cli-continuation-and-released.json').write_text(
        json.dumps(report, indent=2) + '\n')
    assert not report['mismatches'], report['mismatches']
    print('PASS: cross-Mac CLI outputs', len(report['compared']))
guard()
