import argparse, hashlib, json, platform, subprocess, sys
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--binary',type=Path,required=True)
p.add_argument('--fixture',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--helpers',type=Path,required=True)
a=p.parse_args()
sys.path.insert(0,str(a.helpers))
from check_telemetry_simulation import detailed_ticks
from check_javascript import complete_ticks
from build_provenance import source_identity
a.output.mkdir(parents=True,exist_ok=False)
manifest={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=a.repo,text=True).strip(),
 'sourceStatus':subprocess.check_output(['git','status','--porcelain'],cwd=a.repo,text=True).splitlines(),
 'binarySha256':hashlib.sha256(a.binary.read_bytes()).hexdigest(),
 'fixtureSha256':hashlib.sha256(a.fixture.read_bytes()).hexdigest(),
 'compiler':subprocess.check_output(['g++','--version'],text=True), 'platform':platform.platform(),'commands':[]}
manifest['sourceIdentity']=source_identity(a.repo)
def orders(path,start,version):
 import struct
 data=path.read_bytes(); token=struct.pack('>HH',0,version); candidates=[]; pos=0
 while (pos:=data.find(token,pos))>=0:
  cursor=pos+4; tick=start; result=[]
  try:
   while cursor<len(data):
    delta,size=struct.unpack_from('>II',data,cursor); cursor+=8
    if not 1<=size<=1024 or delta>128: raise ValueError()
    tick+=delta; kind=data[cursor]; payload=data[cursor+1:cursor+size].hex(); cursor+=size
    sender=data[cursor]; cursor+=5
    result.append({'tick':tick,'type':kind,'sender':sender,'payloadHex':payload})
   if cursor==len(data): candidates.append(result)
  except (ValueError,IndexError,struct.error): pass
  pos+=1
 assert len(candidates)==1
 return candidates[0]
def run(name,save):
 out=a.output/name
 cmd=[str(a.binary),'--run-game','--load-game',str(save),'--ticks','128','--compute-threads','1','--telemetry','checksums','--replay','true','--save','every:64','--save','final','--output-dir',str(out)]
 manifest['commands'].append(cmd)
 with (a.output/(name+'.log')).open('w') as log: subprocess.run(cmd,cwd=a.repo,stdout=log,stderr=subprocess.STDOUT,check=True)
 return (out/'game.replay.checksums').read_bytes()
whole=run('workers1',a.fixture)
resume=run('resumed64',a.output/'workers1/checkpoint-64.game.gz')
fields=detailed_ticks(whole); tail=detailed_ticks(resume)
mismatches=[t for t,v in tail.items() if fields[t]!=v]
manifest['comparison']={'detailedFieldComparison':'all stored team/entity fields; exclude aggregate only because format metadata changes','firstMismatchTick':min(mismatches) if mismatches else None,'mismatchTicks':mismatches,'freshTraceSha256':hashlib.sha256(whole).hexdigest(),'resumeTraceSha256':hashlib.sha256(resume).hexdigest()}
assert len(fields)==128 and len(tail)==64
assert not manifest['sourceStatus']
version=json.loads((a.output/'workers1/result.json').read_text())['resolved']['save_version']
manifest['freshOrders']=orders(a.output/'workers1/game.replay',0,version)
manifest['resumedOrders']=orders(a.output/'resumed64/game.replay',64,version)
(a.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest['comparison']),flush=True)
