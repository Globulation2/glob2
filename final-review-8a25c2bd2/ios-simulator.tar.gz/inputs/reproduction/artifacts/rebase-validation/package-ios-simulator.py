#!/usr/bin/env python3
"""Retain exact-source iOS Simulator proof and verify every archived member."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'test'))
from build_provenance import source_identity
from check_javascript_evidence import inventory, provenance, provenance_issues

p = argparse.ArgumentParser()
p.add_argument('--revision', required=True)
p.add_argument('--source-hash', required=True)
a = p.parse_args()
FINAL = ROOT / 'artifacts/rebase-validation/final'
OUTPUT = FINAL / 'package-staging'
BUILD = ROOT / 'build/ios/simulator/arm64/15.0/client/release'
PROJECT = BUILD / 'xcode-script-tests'
APP = PROJECT / 'build/Release-iphonesimulator/Glob2ScriptTests.app'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def guard():
    source = source_identity(ROOT)
    assert source['revision'] == a.revision, source
    assert source['sourceTreeSha256'] == a.source_hash, source
    assert source['dirty'] is False and source['sourceStatus'] == [], source


guard()
manifest = provenance(FINAL / 'ios-simulator')
assert manifest['revision'] == a.revision and manifest['sourceTreeSha256'] == a.source_hash
assert not provenance_issues(manifest, manifest)
assert len(inventory(FINAL / 'ios-simulator')) == 60
assert manifest['executableSha256'] == sha(APP / 'Glob2ScriptTests')
result = json.loads((FINAL / 'ios-simulator/evidence/result.json').read_text())
assert result['runId'] == manifest['runId'] and result['exitCode'] == 0
build = json.loads((PROJECT / 'scripting-build.json').read_text())
assert build['revision'] == a.revision and build['dirty'] is False
for name, digest in manifest['fixtureHashes'].items():
    assert sha(ROOT / name) == digest, name
comparison = json.loads((FINAL / 'comparisons/ios-simulator.json').read_text())
assert comparison['candidateRevision'] == comparison['referenceRevision'] == a.revision
assert comparison['acceptanceEligible'] and comparison['comparedArtifacts'] == 60
assert not comparison['provenanceIssues'] and not comparison['differences']
config = json.loads((FINAL / 'ios-simulator-config.json').read_text())
assert config['revision'] == a.revision and config['sourceTreeSha256'] == a.source_hash
assert config['device'] == '9FABD46D-BA53-4A0D-A634-4F40CB3EF3B3'
assert config['physicalDeviceAcceptance'] is False
members = {}


def include(path, name):
    assert path.is_file() and not path.is_symlink(), path
    name = str(name)
    assert name not in members, name
    members[name] = path


for name in ('ios-simulator', 'ios-simulator-build.log', 'ios-simulator-build-command.json',
             'ios-simulator-boot.log', 'ios-simulator-run.log', 'ios-simulator-cleanup.log',
             'ios-simulator-config.json', 'ios-simulator-comparison.log',
             'comparisons/ios-simulator.json'):
    path = FINAL / name
    if path.is_dir():
        for child in sorted(path.rglob('*')):
            if child.is_file():
                include(child, child.relative_to(FINAL))
    else:
        include(path, name)
for name in ('CMakeLists.txt', 'Info.plist', 'scripting-build.json'):
    include(PROJECT / name, Path('build-config') / name)
for name in ('BuildConfig.h', 'TestBuildProvenance.h'):
    include(BUILD / 'include/glob2' / name, Path('build-config') / name)
for name in ('mobile/ios_script_tests.py', 'mobile/ios.py', 'mobile/ios/ScriptTests.mm',
             'test/check_javascript_evidence.py', 'test/build_provenance.py',
             'artifacts/rebase-validation/package-ios-simulator.py'):
    include(ROOT / name, Path('inputs/reproduction') / name)
for path in sorted((ROOT / 'test/fixtures/javascript').rglob('*')):
    if path.is_file():
        include(path, Path('inputs') / path.relative_to(ROOT))
proof = {'revision': a.revision, 'sourceTreeSha256': a.source_hash, 'dirty': False,
         'group': 'ios-simulator', 'comparableArtifactCount': 60,
         'executedExecutableSha256': manifest['executableSha256'],
         'physicalDeviceAcceptance': False,
         'files': {name: {'repositoryPath': str(path.relative_to(ROOT)),
                          'sha256': sha(path), 'bytes': path.stat().st_size}
                   for name, path in sorted(members.items())}}
proof_path = OUTPUT / 'ios-simulator.package-manifest.json'
proof_path.write_text(json.dumps(proof, indent=2) + '\n')
include(proof_path, 'PACKAGE-MANIFEST.json')
original = {name: {'repositoryPath': str(path.relative_to(ROOT)),
                  'sha256': sha(path), 'bytes': path.stat().st_size}
            for name, path in sorted(members.items())}
archive = OUTPUT / 'ios-simulator.tar.gz'
with tarfile.open(archive, 'w:gz') as stream:
    for name, path in sorted(members.items()):
        stream.add(path, arcname=name, recursive=False)
assert archive.stat().st_size < 95 * 1024 * 1024
with tarfile.open(archive, 'r:gz') as stream:
    assert len(stream.getmembers()) == len(members)
    for item in stream.getmembers():
        assert item.isfile() and item.name in members
        digest = hashlib.sha256()
        data = stream.extractfile(item)
        for block in iter(lambda: data.read(1024 * 1024), b''):
            digest.update(block)
        assert digest.hexdigest() == original[item.name]['sha256'], item.name
        assert sha(members[item.name]) == original[item.name]['sha256'], item.name
        assert item.size == original[item.name]['bytes'], item.name
guard()
proof = {'revision': a.revision, 'sourceTreeSha256': a.source_hash,
         'group': 'ios-simulator', 'archive': archive.name,
         'archiveBytes': archive.stat().st_size, 'archiveSha256': sha(archive),
         'verifiedFileCount': len(members), 'files': original}
(OUTPUT / 'ios-simulator.files.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({key: proof[key] for key in ('group', 'archiveBytes', 'archiveSha256', 'verifiedFileCount')}))
