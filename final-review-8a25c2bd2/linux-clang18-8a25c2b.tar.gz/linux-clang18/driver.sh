#!/bin/bash
set -u
repo=$1
label=$2
build=$3
compiler=${4:-gcc}
cd "$repo"
expected=8a25c2bd2440e99246171967a31c68dc15917f95
test "$(git rev-parse HEAD)" = "$expected" && test -z "$(git status --porcelain)" || exit 90
logbase="$repo/artifacts/rebase-validation/final-driver/$label"
output="$repo/artifacts/rebase-validation/final/$label"
mkdir -p "$logbase"
if [ "$compiler" = clang ]; then
 scons CC=clang CXX=clang++ --build="$build" release=1 tests "$build/src/glob2" -j4 > "$logbase/build.log" 2>&1
else
 scons release=1 tests "$build/src/glob2" -j4 > "$logbase/build.log" 2>&1
fi
build_code=$?
if [ "$build_code" -ne 0 ]; then exit "$build_code"; fi
mkdir -p "$logbase/focused-profile"
GLOB2_USER_DATA_DIR="$logbase/focused-profile" GLOB2_TEST_ARTIFACTS_ROOT="$logbase/focused" "$build/test/glob2-engine-tests" --test-suite=JavaScriptCompatibility --test-case='JavaScript upgrade retains genuine master124 experiments and continuation' --reporters=junit --out="$logbase/focused.xml" > "$logbase/focused.log" 2>&1
focused_code=$?
printf '{"focusedMaster124ExitCode":%s}\n' "$focused_code" > "$logbase/focused-status.json"
python3 test/check_javascript_corpus.py --build-dir "$build" --output "$output" > "$logbase/corpus.log" 2>&1
corpus_code=$?
python3 test/check_javascript.py "$build/src/glob2" --output "$output/cli-continuations" > "$output/cli-continuations.log" 2>&1
cli_code=$?
python3 test/check_telemetry_simulation.py "$build/src/glob2" --output "$output/released" > "$output/released.log" 2>&1
released_code=$?
python3 test/check_telemetry_simulation.py "$build/src/glob2" --parallel-ai --output "$output/released-parallel-ai" > "$output/released-parallel-ai.log" 2>&1
parallel_code=$?
python3 ../check-master124-baseline.py "$build/src/glob2" "$output/master124-baseline" ../master124-baseline.checksums > "$output/master124-baseline.log" 2>&1
master_code=$?
ui_code=null
if [ "$label" = linux-gcc13 ]; then
 python3 test/run_tests.py --build-dir "$build" --binary engine --filter 'ScriptEditor/*' --filter 'UIPresentation/*' --artifacts "$output/ui" --junit "$output/ui-junit.xml" -j2 > "$output/ui.log" 2>&1
 ui_code=$?
 "$build/test/glob2-engine-tests" --test-suite=ScriptEditor,UIPresentation --list-test-cases > "$output/ui-producer.log" 2>&1
 producer_code=$?
 sha256sum "$build/test/glob2-engine-tests" >> "$output/ui-producer.log"
 if [ "$producer_code" -ne 0 ]; then ui_code=$producer_code; fi
fi
cp "$logbase/build.log" "$output/build.log"
cp "$logbase/corpus.log" "$output/corpus-driver.log"
cp "$logbase/focused.xml" "$output/focused-master124.xml"
cp "$logbase/focused.log" "$output/focused-master124.log"
cp "$0" "$output/driver.sh"
python3 - "$output" "$build_code" "$focused_code" "$corpus_code" "$cli_code" "$released_code" "$parallel_code" "$master_code" "$ui_code" <<'PY'
import json,pathlib,sys
names=('build','focusedMaster124','corpus','cliContinuations','released','releasedParallelAI','master124Baseline','ui')
codes=dict(zip(names,(None if code=='null' else int(code) for code in sys.argv[2:])))
(pathlib.Path(sys.argv[1])/'execution-status.json').write_text(json.dumps(codes,indent=2)+'\n')
print(json.dumps(codes),flush=True)
raise SystemExit(int(any(code for code in codes.values() if code is not None)))
PY
