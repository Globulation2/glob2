#!/bin/bash
set -uo pipefail
git config --global --add safe.directory /workspace
cd /workspace
mkdir -p artifacts/browser-linux
{
 uname -a
 cat /etc/os-release
 node --version
 npm --version
 python3 --version
 git --version
 git status --short
 python3 test/build_provenance.py
 sha256sum build/emscripten/client/release/*
} > artifacts/browser-linux/environment.log 2>&1
cd browser
npm ci > ../artifacts/browser-linux/npm-ci.log 2>&1 || exit $?
python3 -m http.server 8789 --bind 127.0.0.1 --directory ../build/emscripten/client/release > ../artifacts/browser-linux/http.log 2>&1 &
server_pid=$!
trap 'kill "$server_pid" 2>/dev/null || true' EXIT
GLOB2_TEST_URL=http://127.0.0.1:8789 npx playwright test tests/determinism.spec.js --workers=1 --config ../artifacts/browser-linux/playwright.config.cjs > ../artifacts/browser-linux/tests.log 2>&1
result=$?
cd ..
printf '%s\n' "$result" > artifacts/browser-linux/exit.txt
python3 test/build_provenance.py > artifacts/browser-linux/source-after.json
exit "$result"
