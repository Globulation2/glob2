from pathlib import Path
import sys,gzip,subprocess,json,hashlib
root=Path.cwd();sys.path.insert(0,str(root/'test'))
from benchmark_parallel_compute import execute
from compare_save_continuation import records
binary=root/'build/darwin/client/release/src/glob2'; out=root/'artifacts/merge-validation/references'
fixtures=root/'test/fixtures/gradient-pipeline';fixtures.mkdir(parents=True,exist_ok=True)
cases=[('gd-large-4ai-1024',root/'games/gd-large-4ai.game.gz',1024),('gd-bigarena-2048',root/'games/gd-bigarena-long.game.gz',2048),('v108-reload-256',root/'test/fixtures/team-stats/telemetry-expansion-validation/checkpoint-1024-v108.game.gz',1280),('maxima',root/'test/maxima/fixtures/save-continuation/checkpoint-30000-v115.game.gz',30512)]
metadata=[]
for name,save,stop in cases:
 traces=[]
 for workers in (0,1):
  dest=out/(name+f'-w{workers}')
  result=execute(binary,['--load-game',str(save),'--ticks',str(stop),'--gradient-workers',str(workers),'--telemetry','checksums'],dest)
  traces.append((dest/'game.replay.checksums').read_bytes())
  metadata.append(result)
 assert traces[0]==traces[1],name
 if name=='maxima':
  values={str(t):hashlib.sha256(state).hexdigest() for t,state in records(traces[0])}
  (root/'test/maxima/fixtures/save-continuation/expected-gradient-pipeline-30000-30512.json').write_text(json.dumps(values,sort_keys=True,indent=2)+'\n')
 else:
  (fixtures/(name+'.checksums.gz')).write_bytes(gzip.compress(traces[0],mtime=0))
 print(name,len(traces[0]),hashlib.sha256(traces[0]).hexdigest(),flush=True)
(out/'metadata.json').write_text(json.dumps(metadata,indent=2))
