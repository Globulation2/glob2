import hashlib,json
from pathlib import Path
out=Path('artifacts/generator-studio')
report=json.loads((out/'native-report.json').read_text())
assert report['versionMinor']==150 and report['simRevision']==39
for name,trace in [('generator-studio-trace.json',out/'tickrate-native-game/game.replay.checksums'),('studio-trace.json',out/'tickrate-ai-native/result/game.replay.checksums')]:
 path=Path('browser/tests/fixtures')/name; data=json.loads(path.read_text()); previous=data.copy(); payload=trace.read_bytes()
 data.update(traceBytes=len(payload),traceSha256=hashlib.sha256(payload).hexdigest())
 if name.startswith('generator'):
  for key in ['packageHash','worldFingerprint','checksum','versionMinor','simRevision','simVersion']: data[key]=report[key]
  assert (out/'tickrate-native-loaded/game.replay.checksums').read_bytes()==payload
 path.write_text(json.dumps(data,indent=2)+'\n')
 print(json.dumps({'fixture':name,'before':previous,'after':data},indent=2))
