#!/bin/bash
set -euo pipefail
export LD_LIBRARY_PATH=/tmp/glob2-sdl3/prefix/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
GLOB2_TEST_ARTIFACTS=$PWD/artifacts artifacts/generator-studio/build/test/glob2-engine-tests --test-suite=MapPreview --test-case='generator Studio*' --no-breaks=true > artifacts/generator-studio/tickrate-native-preview.log 2>&1
python3 test/run_tests.py --build-dir artifacts/generator-studio/build --filter 'ScriptGenerator/*' --filter 'MapPreview/*' --filter 'ScreenExecution/*' --filter 'BuildingAreaEffects/*' --filter 'EngineSession/*' --filter 'GameSpeed/*' --jobs 8 > artifacts/generator-studio/tickrate-native-tests.log 2>&1
