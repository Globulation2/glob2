#!/bin/bash
set -euo pipefail
cd "/home/bradley/.codex/worktrees/f25d/glob2"
export LD_LIBRARY_PATH=/tmp/glob2-sdl3/prefix/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
export GLOB2_USER_DATA_DIR=$PWD/artifacts/generator-studio/integration-native-profile
export GLOB2_TEST_ARTIFACTS=$PWD/artifacts
artifacts/generator-studio/build/src/glob2 --generator-package artifacts/generator-studio/frozen-package.json --run-game --generator examples:swamp --map-seed 19 --param width=7 --param height=7 --param teams=4 --param workers=4 --candidates 1 --game-seed 19 --player nicowar --player nicowar --player nicowar --player nicowar --ticks 64 --replay true --telemetry checksums --save initial --save final --output-dir artifacts/generator-studio/v150-native-game > artifacts/generator-studio/v150-native-game.log 2>&1
artifacts/generator-studio/build/src/glob2 --run-game --load-game artifacts/generator-studio/v150-native-game/initial.game.gz --ticks 64 --replay true --telemetry checksums --save initial --save final --output-dir artifacts/generator-studio/v150-native-loaded > artifacts/generator-studio/v150-native-loaded.log 2>&1
artifacts/generator-studio/build/src/glob2 --run-game --map-file platform/apps/engine-agent/fixtures/ais/two.map.gz --game-seed 19 --player javascript --ai-script 0:examples/javascript/studio-starter.js --player numbi --ticks 1024 --replay true --telemetry checksums --save initial --save final --output-dir artifacts/generator-studio/v150-ai-native/result > artifacts/generator-studio/integration-ai-native.log 2>&1
sha256sum artifacts/generator-studio/v150-native-game/game.replay.checksums artifacts/generator-studio/v150-native-loaded/game.replay.checksums artifacts/generator-studio/v150-ai-native/result/game.replay.checksums > artifacts/generator-studio/integration-native-digests.txt
