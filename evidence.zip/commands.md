# Additional exact commands

```sh
node platform/node_modules/vitest/vitest.mjs run --root platform platform/apps/api/test/generatorStudio.test.ts platform/apps/api/test/generatorStudioRoutes.test.ts platform/apps/api/test/generatorStudioProvider.test.ts platform/apps/api/test/aiStudio.test.ts platform/apps/api/test/aiStudioRoutes.test.ts platform/apps/api/test/aiStudioProvider.test.ts platform/apps/api/test/accountExport.test.ts platform/apps/web/test/generatorStudio.test.tsx platform/apps/web/test/aiStudioDraft.test.tsx platform/apps/web/test/aiStudioPlaytest.test.tsx platform/apps/web/test/studioChecks.test.tsx platform/packages/db/test/migrationBranches.test.ts platform/packages/protocol/test/protocol.test.ts platform/packages/protocol/test/fixtures.test.ts
python3 -m unittest discover -s test/deployment -p test_update_host.py
python3 -m unittest discover -s test/deployment -p test_online_deploy.py
python3 -m unittest discover -s test/build_system -p test_browser_package.py
python3 -m unittest discover -v -s test/build_system -p test_web_assets.py
```

Native CLI/isolated suite: integration-native-checks.sh. Desktop/phone E2E: integration-ui-checks.sh. These scripts record exact flags and environment, including the isolated scratch tmpfs; every referenced result is in the archive.
