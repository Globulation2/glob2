#!/bin/bash
set -euo pipefail
unshare --user --map-root-user --mount /bin/sh -c '
mount -t tmpfs -o size=512m tmpfs /home/bradley/.codex/worktrees/f25d/glob2/artifacts/generator-studio/isolated-ui
cd /home/bradley/.codex/worktrees/f25d/glob2/platform/apps/web
export PATH=/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:$PATH
export PORT=4296 GENERATOR_E2E_BINARY=/home/bradley/.codex/worktrees/f25d/glob2/artifacts/generator-studio/build/src/glob2 GENERATOR_E2E_WORKDIR=artifacts/generator-studio/build/runtime-assets ENGINE_SET_LIBRARY_PATH=/tmp/glob2-sdl3/prefix/lib
exec node ../../node_modules/.bin/playwright test -c e2e/playwright.config.ts e2e/generator-studio.spec.ts e2e/aiStudio.spec.ts --output /home/bradley/.codex/worktrees/f25d/glob2/artifacts/generator-studio/integration-ui-results'
