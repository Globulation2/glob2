The asynchronous recording-admission fixture intermittently failed on GCC 11 with three dropped frames where it expected two. `reserveWhenAvailable()` retries nonblocking admission, and mutex contention legitimately increments the recorder's drop counter, so the absolute expectation included unrelated admission drops.

Measure the exact +1 caused by each explicit ticket cancellation and shutdown against the count after successful admission. Keep the frozen-context, stale-generation, reservation exclusion and new-session assertions unchanged. This changes only the test fixture.

Validation: clean Linux GCC 13 release unit build passes; the complete GameplayRecording suite and repeated admission probes are running. The failing hosted GCC 11 log is retained for comparison. No simulation, save format, dependency or gameplay changes.
