"""Six balanced within-candidate blocks; compare counts within each core budget.
Architecture is measured separately against both historical revisions. Each
configuration has six paired observations against the unchanged participant
count (2 on two cores, 4 otherwise), with every run starting from the same save.
"""
import itertools,json
from run_matrix import OUT, run
plans=json.loads((OUT/'controlled-plan.json').read_text())
counts={2:[1,2],4:[1,2,4],8:[1,2,4,5,6,8]}
def balanced(values,repeat):
    n=len(values)
    if n==2: return values[::1 if repeat%2==0 else -1]
    if n==3:
        order=values[repeat%3:]+values[:repeat%3]
        return order if repeat<3 else order[::-1]
    # Williams balanced crossover: each count occupies every position once,
    # and each ordered adjacent pair occurs once over the six blocks.
    return [values[(i+repeat)%n] for i in [0,1,5,2,4,3]]
for repeat in range(6):
    for case in (list(plans) if repeat%2==0 else list(plans)[::-1]):
        for cores in list(itertools.permutations(counts))[repeat]:
            plan=plans[case]
            for participants in balanced(counts[cores],repeat):
                run(case,cores,participants,'candidate',repeat,plan['ticks'],plan['warmup'],'measure-candidate-tuning')
