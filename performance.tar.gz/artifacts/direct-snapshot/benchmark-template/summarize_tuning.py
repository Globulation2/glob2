"""Within-candidate tuning; no default changes are inferred from a single trial."""
import json,statistics,collections,random,pathlib
root=pathlib.Path(__file__).resolve().parents[3]/'artifacts/direct-snapshot/benchmark'
rows=[json.loads(s) for s in (root/'results.jsonl').read_text().splitlines()]
rows=[r for r in rows if r['phase']=='measure-candidate-tuning']
counts={2:[1,2],4:[1,2,4],8:[1,2,4,5,6,8]}
for case in ['small','large','dense']:
 samples=[r for r in rows if r['case']==case]
 assert all(r['wall_ns']>=10e9 for r in samples)
 for key in ['initial_checksum','final_checksum','initial_tick','measured_ticks','initial_units','final_units','initial_buildings','final_buildings']:
  assert len({r[key] for r in samples})==1,(case,key,'Worker-count equivalence failed')
by_key={tuple(r[k] for k in ['case','cores','participants','repeat']):r for r in rows}
assert len(by_key)==len(rows),'Duplicate tuning observations'
def interval(values):
 rng=random.Random(9173);samples=sorted(statistics.median(rng.choices(values,k=len(values))) for _ in range(10000));return [samples[250],samples[9749]]
metrics=['tps','cpu_us_per_tick','owner_cpu_us_per_tick','rss_median_bytes','owner_iteration_ns_p95','owner_iteration_ns_p99','completion_interval_ns_p95','completion_interval_ns_p99','frame_p95_ns','scene_age_p95_ms']
records=[];choices=[]
for case in ['small','large','dense']:
 for cores,participants in counts.items():
  reference=2 if cores==2 else 4
  local=[]
  for count in participants:
   samples=[by_key[(case,cores,count,i)] for i in range(6)]
   control=[by_key[(case,cores,reference,i)] for i in range(6)]
   changes={}
   for metric in metrics:
    values=[100*(a[metric]/b[metric]-1) for a,b in zip(samples,control) if b[metric]]
    if values:changes[metric]={'median':statistics.median(values),'values':values,'bootstrap_median_95_percent_interval':interval(values)}
   regression_metrics=[m for m in ['owner_iteration_ns_p95','owner_iteration_ns_p99','completion_interval_ns_p95','completion_interval_ns_p99','frame_p95_ns','scene_age_p95_ms'] if m in changes and changes[m]['bootstrap_median_95_percent_interval'][0]>0]
   row={'case':case,'cores':cores,'participants':count,'reference_participants':reference,'pairs':6,'absolute_medians':{m:statistics.median(r[m] for r in samples) for m in metrics},'percent_changes':changes,'repeatable_regression_metrics':regression_metrics}
   local.append(row);records.append(row)
  qualifying=[r for r in local if not r['repeatable_regression_metrics']]
  best=max(r['absolute_medians']['tps'] for r in qualifying)
  eligible=[r for r in qualifying if r['absolute_medians']['tps']>=.97*best]
  choice=min(eligible,key=lambda r:r['participants'])
  choices.append({'case':case,'cores':cores,'selected_participants':choice['participants'],'best_qualifying_tps':best,'selected_tps':choice['absolute_medians']['tps']})
budget_choices=[]
for cores,participants in counts.items():
 eligible=set(participants)
 for case in ['small','large','dense']:
  local=[r for r in records if r['case']==case and r['cores']==cores and not r['repeatable_regression_metrics']]
  best=max(r['absolute_medians']['tps'] for r in local)
  eligible &= {r['participants'] for r in local if r['absolute_medians']['tps']>=.97*best}
 budget_choices.append({'cores':cores,'selected_participants':min(eligible) if eligible else None,'eligible_in_every_fixture':sorted(eligible),'rule':'Require the 3% throughput and tail/frame/age criteria in every fixture; do not average away a workload regression.'})
result={'budget_choices':budget_choices,'method':'Six balanced within-candidate pairs. Select the smallest count within 3% of the best qualifying median TPS. A positive lower endpoint of the paired bootstrap median 95% interval flags repeatable tail/frame/age regression versus unchanged settings. These single-machine results do not establish a cross-hardware default.','records':records,'choices':choices}
(root/'tuning-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for row in choices:print(row)
