import os,json
from run_matrix import OUT, triplet
os.environ['GLOB2_BENCH_CPU_LIST']='4-7'
plans=json.loads((OUT/'controlled-plan.json').read_text())
for case,plan in plans.items():
    triplet(case,4,4,0,plan['ticks'],plan['warmup'],'verify-rendered-final',verify=True)
