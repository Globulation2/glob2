"""Paired results; preserve raw values and do not conflate tuning with architecture."""
from pathlib import Path
import json, statistics, collections, random, argparse
parser=argparse.ArgumentParser();parser.add_argument("--phase",action="append");args=parser.parse_args()
phases=args.phase or ["measure-architecture-final","measure-paced-final","measure-gpu-final"]

def bootstrap_median(values):
    rng=random.Random(9173)
    samples=sorted(statistics.median(rng.choices(values,k=len(values))) for _ in range(10000))
    return [samples[250],samples[9749]]
root=Path(__file__).resolve().parents[3]/'artifacts/direct-snapshot/benchmark'
rows=[json.loads(line) for line in (root/'results.jsonl').read_text().splitlines()]
counter_metrics=['captures','capture_ns','capture_preparation_ns','copied_bytes','component_reuses','tracked_allocations',
                 'simulation_wait_ns','simulation_join_wait_ns','simulation_lane_wait_ns',
                 'presentation_active_ns','presentation_chunks','presentation_submitted','presentation_replaced']
for row in rows:
    start,end=row['counters']['start'],row['counters']['end']
    for name in counter_metrics:
        row[name+'_per_tick']=(end.get(name,0)-start.get(name,0))/row['measured_ticks']
    for name in ['allocated_buffers','reusable_buffers','leased_buffers','retained_bytes','capacity_bytes','leased_bytes']:
        row['end_'+name]=end.get(name,0)
groups=collections.defaultdict(dict)
for row in rows:
    if row['phase'] not in phases: continue
    key=tuple(row[k] for k in ('phase','case','cores','participants','repeat'))
    groups[key][row['revision']]=row
metrics=['tps','cpu_us_per_tick','owner_cpu_us_per_tick','rss_median_bytes',
         'owner_iteration_ns_p50','owner_iteration_ns_p95','owner_iteration_ns_p99',
         'completion_interval_ns_p95','completion_interval_ns_p99','frame_p95_ns','scene_age_p95_ms']
metrics += [name+'_per_tick' for name in counter_metrics]
metrics += ['end_'+name for name in ['allocated_buffers','reusable_buffers','leased_buffers','retained_bytes','capacity_bytes','leased_bytes']]
paired=collections.defaultdict(lambda:collections.defaultdict(list))
absolute=collections.defaultdict(lambda:collections.defaultdict(list))
for key,triple in groups.items():
    if set(triple)!= {'baseline','merged','candidate'}: raise RuntimeError(f'Incomplete triplet: {key}')
    for reference in ['baseline','merged']:
        group=key[:-1]+(reference,)
        for metric in metrics:
            a,b=triple[reference][metric],triple['candidate'][metric]
            if a:paired[group][metric].append((b/a-1)*100)
    for revision,row in triple.items():
        for metric in metrics:absolute[key[:-1]+(revision,)][metric].append(row[metric])
output={'paired':[], 'absolute':[]}
for group,measurements in paired.items():
    record=dict(zip(('phase','case','cores','participants','reference'),group))
    record['pairs']=len(measurements['tps'])
    record['percent_changes']={metric:{'median':statistics.median(values),'min':min(values),'max':max(values),
                                     'values':values,'bootstrap_median_95_percent_interval':bootstrap_median(values)} for metric,values in measurements.items()}
    record['complete']=record['pairs']>=6
    output['paired'].append(record)
for group,measurements in absolute.items():
    record=dict(zip(('phase','case','cores','participants','revision'),group))
    record['metrics']={metric:{'median':statistics.median(values),'min':min(values),'max':max(values)}
                       for metric,values in measurements.items()}
    output['absolute'].append(record)
(root/'paired-summary.json').write_text(json.dumps(output,indent=2)+'\n')
for row in output['paired']:
    changes=row['percent_changes']
    print(row['phase'],row['case'],row['cores'],row['participants'],row['reference'],f"pairs={row['pairs']}",
          f"TPS {changes['tps']['median']:+.2f}%", f"CPU {changes['cpu_us_per_tick']['median']:+.2f}%",
          f"p95 completion {changes['completion_interval_ns_p95']['median']:+.2f}%")
