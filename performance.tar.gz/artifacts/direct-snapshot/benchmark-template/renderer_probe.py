import ctypes as c,json,os
s=c.CDLL('/home/bradley/glob2-claude/build/sdl3/prefix/lib/libSDL3.so')
s.SDL_Init.argtypes=[c.c_uint];s.SDL_Init.restype=c.c_bool
s.SDL_CreateWindow.argtypes=[c.c_char_p,c.c_int,c.c_int,c.c_uint64];s.SDL_CreateWindow.restype=c.c_void_p
s.SDL_CreateRenderer.argtypes=[c.c_void_p,c.c_char_p];s.SDL_CreateRenderer.restype=c.c_void_p
s.SDL_GetRendererName.argtypes=[c.c_void_p];s.SDL_GetRendererName.restype=c.c_char_p
s.SDL_GetCurrentVideoDriver.restype=c.c_char_p
assert s.SDL_Init(0x20)
w=s.SDL_CreateWindow(b'Glob2 benchmark backend probe',800,600,0)
assert w
r=s.SDL_CreateRenderer(w,None);assert r
print(json.dumps({'sdl_renderer':s.SDL_GetRendererName(r).decode(),'video_driver':s.SDL_GetCurrentVideoDriver().decode(),'environment':{k:v for k,v in os.environ.items() if k.startswith(('SDL_','LIBGL_','LP_','DISPLAY'))}},indent=2))
s.SDL_Quit()
