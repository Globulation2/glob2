"""Controlled three-revision rendering benchmark; invoked inside an owned cpuset."""
import argparse, csv, hashlib, json, os, pathlib, resource, subprocess, time
ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = ROOT / 'artifacts/direct-snapshot/benchmark'
WORK = {name: pathlib.Path('/home/bradley/.codex/worktrees') / folder / 'glob2' for name, folder in
        [('baseline', 'render-bench-baseline'), ('merged', 'render-bench-final')]}
WORK['candidate'] = ROOT
BIN = {name: directory / 'build/linux/client/release/test/glob2-engine-tests' for name, directory in WORK.items()}
BIN['candidate'] = OUT / 'candidate-engine-tests'
FIXTURES = {
    'small': ROOT / 'artifacts/render-master-benchmark/fixture-balanced/initial.game.gz',
    'large': ROOT / 'artifacts/render-master-benchmark/fixture-512/final.game.gz',
    'dense': ROOT / 'artifacts/direct-snapshot/dense-fixture-candidate/final.game.gz',
}
CONFIGS = [(cores, participants) for cores in (2, 4, 8) for participants in (1, 2, 4, 5, 6, 8) if participants <= cores]
REVISIONS = ['baseline', 'merged', 'candidate']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(case, cores, participants, revision, repeat, ticks, warmup, phase, *, verify=False, paced=False, gpu=False, draw=True):
    name = f'{phase}-{case}-{cores}cores-{participants}participants-{repeat}-{revision}'
    output = OUT / 'runs' / name
    output.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ)
    env.update(GLOB2_TEST_SOURCE_ROOT=str(WORK[revision]), GLOB2_TEST_DISPLAY='1', SDL_AUDIODRIVER='dummy',
        SDL_VIDEODRIVER='x11', SDL_VIDEO_DRIVER='x11', SDL_AUDIO_DRIVER='dummy', LP_NUM_THREADS='1', GLOB2_USER_DATA_DIR=str(output / 'profile'),
        GLOB2_TEST_ARTIFACTS_ROOT=str(output / 'artifacts'), GLOB2_BENCH_FIXTURE=str(FIXTURES[case]),
        GLOB2_BENCH_THREADS=str(participants), GLOB2_BENCH_DRAW=str(int(draw)), GLOB2_BENCH_FPS='60',
        GLOB2_BENCH_WARMUP=str(warmup), GLOB2_BENCH_TICKS=str(ticks), GLOB2_BENCH_VERIFY=str(int(verify)),
        GLOB2_BENCH_PACED=str(int(paced)), GLOB2_BENCH_GL=str(int(gpu)))
    if not gpu: env['LIBGL_ALWAYS_SOFTWARE'] = '1'
    else: env.pop('LIBGL_ALWAYS_SOFTWARE', None)
    cpus = os.environ.get('GLOB2_BENCH_CPU_LIST', ','.join(map(str, range(16 - cores, 16))))
    command = ['taskset', '-c', cpus]
    if not gpu: command += ['xvfb-run', '-a', '-s', '-screen 0 800x600x24']
    command += [str(BIN[revision]), '--test-suite=RenderRevisionBenchmark', '--no-breaks=true']
    meta = dict(name=name, case=case, cores=cores, participants=participants, revision=revision, repeat=repeat,
        phase=phase, verify=verify, paced=paced, gpu=gpu, draw=draw, command=command, cwd=str(WORK[revision]),
        environment={k:v for k,v in env.items() if k.startswith(('GLOB2_', 'SDL_', 'LP_', 'LIBGL_', 'DISPLAY'))},
        binary_sha256=digest(BIN[revision]), fixture_sha256=digest(FIXTURES[case]), started_epoch=time.time())
    with (output / 'run.log').open('w') as log:
        child = subprocess.Popen(command, cwd=WORK[revision], env=env, stdout=log, stderr=subprocess.STDOUT)
        _, status, usage = os.wait4(child.pid, 0)
        child.returncode = os.waitstatus_to_exitcode(status)
    meta.update(returncode=child.returncode, finished_epoch=time.time(), lifetime_cpu_s=usage.ru_utime+usage.ru_stime,
                lifetime_peak_rss_bytes=usage.ru_maxrss*1024)
    (output / 'invocation.json').write_text(json.dumps(meta, indent=2)+'\n')
    if child.returncode: raise RuntimeError(f'{name}: exit {child.returncode}; see run.log')
    data = {k:int(v) for k,v in next(csv.DictReader(next(output.rglob('metrics.csv')).open())).items()}
    rows = list(csv.DictReader(next(output.rglob('ticks.csv')).open()))
    for key in ('simulation_ns', 'owner_iteration_ns', 'completion_interval_ns'):
        values = sorted(int(row[key]) for row in rows)
        for quantile in (50,95,99): data[f'{key}_p{quantile}'] = values[min(len(values)-1,len(values)*quantile//100)]
    counters = {'start':{}, 'end':{}}
    for row in csv.DictReader(next(output.rglob('counters.csv')).open()):
        counters[row['phase']][row['metric']] = int(row['value'])
    data['counters'] = counters
    data['tps'] = data['measured_ticks'] * 1e9 / data['wall_ns']
    data['cpu_us_per_tick'] = data['process_cpu_ns'] / data['measured_ticks'] / 1000
    data['owner_cpu_us_per_tick'] = data['owner_cpu_ns'] / data['measured_ticks'] / 1000
    data.update({k:meta[k] for k in ('name','case','cores','participants','revision','repeat','phase','verify','paced','gpu','draw')})
    assert data['rss_median_bytes'] > 0
    if draw: assert data['frames'] > 0
    with (OUT/'results.jsonl').open('a') as stream: stream.write(json.dumps(data)+'\n')
    print(f"{name}: {data['tps']:.1f} TPS; {data['wall_ns']/1e9:.1f}s; CPU {data['cpu_us_per_tick']:.1f} us/tick; RSS {data['rss_median_bytes']/2**20:.1f} MiB", flush=True)
    if phase.startswith('measure') and data['wall_ns'] < 10e9: raise RuntimeError('Measurement window too short; re-plan all paired runs')
    return data, output

def triplet(case, cores, participants, repeat, ticks, warmup, phase, **options):
    # Six permutations balance both position and predecessor across six repeats.
    import itertools
    order = list(itertools.permutations(REVISIONS))[repeat % 6]
    results = [run(case,cores,participants,revision,repeat,ticks,warmup,phase,**options) for revision in order]
    for key in ('initial_checksum','final_checksum','initial_tick','measured_ticks','initial_units','final_units','initial_buildings','final_buildings'):
        assert len({data[key] for data,_ in results}) == 1, (case, key, [(data['revision'],data[key]) for data,_ in results])
    if options.get('verify'):
        assert len({digest(next(output.rglob('checksums.txt'))) for _,output in results}) == 1, 'Per-tick checksums differ'
    return results

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('phase', choices=['pilot','verify','measure-fixed','measure-tuning','measure-paced','measure-gpu','control'])
    args=parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    if args.phase == 'pilot':
        plans={}
        for case in FIXTURES:
            readings=[]
            for cores,participants in [(2,1),(4,4),(8,8)]:
                readings += [data for data,_ in triplet(case,cores,participants,0,1000,500,'pilot')]
            fastest=max(data['tps'] for data in readings)
            plans[case]={'ticks':max(1000,int(fastest*15+99)//100*100),'warmup':max(500,int(fastest*3+99)//100*100)}
        (OUT/'plan.json').write_text(json.dumps(plans,indent=2)+'\n')
    else:
        plans=json.loads((OUT/'plan.json').read_text())
        configurations=CONFIGS if args.phase=='measure-tuning' else [(2,2),(4,4),(8,4)]
        repeats=range(6) if args.phase.startswith('measure') else range(1)
        for repeat in repeats:
            cases=list(FIXTURES)
            if repeat%2: cases.reverse()
            for case in cases:
                for cores,participants in configurations:
                    options={'verify':args.phase=='verify','paced':args.phase=='measure-paced','gpu':args.phase=='measure-gpu','draw':args.phase!='control'}
                    ticks,warmup=(400,100) if options['paced'] else (plans[case]['ticks'],plans[case]['warmup'])
                    triplet(case,cores,participants,repeat,ticks,warmup,args.phase,**options)
