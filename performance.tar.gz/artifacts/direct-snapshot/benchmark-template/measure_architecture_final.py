import json
from run_matrix import OUT, triplet
plans=json.loads((OUT/'controlled-plan.json').read_text())
for repeat in range(6):
    cases=['small','large','dense']
    if repeat%2:cases.reverse()
    for case in cases:
        for cores,participants in [(2,2),(4,4),(8,4)]:
            plan=plans[case]
            triplet(case,cores,participants,repeat,plan['ticks'],plan['warmup'],'measure-architecture-final')
