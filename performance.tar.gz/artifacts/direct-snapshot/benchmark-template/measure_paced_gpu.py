import argparse,json
from run_matrix import OUT, triplet
parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['paced','gpu']);args=parser.parse_args()
plans=json.loads((OUT/'controlled-plan.json').read_text())
for repeat in range(6):
    for case in (list(plans) if repeat%2==0 else list(plans)[::-1]):
        plan=plans[case]
        if args.mode=='paced':
            for cores,participants in [(2,2),(4,4),(8,4)]:
                triplet(case,cores,participants,repeat,400,100,'measure-paced-final',paced=True)
        else:
            # Physical-GPU attribution is a distinct four-core comparison;
            # the full core-budget sweep uses the controlled software renderer.
            triplet(case,4,4,repeat,plan['ticks'],plan['warmup'],'measure-gpu-final',gpu=True)
