#pragma once
// Benchmark-only instrumentation, identical in both revisions; never shipped.
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <vector>
#include <time.h>
#include <string>
#include <utility>
namespace RenderBench {
inline uint64_t ns() { return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count(); }
inline uint64_t cpu(clockid_t id) { timespec t{}; clock_gettime(id,&t);return uint64_t(t.tv_sec)*1000000000+t.tv_nsec; }
inline unsigned option(const char* key,unsigned fallback) {const char* v=std::getenv(key);return v?std::strtoul(v,nullptr,10):fallback;}
struct Row { unsigned tick; uint64_t simulation,owner,interval; };
struct Probe {
 using Counters=std::vector<std::pair<std::string,uint64_t>>;
 Counters startCounters,endCounters;
 template<class Game> Counters counters(Game& game) {
  Counters values;
  const auto& store=[&]() -> auto& {if constexpr(requires { game.snapshotStore(); }) return game.snapshotStore(); else return game.snapshots();}();
  const auto c=store.metrics;
  const auto m=store.memoryMetrics();
  const auto e=game.map.computeExecutor().metrics();
  values={{"captures",c.captures},{"capture_ns",c.captureNs},{"capture_preparation_ns",c.preparationNs},
   {"copied_bytes",c.bytesCopied},{"component_reuses",c.reusedComponents},{"tracked_allocations",c.allocations},
   {"allocated_buffers",m.allocatedBuffers},{"reusable_buffers",m.reusableBuffers},{"leased_buffers",m.leasedBuffers},
   {"retained_bytes",m.retainedBytes},{"capacity_bytes",m.capacityBytes},{"leased_bytes",m.leasedBytes},
   {"simulation_wait_ns",e.waitNs},{"simulation_join_wait_ns",e.joinWaitNs},{"simulation_lane_wait_ns",e.laneWaitNs}};
  if constexpr(requires { game.map.computeExecutor().presentationMetrics(); }) {
   const auto p=game.map.computeExecutor().presentationMetrics();
   values.emplace_back("presentation_active_ns",p.activeNs);values.emplace_back("presentation_chunks",p.chunks);
   values.emplace_back("presentation_submitted",p.submitted);values.emplace_back("presentation_replaced",p.replaced);
  }
  return values;
 }

 bool enabled=false,verify=false; unsigned first=0,warm=0,last=0,before=0;
 uint64_t beginNs=0,simulationEnd=0,previousEnd=0,wallStart=0,wallEnd=0,processStart=0,processEnd=0,ownerStart=0,ownerEnd=0;
 std::atomic<unsigned> phase{0}; std::vector<Row> rows; std::vector<uint32_t> checksums;
 void setup(unsigned initial) {enabled=true;verify=option("GLOB2_BENCH_VERIFY",0);first=initial;warm=initial+option("GLOB2_BENCH_WARMUP",500);last=warm+option("GLOB2_BENCH_TICKS",2000);rows.reserve(last-initial);checksums.reserve(last-initial);}
 template<class Game> void begin(Game& game) {
  const auto tick=game.stepCounter;
  if(!enabled)return;before=tick;beginNs=ns();
  if(tick==warm && phase.load(std::memory_order_relaxed)==0) {startCounters=counters(game);beginNs=ns();wallStart=beginNs;previousEnd=beginNs;processStart=cpu(CLOCK_PROCESS_CPUTIME_ID);ownerStart=cpu(CLOCK_THREAD_CPUTIME_ID);phase.store(1);}
 }
 void simulationDone(){if(enabled)simulationEnd=ns();}
 template<class Game> bool end(Game& game) {
  if(!enabled || game.stepCounter==before)return false;
  const auto now=ns();
  if(before>=warm)rows.push_back({unsigned(game.stepCounter),simulationEnd-beginNs,now-beginNs,now-previousEnd});
  previousEnd=now;
  if(verify)checksums.push_back(game.checkSum());
  if(game.stepCounter>=last) {wallEnd=now;processEnd=cpu(CLOCK_PROCESS_CPUTIME_ID);ownerEnd=cpu(CLOCK_THREAD_CPUTIME_ID);endCounters=counters(game);phase.store(2);return true;}
  return false;
 }
};
inline Probe probe;
}
