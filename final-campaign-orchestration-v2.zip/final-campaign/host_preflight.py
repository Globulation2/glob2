import sys,time,json,os
from pathlib import Path
sys.path.insert(0,str(Path('test').resolve()))
import benchmark_resource_refactor as bench

def processes():
 out={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit(): continue
  try:
   stat=(p/'stat').read_text(); fields=stat[stat.rfind(')')+2:].split()
   out[p.name]={'ticks':int(fields[11])+int(fields[12]),'start':fields[19], 'name':stat[stat.find('(')+1:stat.rfind(')')], 'cwd':os.readlink(p/'cwd')}
  except (OSError,ValueError,IndexError): pass
 return out
first=processes();before=bench.host_cpu_snapshot();time.sleep(5);after=bench.host_cpu_snapshot();last=processes()
report=bench.host_cpu_activity(before,after,0);elapsed=report['snapshot_elapsed_s'];hz=os.sysconf('SC_CLK_TCK')
report['process_activity'] = sorted([dict(pid=k,name=v['name'],cwd=v['cwd'],average_cores=(v['ticks']-first[k]['ticks'])/hz/elapsed) for k,v in last.items() if k in first and v['start']==first[k]['start']],key=lambda x:-x['average_cores'])[:15]
Path(sys.argv[1]).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
