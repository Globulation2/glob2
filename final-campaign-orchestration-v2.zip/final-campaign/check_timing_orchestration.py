"""Lightweight mocked orchestration checks: never launches a process/governor."""
import importlib.util
import json
from pathlib import Path
import signal
import sys
import tempfile
from unittest.mock import patch

path=Path(__file__).with_name('run_final_timing.py')
spec=importlib.util.spec_from_file_location('timing',path)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

for campaign,mode in [(c,m) for c in ('priority-fixes','v2-priority') for m in ('success','child-failure','unrestored','launch-interrupt')]:
    with tempfile.TemporaryDirectory() as tmp:
        output=Path(tmp)/'fresh'
        class Child:
            signals=[]
            def poll(self): return None
            def send_signal(self,s): self.signals.append(s)
            def wait(self,**kwargs): return 1 if mode=='child-failure' else 0
        child=Child()
        def launch(command,**kwargs):
            if mode=='launch-interrupt': signal.getsignal(signal.SIGINT)(signal.SIGINT,None)
            (output/campaign).mkdir()
            (output/(campaign+'-governors.json')).write_text(json.dumps({'restored':mode!='unrestored'}))
            (output/campaign/'input-verification.json').write_text(json.dumps({'state':'verified','inputs_unchanged':True}))
            (output/campaign/'summary.json').write_text(json.dumps({'scenarios':{'one':{},'two':{}}}))
            return child
        previous=signal.getsignal(signal.SIGINT)
        with patch.object(sys,'argv',[str(path),'--output',str(output),'--run','--campaign',campaign]),patch.object(m,'input_snapshot',return_value={}),patch.object(m.subprocess,'Popen',side_effect=launch):
            try: result=m.main()
            except RuntimeError:
                assert mode!='success'
            else:
                assert mode=='success' and result==0
        state=json.loads((output/'campaign-state.json').read_text())
        assert state['status']==('complete' if mode=='success' else 'failed')
        assert signal.getsignal(signal.SIGINT)==previous
        if mode=='launch-interrupt': assert child.signals==[signal.SIGINT]
        print('PASS',campaign,mode)
print('All mocked checks passed; no engine, governor or subprocess executed.')

# Integrity checks use real small frozen metadata but mock all large-file hashing,
# library discovery and fixture reads. No ldd or subprocess is run.
prior=json.loads((m.BASE/'priority-timing/paired-01/metadata.json').read_text())
catalogs={str(Path(k).relative_to('data')):v for k,v in prior['data_roots']['baseline']['files'].items()}
provenance=json.loads((m.ROOTS['reuse-v2']/'provenance.json').read_text())
libraries=provenance['runtime_libraries']['sha256']
real_digest=m.benchmark.digest
for problem in ('none','binary','catalog','library','patch','asset'):
    def digest(p):
        p=Path(p)
        if p in m.BINS.values():
            arm=next(k for k,v in m.BINS.items() if p==v)
            return 'changed' if problem=='binary' and arm=='reuse-v2' else m.HASHES[arm]
        if p==m.ROOTS['reuse-v2']/'source.patch' and problem=='patch':return 'changed'
        return real_digest(p)
    def data(root):
        rows=dict(catalogs)
        if root==m.ROOTS['reuse-v2']:
            if problem=='catalog':rows['new-definition.json']='changed'
            if problem=='asset':rows['gfx/new.png']='changed'
        return rows
    def runtime(binary):
        rows=dict(libraries)
        if problem=='library' and binary==m.BINS['reuse-v2']:rows['new-library']='changed'
        return {'sha256':rows}
    with patch.object(m.benchmark,'digest',side_effect=digest),patch.object(m,'data_hashes',side_effect=data),patch.object(m.benchmark,'runtime_libraries',side_effect=runtime),patch.object(m,'validate_manifest',return_value={'scenarios':[]}):
        try: m.input_snapshot({'v2-priority'})
        except RuntimeError: assert problem!='none'
        else: assert problem=='none'
    print('PASS integrity',problem)
assert m.DEFAULT_CAMPAIGNS==('priority-fixes','legacy-refactor','eight-team-refactor','custom-calibration')
plan=m.commands(Path('/nonexistent'),{'v2-priority','v2-legacy','v2-eight-team','v2-custom'})
assert [r['scenario_count'] for r in plan]==[2,98,3,6]
assert [r['measured_pairs'] for r in plan]==[16,8,8,8]
for row in plan:
    assert str(m.BINS['merged']) in row['command'] and str(m.BINS['reuse-v2']) in row['command']
    assert str(m.ROOTS['reuse-v2']) in row['command']
print('PASS optional candidate inventory/default preservation')

for mode in ('prelaunch-interrupt','between-campaign-integrity'):
    with tempfile.TemporaryDirectory() as tmp:
        output=Path(tmp)/'fresh'
        captures=0
        def snapshot(selected):
            global captures
            captures+=1
            if captures==2:
                if mode=='prelaunch-interrupt':signal.getsignal(signal.SIGINT)(signal.SIGINT,None)
                else:return {'changed':True}
            return {}
        previous=signal.getsignal(signal.SIGINT)
        with patch.object(sys,'argv',[str(path),'--output',str(output),'--run','--campaign','v2-priority']),patch.object(m,'input_snapshot',side_effect=snapshot),patch.object(m.subprocess,'Popen') as launch:
            try:m.main()
            except (RuntimeError,InterruptedError):pass
            else:raise AssertionError('Prelaunch failure must stop')
            launch.assert_not_called()
        assert signal.getsignal(signal.SIGINT)==previous
        assert json.loads((output/'campaign-state.json').read_text())['status']=='failed'
        print('PASS',mode,'no child launched')

combined=m.commands(Path('/nonexistent'),{'priority-fixes','priority-refactor','v2-legacy','v2-eight-team','v2-custom'})
assert [r['name'] for r in combined]==['priority-fixes','priority-refactor','v2-legacy','v2-eight-team','v2-custom']
assert [r['measured_pairs'] for r in combined]==[16,16,8,8,8]
ref=combined[1]['command']
assert str(m.BINS['approved']) in ref and str(m.BINS['merged']) in ref and str(m.BINS['reuse-v2']) not in ref
print('PASS three-reference priority attribution before final-candidate corpus')
