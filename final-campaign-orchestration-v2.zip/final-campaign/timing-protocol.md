# Final timing protocol (local evidence, not source documentation)

Coordinator exclusively launches after stopping owned builds, profiling, compression, and other simulations, and checking external host activity. The script does not establish quietness automatically. Keep any contaminated campaign intact and use a fresh output directory for repeats.

Print exact commands without running processes:

```sh
python3 /home/bradley/.codex/worktrees/eded/glob2/artifacts/resource-followup/final-campaign/run_final_timing.py --output /home/bradley/.codex/worktrees/eded/glob2/artifacts/resource-followup/final-campaign/timing-01
```

Coordinator launch adds `--run`. Optional repeated `--campaign` selects priority-fixes, legacy-refactor, eight-team-refactor, or custom-calibration, preserving their order; never reuse an output directory, even after interruption. The script supplies the retained LD_LIBRARY_PATH, CPU affinity0-7 and authorized governor policies0-7. Governor restoration is verified after each campaign. No build or counter profiling occurs inside the campaign.

`timing-plan.json` contains exact maintained-wrapper and runner commands. `runtime-projection.json` retains approximate runtime projections from prior evidence. Priority estimate uses controlled merged/ring paired-01 whole-child wall medians. Legacy/eight-team estimates use both archived window-preflights-f0-da80dbaac baseline/candidate run_ns totals, including98 and3 cases respectively, multiplied by9 warmup+measured pairs. Custom estimate uses all6 current correctness workers4 run_ns totals multiplied by18 launches. These are scheduling estimates (roughly4.5hours combined plus setup/audits), not new performance results or promises; instrumentation, hardware activity, engine revisions and matched window lengths differ.

Reference labels: pure and approved are retained symbolized controls. Their allocated sections differed from historical freezes only in GNU build ID, with retained unchanged-object evidence; full binary hashes are explicitly different and pinned. Merged77fb is the final engine: no optimization was accepted. Pure→approved attributes intended behavior fixes; approved→merged attributes remaining differences relative to that control. Do not infer broader gameplay equivalence from timing.

Custom uses merged77fb twice and distinct byte-identical frozen data roots. Report absolute CPU/wall/RSS and same-engine order/noise calibration. Ratios are not optimization results. One-definition versus512-definition observations are scenario-major descriptive comparisons, without a matched-pair cross-scenario confidence interval. Idle-AI custom maps stress growth/storage and do not represent active-AI economy workloads.

All historical manifests are preserved. The custom timing manifest explicitly selects4 compute threads, AI experiment,4 gradient workers and delay8. Eight-team explicitly selects4 compute threads, AI experiment,2 gradient workers and delay8, matching the historical priority/legacy settings. Full-window failures stop the campaign and retain evidence; shortening requires independently classified new manifests, not silent retries.

Local preparation validation: four mocked orchestration checks passed (success, child failure, failed restoration, interruption during process launch). They invoke no engine, subprocess or governor. Independent optimizer review repaired the launch-interruption race and nested-finally handler cleanup. Exact logs remain in orchestration-checks.log.

## Optional frozen v2 routes

The four original attribution/calibration routes remain the default. Candidate routes require explicit selection and do not imply acceptance: `v2-priority` (2 windows ×16 measured pairs), `v2-legacy` (98×8), `v2-eight-team` (3×8) and `v2-custom` (6×8). All compare frozen merged77fb against frozen worker-owned reuse v2 `4a068846b4adf1aeeebdecbac94fca423f588398319aa0a25f7e5382cee5610b`. Source-tree `3c7eaa506f2bc6b9a13d95157e9d279fcba7e97b49ddbc093412f3b27f0da4b2` and patch `a5cb13ab13e4659c0c2453a36f63ef5fbf29c5b4fba4f4ef63558000a5bc14a2` are bound to candidate provenance; binary, catalogs, runtime libraries, full data-tree equality and provenance stability are audited. Distinct candidate/merged roots already exist; custom comparison here is actual candidate comparison, unlike optional same-binary calibration.

Print the optional full plan without engines:

```sh
python3 artifacts/resource-followup/final-campaign/run_final_timing.py --output artifacts/resource-followup/final-campaign/v2-final-01 --campaign v2-priority --campaign v2-legacy --campaign v2-eight-team --campaign v2-custom
```

The coordinator adds `--run` only after exclusive reservation. Prefer selecting priority alone first, then a fresh output and the other three only after the priority retention decision. `v2-timing-plan.json` records the complete optional argv inventory. The aborted first v2 attempt is incomplete/contaminated and supplies no retention decision. Scheduling estimates from runtime-projection.json remain approximate proxies, not candidate performance results.

Expanded mocked validation covers both original and v2 cleanup/interruption paths, rejection of changed binaries/catalogs/libraries/patches/noncatalog assets, preserved defaults and exact scenario/repetition inventory, plus interruption/input change before launch. No actual engine, governor, ldd or subprocess runs in those checks.

After a separate successful v2 priority retention decision, the intended final schedule is `--campaign priority-fixes --campaign priority-refactor --campaign v2-legacy --campaign v2-eight-team --campaign v2-custom` (use a fresh output). This preserves all three reference points through two separate 16-pair priority comparisons: pure→approved attributes intended fixes; approved→merged attributes refactor differences. Then merged→v2 covers the required98 legacy,3 eight-team and6 custom windows at eight pairs each. `retained-v2-final-plan.json` records exact commands and ordering. Full98 approved→merged (`legacy-refactor`) remains an optional fallback attribution campaign and is not added to the retained-v2 schedule. No campaign selection implies that v2 has already been retained.
