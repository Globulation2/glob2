# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: session-reload.spec.js >> an active replay can be loaded again through the scheduled loader (serial)
- Location: tests/session-reload.spec.js:83:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "succeeded"
Received: "invalid"

Call Log:
- Timeout 60000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [aria-hidden]:
    - status: Starting the game…
    - generic:
      - progressbar
      - generic: 33 of 33 MB
    - combobox
  - generic "Globulation 2" [active] [ref=e3]
```

# Test source

```ts
  1   | const {test,expect}=require('@playwright/test');
  2   | const {clickMainMenu,gameURL,clickCustomGameStart,clickControl,clickListRow}=require('./main-menu');
  3   | const path=require('node:path');
  4   | const state=page=>page.evaluate(()=>glob2Diagnostics.snapshot());
  5   | const screen=(page,name)=>expect.poll(async()=>(await state(page)).screen).toContain(name);
  6   | 
  7   | async function startAndSave(page) {
  8   |   await page.goto(gameURL());await screen(page,'MainMenuScreen');
  9   |   await clickMainMenu(page,'custom');await screen(page,'CustomGameScreen');
  10  |   await clickCustomGameStart(page); // The lobby prepares its selected generated landscape.
  11  |   await expect.poll(async()=>(await state(page)).tick).toBeGreaterThan(25);
  12  |   await page.locator('#canvas').press('Escape',{delay:80});
  13  |   await clickControl(page,'save');
  14  |   // Name the manual save explicitly: an autosave can arrive while persistence
  15  |   // completes, so selecting the first newly appearing file races with it.
  16  |   await clickControl(page,'name');
  17  |   const nameField=page.getByRole('textbox',{name:'Game text field'});
  18  |   await nameField.click();
  19  |   await nameField.press('Home');
  20  |   await page.keyboard.type('Reload regression ',{delay:30});
  21  |   await clickControl(page,'ok');
  22  |   await expect.poll(async()=>{
  23  |     const saves=await page.evaluate(()=>glob2Diagnostics.saves());
  24  |     return saves.filter(name=>name.startsWith('Reload_regression_')).length;
  25  |   }).toBe(1);
  26  |   await expect.poll(async()=>(await state(page)).persistence).toBe('persisted');
  27  |   // Persistence can finish before the scheduled Save dialog completion runs.
  28  |   // Wait for gameplay before a later Escape attempts to open its menu.
  29  |   await expect.poll(async()=>(await state(page)).screenClass).toContain('GameSessionScreen');
  30  |   return (await page.evaluate(()=>glob2Diagnostics.saves())).find(name=>name.startsWith('Reload_regression_'));
  31  | }
  32  | async function loadSaved(page,replay=false,observeLoading=true) {
  33  |   await page.locator('#canvas').press('Escape',{delay:80});
  34  |   await clickControl(page,'load');
  35  |   // Game loads retain the last saved name; the first row may be an autosave.
  36  |   // The imported replay is selected explicitly because it has a different name.
  37  |   if(replay) await clickListRow(page,'files',/^AAA Replay/);
  38  |   // Start observing before the click so a fast cooperative load is not missed.
  39  |   const loading=observeLoading ? page.waitForFunction(()=>glob2Diagnostics.snapshot().screenClass.includes('GameLoadScreen')) : Promise.resolve();
  40  |   await clickControl(page,'ok');await loading;
  41  | }
  42  | 
  43  | test('an active match can load the same saved game repeatedly through the scheduled loader',async({page})=>{
  44  |   // Two full reloads exceed the suite's WebGL2 budget on software-backed CI.
  45  |   // Match the existing replay reload budget while retaining every transition check.
  46  |   if(process.env.GLOB2_TEST_RENDERER==='webgl2') test.setTimeout(420000);
  47  |   const errors=[];page.on('pageerror',error=>errors.push(String(error)));
  48  |   const name=await startAndSave(page);
  49  |   const digest=await page.evaluate(name=>glob2Diagnostics.saveDigest(name),name);
  50  |   for(let repeat=0;repeat<2;++repeat) {
  51  |     const before=(await state(page)).tick;
  52  |     await expect.poll(async()=>(await state(page)).tick).toBeGreaterThan(before+25);
  53  |     await loadSaved(page);await screen(page,'match');
  54  |     expect((await state(page)).screenClass).toContain('GameSessionScreen');
  55  |     const loaded=(await state(page)).tick;
  56  |     await expect.poll(async()=>(await state(page)).tick).toBeGreaterThan(loaded+25);
  57  |     expect(await page.evaluate(name=>glob2Diagnostics.saveDigest(name),name)).toEqual(digest);
  58  |   }
  59  |   expect(errors).toEqual([]);
  60  | });
  61  | 
  62  | test('a damaged in-game load returns through a scheduled error notice and permits another match',{tag:'@webgl2-reload-b'},async({page})=>{
  63  |   const errors=[];page.on('pageerror',error=>errors.push(String(error)));
  64  |   const name=await startAndSave(page);
  65  |   // Let the initial autosave appear first so loading cannot accidentally select it.
  66  |   await expect.poll(async()=>(await state(page)).tick).toBeGreaterThan(85);
  67  |   // Damage the stored bytes at the filesystem boundary; all loading uses UI input.
  68  |   await page.evaluate(name=>FS.writeFile('/home/web_user/.glob2/games/'+name,new Uint8Array([1,2,3])),name);
  69  |   await loadSaved(page,false,false);await screen(page,'MessageScreen');
  70  |   await page.setViewportSize({width:800,height:600});
  71  |   await expect.poll(async()=>(await state(page)).width).toBe(800);
  72  |   await page.locator('#canvas').press('Escape',{delay:80});await screen(page,'CustomGameScreen');
  73  |   await page.setViewportSize({width:1200,height:900});
  74  |   await expect.poll(async()=>(await state(page)).width).toBe(1200);
  75  |   await clickCustomGameStart(page); // The lobby prepares its selected generated landscape.
  76  |   await screen(page,'match');
  77  |   const restarted=(await state(page)).tick;
  78  |   await expect.poll(async()=>(await state(page)).tick).toBeGreaterThan(restarted+25);
  79  |   expect(errors).toEqual([]);
  80  | });
  81  | 
  82  | for(const mode of ['serial','threaded']) {
  83  | test(`an active replay can be loaded again through the scheduled loader (${mode})`,{tag:'@webgl2-reload-c'},async({page})=>{
  84  |   const loadTimeout=process.env.GLOB2_TEST_RENDERER==='webgl2'?180000:30000;
  85  |   if(process.env.GLOB2_TEST_RENDERER==='webgl2') test.setTimeout(420000);
  86  |   const errors=[];page.on('pageerror',error=>errors.push(String(error)));
  87  |   const url=new URL(gameURL(),'http://localhost');url.searchParams.set('threads',mode);
  88  |   await page.goto(url.pathname+url.search);await screen(page,'MainMenuScreen');
  89  |   expect((await state(page)).executionMode).toBe(mode);
  90  |   const replay=await require('node:fs/promises').readFile(path.resolve(__dirname,'fixtures/cross-replay.replay'));
  91  |   expect(replay.subarray(4,16).toString()).toBe('replayHeader');
  92  |   expect(replay.readUInt32BE(20)).toBe(152);
  93  |   await clickMainMenu(page,'load');await screen(page,'ChooseMapScreen');await clickControl(page,'switch');
  94  |   const chooser=page.waitForEvent('filechooser');await clickControl(page,'import');
  95  |   await (await chooser).setFiles({name:'AAA Replay.replay',mimeType:'application/octet-stream',
  96  |     buffer:replay});
> 97  |   await expect.poll(async()=>(await state(page)).import).toBe('succeeded');
      |                                                          ^ Error: expect(received).toBe(expected) // Object.is equality
  98  |   await clickListRow(page,'files',/^AAA Replay/);await clickControl(page,'ok');
  99  |   await expect.poll(async()=>(await state(page)).screen,{timeout:loadTimeout}).toContain('match');
  100 |   const original=(await state(page)).tick;
  101 |   await expect.poll(async()=>(await state(page)).tick).toBeGreaterThan(original+25);
  102 |   await loadSaved(page,true);
  103 |   await expect.poll(async()=>(await state(page)).screen,{timeout:loadTimeout}).toContain('match');
  104 |   const loaded=(await state(page)).tick;
  105 |   await expect.poll(async()=>(await state(page)).tick).toBeGreaterThan(loaded+25);
  106 |   expect(errors).toEqual([]);
  107 | });
  108 | }
  109 | 
```