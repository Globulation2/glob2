The uploaded browser build omits `presentation-surface.js`, so the launcher throws before diagnostics initialize and static packaging fails with a missing file. Include the module in both web artifacts and extend the packaging contract to require every relative launcher script.

Also update the cancellation fixture for the existing four-word WebGPU signal: completion remains unpublished until queue retirement, buffers are destroyed afterward, canceled work reports zero dispatches and an adjacent canary stays intact. The old assertion expected timing fields removed in #1161. No production simulation or browser runtime changes.

Validation: 28 packaging tests, 130 Node unit tests, 93 CI policy contracts, 25 web-asset tests (1 optional skip), documentation validation. The actual older CI Wasm artifact packages successfully after adding the byte-identical missing module; five Chromium WebGL2 smoke tests pass, with two replay cases exposing a separate stale format-152 fixture (repair in progress). Full native validation previously passed all 2968 cases; these changes affect delivery and fixtures only. Other browser engines and current-master compiled Wasm remain for hosted coverage.

[Accessible regression logs, artifact provenance and browser traces](https://github.com/Globulation2/glob2/tree/evidence/master-ci-recovery-1198/browser-artifact).
