# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: webkit-surface-events.spec.cjs >> threaded: canvas replacement preserves active fullscreen host
- Location: browser/tests/renderer-switching.spec.js:526:3

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0

Call Log:
- Timeout 120000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [aria-hidden]:
    - status: Starting the game…
    - generic:
      - progressbar
      - generic: 41 of 41 MB
    - combobox
  - generic "Globulation 2" [active] [ref=e3]
```

# Test source

```ts
  1   | const {waitForMainMenu}=require('./main-menu');
  2   | // SPDX-License-Identifier: GPL-3.0-or-later
  3   | const {test,expect}=require('@playwright/test');
  4   | const {test:recordingTest}=require('./recording-context');
  5   | const {gameURL,clickMainMenu,clickControl,clickByLabel,clickSettingsDone,clickCustomGameStart,controlBox}=require('./main-menu');
  6   | const {clickCreateMap}=require('./editor-controls');
  7   | const {hasDarkText}=require('./pixels');
  8   | const state=page=>page.evaluate(()=>glob2Diagnostics.snapshot());
  9   | const screen=(page,name)=>name==='MainMenuScreen' ? waitForMainMenu(page) : expect.poll(async()=>{const s=await state(page);return s.screen+' '+s.screenClass;},{timeout:120000}).toContain(name);
  10  | const generation=page=>page.evaluate(()=>Module.glob2PresentationSurface.generation);
  11  | async function settingsPersisted(page) {
  12  |   // Software-backed GL can leave a settings write in flight after drawing
  13  |   // the new renderer. Wait for durable storage before the next UI action.
  14  |   await expect.poll(async()=>(await state(page)).persisting,{timeout:120000}).toBe(false);
  15  | }
  16  | async function choose(page,label) {
  17  |   await settingsPersisted(page);
  18  |   const before={generation:await generation(page),loop:(await state(page)).loop};
  19  |   await clickControl(page,'graphics.renderer');
  20  |   await clickByLabel(page,/popup/,label);
  21  |   // In threaded builds FS belongs to the application worker. The requested
  22  |   // choice alone is also insufficient: a failed switch retains that choice.
  23  |   // Surface generation advances only after successful transaction commit.
> 24  |   await expect.poll(()=>{if(page.rendererSwitchErrors?.length)throw Error(page.rendererSwitchErrors.join('\n'));return generation(page);},{timeout:120000}).toBeGreaterThan(before.generation);
      |                                                                                                                                                             ^ Error: expect(received).toBeGreaterThan(expected)
  25  |   await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['graphics.renderer']?.label)).toContain(label);
  26  |   // Module.renderer is the surface transport family: both GPU contexts use
  27  |   // 'webgl2'. Verify WebGPU against the actual owner and replacement canvas.
  28  |   const active={'Software':'software','Programmable GL':'webgl2','WebGPU':'webgl2'}[label];
  29  |   if(!active)throw Error('Missing active renderer expectation for '+label);
  30  |   try {
  31  |     await expect.poll(()=>page.evaluate(()=>Module.renderer),{timeout:120000}).toBe(active);
  32  |     if(label==='WebGPU') {
  33  |       const owners=await presentationOwners(page);expect(owners).toHaveLength(1);
  34  |       await expect.poll(()=>owners[0].evaluate(()=>{
  35  |         const g=Glob2WebGPU;
  36  |         return g.state===1&&!g.lost&&g.context?.canvas===Module.canvas&&!!g.screen;
  37  |       }),{timeout:120000}).toBe(true);
  38  |       await test.info().attach('active-webgpu-owner',{body:JSON.stringify(await owners[0].evaluate(()=>({
  39  |         state:Glob2WebGPU.state,error:Glob2WebGPU.error,issued:Glob2WebGPU.issued,
  40  |         completed:Glob2WebGPU.completed,canvasOwned:Glob2WebGPU.context.canvas===Module.canvas,
  41  |         adapter:Glob2WebGPU.adapter?.info?{vendor:Glob2WebGPU.adapter.info.vendor,
  42  |           architecture:Glob2WebGPU.adapter.info.architecture,device:Glob2WebGPU.adapter.info.device,
  43  |           description:Glob2WebGPU.adapter.info.description}:null
  44  |       })),null,2),contentType:'application/json'});
  45  |     }
  46  |   } catch (error) {
  47  |     // Preserve the actual owner failure after automatic fallback. A requested
  48  |     // label and a replacement canvas do not establish successful GPU rendering.
  49  |     const owners=await presentationOwners(page);
  50  |     const diagnostics=await Promise.all(owners.map(owner=>owner.evaluate(()=>{
  51  |       const g=globalThis.Glob2WebGPU;
  52  |       return g?{state:g.state,error:g.error,lost:g.lost,epoch:g.epoch,
  53  |         issued:g.issued,completed:g.completed,bytes:g.totalBytes(),
  54  |         frames:g.frames.length,captures:g.captures.length,
  55  |         resources:g.resources.size,meshes:g.meshes.size,masks:g.masks.size}:null;
  56  |     })));
  57  |     await test.info().attach('renderer-switch-failure',{body:JSON.stringify({
  58  |       requested:label,active:await page.evaluate(()=>Module.renderer),
  59  |       generation:await generation(page),diagnostics,snapshot:await state(page)
  60  |     },null,2),contentType:'application/json'});
  61  |     throw error;
  62  |   }
  63  |   if(label==='Programmable GL') {
  64  |     const owners=await presentationOwners(page);
  65  |     expect(owners).toHaveLength(1);
  66  |     const driver=await owners[0].evaluate(()=>{
  67  |       const gl=Module.canvas.getContext('webgl2');
  68  |       if(!gl)return null;
  69  |       const debug=gl.getExtension('WEBGL_debug_renderer_info');
  70  |       return {version:gl.getParameter(gl.VERSION),renderer:gl.getParameter(gl.RENDERER),
  71  |         unmaskedRenderer:debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):null};
  72  |     });
  73  |     expect(driver,'Successful Programmable GL switch must own a WebGL2 context').not.toBeNull();
  74  |     test.info().annotations.push({type:'Actual WebGL2 driver',description:driver.unmaskedRenderer||driver.renderer});
  75  |     await test.info().attach('webgl2-driver',{body:JSON.stringify(driver,null,2),contentType:'application/json'});
  76  |   }
  77  |   await expect.poll(async()=>(await state(page)).loop,{timeout:120000}).toBeGreaterThan(before.loop+1);
  78  |   await expect.poll(async()=>hasDarkText(page,await controlBox(page,'graphics.renderer',{fullyVisible:true})),{timeout:120000}).toBe(true);
  79  |   await expect(page.locator('#canvas')).toHaveCount(1);
  80  |   expect(await page.evaluate(()=>document.querySelector('#canvas').isConnected)).toBe(true);
  81  | }
  82  | async function start(page,mode) {
  83  |   const errors=[];page.rendererSwitchErrors=errors;page.on('pageerror',error=>errors.push(String(error)));
  84  |   const url=new URL(gameURL(),'http://localhost');url.searchParams.set('threads',mode);url.searchParams.set('renderer','software');
  85  |   await page.goto(url.pathname+url.search);await screen(page,'MainMenuScreen');
  86  |   const execution=(await state(page)).executionMode;
  87  |   test.skip(execution!==mode,'Browser does not support the requested execution mode');
  88  |   await page.evaluate(()=>{globalThis.rendererSwitchApplicationToken={module:Module,action:Module._glob2_context_action,starts:Module.glob2ApplicationStarts,thread:Module.glob2ApplicationThreadIdentity};globalThis.rendererSwitchToken=rendererSwitchApplicationToken;});
  89  |   return async()=>{
  90  |     expect(await page.evaluate(()=>rendererSwitchToken===rendererSwitchApplicationToken&&rendererSwitchToken.module===Module&&rendererSwitchToken.action===Module._glob2_context_action)).toBe(true);
  91  |     expect(await page.evaluate(()=>({starts:Module.glob2ApplicationStarts,thread:Module.glob2ApplicationThreadIdentity}))).toEqual(await page.evaluate(()=>({starts:rendererSwitchToken.starts,thread:rendererSwitchToken.thread})));
  92  |     expect(await page.evaluate(()=>Module.glob2ApplicationStarts)).toBe(1);
  93  |     expect((await state(page)).executionMode).toBe(execution);
  94  |     expect(errors).toEqual([]);
  95  |   };
  96  | }
  97  | async function openMenu(page) {
  98  |   if (!(await state(page)).controls.return) await page.locator('#canvas').press('Escape',{delay:80});
  99  |   await expect.poll(async()=>Boolean((await state(page)).controls.return)).toBe(true);
  100 | }
  101 | async function openOverlay(page) {
  102 |   await openMenu(page);
  103 |   await clickControl(page,'settings');await screen(page,'SettingsScreen');
  104 | }
  105 | async function resumeOverlay(page) {
  106 |   await clickSettingsDone(page);
  107 |   await settingsPersisted(page);
  108 |   // Settings closes the menu before opening. Wait for the parent screen to
  109 |   // resume and clear its old input before sending a new physical key.
  110 |   await expect.poll(async()=>(await state(page)).screenClass).not.toContain('SettingsScreen');
  111 |   const loop=(await state(page)).loop;
  112 |   await expect.poll(async()=>(await state(page)).loop,{timeout:120000}).toBeGreaterThan(loop+2);
  113 |   if ((await state(page)).controls.return) await clickControl(page,'return');
  114 | }
  115 | async function presentationOwners(page) {
  116 |   const threaded=(await state(page)).executionMode==='threaded';
  117 |   if(!threaded)return [page];
  118 |   if(page.rendererPresentationOwner)return [page.rendererPresentationOwner];
  119 |   const identity=await page.evaluate(()=>Module.glob2ApplicationThreadIdentity);
  120 |   // The DOM page and idle asset workers load the same libraries. Only the
  121 |   // application pthread owns renderer initialization; Software deliberately
  122 |   // has no Module.canvas in that worker, so canvas presence is not a predicate.
  123 |   const realms=threaded?page.workers():[page];
  124 |   const owners=await Promise.all(realms.map(async realm=>{
```