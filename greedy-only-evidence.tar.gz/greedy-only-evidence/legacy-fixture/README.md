# Round-trip save continuation

`round-trip-143.game.gz` is a binary format-143 save written at tick 1,200 by
master `06a106d3a`, the last routing that chose resources by round trip
(fetch plus carry). It is a 64×64 headless world with two teams, each with an
inn, a swarm, scattered wheat and ten workers (`HeadlessGame`, seed 146). When it
was saved, 12 of the 20 workers were fetching and four buildings' round-trip
fields were live, so the save carries those fields in each building's
`roundTrip` section.

`LegacyRoundTripSave/*` loads it with the current engine, which reads and
discards the round-trip fields, and plays ticks 1,201–2,200 with greedy
fetching. `round-trip-143-checksums.txt` is that per-tick trace (FNV-1a over
every checksum part except the MapHeader, whose version changes on save).
PR #883's greedy default produced the same trace. Re-saving at tick 1,700 in
binary and text form, in the current format, must continue identically.

The fixture was produced by a writer case built only in a master `06a106d3a`
tree; it is not part of the test suite because current code has no round-trip
fields to populate. Regenerating it is not expected: it represents saves that
already exist.
