// SPDX-License-Identifier: GPL-3.0-or-later
// NOT COMMITTED. Built only in a master 06a106d3a tree (round-trip fetching on by
// default) to write test/fixtures/greedy-fetching/round-trip-143.game.gz.
#include "Material.h"
#include "EngineFixtures.h"
#include "MapInternal.h"
#include "Version.h"
#include <BinaryStream.h>
#include <StreamBackend.h>
#include <sstream>

namespace
{
std::vector<Uint32> simulation(Game &game)
{
	std::vector<Uint32> state, buildings, units;
	game.checkSum(&state, &buildings, &units, true);
	state.erase(state.begin());
	state.insert(state.end(), buildings.begin(), buildings.end());
	state.insert(state.end(), units.begin(), units.end());
	return state;
}
}

TEST_CASE("write a mid-game save with live round-trip fields [fixture-writer]")
{
	glob2test::HeadlessGlobals globals;
	glob2test::HeadlessGame world({.wDec=6, .hDec=6, .teams=2, .discovered=true,
		.clearImmobile=true, .loadDefaultRace=true, .header=true, .seed=146});
	auto &g = world.game;
	for (int t=0; t<2; ++t)
	{
		const int ox = 32*t;
		auto *inn = world.addBuilding("inn", ox+6, 6, 1, t);
		auto *swarm = world.addBuilding("swarm", ox+6, 20, 0, t);
		REQUIRE(inn); REQUIRE(swarm);
		inn->maxUnitWorking = 3;
		swarm->maxUnitWorking = 3;
		inn->materials[WHEAT] = 2;
		for (int i=0; i<10; ++i)
		{
			g.map.setResourceByIndex(ox+3+2*i, 40+(i%3)*3, WHEAT, 0);
			g.map.setResourceByIndex(ox+20+(i%4), 6+2*i, WHEAT, 0);
		}
		for (int i=0; i<10; ++i) world.addUnit(WORKER, ox+10+i%5, 12+i/5, t, 1);
		inn->updateCallLists();
		swarm->updateCallLists();
	}
	std::ostringstream trace;
	for (int tick=0; tick<1200; ++tick)
	{
		world.step();
		Uint32 hash=2166136261u;
		for (Uint32 value : simulation(g)) hash=(hash ^ value)*16777619u;
		trace << tick+1 << ' ' << std::hex << hash << std::dec << '\n';
	}
	int live=0;
	for (int t=0; t<2; ++t)
		for (int b=0; b<Building::MAX_COUNT; ++b) if (auto *building=g.teams[t]->myBuildings[b])
			for (int r=0; r<MaterialSlotCount; ++r) for (int sw=0; sw<SWIM_CLASS_COUNT; ++sw)
				live += building->roundTripGradient[r][sw] != nullptr;
	int filling=0, units=0, buildings=0;
	for (int t=0; t<2; ++t)
	{
		for (int u=0; u<Unit::MAX_COUNT; ++u) if (auto *unit=g.teams[t]->myUnits[u]) { ++units; filling += unit->activity==Unit::ACT_FILLING; }
		for (int b=0; b<Building::MAX_COUNT; ++b) buildings += g.teams[t]->myBuildings[b]!=nullptr;
	}
	std::printf("LIVE round-trip fields at save: %d; units %d (%d fetching); buildings %d; step %u\n", live, units, filling, buildings, g.stepCounter);
	REQUIRE(live > 0);
	auto *backend = new GAGCore::MemoryStreamBackend;
	{
		GAGCore::BinaryOutputStream out(backend);
		g.save(&out, false, "Round-trip 143 fixture");
		out.flush();
		REQUIRE(!glob2test::artifactDir().empty());
		glob2test::writeFile(glob2test::artifactDir()/"round-trip-143.game", backend->takeContents());
	}
	glob2test::writeFile(glob2test::artifactDir()/"master-trace-0-1200.txt", trace.str());
	// The same game played on by master, for reference only.
	std::ostringstream after;
	for (int tick=1200; tick<2200; ++tick)
	{
		world.step();
		Uint32 hash=2166136261u;
		for (Uint32 value : simulation(g)) hash=(hash ^ value)*16777619u;
		after << tick+1 << ' ' << std::hex << hash << std::dec << '\n';
	}
	glob2test::writeFile(glob2test::artifactDir()/"master-trace-1200-2200.txt", after.str());
}
