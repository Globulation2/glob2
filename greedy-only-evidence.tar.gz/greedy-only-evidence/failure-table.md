# Linux full-suite failures: head 64284b331 vs origin/master 0f1a2569a

Ubuntu 24.04 x86_64, GCC 13.3.0, `scons -j8 release=1` + `tests`, identical SDL3/recording prefixes.
Full runs: `python3 test/run_tests.py -j8 --junit …` (shared host, load 16–30).
Head: 1,217 passed, 16 failed, 0 skipped. Master: 1,211 passed, 21 failed, 0 skipped.
Every case that failed or timed out on either side was re-run at `-j3` on both trees (rerun column).
No test case was skipped on either side. The only SKIP lines are master's in-case
"fullscreen camera continuity" checks, which need `--fullscreen`.

| Test | Head full / rerun | Master full / rerun | Cause |
|---|---|---|---|
| FontKerning/the bundled SDL3_ttf moves the pen for kerned pairs | FAIL / FAIL | FAIL / FAIL | Environment (host SDL3_ttf); also fails on 06a106d3a |
| glob2-unit-tests: 16-bit RGBA rounds normalized channels to the exporter reference | FAIL / FAIL | FAIL / FAIL | Environment; also fails on 06a106d3a |
| unit: native software glyphs at fractional scale; scaled and unscaled text rasterisation | FAIL / pass | FAIL / pass | Load-sensitive font rendering, both sides |
| GameSpeed/settings screen; in-game slider; shortcuts and camera cadence | FAIL / FAIL | FAIL / FAIL | Master regression (`-27 == 101`) |
| FarmAreas/without the experiment the order is rejected and a painted mask is inert | FAIL / FAIL | FAIL / FAIL | Master regression (`3 == 4`) |
| JavaScriptIntegration/JavaScript telemetry scene permissions and replay diagnostic roundtrip | FAIL / FAIL | FAIL / FAIL | Master regression |
| JavaScriptIntegration/JavaScript custom library and telemetry dialogs render | FAIL / FAIL | FAIL / FAIL | Master regression |
| MarketsV2/disabled gate blocks explicit fetch APIs and upgrade execution | FAIL / FAIL | FAIL / FAIL | Master regression (scene `showLevel`) |
| UIPresentation/… tablet landscape, laptop, fullhd | TIMEOUT / TIMEOUT | TIMEOUT / TIMEOUT | 600 s timeout under load, both sides |
| UIPresentation/… tablet portrait | pass | TIMEOUT / pass | Load |
| MapGeneratorRegistry/catalog generation contracts | TIMEOUT / pass | TIMEOUT / pass | Load (600 s) |
| Maxima.Economy/observed hunger expands feeding… | pass (106 s) / TIMEOUT | TIMEOUT / TIMEOUT | 120 s timeout under load; passes on both with `--timeout 400` (head 123 s, master 114 s); 66 s on a quieter run |
| Maxima.Economy/sustained stock feeding… | pass | TIMEOUT / pass | Load; with `--timeout 400`: head 102 s, master 93 s |
| EngineSession/routine snapshot input needs no simulation boundary | FAIL / pass | pass / pass | Threaded presentation timing under load: passes 5/5 isolated on head (3/3 master); no simulation code involved |
| RuntimePack/HD runtime pack… | pass | TIMEOUT / pass | Load |
| TorusRender/game rendering at triple UI scale in OpenGL | pass | TIMEOUT / pass | Load |
| HighResolutionIntegration/HD artwork; cursor scaling and replay fixture in OpenGL | pass | FAIL / pass | Load |
| LanMatchHarness/an idle LAN host sleeps and wakes at once… | pass | FAIL / FAIL | Master-side network timing (`87 < 50`) |

No failure is specific to this branch. The goldens #883 had left stale were regenerated in
64284b331 and pass on Linux and macOS: Maxima army births, FarmAreas off-path, MapTiling,
RuntimeResources seeded compositions and the JavaScript profile-1 resource traces.
