# Greedy-only resource fetching: review evidence

Branch head 64284b331 (merge base 50c137ab0 = PR #883 head ab143f583 + origin/master 0f1a2569a).

- `failure-table.md`: every Linux full-suite failure at the head and on origin/master 0f1a2569a, with causes.
- `junit/`: Linux full suites for the head and master, low-concurrency reruns of every failing case on both, and the macOS focused run.
- `identity/`: per-scenario comparisons of the #883 greedy baseline against this branch, on macOS and Linux
  (`*-883-vs-mine.json`: entity-record identity, constant aggregate XOR, team results, record-stream SHA-256),
  plus SHA-256 of every checksum sidecar on both platforms.
- `saves/`: the mid-game saves the continuation scenarios load (master 06a106d3a round-trip saves, a #883 format-145 checkpoint).
- `legacy-fixture/`: provenance of `test/fixtures/greedy-fetching/round-trip-143.game.gz`. Includes the writer case
  (built only in a 06a106d3a tree), master's own traces for ticks 1–1,200 and 1,201–2,200, the fixture and its
  golden (produced by the #883 baseline).
- `fixtures/`: SHA-256 of every regenerated fixture and the Studio sidecar hashes for master, #883 and this branch.
- `scripts/`: `identity.py` (runs the scenarios) and `compare.py` (compares two runs).
- `binaries-*.txt`: source revisions and binary hashes.
