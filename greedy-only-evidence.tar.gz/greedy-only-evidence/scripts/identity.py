#!/usr/bin/env python3
"""Tick-for-tick identity of greedy-only fetching against PR #883's greedy default.

usage: identity.py OUT LABEL BINARY [MASTER_BINARY]

Runs each scenario with BINARY into OUT/LABEL/<scenario>. With MASTER_BINARY
(master 06a106d3a, round-trip routing), first writes mid-game saves that the
continuation scenarios load. Compare two labels with compare.py.
"""
import json, os, subprocess, sys, time
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out, label, binary = Path(sys.argv[1]).resolve(), sys.argv[2], Path(sys.argv[3]).resolve()
master = Path(sys.argv[4]).resolve() if len(sys.argv) > 4 else None
oazis = ['--map-file', str(root/'maps/Oazis.map.gz'), '--game-seed', '19', *sum((['--player', 'maxima'] for _ in range(11)), [])]
small = ['--map-file', str(root/'maps/SmallForTwo.map.gz'), '--game-seed', '23', '--player', 'numbi', '--player', 'maxima']
generated = ['--generator', '15', '--map-seed', '4242', '--param', 'teams=4', '--game-seed', '31', '--player', 'numbi', '--player', 'castor', '--player', 'maxima', '--player', 'warrush']
mixed = ['--map-file', str(root/'maps/Oazis.map.gz'), '--game-seed', '57',
         *sum((['--player', p] for p in (['numbi', 'castor', 'warrush', 'maxima', 'nicowar', 'econo'] * 2)[:11]), [])]

def run(binary, args, directory):
    directory.parent.mkdir(parents=True, exist_ok=True)
    if (directory/'result.json').exists():
        return
    started = time.time()
    with open(str(directory) + '.log', 'w') as log:
        subprocess.run([str(binary), '--run-game', *args, '--telemetry', 'checksums', '--output-dir', str(directory)],
                       cwd=root, stdout=log, stderr=subprocess.STDOUT, check=True)
    print(f'{directory.name}: {time.time()-started:.0f}s', flush=True)

if master:
    saves = out/'master-saves'
    run(master, [*oazis, '--ticks', '3000', '--save', 'final'], saves/'oazis-3000')
    run(master, [*small, '--ticks', '2500', '--save', 'final'], saves/'small-2500')

scenarios = {
    'oazis-maxima11-s19': [*oazis, '--ticks', '4096', '--save', 'every:2048'],
    'oazis-mixed11-s57': [*mixed, '--ticks', '4096'],
    'small-numbi-maxima-s23': [*small, '--ticks', '6000'],
    'generated-15-s4242': [*generated, '--ticks', '4096'],
    'oazis-maxima11-s19-parallel': [*oazis, '--ticks', '2048', '--compute-threads', '4', '--gradient-workers', '4'],
    'from-master-oazis-3000': ['--load-game', str(out/'master-saves/oazis-3000/final.game.gz'), '--ticks', '7096'],
    'from-master-small-2500': ['--load-game', str(out/'master-saves/small-2500/final.game.gz'), '--ticks', '6596'],
    # PR #883's own format-145 checkpoint (greedy default), written by the base883 run.
    'from-883-oazis-2048': ['--load-game', str(out/'base883/oazis-maxima11-s19/checkpoint-2048.game.gz'), '--ticks', '6144'],
}
for name, args in scenarios.items():
    run(binary, args, out/label/name)
