#!/usr/bin/env python3
"""usage: compare.py DIR_A DIR_B [JSON_OUT]

Per scenario, compares the checksum sidecars of two runs tick by tick:
- every team/unit/building record must be byte-identical;
- the aggregate checksum includes the MapHeader (and so VERSION_MINOR, 145 vs
  146), which is constant within a game, so aggregate_a XOR aggregate_b must be
  one constant for every tick; any other difference would make it vary;
- the final team results in result.json must be equal.
Also hashes the version-independent record stream, for cross-platform comparison.
"""
import hashlib, json, mmap, struct, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'test'))
from compare_save_continuation import records


def ticks(path):
    data = path.read_bytes()
    out = list(records(data))
    # aggregate checksums: re-walk to read the u32 following each tick number
    aggregates, position = [], 20
    teams, _, count, _ = struct.unpack_from('<4I', data, 4)
    for tick, body in out:
        t, aggregate = struct.unpack_from('<2I', data, position)
        assert t == tick
        aggregates.append(aggregate)
        position += 8 + len(body)
    return out, aggregates


def teams(path):
    result = json.loads((path / 'result.json').read_text())
    entries = result.get('teams') or []
    for entry in entries:
        entry.pop('routing_comparison', None)
    return entries


a, b = Path(sys.argv[1]), Path(sys.argv[2])
ok, rows = True, []
for scenario in sorted(p.name for p in a.iterdir() if p.is_dir()):
    sa, sb = a / scenario / 'game.replay.checksums', b / scenario / 'game.replay.checksums'
    if not sb.exists():
        print(f'{scenario}: missing in {b}')
        ok = False
        continue
    ra, aa = ticks(sa)
    rb, ab = ticks(sb)
    first = next((i for i, (x, y) in enumerate(zip(ra, rb)) if x != y), None)
    records_same = first is None and len(ra) == len(rb)
    xors = {x ^ y for x, y in zip(aa, ab)}
    aggregate_constant = len(xors) == 1
    teams_same = teams(a / scenario) == teams(b / scenario)
    digest = hashlib.sha256(b''.join(struct.pack('<I', t) + body for t, body in ra)).hexdigest()
    rows.append(dict(scenario=scenario, ticks=len(ra), first_tick=ra[0][0], last_tick=ra[-1][0],
                     identical_entity_records=records_same, aggregate_xor_constant=aggregate_constant,
                     aggregate_xor=sorted(xors)[:3], identical_team_results=teams_same,
                     first_difference=None if first is None else ra[first][0], records_sha256=digest))
    print(f'{scenario}: ticks {ra[0][0]}..{ra[-1][0]} ({len(ra)}), entity records '
          f'{"identical" if records_same else f"DIFFER from tick {rows[-1]["first_difference"]}"}, '
          f'aggregate xor {"constant " + hex(next(iter(xors))) if aggregate_constant else "VARIES"}, '
          f'teams {"identical" if teams_same else "DIFFER"}, records sha256 {digest[:16]}')
    ok &= records_same and aggregate_constant and teams_same
if len(sys.argv) > 3:
    Path(sys.argv[3]).write_text(json.dumps(rows, indent=1))
print('ALL IDENTICAL' if ok else 'MISMATCH')
sys.exit(0 if ok else 1)
