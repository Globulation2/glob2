Returning from fullscreen can overlap the window manager's decoration restoration with a client resize. The resulting callback can shrink and persist a remembered 1280×640 window as 1280×603.

Wait for fullscreen exit before requesting the remembered client dimensions, then settle that resize before persisting preferences. The existing failure rollback and graphics context remain in place. This visibly preserves the window's original size when leaving fullscreen or using F11.

Validation: baseline reproduces the corruption in repeated software/OpenGL transitions; patched candidate passes 40/40 runs constrained to two CPUs. Clean release tests pass all six WindowResize/FullscreenAspect cases under correctly sized Xvfb sessions, including pixel, clipping, input and context checks. Documentation and sim-version checks pass. Full local rerun and master CI continue; actual macOS/Windows fullscreen behavior is not verified locally.
