from pathlib import Path
import os, subprocess, sys, json, hashlib
root=Path.cwd(); out=root/'artifacts/ai-studio'; binary=root/'build/linux/client/release/src/glob2'
sys.path.insert(0,str(root/'test'))
from check_javascript import complete_ticks,compare_payloads
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_CHECKSUM_SIDECAR='1',GLOB2_USER_DATA_DIR=str(out/'review-native-profile'))
base=[str(binary),'--run-game','--map-file','platform/apps/engine-agent/fixtures/ais/two.map.gz','--game-seed','19','--player','javascript','--ai-script','0:examples/javascript/studio-starter.js','--player','numbi']
def run(name,args):
    target=out/name
    command=[str(binary),*args,'--replay','true','--telemetry','checksums','--save','final','--output-dir',str(target)]
    (out/(name+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
    with (out/(name+'.log')).open('w') as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    return target
split=run('review-native',base[1:]+['--ticks','1024','--save','initial'])
whole=run('review-whole',base[1:]+['--ticks','1536'])
resumed=run('review-resumed',['--run-game','--load-game',str(split/'final.game.gz'),'--ticks','1536'])
# --ticks is the absolute simulation endpoint when resuming a saved game.
a=complete_ticks((whole/'game.replay.checksums').read_bytes()); b=complete_ticks((resumed/'game.replay.checksums').read_bytes())
assert set(b)==set(range(1024,1536)),list(b)[:5]
assert all(a[t]==b[t] for t in b)
compare_payloads((whole/'final.game.gz').read_bytes(),(resumed/'final.game.gz').read_bytes())
trace=(split/'game.replay.checksums').read_bytes(); fixture=json.loads((root/'browser/tests/fixtures/studio-trace.json').read_text())
assert hashlib.sha256(trace).hexdigest()==fixture['traceSha256']
(out/'review-save-resume.json').write_text(json.dumps({'matchingTicks':len(b),'firstTick':min(b),'lastTick':max(b),'savedPayloadMatches':True,'traceSha256':hashlib.sha256(trace).hexdigest(),'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest()},indent=2)+'\n')
print('PASS native fixture:1024 ticks match frozen browser digest;512 continuation ticks and saved payload match',flush=True)
subprocess.run([sys.executable,str(root/'test/check_javascript.py'),str(binary),'--output',str(out/'review-javascript-compatibility')],env=env,check=True)
