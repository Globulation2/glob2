// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#pragma once

#include "Material.h"
#include <bitset>
#include <climits>
#include <list>
#include <memory>
#include <vector>

#include "BuildingUtils.h"
#include "BuildingState.h"
#include "MapInternal.h"
#include "Ressource.h"
#include "MaterialPacket.h"
#include "UnitConsts.h"
#include "BuildingCatalog.h"

namespace GAGCore
{
	class InputStream;
	class OutputStream;
}


struct WideMaterialPacket;
struct WideMaterialDeliveryResult;
class Unit;
class Team;
class Map;
class BuildingGradientSearch;
struct BuildingType;
class BuildingsTypes;
class Order;

/// Sentinel for `BuildingType::prevLevel` / `nextLevel` meaning
/// "no upgrade/downgrade exists in this chain" (signed int).
/// Distinct from the wire-format `NB_BUILDING` size sentinel.
static constexpr int BUILDING_LEVEL_NONE = -1;

/// Sentinel for "no material chosen yet" in building selection loops.
/// Distinct from the map resource sentinel `NO_RES_TYPE` (Uint16 0xFFFF).
static constexpr int MATERIAL_TYPE_NONE = -1;

/// Length of the per-building "no-swim variant" / "can-swim variant"
/// pair. Every per-building gradient/lock/clearing array is indexed
/// `[canSwim]` where `canSwim == 0` means the no-swim variant and
/// `canSwim == 1` means the can-swim variant. Used both as the array
/// dimension and as the loop bound in `for (canSwim=0; canSwim<...; …)`.
static constexpr int SWIM_VARIANT_COUNT = 3;

/// Index into a `[SWIM_VARIANT_COUNT]` array selecting the variant
/// reachable by units that have the SWIM ability. Used at sites that
/// hard-pick the swim variant (e.g. swarms only emit swimming workers
/// once the can-swim path is reachable).
static constexpr int SWIM_VARIANT_CAN_SWIM = 1;

enum class BuildingRoute : unsigned char { Footprint, Clearing, Combat, Automatic };
inline constexpr int BUILDING_ROUTE_COUNT = 3;
inline constexpr int BUILDING_GRADIENT_COUNT = BUILDING_ROUTE_COUNT * SWIM_CLASS_COUNT;
inline constexpr int BUILDING_ACCESS_COUNT = BUILDING_ROUTE_COUNT * SWIM_VARIANT_COUNT;
static_assert(BUILDING_ACCESS_COUNT == std::extent_v<decltype(BuildingStateRecord::locked)>);

class Building : public BuildingUtils, public BuildingStateRecord
{
	friend struct TeamStatsMeasurementFixture;

  public:
	static const int MAX_COUNT=1024;
	const BuildingRuntimeTraits* runtime=nullptr;
	void bindType(Sint32 id, BuildingsTypes* catalog=nullptr);

	/// `lastShootStep = LAST_SHOOT_STEP_NEVER` means this turret has
	/// not fired yet this game; the field is `Uint32` step counter.
	static constexpr Uint32 LAST_SHOOT_STEP_NEVER = static_cast<Uint32>(-1);

	/// Initial value for proportion-finding loops in `neededMaterial`
	/// and `swarmStep`: every real proportion compares less. Same as
	/// `INT32_MAX`; named for clarity at the call site.
	static constexpr Sint32 MIN_PROPORTION_INIT = INT32_MAX;

	/// Wished-materials scaling factor: `wishedMaterials = (NUM/DEN) *
	/// missing` ≈ 1.33×, so workers can be subscribed before materials
	/// are actually depleted.
	static constexpr int WISHED_MATERIAL_NUM = 4;
	static constexpr int WISHED_MATERIAL_DEN = 3;

	/// `findGroundExit` quality scoring (per-tile bonuses):
	///  - +1 when the candidate exit is next to a resource
	///  - +2 when the candidate exit is on open ground
	/// Search aborts once any side reaches `EXIT_QUALITY_GOOD_ENOUGH`.
	static constexpr int EXIT_QUALITY_NEAR_RESOURCE = 1;
	static constexpr int EXIT_QUALITY_OPEN_GROUND = 2;
	static constexpr int EXIT_QUALITY_GOOD_ENOUGH = 4;

	/// Sanity bound on `maxUnitInside` reads from old saves; the value
	/// is logically a `Uint16` so anything ≥ 65536 is corrupt data.
	static constexpr Sint32 MAX_UNIT_INSIDE_LIMIT = 65536;

	/// Turret rotating-shoot sprite has this many animation frames;
	/// `shootingStep` cycles `0..SHOOTING_ANIMATION_FRAMES-1`.
	static constexpr Uint32 SHOOTING_ANIMATION_FRAMES = 8;

	/// Original square footprint, retained by legacy geometry test helpers.
	static constexpr int TURRET_SIZE = 2;

	///The state of a unit in certain lists.
	enum InListState
	{
		LS_UNKNOWN=0,
		LS_IN=1,
		LS_OUT=2
	};

	// ─── Public methods ─────────────────────────────────────────────

	Building(GAGCore::InputStream *stream, BuildingsTypes *types, Team *owner, Sint32 versionMinor);
	Building(int x, int y, Uint16 gid, Sint32 typeNum, Team *team, BuildingsTypes *types, Sint32 unitWorking, Sint32 unitWorkingFuture);
	virtual ~Building(void);
	void freeGradients();
	// Drop the pathfinding gradients (call after the building moves or its range changes).
	// Why a field was last dropped; diagnostics only (synchronous rebuild reasons).
	enum class GradientDrop : Uint8 { New, Idle, Own, Team, Area };
	void resetPathfindGradients(GradientDrop cause = GradientDrop::Own);
	bool keepsStaleGradients(GradientDrop cause) const;
	// Request a rebuild on use once the refresh throttle permits (map changed nearby).
	void dirtyGradients();

	void load(GAGCore::InputStream *stream, BuildingsTypes *types, Team *owner, Sint32 versionMinor);
	void save(GAGCore::OutputStream *stream);
	void loadCrossRef(GAGCore::InputStream *stream, BuildingsTypes *types, Team *owner, Sint32 versionMinor);
	void saveCrossRef(GAGCore::OutputStream *stream);

	bool isMaterialFull(void);
	///Custom-game "fortress buildings" rule: type->hpMax scaled by the
	///configured multiplier. Use this instead of reading type->hpMax
	///directly anywhere the result affects simulation or display.
	int getEffectiveArmor() const;
	int applyAreaAttack(int value) const;
	int getEffectiveMaxHp(void) const;
	Sint32 getMaxUnitWorkingFuture() const { return maxUnitWorkingFuture; }
	///Same rule, for type->hpInit.
	int getEffectiveInitHp(void) const;
	///Same rule, for type->hpInc: a site delivered in full must still reach
	///the scaled hpInit, or every new building would finish badly damaged.
	int getEffectiveHpInc(void) const;
	int neededMaterial(void);
	/**
	 * Calls neededMaterial(int res) for each material slot.
	 * @param array of needs that will be filled by this function
	 */
	void neededMaterials(int needs[MaterialSlotCount]);
	/**
	 * @param res The material slot
	 * @return count of materials needed in slot res. In case of higher multiplicity
	 * of the requested material (fruits have 10) the value is reduced by (multiplicity-1)
	 * and clipped to >= 0
	 */
	int neededMaterial(int res);
	///Wished materials are any materials that are needed, and not being carried by a unit already.
	///Fills `needs[]` with the result; pass `wishedMaterials` to refresh the cached member.
	void computeWishedMaterials(int needs[MaterialSlotCount]);
	int totalWishedMaterial();

	///Launches construction. Provided with the number of units that should be working during the construction,
	///and the number of units that should be working after the construction is finished.
	bool launchConstruction(Sint32 unitWorking, Sint32 unitWorkingFuture);
	///Cancels construction of a building, returning it to a normal state.
	void cancelConstruction(Sint32 unitWorking);
	///Causes a building to be put on the waiting list for deletion. It is deleted by team after all units
	///that are inside the building leave.
	void launchDelete(void);
	///Cancels the deletion of a building, returning it to normal.
	void cancelDelete(void);

	///This function updates the call lists that the Building is on. A call list is a list
	///of buildings in Team that need units for work, or can have units "inside"
	void updateCallLists(void);
	/// Synchronize cached membership after Team removes every service-list entry.
	void resetServiceListState();
	///When a building is waiting for room, this will make sure that the building is in the
	///Team::buildingsTryToBuildingSiteRoom list. It will also check for hard space, etc if
	///resources grow into the space or a building is placed, it becomes impossible
	///to upgrade and the construction is cancelled.
	void updateConstructionState(void);
	///Updates the construction state when undergoing construction. If the construction materials are fully funded,
	///construction has completed.
	void updateBuildingSite(void);
	///This function updates the units working at this building. If there are too many units, it
	///fires some.
	void updateUnitsWorking(void);

	///This function is called after important events in order to update the building
	void update(void);

	///Sets the area around the building to be discovered, and visible by the building
	void setMapDiscovered(void);

	///Gets the amount of each material that are needed to repair the building.
	void getMaterialCountToRepair(int materials[MaterialCount]);

	///Attempts to find room for a building site. If room is found, the building site is established,
	///and it returns true.
	bool tryToBuildingSiteRoom(void);

	///Checks if there is hard space for a building site under the given construction result state.
	///Non hard space is any space occupied by something that won't move. Units will move, so they
	///are ignored. If there is space for the building site, then this returns true. The no-arg
	///private overload defers to this one using the building's current `constructionResultState`.
	bool isHardSpaceForBuildingSite(ConstructionResultState requestedState);

	///This is called every step. The building updates the desiredMaxUnitWorking variable using
	///the function desiredNumberOfWorkers
	void step(void);
	///This function subscribes any building that needs materials carried to it with units.
	///It is considered greedy, hiring as many units as it needs in order of its preference
	///Returns true if a unit was hired
	bool subscribeToBringMaterialsStep(bool borrowUnused = false);
	//! Whether the unit's type and level qualify it to work for this building.
	bool canUnitWorkHere(Unit* unit, bool attraction = false, int role=-1);
	/// Whether any configured material uses routed team-stock fetching.
	/// Consumer-aware Map queries apply per-material gates and exclude own pools.
	bool fetchesFromMarkets() const;
	/// Game-aware upgrade availability; the static type table is shared by games.
	bool isUpgradeAvailable() const;
	///This function subscribes any flag that needs units.
	///It is considered greedy, hiring as many units as it needs in order of its preference
	///Returns true if a unit was hired
	bool subscribeForFlagingStep();
	/// Subscribes a unit to go inside the building.
	void subscribeUnitForInside(Unit* unit);
	// Reservations protect shared stock from other services and production.
	BuildingMaterialCost reservedMaterials{};
	Sint32 availableMaterial(int resource) const;
	bool reserveMaterials(const BuildingMaterialCost& cost);
	bool restoreMaterialsReservation(const BuildingMaterialCost& cost);
	void releaseMaterials(const BuildingMaterialCost& cost);
	void consumeReservedMaterials(const BuildingMaterialCost& cost, int diagnosticUse);
	BuildingMaterialCost serviceCost(const Unit* unit, int purpose) const;
	bool canOfferService(const Unit* unit, int purpose) const;
	void reserveService(Unit* unit);
	void releaseService(Unit* unit);
	void settleService(Unit* unit);
	void restoreServiceReservations();
	int selectProductionRecipe() const;
	bool canAffordProduction(int unitType) const;
	void resetProduction();
	void cancelProduction();
	void restoreProductionReservations();
	void regenerationStep();
	/// One production phase. Services and shooting use independent phases.
	void swarmStep(void);
	/// This function searches for enemies, computes the best target, and fires a bullet
	void turretStep(Uint32 stepCounter);
	/// Kills the building: releases its workers, expels the units inside onto
	/// the footprint or the ring around it, and queues it for deletion.
	void kill(int diagnosticRemoval = 2);

	/// This function removes the unit from the list of units working on the building. Units will remove themselves
	/// when they run out of food, for example. This does not handle units state, just the buildings.
	void removeUnitFromWorking(Unit* unit);

	/// Detach every worker from this building: each unit gets `standardRandomActivity()`
	/// (which clears its `attachedBuilding` link and puts it back in the free pool), and
	/// then `unitsWorking` is emptied. The list is required to contain no null pointers.
	/// Used when a building becomes incapable of holding workers (completion, kill, max=0,
	/// or unreachable clearing-flag resources).
	void releaseAllWorkers();

	/// Insert into the harvesting unit, when the unit has decided to do so.
	/// This does not handle units state, just the buildings.
	void insertUnitToHarvesting(Unit* unit);

	/// This function removes the unit from the list of units harvesting from the building. Units will remove themselves
	/// when they run out of food, for example. This does not handle units state, just the buildings.
	/// It is safe to call this function even if the unit is not harvesting at the building.
	void removeUnitFromHarvesting(Unit* unit);

	/// Remove unit from inside. This function removes the unit from being inside the building. Like removeUnitFromWorking,
	/// it does not update the units state.
	void removeUnitFromInside(Unit* unit);

	/// This function is called when a Unit delivers a material into the building.
	void addMaterialIntoBuilding(int resourceType);
	MaterialDeliveryResult deliverMaterialPacket(int resourceType, MaterialPacket packet);
	WideMaterialDeliveryResult deliverCargoPacket(int resourceType, WideMaterialPacket packet);
	MaterialPacket withdrawMaterialPacket(int resourceType);
	int getConstructionOriginTypeNum() const { return constructionOriginTypeNum; }
	int getConstructionCompletionTypeNum() const;
	int constructionMaterialNeed(int resource) const;
	int materialDeliveryNeed(int resource) const;
	int materialDeliveryTarget(int resource) const;
	void fundConstructionFromInventory();
	void restoreConstructionReservations();
	void releaseConstructionReservations();
	bool canTransferMaterialsTo(const BuildingType* destination) const;
	void transferMaterialsPointer(bool wasShared);
	BuildingMaterialCost constructionBudget{}, constructionReserved{};
	std::array<Sint32,NB_UNIT_TYPE> constructionOriginRatios{};
	// Optional additional types do not enlarge the pointer-free hot state record.
	std::vector<Sint32> extraProductionRatios, extraProductionUsed, extraConstructionOriginRatios;
	Sint32& productionRatio(unsigned id) { return id<NB_UNIT_TYPE ? ratio[id] : extraProductionRatios.at(id-NB_UNIT_TYPE); }
	Sint32 productionRatio(unsigned id) const { return id<NB_UNIT_TYPE ? ratio[id] : extraProductionRatios.at(id-NB_UNIT_TYPE); }
	Sint32& productionUsed(unsigned id) { return id<NB_UNIT_TYPE ? percentUsed[id] : extraProductionUsed.at(id-NB_UNIT_TYPE); }
	Sint32 productionUsed(unsigned id) const { return id<NB_UNIT_TYPE ? percentUsed[id] : extraProductionUsed.at(id-NB_UNIT_TYPE); }
	Sint32& originProductionRatio(unsigned id) { return id<NB_UNIT_TYPE ? constructionOriginRatios[id] : extraConstructionOriginRatios.at(id-NB_UNIT_TYPE); }
	Sint32 originProductionRatio(unsigned id) const { return id<NB_UNIT_TYPE ? constructionOriginRatios[id] : extraConstructionOriginRatios.at(id-NB_UNIT_TYPE); }
	void configureProductionState();
	std::size_t productionTypeCount() const { return NB_UNIT_TYPE+extraProductionRatios.size(); }
	void transitionProductionPreferences(const BuildingType* previous, const BuildingType* origin = nullptr, bool restoring = false);
	Sint32 repairInitialDeficit = 0, repairHealthGranted = 0;
	void applyConstructionHealth(int funded, bool finishRepair = false);
	void cancelConstructionMaterials();

	/// This function is called when a Unit takes a material from a building, such as a market
	void removeMaterialFromBuilding(int resourceType);

	///Gets the middle x coordinate relative to posX
	int getMidX(void);
	///Gets the middle y coordinate relative to posY
	int getMidY(void);

	/// When a unit leaves a building, this function will find an open spot for that unit to leave,
	/// and provides the x and y coordinates, along with the direction the unit should be travelling
	/// when it leaves.
	bool findGroundExit(int *posX, int *posY, int *dx, int *dy, bool canSwim, bool canWalk=true);
	/// When a unit leaves a building, this function will find an open spot for that unit to leave,
	/// and provides the x and y coordinates, along with the direction the unit should be travelling
	/// when it leaves.
	bool findAirExit(int *posX, int *posY, int *dx, int *dy);

	/// Free tile for a unit expelled by kill(): footprint first, then the ring; dx/dy point outwards.
	bool findExpelTile(bool fly, bool canSwim, int *posX, int *posY, int *dx, int *dy, bool canWalk=true);

	/// Returns the script level number. Construction sites are odd numbers and completed buildings
	/// even, from 0 to 5
	int getLongLevel(void);

	/// Eats one wheat and one of each of the available fruit from the building.
	/// Return the number of different fruits in this building. If mask is non-null,
	/// set masks value to the mask as well
	Uint32 eatOnce(Uint32 *mask=NULL, Unit* visitor=nullptr);

	/// Returns the maximum happyness level that this building can provide, taking into account the
	/// units that are already in it.
	int availableHappynessLevel();

	/// Returns if this Building (Inn) can convert a hostile Unit. To avoid conversion
	/// once the capacities of the own inns are hit, conversion is limited.
	bool canConvertUnit(void);

	// Uses the same pixel trajectory and terrain obstruction test as turret fire.
	bool hasClearShotTo(int targetX, int targetY) const;

	bool integrity();
	Uint32 checkSum(std::vector<Uint32> *checkSumsVector, bool legacy152=false);

private:
	// ─── Turret targeting (turretStep helpers) ──────────────────────

	/// Classification of what a turret's target search found, ordered by
	/// firing priority. Explorers short-circuit the ring scan; workers are
	/// only considered when no warrior has been found; buildings only when
	/// no unit at all has been found.
	enum TurretTargetType
	{
		TARGETTYPE_NONE,
		TARGETTYPE_BUILDING,
		TARGETTYPE_GENERAL,
		TARGETTYPE_THREAT,
		TARGETTYPE_PRIORITY,
	};

	/// Result of a turret's ring scan: the best target found and the data
	/// needed to fire at it. `score` uses INT_MIN as "nothing yet"; higher
	/// scores override lower ones. `ticks` is the number of ticks the target
	/// is expected to remain reachable (buildings use 256, i.e. "stationary").
	struct TurretTarget
	{
		TurretTargetType type = TARGETTYPE_NONE;
		int score = INT_MIN;
		int ticks = 0;
		int x = 0, y = 0;
		bool found() const { return type != TARGETTYPE_NONE; }
	};

	/// Firing solution computed from a target tile: the bullet spawn origin in
	/// pixels (`originX/originY`), its Q8 fixed-point velocity (`speedX/speedY`),
	/// and `ticksLeft` until it reaches the target.
	struct TurretFiringSolution
	{
		int originX, originY;
		int speedX, speedY;
		int ticksLeft;
	};

	/// Phase 1 of turretStep: convert one stone in stock into bullets if there
	/// is bullet capacity for a full multiplierStoneToBullets batch.
	void convertStoneToBullet();

	/// Phase 2 of turretStep: advance the shooting cooldown. Returns true when
	/// the turret is off cooldown and may search for a target this tick; when
	/// still cooling it decrements by shootRhythm and returns false.
	bool tickShootingCooldown();

	/// Scan outward ring-by-ring for the best enemy target in range. Pure query
	/// over map/units/buildings; mutates nothing on the turret.
	TurretTarget findBestTarget() const;

	/// Evaluate the single tile (targetX,targetY) on ring `ring` and update
	/// `best` if it holds a higher-priority/higher-scoring target. `ticksToHit`
	/// is how long a bullet would take to reach this ring; targets that will
	/// move away before then are skipped (and, matching the original, skipping a
	/// ground unit also skips the air/building checks at the same tile).
	void considerScanTile(int targetX, int targetY, int ring, int ticksToHit,
	                      Uint32 enemies, Map* map, TurretTarget& best) const;

	/// Score a warrior target (offense + weakness + proximity); higher is more
	/// urgent. `ring` is the scan ring distance used for the proximity term.
	int scoreWarriorTarget(const Unit* target, int ring) const;

	/// Overwrite `best` with this candidate when its score beats the incumbent.
	static void applyCandidate(TurretTarget& best, int score, int ticks,
	                           int x, int y, TurretTargetType type);

	/// Phase 5 geometry: compute the bullet spawn origin and velocity aimed at
	/// the target tile, accounting for toroidal map wrap.
	TurretFiringSolution computeFiringSolution(int targetX, int targetY) const;

	/// Phase 5 spawn: if the bullet would reach the target before it moves away,
	/// create it, consume a bullet, and arm the cooldown.
	void fireBullet(const TurretTarget& target, Uint32 stepCounter);

	// ─── Private helper methods ─────────────────────────────────────

	/// This function updates the units harvesting at this building. In
	/// particular, it unsubscribes them when the building is being destroyed or
	/// turns invisible when for example the other teams switches the view for
	/// its markets.
	void updateUnitsHarvesting(void);

	///This function puts hidden forbidden area around a new building site. This disperses units so that
	///the building isn't waiting for space when there are lots of units.
	void addForbiddenZoneToUpgradeArea(void);
	///This function removes the hidden forbidden area placed by addForbiddenToUpgradeArea
	///It must be done before any type or position state is changed.
	void removeForbiddenZoneFromUpgradeArea(void);
	///Shared body for add/remove. `add=true` adds the zone, `add=false` removes it.
	void modifyForbiddenZoneForUpgradeArea(bool add);

	///No-arg overload: defers to the public `isHardSpaceForBuildingSite(requestedState)` using the
	///building's current `constructionResultState`.
	bool isHardSpaceForBuildingSite(void);

	///Designates whether we are full inside. For Inns, takes into account how much food is left
	///and whether there is enough food for more units.
	bool fullInside(void);

	///This function tells the number of workers that should be working at this building.
	///If, for example, the building doesn't need any materials, then this function will
	///return 0, because if its already full, it doesn't need any units.
	int desiredNumberOfWorkers(void);

	/// Tells whether a particular unit can work at this building. Takes into account this buildings level,
	/// the units type and level, and whether this building is a flag, because flags get a couple of special
	/// rules.

	/// Per-zonable candidate-selection helpers for subscribeForFlagingStep.
	/// Each tests one unit against the per-flag-type requirements (activity,
	/// level, distance reachability) and either populates *dist with the
	/// distance metric used for scoring, or increments
	/// unitsFailingRequirements with the rejection reason.
	/// Returns true iff the unit is accepted as a candidate.
	///
	/// Distance metrics differ by flag type and are NOT interchangeable:
	///   - Explorer flag: squared Euclidean distance from Map::warpDistSquare,
	///     compared against timeLeft^2. On constrained air terrain, the same
	///     squared score uses route travel distance supplied by a shared field.
	///   - Worker / Warrior flag: linear gradient distance from
	///     Map::buildingAvailable (range 0..~254), compared against timeLeft.
	bool considerUnitForExplorerFlag(Unit* unit, int* dist, int terrainDistance = -1);
	bool considerUnitForWorkerFlag(Unit* unit, int* dist);
	bool considerUnitForWarriorFlag(Unit* unit, int* dist, int terrainDistance=-1);

	/// One worker that could be hired to carry materials to this building,
	/// with the metrics the selection passes of
	/// subscribeToBringMaterialsStep score on. A null `unit` means the slot
	/// holds no candidate. `distance` is the linear gradient distance to the
	/// building when the unit already carries the material being staffed, or
	/// the round distance through a source when it must fetch the material.
	struct BringMaterialsCandidate
	{
		Unit* unit;
		int distance;
	};

	/// Running best-candidate state shared, in order, across the three
	/// selection passes. Later passes run only while `choosen` is still null.
	/// Candidates are ranked by `maxLevel` first, then by smallest `minValue`.
	struct BringMaterialsSelection
	{
		int maxLevel;
		int minValue;
		Unit* choosen;
	};

	/// Lets src/unit/FetchHiringScoreHarness.cpp reach considerUnitForMaterial
	/// without exposing it to game callers, as GameGUI does for its own harness.
	friend class FetchHiringScoreHarness;

	/// Whether a unit is a possible hire at all: harvest-capable, idle, healthy,
	/// high enough level, and close enough to reach this building before going
	/// hungry. Fills *distBuilding on success; on failure tallies the rejection
	/// reason in unitsFailingRequirements and returns false.
	bool considerUnitForBuilding(Unit* unit, int* distBuilding, int airDistance=-1);

	/// Per-unit predicate for one material: considerUnitForBuilding plus a
	/// reachable source of `wantedMaterial` the unit can fetch from and still
	/// carry to this building before going hungry. Fills *dist with the round
	/// distance by way of the resource. Callers must pre-filter units lacking
	/// the HARVEST ability or already filling this building.
	bool considerUnitForMaterial(Unit* unit, int wantedMaterial, int* dist, int airDistance=-1);

	/// Packs workers hireable to fetch `wantedMaterial` into candidates in unit
	/// index order and returns their count. The caller supplies Unit::MAX_COUNT
	/// slots. Rejection reasons are tallied via considerUnitForMaterial. The
	/// tallies are reset per scan, so they describe one material, never a unit
	/// counted once per material the building tried.
	int gatherBringMaterialsCandidates(BringMaterialsCandidate* candidates, int wantedMaterial, const int* airDistances=nullptr);
	// Keep large scratch arrays off fully staffed/dead/timer-only admission paths.
	[[gnu::noinline]] bool hireMaterialUnit(const int* targets, const int* served, const int* airDistances);
	[[gnu::noinline]] bool hireMaterialUnitWithFlyingDistances(const int* targets, const int* served);
	[[gnu::noinline]] bool hireFlagUnits();

	/// Per-material delivery targets and how many of each are already accounted
	/// for by deliveries that landed plus units on their way. Counted in
	/// deliveries, not material units: one delivery adds
	/// materialMultiplier[r] to materials[r].
	void fetchApportionment(int targets[MaterialSlotCount], int served[MaterialSlotCount]) const;

	/// Whether another fetcher should be sent for r: the building has physical
	/// room for one more delivery and the deliveries already subscribed do not
	/// cover the target.
	bool wantsAnotherDelivery(int r, const int* targets, const int* served);

	/// Hire a unit that already carries a material this building still wants. It
	/// delivers without a fetch trip at all, so it is preferred whatever the
	/// apportionment says; the apportionment only directs units we must send
	/// out. Assigns destinationPurpose to every carrying candidate it inspects,
	/// not only the one chosen, and scores on a hunger-discounted distance.
	/// Both are deliberate and must be preserved.
	void selectUnitCarryingWantedMaterial(const int* targets, const int* served, BringMaterialsSelection& sel, const int* airDistances=nullptr);

	/// The fetch-out selection pass for one material. Scans all candidates and
	/// updates `sel` with the best match, assigning destinationPurpose only to
	/// the unit it chooses. A candidate holding something else is charged
	/// CARRIED_MATERIAL_PENALTY_TILES of detour rather than excluded, so it is
	/// hired when it is enough closer to be worth the loss.
	void selectFetcher(const BringMaterialsCandidate* candidates, int count, int wantedMaterial, BringMaterialsSelection& sel);

	/// Updates the materials pointer to local or team storage, depending on BuildingType.
	void updateMaterialsPointer();

	/// checkstyle found this block of 26 lines being repeated 4 times.
	void checkGroundExitQuality(
		const int testX,
		const int testY,
		const int extraTestX,
		const int extraTestY,
		int & exitX,
		int & exitY,
		int & exitQuality,
		int & oldQuality,
		bool canSwim, bool canWalk);

public:
	// ─── Public data ────────────────────────────────────────────────

	int verbose;

	// Pointer-free authoritative values are inherited from BuildingStateRecord.
	BuildingType *type;
	Team *owner;
	/// Runtime alias selecting localMaterials or owner->teamMaterials. Snapshot
	/// records retain the local stock and a selector for the frozen team stock.
	Sint32* materials;
	/// Units actively working for and occupying the building, respectively.
	std::list<Unit *> unitsWorking;
	std::list<Unit *> unitsInside;

	//! Full-map pathfinding gradient toward this building (a flag's zone, or a clearing
	//! flag's resources), one per swim class, NULL until a unit of that class asks for it.
	//! Building owns these buffers; resetPathfindGradients frees them. Refresh and
	//! stuck-unit retry policy lives in Map::buildingGradient / pathfindBuilding.
	Uint16 *globalGradient[BUILDING_GRADIENT_COUNT];
	//! Retained propagation queues. Never serialized: saving completes
	//! their fields first. Null for loaded or locked fields; owned with globalGradient.
	std::unique_ptr<BuildingGradientSearch> globalGradientSearch[BUILDING_GRADIENT_COUNT];
	//! Set when the map changed nearby; rebuilt on use once DIRTY_REBUILD_TICKS
	//! have elapsed since the last rebuild.
	bool dirtyGradient[BUILDING_GRADIENT_COUNT];
	Uint32 lastGlobalGradientUpdateStepCounter[BUILDING_GRADIENT_COUNT];
	//! Map::topologyGeneration when each field was computed. Differs from the
	//! map's current value exactly when the ground it was built against has moved.
	Uint32 gradientGeneration[BUILDING_GRADIENT_COUNT];
	// These flags track physical access (cannot swim / can swim), not travel cost.
	// All swimming classes share passability, but keep separate weighted fields.
	//! Last step a unit asked for the gradient; freeIdleGradients drops it when that is long ago.
	Uint32 globalGradientUsedStep[BUILDING_GRADIENT_COUNT];
	//! Drop the building's gradients nobody asked for lately. Each is a full map
	//! of Uint16.
	void freeIdleGradients();
	//! Scheduled building gradients (MapGradientScheduling.cpp).
	//! Owner-only and never serialized: a save records each pending result's
	//! supersession instead. refreshEpoch[slot] changes whenever the slot is
	//! rebuilt synchronously or dropped, so an older pending result cannot
	//! replace it; refreshRequested marks a queued or pending refresh of the
	//! slot; settledCostHint is the previous search's reader-required cost
	//! when it was replaced (Map::predictBuildingDepth).
	Uint32 refreshEpoch[BUILDING_GRADIENT_COUNT] {};
	std::bitset<BUILDING_GRADIENT_COUNT> refreshRequested;
	static constexpr Uint16 UNKNOWN_SETTLED_COST = 0xFFFF;
	Uint16 settledCostHint[BUILDING_GRADIENT_COUNT] {};
	void supersedeGradient(int slot) { ++refreshEpoch[slot]; refreshRequested.reset(slot); }
	//! A dropped field starts its next lifetime with no depth history.
	void dropGradientSlot(int slot, GradientDrop cause)
	{ supersedeGradient(slot); settledCostHint[slot] = UNKNOWN_SETTLED_COST; gradientDrop[slot] = cause; }
	//! Owner-only diagnostics, never serialized or read by the simulation.
	GradientDrop gradientDrop[BUILDING_GRADIENT_COUNT] {};
	BuildingRoute resolveRoute(BuildingRoute route) const;
	int routeSlot(int swimClass, BuildingRoute route) const
	{ return int(route == BuildingRoute::Automatic ? resolveRoute(route) : route) * SWIM_CLASS_COUNT + swimClass; }
	int routeAccess(int swimClass, BuildingRoute route) const
	{ return int(route == BuildingRoute::Automatic ? resolveRoute(route) : route) * SWIM_VARIANT_COUNT + (swimClass == SWIM_CLASS_COUNT-1 ? 2 : int(swimClass > 0)); }
	int workRoleTarget(int role) const; // -1 delivery, otherwise attracted unit class
	bool subscribeWorkStep();

	// Per-swim-variant tri-state cache of whether a clearing flag has any
	// resource in range (set when its gradient is built). Stored value at each
	// slot: 0 = unknown (not yet computed), 1 = true (has at least one), 2 = false (none).
	int anyResourceToClear[SWIM_VARIANT_COUNT];



	enum UnitCantWorkReason
	{
		UnitNotAvailable=0,
		UnitTooLowLevel=1,
		UnitCantAccessBuilding=2,
		UnitTooFarFromBuilding=3,
		UnitCantAccessResource=4,
		UnitCantAccessFruit=5,
		UnitTooFarFromResource=6,
		UnitTooFarFromFruit=7,
		UnitCantWorkReasonSize,
	};

	/// Display only. While the local player has this building selected, the
	/// units behind each tally are kept by gid so the map view can mark them.
	/// Never read by the simulation, not saved, not in the checksum.
	bool recordFailingUnits = false;
	std::vector<Uint16> unitsFailingByReason[UnitCantWorkReasonSize];
	void setRecordFailingUnits(bool on);
	/// Count `unit` under `reason`, and remember it while recording (busy units,
	/// UnitNotAvailable, are only counted: marking every working unit says nothing).
	void noteUnitFailing(Unit* unit, UnitCantWorkReason reason);
	/// Start a hiring pass: every tally and remembered unit is dropped.
	void resetFailureTallies();

private:
	// ─── Private data ───────────────────────────────────────────────

	// pending player orders (consumed by step())
	std::list<Order *> orderQueue;

	// units: scratch counters for subscription / priority diff
	Sint32 maxUnitWorkingPrevious;
	///The subscribeToBringMaterialsStep and subscribeForFlagingStep operate every 32 ticks
	Sint32 subscriptionWorkingTimer;
	///This stores the old priority, so that if the priority changes, this building will be updated in Teams
	Sint32 oldPriority;

	///This is the list of units harvesting from the building (if it is a market for instance)
	std::list<Unit *> unitsHarvesting;

	// optimisation and consistency
	InListState inCanFeedUnit;
	Uint8 canNotConvertUnitTimer; //counts down 150 frames after the building was last unable to feed a unit
	InListState inCanHealUnit;
	InListState inUpgrade[NB_ABILITY];
	/// This variable indicates whether this building is already in the team call list
	/// to receive units. A 1 indicates its already in the call list, and 0 indicates
	/// that it is not.
	Uint8 callListState;


	// swarm building parameters (private):
	Sint32 totalRatio;

	// turrets building parameters (private):
	Uint32 shootingStep;
	Sint32 shootingCooldown;
};
