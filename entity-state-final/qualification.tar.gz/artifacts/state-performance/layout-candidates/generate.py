from pathlib import Path
import subprocess,hashlib,json,difflib
out=Path(__file__).resolve().parent
state=Path('src/building/BuildingState.h').read_text()
live=Path('src/building/Building.h').read_text()
lifecycle=Path('src/building/Lifecycle.cpp').read_text()
assert state==subprocess.check_output(['git','show','277510840054b1416f2defd7d86fe1431dd0ddc0:src/building/BuildingState.h'],text=True), 'Building state changed; re-audit before applying historical compact layout'
compact=subprocess.check_output(['git','show','3122cbe34433a0211faa34ec00bdeef9a09edca3:src/building/BuildingState.h'],text=True)
# Audited conversions preserve original full-width save rejection before narrowing.
loader=lifecycle
replacements=[
('minLevelToFlag = stream->readSint32("minLevelToFlag");\n\tif (minLevelToFlag < 0 || minLevelToFlag >= NB_UNIT_LEVELS) throw std::runtime_error("Invalid flag level");','const Sint32 savedMinLevelToFlag = stream->readSint32("minLevelToFlag");\n\tif (savedMinLevelToFlag < 0 || savedMinLevelToFlag >= NB_UNIT_LEVELS) throw std::runtime_error("Invalid flag level");\n\tminLevelToFlag = Uint8(savedMinLevelToFlag);'),
('minWorkerLevelToFlag = stream->readSint32("minWorkerLevelToFlag");\n\t\tif (minWorkerLevelToFlag < 0 || minWorkerLevelToFlag >= NB_UNIT_LEVELS) throw std::runtime_error("Invalid worker flag qualification");','const Sint32 savedMinWorkerLevelToFlag = stream->readSint32("minWorkerLevelToFlag");\n\t\tif (savedMinWorkerLevelToFlag < 0 || savedMinWorkerLevelToFlag >= NB_UNIT_LEVELS) throw std::runtime_error("Invalid worker flag qualification");\n\t\tminWorkerLevelToFlag = Uint8(savedMinWorkerLevelToFlag);'),
('maxUnitInside = stream->readSint32("maxUnitInside");\n\tif (maxUnitInside < 0 || maxUnitInside >= MAX_UNIT_INSIDE_LIMIT)\n\t\tthrow std::runtime_error("Invalid building capacity");','const Sint32 savedMaxUnitInside = stream->readSint32("maxUnitInside");\n\tif (savedMaxUnitInside < 0 || savedMaxUnitInside >= MAX_UNIT_INSIDE_LIMIT)\n\t\tthrow std::runtime_error("Invalid building capacity");\n\tmaxUnitInside = Uint16(savedMaxUnitInside);')]
for old,new in replacements:
 assert loader.count(old)==1,old
 loader=loader.replace(old,new)
# Move only owner/type/material bindings and reservations within the existing live
# class. Runtime already directly follows the inherited state.
def cluster_live(s):
 reservations='\t// Reservations protect shared stock from other services and production.\n\tBuildingMaterialCost reservedMaterials{};\n'
 pointers='\t// Pointer-free authoritative values are inherited from BuildingStateRecord.\n\tBuildingType *type;\n\tTeam *owner;\n\t/// Runtime alias selecting localMaterials or owner->teamMaterials. Snapshot\n\t/// records retain the local stock and a selector for the frozen team stock.\n\tSint32* materials;\n'
 assert s.count(reservations)==1 and s.count(pointers)==1
 s=s.replace(reservations,'').replace(pointers,'')
 return s.replace('\tconst BuildingRuntimeTraits* runtime=nullptr;\n','\tconst BuildingRuntimeTraits* runtime=nullptr;\n'+pointers+reservations)
# Reuse real existing fields, rather than padding, to restore stock offsets.
offsets=compact
for declaration in ['\tSint32 hp;\n','\tSint32 productionTimeout;\n','\tSint32 productionUnit = -1;\n']:
 assert offsets.count(declaration)==1
 offsets=offsets.replace(declaration,'')
offsets=offsets.replace('\t// Canonical private stock.', '\tSint32 hp;\n\tSint32 productionTimeout;\n\tSint32 productionUnit = -1;\n\t// Canonical private stock.')
# Put both inventory arrays at offset zero; all other fields retain relative order.
first=compact
arrays='\tSint32 localMaterials[MaterialSlotCount];\n\tSint32 wishedMaterials[MaterialSlotCount];\n'
assert first.count(arrays)==1
first=first.replace(arrays,'').replace('\t// Presentation clocks remain excluded from legacy simulation checksums.','\t// Inventory arrays lead this experimental state layout.\n'+arrays+'\n\t// Presentation clocks remain excluded from legacy simulation checksums.')
# Keep the displaced explanatory stock comment with the arrays.
stock_comment='\t// Canonical private stock. Shared stock is owned by Team; a runtime binding\n\t// selects that pool instead, and snapshot queries select the frozen Team pool.\n'
first=first.replace(stock_comment,'').replace('\t// Inventory arrays lead this experimental state layout.\n',stock_comment)
padded=compact.replace('\tbool operator==(const BuildingStateRecord&) const = default;','\t// Experimental control only: restore the baseline state extent/downstream offsets.\n\tUint8 layoutControlPadding[16]{};\n\tbool operator==(const BuildingStateRecord&) const = default;')
candidates={
 'compact-near-bindings':(compact,cluster_live(live)),
 'stock-offsets-preserved':(offsets,live),
 'stock-first-near-bindings':(first,cluster_live(live)),
 'compact-padded-control':(padded,live)}
manifest={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_master':subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip(),'source_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['src/building/BuildingState.h','src/building/Building.h','src/building/Lifecycle.cpp']},'candidates':[]}
for name,(st,lv) in candidates.items():
 content={'src/building/BuildingState.h':st,'src/building/Building.h':lv,'src/building/Lifecycle.cpp':loader}
 patch=''
 for path,s in content.items():
  dest=out/name/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(s)
  old=Path(path).read_text();patch+=''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 (out/(name+'.patch')).write_text(patch)
 manifest['candidates'].append({'name':name,'sha256':{p:hashlib.sha256(s.encode()).hexdigest() for p,s in content.items()}})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Generated',', '.join(candidates))
