#include "Unit.h"
#include "Building.h"
#include "sim/snapshot/WorldRecords.h"
#include <cstddef>
#include <iostream>
#define RECORD(T) std::cout << #T << " size=" << sizeof(T) << " align=" << alignof(T) << '\n'
#define FIELD(F) std::cout << "BuildingStateRecord." #F << " offset=" << offsetof(BuildingStateRecord,F) << " size=" << sizeof(BuildingStateRecord::F) << '\n'
int main() {
    RECORD(BuildingStateRecord); RECORD(Building); RECORD(SimulationSnapshot::BuildingView);
    FIELD(lastShootStep); FIELD(entityRandom); FIELD(gid); FIELD(maxUnitInside);
    FIELD(buildingState); FIELD(constructionResultState); FIELD(minLevelToFlag); FIELD(minWorkerLevelToFlag);
    FIELD(localMaterials); FIELD(wishedMaterials); FIELD(hp); FIELD(productionTimeout); FIELD(productionUnit);
    FIELD(ratio); FIELD(unitsFailingRequirements); FIELD(areaFundingTick);
}
