// Temporary diagnostic harness: evidence only, never a shipping source.
#include "EngineFixtures.h"
#include "sim/snapshot/WorldRecords.h"
#include <cstdint>
#include <iostream>
#if defined(__GLIBC__)
#include <malloc.h>
#endif
TEST_SUITE("BuildingLayoutDiagnostic") {
TEST_CASE("live building offsets and allocation placement [benchmark]") {
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame fixture({.wDec=7,.hDec=7,.teams=1,.clearImmobile=true,.header=true,.seed=9123});
    // Report actual member addresses; Building need not be standard-layout.
    for(int i=0;i<256;++i) {
        auto* b=fixture.addBuilding("inn",4+(i%16)*6,4+(i/16)*6); REQUIRE(b);
        const auto address=reinterpret_cast<std::uintptr_t>(b);
        const auto offset=[&](const auto* member) {return reinterpret_cast<std::uintptr_t>(member)-address;};
        nlohmann::json row{{"slot",i},{"address",address},{"address_mod_64",address%64},{"address_mod_128",address%128},{"address_mod_4096",address%4096},
            {"state_size",sizeof(BuildingStateRecord)},{"state_alignment",alignof(BuildingStateRecord)},
            {"live_size",sizeof(Building)},{"live_alignment",alignof(Building)},
            {"view_size",sizeof(SimulationSnapshot::BuildingView)},{"view_alignment",alignof(SimulationSnapshot::BuildingView)},
            {"state_offset",offset(static_cast<const BuildingStateRecord*>(b))},{"runtime_offset",offset(&b->runtime)},
            {"type_offset",offset(&b->type)},{"owner_offset",offset(&b->owner)},{"materials_binding_offset",offset(&b->materials)},
            {"reservations_offset",offset(&b->reservedMaterials)},{"stock_offset",offset(&b->localMaterials)},
            {"demand_offset",offset(&b->wishedMaterials)},{"stock_address_mod_64",reinterpret_cast<std::uintptr_t>(b->localMaterials)%64},
            {"demand_address_mod_64",reinterpret_cast<std::uintptr_t>(b->wishedMaterials)%64},
            {"reservation_address_mod_64",reinterpret_cast<std::uintptr_t>(&b->reservedMaterials)%64},
            {"private_stock_selected",b->materials==b->localMaterials}};
#if defined(__GLIBC__)
        row["malloc_usable_size"]=malloc_usable_size(b);
#else
        row["malloc_usable_size"]=nullptr;
#endif
        std::cout<<"BUILDING_LAYOUT "<<row.dump()<<'\n';
    }
}
}
