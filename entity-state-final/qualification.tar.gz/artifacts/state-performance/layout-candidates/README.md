# Offline building-layout candidates

These ignored diagnostic alternatives preserve the current unit compaction and all
building logical values. They reuse only the already-audited building changes:
byte lifecycle/recruitment fields and unsigned 16-bit maxUnitInside. Stock/demand,
production, staffing, priority, timers and masks retain their original widths.
Each candidate includes the wide-before-narrow loader conversions; never apply a
candidate header alone when testing save acceptance.

Run `python3 artifacts/state-performance/layout-candidates/generate.py` from the
repository root to regenerate copied headers, lifecycle source, manifests and four
independent patches. Apply exactly one patch to a separate copied candidate source.
No build or native benchmark was performed during design. All patches passed
`git apply --check` against the current resolved integration source.

| Candidate | Exact changes | Expected x86_64 layout, to verify |
| --- | --- | --- |
| compact-near-bindings | Use the original audited compact state. Move type, owner, materials bindings next to runtime immediately after the state base, then reservedMaterials; keep them outside pointer-free state. | State336; stock/demand108/168. Runtime/type/owner/material/reservations cluster. Live1944 expected; compiler decides padding. |
| stock-offsets-preserved | Use compact state. Move existing hp, productionTimeout and productionUnit declarations immediately before private stock. Keep live class member order unchanged. | State336; stock/demand120/180, matching baseline record offsets. Later live fields still shift by16. No explicit padding. |
| stock-first-near-bindings | Move both 15-slot stock/demand arrays to the beginning of compact state. Keep all other state declarations in their relative order. Move live bindings/reservations as in compact-near-bindings. | State336; stock/demand0/60. The two arrays remain contiguous; live bindings follow the record. |
| compact-padded-control | Original audited compact state plus16 explicit zero-initialized bytes at its end. Keep baseline live class member order. | State352 and live1960 expected, with baseline downstream live offsets and allocation extent. Stock/demand remain108/168. Snapshot record savings intentionally disappear. |

These are expected sizes, not compiled measurements or portability guarantees.
The padding control is experimental only: it tests the effect of downstream offsets
and object extent while retaining narrowed operations. Its explicit bytes are
never serialized; they must stay zero. This control must not be shipped solely to
preserve a presumed allocation pattern.

`record-offsets.cpp` is a standalone compile/run probe using only standard-layout
BuildingStateRecord for offsetof. Use the exact release include/dependency flags
from the corresponding build. It reports state/live/view sizeof and alignment,
plus stock, demand, narrowed fields and major continuation fields. Compare its
output with the actual build, not handwritten field arithmetic.

`BuildingLayoutDiagnostic.cpp` is an evidence-only engine harness; temporarily
register it in the copied candidate sources alongside existing harnesses. Run the
BuildingLayoutDiagnostic suite in a separate process after release builds. It
creates256 identical inn allocations and emits each actual base/member offset,
object/stock/demand/reservation address residue modulo64/128/4096, and glibc usable
allocation size (null elsewhere). Real member addresses avoid assuming Building's
multiple inheritance is standard-layout. Preserve individual rows, not just totals.

Run baseline and all candidates under the same affinity, dependencies, release
flags, fixtures and rotated paired protocol. Record disassembly for availableMaterial
and the calling inventory loops; field displacement, inlining or code alignment
may change even when the instruction counts match. Use actual allocator/address
samples to describe placement differences. If practical, repeat placement samples
with both building-first and interleaved unit/building allocation order in isolated
fixture copies, and report seed/order. ASLR/address residue correlation alone does
not establish the cause of a timing difference.

Before any performance interpretation, require equal canonical saves and continued
checksums, capacity/recruitment invalid-input boundaries, and snapshot correctness.
Compare capture, read, update, owner and whole-match/frame costs separately, plus
payload/capacity and allocator bytes. The padding control and reordered candidates
are diagnostics; retain a shipping candidate only if its savings and measured costs
justify the change. Do not assume cache placement caused the previous regression.

The user's acceptance criterion is total process CPU, not an independent prohibition
on any inventory microbenchmark slowdown. Keep read/update results for attribution,
but assess each smaller candidate against ordinary/colony whole-match and whole-frame
CPU under the agreed paired protocol. Report confidence bounds and inconclusive
results; do not assert no regression from an interval that permits a meaningful
slowdown. A local inventory slowdown can be acceptable when reduced capture and
other costs pay for it in the total workloads.
