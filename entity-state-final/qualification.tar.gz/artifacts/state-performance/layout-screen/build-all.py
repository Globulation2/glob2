import subprocess,os,json,time,hashlib,shutil,argparse
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--jobs',type=int,default=28);parser.add_argument('--resume',action='store_true');args=parser.parse_args()
repo=Path.cwd();r=repo/'artifacts/state-performance/layout-screen';source=r/'source'
labels=['baseline','units','compact-original','compact-near-bindings','stock-offsets-preserved','stock-first-near-bindings','compact-padded-control']
env=dict(os.environ,GLOB2_SDL3_PREFIX=str(repo/'artifacts/state-compaction/native-sdl'))
targets=['engine-tests','software-render-benchmark','build/linux/client/release/dev-linker-auto/src/glob2']
outputs={'engine-tests':'test/glob2-engine-tests','renderer':'test/SoftwareRenderBenchmark','glob2':'src/glob2'}
manifest=json.loads((r/'binaries.json').read_text()) if args.resume and (r/'binaries.json').exists() else {}
for label in labels:
 if args.resume and label in manifest:continue
 (r/'build-stage.json').write_text(json.dumps({'label':label,'status':'building','time_ns':time.time_ns()})+'\n')
 subprocess.run(['python3',str(r/'prepare-source.py'),label],check=True,cwd=repo)
 cmd=['python3','tools/dev_build.py','dev_fast=0','release=1','-j'+str(args.jobs),*targets]
 with (r/(label+'-build.log')).open('w') as f:subprocess.run(cmd,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 manifest[label]={'build_command':cmd,'binaries':{}}
 for suffix,path in outputs.items():
  dest=r/(label+'-'+suffix);shutil.copy2(source/'build/linux/client/release/dev-linker-auto'/path,dest)
  manifest[label]['binaries'][suffix]={'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'path':str(dest)}
 # Standard-layout offsetof probe with the exact release include/dependency flags.
 import shlex
 line=next(x for x in (r/(label+'-build.log')).read_text().splitlines() if 'g++ -o ' in x and ' -c ' in x)
 tokens=shlex.split(line);flags=[x for x in tokens if x.startswith(('-I','-D','-std='))]
 probe=repo/'artifacts/state-performance/layout-candidates/record-offsets.cpp'
 subprocess.run(['g++','-O3',*flags,str(probe),'-o',str(r/(label+'-offsets'))],cwd=source,check=True)
 (r/(label+'-offsets.txt')).write_text(subprocess.check_output([str(r/(label+'-offsets'))],text=True))
 (r/'binaries.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('Frozen '+label,flush=True)
(r/'build-stage.json').write_text(json.dumps({'status':'passed','labels':labels,'time_ns':time.time_ns()})+'\n')
