import argparse,os,subprocess,json,hashlib,random,statistics,math,re
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--label',action='append',required=True);p.add_argument('--repeat',type=int,default=10);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
r=Path(__file__).resolve().parent;a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=True)
fixtures=[('normal-colonies',r.parent/'colony-fixture/final.game.gz'),('unit-heavy',r/'unit-heavy-gui.game')]
report={'protocol':json.loads((r/'protocol.json').read_text()),'warmup_frames':120,'measured_frames':240,'mode':'advancing production Engine, unpaced serial host, one tick per displayed frame','process_cpu_scope':'game process and all its threads; excludes Xvfb/display server','runs':[],'summaries':[]}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ci(v):
 logs=[math.log(x) for x in v];rng=random.Random(919);s=sorted(statistics.mean(rng.choices(logs,k=len(logs))) for _ in range(20000))
 return {'change_percent':100*math.expm1(statistics.mean(logs)),'lower_95_percent':100*math.expm1(s[500]),'upper_95_percent':100*math.expm1(s[19500])}
for rep in range(a.repeat):
 order=a.label[rep%len(a.label):]+a.label[:rep%len(a.label)]
 if rep%2:order.reverse()
 for workers,affinity in [(1,'6'),(4,'4-7')]:
  for name,fixture in fixtures:
   for label in order:
    out=a.output/f'{rep:02d}-{name}-workers{workers}-{label}';out.mkdir(exist_ok=True)
    env=dict(os.environ,SDL_VIDEODRIVER='x11',SDL_AUDIODRIVER='dummy',LIBGL_ALWAYS_SOFTWARE='1',PROFILE_MODE='advancing',PROFILE_SAVE=str(fixture),PROFILE_SECONDS='0',PROFILE_FRAMES='240',PROFILE_WARMUP='120',PROFILE_CLOUDS='1',GLOB2_RENDER_WORKERS=str(workers),GLOB2_USER_DATA_DIR=str(out/'profile'))
    if name=='unit-heavy':env.update(PROFILE_ZOOM='0.5',PROFILE_OFFSET_Y='86')
    if rep==0:env['PROFILE_CAPTURE']=str(out/'frame.bmp')
    cmd=['taskset','-c',affinity,str(r/(label+'-renderer')),'--renderer','software','--window-size','1280x800','--mute','--no-fullscreen','--compute-threads',str(workers),'--gradient-backend','cpu']
    with (out/'run.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
    text=(out/'run.log').read_text();cpu=float(re.search(r'process_cpu_seconds=([0-9.]+)',text)[1]);wall=float(re.search(r'wall_seconds=([0-9.]+)',text)[1]);ticks=int(re.search(r'measured_ticks=(\d+)',text)[1]);assert ticks==240
    report['runs'].append({'pair':rep,'fixture':name,'workers':workers,'variant':label,'command':cmd,'binary_sha256':sha(r/(label+'-renderer')),'fixture_sha256':sha(fixture),'total_process_cpu_seconds':cpu,'wall_seconds':wall,'cpu_seconds_per_tick':cpu/ticks,'cpu_seconds_per_frame':cpu/240,'wall_seconds_per_frame':wall/240,'checksum':int(re.search(r'simulation_checksum=(\d+)',text)[1]),'displayed_scene_tick':int(re.search(r'displayed_scene_tick=(\d+)',text)[1]),'measured_ticks':ticks,'frames':240,'environment':{k:v for k,v in env.items() if k.startswith(('PROFILE_','GLOB2_RENDER'))}})
    (a.output/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
   group=[x for x in report['runs'] if x['pair']==rep and x['fixture']==name and x['workers']==workers];assert len({x['checksum'] for x in group})==1,'simulation divergence'
   print('Frame pair',rep+1,name,'workers',workers,{x['variant']:round(x['cpu_seconds_per_frame']*1000,3) for x in group},flush=True)
for workers in [1,4]:
 for name,_ in fixtures:
  for label in a.label:
   if label=='baseline':continue
   row={'fixture':name,'workers':workers,'variant':label,'metrics':{}}
   for metric in ['cpu_seconds_per_frame','wall_seconds_per_frame']:
    bs=[];cs=[]
    for rep in range(a.repeat):
     b=next(x for x in report['runs'] if x['pair']==rep and x['fixture']==name and x['workers']==workers and x['variant']=='baseline');c=next(x for x in report['runs'] if x['pair']==rep and x['fixture']==name and x['workers']==workers and x['variant']==label);bs.append(b[metric]);cs.append(c[metric])
    row['metrics'][metric]={'baseline':statistics.mean(bs),'candidate':statistics.mean(cs),**ci([c/b for b,c in zip(bs,cs)])}
   report['summaries'].append(row)
(a.output/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
