import argparse,os,json,subprocess,re
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--label',action='append',required=True);p.add_argument('--tool',choices=['callgrind','cachegrind'],required=True);a=p.parse_args()
r=Path(__file__).resolve().parent;out=r/a.tool;out.mkdir(exist_ok=True)
counts={'2':{'capture':64,'inventory_read':64,'inventory_update':64,'owner':1,'consumer':1}};(out/'counts.json').write_text(json.dumps(counts)+'\n')
for mode in ['private','shared']:
 for label in a.label:
  selections=[None] if a.tool=='callgrind' else [mode+'_inventory_read',mode+'_inventory_update',mode+'_capture']
  for selection in selections:
   name=label+'-'+mode+('-'+selection if selection else '');prefix=out/name
   cmd=['valgrind','--tool='+a.tool,'--instr-atstart=no' if a.tool=='callgrind' else '--instr-at-start=no','--cache-sim=yes','--branch-sim=yes','--'+a.tool+'-out-file='+str(prefix)+'.out',str(r/(label+'-engine-tests')),'--test-suite=WorldSnapshot','--test-case=paired entity storage workload*','--no-colors=true']
   env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_ENTITY_SCENARIO='2',GLOB2_ENTITY_SHARED='1' if mode=='shared' else '0',GLOB2_ENTITY_BENCH_CONFIG=str(out/'counts.json'))
   if selection:env['GLOB2_ENTITY_PROFILE_PHASE']=selection
   with Path(str(prefix)+'.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
   files=list(sorted(out.glob(name+'.out.*'))) if a.tool=='callgrind' else [Path(str(prefix)+'.out')];phases=[]
   for file in files:
    s=file.read_text();events=re.search(r'^events: (.*)$',s,re.M)[1].split();values=list(map(int,re.search(r'^summary: (.*)$',s,re.M)[1].split()))
    phase=re.search(r'^desc: Trigger: Client Request: (.*)$',s,re.M)[1] if a.tool=='callgrind' else selection
    phases.append({'phase':phase,'events':dict(zip(events,values)),'path':str(file)})
   Path(str(prefix)+'.json').write_text(json.dumps({'label':label,'mode':mode,'tool':a.tool,'command':cmd,'counts':counts,'phases':phases,'scope':'simulated caches/instructions; no native runtime claim'},indent=2)+'\n')
   print(a.tool,name,'complete',flush=True)
