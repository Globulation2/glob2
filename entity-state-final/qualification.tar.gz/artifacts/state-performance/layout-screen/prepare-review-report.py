from pathlib import Path
import json,re,hashlib,shutil
p=Path(__file__).resolve().parent
screen=json.loads((p/'screen/comparison.json').read_text());profiles=json.loads((p/'profile-summary.json').read_text());smoke=json.loads((p/'layout-smoke/results.json').read_text());bins=json.loads((p/'binaries.json').read_text());fail=json.loads((p/'baseline-four-results.json').read_text());protocol=json.loads((p/'protocol.json').read_text())
labels=list(bins)
rows=[]
for label in labels:
 text=(p/(label+'-offsets.txt')).read_text();size=dict(re.findall(r'^(\S+) size=(\d+) align=',text,re.M));offset=dict(re.findall(r'^BuildingStateRecord\.(\w+) offset=(\d+) ',text,re.M))
 layout=next(r['building_layout'] for r in screen['runs'] if r['variant']==label and r['inventory_mode']=='private')
 rows.append('| '+label+' | '+' | '.join([size['BuildingStateRecord'],size['SimulationSnapshot::BuildingView'],size['Building'],offset['localMaterials'],offset['wishedMaterials'],str(layout['offsets']['type']),str(layout['offsets']['owner']),str(layout['offsets']['materials']),str(layout['offsets']['reservedMaterials'])])+' |')
head='''# Reviewer evidence inventory and layout report — selection pending

Integrated source base: b4c463a439953059c9ac058902cff8a652e87f02. The seven-label
release screen uses source manifests based on candidate5f3f6bd37048dc0adb90ad87db95669875ab850c;
manifest hashes, exact commands and binary SHA-256 identify each actual experiment.
Whole-match and advancing-frame qualification are pending: **no final layout choice**.
Earlier results against277510840 are superseded for current integration claims.

## Provenance and acceptance

Archive copies can inherit a Git-revision string from the surrounding checkout or
cached generated inputs. Embedded revision text alone does not identify their
production source. Use each `*-source.json` file's per-file hashes together with
`binaries.json` and exact command/results records. Publish those manifests and the
actual final tested commit/base SHA; do not attribute every binary to a single
embedded Git string. Experimental layout patches and diagnostic adapters belong
only in evidence, not the shipping tree.

User criterion: reduce data size provided total CPU does not regress. Inventory
microbenchmarks explain costs; they are not an independent rejection gate and
must not be summed into a fictitious whole-match estimate. Report absolute process
CPU including all threads, paired bounds, storage savings and each workload's
limitations. Preset component/whole tolerances describe practical uncertainty,
not permission to call a possible slowdown proven absence of regression. Final
choice requires ordinary and colony whole matches plus advancing frames, one/four
workers, and independent confirmation where selected.

## Compiled building layouts

All seven records/live objects/views have natural alignment8 on this toolchain.
UnitState360→264, UnitView384→288 and live Unit440→344 save96bytes each wherever
unit compaction is enabled. Baseline and units-only retain the original building
layout. Four space-saving building candidates save16bytes/record/view/live object;
the padded control intentionally restores those sizes.

| Variant | State | View | Live | State stock | State demand | Live type | Live owner | Live materials pointer | Live reservations |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''
report=head+'\n'.join(rows)+'\n\n'
report+='''Authoritative offsets are compiled standard-layout probes (`*-offsets.txt`);
live offsets use real allocated member addresses from the harness. Allocator usable
size and modulo64 address histograms are recorded per run. The sampled1960-byte
objects sometimes occupy1976 usable bytes; compact objects sampled1944 usable bytes.
Allocation/address distributions describe these fixtures and allocator, not a
portable cache guarantee. Neither matching size nor changed placement proves causality.

## Completed release screen

Ten rotated paired repetitions, private/shared modes, fixed baseline-derived counts,
fixed affinity and process CPU. The140 completed rows have identical canonical
saves within each inventory mode across every variant/pair. The standalone layout
smoke currently has'''+str(len(smoke))+'''rows; remaining coverage must be checked before final publication.
The screen's canonical comparisons cover all seven labels regardless of that
smaller standalone smoke inventory.

Changes below compare compact candidates with units-only, separating unit savings
from incremental building layout effects. Values are process-CPU percent estimate
[two-sided95% paired log-ratio bootstrap bounds].

| Variant | Mode | Capture | Inventory read | Inventory update |
| --- | --- | ---: | ---: | ---: |
'''
for r in screen['summaries']:
 if r['reference']!='units':continue
 vals=[]
 for phase in ['capture','inventory_read','inventory_update']:
  q=r['phases'][phase]['process_cpu_ns'];vals.append(f"{q['change_percent']:+.2f} [{q['lower_95_percent']:+.2f}, {q['upper_95_percent']:+.2f}]")
 report+='| '+r['variant']+' | '+r['inventory_mode']+' | '+' | '.join(vals)+' |\n'
report+='''
Private read Callgrind retired instructions are5,997,701 for every label. Native
read CPU is roughly10–14% higher in the compact layouts versus units-only. Nearby
bindings and stock-first designs reduce simulated private-read D1 misses by about13%,
while native CPU remains worse. Cache simulation does not predict or establish the
cause of this slowdown; this evidence rejects a simple “fewer simulated misses
must be faster” explanation. Hardware effects, generated instruction displacements,
code placement, frequency/host conditions and allocation placement remain possible
contributors rather than demonstrated explanations.

## Compatibility and existing baseline failures

Explicit serialized widths/order, ability IDs, enum gaps/sentinels and checksum
order stay unchanged. Narrow loads validate wide values before conversion. The save
floor remains58; current158 format and SIM_REVISION53 come from incoming master,
not this representation change. Never remove accepted historical continuations
merely because they appear derived. No arbitrary content limits, movement adoption,
GUI/headless representation split or new exceptional-material path is introduced.

Four focused failures reproduce on the current native baseline; their exact commands,
binary hash and logs are in baseline-four-results.json. These are unresolved base
limitations, not silently counted as candidate passes:
'''
for r in fail['results']:report+='- '+r['suite']+': '+r['case']+' (exit'+str(r['exit_code'])+').\n'
report+='''
The two JavaScript cases disagree with stored expected traces; the legacy143 roundtrip
fails its resumed-checkpoint comparison; the UnitCatalog case throws an oversized
collection error. Retain logs and distinguish baseline failures from new regressions.
Cross-platform execution is still a separate requirement; Linux/GCC layout evidence
is not proof of Windows/macOS/browser/mobile simulation equivalence.

## Evidence index and final report placeholders

- protocol.json: predeclared paired design, practical bounds, worker/affinity rules.
- binaries.json and seven *-source.json files: executable/source provenance.
- seven *-offsets.txt files: compiled state/live/view size and state offsets.
- screen/comparison.json plus run logs/canonical saves:140 native screen rows.
- profile-summary.json, Callgrind/Cachegrind logs and dumps: attribution diagnostics.
- layout-smoke/results.json: standalone allocation/snapshot/canonical smoke.
- baseline-four-results.json and baseline-failure-0…3.log: reproduced baseline failures.
- ../layout-candidates/: exact alternative definitions and experiment rationale.

Fill after completion, without overwriting exploratory results:

| Required conclusion | Final result / evidence path |
| --- | --- |
| Selected layout and shipping diff | PENDING |
| Paired ordinary/colony whole-match process CPU1/4workers | PENDING |
| Paired advancing-frame process CPU1/4workers | PENDING |
| Independent confirmation and confidence interpretation | PENDING |
| Selected live payload / allocated payload / retained leases / copy traffic | PENDING |
| Final canonical saves, per-tick/replay orders/checksums, renderer pixels | PENDING |
| Current/historical save boundaries and snapshot suite | PENDING |
| Final tested commit/base, exact commands, platform coverage and omissions | PENDING |
| Reviewer-accessible immutable evidence links and PR description | PENDING |

## Review cleanup still needed

Once selection is made, update architecture/persistence wording to exactly the chosen
building layout (current unit-only prose must change if a compact candidate wins).
Keep only selected declaration order, validation conversions and useful enduring
harness coverage. Delete experimental padding, alternative selectors, temporary
baseline adapters and diagnostic-only sources from the shipping diff. Keep them in
published reproduction evidence. Refresh build/test/source hashes after final edits;
check renderer/editor bindings and the latest incoming snapshot/statistics APIs.
Fetch master and refresh relevant integration checks before merge. Keep the PR draft
until required final qualification is recorded. Publish source/binary manifests,
raw paired runs, compatibility files and baseline failure logs, not only this narrative.
'''
(p/'reviewer-layout-report.md').write_text(report)
old=Path('docs/.work/entity-state-decisions.md');oldtext=old.read_text()
if not (p/'superseded-field-inventory.md').exists(): (p/'superseded-field-inventory.md').write_text(oldtext)
a=oldtext.index('| Field |');b=oldtext.index('\nCompiled x86_64 layout',a);table=oldtext[a:b]
table=table.replace('| Building lifecycle/result | Direct, Uint8 backing |','| Building lifecycle/result | Candidate direct narrowing, Uint8; final selection pending |').replace('| Building maxUnitInside | Direct, Uint16 |','| Building maxUnitInside | Candidate direct narrowing, Uint16; final selection pending |').replace('| Building minLevelToFlag / minWorkerLevelToFlag | Direct, Uint8 |','| Building minLevelToFlag / minWorkerLevelToFlag | Candidate direct narrowing, Uint8; final selection pending |').replace('not needed for current 16-byte reduction','not needed to establish unit savings')
new='''# Current entity-state field decision inventory

Baseline: origin/master b4c463a439953059c9ac058902cff8a652e87f02.
The current integrated shipping proposal has unit compaction; final building layout
selection is pending whole-match/advancing-frame process-CPU qualification.
Observed catalog maxima choose workloads, not storage bounds. This table records
why each value is directly narrowable, remains wide or needs more evidence.
Current release source/binary manifests and measured layouts are indexed in
artifacts/state-performance/layout-screen/reviewer-layout-report.md. Earlier
277510-based measurements are preserved as superseded evidence, not current claims.

'''+table+'''

Measured unit saving is96bytes per authoritative state, snapshot view and live
unit on this x86_64 toolchain (360→264,384→288,440→344). Baseline/units-only
buildings remain352/408/1960; compact alternatives are336/392/1944, except the
explicit padding control352/408/1960. Padding control is experimental evidence,
not a proposed long-term design. See the reviewer layout report for all offsets.

Stock/demand remain all15 full-width slots; no promotion block/sidecar or new
material bound exists. Team inventory remains wide. Preserve stream widths and
field/checksum order, accepted values, enum gaps and sentinels. Current save158,
minimum58 and simulation revision53 belong to incoming master. This representation
work does not justify a new simulation version or dropping old save behavior.

Four current-base test failures reproduce without compaction; final candidate
coverage must distinguish them from introduced failures. Full paired whole-match
and frame evidence, independent confirmation, final selection, renderer/replay
continuation, platform omissions and reviewer-accessible publication remain to be
filled before merge. A microbenchmark slowdown alone does not reject a candidate;
user acceptance concerns total CPU and data size, with uncertainty reported honestly.
'''
old.write_text(new)
(p/'field-decision-inventory.md').write_text(new)
inputs=['screen/comparison.json','profile-summary.json','layout-smoke/results.json','binaries.json','baseline-four-results.json','protocol.json']+[label+'-offsets.txt' for label in labels]
(p/'review-report-input-hashes.json').write_text(json.dumps({name:hashlib.sha256((p/name).read_bytes()).hexdigest() for name in inputs},indent=2)+'\n')
print('Wrote evidence report and current field inventory; no build/timing inputs modified')
