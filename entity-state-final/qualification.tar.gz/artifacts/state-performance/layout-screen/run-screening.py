import subprocess,json,time,concurrent.futures
from pathlib import Path
repo=Path.cwd();r=repo/'artifacts/state-performance/layout-screen'
labels=list(json.loads((r/'binaries.json').read_text()))
def state(stage,status):
 (r/'qualification-stage.json').write_text(json.dumps({'stage':stage,'status':status,'time_ns':time.time_ns()})+'\n')
def profile(task):
 tool,label=task
 cmd=['python3',str(r/'profiles.py'),'--tool',tool,'--label',label]
 with (r/(tool+'-'+label+'-driver.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('Profile complete',tool,label,flush=True)
state('profiles','running')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for result in pool.map(profile,[(tool,label) for tool in ['callgrind','cachegrind'] for label in labels]):pass
state('pilot','running')
with (r/'pilot.log').open('w') as f:subprocess.run(['python3',str(r/'screen.py'),'--pilot'],stdout=f,stderr=subprocess.STDOUT,check=True)
state('native-screen','running')
with (r/'screen.log').open('w') as f:subprocess.run(['python3',str(r/'screen.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
state('native-screen','passed')
print('All native layout screening completed.',flush=True)
