import json,time,os,sys
from pathlib import Path
root=Path('artifacts/state-performance/layout-screen');stop=root/'stop-monitor';stop.unlink(missing_ok=True)
with (root/'host-samples.jsonl').open('w') as f:
 while not stop.exists():
  row={'time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),'load':os.getloadavg(),'cpu_stat':Path('/proc/stat').read_text().splitlines()[:33],'pressure':{x:Path('/proc/pressure/'+x).read_text() for x in ['cpu','memory','io']},'selected_cpu_frequency_khz':Path('/sys/devices/system/cpu/cpu6/cpufreq/scaling_cur_freq').read_text().strip()}
  f.write(json.dumps(row)+'\n');f.flush();time.sleep(5)
