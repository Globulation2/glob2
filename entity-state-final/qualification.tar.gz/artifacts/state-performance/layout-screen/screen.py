import argparse,os,json,subprocess,hashlib,random,statistics,math
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');p.add_argument('--repeat',type=int,default=10);a=p.parse_args()
r=Path(__file__).resolve().parent;out=r/('pilot' if a.pilot else 'screen');out.mkdir(exist_ok=True)
labels=['baseline'] if a.pilot else list(json.loads((r/'binaries.json').read_text()))
phases=['capture','inventory_read','inventory_update'];counts={}
if not a.pilot:counts=json.loads((r/'screen-counts.json').read_text())
report={'protocol':json.loads((r/'protocol.json').read_text()),'runs':[],'summaries':[]}
def ci(v):
 logs=[math.log(x) for x in v];rng=random.Random(871);samples=sorted(statistics.mean(rng.choices(logs,k=len(logs))) for _ in range(20000))
 return {'change_percent':100*math.expm1(statistics.mean(logs)),'lower_95_percent':100*math.expm1(samples[500]),'upper_95_percent':100*math.expm1(samples[19500])}
for rep in range(1 if a.pilot else a.repeat):
 order=labels[rep%len(labels):]+labels[:rep%len(labels)]
 if rep%2:order.reverse()
 for mode in ['private','shared']:
  for label in order:
   dest=out/f'{rep:02d}-{mode}-{label}';dest.mkdir(exist_ok=True)
   config=counts.get(mode,{'2':{'capture':4096,'inventory_read':10000,'inventory_update':10000,'owner':1,'consumer':1}})
   (dest/'counts.json').write_text(json.dumps(config)+'\n')
   env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_ENTITY_SCENARIO='2',GLOB2_ENTITY_SHARED='1' if mode=='shared' else '0',GLOB2_ENTITY_LEASES='8',GLOB2_ENTITY_BENCH_CONFIG=str(dest/'counts.json'),GLOB2_ENTITY_EVIDENCE_DIR=str(dest),GLOB2_USER_DATA_DIR=str(dest/'profile'))
   cmd=['taskset','-c','6',str(r/(label+'-engine-tests')),'--test-suite=WorldSnapshot','--test-case=paired entity storage workload*','--no-colors=true']
   with (dest/'run.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
   rows=[json.loads(s[13:]) for s in (dest/'run.log').read_text().splitlines() if s.startswith('ENTITY_BENCH ')];assert len(rows)==1
   row=rows[0];row.update(pair=rep,variant=label,command=cmd,canonical_sha256=hashlib.sha256((dest/'scenario-2.game').read_bytes()).hexdigest())
   if label=='baseline':
    row['record_bytes_copied']=None;row['sidecar_bytes_copied']=None
    row['derived_record_bytes_copied']=row['capture']['iterations']*(row['units']*row['unit_state']+row['buildings']*row['building_state'])
    row['entity_copy_accounting']='baseline lacks entity counters; derived authoritative count, sidecars unavailable'
   else:row['entity_copy_accounting']='instrumented'
   report['runs'].append(row)
   if a.pilot:
    c={'owner':1,'consumer':1}
    for phase in phases:
     key=phase if phase=='capture' else mode+'_'+phase
     c[phase]=max(row[key]['iterations'],math.ceil(row[key]['iterations']*1.5e9/max(1,row[key]['process_cpu_ns'])))
    c['inventory_update']+=c['inventory_update']%2;counts[mode]={'2':c}
   (out/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
  group=[x for x in report['runs'] if x['pair']==rep and x['inventory_mode']==mode];assert len({x['canonical_sha256'] for x in group})==1,'canonical divergence'
  print('Screen pair',rep+1,mode,{x['variant']:round(x['capture']['process_cpu_ns']/x['capture']['iterations']) for x in group},flush=True)
if a.pilot:(r/'screen-counts.json').write_text(json.dumps(counts,indent=2)+'\n')
else:
 for mode in ['private','shared']:
  for reference in ['baseline','units']:
   for label in [x for x in labels[1:] if x!=reference]:
    summary={'reference':reference,'variant':label,'inventory_mode':mode,'phases':{}}
    for phase in phases:
     key=phase if phase=='capture' else mode+'_'+phase;summary['phases'][phase]={}
     for metric in ['process_cpu_ns','wall_ns']:
      bs=[];cs=[]
      for rep in range(a.repeat):
       b=next(x for x in report['runs'] if x['pair']==rep and x['inventory_mode']==mode and x['variant']==reference);c=next(x for x in report['runs'] if x['pair']==rep and x['inventory_mode']==mode and x['variant']==label)
       bs.append(b[key][metric]/b[key]['iterations']/1e9);cs.append(c[key][metric]/c[key]['iterations']/1e9)
      summary['phases'][phase][metric]={'baseline_seconds_per_operation':statistics.mean(bs),'candidate_seconds_per_operation':statistics.mean(cs),**ci([c/b for b,c in zip(bs,cs)])}
    report['summaries'].append(summary)
 (out/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
