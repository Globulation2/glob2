from pathlib import Path
import argparse,subprocess,shutil,json,hashlib,re
p=argparse.ArgumentParser();p.add_argument('label');a=p.parse_args()
repo=Path.cwd();root=repo/'artifacts/state-performance/layout-screen/source';out=root.parent
base='b4c463a439953059c9ac058902cff8a652e87f02';head='5f3f6bd37048dc0adb90ad87db95669875ab850c'
changed=subprocess.check_output(['git','diff','--name-only',base,head],text=True).splitlines()
for name in changed:
 if not name.startswith(('src/','docs/','test/')):continue
 revision=base if a.label=='baseline' else head
 try:s=subprocess.check_output(['git','show',revision+':'+name],text=True)
 except subprocess.CalledProcessError:continue
 (root/name).parent.mkdir(parents=True,exist_ok=True);(root/name).write_text(s)
if a.label not in ['baseline','units']:
 candidate=repo/'artifacts/state-performance/layout-candidates'/('compact-near-bindings' if a.label=='compact-original' else a.label)
 for name in ['src/building/BuildingState.h','src/building/Building.h','src/building/Lifecycle.cpp']:
  shutil.copyfile(candidate/name,root/name)
  if a.label=='compact-original' and name=='src/building/Building.h':(root/name).write_text(subprocess.check_output(['git','show',base+':'+name],text=True))
else:
 for name in ['src/building/BuildingState.h','src/building/Building.h','src/building/Lifecycle.cpp']:
  (root/name).write_text(subprocess.check_output(['git','show',base+':'+name],text=True))
# Baseline has no entity counters. Adapters only affect reported copy counts.
s=(repo/'src/engine/sim/snapshot/WorldSnapshotTest.cpp').read_text();h=s[s.index('#include <fstream>'):]
adapter='''template<class S> Uint64 records(const S& s) {if constexpr(requires{s.entityBytesCopied;})return s.entityBytesCopied;else return 0;}
template<class S> Uint64 sidecarCounter(const S& s) {if constexpr(requires{s.entitySidecarBytesCopied;})return s.entitySidecarBytesCopied;else return 0;}
'''
h=h.replace('volatile Sint64 sink=0;','volatile Sint64 sink=0;'+adapter)
h=h.replace('storage.entityBytesCopied','records(storage)').replace('storage.entitySidecarBytesCopied','sidecarCounter(storage)')
tests=subprocess.check_output(['git','show',base+':src/engine/sim/snapshot/WorldSnapshotTest.cpp'],text=True)
if a.label!='baseline':tests=re.sub(r'canLearn\[([^\]\n]+)\]',r'canLearn(\1)',tests)
(root/'src/engine/sim/snapshot/WorldSnapshotTest.cpp').write_text(tests+'\n'+h)
# Evidence-only shared renderer harness. One interval includes AI, simulation,
# capture, preparation and all rendering workers; static mode stays available.
p=root/'src/render/SoftwareRenderBenchmark.cpp';s=subprocess.check_output(['git','show',base+':src/render/SoftwareRenderBenchmark.cpp'],text=True)
helper=(out/'advancing-renderer-helper.txt').read_text()
s=s.replace('static void interactiveBenchmark()',helper+'\nstatic void interactiveBenchmark()',1)
needle='        if (const char *mode = std::getenv("PROFILE_MODE");\n            mode && std::string(mode) == "interactive")'
s=s.replace(needle,'        if (const char *mode = std::getenv("PROFILE_MODE"); mode && std::string(mode) == "advancing") {\n            advancingBenchmark(); delete globalContainer; globalContainer=nullptr; return 0;\n        }\n'+needle)
p.write_text(s)
p=root/'src/app/cli/Headless.cpp';s=subprocess.check_output(['git','show',base+':src/app/cli/Headless.cpp'],text=True)
s=s.replace('uint64_t setupCpu=0,runCpu=0,measureStart=0;','uint64_t setupCpu=0,runCpu=0,measureStart=0,runWall=0;\n        std::chrono::steady_clock::time_point measureWall;')
s=s.replace('if(benchmarkWarmup==0) measureStart=processCpuNs();','if(benchmarkWarmup==0) {engine.gui.game.drainAI();engine.gui.game.drainTeamStats();measureStart=processCpuNs();measureWall=std::chrono::steady_clock::now();}')
s=s.replace('if(!measureStart && engine.gui.game.stepCounter>=start) measureStart=processCpuNs();','if(!measureStart && engine.gui.game.stepCounter>=start) {engine.gui.game.drainAI();engine.gui.game.drainTeamStats();measureStart=processCpuNs();measureWall=std::chrono::steady_clock::now();}')
s=s.replace('runCpu=processCpuNs()-measureStart;','engine.gui.game.drainAI();engine.gui.game.drainTeamStats();\n            runCpu=processCpuNs()-measureStart;\n            runWall=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-measureWall).count();')
s=s.replace('<< ",\\\"benchmark_save_cpu_ns\\\":" << saveCpu','<< ",\\\"benchmark_run_wall_ns\\\":" << runWall\n            << ",\\\"benchmark_save_cpu_ns\\\":" << saveCpu')
p.write_text(s)
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'src').rglob('*') if p.suffix in ['.h','.cpp']}
(out/(a.label+'-source.json')).write_text(json.dumps({'label':a.label,'base':base,'head':head,'sources':manifest},indent=2)+'\n')
print('Prepared',a.label,flush=True)
