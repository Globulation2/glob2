from pathlib import Path
import json,os,subprocess,time
root=Path.cwd();work=root/'artifacts/state-performance/layout-screen';binary=work/'baseline-engine-tests'
for _ in range(3600):
 if binary.exists():break
 time.sleep(1)
else:raise SystemExit('baseline binary unavailable after one hour')
config=work/'smoke-inventory-counts.json'
config.write_text(json.dumps({'2':{'capture':2,'inventory_read':2,'inventory_update':2,'owner':1,'consumer':2}})+'\n')
rows=[]
for shared in [False,True]:
 mode='shared' if shared else 'private';out=work/('baseline-'+mode+'-smoke');out.mkdir(exist_ok=True)
 env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_ENTITY_SCENARIO='2',GLOB2_ENTITY_LEASES='8',GLOB2_ENTITY_SHARED='1' if shared else '0',GLOB2_ENTITY_BENCH_CONFIG=str(config),GLOB2_ENTITY_EVIDENCE_DIR=str(out))
 cmd=['taskset','-c','0',str(binary),'--test-suite=WorldSnapshot','--test-case=paired entity storage workload*','--no-colors=true']
 with (out/'smoke.log').open('w') as log:r=subprocess.run(cmd,cwd=work/'source',env=env,stdout=log,stderr=subprocess.STDOUT)
 data=[json.loads(x[len('ENTITY_BENCH '):]) for x in (out/'smoke.log').read_text().splitlines() if x.startswith('ENTITY_BENCH ')]
 rows.append({'mode':mode,'exit_code':r.returncode,'command':cmd,'records':data})
 (work/'baseline-inventory-smoke-results.json').write_text(json.dumps({'purpose':'Functional smoke only; no timing claims','results':rows},indent=2)+'\n')
 print(mode,r.returncode,len(data),flush=True)
