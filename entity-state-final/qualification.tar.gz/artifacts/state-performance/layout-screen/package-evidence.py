from pathlib import Path
import tarfile,subprocess,json,hashlib
repo=Path.cwd();r=repo/'artifacts/state-performance/layout-screen';dest=r/'publication';dest.mkdir(exist_ok=True)
files=[]
for p in r.iterdir():
 if p.is_file() and p.suffix in {'.json','.jsonl','.py','.md','.txt','.log'}:files.append(p)
for folder in ['whole-comparison','screen','callgrind','cachegrind','baseline-regression-artifacts','layout-smoke']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and 'profile' not in p.parts:files.append(p)
for folder in ['layout-candidates','colony-fixture','echo-fixture']:
 for p in (r.parent/folder).rglob('*'):
  if p.is_file() and p.suffix in {'.py','.json','.md','.cpp','.h','.txt','.gz','.log'}:files.append(p)
for name in ['integration-tests.xml','integration-inventory.json','integration-tests.log','verification-refresh.xml','verification-refresh-inventory.json','verification-refresh.log','final-build.log','final-tests.xml','final-inventory.json','final-tests.log']:
 p=r.parent/name
 if p.exists():files.append(p)
(repo/'docs/.work/final-source.patch').write_bytes(subprocess.check_output(['git','diff','origin/master','HEAD']))
files.append(repo/'docs/.work/final-source.patch')
seen={};duplicates={}
with tarfile.open(dest/'qualification.tar.gz','w:gz',compresslevel=6) as t:
 for p in sorted(set(files)):
  key=hashlib.sha256(p.read_bytes()).hexdigest();name=str(p.relative_to(repo))
  if key in seen:duplicates[name]={'same_as':seen[key],'sha256':key};continue
  seen[key]=name;t.add(p,arcname=name,recursive=False)
 mapping=dest/'deduplicated-files.json';mapping.write_text(json.dumps(duplicates,indent=2)+'\n');t.add(mapping,arcname='deduplicated-files.json',recursive=False)
archive=dest/'qualification.tar.gz';(dest/'manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'tested_source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'integration_base':subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip(),'performance_base':'b4c463a439953059c9ac058902cff8a652e87f02','rendering':'skipped at user request','repeat_comparison':'not rerun on newer master at user request','files':len(set(files))},indent=2)+'\n');print(archive.stat().st_size)
