import subprocess,json,time
from pathlib import Path
r=Path(__file__).resolve().parent
for attempt in range(360):
 p=r/'whole-comparison/comparison.json'
 if p.exists():
  try:d=json.loads(p.read_text())
  except json.JSONDecodeError:
   time.sleep(1);continue
  if len(d.get('summaries',[]))==18:break
 time.sleep(5)
else:raise SystemExit('Whole-match comparison did not complete')
cmd=['xvfb-run','-a','-s','-screen 0 1280x800x24','python3',str(r/'frames.py'),'--label','baseline','--label','units','--label','compact-original','--label','compact-near-bindings','--output',str(r/'frame-comparison')]
(r/'frame-stage.json').write_text(json.dumps({'status':'running','command':cmd,'started_ns':time.time_ns()})+'\n')
with (r/'frame-comparison.log').open('w') as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(r/'frame-stage.json').write_text(json.dumps({'status':'passed' if result.returncode==0 else 'failed','command':cmd,'ended_ns':time.time_ns(),'returncode':result.returncode})+'\n')
raise SystemExit(result.returncode)
