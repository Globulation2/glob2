from pathlib import Path
import os,subprocess,time,json,hashlib
root=Path.cwd();work=root/'artifacts/state-performance/layout-screen';binary=work/'baseline-engine-tests'
for _ in range(3600):
 if binary.exists():break
 time.sleep(1)
else:raise SystemExit('baseline binary unavailable after one hour')
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_TEST_ARTIFACTS_ROOT=str(work/'baseline-regression-artifacts'))
cases=[('JavaScriptSimulation','JavaScript original fixture executes, resumes and replays 256 ticks'),('JavaScriptSimulation','JavaScript economic planners and map survey execute, resume and replay 256 ticks'),('LegacyRoundTripSave','a format-143 save with live round-trip fields plays on greedily [golden][save-format]'),('UnitCatalog','both header forms retain embedded unit properties and experiment gates')]
rows=[]
for i,(suite,case) in enumerate(cases):
 pattern=case.split(',')[0]+'*'
 cmd=['taskset','-c','0',str(binary),'--test-suite='+suite,'--test-case='+pattern,'--no-colors=true']
 with (work/f'baseline-failure-{i}.log').open('w') as out:r=subprocess.run(cmd,cwd=work/'source',env=env,stdout=out,stderr=subprocess.STDOUT)
 rows.append({'suite':suite,'case':case,'command':cmd,'exit_code':r.returncode,'log':str(work/f'baseline-failure-{i}.log')})
 (work/'baseline-four-results.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'base':'b4c463a439953059c9ac058902cff8a652e87f02','results':rows},indent=2)+'\n')
 print(suite,case,r.returncode,flush=True)
