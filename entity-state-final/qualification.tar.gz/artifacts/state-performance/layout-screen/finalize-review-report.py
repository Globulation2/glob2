from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent
whole=json.loads((p/'whole-comparison/comparison.json').read_text())
report=(p/'reviewer-layout-report.md').read_text()
report=report.replace('# Reviewer evidence inventory and layout report — selection pending','# Reviewer evidence inventory and final layout report')
report=report.replace('Whole-match and advancing-frame qualification are pending: **no final layout choice**.','Selected: **compact-original** — audited compact BuildingStateRecord/Lifecycle\nconversions, with baseline Building.h ordering. Whole-match qualification uses the\ncompleted240-run matrix. Rendering and further comparisons are skipped at the\nuser\'s explicit direction; no claim of final rendering performance is made.')
report=report.replace('Current release source/binary manifests and measured layouts are indexed in','Current release source/binary manifests and measured layouts are indexed in')
report=report.replace('Final\nchoice requires ordinary and colony whole matches plus advancing frames, one/four\nworkers, and independent confirmation where selected.','Final choice uses the completed ordinary, colony and shared-runtime whole-match\nrows with one/four workers. The user waived rendering and further comparisons.\nIndependent confirmation and final-head performance remain unavailable, not assumed.')
start=report.index('## Evidence index and final report placeholders')
end=report.index('## Review cleanup still needed',start)
report=report[:start]+'''## Completed whole-match process CPU and wall results

240 runs: four variants × three fixtures × one/four workers × ten rotated pairs.
Each run warms1024ticks then measures16384ticks. CPU includes all process threads.
The table below reports arithmetic mean absolute costs in microseconds/tick and
paired geometric-mean percentage changes with pointwise two-sided95% bootstrap
intervals. The absolute mean ratio and paired log estimate need not be identical.

| Fixture | Workers | Baseline CPU µs/tick | Selected CPU µs/tick | CPU change [95%] | Baseline wall µs/tick | Selected wall µs/tick | Wall change [95%] |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''+''.join('| '+r['fixture']+' | '+str(r['workers'])+' | '+f"{r['metrics']['cpu_seconds_per_tick']['baseline']*1e6:.3f} | {r['metrics']['cpu_seconds_per_tick']['candidate']*1e6:.3f} | {r['metrics']['cpu_seconds_per_tick']['change_percent']:+.2f} [{r['metrics']['cpu_seconds_per_tick']['lower_95_percent']:+.2f}, {r['metrics']['cpu_seconds_per_tick']['upper_95_percent']:+.2f}] | {r['metrics']['wall_seconds_per_tick']['baseline']*1e6:.3f} | {r['metrics']['wall_seconds_per_tick']['candidate']*1e6:.3f} | {r['metrics']['wall_seconds_per_tick']['change_percent']:+.2f} [{r['metrics']['wall_seconds_per_tick']['lower_95_percent']:+.2f}, {r['metrics']['wall_seconds_per_tick']['upper_95_percent']:+.2f}] |\n" for r in whole['summaries'] if r['variant']=='compact-original')+'''
Selected CPU estimates span−3.63% to+0.73%. Only shared-runtime/four-worker CPU
shows a negative interval excluding zero (−3.63%,95%−7.06…−0.63). Ordinary/one
worker's upper bound is+1.13%; other selected rows permit roughly+2.35…+4.90%
slowdown, exceeding the predeclared2% whole-process uncertainty bound. This matrix
therefore establishes storage reduction and reports mixed/inconclusive CPU effects;
it does **not** prove general speedup or universal absence of regression.

The nearby-bindings variant regresses ordinary/four-worker CPU by+3.79%
(95%+0.43…+8.03), despite favorable simulated cache counts. Compact-original's
corresponding estimate is−2.00% (95%−6.43…+2.35); it retains baseline live member
ordering and avoids the additional pointer/reservation reorder. Stock-first and
stock-offset-preserved remain exploratory screen layouts, not whole-match-qualified
shipping choices. The padded control offers no building byte saving and is omitted.

## Integrated head and limits

Final integrated source is5750ba72963a494e1f61873ca3663175cc7f203f, including current
master35b84d4ffd774742ada41d33c39ab1a50551f113. **Performance comparisons were built
against b4c463a439953059c9ac058902cff8a652e87f02**, using the published5f3f6bd-based
source manifests and binary hashes. The later incoming changes overlap worker/
statistics execution; timings have not been repeated on5750ba7296 at the user's
request. Do not label earlier numbers as a final-head benchmark. Final integration
functional checks belong to the parent's PR validation record.

Rendering performance/screenshots on the final head are skipped at user request.
No new native comparisons, independent confirmation or platform runs were started
for this finalization. The240 completed whole rows and prior screening data remain
available without suppressing unfavorable candidates or uncertainty.

## Evidence index

- protocol.json: predeclared paired design, practical bounds, worker/affinity rules.
- binaries.json and seven *-source.json files: executable/source provenance.
- seven *-offsets.txt files: compiled state/live/view size and state offsets.
- screen/comparison.json plus run logs/canonical saves:140 native screen rows.
- whole-comparison/comparison.json:240 whole runs, exact commands, absolute CPU/wall,
  per-pair executable/input hashes, saved outcomes and confidence summaries.
- profile-summary.json, Callgrind/Cachegrind logs and dumps: attribution diagnostics.
- layout-smoke/results.json: standalone allocation/snapshot/canonical smoke.
- baseline-four-results.json and baseline-failure-0…3.log: reproduced baseline failures.
- ../layout-candidates/: unselected definitions and experiment rationale.
- field-decision-inventory.md: current field-level width/compatibility decisions.
- review-report-input-hashes.json: exact report input snapshot.

Publish these evidence paths on an immutable evidence commit; local paths alone
are insufficient reviewer access. Record final integration tests separately with
5750ba7296 and master35b84d4ff; preserve the performance-base distinction.

'''+report[end:]
report=report[:report.index('## Review cleanup still needed')]+'''## Final review cleanup

Selected production consists of compact state/validated loads and baseline live
building ordering. Architecture/persistence guides should describe that exact
choice. Keep unselected layouts, padding, source generators and temporary baseline
adapters only on the evidence branch. Retain useful logical/snapshot tests and
ordinary width-safe editor APIs in production. Before merge, record final-head
functional results, existing baseline failures, platform omissions and immutable
review evidence links. Rendering and new comparisons are explicitly waived rather
than silently presented as passed.
'''
(p/'reviewer-layout-report.md').write_text(report)
for path in [p/'field-decision-inventory.md',Path('docs/.work/entity-state-decisions.md')]:
 s=path.read_text().replace('The current integrated shipping proposal has unit compaction; final building layout\nselection is pending whole-match/advancing-frame process-CPU qualification.','Selected shipping layout: compact-original, with unit compaction and audited narrow\nbuilding state/loads, retaining baseline Building.h live binding order. Selection\nuses the completed240 whole-match runs; rendering/further comparisons are skipped\nat the user\'s direction. Performance base b4 differs from final integrated5750ba7296\nincluding master35b84d4ff; no final-head performance rerun is claimed.')
 s=s.replace('Candidate direct narrowing, Uint8; final selection pending','Direct, Uint8 backing').replace('Candidate direct narrowing, Uint16; final selection pending','Direct, Uint16')
 # Exact replacement handles separate enum row with backing wording.
 s=s.replace('Candidate direct narrowing, Uint8; final selection pending','Direct, Uint8')
 s=s.replace('Baseline/units-only\nbuildings remain352/408/1960; compact alternatives are336/392/1944, except the','Baseline/units-only\nbuildings remain352/408/1960; selected compact-original is336/392/1944, except the')
 s=s.replace('Full paired whole-match\nand frame evidence, independent confirmation, final selection, renderer/replay\ncontinuation, platform omissions and reviewer-accessible publication remain to be\nfilled before merge.','Completed whole-match estimates range−3.63%…+0.73%, with confidence limits\npermitting roughly+2.35%…+4.90% slowdown in some rows; no universal no-regression\nclaim is justified. Final-head functional/replay validation and evidence publication\nare recorded separately. Rendering and further comparisons are waived; independent\nconfirmation and platform execution remain unavailable.')
 s+='\nSelected inline saving:96×unit count+16×building count for authoritative copy\nbytes and populated record/view payload. Live object sizeof reductions match those\nvalues; allocator/capacity/lease effects must use the measured retained-memory rows.\nNo building padding control or pointer/reservation reorder ships.\n'
 path.write_text(s)
(p/'pr-results-paragraph.md').write_text('''Selected the original compact building record with baseline live binding order. Compiled x86_64 sizes fall by96bytes per unit state/view/live object and16bytes per building state/view/live object. Existing serialized widths, accepted values, save floor58 and checksum order remain intact; inventories keep all15 wide slots. The completed240-run paired whole-match matrix reports process-CPU estimates from−3.63% to+0.73%, with several confidence intervals still permitting2–5% slowdowns: this is a measured storage reduction, not a general speedup or proof of universal no-regression. Nearby bindings showed an ordinary/four-worker CPU regression (+3.79%,95%+0.43…+8.03) and were omitted. Four focused failures reproduce on baseline and remain explicitly documented. Performance evidence uses base b4c463a43; final integration5750ba7296 includes master35b84d4ff and was not rebenchmarked. Rendering and further comparisons were skipped at the user's direction. Link the immutable source/binary manifests, raw240runs, layout/profiling data and final-head functional validation when publishing this paragraph.\n''')
hashes=json.loads((p/'review-report-input-hashes.json').read_text());hashes['whole-comparison/comparison.json']=hashlib.sha256((p/'whole-comparison/comparison.json').read_bytes()).hexdigest();(p/'review-report-input-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
print('Finalized report, decision inventory and PR paragraph using saved data only')
