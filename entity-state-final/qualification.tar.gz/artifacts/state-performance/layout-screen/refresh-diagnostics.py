import subprocess,os,json,hashlib,shutil,time
from pathlib import Path
repo=Path.cwd();r=repo/'artifacts/state-performance/layout-screen';source=r/'source';manifest=json.loads((r/'binaries.json').read_text())
env=dict(os.environ,GLOB2_SDL3_PREFIX=str(repo/'artifacts/state-compaction/native-sdl'))
for label in manifest:
 (r/'refresh-stage.json').write_text(json.dumps({'label':label,'status':'building','time_ns':time.time_ns()})+'\n')
 subprocess.run(['python3',str(r/'prepare-source.py'),label],check=True)
 cmd=['python3','tools/dev_build.py','dev_fast=0','release=1','-j28','engine-tests','software-render-benchmark']
 with (r/(label+'-diagnostics-refresh.log')).open('w') as f:subprocess.run(cmd,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 for suffix,path in [('engine-tests','test/glob2-engine-tests'),('renderer','test/SoftwareRenderBenchmark')]:
  dest=r/(label+'-'+suffix);shutil.copy2(source/'build/linux/client/release/dev-linker-auto'/path,dest);manifest[label]['binaries'][suffix]={'path':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}
 manifest[label]['diagnostics_refresh_command']=cmd
 (r/'binaries.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Refreshed '+label,flush=True)
(r/'refresh-stage.json').write_text(json.dumps({'status':'passed','time_ns':time.time_ns()})+'\n')
