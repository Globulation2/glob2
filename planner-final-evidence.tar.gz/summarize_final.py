import json,math,statistics,random,hashlib,re
from pathlib import Path
p=Path('artifacts/hiring-study/planner-final');out=p/'final-pairs';rows=[json.loads(x) for x in (out/'measurements.jsonl').read_text().splitlines()];rng=random.Random(20261013)
def paired(values):
 ratios=[b/a for a,b in values];boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000));n=len(boot)
 return {'samples':len(values),'baseline_median':statistics.median(a for a,b in values),'after_median':statistics.median(b for a,b in values),'paired_ratio_median':statistics.median(ratios),'bootstrap_95_ci_ratio':[boot[int(n*.025)],boot[int(n*.975)]],'paired_ratios':ratios}
result={'protocol':json.loads((out/'metadata.json').read_text()),'planner':[],'engine':[],'callgrind':[],'verification':{},'limitations':['Performance deltas compare current PR production planner (2cfb2cdbe) against optimized planner dda12cd3b on one macOS arm64 host. Benchmark-only helper a9f16cde0 is identical before/after.','Planner refresh measurements exclude snapshot capture, serial admission/subscription/swaps and live economy. No live consumer is implemented.','Whole-engine study still retains original hiring. Completed-boundary material demand can disappear before capture. Do not extrapolate isolated planner speedup to live whole-match gains.','Headless run_ns includes 256 warmup ticks plus 256 measured ticks; CPU and tick percentiles describe only the measured window. No saves/checksum exports/diagnostic reports during timing.','Process wall/setup costs are not engine tick costs. Raw warmups, all outliers and complete commands retained.','Callgrind instruction counts are Linux arm64/GCC11.4 diagnostics, not native seconds. First complete rank per team excluded as warmup. Inclusive annotation has recursive/context artifacts and is not used for attribution; self counts and raw totals are retained.','macOS arm64 correctness only; no new Linux x86-64/Windows/browser matching traces, TSAN or gameplay footage. Linux arm64 used for profiling, not cross-platform simulation verification.','Host activity is uncontrolled. Profiling container stopped and builds/tests completed before timings; alternating order and paired confidence intervals reduce but do not eliminate host noise.']}
for execution in ['owner','pool']:
 for stride in [1,4,8]:
  r=[row for row in rows if row['kind']=='planner' and row['execution']==execution and row['repetition']>=0];pairs={}
  for row in r:
   v=next(x for x in row['result'] if x['availability_stride']==stride);assert v['private_overlay_hires']==v['reference_hires'];pairs.setdefault(row['repetition'],{})[row['variant']]=v
  if not all(set(v)=={'baseline','after'} for v in pairs.values()):continue
  records=list(pairs.values());result['planner'].append({'execution':execution,'availability_stride':stride,'cpu_ns_per_refresh':paired([(v['baseline']['cpu_ns']/v['baseline']['iterations'],v['after']['cpu_ns']/v['after']['iterations']) for v in records]),'elapsed_ns_per_refresh':paired([(v['baseline']['elapsed_ns']/v['baseline']['iterations'],v['after']['elapsed_ns']/v['after']['iterations']) for v in records]),'useful_private_offers':1.0,'retained_bytes_per_refresh':records[0]['after']['retained_bytes_sum']/records[0]['after']['iterations']})
for name in sorted(set(r['workload'] for r in rows if r['kind']=='engine')):
 for enabled in [False,True]:
  selected=[r for r in rows if r['kind']=='engine' and r['workload']==name and r['enabled']==enabled and r['repetition']>=0];pairs={}
  for row in selected:pairs.setdefault(row['repetition'],{})[row['variant']]=row['result']
  if not pairs or not all(set(v)=={'baseline','after'} for v in pairs.values()):continue
  values=list(pairs.values());assert all(v['baseline']['finalChecksum']==v['after']['finalChecksum'] for v in values)
  result['engine'].append({'workload':name,'cached_pool_enabled':enabled,**{metric:paired([(v['baseline'][metric],v['after'][metric]) for v in values]) for metric in ['benchmark_run_cpu_ns','run_ns','tick_p50_ns','tick_p95_ns']}})
for stride in [1,4,8]:
 ir={}
 for label in ['baseline','first-stage','after']:
  path=Path(f'artifacts/hiring-study/callgrind/final-planner/{label}-stride-{stride}/callgrind.out');ir[label]=int(re.search(r'^summary: (\d+)',path.read_text(),re.M)[1])
 result['callgrind'].append({'availability_stride':stride,'warm_rank_instruction_counts':ir,'reduction':1-ir['after']/ir['baseline']})
result['verification']={'focused_cases':156,'ordinary_runs':json.loads((p/'verification/verification.json').read_text()),'nonempty_controlled_matches_preoptimization':json.loads((p/'controlled-verification/matches-preoptimization.json').read_text())}
(p/'findings.json').write_text(json.dumps(result,indent=2))
for r in result['planner']:
 print(r['execution'],r['availability_stride'],'cpu',round(r['cpu_ns_per_refresh']['baseline_median']/1000,1),round(r['cpu_ns_per_refresh']['after_median']/1000,1),'elapsed',round(r['elapsed_ns_per_refresh']['baseline_median']/1000,1),round(r['elapsed_ns_per_refresh']['after_median']/1000,1),'ratio',r['elapsed_ns_per_refresh']['paired_ratio_median'],r['elapsed_ns_per_refresh']['bootstrap_95_ci_ratio'])
for r in result['engine']:
 print(r['workload'],r['cached_pool_enabled'],'elapsed',round(r['run_ns']['paired_ratio_median'],4),'cpu',round(r['benchmark_run_cpu_ns']['paired_ratio_median'],4),'p95',round(r['tick_p95_ns']['paired_ratio_median'],4))
