import json,subprocess,os,time,hashlib,platform
from pathlib import Path
root=Path.cwd();p=root/'artifacts/hiring-study/planner-final';out=p/'final-pairs';out.mkdir(exist_ok=False)
metadata={'host':platform.platform(),'machine':platform.machine(),'baseline_production_revision':'2cfb2cdbed2b25fda0e7efd091075b4df6c060f2','baseline_benchmark_revision':'a9f16cde0','after_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD'])).hexdigest(),'executables':{name:hashlib.sha256((p/name).read_bytes()).hexdigest() for name in ['baseline-benchmark','after-benchmark','baseline-glob2','after-glob2']},'protocol':'one warmup process per executable/control; ten paired repetitions with alternating executable order; no builds/profiling/correctness runs concurrently; preserve all raw samples'}
(out/'metadata.json').write_text(json.dumps(metadata,indent=2));rows=[]
with (out/'measurements.jsonl').open('w') as log:
 for rep in range(-1,10):
  for execution in ['owner','pool']:
   for variant in (['baseline','after'] if rep%2==0 else ['after','baseline']):
    dest=out/f'planner-{execution}-{variant}-r{rep}';env=dict(os.environ,GLOB2_HIRING_BENCH_EXECUTION=execution)
    cmd=[str(p/(variant+'-benchmark')),'--prepare','planner-benchmark',str(dest)]
    start=time.monotonic()
    with (out/(dest.name+'.log')).open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
    row={'kind':'planner','variant':variant,'execution':execution,'repetition':rep,'command':cmd,'process_wall_seconds':time.monotonic()-start,'result':json.loads((dest/'opportunities.json').read_text())['rows']};rows.append(row);log.write(json.dumps(row)+'\n');log.flush()
   print('planner',execution,rep,flush=True)
 # Whole-engine controls use the same saved states, measured window and four
 # participants. This study still leaves original hiring authoritative.
 workloads=json.loads((root/'artifacts/hiring-study/workloads.json').read_text())
 for rep in range(-1,10):
  for workload in workloads:
   for enabled in [False,True]:
    for variant in (['baseline','after'] if rep%2==0 else ['after','baseline']):
     dest=out/f"engine-{workload['name']}-{'pool' if enabled else 'disabled'}-{variant}-r{rep}";dest.mkdir()
     cmd=[str(p/(variant+'-glob2')),'game','run','--load-game',workload['save'],'--ticks',str(workload['ticks']),'--benchmark-warmup','256','--compute-threads','4','--gpu','off','--output-dir',str(dest)]
     if enabled:cmd+=['--hiring-schedule','4:4:128:split','--hiring-execution','pool','--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds']
     with (dest/'engine.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
     r=json.loads((dest/'result.json').read_text());row={'kind':'engine','workload':workload['name'],'variant':variant,'enabled':enabled,'repetition':rep,'command':cmd,'result':{k:r[k] for k in ['benchmark_run_cpu_ns','benchmark_measured_ticks','run_ns','tick_p50_ns','tick_p95_ns','tick_p99_ns','finalChecksum']}};log.write(json.dumps(row)+'\n');log.flush()
    print('engine',workload['name'],enabled,rep,flush=True)
