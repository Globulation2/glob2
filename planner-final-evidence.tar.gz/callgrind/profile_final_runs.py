from pathlib import Path
import subprocess,os,json,time,hashlib
base=Path('/evidence/final-planner');binary=base/(os.environ['PROFILE_LABEL']+'-profile-harness');rows=[]
for stride in [1,4,8]:
 dest=base/(os.environ['PROFILE_LABEL']+'-stride-'+str(stride));dest.mkdir(exist_ok=True)
 env=dict(os.environ,LD_LIBRARY_PATH='/opt/glob2-sdl/lib',GLOB2_CALLGRIND_SCOPE='planner',HIRING_PROFILE_MODE='8',HIRING_PROFILE_STRIDE=str(stride))
 cmd=['valgrind','--tool=callgrind','--instr-atstart=no','--collect-atstart=no','--separate-callers=2','--callgrind-out-file='+str(dest/'callgrind.out'),str(binary),'--prepare','opportunities',str(dest/'harness-output')]
 start=time.monotonic()
 with (dest/'stdout.log').open('w') as out,(dest/'stderr.log').open('w') as err:r=subprocess.run(cmd,env=env,stdout=out,stderr=err)
 rows.append(dict(stride=stride,command=cmd,environment={k:env[k] for k in ['LD_LIBRARY_PATH','GLOB2_CALLGRIND_SCOPE','HIRING_PROFILE_MODE','HIRING_PROFILE_STRIDE']},exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()));assert r.returncode==0
 for kind in ['self','inclusive']:
  with (dest/(kind+'.txt')).open('w') as out:subprocess.run(['callgrind_annotate','--auto=no','--inclusive='+('yes' if kind=='inclusive' else 'no'),'--threshold=100',str(dest/'callgrind.out')],stdout=out,check=True)
 print(stride,flush=True)
(base/(os.environ['PROFILE_LABEL']+'-commands.json')).write_text(json.dumps(rows,indent=2))
