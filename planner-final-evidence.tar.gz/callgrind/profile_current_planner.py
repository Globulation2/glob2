from pathlib import Path
import subprocess,shutil
root=Path('/work');out=Path('/evidence/final-planner');out.mkdir(exist_ok=True)
binpath=root/'build/linux/client/release/retain-symbols/dev-linker-auto/test/HiringStudyHarness'
shutil.copy2(binpath,out/'baseline-native-harness')
p=root/'src/building/HiringPlanner.cpp';s=p.read_text();s='#include "/evidence/CallgrindRegion.h"\n'+s
start=s.index('Output Cache::rank(');marker=s.index('    if(capacity<1 || capacity>128)',start)
s=s[:marker]+'    static unsigned profileCalls=0;\n    HiringCallgrindRegion region(++profileCalls<=2?"warmup":"planner");\n'+s[marker:];p.write_text(s)
p=root/'test/HiringStudyHarness.cpp';s=p.read_text();s=s.replace('        for(unsigned stride:{1u,4u,8u}) {','        for(unsigned stride:{1u,4u,8u}) {\n            if(std::getenv("HIRING_PROFILE_STRIDE") && stride!=unsigned(std::atoi(std::getenv("HIRING_PROFILE_STRIDE"))))continue;')
s=s.replace('for(int repetition=-1;repetition<10;++repetition)','for(int repetition=0;repetition<1;++repetition)').replace('                HiringPlanner::Options options;options.pruneFetch=mode<8;','                if(mode!=std::atoi(std::getenv("HIRING_PROFILE_MODE")))continue;\n                HiringPlanner::Options options;options.pruneFetch=mode<8;').replace('iteration<20','iteration<4')
s=s.replace('            // Controlled scheduling model:', '            std::ofstream measured(directory/"profile-rows.json");measured<<rows.dump(2);return 0;\n            // Controlled scheduling model:')
p.write_text(s)
(out/'profile-only.patch').write_bytes(subprocess.check_output(['git','diff','--','src/building/HiringPlanner.cpp','test/HiringStudyHarness.cpp'],cwd=root))
