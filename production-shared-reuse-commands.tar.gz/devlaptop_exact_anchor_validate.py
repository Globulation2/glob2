from pathlib import Path
import subprocess,json,time,os,hashlib
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'exact-anchor';out.mkdir(exist_ok=True)
while not (data/'original-partial-cost-pilot/finished.json').exists():time.sleep(2)
assert json.loads((data/'original-partial-cost-pilot/finished.json').read_text())['status']=='complete'
state={'stage':'start','started':time.time()};env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2/build/sdl3/prefix';env['PYTHONPATH']='.'
def update(**kw):state.update(kw);(out/'status.json').write_text(json.dumps(state,indent=2))
def run(cmd,log):
 update(command=cmd)
 with (out/log).open('w') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('failed '+log)
try:
 assert json.loads((data/'available-routes/status.json').read_text())['stage']=='complete'
 run(['git','fetch','/home/bradley/hiring-exact-anchor.bundle','HEAD'],'fetch.log')
 run(['git','checkout','--detach','FETCH_HEAD'],'checkout.log');state['source']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 update(stage='build and focused validation')
 run(['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12','engine-tests'],'build-tests.log')
 run(['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12'],'build-client.log')
 run(['python3','test/run_tests.py','--build-dir','build/linux/client/release/retain-symbols/dev-linker-auto','--binary','engine','--filter','AICustomCatalog/*','--filter','RuntimeBuildingOrderSaveLoad/*','--filter','Hiring*/*','--filter','GradientPreparation/*','--filter','PathGradient/*','--filter','CellRules/*','--filter','AIOrderScheduler/*','--filter','AIPipeline/*','--filter','AIRecoveryCoverage/*','--filter','FetchHiringScore/*','--filter','UnitCustomization/hybrid*','--filter','UnitCustomization/pending lethal*','--filter','TeamStatsSave/retained format152*','--no-display','--timeout','600','-j4','--junit',str(out/'focused.xml'),'--artifacts',str(out/'focused')],'focused.log')
 update(stage='participant traces');state['traces']={}
 for n in (1,2,4,8):
  dest=out/f'trace-{n}'
  run([str(root/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2'),'game','run','--ticks','5120','--compute-threads',str(n),'--gpu','off','--output-dir',str(dest),'--load-game',str(data/'common-checkpoint/final.game.gz'),'--telemetry','checksums'],f'trace-{n}.log')
  state['traces'][n]=hashlib.sha256((dest/'world.checksums').read_bytes()).hexdigest()
  assert state['traces'][n]==state['traces'][1]
  assert state['traces'][n]=='e8c553217e444e6a6f92822a447d4fad93ef14985f62e77c18896084e3afe929'
 import shutil
 shutil.copy2(root/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2',data/'glob2-exact-anchor')
 update(stage='complete',finished=time.time())
except BaseException as e:update(stage='failed',error=str(e),finished=time.time());raise
