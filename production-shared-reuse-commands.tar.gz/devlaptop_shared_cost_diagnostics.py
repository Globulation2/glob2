from pathlib import Path
import subprocess,json,time,hashlib
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'shared-cost-diagnostics';out.mkdir(exist_ok=False)
state={'stage':'waiting for resource-first validation','started':time.time()}
def update(**kw):
 state.update(kw);(out/'status.json').write_text(json.dumps(state,indent=2))
def run(command,log):
 update(command=command)
 with (out/log).open('w') as stream:p=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,timeout=3600)
 if p.returncode:raise RuntimeError('Failed diagnostic retained: '+log)
try:
 update()
 while True:
  status=json.loads((data/'resource-first/status.json').read_text())
  if status['stage']=='complete':break
  if status['stage']=='failed':raise RuntimeError('Validation failed; diagnostics blocked')
  time.sleep(2)
 binaries={'original':data/'glob2-original-pristine','cached':data/'glob2-resource-first'}
 checkpoint=data/'gradient-count-audit/common-start/final.game.gz'
 metadata={'sources':{'original':'35b84d4ffd774742ada41d33c39ab1a50551f113','cached':status['source']},'input_sha256':hashlib.sha256(checkpoint.read_bytes()).hexdigest(),'binary_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},'purpose':'same-start diagnostic attribution; divergent policy trajectories, not a throughput benchmark'}
 assert metadata['binary_sha256']['original']=='750be092b10c2f9b137f6c36df8dde5960ba178b6f3d144778d7112441d7a7dd'
 (out/'metadata.json').write_text(json.dumps(metadata,indent=2))
 update(stage='phase and process diagnostics')
 for arm,binary in binaries.items():
  command=[str(binary),'game','run','--ticks','6144','--compute-threads','4','--gpu','off','--output-dir',str(out/(arm+'-stats')),'--load-game',str(checkpoint),'--compute-telemetry','waits']
  if arm=='cached':command+=['--telemetry','hiring-stats']
  run(['/usr/bin/time','-v','-o',str(out/(arm+'-time.txt'))]+command,arm+'-stats.log')
 update(stage='callgrind attribution')
 for arm,binary in binaries.items():
  run(['valgrind','--tool=callgrind','--callgrind-out-file='+str(out/(arm+'.callgrind')),str(binary),'game','run','--ticks','4352','--compute-threads','1','--gpu','off','--output-dir',str(out/(arm+'-callgrind')),'--load-game',str(checkpoint)],arm+'-callgrind.log')
  run(['callgrind_annotate','--inclusive=yes','--threshold=95',str(out/(arm+'.callgrind'))],arm+'-inclusive.txt')
 update(stage='complete',finished=time.time())
except BaseException as error:update(stage='failed',error=str(error),finished=time.time());raise
