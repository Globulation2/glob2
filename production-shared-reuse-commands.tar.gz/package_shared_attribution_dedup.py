from pathlib import Path
import tarfile,hashlib,json
root=Path('/home/bradley/glob2-hiring-profile-20261013/artifacts/hiring-profile')
names=['shared-planes','shared-planes-v2','shared-planes-v3','available-routes','borrow-routes','borrow-routes-v2','resource-first','exact-anchor','leading-anchor','compact-flags','original-shared-pilot','pristine-baseline-restoration','original-shared-verified-pilot','original-available-routes-pilot','original-borrow-routes-pilot','shared-cost-diagnostics','late-cost-diagnostics','full-window-attribution','anchor-cost-control','anchor-cost-control-v2','optimized-ai-pilot','optimized-ai-pilot-v2','optimized-trace-diagnostics','optimized-trace-diagnostics-v2','compact-flags-control','compact-flags-pilot']
archive=root/'shared-attribution-evidence.tar.gz';files={};seen={}
with tarfile.open(archive,'w:gz') as stream:
 for name in names:
  directory=root/name
  if not directory.exists():continue
  for path in sorted(directory.rglob('*')):
   if not path.is_file() or 'profile' in path.relative_to(directory).parts:continue
   if path.name.startswith('glob2') or path.suffix not in ['.json','.jsonl','.log','.xml','.txt','.callgrind','.checksums','.patch','.gz']:continue
   relative=str(path.relative_to(root));digest=hashlib.sha256(path.read_bytes()).hexdigest();files[relative]=digest
   if digest in seen:
    entry=tarfile.TarInfo(relative);entry.type=tarfile.LNKTYPE;entry.linkname=seen[digest];stream.addfile(entry)
   else:
    seen[digest]=relative;stream.add(path,arcname=relative)
 for name in ['river-713.map.gz','islands-713.map.gz','swamp-713.map.gz','maps.json']:
  path=root/name
  if path.exists():files[name]=hashlib.sha256(path.read_bytes()).hexdigest();stream.add(path,arcname=name)
(root/'shared-attribution-manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files,'identical_files_deduplicated_as_tar_hardlinks':True},indent=2))
print(json.dumps({'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
