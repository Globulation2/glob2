from pathlib import Path
import subprocess,json,time,hashlib,os,platform
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'optimized-ai-pilot';out.mkdir(exist_ok=False)
def status(**kw):(out/'status.json').write_text(json.dumps(kw,indent=2))
try:
 status(stage='waiting for exact AI cost control')
 while True:
  state=json.loads((data/'anchor-cost-control/status.json').read_text())
  if state['stage']=='complete':break
  if state['stage']=='failed':raise RuntimeError('AI optimization control failed; timing blocked')
  time.sleep(2)
 control=json.loads((data/'anchor-cost-control/metadata.json').read_text());binaries={'original':data/'glob2-original-leading-anchor','cached':data/'glob2-leading-anchor'}
 cases=[c for c in json.loads((data/'maps.json').read_text()) if c['name'] in ['river-713','islands-713','swamp-713']]
 meta={'control_provenance':control,'binary_sha256':{a:hashlib.sha256(b.read_bytes()).hexdigest() for a,b in binaries.items()},'host':platform.platform(),'protocol':{'participants':4,'ticks':16384,'benchmark_warmup':4096,'repetitions':3,'exports':'none','purpose':'three-map regression screen; identical AI optimization applied to both hiring policies'},'cases':cases}
 (out/'metadata.json').write_text(json.dumps(meta,indent=2));status(stage='quiet release regression screening')
 with (out/'samples.jsonl').open('w') as stream:
  for rep in range(-1,3):
   for wi,case in enumerate(cases[rep%3:]+cases[:rep%3]):
    assert hashlib.sha256(Path(case['map']).read_bytes()).hexdigest()==case['sha256']
    for arm in (['original','cached'] if (rep+wi)%2==0 else ['cached','original']):
     dest=out/f"{case['name']}-{arm}-{rep}";cmd=[str(binaries[arm]),'game','run','--ticks','16384','--benchmark-warmup','4096','--compute-threads','4','--gpu','off','--output-dir',str(dest),'--map-file',case['map'],'--game-seed',str(case['game_seed'])]+['--player','nicowar']*8
     before=subprocess.check_output(['ps','-eo','pid,pcpu,comm','--sort=-pcpu'],text=True);started=time.time();status(stage='quiet release regression screening',repetition=rep,case=case['name'],arm=arm,started=started)
     with dest.with_suffix('.log').open('w') as log:p=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=900)
     row={'repetition':rep,'case':case['name'],'arm':arm,'command':cmd,'returncode':p.returncode,'elapsed_s':time.time()-started,'host_before':before,'host_after':subprocess.check_output(['ps','-eo','pid,pcpu,comm','--sort=-pcpu'],text=True),'result':json.loads((dest/'result.json').read_text()) if (dest/'result.json').exists() else None}
     stream.write(json.dumps(row)+'\n');stream.flush()
     if p.returncode:raise RuntimeError('Failed pilot attempt retained')
 status(stage='complete',finished=time.time())
except BaseException as error:status(stage='failed',error=str(error),finished=time.time());raise
