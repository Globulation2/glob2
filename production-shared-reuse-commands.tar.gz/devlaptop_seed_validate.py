from pathlib import Path
import subprocess,json,time,os,hashlib
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'existing-seed-revision';out.mkdir(exist_ok=True)
while True:
 previous=json.loads((data/'owner-allocation-cleanup/status.json').read_text())
 if previous['stage']=='complete':break
 if previous['stage']=='failed':raise RuntimeError('Earlier validation failed; retain and diagnose')
 time.sleep(2)
state={'stage':'start','started':time.time()};env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2/build/sdl3/prefix';env['PYTHONPATH']='.'
def update(**kw):state.update(kw);(out/'status.json').write_text(json.dumps(state,indent=2))
def run(cmd,log):
 update(command=cmd)
 with (out/log).open('w') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('failed '+log)
try:
 run(['git','fetch','/home/bradley/hiring-existing-seed-revision.bundle','HEAD'],'fetch.log')
 run(['git','checkout','--detach','FETCH_HEAD'],'checkout.log');state['source']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 update(stage='build and focused validation')
 run(['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12','engine-tests'],'build-tests.log')
 run(['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12'],'build-client.log')
 run(['python3','test/run_tests.py','--build-dir','build/linux/client/release/retain-symbols/dev-linker-auto','--binary','engine','--filter','Hiring*/*','--filter','GradientPreparation/*','--filter','UnitCustomization/hybrid*','--filter','UnitCustomization/pending lethal*','--filter','TeamStatsSave/retained format152*','--no-display','--timeout','600','-j4','--junit',str(out/'focused.xml'),'--artifacts',str(out/'focused')],'focused.log')
 update(stage='participant traces');state['traces']={}
 for n in (1,2,4,8):
  dest=out/f'trace-{n}'
  run([str(root/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2'),'game','run','--ticks','5120','--compute-threads',str(n),'--gpu','off','--output-dir',str(dest),'--load-game',str(data/'common-checkpoint/final.game.gz'),'--telemetry','checksums'],f'trace-{n}.log')
  state['traces'][n]=hashlib.sha256((dest/'world.checksums').read_bytes()).hexdigest()
  assert state['traces'][n]=='a357e126c006c962591b5c3ed452f51af10e9a958fe0e11ac16a618739d842b1'
 import shutil
 shutil.copy2(root/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2',data/'glob2-seed-revisions')
 update(stage='complete',finished=time.time())
except BaseException as e:update(stage='failed',error=str(e),finished=time.time());raise
