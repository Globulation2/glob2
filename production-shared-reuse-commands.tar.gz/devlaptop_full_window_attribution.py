from pathlib import Path
import subprocess,json,time
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'full-window-attribution';out.mkdir(exist_ok=False)
def update(**kw):(out/'status.json').write_text(json.dumps(kw,indent=2))
try:
 assert json.loads((data/'optimized-trace-diagnostics-v2/status.json').read_text())['stage']=='complete'
 for arm,binary in [('original',data/'glob2-original-leading-anchor'),('cached',data/'glob2-leading-anchor')]:
  cmd=['valgrind','--tool=callgrind','--collect-atstart=no','--toggle-collect=Engine::advanceSession*','--callgrind-out-file='+str(out/(arm+'.callgrind')),str(binary),'game','run','--ticks','14336','--compute-threads','1','--gpu','off','--output-dir',str(out/(arm+'-game')),'--load-game',str(data/'late-cost-diagnostics'/(arm+'-checkpoint')/'final.game.gz')]
  update(stage='whole late-window callgrind attribution',arm=arm,command=cmd)
  with (out/(arm+'.log')).open('w') as stream:p=subprocess.run(cmd,cwd=root,stdout=stream,stderr=subprocess.STDOUT,timeout=3600)
  if p.returncode:raise RuntimeError('Failed profile retained')
  cmd=['callgrind_annotate','--inclusive=yes','--auto=no','--threshold=100',str(out/(arm+'.callgrind'))]
  with (out/(arm+'-functions.txt')).open('w') as stream:subprocess.run(cmd,cwd=root,stdout=stream,stderr=subprocess.STDOUT,check=True)
 update(stage='complete',finished=time.time())
except BaseException as error:update(stage='failed',error=str(error),finished=time.time());raise
