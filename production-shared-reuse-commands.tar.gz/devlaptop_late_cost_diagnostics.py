from pathlib import Path
import subprocess,json,time,hashlib
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'late-cost-diagnostics';out.mkdir(exist_ok=False)
state={'stage':'start','started':time.time()}
def update(**kw):
 state.update(kw);(out/'status.json').write_text(json.dumps(state,indent=2))
def run(command,log):
 update(command=command)
 with (out/log).open('w') as stream:p=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,timeout=3600)
 if p.returncode:raise RuntimeError('Failed diagnostic retained: '+log)
try:
 binaries={'original':data/'glob2-original-pristine','cached':data/'glob2-resource-first'}
 metadata={'sources':json.loads((data/'shared-cost-diagnostics/metadata.json').read_text())['sources'],'binary_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},'purpose':'late-colony phase attribution on each policy trajectory; not a paired state-equivalence or authoritative performance benchmark','checkpoints':{}}
 assert metadata['binary_sha256']['original']=='750be092b10c2f9b137f6c36df8dde5960ba178b6f3d144778d7112441d7a7dd'
 for arm,binary in binaries.items():
  update(stage='produce late checkpoints')
  dest=out/(arm+'-checkpoint')
  run([str(binary),'game','run','--ticks','12288','--compute-threads','4','--gpu','off','--output-dir',str(dest),'--map-file',str(data/'river-713.map.gz'),'--game-seed','100713','--save','final']+['--player','nicowar']*8,arm+'-checkpoint.log')
  checkpoint=dest/'final.game.gz';metadata['checkpoints'][arm]=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
 (out/'metadata.json').write_text(json.dumps(metadata,indent=2))
 for arm,binary in binaries.items():
  checkpoint=out/(arm+'-checkpoint')/'final.game.gz'
  update(stage='late diagnostic timers')
  command=[str(binary),'game','run','--ticks','14336','--compute-threads','4','--gpu','off','--output-dir',str(out/(arm+'-stats')),'--load-game',str(checkpoint),'--compute-telemetry','waits']
  if arm=='cached':command+=['--telemetry','hiring-stats']
  run(['/usr/bin/time','-v','-o',str(out/(arm+'-time.txt'))]+command,arm+'-stats.log')
  update(stage='late callgrind attribution')
  run(['valgrind','--tool=callgrind','--callgrind-out-file='+str(out/(arm+'.callgrind')),str(binary),'game','run','--ticks','12800','--compute-threads','1','--gpu','off','--output-dir',str(out/(arm+'-callgrind')),'--load-game',str(checkpoint)],arm+'-callgrind.log')
  for mode in ('yes','no'):
   run(['callgrind_annotate','--inclusive='+mode,'--auto=no','--threshold=100',str(out/(arm+'.callgrind'))],arm+('-functions.txt' if mode=='yes' else '-exclusive.txt'))
 update(stage='complete',finished=time.time())
except BaseException as error:update(stage='failed',error=str(error),finished=time.time());raise
