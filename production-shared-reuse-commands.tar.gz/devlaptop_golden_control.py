from pathlib import Path
import subprocess,json,time,os,shutil,hashlib
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'golden-control';out.mkdir(exist_ok=False)
env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2/build/sdl3/prefix';env['PYTHONPATH']='.'
current='c00f54894aecf473edb2bf3f439e26201fcf8b14';control='fb2b6174c72213016af7f4e9f4b03a638f62a7bd';state={'current':current,'control':control,'started':time.time()};modified=[]
def update(**kw):state.update(kw);(out/'status.json').write_text(json.dumps(state,indent=2))
def run(cmd,log):
 update(command=cmd)
 with (out/log).open('w') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('failed '+log)
def capture(arm):
 global modified
 cmd=['python3','test/run_tests.py','--build-dir','build/linux/client/release/retain-symbols/dev-linker-auto','--binary','engine','--filter','RuntimeResources/frozen seeded resource compositions*','--no-display','--timeout','600','-j1','--update-fixtures','--junit',str(out/(arm+'.xml')),'--artifacts',str(out/arm)]
 run(cmd,arm+'.log')
 modified=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
 assert modified and all(p.startswith('test/fixtures/resources/') for p in modified),modified
 hashes={}
 for p in modified:
  dest=out/(arm+'-fixtures')/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/p,dest);hashes[p]=hashlib.sha256(dest.read_bytes()).hexdigest()
 subprocess.run(['git','restore','--']+modified,cwd=root,check=True);modified=[]
 return hashes
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==current
 update(stage='capture current actual trace')
 state['current_traces']=capture('current')
 run(['git','checkout','--detach',control],'checkout-control.log')
 update(stage='build earlier production control')
 run(['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12','engine-tests'],'build-control.log')
 state['control_traces']=capture('control')
 state['traces_match']=state['current_traces']==state['control_traces']
 if not state['traces_match']:raise RuntimeError('Current versus old production resource trace differs')
 run(['git','checkout','--detach',current],'restore-source.log')
 update(stage='complete',finished=time.time())
except BaseException as e:update(stage='failed',error=str(e),finished=time.time());raise
finally:
 if modified:subprocess.run(['git','restore','--']+modified,cwd=root)
