from pathlib import Path
import subprocess,os,json,time,hashlib
root=Path.cwd(); out=root/'artifacts/hiring-profile';out.mkdir(exist_ok=True)
env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2/build/sdl3/prefix';env['PYTHONPATH']='.'
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
commands=[['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12','engine-tests'],['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12']]
status={'source':source,'started':time.time(),'commands':commands,'status':'building'}
def write(): (out/'build-status.json').write_text(json.dumps(status,indent=2))
write()
for n,cmd in enumerate(commands):
 with (out/f'build-{n}.log').open('w') as log:
  p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:status.update(status='failed',returncode=p.returncode,finished=time.time());write();raise SystemExit(p.returncode)
status.update(status='complete',finished=time.time());write()
