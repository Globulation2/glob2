from pathlib import Path
import tarfile,hashlib,json
root=Path('/home/bradley/glob2-hiring-profile-20261013/artifacts/hiring-profile');names=['resource-first','leading-anchor','compact-flags','shared-cost-diagnostics','late-cost-diagnostics','full-window-attribution','anchor-cost-control','anchor-cost-control-v2','compact-flags-control','optimized-ai-pilot-v2','compact-flags-pilot','optimized-trace-diagnostics','optimized-trace-diagnostics-v2']
archive=root/'primary-attribution-evidence.tar.gz';files={};seen={}
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for name in names:
  for p in sorted((root/name).rglob('*')):
   if not p.is_file() or 'profile' in p.relative_to(root/name).parts:continue
   if p.name=='game.replay.checksums':continue
   if p.suffix not in ['.json','.jsonl','.log','.xml','.txt','.callgrind','.checksums','.patch','.gz','.replay']:continue
   n=str(p.relative_to(root));h=hashlib.sha256(p.read_bytes()).hexdigest();files[n]=h
   if h in seen:
    entry=tarfile.TarInfo(n);entry.type=tarfile.LNKTYPE;entry.linkname=seen[h];t.addfile(entry)
   else:seen[h]=n;t.add(p,arcname=n)
 for name in ['river-713.map.gz','islands-713.map.gz','swamp-713.map.gz','maps.json']:
  p=root/name
  if p.exists():files[name]=hashlib.sha256(p.read_bytes()).hexdigest();t.add(p,arcname=name)
(root/'primary-attribution-manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files,'identical_files_are_tar_hardlinks':True,'omitted':'Repeated large verbose game.replay.checksums dumps retained remotely; compact world.checksums, replay files, checkpoints and logs included.'},indent=2));print(archive.stat().st_size)
