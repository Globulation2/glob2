from pathlib import Path
import subprocess,json,time,os
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'original-release';out.mkdir(exist_ok=True)
status=out/'status.json';base='35b84d4ffd774742ada41d33c39ab1a50551f113';checkout=root.with_name(root.name+'-baseline')
while not (data/'version-key-benchmark/finished.json').exists():time.sleep(1)
assert json.loads((data/'version-key-benchmark/finished.json').read_text())['status']=='complete'
env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2/build/sdl3/prefix';env['PYTHONPATH']='.'
state={'source':base,'stage':'preparing','started':time.time()}
def update(**kw):state.update(kw);status.write_text(json.dumps(state,indent=2))
def run(cmd,cwd,log):
 update(command=cmd)
 with log.open('w') as f:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(str(cmd)+' failed '+str(p.returncode))
try:
 update()
 if not checkout.exists():run(['git','worktree','add','--detach',str(checkout),base],root,out/'checkout.log')
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip()==base
 update(stage='building ordinary release baseline')
 run(['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12'],checkout,out/'build.log')
 update(stage='complete',finished=time.time(),binary=str(checkout/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2'))
except BaseException as e:update(stage='failed',error=str(e),finished=time.time());raise
