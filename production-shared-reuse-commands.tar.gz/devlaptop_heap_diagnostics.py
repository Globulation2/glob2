from pathlib import Path
import subprocess,json,time,os,hashlib
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'heap-diagnostics';out.mkdir(exist_ok=False)
state={'stage':'waiting for timing screen','started':time.time()};env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2/build/sdl3/prefix';env['PYTHONPATH']='.'
def update(**kw):
 state.update(kw);(out/'status.json').write_text(json.dumps(state,indent=2))
def run(cmd,log):
 update(command=cmd)
 with (out/log).open('w') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('failed '+log)
try:
 update()
 while not (data/'original-heap-pilot/finished.json').exists():time.sleep(2)
 assert json.loads((data/'original-heap-pilot/finished.json').read_text())['status']=='complete'
 run(['git','fetch','/home/bradley/hiring-heap-controls.bundle','HEAD'],'fetch.log')
 run(['git','checkout','--detach','FETCH_HEAD'],'checkout.log');state['source']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 update(stage='strengthened ranking controls')
 run(['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12','engine-tests'],'build-tests.log')
 run(['python3','test/run_tests.py','--build-dir','build/linux/client/release/retain-symbols/dev-linker-auto','--binary','engine','--filter','HiringPlanner/distance bounds preserve exhaustive rankings for every job','--no-display','--timeout','600','-j1','--junit',str(out/'controls.xml'),'--artifacts',str(out/'controls')],'controls.log')
 update(stage='diagnostic counters and callgrind; not throughput measurements')
 for arm,binary in [('before',data/'glob2-partial-costs'),('after',data/'glob2-heap-reuse')]:
  for n in (1,4):
   dest=out/f'{arm}-stats-{n}'
   run([str(binary),'game','run','--ticks','6144','--compute-threads',str(n),'--gpu','off','--output-dir',str(dest),'--load-game',str(data/'common-checkpoint/final.game.gz'),'--telemetry','hiring-stats'],f'{arm}-stats-{n}.log')
  dest=out/f'{arm}-callgrind'
  run(['valgrind','--tool=callgrind','--callgrind-out-file='+str(out/f'{arm}.callgrind'),str(binary),'game','run','--ticks','4352','--compute-threads','1','--gpu','off','--output-dir',str(dest),'--load-game',str(data/'common-checkpoint/final.game.gz')],f'{arm}-callgrind.log')
 update(stage='complete',finished=time.time())
except BaseException as e:update(stage='failed',error=str(e),finished=time.time());raise
