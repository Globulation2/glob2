from pathlib import Path
import subprocess,json,time
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'partial-cost-extra';out.mkdir(exist_ok=False)
while True:
 state=json.loads((data/'partial-costs/status.json').read_text())
 if state['stage']=='complete':break
 if state['stage']=='failed':raise RuntimeError('Partial cost validation failed')
 time.sleep(2)
cmd=['python3','test/run_tests.py','--build-dir','build/linux/client/release/retain-symbols/dev-linker-auto','--binary','engine','--filter','Terrain*/*','--filter','VertexTerrain/*','--filter','RuntimeResources/*','--no-display','--timeout','600','-j4','--junit',str(out/'focused.xml'),'--artifacts',str(out/'focused')]
with (out/'focused.log').open('w') as log:p=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
(out/'finished.json').write_text(json.dumps({'source':state['source'],'command':cmd,'status':'complete' if p.returncode==0 else 'failed','returncode':p.returncode,'finished':time.time()},indent=2))
