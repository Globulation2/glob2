from pathlib import Path
import subprocess,json,time,os,hashlib,shutil
root=Path('/home/bradley/glob2-hiring-profile-20261013-baseline');data=Path('/home/bradley/glob2-hiring-profile-20261013/artifacts/hiring-profile');out=data/'pristine-baseline-restoration';out.mkdir(exist_ok=False)
state={'stage':'build','started':time.time()};env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2/build/sdl3/prefix';env['PYTHONPATH']='.'
def update(**kw):state.update(kw);(out/'status.json').write_text(json.dumps(state,indent=2))
try:
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
 state['source']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 command=['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12'];update(command=command)
 with (out/'build.log').open('w') as log:p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert p.returncode==0
 binary=root/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2'
 raw=binary.read_bytes();assert b'GRADAUDIT ' not in raw
 destination=data/'glob2-original-pristine';shutil.copy2(binary,destination)
 state['binary']=str(destination);state['binary_sha256']=hashlib.sha256(raw).hexdigest()
 expected=json.loads((data/'original-full-kernel-pilot/metadata.json').read_text())['binary_sha256']['original']
 state['earlier_binary_sha256']=expected;state['matches_earlier_binary']=state['binary_sha256']==expected
 update(stage='complete',finished=time.time())
except BaseException as e:update(stage='failed',error=str(e),finished=time.time());raise
