from pathlib import Path
import subprocess,json,time,os,hashlib,shutil
root=Path('/home/bradley/glob2-hiring-profile-20261013');base=Path(str(root)+'-baseline');data=root/'artifacts/hiring-profile';out=data/'compact-flags-control';out.mkdir(exist_ok=False)
state={'stage':'waiting for leading-anchor validation','started':time.time()};env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2/build/sdl3/prefix';env['PYTHONPATH']='.'
def update(**kw):state.update(kw);(out/'status.json').write_text(json.dumps(state,indent=2))
def run(command,log,cwd=root):
 update(command=command)
 with (out/log).open('w') as stream:p=subprocess.run(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=3600)
 if p.returncode:raise RuntimeError('Failed control retained: '+log)
try:
 update()
 while True:
  status=json.loads((data/'compact-flags/status.json').read_text()) if (data/'compact-flags/status.json').exists() else {}
  if status.get('stage')=='complete':break
  if status.get('stage')=='failed':raise RuntimeError('Final leading anchor validation failed')
  time.sleep(2)
 assert subprocess.check_output(['git','status','--porcelain'],cwd=base,text=True)==''
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip()=='35b84d4ffd774742ada41d33c39ab1a50551f113'
 update(stage='build isolated original-policy AI optimization control')
 patch=Path('/home/bradley/compact-flags-control.patch');shutil.copy2(patch,out/'original-control.patch')
 try:
  run(['git','apply',str(patch)],'apply-original.log',base)
  run(['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12'],'build-original.log',base)
  shutil.copy2(base/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2',data/'glob2-original-compact-flags')
 finally:subprocess.run(['git','restore','--','src/ai/shared_runtime/BuildingOrder.cpp','src/ai/observation/ObservationQueries.h'],cwd=base,check=True)
 binaries={'original-before':data/'glob2-original-pristine','original-after':data/'glob2-original-compact-flags','cached-before':data/'glob2-resource-first','cached-after':data/'glob2-compact-flags'}
 checkpoints={arm:data/'late-cost-diagnostics'/('original-checkpoint' if arm.startswith('original') else 'cached-checkpoint')/'final.game.gz' for arm in binaries}
 metadata={'original_base':'35b84d4ffd774742ada41d33c39ab1a50551f113','cached_before':'0c6aa19ab612e9f3a635b577cf13987a0c965770','cached_after':status['source'],'original_control_patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'binary_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},'purpose':'exact AI optimization control; before/after each policy from identical own-policy checkpoint; policies themselves have different worlds'}
 (out/'metadata.json').write_text(json.dumps(metadata,indent=2))
 update(stage='late trace equivalence controls')
 traces={}
 for arm,binary in binaries.items():
  dest=out/(arm+'-trace')
  run([str(binary),'game','run','--ticks','14336','--compute-threads','4','--gpu','off','--output-dir',str(dest),'--load-game',str(checkpoints[arm]),'--telemetry','checksums'],arm+'-trace.log')
  traces[arm]=hashlib.sha256((dest/'world.checksums').read_bytes()).hexdigest()
 assert traces['original-before']==traces['original-after'],traces
 assert traces['cached-before']==traces['cached-after'],traces
 (out/'trace-controls.json').write_text(json.dumps(traces,indent=2))
 update(stage='quiet release late-window paired screen')
 with (out/'samples.jsonl').open('w') as stream:
  arms=list(binaries)
  for rep in range(-1,3):
   for arm in arms[rep%4:]+arms[:rep%4]:
    binary=binaries[arm];dest=out/(arm+'-timing-'+str(rep));command=[str(binary),'game','run','--ticks','14336','--benchmark-warmup','256','--compute-threads','4','--gpu','off','--output-dir',str(dest),'--load-game',str(checkpoints[arm])]
    before=subprocess.check_output(['ps','-eo','pid,pcpu,comm','--sort=-pcpu'],text=True)
    run(command,arm+'-timing-'+str(rep)+'.log')
    stream.write(json.dumps({'repetition':rep,'arm':arm,'command':command,'host_before':before,'result':json.loads((dest/'result.json').read_text())})+'\n');stream.flush()
 update(stage='optimized late Callgrind attribution')
 for arm in ['original-after','cached-after']:
  run(['valgrind','--tool=callgrind','--callgrind-out-file='+str(out/(arm+'.callgrind')),str(binaries[arm]),'game','run','--ticks','12800','--compute-threads','1','--gpu','off','--output-dir',str(out/(arm+'-callgrind')),'--load-game',str(checkpoints[arm])],arm+'-callgrind.log')
  run(['callgrind_annotate','--inclusive=yes','--auto=no','--threshold=100',str(out/(arm+'.callgrind'))],arm+'-functions.txt')
 update(stage='complete',finished=time.time())
except BaseException as error:update(stage='failed',error=str(error),finished=time.time());raise
