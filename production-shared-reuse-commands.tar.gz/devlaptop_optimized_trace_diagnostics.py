from pathlib import Path
import subprocess,json,time,os
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'optimized-trace-diagnostics';out.mkdir(exist_ok=False)
def update(**kw):(out/'status.json').write_text(json.dumps(kw,indent=2))
try:
 update(stage='waiting for quiet release screen')
 while True:
  state=json.loads((data/'optimized-ai-pilot-v2/status.json').read_text())
  if state['stage']=='complete':break
  if state['stage']=='failed':raise RuntimeError('Timing screen failed; profiling blocked')
  time.sleep(2)
 env=os.environ.copy();env['GLOB2_SNAPSHOT_PROFILE']='1'
 for policy,binary in [('original',data/'glob2-original-leading-anchor'),('cached',data/'glob2-leading-anchor')]:
  dest=out/policy;cmd=[str(binary),'game','run','--ticks','14336','--compute-threads','4','--gpu','off','--output-dir',str(dest),'--load-game',str(data/'late-cost-diagnostics'/(policy+'-checkpoint')/'final.game.gz'),'--compute-telemetry','trace']
  if policy=='cached':cmd+=['--telemetry','hiring-stats']
  update(stage='trace diagnostics',policy=policy,command=cmd)
  with (out/(policy+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
  if p.returncode:raise RuntimeError('Failed diagnostic retained')
 update(stage='complete',finished=time.time())
except BaseException as error:update(stage='failed',error=str(error),finished=time.time());raise
