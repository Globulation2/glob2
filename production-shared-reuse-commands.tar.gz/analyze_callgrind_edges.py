import re,json,sys
from collections import defaultdict
from pathlib import Path

def edges(path):
 names={};rows=defaultdict(lambda:[0,0]); current=None;target=None;calls=None
 for line in Path(path).read_text().splitlines():
  m=re.match(r'(c?fn)=\((\d+)\)(?: (.*))?$',line)
  if m:
   ident=int(m[2]);
   if m[3]:names[ident]=m[3]
   if m[1]=='fn':current=ident;target=None;calls=None
   else:target=ident
  elif line.startswith('calls='):
   calls=int(line.split('=',1)[1].split()[0]);rows[(current,target)][0]+=calls
  elif calls is not None and re.match(r'^[+\-*\d]',line):
   bits=line.split()
   if len(bits)==2:rows[(current,target)][1]+=int(bits[1]);calls=None
 return [{'caller':names.get(a,str(a)),'callee':names.get(b,str(b)),'calls':v[0],'ir':v[1]} for (a,b),v in rows.items()]
if __name__=='__main__':
 path=Path(sys.argv[1]);r=edges(path);path.with_suffix('.edges.json').write_text(json.dumps(r))
 wanted=['BuildingOrder::find_location','Gradients::Gradient::recalculate','Runtime::getOrder','OrderScheduler::Pending::run','NewNicowar::tick']
 for key in wanted:
  rows=[v for v in r if key in v['callee']]
  print(key,'calls',sum(v['calls'] for v in rows),'edge_Ir',sum(v['ir'] for v in rows))
  for v in sorted(rows,key=lambda x:x['ir'],reverse=True)[:3]:print(v)
