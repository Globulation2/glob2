from pathlib import Path
import subprocess,json,time,os,hashlib,shutil
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'full-kernel-control';out.mkdir(exist_ok=False)
state={'stage':'build full kernel control','started':time.time()};env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2/build/sdl3/prefix';env['PYTHONPATH']='.'
src=root/'src/building/HiringPlanner.cpp';original=src.read_text()
def update(**kw):
 state.update(kw);(out/'status.json').write_text(json.dumps(state,indent=2))
def run(cmd,log):
 update(command=cmd)
 with (out/log).open('w') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('failed '+log)
try:
 assert json.loads((data/'heap-diagnostics/status.json').read_text())['stage']=='complete'
 state['source']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 state['baseline_source_sha256']=hashlib.sha256(original.encode()).hexdigest()
 changed=original.replace('Cache(budget, Options{})','Cache(budget, Options{.partialResourceFields = false})')
 assert changed != original
 src.write_text(changed);state['control_source_sha256']=hashlib.sha256(changed.encode()).hexdigest()
 run(['git','diff','--','src/building/HiringPlanner.cpp'],'control.patch')
 run(['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12'],'build.log')
 binary=data/'glob2-full-kernel-control';shutil.copy2(root/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2',binary);state['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
 src.write_text(original)
 update(stage='unchanged participant traces');state['traces']={}
 for n in [1,4]:
  dest=out/f'trace-{n}'
  run([str(binary),'game','run','--ticks','5120','--compute-threads',str(n),'--gpu','off','--output-dir',str(dest),'--load-game',str(data/'common-checkpoint/final.game.gz'),'--telemetry','checksums'],f'trace-{n}.log')
  state['traces'][n]=hashlib.sha256((dest/'world.checksums').read_bytes()).hexdigest()
  assert state['traces'][n]=='a357e126c006c962591b5c3ed452f51af10e9a958fe0e11ac16a618739d842b1'
 update(stage='counter collection; no throughput claim')
 run([str(binary),'game','run','--ticks','6144','--compute-threads','4','--gpu','off','--output-dir',str(out/'stats-4'),'--load-game',str(data/'common-checkpoint/final.game.gz'),'--telemetry','hiring-stats'],'stats-4.log')
 update(stage='complete',finished=time.time())
except BaseException as e:update(stage='failed',error=str(e),finished=time.time());raise
finally:src.write_text(original)
