from pathlib import Path
import subprocess,json,time,os,hashlib,shutil,collections,re
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'gradient-count-audit';out.mkdir(exist_ok=False)
roots={'original':Path('/home/bradley/glob2-hiring-profile-20261013-baseline'),'cached':root}
state={'stage':'start','started':time.time(),'scope':'diagnostic counts; instrumented binaries are not timing evidence'};env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2/build/sdl3/prefix';env['PYTHONPATH']='.'
def update(**kw):
 state.update(kw);(out/'status.json').write_text(json.dumps(state,indent=2))
def run(cmd,log,cwd=root):
 update(command=cmd)
 with (out/log).open('w') as f:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('failed '+log)
try:
 assert json.loads((data/'original-full-kernel-pilot/finished.json').read_text())['status']=='complete'
 # Both policies begin the main comparison from exactly this old-format world.
 original_binary=roots['original']/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2'
 run([str(original_binary),'game','run','--ticks','4096','--compute-threads','4','--gpu','off','--output-dir',str(out/'common-start'),'--map-file',str(data/'river-713.map.gz'),'--game-seed','100713','--save','final']+['--player','nicowar']*8,'common-start.log',roots['original'])
 state['checkpoint_sha256']=hashlib.sha256((out/'common-start/final.game.gz').read_bytes()).hexdigest();state['sources']={};state['binaries']={}
 for arm,checkout in roots.items():
  backups={}
  try:
   assert not subprocess.check_output(['git','status','--porcelain'],cwd=checkout,text=True).strip()
   state['sources'][arm]=subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip();update(stage='build '+arm+' counters')
   replacements={
    'src/map/gradient/MapGradientMaterial.cpp':('\tif (gradient == NULL)', '\tstd::fprintf(stderr,"GRADAUDIT live_request %u %d %d %d %d %d\\n",game->stepCounter,teamNumber,resourceType,swimClass,int(withMarkets),int(gradient==nullptr));\n\tif (gradient == NULL)'),
    'src/map/MapStep.cpp':('auto dispatch = [&](Uint16 **slot, Kind kind, int team, int material, int swim) {','auto dispatch = [&](Uint16 **slot, Kind kind, int team, int material, int swim) {\n std::fprintf(stderr,"GRADAUDIT periodic_admit %u %d %d %d %d\\n",game->stepCounter,int(kind),team,material,swim);'),
    'src/map/gradient/SnapshotGradient.cpp':('void seed(const Request& request, const SimulationSnapshot::Handle& snapshot, Uint16* out, CrowdingScratch& scratch)\n{','void seed(const Request& request, const SimulationSnapshot::Handle& snapshot, Uint16* out, CrowdingScratch& scratch)\n{\n std::fprintf(stderr,"GRADAUDIT snapshot_seed %u %d %d %d %d\\n",snapshot.tick,int(request.kind),request.team,request.material,request.swim);'),
    'src/ai/observation/WorldQueries.h':('if(!published.empty()) resourceFields.erase(key);','std::fprintf(stderr,"GRADAUDIT ai_request %u %d %d %d %d %d\\n",world.tick,owner,resource,swim,int(!published.empty()),int(resourceFields.contains(key)));\n  if(!published.empty()) resourceFields.erase(key);')
   }
   if arm=='cached':
    replacements['src/building/HiringPlanner.cpp']=('\t\treturn field(world, key,','\t\tstd::fprintf(stderr,"GRADAUDIT planner_request %u %d %d %d %u %d %llu %llu %llu %llu %llu\\n",world.tick,b.team,material,swim,modes,int(fields.contains(key)),(unsigned long long)key.mapVersions[0],(unsigned long long)key.mapVersions[1],(unsigned long long)key.mapVersions[2],(unsigned long long)key.mapVersions[3],(unsigned long long)key.mapVersions[4]);\n\t\treturn field(world, key,')
   for name,(anchor,replacement) in replacements.items():
    f=checkout/name;s=f.read_text();backups[f]=s
    assert s.count(anchor)==1,(name,s.count(anchor))
    f.write_text('#include <cstdio>\n'+s.replace(anchor,replacement))
   run(['git','diff','--'],arm+'-instrumentation.patch',checkout)
   run(['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12'],arm+'-build.log',checkout)
   binary=out/('glob2-'+arm+'-counts');shutil.copy2(checkout/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2',binary)
   state['binaries'][arm]={'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
  finally:
   for f,s in backups.items():f.write_text(s)
  update(stage=arm+' same-start field counts')
  run([str(binary),'game','run','--ticks','6144','--compute-threads','4','--gpu','off','--output-dir',str(out/(arm+'-game')),'--load-game',str(out/'common-start/final.game.gz')],arm+'-game.log',checkout)
  # Keep the full key/request stream and explicit counts, not inferred builds.
  counts=collections.Counter();by_family=collections.defaultdict(collections.Counter);last={};reasons=collections.Counter()
  for line in (out/(arm+'-game.log')).read_text().splitlines():
   if not line.startswith('GRADAUDIT '):continue
   parts=line.split();kind=parts[1];v=list(map(int,parts[2:]));counts[kind]+=1
   if kind=='live_request':
    tick,team,mat,swim,markets,miss=v;counts['live_lazy_builds']+=miss;by_family[str((team,mat,swim,markets))]['live_requests']+=1;by_family[str((team,mat,swim,markets))]['live_lazy_builds']+=miss
   if kind=='ai_request':
    tick,team,mat,swim,published,cached=v;counts['ai_private_builds']+=int(not published and not cached);counts['ai_published_hits']+=published;counts['ai_private_hits']+=int(not published and cached)
   if kind=='planner_request':
    tick,team,mat,swim,modes,hit,*versions=v;counts['planner_builds']+=int(not hit);group=(team,mat,swim,modes);prev=last.get(group);last[group]=versions
    if not hit:
     if prev is None:reasons['first_family']+=1
     else:
      changed=False
      for label,a,b in zip(['terrain','resources','occupancy','areas','visibility'],prev,versions):
       if a!=b:reasons[label]+=1;changed=True
      if not changed:reasons['other_key_change_or_eviction']+=1
  (out/(arm+'-counts.json')).write_text(json.dumps({'counts':dict(counts),'live_families':{k:dict(v) for k,v in by_family.items()},'planner_overlapping_map_version_miss_reasons':dict(reasons)},indent=2))
 update(stage='complete',finished=time.time())
except BaseException as e:update(stage='failed',error=str(e),finished=time.time());raise
