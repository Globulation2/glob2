from pathlib import Path
import subprocess,json,time,os,shutil,collections
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';out=data/'key-diagnostic';out.mkdir(exist_ok=False)
src=root/'src/building/HiringPlanner.cpp';original=src.read_text();state={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'stage':'build diagnostic','started':time.time()}
def update(**kw):state.update(kw);(out/'status.json').write_text(json.dumps(state,indent=2))
env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2/build/sdl3/prefix';env['PYTHONPATH']='.'
def run(cmd,name):
 update(command=cmd)
 with (out/name).open('w') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('failed '+name)
try:
 assert state['source']=='a8e53acd789f16a60e0057d6cf2b57b80c5bfccd'
 assert json.loads((data/'original-seed-pilot/finished.json').read_text())['status']=='complete'
 injection='''
        std::fprintf(stderr,"HIRINGKEY %u %d %d %d %u %llu %d %llu %llu %llu %llu %llu %u %d\\n",
            world.tick,b.team,material,swim,modes,(unsigned long long)key.consumer,key.seedVersioned,
            (unsigned long long)key.terrainRevision,(unsigned long long)key.mapVersions[0],
            (unsigned long long)key.mapVersions[1],(unsigned long long)key.mapVersions[4],
            (unsigned long long)key.configuration,key.supplierTick,fields.contains(key));
'''
 src.write_text(original.replace('#include <algorithm>','#include <algorithm>\n#include <cstdio>').replace('\t\treturn field(world, key,',injection+'\t\treturn field(world, key,'))
 run(['git','diff','--','src/building/HiringPlanner.cpp'],'instrumentation.patch')
 run(['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','pch=0','unity=0','-j12'],'build.log')
 binary=out/'glob2-key-diagnostic';shutil.copy2(root/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2',binary)
 update(stage='collect key changes; not a timing run')
 run([str(binary),'game','run','--ticks','4096','--compute-threads','1','--gpu','off','--output-dir',str(out/'game'),'--map-file',str(data/'river-713.map.gz'),'--game-seed','100713']+['--player','nicowar']*8,'game.log')
 counts=collections.Counter();reasons=collections.Counter();by_mode={};last={}
 for line in (out/'game.log').read_text().splitlines():
  if not line.startswith('HIRINGKEY '):continue
  v=list(map(int,line.split()[1:]));tick,team,mat,swim,mode,consumer,seed,terr,terrain,resource,vis,conf,supplier,hit=v
  group=(team,mat,swim,mode,consumer,seed);now=(terr,terrain,resource,vis,conf,supplier);prev=last.get(group);last[group]=now
  counts['queries']+=1;counts['hits' if hit else 'misses']+=1
  bucket=by_mode.setdefault(str(mode),collections.Counter());bucket['queries']+=1;bucket['hits' if hit else 'misses']+=1
  if hit:continue
  if prev is None:reasons['first_family_query']+=1;continue
  changed=[name for name,a,b in zip(['terrain_rule_revision','terrain_map_generation','seed_revision' if seed else 'resource_map_generation','visibility_map_generation','configuration_revision','supplier_tick'],prev,now) if a!=b]
  if not changed:changed=['same_visible_key_cache_miss']
  for name in changed:reasons[name]+=1
 (out/'findings.json').write_text(json.dumps({'counts':dict(counts),'overlapping_miss_reasons':dict(reasons),'by_supplier_mode':{k:dict(v) for k,v in by_mode.items()},'scope':'diagnostic build; no throughput claim; current semantic seed experiment a8, river4096, serial'},indent=2))
 update(stage='complete',finished=time.time())
except BaseException as e:update(stage='failed',error=str(e),finished=time.time());raise
finally:src.write_text(original)
