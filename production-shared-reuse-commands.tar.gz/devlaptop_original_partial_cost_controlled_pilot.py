from pathlib import Path
import subprocess,json,time,hashlib,os,platform
root=Path('/home/bradley/glob2-hiring-profile-20261013');data=root/'artifacts/hiring-profile';status=data/'original-release/status.json'
while True:
 s=json.loads(status.read_text())
 if s['stage']=='complete':break
 if s['stage']=='failed':raise RuntimeError('Original release build failed; retained logs')
 time.sleep(2)
while True:
 verified=json.loads((data/'partial-costs/status.json').read_text()) if (data/'partial-costs/status.json').exists() else {}
 if verified.get('stage')=='complete':break
 if verified.get('stage')=='failed':raise RuntimeError('Partial resource validation failed; retain and diagnose')
 time.sleep(2)
while not (data/'golden-control/status.json').exists():time.sleep(2)
while json.loads((data/'golden-control/status.json').read_text()).get('stage') not in ['complete','failed']:time.sleep(2)
proof=json.loads((data/'golden-control/status.json').read_text())
assert proof['stage']=='complete' and proof['traces_match'],proof
old=Path(s['binary']);binaries={'original':old,'cached':data/'glob2-partial-costs'}
out=data/'original-partial-cost-pilot';out.mkdir(exist_ok=False)
cases=json.loads((data/'maps.json').read_text());cases=[c for c in cases if c['name'] in ['river-713','islands-713','swamp-713']]
meta={'sources':{'original':s['source'],'cached':verified['source']},'binary_sha256':{a:hashlib.sha256(b.read_bytes()).hexdigest() for a,b in binaries.items()},'host':platform.platform(),'protocol':{'participants':4,'ticks':16384,'benchmark_warmup':4096,'repetitions':3,'exports':'none','purpose':'regression screening before full ten-pair twelve-map comparison'},'cases':cases}
(out/'metadata.json').write_text(json.dumps(meta,indent=2))
try:
 with (out/'samples.jsonl').open('w') as stream:
  for rep in range(-1,3):
   for wi,case in enumerate(cases[rep%3:]+cases[:rep%3]):
    assert hashlib.sha256(Path(case['map']).read_bytes()).hexdigest()==case['sha256']
    for arm in (['original','cached'] if (rep+wi)%2==0 else ['cached','original']):
     dest=out/f"{case['name']}-{arm}-{rep}";c=[str(binaries[arm]),'game','run','--ticks','16384','--benchmark-warmup','4096','--compute-threads','4','--gpu','off','--output-dir',str(dest),'--map-file',case['map'],'--game-seed',str(case['game_seed'])]+['--player','nicowar']*8
     activity=subprocess.check_output(['ps','-eo','pid,pcpu,comm','--sort=-pcpu'],text=True);started=time.time()
     (out/'progress.json').write_text(json.dumps({'repetition':rep,'case':case['name'],'arm':arm,'started':started}))
     with dest.with_suffix('.log').open('w') as log:p=subprocess.run(c,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=900)
     row={'repetition':rep,'case':case['name'],'arm':arm,'command':c,'returncode':p.returncode,'elapsed_s':time.time()-started,'host_before':activity,'host_after':subprocess.check_output(['ps','-eo','pid,pcpu,comm','--sort=-pcpu'],text=True),'load_after':os.getloadavg(),'result':json.loads((dest/'result.json').read_text()) if (dest/'result.json').exists() else None}
     stream.write(json.dumps(row)+'\n');stream.flush()
     if p.returncode:raise RuntimeError('Failed pilot attempt retained')
 (out/'finished.json').write_text(json.dumps({'finished':time.time(),'status':'complete'}))
except BaseException as e:(out/'finished.json').write_text(json.dumps({'finished':time.time(),'status':'failed','error':str(e)}));raise
