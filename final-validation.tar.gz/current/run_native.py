import os,json,subprocess,time,hashlib
from pathlib import Path
r=Path.cwd();b=r/'artifacts/ci-recovery';d=b/'comb-stack';w=b/'comb-stack-repair';sdk=w/'build/ci-prefix';build=w/'build/stack-release';provenance=json.loads((d/'dependency-provenance.json').read_text())
env=dict(os.environ,GLOB2_SDL3_PREFIX=str(sdk),GLOB2_RECORDING_PREFIX=str(sdk/'recording'),GLOB2_GLSLANG=str(r/'build/glslang-tools/StandAlone/glslang'),LD_LIBRARY_PATH=str(sdk/'lib'),GLOB2_BUILD_DIR=str(build));env['PATH']=str(b/'node/node_modules/.bin')+':'+str(sdk/'bin')+':'+env['PATH'];env.pop('DISPLAY',None)
state={'pid':os.getpid(),'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'base':'a46b28716cc0d69ac6435513c98233cc3e2ddf23','worktree':str(w),'build':str(build),'sdk':str(sdk),'results':[],'note':'Separate release native outputs and byte-identical private SDL/recording copy; root helper/source/dependencies remain frozen for active full-browser suite. Fixed-capacity slots allocated once, never resized. No thresholds/goldens/SIM_REV changes.'}
def save(phase):state['phase']=phase;(d/'native-status.json').write_text(json.dumps(state,indent=2)+'\n')
def guard():
 for name,digest in provenance['files'].items():
  for prefix in [Path(provenance['original_prefix']),sdk]:assert hashlib.sha256((prefix/name).read_bytes()).hexdigest()==digest,'dependency changed: '+str(prefix/name)
def run(name,cmd,timeout=None):
 save(name);start=time.monotonic()
 with(d/(name+'.log')).open('w')as log:code=subprocess.call(cmd,cwd=w,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 state['results'].append({'name':name,'command':cmd,'exit_code':code,'seconds':round(time.monotonic()-start,1)});save(name+' finished');return code
guard()
cmd=['python3','tools/dev_build.py','--build=build/stack-release','dev_fast=0','release=1','server=0','-j8','tests','build/stack-release/src/glob2','map-generator-golden-test','maxima-strategy-dump','map-report-test','lan-test','menu-colony-harness','transport-test']
if run('native-build',cmd):save('native build failed; inspect before continuing');raise SystemExit(1)
guard()
cmd=['python3','test/run_tests.py','--build-dir','build/stack-release','--filter','EngineSession/menu colony rendering consumes its shared boundary without recapture*','--filter','ComputeExecutor/*','--filter','PerformanceTelemetry/*','--filter','CustomGameSetup/Comb preview fits a 512 KiB worker stack*','--jobs','4','--display-jobs','1','--fullscreen','--coverage-profile','full','--timeout','900','--junit',str(d/'focused.xml'),'--artifacts',str(d/'focused')]
if run('focused-executor-stack',cmd):save('focused regression failed; inspect before broad verification');raise SystemExit(1)
if run('generator-goldens',[str(build/'src/MapGeneratorGoldenTest'),str(d/'generator-profile'),'--require-rows']):save('generator fingerprints failed; no reference update allowed');raise SystemExit(1)
# Refresh all integration/continuation tooling against this exact new native revision.
s=(b/'run_auxiliary.py').read_text();s=s.replace("OUT=ROOT/'artifacts/ci-recovery/auxiliary';OUT.mkdir(exist_ok=True)","OUT=Path("+repr(str(d/'auxiliary'))+");OUT.mkdir(parents=True,exist_ok=True)");s=s.replace('build/local-release','build/stack-release').replace('build/sdl3-ci/prefix','build/ci-prefix');s=s.replace("['python3',","["+repr(str(b/'venv/bin/python'))+",");s=s.replace('checks=[',"env['PATH']="+repr(str(b/'node/node_modules/.bin'))+"+':'+env['PATH']\nchecks=[",1);compile(s,str(d/'run_auxiliary.py'),'exec');(d/'run_auxiliary.py').write_text(s)
run('auxiliary-all20',['python3',str(d/'run_auxiliary.py')])
cmd=['python3','test/run_tests.py','--build-dir','build/stack-release','--jobs','4','--display-jobs','1','--fullscreen','--coverage-profile','full','--timeout','900','--write-inventory',str(d/'native-inventory.json'),'--junit',str(d/'native-junit.xml'),'--artifacts',str(d/'native-tests')]
run('native-full',cmd)
run('cli-smoke',['python3','test/test_cli_smoke.py','--binary',str(build/'src/glob2'),'--artifacts',str(d/'cli-smoke'),'--junit',str(d/'cli-smoke.xml')])
run('cli-reference',['python3','tools/cli_reference.py','--binary',str(build/'src/glob2'),'--check'])
guard();save('finished; inspect all result codes/JUnit and auxiliary group statuses')
