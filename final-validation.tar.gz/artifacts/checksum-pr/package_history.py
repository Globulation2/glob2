from pathlib import Path
import json,tarfile
root=Path.cwd(); selected=set()
for name in ['REPORT.md','environment.json','summary.json','callgrind-summary.json','large-combined.json','benchmark.py','large_pairs.py','observed-affinity.json']:
 p=Path('artifacts/checksum-trim')/name
 if p.exists(): selected.add(p)
for name in ['native','large-pairs']:
 for p in (Path('artifacts/checksum-trim')/name).rglob('*'):
  if p.is_file() and p.suffix in {'.json','.log','.py','.sh'}: selected.add(p)
for record in json.loads(Path('artifacts/checksum-trim/callgrind-summary.json').read_text()):
 for p in Path(record['annotation']).parent.iterdir():
  if p.is_file() and (p.suffix in {'.json','.txt','.log','.cpp','.h','.sh','.py'} or p.name.startswith('callgrind.')): selected.add(p)
with tarfile.open('artifacts/checksum-pr/historical-performance.tar.gz','w:gz') as archive:
 for p in sorted(selected): archive.add(p,arcname=p.as_posix(),recursive=False)
print('Historical performance evidence:',len(selected),'files')
