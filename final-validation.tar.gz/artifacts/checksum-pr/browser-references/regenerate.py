import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path.cwd()
out = root / 'artifacts/checksum-pr/browser-references'
build = root / 'build/linux/client/debug/dev-dev_fast-true-linker-auto'
binary = build / 'src/glob2'
env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy',
           GLOB2_CHECKSUM_SIDECAR='1')

def wait_build(name):
    log = root / 'artifacts/checksum-pr' / name
    while not log.exists() or 'scons: done building targets.' not in log.read_text():
        time.sleep(10)

def run(label, args):
    case_env = dict(env, GLOB2_USER_DATA_DIR=str(out / (label + '-profile')))
    (out / (label + '-command.json')).write_text(json.dumps(args, indent=2) + '\n')
    with (out / (label + '.log')).open('w') as log:
        subprocess.run(args, env=case_env, check=True, stdout=log, stderr=subprocess.STDOUT)
    print('Completed ' + label, flush=True)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

wait_build('game-build.log')
run('studio', [str(binary), 'game', 'run', '--map-file',
    str(root / 'platform/apps/engine-agent/fixtures/ais/two.map.gz'), '--game-seed', '19',
    '--player', 'javascript', '--ai-script', '0:' + str(root / 'examples/javascript/studio-starter.js'),
    '--player', 'numbi', '--ticks', '1024', '--write-replay', '--telemetry', 'checksums',
    '--save', 'initial', '--save', 'final', '--output-dir', str(out / 'studio')])
wait_build('tests-build.log')
run('preview', ['python3', 'test/run_tests.py', '--build-dir', str(build), '--binary', 'engine',
    '--filter', 'MapPreview/generator Studio*', '--timeout', '600', '-j1',
    '--artifacts', str(out / 'preview'), '--junit', str(out / 'preview/results.xml')])
package = next((out / 'preview').rglob('frozen-package.json'))
report = json.loads(next((out / 'preview').rglob('native-report.json')).read_text())
run('generated', [str(binary), 'game', 'run', '--generator-package', str(package),
    '--generator', 'examples:swamp', '--map-seed', '19', '--set', 'width=7', '--set', 'height=7',
    '--set', 'teams=4', '--set', 'workers=4', '--candidates', '1', '--game-seed', '19',
    '--player', 'nicowar', '--player', 'nicowar', '--player', 'nicowar', '--player', 'nicowar',
    '--ticks', '64', '--write-replay', '--telemetry', 'checksums', '--save', 'initial',
    '--save', 'final', '--output-dir', str(out / 'generated')])
run('loaded', [str(binary), 'game', 'run', '--load-game', str(out / 'generated/initial.game.gz'),
    '--ticks', '64', '--write-replay', '--telemetry', 'checksums', '--save', 'initial',
    '--save', 'final', '--output-dir', str(out / 'loaded')])
trace = out / 'generated/game.replay.checksums'
assert trace.read_bytes() == (out / 'loaded/game.replay.checksums').read_bytes()
for name, trace_path in [('studio-trace.json', out / 'studio/game.replay.checksums'),
                         ('generator-studio-trace.json', trace)]:
    path = root / 'browser/tests/fixtures' / name
    data = json.loads(path.read_text())
    assert digest(root / data['source']) == data['sourceSha256']
    if 'map' in data:
        assert digest(root / data['map']) == data['mapSha256']
    data['traceBytes'] = trace_path.stat().st_size
    data['traceSha256'] = digest(trace_path)
    if name.startswith('generator-'):
        assert data['packageHash'] == report['packageHash']
        for key in ('worldFingerprint', 'checksum', 'versionMinor', 'simRevision', 'simVersion'):
            data[key] = report[key]
    path.write_text(json.dumps(data, indent=2) + '\n')
(out / 'verification.json').write_text(json.dumps({
    'binarySha256': digest(binary), 'generatedLoadedTracesIdentical': True,
    'previewReport': report, 'actualBrowserRuntime': 'not run'
}, indent=2) + '\n')
print('Updated native-derived browser references', flush=True)
