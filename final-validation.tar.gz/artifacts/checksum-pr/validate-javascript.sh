#!/usr/bin/env bash
set -euo pipefail
while kill -0 2762704 2>/dev/null; do sleep 5; done
python3 -c 'from pathlib import Path; assert "scons: done building targets." in Path("artifacts/checksum-pr/game-build.log").read_text()'
python3 test/check_javascript.py "$PWD/build/linux/client/debug/dev-dev_fast-true-linker-auto/src/glob2" --output artifacts/checksum-pr/javascript > artifacts/checksum-pr/javascript.log 2>&1
