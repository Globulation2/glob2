from pathlib import Path
import hashlib,json,subprocess,tarfile,xml.etree.ElementTree as ET
root=Path.cwd(); out=root/'artifacts/checksum-pr'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
base=subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip()
suites={}
for name in ['tests','javascript-native','browser-playback','remote-playback','browser-references/preview']:
 cases=list(ET.parse(out/name/'results.xml').getroot().iter('testcase'))
 assert all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases),name
 suites[name]={'cases':len(cases),'failures':0,'errors':0,'skipped':0}
paths=subprocess.check_output(['git','diff','--name-only','-z',base,head]).split(b'\0')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
bindir=root/'build/linux/client/debug/dev-dev_fast-true-linker-auto'
metadata={
 'tested_commit':head,'base_revision':base,'integration':'Merged current master; clean committed working tree',
 'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),
 'platform':'Linux 7.0.0-31-generic x86_64; GCC 15.2.0-16ubuntu1; Python 3.14.4',
 'cpu_affinity':'9-15,25-31',
 'dependencies':{'SDL3':'3.4.16','SDL3_ttf':'3.2.2','SDL3_net':'3.2.0','SDL3_image':'3.4.6','libwebp':'1.6.0'},
 'build':'tools/dev_build.py -j8 (game); tools/dev_build.py -j8 engine-tests unit-tests; dev_fast=1, -O0 -g1, existing SDL prefix and compiler cache',
 'commands':['validate.sh','validate-javascript.sh','javascript-native-command.json','browser-references/regenerate.py'],
 'test_suites':suites,'python_tests':21,
 'javascript_cli_corpus':'Both frozen profiles pass complete tick traces, exact one/four-worker save/replay bytes and six saved continuations',
 'browser_references':'Native Studio 1024 ticks and Swamp 64 ticks regenerated; generated and saved Swamp traces byte-identical; actual browser execution unverified',
 'not_verified':['Windows','macOS','mobile','actual browser runtimes','rendered gameplay/feel','release packaging','performance at final one-tick/integrated head'],
 'binary_sha256':{str(p.relative_to(root)):sha(p) for p in [bindir/'src/glob2',bindir/'test/glob2-engine-tests',bindir/'test/glob2-unit-tests']},
 'changed_files_sha256':{p.decode():sha(root/p.decode()) for p in paths if p},
 'historical_performance':'Separate archive predates the final one-tick delay, cache cleanup and integration merge. It is not a final-head throughput claim.'
}
(out/'verification.json').write_text(json.dumps(metadata,indent=2)+'\n')
archive_path=out/'final-validation.tar.gz'
selected=[]
for p in out.rglob('*'):
 if not p.is_file() or p==archive_path or p.name in {'historical-performance.tar.gz','evidence.index'}: continue
 if any(part in {'profile','browser-fixture-profile','__pycache__'} for part in p.relative_to(out).parts): continue
 if p.suffix in {'.o','.a','.pyc'}: continue
 selected.append(p)
with tarfile.open(archive_path,'w:gz') as archive:
 for p in sorted(selected): archive.add(p,arcname=p.relative_to(root).as_posix(),recursive=False)
readme=f'''# Snapshot checksum PR evidence

Tested source: [{head}](https://github.com/Globulation2/glob2/commit/{head}). Integrated base: `{base}`.

- [Verification inventory, environment and source/binary hashes](verification.json)
- [Final validation archive](final-validation.tar.gz): exact commands, build/test logs, JUnit results, checksum traces, saves, replays and native browser-reference evidence. Profiles and executables are excluded.
- [Historical release performance archive](historical-performance.tar.gz): raw measurements and Callgrind profiles/annotations with source hashes and commands. These measurements predate the final one-tick delay and integration merge; they do not establish final-head throughput.
- [Archive integrity hashes](SHA256SUMS)

Final Linux validation passed: 229-case native suite; four JavaScript simulation cases; two replay playback checks; one preview/save-continuation check; 21 Python tests. Both JavaScript CLI profiles pass full traces, exact one/four-worker save/replay equivalence and six saved continuations. CPU work was confined to CPUs 9–15 and 25–31.

Windows, macOS, mobile, actual browser execution, rendered gameplay/feel, release packaging and final-head performance remain unverified. No cross-platform determinism or final-head speedup is claimed. Maintainer acceptance remains pending on the draft PR.

Artifacts are published on a dedicated evidence branch and are excluded from the code PR.
'''
(out/'evidence-README.md').write_text(readme)
(out/'SHA256SUMS').write_text(''.join(f'{sha(out/name)}  {name}\n' for name in ['verification.json','final-validation.tar.gz','historical-performance.tar.gz']))
print(json.dumps({'head':head,'suites':suites,'archive_bytes':archive_path.stat().st_size,'files':len(selected)}))
