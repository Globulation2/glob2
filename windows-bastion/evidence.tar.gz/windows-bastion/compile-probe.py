from pathlib import Path
import shlex,subprocess,json,hashlib,sys
base=Path('artifacts/ci-recovery/windows-bastion')
lines=Path('artifacts/ci-recovery/release-engine-build.log').read_text().splitlines()
command=shlex.split(next(l for l in lines if l.startswith('g++ -o build/ci-recovery-release/src/map/generator/generators/BastionKeysGenerator.o -c ')))
mode=sys.argv[1];command[2]=str(base/(mode+'.o'))
if mode.startswith('macro'):command.append('-Dfar=')
with (base/(mode+'.log')).open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
(base/(mode+'-result.json')).write_text(json.dumps({'command':command,'exitCode':result.returncode},indent=2)+'\n')
print(mode,'exit',result.returncode)
sys.exit(result.returncode)
