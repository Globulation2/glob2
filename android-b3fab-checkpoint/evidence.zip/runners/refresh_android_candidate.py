from pathlib import Path
import argparse,subprocess,json,hashlib,os
p=argparse.ArgumentParser();p.add_argument('--revision',required=True);a=p.parse_args()
root=Path.cwd();source=root/'artifacts/resource-refactor/android-source';out=root/'artifacts/resource-refactor'/('android-'+a.revision[:9]);out.mkdir(exist_ok=False)
revision=subprocess.check_output(['git','rev-parse',a.revision],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
subprocess.run(['git','fetch','--quiet',str(root),revision],cwd=source,check=True)
subprocess.run(['git','reset','--hard',revision],cwd=source,check=True)
files=subprocess.check_output(['git','ls-files','-z'],cwd=source).decode().split('\0')
manifest={f:hashlib.sha256((source/f).read_bytes()).hexdigest() for f in files if f and (source/f).is_file()}
(out/'source-hashes.json').write_text(json.dumps(manifest,indent=2))
command=['scons','target=android','arch=x86_64','release=1','android-tests','-j6']
meta={'revision':revision,'source':str(source),'sourceStatus':subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True),'command':command,'timing_valid':False}
(out/'build.json').write_text(json.dumps(meta,indent=2))
env=dict(os.environ);tmp=out/'tmp';tmp.mkdir();env['TMPDIR']=str(tmp)
with (out/'build.log').open('w') as log:r=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
meta['exit']=r.returncode;(out/'build.json').write_text(json.dumps(meta,indent=2));print(meta);raise SystemExit(r.returncode)
