// Task-local shell entry point. NativeTestMain supplies the existing SDL shell bridges.
extern "C" int SDL_main(int argc, char** argv);
// Assets are already staged by adb; shell execution has no APK AssetManager.
void initializeMobilePaths() {}
int main(int argc, char** argv) { return SDL_main(argc, argv); }
