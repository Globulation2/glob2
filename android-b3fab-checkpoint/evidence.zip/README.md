# Android runtime-resource validation

Exact candidate b3fab1a48; 36 unit cases and98 fresh-process engine cases pass. Stock1500-tick, official match and150-row custom-composition traces equal native/reference goldens. This is correctness evidence, never timing evidence.

See summary.json for scope, omissions and hashes; cases/results.json records every engine invocation and build-provenance check. NativeTestMain supplies Android shell bridges and the tiny shell-cli/ShellMain.cpp calls unmodified production SDL_main. Packaged assets and all tracked source files were verified unchanged before/after. SDK, compiler, dependencies, binary hashes and configuration are recorded in stage/result.json and shell-cli/provenance.json.

The task-owned emulator and isolated ADB server were stopped; all three ports are closed. No unrelated VM was touched. Binary/object files are omitted from this compact archive; their hashes and link/compile commands are retained.
