Browser renderer-switch recording tests invoke `ffprobe` to validate the exported media. Their hosted runner did not install it, so both serial and threaded cases failed with `spawnSync ffprobe ENOENT` after producing a recording.

Install the existing FFmpeg development tooling in browser test jobs, as the platform and music jobs already do. The game build and runtime dependency set are unchanged.

Validation: existing local FFmpeg6.1.1 successfully probes both renderer-switch recordings in the complete Chromium run. All 567 build contracts pass (2 optional skips). The original hosted failure and local media-probe evidence will be linked in a comment.
