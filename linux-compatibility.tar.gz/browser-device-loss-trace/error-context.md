# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: gradient-compute.spec.js >> WebGPU C++ worker ownership bridge requires real device commits
- Location: browser/tests/gradient-compute.spec.js:67:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 1
```

# Test source

```ts
  1  | // SPDX-License-Identifier: GPL-3.0-or-later
  2  | const {test,expect,chromium}=require('@playwright/test');
  3  | const fs=require('node:fs'),path=require('node:path');
  4  | const root=path.resolve(__dirname,'../..');
  5  | const library=fs.readFileSync(path.join(root,'browser/gradient-compute.js'),'utf8');
  6  | const shaders=['frozen8','jacobi'].map(name=>fs.readFileSync(path.join(root,'src/field/shaders',name+'.wgsl'),'utf8'));
  7  | const retainedSource=fs.readFileSync(path.join(root,'test/fixtures/gradients/RetainedVulkanSeeds.h'),'utf8');
  8  | const retained=[...retainedSource.matchAll(/retainedVulkanRuns\d+\{([\s\S]*?)\};/g)].map(match=>match[1].match(/\d+/g).map(Number));
  9  | if(retained.length!==5)throw Error('Expected all five retained NVIDIA fields');
  10 | const hardware=process.env.GLOB2_WEBGPU_EXPECT_DEVICE;
  11 | test('WebGPU compute algorithms match exact weighted fields and preserve canceled output',async({browserName})=>{
  12 |   test.skip(browserName!=='chromium','WebGPU compute qualification uses Chromium with explicit compute support');
  13 |   const args=hardware
  14 |     ? ['--enable-unsafe-webgpu','--use-angle=vulkan','--enable-features=Vulkan','--use-vulkan=native','--disable-vulkan-surface']
  15 |     : ['--enable-unsafe-webgpu','--use-angle=swiftshader','--enable-unsafe-swiftshader'];
  16 |   const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM,args});
  17 |   try{
  18 |     const page=await browser.newPage();
  19 |     await page.route('**/gradient-proof',route=>route.fulfill({contentType:'text/html',body:'<!doctype html><title>Gradient compute proof</title>',headers:{'Cross-Origin-Opener-Policy':'same-origin','Cross-Origin-Embedder-Policy':'require-corp'}}));
  20 |     await page.goto('http://127.0.0.1:8770/gradient-proof');
  21 |     const result=await page.evaluate(async({library,shaders,retained,hardware})=>{
  22 |       const entries={};globalThis.addToLibrary=value=>Object.assign(entries,value);eval(library);globalThis.Glob2GradientGPU=entries.$Glob2GradientGPU;
  23 |       const memory=new SharedArrayBuffer(1024*1024);globalThis.HEAP32=new Int32Array(memory);globalThis.HEAPU32=new Uint32Array(memory);
  24 |       const g=Glob2GradientGPU;await g.prepare(...shaders);let cases=0;
  25 |       const info=g.adapterInfo,adapter={vendor:info.vendor,architecture:info.architecture,device:info.device,description:info.description};
  26 |       if(hardware && (!new RegExp(hardware,'i').test(JSON.stringify(adapter)) || /swiftshader|lavapipe|llvmpipe/i.test(JSON.stringify(adapter))))
  27 |         throw Error('Expected hardware '+hardware+', got '+JSON.stringify(adapter));
  28 |       const wrap=(x,n)=>(x%n+n)%n;
  29 |       function reference(seeds,costs,w,h,cap){const out=seeds.slice();let changes=true;
  30 |         while(changes){changes=false;for(let i=0;i<out.length;i++)if(out[i]){
  31 |           let value=out[i];const x=i%w,y=Math.floor(i/w);
  32 |           for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)if(dx||dy){const k=wrap(y+dy,h)*w+wrap(x+dx,w),step=dx&&dy?costs[k]>>>16:costs[k]&65535,candidate=out[k]-step;if(candidate>=Math.max(2,65535-cap))value=Math.max(value,candidate);}
  33 |           if(value!==out[i]){out[i]=value;changes=true;}
  34 |         }}return out;}
  35 |       for(const frozen of[0,1])for(const[w,h]of[[1,1],[1,32],[32,1],[2,16],[17,19],[32,32]])for(const cap of[0,70,65500]){
  36 |         const n=w*h,seeds=Array(n).fill(1),costs=Array.from({length:n},(_,i)=>{const c=1+(i*71)%181;return c|(Math.floor(c*14/10)<<16);});
  37 |         for(let i=7;i<n;i+=11)seeds[i]=0;seeds[0]=65535;seeds[n-1]=65135;
  38 |         HEAP32.fill(0,0,4);HEAPU32.set(seeds,1024);HEAPU32.set(costs,32768);HEAPU32.fill(999,65536,65536+n);
  39 |         if(!await g.execute(0,4096,131072,262144,w,h,cap,frozen))throw Error('Unexpected decline');
  40 |         const expected=reference(seeds,costs,w,h,cap),actual=Array.from(HEAPU32.slice(65536,65536+n));
  41 |         for(let i=0;i<n;i++)if(actual[i]!==expected[i])throw Error(`Mismatch ${frozen} ${w}x${h} cap=${cap} at ${i}: ${actual[i]} != ${expected[i]}`);
  42 |         cases++;
  43 |       }
  44 |       for(const runs of retained){
  45 |         const seeds=[];for(const run of runs)for(let n=run>>>2;n;n--)seeds.push((run&3)===2?65535:run&3);
  46 |         if(seeds.length!==128*128)throw Error('Malformed retained field');
  47 |         const costs=Array(seeds.length).fill(10|(14<<16)),expected=reference(seeds,costs,128,128,65491);
  48 |         for(const frozen of[0,1])for(let repeat=0;repeat<3;repeat++){
  49 |           HEAP32.fill(0,0,4);HEAPU32.set(seeds,1024);HEAPU32.set(costs,32768);HEAPU32.fill(999,65536,65536+seeds.length);
  50 |           if(!await g.execute(0,4096,131072,262144,128,128,65491,frozen))throw Error('Retained device execution declined');
  51 |           for(let i=0;i<seeds.length;i++)if(HEAPU32[65536+i]!==expected[i])throw Error(`Retained mismatch ${frozen} repeat=${repeat} cell=${i}`);
  52 |           cases++;
  53 |         }
  54 |       }
  55 |       HEAP32[1]=1;HEAPU32[65536]=999;
  56 |       if(await g.execute(0,4096,131072,262144,1,1,65500,0))throw Error('Cancellation accepted');
  57 |       if(HEAPU32[65536]!==999)throw Error('Canceled output mutated');
  58 |       g.finish(0,1);if(Atomics.load(HEAP32,0)!==1)throw Error('Completion publication failed');
  59 |       g.device.destroy();return{cases,adapter};
  60 |     },{library,shaders,retained,hardware});
  61 |     console.log('WebGPU adapter:',JSON.stringify(result.adapter));
  62 |     expect(result.cases).toBe(66);
  63 |   }finally{await browser.close();}
  64 | });
  65 | 
  66 | // Opt in when the compiled threaded harness is served by the browser test host.
  67 | test('WebGPU C++ worker ownership bridge requires real device commits',async({browserName})=>{
  68 |   test.skip(browserName!=='chromium' || process.env.GLOB2_WEBGPU_CPP!=='1','Requires the compiled threaded harness');
  69 |   test.setTimeout(120000);
  70 |   const {openRuntimeHost}=require('./runtime-host');
  71 |   const args=hardware
  72 |     ? ['--enable-unsafe-webgpu','--use-angle=vulkan','--enable-features=Vulkan','--use-vulkan=native','--disable-vulkan-surface']
  73 |     : ['--enable-unsafe-webgpu','--use-angle=swiftshader','--enable-unsafe-swiftshader'];
  74 |   const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM,args});
  75 |   try{
  76 |     const page=await browser.newPage({baseURL:process.env.GLOB2_TEST_URL || 'http://127.0.0.1:8770'});
  77 |     let output='';
  78 |     page.on('console',message=>{output+=message.text()+'\n';console.log(message.text());});
  79 |     await openRuntimeHost(page,`<canvas id="canvas"></canvas><script>
  80 |       var Module={noInitialRun:true,canvas:document.querySelector('canvas'),
  81 |         locateFile:name=>name.endsWith('.data')?'/'+name:'/threaded/'+name,
  82 |         async onRuntimeInitialized(){window.result=await Module.start(['--test-suite=WebGPUGradient']);}};
  83 |       </script><script src="/threaded/script-tests.js"></script>`);
  84 |     await page.waitForFunction(()=>window.result!==undefined,null,{timeout:110000});
> 85 |     expect(await page.evaluate(()=>window.result)).toBe(0);
     |                                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  86 |     const deviceLine=output.split('\n').find(line=>line.includes('WebGPU C++ device:')) || '';
  87 |     expect(deviceLine).toContain('WebGPU C++ device:');
  88 |     if(hardware) expect(deviceLine).toMatch(new RegExp(hardware,'i'));
  89 |   }finally{await browser.close();}
  90 | });
  91 | 
```