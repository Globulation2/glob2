from pathlib import Path
import shlex,subprocess,sys,json
b=Path('artifacts/ci-recovery/gcc11-ai');mode=sys.argv[1];compiler=sys.argv[2]
lines=Path('artifacts/ci-recovery/release-engine-build.log').read_text().splitlines()
a=shlex.split(next(l for l in lines if l.startswith('g++ -o build/ci-recovery-release/test/engine-src_ai_engine_AIPipelineTest.o -c ')))
a[0]=compiler;a[2]=str(b/(mode+'.o'))
with (b/(mode+'.log')).open('w') as log:r=subprocess.run(a,stdout=log,stderr=subprocess.STDOUT)
(b/(mode+'-result.json')).write_text(json.dumps({'command':a,'exitCode':r.returncode},indent=2)+'\n');print(mode,r.returncode);sys.exit(r.returncode)
