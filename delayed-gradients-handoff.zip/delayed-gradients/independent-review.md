# Independent static review

Reviewed the delayed ground/shared and air destination gradient implementation, its consumer changes, scheduling, immutable ownership, logical budgets, save/load encoding, and follow-up fixes. This reviewer did not implement the production changes and did not run builds, tests, or performance measurements. Verification results must come from the separate execution evidence.

No unresolved blocking finding remained in the inspected revisions, including instrumentation commit `13f5d826818a9ec25ad866877eb54ee6346773d9`.

## Findings addressed during review

- Material routing now propagates a cold forbidden escape field as Pending, preserving assignments and avoiding direction RNG.
- Coalesced material and shared-market refreshes preserve newer dirty revisions until a subsequent capture; pending destinations no longer consume the entire periodic visit.
- Cache reduction retains a self-loadable effective budget. Newly published requested fields receive a bounded first-read opportunity, and abandoned requests eventually release that hold.
- Enrolled natural fields continue refreshing after their last source disappears, allowing completed Unreachable guidance to replace stale goals.
- Terrain edits with Markets V2 disabled preserve the loader's market-state invariants.
- Initial building queries initialize the delayed pipeline before choosing a preparation path. Existing nonempty pipelines retain their deadlines.
- Air consumer keys include relevant consumer configuration, and wrapped building midpoints are normalized.
- Air retired-generation budget attribution is serialized and hashed; output planes, labels, goals, and references receive structural validation.
- High-bit air destination IDs avoid material-cache ID collisions. Impossible single-field capacity fails deterministically instead of returning Pending forever.
- Cold air metadata is separated from plane admission: FIFO budget waits assign no deadline, while stable entry storage survives queued refreshes and outstanding jobs.
- Soft resource, area, visibility, supplier-stock, and clearing-claim dependencies retain deterministic refresh behavior and save/load continuation semantics.

## Reviewed guarantees

Scheduled outputs remain private until fixed publication boundaries. Query results distinguish Pending from completed unavailable data. Converted unit paths retain their assignments while waiting, and proposed movement still uses current local legality checks. Building identity/epoch validation and air unit/source/assignment validation prevent stale tickets from publishing into replacement destinations.

Air kernel inspection covered reverse entry costs, source-rooted private choices, blocked goals/sources, caller rounding, unrestricted Chebyshev metrics, stable goal ties, and the finite COST_LIMIT boundary. Private clearing choices inspect all candidate alternatives rather than a fixed nearest list. The inspected tests target these policies, but their successful execution is outside this static review.

The final audit-observer fix serializes observer installation, recording, and destruction with a mutex. A worker that saw an old enabled flag rechecks the observer under that mutex, so destruction cannot race a counter access. Atomic counters permit totals to be read concurrently. Serial targets skip the worker stress case through ThreadSupport capability detection. Text input backends remain owned by the fixture; binary input streams own their released backend.

## Remaining limits

- The 256-logical-tick first-read hold is an explicit cache policy adjustment; it is not an indefinite consumer lease.
- The budget bounds runtime-owned inventory and generations under the documented scoped owner-lease contract. Arbitrarily retained external shared leases can extend physical memory retention beyond that accounting.
- Immediate air A* steering and hazardous-terrain escape searches remain separate owner work and must remain visible in audit reporting.
- No wall-clock speedup, release readiness, cross-platform determinism, or successful test execution is established by this review. Use the actual build, continuation, checksum, and Callgrind artifacts, with omitted platforms stated explicitly.
- The pre-existing genuinely null-game building query path still dereferences game counters; do not infer tested map-only building-query support from the delay-zero configuration branch.
