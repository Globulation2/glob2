#include "/Users/bradley/.codex/worktrees/1cb7/glob2/src/map/gradient/GradientExecutionAudit.h"
#include <memory>
#include <cassert>
int main() {
 for(unsigned attempt=0;attempt<128;++attempt) {
  auto audit=std::make_unique<GradientExecutionAudit>();
  std::atomic<bool> entered{false};
  std::thread worker([&] {
   GradientExecutionAudit::record(GradientExecutionAudit::Kind::Seed);
   entered.store(true,std::memory_order_release);
   for(unsigned i=0;i<10000;++i) GradientExecutionAudit::record(GradientExecutionAudit::Kind::Propagation);
  });
  while(!entered.load(std::memory_order_acquire)) std::this_thread::yield();
  assert(audit->totals().other>0);
  audit.reset(); worker.join();
 }
}
