# Existing Callgrind baseline

Source: `dd493d7e71d21e5ab6cbaee0fe168a37e076860a`. This predates the feature and later master changes. These are existing release instruction counts; no new performance evaluation was run for this PR.

Stock Playground, 128x128, eight Nicowar players, seed 713, eight compute participants. Ubuntu 22.04 ARM64, GCC 11.4, release `-O3 -g`, Valgrind 3.18.1.

| Window | Owner instructions | All-thread instructions | Owner share |
| --- | ---: | ---: | ---: |
| 24,000-tick save, 1024 measured ticks | 2,137,401,920 | 5,637,051,772 | 37.9% |
| 12,000-tick save, 1024 measured ticks | 2,094,535,599 | 5,370,689,655 | 39.0% |

## Estimated feature ownership

Rounded source-based allocation with code inspection; several percentage points uncertainty. These are not literal inclusive function measurements.

| Feature | Estimated owner instruction share |
| --- | ---: |
| Routing and gradient maintenance | 35% |
| Building economy and live job assignment | 18% |
| Immutable snapshots and boundary publication | 13% |
| Simulation compatibility checksums | 12% |
| Fixed-capacity entity traversal and integrity | 11% |
| Remaining unit behavior/combat/medical logic | 4% |
| Visibility and exploration | 2% |
| Scheduling/orders/telemetry/remaining work | 5% |

## Exclusive source attribution

Mutually exclusive source buckets. Coordinate attribution is a lower bound; inlined operations can be attributed to surrounding statements. Bulk operations, vector operations, allocation and reference counting are implementation categories, rather than independent features. They must not be added to the feature percentages above.

| Source operation/category | 24k window | 12k window |
| --- | ---: | ---: |
| Other gradient relaxation/frontier/seeding/terrain work | 26.37% | 24.27% |
| Building/material demand/state logic | 15.10% | 16.31% |
| Other owner bookkeeping/control/runtime | 11.12% | 11.25% |
| Capacity slot iteration and null tests | 9.81% | 10.01% |
| Direct entity/stat checksum arithmetic | 8.46% | 8.87% |
| Bulk copying and zeroing | 4.36% | 4.45% |
| Vector operations attributed to STL headers | 4.35% | 4.40% |
| Other map queries and map maintenance source work | 3.30% | 3.72% |
| Explicit coordinate wrapping and row/index arithmetic | 3.16% | 2.87% |
| Snapshot packing and bookkeeping in project source | 2.88% | 2.78% |
| Other statistics source work | 2.57% | 2.63% |
| Explicit gradient neighbor row pointer construction | 2.16% | 1.86% |
| Other unit state and action source work | 1.90% | 2.27% |
| String implementation and strlen | 1.80% | 1.87% |
| Heap allocator implementation | 1.23% | 1.30% |
| Shared ownership and reference count implementation | 1.19% | 0.91% |
| Other team integrity checks | 0.22% | 0.24% |

## Interpretation and limits

The owner still performed substantial seed/propagation/frontier work, despite worker pipelines already existing. The implementation targets those synchronous cold, demand-extension, refresh and escape-maintenance paths. That work moves to workers and may become more expensive in total because fields are complete. Fixed deadlines can introduce waits; instruction shares do not establish latency or speedup.

Snapshots, checksums, entity-capacity traversal, live economy decisions, bounded steering and local validation remain owner work. Later master improvements already affect some baseline categories. Immediate air A* and hazardous-terrain escape remain separately identified owner operations in this PR. Stock Playground need not exercise custom-flight destination searches heavily.

Optimized function labels/inclusive contexts were unreliable in these dumps. Analysis uses terminal instruction totals and exclusive source/line attribution. Native and profiled final checksums matched in both original windows. Raw traces and partition inputs are included for review. The original scripts retain their `artifacts/sim-callgrind` relative-path convention.
