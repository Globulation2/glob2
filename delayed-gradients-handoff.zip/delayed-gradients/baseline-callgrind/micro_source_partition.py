import json,collections
from pathlib import Path

def classify(r):
 f,l,n=r['file'],r['line'],r['function']
 if (f.endswith('/Team.cpp') and l in [96,98,99,123,125,126]) or (f.endswith('/TeamStep.cpp') and l in [351,353,354,469,471]):return 'Capacity slot iteration and null tests'
 if (f.endswith('/map/Map.h') and l in [431,437,443]) or (f.endswith('/GradientRelaxation.h') and 157<=l<=163):return 'Explicit coordinate wrapping and row/index arithmetic'
 if f.endswith('/GradientRelaxation.h') and 221<=l<=223:return 'Explicit gradient neighbor row pointer construction'
 if any(x in f for x in ['memcpy.S','memset.S','string_fortified.h']):return 'Bulk copying and zeroing'
 if f.endswith('/ChecksumStream.h') or (f.endswith('/UnitSerialization.cpp') and l>=413) or (f.endswith('/building/Misc.cpp') and l>=551) or (f.endswith('/TeamSerialization.cpp') and l>=429):return 'Direct entity/stat checksum arithmetic'
 if 'malloc.c' in f:return 'Heap allocator implementation'
 if 'shared_ptr_base.h' in f or 'ext/atomicity.h' in f:return 'Shared ownership and reference count implementation'
 if any(x in f for x in ['basic_string.h','basic_string.tcc','char_traits.h','strlen_asimd.S']):return 'String implementation and strlen'
 if '/src/field/' in f or '/src/map/gradient/' in f or f.endswith('/arm_neon.h'):return 'Other gradient relaxation/frontier/seeding/terrain work'
 if '/src/building/' in f:return 'Building/material demand/state logic'
 if f.endswith('/Team.cpp') and 90<=l<=134:return 'Other team integrity checks'
 if '/src/engine/sim/snapshot/' in f:return 'Snapshot packing and bookkeeping in project source'
 if '/src/team/stats/' in f:return 'Other statistics source work'
 if '/src/unit/' in f:return 'Other unit state and action source work'
 if '/src/map/' in f:return 'Other map queries and map maintenance source work'
 if 'stl_vector.h' in f or 'vector.tcc' in f:return 'Vector operations attributed to STL headers'
 return 'Other owner bookkeeping/control/runtime'

out={'caveat':'Exclusive source-attribution partition, not measured hardware operation counts. Inlined operations can be attributed to surrounding statements. Some categories are operation kinds and some source-level remainder categories. Two coordinate categories are explicit lower bounds. Bulk copying includes inlined fortified memcpy/memmove and libc implementations. No inclusive function costs used.', 'profiles':{}}
for name in ['owner24k','owner12k']:
 p=json.load(open(f'artifacts/sim-callgrind/{name}.json'));t=p['self_total'];c=collections.Counter(); evidence=collections.defaultdict(list)
 for r in p['lines']:
  b=classify(r);c[b]+=r['ir'];evidence[b].append(r)
 out['profiles'][name]={'total_ir':t,'buckets':[{'bucket':b,'ir':v,'percent':round(v/t*100,4),'top_source_lines':sorted(evidence[b],key=lambda r:r['ir'],reverse=True)[:8]} for b,v in c.most_common()]}
 print(name)
 for b,v in c.most_common():print(f'{v/t*100:6.2f}% {b}')
Path('artifacts/sim-callgrind/micro_source_partition.json').write_text(json.dumps(out,indent=2))
