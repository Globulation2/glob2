#!/usr/bin/env python3
"""Correctness-only sequential continuations; no performance measurements."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import shutil
import subprocess
import sys

ROOT = Path(os.environ.get('GLOB2_CONTINUATION_ROOT',Path(__file__).resolve().parents[3])).resolve()
OUT = Path(os.environ.get('GLOB2_CONTINUATION_OUTPUT',Path(__file__).resolve().parent)).resolve()
BINARY = Path(os.environ.get('GLOB2_CONTINUATION_BINARY',ROOT / 'build/darwin/client/debug/dev-dev_fast-true-linker-auto/src/glob2')).resolve()
INPUT_DIR = Path(os.environ.get('GLOB2_CONTINUATION_SAVES',Path(__file__).resolve().parent)).resolve()
SAVES = {tick: INPUT_DIR / f'midgame-{tick}.game.gz' for tick in (12000,24000)}
TAIL = int(os.environ.get('GLOB2_CONTINUATION_TAIL','256'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    if not BINARY.is_file():
        raise SystemExit('Build this checkout CLI first: python3 tools/dev_build.py build/darwin/client/debug/dev-dev_fast-true-linker-auto/src/glob2 -j2')
    provenance = {'purpose': 'correctness only; no wall-clock comparison', 'platform': platform.platform(),
                  'machine': platform.machine(), 'head': git('rev-parse', 'HEAD').strip(),
                  'base': os.environ.get('GLOB2_CONTINUATION_BASE') or git('rev-parse', 'origin/master').strip(),
                  'status': git('status', '--short'), 'binary': str(BINARY),
                  'binary_sha256': sha(BINARY), 'compiler': subprocess.check_output([os.environ.get('CXX','c++'),'--version'],text=True),
                  'build': os.environ.get('GLOB2_CONTINUATION_BUILD','PYTHONPATH="$PWD" python3 tools/dev_build.py build/darwin/client/debug/dev-dev_fast-true-linker-auto/src/glob2 -j2'),
                  'flags': 'dev_fast=1 -O0 -g1; no release performance claim', 'tail_ticks': TAIL,
                  'commands': [], 'inputs': {}}
    (OUT / 'tested-source.patch').write_text(git('diff', '--binary', 'HEAD'))
    paths = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=ROOT).split(b'\0')
    manifest = {}
    for raw in sorted(set(paths)):
        if not raw: continue
        name=os.fsdecode(raw)
        if name.startswith('.playwright-mcp/'): continue
        path=ROOT/name
        if path.is_file(): manifest[name]=sha(path)
    (OUT/'source-manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    provenance['source_manifest_sha256']=sha(OUT/'source-manifest.json')
    comparisons=[]
    for tick, original in SAVES.items():
        saved=OUT/f'midgame-{tick}.game.gz'
        if original.resolve()!=saved.resolve() and not saved.exists(): shutil.copyfile(original,saved)
        provenance['inputs'][str(tick)]={'original':str(original),'copy':saved.name,'sha256':sha(saved)}
        expected=None
        for participants in (1,2,4,8):
            destination=OUT/f'{tick}-participants-{participants}'
            command=[str(BINARY),'game','run','--load-game',str(saved),'--ticks',str(tick+TAIL),
                     '--compute-threads',str(participants),'--telemetry','checksums','--write-replay',
                     '--save','final','--output-dir',str(destination)]
            provenance['commands'].append(shlex.join(command))
            (OUT/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
            destination.mkdir(exist_ok=True)
            print(f'Running tick {tick} participants {participants}',flush=True)
            with (destination/'console.log').open('w') as log:
                result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
            if result.returncode:
                raise SystemExit(f'Continuation failed ({result.returncode}): {destination}/console.log')
            traces=list(destination.glob('*.checksums'))
            if len(traces)!=1: raise SystemExit(f'Expected one checksum trace, found {traces}')
            trace=traces[0]
            result_json=json.loads((destination/'result.json').read_text())
            if result_json['ticks']!=tick+TAIL: raise SystemExit(f'Wrong final tick: {result_json["ticks"]}')
            hashes={p.name:sha(p) for p in destination.iterdir() if p.is_file() and (p.name.endswith('.checksums') or p.name in ('final.game.gz','game.replay'))}
            content=trace.read_bytes()
            if expected is None: expected=content
            if content!=expected:
                raise SystemExit(f'Per-tick mismatch: tick {tick} participants {participants}')
            comparisons.append({'initial_tick':tick,'final_tick':tick+TAIL,'participants':participants,
                                'trace':str(trace.relative_to(OUT)),'trace_lines':len(content.splitlines()),
                                'initial_checksum':result_json['initialChecksum'],'final_checksum':result_json['finalChecksum'],
                                'hashes':hashes,'matches_participants_1':True})
            (OUT/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n')
            print(f'PASS tick {tick} participants {participants}: {len(content.splitlines())} trace lines',flush=True)
    (OUT/'SUCCESS').write_text('Both mid-game inputs match per-tick checksum traces across participants 1, 2, 4, 8.\n')

if __name__=='__main__': main()
