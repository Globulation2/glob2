# Delayed Air Distance Fields

Status: technical design and implementation plan. This document does not implement engine behavior.

## Background and motivation

The simulation uses distance information for two different decisions: choosing a destination and choosing the next movement step. Flying units need both. They choose among food, healing, training, recruitment, resource, clearing and guard destinations, then steer toward the chosen target while respecting current movement rules.

On terrain that leaves flight unrestricted, many point-distance decisions use inexpensive geometric formulas. When terrain changes flight access, speed or damage, the current destination-ranking code can construct an `AirDistanceField`. This is an incremental Dijkstra search: it allocates map-sized distance and settled arrays, starts from a unit or destination, and expands its frontier as candidate distances are requested. Candidates share a frontier within one selection operation, but subsequent operations can construct another search. Some resource and painted-area selectors also enumerate the entire map even when the distance calculation itself uses a geometric fast path.

These computations run on the simulation owner. They can therefore retain map-sized work on the critical simulation path after shared ground gradients have moved to delayed background publication. Their activation depends on terrain and unit capabilities; they should not be assumed to dominate a stock Playground profile.

The existing field system already provides weighted propagation, efficient bucket frontiers, immutable snapshot inputs, worker scratch, bounded admission, fixed publication deadlines and saveable private outputs. Air destination guidance should extend that machinery. A second independent search framework or worker pool is unnecessary.

The intended result is that the simulation owner reads complete published air guidance, performs candidate selection and live eligibility checks, and requests missing guidance without constructing or extending a distance frontier. Immediate A* steering remains a separate owner operation.

## Decisions

1. Publish air distances in the same 16-bit gradient representation as shared ground fields.
2. Extend the existing field kernels and gradient publication pipeline. Use the existing `ComputeExecutor` and its worker pool.
3. Build complete private outputs from immutable snapshots. Publish at predetermined simulation boundaries, regardless of physical completion time.
4. Share fields rooted at destinations where their semantics permit it. Use complete delayed destination-selection jobs for genuinely unit-specific choices.
5. Distinguish Pending from a completed unavailable result. Preserve needs and existing assignments while guidance is pending.
6. Retain live destination validation and existing immediate A* steering. No owner search serves as a fallback for missing destination guidance.
7. Treat delayed visibility and the new finite air-distance range as simulation-rule changes.

## Scope

| Included | Treatment |
| --- | --- |
| Building recruitment and service distance calculations | Shared fields rooted at the existing destination specification |
| Resource and supplier destination selection | Shared multi-source fields where eligibility is shared; delayed private selection otherwise |
| Guard and clearing destination selection | Shared fields where possible, with complete private selection for unit-specific exclusions |
| Goal enumeration, field initialization and cold terrain-plane construction | Worker computation from snapshot inputs |
| Current capacity, food budget, alliance, reservation and target validity checks | Owner checks using bounded local data or candidate lists |
| Unrestricted-flight point-distance formulas | Existing constant-time fast paths |

Immediate `airRoute` A*, local collision avoidance, flight movement execution and hazardous-terrain escape routing are outside this change. Their audit counters remain distinct so removing destination searches cannot conceal remaining owner pathfinding.

## Current code seams

- `src/field/AirPathfind.h`: incremental `AirDistanceField` and separate `airRoute` A* implementation.
- `src/team/TeamRouting.cpp`: air distances for healing, food and training candidate ranking.
- `src/building/Step.cpp`: recruitment and attraction distances, including reverse searches from a building.
- `src/unit/Unit.cpp`: material, clearing and guard goal enumeration and selection.
- `src/unit/UnitGeometry.cpp` and `src/map/pathfind/MapPathfindPoint.cpp`: immediate air steering that remains unchanged.
- `src/field/GradientPropagation.h`, `GradientRelaxation.h`, `GradientCosts.h`, `Grid.h` and terrain workspace helpers: common propagation infrastructure to extend.
- `src/map/gradient/SnapshotGradient.*`, `GradientPipeline.h` and `GradientRuntime.h`: immutable input preparation, scheduling and publication.
- `src/map/io/MapIO.cpp`: published fields, queued requests and completed unpublished results.

Integration should follow the final shared-gradient contract in the target branch. It must not revive synchronous cold getters or introduce a second publication timeline.

## Field representation and range

Use the existing encoding:

| Stored value | Meaning |
| --- | --- |
| `GRADIENT_FORBIDDEN`, zero | Blocked cell under this field's access policy |
| `GRADIENT_UNREACHABLE`, one | No supported route to an eligible goal in the completed bounded field |
| `GRADIENT_AT_GOAL` | Zero-cost goal or permitted approach seed |
| `GRADIENT_AT_GOAL - cost` | Reachable cell with the encoded travel cost |

Reuse the existing `COST_LIMIT` and the kernel's exact boundary rules. The current definition includes edge-cost headroom; do not substitute a guessed numeric limit based only on the width of `Uint16`.

Compute candidate additions and diagonal multiplication in at least 32-bit arithmetic. Check the supported cost range before converting to a stored value. Saturation must never create a cheap path, a goal, or a wrapped value. Terrain-profile validation must also verify that every admitted edge is compatible with the bucket ring and field encoding.

The old air search used 32-bit distances and could find routes beyond the shared gradient range. Such routes become unavailable to destination selection under this design. A completed unavailable result is not a proof that the underlying unbounded graph has no path. Pending remains a distinct state and never uses the unavailable sentinel as a placeholder field.

Storage consistency does not require changing travel-distance rounding. Decode the gradient to a raw cost and preserve each air caller's existing conversion, including ceiling division where used today. Do not replace it automatically with `gradientTiles`, whose rounding may differ.

At 128 by 128 cells, a distance plane occupies 32 KiB. An optional 32-bit goal-label plane adds 64 KiB, making the pair 96 KiB. Those figures exclude traversal inputs, queue scratch, metadata and retained generations.

## Traversal and propagation

Introduce an explicit air traversal profile supplying passability and cardinal/diagonal entry costs from immutable terrain observations. Do not model air as an invented swim class: water access and air access are different policies, and their array bounds and saved identities must remain clear.

Extend the existing terrain-weighted 16-bit kernel with the narrow policy seam needed for air. Reuse geometry, bucket queues, cost compilation, scalar/SIMD selection and worker scratch. Preserve existing ground specializations rather than forcing all callers through a general virtual interface. Select an existing supported bucket size greater than the largest admitted edge; keep that choice outside the cell loop.

The first implementation may use the existing CPU backend for the new air profile. Add SIMD or accelerator dispatch only where that backend can represent the same access, edge and label semantics exactly. Backend selection must not change publication timing or values.

### Reverse edge costs

The field propagates backward from destinations. If the forward move `u -> v` costs the price of entering `v`, reverse relaxation must use:

```text
distance[u] = min(distance[u], distance[v] + forwardCost(u -> v))
```

Charge the appropriate cardinal or diagonal entry cost of `v`. Charging the predecessor instead reverses terrain-speed preferences. Preserve the existing destination-ranking cost policy; do not automatically substitute A*'s hazard-aware route cost for a caller that currently ranks by flight travel time.

### Goal and source policies

Preserve the exact goal specification used by each caller. Building top-left coordinates, midpoints, footprint access and flag ranges are distinct specifications. The initial conversion must not normalize them all to a new entrance policy.

A passable exact destination seeds its own cell. Where the current search approaches a blocked destination through adjacent passable cells, seed those cells at the corresponding existing approach cost. Keep this policy explicit in the key and capture specification.

Some source-rooted callers currently allow leaving a blocked starting cell. Preserve that behavior with a bounded read of adjacent published values and the appropriate outgoing costs. Other callers require a passable source and retain that restriction. No local exception may start a frontier.

For unrestricted terrain, preserve existing caller metrics. Resource and painted-area selection currently have geometric fast paths that may differ from terrain-weighted octile distance. Worker goal enumeration must retain the applicable metric; moving work off owner must not silently convert Chebyshev or Euclidean ranking into octile ranking.

## Sharing and destination selection

### Building distance fields

Initially use a field for each destination specification and air movement profile. All compatible flyers can read their cost at their current cell. Recruitment can query the same destination-rooted field for multiple candidate units.

Keep owner loops over eligible candidate buildings. They already apply service type, happiness, travel budget, alliance, capacity and other preferences. A combined nearest-hospital or nearest-inn field would lose information needed by those decisions and is not required for the first implementation.

### Resource and painted-area fields

Where all readers share eligibility, use a multi-source field with an optional goal-label plane. A query returns the distance and the actual resource, supplier or painted goal to pursue.

Propagate and compare the pair `(cost, goalRank)`. Goal rank must reproduce the caller's existing deterministic tie-break, including its candidate scan order. Internal field indexing must not choose a different winner. Equal-cost label improvements must propagate correctly and produce identical results under scalar, SIMD and different queue orders.

Keys must capture team visibility, material identity, supplier mode, consumer exclusion and any other condition that changes the goal set. Do not share a field between consumers with different eligibility merely because they request the same material.

### Unit-specific choices

Clearing claims and some consumer exclusions depend on the querying unit, its position or the cost of its alternative. One shared nearest-goal label cannot always reproduce these decisions. A fixed top-K list cannot guarantee that an eligible alternative remains represented.

Use a complete private destination-selection job for these cases. It captures the unit identity, source, selection policy and immutable world; enumerates and ranks candidates on a worker using the common field kernel or the existing unrestricted geometric metric; and publishes a selected goal and bounded cost at the fixed deadline. Its scratch frontier is never published.

If the unit changes its relevant assignment or source before publication, supersede the request using an explicit query epoch. The owner revalidates a published choice against the live unit and destination. An invalid choice triggers a new request and Pending, not an owner search or an assertion that no alternative exists.

## Public APIs and ownership

Use stable family-specific keys and the shared readiness vocabulary. Conceptual interfaces are:

```cpp
FieldReadiness requestAirField(const AirFieldKey&);
PublishedAirField lookupAirField(const AirFieldKey&) const;
RouteResult queryAirDistance(const AirFieldKey&, Position, AirCost*);
RouteResult queryAirDestination(const AirFieldKey&, Position, AirGoalSample*);
```

`AirCost` is a decoded bounded cost, not a published 32-bit plane. `PublishedAirField` owns a read-only lease, readiness, capture revision and the metadata required to interpret the result. It has no implicit boolean conversion. A pending refresh may coexist with a Ready published generation.

Request enrollment is an owner operation. Const lookup cannot allocate, mutate recency, enqueue, or compute. Worker consumers read captured leases. Requests derived from worker proposals are committed by the owner in stable logical order, never in physical completion order.

Keys identify the world, field family, movement and metric profile, team or visibility policy, destination specification, and applicable consumer/supply identity. Building and unit references include script identity, so slot reuse cannot redirect a pending result. Positions and ranges that define a destination belong to a hard epoch or normalized goal specification. A flyer's current position is not part of a shared destination-field key.

## Scheduling and publication

Extend the existing gradient pipeline with air field and complete air-choice payload adapters. Reuse its executor submissions, immutable snapshot leases, admission counters, deadlines, ordered publication, errors and save lifecycle. No new pool or independent tick phase is introduced.

1. A miss enrolls one deduplicated metadata request and returns Pending.
2. Owner admission reserves logical job and byte budgets in stable FIFO order.
3. Admission captures immutable inputs and assigns publication at the existing advance boundary plus configured delay K.
4. A worker initializes every output and cold traversal plane, enumerates goals, and completes propagation or selection privately.
5. At the assigned boundary, owner joins due work, validates identity and hard epoch, and publishes in reservation order.
6. Consumers use complete guidance and perform live eligibility and safety checks.

Use the existing configured gradient delay initially. K begins at admission/capture, so backlog adds queue wait before K. Early completion remains invisible; late completion waits at the same logical boundary. Serial execution runs the same logical jobs and preserves the same publication trajectory.

Only demanded or plausibly prewarmed fields refresh. Periodic refresh and cold demand share deterministic coalescing and admission, so neither receives an unbounded priority stream that starves the other. Bound choice-request metadata by live unit/query slots and shared-field metadata by the supported destination and policy inventory.

Hard changes supersede old tickets and invalidate incompatible published guidance. Soft terrain, visibility, resource or supplier changes retain usable complete guidance, mark it dirty, and coalesce a subsequent refresh. Do not cancel every in-flight job or require its captured topology to equal the live topology before publication. Preserve dirty changes that arrived after capture.

## Consumer behavior

| Situation | Required action |
| --- | --- |
| Cold field or choice is Pending | Preserve the need or existing assignment and retry on its normal decision cadence |
| Complete reachable result | Apply the existing ranking rules and validate current eligibility |
| Complete bounded unavailable result | Apply the unavailable policy for this captured generation |
| Goal is no longer eligible | Request refresh and defer; no owner search |
| Unit has changed assignment or was deleted/reused | Discard incompatible choice results |
| Current local movement is blocked | Existing steering and safety logic handle the step independently |

Hunger, health, death, combat interruptions and reservation cleanup continue while waiting. Readiness checks precede any direction-selection RNG. A reservation is made only after a candidate is accepted, and Pending never releases an existing reservation merely because its route is temporarily absent.

## Memory and cache lifecycle

Charge known output and label bytes plus admitted job slots using deterministic logical budgets. Validate platform support before the match; allocation failures use the existing session error path. Physical completion, reference counts, free memory and elapsed time cannot select admission or publication ticks.

Use stable key/epoch resolution at publication. Do not retain pointers into evictable associative entries. Published generations are immutable and remain alive while consumers or snapshots hold leases. A newly published requested result must receive its required consumer opportunity before eviction; otherwise a tight cache can repeatedly destroy a result before its requester reads it.

Reducing a budget must leave a self-loadable state. Retained leases and outstanding tickets either delay the effective reduction or remain explicitly accounted for. Cache pressure returns Pending and defers admission; it cannot create an unavailable placeholder or trigger synchronous computation.

## Saves and simulation compatibility

Saving completes private jobs without publishing early. Persist published fields and labels, stable keys and hard epochs, FIFO request order, completed unpublished outputs with remaining advances, complete unit-choice results, and logical retention state needed for continuation.

Older supported saves restore no air cache and enroll new fields deterministically on first demand. This is a versioned transition to the new simulation policy; old-binary trajectories are not expected to remain identical. Saving an active new-format session must preserve its continuation exactly, including Pending state and reservations.

Add explicit encoding gates and malformed-count/key/deadline validation. Do not change `MINIMUM_VERSION_MINOR`. Update the simulation revision, replay acceptance, network/simulation identity and golden verification record as appropriate to the final encoding and landing sequence. Hash logical request/publication state where required; never hash worker progress or completion time.

## Implementation sequence

### Change A Air profile and bounded kernel

Add the air traversal/metric and goal policies to the common 16-bit kernel. Preserve ground specializations and use the existing bucket and scratch infrastructure. Add bounded decoding/conversion helpers and reference tests against the old air search. Keep the old implementation as a test oracle until migration is complete.

Acceptance: identical in-range costs for the same frozen inputs, exact boundary encoding, deterministic labels, no arithmetic overflow, and unchanged ground-kernel outputs.

### Change B Shared building air fields

Add stable air keys, leases and job adapters to the existing pipeline. Convert recruitment and food/healing/training ranking to published distance reads, preserving each caller's goal policy and ranking order. Add cold Pending, stale refresh, assignment and reservation behavior.

Acceptance: no owner air-distance initialization or expansion for converted building decisions, and identical publication trajectories across participant counts.

### Change C Resource and painted destinations

Add goal labels and snapshot goal enumeration for shared material, supplier, guard and clearing policies. Convert unit-specific exclusions to complete delayed choice jobs. Preserve live validation and deterministic tie-breaks. Retain immediate A* and geometric point fast paths.

Acceptance: owner performs no map-sized destination enumeration for converted selectors; eligibility and alternative selection remain correct for captured inputs; stale choices retry without owner searches.

### Change D Persistence and lifecycle completion

Finish save gates, FIFO/deadline hashing, hard identity validation, soft-dirty follow-up, cache retention and budget transitions. Remove migrated production uses of `AirDistanceField` after auditing every caller. Update affected architecture and test guides.

Acceptance: binary/text continuation and supported old-save loading pass; no hidden synchronous fallback remains in converted selectors.

Each separately landed behavior-changing change requires its own appropriate simulation boundary and golden fixture. A single coherent PR can use one final version boundary, while keeping intermediate commits unlanded until live consumers handle Pending throughout.

## Verification

Use focused correctness suites and Callgrind instruction attribution. Do not use wall-clock performance comparisons while the development machine is shared. Final instruction evidence uses release flags; fast development builds serve editing and correctness checks.

Required cases:

- Forward reference versus reversed field on asymmetric flight speeds, diagonal steps, no-fly barriers, rectangular and thin wrapped maps, and blocked sources/goals under each policy.
- Finite costs below, at and beyond the actual field limit; long reachable routes that the old wide search accepted; overflow-resistant candidate addition.
- Existing air rounding and unrestricted geometric metrics, including equal-cost candidate ties and stable goal labels.
- Multi-source eligibility by team, visibility, material, supplier mode and consumer identity; no-source versus Pending.
- Unit-specific clearing claims where several nearest candidates are excluded, proving that a fixed alternative list is not silently relied upon.
- Cold deduplication, FIFO saturation, early/late completion, hard supersession/deletion/slot reuse, repeated soft dirtiness and follow-up refresh.
- Hungry and injured flyers retaining need, assignment and reservations through Pending; normal interruptions and deletion cleanup still execute.
- Tight budgets with several active consumers, unpublished outputs, unread published results, retained leases and a reduced budget.
- Binary and text saves across cold, queued, computing, completed unpublished, published, superseded and waiting-choice states, compared with uninterrupted per-tick checksums.
- Identical setup/orders and per-tick checksums with 1, 2, 4 and 8 participants, varied worker completion order, and affected platform coverage.
- Updated replay/network acceptance and golden match verification.

Kernel auditing must cover output initialization, cold air-plane construction, distance expansion, and goal enumeration. With workers configured, owner entries for those operations must be zero. Explicit serial execution is the documented exception with identical logical publication. Immediate A* and terrain-safety counters remain separate and may be nonzero.

Callgrind evidence should report owner instructions removed, additional worker instructions and the remaining immediate A* cost separately. Report queue latency, retained memory and deadline waits independently when their instrumentation is available. Instruction changes alone do not establish a wall-clock speedup.

## Completion criteria

The change is complete when all converted air destination selectors use complete delayed guidance or complete delayed choices; their owner path contains no map-sized initialization, enumeration or frontier expansion; finite range and selection semantics are explicit and tested; publication is independent of physical execution; saves preserve continuation; and immediate A* remains clearly identified as remaining owner work.
