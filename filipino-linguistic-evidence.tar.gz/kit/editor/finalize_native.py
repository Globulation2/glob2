import importlib.util,json,hashlib,shutil
from pathlib import Path
spec=importlib.util.spec_from_file_location('program','tools/localization/translation_program.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
r=Path('artifacts/filipino-localization');m=json.loads((r/'manifest.json').read_text());path=r/'drafts/fil/texts.fil.txt'; native,errors=p.CHECKER.read_table(path);assert not errors,errors
edits=json.loads((r/'editor/native-edits.json').read_text()); assert not set(edits)-set(native),set(edits)-set(native)
before=native.copy();native.update(edits)
keys=(r/'source/native-keys.txt').read_text().splitlines();path.write_text(''.join(k+'\n'+native[k]+'\n' for k in keys))
hashes=p.batch_target_hashes(m,p.catalog_paths(r,'fil'));rp=r/'linguistic/language-editor-record.json';record=json.loads(rp.read_text());record['state']='Native complete; online pending';record['native_catalog_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
for b in record['batches']:
 if b['id'].startswith('native-'):
  assert b['status'].startswith('read;'),b['id'];b['status']='editorial pass complete; final reviewer recheck pending';b['edited_keys']=b['expected_keys'];b['target_sha256']=hashes[b['id']]
rp.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');shutil.copyfile(path,r/'editor/native-editor.txt')
f=json.loads((r/'linguistic/native-meaning-first-pass.json').read_text());res=[]
for x in f['findings']:
 k=x['key'].split(':',1)[1]; assert before[k]!=native[k],f"Finding not changed: {k}"
 res.append({**x,'state':'edited; independent recheck pending','final_target':native[k]})
(r/'editor/native-meaning-resolutions.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'catalog_sha256':record['native_catalog_sha256'],'native_editorial_keys':sum(len(b['edited_keys']) for b in record['batches']),'changed_entries':sum(before[k]!=v for k,v in native.items()),'meaning_findings_edited':len(res)}))
