import json
from pathlib import Path
r=Path('artifacts/filipino-localization');snap=json.loads((r/'editor/native-general-003.read.json').read_text());changes={
'[AICastor-Profile]':{
'Pinag-aaralan ang hydration, paglago ng pinagkukunan ng pagkain, mga balakid at abot ng manggagawa.':'Sinusuri ang kahalumigmigan, muling pagtubo ng pagkain, mga sagabal, at mga lugar na naaabot ng manggagawa.',
'Namamahala sa pagpapalawak ng pagkain, mga pag-upgrade at depensa kasabay ng produksyon.':'Pinamamahalaan ang pagpaparami ng pagkain, mga upgrade, at depensa kasabay ng paglikha ng yunit.',
'mga dating nakikita at naa-access na gusali':'mga gusaling dati nang nakita at naaabot',
'ipinagpapalit ang maagang presyon para sa isang maunlad na base at mas malakas na tropa':'inuuna ang maunlad na base at mas malalakas na tropa kaysa sa maagang pag-atake',
'Makipagkumpitensya sa pagpapalawak nang maaga.':'Agad hadlangan ang pagpapalawak nito.'},
'[AICortex-Profile]':{
'palaguin ang isang ekonomiyang nagtatrabaho at gawing pagkain, teknolohiya, at presyur ng militar ang ekstrang paggawa':'palaguin ang gumaganang ekonomiya at gamitin ang sobrang manggagawa sa pagkain, teknolohiya, at pagdiin sa kalaban',
'Pinipigilan ng problema sa pagkain ang pagpapalawak at paggastos sa teknolohiya.':'Binabawasan ang pagpapalawak at paggastos sa teknolohiya kapag kapos sa pagkain.',
'Nagdaragdag ng paglangoy kapag ang pag-access sa tubig ay malaking tulong.':'Nagdaragdag ng pagsasanay sa paglangoy kapag malaking tulong ang pagtawid sa tubig.',
'na may mga pasulong na panuluyan at ospital':'gamit ang mga panuluyan at ospital malapit sa labanan',
'Pangako at mga emerhensiya: Nagsasagawa ng opensiba sa pamamagitan ng maliliit na panliligalig sa halip na paulit-ulit na pagmartsa pauwi.':'Pagpapatuloy ng atake at mga emerhensiya: Ipinagpapatuloy ang opensiba sa kabila ng maliliit na panggugulo sa halip na paulit-ulit na umuwi.',
'Ang mga malubhang pag-atake ay maaaring magpabalik sa mga tagapagtanggol.':'Maaaring pabalikin ang mga tagapagtanggol kapag malubha ang pag-atake sa base.',
'produksyon na para lamang sa mga mandirigma at isang ospital':'paglikha lamang ng mandirigma at pagtatayo ng ospital',
'mas maliit na pag-atake ng desperasyon':'mas maliit na desperadong pag-atake',
'Mas nakatuon sa suporta sa pasulong kaysa sa Warrush.':'Mas inuuna ang suporta malapit sa labanan kaysa kay Warrush.',
'Mas malayo ang ginagawa ni Maxima sa pagbabadyet ng mga napapanatiling panganganak, pagsasanay, at pag-deploy laban sa tinantyang lakas ng kaaway.':'Mas masusi si Maxima sa paglalaan ng suplay para sa patuloy na paglikha, pagsasanay, at pagpapadala ng yunit ayon sa tinatayang lakas ng kaaway.',
'Ang mga imprastraktura sa unahan ay dapat manatiling may suplay':'Kailangang tuloy ang suplay sa mga gusaling malapit sa labanan',
'Susubukang kontra-atake: Paglalabanan ang mga pasulong na panuluyan, ospital, at mga mapagkukunan ng pagkain.':'Kontra-estratehiyang susubukan: Hadlangan ang mga panuluyan, ospital, at pinagmumulan ng pagkain nito malapit sa labanan.',
'laban sa pagtulak nito':'laban sa paglusob nito',
'nagmasid na mga tropa ng kaaway':'mga tropa ng kaaway na nakita nito'},
'[AINicowar-Profile]':{
'Pagbubukas: Ang ipinadalang agresibong profile':'Simula: Ang kasamang agresibong profile',
'sa limang kabuuang yunit at nagpapahintulot sa digmaan sa limang mandirigma':'kapag may kabuuang limang yunit at nagpapahintulot umatake kapag may limang mandirigma',
'Inaayos ang mga tauhan ng pagkain':'Inaayos ang bilang ng tagasuplay ng pagkain',
'Sinusuri ang mga gusaling maaabot ng kaaway para sa mga pag-atake.':'Pumipili mula sa mga naaabot na gusali ng kaaway bilang target ng pag-atake.',
'mga rutang hinarangan ng mapagkukunan':'mga daang nahaharangan ng mga likas na yaman',
'Ibinabahagi ang maagang agresyon ng Warrush ngunit may mas maraming follow-through.':'Tulad ni Warrush, maagang umaatake ngunit mas malawak ang kasunod na pag-unlad nito.',
'Ang random na pagpili ng target ay maaaring maglaan ng pagsisikap sa mga hindi gaanong mahahalagang gusali.':'Dahil sapalaran ang pagpili ng target, maaaring masayang ang lakas nito sa mga gusaling hindi gaanong mahalaga.',
'Susubukang kontra-atake:':'Kontra-estratehiyang susubukan:',
'labanan ang pagpapalawak':'hadlangan ang pagpapalawak'},
'[AINone-Profile]':{'Isang nahuhulaang kalaban para sa mga eksperimento.':'Isang walang ginagawa at madaling mahulaang kalaban para sa mga eksperimento.'},
'[AINumbi-Profile]':{
'Una, bumubuo ng pagkain at populasyon':'Una, pinaparami ang pagkain at populasyon',
'Ang malawak na yugto nito ay sumusulong kasabay ng oras sa halip na kasabay ng pag-unlad ng kalaban.':'Umuusad ang mga pangunahing yugto nito batay sa oras, hindi sa pag-unlad ng kalaban.',
'Sinusukat ang lumalaking demand gamit ang populasyon':'Inaayon sa populasyon ang pangangailangan sa mga gusali',
'sa mga gusali ng kaaway na kinuhanan ng sample':'sa mga gusali ng kaaway na pinili mula sa isang sample',
'itinataas ang mga limitasyon para sa isa pang pagtatangka':'itinataas ang mga kundisyon bago muling umatake',
'mas maaga ang paglalapat ng presyon sa Nicowar':'mas maagang nanggigipit si Nicowar',
'pagkatapos ng walang patid na pagbuo':'matapos makapagpalakas nang walang sagabal',
'Maglapat ng presyon bago ang yugto ng militar nito. Magtanim ng pagkain at pagsasanay sa likod ng iyong mga pag-atake':'Gipitin ito bago ang yugto ng pakikidigma nito. Palawakin ang pagkain at pagsasanay habang umaatake ka',
'Ang rutina sa pag-atake nito ay direktang nagbabasa ng mga posisyon ng kalaban na naka-build nang walang visibility check.':'Direktang binabasa ng proseso nito sa pag-atake ang mga posisyon ng gusali ng kalaban nang hindi sinusuri kung nakikita ang mga ito.'},
'[AIEcono-Profile]':{
'Pagsasaka at conversion:':'Pagsasaka at pag-akit ng yunit:',
'mga nababagong pagkain at pinagmumulan ng kahoy':'mga pinagmumulan ng pagkain at kahoy na tumutubong muli',
'Ang mas mahusay na pagkain at prutas':'Ang mas masustansiyang pagkain at prutas',
'kung saan ang conversion ay nagbibigay ng isa pang anyo ng kompetisyon':'at nagiging isa pang paraan ng pakikipagkumpitensya ang pag-akit ng yunit',
'Ang mga panuntunan sa pagkain, prutas, heograpiya at tagumpay ay lubos na nakakaapekto sa mga oportunidad nito.':'Malaki ang epekto ng pagkain, prutas, heograpiya, at mga tuntunin sa panalo sa mga pagkakataon nito.',
'Ang presyon ay naglalantad sa pagpapalawak.':'Gipitin ang mga bago at lantad na bahagi ng kolonya nito.'},
'[AIWarrush-Profile]':{
'Kapag nakapag-ani na ang anim na yunit':'Kapag kaya nang umani ng anim na yunit',
'Ang ekstrang konstruksyon ay kadalasang napupunta sa mga ospital at pagsasanay sa paggalaw.':'Karaniwang ginagamit ang natitirang kakayahan sa pagtatayo para sa mga ospital at pagsasanay sa paggalaw.',
'Natuklasan ng mga marka ang mga gusali ng kaaway na may mga lugar ng bantay kaya patuloy na naglalapat ng presyon ang mga mandirigma.':'Minamarkahan ng mga bantayang lugar ang mga natuklasang gusali ng kaaway upang tuloy-tuloy na manggipit ang mga mandirigma.',
'tinatanggihan ang diskarte sa conversion ng Econo':'hindi ginagamit ang estratehiya ni Econo na mang-akit ng yunit',
'Pinarurusahan ang mabagal na pagbubukas':'Sinasamantala ang mabagal na pagsisimula',
'payat na suporta sa pagkain':'limitadong suporta sa pagkain',
'Kontra-atake na susubukan:':'Kontra-estratehiyang susubukan:',
'bumuo ng pagsasanay, pagkatapos ay kontra-atake':'paunlarin ang pagsasanay, saka gumanti ng atake',
'Ang pagbubukas ng mga bandila ng paggalugad ay direktang gumagamit ng mga lokasyon ng pagsisimula ng kaaway. Ang paglalagay sa lugar ng pag-atake sa ibang pagkakataon ay nangangailangan ng kakayahang makita.':'Direktang ginagamit ng mga unang bandila ng paggalugad ang mga panimulang lokasyon ng kalaban. Sa mga susunod na paglalagay ng lugar ng pag-atake, kailangang nakikita ang target.'},
'[AICabino-Profile]':{
'Ibinabahagi ang produksyon ng yunit':'Hinahati ang paglikha ng yunit',
'Paghihiwalayin ang mga tagapamahala ng mga yunit na humihiling at nagrereserba, sabay-sabay na pinapaunlad ang ekonomiya at militar.':'Magkakahiwalay na tagapamahala ang humihiling at nagrereserba ng mga yunit, kaya sabay na umuunlad ang ekonomiya at militar.',
'Nag-iiskawt ng prutas':'Naghahanap ng prutas',
'ayon sa availability at mga kalapit na kaaway':'ayon sa dami ng magagamit na yunit at mga kalapit na kaaway',
'isang kumpletong kuwartel':'isang tapos nang kuwartel',
'Nagkakalat ng mga pag-atake nang higit pa kaysa sa mga nakalap na pangkat ni Maxima':'Mas hinahati ang mga pag-atake kaysa sa pinagsama-samang mga pangkat ni Maxima',
'Ang pagsira sa pagkain at paggaling ay maaaring magpahina sa isang buong kolonya.':'Maaaring humina ang buong kolonya kapag nasira ang suplay ng pagkain at mga pasilidad sa pagpapagaling.',
'Susubukang kontra-atake:':'Kontra-estratehiyang susubukan:',
'i-concentrate ang mga tagapagtanggol':'tipunin ang mga tagapagtanggol',
'Pinsala ang pagkain o pagsasanay bago nito mapanatili ang ilang larangan.':'Sirain ang suplay ng pagkain o mga pasilidad sa pagsasanay bago nito masuportahan ang maraming larangan ng labanan.'}}
pending_path=r/'editor/native-edits.json';pending=json.loads(pending_path.read_text())
for k,repls in changes.items():
 v=snap[k]
 for old,new in repls.items():
  assert old in v,(k,old)
  v=v.replace(old,new)
 pending[k]=v
pending_path.write_text(json.dumps(pending,ensure_ascii=False,indent=2)+'\n')
