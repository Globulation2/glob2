import json,re,hashlib,shutil
from pathlib import Path
folder=Path('artifacts/filipino-localization');p=folder/'drafts/fil/fil.json'
c=json.loads(p.read_text());source=json.loads((folder/'source/online.json').read_text());overrides=json.loads((folder/'author/online-overrides.json').read_text());assert not(set(overrides)-set(source)),set(overrides)-set(source)

def subterm(text,pattern,word):
 return re.sub(pattern,lambda m:word[0].upper()+word[1:] if m[0][0].isupper() else word,text,flags=re.I)

def normalize(key,text):
 text=re.sub(r'\s+([.,;:!?])',r'\1',text)
 text=re.sub(r'([\[(])\s+',r'\1',text);text=re.sub(r'\s+([\])])',r'\1',text)
 text=re.sub(r'" ([^"\n]+) "',r'"\1"',text)
 text=re.sub(r'“\s+(.*?)\s+”',r'“\1”',text)
 text=re.sub(r'(\{[a-zA-Z][a-zA-Z0-9_]*\})\s+%',r'\1%',text)
 for a,b in re.findall(r'(\{[a-zA-Z][a-zA-Z0-9_]*\})(\{[a-zA-Z][a-zA-Z0-9_]*\})',key):
  text=re.sub(re.escape(a)+r'\s+'+re.escape(b),a+b,text)
 text=re.sub(r'(\{[a-zA-Z][a-zA-Z0-9_]*\})\s+(?:na\s+)?mga\s+',r'\1 ',text)
 for pattern,word in [(r'\b(?:eksplorador|explorers?)\b','tagapaggalugad'),(r'\b(?:swarm|swarms|kuyog|kulumpon)\b','pugad'),(r'\b(?:inns?|bahay-tuluyan)\b','panuluyan'),(r'\b(?:flags?|watawat)\b','bandila'),(r'\bunits?\b','yunit'),(r'\b(?:globs?|globules?|globo)\b','yunit'),(r'\b(?:balat)\b','skin'),(r'\b(?:kwarto|kuwarto)\b','silid'),(r'\btseke\b','pagsusuri'),(r'\bentablado\b','yugto'),(r'\bmakina\b','engine'),(r'\btiktik\b','tick'),(r'\btik\b','tick')]:
  text=subterm(text,pattern,word)
 if re.search(r'\bmatch(?:es)?\b',key,re.I) and not re.search(r'\b(?:not match|must match|match the|match this)\b',key,re.I):
  for pattern,word in [(r'\btugma(?:ng)?\b','laban'),(r'\bkatugma\b','laban'),(r'\bkapareha\b','laban'),(r'\bpagtutugma\b','laban')]:text=subterm(text,pattern,word)
 if 'instance' in key.lower():
  text=text.replace('pagkakataong ito','server na ito').replace('pagkakataon','server')
 if 'reconcil' in key.lower():
  text=text.replace('pagkakasundo','pagsasaayos').replace('pinagkakasunduan','inaayos ang tala ng').replace('pagtugmain','ayusin ang tala ng')
 if key.startswith('Reporting range:'):
  text='Saklaw ng pag-uulat: {slot0} hanggang {slot1} (UTC). Hindi pa tapos ang araw na ito; ang nakaraang {slot2} araw ay mga kumpletong araw sa kalendaryo. Maaaring hindi kumpleto ang kasaysayan; naitalang obserbasyon lamang ang ginagamit sa paghahambing.'
 if key.startswith('Current:'):text=text.replace('ngayon ay bahagyang','hindi pa kumpleto ang araw na ito')
 if key.startswith('Each product has its own credit unit.'):
  text=text.replace('ay nilagdaan','ay may positibo o negatibong halaga')
 if key.startswith('Signed HP'):text=text.replace('Lagdadong HP','HP na may positibo o negatibong halaga')
 if 'body' in key and any(word in key for word in ['blob','request','match record']):text=text.replace('katawan','nilalaman')
 text=text.replace('Globulasyon 2','Globulation 2').replace('Korteks','Cortex').replace('Kabino','Cabino')
 text=text.replace('may kapansanan','naka-disable').replace('May kapansanan','Naka-disable')
 text=text.replace('pagbili gamit ang studio credit','pagbili ng credit para sa Studio')
 text=text.replace('kredito sa lumikha','pagkilala sa lumikha')
 return text

changed=[]
for key,original in list(c.items()):
 value=overrides.get(key,original)
 if isinstance(value,dict):
  # Filipino nouns do not require an English singular/plural alternation.
  # Keep the counted meaning in every CLDR branch, including Filipino's broad one category.
  if key not in overrides:value={category:value.get('other',text) for category,text in value.items()}
  value={category:normalize(key,text) for category,text in value.items()}
 else:value=normalize(key,value)
 if value!=original:changed.append({'id':'online:'+key,'before':original,'after':value})
 c[key]=value
p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
snapshot=folder/'author/online-author.json';shutil.copyfile(p,snapshot)
record={'identity':'draft_editor','source_sha256':json.loads((folder/'manifest.json').read_text())['source_sha256'],
 'catalog_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'read_keys':['online:'+key for key in c],
 'method':'Read every English source key and every Google target value, including plural variants; checked ambiguous labels in source call sites and existing Indonesian/Hindi/Traditional Chinese references. Applied contextual corrections, shared terminology, and mechanical protected-span cleanup. Independent meaning review follows.',
 'context_sources':['platform/apps/web/src/admin/Finances.tsx','platform/apps/web/src/sets/Preview.tsx','platform/apps/web/src/sets/Library.tsx','platform/apps/web/src/skins/binaryAsset.ts','platform/apps/api/src/play/rooms.ts'],
 'changed':changed}
(folder/'author/online-author-review.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(len(c),len(changed),record['catalog_sha256'])
