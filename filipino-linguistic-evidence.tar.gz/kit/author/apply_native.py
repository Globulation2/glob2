import importlib.util,json,re,hashlib,shutil
from pathlib import Path
folder=Path('artifacts/filipino-localization')
s=importlib.util.spec_from_file_location('p','tools/localization/translation_program.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
p=folder/'drafts/fil/texts.fil.txt';n,errors=m.CHECKER.read_table(p);assert not errors,errors
source=json.loads((folder/'source/native.json').read_text())
overrides=json.loads((folder/'author/native-overrides.json').read_text())
unknown=set(overrides)-set(source);assert not unknown,unknown

def replacement(value,pattern,word):
 def sub(match):return word[0].upper()+word[1:] if match.group()[0].isupper() else word
 return re.sub(pattern,sub,value,flags=re.I)

def normalize(key,value):
 # Correct mechanical spaces introduced by protective HTML spans.
 value=re.sub(r'\s+([.,;:!?])',r'\1',value)
 value=re.sub(r'([\[(])\s+',r'\1',value)
 value=re.sub(r'\s+([\])])',r'\1',value)
 value=re.sub(r'(%\d+)\s+%',r'\1%',value)
 value=re.sub(r'\s*\\n\s*',r'\\n',value)
 for pattern,word in [
  (r'\bExploration Flags?\b','bandila ng paggalugad'),(r'\bWar Flags?\b','bandila ng digmaan'),
  (r'\bClearing Flags?\b','bandila ng paglilinis'),(r'\bTraining Camps?\b','kuwartel'),
  (r'\b(?:eksplorador|manggagalugad|explorers?)\b','tagapaggalugad'),
  (r'\b(?:swarm|swarms|kuyog|kulumpon)\b','pugad'),(r'\b(?:inns?|bahay-tuluyan)\b','panuluyan'),
  (r'\b(?:flags?|watawat)\b','bandila'),(r'\bunits?\b','yunit'),(r'\bbarracks\b','kuwartel'),
  (r'\bracetracks?\b','karerahan'),(r'\bsuppliers?\b','tagasuplay'),
  (r'\b(?:globs?|globules?|globo)\b','yunit'),(r'\bmerkado\b','pamilihan'),
  (r'\balgae\b','lumot'),(r'\beksplorasyon\b','paggalugad'),(r'\b(?:kwarto|kuwarto)\b','silid')]:
  value=replacement(value,pattern,word)
 if re.search(r'\bmatch(?:es)?\b',source[key],re.I):
  for pattern,word in [(r'\btugma(?:ng)?\b','laban'),(r'\bkatugma\b','laban'),(r'\bkapareha\b','laban'),(r'\bpagtutugma\b','laban')]:value=replacement(value,pattern,word)
 if 'Racetrack' in source[key]:value=re.sub(r'\bKarera\b','Karerahan',value)
 if key.startswith('[intro') or key.startswith('[lesson'):
  value=value.replace('Kawani','Pugad').replace('gutom na butil','gutom na yunit')
  value=value.replace('mas maagang pagsagip','mas maagang save')
 value=value.replace('mga kumbertido','mga yunit na lumilipat ng koponan').replace('mga kumberte','mga yunit na lumilipat ng koponan')
 if key.endswith('-Profile]'):
  value=value.replace('Kontra-dulang','Kontra-estratehiyang').replace('alon','pangkat')
 value=value.replace('Korteks','Cortex').replace('Kabino','Cabino')
 value=value.replace('nakakaantala sa serbisyo ng pagtatayo','pansamantalang pinapatigil ang serbisyo ng gusali')
 return value

changed=[]
for key,value in list(n.items()):
 target=normalize(key,overrides.get(key,value))
 if target!=value:changed.append({'id':'native:'+key,'before':value,'after':target})
 n[key]=target
p.write_text(''.join(key+'\n'+n[key]+'\n' for key in source),encoding='utf-8')
snapshot=folder/'author/native-author.txt';shutil.copyfile(p,snapshot)
record={'identity':'draft_editor','source_sha256':json.loads((folder/'manifest.json').read_text())['source_sha256'],
 'catalog_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'read_keys':['native:'+key for key in n],
 'method':'Read every target entry against its source identifier; consulted English source text for ambiguous keys; contextual overrides and terminology/HTML spacing cleanup. Independent source meaning review follows.',
 'changed':changed}
(folder/'author/native-author-review.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(len(n),len(changed),record['catalog_sha256'])
