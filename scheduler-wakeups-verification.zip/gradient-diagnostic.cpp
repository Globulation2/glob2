#include "field/OpenCLGradient.h"
#include "field/GradientDeviceService.h"
// SPDX-License-Identifier: GPL-3.0-or-later
#include "sim/snapshot/SnapshotStore.h"
#include "EngineFixtures.h"
#include "MapInternal.h"
#include "gradient/GradientRuntime.h"
#include "engine/sim/snapshot/WorldSnapshot.h"
#include <map>
#include <type_traits>
#include <nlohmann/json.hpp>

#include <algorithm>
#include <array>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <vector>

namespace
{
// Deliberately retain the original scalar predicates as an independent oracle.
// In particular resource goals ignore terrain/buildings, and clearing goals
// also ignore immobile units. Reordering these predicates changes the game.
void scalarResource(Map &m, int team, int resource, int swim, Uint16 *out, bool markets)
{
	markets = markets && m.marketsV2Enabled();
	const Uint32 mask = Team::teamNumberToMask(team);
    for (size_t i=0;i<m.size;++i)
    {
        if ((m.areaCells[i].forbidden&mask) || m.occupancyCells[i].immobileUnit!=IMMOBILE_UNIT_NONE)
            out[i]=GRADIENT_FORBIDDEN;
        else if (m.materialAmountAtSlot(i,resource)>0 && (!m.resourceVisibleToHarvest(i) || (m.fogOfWar[i]&mask)))
            out[i]=GRADIENT_AT_GOAL;
        else if (m.resourceBlocksGround(i)) out[i]=GRADIENT_FORBIDDEN;
        else if (m.occupancyCells[i].building!=NOGBID)
            out[i]=markets && m.isStockedMarketTile(m.occupancyCells[i].building,team,resource) ? GRADIENT_AT_GOAL-5*GRADIENT_STEP : GRADIENT_FORBIDDEN;
        else if (swim==WATER_ONLY_CLASS ? !m.terrainPropertiesAt(i).swimmable : !m.terrainPropertiesAt(i).walkable && !(swim>0 && m.terrainPropertiesAt(i).swimmable))
            out[i]=GRADIENT_FORBIDDEN;
        else out[i]=GRADIENT_UNREACHABLE;
    }
}

void scalarClear(Map &m, int team, int swim, Uint16 *out)
{
	const Uint32 mask = Team::teamNumberToMask(team);
	for (size_t i = 0; i < m.size; ++i)
	{
				if (m.areaCells[i].forbidden & mask)
			out[i] = GRADIENT_FORBIDDEN;
		else if (m.isClearingTarget(i, mask, m.farmAreasEnabled()))
			out[i] = GRADIENT_AT_GOAL;
		else if (m.occupancyCells[i].immobileUnit != IMMOBILE_UNIT_NONE)
			out[i] = GRADIENT_FORBIDDEN;
		else if (m.resourceBlocksGround(i))
			out[i] = GRADIENT_FORBIDDEN;
		else if (m.occupancyCells[i].building != NOGBID)
			out[i] = GRADIENT_FORBIDDEN;
		else if ((swim==WATER_ONLY_CLASS ? !m.terrainPropertiesAt(i).swimmable : !m.terrainPropertiesAt(i).walkable && !(swim > 0 && m.terrainPropertiesAt(i).swimmable)))
			out[i] = GRADIENT_FORBIDDEN;
		else
			out[i] = GRADIENT_UNREACHABLE;
	}
}

void scalarGuard(Map &m, int team, int swim, Uint16 *out)
{
	const Uint32 mask = Team::teamNumberToMask(team);
	bool painted = false;
	for (size_t i = 0; i < m.size; ++i)
	{
				if (m.areaCells[i].forbidden & mask)
			out[i] = GRADIENT_FORBIDDEN;
		else if (m.occupancyCells[i].immobileUnit != IMMOBILE_UNIT_NONE)
			out[i] = GRADIENT_FORBIDDEN;
		else if (m.resourceBlocksGround(i))
			out[i] = GRADIENT_FORBIDDEN;
		else if (m.occupancyCells[i].building != NOGBID && ((1u << Building::GIDtoTeam(m.occupancyCells[i].building)) & m.game->teams[team]->allies))
			out[i] = GRADIENT_FORBIDDEN;
		else if ((swim==WATER_ONLY_CLASS ? !m.terrainPropertiesAt(i).swimmable : !m.terrainPropertiesAt(i).walkable && !(swim > 0 && m.terrainPropertiesAt(i).swimmable)))
			out[i] = GRADIENT_FORBIDDEN;
		else if (m.areaCells[i].guard & mask)
		{
			out[i] = GRADIENT_AT_GOAL;
			painted = true;
		}
		else
			out[i] = GRADIENT_UNREACHABLE;
	}
	// Crowding itself is unchanged: this oracle checks the seeded input and
	// whether crowding runs, while reusing the production crowding operation.
	if (painted && m.game->gameHeader.hasExperiment(ExperimentId::GuardAreaBalancing))
		m.seedGuardAreaCrowding(team, out);
}

void requireSameField(const Map &map, const char *field,
	const std::vector<Uint16> &actual, const std::vector<Uint16> &expected)
{
	REQUIRE(actual.size() == expected.size());
	const auto mismatch = std::mismatch(actual.begin(), actual.end(), expected.begin());
	const size_t index = mismatch.first - actual.begin();
	// Report a cell and its two values instead of dumping an entire map buffer.
	if (index < actual.size())
	{
		INFO("Field: " << field);
		CAPTURE(index);
		const size_t x = index & map.wMask;
		const size_t y = index >> map.wDec;
		CAPTURE(x);
		CAPTURE(y);
		REQUIRE(actual[index] == expected[index]);
	}
}
}

static_assert(std::is_const_v<std::remove_reference_t<decltype(std::declval<Map &>().getTile(0, 0))>>);
static_assert(std::is_const_v<std::remove_reference_t<decltype(std::declval<Map &>().getResource(0, 0))>>);
static_assert(std::is_const_v<std::remove_reference_t<decltype(std::declval<Map &>().resourceState()[0])>>);

TEST_SUITE("GradientPreparation")
{
	TEST_CASE("map dimensions enforce power-of-two exponents before mutation")
    {
        glob2test::HeadlessGlobals globals;
        glob2test::HeadlessGame fixture({.wDec=6, .hDec=5, .teams=1, .discovered=true, .clearImmobile=true, .header=true});
        auto& map = fixture.game.map;
        CHECK(map.getW() == 64);
        CHECK(map.getH() == 32);
        for (auto dimensions : {std::pair{-1,5}, std::pair{6,-1}, std::pair{16,5}, std::pair{6,16}})
        {
            CHECK_THROWS_AS(map.setSize(dimensions.first, dimensions.second, GRASS), std::invalid_argument);
            CHECK(map.getW() == 64);
            CHECK(map.getH() == 32);
            CHECK(map.coordToIndex(-1,-1) == 64*32-1);
        }
    }

    TEST_CASE("material plane and cache keys retain legacy seven-class identity")
    {
        for (int team=0;team<Team::MAX_COUNT;++team)
            for (int material=0;material<int(MaterialSlotCount);++material)
                for (int swim=0;swim<LEGACY_SWIM_CLASS_COUNT;++swim)
                    for (bool market:{false,true}) {
                        const Uint16 legacy=((team*MaterialSlotCount+material)*LEGACY_SWIM_CLASS_COUNT+swim)*2+market;
                        CHECK(MapState::planeKey(team,material,swim,market)==legacy);
                        const auto decoded=MapState::decodePlaneKey(legacy);
                        CHECK(decoded.team==team); CHECK(decoded.resource==material); CHECK(decoded.swim==swim); CHECK(decoded.market==market);
                        if (material<int(MaterialCount))
                            for (int excluded:{-1,0,65534}) for (unsigned modes=0;modes<4;++modes) {
                                const Uint64 source=(Uint64(excluded+1)*Team::MAX_COUNT+team)*MaterialCount+material;
                                const auto oldKey=(source*LEGACY_SWIM_CLASS_COUNT+swim)*4+modes;
                                CHECK(MapState::materialFieldKey(excluded,team,material,swim,modes)==oldKey);
                                CHECK(MapState::materialFieldKey(excluded,team,material,WATER_ONLY_CLASS,modes)!=oldKey);
                            }
                    }
    }

	TEST_CASE("warm preparation keeps custom supplier unions exclusions penalties and overlays live")
	{
		glob2test::HeadlessGlobals globals;
		glob2test::HeadlessGame world({.wDec=7, .hDec=7, .teams=2, .discovered=true, .clearImmobile=true, .loadDefaultRace=true, .header=true});
		auto& game=world.game; auto& m=game.map;
		auto catalog=nlohmann::json::parse(game.buildingsTypes.snapshotJson());
		const char* names[]={"inn","hospital","racetrack","swimmingpool"};
		for (int k=0;k<4;++k)
		{
			auto& spec=catalog["variants"][game.buildingsTypes.getFinishedTypeNum(names[k])];
			spec["properties"]["maxMaterial"][WHEAT]=20;
			auto& semantics=spec["semantics"];
			semantics["occupiesGround"]=k!=1;
			auto& market=semantics["market"];
			market["sharedStock"]=k>=2;
			market["suppliesStock"]=k!=1;
			market["suppliesDirectStock"]=k==1;
			market["suppliesStockExperiment"]="";
			market["suppliesStockMaterials"]={"food"};
			market["suppliesDirectStockMaterials"]={"food"};
			market["pickupPenalty"]=k+2;
		}
		game.buildingsTypes.loadSnapshotJson(catalog.dump()); game.configureBuildingCatalog();
		auto* unified=world.addBuilding(names[0],8,8);
		auto* direct=world.addBuilding(names[1],20,8);
		auto* shared=world.addBuilding(names[2],32,8);
		auto* consumer=world.addBuilding(names[3],44,8);
		REQUIRE(unified); REQUIRE(direct); REQUIRE(shared); REQUIRE(consumer);
		auto* foreign=world.addBuilding(names[0],56,8,0,1); REQUIRE(foreign);
		foreign->materials[WHEAT]=10;
		unified->materials[WHEAT]=10; direct->materials[WHEAT]=10; shared->materials[WHEAT]=10;
		auto& cache=m.gradientRuntime->resourceSeeds;
		std::vector<Uint16> expected(m.size), actual(m.size);
		cache.allocationFailed=true;
		m.seedMaterialGradient(0,WHEAT,0,expected.data(),true,consumer,3);
		cache.allocationFailed=false;
		for(int i=0;i<32;++i)m.seedMaterialGradient(0,WHEAT,0,actual.data(),true,consumer,3);
		REQUIRE(cache.valid);
		requireSameField(m,"custom cached suppliers",actual,expected);
		CHECK(actual[m.coordToIndex(8,8)]==GRADIENT_AT_GOAL-2*GRADIENT_STEP);
		CHECK(actual[m.coordToIndex(20,8)]==GRADIENT_AT_GOAL-3*GRADIENT_STEP);
		CHECK(actual[m.coordToIndex(32,8)]==GRADIENT_FORBIDDEN);
		CHECK(actual[m.coordToIndex(44,8)]==GRADIENT_FORBIDDEN);
		CHECK(actual[m.coordToIndex(56,8)]==GRADIENT_FORBIDDEN);
		// Live stock changes must not wait for template invalidation.
		direct->materials[WHEAT]=0;
		m.seedMaterialGradient(0,WHEAT,0,actual.data(),true,consumer,3);
		CHECK(cache.valid);
		CHECK(actual[m.coordToIndex(20,8)]==GRADIENT_UNREACHABLE);
		direct->materials[WHEAT]=10;
		m.addForbidden(20,8,0); m.markImmobileUnit(21,8,0);
		m.seedMaterialGradient(0,WHEAT,0,actual.data(),true,consumer,3);
		CHECK(actual[m.coordToIndex(20,8)]==GRADIENT_FORBIDDEN);
		CHECK(actual[m.coordToIndex(21,8)]==GRADIENT_FORBIDDEN);
		m.seedMaterialGradient(0,WOOD,0,actual.data(),true,consumer,3);
		CHECK(actual[m.coordToIndex(8,8)]==GRADIENT_FORBIDDEN);
		CHECK(actual[m.coordToIndex(20,9)]==GRADIENT_UNREACHABLE);
		// Mode selection remains independent, including overlay-only Direct mode.
		m.removeForbidden(20,8,0);
		m.seedMaterialGradient(0,WHEAT,0,actual.data(),true,consumer,2);
		CHECK(actual[m.coordToIndex(8,8)]==GRADIENT_FORBIDDEN);
		CHECK(actual[m.coordToIndex(20,8)]==GRADIENT_AT_GOAL-3*GRADIENT_STEP);
	}


	TEST_CASE("supplier seed indexing rejects foreign and invalid building IDs in cached and direct fields")
	{
		glob2test::HeadlessGlobals globals;
		glob2test::HeadlessGame world({.wDec=7, .hDec=7, .teams=Team::MAX_COUNT,
			.discovered=true, .clearImmobile=true, .header=true});
		auto& m=world.game.map;
		const int lastTeam=Team::MAX_COUNT-1;
		const std::array<Uint16,6> gids={Building::GIDfrom(0,0),
			Building::GIDfrom(Building::MAX_COUNT-1,0), Building::GIDfrom(0,lastTeam),
			Building::GIDfrom(Building::MAX_COUNT-1,lastTeam), Uint16(NOGBID-1), NOGBID};
		for (size_t i=0;i<gids.size();++i) m.setBuilding(4+int(i),4,1,1,gids[i]);
		std::array<Uint16,Building::MAX_COUNT> seeds{};
		seeds[0]=GRADIENT_AT_GOAL-2*GRADIENT_STEP;
		seeds.back()=GRADIENT_AT_GOAL-4*GRADIENT_STEP;
		std::vector<Uint16> direct(m.size),cached(m.size);
		for (int team:{0,lastTeam})
		{
			CAPTURE(team);
			m.seedMaterialGradientDirect(team,WHEAT,0,direct.data(),seeds.data());
			for (int request=0;request<32;++request)
				m.gradientRuntime->resourceSeeds.trySeed(m,team,WHEAT,0,cached.data(),seeds.data());
			REQUIRE(m.gradientRuntime->resourceSeeds.valid);
			requireSameField(m,"supplier GID bounds",cached,direct);
			const int ownOffset=team==0 ? 0 : 2;
			const int otherOffset=team==0 ? 2 : 0;
			CHECK(cached[m.coordToIndex(4+ownOffset,4)]==seeds[0]);
			CHECK(cached[m.coordToIndex(5+ownOffset,4)]==seeds.back());
			CHECK(cached[m.coordToIndex(4+otherOffset,4)]==GRADIENT_FORBIDDEN);
			CHECK(cached[m.coordToIndex(5+otherOffset,4)]==GRADIENT_FORBIDDEN);
			CHECK(cached[m.coordToIndex(8,4)]==GRADIENT_FORBIDDEN);
			CHECK(cached[m.coordToIndex(9,4)]==GRADIENT_UNREACHABLE);
		}
	}

	TEST_CASE("resource cache tracks cell writes and falls back through mutation bursts")
	{
		glob2test::HeadlessGlobals globals;
		glob2test::HeadlessGame world({.wDec=7, .hDec=7, .teams=Team::MAX_COUNT, .clearImmobile=true, .header=true});
		auto &m = world.game.map;
		auto &cache = m.gradientRuntime->resourceSeeds;
		std::vector<Uint16> expected(m.size), actual(m.size);
		auto compare = [&](int phase) {
			for (int resource = 0; resource < int(MaterialCount); ++resource)
			{
				const int team = phase % Team::MAX_COUNT, swim = phase % SWIM_CLASS_COUNT;
				CAPTURE(team);
				CAPTURE(swim);
				CAPTURE(resource);
				scalarResource(m, team, resource, swim, expected.data(), false);
				m.seedMaterialGradient(team, resource, swim, actual.data(), false);
				requireSameField(m, "tracked resource", actual, expected);
				m.seedMaterialGradientDirect(team, resource, swim, actual.data(), nullptr);
				requireSameField(m, "direct resource", actual, expected);
			}
		};
		compare(0);
		compare(1);
		REQUIRE(cache.valid);
		CHECK(cache.allocatedBytes() <= 16 * m.size);
		CHECK(cache.allocatedBytes() <= 32 * 1024 * 1024);
		for (int phase = 0; phase < 160; ++phase)
		{
			CAPTURE(phase);
			const size_t index = (phase * 7919u) % m.size;
			const int x = index & m.wMask, y = index >> m.wDec;
			switch (phase % 10)
			{
			case 0: m.replaceResource(index, Resource{WHEAT, 0, 1, 0}); break;
			case 1: m.paintCell(index, WATER); break;
			case 2: m.setBuilding(x, y, 1, 1, 42); break;
			case 3: m.markImmobileUnit(x, y, 0); break;
			case 4: m.addForbidden(x, y, phase % Team::MAX_COUNT); break;
			case 5: m.replaceResource(index, Resource{WOOD, 0, 1, 0}); m.decResource(x, y); break;
			case 6: m.paintCell(index, GRASS); m.incResourceByIndex(x, y, WHEAT, 0); break;
			case 7: m.setResourceByIndex(x, y, WHEAT, 0); m.setNoResource(x, y, 0); break;
			case 8: m.clearImmobileUnit(x, y); m.removeForbidden(x, y, phase % Team::MAX_COUNT); break;
			case 9:
			{
				auto cell = m.getTile(index);
				cell.forbidden ^= Team::teamNumberToMask(phase % Team::MAX_COUNT);
				cell.resource = {STONE, 0, 1, 0};
				cell.building = NOGBID;
				m.replaceTile(index, cell);
				break;
			}
			}
			compare(phase);
		}
		// Publish each occupied state before removing it. Creating and deleting
		// between preparations alone would not detect a missing removal notice.
		const size_t at = m.coordToIndex(11, 11);
		m.replaceTile(at, Tile{});
		m.paintCell(at, GRASS);
		m.clearImmobileUnit(11, 11);
		m.replaceResource(at, Resource{WHEAT, 0, 1, 0});
		compare(0);
		m.decResource(11, 11);
		compare(0);
		m.incResourceByIndex(11, 11, WHEAT, 0);
		compare(0);
		m.setNoResource(11, 11, 0);
		compare(0);
		m.setBuilding(11, 11, 1, 1, 42);
		compare(0);
		m.setBuilding(11, 11, 1, 1, NOGBID);
		compare(0);
		m.markImmobileUnit(11, 11, 0);
		compare(0);
		m.clearImmobileUnit(11, 11);
		compare(0);
		m.addForbidden(11, 11, 0);
		compare(0);
		m.removeForbidden(11, 11, 0);
		compare(0);
		m.replaceResource(at, Resource{WHEAT, 0, 1, 0});
		compare(0);
		m.paintCell(at, WATER);
		compare(0);
		m.removeUnallowedResources(11, 11, 1, 1);
		compare(0);
		// Repeated edits to one cell must not fill the deduplicated queue.
		for (int i = 0; i < 1024; ++i)
			m.setAreaMask(0, &Tile::forbidden, i & 1);
		CHECK(cache.valid);
		compare(0);
		// Reads and amount-only changes are irrelevant to seed contents.
		(void)m.getTile(0);
		(void)m.getResource(0);
		(void)m.resourceState();
		m.setResourceAmount(0, 2);
		m.setResourcesGrow(0, 0, 255);
		CHECK(m.getTile(0).canResourcesGrow == 255);
		CHECK(cache.changes == 0);
		for (size_t i = 0; i <= m.size / 64; ++i)
			m.setAreaMask(i, &Tile::forbidden, m.getTile(i).forbidden ^ 1);
		CHECK_FALSE(cache.valid);
		for (int phase = 0; phase < 4; ++phase) compare(phase);
		CHECK(cache.valid);
		// Bulk reset frees the cache; enough subsequent requests rebuild it.
		m.setSize(8, 8, WATER);
		expected.resize(m.size);
		actual.resize(m.size);
		REQUIRE_FALSE(cache.storage);
		compare(0);
		compare(1);
		CHECK(cache.valid);
		m.setSize(6, 6, GRASS);
		expected.resize(m.size);
		actual.resize(m.size);
		for (int phase = 0; phase < 4; ++phase) compare(phase);
		CHECK_FALSE(cache.storage);
	}

	TEST_CASE("cached natural goals follow immobile occupancy and live overlays")
	{
		glob2test::HeadlessGlobals globals;
		int hiddenResource = -1;
		for (int resource = 0; resource < 8; ++resource)
			if (ResourceRegistry::builtins()->properties(static_cast<ResourceId>(resource)).visibleToHarvest)
			{
				hiddenResource = resource;
				break;
			}
		REQUIRE(hiddenResource >= 0);
		for (const int wDec : {5, 7})
		{
			CAPTURE(wDec);
			glob2test::HeadlessGame world({.wDec=wDec, .hDec=wDec, .teams=2, .clearImmobile=true, .header=true});
			auto &m = world.game.map;
			auto &cache = m.gradientRuntime->resourceSeeds;
			const int x = 10, y = 10;
			const size_t at = m.coordToIndex(x, y);
			const Uint32 mask = Team::teamNumberToMask(0);
			std::vector<Uint16> expected(m.size), actual(m.size);
			m.replaceTile(at, Tile{});
			m.paintCell(at, GRASS);
			m.clearImmobileUnit(x, y);
			m.fogOfWar[at] = mask;
			m.replaceResource(at, Resource{WHEAT, 0, 1, 0});
			auto compare = [&](int checkedResource, Uint16 checkedValue) {
				for (const int swim : {0, 3})
					for (const int resource : {int(WHEAT), int(WOOD), hiddenResource})
					{
						CAPTURE(swim);
						CAPTURE(resource);
						scalarResource(m, 0, resource, swim, expected.data(), false);
						m.seedMaterialGradient(0, resource, swim, actual.data(), false);
						requireSameField(m, "occupied natural goal", actual, expected);
						if (resource == checkedResource) CHECK(actual[at] == checkedValue);
						m.seedMaterialGradientDirect(0, resource, swim, actual.data(), nullptr);
						requireSameField(m, "direct occupied natural goal", actual, expected);
					}
			};
			auto warm = [&] {
				for (int i = 0; i < 32; ++i)
					m.seedMaterialGradient(0, WHEAT, 0, actual.data(), false);
				CHECK(cache.valid == (wDec == 7));
			};
			warm();
			const auto bytes = cache.allocatedBytes();
			compare(WHEAT, GRADIENT_AT_GOAL);
			m.markImmobileUnit(x, y, 0);
			compare(WHEAT, GRADIENT_FORBIDDEN);
			m.clearImmobileUnit(x, y);
			compare(WHEAT, GRADIENT_AT_GOAL);
			m.markImmobileUnit(x, y, 1);
			compare(WHEAT, GRADIENT_FORBIDDEN);
			m.replaceResource(at, Resource{WOOD, 0, 1, 0});
			compare(WOOD, GRADIENT_FORBIDDEN);
			m.clearImmobileUnit(x, y);
			compare(WOOD, GRADIENT_AT_GOAL);
			m.markImmobileUnit(x, y, 0);
			m.replaceResource(at, Resource{});
			compare(WOOD, GRADIENT_FORBIDDEN);
			m.clearImmobileUnit(x, y);
			compare(WOOD, GRADIENT_UNREACHABLE);
			// Coalesced resource/occupancy edits use the final effective goal type.
			m.replaceResource(at, Resource{WHEAT, 0, 1, 0});
			m.markImmobileUnit(x, y, 0);
			m.replaceResource(at, Resource{WOOD, 0, 1, 0});
			m.clearImmobileUnit(x, y);
			m.markImmobileUnit(x, y, 1);
			compare(WOOD, GRADIENT_FORBIDDEN);
			m.clearImmobileUnit(x, y);
			compare(WOOD, GRADIENT_AT_GOAL);
			// A coalesced removal must clear a previously published resource bit,
			// even when the final cell is empty and unoccupied again.
			m.replaceResource(at, Resource{});
			m.markImmobileUnit(x, y, 0);
			m.clearImmobileUnit(x, y);
			compare(WOOD, GRADIENT_UNREACHABLE);
			// Empty-cell occupancy still updates base passability without a goal.
			m.markImmobileUnit(x, y, 0);
			compare(WOOD, GRADIENT_FORBIDDEN);
			m.clearImmobileUnit(x, y);
			compare(WOOD, GRADIENT_UNREACHABLE);
			// Goals still override terrain/buildings, with fog live and paint last.
			m.replaceResource(at, Resource{static_cast<Uint8>(hiddenResource), 0, 1, 0});
			m.paintCell(at, WATER);
			m.setBuilding(x, y, 1, 1, 42);
			m.fogOfWar[at] = 0;
			compare(hiddenResource, GRADIENT_FORBIDDEN);
			m.fogOfWar[at] = mask;
			compare(hiddenResource, GRADIENT_AT_GOAL);
			m.addForbidden(x, y, 0);
			compare(hiddenResource, GRADIENT_FORBIDDEN);
			m.removeForbidden(x, y, 0);
			compare(hiddenResource, GRADIENT_AT_GOAL);
			m.markImmobileUnit(x, y, 0);
			compare(hiddenResource, GRADIENT_FORBIDDEN);
			cache.invalidate();
			warm();
			compare(hiddenResource, GRADIENT_FORBIDDEN);
			m.clearImmobileUnit(x, y);
			compare(hiddenResource, GRADIENT_AT_GOAL);
            // The first appearances of wood and the hidden material each add
            // one lazy goal bitset. After these materials have been observed,
            // occupancy churn, invalidation and rebuild must allocate nothing.
            const auto warmedBytes=cache.allocatedBytes();
            const auto goalBytes=((m.size+63)/64)*sizeof(Uint64);
            CHECK(warmedBytes==bytes+(wDec==7 ? 2*goalBytes : 0));
			if (wDec == 7)
			{
				// A burst exceeds the existing dirty bound; fallback and rebuild
				// must both preserve blocked resource membership.
				for (size_t i = 0; i <= m.size / 64; ++i)
				{
					m.replaceResource(i, Resource{WHEAT, 0, 1, 0});
					m.markImmobileUnit(i & m.wMask, i >> m.wDec, 0);
				}
				REQUIRE_FALSE(cache.valid);
				compare(hiddenResource, GRADIENT_AT_GOAL);
				warm();
				compare(hiddenResource, GRADIENT_AT_GOAL);
				for (size_t i = 0; i <= m.size / 64; ++i)
					m.clearImmobileUnit(i & m.wMask, i >> m.wDec);
				REQUIRE_FALSE(cache.valid);
				compare(hiddenResource, GRADIENT_AT_GOAL);
				warm();
				compare(hiddenResource, GRADIENT_AT_GOAL);
				CHECK(cache.allocatedBytes() == warmedBytes);
			}
		}
	}

	TEST_CASE("concurrent preparation owns buffers and serializes dirty cache refresh")
	{
		glob2test::HeadlessGlobals globals;
		glob2test::HeadlessGame world({.wDec=7, .hDec=7, .teams=2, .clearImmobile=true, .header=true});
		auto &m = world.game.map;
		std::vector<Uint16> expected(m.size);
		for (int pass = 0; pass < 16; ++pass)
			m.seedMaterialGradient(0, WHEAT, 0, expected.data(), false);
		REQUIRE(m.gradientRuntime->resourceSeeds.valid);
		m.replaceResource(0, Resource{WHEAT, 0, 1, 0});
		m.paintCell(1, WATER);
		m.addForbidden(0, 0, 1);
		std::vector<std::vector<Uint16>> outputs(16, std::vector<Uint16>(m.size));
		m.configureCompute(4);
		m.computeExecutor().run(outputs.size(), [&](size_t job) {
			m.seedMaterialGradient(job % 2, job % MaterialCount, job % SWIM_CLASS_COUNT,
				outputs[job].data(), false);
		});
		for (size_t job = 0; job < outputs.size(); ++job)
		{
			CAPTURE(job);
			scalarResource(m, job % 2, job % MaterialCount, job % SWIM_CLASS_COUNT, expected.data(), false);
			requireSameField(m, "concurrent preparation", outputs[job], expected);
		}
	}

	TEST_CASE("custom terrain and registry replacement preserve cached and direct seeds")
	{
		glob2test::HeadlessGlobals globals;
		glob2test::HeadlessGame world({.wDec=7, .hDec=7, .clearImmobile=true, .header=true});
		auto &m = world.game.map;
		auto importTerrain = [&](std::string_view definitions) {
			// Detached maps are the existing pre-match authoring interface.
			m.game = nullptr;
			m.importTerrainDefinitions(definitions);
			m.setGame(&world.game);
		};
		importTerrain(R"({"schemaVersion":1,"terrains":[{"key":"test:seed","name":"Seed terrain","base":"grass","appearance":"sand","properties":{"walkable":false,"swimmable":true}}]})");
		const auto terrain = *m.terrainRegistry().find("test:seed");
		m.paintCell(0, terrain);
		m.replaceResource(1, Resource{WHEAT, 0, 1, 0});
		m.paintCell(1, terrain);
		m.addFarmArea(1, 0, 0);
		world.game.gameHeader.getExperiments().set(ExperimentId::FarmAreas, true);
		std::vector<Uint16> expected(m.size), actual(m.size);
		for (int phase = 0; phase < 2; ++phase)
		{
			for (int pass = 0; pass < 24; ++pass)
			{
				const int swim = pass % SWIM_CLASS_COUNT, resource = pass % MaterialCount;
				scalarResource(m, 0, resource, swim, expected.data(), false);
				m.seedMaterialGradient(0, resource, swim, actual.data(), false);
				requireSameField(m, "custom cached terrain", actual, expected);
				m.seedMaterialGradientDirect(0, resource, swim, actual.data(), nullptr);
				requireSameField(m, "custom direct terrain", actual, expected);
				scalarClear(m, 0, swim, expected.data());
				m.seedClearAreasGradient(0, swim, actual.data());
				requireSameField(m, "custom clearing terrain", actual, expected);
			}
			REQUIRE(m.gradientRuntime->resourceSeeds.valid);
			if (!phase)
			{
				importTerrain(R"({"schemaVersion":1,"terrains":[{"key":"test:seed","name":"Seed terrain","base":"water","appearance":"sand","properties":{"walkable":true,"swimmable":false}}]})");
				CHECK_FALSE(m.gradientRuntime->resourceSeeds.valid);
			}
		}
	}

	TEST_CASE("optional cache storage can be unavailable or over budget")
	{
		glob2test::HeadlessGlobals globals;
		glob2test::HeadlessGame world({.wDec=7, .hDec=7, .clearImmobile=true, .header=true});
		auto &m = world.game.map;
		auto &cache = m.gradientRuntime->resourceSeeds;
		// Exercise the permanent fallback state without exhausting process memory.
		cache.allocationFailed = true;
		m.replaceResource(0, Resource{WHEAT, 0, 1, 0});
		std::vector<Uint16> expected(m.size), actual(m.size);
		for (int pass = 0; pass < 24; ++pass)
		{
			scalarResource(m, 0, WHEAT, pass % SWIM_CLASS_COUNT, expected.data(), false);
			m.seedMaterialGradient(0, WHEAT, pass % SWIM_CLASS_COUNT, actual.data(), false);
			requireSameField(m, "unavailable cache", actual, expected);
		}
		CHECK_FALSE(cache.storage);
		// A 2048-square map exceeds the conservative 16-byte/cell gate.
		m.setSize(11, 11, GRASS);
		actual.resize(m.size);
		m.seedMaterialGradient(0, WHEAT, 0, actual.data(), false);
		CHECK_FALSE(cache.storage);
		CHECK(std::all_of(actual.begin(), actual.end(), [](Uint16 value) {
			return value == GRADIENT_UNREACHABLE;
		}));
	}

	TEST_CASE("seed cells match scalar predicates across policies and changing overlays")
	{
		glob2test::HeadlessGlobals globals;
		glob2test::HeadlessGame world({.wDec=8, .hDec=8, .teams=2, .clearImmobile=true, .loadDefaultRace=true, .header=true});
		auto &m = world.game.map;
		auto *market0 = world.addBuilding("market", 2, 2);
		auto *market1 = world.addBuilding("market", 8, 8, 0, 1);
		REQUIRE(market0);
		REQUIRE(market1);
		REQUIRE(world.addUnit(WARRIOR, 32, 32));
		REQUIRE(world.addUnit(WARRIOR, 33, 33, 1));
		// Cartesian product, including deliberately overlapping goals/blockers.
		size_t i = 0;
		// One terrain per distinct property profile keeps the product inside the map;
		// group members share a profile and therefore the same seed policy.
		for (unsigned terrain=0; terrain<TERRAIN_COUNT; ++terrain)
		{
			bool firstOfProfile = true;
			for (unsigned earlier=0; earlier<terrain; ++earlier)
				if (m.terrainRegistry().propertyIndex(static_cast<TerrainType>(earlier)) == m.terrainRegistry().propertyIndex(static_cast<TerrainType>(terrain)))
					firstOfProfile = false;
			if (!firstOfProfile) continue;
				for (int resource=0; resource<=8; ++resource)
		for (unsigned forbidden=0; forbidden<4; ++forbidden)
		for (unsigned immobile=0; immobile<2; ++immobile)
		for (unsigned building=0; building<3; ++building)
		for (unsigned area=0; area<4; ++area)
		for (unsigned fog=0; fog<4; ++fog, ++i)
		{
			REQUIRE(i < m.size);

			m.paintCell(i, static_cast<TerrainType>(terrain));
			m.resourceCells[i].resource.type = resource == 8 ? NO_RES_TYPE : resource;
            m.resourceCells[i].resource.amount = resource == 8 ? 0 : 1;
			m.areaCells[i].forbidden = forbidden;
			m.occupancyCells[i].immobileUnit = immobile ? 0 : IMMOBILE_UNIT_NONE;
			m.occupancyCells[i].building = building == 0 ? NOGBID : building == 1 ? market0->gid : market1->gid;
			m.areaCells[i].clear = area;
			m.areaCells[i].farm = area ^ 3;
			m.areaCells[i].guard = area;
			m.fogOfWarA[i] = fog;
			m.fogOfWarB[i] = fog ^ 3;
		}
		}
		std::vector<Uint16> expected(m.size), actual(m.size);
		for (unsigned threads : {1, 2, 4})
		{
			m.configureCompute(threads);
			for (int phase=0; phase<4; ++phase)
			{
				world.game.gameHeader.getExperiments().set(ExperimentId::FarmAreas, phase & 1);
				world.game.gameHeader.getExperiments().set(ExperimentId::MarketsV2, phase & 2);
				world.game.gameHeader.getExperiments().set(ExperimentId::GuardAreaBalancing, phase & 1);
				world.game.configureBuildingCatalog();
				m.fogOfWar = phase & 1 ? m.fogOfWarB.data() : m.fogOfWarA.data();
				world.game.teams[0]->allies = phase & 1 ? 3 : 1;
				for (int r=0; r<int(MaterialCount); ++r)
				{
					market0->materials[r] = phase & 1 ? 0 : 10;
					market1->materials[r] = phase & 1 ? 10 : 0;
				}
				for (int team=0; team<2; ++team)
				for (int swim=0; swim<SWIM_CLASS_COUNT; ++swim)
				{
					CAPTURE(threads);
					CAPTURE(phase);
					CAPTURE(team);
					CAPTURE(swim);
					for (int resource=0; resource<int(MaterialCount); ++resource)
					for (bool markets : {false, true})
					{
						CAPTURE(resource);
						CAPTURE(markets);
						scalarResource(m, team, resource, swim, expected.data(), markets);
						m.seedMaterialGradient(team, resource, swim, actual.data(), markets);
						requireSameField(m, "resource", actual, expected);
						std::array<Uint16, Building::MAX_COUNT> supplierSeeds{};
						if (markets && m.marketsV2Enabled())
							for (const auto* b : world.game.teams[team]->stockSuppliers)
								if (m.isStockedMarketTile(b->gid, team, resource))
									supplierSeeds[Building::GIDtoID(b->gid)] = (GRADIENT_AT_GOAL - 5 * GRADIENT_STEP);
						m.seedMaterialGradientDirect(team, resource, swim, actual.data(),
							markets && m.marketsV2Enabled() ? supplierSeeds.data() : nullptr);
						requireSameField(m, "direct resource", actual, expected);
					}
					scalarClear(m, team, swim, expected.data());
					m.seedClearAreasGradient(team, swim, actual.data());
					requireSameField(m, "clearing", actual, expected);
					scalarGuard(m, team, swim, expected.data());
					m.seedGuardAreasGradient(team, swim, actual.data());
					requireSameField(m, "guard", actual, expected);
				}
			}
		}
	}

	TEST_CASE("all supported team masks match the scalar fields")
	{
		glob2test::HeadlessGlobals globals;
		glob2test::HeadlessGame world({.teams=Team::MAX_COUNT, .clearImmobile=true, .header=true});
		auto &m = world.game.map;
		world.game.gameHeader.getExperiments().set(ExperimentId::FarmAreas, true);
		for (size_t i=0; i<m.size; ++i)
		{

			const Uint32 mask = Team::teamNumberToMask(i % Team::MAX_COUNT);
			m.paintCell(i, static_cast<TerrainType>(i % TERRAIN_COUNT));
			m.resourceCells[i].resource.type = i % (8 + 1) == 8 ? NO_RES_TYPE : i % (8 + 1);
            m.resourceCells[i].resource.amount = m.resourceCells[i].resource.type==NO_RES_TYPE ? 0 : 1;
			m.areaCells[i].forbidden = i & 1 ? mask : ~mask;
			m.areaCells[i].clear = i & 2 ? mask : 0;
			m.areaCells[i].farm = i & 4 ? mask : 0;
			m.fogOfWar[i] = i & 8 ? mask : ~mask;
		}
		std::vector<Uint16> expected(m.size), actual(m.size);
		for (int team=0; team<Team::MAX_COUNT; ++team)
		for (int swim=0; swim<SWIM_CLASS_COUNT; ++swim)
		{
			CAPTURE(team);
			CAPTURE(swim);
			for (int resource=0; resource<int(MaterialCount); ++resource)
			{
				CAPTURE(resource);
				scalarResource(m, team, resource, swim, expected.data(), false);
				m.seedMaterialGradient(team, resource, swim, actual.data(), false);
				requireSameField(m, "resource", actual, expected);
			}
			scalarClear(m, team, swim, expected.data());
			m.seedClearAreasGradient(team, swim, actual.data());
			requireSameField(m, "clearing", actual, expected);
		}
	}

	TEST_CASE("explicit clearing overrides farm crop protection but never forbidden paint")
	{
		glob2test::HeadlessGlobals globals;
		glob2test::HeadlessGame world({.clearImmobile=true, .header=true});
		auto &m = world.game.map;
		const Uint32 teamMask = Team::teamNumberToMask(0);
		std::vector<Uint16> actual(m.size);
		for (TerrainType terrain : {GRASS, WATER})
		{
			CAPTURE(terrain);
			m.paintCell(0, terrain);
			m.resourceCells[0].resource.type = terrainProperties(terrain).farmMaterial;
			REQUIRE(m.resourcePropertiesByIndex(m.resourceCells[0].resource.type).clearable);
			m.areaCells[0].farm = teamMask;
			m.occupancyCells[0].building = 42;
			m.occupancyCells[0].immobileUnit = 0;
			for (bool farming : {false, true})
			{
				CAPTURE(farming);
				world.game.gameHeader.getExperiments().set(ExperimentId::FarmAreas, farming);
				m.areaCells[0].forbidden = 0;
				m.areaCells[0].clear = 0;
				m.seedClearAreasGradient(0, 0, actual.data());
				REQUIRE(actual[0] == GRADIENT_FORBIDDEN);

				// Explicit clearing wins even on water and an occupied cell.
				m.areaCells[0].clear = teamMask;
				m.seedClearAreasGradient(0, 0, actual.data());
				REQUIRE(actual[0] == GRADIENT_AT_GOAL);

				m.areaCells[0].forbidden = teamMask;
				m.seedClearAreasGradient(0, 0, actual.data());
				REQUIRE(actual[0] == GRADIENT_FORBIDDEN);
			}
		}
	}

	TEST_CASE("mutation and reset boundaries use current state")
	{
		glob2test::HeadlessGlobals globals;
		glob2test::HeadlessGame world({.wDec=6, .hDec=6, .teams=2, .clearImmobile=true, .header=true});
		auto &m = world.game.map;
		for (int phase=0; phase<12; ++phase)
		{
			CAPTURE(phase);
			if (phase == 8)
				m.setSize(7, 7, WATER);
			m.setResourceByIndex(20, 20, phase % MaterialCount, 0);
			if (phase & 1)
				m.replaceResource(20, 20, Resource{});
			m.setBuilding(21, 20, 1, 1, phase & 1 ? NOGBID : 42);
			if (phase & 1)
				m.markImmobileUnit(22, 20, 0);
			else
				m.clearImmobileUnit(22, 20);
			m.addClearArea(20, 20, phase % 2);
			m.addForbidden(22, 20, phase % 2);
			std::vector<Uint16> expected(m.size), actual(m.size);
			for (int swim=0; swim<SWIM_CLASS_COUNT; ++swim)
			{
				CAPTURE(swim);
				scalarResource(m, 0, WHEAT, swim, expected.data(), false);
				m.seedMaterialGradient(0, WHEAT, swim, actual.data(), false);
				requireSameField(m, "resource", actual, expected);
				scalarClear(m, 0, swim, expected.data());
				m.seedClearAreasGradient(0, swim, actual.data());
				requireSameField(m, "clearing", actual, expected);
			}
		}
	}

	TEST_CASE("concurrent lazy requests publish one complete resource field")
	{
		glob2test::HeadlessGlobals globals;
		glob2test::HeadlessGame world({.wDec=7, .hDec=7, .teams=2, .clearImmobile=true, .header=true});
		auto &m = world.game.map;
		for (int resource=0; resource<3; ++resource)
			m.setResourceByIndex(20 + resource, 20, resource, 0);
		std::vector<Uint16> warmup(m.size);
		for (int i = 0; i < 16; ++i) m.seedMaterialGradient(0, WHEAT, 0, warmup.data(), false);
		REQUIRE(m.gradientRuntime->resourceSeeds.valid);
		for (unsigned workers : {0, 1, 2})
		{
			CAPTURE(workers);
			// Use an unallocated field for every worker count.
			const int resource = workers;
			REQUIRE(m.materialGradients[0][resource][0] == nullptr);
			std::vector<Uint16> expected(m.size);
			scalarResource(m, 0, resource, 0, expected.data(), false);
			m.propagateGradient(expected.data(), 0);
			m.configureGradientPipeline(workers, 8);
			m.configureCompute(4);
			std::vector<Uint16 *> requests(8);
			m.computeExecutor().run(requests.size(), [&](size_t j) {
				requests[j] = m.getMaterialGradientSlot(0, resource, 0);
			});
			REQUIRE(requests[0] != nullptr);
			for (size_t j=1; j<requests.size(); ++j)
				REQUIRE(requests[j] == requests[0]);
			requireSameField(m, "lazy resource", std::vector<Uint16>(requests[0], requests[0] + m.size), expected);
		}
	}
}

TEST_SUITE("GradientPreparation")
{
TEST_CASE("compound passable material goals track depletion visibility and overlapping suppliers")
{
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame world({.wDec=7,.hDec=7,.teams=2,.clearImmobile=true,.header=true});
    auto& map=world.game.map;
    using Json=nlohmann::json;
    auto source=Json::parse(map.resourceRegistry().serialize())["resources"][1];
    source["key"]="mixed-visible";
    source["properties"]["blocksGround"]=false;
    source["properties"]["visibleToHarvest"]=true;
    source["properties"]["persistsWhenEmpty"]=true;
    source["yields"]["wood"]={{"capacity",5},{"initial",2},{"growthRate",196608},{"consumption","one"}};
    auto hidden=source;
    hidden["key"]="mixed-always";
    hidden["properties"]["visibleToHarvest"]=false;
    map.installResourceDefinitions(Json{{"schemaVersion",1},{"resources",Json::array({source,hidden})}}.dump());
    const auto first=resourceIndex(*map.resourceRegistry().find("mixed-visible"));
    const auto second=resourceIndex(*map.resourceRegistry().find("mixed-always"));
    REQUIRE(map.incResourceByIndex(10,10,first,0));
    REQUIRE(map.incResourceByIndex(11,10,second,0));
    const auto a=map.coordToIndex(10,10), b=map.coordToIndex(11,10);
    map.fogOfWar[a]=map.fogOfWar[b]=0;
    std::vector<Uint16> direct(map.size),cached(map.size);
    gradient_preparation::MaterialSeedCache snapshotCache;
    auto compare=[&](int material) {
        map.seedMaterialGradientDirect(0,material,0,direct.data(),nullptr);
        for (int repeat=0;repeat<32;++repeat) map.seedMaterialGradient(0,material,0,cached.data(),false);
        REQUIRE(map.gradientRuntime->resourceSeeds.valid);
        requireSameField(map,"compound source",cached,direct);
        gradient_preparation::Request request{gradient_preparation::Kind::Materials,0,material,0};
        auto snapshot=SimulationSnapshot::capture(world.game,SimulationSnapshot::captureCatalog(world.game),request.requirements());
        REQUIRE(snapshotCache.trySeed(snapshot,0,material,0,cached.data(),nullptr));
        requireSameField(map,"compound snapshot cache",cached,direct);
    };
    compare(int(MaterialId::Food));
    CHECK(cached[a]==GRADIENT_UNREACHABLE);
    CHECK(cached[b]==GRADIENT_AT_GOAL);
    map.fogOfWar[a]=Team::teamNumberToMask(0);
    compare(int(MaterialId::Wood));
    CHECK(cached[a]==GRADIENT_AT_GOAL);
    map.setMaterialAmount(a,MaterialId::Wood,0);
    compare(int(MaterialId::Wood));
    CHECK(cached[a]==GRADIENT_UNREACHABLE);
    compare(int(MaterialId::Food));
    CHECK(cached[a]==GRADIENT_AT_GOAL);
    map.setMaterialAmount(a,MaterialId::Food,0);
    compare(int(MaterialId::Food));
    CHECK(cached[a]==GRADIENT_UNREACHABLE);
    REQUIRE(map.growResourceStock(a));
    compare(int(MaterialId::Food));
    CHECK(cached[a]==GRADIENT_AT_GOAL);
    // A passable natural source can overlap a building. Natural goals take
    // precedence over supplier prices in both kernels.
    const auto building=Building::GIDfrom(0,0);
    map.setBuilding(10,10,1,1,building);
    std::array<Uint16,Building::MAX_COUNT> supplierSeeds{};
    supplierSeeds[0]=GRADIENT_AT_GOAL-4*GRADIENT_STEP;
    map.seedMaterialGradientDirect(0,int(MaterialId::Food),0,direct.data(),supplierSeeds.data());
    REQUIRE(map.gradientRuntime->resourceSeeds.trySeed(map,0,int(MaterialId::Food),0,cached.data(),supplierSeeds.data()));
    requireSameField(map,"natural and building source overlap",cached,direct);
    CHECK(cached[a]==GRADIENT_AT_GOAL);
    map.addForbidden(10,10,0);
    REQUIRE(map.gradientRuntime->resourceSeeds.trySeed(map,0,int(MaterialId::Food),0,cached.data(),supplierSeeds.data()));
    CHECK(cached[a]==GRADIENT_FORBIDDEN);
}
}

TEST_SUITE("RuntimeResources")
{
TEST_CASE("unused catalog definitions allocate no material gradients and schedule no extra work")
{
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame base({.wDec=7,.hDec=7,.header=true,.seed=7411});
    glob2test::HeadlessGame expanded({.wDec=7,.hDec=7,.header=true,.seed=7411});
    using Json=nlohmann::json;
    const auto prototype=Json::parse(base.game.map.resourceRegistry().serialize())["resources"][1];
    Json additions=Json::array();
    for (unsigned n=0;n<192;++n)
    {
        auto definition=prototype;
        definition["key"]="unused-"+std::to_string(1000+n);
        const auto material=MaterialKeys[8+n%4];
        definition["properties"]["primaryMaterial"]=material;
        definition["yields"]=Json{{material,{{"capacity",7},{"initial",1},{"growthRate",ResourceRateScale},{"consumption","one"}}}};
        additions.push_back(std::move(definition));
    }
    auto& original=base.game.map;
    auto& candidate=expanded.game.map;
    candidate.installResourceDefinitions(Json{{"schemaVersion",1},{"resources",additions}}.dump());
    for (Map* map:{&original,&candidate})
    {
        REQUIRE(map->incResourceByIndex(8,8,WHEAT,0));
        map->configureGradientPipeline(1,3);
        for (unsigned material=0;material<MaterialCount;++material)
            for (int swim=0;swim<SWIM_CLASS_COUNT;++swim)
            {
                REQUIRE(map->getMaterialGradientSlot(0,material,swim)!=nullptr);
                CHECK((map->materialGradients[0][material][swim]!=nullptr)==(material==materialIndex(MaterialId::Food)));
            }
    }
    expanded.game.syncRandom=base.game.syncRandom;
    for (unsigned tick=0;tick<64;++tick)
    {
        { auto random=base.game.bindRandom(); base.game.syncStep(0); }
        { auto random=expanded.game.bindRandom(); expanded.game.syncStep(0); }
        CHECK(base.game.syncRandom==expanded.game.syncRandom);
        CHECK(original.gradientPipelineStatus().jobs==candidate.gradientPipelineStatus().jobs);
        CHECK(original.gradientPipelineStatus().pending==candidate.gradientPipelineStatus().pending);
    }
    original.finishGradientPipeline();
    candidate.finishGradientPipeline();
    CHECK(original.gradientPipelineStatus().jobs>0);
    CHECK(original.gradientPipelineStatus().published==candidate.gradientPipelineStatus().published);
    CHECK(original.gradientRuntime->resourceSeeds.allocatedBytes()==candidate.gradientRuntime->resourceSeeds.allocatedBytes());
    for (unsigned material=0;material<MaterialCount;++material)
        for (int swim=0;swim<SWIM_CLASS_COUNT;++swim)
        {
            const auto* left=original.materialGradients[0][material][swim];
            const auto* right=candidate.materialGradients[0][material][swim];
            CHECK((left==nullptr)==(right==nullptr));
            if (left && right) CHECK(std::equal(left,left+original.size,right));
        }
}
}

TEST_SUITE("RuntimeResources")
{
TEST_CASE("seed cache allocates only live material bitsets and reuses them after depletion")
{
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame fixture({.wDec=7,.hDec=7,.clearImmobile=true,.header=true});
    auto& map=fixture.game.map;
    using Json=nlohmann::json;
    auto definition=Json::parse(map.resourceRegistry().serialize())["resources"][1];
    definition["key"]="lazy-stock-cache";
    definition["properties"]["persistsWhenEmpty"]=true;
    definition["yields"]["gold"]={{"capacity",2},{"initial",1},{"consumption","one"}};
    map.installResourceDefinitions(Json{{"schemaVersion",1},{"resources",Json::array({definition})}}.dump());
    auto& cache=map.gradientRuntime->resourceSeeds;
    std::vector<Uint16> actual(map.size),expected(map.size);
    const auto verify=[&](unsigned material) {
        scalarResource(map,0,material,0,expected.data(),false);
        map.seedMaterialGradient(0,material,0,actual.data(),false);
        requireSameField(map,"lazy material availability",actual,expected);
    };
    for (unsigned pass=0;pass<32;++pass) verify(materialIndex(MaterialId::Food));
    REQUIRE(cache.valid);
    const auto emptyBytes=cache.allocatedBytes();
    // Querying every absent material must not instantiate any goal bitset.
    for (unsigned material=0;material<MaterialCount;++material) verify(material);
    CHECK(cache.allocatedBytes()==emptyBytes);
    const auto id=*map.resourceRegistry().find("lazy-stock-cache");
    REQUIRE(map.incResource(8,8,id,0));
    verify(materialIndex(MaterialId::Food));
    verify(materialIndex(MaterialId::Gold));
    const auto stockedBytes=cache.allocatedBytes();
    CHECK(stockedBytes==emptyBytes+2*((map.size+63)/64)*sizeof(Uint64));
    for (unsigned cycle=0;cycle<8;++cycle)
    {
        const auto index=map.coordToIndex(8,8);
        map.setMaterialAmount(index,MaterialId::Food,0);
        map.setMaterialAmount(index,MaterialId::Gold,0);
        verify(materialIndex(MaterialId::Food));
        verify(materialIndex(MaterialId::Gold));
        CHECK(actual[index]!=GRADIENT_AT_GOAL);
        map.setMaterialAmount(index,MaterialId::Food,1);
        map.setMaterialAmount(index,MaterialId::Gold,1);
        verify(materialIndex(MaterialId::Food));
        verify(materialIndex(MaterialId::Gold));
        CHECK(actual[index]==GRADIENT_AT_GOAL);
        CHECK(cache.allocatedBytes()==stockedBytes);
    }
}
}

TEST_CASE("compact clearing traits preserve custom high-ID property combinations" * doctest::test_suite("GradientPreparation"))
{
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame world({.teams=2,.clearImmobile=true,.header=true});
    auto& map=world.game.map;
    using Json=nlohmann::json;
    const auto prototype=Json::parse(map.resourceRegistry().serialize())["resources"][1];
    Json definitions=Json::array();
    for(unsigned n=0;n<272;++n) {
        auto definition=prototype;
        definition["key"]="clearing-traits-"+std::to_string(1000+n);
        definition["properties"]["persistsWhenEmpty"]=true;
        definition["properties"]["blocksGround"]=bool(n&1);
        definition["properties"]["clearable"]=bool(n&2);
        definition["properties"]["farmable"]=bool(n&4);
        definitions.push_back(std::move(definition));
    }
    map.installResourceDefinitions(Json{{"schemaVersion",1},{"resources",definitions}}.dump());
    std::vector<Uint16> actual(map.size),expected(map.size);
    for(unsigned n=264;n<272;++n) {
        const auto id=*map.resourceRegistry().find("clearing-traits-"+std::to_string(1000+n));
        REQUIRE(resourceIndex(id)>255);
        const auto index=map.coordToIndex(8+n-264,8);
        map.paintCell(index,GRASS);
        map.setResource(8+n-264,8,id,0);
        // Empty persistent stocks remain clearable according to properties.
        map.resourceCells[index].resource.amount=0;
        for(bool farms:{false,true}) for(unsigned paint=0;paint<8;++paint) {
            CAPTURE(n);CAPTURE(farms);CAPTURE(paint);
            world.game.gameHeader.getExperiments().set(ExperimentId::FarmAreas,farms);
            map.areaCells[index].clear=paint&1 ? 1:0;
            map.areaCells[index].farm=paint&2 ? 1:0;
            map.areaCells[index].forbidden=paint&4 ? 1:0;
            map.occupancyCells[index].building=42;map.occupancyCells[index].immobileUnit=0;
            scalarClear(map,0,0,expected.data());
            map.seedClearAreasGradient(0,0,actual.data());
            CHECK(actual==expected);
            const bool goal=!(paint&4) && (n&2) && ((paint&1) || (farms && (paint&2) && !(n&4)));
            CHECK(actual[index]==(goal ? GRADIENT_AT_GOAL : GRADIENT_FORBIDDEN));
            map.occupancyCells[index].building=NOGBID;map.occupancyCells[index].immobileUnit=IMMOBILE_UNIT_NONE;
            map.areaCells[index].clear=map.areaCells[index].farm=map.areaCells[index].forbidden=0;
        }
        // Reuse the high-ID definitions through both other area kernels.
        map.areaCells[index].guard=1;
        for(int swim=0;swim<SWIM_CLASS_COUNT;++swim) {
            scalarGuard(map,0,swim,expected.data());
            map.seedGuardAreasGradient(0,swim,actual.data());
            CHECK(actual==expected);
            map.getForbiddenGradient(0,swim);
            map.updateForbiddenGradient(0,swim);
            CHECK(map.forbiddenGradient[0][swim][index]==((n&1) || swim==WATER_ONLY_CLASS ? GRADIENT_FORBIDDEN : GRADIENT_AT_GOAL));
        }
    }
}

TEST_CASE("published plane registry matches a sweep of live material fields" * doctest::test_suite("GradientPreparation"))
{
	glob2test::HeadlessGlobals globals;
	glob2test::HeadlessGame world({.wDec=5, .hDec=5, .teams=2, .clearImmobile=true, .header=true});
	auto& m = world.game.map;
	const auto sweep = [&] {
		std::map<Uint16, Uint16* const*> live;
		for (int t=0; t<Team::MAX_COUNT; ++t) for (int r=0; r<MaterialSlotCount; ++r) for (int s=0; s<SWIM_CLASS_COUNT; ++s)
		{
			if (m.materialGradients[t][r][s]) live.emplace(MapState::planeKey(t, r, s, false), &m.materialGradients[t][r][s]);
			if (m.marketMaterialGradients[t][r][s]) live.emplace(MapState::planeKey(t, r, s, true), &m.marketMaterialGradients[t][r][s]);
		}
		return live;
	};
	std::map<Uint16, Uint64> seen;
	const auto check = [&] {
		const auto live = sweep();
		const auto planes = m.publishedResourceFields();
		REQUIRE(planes.size() == live.size());
		for (const auto& plane : planes)
		{
			const auto found = live.find(plane.key);
			REQUIRE(found != live.end());
			CHECK(found->second == plane.slot);
			const auto id = MapState::decodePlaneKey(plane.key);
			CHECK(MapState::planeKey(id.team, id.resource, id.swim, id.market) == plane.key);
			CHECK(plane.generation > 0);
			auto [it, inserted] = seen.try_emplace(plane.key, plane.generation);
			if (!inserted) { CHECK(plane.generation >= it->second); it->second = plane.generation; }
		}
	};
	for (int resource=0; resource<3; ++resource) m.setResourceByIndex(10 + resource, 10, resource, 0);
	m.setMapDiscovered();
	check(); CHECK(m.publishedResourceFields().empty());
	m.getMaterialGradientSlot(0, WHEAT, 0); check();
	REQUIRE(m.publishedResourceFields().size() == 1);
	const auto first = m.publishedResourceFields()[0].generation;
	m.updateMaterialGradient(0, WHEAT, 0, false); check();
	CHECK(m.publishedResourceFields()[0].generation > first);
	m.getMaterialGradientSlot(1, WOOD, 2); check();
	std::vector<Uint16> observed(m.getW() * m.getH(), 5);
	m.installObservedResourceField(1, STONE, 1, observed); check();
	CHECK(m.publishedResourceFields().size() == 3);
	// Bulk slot changes re-register every live plane with a newer generation.
	std::map<Uint16, Uint64> before;
	for (const auto& plane : m.publishedResourceFields()) before[plane.key] = plane.generation;
	m.rebuildPlaneRegistry(); check();
	for (const auto& plane : m.publishedResourceFields()) CHECK(plane.generation > before.at(plane.key));
	// A captured snapshot sees exactly the registry, keyed the same way.
	const auto handle = SimulationSnapshot::capture(world.game, SimulationSnapshot::captureCatalog(world.game));
	REQUIRE(handle.resourceFields);
	CHECK(handle.resourceFields->planes.size() == 3);
	const auto* stone = handle.resourceFields->find(MapState::planeKey(1, STONE, 1, false));
	REQUIRE(stone); CHECK(stone->values->at(7) == 5);
	CHECK_FALSE(handle.resourceFields->find(MapState::planeKey(0, WOOD, 0, false)));
}

TEST_CASE("snapshot seeds preserve every periodic kind after the live world changes" * doctest::test_suite("GradientPreparation"))
{
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame world({.wDec=6, .hDec=6, .teams=2, .discovered=true, .clearImmobile=true, .loadDefaultRace=true, .header=true});
    auto& game=world.game; auto& m=game.map;
    game.gameHeader.getExperiments().set(ExperimentId::MarketsV2, true);
    game.gameHeader.getExperiments().set(ExperimentId::GuardAreaBalancing, true);
    game.gameHeader.getExperiments().set(ExperimentId::FarmAreas, true);
    game.configureBuildingCatalog();
    for (size_t i=0; i<m.size; ++i) {
        m.paintCell(i, static_cast<TerrainType>(i%TERRAIN_COUNT));
        m.resourceCells[i].resource=Resource{Uint16(i%3==0 ? WHEAT : NO_RES_TYPE),0,1,0};
        m.areaCells[i].forbidden=i%7==0?1:0;
        m.areaCells[i].guard=i%5==0?3:0;
        m.areaCells[i].clear=i%3==0?3:0;
        m.areaCells[i].farm=i%2==0?3:0;
        m.occupancyCells[i].immobileUnit=i%11==0?0:IMMOBILE_UNIT_NONE;
        m.fogOfWar[i]=i%2?1:3;
    }
    for (int pos : {32,33}) {
        m.paintCell(pos,pos,GRASS); m.resourceCells[m.coordToIndex(pos,pos)].resource=Resource{}; m.clearImmobileUnit(pos,pos);
    }
    REQUIRE(world.addUnit(WARRIOR,32,32));
    REQUIRE(world.addUnit(WARRIOR,33,33,1));
    using namespace gradient_preparation;
    for (auto kind : {Kind::Materials, Kind::Markets, Kind::Guard, Kind::Clear})
    for (int swim=0; swim<SWIM_CLASS_COUNT; ++swim) {
        Request request{kind,0,WHEAT,swim,game.teams[0]->allies,true,m.terrainQueueBuckets()};
        auto snapshot=SimulationSnapshot::capture(game, SimulationSnapshot::captureCatalog(game), request.requirements());
        std::vector<Uint16> expected(m.size), actual(m.size);
        if(kind==Kind::Materials || kind==Kind::Markets) scalarResource(m,0,WHEAT,swim,expected.data(),kind==Kind::Markets);
        else if(kind==Kind::Clear) scalarClear(m,0,swim,expected.data());
        else scalarGuard(m,0,swim,expected.data());
        CrowdingScratch scratch;
        seed(request,snapshot,actual.data(),scratch);
        requireSameField(m,"snapshot seed",actual,expected);
        m.propagateGradient(expected.data(),swim);
        // All worker input comes from the lease, even after these live writes.
        const auto old=m.areaCells[1].forbidden;
        m.areaCells[1].forbidden=~old;
        seed(request,snapshot,actual.data(),scratch);
        GradientWorkspace propagation;
        propagate(request,snapshot,actual.data(),propagation);
        requireSameField(m,"frozen propagation",actual,expected);
        m.areaCells[1].forbidden=old;
    }
}

TEST_CASE("periodic supplier snapshots subtract reservations and retain overlay seeds" * doctest::test_suite("GradientPreparation"))
{
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame world({.wDec=7, .hDec=7, .teams=2, .discovered=true, .clearImmobile=true, .loadDefaultRace=true, .header=true});
    auto& game=world.game; auto& m=game.map;
    auto catalog=nlohmann::json::parse(game.buildingsTypes.snapshotJson());
    auto& spec=catalog["variants"][game.buildingsTypes.getFinishedTypeNum("inn")];
    spec["properties"]["maxMaterial"][WHEAT]=20;
    spec["semantics"]["occupiesGround"]=false;
    auto& market=spec["semantics"]["market"];
    market["suppliesStock"]=true; market["suppliesStockExperiment"]="";
    market["suppliesStockMaterials"]={"food"}; market["pickupPenalty"]=7;
    game.buildingsTypes.loadSnapshotJson(catalog.dump());
    game.gameHeader.getExperiments().set(ExperimentId::MarketsV2,true);
    game.configureBuildingCatalog();
    auto* supplier=world.addBuilding("inn",8,8); REQUIRE(supplier);
    supplier->materials[WHEAT]=10;
    using namespace gradient_preparation;
    Request request{Kind::Markets,0,WHEAT,0};
    CrowdingScratch scratch;
    for (int reserved : {0,10}) {
        supplier->reservedMaterials[WHEAT]=reserved;
        auto snapshot=SimulationSnapshot::capture(game,SimulationSnapshot::captureCatalog(game),request.requirements());
        std::vector<Uint16> expected(m.size),actual(m.size);
        m.seedMaterialGradient(0,WHEAT,0,expected.data(),true);
        supplier->materials[WHEAT]=0;
        seed(request,snapshot,actual.data(),scratch);
        requireSameField(m,"supplier snapshot",actual,expected);
        supplier->materials[WHEAT]=10;
    }
}

TEST_CASE("snapshot material templates refresh changed chunks and accept older snapshots" * doctest::test_suite("GradientPreparation"))
{
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame world({.wDec=7,.hDec=7,.teams=2,.discovered=true,.clearImmobile=true,.header=true});
    auto& game=world.game; auto& map=game.map;
    for (size_t i=0;i<map.size;++i) {
        map.paintCell(i,static_cast<TerrainType>(i%TERRAIN_COUNT));
        map.replaceResource(i,Resource{Uint16(i%3==0?WHEAT:i%5==0?WOOD:NO_RES_TYPE),0,1,0});
    }
    using namespace gradient_preparation;
    Request request{Kind::Materials,0,WHEAT,0};
    SimulationSnapshot::Store store;
    auto before=store.captureBoundary(game,request.requirements());
    CrowdingScratch scratch;
    std::vector<Uint16> actual(map.size),expected(map.size);
    auto check=[&](const auto& snapshot) {
        for (int team : {0,1}) for (int material : {WHEAT,WOOD,STONE})
        for (int swim=0;swim<SWIM_CLASS_COUNT;++swim) {
            request.team=team;request.material=material;request.swim=swim;
            CrowdingScratch direct; direct.materials.budget=0;
            seed(request,snapshot,expected.data(),direct);
            seed(request,snapshot,actual.data(),scratch);
            requireSameField(map,"cached snapshot",actual,expected);
        }
    };
    check(before);
    const auto initial=scratch.materials.refreshedCells;
    CHECK(initial==size_t(map.size));
    check(before); CHECK(scratch.materials.refreshedCells==initial);
    map.replaceResource(0,Resource{});
    map.setVertexTerrain(1,1,WATER); // cells (0..1,0..1), all in the first chunk
    map.areaCells[2].forbidden=3; map.markArea(2);
    map.areaCells[5].guard=1; map.markArea(5);
    map.areaCells[6].clear=1; map.markArea(6);
    map.occupancyCells[3].immobileUnit=0; map.markOccupancy(3);
    map.fogOfWar[6]=0; map.markVisibility(6);
    ++game.stepCounter;
    auto after=store.captureBoundary(game,request.requirements());
    check(after);
    CHECK(scratch.materials.refreshedCells-initial==256);
    check(before); // Worker scheduling need not visit snapshot ticks in order.
    check(after);
    // A reused cache must discard templates after registry/world replacement.
    glob2test::HeadlessGame replacement({.wDec=7,.hDec=7,.teams=2,.discovered=true,.clearImmobile=true,.header=true});
    auto other=SimulationSnapshot::capture(replacement.game,SimulationSnapshot::captureCatalog(replacement.game),request.requirements());
    check(other);
}

TEST_CASE("GradientPreparation/explicit snapshot batches isolate invalid fields and retain exact output")
{
    using namespace gradient_kernel;
    const auto previous=backend();struct Restore {Backend value;~Restore(){setBackend(value);}} restore{previous};
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame fixture({.wDec=6,.hDec=6,.teams=1,.discovered=true,.clearImmobile=true,.header=true});
    auto& game=fixture.game;auto& map=game.map;
    map.setVertexTerrain(5,5,WATER);
    auto snapshot=SimulationSnapshot::capture(game,SimulationSnapshot::captureCatalog(game),gradient_preparation::buildingRequirements());
    std::array<std::vector<Uint16>,3> outputs,expected;
    std::array<std::exception_ptr,3> errors{};
    std::array<GradientWorkspace,3> scratch;
    std::vector<gradient_preparation::PropagationField> fields;
    setBackend(Backend::CPU);
    for(unsigned i=0;i<3;++i){
        outputs[i].assign(map.getW()*map.getH(),1);outputs[i][i]=65535;outputs[i][13]=0;
        outputs[i][21]=65000;expected[i]=outputs[i];
        map.propagateGradient(expected[i].data(),i==2?6:0);
        gradient_preparation::Request request;request.swim=i==2?6:0;request.terrainBuckets=i==1?65:64;
        fields.push_back({request,&snapshot,outputs[i].data(),&scratch[i],&errors[i]});
    }
    setBackend(Backend::OpenCL);gradient_preparation::propagateBatch(fields);
    CHECK(outputs[0]==expected[0]);CHECK(outputs[2]==expected[2]);
    CHECK_FALSE(errors[0]);CHECK_FALSE(errors[2]);REQUIRE(errors[1]);
    CHECK_THROWS_AS(std::rethrow_exception(errors[1]),std::invalid_argument);
    CHECK(outputs[1][1]==65535);CHECK(outputs[1][21]==65000); // Invalid field was never propagated.

}

TEST_CASE("GradientPreparation/modified terrain costs remain exact when field obstacles change")
{
    using namespace gradient_kernel;
    const auto previous=backend();struct Restore {Backend value;~Restore(){setBackend(value);}} restore{previous};
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame world({.wDec=6,.hDec=6,.teams=1,.discovered=true,.clearImmobile=true,.header=true});
    auto& map=world.game.map;
    map.game=nullptr;
    map.importTerrainDefinitions(R"({"schemaVersion":1,"terrains":[{"key":"test:gpu-cost","name":"Slow ground","base":"grass","appearance":"grass","properties":{"groundSpeedQ8":192}}]})");
    map.setGame(&world.game);
    map.paintCell(3,*map.terrainRegistry().find("test:gpu-cost"));
    const auto snapshot=SimulationSnapshot::capture(world.game,SimulationSnapshot::captureCatalog(world.game),gradient_preparation::buildingRequirements());
    REQUIRE(snapshot.terrain->movementModifiers);
    gradient_preparation::Request request;
    GradientWorkspace scratch;
    setBackend(Backend::OpenCL);
    map.configureCompute(3); // one eligible maintenance worker plus presentation
    if constexpr(GAGCore::ThreadSupport::available) {
        const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(30);
        while(initializationState.load()!=2 && std::chrono::steady_clock::now()<deadline) std::this_thread::yield();
        REQUIRE(initializationState.load()==2);
    }

    for (unsigned entry=0;entry<3;++entry) {
        for(unsigned phase=0;phase<2;++phase) {
            std::vector<Uint16> output(map.size,1);output[0]=65535;output[phase?37:13]=0;
            auto expected=output;
            setBackend(Backend::CPU);map.propagateGradient(expected.data(),0);
            setBackend(Backend::OpenCL);
            const auto completed=openCLStatus().committedFields;
            const bool deviceReady=readyPlans.load()&(1u<<unsigned(Plan::Frozen8));
            std::function<void()> work=[&] {
                if(entry==0) gradient_preparation::propagate(request,snapshot,output.data(),scratch);
                else if(entry==1) {
                    const gradient_preparation::PropagationField field{request,&snapshot,output.data(),&scratch};
                    gradient_preparation::propagateBatch(std::span(&field,1));
                } else map.propagateGradient(output.data(),0);
            };
            const ComputeExecutor::Group group{1,{[](void* p,std::size_t){(*static_cast<std::function<void()>*>(p))();},&work}};
            auto batch=map.computeExecutor().submit(std::span(&group,1)); map.computeExecutor().join(batch);
            CHECK(output==expected);
            if(deviceReady) { const auto status=openCLStatus(); if(status.committedFields!=completed+1) std::cerr<<"GPU_DIAGNOSTIC entry="<<entry<<" phase="<<phase<<" fields="<<status.fields<<" cpu="<<status.cpuSelections<<" error="<<status.error<<" budget="<<status.budgetDeclines<<" quarantines="<<status.requiredQuarantines<<" canceled="<<status.requiredCancellations<<"\n"; CHECK(status.committedFields==completed+1); }
        }
    }
}

TEST_CASE("GradientPreparation/minimal GPU views release source graphs and recover exact CPU fields")
{
    using namespace gradient_kernel;
    const auto previous=backend();struct Restore {Backend value;~Restore(){setBackend(value);}} restore{previous};
    setBackend(Backend::CPU);
    glob2test::HeadlessGlobals globals;
    const auto* activation=std::getenv("GLOB2_TEST_OPENCL_MINIMAL_COSTS");
    const bool nativeRequired=activation && !std::strcmp(activation,"1");
    ComputeExecutor nativeExecutor;
    if(nativeRequired) {
        REQUIRE(GAGCore::ThreadSupport::available);
        nativeExecutor.configure(2,[](auto work){return GAGCore::ThreadSupport::launch(std::move(work));});
    }
    for(bool modified:{false,true})for(int swim:{0,1,3,6,WATER_ONLY_CLASS})for(unsigned ring:{64u,128u,256u}) {
        CAPTURE(modified);CAPTURE(swim);CAPTURE(ring);
        glob2test::HeadlessGame world({.wDec=4,.hDec=4,.teams=1,.discovered=true,.clearImmobile=true,.header=true});
        auto& map=world.game.map;
        if(modified) {
            map.game=nullptr;
            map.importTerrainDefinitions(R"({"schemaVersion":1,"terrains":[{"key":"test:minimal-cost","name":"Slow ground","base":"grass","appearance":"grass","properties":{"groundSpeedQ8":192}}]})");
            map.setGame(&world.game);map.paintCell(3,*map.terrainRegistry().find("test:minimal-cost"));
        }
        map.setVertexTerrain(5,5,WATER);
        auto snapshot=SimulationSnapshot::capture(world.game,SimulationSnapshot::captureCatalog(world.game),gradient_preparation::buildingRequirements());
        // Distinct owners let expiry prove that the view did not retain the
        // Terrain or its table even though the live map has its own catalog.
        auto terrain=std::make_shared<SimulationSnapshot::Terrain>(*snapshot.terrain);
        auto rules=std::make_shared<CellRuleTable>(*terrain->rules);terrain->rules=rules;snapshot.terrain=terrain;
        std::weak_ptr<const SimulationSnapshot::Terrain> source=terrain;
        std::weak_ptr<const CellRuleTable> table=rules;
        gradient_preparation::Request request;request.swim=swim;request.terrainBuckets=ring;
        std::vector<Uint16> original(map.size,1);original[0]=65535;original[13]=0;original[21]=65000;
        auto expected=original;GradientWorkspace reference;
        gradient_preparation::propagateCPU(request,snapshot,expected.data(),reference);
        auto make=[&]{auto data=std::make_unique<Uint16[]>(map.size);std::copy(original.begin(),original.end(),data.get());return data;};
        auto data=make();auto session=std::make_shared<BackendSession>();
        auto owned=gradient_preparation::ownPropagation(request,snapshot,data,session,{Plan::Frozen8,session->currentGeneration()},17);
        REQUIRE(bool(owned));CHECK_FALSE(data);CHECK(owned->identity.owner==owned->inputs);
        CHECK(owned->identity.retainedBytes>0);CHECK(owned->retainedInputBytes==0);
        const auto before=gradient_preparation::minimalCostViewMetrics();
        auto otherData=make();auto other=gradient_preparation::ownPropagation(request,snapshot,otherData,session,{},17);
        REQUIRE(bool(other));CHECK(other->identity.owner==owned->identity.owner);
        CHECK(gradient_preparation::minimalCostViewMetrics().reused==before.reused+1);
        auto replacement=std::make_shared<SimulationSnapshot::Terrain>(*terrain);snapshot.terrain=replacement;
        auto replacedData=make();auto replaced=gradient_preparation::ownPropagation(request,snapshot,replacedData,session,{},17);
        REQUIRE(bool(replaced));CHECK(replaced->identity.owner!=owned->identity.owner); // Same revision, different control identity.
        replacement.reset();snapshot={};terrain.reset();rules.reset();
        CHECK(source.expired());CHECK(table.expired());
        // Original seeds have remained untouched throughout view construction.
        CHECK(std::equal(original.begin(),original.end(),owned->data.get()));
        owned->cpu(*owned);CHECK(std::vector<Uint16>(owned->data.get(),owned->data.get()+map.size)==expected);
        if(nativeRequired) {
            // The simulation/catalog owners are already gone. Exercise both
            // distinct cost owners at the same revision on a background worker,
            // with explicit proof that a real device result was committed.
            for(const auto& candidate:{owned,replaced}) {
                std::copy(original.begin(),original.end(),candidate->data.get());
                bool handled=false,executed=false,observed=false;
                std::function<void()> work=[&] {
                    REQUIRE(ComputeExecutor::workerSlot()!=0);
                    REQUIRE(initializeOpenCL());
                    REQUIRE((readyPlans.load()&(1u<<unsigned(Plan::Frozen8)))!=0);
                    BackendRequest native{candidate->data.get(),COST_LIMIT,candidate->grid,*session,candidate.get(),
                        [](void* context,std::size_t cell){auto& field=*static_cast<OwnedGradientField*>(context);return field.costAt(field,cell);},
                        [](void* context,Uint16*){auto& field=*static_cast<OwnedGradientField*>(context);field.cpu(field);},candidate->identity};
                    native.family=candidate->family;native.cpuBuckets=ring;
                    native.executedOnDevice=&executed;native.deviceExecutionObserved=&observed;
                    native.requiredControl=candidate->requiredControl;
                    handled=executeOpenCLDevice(std::span(&native,1),Plan::Frozen8);
                };
                const ComputeExecutor::Group group{1,{[](void* context,std::size_t){(*static_cast<std::function<void()>*>(context))();},&work}};
                auto ticket=nativeExecutor.submit(std::span(&group,1));nativeExecutor.join(ticket);
                REQUIRE(handled);REQUIRE(executed);REQUIRE(observed);
                CHECK(std::vector<Uint16>(candidate->data.get(),candidate->data.get()+map.size)==expected);
                CHECK(openCLStatus().hostBytes<=OpenCLHostBudget);
                CHECK(openCLStatus().deviceBytes<=OpenCLDeviceBudget);
            }
        }
    }
}

TEST_CASE("GradientPreparation/minimal view pressure declines without moving original seeds")
{
    using namespace gradient_kernel;
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame world({.wDec=4,.hDec=4,.teams=1,.discovered=true,.clearImmobile=true,.header=true});
    auto snapshot=SimulationSnapshot::capture(world.game,SimulationSnapshot::captureCatalog(world.game),gradient_preparation::buildingRequirements());
    auto data=std::make_unique<Uint16[]>(world.game.map.size);std::fill_n(data.get(),world.game.map.size,Uint16(77));
    const auto original=data.get();auto session=std::make_shared<BackendSession>();gradient_preparation::Request request;
    const auto current=openCLStatus().hostBytes;
    REQUIRE(current<=OpenCLHostBudget);const auto pressure=OpenCLHostBudget-current;
    REQUIRE(reserveOpenCLHostBytes(pressure));
    {
        struct Release {std::size_t bytes;~Release(){releaseOpenCLHostBytes(bytes);}} release{pressure};
        const auto before=gradient_preparation::minimalCostViewMetrics();
        CHECK_FALSE(gradient_preparation::ownPropagation(request,snapshot,data,session,{},17));
        CHECK(gradient_preparation::minimalCostViewMetrics().budgetDeclines==before.budgetDeclines+1);
    }
    CHECK(data.get()==original);CHECK(data[0]==77);CHECK(data[world.game.map.size-1]==77);
    auto malformed=std::make_shared<SimulationSnapshot::Terrain>(*snapshot.terrain);
    malformed->cellRules.pop_back();snapshot.terrain=malformed;
    const auto before=gradient_preparation::minimalCostViewMetrics();
    CHECK_FALSE(gradient_preparation::ownPropagation(request,snapshot,data,session,{},17));
    CHECK(gradient_preparation::minimalCostViewMetrics().representationDeclines==before.representationDeclines+1);
    CHECK(data.get()==original);CHECK(data[0]==77);
}

TEST_CASE("compiled preparation tables preserve rule and catalog interpretation" * doctest::test_suite("GradientPreparation"))
{
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame world({.wDec=5,.hDec=5,.teams=2,.discovered=true,.clearImmobile=true,.loadDefaultRace=true,.header=true});
    auto& map=world.game.map;
    for(std::size_t i=0;i<map.size;++i)map.paintCell(i,static_cast<TerrainType>(i%TERRAIN_COUNT));
    const auto snapshot=SimulationSnapshot::capture(world.game,SimulationSnapshot::captureCatalog(world.game),
        gradient_preparation::Request{gradient_preparation::Kind::Clear}.requirements());
    const auto& rules=*snapshot.terrain->rules;
    REQUIRE(rules.gradientPreparation().size()==rules.size());
    for(std::size_t id=0;id<rules.size();++id)for(unsigned swim=0;swim<8;++swim){
        const auto& original=rules[Uint16(id)];const auto& compact=rules.gradientPreparation()[id];
        CHECK(bool(compact.accessibility&(1u<<swim))==gradient_kernel::terrainAllowsGround(original.properties,swim));
        CHECK((compact.costs[swim]&65535)==original.ground[swim].cardinal);
        CHECK((compact.costs[swim]>>16)==original.ground[swim].diagonal);
    }
    const auto& resources=*snapshot.catalogs->resources;
    REQUIRE(resources.gradientPreparation().size()==resources.size());
    for(std::size_t id=0;id<resources.size();++id){
        const auto& original=resources.properties(static_cast<ResourceId>(id));
        const auto compact=resources.gradientPreparation()[id];
        CHECK((compact&AllMaterials)==original.materialMask);
        CHECK(bool(compact&(1u<<16))==original.blocksGround);
        CHECK(bool(compact&(1u<<17))==original.visibleToHarvest);
        CHECK(bool(compact&(1u<<18))==original.clearable);
        CHECK(bool(compact&(1u<<19))==original.farmable);
    }
}

TEST_CASE("rejected corner identities preserve all compiled gradient tables" *
		  doctest::test_suite("GradientPreparation"))
{
	glob2test::HeadlessGlobals globals;
	CellRuleTable table(TerrainRegistry::builtins(), ResourceRegistry::builtins());
	table.intern(GRASS, SAND, GRASS, SAND);
	const auto original = table;
	const auto invalid = static_cast<TerrainType>(TerrainRegistry::builtins()->size());
	CHECK_THROWS_AS(table.intern(GRASS, SAND, GRASS, invalid), std::invalid_argument);
	REQUIRE(table.size() == original.size());
	CHECK(table.gradientPreparation().size() == original.gradientPreparation().size());
	for (unsigned swim = 0; swim < 8; ++swim)
	{
		const auto &actual = table.movement(swim);
		const auto &expected = original.movement(swim);
		CHECK(actual.entries.size() == expected.entries.size());
		CHECK(actual.profiles.size() == expected.profiles.size());
		CHECK(actual.profileIds == expected.profileIds);
		CHECK(actual.steps == expected.steps);
		CHECK(actual.minimum == expected.minimum);
	}
	// A subsequent valid insertion still issues the next stable rule identity.
	CHECK(table.intern(GRASS, GRASS, GRASS, SAND) == original.size());
	CHECK(table.gradientPreparation().size() == table.size());
}

TEST_CASE("movement profile rejection rolls back previously appended swim classes" *
		  doctest::test_suite("GradientPreparation"))
{
	glob2test::HeadlessGlobals globals;
	CellRuleTable table(TerrainRegistry::builtins(), ResourceRegistry::builtins());
	// Force the final class's documented profile limit. Earlier classes have
	// already appended entries when this rejection occurs; rollback must cover
	// their prepared metadata as well as the unpublished derived record.
	auto &capped = const_cast<TerrainRegistry::Movement &>(table.movement(7));
	capped.profiles.assign(256, gradient_kernel::EntrySteps{1, 1});
	const auto original = table;
	const auto corners = CellRuleTable::key(GRASS, SAND, GRASS, SAND);
	CHECK_THROWS_AS(table.intern(corners), std::length_error);
	CHECK_FALSE(table.find(corners).has_value());
	CHECK(table.size() == original.size());
	CHECK(table.gradientPreparation().size() == original.gradientPreparation().size());
	for (unsigned swim = 0; swim < 8; ++swim)
	{
		const auto &actual = table.movement(swim);
		const auto &expected = original.movement(swim);
		REQUIRE(actual.entries.size() == expected.entries.size());
		REQUIRE(actual.profiles.size() == expected.profiles.size());
		CHECK(actual.profileIds == expected.profileIds);
		CHECK(actual.steps == expected.steps);
		CHECK(actual.minimum == expected.minimum);
		REQUIRE(actual.prepared.has_value() == expected.prepared.has_value());
		if (actual.prepared)
			std::visit(
				[&](const auto &profile)
				{
					using Profile = std::remove_cvref_t<decltype(profile)>;
					const auto *previous = std::get_if<Profile>(&*expected.prepared);
					REQUIRE(previous != nullptr);
					CHECK(profile.terrainClasses == previous->terrainClasses);
					CHECK(profile.cardinalSlots == previous->cardinalSlots);
					CHECK(profile.diagonalSlots == previous->diagonalSlots);
					CHECK(profile.steps == previous->steps);
					CHECK(profile.maxAppends == previous->maxAppends);
					CHECK(profile.classCount == previous->classCount);
					CHECK(profile.stepCount == previous->stepCount);
				},
				*actual.prepared);
		for (std::size_t i = 0; i < actual.entries.size(); ++i)
		{
			CHECK(actual.entries[i].cardinal == expected.entries[i].cardinal);
			CHECK(actual.entries[i].diagonal == expected.entries[i].diagonal);
		}
	}
}
