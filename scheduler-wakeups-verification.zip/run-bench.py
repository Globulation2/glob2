from pathlib import Path
import random,subprocess
p=Path(__file__).parent
with (p/'bench-results.log').open('w') as out:
 for trial in range(5):
  cases=[(workers,shape,gap) for workers in [0,1,2,4] for shape in range(5) for gap in [0,20000]]
  random.Random(trial).shuffle(cases)
  for workers,shape,gap in cases:
   order=['before','after'];random.Random(trial+shape+workers+gap).shuffle(order)
   for variant in order:
    r=subprocess.run([str(p/('bench-'+variant)),str(workers+1),str(shape),str(gap),'5000'],capture_output=True,text=True,check=True)
    out.write(f'trial={trial} variant={variant} '+r.stdout);out.flush()
  print('bench trial',trial,'complete',flush=True)
with (p/'bench-timed.log').open('w') as out:
 for trial in range(5):
  for workers in [1,2,4]:
   for variant in ['before','after']:
    r=subprocess.run([str(p/('bench-'+variant+'-timed')),str(workers+1),'0','20000','5000'],capture_output=True,text=True,check=True)
    out.write(f'trial={trial} variant={variant} '+r.stdout);out.flush()
