#include EXHEADER
#include <iostream>
struct Work { std::atomic<unsigned> done{0}; unsigned iterations; };
void calculate(void* value,std::size_t) {
 auto& work=*static_cast<Work*>(value);unsigned x=1;
 for(unsigned i=0;i<work.iterations;++i){x=x*1664525u+1013904223u;asm volatile("" : "+r"(x));}
 work.done.fetch_add(1,std::memory_order_relaxed);
}
int main(int argc,char**argv) {
 const unsigned threads=std::atoi(argv[1]),shape=std::atoi(argv[2]),gap=std::atoi(argv[3]),n=std::atoi(argv[4]);
 ComputeExecutor executor;executor.configure(threads);Work work{{0},argc>5?unsigned(std::atoi(argv[5])):1000u};
 std::array<ComputeExecutor::Group,4> groups{};const ComputeExecutor::Job job{calculate,&work};
 unsigned groupCount=1,jobs=1;
 switch(shape){
  case 0:groups[0]={1,job,3};break;
  case 1:groups[0]={1,job};break;
  case 2:groups[0]={16,job,3};jobs=16;break;
  case 3:groups[0]={16,job};jobs=16;break;
  default:groups={{{4,job,1},{4,job,2},{4,job},{4,job}}};groupCount=4;jobs=16;
 }
 std::array<ComputeExecutor::Batch,8> batches{};unsigned check=0;
 auto start=std::chrono::steady_clock::now();
 for(unsigned tick=0;tick<n;++tick){
  if(tick>=8)executor.join(batches[tick%8]);
  batches[tick%8]=executor.submit(std::span(groups.data(),groupCount),tick+8);
  for(unsigned i=0;i<gap;++i){check=check*1664525u+1013904223u;asm volatile("" : "+r"(check));}
 }
 for(auto& b:batches)if(!b.empty())executor.join(b);
 const auto ns=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();
 std::cout<<"workers="<<threads-1<<" shape="<<shape<<" gap="<<gap<<" batches="<<n<<" jobs="<<n*jobs<<" done="<<work.done<<" ns_per_batch="<<double(ns)/n<<" check="<<check;
#ifdef TIMED
 std::cout<<" submit_lock_ns="<<double(SubmitProbe::lockNs)/n<<" submit_body_ns="<<double(SubmitProbe::bodyNs)/n<<" submit_unlock_wake_ns="<<double(SubmitProbe::wakeNs)/n;
#endif
 std::cout<<"\n";return work.done==n*jobs?0:1;
}
