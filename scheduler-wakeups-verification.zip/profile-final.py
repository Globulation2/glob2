from pathlib import Path
import os,subprocess,time,json,statistics
p=Path(__file__).parent
while not (p/'engine-tests.xml').exists():time.sleep(2)
for source,target in [('bench-results.log','bench-results-loaded.log'),('bench-timed.log','bench-timed-loaded.log')]:
 if (p/source).exists() and not (p/target).exists():(p/source).rename(p/target)
subprocess.run(['python3',str(p/'run-bench.py')],check=True)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_PERF_DISABLE='1',GLOB2_STATS_BENCHMARK='1',GLOB2_STATS_BENCHMARK_TICKS='2048',GLOB2_STATS_PROFILE='1')
for trial in range(3):
 for variant,binary in [('before','artifacts/teamstats/capture-submission/deferred-benchmark'),('after',str(p/'deferred-engine-tests'))]:
  with (p/f'advancing-{variant}-{trial}.log').open('w') as out:subprocess.run([binary,'--test-suite=TeamStatsPipeline','--test-case=advancing match statistics timing*'],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
 print('advancing profile',trial,'passed',flush=True)
for variant,binary in [('before','artifacts/teamstats/capture-submission/deferred-benchmark'),('after',str(p/'deferred-engine-tests'))]:
 with (p/f'trace-{variant}.log').open('w') as out:subprocess.run([binary,'--test-suite=TeamStatsPipeline','--test-case=advancing match statistics timing*'],env=dict(env,GLOB2_STATS_PROFILE='0',GLOB2_STATS_BENCHMARK_TICKS='520',GLOB2_STATS_BENCHMARK_CHECKSUM='1'),stdout=out,stderr=subprocess.STDOUT,check=True)
 print('per-tick traces',variant,'passed',flush=True)
