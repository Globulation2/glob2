from pathlib import Path
import subprocess
p=Path(__file__).parent
for name,path in [('after.h','src/common/ComputeExecutor.h'),('ComputeTelemetry.h','src/common/ComputeTelemetry.h'),('ThreadSupport.h','libgag/include/ThreadSupport.h'),('PresentationWork.h','libgag/include/PresentationWork.h')]: (p/name).write_bytes(Path(path).read_bytes())
for name in ['before','after']:
 s=(p/(name+'.h')).read_text().replace('class ComputeExecutor :','struct SubmitProbe { inline static std::uint64_t lockNs=0,bodyNs=0,wakeNs=0; };\nclass ComputeExecutor :',1)
 index=s.index('Batch submitImpl(');a=s[:index];b=s[index:]
 b=b.replace('std::unique_lock<std::mutex> lock(mutex);','const auto probeStart=std::chrono::steady_clock::now();\n        std::unique_lock<std::mutex> lock(mutex);\n        const auto probeLocked=std::chrono::steady_clock::now();',1)
 b=b.replace('\t\tlock.unlock();','\t\tconst auto probeFilled=std::chrono::steady_clock::now();\n\t\tlock.unlock();',1)
 b=b.replace('\t\treturn batch;\n\t}\npublic:', '''        const auto probeWoken=std::chrono::steady_clock::now();
        SubmitProbe::lockNs+=std::chrono::duration_cast<std::chrono::nanoseconds>(probeLocked-probeStart).count();
        SubmitProbe::bodyNs+=std::chrono::duration_cast<std::chrono::nanoseconds>(probeFilled-probeLocked).count();
        SubmitProbe::wakeNs+=std::chrono::duration_cast<std::chrono::nanoseconds>(probeWoken-probeFilled).count();
        return batch;
    }
public:''',1)
 (p/(name+'-timed.h')).write_text(a+b)
 for timed in [False,True]:
  label=name+('-timed' if timed else '');args=['clang++','-std=c++20','-O3','-g','-pthread','-I'+str(p),'-DEXHEADER="'+label+'.h"',str(p/'bench.cpp'),'-o',str(p/('bench-'+label))]+(['-DTIMED'] if timed else [])
  subprocess.run(args,check=True)
 print(name,'built',flush=True)
