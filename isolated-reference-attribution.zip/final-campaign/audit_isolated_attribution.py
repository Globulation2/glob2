#!/usr/bin/env python3
import json,math,statistics,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parents[2]/'test'))
import benchmark_resource_refactor as b
base=HERE/'isolated-attribution-01'
cp=json.loads(base.with_name(base.name+'-cpuset.json').read_text())
assert cp['state']=='completed' and cp['exit_code']==0 and cp['cgroup_restored'] and cp['wrapper_affinity_restored'] and not cp['forced_cgroup_kill']
assert json.loads((base/'inputs-before.json').read_text())==json.loads((base/'inputs-after.json').read_text())
state=json.loads((base/'campaign-state.json').read_text());assert state['status']=='complete' and state['completed']==['priority-fixes','priority-refactor']
reserved=set(range(8))|set(range(16,24));outside=set(range(32))-reserved
out={'status':'verified','input_snapshots_equal':True,'cpuset_restored':True,'partition_checks':cp['validity_checks'],'campaigns':{}}
def activity(rows):
 vals=[]
 for r in rows:
  a=r['host_cpu_activity']; assert a['status']=='available'
  sums={name:sum(a['per_cpu_busy_s'][f'cpu{i}'] for i in cpus) for name,cpus in [('reserved',reserved),('outside',outside),('siblings',set(range(16,24)))]}
  vals.append({'scenario':r['scenario'],'repeat':r['repeat'],'variant':r['variant'],'snapshot_elapsed_s':a['snapshot_elapsed_s'],'child_cpu_s':r['cpu_s'],**{k+'_cpu_s':v for k,v in sums.items()},'reserved_residual_cpu_s':sums['reserved']-r['cpu_s']})
 def stats(v):
  total=sum(r['snapshot_elapsed_s'] for r in v)
  return {'rows':len(v),'snapshot_elapsed_s':total,**{k:{'total_s':sum(r[k] for r in v),'weighted_average_cores':sum(r[k] for r in v)/total,'min_average_cores':min(r[k]/r['snapshot_elapsed_s'] for r in v),'max_average_cores':max(r[k]/r['snapshot_elapsed_s'] for r in v)} for k in ['reserved_cpu_s','reserved_residual_cpu_s','outside_cpu_s','siblings_cpu_s']}}
 return {'rows':vals,'all':stats(vals),'measured':stats([v for v in vals if v['repeat']>=0]),'by_variant':{variant:stats([v for v in vals if v['repeat']>=0 and v['variant']==variant])for variant in ['baseline','candidate']}}
for name in state['completed']:
 rows=[json.loads(x)for x in (base/name/'measurements.jsonl').read_text().splitlines()];assert len(rows)==68
 summary=json.loads((base/name/'summary.json').read_text());pairs={};checksums={}
 for s in sorted({r['scenario'] for r in rows}):
  sr=[r for r in rows if r['scenario']==s];assert len(sr)==34
  for i in range(-1,16):
   pair=[r for r in sr if r['repeat']==i]
   assert [r['variant']for r in pair]==(['baseline','candidate']if i%2 else ['candidate','baseline'])
   assert all(r['result']['benchmark_measured_ticks']==8192 and r['result']['ticks']==32768 for r in pair)
  checksums[s]={v:sorted({r['result']['finalChecksum']for r in sr if r['variant']==v}) for v in ['baseline','candidate']}
  assert all(len(x)==1 for x in checksums[s].values())
  pairs[s]=[{r['variant']:r for r in sr if r['repeat']==i}for i in range(16)]
  for metric,reported in summary['scenarios'][s].items():
   logs=[math.log(p['candidate'][metric]/p['baseline'][metric])for p in pairs[s]]
   assert math.isclose(math.exp(statistics.mean(logs)),reported['ratio'],rel_tol=1e-14) and b.interval(logs)==reported['ci95']
   for v in ['baseline','candidate']:assert statistics.median(p[v][metric]for p in pairs[s])==reported[v+'_median']
 assert b.aggregate_interval([[math.log(p['candidate']['simulation_cpu_s']/p['baseline']['simulation_cpu_s'])for p in ps]for ps in pairs.values()])==summary['aggregate_cpu']
 gov=json.loads((base/(name+'-governors.json')).read_text());assert gov['restored'] and not gov.get('child_cleanup_error')
 inv=json.loads((base/name/'input-verification.json').read_text());assert inv['state']=='verified' and inv['inputs_unchanged']
 out['campaigns'][name]={'runs':68,'measured_runs':64,'warmup_runs':4,'governors_restored':True,'inputs_verified':True,'summary_recomputed_exactly':True,'summary':summary,'activity':activity(rows),'checksums_by_variant':checksums}
out['limits']='Reference cost attribution, not optimization gain or gameplay equivalence. All three historical reference outputs differ; variants are repeat-stable, but cross-reference checksums are not equal and differing behavior/representation is part of attribution. Paired geometric means and seeded4000-draw bootstrap CIs describe these fixed windows. Simulation CPU includes all threads through finishSession and drain but excludes setup/requested save; whole-child wait4CPU includes setup/exit. Residual busy is reserved /proc/stat busy minus whole-childCPU, includes wrappers/kernel and jiffy/boundary skew, not process attribution. Outside work is expected under verified isolation; package power/thermal/memory/IRQ effects remain possible.'
(base/'independent-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({n:{'aggregate':v['summary']['aggregate_cpu'],'activity':v['activity']['measured']}for n,v in out['campaigns'].items()},indent=2))
