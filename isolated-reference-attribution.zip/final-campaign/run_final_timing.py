#!/usr/bin/env python3
"""Coordinator-only sequential timing. Default prints commands without launching anything."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import subprocess
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ROOT = BASE.parents[1]
sys.path.insert(0, str(ROOT / 'test'))
import benchmark_resource_refactor as benchmark

LIBS = '/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib'
HASHES = {
    'pure': '8296540a82234e060250b1b6d8d445743e239f7049e1bd6c5219c4f6c36accab',
    'approved': '91d3543383785811fc1fbd79ee497d6cdf7c67201464383ba09f471fbf741741',
    'merged': '77fb4b9d29432cdfea08734b4eb0b0d3eb7c354862fdc9820ba01c89a76333b6',
    'reuse-v2': '4a068846b4adf1aeeebdecbac94fca423f588398319aa0a25f7e5382cee5610b',
}
BINS = {key: BASE / 'pr846-retained' / f'symbolized-f0-{key}' / 'glob2' for key in ('pure', 'approved')}
BINS['merged'] = BASE / 'merged-reference/glob2'
BINS['reuse-v2'] = BASE / 'candidate-gradient-reuse-v2/glob2'
ROOTS = {key: BASE / f'control-f0-{key}' for key in ('pure', 'approved')}
ROOTS['merged'] = BASE / 'merged-reference'
ROOTS['reuse-v2'] = BASE / 'candidate-gradient-reuse-v2'
V2_PATCH_SHA = 'a5cb13ab13e4659c0c2453a36f63ef5fbf29c5b4fba4f4ef63558000a5bc14a2'
V2_SOURCE_SHA = '3c7eaa506f2bc6b9a13d95157e9d279fcba7e97b49ddbc093412f3b27f0da4b2'
SPECS = [
    ('priority-fixes', 'pure', 'approved', BASE / 'priority-recovery/priority-windows.json', 16, 2,
     'Cost attribution of approved behavior fixes, not an optimization or equivalence claim.'),
    ('legacy-refactor', 'approved', 'merged', HERE / 'legacy-98-windows.json', 8, 98,
     'Approved-control versus merged reference attribution. No accepted optimization candidate exists.'),
    ('eight-team-refactor', 'approved', 'merged', HERE / 'eight-team-timing-windows.json', 8, 3,
     'Separate 512-square eight-team attribution; do not pool into the 98-window aggregate.'),
    ('custom-calibration', 'merged', 'merged', HERE / 'custom-stress-timing-windows.json', 8, 6,
     'Same-binary calibration and absolute CPU/RSS. Ratios are not optimization evidence; idle-AI custom growth/storage only.'),
]

DEFAULT_CAMPAIGNS = tuple(row[0] for row in SPECS)
SPECS.insert(1, (
    'priority-refactor', 'approved', 'merged', BASE / 'priority-recovery/priority-windows.json', 16, 2,
    'Priority-only approved-behavior-control versus merged reference attribution; separate from intended fixes and v2 optimization effect.'
))
# Explicit opt-in only. No retained speedup or completed priority campaign implied.
SPECS += [
    ('v2-priority', 'merged', 'reuse-v2', BASE / 'priority-recovery/priority-windows.json', 16, 2,
     'Exploratory or controlled v2 retention assessment as separately documented by coordinator; no automatic retention decision.'),
    ('v2-legacy', 'merged', 'reuse-v2', HERE / 'legacy-98-windows.json', 8, 98,
     'Primary merged-reference versus frozen v2 full legacy comparison, after coordinator priority decision.'),
    ('v2-eight-team', 'merged', 'reuse-v2', HERE / 'eight-team-timing-windows.json', 8, 3,
     'Separate merged-reference versus frozen v2 large eight-team comparison.'),
    ('v2-custom', 'merged', 'reuse-v2', HERE / 'custom-stress-timing-windows.json', 8, 6,
     'Actual merged-reference versus frozen v2 custom comparison, not same-binary calibration. Idle-AI growth/storage stress only.'),
]



def data_hashes(root):
    return {str(p.relative_to(root / 'data')): benchmark.digest(p)
            for p in sorted((root / 'data').rglob('*')) if p.is_file()}


def commands(output, selected):
    result = []
    for name, before, after, manifest, repeats, count, meaning in SPECS:
        if name not in selected:
            continue
        after_root = output / 'custom-identical-root' if name == 'custom-calibration' else ROOTS[after]
        command = [sys.executable, str(ROOT / 'test/run_with_benchmark_governor.py'),
                   '--audit', str(output / f'{name}-governors.json'), '--timeout-seconds', '43200',
                   '--cpus', *map(str, range(8)), '--', 'taskset', '-c', '0-7', sys.executable,
                   str(ROOT / 'test/benchmark_resource_refactor.py'), str(BINS[before]), str(BINS[after]),
                   str(manifest), '--before-root', str(ROOTS[before]), '--after-root', str(after_root),
                   '--repeats', str(repeats), '--report-only', '--output', str(output / name)]
        result.append(dict(name=name, command=command, purpose=meaning, scenario_count=count,
                           measured_pairs=repeats, discarded_pairs_per_scenario=1))
    return result


def validate_manifest(path, count):
    content = json.loads(path.read_text())
    scenarios = content['scenarios']
    if len(scenarios) != count or len({s['id'] for s in scenarios}) != count:
        raise RuntimeError(f'Unexpected scenario inventory: {path}')
    for scenario in scenarios:
        args = scenario['args']
        for flag in ('--load-game', '--ticks', '--compute-threads', '--compute-experiments', '--gradient-workers', '--gradient-delay'):
            if args.count(flag) != 1 or args.index(flag) + 1 >= len(args):
                raise RuntimeError(f'Missing/duplicate {flag}: {scenario["id"]}')
        if int(args[args.index('--ticks') + 1]) <= scenario['start_tick']:
            raise RuntimeError(f'Empty window: {scenario["id"]}')
        save = args[args.index('--load-game') + 1]
        if not Path(save).is_absolute() or save not in scenario['fixture_sha256']:
            raise RuntimeError(f'Unverified fixture: {scenario["id"]}')
        for fixture, expected in scenario['fixture_sha256'].items():
            if benchmark.digest(fixture) != expected:
                raise RuntimeError(f'Fixture changed: {fixture}')
    return content


def input_snapshot(selected):
    result = {'orchestrator': benchmark.digest(__file__), 'scripts': {}, 'binaries': {}, 'data': {}, 'libraries': {}, 'manifests': {}, 'provenance': {}}
    for path in (ROOT / 'test/run_with_benchmark_governor.py', *benchmark.RUNNER_INPUTS):
        result['scripts'][str(path)] = benchmark.digest(path)
    arms = {arm for name, before, after, *_ in SPECS if name in selected for arm in (before, after)}
    for arm in sorted(arms):
        actual = benchmark.digest(BINS[arm])
        if actual != HASHES[arm]:
            raise RuntimeError(f'Frozen binary changed: {arm}')
        result['binaries'][arm] = actual
        result['data'][arm] = data_hashes(ROOTS[arm])
        result['libraries'][arm] = benchmark.runtime_libraries(BINS[arm])['sha256']
        if arm in ('pure', 'approved'):
            provenance = json.loads((ROOTS[arm] / 'historical-provenance.json').read_text())['runtime']
            expected_data = {str(Path(key).relative_to('data')): value for key, value in provenance['data_inputs'].items()}
            expected_libraries = {key: value['sha256'] for key, value in provenance['shared_libraries'].items()}
        else:
            prior = json.loads((BASE / 'priority-timing/paired-01/metadata.json').read_text())
            expected_data = {str(Path(key).relative_to('data')): value for key, value in prior['data_roots']['baseline']['files'].items()}
            expected_libraries = json.loads((ROOTS[arm] / 'provenance.json').read_text())['runtime_libraries']['sha256']
        if arm == 'reuse-v2':
            provenance_path = ROOTS[arm] / 'provenance.json'
            patch_path = ROOTS[arm] / 'source.patch'
            data_path = ROOTS[arm] / 'data-freeze.json'
            provenance = json.loads(provenance_path.read_text())
            if (provenance['binary_sha256'] != HASHES[arm] or provenance['patch_sha256'] != V2_PATCH_SHA
                    or provenance['source']['sourceTreeSha256'] != V2_SOURCE_SHA
                    or benchmark.digest(patch_path) != V2_PATCH_SHA):
                raise RuntimeError('Frozen v2 source/provenance binding changed')
            if json.loads(data_path.read_text())['catalog_hashes'] != expected_data:
                raise RuntimeError('Frozen v2 catalog provenance differs from merged reference')
            for path in (provenance_path, patch_path, data_path):
                result['provenance'][str(path)] = benchmark.digest(path)
        observed_catalogs = {key: value for key, value in result['data'][arm].items() if Path(key).suffix in benchmark.CATALOG_SUFFIXES}
        if observed_catalogs != expected_data:
            raise RuntimeError(f'Previously verified catalog input changed: {arm}')
        if result['libraries'][arm] != expected_libraries:
            raise RuntimeError(f'Previously verified runtime libraries changed: {arm}')
    if 'reuse-v2' in arms and result['data']['reuse-v2'] != result['data']['merged']:
        raise RuntimeError('Frozen v2 full data tree differs from merged reference')
    for name, _, _, path, _, count, _ in SPECS:
        if name in selected:
            manifest = validate_manifest(path, count)
            result['manifests'][name] = {'sha256': benchmark.digest(path), 'manifest': manifest}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path, help='Fresh campaign directory; never reused')
    parser.add_argument('--run', action='store_true', help='Coordinator only, after exclusive timing reservation')
    parser.add_argument('--campaign', action='append', choices=[row[0] for row in SPECS])
    args = parser.parse_args()
    output = args.output.resolve()
    selected = set(args.campaign or DEFAULT_CAMPAIGNS)
    plan = commands(output, selected)
    print(json.dumps({'environment': {'LD_LIBRARY_PATH': LIBS}, 'campaigns': plan,
                      'launch_requires': 'Exclusive coordinator timing reservation; no owned builds/profiles/compression and an acceptable external-host preflight.'}, indent=2))
    if not args.run:
        return 0
    output.mkdir(parents=True, exist_ok=False)
    os.environ['LD_LIBRARY_PATH'] = LIBS
    original = input_snapshot(selected)
    benchmark.write_json(output / 'inputs-before.json', original)
    if 'custom-calibration' in selected:
        shutil.copytree(ROOTS['merged'] / 'data', output / 'custom-identical-root/data')
        if data_hashes(output / 'custom-identical-root') != original['data']['merged']:
            raise RuntimeError('Custom calibration data copy differs')
    benchmark.write_json(output / 'plan.json', {'campaigns': plan, 'environment': {'LD_LIBRARY_PATH': LIBS}})
    state = {'status': 'running', 'completed': []}
    active = None
    interrupted = False
    def stop(signum, frame):
        nonlocal interrupted
        if not interrupted:
            interrupted = True
            if active is not None and active.poll() is None:
                active.send_signal(signal.SIGINT)  # Let wrapper restore governors and reap its engine group.
    handlers = {sig: signal.signal(sig, stop) for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)}
    try:
        for item in plan:
            if interrupted:
                raise InterruptedError('Coordinator interrupted campaign')
            if input_snapshot(selected) != original:
                raise RuntimeError('Campaign input changed between timing groups')
            name = item['name']
            if name == 'custom-calibration' and data_hashes(output / 'custom-identical-root') != original['data']['merged']:
                raise RuntimeError('Custom calibration copy changed')
            state['active'] = name
            benchmark.write_json(output / 'campaign-state.json', state)
            with (output / f'{name}.log').open('x') as log:
                if interrupted:
                    raise InterruptedError('Coordinator interrupted before launch')
                active = subprocess.Popen(item['command'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                if interrupted:
                    active.send_signal(signal.SIGINT)
                code = active.wait()
            active = None
            audit = json.loads((output / f'{name}-governors.json').read_text())
            if code != 0 or audit.get('restored') is not True or audit.get('child_cleanup_error') or interrupted:
                raise RuntimeError(f'{name} failed/interrupted or governors/children not restored; see retained log and audit')
            verification = json.loads((output / name / 'input-verification.json').read_text())
            summary = json.loads((output / name / 'summary.json').read_text())
            if verification.get('state') != 'verified' or not verification.get('inputs_unchanged') or len(summary['scenarios']) != item['scenario_count']:
                raise RuntimeError(f'{name} incomplete or invalid')
            state['completed'].append(name)
        after = input_snapshot(selected)
        benchmark.write_json(output / 'inputs-after.json', after)
        if after != original:
            raise RuntimeError('Campaign input changed')
        state.update(status='complete', active=None)
    except BaseException as error:
        state.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        try:
            if active is not None and active.poll() is None:
                active.send_signal(signal.SIGINT)
                active.wait(timeout=90)  # Never SIGKILL the governor owner during restoration.
        finally:
            try:
                benchmark.write_json(output / 'campaign-state.json', state)
            finally:
                for sig, handler in handlers.items():
                    signal.signal(sig, handler)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
