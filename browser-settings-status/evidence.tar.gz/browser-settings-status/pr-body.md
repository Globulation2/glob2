The storage-error screenshot visibly contains the support-size status text, but the visual assertion counts only18 solid-dark pixels and requires more than50. Include its antialiased ink for this status check while preserving the shared helper default and pixel-count floor. Add a blank-paper negative check so absent text still fails.

All6 quota/aborted-transaction cases pass across Chromium, Firefox and WebKit. Persistence failure, retry, old durable values and reload assertions remain intact. No production changes.

[Measured positive/negative pixel counts, before/after screenshots and exact browser commands](https://github.com/Globulation2/glob2/tree/evidence/master-ci-recovery-1198/browser-settings-status).
