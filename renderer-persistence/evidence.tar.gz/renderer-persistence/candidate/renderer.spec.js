const helpers=require("/home/bradley/.codex/worktrees/2ae630e5-9773-4605-8d29-1c8941969170/glob2/browser/tests/main-menu.js");
const realDone=helpers.clickSettingsDone;
helpers.clickSettingsDone=async page=>{
  const {expect}=require("/home/bradley/.codex/worktrees/2ae630e5-9773-4605-8d29-1c8941969170/glob2/browser/node_modules/@playwright/test");
  await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().persisting),{timeout:120000}).toBe(false);
  await page.evaluate(()=>{
    if(window.delayedSettingsDoneInstalled)return;
    window.delayedSettingsDoneInstalled=true;
    const original=FS.syncfs;let delayed=false;
    FS.syncfs=function(populate,callback){
      if(!populate&&!delayed){delayed=true;return original.call(FS,populate,error=>setTimeout(()=>callback(error),35000));}
      return original.call(FS,populate,callback);
    };
  });
  await realDone(page);
};
// SPDX-License-Identifier: GPL-3.0-or-later
const {test,expect}=require("/home/bradley/.codex/worktrees/2ae630e5-9773-4605-8d29-1c8941969170/glob2/browser/node_modules/@playwright/test");
const {gameURL,clickMainMenu,clickControl,clickByLabel,clickSettingsDone,clickCustomGameStart,controlBox}=require("/home/bradley/.codex/worktrees/2ae630e5-9773-4605-8d29-1c8941969170/glob2/browser/tests/main-menu");
const {clickCreateMap}=require("/home/bradley/.codex/worktrees/2ae630e5-9773-4605-8d29-1c8941969170/glob2/browser/tests/editor-controls");
const {hasDarkText}=require("/home/bradley/.codex/worktrees/2ae630e5-9773-4605-8d29-1c8941969170/glob2/browser/tests/pixels");
const state=page=>page.evaluate(()=>glob2Diagnostics.snapshot());
const screen=(page,name)=>expect.poll(async()=>{const s=await state(page);return s.screen+' '+s.screenClass;},{timeout:120000}).toContain(name);
const generation=page=>page.evaluate(()=>Module.glob2PresentationSurface.generation);
async function settingsPersisted(page) {
  // Software-backed GL can leave a settings write in flight after drawing
  // the new renderer. Wait for durable storage before the next UI action.
  await expect.poll(async()=>(await state(page)).persisting,{timeout:120000}).toBe(false);
}
async function choose(page,label) {
  await settingsPersisted(page);
  const before={generation:await generation(page),loop:(await state(page)).loop};
  await clickControl(page,'graphics.renderer');
  await clickByLabel(page,/popup/,label);
  // In threaded builds FS belongs to the application worker. The requested
  // choice alone is also insufficient: a failed switch retains that choice.
  // Surface generation advances only after successful transaction commit.
  await expect.poll(()=>{if(page.rendererSwitchErrors?.length)throw Error(page.rendererSwitchErrors.join('\n'));return generation(page);},{timeout:120000}).toBeGreaterThan(before.generation);
  await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['graphics.renderer']?.label)).toContain(label);
  // Module.renderer is the surface transport family: both GPU contexts use
  // 'webgl2'. Verify WebGPU against the actual owner and replacement canvas.
  const active={'Software':'software','Programmable GL':'webgl2','WebGPU':'webgl2'}[label];
  if(!active)throw Error('Missing active renderer expectation for '+label);
  try {
    await expect.poll(()=>page.evaluate(()=>Module.renderer),{timeout:120000}).toBe(active);
    if(label==='WebGPU') {
      const owners=await presentationOwners(page);expect(owners).toHaveLength(1);
      await expect.poll(()=>owners[0].evaluate(()=>{
        const g=Glob2WebGPU;
        return g.state===1&&!g.lost&&g.context?.canvas===Module.canvas&&!!g.screen;
      }),{timeout:120000}).toBe(true);
      await test.info().attach('active-webgpu-owner',{body:JSON.stringify(await owners[0].evaluate(()=>({
        state:Glob2WebGPU.state,error:Glob2WebGPU.error,issued:Glob2WebGPU.issued,
        completed:Glob2WebGPU.completed,canvasOwned:Glob2WebGPU.context.canvas===Module.canvas,
        adapter:Glob2WebGPU.adapter?.info?{vendor:Glob2WebGPU.adapter.info.vendor,
          architecture:Glob2WebGPU.adapter.info.architecture,device:Glob2WebGPU.adapter.info.device,
          description:Glob2WebGPU.adapter.info.description}:null
      })),null,2),contentType:'application/json'});
    }
  } catch (error) {
    // Preserve the actual owner failure after automatic fallback. A requested
    // label and a replacement canvas do not establish successful GPU rendering.
    const owners=await presentationOwners(page);
    const diagnostics=await Promise.all(owners.map(owner=>owner.evaluate(()=>{
      const g=globalThis.Glob2WebGPU;
      return g?{state:g.state,error:g.error,lost:g.lost,epoch:g.epoch,
        issued:g.issued,completed:g.completed,bytes:g.totalBytes(),
        frames:g.frames.length,captures:g.captures.length,
        resources:g.resources.size,meshes:g.meshes.size,masks:g.masks.size}:null;
    })));
    await test.info().attach('renderer-switch-failure',{body:JSON.stringify({
      requested:label,active:await page.evaluate(()=>Module.renderer),
      generation:await generation(page),diagnostics,snapshot:await state(page)
    },null,2),contentType:'application/json'});
    throw error;
  }
  if(label==='Programmable GL') {
    const owners=await presentationOwners(page);
    expect(owners).toHaveLength(1);
    const driver=await owners[0].evaluate(()=>{
      const gl=Module.canvas.getContext('webgl2');
      if(!gl)return null;
      const debug=gl.getExtension('WEBGL_debug_renderer_info');
      return {version:gl.getParameter(gl.VERSION),renderer:gl.getParameter(gl.RENDERER),
        unmaskedRenderer:debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):null};
    });
    expect(driver,'Successful Programmable GL switch must own a WebGL2 context').not.toBeNull();
    test.info().annotations.push({type:'Actual WebGL2 driver',description:driver.unmaskedRenderer||driver.renderer});
    await test.info().attach('webgl2-driver',{body:JSON.stringify(driver,null,2),contentType:'application/json'});
  }
  await expect.poll(async()=>(await state(page)).loop,{timeout:120000}).toBeGreaterThan(before.loop+1);
  await expect.poll(async()=>hasDarkText(page,await controlBox(page,'graphics.renderer',{fullyVisible:true})),{timeout:120000}).toBe(true);
  await expect(page.locator('#canvas')).toHaveCount(1);
  expect(await page.evaluate(()=>document.querySelector('#canvas').isConnected)).toBe(true);
}
async function start(page,mode) {
  const errors=[];page.rendererSwitchErrors=errors;page.on('pageerror',error=>errors.push(String(error)));
  const url=new URL(gameURL(),'http://localhost');url.searchParams.set('threads',mode);url.searchParams.set('renderer','software');
  await page.goto(url.pathname+url.search);await screen(page,'MainMenuScreen');
  const execution=(await state(page)).executionMode;
  test.skip(execution!==mode,'Browser does not support the requested execution mode');
  await page.evaluate(()=>{globalThis.rendererSwitchApplicationToken={module:Module,action:Module._glob2_context_action,starts:Module.glob2ApplicationStarts,thread:Module.glob2ApplicationThreadIdentity};globalThis.rendererSwitchToken=rendererSwitchApplicationToken;});
  return async()=>{
    expect(await page.evaluate(()=>rendererSwitchToken===rendererSwitchApplicationToken&&rendererSwitchToken.module===Module&&rendererSwitchToken.action===Module._glob2_context_action)).toBe(true);
    expect(await page.evaluate(()=>({starts:Module.glob2ApplicationStarts,thread:Module.glob2ApplicationThreadIdentity}))).toEqual(await page.evaluate(()=>({starts:rendererSwitchToken.starts,thread:rendererSwitchToken.thread})));
    expect(await page.evaluate(()=>Module.glob2ApplicationStarts)).toBe(1);
    expect((await state(page)).executionMode).toBe(execution);
    expect(errors).toEqual([]);
  };
}
async function openMenu(page) {
  if (!(await state(page)).controls.return) await page.locator('#canvas').press('Escape',{delay:80});
  await expect.poll(async()=>Boolean((await state(page)).controls.return)).toBe(true);
}
async function openOverlay(page) {
  await openMenu(page);
  await clickControl(page,'settings');await screen(page,'SettingsScreen');
}
async function resumeOverlay(page) {
  await clickSettingsDone(page);
  await settingsPersisted(page);
  // Settings closes the menu before opening. Wait for the parent screen to
  // resume and clear its old input before sending a new physical key.
  await expect.poll(async()=>(await state(page)).screenClass).not.toContain('SettingsScreen');
  const loop=(await state(page)).loop;
  await expect.poll(async()=>(await state(page)).loop,{timeout:120000}).toBeGreaterThan(loop+2);
  if ((await state(page)).controls.return) await clickControl(page,'return');
}
async function presentationOwners(page) {
  const threaded=(await state(page)).executionMode==='threaded';
  if(!threaded)return [page];
  if(page.rendererPresentationOwner)return [page.rendererPresentationOwner];
  const identity=await page.evaluate(()=>Module.glob2ApplicationThreadIdentity);
  // The DOM page and idle asset workers load the same libraries. Only the
  // application pthread owns renderer initialization; Software deliberately
  // has no Module.canvas in that worker, so canvas presence is not a predicate.
  const realms=threaded?page.workers():[page];
  const owners=await Promise.all(realms.map(async realm=>{
    let timer;
    try{return await Promise.race([
      realm.evaluate(({threaded,identity})=>
        typeof Glob2WebGPU==='object'&&typeof Module==='object'&&
        (threaded
          ? typeof ENVIRONMENT_IS_PTHREAD!=='undefined'&&ENVIRONMENT_IS_PTHREAD&&
            typeof _pthread_self==='function'&&_pthread_self()===identity
          : typeof ENVIRONMENT_IS_PTHREAD==='undefined'||!ENVIRONMENT_IS_PTHREAD),
      {threaded,identity}).catch(()=>false),
      new Promise(resolve=>{timer=setTimeout(()=>resolve(false),5000);})
    ]);}finally{clearTimeout(timer);}
  }));
  const found=realms.filter((realm,index)=>owners[index]);
  if(found.length===1) {
    page.rendererPresentationOwner=found[0];
    found[0].once('close',()=>{page.rendererPresentationOwner=null;});
  }
  return found;
}
async function match(page) {
  const owners=await presentationOwners(page);
  expect(owners).toHaveLength(1);
  const owner=owners[0],rootSeed=0xdecafbad,candidates=[];
  const record=message=>{if(message.text().startsWith('Map generation:'))candidates.push(message.text());};
  page.on('console',record);
  await owner.evaluate(seed=>{
    // Emscripten's random_get requests four bytes for std::random_device.
    // Scope this override to map setup, on the application thread only. UUIDs,
    // account crypto and all other request sizes retain real entropy.
    const original=crypto.getRandomValues,descriptor=Object.getOwnPropertyDescriptor(crypto,'getRandomValues');
    const receipt={rootSeed:seed,requests:0};
    Object.defineProperty(crypto,'getRandomValues',{configurable:true,value:function(view){
      if(ArrayBuffer.isView(view)&&view.byteLength===4){
        new DataView(view.buffer,view.byteOffset,view.byteLength).setUint32(0,seed,true);
        ++receipt.requests;return view;
      }
      return original.call(this,view);
    }});
    globalThis.rendererMapEntropy={receipt,restore:()=>{
      if(descriptor)Object.defineProperty(crypto,'getRandomValues',descriptor);
      else delete crypto.getRandomValues;
      delete globalThis.rendererMapEntropy;
      return receipt;
    }};
  },rootSeed);
  let receipt;
  try {
    await clickMainMenu(page,'custom');
    await clickControl(page,'generator/colonies');await clickByLabel(page,/popup/,'2');
    for(const dimension of ['width','height']) {
      await clickControl(page,'generator/'+dimension);await clickByLabel(page,/popup/,'128');
    }
    await clickCustomGameStart(page);
    await screen(page,'GameSessionScreen');
  } finally {
    receipt=await owner.evaluate(()=>rendererMapEntropy.restore());
    page.off('console',record);
    await test.info().attach('map-entropy-fixture',{body:JSON.stringify({
      ...receipt,generator:'fingerprint',width:128,height:128,colonies:2,candidates,
      note:'Fixed root entropy, not an assertion that the last logged candidate is the selected map seed.'
    },null,2),contentType:'application/json'});
  }
  expect(receipt.requests,'Pinned map fixture must consume the scoped four-byte entropy').toBeGreaterThan(0);
  expect(candidates.at(-1),'Pinned map setup must finish the expected generation').toBe('Map generation: fingerprint revision 5 seed 4039698994 [complete]: ');
  await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(25);
}
async function available(page,label) {
  await clickControl(page,'graphics.renderer');
  const offered=await page.evaluate(label=>Object.entries(glob2Diagnostics.snapshot().controls).some(([key,value])=>/popup/.test(key)&&value.label===label),label);
  await page.locator('#canvas').press('Escape',{delay:80});
  if (label!=='WebGPU') return offered;
  // Compiled shaders alone do not establish an adapter. In threaded builds
  // inspect the application worker that owns the backend, not the DOM realm.
  let reason=offered?'Presentation-owner WebGPU realm could not be inspected':'Renderer selector reports WebGPU unavailable';
  // Idle Emscripten asset pthreads may be inside Atomics.wait forever. Probe
  // all realms with bounded waits before sending async work to the GPU owner.
  const realms=await presentationOwners(page);
  for (let index=0;index<realms.length;++index) {
    const realm=realms[index];
    let timer,result;
    try{result=await Promise.race([realm.evaluate(async()=>{
      if(!globalThis.navigator?.gpu)return {available:false,reason:'Presentation owner has no navigator.gpu'};
      try{return await navigator.gpu.requestAdapter() ? {available:true} : {available:false,reason:'Presentation owner returned no WebGPU adapter'};}
      catch(error){return {available:false,reason:String(error)};}
    }).catch(()=>null),new Promise(resolve=>{timer=setTimeout(()=>resolve({available:false,reason:'Presentation-owner adapter request timed out'}),15000);})]);}
    finally{clearTimeout(timer);}
    if(!result)continue;
    if(result.available){if(offered)return true;break;}
    reason=result.reason;break;
  }
  page.rendererBackendUnavailableReason=reason;
  test.info().annotations.push({type:'WebGPU coverage omitted',description:reason});
  return false;
}
for(const mode of ['serial','threaded']) {
  test(`${mode}: Automatic resolving to the active Software renderer completes without replacing the surface`,async({page},info)=>{
    test.setTimeout(360000);const verify=await start(page,mode);await match(page);await openOverlay(page);
    // direct0 keeps Software as its initial automatic policy. Capture the actual
    // presentation object as well as its generation to detect redundant teardown.
    expect(await page.evaluate(()=>Module.renderer)).toBe('software');
    const before={generation:await generation(page),loop:(await state(page)).loop};
    await page.evaluate(()=>{globalThis.rendererNoopCanvas=Module.canvas;});
    await clickControl(page,'graphics.renderer');await clickByLabel(page,/popup/,'Automatic');
    await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['graphics.renderer']?.label)).toContain('Automatic');
    await expect.poll(async()=>(await state(page)).loop,{timeout:120000}).toBeGreaterThan(before.loop+3);
    expect(await generation(page)).toBe(before.generation);
    expect(await page.evaluate(()=>Module.canvas===rendererNoopCanvas&&Module.renderer==='software')).toBe(true);
    await verify();
    // A subsequent real switch must be admitted: a no-op left in Preparing
    // would stall this request and all following capture admission.
    await choose(page,'Programmable GL');await resumeOverlay(page);
    const completed=()=>page.evaluate(async()=>{
      const root=await(await navigator.storage.getDirectory()).getDirectoryHandle('glob2-recordings',{create:true});
      const paths=[];for await(const [name,handle]of root.entries())if(name.endsWith('.complete')&&(await handle.getFile()).size)paths.push(name);return paths;
    });
    const previousRecordings=new Set(await completed());
    await openMenu(page);
    await clickControl(page,'recording/toggle');
    await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['recording/toggle']?.label)).toMatch(/Stop recording/i);
    await clickControl(page,'return');const tick=(await state(page)).tick;
    await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(tick+10);
    await openMenu(page);
    await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['recording/toggle']?.label)).toMatch(/Stop recording/i);
    await clickControl(page,'recording/toggle');
    await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['recording/toggle']?.label)).not.toMatch(/Stop recording/i);
    await expect.poll(async()=>(await completed()).filter(path=>!previousRecordings.has(path)).length,{timeout:60000}).toBe(1);
    const recording=(await completed()).find(path=>!previousRecordings.has(path));
    const metadata=await page.evaluate(async name=>{
      const root=await(await navigator.storage.getDirectory()).getDirectoryHandle('glob2-recordings');
      const file=await(await root.getFileHandle(name.slice(0,-9)+'.json')).getFile();
      return JSON.parse(await file.text());
    },recording);
    expect(metadata.complete).toBe(true);expect(metadata.width).toBeGreaterThan(0);expect(metadata.height).toBeGreaterThan(0);
    await info.attach('automatic-noop-recording-metadata',{body:JSON.stringify(metadata,null,2),contentType:'application/json'});
    await page.screenshot({path:info.outputPath('automatic-noop-following-capture.png')});await verify();
  });
  test(`${mode}: repeated menu switches preserve Wasm lifetime and input`,async({page},info)=>{
    test.setTimeout(360000);const verify=await start(page,mode);
    await clickMainMenu(page,'settings');await screen(page,'SettingsScreen');
    for(let cycle=0;cycle<3;++cycle) {
      await choose(page,'Programmable GL');
      await page.screenshot({path:info.outputPath('gl-'+cycle+'.png')});
      await choose(page,'Software');
    }
    await clickSettingsDone(page);await screen(page,'MainMenuScreen');
    await match(page);await page.setViewportSize({width:1280,height:720});
    // A single physical key opens exactly one menu after repeated replacement.
    await page.locator('#canvas').press('Escape',{delay:80});await clickControl(page,'return');
    const tick=(await state(page)).tick;
    await expect.poll(async()=>(await state(page)).tick).toBeGreaterThan(tick);
    await verify();
  });
  test(`${mode}: gameplay and torus survive settings overlay switches`,async({page},info)=>{
    test.setTimeout(360000);const verify=await start(page,mode);await match(page);
    const tick=(await state(page)).tick;
    await openOverlay(page);await choose(page,'Programmable GL');await resumeOverlay(page);
    await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(tick);
    await page.locator('#canvas').press('g',{delay:80});
    await expect.poll(async()=>(await state(page)).torusSettled,{timeout:120000}).toBe(true);
    await page.screenshot({path:info.outputPath('torus-before-switch.png')});
    await openOverlay(page);await choose(page,'Software');await resumeOverlay(page);
    await expect.poll(async()=>(await state(page)).torus).toBe(false);
    await openOverlay(page);await choose(page,'Programmable GL');await resumeOverlay(page);
    const restored=await state(page);
    await info.attach('torus-restored-before-key',{body:JSON.stringify({screenClass:restored.screenClass,
      controls:Object.keys(restored.controls),renderer:restored.renderer,tick:restored.tick,
      torus:restored.torus,torusSettled:restored.torusSettled}),contentType:'application/json'});
    expect(restored.screenClass).toContain('GameSessionScreen');
    expect(restored.controls.done).toBeUndefined();
    // An unsupported backend resets the view. As in the native switching
    // harness, activate Torus afresh after returning to a capable renderer.
    await expect.poll(async()=>(await state(page)).torus,{timeout:120000}).toBe(false);
    await page.locator('#canvas').press('g',{delay:80});
    await expect.poll(async()=>(await state(page)).torusSettled,{timeout:120000}).toBe(true);
    await page.locator('#canvas').press('g',{delay:80});
    await expect.poll(async()=>(await state(page)).torus,{timeout:120000}).toBe(false);
    await page.locator('#canvas').press('g',{delay:80});
    await expect.poll(async()=>(await state(page)).torusSettled,{timeout:120000}).toBe(true);
    await page.screenshot({path:info.outputPath('torus-after-switch.png')});await verify();
  });
  test(`${mode}: editor stays open across live renderer switches and resize`,async({page},info)=>{
    test.setTimeout(360000);const verify=await start(page,mode);
    await clickMainMenu(page,'editor');await screen(page,'EditorMainMenu');await clickControl(page,'new-map');
    await screen(page,'NewMapScreen');await clickCreateMap(page);await screen(page,'MapEditorScreen');
    for(const label of ['Programmable GL','Software']) {
      await openOverlay(page);await choose(page,label);await resumeOverlay(page);await screen(page,'MapEditorScreen');
      const viewport={width:label==='Software'?1200:1001,height:label==='Software'?900:701};
      await page.setViewportSize(viewport);
      // Diagnostics retain controls from suspended screen hosts. Inspect the
      // active editor menu rather than the retained EditorMainMenu's bounds.
      await openMenu(page);
      await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls.settings?.surface),
        {timeout:120000}).toEqual({w:viewport.width,h:viewport.height});
      await clickControl(page,'return');
      await page.screenshot({path:info.outputPath('editor-'+label+'.png')});
    }
    await openMenu(page);await clickControl(page,'quit');
    await clickControl(page,'choice/1');await screen(page,'EditorMainMenu');await verify();
  });
  test(`${mode}: recording retains one session while changing backend`,async({page},info)=>{
    test.setTimeout(480000);const verify=await start(page,mode);await match(page);
    const completed=()=>page.evaluate(async()=>{
      const root=await(await navigator.storage.getDirectory()).getDirectoryHandle('glob2-recordings',{create:true});
      const paths=[];for await(const [name,handle]of root.entries())if(name.endsWith('.complete')&&(await handle.getFile()).size)paths.push(decodeURIComponent(name).slice(0,-9));return paths;
    });
    const existing=new Set(await completed());
    await openMenu(page);await clickControl(page,'recording/toggle');
    await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['recording/toggle']?.label)).toMatch(/Stop recording/i);
    await clickControl(page,'return');const started=(await state(page)).tick;
    await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(started+10);
    await openOverlay(page);
    if(await available(page,'WebGPU')) {
      await choose(page,'WebGPU');
      const owners=await presentationOwners(page);expect(owners).toHaveLength(1);const owner=owners[0];
      await owner.evaluate(()=>{
        const recorder=Module.glob2Recording,frame=recorder.frame;
        globalThis.rendererRecordedWebGPU={frames:0,restore(){recorder.frame=frame;}};
        recorder.frame=function(...args){const accepted=frame.apply(this,args);if(accepted&&JSON.parse(args[4]).screen==='game_session')rendererRecordedWebGPU.frames++;return accepted;};
      });
      try {
        await resumeOverlay(page);const webgpuTick=(await state(page)).tick;
        await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(webgpuTick+10);
        await expect.poll(()=>owner.evaluate(()=>rendererRecordedWebGPU.frames),{timeout:120000}).toBeGreaterThan(0);
        await info.attach('recording-active-webgpu',{body:JSON.stringify({state:await state(page),acceptedFrames:await owner.evaluate(()=>rendererRecordedWebGPU.frames)},null,2),contentType:'application/json'});
        await openOverlay(page);
      } finally {await owner.evaluate(()=>{rendererRecordedWebGPU.restore();delete globalThis.rendererRecordedWebGPU;});}
    }
    await choose(page,'Programmable GL');await choose(page,'Software');await resumeOverlay(page);
    const resumed=(await state(page)).tick;
    await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(resumed+10);
    await openMenu(page);
    await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['recording/toggle']?.label)).toMatch(/Stop recording/i);
    await clickControl(page,'recording/toggle');
    try {
      await expect.poll(async()=>(await completed()).filter(path=>!existing.has(path)).length,{timeout:60000}).toBe(1);
    } catch(error) {
      // A writer lock or stalled worker must not hide the original assertion.
      const inspect=async operation=>{
        let timer;try{return await Promise.race([
          Promise.resolve().then(operation).catch(e=>({inspectionError:String(e)})),
          new Promise(resolve=>{timer=setTimeout(()=>resolve({inspectionTimedOut:true}),5000);})
        ]);}finally{clearTimeout(timer);}
      };
      const evidence={};
      try {
        evidence.producer=await inspect(async()=>{
          const owners=await presentationOwners(page);
          if(owners.length!==1)throw Error('Expected one actual recording producer');
          return owners[0].evaluate(()=>({active:Module.glob2Recording.active,
            status:Module.glob2Recording.status,frames:Module.glob2Recording.frames,audio:Module.glob2Recording.audio}));
        });
        evidence.files=await inspect(()=>page.evaluate(async()=>{
          const root=await(await navigator.storage.getDirectory()).getDirectoryHandle('glob2-recordings');
          const files=[];for await(const[name,handle]of root.entries()) {
            const path=decodeURIComponent(name);
            try {
              const file=await handle.getFile();
              files.push({path,size:file.size,text:/manifest|\.json$/.test(path)?(await file.text()).slice(0,20000):undefined});
            } catch(e) {files.push({path,inspectionError:String(e)});}
          }return files;
        }));
        evidence.workers=await Promise.all(page.workers().filter(worker=>worker.url().includes('recording-worker')).map(worker=>
          inspect(()=>worker.evaluate(()=>({workerState:state,stopped,processing,frameCredits,
            closing:!!closing,terminal,files:[...recordingStorage.files].map(([name,value])=>({name,size:value.sync.getSize()}))})))));
        evidence.snapshot=await inspect(()=>state(page));
      } catch(e) {evidence.collectionError=String(e);}
      finally {
        await inspect(()=>info.attach('recording-completion-failure',{body:JSON.stringify(evidence,null,2),contentType:'application/json'}));
        throw error;
      }
    }
    const path=(await completed()).find(path=>!existing.has(path));
    const metadata=await page.evaluate(async path=>{const root=await(await navigator.storage.getDirectory()).getDirectoryHandle('glob2-recordings');return JSON.parse(await(await(await root.getFileHandle(encodeURIComponent(path+'.json'))).getFile()).text());},path);
    expect(metadata.complete).toBe(true);expect(metadata.width).toBe(1200);expect(metadata.height).toBe(900);
    const chapters=metadata.chapters.filter(chapter=>chapter.screen==='game_session');
    expect(chapters.length).toBeGreaterThan(1);
    const identity=chapters[0];expect(identity.match).toBeGreaterThan(0);
    for(const chapter of chapters) {
      expect(chapter.match).toBe(identity.match);expect(chapter.mode).toBe(identity.mode);
      expect(chapter.map).toBe(identity.map);expect(chapter.team).toBe(identity.team);
      expect(chapter.tick).toBeGreaterThanOrEqual(identity.tick);
    }
    await info.attach('recording-switch-metadata',{body:JSON.stringify(metadata,null,2),contentType:'application/json'});
    await clickControl(page,'recording/files');await screen(page,'RecordingFilesScreen');
    const download=page.waitForEvent('download');await clickControl(page,'export/'+path);
    const video=await download,file=info.outputPath('backend-switch-recording.mp4');await video.saveAs(file);
    expect(require('node:fs').statSync(file).size).toBeGreaterThan(1000);
    const probe=JSON.parse(require('node:child_process').execFileSync(process.env.GLOB2_FFPROBE||'ffprobe',
      ['-v','error','-show_entries','stream=codec_name,codec_type,width,height:format=duration','-of','json',file],
      {encoding:'utf8',timeout:10000}));
    const videoStream=probe.streams.find(stream=>stream.codec_type==='video');
    expect(videoStream).toMatchObject({codec_name:'h264',width:metadata.width,height:metadata.height});
    expect(probe.streams.some(stream=>stream.codec_type==='audio'&&stream.codec_name==='aac')).toBe(true);
    expect(Number(probe.format.duration)).toBeGreaterThan(0);
    await info.attach('backend-switch-media-probe',{body:JSON.stringify(probe,null,2),contentType:'application/json'});
    await info.attach('backend-switch-video',{path:file,contentType:'video/mp4'});await verify();
  });
  test(`${mode}: all available WebGPU pairs retain application ownership`,async({page},info)=>{
    test.setTimeout(480000);const verify=await start(page,mode);
    await clickMainMenu(page,'settings');await screen(page,'SettingsScreen');
    test.skip(!await available(page,'WebGPU'),'WebGPU assets or browser/device capability unavailable');
    for(const label of ['Programmable GL','WebGPU','Software','WebGPU','Programmable GL','Software'])await choose(page,label);
    await page.screenshot({path:info.outputPath('all-backend-pairs.png')});await verify();
  });
  test(`${mode}: current GL context restores after earlier canvas replacements`,async({page},info)=>{
    test.setTimeout(360000);const verify=await start(page,mode);await match(page);
    for(const label of ['Programmable GL','Software','Programmable GL']){await openOverlay(page);await choose(page,label);await resumeOverlay(page);}
    const before=await state(page);
    await page.evaluate(()=>Module._glob2_context_action(0));await expect.poll(async()=>(await state(page)).contextLost).toBe(true);
    await page.evaluate(()=>Module._glob2_context_action(1));
    await expect.poll(async()=>(await state(page)).contextRestores,{timeout:120000}).toBeGreaterThan(before.contextRestores);
    await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(before.tick);
    await page.screenshot({path:info.outputPath('restored-current-context.png')});await verify();
  });
  test(`${mode}: real WebGPU device loss falls back during gameplay`,async({page},info)=>{
    test.setTimeout(360000);const verify=await start(page,mode);await match(page);await openOverlay(page);
    test.skip(!await available(page,'WebGPU'),'WebGPU assets or browser/device capability unavailable');
    await choose(page,'WebGPU');await resumeOverlay(page);
    const before={generation:await generation(page),tick:(await state(page)).tick};
    await page.evaluate(()=>Module._glob2_context_action(2));
    await expect.poll(()=>{if(page.rendererSwitchErrors?.length)throw Error(page.rendererSwitchErrors.join('\n'));return generation(page);},{timeout:120000}).toBeGreaterThan(before.generation);
    await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(before.tick);
    const owners=await presentationOwners(page);expect(owners).toHaveLength(1);
    const fallback=await owners[0].evaluate(()=>{
      const gl=Module.canvas.getContext('webgl2');
      if(gl){
        const debug=gl.getExtension('WEBGL_debug_renderer_info');
        return {family:'programmable-gl',version:gl.getParameter(gl.VERSION),
          renderer:debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),
          oldWebGPUCanvasActive:Glob2WebGPU.context?.canvas===Module.canvas};
      }
      return {family:Module.renderer==='software'&&Module.canvas.getContext('2d')?'software':null,
        oldWebGPUCanvasActive:Glob2WebGPU.context?.canvas===Module.canvas};
    });
    expect(['programmable-gl','software']).toContain(fallback.family);
    expect(fallback.oldWebGPUCanvasActive).toBe(false);
    await info.attach('actual-device-loss-fallback',{body:JSON.stringify(fallback,null,2),contentType:'application/json'});
    await openOverlay(page);
    expect(await page.evaluate(()=>glob2Diagnostics.snapshot().controls['graphics.renderer']?.label)).toContain('WebGPU'); // Successful preference survives automatic fallback.
    await page.screenshot({path:info.outputPath('device-loss-fallback.png')});await resumeOverlay(page);await verify();
  });
  test(`${mode}: presentation surface creation failure restores the running session`,async({page},info)=>{
    test.setTimeout(360000);const verify=await start(page,mode);await match(page);await openOverlay(page);
    const before={generation:await generation(page),loop:(await state(page)).loop};
    await page.evaluate(()=>{const surface=Module.glob2PresentationSurface,original=surface.prepare;Module.rendererFaultConsumed=0;Module.rendererSurfaceCleanup=()=>{surface.prepare=original;};surface.prepare=function(...args){surface.prepare=original;Module.rendererFaultConsumed++;throw Error('injected presentation surface creation failure');};});
    try {
      await clickControl(page,'graphics.renderer');await clickByLabel(page,/popup/,'Programmable GL');
      await expect.poll(()=>page.evaluate(()=>Module.rendererFaultConsumed)).toBe(1);
      await expect.poll(async()=>(await state(page)).loop,{timeout:120000}).toBeGreaterThan(before.loop+4);
      expect(await generation(page)).toBe(before.generation);
      expect(await page.evaluate(()=>Module.renderer)).toBe('software');
      await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['graphics.renderer']?.label)).toContain('Programmable GL');
      await page.screenshot({path:info.outputPath('surface-creation-rollback.png')});
      await choose(page,'Programmable GL');await choose(page,'Software');await verify();
    } finally { await page.evaluate(()=>{Module.rendererSurfaceCleanup?.();delete Module.rendererSurfaceCleanup;delete Module.rendererFaultConsumed;}); }
  });
  test(`${mode}: canvas replacement preserves active fullscreen host`,async({page},info)=>{
    test.setTimeout(360000);const verify=await start(page,mode);
    test.skip(!await page.evaluate(()=>document.fullscreenEnabled),'Fullscreen unavailable on browser/device');
    await clickMainMenu(page,'settings');await screen(page,'SettingsScreen');
    await page.locator('#canvas').click({position:{x:5,y:5}});
    await page.evaluate(()=>Module.glob2PresentationSurface.fullscreenHost.requestFullscreen());
    await expect.poll(()=>page.evaluate(()=>document.fullscreenElement===Module.glob2PresentationSurface.fullscreenHost)).toBe(true);
    for(const label of ['Programmable GL','Software']) {
      await choose(page,label);
      expect(await page.evaluate(()=>document.fullscreenElement===Module.glob2PresentationSurface.fullscreenHost)).toBe(true);
    }
    await page.screenshot({path:info.outputPath('fullscreen-replaced-canvas.png')});await page.evaluate(()=>document.exitFullscreen());await verify();
  });
}

// Serial-only API interception exercises the actual shaders, uploads and
// presentation calls. The application worker owns these APIs in threaded mode;
// the shared surface failure and device-loss cases above cover its public bridge.
test('serial: shader upload presentation and rollback failures preserve the session',async({page},info)=>{
  test.setTimeout(900000);const verify=await start(page,'serial');await match(page);await openOverlay(page);
  test.skip(!await available(page,'WebGPU'),'WebGPU unavailable on browser/device');
  test.skip(!await page.evaluate(()=>typeof FS!=='undefined'&&typeof Glob2WebGPU!=='undefined'&&typeof GL!=='undefined'),'Serial graphics owner APIs unavailable');
  await choose(page,'Programmable GL');
  const shaderPath='/shaders/webgpu/primitive.vert.wgsl';
  await page.evaluate(path=>{Module.rendererShaderOriginal=FS.readFile(path,{encoding:'utf8'});FS.writeFile(path,'this is deliberately invalid WGSL');},shaderPath);
  try {
    await clickControl(page,'graphics.renderer');await clickByLabel(page,/popup/,'WebGPU');
    await expect.poll(()=>page.evaluate(()=>Glob2WebGPU.state),{timeout:120000}).toBe(-1);
    expect(await page.evaluate(()=>Module.renderer)).toBe('webgl2');
    await page.screenshot({path:info.outputPath('shader-creation-rollback.png')});
  } finally {await page.evaluate(path=>{FS.writeFile(path,Module.rendererShaderOriginal);delete Module.rendererShaderOriginal;},shaderPath);}
  await choose(page,'WebGPU');await choose(page,'Programmable GL');
  // Device preparation is retained between backend switches. Fail the actual
  // white/restoration upload once and let the previous GL renderer recover.
  await page.evaluate(()=>{const queue=Glob2WebGPU.device.queue,original=queue.writeTexture;Module.rendererFaultConsumed=0;Module.rendererFaultCleanup=()=>{queue.writeTexture=original;};queue.writeTexture=function(...args){queue.writeTexture=original;Module.rendererFaultConsumed++;throw Error('injected owned upload failure');};});
  try {
    const loop=(await state(page)).loop;await clickControl(page,'graphics.renderer');await clickByLabel(page,/popup/,'WebGPU');
    await expect.poll(()=>page.evaluate(()=>Module.rendererFaultConsumed),{timeout:120000}).toBe(1);
    await expect.poll(async()=>(await state(page)).loop,{timeout:120000}).toBeGreaterThan(loop+4);
    expect(await page.evaluate(()=>Module.renderer)).toBe('webgl2');await page.screenshot({path:info.outputPath('upload-rollback.png')});
  } finally {await page.evaluate(()=>{Module.rendererFaultCleanup?.();delete Module.rendererFaultCleanup;});}
  await choose(page,'WebGPU');
  await page.evaluate(()=>{const context=Glob2WebGPU.context,original=context.getCurrentTexture;Module.rendererFaultConsumed=0;Module.rendererFaultCleanup=()=>{context.getCurrentTexture=original;};context.getCurrentTexture=function(...args){context.getCurrentTexture=original;Module.rendererFaultConsumed++;throw Error('injected presentation failure');};});
  try {
    await expect.poll(()=>page.evaluate(()=>Module.rendererFaultConsumed),{timeout:120000}).toBe(1);
    await expect.poll(()=>page.evaluate(()=>Glob2WebGPU.state),{timeout:120000}).toBe(-1);
    await expect.poll(()=>page.evaluate(()=>Module.renderer),{timeout:120000}).toBe('webgl2');
    await page.screenshot({path:info.outputPath('presentation-fallback.png')});
  } finally {await page.evaluate(()=>{Module.rendererFaultCleanup?.();delete Module.rendererFaultCleanup;});}
  // Restore a healthy prepared device, then fail both the new device's upload
  // and the previous GL context recreation. Software must complete the rollback.
  await choose(page,'WebGPU');await choose(page,'Programmable GL');
  await page.evaluate(()=>{const queue=Glob2WebGPU.device.queue,upload=queue.writeTexture,create=GL.createContext;Module.rendererFaultConsumed=0;Module.rendererRollbackConsumed=0;Module.rendererFaultCleanup=()=>{queue.writeTexture=upload;GL.createContext=create;};queue.writeTexture=function(){queue.writeTexture=upload;Module.rendererFaultConsumed++;throw Error('injected new device upload failure');};GL.createContext=function(){GL.createContext=create;Module.rendererRollbackConsumed++;return 0;};});
  try {
    await clickControl(page,'graphics.renderer');await clickByLabel(page,/popup/,'WebGPU');
    await expect.poll(()=>page.evaluate(()=>Module.rendererFaultConsumed),{timeout:120000}).toBe(1);
    await expect.poll(()=>page.evaluate(()=>Module.rendererRollbackConsumed),{timeout:120000}).toBe(1);
    await expect.poll(()=>page.evaluate(()=>Module.renderer),{timeout:120000}).toBe('software');
    await page.screenshot({path:info.outputPath('failed-previous-device-software-rollback.png')});
  } finally {await page.evaluate(()=>{Module.rendererFaultCleanup?.();delete Module.rendererFaultCleanup;delete Module.rendererFaultConsumed;delete Module.rendererRollbackConsumed;});}
  await choose(page,'Programmable GL');await choose(page,'Software');await resumeOverlay(page);
  const tick=(await state(page)).tick;await expect.poll(async()=>(await state(page)).tick).toBeGreaterThan(tick);await verify();
});
