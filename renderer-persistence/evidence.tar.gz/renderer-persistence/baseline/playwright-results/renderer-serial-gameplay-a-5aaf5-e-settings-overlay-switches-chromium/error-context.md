# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.js >> serial: gameplay and torus survive settings overlay switches
- Location: ../artifacts/ci-recovery/renderer-persistence/baseline/renderer.spec.js:284:3

# Error details

```
Error: expect(received).not.toContain(expected) // indexOf

Expected substring: not "SettingsScreen"
Received string:        "14SettingsScreen"

Call Log:
- Timeout 30000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [aria-hidden]:
    - status: Starting the game…
    - generic:
      - progressbar
      - generic: 33 of 33 MB
    - combobox
  - generic "Globulation 2" [active] [ref=e3]
```

# Test source

```ts
  17  | // SPDX-License-Identifier: GPL-3.0-or-later
  18  | const {test,expect}=require("/home/bradley/.codex/worktrees/2ae630e5-9773-4605-8d29-1c8941969170/glob2/browser/node_modules/@playwright/test");
  19  | const {gameURL,clickMainMenu,clickControl,clickByLabel,clickSettingsDone,clickCustomGameStart,controlBox}=require("/home/bradley/.codex/worktrees/2ae630e5-9773-4605-8d29-1c8941969170/glob2/browser/tests/main-menu");
  20  | const {clickCreateMap}=require("/home/bradley/.codex/worktrees/2ae630e5-9773-4605-8d29-1c8941969170/glob2/browser/tests/editor-controls");
  21  | const {hasDarkText}=require("/home/bradley/.codex/worktrees/2ae630e5-9773-4605-8d29-1c8941969170/glob2/browser/tests/pixels");
  22  | const state=page=>page.evaluate(()=>glob2Diagnostics.snapshot());
  23  | const screen=(page,name)=>expect.poll(async()=>{const s=await state(page);return s.screen+' '+s.screenClass;},{timeout:120000}).toContain(name);
  24  | const generation=page=>page.evaluate(()=>Module.glob2PresentationSurface.generation);
  25  | async function choose(page,label) {
  26  |   const before={generation:await generation(page),loop:(await state(page)).loop};
  27  |   await clickControl(page,'graphics.renderer');
  28  |   await clickByLabel(page,/popup/,label);
  29  |   // In threaded builds FS belongs to the application worker. The requested
  30  |   // choice alone is also insufficient: a failed switch retains that choice.
  31  |   // Surface generation advances only after successful transaction commit.
  32  |   await expect.poll(()=>{if(page.rendererSwitchErrors?.length)throw Error(page.rendererSwitchErrors.join('\n'));return generation(page);},{timeout:120000}).toBeGreaterThan(before.generation);
  33  |   await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['graphics.renderer']?.label)).toContain(label);
  34  |   // Module.renderer is the surface transport family: both GPU contexts use
  35  |   // 'webgl2'. Verify WebGPU against the actual owner and replacement canvas.
  36  |   const active={'Software':'software','Programmable GL':'webgl2','WebGPU':'webgl2'}[label];
  37  |   if(!active)throw Error('Missing active renderer expectation for '+label);
  38  |   try {
  39  |     await expect.poll(()=>page.evaluate(()=>Module.renderer),{timeout:120000}).toBe(active);
  40  |     if(label==='WebGPU') {
  41  |       const owners=await presentationOwners(page);expect(owners).toHaveLength(1);
  42  |       await expect.poll(()=>owners[0].evaluate(()=>{
  43  |         const g=Glob2WebGPU;
  44  |         return g.state===1&&!g.lost&&g.context?.canvas===Module.canvas&&!!g.screen;
  45  |       }),{timeout:120000}).toBe(true);
  46  |       await test.info().attach('active-webgpu-owner',{body:JSON.stringify(await owners[0].evaluate(()=>({
  47  |         state:Glob2WebGPU.state,error:Glob2WebGPU.error,issued:Glob2WebGPU.issued,
  48  |         completed:Glob2WebGPU.completed,canvasOwned:Glob2WebGPU.context.canvas===Module.canvas,
  49  |         adapter:Glob2WebGPU.adapter?.info?{vendor:Glob2WebGPU.adapter.info.vendor,
  50  |           architecture:Glob2WebGPU.adapter.info.architecture,device:Glob2WebGPU.adapter.info.device,
  51  |           description:Glob2WebGPU.adapter.info.description}:null
  52  |       })),null,2),contentType:'application/json'});
  53  |     }
  54  |   } catch (error) {
  55  |     // Preserve the actual owner failure after automatic fallback. A requested
  56  |     // label and a replacement canvas do not establish successful GPU rendering.
  57  |     const owners=await presentationOwners(page);
  58  |     const diagnostics=await Promise.all(owners.map(owner=>owner.evaluate(()=>{
  59  |       const g=globalThis.Glob2WebGPU;
  60  |       return g?{state:g.state,error:g.error,lost:g.lost,epoch:g.epoch,
  61  |         issued:g.issued,completed:g.completed,bytes:g.totalBytes(),
  62  |         frames:g.frames.length,captures:g.captures.length,
  63  |         resources:g.resources.size,meshes:g.meshes.size,masks:g.masks.size}:null;
  64  |     })));
  65  |     await test.info().attach('renderer-switch-failure',{body:JSON.stringify({
  66  |       requested:label,active:await page.evaluate(()=>Module.renderer),
  67  |       generation:await generation(page),diagnostics,snapshot:await state(page)
  68  |     },null,2),contentType:'application/json'});
  69  |     throw error;
  70  |   }
  71  |   if(label==='Programmable GL') {
  72  |     const owners=await presentationOwners(page);
  73  |     expect(owners).toHaveLength(1);
  74  |     const driver=await owners[0].evaluate(()=>{
  75  |       const gl=Module.canvas.getContext('webgl2');
  76  |       if(!gl)return null;
  77  |       const debug=gl.getExtension('WEBGL_debug_renderer_info');
  78  |       return {version:gl.getParameter(gl.VERSION),renderer:gl.getParameter(gl.RENDERER),
  79  |         unmaskedRenderer:debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):null};
  80  |     });
  81  |     expect(driver,'Successful Programmable GL switch must own a WebGL2 context').not.toBeNull();
  82  |     test.info().annotations.push({type:'Actual WebGL2 driver',description:driver.unmaskedRenderer||driver.renderer});
  83  |     await test.info().attach('webgl2-driver',{body:JSON.stringify(driver,null,2),contentType:'application/json'});
  84  |   }
  85  |   await expect.poll(async()=>(await state(page)).loop,{timeout:120000}).toBeGreaterThan(before.loop+1);
  86  |   await expect.poll(async()=>hasDarkText(page,await controlBox(page,'graphics.renderer',{fullyVisible:true})),{timeout:120000}).toBe(true);
  87  |   await expect(page.locator('#canvas')).toHaveCount(1);
  88  |   expect(await page.evaluate(()=>document.querySelector('#canvas').isConnected)).toBe(true);
  89  | }
  90  | async function start(page,mode) {
  91  |   const errors=[];page.rendererSwitchErrors=errors;page.on('pageerror',error=>errors.push(String(error)));
  92  |   const url=new URL(gameURL(),'http://localhost');url.searchParams.set('threads',mode);url.searchParams.set('renderer','software');
  93  |   await page.goto(url.pathname+url.search);await screen(page,'MainMenuScreen');
  94  |   const execution=(await state(page)).executionMode;
  95  |   test.skip(execution!==mode,'Browser does not support the requested execution mode');
  96  |   await page.evaluate(()=>{globalThis.rendererSwitchApplicationToken={module:Module,action:Module._glob2_context_action,starts:Module.glob2ApplicationStarts,thread:Module.glob2ApplicationThreadIdentity};globalThis.rendererSwitchToken=rendererSwitchApplicationToken;});
  97  |   return async()=>{
  98  |     expect(await page.evaluate(()=>rendererSwitchToken===rendererSwitchApplicationToken&&rendererSwitchToken.module===Module&&rendererSwitchToken.action===Module._glob2_context_action)).toBe(true);
  99  |     expect(await page.evaluate(()=>({starts:Module.glob2ApplicationStarts,thread:Module.glob2ApplicationThreadIdentity}))).toEqual(await page.evaluate(()=>({starts:rendererSwitchToken.starts,thread:rendererSwitchToken.thread})));
  100 |     expect(await page.evaluate(()=>Module.glob2ApplicationStarts)).toBe(1);
  101 |     expect((await state(page)).executionMode).toBe(execution);
  102 |     expect(errors).toEqual([]);
  103 |   };
  104 | }
  105 | async function openMenu(page) {
  106 |   if (!(await state(page)).controls.return) await page.locator('#canvas').press('Escape',{delay:80});
  107 |   await expect.poll(async()=>Boolean((await state(page)).controls.return)).toBe(true);
  108 | }
  109 | async function openOverlay(page) {
  110 |   await openMenu(page);
  111 |   await clickControl(page,'settings');await screen(page,'SettingsScreen');
  112 | }
  113 | async function resumeOverlay(page) {
  114 |   await clickSettingsDone(page);
  115 |   // Settings closes the menu before opening. Wait for the parent screen to
  116 |   // resume and clear its old input before sending a new physical key.
> 117 |   await expect.poll(async()=>(await state(page)).screenClass).not.toContain('SettingsScreen');
      |                                                                   ^ Error: expect(received).not.toContain(expected) // indexOf
  118 |   const loop=(await state(page)).loop;
  119 |   await expect.poll(async()=>(await state(page)).loop,{timeout:120000}).toBeGreaterThan(loop+2);
  120 |   if ((await state(page)).controls.return) await clickControl(page,'return');
  121 | }
  122 | async function presentationOwners(page) {
  123 |   const threaded=(await state(page)).executionMode==='threaded';
  124 |   if(!threaded)return [page];
  125 |   if(page.rendererPresentationOwner)return [page.rendererPresentationOwner];
  126 |   const identity=await page.evaluate(()=>Module.glob2ApplicationThreadIdentity);
  127 |   // The DOM page and idle asset workers load the same libraries. Only the
  128 |   // application pthread owns renderer initialization; Software deliberately
  129 |   // has no Module.canvas in that worker, so canvas presence is not a predicate.
  130 |   const realms=threaded?page.workers():[page];
  131 |   const owners=await Promise.all(realms.map(async realm=>{
  132 |     let timer;
  133 |     try{return await Promise.race([
  134 |       realm.evaluate(({threaded,identity})=>
  135 |         typeof Glob2WebGPU==='object'&&typeof Module==='object'&&
  136 |         (threaded
  137 |           ? typeof ENVIRONMENT_IS_PTHREAD!=='undefined'&&ENVIRONMENT_IS_PTHREAD&&
  138 |             typeof _pthread_self==='function'&&_pthread_self()===identity
  139 |           : typeof ENVIRONMENT_IS_PTHREAD==='undefined'||!ENVIRONMENT_IS_PTHREAD),
  140 |       {threaded,identity}).catch(()=>false),
  141 |       new Promise(resolve=>{timer=setTimeout(()=>resolve(false),5000);})
  142 |     ]);}finally{clearTimeout(timer);}
  143 |   }));
  144 |   const found=realms.filter((realm,index)=>owners[index]);
  145 |   if(found.length===1) {
  146 |     page.rendererPresentationOwner=found[0];
  147 |     found[0].once('close',()=>{page.rendererPresentationOwner=null;});
  148 |   }
  149 |   return found;
  150 | }
  151 | async function match(page) {
  152 |   const owners=await presentationOwners(page);
  153 |   expect(owners).toHaveLength(1);
  154 |   const owner=owners[0],rootSeed=0xdecafbad,candidates=[];
  155 |   const record=message=>{if(message.text().startsWith('Map generation:'))candidates.push(message.text());};
  156 |   page.on('console',record);
  157 |   await owner.evaluate(seed=>{
  158 |     // Emscripten's random_get requests four bytes for std::random_device.
  159 |     // Scope this override to map setup, on the application thread only. UUIDs,
  160 |     // account crypto and all other request sizes retain real entropy.
  161 |     const original=crypto.getRandomValues,descriptor=Object.getOwnPropertyDescriptor(crypto,'getRandomValues');
  162 |     const receipt={rootSeed:seed,requests:0};
  163 |     Object.defineProperty(crypto,'getRandomValues',{configurable:true,value:function(view){
  164 |       if(ArrayBuffer.isView(view)&&view.byteLength===4){
  165 |         new DataView(view.buffer,view.byteOffset,view.byteLength).setUint32(0,seed,true);
  166 |         ++receipt.requests;return view;
  167 |       }
  168 |       return original.call(this,view);
  169 |     }});
  170 |     globalThis.rendererMapEntropy={receipt,restore:()=>{
  171 |       if(descriptor)Object.defineProperty(crypto,'getRandomValues',descriptor);
  172 |       else delete crypto.getRandomValues;
  173 |       delete globalThis.rendererMapEntropy;
  174 |       return receipt;
  175 |     }};
  176 |   },rootSeed);
  177 |   let receipt;
  178 |   try {
  179 |     await clickMainMenu(page,'custom');
  180 |     await clickControl(page,'generator/colonies');await clickByLabel(page,/popup/,'2');
  181 |     for(const dimension of ['width','height']) {
  182 |       await clickControl(page,'generator/'+dimension);await clickByLabel(page,/popup/,'128');
  183 |     }
  184 |     await clickCustomGameStart(page);
  185 |     await screen(page,'GameSessionScreen');
  186 |   } finally {
  187 |     receipt=await owner.evaluate(()=>rendererMapEntropy.restore());
  188 |     page.off('console',record);
  189 |     await test.info().attach('map-entropy-fixture',{body:JSON.stringify({
  190 |       ...receipt,generator:'fingerprint',width:128,height:128,colonies:2,candidates,
  191 |       note:'Fixed root entropy, not an assertion that the last logged candidate is the selected map seed.'
  192 |     },null,2),contentType:'application/json'});
  193 |   }
  194 |   expect(receipt.requests,'Pinned map fixture must consume the scoped four-byte entropy').toBeGreaterThan(0);
  195 |   expect(candidates.at(-1),'Pinned map setup must finish the expected generation').toBe('Map generation: fingerprint revision 5 seed 4039698994 [complete]: ');
  196 |   await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(25);
  197 | }
  198 | async function available(page,label) {
  199 |   await clickControl(page,'graphics.renderer');
  200 |   const offered=await page.evaluate(label=>Object.entries(glob2Diagnostics.snapshot().controls).some(([key,value])=>/popup/.test(key)&&value.label===label),label);
  201 |   await page.locator('#canvas').press('Escape',{delay:80});
  202 |   if (label!=='WebGPU') return offered;
  203 |   // Compiled shaders alone do not establish an adapter. In threaded builds
  204 |   // inspect the application worker that owns the backend, not the DOM realm.
  205 |   let reason=offered?'Presentation-owner WebGPU realm could not be inspected':'Renderer selector reports WebGPU unavailable';
  206 |   // Idle Emscripten asset pthreads may be inside Atomics.wait forever. Probe
  207 |   // all realms with bounded waits before sending async work to the GPU owner.
  208 |   const realms=await presentationOwners(page);
  209 |   for (let index=0;index<realms.length;++index) {
  210 |     const realm=realms[index];
  211 |     let timer,result;
  212 |     try{result=await Promise.race([realm.evaluate(async()=>{
  213 |       if(!globalThis.navigator?.gpu)return {available:false,reason:'Presentation owner has no navigator.gpu'};
  214 |       try{return await navigator.gpu.requestAdapter() ? {available:true} : {available:false,reason:'Presentation owner returned no WebGPU adapter'};}
  215 |       catch(error){return {available:false,reason:String(error)};}
  216 |     }).catch(()=>null),new Promise(resolve=>{timer=setTimeout(()=>resolve({available:false,reason:'Presentation-owner adapter request timed out'}),15000);})]);}
  217 |     finally{clearTimeout(timer);}
```