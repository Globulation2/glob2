from pathlib import Path
import json,os,signal,time
ROOT=Path(__file__).resolve().parents[3];K=ROOT/'artifacts/filipino-localization';log=K/'rendering/native-capture-runner.log'
expected=b'python3\0artifacts/filipino-localization/rendering/capture_native.py\0'
pids=[]
for proc in Path('/proc').glob('[0-9]*'):
 try:
  if (proc/'cmdline').read_bytes()==expected and (proc/'cwd').resolve()==ROOT:pids.append(int(proc.name))
 except OSError:pass
if len(pids)!=1:raise SystemExit('Expected exactly one own capture controller; found'+str(pids))
pid=pids[0];deadline=time.monotonic()+1800
while time.monotonic()<deadline:
 if 'CAPTURED phone-tutorial:defensive-tactics' in log.read_text():
  os.kill(pid,signal.SIGINT)
  (K/'rendering/matrix-hold.json').write_text(json.dumps({'controller_pid':pid,'action':'SIGINT own capture controller immediately after final unaffected screenshot completed','reason':'Hold full matrix pending independently reviewed compact Rules caption fix. No build or other task stopped.','expected_completed_capture_commands':32},indent=2)+'\n')
  print('HOLD_REQUESTED_AFTER32SCREEN_GAME_CAPTURES',flush=True);break
 try:os.kill(pid,0)
 except ProcessLookupError:raise SystemExit('Capture controller ended before requested hold')
 time.sleep(.05)
else:raise SystemExit('Timed out waiting for final unaffected capture')
