from pathlib import Path
r=Path('artifacts/filipino-localization/rendering');s=(r/'capture_native.py').read_text();prefix=s[:s.index('\ntry:\n deadline=')]
prefix=prefix.replace("OUT=KIT/'rendering/native'","OUT=KIT/'rendering/native-final'")
prefix=prefix.replace("'status':'waiting for freshly linked executable'","'status':'preparing final compact-caption captures'")
prefix=prefix.replace("allowed='platform/apps/web/e2e/i18n.spec.ts'","allowed={'platform/apps/web/e2e/i18n.spec.ts','data/texts.fil.txt'}")
prefix=prefix.replace("set(names)-{allowed} or any(line[3:]!=allowed for line in actual['sourceStatus'])","set(names)-allowed or any(line[3:] not in allowed for line in actual['sourceStatus'])")
prefix=prefix.replace("['git','diff','--binary',source['revision'],'--',allowed]","['git','diff','--binary',source['revision'],'--',*sorted(allowed)]")
prefix=prefix.replace("'allowed_paths':[allowed]","'allowed_paths':sorted(allowed)")
prefix=prefix.replace("Only web e2e test lint changes;every other tracked source input unchanged from compiled091 revision. Actual executed producer remains091 and is validated against that frozen identity.","Only web e2e lint and two reviewed Filipino compact-caption data changes. Every compiled code/font/English-source input unchanged from091. Actual executed producer remains091; final target values are deliberately supplied through the supported draft overlay and separately hashed.")
prefix=prefix.replace("Non-test-only source changed during capture; refusing stale evidence","Source changed beyond reviewed test/data-only carry-forward; refusing stale evidence")
prefix=prefix.replace("record['binary_derivation']=","record['repair_scope']=['native:[Rules]','native:[Editor tools]']\nrecord['binary_derivation']=")
body='''
try:
 import sys
 sys.path.insert(0,str(ROOT/'tools/localization'))
 import translation_program as T
 old,errors=T.CHECKER.read_table(KIT/'editor/native-after-adversary.txt');assert not errors
 current,errors=T.CHECKER.read_table(ROOT/'data/texts.fil.txt');assert not errors
 native=json.loads((DRAFT/'native.json').read_text())
 assert current==native,'Final native JSON must exactly match installed text table'
 changes={key:{'before':old[key],'after':native[key]} for key in old if old[key]!=native[key]}
 assert set(changes)=={'[Rules]','[Editor tools]'},'Unexpected native target changes'
 assert native['[Rules]']=='Mga tuntunin' and native['[Editor tools]']=='Mga tool'
 assert T.sources(ROOT)[4]==json.loads((KIT/'manifest.json').read_text())['source_sha256'],'English contract source changed'
 record['target_delta']=changes;record['binary_sha256']=digest(BINARY)
 assert record['binary_sha256']==record['binary_derivation']['derived_sha256'],'Derived executable changed'
 record['status']='capturing final compact-caption repair';write(OUT/'capture-manifest.json',record)
 execute('screen','lobby',390,844,True,600)
 execute('screen','lobby-players',390,844,True,600)
 execute('game','gameplay',390,844,True,600)
 execute('game','tutorial:introduction',390,844,True,600)
 matrix=execute('matrix','full-matrix',390,844,True,1800)
 samples=matrix['samples'];rows=len(native)+sum(len(v) if isinstance(v,dict) else 1 for v in json.loads((DRAFT/'online.json').read_text()).values())
 missing=[{'surface':x['surface'],'key':x['key'],'branch':x['branch'],'size':x['size'],'scale':x['scale']} for x in samples if not x['has_glyphs']]
 fits=[{'surface':x['surface'],'key':x['key'],'branch':x['branch'],'size':x['size'],'scale':x['scale'],'line':line} for x in samples for line in x['lines'] if not line['drawn_fits_width'] or not line['drawn_fits_height']]
 raw=[{'surface':x['surface'],'key':x['key'],'size':x['size'],'scale':x['scale'],'line':line} for x in samples for line in x['lines'] if not line['fits_width'] or not line['fits_height']]
 write(OUT/'matrix-summary.json',{'rows':rows,'expected_samples':rows*6,'actual_samples':len(samples),'sizes':[10,13,20],'scales':[1,2],'missing_glyphs':missing,'drawn_fit_failures':fits,'raw_raster_fit_diagnostics':raw,'png_count':len(list((OUT/'phone-full-matrix').glob('*.png'))),'limits':['Native catalog escapes and substitution tokens are shown literally in this glyph/wrapping diagnostic.','Actual tutorial/phone widgets have separate real-engine captures; no claim that every final message was viewed in its runtime context.']})
 assert rows==6256 and len(samples)==37536,'Full matrix inventory incomplete'
 record.update(status='captured; visual inspection pending',matrix_summary='rendering/native-final/matrix-summary.json',storage_bytes=size());write(OUT/'capture-manifest.json',record)
 print('FINAL_CAPTURES_COMPLETE',json.dumps({'samples':len(samples),'missing_glyphs':len(missing),'drawn_fit_failures':len(fits),'raw_diagnostics':len(raw),'storage_bytes':size()}),flush=True)
except BaseException as exc:
 record.update(status='failed or stale; do not approve',error=str(exc),traceback=traceback.format_exc());write(OUT/'capture-manifest.json',record);print(record['error'],flush=True);raise
'''
(r/'capture_native_final.py').write_text(prefix+body)
