from pathlib import Path
import hashlib,importlib.util,json,mmap,subprocess,time
ROOT=Path(__file__).resolve().parents[3];K=ROOT/'artifacts/filipino-localization';p=ROOT/'build/linux/client/debug/dev-dev_fast-true-linker-auto/test/TranslationPreviewHarness';q=K/'rendering/bin/TranslationPreviewHarness-fil-width'
s=importlib.util.spec_from_file_location('p',ROOT/'test/build_provenance.py');P=importlib.util.module_from_spec(s);s.loader.exec_module(P)
source=P.source_identity(ROOT)
assert source['revision'].startswith('22be432380') and not source['dirty'],'Require final clean highDPI fix source'
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
 try:
  stat=p.stat()
  with p.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as m:
   i=m.find(b'sourceTreeSha256');a=m.rfind(b'\0',0,i)+1;b=m.find(b'\0',i);producer=json.loads(m[a:b])
  if not P.build_issues(producer,source) and p.open('rb').read(4)==b'\x7fELF' and subprocess.run(['readelf','--file-header',str(p)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:
   time.sleep(5)
   if p.stat().st_mtime_ns==stat.st_mtime_ns and p.stat().st_size==stat.st_size:break
 except (OSError,ValueError):pass
 time.sleep(5)
else:raise RuntimeError('New compiled producer did not become ready within30minutes')
assert not P.build_issues(source,P.source_identity(ROOT)),'Source changed before derivation'
def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest()
command=['objcopy','--strip-all',str(p),str(q)];original_sha=sha(p);subprocess.run(command,check=True);assert original_sha==sha(p),'Original changed during strip'
r={'source':source,'embedded_producer':producer,'original':str(p.relative_to(ROOT)),'original_sha256':original_sha,'original_bytes':p.stat().st_size,'derived':str(q.relative_to(ROOT)),'derived_sha256':sha(q),'derived_bytes':q.stat().st_size,'command':command,'limits':'Stripped debug/symbol data only; new actual producer and derived executable identities retained. Development harness, not shipping package.'}
(K/'rendering/binary-derivation-fil-width.json').write_text(json.dumps(r,indent=2)+'\n');print('NEW_EXECUTABLE_DERIVED',r['derived_sha256'],flush=True)
