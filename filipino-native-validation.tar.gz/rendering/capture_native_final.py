#!/usr/bin/env python3
"""Bounded artifact-only native capture; never approves a release gate."""
from pathlib import Path
import concurrent.futures,gzip,hashlib,importlib.util,json,os,subprocess,threading,time,traceback
ROOT=Path(__file__).resolve().parents[3]
KIT=ROOT/'artifacts/filipino-localization';OUT=KIT/'rendering/native-final';OUT.mkdir(parents=True,exist_ok=True)
BINARY=KIT/'rendering/bin/TranslationPreviewHarness'
DRAFT=KIT/'drafts/fil';MAX_BYTES=2*1024**3
spec=importlib.util.spec_from_file_location('provenance',ROOT/'test/build_provenance.py');P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def size():return sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())
source=json.loads((KIT/'rendering/native-preflight-timeout/capture-manifest.json').read_text())['source']
record={'source':source,'binary':str(BINARY),'status':'preparing final compact-caption captures','commands':[],'limits':['Native Linux software-rendered desktop executable only. Phone-sized forced presentation does not establish Android/iOS execution.','Matrix glyph/drawn-fit diagnostics cover all catalog rows; representative visual inspection is recorded separately.']}
record['repair_scope']=['native:[Rules]','native:[Editor tools]']
record['binary_derivation']=json.loads((KIT/'rendering/binary-derivation.json').read_text())
write(OUT/'capture-manifest.json',record)
original={n:digest(DRAFT/n) for n in ['native.json','online.json','metadata.json']}
record['input_sha256']=original

def source_unchanged():
 actual=P.source_identity(ROOT)
 if P.build_issues(source,actual):
  allowed={'platform/apps/web/e2e/i18n.spec.ts','data/texts.fil.txt'}
  names=subprocess.check_output(['git','diff','--name-only',source['revision'],'--'],cwd=ROOT,text=True).splitlines()
  if set(names)-allowed or any(line[3:] not in allowed for line in actual['sourceStatus']):raise RuntimeError('Source changed beyond reviewed test/data-only carry-forward; refusing stale evidence')
  delta=subprocess.check_output(['git','diff','--binary',source['revision'],'--',*sorted(allowed)],cwd=ROOT)
  (OUT/'source-carry-forward.diff').write_bytes(delta)
  record['runner_source_current']=actual
  record['source_carry_forward']={'allowed_paths':sorted(allowed),'changed_paths':names,'diff_sha256':hashlib.sha256(delta).hexdigest(),'diff_path':'rendering/native-final/source-carry-forward.diff','basis':'Only web e2e lint and two reviewed Filipino compact-caption data changes. Every compiled code/font/English-source input unchanged from091. Actual executed producer remains091; final target values are deliberately supplied through the supported draft overlay and separately hashed.'}
 if {n:digest(DRAFT/n) for n in original}!=original:raise RuntimeError('Draft inputs changed during capture')

def execute(mode,label,width,height,phone,timeout):
 source_unchanged()
 if digest(BINARY)!=record['binary_sha256']:raise RuntimeError('Executable changed during capture')
 if size()>MAX_BYTES:raise RuntimeError('Native capture2GiB budget exhausted')
 name=('phone' if phone else 'desktop')+'-'+label;folder=OUT/name;folder.mkdir(exist_ok=True)
 argv=[str(BINARY),mode,str(ROOT),str(DRAFT),str(folder),str(width),str(height)]
 if mode!='matrix':argv.append(label)
 env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_RENDER_DRIVER='software',SDL_AUDIODRIVER='dummy',GLOB2_MOBILE_UI='1' if phone else '0',GLOB2_USER_DATA_DIR=str(folder/'profile'))
 # Preserve the pinned SDL prefix runtime paths used by the finished build.
 env['LD_LIBRARY_PATH']=str(KIT/'sdl-reused/lib')+os.pathsep+env.get('LD_LIBRARY_PATH','')
 result={'name':name,'argv':argv,'phone_presentation':phone,'log':str((folder/'process.log.gz').relative_to(KIT))};record['commands'].append(result);write(OUT/'capture-manifest.json',record)
 started=time.monotonic();proc=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 def consume():
  with gzip.open(folder/'process.log.gz','wb') as log:
   for chunk in iter(lambda:proc.stdout.read1(65536),b''):log.write(chunk)
 reader=threading.Thread(target=consume,daemon=True);reader.start()
 try:
  while proc.poll() is None:
   if time.monotonic()-started>timeout:raise TimeoutError('Capture exceeded per-process deadline')
   if size()>MAX_BYTES:raise RuntimeError('Native capture exceeded2GiB disk allowance')
   time.sleep(1)
 except BaseException:
  proc.kill();proc.wait();raise
 finally:reader.join(10)
 result.update(exit_code=proc.returncode,elapsed_seconds=round(time.monotonic()-started,3))
 if proc.returncode:raise RuntimeError('Capture failed: '+name+'; see compressed log')
 source_unchanged()
 manifest=folder/('font-matrix.json' if mode=='matrix' else (label.replace('tutorial:','tutorial-')+'.json'))
 proof=json.loads(manifest.read_text());issues=P.build_issues(proof['evidence_identity']['producer'],source)
 if issues:raise RuntimeError('Executed binary provenance mismatch: '+str(issues))
 if proof['evidence_identity']['executable_sha256']!=record['binary_sha256']:raise RuntimeError('Manifest executable hash mismatch')
 result.update(manifest=str(manifest.relative_to(KIT)),manifest_sha256=digest(manifest),provenance_issues=[])
 write(OUT/'capture-manifest.json',record)
 print('CAPTURED',name,flush=True)
 return proof

try:
 import sys
 sys.path.insert(0,str(ROOT/'tools/localization'))
 import translation_program as T
 old,errors=T.CHECKER.read_table(KIT/'editor/native-after-adversary.txt');assert not errors
 current,errors=T.CHECKER.read_table(ROOT/'data/texts.fil.txt');assert not errors
 native=json.loads((DRAFT/'native.json').read_text())
 assert current==native,'Final native JSON must exactly match installed text table'
 changes={key:{'before':old[key],'after':native[key]} for key in old if old[key]!=native[key]}
 assert set(changes)=={'[Rules]','[Editor tools]'},'Unexpected native target changes'
 assert native['[Rules]']=='Mga tuntunin' and native['[Editor tools]']=='Mga tool'
 assert T.sources(ROOT)[4]==json.loads((KIT/'manifest.json').read_text())['source_sha256'],'English contract source changed'
 record['target_delta']=changes;record['binary_sha256']=digest(BINARY)
 assert record['binary_sha256']==record['binary_derivation']['derived_sha256'],'Derived executable changed'
 record['status']='capturing final compact-caption repair';write(OUT/'capture-manifest.json',record)
 execute('screen','lobby',390,844,True,600)
 execute('screen','lobby-players',390,844,True,600)
 execute('game','gameplay',390,844,True,600)
 execute('game','tutorial:introduction',390,844,True,600)
 matrix=execute('matrix','full-matrix',390,844,True,1800)
 samples=matrix['samples'];rows=len(native)+sum(len(v) if isinstance(v,dict) else 1 for v in json.loads((DRAFT/'online.json').read_text()).values())
 missing=[{'surface':x['surface'],'key':x['key'],'branch':x['branch'],'size':x['size'],'scale':x['scale']} for x in samples if not x['has_glyphs']]
 fits=[{'surface':x['surface'],'key':x['key'],'branch':x['branch'],'size':x['size'],'scale':x['scale'],'line':line} for x in samples for line in x['lines'] if not line['drawn_fits_width'] or not line['drawn_fits_height']]
 raw=[{'surface':x['surface'],'key':x['key'],'size':x['size'],'scale':x['scale'],'line':line} for x in samples for line in x['lines'] if not line['fits_width'] or not line['fits_height']]
 write(OUT/'matrix-summary.json',{'rows':rows,'expected_samples':rows*6,'actual_samples':len(samples),'sizes':[10,13,20],'scales':[1,2],'missing_glyphs':missing,'drawn_fit_failures':fits,'raw_raster_fit_diagnostics':raw,'png_count':len(list((OUT/'phone-full-matrix').glob('*.png'))),'limits':['Native catalog escapes and substitution tokens are shown literally in this glyph/wrapping diagnostic.','Actual tutorial/phone widgets have separate real-engine captures; no claim that every final message was viewed in its runtime context.']})
 assert rows==6256 and len(samples)==37536,'Full matrix inventory incomplete'
 record.update(status='captured; visual inspection pending',matrix_summary='rendering/native-final/matrix-summary.json',storage_bytes=size());write(OUT/'capture-manifest.json',record)
 print('FINAL_CAPTURES_COMPLETE',json.dumps({'samples':len(samples),'missing_glyphs':len(missing),'drawn_fit_failures':len(fits),'raw_diagnostics':len(raw),'storage_bytes':size()}),flush=True)
except BaseException as exc:
 record.update(status='failed or stale; do not approve',error=str(exc),traceback=traceback.format_exc());write(OUT/'capture-manifest.json',record);print(record['error'],flush=True);raise
