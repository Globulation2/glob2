"""Artifact audit of actual pre-repair and final captures, never mutates gates."""
from pathlib import Path
import hashlib,importlib.util,json,re,struct,subprocess
ROOT=Path(__file__).resolve().parents[3];KIT=ROOT/'artifacts/filipino-localization'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=importlib.util.spec_from_file_location('p',ROOT/'test/build_provenance.py');P=importlib.util.module_from_spec(s);s.loader.exec_module(P)
issues=[];pngs=[];sets=[];source=None
for name,count in [('native',32),('native-fixed',7)]:
 out=KIT/'rendering'/name;r=json.loads((out/'capture-manifest.json').read_text());source=r['source'];commands=r['commands']
 if len(commands)!=count:issues.append(name+': unexpected command inventory')
 for c in commands:
  if c.get('exit_code')!=0 or not c.get('manifest'):issues.append(c['name']+': missing completed evidence');continue
  path=KIT/c['manifest'];e=json.loads(path.read_text())
  if sha(path)!=c['manifest_sha256']:issues.append(c['name']+': receipt hash changed')
  issues.extend(c['name']+': '+x for x in P.build_issues(e['evidence_identity']['producer'],source))
  if e['evidence_identity']['executable_sha256']!=r['binary_sha256']:issues.append(c['name']+': executable hash mismatch')
  identity=e['evidence_identity']
  for rel,h in identity['source_sha256'].items():
   expected=sha(ROOT/rel) if name=='native-fixed' else hashlib.sha256(subprocess.check_output(['git','show',source['revision']+':'+rel],cwd=ROOT)).hexdigest()
   if expected!=h:issues.append(c['name']+': evidence source hash mismatch '+rel)
  for font in identity['runtime_fonts']:
   if sha(Path(font['path']))!=font['sha256']:issues.append(c['name']+': runtime font changed '+font['virtual_path'])
  if identity['catalog_sha256']['native']!=r['input_sha256']['native.json'] or identity['catalog_sha256']['online']!=r['input_sha256']['online.json']:issues.append(c['name']+': actual overlay hash differs from frozen capture inputs')
  if e.get('native_keys_overridden',3393)!=3393:issues.append(c['name']+': incomplete native overlay')
  if e.get('kind')=='production-game-draft-overlay':
   if e['phone_presentation_requested']!=c['phone_presentation']:issues.append(c['name']+': presentation mismatch')
   if c['argv'][-1].startswith('tutorial:') and (not e['tutorial_instruction_shown'] or not e['tutorial_capture_dialog_free']):issues.append(c['name']+': tutorial guidance not exposed')
   for cap in e['captures']:
    if cap['checksum_before_draw']!=cap['checksum_after_draw']:issues.append(c['name']+': draw changed simulation checksum')
  width,height=map(int,c['argv'][5:7])
  for p in path.parent.glob('*.png'):
   blob=p.read_bytes();w,h=struct.unpack('>II',blob[16:24]);scale=int(re.search(r'-scale-(\d+)-',p.name)[1]) if '-scale-' in p.name else 1
   if (w,h)!=(width*scale,height*scale):issues.append(str(p.relative_to(KIT))+': unexpected PNG dimensions')
   pngs.append({'path':str(p.relative_to(KIT)),'sha256':hashlib.sha256(blob).hexdigest(),'width':w,'height':h,'catalog_phase':'final8dcf-fixed-font' if name=='native-fixed' else 'before-two-caption-repair5c86'})
 sets.append({'path':str((out/'capture-manifest.json').relative_to(KIT)),'sha256':sha(out/'capture-manifest.json'),'commands':len(commands),'input_sha256':r['input_sha256'],'producer':source,'source_carry_forward':r.get('source_carry_forward')})
actual=P.source_identity(ROOT);changed=subprocess.check_output(['git','diff','--name-only',source['revision'],'--'],cwd=ROOT,text=True).splitlines();allowed=set()
if set(changed)-allowed or any(line[3:] not in allowed for line in actual['sourceStatus']):issues.append('Current source changed outside reviewed two-caption/test carry-forward')
m=json.loads((KIT/'rendering/native-fixed/matrix-summary.json').read_text())
if m['actual_samples']!=37536 or m['expected_samples']!=37536:issues.append('Incomplete full matrix')
if m['missing_glyphs']:issues.append('Matrix missing glyphs; inspect all diagnostics')
if m['drawn_fit_failures']:issues.append('Matrix drawn fit failures; inspect all diagnostics')
findings=json.loads((KIT/'visual/native-findings.json').read_text());inspections=json.loads((KIT/'visual/native-inspections.json').read_text())
for f in findings:
 if f['state']!='resolved':issues.append('Unresolved visual finding '+f['key'])
review={'identity':'/root/adversarial_reviewer','status':'complete' if not issues else 'requires review','source_current':actual,'compiled_source':source,'catalog_native_sha256':sha(ROOT/'data/texts.fil.txt'),'catalog_online_sha256':sha(KIT/'editor/online-final.json'),'capture_sets':sets,'historical_failed_matrix':{'path':'visual/native-highdpi-finding.json','preserved_capture':'rendering/native-final/capture-manifest.json','state':'Before-fix559width failures retained; superseded only by fresh22be matrix diagnostics'},'width_carry_forward':json.loads((KIT/'visual/native-width-carry-forward.json').read_text()),'capture_command_count':sum(s['commands'] for s in sets),'png_count':len(pngs),'diagnostic_issues':issues,'matrix':m,'png_inventory':pngs,'visually_inspected':inspections,'findings':findings,'carry_forward':{'proof':'author/compact-labels/author-delta.json','exact_changed_keys':['native:[Rules]','native:[Editor tools]'],'unchanged_native_entries':3391,'unchanged_online_entries':2836,'old_tutorial_scope':'All10 desktop/phone guidance and briefing text retains exact targets; old full screens show old Tools caption. Fresh22be phone gameplay+introduction validate shared Tools geometry; final two lobby tabs validate Rules. Prior1x drawing carries through fullcatalog1xgeometry/pixel equality in native-width-carry-forward.json.','compiled_inputs':'Historical32 captures truthfully retain compiled091; fresh7commands execute actual22be. Catalog final8dcf supplied through supported3393-key overlay. Exact changes: two captions, test-only lint/startup/font regressions, and existing authored-width path extended to fil. Font assets and all other code unchanged. See native-width-carry-forward.json for full1x preservation proof.'},'limits':['Linux native software-rendered dev harness1280x860 and forced390x844 phone presentation. No actual Android/iOS,Windows/macOS execution claim.','Final matrix inventories6256rows at3font sizes and2raster scales; all diagnostics audited, representative PNGs visually inspected. Catalog escapes/substitution tokens are literal in matrix; it does not show every message in runtime context.','Main lobby preview is initial generating state; no claim of completed map generation.','Native gameplay initial state has no selected building; actual browser interaction evidence owned by root covers building details/long help separately.','No gate mutation; root reviews these artifacts.']}
(KIT/'visual/native-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:review[k] for k in ['status','capture_command_count','png_count','diagnostic_issues']}))
