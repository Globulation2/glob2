from pathlib import Path
import hashlib,importlib.util,json,re,struct
ROOT=Path(__file__).resolve().parents[3];KIT=ROOT/'artifacts/filipino-localization';OUT=KIT/'rendering/native'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=importlib.util.spec_from_file_location('p',ROOT/'test/build_provenance.py');P=importlib.util.module_from_spec(s);s.loader.exec_module(P)
r=json.loads((OUT/'capture-manifest.json').read_text());actual=P.source_identity(ROOT);issues=[];pngs=[]
if P.build_issues(r['source'],actual):
 import subprocess
 allowed='platform/apps/web/e2e/i18n.spec.ts';changed=subprocess.check_output(['git','diff','--name-only',r['source']['revision'],'--'],cwd=ROOT,text=True).splitlines()
 if set(changed)-{allowed} or any(line[3:]!=allowed for line in actual['sourceStatus']):issues.append('Source changed beyond permitted test-only carry-forward')
for cmd in r['commands']:
 if cmd.get('exit_code')!=0 or not cmd.get('manifest'):issues.append(cmd['name']+': no completed evidence');continue
 path=KIT/cmd['manifest'];e=json.loads(path.read_text());issues.extend(cmd['name']+': '+x for x in P.build_issues(e['evidence_identity']['producer'],r['source']))
 if e['native_keys_overridden']!=3393:issues.append(cmd['name']+': incomplete native overlay')
 if e.get('kind')=='production-game-draft-overlay':
  if e['phone_presentation_requested']!=cmd['phone_presentation']:issues.append(cmd['name']+': actual presentation mismatch')
  if cmd['argv'][-1].startswith('tutorial:') and (not e['tutorial_instruction_shown'] or not e['tutorial_capture_dialog_free']):issues.append(cmd['name']+': tutorial not visibly exposed')
  for cap in e['captures']:
   if cap['checksum_before_draw']!=cap['checksum_after_draw']:issues.append(cmd['name']+': drawing changed simulation')
 width,height=map(int,cmd['argv'][5:7])
 for png in path.parent.glob('*.png'):
  blob=png.read_bytes();w,h=struct.unpack('>II',blob[16:24]);scale=int(re.search(r'-scale-(\d+)-',png.name)[1]) if '-scale-' in png.name else 1
  if (w,h)!=(width*scale,height*scale):issues.append(str(png.relative_to(KIT))+': unexpected dimensions '+str((w,h)))
  pngs.append({'path':str(png.relative_to(KIT)),'sha256':hashlib.sha256(blob).hexdigest(),'width':w,'height':h})
m=json.loads((OUT/'matrix-summary.json').read_text()) if (OUT/'matrix-summary.json').exists() else None
if m:
 if m['actual_samples']!=37536:issues.append('Matrix count differs from6256rows*6')
 if m['missing_glyphs']:issues.append('Matrix contains missing glyphs')
 if m['drawn_fit_failures']:issues.append('Matrix contains drawn-fit failures; inspect every reported line')
else:issues.append('Full matrix summary missing')
review={'status':'diagnostics complete; representative visual inspection pending','source':actual,'compiled_source':r['source'],'source_carry_forward':r.get('source_carry_forward'),'binary_sha256':r.get('binary_sha256'),'capture_count':len(r['commands']),'png_count':len(pngs),'diagnostic_issues':issues,'matrix':m,'png_inventory':pngs,'visually_inspected':[],'limits':['Linux native software renderer at1280x860 and forced390x844phonepresentation; no real Android/iOS or Windows/macOS execution claim.','All matrix diagnostics audited; full6256row text inventory is not claimed as visually read on every PNG.','Visual result must be rechecked if executable/source/catalog identity changes.']}
p=KIT/'visual/native-review.json';p.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:review[k] for k in ['status','capture_count','png_count','diagnostic_issues']}))
