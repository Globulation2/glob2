from pathlib import Path
import os,signal,subprocess,time,json,hashlib
root=Path.cwd(); kit=root/'artifacts/filipino-localization'; binary=root/'build/linux/client/debug/dev-dev_fast-true-linker-auto/test/glob2-engine-tests'; scons_pid=1699954
record={'purpose':'Build and run affected engine language/font cases; unit suite is outside this text-only change scope','expected_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'build_pid':scons_pid}
assert record['expected_revision']=='b768c25b2744bc405516cef80b667713767664ad'
env=dict(os.environ,GLOB2_SDL3_PREFIX=str(kit/'sdl-reused'),LD_LIBRARY_PATH=str(kit/'sdl-reused/lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''),SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
deadline=time.monotonic()+7200
while time.monotonic()<deadline:
 if binary.is_file() and binary.stat().st_size>1000000:
  try:
   r=subprocess.run([str(binary),'--list-test-cases','--test-case=SystemLanguage*'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=45)
   if r.returncode==0: break
  except (OSError,subprocess.TimeoutExpired):pass
 time.sleep(10)
else:raise SystemExit('Engine executable did not finish in bounded wait')
p=Path('/proc')/str(scons_pid)
if p.exists():
 assert (p/'cwd').resolve()==root and b'engine-tests\x00unit-tests' in (p/'cmdline').read_bytes()
 os.kill(scons_pid,signal.SIGINT)
 record['stopped_own_unneeded_unit_build']='SIGINT after affected engine executable became runnable; existing compiler jobs allowed to finish'
 while p.exists(): time.sleep(1)
argv=['python3','tools/dev_build.py','engine-tests','-j8']
with (kit/'native-engine-final-build.log').open('w') as log:r=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
record['final_build']={'argv':argv,'exit_code':r.returncode}
if r.returncode:raise SystemExit(r.returncode)
argv=['python3','test/run_tests.py','--build-dir','build/linux/client/debug/dev-dev_fast-true-linker-auto','--binary','engine','--filter','SystemLanguage/*','--filter','FontKerning/*','--no-display','--artifacts',str(kit/'native-focused')]
with (kit/'native-focused.log').open('w') as log:r=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
record['focused']={'argv':argv,'exit_code':r.returncode}
record['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
for name in ['native-engine-final-build.log','native-focused.log']:record[name+'_sha256']=hashlib.sha256((kit/name).read_bytes()).hexdigest()
(kit/'native-focused-results.json').write_text(json.dumps(record,indent=2)+'\n')
print('Native focused result',r.returncode,flush=True)
raise SystemExit(r.returncode)
