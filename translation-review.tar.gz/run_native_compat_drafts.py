from pathlib import Path
import hashlib,json,subprocess,sys,time
repo=Path(__file__).resolve().parents[2]
base=repo/'artifacts/bulgarian'
module=base/'legacy-native-drafting/stage/tools/localization/translation_program.py'
expected='7c0036ca79969accc0224004089b7e76ed1c7f7832949bde9f25448d660b1a7d'
kit=base/'kit-v3-native-compat'
locales=json.loads((base/'legacy-native-drafting/legacy-locales.json').read_text())
results=[]
if '--after' in sys.argv:
    locales=locales[locales.index(sys.argv[sys.argv.index('--after')+1])+1:]
for locale in locales:
    assert hashlib.sha256(module.read_bytes()).hexdigest()==expected
    command=[sys.executable,str(module),'machine-draft','--output',str(kit),'--locale',locale,
        '--project','bradley-personal-20261027','--max-cost-usd','10','--rate-per-million','20',
        '--only-keys',str(kit/'delta-only-keys.json')]
    start=time.monotonic()
    completed=subprocess.run(command,cwd=repo,capture_output=True,text=True)
    log=base/'compat-provider-logs'/(locale+'.log');log.parent.mkdir(exist_ok=True)
    log.write_text(completed.stdout+completed.stderr)
    record={'locale':locale,'exit_code':completed.returncode,'seconds':round(time.monotonic()-start,3),
        'command':command,'log':str(log.relative_to(repo))}
    if completed.returncode==0:
        record['result']=json.loads(completed.stdout)
    results.append(record)
    (base/'native-compat-drafting-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'locale':locale,'exit_code':completed.returncode,'result':record.get('result')},ensure_ascii=False),flush=True)
    if completed.returncode:
        if completed.stderr.strip().startswith('Provider damaged protected marker:'):
            print(json.dumps({'locale':locale,'state':'Rejected provider batch; requires manual source-based draft and independent reviews; reservation retained'}),flush=True)
            continue
        raise SystemExit(completed.returncode)
