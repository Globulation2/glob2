"""Independent literal/identity/lineage verifier; supplies no linguistic approval."""
from pathlib import Path
import json,hashlib,importlib.util,subprocess
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'kit-v4';O=B/'kit-v3';L=B/'linguistics'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rawhash=lambda s:hashlib.sha256(s.encode()).hexdigest();jsonhash=lambda s:rawhash(json.dumps(s,ensure_ascii=False,sort_keys=True,separators=(',',':')))
spec=importlib.util.spec_from_file_location('program',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
m=read(K/'manifest.json');om=read(O/'manifest.json');record=read(K/'reviews/bg.json');oldrecord=read(O/'reviews/bg.json');proof=read(B/'review-proof-v4-validation.json');parent=read(B/'review-proof-v3-validation.json');priorcheck=read(B/'review-proof-v3-independent-validation.json')
assert m['source_sha256']==proof['source_sha256']==record['source_sha256']=='2b396013f79c0bd68dd016a771fe48b8769ec856c5a5cb8f700f0e6ee2e845c7'
for ref in ('parent_record','parent_proof'):assert sha(B/proof[ref]['path'])==proof[ref]['sha256']
assert priorcheck['result']=='passed' and priorcheck['proof_sha256']==sha(B/'review-proof-v3-validation.json') and priorcheck['record_sha256']==sha(O/'reviews/bg.json')
assert oldrecord['review_proof']['sha256']==sha(B/'review-proof-v3-validation.json');assert record['review_proof']['sha256']==sha(B/'review-proof-v4-validation.json')
assert record['source_expansion_v4']==proof
source={s:read(K/'source'/f'{s}.json')for s in ('native','online')};oldsource={s:read(O/'source'/f'{s}.json')for s in source}
target={'native':p.CHECKER.read_table(K/'drafts/bg/texts.bg.txt')[0],'online':read(K/'drafts/bg/bg.json')};oldtarget={'native':p.CHECKER.read_table(O/'drafts/bg/texts.bg.txt')[0],'online':read(O/'drafts/bg/bg.json')}
for surface,path in p.catalog_paths(K,'bg').items():assert proof['catalog_sha256'][surface]==record['catalog_sha256'][surface]==sha(path)
assert proof['catalog_sha256']['native']=='24ee79586ba0e811c67958785623e0755602e2b075c767f7ee84e31677aa90bb'
assert proof['catalog_sha256']['online']=='69de8f4cf769924db105fe166cf25a352967e5ca3263951dd1753c3d8f263813'
for file,h in m['source_files'].items():assert sha(R/file)==h
assert rawhash(json.dumps(m['source_files'],sort_keys=True))==m['source_sha256']
for file,h in m['source_snapshots'].items():assert sha(K/'source'/file)==h
assert len(source['native'])==3425 and len(source['online'])==2843
for s in source:
 assert set(source[s])==set(target[s]);assert set(oldsource[s])<=set(source[s]);assert all(source[s][k]==v for k,v in oldsource[s].items())
added={s:{s+':'+k for k in source[s]if k not in oldsource[s]}for s in source};changed={s:{s+':'+k for k in oldsource[s]if target[s][k]!=oldtarget[s][k]}for s in source};delta=added['native']|changed['native'];assert len(added['native'])==14 and len(changed['native'])==15 and not added['online'] and not changed['online']
allids={s+':'+k for s in source for k in source[s]};unchanged=allids-delta;assert len(unchanged)==6239
for i in unchanged:
 s,k=i.split(':',1);assert source[s][k]==oldsource[s][k] and target[s][k]==oldtarget[s][k]
assert proof['source_delta']['new_native']==sorted(i[7:]for i in added['native']);assert proof['source_delta']['revised_native']==sorted(i[7:]for i in changed['native']);assert proof['source_delta']['unchanged_native_pairs']==3396 and proof['source_delta']['unchanged_online_pairs']==2843
# Reconstruct the historical pre-refinement catalog; earlier reviewer file hashes
# intentionally identify that snapshot, not today's final catalog.
native_order=(K/'drafts/bg/texts.bg.txt').read_text().splitlines()[::2];pre_values={**target['native'],**{i[7:]:oldtarget['native'][i[7:]]for i in changed['native']}}
pre_catalog_sha=rawhash(''.join(k+'\n'+pre_values[k]+'\n'for k in native_order));assert pre_catalog_sha=='2b59319009dd785659946516410f720e64a14f55bdb5f96baf7fe72e15715214'
roles=[]
for role,names,identity in [('semantic',['semantic-v4-final14.json','semantic-v4-refinement15.json'],'/root/semantic_reviewer'),('editor',['editor-v4-original-role-final14.json','editor-v4-refinement15.json'],'/root/bulgarian_editor')]:
 seen=set()
 for name in names:
  f=L/name;d=read(f);assert not d.get('findings') and not d.get('unresolved') and not d.get('unresolved_count');assert (d.get('reviewer_agent')or d['identity']['agent'])==identity
  aggregate=d.get('source_sha256',d.get('source_aggregate_contract_sha256',d.get('reported_source_aggregate_sha256')));assert aggregate==m['source_sha256']
  for e in d['entries']:
   i='native:'+e['key'];assert i not in seen;seen.add(i);assert e['source']==source['native'][e['key']] and e['target']==target['native'][e['key']]
   hasher=rawhash if role=='semantic'else jsonhash
   for field in ('source','target'):assert e[field+'_sha256']==hasher(e[field]),(name,e['key'],field)
   assert e.get('decision',e.get('status'))in ('approved','accept','acceptable');assert not e.get('findings')
  if '14' in name:
   if role=='semantic':
    assert d['prior_review_sha256']==sha(R/d['prior_review_file']);before=read(R/d['prior_review_file']);assert before['fresh_reading_count']==14;previous={e['key']:e for e in before['entries']};assert len(previous)==14
    for q in previous.values():
     assert q['source_sha256']==rawhash(q['source'])and q['target_sha256']==rawhash(q['target'])and q['actual_reading']
    fresh=[e for e in d['entries']if e['actual_reading']];assert len(fresh)==1
    for e in d['entries']:
     if not e['actual_reading']:q=previous[e['key']];assert q['actual_reading'] and (e['source'],e['target'])==(q['source'],q['target'])
   else:
    previous_file=L/'editor-v4-original-role14.json';before=read(previous_file);assert d['raw_file_sha256'][str(previous_file.relative_to(R))]==sha(previous_file);previous={e['key']:e for e in before['entries']};fresh=[e for e in d['entries']if e['method']=='actual-final-corrected-paragraph-reread'];assert len(fresh)==1
    for e in d['entries']:
     q=previous[e['key']];assert q['actual_editor_identity']==identity
     for field in ('source','input_target','proposed_final'):assert q[field+'_sha256']==jsonhash(q[field])
     if e not in fresh:assert (e['source'],e['target'])==(q['source'],q['proposed_final'])
   assert fresh[0]['key']=='[stat win probability about]'
   declared=d.get('native_catalog_sha256',d.get('staged_native3425_catalog_sha256'));assert declared==pre_catalog_sha
  else:
   assert len(d['entries'])==15
   declared=d.get('native_catalog_sha256',d.get('staged_native_catalog_sha256'));assert declared==proof['catalog_sha256']['native']
  row=next(row for row in proof['semantic_editor_delta']if row['role']==role);assert row['actual_agent']==identity;assert {'path':'linguistics/'+name,'sha256':sha(f)}in row['evidence']
  roles.append({'role':role,'file':'linguistics/'+name,'sha256':sha(f),'final_pairs':len(d['entries'])})
 assert seen==delta
# Additional editor is real supplementary coverage, not substituted for original role.
extra=read(L/'editor-v4-final14.json');assert extra['reviewer_agent']=='/root/compat_editor' and extra['approved_count']==14
extra_superseded=[]
for e in extra['entries']:
 assert e['source']==source['native'][e['key']]
 if e['target']!=target['native'][e['key']]:extra_superseded.append(e['key'])
 for field in ('source','target'):assert e[field+'_value_sha256']==rawhash(e[field])
assert extra_superseded==['[stat win probability about]']
# Complete new adversarial batch reading, followed by actual15 rereads/465 exact own carry.
advfile=L/'adversarial-v4-final-recheck.json';adv=read(advfile);priorfile=R/adv['prior_480_review_file'];assert sha(priorfile)==adv['prior_480_review_file_sha256'];before=read(priorfile);assert adv['reviewer']['actual_agent_identity']==before['reviewer']['actual_agent_identity']=='/root/v4_adversarial';assert before['coverage']['fresh_readings']==480
assert before['input_file_sha256']==sha(R/before['input_file']);actualinput=read(R/before['input_file']);input_entries={e['key']:e for batch in actualinput['batches']for e in batch['entries']};previous={e['key']:e for e in before['entries']};assert len(previous)==len(input_entries)==480
batchids=set(proof['adversarial']['complete_batches']);assert batchids=={'native-general-012','native-general-013','native-maps-001'};expected={i for batch in m['batches']if batch['id']in batchids for i in batch['keys']};assert len(expected)==480 and delta<=expected
assert {'native:'+e['key']for e in adv['entries']}==expected and len(adv['entries'])==480
fresh=0;carried=0
for e in adv['entries']:
 q=previous[e['key']];i='native:'+e['key'];assert q['fresh_reading']and q['source']==input_entries[e['key']]['source']and q['target']==input_entries[e['key']]['target']
 assert e['reviewer_agent']==q['reviewer_agent']=='/root/v4_adversarial';assert e['decision']=='accept'and not e['findings']and not e.get('unresolved_linguistic_uncertainty');assert e['source']==source['native'][e['key']]and e['target']==target['native'][e['key']]
 for entry in (e,q):
  for field in ('source','target'):assert entry[field+'_utf8_sha256']==rawhash(entry[field])
 lineage=e['lineage'];assert lineage['prior_report_sha256']==sha(priorfile) and lineage['prior_reviewer_agent']=='/root/v4_adversarial';assert lineage['prior_batch_id']==q['batch_id']and lineage['prior_batch_ordinal_0']==q['batch_ordinal_0'];assert lineage['prior_source_utf8_sha256']==q['source_utf8_sha256']and lineage['prior_target_utf8_sha256']==q['target_utf8_sha256']
 batch=next(b for b in m['batches']if b['id']==e['batch_id']);assert batch['keys'][e['batch_ordinal_0']]==i
 if e['fresh_reading_this_recheck']:fresh+=1;assert i in changed['native']and q['decision']=='change_requested'and e['resolved_findings']
 else:carried+=1;assert e['source']==q['source']and e['target']==q['target']and q['decision']=='accept'and lineage['target_exactly_unchanged']
assert fresh==15 and carried==465 and not adv['open_findings'];assert proof['adversarial']['evidence']=={'path':str(advfile.relative_to(B)),'sha256':sha(advfile)}
# Membership shifts are checked by literal per-key provenance, not batch-name inference.
old_members={i:b['id']for b in om['batches']for i in b['keys']};new_members={i:b['id']for b in m['batches']for i in b['keys']};assert set(new_members)==allids
oldrows={b['id']:b for b in oldrecord['batches']};rows={b['id']:b for b in record['batches']};shifted=[i for i in old_members if old_members[i]!=new_members[i]];bindings=0
for batch in m['batches']:
 row=rows[batch['id']];assert row['source_sha256']==m['source_sha256'];values={i:target[i.split(':',1)[0]][i.split(':',1)[1]]for i in batch['keys']};assert row['target_sha256']==rawhash(json.dumps(values,sort_keys=True,ensure_ascii=False))
 for field in ('reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys'):assert row[field]==batch['keys']
 assert len({row[f]for f in ('author','reviewer','editor','adversarial_reviewer')})==4
 for i in batch['keys']:
  assert row['reviewer']=='/root/semantic_reviewer'and row['editor']=='/root/bulgarian_editor';assert row['adversarial_reviewer']==('/root/v4_adversarial'if i in expected else'/root/adversarial_reviewer')
  if i not in delta:
   parentrow=oldrows[old_members[i]];assert row['author']==parentrow['author']and row['reviewer']==parentrow['reviewer']and row['editor']==parentrow['editor']
  if i not in expected:
   assert i in unchanged;assert row['adversarial_reviewer']==oldrows[old_members[i]]['adversarial_reviewer']
  bindings+=3
assert bindings==18804 and len(allids)==6268 and len(allids-expected)==5788
checked=p.check_draft(K,'bg');assert not checked['errors']and not checked['untranslated'];english={e['key']for e in record['accepted_english']};assert len(english)==108 and english==set(checked['same_as_english_review_queue']);assert record['accepted_english']==oldrecord['accepted_english'];assert len(record['gates'])==9 and all(g['passed']is False and not g['evidence']for g in record['gates'].values())
result={'result':'passed','validator':'/root/draft_tooling','scope':'Independent source/target/identity/lineage binding verification only; no new linguistic approval','source_sha256':m['source_sha256'],'catalog_sha256':proof['catalog_sha256'],'total_keys':6268,'bindings':bindings,'exact_parent_semantic_editor_pairs':6239,'explicit_semantic_editor_pairs_each':29,'new_native':14,'revised_native':15,'adversarial_final_batch_pairs':480,'adversarial_fresh_final_rereads':fresh,'adversarial_own_exact_carry':carried,'original_adversarial_exact_pairs':5788,'batch_membership_shifted_parent_keys':len(shifted),'batch_membership_shift_checked_per_key':True,'batch_target_hashes_checked':len(m['batches']),'accepted_english_exact_parent':108,'roles':roles,'historical_supplemental_editor':{'actual_identity':'/root/compat_editor','current_exact_pairs':13,'superseded_pairs':extra_superseded,'used_for_final_coverage':False},'original_editor_actual_identity':'/root/bulgarian_editor','fresh_adversarial_actual_identity':'/root/v4_adversarial','parent_record_sha256':sha(O/'reviews/bg.json'),'parent_proof_sha256':sha(B/'review-proof-v3-validation.json'),'proof_sha256':sha(B/'review-proof-v4-validation.json'),'record_sha256':sha(K/'reviews/bg.json'),'historical_pre_refinement_catalog_sha256_reconstructed':pre_catalog_sha,'all9_gates_pending':True,'no_approval_generated_by_validation':True}
(B/'review-proof-v4-independent-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
