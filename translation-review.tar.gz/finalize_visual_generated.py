"""Rebind supplied one-key reviews; retain all prior proof and before captures."""
from pathlib import Path
import copy,hashlib,importlib.util,json
R=Path(__file__).resolve().parents[2];B=R/'artifacts/bulgarian';K=B/'kit-v4';O=B/'visual-refinement-v4/before'
s=importlib.util.spec_from_file_location('p',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
def read(f):return json.loads(f.read_text())
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def ev(f):return {'path':str(f.relative_to(B)),'sha256':sha(f)}
m=read(K/'manifest.json');source=read(K/'source/native.json');old,errors=p.CHECKER.read_table(O/'texts.bg.txt');assert not errors
paths=p.catalog_paths(K,'bg');target,errors=p.CHECKER.read_table(paths['native']);assert not errors
assert set(old)==set(target)and[key for key in old if old[key]!=target[key]]==['[Generated]']
assert old['[Generated]']=='Генерирано'and target['[Generated]']=='Генерирана'
role_records=[]
for role,name in [('semantic','semantic-visual-generated.json'),('editor','editor-visual-generated.json'),('adversarial','adversarial-visual-generated.json')]:
 f=B/'linguistics'/name;d=read(f);e=d['entry']if'entry'in d else d['entries'][0];value=e.get('target',e.get('proposed_target'))
 assert e['key']=='[Generated]'and e['source']==source[e['key']]and value==target[e['key']]
 hash_value=lambda value:hashlib.sha256((json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))if role=='editor'else value).encode()).hexdigest()
 assert e.get('source_sha256',e.get('source_value_sha256'))==hash_value(e['source'])and e['target_sha256']==hash_value(value)
 assert not d.get('findings',[])and not d.get('unresolved_findings',[])
 role_records.append({'role':role,'agent':'/root/'+{'semantic':'semantic_reviewer','editor':'bulgarian_editor','adversarial':'adversarial_reviewer'}[role],'evidence':ev(f),'actual_targeted_readings':1})
record=read(O/'review-record-bg.json');before_hashes=record['catalog_sha256'];final_hashes={surface:sha(f)for surface,f in paths.items()};assert final_hashes['online']==before_hashes['online']
bhash=p.batch_target_hashes(m,paths);changed=[]
for batch in record['batches']:
 if batch['target_sha256']!=bhash[batch['id']]:changed.append(batch['id'])
assert changed==['native-general-008']
proof={'source_sha256':m['source_sha256'],'catalog_sha256':final_hashes,'parent_catalog_sha256':before_hashes,'parent_record':ev(O/'review-record-bg.json'),'parent_proof':ev(O/'review-proof-v4-validation.json'),'parent_independent_proof':ev(O/'review-proof-v4-independent-validation.json'),'changed_keys':['native:[Generated]'],'changed_batches':changed,'unchanged_exact_source_target_pairs':6267,'actual_new_reviews':role_records,'total_keys':6268,'role_bindings':18804,'adversarial_final_scope':'Fresh v4 agent480 unchanged; original agent5787 exact parent pairs plus actual Generated reread1.','semantic_editor_final_scope':'Parent6238 exact pairs plus explicit source/target30 values (14source additions,15earlier refinements,1Generated correction).','limits':'Binding verifier only; no linguistic approval generated. Before f02 runtime results remain their original producer. Layout fixes require actual after-render checks.'}
p.write_json(B/'review-proof-v4-visual-validation.json',proof)
record=copy.deepcopy(record);record['catalog_sha256']=final_hashes
for batch in record['batches']:
 batch['target_sha256']=bhash[batch['id']]
 if batch['id']in changed:batch['methodology']+=' Post-visual Generated value actually reread by original three roles; all other members retain exact parent pairs. See review-proof-v4-visual-validation.json.'
record['visual_refinement_v4']=proof;record['review_proof']={'path':'../../review-proof-v4-visual-validation.json','sha256':sha(B/'review-proof-v4-visual-validation.json')}
record['findings'].append({'key':'native:[Generated]','severity':'minor','state':'resolved','reason':'The map-mode option needs feminine agreement with implied карта.','resolution':'Генерирана independently accepted by original semantic/editorial/adversarial agents; exact target proofs linked in visual refinement record.'})
record['technical_findings']+= [{'id':'statistics-empty-notice-wrap','severity':'major','state':'pending-runtime-verification','reason':'Actual narrow desktop chart hard-clipped the correct Bulgarian no-history notice.','resolution':'Reviewed bounded production-font wrapping source and pixel regression integrated; actual after captures/tests still required.','evidence':[ev(B/'review-chart-script-visual-fixes.json')]},{'id':'script-editor-compact-status-and-labels','severity':'major','state':'pending-runtime-verification','reason':'Actual phone compiler status ellipsized the cause; tabs/actions fragmented words.','resolution':'Reviewed paragraph status and word-measured responsive touch grids integrated with production-host regression; actual after captures/tests and >=3code-lines still required.','evidence':[ev(B/'review-chart-script-visual-fixes.json')]}]
for name in record['gates']:record['gates'][name]={'passed':False,'evidence':[],'reason':'Await final post-visual source/catalog/render/test binding. Unavailable platform coverage must not be marked passed.'}
checked=p.check_draft(K,'bg');assert not checked['errors']and not checked['untranslated'];assert set(checked['same_as_english_review_queue'])=={e['key']for e in record['accepted_english']}
p.write_json(K/'reviews/bg.json',record);print(final_hashes,'6268 keys18804bindings; one changed batch original-role approvals; runtime gates pending')
