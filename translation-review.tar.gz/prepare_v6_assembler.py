from pathlib import Path
import shutil,json,hashlib
B=Path('artifacts/bulgarian');H=B/'v6-review-assembler';H.mkdir(exist_ok=True);P=H/'parent-v5';assert not P.exists();P.mkdir();K=B/'kit-v5'
for name in ('manifest.json','reviews/bg.json','review-proof-v5-validation.json'):
 q=P/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(K/name,q)
for name in ('source','drafts/bg'):shutil.copytree(K/name,P/name)
(P/'linked-proofs').mkdir();shutil.copy2(B/'review-proof-v5-independent-validation.json',P/'linked-proofs/review-proof-v5-independent-validation.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(H/'parent-snapshot.json').write_text(json.dumps({'purpose':'Immutable exact V5 final record/source/target/proofs snapshot, no new approval.','files':{str(p.relative_to(P)):sha(p)for p in P.rglob('*')if p.is_file()}},indent=2)+'\n')
s=(B/'v5-review-assembler/assemble.py').read_text()
s=s.replace('35a434573e88a3cc9ec968b1a8f6e9e4bfa922b21debf924aaa0374b7adec3fe','dca9d5dac7b077148101c5feb29e9321c93d59a922925fbcd3138da678c3d353').replace("len(source['online'])==2843","len(source['online'])==2948").replace('len(allkeys)==6272','len(allkeys)==6377')
s=s.replace("'actual_fresh_read','final_read'","'actual_fresh_read','final_read','actual_fresh_complete_final_pair_read','final_fresh_read'")
s=s.replace("for field in ('actual_fresh_final_pairs_read','fresh_final_pairs_read','fresh_readings'):","for field in ('actual_fresh_final_pairs_read','fresh_final_pairs_read','fresh_readings','actual_fresh_complete_final_pairs_read'):")
s=s.replace("counts[verify_entry_reading(e,d,role)]+=1", "require(fresh(e,d),'final full-batch report lacks actual fresh reading: '+entry_id(e));counts[verify_entry_reading(e,d,role)]+=1")
s=s.replace("if 'source_target_sha256'in e:","if 'identity_sha256'in e:require(e['identity_sha256']==digest(canonical([entry_id(e),e['source'],e['target']])),'combined identity hash mismatch')\n if 'source_target_sha256'in e:")
s=s.replace("('final_editor_report_path','final_editor_report_sha256')", "('final_editor_report_path','final_editor_report_sha256'),('editor_report_path','editor_report_sha256'),('context_reference_path','context_reference_sha256')")
s=s.replace("linked=parent/'linked-proofs/review-proof-v4-visual-validation.json';independent=parent/'linked-proofs/review-proof-v4-visual-independent-validation.json'", "linked=parent/'review-proof-v5-validation.json';independent=parent/'linked-proofs/review-proof-v5-independent-validation.json'")
s=s.replace("parentcheck['visual_proof_sha256']", "parentcheck['proof_sha256']").replace("parentcheck['final_record_sha256']", "parentcheck['record_sha256']")
s=s.replace("row=copy.deepcopy(oldrows[b['id']]);row.update", "row=copy.deepcopy(oldrows[b['id']])if b['id']in oldrows else {'id':b['id']};row.update")
s=s.replace('review-proof-v5-validation.json','review-proof-v6-validation.json').replace('source_expansion_v5','source_expansion_v6').replace('final v5 runtime','final v6 runtime').replace('normalized v4 parent','final v5 parent').replace('NB29 separate','MS19 separate').replace("default=BASE/'kit-v5'","default=BASE/'kit-v6'").replace("default=HERE/'parent-v4'","default=HERE/'parent-v5'")
# The parent link must remain V5, after renaming the new proof output.
s=s.replace("linked=parent/'review-proof-v6-validation.json'", "linked=parent/'review-proof-v5-validation.json'")
# Ensure the packet itself is source/target/current-scope bound, not merely hash-linked.
s=s.replace("fresh_ids=scope['batches'];", "fresh_ids=scope['batches'];")
s=s.replace("allkeys={s+':'+k for s in source for k in source[s]};unchanged", "require(len(m['batches'])==44,'unexpected batch total');packetpath=resolve_reference(scope['candidate_packet']);require(sha(packetpath)==scope['candidate_packet_sha256'],'scope candidate packet changed');packet=read(packetpath);require(packet['source_sha256']==m['source_sha256']and packet['catalog_sha256']==hashes,'scope packet source/catalog stale');require({e['id']for e in packet['entries']}==fresh_keys,'scope packet membership mismatch');require(len(packet['entries'])==len(fresh_keys),'scope packet duplicate entries');require(set(packet['batch_ids'])==set(fresh_ids),'scope packet batch IDs differ')\n allkeys={s+':'+k for s in source for k in source[s]};unchanged")
s=s.replace("approved={};role_proofs=[]", "approved={};role_proofs=[]\n for e in packet['entries']:require(e['source']==expected[e['id']]['source']and e['target']==expected[e['id']]['target']and e['batch_id']==expected[e['id']]['batch_id'],'scope packet literal/batch differs')")
(H/'assemble.py').write_text(s)
packet=B/'kit-v6/bg228-final-candidate-input.json';d=json.loads(packet.read_text());scope={'source_sha256':d['source_sha256'],'batches':d['batch_ids'],'expected_entries':len(d['entries']),'candidate_packet':str(packet),'candidate_packet_sha256':sha(packet),'context_reuse':[],'scope_type':'Mechanical full affected batch membership, not a reviewer approval','author':'/root/draft_tooling'}
(B/'kit-v6/final-review-scope.json').write_text(json.dumps(scope,indent=2)+'\n')
