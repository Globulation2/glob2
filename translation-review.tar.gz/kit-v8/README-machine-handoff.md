Machine-first-draft V8 handoff

Source3430native+2978online=6408keys, frozen during the unresolved generated-browser-file merge; revision is intentionally null. Source identity and actual parent V7 review/proof hashes are in review-handoff.json.

Review the full98pairs in bg-full-affected-batches-review-input.json, not merely the30newkeys. Marathi and Tamil compatibility packets contain18nativepairs each; their Artist entries already exist and were not requested. Packet hashes, provider raw-body hashes, catalogs, exact source/target literals, protected tokens and caller references are bound in the JSON evidence. No linguistic approval is inferred from machine agreement.

The92prior cumulative reservations and raw responses are preserved exactly; three additional requests produced95reservations/$5.46822. Provider outputs are frozen separately under provider-drafts; only ignored editable drafts may be revised by the review process. Do not rerun run_kit_v8_once.py: it is an evidence record of the authorized3requests, not a resume launcher. Use the reviewed CLI for any independently authorized resume.

All6378previousBGpairs remain exact at this initial stage; all existing MR/TA pairs remain exact. All runtime/platform gates stay pending. Historical native/browser receipts retain actual producer identities and are not V8 runtime evidence. No live catalog values were changed by this drafting task.
