"""Temporary marked fixtures exercise mechanics; no reviewer approvals are emitted."""
import copy,importlib.util,json,shutil,tempfile,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('assembler',HERE/'assemble.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
class AssemblyTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(dir=HERE,prefix='mock-test-');self.addCleanup(self.temp.cleanup);self.folder=Path(self.temp.name);self.path=self.folder/'mock.json';self.sourcehash='mock-source';self.hashes={'native':'n','online':'o'}
  self.expected={'native:[Mock]':{'source':'Source','target':'Превод'},'online:Mock plural':{'source':{'one':'One','other':'Many'},'target':{'one':'Едно','other':'Много'}}}
  self.entries=[]
  for i,v in self.expected.items():
   surface,key=i.split(':',1);self.entries.append({'id':i,'key':key,'surface':surface,**v,'status':'approved','final_read':True,'source_sha256':a.digest(v['source']if isinstance(v['source'],str)else a.canonical(v['source'])),'target_sha256':a.digest(v['target']if isinstance(v['target'],str)else a.canonical(v['target'])),'source_target_sha256':a.digest(a.canonical([i,v['source'],v['target']]))})
  self.data={'test_fixture':True,'reviewer_identity':{'agent':a.ROLES['semantic']},'status':'approved','source_sha256':self.sourcehash,'catalog_sha256':self.hashes,'coverage':{'expected':2,'reviewed':2,'approved':2,'fresh_final_pairs_read':2},'entries':self.entries,'findings':[]}
 def report(self):
  self.path.write_text(json.dumps(self.data,ensure_ascii=False));return a.verify_report(self.path,'semantic',self.expected,self.sourcehash,self.hashes)
 def test_valid_literal_and_plural_hashes(self):
  _,proof=self.report();self.assertEqual(proof['reading_lineage'],{'actual-reading':2,'own-exact-carry':0})
 def test_missing_final_report(self):
  with self.assertRaisesRegex(ValueError,'missing final'):a.verify_report(self.path,'semantic',self.expected,self.sourcehash,self.hashes)
 def test_pending_report_and_entry_rejected(self):
  self.data['status']='pending'
  with self.assertRaises(ValueError):self.report()
  self.data['status']='approved';self.entries[0]['status']='proposed_edit'
  with self.assertRaises(ValueError):self.report()
 def test_stale_source_and_target_catalog(self):
  self.data['source_sha256']='stale'
  with self.assertRaises(ValueError):self.report()
  self.data['source_sha256']=self.sourcehash;self.data['catalog_sha256']={'native':'wrong','online':'o'}
  with self.assertRaises(ValueError):self.report()
 def test_wrong_actual_role_identity(self):
  self.data['reviewer_identity']['agent']=a.ROLES['editor']
  with self.assertRaises(ValueError):self.report()
 def test_literal_pair_and_coverage_mismatch(self):
  self.entries[0]['target']='Wrong'
  with self.assertRaisesRegex(ValueError,'literal final pair'):self.report()
 def test_duplicate_and_missing_entries(self):
  self.data['entries']=[self.entries[0],self.entries[0]]
  with self.assertRaisesRegex(ValueError,'membership'):self.report()
 def test_value_hash_and_compound_hash_fail(self):
  self.entries[0]['source_sha256']='bad'
  with self.assertRaises(ValueError):self.report()
  self.entries[0]['source_sha256']=a.digest('Source');self.entries[0]['source_target_sha256']='bad'
  with self.assertRaisesRegex(ValueError,'combined'):self.report()
 def test_canonical_value_and_literal_variant_hashes(self):
  self.data['coverage']['literal_variants']=3
  for e in self.entries:
   e['source_sha256']=a.digest(a.canonical(e['source']));e['target_sha256']=a.digest(a.canonical(e['target']));e['pair_sha256']=e.pop('source_target_sha256')
   pairs={'literal':(e['source'],e['target'])}if isinstance(e['source'],str)else{k:(e['source'][k],e['target'][k])for k in e['source']}
   e['variants']={k:{'source_sha256_utf8':a.digest(v[0]),'target_sha256_utf8':a.digest(v[1]),'decision':'accepted'}for k,v in pairs.items()}
  _,proof=self.report();self.assertEqual(proof['value_hash_schemes'],['canonical-json'])
  self.entries[0]['variants']['literal']['target_sha256_utf8']='bad'
  with self.assertRaisesRegex(ValueError,'variant'):self.report()
 def test_wrong_batch_assignment_rejected(self):
  for value in self.expected.values():value['batch_id']='mock-batch'
  for e in self.entries:e['batch_id']='wrong-batch'
  with self.assertRaisesRegex(ValueError,'wrong batch'):self.report()
 def test_reading_claim_required(self):
  self.entries[0]['final_read']=False
  with self.assertRaisesRegex(ValueError,'lacks actual'):self.report()
 def test_own_exact_lineage_and_mutation(self):
  prior=self.folder/'prior.json';prior.write_text(json.dumps(self.data,ensure_ascii=False));self.entries[0]['final_read']=False;self.entries[0]['lineage']={'prior_report':str(prior),'prior_report_sha256':a.sha(prior)};self.data['coverage']['fresh_final_pairs_read']=1
  _,proof=self.report();self.assertEqual(proof['reading_lineage']['own-exact-carry'],1)
  self.entries[0]['lineage']['prior_report_sha256']='bad'
  with self.assertRaises(ValueError):self.report()
 def test_false_fresh_count_rejected(self):
  self.data['coverage']['fresh_final_pairs_read']=1
  with self.assertRaisesRegex(ValueError,'contradicts'):self.report()
 def test_english_exception_requires_exact_parent_or_three_actual_reasons(self):
  src={'native':{'X':'X'},'online':{}};target=copy.deepcopy(src);old={'native':{'X':'old'},'online':{}};parent={'native:X':{'key':'native:X','reason':'Identifier'}};roles={r:{}for r in a.ROLES}
  accepted=a.english_exceptions({'native:X'},parent,src,target,src,target,set(),roles);self.assertEqual(accepted,list(parent.values()))
  with self.assertRaises(ValueError):a.english_exceptions({'native:X'},parent,src,target,old,target,{'native:X'},roles)
  for role in roles:roles[role]['accepted_english']=[{'key':'native:X','reason':'Actual mock identifier exception'}]
  self.assertEqual(len(a.english_exceptions({'native:X'},parent,src,target,old,target,{'native:X'},roles)),1)
 def test_context_requires_three_actual_acceptances_and_literal_hashes(self):
  reuse={'context_id':'mock-context','source':'Building','target':'Изграждане','catalog_key':'Build','catalog_source':'Build','reports_pending':True};scope={'context_reuse':[reuse]};source={'online':{'Build':'Build'}};target={'online':{'Build':'Изграждане'}};e={**reuse,'status':'approved','actual_fresh_read':True,'source_sha256':a.digest('Building'),'target_sha256':a.digest('Изграждане')};roles={role:{'context_reuse':[copy.deepcopy(e)]}for role in a.ROLES};proofs=[{'role':role}for role in a.ROLES]
  self.assertEqual(len(a.verify_contexts(scope,roles,proofs,source,target)),3)
  roles['editor']['context_reuse']=[]
  with self.assertRaises(ValueError):a.verify_contexts(scope,roles,proofs,source,target)
 def test_mutated_unaffected_pair_rejected_before_missing_roles(self):
  original=a.BASE/'kit-v5';clone=self.folder/'kit';clone.mkdir()
  for name in ('manifest.json','final-review-scope.json'):shutil.copy2(original/name,clone/name)
  shutil.copytree(original/'source',clone/'source');shutil.copytree(original/'drafts',clone/'drafts');m=a.read(clone/'manifest.json');scope=a.read(clone/'final-review-scope.json');fresh={i for b in m['batches']if b['id']in scope['batches']for i in b['keys']};path=clone/'drafts/bg/texts.bg.txt';lines=path.read_text().splitlines();key=next(k for k in lines[::2]if'native:'+k not in fresh);index=lines.index(key);lines[index+1]='MOCK OUT OF SCOPE';path.write_text('\n'.join(lines)+'\n');reports={r:self.folder/'missing.json'for r in a.ROLES}
  with self.assertRaisesRegex(ValueError,'outside final full-batch scope'):a.assemble(clone,HERE/'parent-v4',clone/'final-review-scope.json',reports)
if __name__=='__main__':unittest.main(verbosity=2)
