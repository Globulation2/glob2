"""Assemble only supplied final BG reviews; never create a reviewer approval."""
from pathlib import Path
import argparse,copy,hashlib,importlib.util,json
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'artifacts/bulgarian';HERE=Path(__file__).resolve().parent
ROLES={'semantic':'/root/v5_semantic','editor':'/root/v5_editor','adversarial':'/root/v5_adversary'}
ACCEPT={'approved','approve','accepted','accept','acceptable','no_semantic_blocker','no_editorial_change','no_changes_needed'}
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(value):return hashlib.sha256(value.encode()).hexdigest()
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def require(test,message):
 if not test:raise ValueError(message)
def identity(d):
 values=[]
 for field in ('reviewer_agent','reviewer','actual_agent','reviewer_identity'):
  v=d.get(field)
  if isinstance(v,str):values.append(v)
  elif isinstance(v,dict):values.extend(v[k]for k in ('agent','agent_path','actual_agent_identity')if k in v)
 if isinstance(d.get('identity'),dict):values.append(d['identity'].get('agent'))
 values=[v for v in values if v];require(len(set(values))==1,'missing/ambiguous actual reviewer identity');return values[0]
def verdict(e):return e.get('decision',e.get('status',e.get('verdict')))
def entry_id(e):
 value=e.get('id')or(e.get('surface','native')+':'+e['key']);surface,key=value.split(':',1)
 require(surface in ('native','online')and e.get('key',key)==key and e.get('surface',surface)==surface,'entry identity mismatch');require(e.get('locale','bg')=='bg','non-BG entry in BG report');return value

def hash_fields(e,field):
 names=(field+'_sha256',field+'_value_sha256',field+'_utf8_sha256')
 found=[e[n]for n in names if n in e];require(bool(found),'missing '+field+' SHA256');return found

def check_value_hashes(e,schemes):
 for field in ('source','target'):
  value=e[field];variants={'canonical-json':digest(canonical(value)),'literal-utf8-with-json-objects':digest(value if isinstance(value,str)else canonical(value))}
  schemes &= {name for name,h in variants.items()if all(v==h for v in hash_fields(e,field))}
  require(bool(schemes),'source/target hash mismatch or inconsistent role hash scheme: '+entry_id(e))
 if 'pair_sha256'in e:require(e['pair_sha256']==digest(canonical([entry_id(e),e['source'],e['target']])),'combined pair hash mismatch')
 if 'source_target_sha256'in e:require(e['source_target_sha256']==digest(canonical([entry_id(e),e['source'],e['target']])),'combined [id,source,target] hash mismatch')
 if 'translation_sha256'in e:require(e['translation_sha256']in {digest(e['target']if isinstance(e['target'],str)else canonical(e['target'])),digest(canonical(e['target']))},'translation hash mismatch')
 return schemes

def fresh(e,d):
 if any(e.get(f)is True for f in ('actual_reading','fresh_reading','fresh_reading_this_recheck','actual_final_reading','actual_fresh_read','final_read')):return True
 if e.get('coverage')in ('entire_literal_source_and_target_read_fresh','entire_literal_source_and_target_fresh_read'):return True
 c=d.get('coverage',{});n=len(d.get('entries',[]))
 return(c.get('fresh_reading')is True or c.get('fresh_read')is True)and any(c.get(k)==n for k in ('read','actually_read','fresh_readings','expected','entries'))

def resolve_reference(name,base=BASE):
 p=Path(name);p=p if p.is_absolute()else(ROOT/p if str(p).startswith('artifacts/')else base/p)
 require(p.resolve().is_relative_to(BASE.resolve()),'review reference escapes evidence root');require(p.is_file(),'missing report '+str(p));return p

def verify_entry_reading(e,d,role,seen=None):
 if fresh(e,d):return 'actual-reading'
 lineage=e.get('lineage',{});name=lineage.get('prior_report',e.get('prior_review_file'));expected=lineage.get('prior_report_sha256',e.get('prior_review_file_sha256'))
 require(name and expected,'entry lacks actual reading or own exact lineage: '+entry_id(e));path=resolve_reference(name);require(sha(path)==expected,'prior report changed');token=(str(path),entry_id(e));seen=set()if seen is None else seen;require(token not in seen and len(seen)<8,'cyclic/excessive review lineage');seen=seen|{token};prior=read(path);require(identity(prior)==ROLES[role],'carry-forward is not this role agent own review');matches=[x for x in prior.get('entries',[])if entry_id(x)==entry_id(e)];require(len(matches)==1,'prior entry missing/duplicated');q=matches[0];require(q['source']==e['source']and q['target']==e['target'],'own carry pair changed');require(verdict(q)in ACCEPT,'prior entry was not accepted');check_value_hashes(q,{'canonical-json','literal-utf8-with-json-objects'});verify_entry_reading(q,prior,role,seen);return 'own-exact-carry'

def verify_report(path,role,expected,source_hash,catalog_hashes):
 path=path.resolve();require(path.is_relative_to(BASE.resolve()),'report escapes evidence root')
 require(path.is_file(),'missing final '+role+' report: '+str(path));d=read(path);require(identity(d)==ROLES[role],'wrong actual '+role+' reviewer');require(d.get('status',d.get('decision'))in ACCEPT or d.get('final_approval')is True,'report is not an actual final approval: '+role)
 for path_field,hash_field in (('packet_path','packet_sha256'),('packet','packet_sha256'),('input_path','input_sha256'),('final_editor_report_path','final_editor_report_sha256')):
  if path_field in d:require(d.get(hash_field)and sha(resolve_reference(d[path_field]))==d[hash_field],'input/reference file missing or changed: '+role)
 require(d.get('source_sha256')==source_hash,'stale report source: '+role);declared=d.get('catalog_sha256',{'native':d.get('native_catalog_sha256'),'online':d.get('online_catalog_sha256')});require(declared==catalog_hashes,'stale/missing final catalog hashes: '+role)
 for field in ('unresolved_findings','open_findings','unresolved_questions','unresolved_uncertainties'):require(not d.get(field),'unresolved report '+role+': '+field)
 entries=d.get('entries',[]);require(len(entries)==len(expected),'incomplete final report '+role);ids=[entry_id(e)for e in entries];require(len(set(ids))==len(ids)and set(ids)==set(expected),'final report membership mismatch '+role)
 coverage=d.get('coverage',{})
 for field in ('expected','reviewed','approved','entries'):
  if field in coverage:require(coverage[field]==len(expected),'coverage count mismatch '+role+': '+field)
 if 'batches'in coverage:
  counts_by_batch={}
  for e in entries:
   require(e.get('batch_id'),'batch_id missing in report entry');counts_by_batch[e['batch_id']]=counts_by_batch.get(e['batch_id'],0)+1
  require(coverage['batches']==counts_by_batch,'report batch counts mismatch '+role)
 literal_variants=0
 schemes={'canonical-json','literal-utf8-with-json-objects'};counts={'actual-reading':0,'own-exact-carry':0}
 for e in entries:
  value=expected[entry_id(e)]
  if 'batch_id'in value:require(e.get('batch_id')==value['batch_id'],'entry assigned to wrong batch: '+entry_id(e))
  require(e['source']==value['source']and e['target']==value['target'],'literal final pair mismatch '+role+': '+entry_id(e));require(verdict(e)in ACCEPT,'entry not accepted '+role+': '+entry_id(e));schemes=check_value_hashes(e,schemes);counts[verify_entry_reading(e,d,role)]+=1
  if 'variants'in e:
   expected_variants={'literal':(e['source'],e['target'])}if isinstance(e['source'],str)else{key:(e['source'][key],e['target'][key])for key in e['source']}
   require(set(e['variants'])==set(expected_variants),'plural variant membership differs')
   for name,(sv,tv)in expected_variants.items():
    variant=e['variants'][name];require(variant['source_sha256_utf8']==digest(sv)and variant['target_sha256_utf8']==digest(tv)and verdict(variant)in ACCEPT,'plural variant hashes/decision differ')
  literal_variants+=1 if isinstance(e['source'],str)else len(e['source'])
 if 'literal_variants'in coverage:require(coverage['literal_variants']==literal_variants,'literal variant count differs')
 for field in ('actual_fresh_final_pairs_read','fresh_final_pairs_read','fresh_readings'):
  if field in coverage:require(coverage[field]==counts['actual-reading'],'fresh-reading count contradicts actual entry lineage: '+role)
 for field in ('lineage_only','unchanged_lineage_only','exact_unchanged_carry'):
  if field in coverage:require(coverage[field]==counts['own-exact-carry'],'own-carry count contradicts entry lineage: '+role)
 for f in d.get('findings',[]):require(f.get('state')=='resolved'or(f.get('severity')=='minor'and f.get('state')=='accepted'and f.get('reason')),'unclosed finding in final '+role+' report')
 return d,{'role':role,'actual_agent':ROLES[role],'path':str(path.relative_to(BASE)),'sha256':sha(path),'entries':len(entries),'value_hash_schemes':sorted(schemes),'reading_lineage':counts}

def verify_contexts(scope,approved,role_proofs,source,target):
 require(set(approved)==set(ROLES),'all three actual roles required for context reuse')
 context_proofs=[]
 for reuse in scope.get('context_reuse',[]):
  key=reuse['catalog_key'];require(source['online'][key]==reuse['catalog_source']and target['online'][key]==reuse['target'],'context catalog literal differs')
  for role,d in approved.items():
   contexts=d.get('context_reuse')
   if contexts is None:contexts=[{'context_id':name,**value}for name,value in d.get('context_resolutions',{}).items()if isinstance(value,dict)and 'source'in value and 'target'in value]
   found=[e for e in contexts if e.get('context_id')==reuse['context_id']];require(len(found)==1,'missing actual '+role+' context approval');e=found[0]
   require(verdict(e)in ACCEPT and fresh(e,d),'context not actually approved')
   require(all(e.get(k)==reuse[k]for k in ('source','target'))and all(e.get(k,reuse[k])==reuse[k]for k in ('catalog_key','catalog_source')),'context approval literal mismatch')
   if any(key in e for key in ('source_sha256','source_value_sha256')):check_value_hashes({**e,'id':'online:'+reuse['source'],'key':reuse['source'],'surface':'online'},{'canonical-json','literal-utf8-with-json-objects'})
   if 'global_entity_target'in e:require(e['global_entity_target']==target['online']['Building'],'global Building entity target differs')
   context_proofs.append({'context_id':reuse['context_id'],'role':role,'actual_agent':ROLES[role],'actual_approved':True,'scope_input_reports_pending_flag':reuse.get('reports_pending',False),'evidence':role_proofs[list(ROLES).index(role)]})

 return context_proofs

def english_exceptions(queue,oldaccepted,source,target,oldsource,oldtarget,fresh_keys,approved):
 accepted=[]
 for i in sorted(queue):
  s,k=i.split(':',1)
  if i in oldaccepted and k in oldsource[s]and source[s][k]==oldsource[s][k]and target[s][k]==oldtarget[s][k]:accepted.append(copy.deepcopy(oldaccepted[i]));continue
  require(i in fresh_keys,'new English match outside review scope')
  reasons=[]
  for role,d in approved.items():
   rows=[e for e in d.get('accepted_english',[])if e.get('key',e.get('id'))==i];require(len(rows)==1 and rows[0].get('reason','').strip(),'new English match lacks explicit '+role+' exception: '+i);reasons.append(role+': '+rows[0]['reason'])
  accepted.append({'key':i,'reason':'; '.join(reasons)})

 return accepted

def load_program():
 s=importlib.util.spec_from_file_location('translation_program',ROOT/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p);return p

def assemble(kit,parent,scope_path,reports,write=False):
 kit=kit.resolve();parent=parent.resolve();scope_path=scope_path.resolve();reports={role:path.resolve()for role,path in reports.items()}
 p=load_program();m=read(kit/'manifest.json');pm=read(parent/'manifest.json');record=read(parent/'reviews/bg.json');scope=read(scope_path)
 require(m['source_sha256']==scope['source_sha256']=='35a434573e88a3cc9ec968b1a8f6e9e4bfa922b21debf924aaa0374b7adec3fe','source contract differs');source={s:read(kit/'source'/f'{s}.json')for s in ('native','online')};oldsource={s:read(parent/'source'/f'{s}.json')for s in source};paths=p.catalog_paths(kit,'bg');oldpaths=p.catalog_paths(parent,'bg');target={'native':p.CHECKER.read_table(paths['native'])[0],'online':read(paths['online'])};oldtarget={'native':p.CHECKER.read_table(oldpaths['native'])[0],'online':read(oldpaths['online'])};hashes={s:sha(path)for s,path in paths.items()}
 require(record['source_sha256']==pm['source_sha256']and record['catalog_sha256']=={s:sha(path)for s,path in oldpaths.items()},'stale parent record');require(len(source['native'])==3429 and len(source['online'])==2843,'unexpected source sizes');require(all(set(source[s])==set(target[s])for s in source),'catalog membership mismatch')
 live_sources=p.sources(ROOT);require(live_sources[4]==m['source_sha256']and live_sources[1]==source['native']and live_sources[2]==source['online'],'frozen source differs from current English contracts')
 for name,h in m['source_snapshots'].items():require(sha(kit/'source'/name)==h,'kit source snapshot changed: '+name)
 for s in source:require(all(source[s].get(k)==v for k,v in oldsource[s].items()),'old English source changed')
 batches={b['id']:b for b in m['batches']};fresh_ids=scope['batches'];require(len(set(fresh_ids))==len(fresh_ids)and set(fresh_ids)<=set(batches),'invalid scope batch IDs');fresh_keys={i for name in fresh_ids for i in batches[name]['keys']};require(len(fresh_keys)==scope['expected_entries'],'scope count differs from complete batches')
 allkeys={s+':'+k for s in source for k in source[s]};unchanged=allkeys-fresh_keys;require(len(allkeys)==6272,'unexpected total keys')
 for i in unchanged:
  s,k=i.split(':',1);require(k in oldsource[s]and source[s][k]==oldsource[s][k]and target[s][k]==oldtarget[s][k],'changed/new pair outside final full-batch scope: '+i)
 linked=parent/'linked-proofs/review-proof-v4-visual-validation.json';independent=parent/'linked-proofs/review-proof-v4-visual-independent-validation.json';require(linked.is_file()and independent.is_file(),'parent linked proofs missing');parentproof=read(linked);parentcheck=read(independent);require(record['review_proof']['sha256']==sha(linked)and parentcheck['visual_proof_sha256']==sha(linked)and parentcheck['final_record_sha256']==sha(parent/'reviews/bg.json'),'parent linked proof identity changed');require(parentproof['source_sha256']==pm['source_sha256']and parentproof['catalog_sha256']==record['catalog_sha256']and parentcheck['result']=='passed','parent proof not bound to exact source/catalogs')
 oldb={b['id']:b for b in pm['batches']};oldrows={b['id']:b for b in record['batches']};oldhashes=p.batch_target_hashes(pm,oldpaths)
 for b in pm['batches']:
  row=oldrows[b['id']];require(row['source_sha256']==pm['source_sha256']and row['target_sha256']==oldhashes[b['id']],'parent batch stale')
  for field in ('reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys'):require(row[field]==b['keys'],'parent per-role coverage changed')
  require(len({row[field]for field in ('author','reviewer','editor','adversarial_reviewer')})==4,'parent role identities not distinct')
 for b in m['batches']:
  if b['id']not in fresh_ids:require(b['keys']==oldb[b['id']]['keys'],'shifted membership outside full-batch scope')
 membership={i:b['id']for b in m['batches']for i in b['keys']}
 expected={i:{'batch_id':membership[i],'source':source[i.split(':',1)[0]][i.split(':',1)[1]],'target':target[i.split(':',1)[0]][i.split(':',1)[1]]}for i in fresh_keys};approved={};role_proofs=[]
 for role in ROLES:approved[role],evidence=verify_report(reports[role],role,expected,m['source_sha256'],hashes);role_proofs.append(evidence)
 context_proofs=verify_contexts(scope,approved,role_proofs,source,target)
 checked=p.check_draft(kit,'bg');require(not checked['errors']and not checked['untranslated'],'draft contract errors/blank translations: '+repr(checked));queue=set(checked['same_as_english_review_queue']);oldaccepted={e['key']:e for e in record.get('accepted_english',[])}
 accepted=english_exceptions(queue,oldaccepted,source,target,oldsource,oldtarget,fresh_keys,approved)
 proof={'source_sha256':m['source_sha256'],'catalog_sha256':hashes,'parent_record':{'path':str((parent/'reviews/bg.json').relative_to(BASE)),'sha256':sha(parent/'reviews/bg.json')},'parent_manifest':{'path':str((parent/'manifest.json').relative_to(BASE)),'sha256':sha(parent/'manifest.json')},'scope':{'path':str(scope_path.relative_to(BASE)),'sha256':sha(scope_path)},'total_keys':len(allkeys),'role_bindings':3*len(allkeys),'fresh_batches':fresh_ids,'actual_fresh_scope_entries_per_role':len(fresh_keys),'exact_parent_pairs':len(unchanged),'unchanged_key_ids':sorted(unchanged),'role_evidence':role_proofs,'context_reuse':context_proofs,'accepted_english_carried':sum(e['key']in oldaccepted for e in accepted),'accepted_english_new':sum(e['key']not in oldaccepted for e in accepted),'candidate_only':True,'source_added_ids':sorted(i for i in allkeys if i.split(':',1)[1]not in oldsource[i.split(':',1)[0]]),'target_changed_existing_ids':sorted(i for i in allkeys if i.split(':',1)[1]in oldtarget[i.split(':',1)[0]]and target[i.split(':',1)[0]][i.split(':',1)[1]]!=oldtarget[i.split(':',1)[0]][i.split(':',1)[1]]),'limits':'Mechanical binding validation only; NB29 separate; no reviewer approval generated. All runtime/platform gates remain pending.'}
 result=copy.deepcopy(record);result.update(source_sha256=m['source_sha256'],catalog_sha256=hashes,batches=[],accepted_english=accepted);bh=p.batch_target_hashes(m,paths)
 for b in m['batches']:
  row=copy.deepcopy(oldrows[b['id']]);row.update(source_sha256=m['source_sha256'],target_sha256=bh[b['id']])
  if b['id']in fresh_ids:row.update(author='/root',reviewer=ROLES['semantic'],editor=ROLES['editor'],adversarial_reviewer=ROLES['adversarial'],rechecked_by=ROLES['semantic'])
  for field in ('reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys'):row[field]=b['keys']
  row['methodology']='Actual complete final batch role records in review-proof-v5-validation.json.'if b['id']in fresh_ids else'Exact source/target and original role identity carry-forward from frozen normalized v4 parent; no fresh reading claimed.';result['batches'].append(row)
 for gate in p.GATES:result['gates'][gate]={'passed':False,'evidence':[],'reason':'Pending actual final v5 runtime/platform verification.'}
 result['source_expansion_v5']=proof
 audit=p.audit_locale(kit,m,result,'bg');expected_gate_issues={gate+' is pending or lacks evidence'for gate in p.GATES};require(set(audit)==expected_gate_issues,'assembled core audit has non-gate errors: '+repr(audit));proof['core_audit_issues']=audit;proof['all9_gates_pending']=True
 if write:
  require(all(sha(reports[r])==next(e['sha256']for e in role_proofs if e['role']==r)for r in ROLES),'review changed during assembly')
  require({s:sha(path)for s,path in paths.items()}==hashes and sha(scope_path)==proof['scope']['sha256']and sha(parent/'reviews/bg.json')==proof['parent_record']['sha256'],'candidate/scope/parent changed during assembly')
  proofpath=kit/'review-proof-v5-validation.json';p.write_json(proofpath,proof);result['review_proof']={'path':'../review-proof-v5-validation.json','sha256':sha(proofpath)};p.write_json(kit/'reviews/bg.json',result)
 return proof,result

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--kit',type=Path,default=BASE/'kit-v5');parser.add_argument('--parent',type=Path,default=HERE/'parent-v4');parser.add_argument('--scope',type=Path);parser.add_argument('--semantic',type=Path,required=True);parser.add_argument('--editor',type=Path,required=True);parser.add_argument('--adversarial',type=Path,required=True);parser.add_argument('--write',action='store_true');args=parser.parse_args();proof,_=assemble(args.kit,args.parent,args.scope or args.kit/'final-review-scope.json',{role:getattr(args,role)for role in ROLES},args.write);print(json.dumps({k:v for k,v in proof.items()if k!='unchanged_key_ids'},indent=2))
if __name__=='__main__':main()
