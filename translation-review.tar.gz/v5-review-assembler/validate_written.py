"""Independent written-record binding check; no linguistic or runtime approval."""
from pathlib import Path
import hashlib,json,importlib.util
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';K=B/'kit-v5';P=Path(__file__).resolve().parent/'parent-v4';read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
s=importlib.util.spec_from_file_location('program',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
m=read(K/'manifest.json');record=read(K/'reviews/bg.json');proof=read(K/'review-proof-v5-validation.json');scope=read(K/'final-review-scope.json');parent=read(P/'reviews/bg.json');pm=read(P/'manifest.json');source={s:read(K/'source'/f'{s}.json')for s in ('native','online')};psource={s:read(P/'source'/f'{s}.json')for s in source};target={'native':p.CHECKER.read_table(K/'drafts/bg/texts.bg.txt')[0],'online':read(K/'drafts/bg/bg.json')};ptarget={'native':p.CHECKER.read_table(P/'drafts/bg/texts.bg.txt')[0],'online':read(P/'drafts/bg/bg.json')}
assert record['source_sha256']==proof['source_sha256']==m['source_sha256'];assert record['catalog_sha256']==proof['catalog_sha256']=={s:sha(path)for s,path in p.catalog_paths(K,'bg').items()};assert record['review_proof']['sha256']==sha(K/'review-proof-v5-validation.json');assert record['source_expansion_v5']==proof
assert sha(P/'reviews/bg.json')==proof['parent_record']['sha256']and sha(P/'manifest.json')==proof['parent_manifest']['sha256'];assert sha(K/'final-review-scope.json')==proof['scope']['sha256']
allids={s+':'+k for s in source for k in source[s]};fresh={i for batch in m['batches']if batch['id']in scope['batches']for i in batch['keys']};unchanged=allids-fresh;assert len(allids)==6272 and len(fresh)==1154 and len(unchanged)==5118;assert set(proof['unchanged_key_ids'])==unchanged
for i in unchanged:
 s,k=i.split(':',1);assert source[s][k]==psource[s][k]and target[s][k]==ptarget[s][k]
rows={b['id']:b for b in record['batches']};oldrows={b['id']:b for b in parent['batches']};bindings=0
for batch in m['batches']:
 row=rows[batch['id']];assert row['source_sha256']==m['source_sha256'];assert row['target_sha256']==h({i:target[i.split(':',1)[0]][i.split(':',1)[1]]for i in batch['keys']})
 for field in ('reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys'):assert row[field]==batch['keys']
 if batch['id']in scope['batches']:assert [row[k]for k in ('author','reviewer','editor','adversarial_reviewer')]==['/root','/root/v5_semantic','/root/v5_editor','/root/v5_adversary']
 else:
  for field in ('author','reviewer','editor','adversarial_reviewer'):assert row[field]==oldrows[batch['id']][field]
 bindings+=3*len(batch['keys'])
for role in proof['role_evidence']:
 path=B/role['path'];assert sha(path)==role['sha256'];d=read(path);identity=d.get('reviewer_identity',{}).get('agent',d.get('reviewer',{}).get('agent_path'));assert identity==role['actual_agent'];assert d['source_sha256']==m['source_sha256']and d['catalog_sha256']==record['catalog_sha256'];assert len(d['entries'])==1154
 assert {e['id']for e in d['entries']}==fresh
 for e in d['entries']:
  s,k=e['id'].split(':',1);assert e['source']==source[s][k]and e['target']==target[s][k]
assert len(proof['context_reuse'])==3 and {e['actual_agent']for e in proof['context_reuse']}=={'/root/v5_semantic','/root/v5_editor','/root/v5_adversary'}and all(e['actual_approved']for e in proof['context_reuse'])
assert len(record['accepted_english'])==108;assert {e['key']:e for e in record['accepted_english']}=={e['key']:e for e in parent['accepted_english']};assert all(not g['passed']and not g['evidence']for g in record['gates'].values());issues=p.audit_locale(K,m,record,'bg');assert set(issues)=={g+' is pending or lacks evidence'for g in p.GATES}
result={'result':'passed','scope':'Independent written-file binding verification only; no linguistic or rendering approval generated','total_keys':6272,'role_bindings':bindings,'fresh_complete_batches':len(scope['batches']),'actual_final_pairs_per_role':1154,'exact_parent_pairs':5118,'accepted_english_exact_parent':108,'context_approvals':3,'all9_gates_pending':True,'non_gate_core_audit_errors':[],'proof_sha256':sha(K/'review-proof-v5-validation.json'),'record_sha256':sha(K/'reviews/bg.json'),'catalog_sha256':record['catalog_sha256'],'source_sha256':m['source_sha256'],'candidate_live_registration_not_inferred':True}
(B/'review-proof-v5-independent-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
