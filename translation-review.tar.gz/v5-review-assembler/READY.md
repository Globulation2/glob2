# Actual v5 record assembled and independently validated

All three supplied final reports approve the exact1154 pairs in eight batches and the separate music-building-phase context. Source35a434; native63d5a5dd; online2e7753b0. Unaffected5118 pairs retain exact normalized v4 source/target and role identities. Existing108 English exceptions carry by exact pair, with no new exception. New source4 plus24 existing target changes are derived. Norwegian compatibility reviews are separate.

Validation-only command (default never writes):

```sh
python3 artifacts/bulgarian/v5-review-assembler/assemble.py --semantic artifacts/bulgarian/linguistics/v5-semantic-bg1154-final.json --editor artifacts/bulgarian/linguistics/v5-editor-bg1154-final.json --adversarial artifacts/bulgarian/linguistics/v5-adversarial-bg1154-final.json
python3 artifacts/bulgarian/v5-review-assembler/validate_written.py
```

The same first command with explicit `--write` already produced kit-v5/review-proof-v5-validation.json and kit-v5/reviews/bg.json from actual supplied reports. It resets runtime gates pending; do not use it to preserve later runtime-gate acknowledgments. The independent result is review-proof-v5-independent-validation.json. The BG kit audit currently has only nine pending-gate issues and zero non-gate issues. No live catalog application is inferred from candidate review approval.

Sixteen mocked mechanics tests pass. They test missing/pending reports, stale identities/catalogs/literals, coverage/duplicates, hash conventions and individual plural variants, false fresh-reading claims, exact own-review lineage, English exception carry/three-role additions, missing context approval, wrong batch membership and an actual cloned-candidate mutation outside scope. Mock files are temporary and removed; no mocked approval is published.

Use the existing publisher PREP command with both actual additional selections to retain historical evidence:

```sh
python3 artifacts/bulgarian/publish_evidence.py --native-selection /home/bradley/.codex/worktrees/5a87/glob2/artifacts/bulgarian/native-captures/v4-final/publish-selection.json --native-selection /home/bradley/.codex/worktrees/5a87/glob2/artifacts/bulgarian/native-captures/v5-final/publish-selection.json
```

This preserves old253, f02 selection168 and corrected8db selection109. Their producer identities remain historical; final runtime evidence is pending. No full PREP/inventory rerun is claimed in this assembler task while catalogs/compatibility work changes. Final publication requires the separate explicit final-evidence contract and actual supplied readiness record.

The BG4 first-draft lineage is85requests/$5.29244. Subsequent independent native compatibility supplement adds HI/UR/SW3requests/111codepoints/$0.00222, cumulative88/$5.29466, held in the active kit-v5 ledger. This does not alter the BG review pair proof. All actual provider bodies and rejected mapping evidence stay separately preserved.
