from pathlib import Path
import sys,subprocess,re,shutil,tempfile,json,hashlib
src=Path(sys.argv[1]).resolve();dst=Path(sys.argv[2]).resolve();record=Path(sys.argv[3]);assert src!=dst and src.exists();dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists()
shutil.copyfile(src,dst);dst.chmod(src.stat().st_mode)
commands=[['strip','--strip-debug',str(dst)]];subprocess.run(commands[0],check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def sections(path):
 raw=subprocess.check_output(['readelf','-SW',str(path)],text=True);result={}
 for line in raw.splitlines():
  m=re.match(r'^\s*\[\s*(\d+)\]\s+(\S+)\s+(\S+)\s+([0-9a-f]+)\s+([0-9a-f]+)\s+([0-9a-f]+)\s+([0-9a-f]+)\s+(\S+)\s+\d+\s+\d+\s+\d+\s*$',line)
  if m and 'A'in m[8]:result[m[2]]={'index':int(m[1]),'type':m[3],'address':int(m[4],16),'offset':int(m[5],16),'size':int(m[6],16),'entry_size':int(m[7],16),'flags':m[8]}
 return raw,result
before_raw,before=sections(src);after_raw,after=sections(dst);assert before and set(before)==set(after)
for name,a in before.items():
 for field in ['type','address','size','entry_size','flags']:assert a[field]==after[name][field],(name,field)
program_before=subprocess.check_output(['readelf','-lW',str(src)],text=True);program_after=subprocess.check_output(['readelf','-lW',str(dst)],text=True);assert program_before==program_after
with tempfile.TemporaryDirectory(prefix='glob2-allocated-section-proof-')as tmp:
 tmp=Path(tmp);proof=[]
 for label,binary,table in [('before',src,before),('after',dst,after)]:
  folder=tmp/label;folder.mkdir();command=['objcopy']
  for name,s in table.items():
   if s['type']!='NOBITS':command+=['--dump-section',name+'='+str(folder/f"section-{s['index']}.bin")]
  command += [str(binary),str(folder/'discard-copy.elf')];subprocess.run(command,check=True);commands.append(command)
 for name,a in before.items():
  if a['type']=='NOBITS':digest='implicit zero-initialized NOBITS, identical size/address/type'
  else:
   first=tmp/'before'/f"section-{a['index']}.bin";last=tmp/'after'/f"section-{after[name]['index']}.bin";assert first.stat().st_size==a['size'] and last.stat().st_size==a['size'];digest=sha(first);assert digest==sha(last)
  proof.append({'name':name,'type':a['type'],'address':a['address'],'size':a['size'],'flags':a['flags'],'content_sha256':digest,'identical':True})
record.parent.mkdir(parents=True,exist_ok=True);record.write_text(json.dumps({'identity':'Immutable capture copy with debug information removed; never an active SCons output. Actual capture metadata must hash this stripped file.','source':str(src),'source_sha256':sha(src),'source_bytes':src.stat().st_size,'capture_copy':str(dst),'capture_copy_sha256':sha(dst),'capture_copy_bytes':dst.stat().st_size,'strip_version':subprocess.check_output(['strip','--version'],text=True).splitlines()[0],'objcopy_version':subprocess.check_output(['objcopy','--version'],text=True).splitlines()[0],'readelf_version':subprocess.check_output(['readelf','--version'],text=True).splitlines()[0],'command':['strip','--strip-debug',str(dst)],'verification':'All SHF_ALLOC section addresses/types/sizes/flags and every file-backed section byte verified equal via readelf and objcopy dumps; full program headers/segment mapping identical. NOBITS implicit contents unchanged.','program_headers':program_before,'allocated_sections':proof,'section_headers_before':before_raw,'section_headers_after':after_raw},indent=2)+'\n');print(src.stat().st_size,dst.stat().st_size,'allocated sections identical',len(proof))
