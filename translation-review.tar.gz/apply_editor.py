import importlib.util,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('program',ROOT/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
base=ROOT/'artifacts/bulgarian'; paths=p.catalog_paths(base/'kit','bg')
native,errors=p.CHECKER.read_table(paths['native']);assert not errors
online=json.loads(paths['online'].read_text()); catalogs={'native':native,'online':online}
findings=json.loads((base/'linguistics/editor-findings.json').read_text())
conflicts=[]; applied=[]
for f in findings:
 surface=f['surface'];key=f['key'];target=catalogs[surface]; current=target[key]
 original=f.get('original',f.get('target'))
 if current==f['value']:continue
 if current!=original:
  conflicts.append(dict(f,current=current));continue
 target[key]=f['value'];applied.append(f)
paths['native'].write_text(''.join(k+'\n'+v+'\n' for k,v in native.items()))
p.write_json(paths['online'],online)
p.write_json(base/'linguistics/editor-conflicts.json',conflicts)
p.write_json(base/'linguistics/editor-applied.json',applied)
print('editor applied',len(applied),'conflicts',len(conflicts))
