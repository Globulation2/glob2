"""Curate review evidence; --publish explicitly creates/pushes the evidence branch.

Default preparation writes ignored archives/manifests only. Historical source kits
remain historical; the current checkout revision is a preparation identity, never
an assertion that an older test or review covered that revision.
"""
import argparse,base64,gzip,hashlib,json,os,re,subprocess,tarfile,tempfile,zlib
from pathlib import Path
root=Path(__file__).resolve().parents[2];base=root/'artifacts/bulgarian';out=base/'published';out.mkdir(exist_ok=True)
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--publish',action='store_true');parser.add_argument('--final-evidence',type=Path,help='Explicit final readiness/scope JSON; default remains partial PREP');parser.add_argument('--native-selection',type=Path,action='append',default=[],help='Additional existing explicit capture selection JSON, resolved against repository root');parser.add_argument('--browser-selection',type=Path,action='append',default=[],help='Explicit existing browser capture selection JSON; supports future capture directories without guessing paths');args=parser.parse_args()
DENIED={'node_modules','__pycache__','.git','dist','build','vite-cache','check-tree','syntax-shadow','probe-includes','empty-types','profiles','cache','caches','provisional','published','snapshots','sanitized','failed-prepare-kit-v6','failed-prepare-tool-shadow'}
TEXT={'.json','.md','.log','.patch','.py','.cjs','.mjs','.html','.xml','.txt','.cpp','.h','.hpp','.ts','.tsx','.css','.yaml','.yml','.sh','.exit','.diff'}
# Only high-confidence credential encodings are rejected: source examples such as
# "Authorization: Bearer <token>" are harmless documentation, not credentials.
SECRETS=[re.compile(rb'ya29\.[A-Za-z0-9_-]{16,}'),re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(rb'Bearer[ \t]+eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+'),re.compile(rb'AIza[A-Za-z0-9_-]{35}'),re.compile(rb'"(?:access_token|refresh_token|client_secret|private_key|authorization)"\s*:\s*"[^"\n]{20,}"')]
archive_members={};files={};scanned={};sanitized={};omitted_images=[]
prepared_inputs={}
PROVIDER_KITS=('kit','kit-v2','kit-v3','kit-v3-native-compat','kit-v3-native-compat-v2','kit-v4','kit-v5','kit-v5-native-compat','terrain-supplement-v5','kit-v6','kit-v7','kit-v8','platform-companion-v8','telugu-compat-v8','filipino-compat-v8')
IMPLEMENTATION_DIRS=('native-error-bridge','comprehensive-error-surfaces','legacy-native-drafting','legacy-native-drafting-v2','script-editor-preview','statistics-preview','chart-status-wrap','script-status-wrap','integration-027a','browser-unit-master-80596','sgsl-bg-compatibility','malay-integration','merge-malay-frontend','ci-selector-fix','master-1801-integration','browser-unit-master-ffabe','master-mr-ta-integration','master-telugu-integration','master-filipino-integration')
CAPTURE_DIRS=('final-online-qa','native-captures','browser-captures','final-web-preview-qa','extended-online-qa','final-v6-online-qa','final-v7-online-qa','final-v8-online-qa','after-postvisual-33','after-credit-fix')
MAX_SCAN_BYTES=256_000_000
def is_provider_response(p):
 try:parts=p.relative_to(base).parts
 except ValueError:return False
 if not parts or parts[0]not in PROVIDER_KITS:return False
 regular=len(parts)==5 and parts[1]=='machine'and parts[3]=='raw'
 rejected=len(parts)==6 and parts[1:5]==('rejected','wrong-br-breton-mapping','provider-history','raw')
 return (regular or rejected)and re.fullmatch(r'[0-9a-f]{64}-[0-9]{6}\.response\.bin',parts[-1])is not None
def provider_content(data,label):
 # Raw response files are HTTP bodies. Preserve stored bytes, but inspect and
 # boundedly decode supported compression before scanning the textual body.
 if data.startswith(b'\x1f\x8b'):decoder=zlib.decompressobj(16+zlib.MAX_WBITS)
 elif len(data)>1 and data[0]==0x78 and (data[0]*256+data[1])%31==0:decoder=zlib.decompressobj()
 else:decoder=None
 if decoder:
  content=decoder.decompress(data,MAX_SCAN_BYTES+1)
  if len(content)>MAX_SCAN_BYTES or decoder.unconsumed_tail:raise ValueError('Provider response exceeds scan bound: '+label)
  if not decoder.eof or decoder.unused_data:raise ValueError('Incomplete/trailing compressed provider response: '+label)
 else:content=data
 if len(content)>MAX_SCAN_BYTES:raise ValueError('Provider response exceeds scan bound: '+label)
 try:content.decode('utf-8')
 except UnicodeDecodeError:raise ValueError('Unsupported binary provider response encoding: '+label)from None
 if b'\x00'in content:raise ValueError('Non-text provider response: '+label)
 return content
def browser_capture_files(folder):
 return [p for p in folder.rglob('*')if p.is_file()and not p.is_symlink()and (p.suffix in {'.png','.jpg','.json','.md','.xml','.mjs','.log','.exit','.txt','.py'}or p.name.endswith('.json.gz'))and not any(x in DENIED for x in p.relative_to(folder).parts)]
def prepared_browser_source_files(folder):
 if not folder.is_dir():return []
 return [p for p in sorted(folder.iterdir())if p.is_file()and not p.is_symlink()and (p.suffix in {'.py','.cjs','.mjs','.md'}or p.name=='preparation.json')]
def implementation_directories():
 return [base/name for name in IMPLEMENTATION_DIRS]+sorted(base.glob('v*-font-supplement-input'))+sorted(base.glob('native-v*-qa'))
def selected_capture_paths(folder,choices):
 # Selection JSON is itself frozen before parsing; the archive and path inventory
 # use exactly that scanned selection even if a producer later appends to it.
 candidates=[]
 for choice in choices:
  choice=choice if choice.is_absolute()else root/choice
  item=json.loads(validate(choice).read_text());labels=item.get('paths')if isinstance(item,dict)else item
  if not isinstance(labels,list)or any(not isinstance(label,str)for label in labels):raise ValueError('Capture selection must contain a paths list')
  for label in labels:
   candidate=root/label if label.startswith('artifacts/')else folder/label
   if not candidate.resolve().is_relative_to(base.resolve()):raise ValueError('Capture selection escapes evidence root')
   candidates.append(candidate)
  candidates.append(choice)
 return candidates
def strip_embedded_images(value, location, path=""):
 if isinstance(value,dict):
  result={k:strip_embedded_images(v,location,path+"/"+str(k)) for k,v in value.items() if k!="body"}
  if "body" not in value:return result
  body=value["body"];mime=value.get("contentType","")
  if isinstance(body,str) and mime in ("image/png","image/jpeg","image/webp"):
   decoded=base64.b64decode(body,validate=True)
   valid=(mime=="image/png" and decoded.startswith(bytes.fromhex("89504e470d0a1a0a"))) or (mime=="image/jpeg" and decoded.startswith(bytes.fromhex("ffd8ff"))) or (mime=="image/webp" and decoded[:4]==b"RIFF" and decoded[8:12]==b"WEBP")
   if not valid:raise ValueError("Invalid embedded image metadata: "+location+path)
   proof={"source":location,"json_pointer":path+"/body","content_type":mime,"bytes":len(decoded),"sha256":hashlib.sha256(decoded).hexdigest()}
   omitted_images.append(proof);result["omitted_embedded_image"]=proof
  else:result["body"]=strip_embedded_images(body,location,path+"/body")
  return result
 if isinstance(value,list):return [strip_embedded_images(v,location,path+"/"+str(i)) for i,v in enumerate(value)]
 return value
def validate(p):
 if not p.is_file() or p.is_symlink():raise ValueError('Missing/nonregular evidence: '+str(p))
 if not p.resolve().is_relative_to(base.resolve()):raise ValueError('Evidence escapes root: '+str(p))
 if any(x in DENIED for x in p.relative_to(base).parts):raise ValueError('Excluded build/cache path: '+str(p))
 label=str(p.relative_to(base))
 if label in prepared_inputs:return prepared_inputs[label]
 provider=is_provider_response(p)
 if p.suffix=='.bin'and not provider:raise ValueError('Unrecognized binary evidence: '+label)
 data=p.read_bytes();original_sha=hashlib.sha256(data).hexdigest();is_gz=p.name.endswith('.json.gz')
 content=provider_content(data,label)if provider else(gzip.decompress(data)if is_gz else data)
 if len(content)>256_000_000:raise ValueError('Uncompressed evidence exceeds bounded scan size: '+label)
 if p.suffix=='.json' or is_gz:
  parsed=json.loads(content);before=len(omitted_images);parsed=strip_embedded_images(parsed,label)
  if len(omitted_images)>before:
   content=(json.dumps(parsed,ensure_ascii=False,indent=2)+'\n').encode()
   data=gzip.compress(content,compresslevel=9,mtime=0) if is_gz else content
   sanitized[label]={'original_sha256':original_sha,'published_sha256':hashlib.sha256(data).hexdigest(),'omitted_embedded_images':len(omitted_images)-before}
 if p.suffix in TEXT or p.suffix in {'.jsonl',''} or is_gz or provider:
  for pattern_index,pattern in enumerate(SECRETS):
   for match in pattern.finditer(content):
    # This exact producer-authorship note is not an HTTP credential. Preserve
    # its original hash-bound bytes; every other authorization value is scanned.
    approval_note=(pattern_index==4 and label=='native-v11-qa/binary-handoff.json' and hashlib.sha256(match.group(0)).hexdigest()=='323fc686749e9ac8c15c131d53daa69e27f820f95120700437ad73ba3b6e6c9c')
    if not approval_note:raise ValueError('Possible secret in '+str(p)+' (value deliberately withheld)')
 digest=hashlib.sha256(data).hexdigest()
 # Freeze exactly the bytes that passed scanning. Never let tar or publication
 # reopen a growing log/source file; cached inputs retain this first read.
 target=out/'snapshots'/digest[:2]/digest;target.parent.mkdir(parents=True,exist_ok=True)
 try:
  with target.open('xb') as frozen:frozen.write(data)
  target.chmod(0o444)
 except FileExistsError:
  if target.read_bytes()!=data:raise ValueError('Content-addressed snapshot differs: '+label)
 scanned[label]={'bytes':len(data),'sha256':digest}
 prepared_inputs[label]=target
 return target

def collect(folder,stage=False):
 if not folder.exists():return []
 result=[]
 for p in sorted(folder.rglob('*')):
  rel=p.relative_to(folder)
  if any(x in DENIED for x in rel.parts) or not p.is_file() or p.is_symlink():continue
  if 'stage' in rel.parts and not stage:continue
  if p.suffix in TEXT or p.suffix=='.jsonl'or is_provider_response(p):result.append(p)
 return result
def archive(name,paths):
 members={str(p.relative_to(base)):p for p in paths};target=out/name
 with tarfile.open(target,'w:gz',compresslevel=9) as tar:
  for label,p in sorted(members.items()):
   safe=validate(p);tar.add(safe,arcname=label,recursive=False)
 archive_members[name]={k:scanned[k] for k in sorted(members)};files[name]=target
final_summary=None
if args.final_evidence:
 import importlib.util
 from final_evidence_contract import validate_final_evidence,REQUIRED_GATES
 specification=importlib.util.spec_from_file_location('publication_translation_program',root/'tools/localization/translation_program.py');program=importlib.util.module_from_spec(specification);specification.loader.exec_module(program)
 if tuple(program.GATES)!=REQUIRED_GATES:raise ValueError('Final-evidence gate contract differs from translation-program audit')
 final_path=args.final_evidence if args.final_evidence.is_absolute()else root/args.final_evidence
 requested=json.loads(validate(final_path).read_text());requested_review=requested.get('review_record',{}).get('path')
 if not isinstance(requested_review,str)or Path(requested_review).is_absolute()or '..'in Path(requested_review).parts:raise ValueError('Final evidence requires an evidence-root relative review_record path')
 review_path=base/requested_review
 if review_path.name!='bg.json'or review_path.parent.name!='reviews':raise ValueError('Final evidence requires a Bulgarian reviews/bg.json record')
 kit_path=review_path.parent.parent;manifest_data=json.loads(validate(kit_path/'manifest.json').read_text());review_snapshot=validate(review_path);review_data=json.loads(review_snapshot.read_text())
 if program.sources(root)[4]!=manifest_data['source_sha256']:raise ValueError('Final evidence source kit differs from current live source contracts')
 catalogs=program.catalog_paths(kit_path,'bg');catalog_hashes={surface:hashlib.sha256(validate(path).read_bytes()).hexdigest()for surface,path in catalogs.items()}
 context={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_sha256':manifest_data['source_sha256'],'catalog_sha256':catalog_hashes,'review_record':review_data,'review_record_ref':{'path':str(review_path.relative_to(base)),'sha256':hashlib.sha256(review_snapshot.read_bytes()).hexdigest()},'review_evidence_root':kit_path,'audit_issues':program.audit_locale(kit_path,manifest_data,review_data,'bg')}
 if catalog_hashes!={'native':hashlib.sha256((root/'data/texts.bg.txt').read_bytes()).hexdigest(),'online':hashlib.sha256((root/'platform/packages/i18n/locales/bg.json').read_bytes()).hexdigest()}:raise ValueError('Final evidence catalog kit differs from actual registered Bulgarian catalogs')
 final_summary=validate_final_evidence(final_path,base,context,validate)
 files[str(final_path.relative_to(base))]=validate(final_path)
 # Explicit report references join publication even if outside prior selections.
 for ref in json.loads(validate(final_path).read_text())['reports']:files[ref['path']]=validate(base/ref['path'])
review=[]
for name in ('kit','kit-v2','kit-v3','kit-v4','kit-v5','kit-v5-native-compat','terrain-supplement-v5','v5-review-assembler','v6-review-assembler','v7-review-assembler','v8-review-assembler','gate-finalization-v8','v8-telugu-review-assembler','v8-filipino-review-assembler','filipino-compat-v8','visual-refinement-v8','telugu-compat-v8','platform-companion-v8','my-colony-context','kit-v6','kit-v7','kit-v8','merge-bengali-tooling','merge-malay-tooling','kit-v3-native-compat-v2','linguistics','native-compat-reviews','source-expansion-v1','visual-refinement-v1','visual-refinement-v4','publication-schema-normalization','source-stage-v3','compat-provider-logs','compat-provider-logs-attempt1','compat-provider-logs-attempt2'):
 review+=collect(base/name)
# Retain the original legacy attempt history as well as corrected/current copies.
review+=collect(base/'kit-v3-native-compat'/'machine')
# Complete new compatibility kit contains the cumulative ledger, all historical
# raw requests/responses (including failed wrong-br), and explicit quarantine.
review += [p for p in base.iterdir() if p.is_file() and p.suffix in {'.json','.md','.py','.patch','.txt'}]
archive('translation-review.tar.gz',review)
source=[]
for folder in implementation_directories():
 source+=collect(folder,stage=folder.name in {'comprehensive-error-surfaces','legacy-native-drafting','legacy-native-drafting-v2'})
for folder in sorted(base.glob('browser-final-v*')):
 source += prepared_browser_source_files(folder)
source += sorted((base/'native-captures').glob('v*-final/font-carryforward.json'))
archive('implementation-review.tar.gz',source)
logs=list(base.glob('*.log'))
for folder in base.glob('native-tests*'):
 if folder.is_dir():logs += [p for p in collect(folder) if p.suffix in {'.log','.json','.xml','.txt'}]
archive('verification-logs.tar.gz',logs)
large=[]
for name in CAPTURE_DIRS:
 folder=base/name
 if not folder.exists():continue
 if name=='native-captures':
  candidates=selected_capture_paths(folder,[folder/'publish-selection.json',*args.native_selection])
 else:
  candidates=browser_capture_files(folder)
 for p in sorted(set(candidates)):
  safe=validate(p);label=str(p.relative_to(base))
  if p.suffix in {'.json','.log'} and safe.stat().st_size>1_000_000:large.append(p)
  else:files[label]=safe
# Additional browser selections are opt-in, concrete existing files. No future
# directory or result is synthesized, and captured bodies remain frozen/scanned.
for p in sorted(set(selected_capture_paths(base,args.browser_selection))):
 safe=validate(p);label=str(p.relative_to(base))
 if p.suffix in {'.json','.log'}and safe.stat().st_size>1_000_000:large.append(p)
 else:files[label]=safe
if large:archive('render-diagnostics.tar.gz',large)
readme=out/'README.md';readme.write_text('''# Bulgarian localization evidence (preparation snapshot)

This is a curated partial preparation snapshot while final builds run. Active logs are frozen at their first read and may be incomplete. Historical review proofs and the actual V6 source-expansion proofs and independent binding validations are included. V6 covers 6,377 BG keys; its runtime/platform gates remain pending until actual final evidence is supplied. Actual f02 font/API/UI component results are preserved as before-fix evidence. Corrective chart/script sources and regressions are included; their post-fix runtime captures and gate binding remain pending. Historical files retain their own source/catalog identities; the preparation revision does not rebind an older check.

- `translation-review.tar.gz`: frozen translation kits, raw provider requests/responses and cumulative spend ledger, rejected mapping evidence, role reviews and binding proofs.
- `implementation-review.tar.gz`: reviewed implementation patches, staged source/test inputs and focused syntax/probe evidence.
- `verification-logs.tar.gz`: bounded check/build logs, inventories, JUnit results.
- `render-diagnostics.tar.gz`: large lossless diagnostics from explicitly curated captures.
- Native and browser screenshots and concise QA reports remain directly browseable.
- `frozen-inputs.json` binds every original input label to its immutable scanned snapshot.
- `archive-members.json` lists every archive member with size and SHA-256; `manifest.json` binds publication files.
- `embedded-image-omissions.json` records metadata/hashes for duplicate screenshot bodies removed from JSON reports. Original local evidence remains unchanged.

No binaries, dependency trees, build outputs, synthetic account profiles, caches, or provisional online reports are included. Language reviews are agent reviews, not native-human certification. Untested platform/rendering gates remain pending.
''');files[readme.name]=readme
redaction=out/'embedded-image-omissions.json';redaction.write_text(json.dumps({'reason':'Duplicate binary screenshots are represented by metadata and hashes; separately curated images remain available.','derived_files':sanitized,'omissions':omitted_images},indent=2)+'\n');files[redaction.name]=redaction
readiness=out/'curation-readiness.json'
historical_kit=base/'kit-v4';km=json.loads((historical_kit/'manifest.json').read_text());active_kit=(root/validate(base/'active-machine-kit.txt').read_text().strip()).resolve();active_ledger_path=active_kit/'machine/spend-ledger.json';ledger=json.loads(validate(active_ledger_path).read_text());active_manifest=json.loads(validate(active_kit/'manifest.json').read_text());active_record_path=active_kit/'reviews/bg.json';active_record=validate(active_record_path)
from decimal import Decimal
selection=json.loads(validate(base/'native-captures/publish-selection.json').read_text());selection=selection['paths'] if isinstance(selection,dict) else selection
readiness.write_text(json.dumps({'status':'Preparation only, not publication approval','v4_source_sha256':km['source_sha256'],'v4_native_keys':km['native_keys'],'v4_online_keys':km['online_keys'],'v4_current_native_draft_sha256':hashlib.sha256(validate(historical_kit/'drafts/bg/texts.bg.txt').read_bytes()).hexdigest(),'active_kit':str(active_kit.relative_to(base)),'active_source_sha256':active_manifest['source_sha256'],'active_native_keys':active_manifest['native_keys'],'active_online_keys':active_manifest['online_keys'],'active_review_record_sha256':hashlib.sha256(active_record.read_bytes()).hexdigest(),'cumulative_ledger_input':str(active_ledger_path.relative_to(base)),'cumulative_ledger_sha256':scanned[str(active_ledger_path.relative_to(base))]['sha256'],'ledger_reservations':len(ledger['reservations']),'reserved_usd':str(sum((Decimal(r['reserved_usd']) for r in ledger['reservations']),Decimal())),'primary_native_selection_entries':len(selection),'additional_native_selection_inputs':[str(choice)for choice in args.native_selection],'additional_browser_selection_inputs':[str(choice)for choice in args.browser_selection],'actual_v4_role_reports':[str(p.relative_to(base)) for p in sorted((base/'linguistics').glob('*v4*.json'))],'actual_v4_proof_reports':[p.name for p in sorted(base.glob('*proof*v4*.json'))],'pending_categories':['Final native/browser capture and platform gate binding','Explicit additional capture selection supplied with --native-selection or incorporated into primary selection'],'future_paths_invented':False},indent=2)+'\n');files[readiness.name]=readiness
# Compare actual raw response files against selected/scanned archive members;
# a cache index or copied ledger alone cannot prove raw-history completeness.
raw_provider_files=sorted(p for kit in sorted(set(base.glob('kit*'))|{base/'terrain-supplement-v5'})if kit.is_dir()for p in kit.rglob('*.response.bin'))
provider_rows=[]
for p in raw_provider_files:
 label=str(p.relative_to(base))
 if not is_provider_response(p):raise ValueError('Unrecognized actual provider response path: '+label)
 if label not in scanned:raise ValueError('Actual provider response was not selected: '+label)
 data=p.read_bytes()
 if scanned[label]!={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}:raise ValueError('Provider response changed after freezing: '+label)
 locations=[{'archive':name,'member':label}for name,members in archive_members.items()if label in members]
 if not locations:raise ValueError('Provider response absent from archives: '+label)
 provider_rows.append({'path':label,**scanned[label],'archives':locations,'stored_encoding':'gzip'if data.startswith(b'\x1f\x8b')else'zlib'if len(data)>1 and data[0]==0x78 and (data[0]*256+data[1])%31==0 else'UTF-8 text'})
provider_report=out/'provider-raw-coverage.json'
provider_report.write_text(json.dumps({'result':'passed','actual_files':len(provider_rows),'selected_files':len(provider_rows),'unique_raw_body_sha256':len({row['sha256']for row in provider_rows}),'by_kit':{kit:sum(row['path'].split('/')[0]==kit for row in provider_rows)for kit in PROVIDER_KITS},'fa_it_raw_copies':sum(any(part in ('fa','it')for part in Path(row['path']).parts)for row in provider_rows),'rejected_wrong_br_copies':sum('rejected'in Path(row['path']).parts for row in provider_rows),'files':provider_rows},indent=2)+'\n');files[provider_report.name]=provider_report
snapshot_index=out/'frozen-inputs.json'
snapshot_index.write_text(json.dumps({'scope':'First scanned bytes of each selected input; active build logs may be partial. Sources can change after preparation without changing these publication bytes.','snapshot_storage':'Local ignored publisher storage; publication_locations identify the uploaded file or archive member.','inputs':{label:{**scanned[label],'snapshot':str(path.relative_to(out)),'publication_locations':([{'path':label}]if label in files else[])+[{'archive':name,'member':label}for name,members in archive_members.items()if label in members]}for label,path in sorted(prepared_inputs.items())}},indent=2)+'\n');files[snapshot_index.name]=snapshot_index
# Archive inventories bind every expanded member, allowing reviewers to find a
# particular proof/raw response without guessing archive contents.
index=out/'archive-members.json';index.write_text(json.dumps(archive_members,indent=2,sort_keys=True)+'\n');files[index.name]=index
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
if final_summary:
 if revision!=context['revision']:raise ValueError('Revision changed during final evidence preparation')
 final_file=out/'final-verification-scope.json';final_file.write_text(json.dumps(final_summary,indent=2)+'\n');files[final_file.name]=final_file
 current_readiness=json.loads(readiness.read_text());current_readiness.update(status='Final evidence for the declared verification scope; unavailable coverage remains unpassed',publication_ready=True,pending_categories=[],final_verification_scope=final_summary);readiness.write_text(json.dumps(current_readiness,indent=2)+'\n')
 title='Final full-audit evidence'if final_summary['full_audit_passed']else'Final scoped verification evidence'
 lines=['# '+title,'',final_summary['scope'],'','Full nine-gate audit: '+('passed.'if final_summary['full_audit_passed']else'incomplete; explicitly unavailable gates remain unpassed.'),'','Verified scope and coverage:']
 lines += ['- '+item['id']+': '+item['status']+' — '+item['scope']+(' Reason: '+item['reason']if item.get('reason')else'')for item in final_summary['coverage']]
 lines += ['','Limits:']+['- '+limit for limit in final_summary['limits']]+['- Agent-reviewed; no native-human certification.','','All referenced reports are frozen and hash-bound. Historical before results retain their original producer identities. Complete scope, gate statuses, retained audit issues and exact readiness input appear in final-verification-scope.json. Archive/member indexes and raw-provider coverage reports remain available.']
 readme.write_text('\n'.join(lines)+'\n')
manifest={'schema_version':2,'prepared_at_revision':revision,'status':'Prepared only; historical evidence retains its own source bindings. Final integrated runtime publication and gate binding are pending.','secret_scan':{'result':'passed','scope':'All selected textual evidence, including decompressed JSON.gz; encoded image payloads replaced with verified metadata before scan','patterns':'Google OAuth/API keys, JWT bearer tokens, private keys; no secret values logged'},'archive_members_index':'archive-members.json','frozen_input_index':'frozen-inputs.json','active_build_logs':'Partial snapshots of the first bytes read; no successful final build status is inferred','sanitized_files':len(sanitized),'embedded_image_omissions':len(omitted_images),'publication_ready':False,'pending_categories':['Final incremental native/browser runtime captures and gate binding','Updated explicit native publish-selection after final supplemental captures'],'files':{name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(files.items())}}
if final_summary:
 manifest.update(status='Final evidence for the declared verification scope',publication_ready=True,pending_categories=[],final_verification_scope=final_summary,full_audit_passed=final_summary['full_audit_passed'],active_build_logs='Historical and before-fix logs retain their own identities; only declared final report scope is verified')
mp=out/'manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');files[mp.name]=mp
assert all(p.stat().st_size<95_000_000 for p in files.values()),'Split oversized evidence files before publishing'
print(json.dumps({'revision':revision,'publication_files':len(files),'archived_members':sum(map(len,archive_members.values())),'bytes':sum(p.stat().st_size for p in files.values()),'manifest':str(mp),'published':False}))
if not args.publish:raise SystemExit(0)
with tempfile.TemporaryDirectory(prefix='bulgarian-evidence-index-') as temp:
 env=dict(os.environ,GIT_INDEX_FILE=str(Path(temp)/'index'))
 def git(*argv,input=None):return subprocess.check_output(['git',*argv],cwd=root,env=env,input=input,text=True).strip()
 git('read-tree','--empty')
 for name,p in files.items():
  blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo','100644',blob,name)
 tree=git('write-tree');branch='refs/heads/codex/bulgarian-localization-evidence'
 previous=subprocess.run(['git','rev-parse','--verify',branch],cwd=root,capture_output=True,text=True)
 parents=['-p',previous.stdout.strip()] if previous.returncode==0 else []
 commit=git('commit-tree',tree,*parents,input='Bulgarian localization review and verification evidence\n')
 git('update-ref',branch,commit);print(commit,len(files),'evidence files')
 subprocess.run(['git','push','origin',branch],cwd=root,check=True)
