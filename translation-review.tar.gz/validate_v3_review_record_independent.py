from pathlib import Path
import json,hashlib
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'kit-v3';O=B/'kit-v2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());m=read(K/'manifest.json');om=read(O/'manifest.json');record=read(K/'reviews/bg.json');proof=read(B/'review-proof-v3-validation.json');oldrecord=read(O/'reviews/bg.json');delta=read(K/'batch-content-delta.json');changed={b['id']for b in delta['changed_content_batches']};fresh={i for b in m['batches']if b['id']in changed for i in b['keys']};assert len(changed)==2 and len(fresh)==73 and len(delta['unchanged_content_batches'])==41
import importlib.util
sp=importlib.util.spec_from_file_location('p',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);src={x:read(K/'source'/f'{x}.json')for x in ['native','online']};osrc={x:read(O/'source'/f'{x}.json')for x in src};tgt={'native':p.CHECKER.read_table(K/'drafts/bg/texts.bg.txt')[0],'online':read(K/'drafts/bg/bg.json')};otgt={'native':p.CHECKER.read_table(O/'drafts/bg/texts.bg.txt')[0],'online':read(O/'drafts/bg/bg.json')};oldb={b['id']:b for b in om['batches']}
for batch in m['batches']:
 if batch['id'] not in changed:
  assert batch['keys']==oldb[batch['id']]['keys']
  for i in batch['keys']:
   s,k=i.split(':',1);assert src[s][k]==osrc[s][k] and tgt[s][k]==otgt[s][k]
for surface in src:
 unchanged=sum(src[surface].get(k)==v and tgt[surface].get(k)==otgt[surface][k]for k,v in osrc[surface].items());assert unchanged==({'native':3389,'online':2843}[surface])
roles=[]
for role,name in [('semantic','semantic-v3-final-batches.json'),('editor','editor-v3-final-batches.json'),('adversarial','adversarial-v3-final-recheck.json')]:
 path=B/'linguistics'/name;d=read(path);entries=d['entries'];assert len(entries)==73 and {e['surface']+':'+e['key']for e in entries}==fresh;assert not d.get('findings',[]) and not d.get('unresolved_findings',[])
 for e in entries:
  assert e['source']==src[e['surface']][e['key']] and e['target']==tgt[e['surface']][e['key']];assert e['decision']in ['acceptable','approved','accept']
  for field in ['source','target']:
   text=json.dumps(e[field],ensure_ascii=False,sort_keys=True,separators=(',',':'))if role=='editor'else e[field];assert hashlib.sha256(text.encode()).hexdigest()==e[field+'_sha256']
 if role=='adversarial':
  prior=R/d['prior_report'];assert sha(prior)==d['prior_report_sha256'];before={e['surface']+':'+e['key']:e for e in read(prior)['entries']};carried=[e for e in entries if e['review_method'].startswith('Exact unchanged')];assert len(carried)==69
  for e in carried:
   q=before[e['surface']+':'+e['key']];assert e['source']==q['source']and e['target']==q['target']
  assert len(entries)-len(carried)==4
 roles.append({'role':role,'file':str(path.relative_to(B)),'sha256':sha(path),'exact_final_pairs':73,'fresh_claim':'73 actual readings'if role!='adversarial'else'Prior73 actual readings plus4 fresh final rereads;69 exact own-review carryforward'})
assert all(not g['passed']for g in record['gates'].values());assert record['source_sha256']==m['source_sha256'];assert proof['bindings']==3*6254;assert record['review_proof']['sha256']==sha(B/'review-proof-v3-validation.json');assert sha(O/'reviews/bg.json')==proof['parent_record']['sha256'];assert sha(B/'review-proof-validation.json')==proof['parent_proof']['sha256']
oldids={r['id']:r for r in oldrecord['batches']}
for b in record['batches']:
 for identity in ['author','reviewer','editor','adversarial_reviewer']:assert b[identity]==oldids[b['id']][identity]
 assert len({b[x]for x in ['author','reviewer','editor','adversarial_reviewer']})==4
out={'validator':'/root/draft_tooling','scope':'Independent source/evidence binding validation, not a new corpus linguistic review','result':'passed','unchanged_batches_exact':41,'changed_batches':2,'fresh_batch_entry_bindings_per_role':73,'independent_role_records':roles,'adversarial_final69_own_review_carryforward_and4_rereads_verified':True,'total_keys':6254,'bindings':18762,'all9_gates_pending':True,'no_approval_generated_by_validation':True,'proof_sha256':sha(B/'review-proof-v3-validation.json'),'record_sha256':sha(K/'reviews/bg.json')};(B/'review-proof-v3-independent-validation.json').write_text(json.dumps(out,indent=2)+'\n');print('v3 independent binding validation passed:41 unchanged batches,73 final pairs×3,adversarial69+4,all9 gates pending')
