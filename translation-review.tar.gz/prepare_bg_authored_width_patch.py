from pathlib import Path
import json,difflib
out=[]
p=Path('libgag/src/TrueTypeFont.cpp');old=p.read_text();new=old.replace('''		// New locales opt into authored advances; preserve the existing Latin
		// geometry for legacy locales. Swahili uses the original Latin font,
		// not the script-font/bidi composition path.
		data.authoredDrawWidth = scripts || std::string(SDL_GetStringProperty(
			TTF_GetFontProperties(font), "glob2.script-language", "")) == "sw";''','''		// New locales opt into authored advances; preserve existing geometry
		// for legacy locales. Swahili and Bulgarian use the primary font,
		// not the script-font/bidi composition path.
		const std::string language = SDL_GetStringProperty(
			TTF_GetFontProperties(font), "glob2.script-language", "");
		data.authoredDrawWidth = scripts || language == "sw" || language == "bg";''');assert old!=new;out.append(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+str(p),tofile='b/'+str(p))))
findings=json.loads(Path('artifacts/bulgarian/native-captures/matrix-desktop-20x2-overflow-findings.json').read_text())['findings'];literals='\n'.join('\t\t\t'+json.dumps(x['line']['text'],ensure_ascii=False)+',' for x in findings)
case='''
	TEST_CASE("Bulgarian scaled advances fit authored wrapping and locale switches preserve legacy geometry")
	{
		TtfScope ttf;
		glob2test::ToolkitScope toolkit;
		glob2test::TempDir files("bg-authored-advance");
		GAGCore::Toolkit::getFileManager()->addDir(glob2test::sourceRoot().string());
		GAGCore::Toolkit::getFileManager()->addDir(files.path.string());
		std::ofstream(files.path / "probe.keys.txt") << "[language-code]\\n";
		std::ofstream listing(files.path / "probe.list.txt");
		listing << "probe.keys.txt\\n";
		for (const char *code : {"en", "bg", "ru"}) {
			listing << "probe." << code << ".txt\\n";
			std::ofstream(files.path / (std::string("probe.") + code + ".txt")) << "[language-code]\\n" << code << '\\n';
		}
		listing.close();
		auto *strings = GAGCore::Toolkit::getStringTable();
		REQUIRE(strings->load("probe.list.txt"));
		TrueTypeFont font("data/fonts/sans.ttf", 20);
		// Exact lines clipped by 1--6.5 logical pixels in the 1280px matrix at2x.
		// Their 40px hinted rasters expand by 14--18.5 logical pixels after /2.
		const char *lines[] = {
__LINES__
		};
		for (const auto *text : lines) {
			CAPTURE(text);
			strings->setLang(strings->getLangCode("en"));
			const int authored = font.getStringWidth(text);
			REQUIRE(authored > 0);
			REQUIRE(authored <= 1256);
			auto reference = font.rasterizeString(text, 2.f);
			REQUIRE(reference);
			// Use one font object and the same text across repeated language
			// switches, so stale per-raster width policy cannot hide in its cache.
			for (const char *code : {"bg", "en", "bg", "ru", "bg"}) {
				CAPTURE(code);
				strings->setLang(strings->getLangCode(code));
				const auto drawn = font.getStringDrawSize(text, 2.f);
				CHECK(font.getStringWidth(text) == authored);
				if (std::string(code) == "bg") CHECK(drawn.first <= 1256.f);
				CHECK(drawn.first == doctest::Approx(std::string(code) == "bg"
					? float(authored) : reference->getW() / 2.f));
				auto raster = font.rasterizeString(text, 2.f);
				REQUIRE(raster);
				CHECK(samePixels(reference->getSDLSurface(), raster->getSDLSurface()));
			}
		}
		// The policy follows locale, not script detection or a special-cased
		// Bulgarian string: existing English and Russian geometry stays raw.
		for (const char *code : {"en", "ru"}) {
			strings->setLang(strings->getLangCode(code));
			for (const char *text : {"You can leave the match or reduce the graphics settings and keep waiting.",
				"Вы можете покинуть матч или снизить настройки графики и продолжить ожидание."}) {
				auto raster = font.rasterizeString(text, 2.f);
				REQUIRE(raster);
				CHECK(font.getStringDrawSize(text, 2.f).first == doctest::Approx(raster->getW() / 2.f));
			}
		}
	}
'''.replace('__LINES__',literals).replace('at2x','at 2x').replace('Their40px','Their 40px').replace('were14','were 14').replace('authored20px','authored 20px')
p=Path('libgag/src/FontKerningTest.cpp');old=p.read_text();needle='\n\tTEST_CASE("script fonts shape clusters and preserve measured raster sizes after reload")';assert needle in old;new=old.replace(needle,case+needle,1);out.append(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+str(p),tofile='b/'+str(p))))
Path('artifacts/bulgarian/native-bg-authored-width.patch').write_text(''.join(out))
