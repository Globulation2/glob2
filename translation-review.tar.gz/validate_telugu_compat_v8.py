from pathlib import Path
from decimal import Decimal
import hashlib,importlib.util,json,shutil
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'telugu-compat-v8';P=B/'kit-v8';S=B/'telugu-compat-v8-tool-shadow';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pre=load(K/'preflight.json');spec=importlib.util.spec_from_file_location('tecompat',S/'tools/localization/translation_program.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);manifest=load(K/'manifest.json');assert m.sources()[4]==m.sources(R)[4]==manifest['source_sha256'];ledger=load(K/'machine/spend-ledger.json');assert len(ledger['reservations'])==97 and ledger['reservations'][:96]==load(P/'machine/spend-ledger.json')['reservations'];spent=sum((Decimal(r['reserved_usd'])for r in ledger['reservations']),Decimal());assert str(spent)==pre['expected_total_usd']
for rel,h in pre['prior_machine_sha256'].items():
 if rel!='spend-ledger.json':assert sha(K/'machine'/rel)==h,rel
paths=m.catalog_paths(K,'te');n,e=m.CHECKER.read_table(paths['native']);assert not e;obj=load(paths['online']);baseline=K/'baselines/te/texts.te.txt';old,e=m.CHECKER.read_table(baseline);assert not e and all(n[k]==v for k,v in old.items());missing=[e['key']for e in pre['entries']];assert set(n)-set(old)==set(missing);paths['native'].write_bytes(baseline.read_bytes()+''.join(k+'\n'+n[k]+'\n'for k in missing).encode());assert obj==load(K/'baselines/te/te.json');provider=load(K/'machine/te/provider-drafts.json');membership={i:b['id']for b in manifest['batches']for i in b['keys']};rows=[]
for e in pre['entries']:
 row=e.copy();source=e['source'];target=n[e['key']];assert target.strip()and target!=source;protected,replacements=m.protect_text(source,[]);pr=provider[json.dumps(['native',e['key'],''],ensure_ascii=False)];assert pr['source']==source and pr['translation']==target
 for token in set(replacements.values()):assert source.count(token)==target.count(token)
 req=next((K/'machine/te/raw').glob(pr['request_sha256']+'-*.request.json'));request=load(req);raw=req.with_name(req.name.replace('.request.json','.response.bin'));body=load(raw);payload=request['payload'];assert payload['targetLanguageCode']=='te'and payload['sourceLanguageCode']=='en'and payload['mimeType']=='text/plain'and payload['model']=='projects/bradley-personal-20261027/locations/global/models/general/nmt';assert len(payload['contents'])==len(body['translations'])==18;idx=payload['contents'].index(protected);assert m.restore_text(body['translations'][idx]['translatedText'],replacements)==target
 row.update(target=target,batch_id=membership[e['id']],source_sha256=m.digest(source.encode()),target_sha256=m.digest(target.encode()),request_sha256=pr['request_sha256'],raw_provider_path=str(raw.relative_to(B)),raw_provider_sha256=sha(raw),approval=None);rows.append(row)
checked=m.check_draft(K,'te');assert not checked['errors']and not checked['untranslated'];raw=list((K/'machine').rglob('*.response.bin'));assert len(raw)==97
for p in raw:
 request,num=p.name.removesuffix('.response.bin').rsplit('-',1);assert ledger['reservations'][int(num)-1]['request_sha256']==request
for surface,p in paths.items():
 q=K/'provider-drafts/te'/p.name;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.copy2(p,q)
refs={}
for locale in ('mr','ta'):
 q=P/f'{locale}-after-editor-review-input.json';refs[locale]={'path':str(q.relative_to(B)),'sha256':sha(q),'use':'Reference translations only, not evidence that Telugu is approved'}
shutil.copy2(P/'native-compatibility-caller-references.txt',K/'caller-references.txt')
packet={'source_sha256':manifest['source_sha256'],'locale':'te','catalog_sha256':{s:sha(p)for s,p in paths.items()},'entries':rows,'entry_count':18,'source_context':'Eighteen existing native application-owned diagnostic/status/ScriptEditor/Hive strings. Script compilation success/error, source line/column wrappers, load/save failure, stopped game/remediation, missing-generator fallback, local Hive standing-order acknowledgments. Preserve exact slots and raw remote/user content; approval covers compatibility strings, not execution of BG-only guarded presenters in Telugu. Actual callers in caller-references.txt.','reference_packets':refs,'old_native_pairs_exact':3412,'old_online_pairs_exact':2978,'status':'Machine first draft only; no approval; all three independent actual reviews required','runtime_platform_gates':'pending'};m.write_json(K/'te18-review-input.json',packet)
changes=[]
for p in(K/'machine').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(K/'machine');q=P/'machine'/rel
 if q.exists()and sha(q)==sha(p):continue
 assert not q.exists()or str(rel)=='spend-ledger.json';q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);changes.append(str(rel))
assert sha(K/'machine/spend-ledger.json')==sha(P/'machine/spend-ledger.json');(B/'active-machine-kit.txt').write_text(str(P)+'\n');result={'result':'passed','source_sha256':manifest['source_sha256'],'packet_sha256':sha(K/'te18-review-input.json'),'catalog_sha256':packet['catalog_sha256'],'new_entries':18,'prior96_ledger_exact_prefix':True,'all_prior_raw_cache_bytes_exact':True,'ledger_reservations':97,'reserved_usd':str(spent),'additional_reserved_usd':pre['expected_additional_usd'],'protected_codepoints':1196,'request_attempts':1,'machine_raw_bodies':97,'main_V8_machine_history_synced':changes,'old_native_pairs_exact':3412,'old_online_pairs_exact':2978,'protected_tokens_exact':True,'structural_errors':[],'runtime_platform_gates':'all pending','linguistic_approval':False};m.write_json(K/'machine-validation.json',result);print(json.dumps(result,indent=2))
