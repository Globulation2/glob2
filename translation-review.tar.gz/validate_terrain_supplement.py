from pathlib import Path
from decimal import Decimal
import hashlib,json,importlib.util,re,shutil
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'terrain-supplement-v5';OLD=B/'kit-v4';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pre=json.loads((K/'preflight.json').read_text());tool=R/pre['tool'];assert sha(tool)==pre['tool_sha256'];spec=importlib.util.spec_from_file_location('terrain_tool',tool);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
manifest=json.loads((K/'manifest.json').read_text());assert manifest['revision']is None and manifest['staged_merge_tree']=='b9267f871a7cdc29e4eeee072801fdddd2a511d4';assert manifest['source_sha256']=='35a434573e88a3cc9ec968b1a8f6e9e4bfa922b21debf924aaa0374b7adec3fe';source=json.loads((K/'source/native.json').read_text());draft,e=m.CHECKER.read_table(K/'drafts/bg/texts.bg.txt');before,e2=m.CHECKER.read_table(OLD/'drafts/bg/texts.bg.txt');assert not e and not e2 and len(draft)==3429 and len(before)==3425;assert all(draft[k]==v for k,v in before.items());assert sha(K/'drafts/bg/bg.json')==pre['online_sha256'];ids=json.loads((K/'delta-only-keys.json').read_text());keys=[i[7:]for i in ids]
entries=[]
for k in keys:
 value=draft[k];assert value.strip()and value!=source[k]and not any(c in value for c in ('\n','\r','\x00','\ufffd'));assert m.CHECKER.placeholders(value)==m.CHECKER.placeholders(source[k])and not m.CHECKER.invalid_percent(value);protected,tokens=m.protect_text(source[k]);assert not re.search(r'ZXQ[A-F0-9]{12}Q\d+QXZ',value);assert all(value.count(token)==source[k].count(token)for token in tokens.values());entries.append({'id':'native:'+k,'key':k,'source':source[k],'target':value,'source_sha256':hashlib.sha256(source[k].encode()).hexdigest(),'target_sha256':hashlib.sha256(value.encode()).hexdigest(),'protected_tokens':list(tokens.values())})
ledger=json.loads((K/'machine/spend-ledger.json').read_text());old=json.loads((OLD/'machine/spend-ledger.json').read_text());assert ledger['reservations'][:84]==old['reservations']and len(ledger['reservations'])==85;spent=sum((Decimal(r['reserved_usd'])for r in ledger['reservations']),Decimal());assert spent==Decimal('5.29244')and ledger['reservations'][-1]['codepoints']==37 and ledger['reservations'][-1]['locale']=='bg'
for name,digest in pre['machine_file_sha256'].items():
 if name not in ('spend-ledger.json','bg/provider-drafts.json'):assert sha(K/'machine'/name)==digest,name
raw=sorted((K/'machine').rglob('*.response.bin'));assert len(raw)==85
for path in raw:
 request,number=path.name.removesuffix('.response.bin').split('-');assert ledger['reservations'][int(number)-1]['request_sha256']==request
shutil.copytree(K/'drafts/bg',K/'provider-drafts/bg');raw_new=next(p for p in raw if p.name.endswith('-000085.response.bin'));packet={'status':'Google NMT draft only; original three-role full changed-batch review required','revision':None,'staged_merge_tree':manifest['staged_merge_tree'],'source_sha256':manifest['source_sha256'],'tool_sha256':sha(tool),'native_draft_sha256':sha(K/'drafts/bg/texts.bg.txt'),'online_sha256':sha(K/'drafts/bg/bg.json'),'entries':entries,'raw_response':{'path':str(raw_new.relative_to(R)),'sha256':sha(raw_new)},'provider_snapshot':{'path':str((K/'provider-drafts/bg/texts.bg.txt').relative_to(R)),'sha256':sha(K/'provider-drafts/bg/texts.bg.txt')},'paid_requests':1,'protected_codepoints':37,'new_reserved_usd':'0.00074','cumulative_reservations':85,'cumulative_reserved_usd':str(spent),'old_native_values_exact':3425,'old_ledger_prefix_exact':84,'complete_raw_bodies':85,'approval':None}
(K/'bg4-final-machine-packet.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n');context=json.loads((K/'bg4-context-input.json').read_text());bykey={e['key']:e for e in entries}
for e in context['entries']:e.update(bykey[e['id'][7:]])
context['machine_provenance']=packet;(K/'bg4-review-input.json').write_text(json.dumps(context,ensure_ascii=False,indent=2)+'\n')
# Supply every literal pair in each changed batch, including shifted old members.
affected={b['id']for b in pre['affected_batches_require_full_review']};review_batches=[]
for batch in manifest['batches']:
 if batch['id']not in affected:continue
 items=[]
 for i in batch['keys']:
  surface,key=i.split(':',1);assert surface=='native';items.append({'id':i,'key':key,'source':source[key],'target':draft[key]})
 review_batches.append({'id':batch['id'],'entries':items})
(K/'bg-full-affected-batches-review-input.json').write_text(json.dumps({'source_sha256':manifest['source_sha256'],'native_catalog_sha256':sha(K/'drafts/bg/texts.bg.txt'),'scope':'All full membership-shifted source batches require fresh original three-role readings; no carry-forward approval inferred.','batches':review_batches,'entries':sum(len(b['entries'])for b in review_batches)},ensure_ascii=False,indent=2)+'\n')
(K/'validation.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n');print(json.dumps(packet,ensure_ascii=False,indent=2))
