"""Build ignored integration candidates; approvals are checked separately."""
from pathlib import Path
import importlib.util,hashlib,json
R=Path(__file__).resolve().parents[2];B=R/'artifacts/bulgarian';V=B/'native-compat-reviews';K=B/'kit-v3-native-compat-v2';out=B/'final-native-catalog-candidate';out.mkdir(exist_ok=True)
s=importlib.util.spec_from_file_location('p',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
keys=json.loads((B/'kit-v3/source/native.json').read_text());oldkeys=json.loads((B/'kit-v2/source/native.json').read_text());newkeys=[k for k in keys if k not in oldkeys];assert len(newkeys)==18
entries=[];inputs=[]
for i in range(1,7):
 f=V/f'editorial-final-{i:02}.json';d=json.loads(f.read_text());entries+=d['entries'];inputs.append({'path':str(f.relative_to(B)),'sha256':sha(f)})
assert len(entries)==630 and len({(e['locale'],e['key'])for e in entries})==630
locales=sorted({e['locale']for e in entries});assert len(locales)==35
records=[]
for locale in locales:
 rows={e['key']:e for e in entries if e['locale']==locale};assert set(rows)==set(newkeys)
 code=p.game_code(locale);live=R/'data'/f'texts.{code}.txt';old,errors=p.CHECKER.read_table(live);assert not errors and len(old)==3393
 for key,e in rows.items():
  assert e['value']==keys[key] and e['native_code']==code
  assert e['translation'].strip() and e['translation']!=keys[key] and p.CHECKER.placeholders(e['translation'])==p.CHECKER.placeholders(keys[key])
 text=live.read_text();assert text.endswith('\n')
 candidate=out/live.name;candidate.write_text(text+''.join(k+'\n'+rows[k]['translation']+'\n'for k in newkeys))
 final,errors=p.CHECKER.read_table(candidate);assert not errors and len(final)==3411 and all(final[k]==v for k,v in old.items())
 records.append({'locale':locale,'native_code':code,'baseline_sha256':sha(live),'candidate_sha256':sha(candidate),'old3393_exact':True,'new_values':18})
for name,src in [('texts.en.txt',B/'source-stage-v3/data/texts.en.txt'),('texts.keys.txt',B/'source-stage-v3/data/texts.keys.txt'),('texts.bg.txt',B/'kit-v3/drafts/bg/texts.bg.txt')]:
 (out/name).write_bytes(src.read_bytes())
(out/'manifest.json').write_text(json.dumps({'source_sha256':'f8d14316709d155e55ce55a95f474763a34b22b897d0134494fb84aaf17e10ee','candidate_inputs':inputs,'compatibility_catalogs':records,'status':'Unregistered integration candidate; requires exact semantic and adversarial final approvals before final acceptance. BG independent v3 proof separate.'},ensure_ascii=False,indent=2)+'\n')
print('Prepared35 compatibility catalogs plus English/keys/BG; no live catalogs changed.')
