"""Validate supplied reviews and exact carry-forward; never generate reviews."""
from pathlib import Path
import copy,hashlib,importlib.util,json
R=Path(__file__).resolve().parents[2];B=R/'artifacts/bulgarian';K=B/'kit-v4';O=B/'kit-v3'
s=importlib.util.spec_from_file_location('p',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
def read(f):return json.loads(f.read_text())
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def ev(f):return {'path':str(f.relative_to(B)),'sha256':sha(f)}
m=read(K/'manifest.json');oldm=read(O/'manifest.json');oldrec=read(O/'reviews/bg.json');paths=p.catalog_paths(K,'bg');oldpaths=p.catalog_paths(O,'bg')
sources={s:read(K/'source'/f'{s}.json')for s in ('native','online')};oldsources={s:read(O/'source'/f'{s}.json')for s in sources}
targets={'native':p.CHECKER.read_table(paths['native'])[0],'online':read(paths['online'])};oldtargets={'native':p.CHECKER.read_table(oldpaths['native'])[0],'online':read(oldpaths['online'])}
assert all(set(oldsources[s])<=set(sources[s]) and all(oldsources[s][key]==sources[s][key]for key in oldsources[s])for s in sources)
changed={s:{key for key in oldsources[s]if targets[s][key]!=oldtargets[s][key]}for s in sources};added={s:set(sources[s])-set(oldsources[s])for s in sources}
assert len(changed['native'])==15 and len(added['native'])==14 and not changed['online'] and not added['online']
expected_delta=changed['native']|added['native'];proof_rows=[]
for role,names in [('semantic',['semantic-v4-final14.json','semantic-v4-refinement15.json']),('editor',['editor-v4-original-role-final14.json','editor-v4-refinement15.json'])]:
 entries=[];files=[]
 for name in names:
  f=B/'linguistics'/name;d=read(f);assert not d.get('findings',[]) and not d.get('unresolved',[]);entries+=d['entries'];files.append(ev(f))
 assert len(entries)==len({e['key']for e in entries})==29 and {e['key']for e in entries}==expected_delta
 for e in entries:assert e['source']==sources['native'][e['key']] and e['target']==targets['native'][e['key']],(role,e['key'])
 proof_rows.append({'role':role,'new_or_changed_final_pairs':29,'actual_agent':'/root/semantic_reviewer'if role=='semantic'else'/root/bulgarian_editor','evidence':files,'limits':'14 initial fresh readings and affected paragraph reread/13 exact carry;15 additional refinements freshly read. Other6239 source/target pairs preserve parent coverage.'})
advfile=B/'linguistics/adversarial-v4-final-recheck.json';adv=read(advfile);entries=adv['entries'];assert len(entries)==len({e['key']for e in entries})==480
ids={e['key']for e in entries};assert expected_delta<=ids
for e in entries:assert e['source']==sources['native'][e['key']] and e['target']==targets['native'][e['key']],e['key']
for field in ('unresolved_findings','open_findings'):assert not adv.get(field,[])
batches={b['id']for b in m['batches']if any(i.split(':',1)[1]in added['native']for i in b['keys']if i.startswith('native:'))};assert batches=={'native-general-012','native-general-013','native-maps-001'}
assert ids=={i.split(':',1)[1]for b in m['batches']if b['id']in batches for i in b['keys']}
for surface in sources:
 for key in oldsources[surface]:
  if surface=='native'and key in changed['native']:continue
  assert sources[surface][key]==oldsources[surface][key] and targets[surface][key]==oldtargets[surface][key]
proof={'source_sha256':m['source_sha256'],'catalog_sha256':{s:sha(f)for s,f in paths.items()},'parent_record':ev(O/'reviews/bg.json'),'parent_proof':ev(B/'review-proof-v3-validation.json'),'source_delta':{'new_native':sorted(added['native']),'revised_native':sorted(changed['native']),'unchanged_native_pairs':3396,'unchanged_online_pairs':2843},'semantic_editor_delta':proof_rows,'adversarial':{'actual_agent':'/root/v4_adversarial','complete_batches':sorted(batches),'final_pairs':480,'evidence':ev(advfile),'limits':'480 freshly read;15 corrections actually reread and465 exact pairs carried from own fresh review. Other5788 key pairs retain original adversarial identity and exact tuple coverage.'},'total_keys':6268,'bindings':18804,'limits':'Binding verifier only. Actual reviewer-supplied files establish readings; no native-human certification. Rendering and unavailable-platform assessments remain separate.'}
p.write_json(B/'review-proof-v4-validation.json',proof)
record=copy.deepcopy(oldrec);record['source_sha256']=m['source_sha256'];record['catalog_sha256']=proof['catalog_sha256'];record['batches']=[];oldb={b['id']:b for b in oldrec['batches']};hashes=p.batch_target_hashes(m,paths)
for batch in m['batches']:
 row=copy.deepcopy(oldb[batch['id']]);row.update(source_sha256=m['source_sha256'],target_sha256=hashes[batch['id']])
 for field in ('reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys'):row[field]=batch['keys']
 row['adversarial_reviewer']='/root/v4_adversarial'if batch['id']in batches else'/root/adversarial_reviewer'
 row['methodology']='Exact per-key source/target lineage in review-proof-v4-validation.json; changed29 semantic/editor pairs explicit,480 actual independent final adversarial batch readings. No fresh reading claimed for unchanged parent pairs.'
 record['batches'].append(row)
record['source_expansion_v4']=proof;record['review_proof']={'path':'../../review-proof-v4-validation.json','sha256':sha(B/'review-proof-v4-validation.json')}
for name in record['gates']:record['gates'][name]={'passed':False,'evidence':[],'reason':'Pending final integrated v4 verification. Unavailable physical/platform coverage must be listed explicitly, not marked passed.'}
for finding in read(B/'linguistics/adversarial-v4-final-batches.json')['findings']:
 record['findings'].append({'key':'native:'+finding['key'],'severity':finding['severity'],'state':'resolved','reason':finding['reason'],'resolution':'Exact proposed value independently accepted by semantic and original editorial reviewers, then rechecked by adversarial reviewer; proof files bound in v4 record.'})
checked=p.check_draft(K,'bg');assert not checked['errors'] and not checked['untranslated'];assert {e['key']for e in record['accepted_english']}==set(checked['same_as_english_review_queue'])
p.write_json(K/'reviews/bg.json',record);print('V4 verified6268keys/18804bindings; actual480newadversarial/29semantic-editor delta; gatespending')
