from pathlib import Path
from decimal import Decimal
import hashlib,importlib.util,json,re,shutil,xml.etree.ElementTree as ET
R=Path.cwd();B=R/'artifacts/bulgarian';P=B/'kit-v8';K=B/'platform-companion-v8';S=B/'platform-companion-v8-tool-shadow'
assert not K.exists() and not S.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
shutil.copytree(B/'v8-tool-shadow',S,ignore=shutil.ignore_patterns('__pycache__'))
resource_paths={'android.preparing_game':'mobile/android/app/src/main/res/values/strings.xml','darwin.NSLocalNetworkUsageDescription':'darwin/en.lproj/InfoPlist.strings','ios.NSLocalNetworkUsageDescription':'mobile/ios/en.lproj/InfoPlist.strings'}
rows=[]
for name,rel in resource_paths.items():
 path=R/rel;raw=path.read_bytes();assert b'<<<<<<<' not in raw
 if name.startswith('android'):text=ET.fromstring(raw).find("string[@name='preparing_game']").text
 else:
  match=re.fullmatch(r'\s*"NSLocalNetworkUsageDescription"\s*=\s*("(?:[^"\\]|\\.)*");\s*',raw.decode());assert match; text=json.loads(match[1])
 rows.append({'id':'online:platform.'+name,'key':'platform.'+name,'source':text,'resource_path':rel,'resource_sha256':sha(path),'resource_field':'preparing_game' if name.startswith('android')else'NSLocalNetworkUsageDescription'})
 q=K/'frozen-platform-resources'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
online=load(S/'platform/packages/i18n/locales/en.json');inv=load(S/'platform/packages/i18n/invariants.json')
for row in rows:
 assert row['key'] not in online;online[row['key']]=row['source'];inv[row['key']]=['Globulation 2'] if 'Globulation 2' in row['source']else[]
for rel,obj in [('platform/packages/i18n/locales/en.json',online),('platform/packages/i18n/invariants.json',inv)]:
 (S/rel).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('companion',S/'tools/localization/translation_program.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
manifest=m.prepare(K,root=S,locales=('bg',));manifest.update(revision=None,companion_only=True,parent_main_source_sha256=load(P/'manifest.json')['source_sha256'],source_context='Synthetic frozen tooling scope appends exactly3platform resources to clonedV8 online-style source; this is not the authoritative game/online source. No mainV8 source reset.');m.write_json(K/'manifest.json',manifest)
m.draft(K,'bg');paths=m.catalog_paths(K,'bg');shutil.copy2(P/'drafts/bg/texts.bg.txt',paths['native']);obj=load(P/'drafts/bg/bg.json');assert set(obj)==set(online)-{r['key']for r in rows};obj.update({r['key']:''for r in rows});m.write_json(paths['online'],obj)
for rel in m.SOURCE_PATHS:
 q=K/'frozen-source-inputs'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(S/rel,q)
shutil.copytree(P/'machine',K/'machine')
for folder in('rejected','provider-history'):
 if(P/folder).exists():shutil.copytree(P/folder,K/folder)
ledger=load(K/'machine/spend-ledger.json');spent=sum((Decimal(r['reserved_usd'])for r in ledger['reservations']),Decimal());assert len(ledger['reservations'])==95 and spent==Decimal('5.46822');assert len(list((K/'machine').rglob('*.response.bin')))==95
for row in rows:
 protected,replacements=m.protect_text(row['source'],inv[row['key']]);row.update(protected_codepoints=len(protected),protected_tokens=list(replacements.values()));assert len(protected)<=5000
chars=sum(r['protected_codepoints']for r in rows);cost=Decimal(chars)*20/1000000;assert spent+cost<10
m.write_json(K/'only-keys.json',[r['id']for r in rows]);record={'source_sha256':manifest['source_sha256'],'main_source_sha256':manifest['parent_main_source_sha256'],'main_source_is_unchanged':True,'tool_sha256':sha(S/'tools/localization/translation_program.py'),'entries':rows,'prior_machine_sha256':{str(p.relative_to(K/'machine')):sha(p)for p in(K/'machine').rglob('*')if p.is_file()},'prior_reservations':95,'prior_reserved_usd':str(spent),'protected_codepoints':chars,'expected_request_usd':str(cost),'expected_total_usd':str(spent+cost),'baseline_main_BG_catalogs':{s:sha(p)for s,p in m.catalog_paths(P,'bg').items()},'baseline_main_BG_snapshot':{},'main_manifest_sha256':sha(P/'manifest.json'),'paid_calls':0}
for surface,p in m.catalog_paths(P,'bg').items():
 q=K/'baseline-main-bg'/p.name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);record['baseline_main_BG_snapshot'][surface]=str(q.relative_to(K))
m.write_json(K/'preflight.json',record);print(json.dumps({k:v for k,v in record.items()if k!='prior_machine_sha256'},indent=2,ensure_ascii=False))
