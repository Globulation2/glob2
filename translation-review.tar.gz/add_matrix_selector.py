from pathlib import Path
p=Path('tools/TranslationPreviewHarness.cpp');s=p.read_text()
s=s.replace('void fontMatrix(const fs::path &root, const fs::path &pilot, const fs::path &output, int width, int height)','void fontMatrix(const fs::path &root, const fs::path &pilot, const fs::path &output, int width, int height,\n                unsigned selectedSize = 0, int selectedScale = 0)')
s=s.replace('''        for (unsigned size : {10u, 13u, 20u}) for (int scale : {1, 2}) {
            GAGCore::TrueTypeFont font;''','''        for (unsigned size : {10u, 13u, 20u}) for (int scale : {1, 2}) {
            if (selectedSize && (size != selectedSize || scale != selectedScale)) continue;
            GAGCore::TrueTypeFont font;''')
s=s.replace('''    manifest["native_keys_overridden"] = localized;''','''    manifest["native_keys_overridden"] = localized;
    manifest["selected_size"] = selectedSize ? Json(selectedSize) : Json(nullptr);
    manifest["selected_scale"] = selectedScale ? Json(selectedScale) : Json(nullptr);''',1)
s=s.replace('matrix ROOT DRAFT OUTPUT W H | screen','matrix ROOT DRAFT OUTPUT W H [SIZE SCALE] | screen')
s=s.replace('''        if (mode == "matrix") fontMatrix(root, pilot, output, width, height);''','''        if (mode == "matrix") {
            require(argc == 7 || argc == 9, "Matrix takes ROOT DRAFT OUTPUT W H and optional SIZE SCALE");
            unsigned size = 0;
            int scale = 0;
            if (argc == 9) {
                const std::string sizeArg = argv[7], scaleArg = argv[8];
                require(sizeArg == "10" || sizeArg == "13" || sizeArg == "20", "Matrix SIZE must be 10, 13 or 20");
                require(scaleArg == "1" || scaleArg == "2", "Matrix SCALE must be 1 or 2");
                size = unsigned(std::stoi(sizeArg));
                scale = std::stoi(scaleArg);
            }
            fontMatrix(root, pilot, output, width, height, size, scale);
        }''')
p.write_text(s)
p=Path('docs/development/ui-framework.md');s=p.read_text();s=s.replace('''wrapper at several authored sizes and raster scales. `screen` adds''','''wrapper at authored sizes 10, 13 and 20 and raster scales 1 and 2. Optional
`SIZE SCALE` arguments select exactly one of these combinations for independently
resumable batches; omitting both runs all six. Each batch has its own complete
manifest and uses the same wrapping and rasterization. `screen` adds''');p.write_text(s)
print('Optional matrix selector applied; default loop and row raster algorithm unchanged.')
