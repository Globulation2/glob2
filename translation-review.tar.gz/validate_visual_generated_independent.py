"""Verify one-key visual refinement against retained actual role/parent proofs."""
from pathlib import Path
import hashlib,json,importlib.util,subprocess
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'kit-v4';O=B/'visual-refinement-v4/before';read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=lambda s:hashlib.sha256(s.encode()).hexdigest();jh=lambda s:h(json.dumps(s,ensure_ascii=False,sort_keys=True,separators=(',',':')))
s=importlib.util.spec_from_file_location('program',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
manifest=read(K/'manifest.json');proof=read(B/'review-proof-v4-visual-validation.json');record=read(K/'reviews/bg.json');before_record=read(O/'review-record-bg.json');before_proof=read(O/'review-proof-v4-validation.json');before_independent=read(O/'review-proof-v4-independent-validation.json')
for field in ('parent_record','parent_proof','parent_independent_proof'):assert proof[field]['sha256']==sha(B/proof[field]['path'])
assert before_independent['result']=='passed'and before_independent['proof_sha256']==sha(O/'review-proof-v4-validation.json')and before_independent['record_sha256']==sha(O/'review-record-bg.json')
assert before_record['review_proof']['sha256']==sha(O/'review-proof-v4-validation.json');assert record['review_proof']['sha256']==sha(B/'review-proof-v4-visual-validation.json');assert record['visual_refinement_v4']==proof
for field in ('parent_record','parent_proof'):assert before_proof[field]['sha256']==sha(B/before_proof[field]['path'])
source={surface:read(K/'source'/f'{surface}.json')for surface in ('native','online')};target={'native':p.CHECKER.read_table(K/'drafts/bg/texts.bg.txt')[0],'online':read(K/'drafts/bg/bg.json')};before={'native':p.CHECKER.read_table(O/'texts.bg.txt')[0],'online':target['online']}
assert sha(O/'texts.bg.txt')==before_proof['catalog_sha256']['native']==before_record['catalog_sha256']['native']==proof['parent_catalog_sha256']['native']=='24ee79586ba0e811c67958785623e0755602e2b075c767f7ee84e31677aa90bb'
assert sha(K/'drafts/bg/texts.bg.txt')==proof['catalog_sha256']['native']==record['catalog_sha256']['native']=='dfc3638b84e9d90272a093c7fe0f6e9112b3af0c8a6b3cca7d45ff26c69ca10c'
assert sha(K/'drafts/bg/bg.json')==proof['catalog_sha256']['online']==proof['parent_catalog_sha256']['online']==before_proof['catalog_sha256']['online']=='69de8f4cf769924db105fe166cf25a352967e5ca3263951dd1753c3d8f263813'
for file,digest in manifest['source_files'].items():assert sha(R/file)==digest
assert h(json.dumps(manifest['source_files'],sort_keys=True))==manifest['source_sha256']==proof['source_sha256']==record['source_sha256']=='2b396013f79c0bd68dd016a771fe48b8769ec856c5a5cb8f700f0e6ee2e845c7'
for file,digest in manifest['source_snapshots'].items():assert sha(K/'source'/file)==digest
allids={surface+':'+key for surface in source for key in source[surface]};assert len(allids)==6268
changed={surface+':'+key for surface in target for key in target[surface]if target[surface][key]!=before[surface][key]};assert changed=={'native:[Generated]'};assert proof['changed_keys']==list(changed)and proof['unchanged_exact_source_target_pairs']==6267
assert source['native']['[Generated]']=='Generated'and before['native']['[Generated]']=='Генерирано'and target['native']['[Generated]']=='Генерирана'
# Original three roles supply actual new readings; hashes use their declared
# literal UTF8 or canonical JSON string conventions, not one imposed convention.
roles=[]
for role,name,identity in [('semantic','semantic-visual-generated.json','/root/semantic_reviewer'),('editor','editor-visual-generated.json','/root/bulgarian_editor'),('adversarial','adversarial-visual-generated.json','/root/adversarial_reviewer')]:
 f=B/'linguistics'/name;d=read(f);e=d['entry']if'entry'in d else d['entries'][0];assert len(d.get('entries',[e]))==1
 assert(d.get('reviewer_agent')or d['identity']['agent'])==identity
 assert d.get('source_sha256',d.get('source_aggregate_sha256'))==manifest['source_sha256']
 assert e['key']=='[Generated]'and e['source']==source['native'][e['key']]and e.get('target',e.get('proposed_target'))==target['native'][e['key']]
 hash_value=jh if role=='editor'else h;assert e.get('source_sha256',e.get('source_value_sha256'))==hash_value(e['source']);assert e['target_sha256']==hash_value(target['native'][e['key']]);assert e.get('decision',e.get('status'))in ('approved','accept')
 assert not d.get('findings')and not d.get('unresolved_findings')
 if role=='semantic':assert e['actual_reading']is True
 if role=='editor':assert e['method']=='actual-independent-targeted-context-reread'
 if role=='adversarial':assert e['current_target']==before['native'][e['key']]and e['current_target_sha256']==h(e['current_target'])and e['key_sha256']==h(e['key'])and d['frozen_native_catalog_sha256']==sha(O/'texts.bg.txt')
 candidate=R/d.get('candidate_file','artifacts/bulgarian/linguistics/visual-generated-candidate.json');expected=d.get('candidate_file_sha256',d.get('raw_file_sha256',{}).get(str(candidate.relative_to(R))));assert sha(candidate)==expected
 actual=next(row for row in proof['actual_new_reviews']if row['role']==role);assert actual['agent']==identity and actual['actual_targeted_readings']==1 and actual['evidence']=={'path':str(f.relative_to(B)),'sha256':sha(f)}
 roles.append({'role':role,'actual_agent':identity,'actual_new_readings':1,'file':str(f.relative_to(B)),'sha256':sha(f)})
# Membership is unchanged; every row hash and four role identities stay bound.
oldrows={row['id']:row for row in before_record['batches']};rows={row['id']:row for row in record['batches']};changed_batches=[];bindings=0
for batch in manifest['batches']:
 row=rows[batch['id']];oldrow=oldrows[batch['id']];assert row['source_sha256']==oldrow['source_sha256']==manifest['source_sha256']
 for field in ('reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys'):assert row[field]==oldrow[field]==batch['keys']
 for identity in ('author','reviewer','editor','adversarial_reviewer'):assert row[identity]==oldrow[identity]
 assert len({row[f]for f in ('author','reviewer','editor','adversarial_reviewer')})==4
 values={i:target[i.split(':',1)[0]][i.split(':',1)[1]]for i in batch['keys']};oldvalues={i:before[i.split(':',1)[0]][i.split(':',1)[1]]for i in batch['keys']};assert row['target_sha256']==h(json.dumps(values,ensure_ascii=False,sort_keys=True));assert oldrow['target_sha256']==h(json.dumps(oldvalues,ensure_ascii=False,sort_keys=True))
 if row['target_sha256']!=oldrow['target_sha256']:changed_batches.append(batch['id'])
 bindings+=3*len(batch['keys'])
assert changed_batches==proof['changed_batches']==['native-general-008']and bindings==proof['role_bindings']==18804
v3source={surface:read(B/'kit-v3/source'/f'{surface}.json')for surface in source};v3target={'native':p.CHECKER.read_table(B/'kit-v3/drafts/bg/texts.bg.txt')[0],'online':read(B/'kit-v3/drafts/bg/bg.json')}
semantic_editor_delta={surface+':'+key for surface in source for key in source[surface]if key not in v3source[surface]or target[surface][key]!=v3target[surface][key]};assert len(semantic_editor_delta)==30
assert len(allids-semantic_editor_delta)==6238
fresh480={i for batch in manifest['batches']if batch['id']in before_proof['adversarial']['complete_batches']for i in batch['keys']};assert len(fresh480)==480 and not changed&fresh480
for i in fresh480:
 surface,key=i.split(':',1);assert target[surface][key]==before[surface][key]
original_exact=allids-fresh480-changed;assert len(original_exact)==5787
for i in original_exact:
 surface,key=i.split(':',1);assert source[surface][key]==v3source[surface][key]and target[surface][key]==v3target[surface][key]
checked=p.check_draft(K,'bg');assert not checked['errors']and not checked['untranslated'];assert len(record['accepted_english'])==108 and record['accepted_english']==before_record['accepted_english'];assert {row['key']for row in record['accepted_english']}==set(checked['same_as_english_review_queue'])
assert len(record['gates'])==9 and all(g['passed']is False and not g['evidence']for g in record['gates'].values())
technical={row['id']:row for row in record['technical_findings']if row.get('id')in ('statistics-empty-notice-wrap','script-editor-compact-status-and-labels')};assert len(technical)==2 and all(row['state']=='pending-runtime-verification'for row in technical.values())
for row in technical.values():
 for reference in row['evidence']:assert sha(B/reference['path'])==reference['sha256']
result={'result':'passed','validator':'/root/draft_tooling','scope':'Independent literal/hash/role/lineage binding verification only; no new linguistic or rendering approval','checked_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':manifest['source_sha256'],'catalog_sha256':proof['catalog_sha256'],'total_keys':6268,'bindings':bindings,'exact_parent_pairs':6267,'changed_keys':list(changed),'changed_batches':changed_batches,'batch_hashes_verified':len(rows),'actual_new_readings':roles,'semantic_editor_explicit_final_delta_each':30,'semantic_editor_exact_v3_pairs':6238,'fresh_v4_adversarial_pairs_exact':480,'original_adversarial_exact_pairs':5787,'original_adversarial_actual_new_reading':1,'accepted_english_exact_parent':108,'all9_gates_pending':True,'new_technical_findings_pending_runtime':2,'parent_proof_sha256':sha(O/'review-proof-v4-validation.json'),'parent_independent_proof_sha256':sha(O/'review-proof-v4-independent-validation.json'),'parent_record_sha256':sha(O/'review-record-bg.json'),'visual_proof_sha256':sha(B/'review-proof-v4-visual-validation.json'),'final_record_sha256':sha(K/'reviews/bg.json'),'before_runtime_results_not_rebound':True,'no_approval_generated_by_validation':True}
(B/'review-proof-v4-visual-independent-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
