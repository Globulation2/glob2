from pathlib import Path
import json,hashlib,tarfile,gzip,re
from collections import Counter
B=Path(__file__).resolve().parent;O=B/'published';manifest=json.loads((O/'manifest.json').read_text());index=json.loads((O/'archive-members.json').read_text());frozen=json.loads((O/'frozen-inputs.json').read_text())['inputs'];checked=0;errors=[];base64_candidates=[]
def check_json(data,label):
 def walk(x,path=''):
  if isinstance(x,dict):
   for k,v in x.items():walk(v,path+'/'+k)
  elif isinstance(x,list):
   for i,v in enumerate(x):walk(v,path+'/'+str(i))
  elif isinstance(x,str) and len(x)>1000 and re.fullmatch(r'[A-Za-z0-9+/=\r\n]+',x):base64_candidates.append({'file':label,'pointer':path,'length':len(x)})
 walk(json.loads(data))
for name,identity in manifest['files'].items():
 p=O/name
 if name in frozen:p=O/frozen[name]['snapshot']
 data=p.read_bytes();assert len(data)==identity['bytes'] and hashlib.sha256(data).hexdigest()==identity['sha256'],name
 if name.endswith('.json'):check_json(data,name)
for name,identity in frozen.items():
 data=(O/identity['snapshot']).read_bytes();assert len(data)==identity['bytes']and hashlib.sha256(data).hexdigest()==identity['sha256'],name
for archive,members in index.items():
 with tarfile.open(O/archive,'r:gz') as t:
  assert set(t.getnames())==set(members)
  for m in t:
   data=t.extractfile(m).read();expected=members[m.name];assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'],m.name;checked+=1
   assert not any(c in m.name.split('/')for c in ('cache','caches','node_modules','__pycache__','provisional','profiles','dist','build'))
   if m.name.endswith('.json'):check_json(data,m.name)
assert not base64_candidates,base64_candidates
selection=json.loads((B/'native-captures/publish-selection.json').read_text())['paths'];publication=set(manifest['files'])|{n for d in index.values()for n in d};assert all(str(Path(p).relative_to('artifacts/bulgarian'))in publication for p in selection)
additional_selection_count=0
for choice in json.loads((O/'curation-readiness.json').read_text())['additional_native_selection_inputs']:
 item=json.loads(Path(choice).read_text());paths=item['paths']if isinstance(item,dict)else item
 for path in paths:
  path=Path(path);label=str(path.relative_to('artifacts/bulgarian'))if str(path).startswith('artifacts/')else str(Path('native-captures')/path);assert label in publication,label
 additional_selection_count+=len(paths)
required=['review-proof-v4-visual-validation.json','review-proof-v4-visual-independent-validation.json','visual-refinement-v4/before/review-record-bg.json','visual-refinement-v4/before/texts.bg.txt','chart-status-wrap/chart-status-wrap.patch','chart-status-wrap/chart-status-wrap-test.patch','script-status-wrap/script-responsive-layout.patch','script-status-wrap/script-responsive-test.patch','review-chart-script-visual-fixes.json','v5-frozen-inputs.json','native-captures/v4-final/publish-selection.json','review-proof-v4-validation.json','review-proof-v4-independent-validation.json','kit-v4/reviews/bg.json','v4-frozen-inputs.json','final-catalog-font-coverage-v4.json','statistics-preview/statistics-preview.patch','statistics-preview/statistics-preview-docs.patch','statistics-preview/syntax-with-preview-friend.json','statistics-preview/include/touch/GameGUITouch.h','native-captures/v4-final/font-carryforward.json','kit-v4/manifest.json','kit-v4/machine/spend-ledger.json','kit-v3-native-compat-v2/machine/spend-ledger.json','review-proof-v3-validation.json','review-proof-v3-independent-validation.json','native-compat-review-binding-final.json','comprehensive-error-surfaces/comprehensive-error-surfaces.patch','legacy-native-drafting-v2/legacy-native-drafting.patch','script-editor-preview/script-editor-preview.patch','master-e927-conflict-resolution.json','merge-tree-82394-e927.txt','drafting-tests-v3-final.log','native-translation-tests-v3.log'];assert all(n in publication for n in required),[n for n in required if n not in publication]
# Census actual provider files independently of the curated archive index.
raw_provider_files=sorted(p for kit in sorted(set(B.glob('kit*'))|{B/'terrain-supplement-v5'})if kit.is_dir()for p in kit.rglob('*.response.bin'))
raw_rows=[]
for path in raw_provider_files:
 name=str(path.relative_to(B));data=path.read_bytes();assert name in publication,'Unselected actual provider response: '+name
 assert name in frozen and hashlib.sha256(data).hexdigest()==frozen[name]['sha256']and len(data)==frozen[name]['bytes'],name
 selected_archives=[archive for archive,members in index.items()if name in members];assert selected_archives,name
 raw_rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'stored_format':'gzip'if data.startswith(b'\x1f\x8b')else'zlib'if len(data)>1 and data[0]==0x78 and (data[0]*256+data[1])%31==0 else'UTF-8 text','archives':selected_archives})
ledger_options=[json.loads((O/info['snapshot']).read_text())['reservations']for name,info in frozen.items()if name.endswith('/machine/spend-ledger.json')];ledger=max(ledger_options,key=len)
for prior in ledger_options:assert prior==ledger[:len(prior)],'Divergent cumulative ledger prefix';mapped=set()
for row in raw_rows:
 request,number=Path(row['path']).name.removesuffix('.response.bin').split('-');number=int(number)
 assert ledger[number-1]['request_sha256']==request,row['path'];mapped.add(number)
assert mapped=={i+1 for i,reservation in enumerate(ledger)if reservation['state']=='response-received'}
provider_report={'result':'passed','actual_files':len(raw_rows),'selected_files':len(raw_rows),'cumulative_response_received_reservations':len(mapped),'request_identities_match_frozen_ledger':True,'unique_body_sha256':len({r['sha256']for r in raw_rows}),'by_kit':dict(Counter(Path(r['path']).parts[0]for r in raw_rows)),'stored_formats':dict(Counter(r['stored_format']for r in raw_rows)),'fa_it_raw_files':sum(any(part in ('fa','it')for part in Path(r['path']).parts)for r in raw_rows),'rejected_wrong_br_raw_files':sum('rejected'in Path(r['path']).parts for r in raw_rows),'current_kit_regular_files':sum(r['path'].startswith('kit-v4/machine/')for r in raw_rows),'files':raw_rows}
(B/'publisher-provider-raw-coverage.json').write_text(json.dumps(provider_report,indent=2)+'\n')
r={'result':'passed','publication_files_verified':len(manifest['files']),'archive_members_verified':checked,'frozen_inputs_verified':len(frozen),'actual_provider_response_bins_verified':len(raw_rows),'unique_provider_response_bodies':provider_report['unique_body_sha256'],'native_selection_preserved':len(selection),'additional_native_selection_entries_preserved':additional_selection_count,'base64_duplicate_candidates':base64_candidates,'required_evidence_paths_verified':required,'manifest_sha256':hashlib.sha256((O/'manifest.json').read_bytes()).hexdigest(),'publication_ready':False,'pending':json.loads((O/'curation-readiness.json').read_text())['pending_categories']};(B/'publisher-curation-inventory-validation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
