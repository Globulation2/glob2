import json,hashlib,re,collections,sys
from pathlib import Path
p=Path(__file__).parent;h=lambda s:hashlib.sha256(s.encode()).hexdigest()
reasons=json.loads((p/'editorial-01.json').read_text())['entries'][:18]
def write(n,edits):
 inp=p/f'semantic-input-{n:02}.json';sem=p/f'semantic-{n:02}.json';d=json.loads(inp.read_text());s=json.loads(sem.read_text());sm={(e['locale'],e['key']):e for e in s['entries']};candidate=[]
 for e in d['entries']:
  e=e.copy();e['translation']=sm[e['locale'],e['key']]['proposed'];e['original_draft_origin']=e['origin'];e['origin']='Integrated semantic proposal; original provider/manual origin and semantic records preserved';candidate.append(e)
 c={k:v for k,v in d.items() if k!='entries'};c['entries']=candidate;c['semantic_report_sha256']=h(sem.read_text());cp=p/f'editorial-input-{n:02}.json';cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');entries=[];finals=[];counter=collections.Counter()
 for e in candidate:
  l=e['locale'];i=counter[l];counter[l]+=1;v=e['translation'];new,reason=edits.get((l,i),(v,'Read independently against English, gameplay context and existing native terminology: grammar, register, command state and placeholders are suitable.'))
  assert sorted(re.findall(r'%\d+',e['value']))==sorted(re.findall(r'%\d+',new)),(l,i)
  entries.append({'locale':l,'native_code':e['native_code'],'key':e['key'],'source':e['value'],'input':v,'proposed':new,'source_sha256':h(e['value']),'input_sha256':h(v),'proposed_sha256':h(new),'actual_reading':True,'context_examined':e['context'],'decision':'replace' if v!=new else 'accept','reason':reason,'confidence':'medium','input_origin':e['origin'],'original_draft_origin':e['original_draft_origin'],'proposed_origin':'Manual editorial revision' if v!=new else 'Semantic candidate retained after independent editorial reading'})
  f=e.copy();f['translation']=new;f['origin']='Editorial candidate; requires semantic recheck and adversarial review';finals.append(f)
 r={'reviewer_agent':'/root/compat_editor','review_role':'Independent editorial reviewer','certification':'Agent-reviewed only; not native-human certification. No old3393 approval implied.','source_sha256':d['source_sha256'],'input_file':str(cp),'input_file_sha256':h(cp.read_text()),'examined_count':len(entries),'proposed_correction_count':sum(e['decision']=='replace' for e in entries),'per_locale_counts':dict(counter),'entries':entries,'unresolved_questions':[]}
 (p/f'editorial-{n:02}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');(p/f'editorial-{n:02}-proposed-corrections.json').write_text(json.dumps([e for e in entries if e['decision']=='replace'],ensure_ascii=False,indent=2)+'\n');c['entries']=finals;c['editorial_report_sha256']=h((p/f'editorial-{n:02}.json').read_text());out=p/f'editorial-final-{n:02}.json';out.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print(n,len(entries),r['proposed_correction_count'],h(out.read_text()))
if __name__=='__main__':
 n=int(sys.argv[1]);edits=json.loads((p/f'editorial-edits-{n:02}.json').read_text());write(n,{(e['locale'],e['index']):(e['value'],e['reason']) for e in edits})
