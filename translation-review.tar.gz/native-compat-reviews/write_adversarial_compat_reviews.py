from pathlib import Path
import json,hashlib,collections,re
base=Path('artifacts/bulgarian/native-compat-reviews');sourcepath=Path('artifacts/bulgarian/kit-v3/source/native.json');source=json.loads(sourcepath.read_text());source_bundle='f8d14316709d155e55ce55a95f474763a34b22b897d0134494fb84aaf17e10ee'
expected=['fa3192057b37bdcce028e107d4a340e65313ee029a628ae88b19721ec15a40aa','fe2df1ea10098b0379daff7b0147ad7a9aa735f648310831537044580e2d6323','1de9b5040b1fa6824ca825160f13157d81ac5897abd01170f1720035bfa9f9c9','17901e9923bec3efc352121cd0e4409c8f63d0bd87098db8c3095910c7ef7edc','17094789fdc80d88aafdffd9bc345e78b514fa1d8845bb8edf5636faea47165e','fe9b2769f00136db3230db3c4d0e4fba3971c1681d7137b0f2815314efe7b5c3']
def sha(b):return hashlib.sha256(b).hexdigest()
def th(t):return sha(t.encode('utf-8'))
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
standing='[settings The commander may follow up on standing orders. Follow-ups use credits; installed orders keep running without credits.]'
refkeys=['[compile]','[load script]','[open commander]',standing]
refs={};allentries=[];groups=[]
for n in range(1,7):
 f=base/f'editorial-final-{n:02}.json';raw=f.read_bytes();assert sha(raw)==expected[n-1],f'Candidate changed after reading: {f}'
 d=json.loads(raw);assert d['source_sha256']==source_bundle
 records=[];seen=set()
 for ordinal,e in enumerate(d['entries'],1):
  locale=e['locale'];code=e['native_code'];key=e['key'];s=e['value'];t=e['translation'];assert source[key]==s
  token=(locale,key);assert token not in seen;seen.add(token)
  assert collections.Counter(re.findall(r'%\d+',s))==collections.Counter(re.findall(r'%\d+',t)),token
  if code not in refs:
   rp=Path('data')/f'texts.{code}.txt';rraw=rp.read_bytes();cat={};k=None
   for line in rraw.decode().splitlines():
    if line.startswith('[') and line.endswith(']'):k=line
    elif k is not None:cat[k]=line;k=None
   refs[code]={'locale':locale,'path':str(rp),'file_sha256':sha(rraw),'scope':'Only these four contextual legacy entries consulted; no full legacy catalog reread claimed.','entries':[{'key':k,'target':cat[k],'target_sha256':th(cat[k])} for k in refkeys]}
  if key=='[script compilation success]':reason='Success remains an unambiguous successful compilation/validation status; software compile terminology checked against the native menu.'
  elif key=='[script error at %0:%1: %2]':reason='Error wrapper preserves line%0, column%1 and diagnostic%2. Coordinate notation or explicit line/column wording is accurate; no parameter content is translated.'
  elif key=='[script compilation failure %0:%1:(%2):%3]':reason='Compile failure outcome and all four coordinate/offset/diagnostic parameters are preserved in order, including parenthesized offset.'
  elif key=='[script compilation failed %0]':reason='Compile failure status and exact supplied diagnostic parameter preserved.'
  elif key in ['[script loading failed %0]','[script saving failed %0]']:reason='Correct load-from/save-to failure direction; exact filename placeholder preserved. Conventional local software script terms are acceptable.'
  elif key=='[script line %0 column %1]':reason='Line and column are cursor coordinates, not a person/rank; labels and both positional parameters are accurate.'
  elif key=='[game stopped %0]':reason='Reports the running game as stopped/interrupted/ended with its supplied diagnostic, rather than claiming a start failure or victory.'
  elif key=='[game stopped script help]':reason='Embedded JavaScript and its resource consumption remain the subject of review before restarting the game. JavaScript is intentionally the exact programming-language name.'
  elif key=='[missing map generator %0]':reason='Missing generator ID is preserved; fallback denotes built-in/integrated game landscape, not indigenous ethnicity, nationality or native-language content. Selection is completed.'
  elif key=='[hive standing order paused]':reason='Persistent game commander instruction needs attention and is already paused. Standing-order term checked against native commander context.'
  elif key=='[hive connection changed orders paused]':reason='Connection changed; already-paused persistent orders must be reviewed before resumption. No claim that reconnection automatically resumes them.'
  elif key=='[hive standing order fresh instruction]':reason='After reconnection a fresh instruction is required; cancellation or commander replacement remains available. No banking/purchase action is introduced.'
  elif key=='[hive order confirmation failed]':reason='Order confirmation failed; persistent orders must be reviewed before resuming. Failure is not misreported as success or completed remote execution.'
  elif key=='[hive previous order sending]':reason='Previous order is still in flight; this new message remains saved and can be resent by opening the commander. Pronoun/gender choices refer correctly to the saved message.'
  elif key=='[hive order received %0]':reason='Acknowledges receipt and retains exact literal user-authored order parameter; no assumptions about the parameter contents.'
  elif key=='[hive order not confirmed]':reason='Unconfirmed order and retry via commander are explicit; user message is retained.'
  elif key=='[hive standing order update failed]':reason='Update failed and this device/local order is paused; retry the corresponding control. Does not assert remote server completion.'
  else:raise AssertionError(key)
  record={'ordinal':ordinal,'locale':locale,'native_code':code,'surface':'native','key':key,'source':s,'translation':t,'context':e['context'],'key_sha256':th(key),'source_sha256':th(s),'target_sha256':th(t),'context_sha256':th(e['context']),'decision':'accept','findings':[],'reason':reason,'review_method':'Fresh direct reading of this exact displayed candidate against English, context and relevant native menu/commander vocabulary; structural checks supplement linguistic reading.'}
  if locale=='de' and 'standing order' in key:record['terminology_note']='Dauerauftrag retained as the established in-game persistent-instruction term from commander settings; surrounding Befehl/Kommandant/pause/retry context distinguishes it from banking.'
  if locale=='pt-BR':record['identity_note']='Brazilian Portuguese text in repository legacy native code br; not Breton. Salvar/salva/conexão/controle agree with Brazilian usage and existing commander vocabulary.'
  if 'JavaScript' in t:record['intentional_english_fragments']=[{'text':'JavaScript','reason':'Exact programming-language identifier, intentionally not translated.'}]
  if s==t:record['english_identical_disposition']='Checked technical status/identifier; no unintended untranslated full string.'
  records.append(record)
 counts=dict(collections.Counter(e['locale'] for e in records));assert all(v==18 for v in counts.values())
 result={'schema_version':1,'reviewer_agent':'/root/adversarial_reviewer','scope':'Only18 newly added native compatibility keys per listed locale, not the legacy3393-key corpus. Every listed candidate value was freshly read independently.','source_sha256':source_bundle,'frozen_source_native_json_sha256':sha(sourcepath.read_bytes()),'candidate_file':str(f),'candidate_file_sha256':sha(raw),'actual_read_count':len(records),'locale_count':len(counts),'per_locale_counts':counts,'locales':d['locales'],'native_human_certification':False,'severity_scale':['critical','major','minor'],'findings':[],'proposed_edits':[],'placeholder_mismatches':0,'english_identical_count':sum(x['source']==x['translation'] for x in records),'serialization':'String SHA256 values use raw UTF-8 bytes of decoded strings, without JSON quotes or added newline. Candidate/reference file SHA256 uses exact file bytes.','status':'Accepted only for this exact candidate SHA256; a later changed candidate is not approved until its delta is reread.','reference_catalogs':[refs[c] for c in dict.fromkeys(e['native_code'] for e in records)],'usage_evidence':['artifacts/bulgarian/comprehensive-error-surfaces/stage/src/ui/HiveReportText.h:17-24','ScriptEditorScreen compile/load/save/cursor context previously inspected with these same18 English source keys; candidate contexts freshly read in this pass.','GameSessionScreen Script::SessionFailure abort and CustomGameScreen missing-generator fallback previously inspected with these same18 source keys.'],'entries':records}
 output=base/f'adversarial-{n:02}.json';write(output,result);groups.append({'group':f'{n:02}','candidate_file':str(f),'candidate_file_sha256':sha(raw),'review_file':str(output),'review_file_sha256':sha(output.read_bytes()),'actual_read_count':len(records),'per_locale_counts':counts,'findings':0,'status':'accept_exact_candidate'})
 allentries.extend(records)
assert len(allentries)==630 and len({(e['locale'],e['key']) for e in allentries})==630
counts=dict(collections.Counter(e['locale'] for e in allentries));assert len(counts)==35 and all(n==18 for n in counts.values())
summary={'schema_version':1,'reviewer_agent':'/root/adversarial_reviewer','source_sha256':source_bundle,'scope':'Fresh independent adversarial reading of630 new compatibility values,18keys×35non-Bulgarian locales, across all six exact editorial candidates. No whole legacy-catalog review or native-human certification claimed.','actual_read_count':630,'locale_count':35,'per_locale_counts':counts,'groups':groups,'findings':[],'proposed_edits':[],'placeholder_mismatches':0,'english_identical_count':sum(e['source']==e['translation'] for e in allentries),'pt_br_identity':'Group06 is Brazilian Portuguese in legacy native code br, not Breton. All18 Brazilian Portuguese values were freshly read.','independence':'No semantic reviewer findings read. Editorial coverage metadata used for scope/file identity only; decisions above come from the displayed630 values, English/context and limited native reference vocabulary.','status':'All six exact candidate hashes accepted. Any subsequent changed value/candidate requires targeted rereading and a new hash binding.','no_live_or_candidate_edits':True,'no_paid_calls_or_builds_or_captures':True,'limits':['Independent AI linguistic review, not native-human certification in35languages.','Only18new compatibility keys reviewed per locale; existing3393-key native corpora were not reviewed or certified.','No pixel-fit, bidirectional rendering, font coverage or runtime claims from this linguistic pass.']}
write(base/'adversarial-summary.json',summary)
print(json.dumps({'actual_read_count':630,'locale_count':35,'findings':0,'per_group':[(g['group'],g['actual_read_count'],g['candidate_file_sha256'])for g in groups],'summary_sha256':sha((base/'adversarial-summary.json').read_bytes())}))
