from pathlib import Path
import json,hashlib,re
p=Path(__file__).parent
inp=p/'semantic-input-01.json'; sem=p/'semantic-01.json'
d=json.loads(inp.read_text()); s=json.loads(sem.read_text()); sm={(e['locale'],e['key']):e for e in s['entries']}
locales=['ar','ca','cs','da','de','eo']; candidate=[]
for e in d['entries']:
 if e['locale'] not in locales: continue
 e=e.copy(); sr=sm[(e['locale'],e['key'])]; e['translation']=sr['proposed']; e['origin']='Semantic candidate; original provider and semantic records preserved'; candidate.append(e)
sha=lambda v:hashlib.sha256(v.encode()).hexdigest()
cp=p/'editorial-input-01.json'; c={'source_sha256':d['source_sha256'],'scope':'108 new native compatibility entries only, excluding rejected wrong-language br','locales':locales,'entries':candidate,'references':{l:d['references'][l] for l in locales},'contexts':d['contexts'],'requirements':d['requirements'],'semantic_input_sha256':sha(sem.read_text())};cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
# Manually authored editorial changes after reading all108 current candidates and glossary/context.
edits={
('ar',0):('نجاح تصريف النص البرمجي','Use the established صرّف compile terminology and النص البرمجي label rather than switching to assembly terminology.'),
('ar',2):('فشل التصريف: %0:%1:(%2):%3','Keep compiler term consistent with the existing Compile action; preserve every diagnostic coordinate.'),
('ar',3):('فشل التصريف: %0','Concise failure status consistent with the existing compile action.'),
('ar',4):('فشل تحميل النص البرمجي من %0','Use existing النص البرمجي terminology for script; filename remains literal.'),
('ar',5):('فشل حفظ النص البرمجي في %0','Use existing script term and natural destination preposition في.'),
('ar',10):('هناك أمر دائم يحتاج إلى اهتمام وقد تم إيقافه مؤقتًا.','Normalize modern tanwin placement consistently with adjacent messages.'),
('ca',0):('Compilació correcta','Natural concise Catalan success status instead of a literal success noun phrase.'),
('ca',6):('Línia: %0 Columna: %1','Spell out the column label; avoids unpunctuated abbreviation while fitting the adaptive cursor control.'),
('da',0):('Kompilering lykkedes','Natural status phrase rather than the mechanically compounded Kompileringssucces.'),
('da',5):('Scriptet kunne ikke gemmes i %0','Use gemme consistent with the existing Gem script action, with a natural file destination.'),
('da',13):('En ordre kunne ikke bekræftes. Gennemgå dine stående ordrer, før du genoptager dem.','Name the resumed orders with dem, matching adjacent paused-order notice.'),
('de',10):('Ein Dauerauftrag erfordert Aufmerksamkeit und wurde pausiert.','Replace formal bedarf der Aufmerksamkeit with plain UI language; retain established catalog Dauerauftrag term.'),
('de',12):('Ein Dauerauftrag benötigt nach dem Wiederverbinden eine neue Anweisung. Sie können ihn abbrechen oder den Kommandanten bitten, ihn zu ersetzen.','State the fresh instruction explicitly and use game cancellation abbrechen rather than commercial stornieren.'),
('eo',0):('Kompilo sukcesis','Natural Esperanto completed-action success status, parallel to Kompilo malsukcesis.'),
('eo',4):('Malsukcesis ŝargi la skripton el %0','Use a definite script and source-file preposition el.'),
('eo',8):('Kontrolu la enigitan JavaScript-kodon kaj ĝian rimeduzon antaŭ ol rekomenci ĉi tiun ludon.','Specify embedded JavaScript code, and use direct review/check instruction Kontrolu.'),
('eo',11):('La konekto ŝanĝiĝis. Kontrolu viajn paŭzitajn daŭrajn ordonojn antaŭ ol rekomenci ilin.','Use direct check instruction consistently rather than an unnecessary revise ambiguity.'),
('eo',13):('Ordono ne povis esti konfirmita. Kontrolu viajn daŭrajn ordonojn antaŭ ol rekomenci ilin.','Use consistent check instruction while preserving confirmation failure and resume target.')}
base_reasons=[
'Clear successful compilation status using the script-editor register.',
'Natural diagnostic wrapper; line and column and diagnostic slots are intact.',
'Clear compilation failure; all four diagnostic coordinates/slots remain intact.',
'Clear failed compilation with a literal diagnostic placeholder.',
'Natural script-file loading failure with the filename slot preserved.',
'Natural script-file saving failure with the filename slot preserved.',
'Clear compact line/column cursor label with both numbers intact.',
'Clear stopped running-game state rather than a match-start failure.',
'Grammatical remediation referring to embedded JavaScript and resource use before restarting.',
'Built-in landscape fallback is explicit, and generator identifier is preserved.',
'Persistent commander instruction requires attention and is already paused.',
'Connection change and paused persistent instructions are explicit; resumption remains user action.',
'Fresh instruction after reconnection and the cancel/commander replacement choices are explicit.',
'Confirmation failure and the review-before-resuming instruction are grammatical.',
'In-flight prior command, retained new message, and reopening commander for resend are explicit.',
'Concise command receipt acknowledgment preserving exact user text placeholder.',
'Failed acknowledgment and retained message/retry action are clear.',
'Update failure, pause on this device only, and retrying the relevant control are explicit.']
entries=[]; finals=[]
for l in locales:
 rows=[e for e in candidate if e['locale']==l]; assert len(rows)==18
 for i,e in enumerate(rows):
  v=e['translation']; new,reason=edits.get((l,i),(v,base_reasons[i])); assert sorted(re.findall(r'%\d+',v))==sorted(re.findall(r'%\d+',new))
  entries.append({'locale':l,'native_code':e['native_code'],'key':e['key'],'source':e['value'],'input':v,'proposed':new,'source_sha256':sha(e['value']),'input_sha256':sha(v),'proposed_sha256':sha(new),'actual_reading':True,'context_examined':e['context'],'decision':'replace' if v!=new else 'accept','reason':reason,'confidence':'medium','proposed_origin':'Manual editorial revision' if v!=new else 'Semantic candidate retained after independent editorial reading'})
  f=e.copy();f['translation']=new;f['origin']='Editorial candidate; requires semantic recheck and adversarial review';finals.append(f)
report={'reviewer_agent':'/root/compat_editor','review_role':'Independent editorial reviewer','certification':'Agent-reviewed only; not native-human certification. No old3393 approval implied.','source_sha256':d['source_sha256'],'input_file':str(cp),'input_file_sha256':sha(cp.read_text()),'examined_count':len(entries),'proposed_correction_count':sum(e['decision']=='replace' for e in entries),'per_locale_counts':{l:18 for l in locales},'entries':entries,'accepted_terminology_notes':[{'locale':'de','term':'Dauerauftrag','decision':'Retain established native catalog term for this bounded delta. Existing commander settings explicitly use it for standing game instructions; adjacent Befehl remains one-shot command. Banking sense noted, not an unresolved semantic question.'}],'unresolved_questions':[]}
(p/'editorial-01.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(p/'editorial-01-proposed-corrections.json').write_text(json.dumps([e for e in entries if e['decision']=='replace'],ensure_ascii=False,indent=2)+'\n');out=c.copy();out['entries']=finals;out['editorial_report_sha256']=sha((p/'editorial-01.json').read_text());(p/'editorial-final-01.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('read',len(entries),'edits',report['proposed_correction_count'],'candidate',sha((p/'editorial-final-01.json').read_text()))
