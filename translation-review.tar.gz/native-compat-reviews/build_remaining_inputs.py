import json,re,hashlib
from pathlib import Path
base=Path('artifacts/bulgarian'); kit=base/'kit-v3-native-compat'; out=base/'native-compat-reviews';first=json.loads((out/'semantic-input-01.json').read_text()); proto=first['entries'][:18]
locales='es eu el fa fi fr hi hu id it ja ko nl pl pt-PT ro ru sl sk sr-Cyrl sv sw tr uk ur vi zh-Hans zh-Hant'.split();aliases={'el':'gr','sl':'si','pt-PT':'pt','sr-Cyrl':'sr','zh-Hans':'zh-cn','zh-Hant':'zh-tw'}
def parse(p):return dict(re.findall(r'^(\[[^\n]+\])\n([^\n]*)',p.read_text(),re.M))
for n in range(4):
 ls=locales[n*7:n*7+7]; entries=[]; refs={};files={}
 for l in ls:
  code=aliases.get(l,l);draft=kit/'drafts'/l/f'texts.{code}.txt';d=parse(draft);old=Path(f'data/texts.{code}.txt');o=parse(old);adopt=base/f'native-compat-{l}-component-adoption.json';ad={e['key']:e for e in json.loads(adopt.read_text())['entries']} if adopt.exists() else {}
  for p in proto:
   e={k:p[k] for k in ('key','value','context')};e.update(locale=l,native_code=code,translation=d[p['key']],origin=ad.get(p['key'],{}).get('origin','Validated Google NMT draft; not linguistic approval.'));entries.append(e)
  terms=first['references']['ar']['terms'];refs[l]={'existing_native_file':str(old),'old_file_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'terms':[{'key':t['key'],'source':t['source'],'translation':o.get(t['key'],'')} for t in terms]}
  for key in ('[open commander]','[settings The commander may follow up on standing orders. Follow-ups use credits; installed orders keep running without credits.]'):
   refs[l]['terms'].append({'key':key,'translation':o.get(key,'')})
  files[str(draft)]=hashlib.sha256(draft.read_bytes()).hexdigest()
  if adopt.exists():files[str(adopt)]=hashlib.sha256(adopt.read_bytes()).hexdigest()
 obj={'scope':first['scope'],'source_sha256':first['source_sha256'],'locales':ls,'entries':entries,'references':refs,'frozen_input_files':files,'requirements':first['requirements']}
 f=out/f'semantic-input-{n+2:02}.json';assert not f.exists();f.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
