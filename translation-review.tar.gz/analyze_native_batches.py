from pathlib import Path
import json,gzip,hashlib,sys
from PIL import Image,ImageDraw
tag=sys.argv[1]if len(sys.argv)>1 else '16cefd';base=Path('artifacts/bulgarian/native-captures');base=base if tag=='16cefd' else base/'font-corrected';selection=[];matrices=[]
inputs=Path('artifacts/bulgarian/native-matrix-input-'+tag+'/render-input/bg');expected=set()
for surface in ['native','online']:
 for key,value in json.loads((inputs/(surface+'.json')).read_text()).items():
  if isinstance(value,str):expected.add((surface,key,''))
  else:
   for branch in value:expected.add((surface,key,branch))
assert len(expected)==6263
for presentation in ['desktop','phone']:
 aggregate={'presentation':presentation,'expected_samples':37578,'batches':[]};seen=set()
 for size in [10,13,20]:
  for scale in [1,2]:
   folder=base/f'{presentation}-matrix-{size}-scale-{scale}';path=folder/'font-matrix.json'
   assert path.exists(),f'Missing complete batch {path}'
   d=json.load(open(path));samples=d['samples'];assert len(samples)==6263
   assert all(x['size']==size and x['scale']==scale for x in samples)
   tokens={(x['surface'],x['key'],x['branch'],x['size'],x['scale'])for x in samples};assert len(tokens)==6263;assert {(x[0],x[1],x[2])for x in tokens}==expected;assert not tokens&seen;seen|=tokens
   lines=[line for sample in samples for line in sample['lines']]
   summary={'folder':str(folder),'size':size,'scale':scale,'samples':len(samples),'unique_source_keys':len({(x['surface'],x['key'])for x in samples}),'glyph_missing_samples':sum(not x['has_glyphs']for x in samples),'drawn_width_failures':sum(not x['drawn_fits_width']for x in lines),'drawn_height_failures':sum(not x['drawn_fits_height']for x in lines),'actual_viewport_width_failures':sum(line['x']+line['drawn_width']/sample['scale']>d['logical_width'] for sample in samples for line in sample['lines']),'actual_viewport_height_failures':sum(line['y']+line['drawn_height']/sample['scale']>d['logical_height'] for sample in samples for line in sample['lines']),'raw_width_diagnostics':sum(not x['fits_width']for x in lines),'raw_height_diagnostics':sum(not x['fits_height']for x in lines),'raster_pages':len(list(folder.glob('font-*.png'))),'selected':[],'evidence_identity':d['evidence_identity']}
   pages=sorted(folder.glob(f'font-{size}-scale-{scale}-page-*.png'));assert pages
   for p in dict.fromkeys([pages[0],pages[len(pages)//2],pages[-1]]):selection.append(p);summary['selected'].append(str(p))
   compressed=folder/'font-matrix.json.gz'
   with open(path,'rb')as inp,gzip.open(compressed,'wb',compresslevel=9)as out:out.write(inp.read())
   summary['complete_diagnostics_gzip']=str(compressed);summary['uncompressed_diagnostics_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();selection.append(compressed);aggregate['batches'].append(summary)
 assert len(seen)==37578;aggregate['samples']=len(seen)
 aggregate['counts']={k:sum(x[k]for x in aggregate['batches'])for k in ['glyph_missing_samples','drawn_width_failures','drawn_height_failures','raw_width_diagnostics','raw_height_diagnostics','actual_viewport_width_failures','actual_viewport_height_failures','raster_pages']}
 thumbs=[]
 for batch in aggregate['batches']:
  for name in batch['selected']:
   p=Path(name);im=Image.open(p).convert('RGB');im.thumbnail((320,280));tile=Image.new('RGB',(340,310),'#eeeeee');tile.paste(im,((340-im.width)//2,10));ImageDraw.Draw(tile).text((5,294),p.name,fill='black');thumbs.append(tile)
 sheet=Image.new('RGB',(340*6,310*3),'white')
 for i,im in enumerate(thumbs):sheet.paste(im,((i%6)*340,(i//6)*310))
 contact=base/f'{presentation}-selected-pages-contact.png';sheet.save(contact);selection.append(contact);aggregate['contact_sheet']=str(contact);matrices.append(aggregate)
# Include all actual production screen/game/editor and separately labeled synthetic probe output, never failed/incomplete attempts.
for folder in sorted(base.iterdir()):
 if not folder.is_dir()or not folder.name.startswith(('desktop-','phone-'))or '-matrix-'in folder.name or folder.name.endswith('-matrix'):continue
 selection.extend(sorted(folder.glob('*.png')));selection.extend(sorted(folder.glob('*.json')))
for parent in ['final-ui','final-api']:
 folder=base/parent
 if folder.exists():
  selection.extend(sorted(folder.rglob('*.png')))
  selection.extend(sorted(p for p in folder.rglob('*.json')if 'profile'not in p.parts))
for name in ['baseline-surface-validation.json','matrix-selector-raster-equivalence.json','matrix-selector-validation.json']:
 if (base/name).exists():selection.append(base/name)
selection.append(Path('artifacts/bulgarian/native-matrix-source-'+tag+'/frozen-source.json'))
(base/'matrix-diagnostics.json').write_text(json.dumps(matrices,ensure_ascii=False,indent=2)+'\n');selection.append(base/'matrix-diagnostics.json');selection.extend(sorted(base.glob('execution*.json')))
for name in ['visual-inspection.json','final-validation.json','producer-libraries.txt']:
 if (base/name).exists():selection.append(base/name)
(base/'publish-selection.json').write_text(json.dumps({'paths':[str(p)for p in dict.fromkeys(selection)],'limits':'Bounded first/middle/last font pages per size/scale/viewport; all actual screen/game/editor and synthetic probe images; full raster matrix remains local. Complete diagnostics retained losslessly. Selection is not a claim every page/line was visually read; actual inspected images are listed separately.'},indent=2)+'\n')
print(json.dumps([{k:v for k,v in d.items()if k!='batches'}for d in matrices],indent=2))
