from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path.cwd();B=R/'artifacts/bulgarian';k=B/'terrain-supplement-v5';module=B/'terrain-supplement-tool-shadow/tools/localization/translation_program.py';assert hashlib.sha256(module.read_bytes()).hexdigest()=='47f5f68af625050ae0a178c22aba459d34bcc18f9f524ad915102228a12f1004';ledger=k/'machine/spend-ledger.json';assert len(json.loads(ledger.read_text())['reservations'])==84
command=[sys.executable,str(module),'machine-draft','--output',str(k),'--locale','bg','--project','bradley-personal-20261027','--max-cost-usd','10','--rate-per-million','20','--only-keys',str(k/'delta-only-keys.json')]
started=time.monotonic();log=B/'machine-draft-terrain-supplement-bg.log';terminated=False
with log.open('w') as out:
 process=subprocess.Popen(command,cwd=R,stdout=out,stderr=subprocess.STDOUT)
 while process.poll() is None:
  state=json.loads(ledger.read_text())['reservations']
  # Do not allow an automatic retry after a failed/ambiguous paid attempt.
  if len(state)>84 and state[-1]['state']=='failed-or-ambiguous':process.terminate();terminated=True;break
  time.sleep(.05)
 code=process.wait()
(k/'bg-paid-invocation.json').write_text(json.dumps({'command':command,'exit_code':code,'seconds':round(time.monotonic()-started,3),'log':str(log.relative_to(R)),'stopped_before_retry_after_ambiguous_failure':terminated},indent=2)+'\n')
print(log.read_text());raise SystemExit(code)
