import importlib.util,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('program',ROOT/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
base=ROOT/'artifacts/bulgarian';drafts=p.catalog_paths(base/'kit','bg')
checked=p.check_draft(base/'kit','bg');assert not checked['errors'] and not checked['untranslated'],checked
native,errors=p.CHECKER.read_table(drafts['native']);assert not errors
english=json.loads((base/'kit/source/native.json').read_text()); online=json.loads(drafts['online'].read_text()); ens=json.loads((base/'kit/source/online.json').read_text())
# This script may only run after all three linguistic reviewers approve final hashes.
for role in ('semantic','editor','adversarial'):
 for surface in ('native','online'):
  name=f'{role}-{surface}-final-examined.json' if role!='adversarial' else f'{role}-{surface}-examined.json'
  assert (base/'linguistics'/name).exists(),name
shutil.copyfile(drafts['native'],ROOT/'data/texts.bg.txt');shutil.copyfile(drafts['online'],ROOT/'platform/packages/i18n/locales/bg.json')
for name in ('data/texts.list.txt','data/texts.incomplete.txt'):
 path=ROOT/name;text=path.read_text();assert 'data/texts.bg.txt' not in text;path.write_text(text.rstrip()+'\ndata/texts.bg.txt\n')
path=ROOT/'platform/packages/i18n/src/locales.ts';text=path.read_text();text=text.replace('] as const;',"  {\n    code: 'bg',\n    gameCode: 'bg',\n    name: 'Български',\n    dir: 'ltr',\n  },\n] as const;");path.write_text(text)
path=ROOT/'platform/packages/i18n/src/index.ts';text=path.read_text();needle='const loaders: Record<string, () => Promise<{ default: Catalog }>> = {';assert needle in text;text=text.replace(needle,needle+"\n  bg: () => import('../locales/bg.json', { with: { type: 'json' } }),");path.write_text(text)
path=ROOT/'platform/packages/i18n/test/runtime.test.ts';text=path.read_text().replace('contains 36 unique game catalog mappings','contains 37 unique game catalog mappings').replace('toHaveLength(36)','toHaveLength(37)').replace('size).toBe(36)','size).toBe(37)');path.write_text(text)
# Only individually reviewed identical values enter the release exception lists.
native_review=json.loads((base/'linguistics/editor-native-english-identical.json').read_text()); approved={x['key']:x for x in native_review}
values=[]
for key,value in native.items():
 if value and value==english[key]:
  assert key in approved and approved[key]['reason'],key
  values.append(value)
path=ROOT/'test/translation_shared_values.json';data=json.loads(path.read_text());data['shared_vocabulary']['texts.bg.txt']=sorted(set(values)-set(data['standard_names_and_key_legends']));p.write_json(path,data)
review=json.loads((base/'linguistics/editor-online-english-identical.json').read_text());approved={x['key']:x for x in review}; values=[]
for key,value in online.items():
 variants={'other':value} if isinstance(value,str) else value
 if any(v==key for v in variants.values()):
  assert key in approved and approved[key]['reason'],key
  values.append(key)
path=ROOT/'platform/packages/i18n/shared-values.json';data=json.loads(path.read_text());data['bg']=sorted(values);p.write_json(path,data)
print('Registered bg; native identical exceptions',len(values))
