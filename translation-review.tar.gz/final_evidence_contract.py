"""Explicit final publication scope; the translation-program audit is unchanged."""
import hashlib,json,re
from pathlib import Path
REQUIRED_GATES=('language_brief','source_based_pilot','structural','desktop_rendering','phone_rendering','browser_startup','native_platforms','browser_platforms','mobile_platforms')
UNAVAILABLE_PLATFORM_GATES={'native_platforms','browser_platforms','mobile_platforms'}
LAYOUT_FINDINGS={'statistics-empty-notice-wrap','script-editor-compact-status-and-labels'}
def validate_final_evidence(path,base,context,freeze):
 def require(condition,message):
  if not condition:raise ValueError('Final evidence: '+message)
 def reference(ref):
  require(isinstance(ref,dict)and set(ref)=={'path','sha256'},'each report reference requires only path and sha256')
  name=ref['path'];digest=ref['sha256'];require(isinstance(name,str)and name and not Path(name).is_absolute()and '..'not in Path(name).parts,'report paths must be relative to the evidence root without traversal')
  require(isinstance(digest,str)and re.fullmatch('[0-9a-f]{64}',digest),'invalid report SHA256')
  original=base/name;require(original.is_file()and not original.is_symlink(),'missing/nonregular input '+name)
  frozen=freeze(original);require(hashlib.sha256(frozen.read_bytes()).hexdigest()==digest,'missing/mismatched input '+name)
  return name,digest
 frozen_record=freeze(path);data=json.loads(frozen_record.read_text())
 require(data.get('schema_version')==1,'unsupported schema version')
 mode=data.get('mode');require(mode in ('scoped-verification','full-audit'),'mode must be scoped-verification or full-audit')
 for field in ('revision','source_sha256','catalog_sha256'):require(data.get(field)==context[field],field+' does not match the current frozen inputs')
 require(isinstance(data.get('scope'),str)and data['scope'].strip(),'scope is required')
 require(isinstance(data.get('limits'),list)and data['limits']and all(isinstance(x,str)and x.strip()for x in data['limits']),'explicit limits are required')
 require(isinstance(data.get('reports'),list)and data['reports'],'reports are required')
 declared={}
 for ref in data['reports']:
  name,digest=reference(ref);require(name not in declared,'duplicate report '+name);declared[name]=digest
 def declared_refs(refs):
  require(isinstance(refs,list),'evidence must be a list of report references')
  result=[]
  for ref in refs:
   pair=reference(ref);require(declared.get(pair[0])==pair[1],'evidence is not listed in reports: '+pair[0]);result.append(pair)
  require(len(result)==len(set(result)),'duplicate evidence references');return set(result)
 require(data.get('review_record')==context['review_record_ref'],'review record identity is stale')
 declared_refs([data['review_record']]);record=context['review_record']
 require(json.loads(freeze(base/data['review_record']['path']).read_text())==record,'review record body differs from audited context')
 def actual_refs(refs,evidence_root=None):
  result=[]
  for ref in refs:
   require(isinstance(ref,dict)and ref.get('path')and ref.get('sha256'),'review record contains malformed evidence')
   p=Path(ref['path']);p=p if p.is_absolute()else(evidence_root or context['review_evidence_root'])/p
   require(p.resolve().is_relative_to(base.resolve()),'review evidence escapes root')
   result.append({'path':str(p.resolve().relative_to(base.resolve())),'sha256':ref['sha256']})
  return declared_refs(result)
 def finding(f):
  require(f.get('severity')in ('critical','major','minor'),'finding severity must be canonical')
  require(f.get('state')=='resolved'or(f.get('severity')=='minor'and f.get('state')=='accepted'and bool(f.get('reason','').strip())),'unresolved finding '+str(f.get('id',f.get('key'))))
 for f in record.get('findings',[]):finding(f)
 require(isinstance(data.get('findings'),list),'findings list is required, even when empty')
 for f in data['findings']:finding(f)
 technical={f.get('id'):f for f in record.get('technical_findings',[])}
 require(LAYOUT_FINDINGS<=set(technical),'both layout findings must remain represented')
 for f in record.get('technical_findings',[]):
  if f.get('severity')in ('critical','major'):require(f.get('state')=='resolved','pending critical/major technical finding '+str(f.get('id')))
 for name in LAYOUT_FINDINGS:
  f=technical[name];require(f.get('state')=='resolved'and f.get('evidence'),'layout finding not resolved with evidence: '+name);actual_refs(f['evidence'],base)
 gates=data.get('gates');require(isinstance(gates,dict)and set(gates)==set(REQUIRED_GATES),'exactly all nine gates are required')
 unavailable=[]
 for gate,item in gates.items():
  require(isinstance(item,dict)and item.get('status')in ('passed','unavailable'),'pending/unknown gate '+gate)
  require(isinstance(item.get('scope'),str)and item['scope'].strip(),'gate scope required: '+gate)
  actual=record.get('gates',{}).get(gate,{})
  if item['status']=='passed':
   require(actual.get('passed')is True,'gate has not passed in the actual review record: '+gate)
   refs=declared_refs(item.get('evidence'));require(refs and refs==actual_refs(actual.get('evidence',[])),'gate evidence does not exactly match actual record: '+gate)
  else:
   require(mode=='scoped-verification'and gate in UNAVAILABLE_PLATFORM_GATES,'unavailable coverage cannot waive this gate: '+gate)
   require(actual.get('passed')is False,'unavailable gate must remain unpassed: '+gate)
   require(isinstance(item.get('reason'),str)and item['reason'].strip(),'unavailable gate reason required: '+gate)
   refs=declared_refs(item.get('evidence',[]));require(refs==actual_refs(actual.get('evidence',[])),'unavailable gate evidence differs from actual record: '+gate);unavailable.append(gate)
 coverage=data.get('coverage');require(isinstance(coverage,list)and coverage,'explicit tested/unavailable coverage is required');mapped=set();ids=set()
 for item in coverage:
  require(isinstance(item,dict)and isinstance(item.get('id'),str)and item['id']and item['id']not in ids,'coverage IDs must be unique');ids.add(item['id'])
  require(item.get('status')in ('verified','unavailable')and 'passed'not in item,'coverage must use verified/unavailable status, never passed=true for unavailable')
  require(isinstance(item.get('scope'),str)and item['scope'].strip(),'coverage scope required')
  gate_ids=item.get('gate_ids');require(isinstance(gate_ids,list)and gate_ids and set(gate_ids)<=set(REQUIRED_GATES),'coverage gate IDs required')
  refs=declared_refs(item.get('evidence',[]))
  if item['status']=='verified':require(bool(refs),'verified coverage needs actual evidence')
  else:
   require(mode=='scoped-verification','full audit cannot include unavailable coverage')
   require(isinstance(item.get('reason'),str)and item['reason'].strip(),'unavailable coverage reason required')
   require(set(gate_ids)<=set(unavailable),'unavailable coverage requires explicitly unpassed platform gate');mapped.update(gate_ids)
 require(mapped==set(unavailable),'every unavailable gate needs explicit unavailable coverage')
 allowed={gate+' is pending or lacks evidence'for gate in unavailable}
 require(not(set(context['audit_issues'])-allowed),'non-waivable translation audit issues: '+repr(sorted(set(context['audit_issues'])-allowed)))
 if mode=='full-audit':require(not context['audit_issues']and not unavailable,'full audit requires all nine gates and zero audit issues')
 return {'revision':data['revision'],'source_sha256':data['source_sha256'],'catalog_sha256':data['catalog_sha256'],'review_record':data['review_record'],'mode':mode,'scope':data['scope'],'limits':data['limits'],'coverage':coverage,'gates':gates,'unavailable_gates':sorted(unavailable),'full_audit_passed':not context['audit_issues']and not unavailable,'audit_issues_retained':context['audit_issues'],'publication_ready_for_declared_scope':True,'record':{'path':str(path.relative_to(base)),'sha256':hashlib.sha256(frozen_record.read_bytes()).hexdigest()},'report_count':len(declared)}
