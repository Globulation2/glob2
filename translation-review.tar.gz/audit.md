# Bulgarian localization surface audit

Read-only audit, 2026-10-31. No tracked file edits. This is technical coverage evidence, not linguistic approval.

## Integration paths

- Native selectable inventory: `data/texts.list.txt`; synchronized completion rows `data/texts.incomplete.txt`; game catalog `data/texts.bg.txt`, key order `data/texts.keys.txt`.
- First-run system selection: `src/app/SystemLanguage.cpp`, `codes` needs bg; explicit wrong-script rejection can use `writtenForms` bg/Cyrl. `choose` already requires installed catalog.
- Online native/app/SSR inventory: `platform/packages/i18n/src/locales.ts` (bg, gameCode bg, Български, ltr). Async app loader additionally requires `src/index.ts` literal loader. Server loads all registered inventory dynamically from `src/server.ts`.
- Native equivalent-English exceptions are keyed by filename in `test/translation_shared_values.json`; new filename must exist for regression suite. Online reviewed shared strings in `platform/packages/i18n/shared-values.json`.
- `npm run i18n:browser` regenerates checked-in launcher runtime and browser/locales/bg.json. `npm run i18n:check` requires exact game/online inventory equality and fresh launcher output. Browser asset derivatives record ALL language names: regenerate via browser/derive_assets.py when name inventory changes (core cmap already supports Bulgarian).
- Translation program already supports bg draft, plural categories via Node Intl.PluralRules; status additionally requires adversarial pass for bg.

## Font evidence

`font-audit.json` has probes and SHA256. fontTools cmap check covers Bulgarian alphabet, ѝ, Ѝ, „“”’, dashes, ellipsis, decomposed и + combining grave and И + combining grave.

- `data/fonts/sans.ttf`: zero missing.
- `browser/assets/sans-core.ttf`: zero missing; survives before CJK package loading.
- `/home/bradley/glob2-design-system/assets/glob2-sans.woff2`: all Cyrillic missing, also combining grave.
- `/home/bradley/glob2-design-system/assets/nunito.woff2`: all Cyrillic missing; combining grave present.

The shared design-system WOFF2 assets are Latin subsets, so current online app, SSR sign-in and browser launcher use OS fallback for Cyrillic. Server styling: `platform/apps/api/src/web/pages.ts` BODY Nunito/system stack, H1 Glob2 Sans/DejaVu/Verdana stack; script CSS imported but Bulgarian has no script-family override. Launcher `browser/shell.html` Nunito/system stack; fonts loaded from `/signin/assets/`. New Cyrillic font, if introduced, must be included in API asset whitelist and actual container copy and standalone launcher bundle. The audit read a local design-system checkout whose recorded asset hashes match its provenance; installed pinned package identity still must be checked. Existing Russian/Ukrainian/Serbian use the same fallback arrangement, so this is shared existing behavior, not proof of Bulgarian-specific failure.

FontTools interpreter: `PYTHONPATH=/home/bradley/.cache/uv/archive-v0/XOIMT4p6kY2UzTsQ python3`. Base interpreter lacks fontTools. WOFF2 decode used system `libbrotlidec.so.1` through a temporary in-memory Python module shim; no dependencies/files installed. cmap coverage is not layout/render proof.

## Source-contract gaps and concrete player-visible paths

Native scanner `data/check_translations.py` catches bracketed keys, selected wrappers, action tables, frontend helper literal positions. It explicitly does not prove all dynamic rendered text is localized. Online `source-contract.ts` scans app/web/src JSX and browser shell; API `pageHtml` automatically translates text nodes but missing API keys fall back to English. API source tree is not scanned by current online source contract.

Concrete remaining native English path: `src/ui/screens/MusicLibraryScreen.cpp:242` throws `Invalid music catalogue.` and line 259 throws `Music download checksum failed.`; catch at line 278 copies e.what() to displayed notice without musicText. Raw transport error at line 230 and server message at 235 also show directly. Music library `src/audio/MusicLibrary.cpp` require messages include Missing or duplicate music metadata, Invalid ZIP bounds, Music file is too large, Unsupported music metadata version, Invalid embedded cover art, Corrupt music audio, etc.; exceptions flow to MusicLibraryScreen notice (line 67/278/498). `job->error()` at line 171 likewise raw. These strings need localizable error codes or explicit catalog mapping if all shipped UI includes errors.

No broad assertion of complete source coverage follows from lexical scan success. UI review remains needed for imported map/scenario names, user-generated content, server diagnostics, custom-AI diagnostics and old SGSL embedded messages; technical identifiers/UGC should not be mechanically translated.

## Verification commands and build state

- `python3 data/check_translations.py --strict --json`.
- `python3 -m unittest test.test_translations`.
- `cd platform && npm run i18n:check` and focused i18n runtime/source-contract tests.
- `GLOB2_SDL3_PREFIX=/absolute/current/prefix python3 test/test_font_coverage.py` (requires shared SDL3_ttf).
- `python3 tools/dev_build.py translation-preview-harness engine-tests`.
- Preview CLI: `TranslationPreviewHarness matrix ROOT INPUT OUTPUT W H`; `screen ROOT INPUT OUTPUT W H main|settings|settings-audio|lobby|lobby-players`; `game ROOT INPUT OUTPUT W H gameplay|tutorial[:LESSON-ID]`. INPUT native.json, online.json, metadata.json. Metadata must preserve catalog hash identity; frozen sources needed during build/capture.

System SDL3 exists but SDL3_ttf/image/net unavailable. All six managed Linux-x86_64-* root manifests are Android targets; build-* SDL prefixes are Emscripten. Do not use them as native libraries. Older native prefixes `/home/bradley/glob2-claude/build/sdl3/prefix` and glob2-torus equivalent have matching SDL versions but configuration 11 and no HarfBuzz; initial build using former was interrupted before compilation, evidence log `native-build-managed.log` is not validation.

Current correct pinned dependency build plus harness/engine-tests running session 73684:

```
python3 scons/sdl3_dependencies.py --prefix artifacts/bulgarian/sdl3/prefix --work artifacts/bulgarian/sdl3/sources --jobs 8 > artifacts/bulgarian/sdl3-build.log 2>&1 && GLOB2_SDL3_PREFIX="$PWD/artifacts/bulgarian/sdl3/prefix" python3 tools/dev_build.py translation-preview-harness engine-tests > artifacts/bulgarian/native-build-pinned.log 2>&1
```

Parent owns polling/completion after audit agent exits. No successful binary/render/platform claim yet.
