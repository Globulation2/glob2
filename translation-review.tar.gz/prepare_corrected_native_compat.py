from pathlib import Path
from decimal import Decimal
import json,hashlib,subprocess,shutil,sys,importlib.util
R=Path.cwd();B=R/'artifacts/bulgarian';old=B/'kit-v3-native-compat';new=B/'kit-v3-native-compat-v2';tool=B/'legacy-native-drafting-v2/stage/tools/localization/translation_program.py';expected='47f5f68af625050ae0a178c22aba459d34bcc18f9f524ad915102228a12f1004';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(tool)==expected;assert not new.exists(),'Fresh destination required'
snapshot={str(p.relative_to(old)):sha(p)for p in old.rglob('*')if p.is_file()};v1=B/'legacy-native-drafting/stage/tools/localization/translation_program.py';assert sha(v1)=='7c0036ca79969accc0224004089b7e76ed1c7f7832949bde9f25448d660b1a7d'
# Populate only the V2 source shadow from the already-frozen authoritative source snapshot.
source=B/'source-stage-v3';shadow=tool.parents[2]
for p in source.rglob('*'):
 if p.is_file():q=shadow/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
spec=importlib.util.spec_from_file_location('v2',tool);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
locales=['bg',*m.LEGACY_NATIVE_LOCALES];assert len(locales)==36 and 'br' not in locales and 'pt-BR' in locales
command=[sys.executable,str(tool),'prepare','--output',str(new),'--locales',*locales]
r=subprocess.run(command,text=True,capture_output=True,check=True);(B/'native-compat-v2-prepare.log').write_text(r.stdout+r.stderr)
prior=json.loads((old/'manifest.json').read_text());manifest=json.loads((new/'manifest.json').read_text());assert prior['source_sha256']==manifest['source_sha256'];assert prior['source_files']==manifest['source_files'];assert prior['source_snapshots']==manifest['source_snapshots']
shutil.copytree(old/'machine',new/'machine');shutil.copy2(old/'delta-only-keys.json',new/'delta-only-keys.json')
# Rejected drafts remain bit-identical quarantined evidence, never an active draft locale.
rejected=new/'rejected/wrong-br-breton-mapping';rejected.mkdir(parents=True);shutil.copytree(old/'drafts/br',rejected/'drafts');shutil.copytree(old/'machine/br',rejected/'provider-history')
# Historical provider br data also stays in machine/br to preserve the complete copied history.
carried={}
for locale in locales:
 if locale=='pt-BR':continue
 shutil.copytree(old/'drafts'/locale,new/'drafts'/locale)
 carried[locale]={str(p.relative_to(new/'drafts'/locale)):sha(p)for p in (new/'drafts'/locale).rglob('*')if p.is_file()}
 # Review record bytes are preserved; source identity is identical and catalogs are unchanged.
 shutil.copy2(old/'reviews'/(locale+'.json'),new/'reviews'/(locale+'.json'))
subprocess.run([sys.executable,str(tool),'draft','--output',str(new),'--locale','pt-BR'],check=True,capture_output=True,text=True)
keys=(new/'source/native-keys.txt').read_text().splitlines();ids=json.loads((new/'delta-only-keys.json').read_text());delta=[i[len('native:'):]for i in ids];assert len(delta)==18 and len(set(delta))==18 and all(i.startswith('native:')for i in ids)
assert set(keys)-set(delta)==set(m.CHECKER.read_table(R/'data/texts.br.txt')[0]);assert len(keys)==3411
seed,e=m.CHECKER.read_table(R/'data/texts.br.txt');assert not e and len(seed)==3393
paths=m.catalog_paths(new,'pt-BR');paths['native'].write_text(''.join(k+'\n'+seed.get(k,'')+'\n'for k in keys))
old_identity={}
for locale in locales:
 current,e=m.CHECKER.read_table(m.catalog_paths(new,locale)['native']);baseline,e2=m.CHECKER.read_table(R/'data'/('texts.'+m.game_code(locale)+'.txt'));assert not e and not e2;assert len(baseline)==3393;assert all(current[k]==v for k,v in baseline.items()),locale
 assert set(current)==set(keys);old_identity[locale]={'native_code':m.game_code(locale),'baseline_sha256':sha(R/'data'/('texts.'+m.game_code(locale)+'.txt')),'old_keys_equal':3393,'delta_blank':sum(not current[k].strip()for k in delta)}
 assert old_identity[locale]['delta_blank']==(18 if locale=='pt-BR'else 0),locale
ledger=json.loads((new/'machine/spend-ledger.json').read_text());spent=sum((Decimal(r['reserved_usd'])for r in ledger['reservations']),Decimal(0));assert len(ledger['reservations'])==82 and spent==Decimal('5.25872');assert sha(old/'machine/spend-ledger.json')==sha(new/'machine/spend-ledger.json')
native=json.loads((new/'source/native.json').read_text());invariants=json.loads((new/'source/invariants.json').read_text());protected=[m.protect_text(native[k],invariants.get('native',{}).get(k,[]) if isinstance(invariants.get('native',{}),dict)else [])[0]for k in delta]
# Use the exact command's frozen item/invariant protection authority. All these new native entries have no contract overrides.
assert sum(map(len,protected))==1196
preflight={'kit':str(new.relative_to(R)),'source_sha256':manifest['source_sha256'],'module':str(tool.relative_to(R)),'module_sha256':sha(tool),'scope':locales,'mapping':{'canonical':'pt-BR','native':m.game_code('pt-BR'),'target':m.NMT_TARGETS['pt-BR']},'prior_reservations':82,'prior_reserved_usd':str(spent),'copied_ledger_sha256':sha(new/'machine/spend-ledger.json'),'expected_new_codepoints':1196,'expected_extra_usd':'0.02392','expected_total_usd':'5.28264','carried_drafts_sha256':carried,'old_values_identity':old_identity,'original_kit_file_sha256':snapshot,'wrong_br_evidence':str(rejected.relative_to(new)),'active_pointer_before':(B/'active-machine-kit.txt').read_text(),'paid_calls_in_preparation':0}
(new/'compat-v2-preflight.json').write_text(json.dumps(preflight,ensure_ascii=False,indent=2)+'\n');(rejected/'rejection.json').write_text(json.dumps({'reason':'Native br is Brazilian Portuguese; all18 Breton drafts rejected by semantic review','active_locale':'pt-BR','no_wrong_delta_carry_forward':True,'original_native_draft_sha256':sha(old/'drafts/br/texts.br.txt'),'quarantined_native_draft_sha256':sha(rejected/'drafts/texts.br.txt')},indent=2)+'\n')
assert snapshot=={str(p.relative_to(old)):sha(p)for p in old.rglob('*')if p.is_file()};print(json.dumps({'prepared':str(new),'carried_good_locales':35,'old_values_equal_per_locale':3393,'pt_BR_blank_delta':18,'prior_reserved_usd':str(spent),'expected_charge':'0.02392'},indent=2))
