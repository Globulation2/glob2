"""Verify actual final catalog character coverage; no shaping/rendering claim."""
import hashlib
import json
from pathlib import Path
from fontTools.ttLib import TTFont
ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'artifacts/bulgarian'
def sha(data):
    return hashlib.sha256(data).hexdigest()
native = ROOT / 'data/texts.bg.txt'
online = ROOT / 'platform/packages/i18n/locales/bg.json'
kit = BASE / 'kit-v2'
assert native.read_bytes() == (kit / 'drafts/bg/texts.bg.txt').read_bytes()
assert online.read_bytes() == (kit / 'drafts/bg/bg.json').read_bytes()
texts = native.read_text().splitlines()[1::2]
for value in json.loads(online.read_text()).values():
    texts.extend([value] if isinstance(value, str) else value.values())
# Formatting controls do not have a visible glyph; whitespace is excluded.
characters = sorted({c for text in texts for c in text if ord(c) > 32 and c not in '\u200c\u200d\u200e\u200f'})
character_text = ''.join(characters)
fonts = []
for name in ('data/fonts/sans.ttf', 'browser/assets/sans-core.ttf'):
    path = ROOT / name
    with TTFont(path, lazy=True) as font:
        missing = [f'U+{ord(c):04X}' for c in characters if ord(c) not in font.getBestCmap()]
    fonts.append({'path':name, 'sha256':sha(path.read_bytes()), 'examined_characters':len(characters), 'missing':missing})
    assert not missing, (name, missing)
report = {'method':'cmap coverage of every visible final Bulgarian game and online character; actual SDL3_ttf native suite is recorded separately in font-coverage-final.log',
          'source_sha256':json.loads((kit / 'manifest.json').read_text())['source_sha256'],
          'catalog_sha256':{'native':sha(native.read_bytes()), 'online':sha(online.read_bytes())},
          'character_set_sha256':sha(character_text.encode()),
          'character_set_serialization':'Unique visible codepoints sorted ascending and concatenated as UTF-8; excludes <=U+0020 and U+200C/U+200D/U+200E/U+200F',
          'characters':[f'U+{ord(c):04X}' for c in characters], 'fonts':fonts,
          'limits':'Glyph presence does not establish line breaking, shaping, clipping, pixel fit or platform rendering.'}
previous_path = BASE / 'visual-refinement-v1/final-catalog-font-coverage.json'
previous = json.loads(previous_path.read_text())
assert previous['characters'] == report['characters']
assert previous['character_set_sha256'] == report['character_set_sha256']
assert [(f['path'], f['sha256']) for f in previous['fonts']] == [(f['path'], f['sha256']) for f in report['fonts']]
report['visual_refinement_invariance'] = {'baseline':str(previous_path.relative_to(BASE)), 'baseline_sha256':sha(previous_path.read_bytes()), 'previous_catalog_sha256':previous['catalog_sha256'], 'character_set_unchanged':True, 'font_bytes_unchanged':True}
ttf_log = BASE / 'font-coverage-final.log'
assert 'OK' in ttf_log.read_text()
report['sdl3_ttf_verification'] = {'log':'font-coverage-final.log', 'log_sha256':sha(ttf_log.read_bytes()), 'test':'test/test_font_coverage.py', 'test_sha256':sha((ROOT / 'test/test_font_coverage.py').read_bytes()), 'scope':'Both native sans.ttf and browser sans-core.ttf checked separately through SDL3_ttf for final Bulgarian catalog characters plus ѝ, Ѝ, Bulgarian quotation/punctuation and decomposed и/И + U+0300.', 'result':'Passing refreshed log supplied by parent task; glyph presence is separate from shaping/rendering.', 'unchanged_final_catalog_glyph_set_proved':True}
(BASE / 'final-catalog-font-coverage.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('catalog_sha256','character_set_sha256','fonts')},indent=2))
