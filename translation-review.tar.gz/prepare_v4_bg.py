from pathlib import Path
from decimal import Decimal
import hashlib,json,shutil,importlib.util,subprocess,sys
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'kit-v4';old=B/'kit-v3-native-compat-v2';shadow=B/'v4-tool-shadow';assert not K.exists();assert not shadow.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert revision=='3100417199fd8889866fbfcb5c48aaf3c5d224b6'
shutil.copytree(B/'legacy-native-drafting-v2/stage',shadow,ignore=shutil.ignore_patterns('__pycache__'));tool=shadow/'tools/localization/translation_program.py';assert sha(tool)=='47f5f68af625050ae0a178c22aba459d34bcc18f9f524ad915102228a12f1004'
spec=importlib.util.spec_from_file_location('v4tool',tool);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
for name in m.SOURCE_PATHS:
 dest=shadow/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/name,dest)
m.prepare(K,root=shadow,locales=('bg',));m.draft(K,'bg');manifest=json.loads((K/'manifest.json').read_text());assert manifest['native_keys']==3425 and manifest['online_keys']==2843
baseline,errors=m.CHECKER.read_table(old/'drafts/bg/texts.bg.txt');assert not errors and len(baseline)==3411
live,errors=m.CHECKER.read_table(R/'data/texts.bg.txt');assert not errors
assert all(live[k]==v for k,v in baseline.items())
keys=(K/'source/native-keys.txt').read_text().splitlines();delta=[k for k in keys if k not in baseline];audit=json.loads((B/'master-source-delta.json').read_text());assert set(delta)=={e['key']for e in audit['entries']} and len(delta)==14
native=K/'drafts/bg/texts.bg.txt';native.write_text(''.join(k+'\n'+baseline.get(k,'')+'\n'for k in keys));shutil.copy2(R/'platform/packages/i18n/locales/bg.json',K/'drafts/bg/bg.json');assert sha(K/'drafts/bg/bg.json')=='69de8f4cf769924db105fe166cf25a352967e5ca3263951dd1753c3d8f263813'
shutil.copytree(old/'machine',K/'machine');shutil.copytree(old/'rejected',K/'rejected');ledger=json.loads((K/'machine/spend-ledger.json').read_text());spent=sum((Decimal(r['reserved_usd'])for r in ledger['reservations']),Decimal());assert len(ledger['reservations'])==83 and spent==Decimal('5.28264')
ids=['native:'+k for k in delta];(K/'delta-only-keys.json').write_text(json.dumps(ids,ensure_ascii=False,indent=2)+'\n');source=json.loads((K/'source/native.json').read_text());assert sum(len(m.protect_text(source[k])[0])for k in delta)==453
record={'revision':revision,'tool':str(tool.relative_to(R)),'tool_sha256':sha(tool),'source_sha256':manifest['source_sha256'],'source_files':manifest['source_files'],'scope':['bg'],'mapping':{'locale':'bg','native':'bg','target':m.NMT_TARGETS['bg']},'delta':ids,'old_native_values_exact':3411,'baseline_native_sha256':sha(old/'drafts/bg/texts.bg.txt'),'online_sha256':sha(K/'drafts/bg/bg.json'),'prior_reservations':83,'prior_reserved_usd':str(spent),'copied_ledger_sha256':sha(K/'machine/spend-ledger.json'),'copied_provider_history':{str(p.relative_to(old/'machine')):sha(p)for p in (old/'machine').rglob('*')if p.is_file()},'codepoints':453,'expected_new_usd':'0.00906','expected_total_usd':'5.29170','previous_active_kit':(B/'active-machine-kit.txt').read_text(),'review_status':'New14 blank; no approvals carried to changed source automatically; all gates pending'}
(K/'preflight.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps(record,ensure_ascii=False)[:650])
