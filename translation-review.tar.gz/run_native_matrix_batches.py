from pathlib import Path
import json,os,subprocess,time,hashlib,sys
root=Path.cwd();tag=sys.argv[2] if len(sys.argv)>2 else '16cefd';base=root/'artifacts/bulgarian/native-captures';base=base if tag=='16cefd' else base/'font-corrected';base.mkdir(exist_ok=True);binary=Path(sys.argv[1]).resolve();kit=root/('artifacts/bulgarian/native-matrix-input-'+tag+'/render-input/bg');source_root=root/('artifacts/bulgarian/native-matrix-source-'+tag);producer=hashlib.sha256(binary.read_bytes()).hexdigest();record=base/'execution-matrix-batches.json'
entries=json.loads(record.read_text())['jobs'] if record.exists() else []
combinations=[(p,w,h,z,s)for p,w,h in [('desktop',1280,1024),('phone',480,960)]for z in [10,13,20]for s in [1,2]]
if tag!='16cefd':
 priority=[('desktop',1280,1024,20,2),('desktop',1280,1024,13,2),('phone',480,960,20,2)]
 combinations=priority+[x for x in combinations if x not in priority]
for presentation,w,h,size,scale in combinations:
 tag=f'{presentation}-matrix-{size}-scale-{scale}';output=base/tag;output.mkdir(exist_ok=True);manifest=output/'font-matrix.json'
 if manifest.exists():
  m=json.loads(manifest.read_text());assert len(m['samples'])==6263 and m['selected_size']==size and m['selected_scale']==scale;assert m['evidence_identity']['executable_sha256']==producer
  print('RETAIN complete',tag,flush=True);continue
 profile=output/'profile';profile.mkdir(exist_ok=True)
 env=dict(os.environ,LD_LIBRARY_PATH=str(root/'artifacts/bulgarian/sdl3/prefix/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''),GLOB2_USER_DATA_DIR=str(profile/'user'),XDG_DATA_HOME=str(profile/'data'),XDG_CONFIG_HOME=str(profile/'config'),XDG_CACHE_HOME=str(profile/'cache'),SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='x11')
 if presentation=='phone':env['GLOB2_MOBILE_UI']='1'
 else:env.pop('GLOB2_MOBILE_UI',None)
 cmd=[str(binary),'matrix',str(source_root),str(kit),str(output),str(w),str(h),str(size),str(scale)];start=time.monotonic();print('START',tag,flush=True)
 with (output/'capture.log').open('w')as log:
  try:rc=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=3600).returncode
  except subprocess.TimeoutExpired:rc='timeout'
 entries.append(dict(tag=tag,command=cmd,returncode=rc,seconds=round(time.monotonic()-start,2),log=str(output/'capture.log')))
 record.write_text(json.dumps({'binary':str(binary),'binary_sha256':producer,'jobs':entries},indent=2)+'\n');print('END',tag,rc,entries[-1]['seconds'],flush=True)
 if rc!=0:print((output/'capture.log').read_text()[-1500:],flush=True)
print('COMPLETE',flush=True)
