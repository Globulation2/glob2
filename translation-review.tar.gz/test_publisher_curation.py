"""Focused tests execute the actual curator's validation functions in isolation."""
import ast,base64,gzip,hashlib,json,re,tarfile,tempfile,unittest,zlib
from pathlib import Path
SOURCE=Path(__file__).with_name('publish_evidence.py')
class CurationTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(dir=SOURCE.parent);self.addCleanup(self.temp.cleanup);self.base=Path(self.temp.name);self.out=self.base/'published';self.out.mkdir()
  tree=ast.parse(SOURCE.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('strip_embedded_images','validate','archive','collect','is_provider_response','provider_content','selected_capture_paths','implementation_directories','browser_capture_files','prepared_browser_source_files') or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('TEXT','DENIED','SECRETS','PROVIDER_KITS','MAX_SCAN_BYTES','IMPLEMENTATION_DIRS','CAPTURE_DIRS')for t in n.targets)]
  self.ns=dict(root=self.base,base=self.base,out=self.out,Path=Path,base64=base64,gzip=gzip,hashlib=hashlib,json=json,re=re,prepared_inputs={},scanned={},sanitized={},omitted_images=[],tarfile=tarfile,archive_members={},files={},zlib=zlib);exec(compile(ast.Module(body=nodes,type_ignores=[]),str(SOURCE),'exec'),self.ns)
 def write(self,name,data):
  p=self.base/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return p
 def test_embedded_png_is_metadata_only_and_original_unchanged(self):
  original=json.loads((SOURCE.parent/'final-online-qa/provisional/tests.json').read_text());image=original['suites'][2]['specs'][0]['tests'][0]['results'][0]['attachments'][2];raw=json.dumps({'attachment':image}).encode();p=self.write('report.json',raw);safe=self.ns['validate'](p);result=json.loads(safe.read_text());self.assertNotIn('body',result['attachment']);self.assertEqual(p.read_bytes(),raw);self.assertEqual(result['attachment']['omitted_embedded_image']['sha256'],'6c67ee3c75a877481af438f3ab1e1373579b4a3854a0fedfe3dbf676590d35d7')
 def test_real_key_shaped_text_fails_without_echoing_value(self):
  credential='AIza'+'x'*35;p=self.write('provider-response.json',json.dumps({'credential':credential}).encode())
  with self.assertRaises(ValueError) as caught:self.ns['validate'](p)
  self.assertNotIn(credential,str(caught.exception))
 def test_gzip_content_scanned(self):
  p=self.write('diagnostics.json.gz',gzip.compress(json.dumps({'token':'ya29.'+'x'*32}).encode()))
  with self.assertRaises(ValueError):self.ns['validate'](p)
 def test_bad_image_metadata_fails(self):
  p=self.write('report.json',json.dumps({'contentType':'image/png','body':base64.b64encode(b'not png').decode()}).encode())
  with self.assertRaises(ValueError):self.ns['validate'](p)
 def test_ordinary_provider_response_byte_exact(self):
  raw=b'{"translations":[{"translatedText":"test"}]}';p=self.write('provider-response.json',raw);safe=self.ns['validate'](p);self.assertNotEqual(p,safe);self.assertTrue(safe.is_relative_to(self.out/'snapshots'));self.assertEqual(raw,safe.read_bytes());self.assertFalse(self.ns['sanitized'])
 def test_appended_log_uses_first_scanned_bytes_for_archive_and_publication(self):
  raw=b'build still running\n';source=self.write('build.log',raw);frozen=self.ns['validate'](source)
  with source.open('ab') as log:log.write(b'build later completed\n')
  self.ns['archive']('logs.tar.gz',[source])
  with tarfile.open(self.out/'logs.tar.gz') as archive:self.assertEqual(archive.extractfile('build.log').read(),raw)
  self.assertEqual(self.ns['validate'](source),frozen);self.assertEqual(frozen.read_bytes(),raw)
  self.assertEqual(self.ns['archive_members']['logs.tar.gz']['build.log'],{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
  self.ns['files']['build.log']=self.ns['validate'](source)
  self.assertEqual(self.ns['files']['build.log'].read_bytes(),raw)
 def test_rewritten_provider_and_gzip_preserve_raw_frozen_bytes(self):
  for name,raw in [('response.json',b'{"translations":[{"translatedText":"original"}]}'),('diagnostics.json.gz',gzip.compress(b'{"original":true}')),('image.png',bytes.fromhex('89504e470d0a1a0a')+b'original')]:
   with self.subTest(name=name):
    source=self.write(name,raw);frozen=self.ns['validate'](source);source.write_bytes(b'changed after validation')
    self.ns['archive']('one.tar.gz',[source])
    with tarfile.open(self.out/'one.tar.gz') as archive:self.assertEqual(archive.extractfile(name).read(),raw)
    self.assertEqual(frozen.read_bytes(),raw);self.assertEqual(self.ns['scanned'][name]['sha256'],hashlib.sha256(raw).hexdigest())
 def test_snapshots_are_not_selected_as_inputs(self):
  source=self.write('published/snapshots/duplicate.json',b'{}')
  with self.assertRaises(ValueError):self.ns['validate'](source)
 def provider_path(self,kit='kit-v4',rejected=False):
  prefix=kit+'/rejected/wrong-br-breton-mapping/provider-history/raw/'if rejected else kit+'/machine/fa/raw/'
  return prefix+'a'*64+'-000057.response.bin'
 def test_known_provider_bin_selected_and_frozen_exact(self):
  actual=next((SOURCE.parent/'kit-v4/machine/fa/raw').glob('*.response.bin'));raw=actual.read_bytes();source=self.write(self.provider_path(),raw)
  self.assertIn(source,self.ns['collect'](self.base/'kit-v4'));frozen=self.ns['validate'](source);source.write_bytes(b'changed')
  self.ns['archive']('raw.tar.gz',[source])
  with tarfile.open(self.out/'raw.tar.gz')as archive:self.assertEqual(archive.extractfile(self.provider_path()).read(),raw)
  self.assertEqual(frozen.read_bytes(),raw)
  rejected=self.write(self.provider_path(rejected=True),raw);self.assertIn(rejected,self.ns['collect'](self.base/'kit-v4'))
 def test_v6_malay_provider_selected_exact_and_secret_scanned(self):
  self.assertIn('kit-v7',self.ns['PROVIDER_KITS'])
  actual=next((SOURCE.parent/'kit-v6/machine/ms/raw').glob('*.response.bin'));raw=actual.read_bytes();name=self.provider_path(kit='kit-v6').replace('/fa/','/ms/');source=self.write(name,raw)
  self.assertIn(source,self.ns['collect'](self.base/'kit-v6'));frozen=self.ns['validate'](source);self.assertEqual(frozen.read_bytes(),raw)
  bad=self.write(name.replace('000057','000090'),json.dumps({'credential':'ya29.'+'x'*32}).encode())
  with self.assertRaises(ValueError):self.ns['validate'](bad)
 def test_provider_bin_secret_scan_raw_gzip_and_zlib(self):
  secret=json.dumps({'credential':'ya29.'+'x'*32}).encode()
  for index,body in enumerate([secret,gzip.compress(secret),zlib.compress(secret)]):
   with self.subTest(index=index):
    source=self.write(self.provider_path(kit='kit-v3') .replace('000057','00005'+str(index)),body)
    with self.assertRaises(ValueError):self.ns['validate'](source)
 def test_provider_compression_bound_is_enforced(self):
  self.ns['MAX_SCAN_BYTES']=32;source=self.write(self.provider_path(),gzip.compress(b'x'*200))
  with self.assertRaises(ValueError):self.ns['validate'](source)
 def test_compressed_provider_raw_bytes_preserved(self):
  raw=gzip.compress(b'{"translations":[]}');source=self.write(self.provider_path(),raw);self.assertEqual(self.ns['validate'](source).read_bytes(),raw)
 def test_arbitrary_bins_and_executable_named_as_response_excluded(self):
  source=self.write('native-tests/probe.bin',b'executable');self.assertNotIn(source,self.ns['collect'](self.base))
  with self.assertRaises(ValueError):self.ns['validate'](source)
  source=self.write(self.provider_path(),b'\x7fELF\x00binary')
  with self.assertRaises(ValueError):self.ns['validate'](source)
 def test_explicit_native_history_and_v8_selections_are_frozen(self):
  folder=self.base/'native-captures';choices=[];expected=[]
  for name in ('v2','v4-final','v5-final','v8-final'):
   capture=self.write('native-captures/'+name+'/one.png',b'capture '+name.encode());selection=self.write('native-captures/'+name+'/selection.json',json.dumps({'paths':[name+'/one.png']}).encode());choices.append(selection);expected.extend([capture,selection])
  selected=self.ns['selected_capture_paths'](folder,choices);self.assertEqual(selected,expected)
  choices[-1].write_text(json.dumps({'paths':['v8-final/UNREQUESTED.png']}))
  self.assertEqual(self.ns['selected_capture_paths'](folder,choices),expected)
 def test_future_browser_selection_is_explicit_and_rejects_escape(self):
  self.assertIn('final-v6-online-qa',self.ns['CAPTURE_DIRS'])
  capture=self.write('next-browser-actual/after.png',b'capture');selection=self.write('browser-selection.json',json.dumps(['next-browser-actual/after.png']).encode())
  self.assertEqual(self.ns['selected_capture_paths'](self.base,[selection]),[capture,selection])
  bad=self.write('bad-selection.json',json.dumps(['../outside.png']).encode())
  with self.assertRaises(ValueError):self.ns['selected_capture_paths'](self.base,[bad])
  with self.assertRaises((ValueError,OSError)):self.ns['selected_capture_paths'](self.base,[self.base/'missing-selection.json'])
 def test_new_integration_evidence_selected_but_build_payloads_excluded(self):
  for folder in ('sgsl-bg-compatibility','malay-integration','merge-malay-frontend','ci-selector-fix','native-v7-qa','native-v8-qa','native-v9-qa','master-mr-ta-integration','master-telugu-integration','master-1801-integration','browser-unit-master-ffabe'):
   good=self.write(folder+'/result.json',b'{}');patch=self.write(folder+'/implementation.diff',b'--- old\n+++ new\n');exitcode=self.write(folder+'/tests.exit',b'0\n');binary=self.write(folder+'/build/game.bin',b'compiled');cache=self.write(folder+'/__pycache__/test.pyc',b'bytecode')
   self.assertIn(self.base/folder,self.ns['implementation_directories']());selected=self.ns['collect'](self.base/folder);self.assertIn(good,selected);self.assertIn(exitcode,selected);self.assertIn(patch,selected);self.assertNotIn(binary,selected);self.assertNotIn(cache,selected)
 def test_actual_final_v7_browser_selection_retains_bindings_and_excludes_payloads(self):
  self.assertIn('final-v7-online-qa',self.ns['CAPTURE_DIRS']);folder=self.base/'final-v7-online-qa'
  expected=[self.write('final-v7-online-qa/'+name,raw)for name,raw in [('producer.json',b'{}'),('inputs-clean.json',b'{}'),('verified/after.png',b'actual screenshot'),('types.exit',b'0\n'),('index-evidence.py',b'# source'),('report.json.gz',gzip.compress(b'{}'))]]
  denied=[self.write('final-v7-online-qa/'+name,b'payload')for name in ('profiles/account.json','node_modules/package.json','build/game.wasm','game.exe','cache/report.json','provisional/report.json')]
  selected=self.ns['browser_capture_files'](folder);self.assertEqual(set(selected),set(expected));self.assertFalse(set(denied)&set(selected))
 def test_prepared_browser_sources_do_not_select_runtime_packages(self):
  folder=self.base/'browser-final-v7';expected=[self.write('browser-final-v7/'+name,b'{}')for name in ('stage.py','capture.cjs','startup.cjs','README.md','preparation.json')]
  for name in ('static/game.js','static/input.json','static/game.wasm','captures/after.png','handoff.json','profiles/account.json'):self.write('browser-final-v7/'+name,b'payload')
  self.assertEqual(set(self.ns['prepared_browser_source_files'](folder)),set(expected))
 def test_build_cache_and_symlink_rejected(self):
  p=self.write('cache/response.json',b'{}')
  with self.assertRaises(ValueError):self.ns['validate'](p)
  target=self.write('plain.json',b'{}');alias=self.base/'alias.json';alias.symlink_to(target)
  with self.assertRaises(ValueError):self.ns['validate'](alias)
 def test_v8_and_platform_companion_provider_bodies_are_scanned_exact(self):
  for kit,locale in [('kit-v8','mr'),('kit-v8','ta'),('platform-companion-v8','bg'),('telugu-compat-v8','te'),('filipino-compat-v8','fil')]:
   self.assertIn(kit,self.ns['PROVIDER_KITS']);name=self.provider_path(kit=kit).replace('/fa/','/'+locale+'/');body=b'{"translations":[{"translatedText":"reviewed separately"}]}';source=self.write(name,body);self.assertIn(source,self.ns['collect'](self.base/kit));self.assertEqual(self.ns['validate'](source).read_bytes(),body)
   bad=self.write(name.replace('000057','000096'),b'{"credential":"ya29.'+b'x'*32+b'"}')
   with self.assertRaises(ValueError):self.ns['validate'](bad)
 def test_future_native_v9_capture_requires_explicit_selection(self):
  image=self.write('native-captures/v9-final/one.png',b'future actual capture');choice=self.write('native-captures/v9-final/selection.json',json.dumps({'paths':['v9-final/one.png']}).encode());self.assertEqual(self.ns['selected_capture_paths'](self.base/'native-captures',[choice]),[image,choice])
 def test_actual_postvisual_capture_proof_directories_selected(self):
  for name in ('after-postvisual-33','after-credit-fix'):
   self.assertIn(name,self.ns['CAPTURE_DIRS']);folder=self.base/name;report=self.write(name+'/after-visible-wallet/source-bundle-closure.json',b'{}');image=self.write(name+'/after-visible-wallet/captures/phone.png',b'actual image');cache=self.write(name+'/profiles/secret.json',b'{}');self.assertEqual(set(self.ns['browser_capture_files'](folder)),{report,image})
if __name__=='__main__':unittest.main(verbosity=2)
