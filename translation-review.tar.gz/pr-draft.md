Bulgarian localization implementation in progress. This draft currently adds budgeted Google Cloud drafting, mandatory independent review records, native locale mapping, bundled Cyrillic browser typography and packaging, and localized music error presentation.

The complete machine draft is generated locally (USD 4.39760 conservatively reserved). Semantic, editorial, and independent adversarial review plus rendering validation are required before registering Bulgarian or marking this PR ready. Catalogs and final verification evidence will follow.

Initial checks: 40 translation-program tests; 6 API page tests; focused launcher packaging and Bulgarian glyph coverage checks. Native SDL dependencies and browser builds are running. No native-human certification is claimed.
