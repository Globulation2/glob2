from pathlib import Path
import difflib
p=Path('tools/TranslationPreviewHarness.cpp');old=p.read_text();s=old
needle='''    void redraw() {
        this->paintFrame(SDL_GetTicks());'''
s=s.replace(needle,'''    bool containsText(const std::string &expected) {
        const auto visit = [&](const auto &self, GAGGUI::ui::Node *node) -> bool {
            if (!node) return false;
            if (node->accessibleText() == expected) return true;
            for (const auto &child : node->children) if (self(self, child.get())) return true;
            return false;
        };
        return visit(visit, this->GAGGUI::ui::UIScreen::host().root());
    }
    void redraw() {
        this->paintFrame(SDL_GetTicks());''',1)
needle='''    Online::ServicesOwner services;
    if (onlineSettings) services.get().client.start("http://127.0.0.1:1");
    Json controls, actions = Json::array();'''
s=s.replace(needle,'''    Online::ServicesOwner services;
    const auto *fixtureOrigin = SDL_getenv("GLOB2_TRANSLATION_PREVIEW_HTTP_ORIGIN");
    const auto *fixtureNotice = SDL_getenv("GLOB2_TRANSLATION_PREVIEW_EXPECT_NOTICE");
    const bool httpFixture = fixtureOrigin && *fixtureOrigin;
    std::string origin = "http://127.0.0.1:1";
    if (httpFixture) {
        require(screen == "settings-ais" && fixtureNotice && *fixtureNotice,
            "HTTP fixture is only available in the AI Settings CLI preview with expected notice");
        origin = fixtureOrigin;
        const std::string prefix = "http://127.0.0.1:";
        require(origin.starts_with(prefix), "HTTP preview fixture requires IPv4 loopback");
        const auto port = origin.substr(prefix.size());
        require(!port.empty() && port.size() <= 5 &&
            std::all_of(port.begin(), port.end(), [](char c) { return c >= '0' && c <= '9'; }) &&
            std::stoi(port) > 0 && std::stoi(port) <= 65535,
            "HTTP preview fixture requires a numeric loopback port");
    }
    if (onlineSettings) services.get().client.start(origin);
    Json controls, actions = Json::array();''',1)
needle='''                for (const auto *tag : {"Balanced", "Rush", "Defensive", "Economy", "Expansion", "Experimental", "Beginner-friendly"})
                    require(preview.hasControl(std::string("ais/tag/") + tag), "Production AI tag control: " + std::string(tag));'''
s=s.replace(needle,needle+'''
                if (httpFixture) {
                    const Uint64 deadline = SDL_GetTicks() + 15000;
                    do {
                        Online::pump();
                        preview.redraw();
                        if (preview.containsText(fixtureNotice)) break;
                        SDL_Delay(10);
                    } while (SDL_GetTicks() < deadline);
                    require(preview.containsText(fixtureNotice),
                        "Real HTTP decoder and AI Settings callback produced the expected notice");
                    actions.push_back("Observed expected notice through production HTTP decoder and AI Settings callback; controlled localhost fixture only.");
                }''',1)
s=s.replace('''        {"online_environment", onlineSettings ? "Unavailable loopback origin; no remote account/provider action or online-flow verification." : "Not exercised."},''','''        {"http_fixture_origin", httpFixture ? Json(origin) : Json(nullptr)},
        {"expected_notice", httpFixture ? Json(fixtureNotice) : Json(nullptr)},
        {"online_environment", onlineSettings ? "CLI preview uses controlled localhost fixture or unavailable loopback; no production server, remote account/provider or physical-device verification." : "Not exercised."},''',1)
s=s.replace('''             "src/ui/settings/SettingsScreenKeyboard.cpp",
''','''             "src/ui/settings/SettingsScreenKeyboard.cpp", "src/online/PlatformClient.cpp",
             "src/online/PlatformProtocol.cpp", "src/online/PlatformProtocol.h",
             "src/online/ApiErrorText.cpp", "src/online/ApiErrorText.h", "src/ui/ApiErrorText.h",
''',1)
s=s.replace('actions.push_back("Opened AI Library through its production button; client uses unavailable loopback origin.");', 'actions.push_back(httpFixture ? "Opened AI Library through its production button; controlled localhost HTTP fixture." : "Opened AI Library through its production button; client uses unavailable loopback origin.");')
assert s!=old
Path('artifacts/bulgarian/native-api-notice-preview.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+str(p),tofile='b/'+str(p))))
