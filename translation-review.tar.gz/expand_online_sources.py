import importlib.util,json,re,shutil,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];base=ROOT/'artifacts/bulgarian';old=base/'kit'
s=importlib.util.spec_from_file_location('p',ROOT/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
backup=base/'source-expansion-v1';backup.mkdir(exist_ok=True)
if not (backup/'linguistics').exists():shutil.copytree(base/'linguistics',backup/'linguistics')
for name in ('review-proof-validation.json','review-proof-validation.log','final-catalog-font-coverage.json'):
 if (base/name).exists():shutil.copyfile(base/name,backup/name)
tags=['Rush','Defensive','Economy','Expansion','Experimental','Beginner-friendly']
locales=re.findall(r"code: '([^']+)',\s+gameCode: '([^']+)'",(ROOT/'platform/packages/i18n/src/locales.ts').read_text())
shared_path=ROOT/'platform/packages/i18n/shared-values.json';shared=json.loads(shared_path.read_text());provenance=[]
for code,gamecode in locales:
 native,errors=p.CHECKER.read_table(ROOT/f'data/texts.{gamecode}.txt');assert not errors
 target=ROOT/f'platform/packages/i18n/locales/{code}.json';data=json.loads(target.read_text());changes={}
 for key in tags:
  assert key not in data,key;v=native['['+key+']'];assert v.strip();data[key]=v;changes[key]={'value':v,'origin':f'data/texts.{gamecode}.txt:['+key+']','method':'Exact existing native canonical AI-tag value; stored tags remain unchanged.'}
 source=data['Title, artist, description…'];parts=re.split(r'[,،、，]',source);assert len(parts)==3,(code,source);artist=parts[1].strip();artist=artist[:1].upper()+artist[1:]
 # Existing search phrases in these two locales use art/painter, rather than
 # the music performer. Use the conventional performer label in this context.
 if code=='ar':artist='الفنان'
 if code=='ru':artist='Исполнитель'
 assert 'Artist'not in data;data['Artist']=artist;changes['Artist']={'value':artist,'origin':'Title, artist, description…','origin_value':source,'method':'Existing music metadata search vocabulary, standalone capitalized label; Arabic/Russian corrected for the music-performer context.'}
 for key,change in changes.items():
  if code!='en' and change['value']==key:
   shared.setdefault(code,[])
   if key not in shared[code]:shared[code].append(key)
   change['english_identical_rationale']='Reviewed existing native AI-tag cognate, or existing music-search native cognate (Romanian artist); identical spelling is intentional.'
 p.write_json(target,data);provenance.append({'locale':code,'game_code':gamecode,'entries':changes})
p.write_json(shared_path,shared);p.write_json(base/'online-source-additions-provenance.json',provenance)
new=base/'kit-v2';p.prepare(new,locales=('bg',));p.draft(new,'bg');paths=p.catalog_paths(new,'bg');shutil.copyfile(ROOT/'data/texts.bg.txt',paths['native']);shutil.copyfile(ROOT/'platform/packages/i18n/locales/bg.json',paths['online']);(new/'machine').mkdir(exist_ok=True);shutil.copyfile(old/'machine/spend-ledger.json',new/'machine/spend-ledger.json')
oldsource=json.loads((old/'source/online.json').read_text());newsource=json.loads((new/'source/online.json').read_text());oldtarget=json.loads(p.catalog_paths(old,'bg')['online'].read_text());newtarget=json.loads(paths['online'].read_text());assert all(newsource[k]==v for k,v in oldsource.items());assert all(newtarget[k]==v for k,v in oldtarget.items());added=sorted(set(newsource)-set(oldsource));assert len(added)==7
p.write_json(base/'source-expansion-carryforward.json',{'old_kit':'kit','new_kit':'kit-v2','old_source_sha256':json.loads((old/'manifest.json').read_text())['source_sha256'],'new_source_sha256':json.loads((new/'manifest.json').read_text())['source_sha256'],'unchanged_native_keys':3393,'unchanged_online_keys':len(oldsource),'new_online_keys':added,'old_proof_snapshot':'source-expansion-v1/linguistics','method':'Every pre-existing source and translated value compared exactly. Only seven new online source entries require new reading; old exact source/target review proofs retained. No fresh reading of unchanged keys is claimed. Original Google cost reservations copied into new kit to retain the USD10 campaign ceiling.'})
(base/'active-kit.txt').write_text('kit-v2\n');print('New online keys',added,'locale count',len(locales))
