from pathlib import Path
import json,gzip,hashlib
from PIL import Image,ImageOps,ImageDraw
base=Path('artifacts/bulgarian/native-captures');selection=[];matrices=[]
for folder in [base/'desktop-matrix',base/'phone-matrix']:
 path=folder/'font-matrix.json'
 if not path.exists():continue
 d=json.load(open(path));samples=d['samples'];lines=[line for sample in samples for line in sample['lines']];summary={'folder':str(folder),'samples':len(samples),'unique_source_keys':len({(x['surface'],x['key'])for x in samples}),'unique_branches':len({(x['surface'],x['key'],x['branch'])for x in samples}),'glyph_missing_samples':sum(not x['has_glyphs']for x in samples),'drawn_width_failures':sum(not x['drawn_fits_width']for x in lines),'drawn_height_failures':sum(not x['drawn_fits_height']for x in lines),'raw_width_diagnostics':sum(not x['fits_width']for x in lines),'raw_height_diagnostics':sum(not x['fits_height']for x in lines),'raster_pages':len(list(folder.glob('font-*.png'))),'selected':[],'evidence_identity':d['evidence_identity']}
 for size in [10,13,20]:
  for scale in [1,2]:
   pages=sorted(folder.glob(f'font-{size}-scale-{scale}-page-*.png'));chosen=[pages[0],pages[len(pages)//2],pages[-1]]
   for p in chosen:
    if p not in selection:selection.append(p);summary['selected'].append(str(p))
 thumbs=[]
 for p in map(Path,summary['selected']):
  im=Image.open(p).convert('RGB');im.thumbnail((320,280));tile=Image.new('RGB',(340,310),'#eeeeee');tile.paste(im,((340-im.width)//2,20));ImageDraw.Draw(tile).text((5,294),p.name,fill='black');thumbs.append(tile)
 sheet=Image.new('RGB',(340*6,310*3),'white')
 for i,im in enumerate(thumbs):sheet.paste(im,((i%6)*340,(i//6)*310))
 contact=folder/'selected-pages-contact.png';sheet.save(contact);selection.append(contact)
 compressed=folder/'font-matrix.json.gz'
 with open(path,'rb')as inp,gzip.open(compressed,'wb',compresslevel=9)as out:out.write(inp.read())
 summary['complete_diagnostics_gzip']=str(compressed);summary['uncompressed_diagnostics_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();selection.append(compressed);matrices.append(summary)
for folder in sorted(base.iterdir()):
 if not folder.is_dir()or folder.name.endswith('-matrix'):continue
 selection.extend(sorted(folder.glob('*.png')));selection.extend(sorted(folder.glob('*.json')))
(base/'matrix-diagnostics.json').write_text(json.dumps(matrices,ensure_ascii=False,indent=2)+'\n');selection.append(base/'matrix-diagnostics.json');selection.extend(sorted(base.glob('execution*.json')))
(base/'publish-selection.json').write_text(json.dumps({'paths':[str(p)for p in selection],'limits':'Font pages selected first/middle/last per size/scale/viewport; full raster output remains local. Complete diagnostics/provenance retained losslessly in font-matrix.json.gz. Actual visually inspected files are recorded separately; selection does not imply every page or line was visually read.'},indent=2)+'\n')
print(json.dumps([{k:v for k,v in d.items()if k not in ['selected','evidence_identity']}for d in matrices],indent=2))
