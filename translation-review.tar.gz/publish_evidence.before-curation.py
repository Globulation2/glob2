"""Publish a curated evidence-only branch without changing the checkout or index."""
import hashlib,json,os,subprocess,tarfile,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];base=root/'artifacts/bulgarian';out=base/'published';out.mkdir(exist_ok=True)
# Exclude SDKs, binaries, dependencies and caches. Preserve provider data without
# HTTP authorization headers (the drafting tool never wrote those headers).
selected=['kit','kit-v2','linguistics','source-expansion-v1','visual-refinement-v1']
with tarfile.open(out/'translation-review.tar.gz','w:gz',compresslevel=9) as tar:
 for name in selected:
  tar.add(base/name,arcname=name)
 for p in sorted(base.glob('*.json')):tar.add(p,arcname=p.name)
 for p in sorted(base.glob('*.md')):tar.add(p,arcname=p.name)
 for p in sorted(base.glob('*.py')):tar.add(p,arcname=p.name)
 for directory in ('native-error-bridge','integration-027a','browser-unit-master-80596'):
  for p in sorted((base/directory).rglob('*')):
   if p.is_file() and p.suffix in ('.json','.md','.log','.patch','.py','.cjs','.tar') and 'stage' not in p.relative_to(base/directory).parts and '__pycache__' not in p.parts:
    tar.add(p,arcname=str(p.relative_to(base)))
with tarfile.open(out/'verification-logs.tar.gz','w:gz',compresslevel=9) as tar:
 for p in sorted(base.glob('*.log')):tar.add(p,arcname=p.name)
 for directory in sorted(base.glob('native-tests*')):
  if directory.is_dir():
   for p in sorted(directory.rglob('*')):
    if p.is_file() and p.suffix in ('.log','.json','.xml','.txt'):
     tar.add(p,arcname=str(p.relative_to(base)))
 for name in ('final-online-qa/verified/web-typecheck.log','final-online-qa/verified/e2e-typecheck.log','final-online-qa/add-kind-unit.log'):
  p=base/name
  if p.exists():tar.add(p,arcname=name)
# Screens and small identity/QA reports stay directly browseable on GitHub.
files={p.name:p for p in out.glob('*.tar.gz')}
large_diagnostics=[]
for directory in ['final-online-qa','native-captures','browser-captures']:
 folder=base/directory
 selection=None
 if directory=='native-captures' and folder.exists():
  choice=folder/'publish-selection.json'
  if not choice.exists():
   if not any(folder.rglob('*.png')):continue
   raise ValueError('Native capture publication requires a curated publish-selection.json')
  selection=json.loads(choice.read_text())
  if isinstance(selection,dict):selection=selection['paths']
  selection=set(selection)
 for p in sorted(folder.rglob('*')):
  if not p.is_file() or p.suffix not in ('.png','.jpg','.json','.md','.xml','.gz','.mjs','.html'):continue
  relative=str(p.relative_to(folder))
  if selection is not None and p.suffix in ('.png','.jpg') and relative not in selection:continue
  if p.suffix=='.json' and p.stat().st_size>1_000_000:
   large_diagnostics.append((p,f'{directory}/{relative}'));continue
  files[f'{directory}/{relative}']=p
if large_diagnostics:
 diagnostic_archive=out/'render-diagnostics.tar.gz'
 with tarfile.open(diagnostic_archive,'w:gz',compresslevel=9) as tar:
  for p,name in large_diagnostics:tar.add(p,arcname=name)
 files[diagnostic_archive.name]=diagnostic_archive
for p in (base/'extended-online-qa').glob('*'):
 if p.is_file() and p.suffix in ('.md','.json','.jpg'):files['extended-online-qa/'+p.name]=p
for p in [base/'verification-summary.md']:
 if p.exists():files[p.name]=p
manifest={'feature_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'files':{name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in files.items()}}
mp=out/'manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');files['manifest.json']=mp
assert all(p.stat().st_size<95_000_000 for p in files.values()),'Split oversized evidence files before publishing'
with tempfile.TemporaryDirectory(prefix='bulgarian-evidence-index-') as temp:
 env=dict(os.environ,GIT_INDEX_FILE=str(Path(temp)/'index'))
 def git(*args,input=None):return subprocess.check_output(['git',*args],cwd=root,env=env,input=input,text=True).strip()
 git('read-tree','--empty')
 for name,p in files.items():
  blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo','100644',blob,name)
 tree=git('write-tree');branch='refs/heads/codex/bulgarian-localization-evidence'
 previous=subprocess.run(['git','rev-parse','--verify',branch],cwd=root,capture_output=True,text=True)
 parents=['-p',previous.stdout.strip()] if previous.returncode==0 else []
 commit=git('commit-tree',tree,*parents,input='Bulgarian localization review and verification evidence\n')
 git('update-ref',branch,commit)
 print(commit,len(files),'evidence files')
 subprocess.run(['git','push','origin',branch],cwd=root,check=True)
