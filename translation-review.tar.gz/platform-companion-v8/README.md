Three Bulgarian OS resource values, separate from authoritative game/online source.

Read bg-platform3-review-input.json for exact frozen English resource bytes/hashes, resource fields/callers, source/target, raw response and brand protection. Main V8 source remains3d16c1… and no main catalog/source was edited. The synthetic companion tooling source8bd160… appends stable platform IDs solely to reuse the reviewed machine path; these IDs are not registered game or online translation keys.

One authorized request reserved163protectedcodepoints/$0.00326. Exact95-reservation parent prefix is preserved; current total96/$5.47148. MainV8 machine history was extended with the new raw/cache/index/ledger, so the active campaign pointer can remain mainV8 without budget reset. Main initial machine-validation.json retains truthful historical95-at-phase-completion; this companion machine-validation.json records the extension. Provider raw/index and frozen provider-drafts are separate from editable candidate drafts. No actual linguistic approval or runtime/platform gate is claimed.

Do not rerun the one-shot paid launcher. The standalone review requires actual semantic,editorial,adversarial read and approval before root creates Android/macOS/iOS Bulgarian resource files.
