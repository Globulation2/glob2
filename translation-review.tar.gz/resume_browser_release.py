from pathlib import Path
import os,subprocess,time
root=Path.cwd();old=Path('/proc/1411905')
while old.exists():
 try:
  command=(old/'cmdline').read_bytes()
  if (old/'cwd').resolve()!=root or b'scons' not in command:break
 except OSError:break
 time.sleep(2)
env=dict(os.environ,CCACHE='1',CCACHE_MAXSIZE='12G')
print('Resuming browser release build with compiler caching',flush=True)
with (root/'artifacts/bulgarian/browser-release-cached.log').open('w') as log:
 result=subprocess.run(['scons','release=1','target=web','web_variant=both','-j4','web-package'],env=env,stdout=log,stderr=subprocess.STDOUT)
print('Browser release build exit',result.returncode,flush=True)
raise SystemExit(result.returncode)
