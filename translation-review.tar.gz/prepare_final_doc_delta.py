from pathlib import Path
import difflib
p=Path('docs/development/ui-framework.md');old=p.read_text();text=old
needle='Damaged protected tokens or invalid responses stop drafting and retain evidence;\nreview the affected entry before resuming rather than guessing a repair.\n'
assert needle in text
text=text.replace(needle,needle+'''
The same explicit drafting command supports the legacy native locales when new
shared keys need translations. Use canonical locale tags in `--locales` and
`--locale`; native filename aliases are mapped separately. In particular,
`pt-BR` writes `texts.br.txt` (Brazilian Portuguese), while `pt-PT` writes
`texts.pt.txt`. Canonical `br` would mean Breton and is rejected. Inspect each
catalog's language metadata before adding a mapping. This opt-in scope does not
change the default release-language set or certify an unfinished online catalog.
When a source expansion needs a fresh immutable kit, carry the complete cumulative
cost ledger and provider evidence forward before any further request; a new
output directory must not reset the task's spending budget.
''')
needle='Keep this marker out of models,'
# Add durable UI diagnostic explanation before translation program section.
anchor='For a Bulgarian Google Cloud draft, prepare a kit with `--locales bg`, then run:'
assert anchor in text
text=text.replace(anchor,'''Bulgarian diagnostic surfaces keep raw errors in the diagnostic log and display
an existing reviewed native message where available, otherwise the reviewed
online summary. `Glob2UI::DiagnosticText` keeps a bounded cache per UI context;
changing the diagnostic invalidates its display cache. It does not change model
readiness, error codes, or transmitted values. Script-editor statuses, cursor
coordinates and built-in Hive notices have explicit catalog keys. Hive's public
string report history remains unchanged; a private companion records which
messages were created locally. Remote reports and user text are never classified
by matching their contents. Editor preview status retains its raw event and
localizes it during rendering so changing language updates an existing notice
without restarting the engine.

'''+anchor)
out=Path('artifacts/bulgarian/final-localization-doc.patch');out.write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='a/'+str(p),tofile='b/'+str(p))))
