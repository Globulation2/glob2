"""Bind actual one-pair caller reviews without changing whole-catalog gates."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'artifacts/bulgarian';HERE=Path(__file__).resolve().parent
ROLES={'semantic':'/root/v7_meaning','editor':'/root/v7_editor','adversarial':'/root/v7_adversary'}
ACCEPT={'approved','approve','accepted','accept'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def digest(v):return hashlib.sha256(v.encode()).hexdigest()
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def require(v,message):
 if not v:raise ValueError(message)
def path_ref(name,root=ROOT,base=BASE):
 p=Path(name);p=p if p.is_absolute()else(root/p if str(p).startswith('artifacts/')else base/p)
 require(p.resolve().is_relative_to(base.resolve())and p.is_file(),'missing/escaping evidence reference');return p

def verify_report(path,role,expected,root=ROOT,base=BASE):
 path=path.resolve();d=read(path);require(d.get('reviewer_identity',{}).get('agent')==ROLES[role],'wrong actual reviewer identity');require(d.get('status')=='approved'and d.get('final_approval')is not False,'report not approved');require(not d.get('findings'),'unresolved findings')
 require(d.get('packet_sha256')==expected['packet_sha256']and path_ref(d['packet_path'],root,base)==expected['packet_path'],'stale/mismatched current packet')
 original=None;body=d
 if 'original_report_path'in d or 'original_frozen_report'in d:
  ref=d.get('original_frozen_report',{'path':d.get('original_report_path'),'sha256':d.get('original_report_sha256')});p=path_ref(ref['path'],root,base);require(sha(p)==ref['sha256'],'original report hash changed');original=read(p);require(original.get('reviewer_identity',{}).get('agent')==ROLES[role]and original.get('status')=='approved','original reviewer approval differs');body=original
 entries=d.get('entries',[d['entry']]if 'entry'in d else[]);require(len(entries)==1,'context report must cover exactly one pair');e=entries[0]
 for k,v in {'key':'My colony','source':expected['source'],'target':expected['target']}.items():require(e.get(k)==v,'literal pair differs: '+k)
 require(e.get('locale','bg')=='bg'and e.get('id','online:My colony')=='online:My colony','entry identity differs');require(e.get('source_sha256')==digest(expected['source'])and e.get('target_sha256')==digest(expected['target']),'literal hashes differ')
 if 'identity_sha256'in e:require(e['identity_sha256']==digest(canonical(['bg','online:My colony',e['source'],e['target']])),'combined identity hash differs')
 if original:
  old=original['entries'];require(len(old)==1,'original context coverage differs');require(all(e.get(k)==old[0].get(k)for k in ('key','source','target','source_sha256','target_sha256')),'supplement changed original pair')
 if role=='semantic':
  checks=d.get('actual_check',{});require(all(checks.get(k)is True for k in ('current_packet_read_in_full','source_target_exactly_recompared','caller_test_catalog_source_file_hashes_directly_verified_unchanged','startup_source_files_freshly_read')),'semantic actual recheck incomplete');require(body['entries'][0].get('actual_fresh_production_caller_read')is True and body['entries'][0].get('actual_fresh_complete_source_target_read')is True,'semantic original reading missing')
 elif role=='editor':require(d.get('actual_complete_fresh_metadata_and_source_read')is True and e.get('actual_complete_fresh_context_read')is True and e.get('verdict')in ACCEPT,'editor actual context reading missing')
 else:require(d.get('actual_fresh_complete_source_target_read')is True and e.get('actual_fresh_complete_source_target_read')is True and e.get('status')in ACCEPT and d.get('context_assessment'),'adversarial actual context reading missing')
 catalog=d.get('catalog_sha256',{});source_file=d.get('source_file_sha256',{});en=catalog.get('source_en',catalog.get(expected['en_path'],source_file.get(expected['en_path'])));bg=catalog.get('online',catalog.get('target_bg',catalog.get(expected['bg_path'])));require(en==expected['en_sha256']and bg==expected['bg_sha256'],'catalog identities differ')
 require(d.get('source_sha256')in (expected['source_sha256'],digest(expected['source'])),'declared source hash differs');caller=d.get('caller_sha256',{});require(caller.get(expected['caller_path'])==expected['caller_sha256'],'caller binding missing/stale')
 allhashes=dict(caller);allhashes.update(d.get('test_sha256',{}));allhashes.update(d.get('startup_source_sha256',{}));allhashes.update(d.get('actual_check',{}).get('startup_source_hashes',{}));test=d.get('test_context',{});
 if test:allhashes[test['path']]=test['sha256']
 for name,value in allhashes.items():require(name in expected['input_hashes']and value==expected['input_hashes'][name]and sha(root/name)==value,'test/caller/startup binding differs: '+name)
 require(all(name in allhashes for name in expected['input_hashes']),'report lacks exact caller/test/startup bindings')
 return {'role':role,'actual_agent':ROLES[role],'path':str(path.relative_to(base)),'sha256':sha(path),'original':{'path':str(p.relative_to(base)),'sha256':sha(p)}if original else None,'declared_source_hash_kind':'aggregate-frozen-source'if d['source_sha256']==expected['source_sha256']else'exact-literal-UTF8','actual_one_pair_and_caller_approved':True,'reviewer_test_execution_claimed':False}

def assemble(reports,write=False):
 root=ROOT;base=BASE;kit=base/'kit-v7';protected=[kit/'reviews/bg.json',kit/'review-proof-v7-validation.json'];before={str(p):sha(p)for p in protected};packetpath=base/'final-v7-online-qa/after-ui-fixes/my-colony-context-packet.json';packet=read(packetpath);require(sha(packetpath)=='103883f239ff367fef3e59c4881c81a0e77afd7fe1a42969c69026ab2f15acde','owner-frozen packet changed');manifest=read(kit/'manifest.json')
 for name,value in manifest['source_files'].items():require(sha(root/name)==value,'frozen source input changed')
 en_path='platform/packages/i18n/locales/en.json';bg_path='platform/packages/i18n/locales/bg.json';source=read(root/en_path)['My colony'];target=read(root/bg_path)['My colony'];require(packet['source']==source and packet['bulgarian']==target,'packet/catalog pair differs');test=packet['lifecycleTest'];inputs={packet['sourceFile']:packet['sha256'],test['file']:test['sha256'],**packet['startupOrder']['sourceHashes']}
 for name,value in inputs.items():require(sha(root/name)==value,'caller/test/startup source changed')
 expected={'packet_path':packetpath,'packet_sha256':sha(packetpath),'source':source,'target':target,'source_sha256':manifest['source_sha256'],'en_path':en_path,'bg_path':bg_path,'en_sha256':sha(root/en_path),'bg_sha256':sha(root/bg_path),'caller_path':packet['sourceFile'],'caller_sha256':packet['sha256'],'input_hashes':inputs}
 evidence=[verify_report(reports[r],r,expected)for r in ROLES]
 folder=packetpath.parent;unit=folder/'unit.log';exitfile=folder/'unit.exit';require(exitfile.read_text().strip()=='0'and re.search(r'Tests\s+9 passed \(9\)',unit.read_text()),'actual lifecycle tests did not report9pass/exit0');binding=read(folder/'final-component-binding.json');require(binding['finalHookSha256']==packet['sha256']and binding['finalTestSha256']==test['sha256'],'test producer source binding differs')
 pre=read(folder/'inputs-before-browser.json');post=read(folder/'inputs-after-browser.json');require(pre['files']==post['files'],'capture inputs changed');require(all(pre['files'].get(name)==value for name,value in inputs.items()),'caller/test/startup capture-input binding differs');clean=read(folder/'clean-commit-binding.json');require(clean['sourceByteIdentical']is True and clean['changed']==[] and clean['currentStatus']==[] and clean['fileCount']==len(post['files']),'clean commit input binding invalid');require(clean['currentHead']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'clean commit binding stale')
 require({str(p):sha(p)for p in protected}==before,'main V7record/proof changed');require(all(sha(base/e['path'])==e['sha256']for e in evidence),'review changed during validation')
 paths=[packetpath,unit,exitfile,folder/'final-component-binding.json',folder/'inputs-before-browser.json',folder/'inputs-after-browser.json',folder/'clean-commit-binding.json'];result={'result':'passed','scope':'Separate one-existing-key initial skin-document caller context only; no catalog or whole-review gate change','source_sha256':manifest['source_sha256'],'catalog_sha256':{'source_en':expected['en_sha256'],'online_bg':expected['bg_sha256']},'pair':{'id':'online:My colony','source':source,'target':target,'source_sha256':digest(source),'target_sha256':digest(target)},'caller_test_startup_sha256':inputs,'actual_role_evidence':evidence,'actual_context_pairs':1,'role_bindings':3,'focused_test_evidence':{'tests':9,'exit':0,'reviewers_executed_tests':False},'producer_revision':pre['head'],'clean_byte_equivalent_revision':clean['currentHead'],'producer_clean_input_files':clean['fileCount'],'current_caller_test_startup_files_rehashed':len(inputs),'main_record_proof_unchanged':{str(p.relative_to(base)):sha(p)for p in protected},'evidence':{str(p.relative_to(base)):sha(p)for p in paths},'limits':['Agent reviewed, not native-human certified.','No new whole-catalog linguistic, rendering or platform approval.','Saved/authored-name preservation is bounded to this exact caller/test and existing lifecycle review.']}
 if write:(HERE/'context-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 return result
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 for r in ROLES:parser.add_argument('--'+r,type=Path,required=True)
 parser.add_argument('--write',action='store_true');a=parser.parse_args();print(json.dumps(assemble({r:getattr(a,r)for r in ROLES},a.write),ensure_ascii=False,indent=2))
