"""Temporary context fixtures; no reviewer approvals are written as evidence."""
import copy,importlib.util,json,shutil,tempfile,unittest
from pathlib import Path
H=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('context_validator',H/'validate.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
class ContextTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(dir=H,prefix='mock-');self.addCleanup(self.temp.cleanup);self.work=Path(self.temp.name);self.root=self.work/'root';self.path=self.work/'mock-report.json';self.packet=v.BASE/'final-v7-online-qa/after-ui-fixes/my-colony-context-packet.json';p=v.read(self.packet);self.inputs={p['sourceFile']:p['sha256'],p['lifecycleTest']['file']:p['lifecycleTest']['sha256'],**p['startupOrder']['sourceHashes']}
  for name in self.inputs:
   q=self.root/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(v.ROOT/name,q)
  self.expected={'packet_path':self.packet,'packet_sha256':v.sha(self.packet),'source':p['source'],'target':p['bulgarian'],'source_sha256':v.read(v.BASE/'kit-v7/manifest.json')['source_sha256'],'en_path':'platform/packages/i18n/locales/en.json','bg_path':'platform/packages/i18n/locales/bg.json','en_sha256':v.sha(v.ROOT/'platform/packages/i18n/locales/en.json'),'bg_sha256':v.sha(v.ROOT/'platform/packages/i18n/locales/bg.json'),'caller_path':p['sourceFile'],'caller_sha256':p['sha256'],'input_hashes':self.inputs}
 def fixture(self,role):
  name=f'v7-{role}-my-colony-context-'+('final'if role=='adversarial'else'current-packet')+'.json';self.d=v.read(v.BASE/'linguistics'/name);self.d['test_fixture']=True;self.d['packet_path']=str(self.packet)
  if 'original_report_path'in self.d:self.d['original_report_path']=str(v.path_ref(self.d['original_report_path']))
  if 'original_frozen_report'in self.d:self.d['original_frozen_report']['path']=str(v.path_ref(self.d['original_frozen_report']['path']))
  self.role=role
 def check(self):
  self.path.write_text(json.dumps(self.d,ensure_ascii=False));return v.verify_report(self.path,self.role,self.expected,self.root,v.BASE)
 def test_all_three_actual_schema_positive(self):
  for role in v.ROLES:self.fixture(role);self.assertTrue(self.check()['actual_one_pair_and_caller_approved'])
 def test_missing_report(self):
  with self.assertRaises(OSError):v.verify_report(self.path,'semantic',self.expected,self.root,v.BASE)
 def test_stale_packet_rejected(self):
  self.fixture('semantic');self.d['packet_sha256']='bad'
  with self.assertRaisesRegex(ValueError,'packet'):self.check()
 def test_wrong_identity_and_pending_rejected(self):
  self.fixture('semantic');self.d['reviewer_identity']['agent']=v.ROLES['editor']
  with self.assertRaisesRegex(ValueError,'identity'):self.check()
  self.fixture('semantic');self.d['status']='pending'
  with self.assertRaisesRegex(ValueError,'approved'):self.check()
 def test_pair_and_literal_hash_changes_rejected(self):
  self.fixture('editor');self.d['entries'][0]['target']='MOCK CHANGED'
  with self.assertRaisesRegex(ValueError,'literal pair'):self.check()
  self.fixture('editor');self.d['entries'][0]['target_sha256']='bad'
  with self.assertRaisesRegex(ValueError,'literal hashes'):self.check()
 def test_original_report_identity_must_match(self):
  self.fixture('semantic');self.d['original_report_sha256']='bad'
  with self.assertRaisesRegex(ValueError,'original report'):self.check()
 def test_reading_and_catalog_assertions_required(self):
  self.fixture('semantic');self.d['actual_check']['current_packet_read_in_full']=False
  with self.assertRaisesRegex(ValueError,'actual recheck'):self.check()
  self.fixture('editor');self.d['catalog_sha256']['target_bg']='bad'
  with self.assertRaisesRegex(ValueError,'catalog'):self.check()
 def test_caller_and_test_file_bytes_rechecked(self):
  self.fixture('adversarial');(self.root/self.expected['caller_path']).write_text('MOCK changed source')
  with self.assertRaisesRegex(ValueError,'binding differs'):self.check()
  self.fixture('editor');shutil.copy2(v.ROOT/self.expected['caller_path'],self.root/self.expected['caller_path']);(self.root/'platform/apps/web/test/skin-document.test.tsx').write_text('MOCK changed test')
  with self.assertRaisesRegex(ValueError,'binding differs'):self.check()
 def test_missing_startup_binding_and_multiple_pairs_rejected(self):
  self.fixture('editor');self.d['startup_source_sha256'].pop('platform/apps/web/src/main.tsx')
  with self.assertRaisesRegex(ValueError,'lacks exact'):self.check()
  self.fixture('editor');self.d['entries']*=2
  with self.assertRaisesRegex(ValueError,'exactly one'):self.check()
if __name__=='__main__':unittest.main(verbosity=2)
