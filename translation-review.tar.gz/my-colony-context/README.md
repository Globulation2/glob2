# Existing-key guest colony-name context proof

`context-validation.json` and `independent-validation.json` bind the exact `My colony` / `Моята колония` pair at the fresh guest initialization caller. The owner-frozen current packet is `103883f239ff367fef3e59c4881c81a0e77afd7fe1a42969c69026ab2f15acde`. Semantic/editor supplied their own current-packet confirmations referencing unchanged original reports; adversary's original final report already binds this packet. Actual agents are `/root/v7_meaning`, `/root/v7_editor`, `/root/v7_adversary`. The proof accounts for one pair and three actual context approvals, with no full-catalog or runtime/platform approval inferred.

The validator checks literal hashes and catalogs, the caller `fe942498…`, lifecycle test `b067a94e…`, startup source hashes, explicit actual-reading assertions, current packet and original report references. The producer's focused test result is independently bound to nine passing tests/exit zero and before/after source manifests. `clean-commit-binding.json` records 1,637 source inputs equivalent to clean `f3b568c8…`; this validator checks that producer record, manifest agreement and the four relevant caller/test/startup files against current bytes. It does not claim to rehash the entire producer's 1,637-file inventory. Reviewers inspected tests but did not execute them.

Main V7 review record and proof remain byte-identical (`1a2e8d54…`, `7871dc67…`). No translations or gate values were changed. User/authored names are covered only by the exact initialization/lifecycle context and actual role assessments, not guessed from text.

Read-only reproduction:

```sh
python3 artifacts/bulgarian/my-colony-context/validate.py --semantic artifacts/bulgarian/linguistics/v7-semantic-my-colony-context-current-packet.json --editor artifacts/bulgarian/linguistics/v7-editor-my-colony-context-current-packet.json --adversarial artifacts/bulgarian/linguistics/v7-adversarial-my-colony-context-final.json
python3 artifacts/bulgarian/my-colony-context/verify_written.py
```

Nine context-validator regressions, 20 publisher curation regressions and 13 final-evidence contract tests pass. Fixtures are temporary and removed; no mock review is published as an actual approval. Publisher prepared-source selection includes only top-level scripts/docs and preparation metadata in `browser-final-v7`. Future static packages, profiles, capture images and handoff results are excluded from that source selection; actual runtime evidence remains explicit through `--browser-selection`. No PREP, inventory, build, provider call or publication ran.
