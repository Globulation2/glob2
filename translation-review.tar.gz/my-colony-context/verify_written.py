"""Independent written-file context binding check, no new linguistic approval."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';H=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();utf=lambda x:hashlib.sha256(x.encode()).hexdigest()
p=read(H/'context-validation.json');packet=read(B/'final-v7-online-qa/after-ui-fixes/my-colony-context-packet.json');assert p['actual_context_pairs']==1 and p['role_bindings']==3
assert p['pair']['source']==read(R/'platform/packages/i18n/locales/en.json')['My colony']==packet['source'];assert p['pair']['target']==read(R/'platform/packages/i18n/locales/bg.json')['My colony']==packet['bulgarian'];assert p['pair']['source_sha256']==utf(p['pair']['source'])and p['pair']['target_sha256']==utf(p['pair']['target'])
for name,value in p['caller_test_startup_sha256'].items():assert sha(R/name)==value
for name,value in p['main_record_proof_unchanged'].items():assert sha(B/name)==value
for name,value in p['evidence'].items():assert sha(B/name)==value
roles={'semantic':'/root/v7_meaning','editor':'/root/v7_editor','adversarial':'/root/v7_adversary'};assert {e['role']for e in p['actual_role_evidence']}==set(roles)
for evidence in p['actual_role_evidence']:
 d=read(B/evidence['path']);assert sha(B/evidence['path'])==evidence['sha256'];assert d['reviewer_identity']['agent']==roles[evidence['role']]and d['status']=='approved';assert d['packet_sha256']==sha(B/'final-v7-online-qa/after-ui-fixes/my-colony-context-packet.json')
 entries=d.get('entries',[d['entry']]if 'entry'in d else[]);assert len(entries)==1;entry=entries[0];assert entry['source']==p['pair']['source']and entry['target']==p['pair']['target'];assert entry['source_sha256']==p['pair']['source_sha256']and entry['target_sha256']==p['pair']['target_sha256']
 if evidence['original']:
  original=evidence['original'];assert sha(B/original['path'])==original['sha256'];old=read(B/original['path']);assert old['reviewer_identity']['agent']==roles[evidence['role']];assert old['entries'][0]['source']==entry['source']and old['entries'][0]['target']==entry['target']
 if evidence['role']=='semantic':assert d['actual_check']['current_packet_read_in_full']is True and d['actual_check']['source_target_exactly_recompared']is True and d['actual_check']['startup_source_files_freshly_read']is True
 elif evidence['role']=='editor':assert d['actual_complete_fresh_metadata_and_source_read']is True and entry['actual_complete_fresh_context_read']is True
 else:assert d['actual_fresh_complete_source_target_read']is True and entry['actual_fresh_complete_source_target_read']is True
assert p['focused_test_evidence']=={'tests':9,'exit':0,'reviewers_executed_tests':False};assert (B/'final-v7-online-qa/after-ui-fixes/unit.exit').read_text().strip()=='0';assert '9 passed (9)'in(B/'final-v7-online-qa/after-ui-fixes/unit.log').read_text()
result={'result':'passed','scope':'Independent mechanical one-existing-key caller-context binding only; no whole-catalog or rendering/platform approval','context_pairs':1,'actual_role_bindings':3,'proof_sha256':sha(H/'context-validation.json'),'source_sha256':p['source_sha256'],'catalog_sha256':p['catalog_sha256'],'caller_sha256':packet['sha256'],'test_sha256':packet['lifecycleTest']['sha256'],'actual_focused_tests':9,'main_record_and_proof_byte_unchanged':True,'runtime_gates_mutated':False,'producer_clean_byte_equivalent_revision':p['clean_byte_equivalent_revision']}
(H/'independent-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
