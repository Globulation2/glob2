Current V8 scoped gate finalization support — prepared only

The exact current pre-runtime record462fb8… / linguistic proof5b6be5… / independent2e3051… are copied read-only under pre-runtime/. The original V7 implementation remains historical; this directory is the tested V8 implementation. Main record and all gates remain untouched.

Root fills root-config.pending.json into a NEW concrete config after actual runtime evidence and clean final source are ready. Pending templates intentionally fail closed. Set approval_state=approved only after personally accepting the actual referenced report scope; fill exact40-character final revision, exact source/catalog hashes, scopes/limits, references and source whitelist. Do not invent missing report paths. All references are artifacts/bulgarian-relative path+SHA256 of actual closed reports.

Authorized scope is exactly six passed gates (language_brief,source_based_pilot,structural,desktop_rendering,phone_rendering,browser_startup), and three UNAVAILABLE aggregates(native_platforms,browser_platforms,mobile_platforms). An emulated phone screenshot supports its declared rendering scope; it never establishes physical mobile execution. Any untested native OS/architecture/browser/variant/device coverage must remain explicit. This is never a full-nine-gate audit pass.

The record mutation allowlist contains gates, two technical-finding resolutions and final_verification only. All other top-level fields and complete nested linguistic/review/English exceptions/actual role identities/proof metadata must be exactly unchanged. Technical finding IDs/order/severity/reason remain exact; only statistics-empty-notice-wrap and script-editor-compact-status-and-labels may change state/resolution/evidence. Their real nativeV9 plus current affectedV10 evidence is mandatory. No gate is passed merely by this tool inspecting a filename or report hash: root approval is the actual acceptance decision; the tool enforces exact evidence bindings and unchanged linguistic fields.

Required report groups (every group nonempty before finalization): linguistic; compatibility_mr_ta_te; os_resources; font_delta; runtime_carry; desktop; phone; startup; layout_resolutions. Current linguistic/MR/TA/TE/platform3 evidence is prefilled. New33flat-target font supplement needs396actualmeasurements across12combos;6402otherliteralvalues are exact. Runtime closure must preserve actual old producer/catalog identities and bind new bundles/API resource/SPA captures without relabeling old receipts. Required groups still pending remain empty.

Source closure schema supplied through verification.source_closure:

    {"schema_version":1,"final_revision":"<actual40hex>","limits":["actual limits"],
     "components":[{"id":"native-or-browser-or-spa-unique-id", "producer_revision":"<actual40hex>",
       "producer_binding":{"path":"<actual report>","sha256":"<actual64hex>"},
       "limitations":["actual scope and omissions"],"changes":[
         {"path":"<actual repo-relative changed path>",
          "classification":"test-only|presentation-only|catalog-target-only|packaging-only|documentation-only",
          "before_sha256":"<actual64hex or null when absent>","final_sha256":"<actual64hex or null when absent>",
          "evidence":[{"path":"<actual closure report>","sha256":"<actual64hex>"}]}]}]}

Each component declares EVERY actual git diff --no-renames --name-only path from its real producer to final revision. An exact same-revision producer has changes:[]. Both before/final blob hashes are checked with git show; missing files use null. Actual producer binding and component limits remain explicit. Root config approved_source_changes contains the exact flattened rows {component,path,classification,before_sha256,final_sha256}; source changes require real evidence and cannot be silently omitted. This proves exact identities/declared whitelist, not by itself that a changed UI surface can reuse old visual approval. The runtime-carry evidence supplies that actual scoped judgment.

Once complete (no commands below have been applied here):

    python3 artifacts/bulgarian/gate-finalization-v8/finalize.py --config <actual-root-config>
    python3 artifacts/bulgarian/gate-finalization-v8/finalize.py --config <actual-root-config> --apply
    python3 artifacts/bulgarian/gate-finalization-v8/independent_check.py --config <actual-root-config>
    python3 artifacts/bulgarian/gate-finalization-v8/prepare_publication.py --config <actual-root-config> --output <new-actual-final-evidence-json>

Default finalizer validates without writing. --apply requires clean exact finalHEAD, exact pre-runtime live record, current registered/frozen source/catalog agreement, unchanged linguistic proof and zero non-waivable core audit errors; it writes the gate-only record and finalization-validation.json. Independent checker rejects unauthorized linguistic/technical/gate changes and rehashes actual evidence. Publication config generation requires that exact written finalization and independent proof, then gathers all required evidence refs without manufacturing statuses. final-evidence.pending.json is deliberately invalid and never means readiness.

Root may then use the existing publisher --final-evidence <actual-json> (PREP only by default). All old capture selections plus explicit current native/browser selection inputs remain required as appropriate. No PREP inventory/publication/build or main record update was performed by this task. Ten focused finalizer regressions pass; existing96postvisual/TE/publisher/contract checks were not redundantly rerun.

Actual dirty-producer closure variant (current evidence)

current-source-closure.json + current-source-closure-validation.json are mechanically validated against actual Git blobs and frozen inventory files. They retain actual SPA producerHEAD2ac54f with its recorded dirty status, clean anchor3810, and finalb148. Exactly1644frozen input hashes match before/after capture:1641trackedinputs match actual3810Gitblobs;3explicit tools/music/glob2music/__pycache__/*.pyc are historical development-cache inventory records, NOT clean-Git source blobs. They are not published as cache payloads. Dist inventories match exactly. From3810to b148only the Telugu test and preview harness differ; within the1641trackedinputs only the Telugu test differs, and no production input changed. Dirty capture receipts retain their actual2ac54f identity.

Component kind=frozen-inputs adds frozen_input_revision (clean anchor), frozen_inputs_before/after and artifact_inventory_before/after path+SHA references, plus explicit non_git_inputs cache-only classifications. changes describe clean-anchor→final diffs, not misleading dirtyHEAD→final categories. Tracked inventories are verified in one git cat-file batch. Clean producer kind=git-tree keeps the original exact diff variant. Categories now also permit harness-only,upstream-master-integration,compatibility-namespace, but root must truthfully declare/justify every actual path: these categories alone never authorize runtime carry. A production input changed after the frozen clean anchor cannot pass the dirty-input variant as unchanged runtime. Historical EA0V9 native/V8browser carry is restricted to actual compared components/corpus in its own evidence, without claiming all upstream integration was presentation-only.

root-config.pending.json is now populated with concreteb148/currentlinguistic identities and actual ready language/pilot/structural, font396, nativeV9personalreview, scopedoldcarry/sourcecomparison and new12SPA approval refs. Overall approval remains PENDING; desktop/phone/startup and both technical resolutions remain PENDING until root accepts final current V10preview/browser receipts. Missing startup/layout-resolution report groups remain empty, so apply/publication cannot pass. prepare_current_closure.py reconstructs only the two already-completed SPA/font-source components; it does not invent a pending browser or preview producer.

13focusedfinalizer regressions pass, including valid dirtyHEAD+nonGitcache provenance and rejection of unclassified nonGit or changed production inputs. One new focused publisher test confirms actual after-postvisual-33/after-credit-fix capture/proof directories are curated while profiles remain excluded. Older unrelated regressions were not rerun. Default publisher remains PREP; no PREP inventory/publication was run.
