import copy,importlib.util,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import subprocess,hashlib
H=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('finalizer',H/'finalize.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
s=importlib.util.spec_from_file_location('independent',H/'independent_check.py');i=importlib.util.module_from_spec(s);s.loader.exec_module(i)
class FinalizerTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=H,prefix='mock-');self.addCleanup(self.tmp.cleanup);self.base=Path(self.tmp.name);self.e=self.base/'fixture-report.json';self.e.write_text('{"test_fixture":true}');self.ref={'path':self.e.name,'sha256':f.sha(self.e)};self.before=f.read(H/'pre-runtime/bg.json');self.c=f.read(H/'root-config.pending.json');self.c.update(approval_state='approved',revision='a'*40,scope='Mock scope only',limits=['Mock explicit limitation']);self.c['gates']={name:{'status':'unavailable'if name in f.PLATFORMS else'passed','scope':'Mock actual scope','limitations':['Mock limitation'],'reason':'Mock unavailable coverage'if name in f.PLATFORMS else'','evidence':[self.ref]}for name in f.GATES};self.c['technical_resolutions']={name:{'state':'resolved','resolution':'Mock actual layout report','evidence':[self.ref]}for name in f.FINDINGS};self.c['required_reports']={name:[self.ref]for name in f.REQUIRED_REPORT_GROUPS};self.c['verification']={'final_revision':self.c['revision'],'source_closure':self.ref,'render_evidence':[self.ref],'limits':['Mock exact producer identity retained']}
 def candidate(self):return f.build_candidate(self.before,self.c,self.base)
 def test_valid_scoped_candidate_and_independent_checker(self):
  after=self.candidate();self.assertTrue(i.check_record(self.before,after,self.c,self.base));self.assertEqual(sum(g['passed']for g in after['gates'].values()),6)
 def test_pending_root_config_fails_closed(self):
  self.c['approval_state']='PENDING'
  with self.assertRaises(ValueError):self.candidate()
 def test_missing_or_rewritten_actual_reference_fails(self):
  self.e.write_text('changed')
  with self.assertRaisesRegex(ValueError,'hash differs'):self.candidate()
 def test_full_audit_or_passed_platform_not_authorized(self):
  self.c['mode']='full-audit'
  with self.assertRaises(ValueError):self.candidate()
  self.c['mode']='scoped-verification';self.c['gates']['mobile_platforms']['status']='passed'
  with self.assertRaises(ValueError):self.candidate()
 def test_nonplatform_gate_cannot_be_unavailable(self):
  self.c['gates']['phone_rendering'].update(status='unavailable',reason='No physical phone')
  with self.assertRaises(ValueError):self.candidate()
 def test_linguistic_change_rejected_by_both_independent_masks(self):
  after=self.candidate();after['accepted_english'][0]['reason']='Unapproved replacement'
  with self.assertRaises(ValueError):f.assert_allowed_changes(self.before,after)
  with self.assertRaises(ValueError):i.check_record(self.before,after,self.c,self.base)
 def test_technical_identity_and_unrelated_resolution_cannot_change(self):
  after=self.candidate();after['technical_findings'][1]['severity']='minor'
  with self.assertRaises(ValueError):f.assert_allowed_changes(self.before,after)
  after=self.candidate();after['technical_findings'][0]['resolution']='unrelated'
  with self.assertRaises(ValueError):i.check_record(self.before,after,self.c,self.base)
 def test_report_groups_and_missing_layout_evidence_fail_closed(self):
  self.c['required_reports']['font_delta']=[]
  with self.assertRaisesRegex(ValueError,'pending required report'):self.candidate()
  self.c['required_reports']['font_delta']=[self.ref];self.c['technical_resolutions']['statistics-empty-notice-wrap']['evidence']=[]
  with self.assertRaises(ValueError):self.candidate()
 def test_independent_rejects_lost_platform_limit_and_replaced_proof(self):
  after=self.candidate();after['gates']['mobile_platforms']['reason']=''
  with self.assertRaises(ValueError):i.check_record(self.before,after,self.c,self.base)
  after=self.candidate();after['review_proof']['sha256']='b'*64
  with self.assertRaises(ValueError):i.check_record(self.before,after,self.c,self.base)
 def test_source_closure_exact_git_paths_and_both_blobs(self):
  before=b'before';after=b'after';row={'path':'src/ui/mock.cpp','classification':'presentation-only','before_sha256':hashlib.sha256(before).hexdigest(),'final_sha256':hashlib.sha256(after).hexdigest(),'evidence':[self.ref]};body={'schema_version':1,'final_revision':'a'*40,'limits':['Mock limitation'],'components':[{'id':'native','producer_revision':'b'*40,'producer_binding':self.ref,'limitations':['Mock exact source evidence only'],'changes':[row]}]};path=self.base/'closure.json';path.write_text(json.dumps(body));ref={'path':path.name,'sha256':f.sha(path)};allowed=[{'component':'native',**{k:row[k]for k in('path','classification','before_sha256','final_sha256')}}]
  def blobs(args,**kwargs):return subprocess.CompletedProcess(args,0,before if args[-1].startswith('b'*40)else after,b'')
  with patch.object(f.subprocess,'check_output',return_value='src/ui/mock.cpp\n'),patch.object(f.subprocess,'run',side_effect=blobs):self.assertTrue(f.verify_closure(ref,'a'*40,allowed,self.base,self.base)['producer_revisions_retained'])
  with patch.object(f.subprocess,'check_output',return_value='src/ui/mock.cpp\nsrc/unlisted.cpp\n'):
   with self.assertRaisesRegex(ValueError,'omitted/duplicated'):f.verify_closure(ref,'a'*40,allowed,self.base,self.base)
 def frozen_fixture(self):
  def write(name,value):
   p=self.base/name;p.write_text(json.dumps(value));return {'path':name,'sha256':f.sha(p)}
  h=hashlib.sha256(b'actual source').hexdigest();producer='b'*40;anchor='c'*40;files={'src/mock.ts':h,'tools/__pycache__/mock.pyc':h};status=[' M src/mock.ts'];item={'producer_revision':producer,'frozen_input_revision':anchor,'frozen_inputs_before':write('before.json',{'head':producer,'status':status,'files':files}),'frozen_inputs_after':write('after.json',{'head':anchor,'status':[],'files':files}),'artifact_inventory_before':write('dist-before.json',{'bundle.js':h}),'artifact_inventory_after':write('dist-after.json',{'bundle.js':h}),'producer_binding':write('binding.json',{'actualProducerHead':producer,'actualProducerStatus':status,'afterHead':anchor,'inputFileCount':2}),'non_git_inputs':{'tools/__pycache__/mock.pyc':'development-python-bytecode-cache'},'changes':[]};return item,h
 def test_actual_dirty_producer_inventory_variant_keeps_head_and_cache_limits(self):
  item,h=self.frozen_fixture()
  with patch.object(f.subprocess,'check_output',return_value='src/mock.ts\n'),patch.object(f,'git_blob_hashes',return_value={'src/mock.ts':h}):result=f.verify_frozen_inputs(item,'d'*40,self.base,self.base)
  self.assertEqual(result['actual_dirty_producer_head'],'b'*40);self.assertEqual(result['tracked_input_files_git_verified'],1);self.assertTrue(result['non_git_inputs_are_historical_inventory_only_not_final_git_blobs'])
 def test_unclassified_non_git_input_fails_closed(self):
  item,h=self.frozen_fixture();item['non_git_inputs']={}
  with patch.object(f.subprocess,'check_output',return_value='src/mock.ts\n'):
   with self.assertRaisesRegex(ValueError,'explicit cache-only'):f.verify_frozen_inputs(item,'d'*40,self.base,self.base)
 def test_dirty_producer_cannot_carry_changed_production_input(self):
  item,h=self.frozen_fixture();item['changes']=[{'path':'src/mock.ts','classification':'presentation-only'}]
  with patch.object(f.subprocess,'check_output',return_value='src/mock.ts\n'),patch.object(f,'git_blob_hashes',side_effect=[{'src/mock.ts':h},{'src/mock.ts':'e'*64}]):
   with self.assertRaisesRegex(ValueError,'production frozen input changed'):f.verify_frozen_inputs(item,'d'*40,self.base,self.base)
if __name__=='__main__':unittest.main()
