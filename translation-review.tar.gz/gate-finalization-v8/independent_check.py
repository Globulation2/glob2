"""Independent narrow written-gate mutation audit; never assigns a gate pass."""
from pathlib import Path
import argparse,hashlib,json
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';H=Path(__file__).resolve().parent
BASELINE='462fb8c6aed1d0cae874bcb3dd098d0c8b9fc5e12a5e7850d4c9057c03c97a3d';PLATFORMS={'native_platforms','browser_platforms','mobile_platforms'};FINDINGS={'statistics-empty-notice-wrap','script-editor-compact-status-and-labels'}
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,message):
 if not ok:raise ValueError(message)
def check_record(before,after,config,base=B):
 omit={'gates','technical_findings','final_verification'};require({k:v for k,v in before.items()if k not in omit}=={k:v for k,v in after.items()if k not in omit},'unauthorized linguistic/review delta');require(set(after)==set(before)|{'final_verification'},'unauthorized top-level delta');require(config.get('approval_state')=='approved'and config.get('authorized_by')=='/root'and config.get('mode')=='scoped-verification','root-approved scoped evidence required');require(after['source_sha256']==config['source_sha256']and after['catalog_sha256']==config['catalog_sha256'],'source/catalog identity changed')
 def ref(r):
  p=base/r['path'];require(not Path(r['path']).is_absolute()and '..'not in Path(r['path']).parts and p.is_file()and not p.is_symlink()and sha(p)==r['sha256'],'missing/mismatched evidence')
 require(set(after['gates'])==set(before['gates'])==set(config['gates']),'gate membership differs')
 for name,item in config['gates'].items():
  gate=after['gates'][name];expected='unavailable'if name in PLATFORMS else'passed';require(item['status']==expected and gate['status']==expected and gate['passed']==(expected=='passed'),'gate status not authorized');require(gate['source_sha256']==after['source_sha256']and gate['catalog_sha256']==after['catalog_sha256'],'gate not source-bound');require(gate['scope']==item['scope']and gate['limitations']==item['limitations']and gate['reason']==item.get('reason',''),'gate scope/limits differ');require(gate['evidence']==[{'path':'../'+e['path'],'sha256':e['sha256']}for e in item['evidence']],'gate evidence differs')
  for evidence in item['evidence']:ref(evidence)
  require(item['evidence']if expected=='passed'else bool(item['reason']),'gate lacks actual evidence/unavailable reason')
 require([f['id']for f in before['technical_findings']]==[f['id']for f in after['technical_findings']],'technical finding membership changed')
 for old,new in zip(before['technical_findings'],after['technical_findings']):
  if old['id']not in FINDINGS:require(old==new,'unrelated technical finding changed');continue
  allowed={'state','resolution','evidence'};require({k:v for k,v in old.items()if k not in allowed}=={k:v for k,v in new.items()if k not in allowed},'technical identity/severity/reason changed');require({k:new[k]for k in allowed}==config['technical_resolutions'][old['id']]and new['state']=='resolved'and new['resolution']and new['evidence'],'technical resolution differs')
  for evidence in new['evidence']:ref(evidence)
 for group in config['required_reports'].values():
  require(bool(group),'required report group pending')
  for evidence in group:ref(evidence)
 for evidence in [config['verification']['source_closure'],*config['verification']['render_evidence']]:ref(evidence)
 meta=after['final_verification'];require(set(meta)=={'revision','mode','scope','limits','source_sha256','catalog_sha256','actual_render_source_closure','pre_runtime_record_sha256','required_reports','claim_boundary'}and meta['source_sha256']==after['source_sha256']and meta['catalog_sha256']==after['catalog_sha256'],'unexpected final metadata change');require(meta['revision']==config['revision']and meta['mode']=='scoped-verification'and meta['scope']==config['scope']and meta['limits']==config['limits'],'final verification metadata differs');require(meta['pre_runtime_record_sha256']==BASELINE and meta['actual_render_source_closure']==config['verification']and meta['required_reports']==config['required_reports'],'final metadata loses baseline/source/actual-report binding');return True
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--config',type=Path,required=True);a=ap.parse_args();before=H/'pre-runtime/bg.json';require(sha(before)==BASELINE,'snapshot identity changed');record=B/'kit-v8/reviews/bg.json';config=read(a.config);check_record(read(before),read(record),config);finalization=read(H/'finalization-validation.json');require(finalization['final_record']['sha256']==sha(record)and finalization['config']['sha256']==sha(a.config),'finalization proof stale');result={'result':'passed','scope':'Independent allowed-field/gate/evidence identity check only; no new review or runtime judgment','pre_runtime_record_sha256':BASELINE,'record_sha256':sha(record),'config_sha256':sha(a.config),'finalization_proof_sha256':sha(H/'finalization-validation.json'),'all_core_linguistic_fields_unchanged':True,'unavailable_gates':sorted(PLATFORMS),'full_nine_gate_audit_passed':False};(H/'finalization-independent-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
