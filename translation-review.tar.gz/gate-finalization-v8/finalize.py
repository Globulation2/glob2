"""Narrow root-authorized gate finalization; no translation/review fabrication."""
from pathlib import Path
import argparse,copy,hashlib,importlib.util,json,re,subprocess,io
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'artifacts/bulgarian';HERE=Path(__file__).resolve().parent
BASELINE_SHA='462fb8c6aed1d0cae874bcb3dd098d0c8b9fc5e12a5e7850d4c9057c03c97a3d'
GATES=('language_brief','source_based_pilot','structural','desktop_rendering','phone_rendering','browser_startup','native_platforms','browser_platforms','mobile_platforms')
PLATFORMS={'native_platforms','browser_platforms','mobile_platforms'}
FINDINGS={'statistics-empty-notice-wrap','script-editor-compact-status-and-labels'}
REQUIRED_REPORT_GROUPS={'linguistic','compatibility_mr_ta_te','os_resources','font_delta','runtime_carry','desktop','phone','startup','layout_resolutions'}
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def require(v,msg):
 if not v:raise ValueError(msg)
def reference(ref,base=BASE):
 require(isinstance(ref,dict)and set(ref)=={'path','sha256'},'evidence requires exactly path and sha256');name=ref['path'];require(isinstance(name,str)and name and not Path(name).is_absolute()and '..'not in Path(name).parts,'evidence path must be relative without traversal');p=base/name;require(p.is_file()and not p.is_symlink(),'missing/nonregular evidence: '+name);require(re.fullmatch('[0-9a-f]{64}',str(ref['sha256']))and sha(p)==ref['sha256'],'evidence hash differs: '+name);return p

def linguistic_projection(record):return {k:v for k,v in record.items()if k not in {'gates','technical_findings','final_verification'}}
def assert_allowed_changes(before,after):
 require(linguistic_projection(before)==linguistic_projection(after),'core linguistic/review field changed');require(set(after)==set(before)|{'final_verification'},'unexpected top-level change')
 old=before['technical_findings'];new=after['technical_findings'];require([f['id']for f in old]==[f['id']for f in new],'technical finding membership/order changed')
 for a,b in zip(old,new):
  if a['id']not in FINDINGS:require(a==b,'unrelated technical finding changed');continue
  require({k:v for k,v in a.items()if k not in {'state','resolution','evidence'}}=={k:v for k,v in b.items()if k not in {'state','resolution','evidence'}},'technical finding identity/severity/reason changed');require(b['state']=='resolved'and b.get('resolution','').strip()and b.get('evidence'),'layout finding lacks actual resolution/evidence')

def git_blob_hashes(revision,paths,root=ROOT):
 require(all(isinstance(name,str)and name and '\n'not in name and not Path(name).is_absolute()and '..'not in Path(name).parts for name in paths),'unsafe frozen input path');raw=subprocess.check_output(['git','cat-file','--batch'],input=''.join(revision+':'+name+'\n'for name in paths).encode(),cwd=root);stream=io.BytesIO(raw);result={}
 for name in paths:
  header=stream.readline().decode().strip().split();require(len(header)==3 and header[1]=='blob','frozen input absent from actual git tree: '+name);size=int(header[2]);data=stream.read(size);require(len(data)==size and stream.read(1)==b'\n','invalid git batch framing');result[name]=hashlib.sha256(data).hexdigest()
 require(stream.read()==b'','unexpected git batch output');return result

def verify_frozen_inputs(item,revision,base=BASE,root=ROOT):
 before=read(reference(item['frozen_inputs_before'],base));after=read(reference(item['frozen_inputs_after'],base));artifact_before=read(reference(item['artifact_inventory_before'],base));artifact_after=read(reference(item['artifact_inventory_after'],base));binding=read(reference(item['producer_binding'],base));anchor=item['frozen_input_revision'];require(before['head']==item['producer_revision']and bool(before['status']),'actual dirty producer HEAD/status not preserved');require(after['head']==anchor and after['status']==[],'clean frozen-input anchor missing');files=before['files'];require(files and files==after['files'],'frozen capture inputs changed');require(artifact_before and artifact_before==artifact_after,'captured artifact inventory changed');require(binding['actualProducerHead']==before['head']and binding['actualProducerStatus']==before['status']and binding['afterHead']==anchor and binding['inputFileCount']==len(files),'producer closure binding differs');tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',anchor],cwd=root,text=True).splitlines());non_git=set(files)-tracked;classifications=item.get('non_git_inputs',{});require(set(classifications)==non_git and all(value=='development-python-bytecode-cache'and '__pycache__'in Path(name).parts and name.endswith('.pyc')for name,value in classifications.items()),'non-Git inputs require explicit cache-only classification');tracked_files={name:h for name,h in files.items()if name in tracked};require(git_blob_hashes(anchor,list(tracked_files),root)==tracked_files,'frozen source inventory differs from clean anchor git blobs');final=git_blob_hashes(revision,list(tracked_files),root);changed={name for name in tracked_files if final[name]!=tracked_files[name]};rows={row['path']:row for row in item['changes']};require(changed<=set(rows)and all(rows[name]['classification']in ('test-only','harness-only','documentation-only')for name in changed),'production frozen input changed after clean anchor');return {'actual_dirty_producer_head':before['head'],'actual_dirty_status':before['status'],'frozen_clean_anchor':anchor,'frozen_input_files':len(files),'tracked_input_files_git_verified':len(tracked_files),'non_git_frozen_inputs':classifications,'non_git_inputs_are_historical_inventory_only_not_final_git_blobs':True,'artifact_files':len(artifact_before),'final_input_changes':sorted(changed),'limits':'Exact original input/artifact inventory closure only; producer retains original dirty HEAD; no actual capture/execution relabelled to clean revision.'}

def verify_scoped_components(item,revision,root=ROOT,base=BASE):
 require(item.get('scope','').strip()and item.get('limitations')and item.get('component_identities'),'explicit narrow component scope/limits required');producer=item['producer_revision'];rows=item['component_identities'];require(len(rows)==len({r['path']for r in rows}),'duplicate scoped component path');before=git_blob_hashes(producer,[r['path']for r in rows],root);after=git_blob_hashes(revision,[r['path']for r in rows],root);validated=[]
 for row in rows:
  name=row['path'];require(before[name]==row['before_sha256']and after[name]==row['final_sha256'],'scoped component actual git blob differs');relation=row['classification'];require(row.get('evidence'),'scoped component evidence required');reports=[read(reference(e,base))for e in row['evidence']]
  if relation=='scope-byte-identical':require(before[name]==after[name],'scoped component is not byte-identical')
  elif relation=='bg-predicate-equivalent':
   require(name=='libgag/src/TrueTypeFont.cpp','BG predicate relation restricted to actual font implementation');require(any(d.get('result')=='passed'and d.get('old_sha256')==before[name]and d.get('new_sha256')==after[name]and d.get('BG_predicate_result_unchanged_for_both_scripts_states')is True and d.get('only_code_change')=='Append language==fil disjunct to authoredDrawWidth predicate; accompanying comment addsFilipino'for d in reports),'exact BG predicate proof not bound to actual blobs')
  elif relation=='glyph-geometry-equivalent':
   require(name=='browser/assets/sans-core.ttf','glyph geometry relation restricted to starter font');require(any(d.get('result')=='passed'and d.get('old_core_sha256')==before[name]and d.get('new_core_sha256')==after[name]and d.get('all_old_glyph_bytes_equal')is True and d.get('all_old_decomposed_outlines_equal')is True and d.get('all_old_horizontal_metrics_equal')is True and d.get('core_binary_byte_identical')is False for d in reports),'exact glyph geometry proof not bound to actual font blobs')
  else:raise ValueError('unknown scoped component relation')
  validated.append({k:row[k]for k in('path','classification','before_sha256','final_sha256')})
 return {'id':item['id'],'closure_kind':'scoped-components','producer_revision':producer,'final_revision':revision,'scope':item['scope'],'validated_component_identities':validated,'limitations':item['limitations'],'no_whole_source_or_runtime_equivalence_inferred':True},validated

def verify_closure(ref,revision,approved_changes,root=ROOT,base=BASE):
 p=reference(ref,base);d=read(p);require(d.get('schema_version')==1 and d.get('final_revision')==revision,'source closure revision/schema differs');require(d.get('limits')and d.get('components'),'source closure components/limits required');seen=set();validated=[];declared=[]
 for item in d['components']:
  name=item['id'];require(name not in seen,'duplicate source closure component');seen.add(name);producer=item['producer_revision'];kind=item.get('kind','git-tree');require(kind in ('git-tree','frozen-inputs','scoped-components'),'unknown source closure kind');
  if kind=='scoped-components':
   reference(item['producer_binding'],base);result,rows=verify_scoped_components(item,revision,root,base);validated.append(result);declared.extend({'component':name,**row}for row in rows);continue
  anchor=item['frozen_input_revision']if kind=='frozen-inputs'else producer;frozen=verify_frozen_inputs(item,revision,base,root)if kind=='frozen-inputs'else None;require(re.fullmatch('[0-9a-f]{40}',producer)and re.fullmatch('[0-9a-f]{40}',revision),'exact producer/final git revisions required');reference(item['producer_binding'],base);require(item.get('limitations')and isinstance(item.get('changes'),list),'component source closure limits/changes required');actual=set(subprocess.check_output(['git','diff','--no-renames','--name-only',anchor,revision],cwd=root,text=True).splitlines());rows=item['changes'];require(len(rows)==len({r['path']for r in rows})and actual=={r['path']for r in rows},'source closure omitted/duplicated actual git paths')
  for row in rows:
   require(row['classification']in ('test-only','presentation-only','catalog-target-only','packaging-only','documentation-only','harness-only','upstream-master-integration','compatibility-namespace'),'unknown source change class');require(row.get('evidence'),'changed source path requires actual closure evidence')
   for evidence in row['evidence']:reference(evidence,base)
   for rev,field in ((anchor,'before_sha256'),(revision,'final_sha256')):
    result=subprocess.run(['git','show',rev+':'+row['path']],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);actual_hash=hashlib.sha256(result.stdout).hexdigest()if result.returncode==0 else None;require(actual_hash==row[field],'source closure actual blob differs')
   declared.append({'component':name,**{k:row[k]for k in ('path','classification','before_sha256','final_sha256')}})
  validated.append({'id':name,'producer_revision':producer,'comparison_anchor_revision':anchor,'closure_kind':kind,'frozen_input_validation':frozen,'final_revision':revision,'actual_changed_paths':sorted(actual),'producer_binding':item['producer_binding'],'limitations':item['limitations']})
 require(sorted(declared,key=canonical)==sorted(approved_changes,key=canonical),'source changes differ from explicit root-approved whitelist');return {'components':validated,'limits':d['limits'],'producer_revisions_retained':True,'no_unaffected_runtime_claim_inferred':True}

def build_candidate(before,config,base=BASE):
 require(config.get('schema_version')==1 and config.get('approval_state')=='approved'and config.get('authorized_by')=='/root','root finalization approval is pending');require(config.get('mode')=='scoped-verification','this finalizer is authorized only for scoped verification');require(config['source_sha256']==before['source_sha256']and config['catalog_sha256']==before['catalog_sha256'],'source/catalog identity differs');require(config.get('scope','').strip()and config.get('limits')and all(isinstance(v,str)and v.strip()for v in config['limits']),'actual scope/limits required');gates=config.get('gates',{});require(set(gates)==set(GATES),'exactly nine gate updates required');out=copy.deepcopy(before);out['gates']={}
 for name,item in gates.items():
  status=item.get('status');require(status in ('passed','unavailable'),'pending gate '+name);require(item.get('scope','').strip()and isinstance(item.get('limitations'),list),'gate scope and explicit limitations required');refs=item.get('evidence',[]);require(isinstance(refs,list),'gate evidence must be list');require(len({r.get('path')for r in refs})==len(refs),'duplicate gate evidence')
  for ref in refs:reference(ref,base)
  if status=='passed':require(name not in PLATFORMS and refs,'aggregate platform gates must remain unavailable; passed gate needs evidence')
  else:require(config['mode']=='scoped-verification'and name in PLATFORMS and item.get('reason','').strip(),'unavailable cannot waive gate '+name)
  out['gates'][name]={'passed':status=='passed','status':status,'scope':item['scope'],'limitations':item['limitations'],'reason':item.get('reason',''),'source_sha256':before['source_sha256'],'catalog_sha256':before['catalog_sha256'],'evidence':[{'path':'../'+r['path'],'sha256':r['sha256']}for r in refs]}
 resolutions=config.get('technical_resolutions',{});require(set(resolutions)==FINDINGS,'exactly two layout resolutions required')
 for f in out['technical_findings']:
  if f['id']not in FINDINGS:continue
  update=resolutions[f['id']];require(set(update)=={'state','resolution','evidence'}and update['state']=='resolved'and update['resolution'].strip()and update['evidence'],'actual layout resolution required')
  for ref in update['evidence']:reference(ref,base)
  f.update(copy.deepcopy(update))
 groups=config.get('required_reports',{});require(set(groups)==REQUIRED_REPORT_GROUPS,'required final report groups differ')
 for group,refs in groups.items():
  require(isinstance(refs,list)and refs,'pending required report group '+group)
  for ref in refs:reference(ref,base)
 verification=config.get('verification',{});require(set(verification)=={'final_revision','source_closure','render_evidence','limits'},'exact render/source-closure metadata required');require(verification['final_revision']==config['revision']and verification['render_evidence']and verification['limits'],'render metadata incomplete')
 for ref in [verification['source_closure'],*verification['render_evidence']]:reference(ref,base)
 out['final_verification']={'revision':config['revision'],'mode':config['mode'],'scope':config['scope'],'limits':config['limits'],'source_sha256':before['source_sha256'],'catalog_sha256':before['catalog_sha256'],'actual_render_source_closure':copy.deepcopy(verification),'pre_runtime_record_sha256':BASELINE_SHA,'required_reports':copy.deepcopy(groups),'claim_boundary':'Mechanical gate/evidence binding of root-approved scope, no new measurement or linguistic/visual judgment generated; producer binaries retain actual producer identities.'};assert_allowed_changes(before,out);return out

def finalize(config_path,apply=False):
 before_path=HERE/'pre-runtime/bg.json';require(sha(before_path)==BASELINE_SHA,'pre-runtime snapshot changed');before=read(before_path);config_sha=sha(config_path);require(sha(BASE/'kit-v8/review-proof-v8-visual-validation.json')=='5b6be55643eb72fb3ba21298ce8e6e43b310f225eb03b2181018b2d99461f5f7'and sha(BASE/'review-proof-v8-visual-independent-validation.json')=='2e30517167997cea2a28365c1111a354fc3363bfabbd24e0ffa65fd570bbbe77','actual linguistic proof identity changed');config=read(config_path);record_path=BASE/'kit-v8/reviews/bg.json';record_before=sha(record_path);require(record_before==BASELINE_SHA,'live record is not exact pre-runtime baseline');require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==config.get('revision'),'current revision differs');require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip(),'final source tree is dirty');candidate=build_candidate(before,config)
 closure=verify_closure(config['verification']['source_closure'],config['revision'],config['approved_source_changes']);spec=importlib.util.spec_from_file_location('final_gate_program',ROOT/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p);kit=BASE/'kit-v8';manifest=read(kit/'manifest.json');require(p.sources(ROOT)[4]==manifest['source_sha256']==before['source_sha256'],'current English source differs');hashes={s:sha(path)for s,path in p.catalog_paths(kit,'bg').items()};require(hashes==before['catalog_sha256']and hashes=={'native':sha(ROOT/'data/texts.bg.txt'),'online':sha(ROOT/'platform/packages/i18n/locales/bg.json')},'current registered catalogs differ');issues=p.audit_locale(kit,manifest,candidate,'bg');expected={name+' is pending or lacks evidence'for name,item in config['gates'].items()if item['status']=='unavailable'};require(set(issues)==expected,'unexpected core audit issues: '+repr(issues))
 proof={'status':'validated root-approved finalization candidate','source_sha256':before['source_sha256'],'catalog_sha256':hashes,'revision':config['revision'],'config':{'path':str(config_path.resolve().relative_to(BASE)),'sha256':config_sha},'pre_runtime_record':{'path':str(before_path.relative_to(BASE)),'sha256':BASELINE_SHA},'core_linguistic_projection_sha256':hashlib.sha256(canonical(linguistic_projection(before)).encode()).hexdigest(),'allowed_changes_only':True,'source_closure_validation':closure,'audit_issues_retained':issues,'full_nine_gate_audit_passed':not issues,'unavailable_gates':sorted(n for n,i in config['gates'].items()if i['status']=='unavailable'),'main_linguistic_proof_unchanged':sha(kit/'review-proof-v8-visual-validation.json')}
 if apply:
  require(sha(record_path)==record_before and sha(config_path)==config_sha,'review record/config changed during validation')
  for group in config['required_reports'].values():
   for evidence in group:reference(evidence)
  p.write_json(record_path,candidate);proof['final_record']={'path':str(record_path.relative_to(BASE)),'sha256':sha(record_path)};p.write_json(HERE/'finalization-validation.json',proof)
 return candidate,proof
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',type=Path,required=True);parser.add_argument('--apply',action='store_true');a=parser.parse_args();_,proof=finalize(a.config,a.apply);print(json.dumps(proof,indent=2))
