"""Create final publisher scope only from an actually finalized, independently checked record."""
from pathlib import Path
import argparse,hashlib,json
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';H=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def prepare(config_path):
 c=read(config_path);record_path=B/'kit-v8/reviews/bg.json';record=read(record_path);ind=H/'finalization-independent-validation.json';proof=H/'finalization-validation.json';assert ind.is_file()and proof.is_file(),'actual finalization and independent proof required';assert read(ind)['record_sha256']==sha(record_path)and read(ind)['config_sha256']==sha(config_path);assert read(proof)['final_record']['sha256']==sha(record_path);refs={}
 def add(ref):
  p=B/ref['path'];assert p.is_file()and sha(p)==ref['sha256'];assert ref['path']not in refs or refs[ref['path']]==ref['sha256'];refs[ref['path']]=ref['sha256']
 for group in c['required_reports'].values():
  for ref in group:add(ref)
 for gate in c['gates'].values():
  for ref in gate['evidence']:add(ref)
 for f in c['technical_resolutions'].values():
  for ref in f['evidence']:add(ref)
 for p in (record_path,proof,ind,config_path):add({'path':str(p.resolve().relative_to(B.resolve())),'sha256':sha(p)})
 coverage=[{'id':name,'gate_ids':[name],'status':'unavailable'if item['status']=='unavailable'else'verified','scope':item['scope'],'evidence':item['evidence'],**({'reason':item['reason']}if item['status']=='unavailable'else{})}for name,item in c['gates'].items()]
 return {'schema_version':1,'mode':'scoped-verification','revision':c['revision'],'source_sha256':c['source_sha256'],'catalog_sha256':c['catalog_sha256'],'scope':c['scope'],'limits':c['limits'],'review_record':{'path':str(record_path.relative_to(B)),'sha256':sha(record_path)},'reports':[{'path':name,'sha256':h}for name,h in sorted(refs.items())],'findings':c.get('publication_findings',[]),'gates':{name:{'status':item['status'],'scope':item['scope'],'evidence':item['evidence'],**({'reason':item['reason']}if item['status']=='unavailable'else{})}for name,item in c['gates'].items()},'coverage':coverage}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--config',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.write_text(json.dumps(prepare(a.config),ensure_ascii=False,indent=2)+'\n')
