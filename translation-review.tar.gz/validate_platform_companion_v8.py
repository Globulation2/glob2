from pathlib import Path
from decimal import Decimal
import hashlib,importlib.util,json,shutil
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'platform-companion-v8';P=B/'kit-v8';S=B/'platform-companion-v8-tool-shadow';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('companion',S/'tools/localization/translation_program.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
pre=load(K/'preflight.json');manifest=load(K/'manifest.json');ledger=load(K/'machine/spend-ledger.json');assert len(ledger['reservations'])==96 and ledger['reservations'][:95]==load(P/'machine/spend-ledger.json')['reservations'];spent=sum((Decimal(r['reserved_usd'])for r in ledger['reservations']),Decimal());assert str(spent)==pre['expected_total_usd'];assert m.sources()[4]==manifest['source_sha256'];assert sha(P/'manifest.json')==pre['main_manifest_sha256']
for rel,h in pre['prior_machine_sha256'].items():
 if rel=='spend-ledger.json':continue
 if rel=='bg/provider-drafts.json':assert all(load(K/'machine'/rel).get(k)==v for k,v in load(P/'machine'/rel).items());continue
 assert sha(K/'machine'/rel)==h,rel
paths=m.catalog_paths(K,'bg');assert m.CHECKER.read_table(paths['native'])[0]==m.CHECKER.read_table(K/pre['baseline_main_BG_snapshot']['native'])[0];shutil.copy2(K/pre['baseline_main_BG_snapshot']['native'],paths['native']);catalog=load(paths['online']);provider=load(K/'machine/bg/provider-drafts.json');rows=[]
for e in pre['entries']:
 row=e.copy();source=e['source'];target=catalog[e['key']];assert target.strip() and target!=source
 frozen=K/'frozen-platform-resources'/e['resource_path'];assert sha(frozen)==e['resource_sha256'];assert sha(R/e['resource_path'])==e['resource_sha256']
 protected,replacements=m.protect_text(source,e['protected_tokens']);pr=provider[json.dumps(['online',e['key'],''],ensure_ascii=False)];assert pr['source']==source and pr['translation']==target
 for token in set(replacements.values()):assert source.count(token)==target.count(token)
 request=next((K/'machine/bg/raw').glob(pr['request_sha256']+'-*.request.json'));req=load(request);raw=request.with_name(request.name.replace('.request.json','.response.bin'));body=load(raw);payload=req['payload'];assert payload['targetLanguageCode']=='bg'and payload['sourceLanguageCode']=='en'and payload['mimeType']=='text/plain'and payload['model']=='projects/bradley-personal-20261027/locations/global/models/general/nmt';assert len(payload['contents'])==len(body['translations'])==3;index=payload['contents'].index(protected);assert m.restore_text(body['translations'][index]['translatedText'],replacements)==target
 row.update(target=target,locale='bg',source_sha256=m.digest(source.encode()),target_sha256=m.digest(target.encode()),request_sha256=pr['request_sha256'],raw_provider_path=str(raw.relative_to(B)),raw_provider_sha256=sha(raw),actual_source_resource=str(frozen.relative_to(B)),approval=None,context={'android.preparing_game':'Native Android activity startup overlay while game assets/engine prepare; concise non-interactive progress text.','darwin.NSLocalNetworkUsageDescription':'macOS operating-system local-network permission prompt; explains discovery and joining of LAN multiplayer games. Brand Globulation 2 is exact invariant.','ios.NSLocalNetworkUsageDescription':'iOS operating-system local-network permission prompt; purpose is joining local-network Globulation 2 games. Brand is exact invariant.'}[e['key'].removeprefix('platform.')]);rows.append(row)
old=load(K/pre['baseline_main_BG_snapshot']['online']);assert all(catalog[k]==v for k,v in old.items());assert sha(paths['native'])==pre['baseline_main_BG_catalogs']['native'];checked=m.check_draft(K,'bg');assert not checked['errors']and not checked['untranslated'];raw=list((K/'machine').rglob('*.response.bin'));assert len(raw)==96
for p in raw:
 request,num=p.name.removesuffix('.response.bin').rsplit('-',1);assert ledger['reservations'][int(num)-1]['request_sha256']==request
for surface,p in paths.items():
 q=K/'provider-drafts/bg'/p.name;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.copy2(p,q)
packet={'source_sha256':manifest['source_sha256'],'main_V8_source_sha256':pre['main_source_sha256'],'companion_source_only':True,'locale':'bg','entry_count':3,'catalog_sha256':{s:sha(p)for s,p in paths.items()},'entries':rows,'status':'Machine first draft only; no linguistic approval; three actual independent roles required.','no_game_online_keys_added':True,'all_runtime_platform_gates':'pending'};m.write_json(K/'bg-platform3-review-input.json',packet)
# Extend the authoritative main campaign machine history only; source/drafts/catalogs remain untouched.
newfiles=[]
for p in(K/'machine').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(K/'machine');q=P/'machine'/rel
 if q.exists() and sha(q)==sha(p):continue
 assert not q.exists() or str(rel)in('spend-ledger.json','bg/provider-drafts.json'),str(rel)
 q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);newfiles.append(str(rel))
assert sha(P/'machine/spend-ledger.json')==sha(K/'machine/spend-ledger.json')
result={'result':'passed','source_sha256':manifest['source_sha256'],'main_source_sha256':pre['main_source_sha256'],'packet_sha256':sha(K/'bg-platform3-review-input.json'),'request_count':1,'protected_codepoints':pre['protected_codepoints'],'additional_reserved_usd':pre['expected_request_usd'],'ledger_reservations':96,'reserved_usd':str(spent),'prior95_exact_prefix':True,'machine_raw_bodies':96,'main_v8_machine_history_synced':newfiles,'main_source_drafts_catalogs_untouched_by_this_task':True,'protected_brand_exact':True,'structural_errors':[],'linguistic_approval':False,'runtime_platform_gates':'all pending'};m.write_json(K/'machine-validation.json',result);(B/'active-machine-kit.txt').write_text(str(P)+'\n');print(json.dumps(result,indent=2))
