import importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];base=ROOT/'artifacts/bulgarian';kit=base/'kit-v2'
s=importlib.util.spec_from_file_location('p',ROOT/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
m=json.loads((kit/'manifest.json').read_text());paths=p.catalog_paths(kit,'bg');hashes={s:p.digest(v.read_bytes()) for s,v in paths.items()};bhashes=p.batch_target_hashes(m,paths)
record=json.loads((kit/'reviews/bg.json').read_text());record['catalog_sha256']=hashes
record['language_brief']={'variety':'Contemporary standard Bulgarian; polite plural instructions and concise noun/action labels','script':'Cyrillic','region':'Bulgaria (bg-BG); catalog tag bg','sources':[{'path':'../../linguistics/semantic-language-brief.md','sha256':p.digest((base/'linguistics/semantic-language-brief.md').read_bytes())},{'path':'../../linguistics/editor-language-references.md','sha256':p.digest((base/'linguistics/editor-language-references.md').read_bytes())}],'terminology_rationales':['Worker=работник; explorer=разузнавач; warrior=воин; swarm=рояк; inn=хан; flag=флаг. Dictionary entries and gameplay rationale are in the language brief.','English controls meaning; Serbian/Russian/Ukrainian/French/German supplied contextual comparisons, not linguistic approval.'],'unresolved_uncertainty':[],'certification':'Agent-reviewed; not native-human-certified'}
record['batches']=[]
for b in m['batches']:
 record['batches'].append({'id':b['id'],'author':'/root (Google Cloud NMT draft and integrated corrections)','reviewer':'/root/semantic_reviewer','editor':'/root/bulgarian_editor','adversarial_reviewer':'/root/adversarial_reviewer','source_sha256':m['source_sha256'],'target_sha256':bhashes[b['id']],'reviewed_keys':b['keys'],'edited_keys':b['keys'],'rechecked_keys':b['keys'],'rechecked_by':'/root/semantic_reviewer','adversarial_reviewed_keys':b['keys'],'methodology':'Actual every-key independent passes; changed entries explicitly reread; unchanged source/target pairs carried forward with exact hash proof. See review-proof-validation.json and reviewer manifests.'})
reasons={}
for surface in ('native','online'):
 for e in json.loads((base/'linguistics'/f'editor-{surface}-english-identical.json').read_text()):reasons[surface+':'+e['key']]=e['reason']
checked=p.check_draft(kit,'bg');assert not checked['errors'] and not checked['untranslated'],checked
record['accepted_english']=[]
for key in checked['same_as_english_review_queue']:
 basekey=key if key in reasons else key.rsplit('/',1)[0];assert basekey in reasons,key
 record['accepted_english'].append({'key':key,'reason':reasons[basekey]})
record['findings']=[]
for role,files in [('semantic',['semantic-pilot-findings.json','semantic-pilot2-findings.json','semantic-native-findings.json','semantic-online-findings.json','semantic-native-count-findings.json']),('editor',['editor-findings.json','editor-native-final-findings.json','editor-online-final-findings.json']),('adversarial',['adversarial-native-findings.json','adversarial-online-findings.json'])]:
 for file in files:
  for e in json.loads((base/'linguistics'/file).read_text()):
   surface=e.get('surface','native' if 'native' in file else 'online');key=e['key'];key=key if surface!='native' or key.startswith('[') else '['+key+']'
   record['findings'].append({'key':surface+':'+key,'severity':'minor' if e.get('severity')=='P3' else 'major','state':'resolved','reason':e['reason'],'reviewer':role,'evidence':'linguistics/'+file,'resolution':'Final exact source/target binding approved by all three independent linguistic reviewers; historical proposals and conflict decisions retained separately.'})
record['source_expansion']={'carryforward':{'path':'../../source-expansion-carryforward.json','sha256':p.digest((base/'source-expansion-carryforward.json').read_bytes())},'verified_actual_delta_review_counts':{'native_revised_keys_per_reviewer':4,'online_new_keys_per_reviewer':7},'unchanged_source_target_pairs_carried_forward':{'native':3389,'online':2836},'limits':'Unchanged pairs retain prior actual reading through exact hashes; no fresh reading claimed. See source_expansion in the independently supplied record verifier output.'}
record['review_proof']={'path':'../../review-proof-validation.json','sha256':p.digest((base/'review-proof-validation.json').read_bytes())}
for name,files in {'language_brief':['linguistics/semantic-language-brief.md','linguistics/editor-language-references.md'],'source_based_pilot':['linguistics/semantic-pilot-examined.json','linguistics/semantic-pilot2-examined.json','linguistics/semantic-pilot2-gate.md'],'structural':['native-audit-final.json','native-translation-tests.log','online-audit-final.log','review-proof-validation.json','final-catalog-font-coverage.json','font-coverage-final.log','validation-binding-final.json']}.items():
 record['gates'][name]={'passed':True,'source_sha256':m['source_sha256'],'catalog_sha256':hashes,'evidence':[{'path':str((base/file).relative_to(kit)) if (base/file).is_relative_to(kit) else '../'+file,'sha256':p.digest((base/file).read_bytes())} for file in files]}
for name in ('desktop_rendering','phone_rendering','browser_startup','native_platforms','browser_platforms','mobile_platforms'):
 record['gates'][name]={'passed':False,'evidence':[],'reason':'Pending final rendering/startup/platform acceptance; catalog glyph checks and linguistic review do not certify these gates.'}
p.write_json(kit/'reviews/bg.json',record)
print('Review record: batches',len(record['batches']),'resolved historical findings',len(record['findings']),'English exceptions',len(record['accepted_english']))
