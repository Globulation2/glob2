import importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];base=ROOT/'artifacts/bulgarian';kit=base/'kit-v2'
s=importlib.util.spec_from_file_location('p',ROOT/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
m=json.loads((kit/'manifest.json').read_text());paths=p.catalog_paths(kit,'bg');hashes={s:p.digest(v.read_bytes()) for s,v in paths.items()};bhashes=p.batch_target_hashes(m,paths)
record=json.loads((kit/'reviews/bg.json').read_text());record['catalog_sha256']=hashes
record['language_brief']={'variety':'Contemporary standard Bulgarian; polite plural instructions and concise noun/action labels','script':'Cyrillic','region':'Bulgaria (bg-BG); catalog tag bg','sources':[{'path':'../../linguistics/semantic-language-brief.md','sha256':p.digest((base/'linguistics/semantic-language-brief.md').read_bytes())},{'path':'../../linguistics/editor-language-references.md','sha256':p.digest((base/'linguistics/editor-language-references.md').read_bytes())}],'terminology_rationales':['Worker=работник; explorer=разузнавач; warrior=воин; swarm=рояк; inn=хан; flag=флаг. Dictionary entries and gameplay rationale are in the language brief.','English controls meaning; Serbian/Russian/Ukrainian/French/German supplied contextual comparisons, not linguistic approval.'],'unresolved_uncertainty':[],'certification':'Agent-reviewed; not native-human-certified'}
record['batches']=[]
for b in m['batches']:
 record['batches'].append({'id':b['id'],'author':'/root (Google Cloud NMT draft and integrated corrections)','reviewer':'/root/semantic_reviewer','editor':'/root/bulgarian_editor','adversarial_reviewer':'/root/adversarial_reviewer','source_sha256':m['source_sha256'],'target_sha256':bhashes[b['id']],'reviewed_keys':b['keys'],'edited_keys':b['keys'],'rechecked_keys':b['keys'],'rechecked_by':'/root/semantic_reviewer','adversarial_reviewed_keys':b['keys'],'methodology':'Actual every-key independent passes; changed entries explicitly reread; unchanged source/target pairs carried forward with exact hash proof. See review-proof-validation.json and reviewer manifests.'})
reasons={}
for surface in ('native','online'):
 for e in json.loads((base/'linguistics'/f'editor-{surface}-english-identical.json').read_text()):reasons[surface+':'+e['key']]=e['reason']
checked=p.check_draft(kit,'bg');assert not checked['errors'] and not checked['untranslated'],checked
record['accepted_english']=[]
for key in checked['same_as_english_review_queue']:
 basekey=key if key in reasons else key.rsplit('/',1)[0];assert basekey in reasons,key
 record['accepted_english'].append({'key':key,'reason':reasons[basekey]})
record['findings']=[]
for role,files in [('semantic',['semantic-pilot-findings.json','semantic-pilot2-findings.json','semantic-native-findings.json','semantic-online-findings.json','semantic-native-count-findings.json']),('editor',['editor-findings.json','editor-native-final-findings.json','editor-online-final-findings.json']),('adversarial',['adversarial-native-findings.json','adversarial-online-findings.json'])]:
 for file in files:
  for e in json.loads((base/'linguistics'/file).read_text()):
   surface=e.get('surface','native' if 'native' in file else 'online');key=e['key'];key=key if surface!='native' or key.startswith('[') else '['+key+']'
   record['findings'].append({'key':surface+':'+key,'severity':'minor' if e.get('severity')=='P3' else 'major','state':'resolved','reason':e['reason'],'reviewer':role,'evidence':'linguistics/'+file,'resolution':'Final exact source/target binding approved by all three independent linguistic reviewers; historical proposals and conflict decisions retained separately.'})
proof=json.loads((base/'review-proof-validation.json').read_text())
assert proof['catalog_sha256']==hashes and proof['source_sha256']==m['source_sha256']
archive_rows=proof['source_expansion']['archived_pair_checks']
unchanged={surface:{row['unchanged_exact_source_target_pairs'] for row in archive_rows if row['surface']==surface} for surface in ('native','online')}
assert all(len(counts)==1 for counts in unchanged.values())
expansion=json.loads((base/'source-expansion-carryforward.json').read_text())
record['source_expansion']={'evidence_root':'artifacts/bulgarian','carryforward':proof['source_expansion']['carryforward_report'],'verified_actual_delta_review_counts':{'native_revised_keys_per_reviewer':len(expansion['revised_native_keys']),'online_new_keys_per_reviewer':len(expansion['new_online_keys'])},'unchanged_source_target_pairs_since_source_expansion_archive':{surface:next(iter(counts)) for surface,counts in unchanged.items()},'later_visual_revisions_to_existing_online_keys':proof['visual_refinement']['reviewer_checks'][0]['actually_reread_changed_keys'],'limits':'Counts are relative to the original source-expansion archive: existing online pairs later changed by visual refinement are excluded from unchanged carryforward. No fresh reading claimed for unchanged pairs.'}
visual_checks=proof['visual_refinement']['reviewer_checks']
record['visual_refinement']={'evidence_root':'artifacts/bulgarian','carryforward':proof['visual_refinement']['report'],'actual_final_value_rereads_per_reviewer':{row['reviewer']:len(row['actually_reread_changed_keys']) for row in visual_checks},'unchanged_online_pairs_since_pre_visual_archive':{row['reviewer']:row['unchanged_exact_source_target_pairs'] for row in visual_checks},'proof_records':[row['actual_delta_record'] for row in visual_checks],'limits':'Three compact values actually reread independently after integration; unchanged pairs retain prior coverage through exact hashes. Final visual/pixel-fit acceptance remains pending.'}
visual_findings=json.loads((base/'linguistics/editor-final-online-visual6.json').read_text())['findings']
final_online=json.loads(paths['online'].read_text())
for finding in visual_findings:
 key=finding['source_key'];assert key in final_online
 dynamic=key=='Add {slot0}'
 record['findings'].append({'key':'online:'+key,'severity':'major' if dynamic else 'minor','state':'resolved','reason':finding['reason'],'reviewer':'independent editorial visual review','evidence':'linguistics/editor-final-online-visual6.json','resolution':('Visible Terrain/Resource argument localized while canonical wire enums stay unchanged; commit84e910a3d6 and seven focused unit tests pass. Final browser acceptance remains pending.' if dynamic else 'Actual final compact value independently approved by semantic/editorial/adversarial roles and integrated atc271876c11; final pixel-fit acceptance remains pending.'),'final_value':final_online[key]})
for finding in record['findings']:
 if finding['key']=='online:Add {slot0}' and finding.get('reviewer')=='independent editorial visual review':
  finding['resolution_evidence']=[{'path':'../final-online-qa/add-kind-unit.log','sha256':p.digest((base/'final-online-qa/add-kind-unit.log').read_bytes())}]
record['technical_findings']=[{'id':'static-launcher-font-closure','severity':'major','state':'resolved','reason':'The static release packaging closure omitted the separately staged Bulgarian starter font and notices, despite launcher CSS referencing it.','resolution':'Commit62b81974f4 includes the pinned core TTF and DejaVu/Droid notices in static package creation/verification; focused package test passes. Final serial/threaded browser release startup remains a separate pending gate.','evidence':[{'path':'../static-launcher-font-closure-final.log','sha256':p.digest((base/'static-launcher-font-closure-final.log').read_bytes())}],'scope':'Technical packaging finding; does not create a linguistic sign-off.'}]
record['review_proof']={'path':'../../review-proof-validation.json','sha256':p.digest((base/'review-proof-validation.json').read_bytes())}
for name,files in {'language_brief':['linguistics/semantic-language-brief.md','linguistics/editor-language-references.md'],'source_based_pilot':['linguistics/semantic-pilot-examined.json','linguistics/semantic-pilot2-examined.json','linguistics/semantic-pilot2-gate.md'],'structural':['native-audit-final.json','native-translation-tests.log','online-audit-final.log','review-proof-validation.json','final-catalog-font-coverage.json','font-coverage-final.log','validation-binding-final.json','static-launcher-font-closure-final.log']}.items():
 record['gates'][name]={'passed':True,'source_sha256':m['source_sha256'],'catalog_sha256':hashes,'evidence':[{'path':str((base/file).relative_to(kit)) if (base/file).is_relative_to(kit) else '../'+file,'sha256':p.digest((base/file).read_bytes())} for file in files]}
for name in ('desktop_rendering','phone_rendering','browser_startup','native_platforms','browser_platforms','mobile_platforms'):
 record['gates'][name]={'passed':False,'evidence':[],'reason':'Pending final rendering/startup/platform acceptance; catalog glyph checks and linguistic review do not certify these gates.'}
p.write_json(kit/'reviews/bg.json',record)
print('Review record: batches',len(record['batches']),'resolved historical findings',len(record['findings']),'English exceptions',len(record['accepted_english']))
