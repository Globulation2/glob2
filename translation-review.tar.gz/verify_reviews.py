import hashlib,importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; base=ROOT/'artifacts/bulgarian'
s=importlib.util.spec_from_file_location('program',ROOT/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
paths=p.catalog_paths(base/'kit-v2','bg');n,e=p.CHECKER.read_table(paths['native']);assert not e
sources={s:json.loads((base/'kit-v2/source'/f'{s}.json').read_text()) for s in ('native','online')}; targets={'native':n,'online':json.loads(paths['online'].read_text())};rows=[]
def hashed(value,role):
 if role=='editor':text=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
 elif isinstance(value,str):text=value
 elif role=='semantic':text=json.dumps(value,ensure_ascii=False,sort_keys=True)
 else:text=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
 return hashlib.sha256(text.encode()).hexdigest()
for role in ('semantic','editor','adversarial'):
 for surface in ('native','online'):
  name=f'{role}-{surface}-final-examined.json' if role!='adversarial' else f'{role}-{surface}-examined.json';file=base/'linguistics'/name;doc=json.loads(file.read_text());entries=doc if isinstance(doc,list) else doc['entries'];indexed={v['key']:v for v in entries};assert len(indexed)==len(entries)==len(sources[surface]),(role,surface,len(indexed));assert set(indexed)==set(sources[surface]),(role,surface,'coverage')
  for key,entry in indexed.items():
   assert entry['source_sha256']==hashed(sources[surface][key],role),(role,surface,key,'source stale')
   assert entry['target_sha256']==hashed(targets[surface][key],role),(role,surface,key,'target stale')
   if role!='adversarial':
    assert entry['source']==sources[surface][key] and entry['target']==targets[surface][key],(role,surface,key,'value stale')
   if isinstance(targets[surface][key],dict) and role=='adversarial':
    assert set(entry['plural_forms_examined'])==set(targets[surface][key]),key
    for form,value in targets[surface][key].items():
     assert entry['plural_form_sha256'][form]['target_sha256']==hashed(value,role),(key,form)
  if role=='adversarial':
   assert doc['candidate_file_sha256']==p.digest(paths[surface].read_bytes()),(surface,'file stale')
  rows.append({'reviewer':role,'surface':surface,'keys':len(entries),'proof':str(file.relative_to(base)),'proof_sha256':p.digest(file.read_bytes())})
# Verify actual source-expansion delta records rather than treating changed
# targets as covered by the archived pass. Reviewer files are inputs only.
expansion=json.loads((base/'source-expansion-carryforward.json').read_text())
assert expansion['new_source_sha256']==json.loads((base/'kit-v2/manifest.json').read_text())['source_sha256']
expected_delta={'native':set(expansion['revised_native_keys']), 'online':set(expansion['new_online_keys'])}
visual=json.loads((base/'visual-refinement-carryforward.json').read_text())
visual_keys=set(visual['changed_online_keys'])
assert p.digest((base/'visual-refinement-v1/bg.json').read_bytes())==visual['old_online_catalog_sha256']
assert p.digest(paths['online'].read_bytes())==visual['new_online_catalog_sha256']
expansion_rows=[]
for role in ('semantic','editor','adversarial'):
 for surface in ('native','online'):
  name=f'{role}-{surface}-final-examined.json' if role!='adversarial' else f'{role}-{surface}-examined.json'
  oldfile=base/'source-expansion-v1/linguistics'/name
  olddoc=json.loads(oldfile.read_text()); oldentries=olddoc if isinstance(olddoc,list) else olddoc['entries']; old={e['key']:e for e in oldentries}
  unchanged=[]; changed=[]; added=[]
  for key in sources[surface]:
   if key not in old:
    added.append(key)
   elif (old[key]['source_sha256']==hashed(sources[surface][key],role) and old[key]['target_sha256']==hashed(targets[surface][key],role)):
    unchanged.append(key)
   else:
    changed.append(key)
  assert not(set(old)-set(sources[surface])),(role,surface,'removed keys')
  assert set(changed)==(expected_delta[surface] if surface=='native' else visual_keys),(role,surface,'unexpected revision',changed)
  assert set(added)==(expected_delta[surface] if surface=='online' else set()),(role,surface,'unexpected addition',added)
  expansion_rows.append({'reviewer':role,'surface':surface,'archived_proof':str(oldfile.relative_to(base)),'archived_proof_sha256':p.digest(oldfile.read_bytes()),'unchanged_exact_source_target_pairs':len(unchanged),'changed_keys_requiring_explicit_reread':changed,'new_keys_requiring_explicit_reading':added,'unchanged_not_freshly_read':True})
actual_files={
 'semantic':['semantic-online-expansion7-examined.json','semantic-ai-refinement4-delta-examined.json'],
 'editor':['editor-source-expansion7-final-examined.json','editor-source-expansion-native4-reread.json'],
 'adversarial':['adversarial-source-expansion-reread.json'],
}
delta_rows=[]
for role,names in actual_files.items():
 evidence=[]; records=[]
 for name in names:
  file=base/'linguistics'/name; doc=json.loads(file.read_text()); records.extend(doc if isinstance(doc,list) else doc['entries_actually_read']); evidence.append({'path':str(file.relative_to(base)),'sha256':p.digest(file.read_bytes())})
 validated=[]
 for surface,keys in expected_delta.items():
  for key in sorted(keys):
   matches=[entry for entry in records if entry.get('surface')==surface and entry.get('key')==key and entry.get('source')==sources[surface][key] and entry.get('target')==targets[surface][key]]
   assert matches,(role,surface,key,'no actual final-value delta reading')
   validated.append(surface+':'+key)
 delta_rows.append({'reviewer':role,'actual_final_value_delta_readings_verified':validated,'count':len(validated),'evidence':evidence})
source_expansion_proof={'carryforward_report':{'path':'source-expansion-carryforward.json','sha256':p.digest((base/'source-expansion-carryforward.json').read_bytes())},'archived_pair_checks':expansion_rows,'actual_delta_readings':delta_rows,'limits':'Records are independently supplied reviewer evidence. This verifier compares coverage and exact values; it neither performs linguistic review nor creates new sign-offs.'}


# A separate final visual revision changed three existing values. Check the
# actual independently supplied reread records and exact unchanged pair hashes.
visual_rows=[]
for role in ('semantic','editor','adversarial'):
 name=f'{role}-online-final-examined.json' if role!='adversarial' else 'adversarial-online-examined.json'
 oldfile=base/'visual-refinement-v1'/name
 olddoc=json.loads(oldfile.read_text()); oldentries=olddoc if isinstance(olddoc,list) else olddoc['entries'];old={e['key']:e for e in oldentries}
 assert set(old)==set(sources['online'])
 changed={key for key in old if old[key]['target_sha256']!=hashed(targets['online'][key],role)}
 assert changed==visual_keys,(role,'unexpected visual delta',changed)
 assert all(e['source_sha256']==hashed(sources['online'][key],role) for key,e in old.items())
 deltafile=base/'linguistics'/f'{role}-visual-compact-final-examined.json'
 doc=json.loads(deltafile.read_text());entries=doc if isinstance(doc,list) else doc['entries']
 assert len(entries)==len(visual_keys) and {e['key'] for e in entries}==visual_keys,(role,'visual coverage')
 for e in entries:
  key=e['key'];assert e['surface']=='online' and e['source']==sources['online'][key] and e['target']==targets['online'][key],(role,key,'visual exact value')
 visual_rows.append({'reviewer':role,'actually_reread_changed_keys':sorted(visual_keys),'unchanged_exact_source_target_pairs':len(old)-len(changed),'archived_record':{'path':str(oldfile.relative_to(base)),'sha256':p.digest(oldfile.read_bytes())},'actual_delta_record':{'path':str(deltafile.relative_to(base)),'sha256':p.digest(deltafile.read_bytes())},'unchanged_not_freshly_read':True})
visual_proof={'report':{'path':'visual-refinement-carryforward.json','sha256':p.digest((base/'visual-refinement-carryforward.json').read_bytes())},'reviewer_checks':visual_rows,'limits':'Exact value/hash/coverage checks of actual independently supplied reread records; not linguistic inference.'}

report={'source_sha256':json.loads((base/'kit-v2/manifest.json').read_text())['source_sha256'],'catalog_sha256':{k:p.digest(v.read_bytes()) for k,v in paths.items()},'review_records':rows,'source_expansion':source_expansion_proof,'visual_refinement':visual_proof,'per_key_checks':sum(x['keys'] for x in rows),'limits':'Hash/coverage verification of actual independently supplied review records; this script does not perform linguistic review.'}
p.write_json(base/'review-proof-validation.json',report);print(json.dumps(report,ensure_ascii=False,indent=2))
