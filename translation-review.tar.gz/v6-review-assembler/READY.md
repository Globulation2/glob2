# V6 actual proof and validation

Written BG proof: kit-v6/review-proof-v6-validation.json; review record: kit-v6/reviews/bg.json; independent mechanical validation: review-proof-v6-independent-validation.json. Source dca9d5da…, BG native63d5…/online1fb6…. All 6377 keys and 19131 role bindings are accounted for: 228 fresh actual final pairs per role across online018/019, 6149 exact V5 carry pairs. All previous 6272 source/target pairs remain exact;105 added. All108 English exceptions retain exact parent literals and reasons;zero new exceptions. Actual reviewer IDs remain /root/v5_semantic, /root/v5_editor, /root/v5_adversary. Original reports remain unchanged.

All nine runtime/platform gates remain pending; the two technical layout findings remain pending actual new runtime verification. Historical executions do not become final evidence here. No actual live apply or binary/font/platform claim is inferred by this tool. Root owns integration/runtime work.

The immutable parent-v5 snapshot preserves original manifest/source/drafts/record and linked proofs; parent-snapshot.json binds every file. MS compatibility is separate: kit-v6/compatibility-ms19-review-validation.json and compatibility-ms19-independent-validation.json bind only19 actual role-approved additions,57bindings, preserving3411native+2947online old values;zero English matches. This is not a whole-Malay review.

Validation commands (read only; do not rerun --write after runtime gates are later updated):

```sh
python3 artifacts/bulgarian/v6-review-assembler/assemble.py --semantic artifacts/bulgarian/linguistics/v6-semantic-bg228-final.json --editor artifacts/bulgarian/linguistics/v6-editor-bg228-final.json --adversarial artifacts/bulgarian/linguistics/v6-adversarial-bg228-final.json
python3 artifacts/bulgarian/v6-review-assembler/validate_written.py
python3 artifacts/bulgarian/v6-review-assembler/validate_ms19.py --semantic artifacts/bulgarian/linguistics/v6-semantic-ms19-final.json --editor artifacts/bulgarian/linguistics/v6-editor-ms19-final.json --adversarial artifacts/bulgarian/linguistics/v6-adversarial-ms19-final.json
python3 artifacts/bulgarian/v6-review-assembler/validate_ms_written.py
```

22 assembler mock regressions,15 publisher curation tests and12 final-evidence contract tests pass. Mocks are temporary and removed; no fixture approval is published as an actual review. Missing/pending/stale reports, wrong identities/locale/coverage/batches, lost literal/plural hashes, contradictory approvals, changed callers, fake fresh-reading/carry and missing new-English reasons fail closed.

Publisher allowlists now include kit-v6, merge-malay-tooling and v6-review-assembler; known v6 Malay raw bodies are selected, frozen byte-identically and credential-scanned. Failed partial preparation directories are excluded. Default remains PREP, with explicit final-evidence contract unchanged. No full PREP/inventory or publication was run while final source/runtime inputs continue changing. Preserve native selections253+168+109 via existing primary selection and both explicit --native-selection flags on future preparation. Active v6 machine history contains90raw bodies and preserved quarantine; ledger90/$5.36788 exact88prefix. v6-provider-inventory.json gives actual paths/copy hashes. No paid call or source/build/CI edit was performed during this assembler task.
