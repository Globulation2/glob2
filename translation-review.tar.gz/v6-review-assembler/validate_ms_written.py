"""Independent MS19 written-proof binding check; no new linguistic approval."""
from pathlib import Path
import hashlib,json,importlib.util
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';K=B/'kit-v6';H=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rawhash=lambda v:hashlib.sha256(v.encode()).hexdigest();canonical=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'));canonicalhash=lambda v:rawhash(canonical(v))
s=importlib.util.spec_from_file_location('p',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
proof=read(K/'compatibility-ms19-review-validation.json');packet=read(K/'ms19-after-semantic-input.json');source={s:read(K/'source'/f'{s}.json')for s in ('native','online')};target={'native':p.CHECKER.read_table(K/'drafts/ms/texts.ms.txt')[0],'online':read(K/'drafts/ms/ms.json')};baseline={'native':p.CHECKER.read_table(H/'ms-baseline/texts.ms.txt')[0],'online':read(H/'ms-baseline/ms.json')};expected={e['id']:e for e in packet['entries']};assert len(expected)==19;assert proof['source_sha256']==read(K/'manifest.json')['source_sha256'];assert proof['catalog_sha256']=={s:sha(path)for s,path in p.catalog_paths(K,'ms').items()};assert proof['packet']['sha256']==sha(K/'ms19-after-semantic-input.json')
for surface in baseline:
 assert all(target[surface][k]==v for k,v in baseline[surface].items())
assert set(expected)=={s+':'+k for s in source for k in source[s]if k not in baseline[s]}
role_ids={'semantic':'/root/v5_semantic','editor':'/root/v5_editor','adversarial':'/root/v5_adversary'}
for evidence in proof['actual_role_evidence']:
 path=B/evidence['path'];assert sha(path)==evidence['sha256'];d=read(path);actual=d.get('reviewer_identity',{}).get('agent',d.get('reviewer',{}).get('agent_path'));assert actual==role_ids[evidence['role']];assert d['source_sha256']==proof['source_sha256']and d['catalog_sha256']==proof['catalog_sha256'];assert d.get('status',d.get('decision'))in('approved','accepted_all_19');assert len(d['entries'])==19 and {e['id']for e in d['entries']}==set(expected)
 for e in d['entries']:
  surface,key=e['id'].split(':',1);assert e['locale']=='ms';assert e['source']==source[surface][key]and e['target']==target[surface][key];assert e['batch_id']==expected[e['id']]['batch_id'];assert e['source_sha256']in(rawhash(e['source']),canonicalhash(e['source']))and e['target_sha256']in(rawhash(e['target']),canonicalhash(e['target']));assert e.get('status',e.get('verdict',e.get('decision')))in('approved','approve','accepted','accept');assert any(e.get(k)is True for k in('actual_fresh_complete_final_pair_read','final_fresh_read'))or(d.get('coverage',{}).get('fresh_read')is True and d['coverage']['entries']==19)
  if 'identity_sha256'in e:assert e['identity_sha256']==canonicalhash(['ms',e['id'],e['source'],e['target']])
  if 'pair_sha256'in e:assert e['pair_sha256']==canonicalhash([e['id'],e['source'],e['target']])
assert proof['entries']==19 and proof['role_bindings']==57 and proof['new_english_matches']==[]
result={'result':'passed','scope':'Independent mechanical MS19 compatibility proof only; no whole-language or runtime approval generated','source_sha256':proof['source_sha256'],'catalog_sha256':proof['catalog_sha256'],'actual_pairs_per_role':19,'role_bindings':57,'unchanged_native_pairs':len(baseline['native']),'unchanged_online_pairs':len(baseline['online']),'proof_sha256':sha(K/'compatibility-ms19-review-validation.json'),'runtime_platforms':'pending'}
(K/'compatibility-ms19-independent-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
