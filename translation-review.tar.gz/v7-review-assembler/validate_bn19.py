"""Bind nineteen supplied BN compatibility reviews; never approve the full locale."""
from pathlib import Path
from collections import Counter
import argparse,importlib.util,json,hashlib
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v6review',HERE/'assemble.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
def validate(reports,write=False):
 roster=a.read(HERE/'actual-role-roster.json');a.require(all(isinstance(v,str)for v in roster.values()),'actual role roster pending');a.ROLES.update(roster)
 kit=a.BASE/'kit-v7';p=a.load_program();manifest=a.read(kit/'manifest.json');packetpath=kit/'bn-after-editor-review-input.json';packet=a.read(packetpath);paths=p.catalog_paths(kit,'bn');hashes={s:a.sha(path)for s,path in paths.items()};a.require(packet['source_sha256']==manifest['source_sha256']and packet['catalog_sha256']==hashes,'BN packet source/catalog stale')
 source={s:a.read(kit/'source'/f'{s}.json')for s in ('native','online')};target={'native':p.CHECKER.read_table(paths['native'])[0],'online':a.read(paths['online'])};expected={e['id']:e for e in packet['entries']};a.require(len(expected)==len(packet['entries'])==19,'BN scope must be distinct nineteen entries');a.require(set(expected)==set(a.read(kit/'bn-delta-only-keys.json')),'BN scope differs from original machine supplement')
 membership={i:b['id']for b in manifest['batches']for i in b['keys']}
 for i,e in expected.items():
  s,k=i.split(':',1);a.require(e['source']==source[s][k]and e['target']==target[s][k]and e['batch_id']==membership[i],'BN packet literal/batch differs')
 baseline={'native':p.CHECKER.read_table(kit/'baselines/bn/texts.bn.txt')[0],'online':a.read(kit/'baselines/bn/bn.json')};pre=a.read(kit/'preflight.json')
 for s,name in [('native','texts.bn.txt'),('online','bn.json')]:
  a.require(a.sha(kit/'baselines/bn'/name)==pre['baseline']['bn'][s]['sha256'],'BN baseline identity differs');a.require(all(target[s].get(k)==v for k,v in baseline[s].items()),'old BN pair changed outside compatibility supplement')
 a.require({s+':'+k for s in source for k in source[s]if k not in baseline[s]}==set(expected),'BN new pair scope differs')
 checked=p.check_draft(kit,'bn');a.require(not checked['errors']and not checked['untranslated'],'BN draft contract errors');proofs=[]
 for role in a.ROLES:
  report,proof=a.verify_report(reports[role],role,expected,manifest['source_sha256'],hashes,locale='bn');a.require(report.get('packet_sha256')==a.sha(packetpath),'BN report binds different packet');proofs.append(proof)
 result={'result':'passed','scope':'Nineteen compatibility additions only; not full Bengali linguistic review or platform readiness','source_sha256':manifest['source_sha256'],'catalog_sha256':hashes,'packet':{'path':str(packetpath.relative_to(a.BASE)),'sha256':a.sha(packetpath)},'entries':19,'role_bindings':57,'actual_role_evidence':proofs,'unchanged_prior_native_pairs':len(baseline['native']),'unchanged_prior_online_pairs':len(baseline['online']),'new_english_matches':[i for i,e in expected.items()if e['source']==e['target']],'runtime_platform_gates':'pending, no approvals produced','candidate_only':True}
 # Source-equal new literals require actual individual exception rationales in all roles.
 if result['new_english_matches']:
  approved={role:a.read(path)for role,path in reports.items()};a.english_exceptions(set(result['new_english_matches']),{},source,target,{'native':{},'online':{}},{'native':{},'online':{}},set(expected),approved)
 if write:
  a.require(all(a.sha(reports[r])==next(e['sha256']for e in proofs if e['role']==r)for r in a.ROLES),'BN report changed during validation');a.require({s:a.sha(path)for s,path in paths.items()}==hashes,'BN candidate changed during validation');p.write_json(kit/'compatibility-bn19-review-validation.json',result)
 return result
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 for role in a.ROLES:parser.add_argument('--'+role,type=Path,required=True)
 parser.add_argument('--write',action='store_true');args=parser.parse_args();print(json.dumps(validate({r:getattr(args,r)for r in a.ROLES},args.write),indent=2))
