import pathlib,json,hashlib,xml.etree.ElementTree as ET
p=pathlib.Path('artifacts/bulgarian/native-captures')
def load(f):return json.loads(f.read_text())
def save(f,d):f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
# Independently compare all completed scale-one page files across font correction.
batches=[]
for viewport in ['desktop','phone']:
 for size in [10,13,20]:
  name=f'{viewport}-matrix-{size}-scale-1';a=p/name;b=p/'font-corrected'/name
  aa=sorted(a.glob('*.png'));bb=sorted(b.glob('*.png'));assert [x.name for x in aa]==[x.name for x in bb]
  rows=[{'name':x.name,'before_sha256':sha(x),'after_sha256':sha(y),'identical':sha(x)==sha(y)} for x,y in zip(aa,bb)]
  assert all(r['identical'] for r in rows)
  batches.append({'batch':name,'pages':len(rows),'identical':len(rows),'page_hashes':rows})
save(p/'font-scale1-byte-equivalence.json',{'purpose':'Actual byte comparison of all six complete unscaled matrix batches before/after Bulgarian authored-width correction; only PNG bytes compared.','batches':batches,'pages':sum(b['pages'] for b in batches),'all_identical':True})
# These exact images were individually inspected in the prior uninterrupted task context.
ins=load(p/'visual-inspection.json');seen={x['path'] for x in ins['images']}
more=[]
for view in ['desktop','phone']:
 more.append((p/'font-corrected'/f'{view}-selected-pages-contact.png','contact sheet: layout sampling only','First/middle/last page thumbnails across six font combinations inspected for broad layout; no full-text legibility claim for thumbnail sheets.'))
for folder,page in [('desktop-matrix-20-scale-2',1),('desktop-matrix-20-scale-2',118),('desktop-matrix-20-scale-2',235),('phone-matrix-20-scale-2',165)]:
 more.append((p/'font-corrected'/folder/f'font-20-scale-2-page-{page:03}.png','individual full page','Bulgarian text, punctuation and line ends inspected. No missing glyphs, clipped endings or overlap observed in these sampled corrected pages. The targeted four formerly clipped lines were also inspected in the separate before/after crop.'))
for tag in ['desktop-api-unknown','phone-api-known','phone-api-unknown']:
 more.append((p/'final-api'/tag/'settings-ais.png','individual full image','Actual Settings AI notice visually inspected: typed known error or translated generic fallback fits and is legible; all displayed AI tags fit. This is a controlled loopback HTTP fixture, not a production-server account.'))
for f,kind,obs in more:
 assert f.exists()
 if str(f) not in seen:ins['images'].append({'path':str(f),'sha256':sha(f),'inspection':kind,'observations':obs,'limits':'Sample inspection only; every matrix PNG was not visually read. Producer and catalog identities remain those in the companion manifest.'})
save(p/'visual-inspection.json',ins)
# Validate normal fresh UI execution and every real-game drawing checksum.
ui=load(p/'final-ui/execution.json');api=load(p/'final-api/execution.json');assert len(ui['jobs'])==13 and all(x['returncode']==0 for x in ui['jobs'])
checks=[]
for f in (p/'final-ui').glob('*/*.json'):
 if f.name=='http-fixture-receipt.json':continue
 d=load(f)
 for c in d.get('captures',[]):
  if 'checksum_before_draw' in c:
   assert c['checksum_before_draw']==c['checksum_after_draw'];checks.append({'manifest':str(f),'capture':c['name'],'checksum':c['checksum_before_draw']})
assert len(checks)==8
apiok=[x for x in api['jobs'] if x['returncode']==0];apifail=[x for x in api['jobs'] if x['returncode']!=0];assert len(apiok)==3 and len(apifail)==1
metrics=load(p/'font-corrected/matrix-diagnostics.json');bs=[b for v in metrics for b in v['batches']]
assert len(bs)==12 and sum(b['samples'] for b in bs)==75156
for b in bs:
 for k in ['glyph_missing_samples','drawn_width_failures','drawn_height_failures','actual_viewport_width_failures','actual_viewport_height_failures']:assert b[k]==0
report={'status':'Completed v2 component evidence; v3 supplemental coverage and final desktop known API fixture remain pending.','scope':{'native_keys':3393,'online_keys':2843,'source_keys':6236,'samples_per_combination':6263,'font_combinations_per_viewport':6,'viewports':2,'measured_font_samples':75156},'font':{'producer':'3881c64e0d2b43b460a122422d2727c0cbd4d3ca','completed_batches':12,'raster_pages':sum(b['raster_pages'] for b in bs),'selected_pages':36,'contact_sheets':2,'glyph_missing':0,'draw_budget_failures':0,'actual_canvas_overflow':0,'raw_raster_width_diagnostics':sum(b['raw_width_diagnostics'] for b in bs),'raw_raster_note':'Full hinted high-resolution bitmap is preserved; production draws it at authored Bulgarian destination width. Raw bitmap measurements are not destination clipping.','scale1_pages_byte_identical':sum(b['pages'] for b in batches)},'final_ui':{'producer':'d3f7ad00c8d4276967b8807e052d46a74d63be34','jobs_passed':13,'images':len(list((p/'final-ui').glob('*/*.png'))),'draw_checksums_unchanged':checks},'api_loopback_fixture':{'passed':[x['tag'] for x in apiok],'failed':[x['tag'] for x in apifail],'failure':'Cold-start native HTTP timer begins before font/theme setup; desktop-known request did not reach AIS503. A harness-only start-timing patch is staged for coordinated future integration. Failed attempt retained, not counted as localized response.','production_server_coverage':False},'tests':{'d3f7_unit_cases_passed':40,'d3f7_engine_cases_passed':22,'evidence':['artifacts/bulgarian/native-tests-corrected-unit','artifacts/bulgarian/native-tests-corrected-engine']},'limits':['No claim that all2536 matrix pages were visually read; exact inspected images are listed separately.','v3 contains18new keys and may include corrections from73-entry fresh language review; v2 coverage does not cover those changed targets.','Matrix inputs retain literal placeholders and9 native catalog values with literal backslash-n paragraph separators; actual UI formatting is covered only by explicit sampled surfaces.','Linux SDL development build and simulated phone-sized viewport only; no release, physical mobile, or cross-platform execution claim.','Initial63c9d actual surfaces remain evidence for their exact producer; corrected Settings/nav/API use d3f7 and font matrices/probes use3881.']}
save(p/'v2-component-validation.json',report)
# Bounded publication: selected matrix pages plus lossless complete diagnostics; no binaries or profiles.
paths=set(load(p/'font-corrected/publish-selection.json')['paths'])
for directory in p.iterdir():
 if directory.is_dir() and directory.name.startswith(('desktop-','phone-')) and 'matrix' not in directory.name:
  paths.update(str(x) for x in directory.iterdir() if x.is_file() and x.suffix in ['.png','.json'])
for root in [p/'final-ui',p/'font-corrected-probes']:
 paths.update(str(x) for x in root.glob('*/*.png'));paths.update(str(x) for x in root.glob('*/*.json'));paths.update(str(x) for x in root.glob('*.json'))
for job in api['jobs']:
 root=p/'final-api'/job['tag'];paths.update(str(x) for x in root.glob('*.json'))
 if job['returncode']==0:paths.update(str(x) for x in root.glob('*.png'))
paths.add(str(p/'final-api/execution.json'))
# Every before matrix diagnostic remains accessible; publish just targeted before raster/crop rather than all before sample pages.
paths.update(str(x) for x in p.glob('*-matrix-*-scale-*/font-matrix.json.gz'))
for pattern in ['*.json','*before-after*.png']:
 paths.update(str(x) for x in p.glob(pattern) if x.name!='publish-selection.json')
paths.update(str(x) for x in (p/'producers').glob('*/strip-debug-proof.json'))
paths.update(str(x) for x in (p/'font-corrected').glob('*.json'))
for directory in ['native-tests-corrected-unit','native-tests-corrected-engine','native-tests-font-corrected','native-tests-fixture-fixed']:
 q=pathlib.Path('artifacts/bulgarian')/directory
 if q.is_dir():paths.update(str(x) for x in q.iterdir() if x.is_file() and x.suffix in ['.json','.xml','.log'])
for s in paths:assert pathlib.Path(s).is_file(),s
assert not any('/profile/' in s or 'TranslationPreviewHarness' in pathlib.Path(s).name for s in paths)
save(p/'publish-selection.json',{'status':'Curated v2 component evidence; future v3 supplemental artifacts pending','paths':sorted(paths),'rationale':'All actual screen/game/editor captures, synthetic probes, bounded36 corrected font pages and two contact sheets; complete lossless measured font diagnostics and exact producer provenance. Full2536 corrected matrix raster pages remain local. Before-state diagnostics preserved separately, not labeled corrected.','visual_inspection':'Only exact images listed in visual-inspection.json were visually inspected; selected matrix thumbnails do not imply all text pages read.','exclude':'No producer binaries, synthetic account profiles or full matrix raster dumps.'})
print(json.dumps({'scale1_pages_identical':sum(b['pages'] for b in batches),'publication_files':len(paths),'final_ui_images':report['final_ui']['images'],'all_matrix_samples':75156,'raw_width_diagnostics':report['font']['raw_raster_width_diagnostics']}))
