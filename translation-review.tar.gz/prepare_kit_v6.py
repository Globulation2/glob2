"""Freeze the resolved in-progress merge and prepare blank-only BG/MS drafting.
Run only after the owner confirms all five SOURCE_PATHS are resolved/frozen.
No provider calls, catalog edits or review approvals are performed here.
"""
from pathlib import Path
from decimal import Decimal
import hashlib, importlib.util, json, shutil, subprocess
R=Path.cwd(); B=R/'artifacts/bulgarian'; K=B/'kit-v6'; OLD=B/'kit-v5'; SHADOW=B/'v6-tool-shadow'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not K.exists() and not SHADOW.exists(), 'Never overwrite an existing kit/shadow'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
merge=subprocess.check_output(['git','rev-parse','MERGE_HEAD'],text=True).strip()
for name in ('tools/localization/translation_program.py','data/check_translations.py'):
 q=SHADOW/name; q.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(R/name,q)
shutil.copytree(R/'tools/tutorials',SHADOW/'tools/tutorials',ignore=shutil.ignore_patterns('__pycache__'))
spec=importlib.util.spec_from_file_location('v6tool',SHADOW/'tools/localization/translation_program.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.NMT_TARGETS['bg']=='bg' and m.NMT_TARGETS['ms']=='ms'
for name in m.SOURCE_PATHS:
 b=(R/name).read_bytes();assert b'<<<<<<< 'not in b and b'>>>>>>> 'not in b,name
 q=SHADOW/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
m.prepare(K,root=SHADOW,locales=('bg','ms')); manifest=json.loads((K/'manifest.json').read_text()); assert (manifest['native_keys'],manifest['online_keys'])==(3429,2948) and manifest['source_sha256']=='dca9d5dac7b077148101c5feb29e9321c93d59a922925fbcd3138da678c3d353'
manifest.update(revision=None,merge_context={'worktree_head':head,'merge_head':merge,'description':'Resolved in-progress merge SOURCE_PATHS frozen as exact bytes, not a committed revision.'});m.write_json(K/'manifest.json',manifest)
native=json.loads((K/'source/native.json').read_text());online=json.loads((K/'source/online.json').read_text());keys=(K/'source/native-keys.txt').read_text().splitlines();prior_native=json.loads((OLD/'source/native.json').read_text());prior_online=json.loads((OLD/'source/online.json').read_text())
assert native==prior_native and all(online.get(k)==v for k,v in prior_online.items())
bg_ids=['online:'+k for k in online if k not in prior_online];assert len(bg_ids)==105 and all(isinstance(online[x[7:]],str)for x in bg_ids)
seed={}; baseline={}
for locale in ('bg','ms'):
 m.draft(K,locale);current_native=R/f'data/texts.{locale}.txt';current_online=R/f'platform/packages/i18n/locales/{locale}.json';table,errors=m.CHECKER.read_table(current_native);assert not errors,(locale,errors); obj=json.loads(current_online.read_text());assert set(table)<=set(native) and set(obj)<=set(online)
 # Preserve all existing reviewed values exactly; only absent source rows are blank.
 n={k:table.get(k,'')for k in keys};o={k:obj.get(k,'' if isinstance(v,str)else {c:''for c in m.plural_categories(locale)})for k,v in online.items()}
 if locale=='bg':
  old_table,e=m.CHECKER.read_table(OLD/'drafts/bg/texts.bg.txt');assert not e and table==old_table
  old_obj=json.loads((OLD/'drafts/bg/bg.json').read_text());assert all(obj.get(k)==v for k,v in old_obj.items())
  assert set(k for k,v in o.items()if not isinstance(v,str)or v.strip())>=set(old_obj)
  assert [f'online:{k}'for k in online if not (isinstance(o[k],str)and o[k].strip()) and k not in old_obj]==bg_ids
 else:
  missing_n=[k for k in keys if k not in table];missing_o=[k for k in online if k not in obj];assert len(missing_n)==18 and missing_o==['Artist'],(missing_n,missing_o)
  marked_ms=[{'key':k,'target':v}for k,v in table.items()if v.startswith('*')]
  assert [e['key']for e in marked_ms]==['[no fullscreen]'],'Unexpected additional marked Malay baseline'
  ms_ids=['native:'+k for k in missing_n]+['online:'+k for k in missing_o]
 paths=m.catalog_paths(K,locale);paths['native'].write_text(''.join(k+'\n'+n[k]+'\n'for k in keys),encoding='utf-8');m.write_json(paths['online'],o)
 seed[locale]={'native':n,'online':o}; baseline[locale]={'native':{'path':str(current_native.relative_to(R)),'sha256':sha(current_native),'preserved_pairs':len(table)},'online':{'path':str(current_online.relative_to(R)),'sha256':sha(current_online),'preserved_pairs':len(obj)}}
shutil.copytree(OLD/'machine',K/'machine')
for folder in ('rejected','provider-history'):
 if (OLD/folder).exists():shutil.copytree(OLD/folder,K/folder)
ledger=json.loads((K/'machine/spend-ledger.json').read_text());spent=sum((Decimal(r['reserved_usd'])for r in ledger['reservations']),Decimal());assert len(ledger['reservations'])==88 and spent==Decimal('5.29466')and sha(K/'machine/spend-ledger.json')==sha(OLD/'machine/spend-ledger.json')
raw=list((K/'machine').rglob('*.response.bin'));assert len(raw)==88
for p in raw:
 request,num=p.name.removesuffix('.response.bin').rsplit('-',1);assert ledger['reservations'][int(num)-1]['request_sha256']==request
entries={}; cost=Decimal()
for locale,ids in [('bg',bg_ids),('ms',ms_ids)]:
 m.write_json(K/f'{locale}-delta-only-keys.json',ids);rows=[]
 for entry_id in ids:
  surface,key=entry_id.split(':',1);source=(native if surface=='native'else online)[key];assert isinstance(source,str)
  protected,replacements=m.protect_text(source,json.loads((K/'source/invariants.json').read_text()).get(key,[])if surface=='online'else[])
  assert len(protected)<=5000
  rows.append({'id':entry_id,'surface':surface,'key':key,'source':source,'target':None,'protected_codepoints':len(protected),'protected_tokens':list(replacements.values())})
 chars=sum(r['protected_codepoints']for r in rows); charge=Decimal(chars)*Decimal(20)/1000000;cost+=charge;entries[locale]={'locale':locale,'NMT_target':m.NMT_TARGETS[locale],'entries':rows,'protected_codepoints':chars,'expected_usd':str(charge),'approval':None};m.write_json(K/f'{locale}-machine-input.json',entries[locale])
old_manifest=json.loads((OLD/'manifest.json').read_text());old_batches={b['id']:b for b in old_manifest['batches']};affected=[]
for b in manifest['batches']:
 previous=old_batches.get(b['id']);membership=previous is None or previous['keys']!=b['keys'];sources_changed=any((native if i.startswith('native:')else online).get(i.split(':',1)[1])!=(prior_native if i.startswith('native:')else prior_online).get(i.split(':',1)[1])for i in b['keys'])
 if membership or sources_changed:affected.append({'id':b['id'],'entries':len(b['keys']),'old_entries':len(previous['keys'])if previous else 0,'membership_changed':membership,'source_changed':sources_changed})
record={'revision':None,'merge_context':manifest['merge_context'],'source_sha256':manifest['source_sha256'],'source_files':manifest['source_files'],'tool_sha256':sha(SHADOW/'tools/localization/translation_program.py'),'mappings':{'bg':'bg','ms':'ms'},'mapping_reference':{'url':'https://docs.cloud.google.com/translate/docs/languages#nmt','finding':'Official NMT table lists Malay ms separately from Malay (Jawi) ms-Arab.'},'baseline':baseline,'master_ms_marked_entry_preserved_outside_scope':marked_ms,'copied_ledger_sha256':sha(K/'machine/spend-ledger.json'),'prior_reservations':88,'prior_reserved_usd':str(spent),'prior_raw_bodies':len(raw),'prior_machine_sha256':{str(p.relative_to(K/'machine')):sha(p)for p in(K/'machine').rglob('*')if p.is_file()},'delta_counts':{l:len(v['entries'])for l,v in entries.items()},'expected_additional_usd':str(cost),'expected_total_usd':str(spent+cost),'rate_per_million':'20','cap_usd':'10','affected_batches_full_review_required':affected,'paid_calls':0,'reviews':'All gates pending; no approvals fabricated or automatically carried','old_active_pointer':(B/'active-machine-kit.txt').read_text()}
assert spent+cost<10;m.write_json(K/'preflight.json',record);print(json.dumps({k:v for k,v in record.items()if k!='prior_machine_sha256'},ensure_ascii=False,indent=2))
