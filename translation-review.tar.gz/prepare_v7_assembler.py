from pathlib import Path
import shutil,json,hashlib
B=Path('artifacts/bulgarian');H=B/'v7-review-assembler';P=H/'parent-v6';assert not H.exists();H.mkdir();P.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();K=B/'kit-v6'
for name in ('manifest.json','reviews/bg.json','review-proof-v6-validation.json'):
 q=P/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(K/name,q)
for folder in ('source','drafts/bg'):shutil.copytree(K/folder,P/folder)
(P/'linked-proofs').mkdir();shutil.copy2(B/'review-proof-v6-independent-validation.json',P/'linked-proofs/review-proof-v6-independent-validation.json');(H/'parent-snapshot.json').write_text(json.dumps({'purpose':'Immutable exact V6 parent snapshot; no runtime/review approval generated','files':{str(p.relative_to(P)):sha(p)for p in P.rglob('*')if p.is_file()}},indent=2)+'\n')
s=(B/'v6-review-assembler/assemble.py').read_text();s=s.replace("'/root/v5_semantic'","'/root/v7_meaning'").replace("'/root/v5_editor'","'/root/v7_editor'").replace("'/root/v5_adversary'","None")
s=s.replace('dca9d5dac7b077148101c5feb29e9321c93d59a922925fbcd3138da678c3d353','67ce07e9975d2737b6de64e547453a8ed3a3222acfdb99b7d5dc49646eb7f38b').replace("len(source['native'])==3429","len(source['native'])==3430").replace('len(allkeys)==6377','len(allkeys)==6378')
s=s.replace('review-proof-v6-validation.json','review-proof-v7-validation.json').replace('review-proof-v5-validation.json','review-proof-v6-validation.json').replace('review-proof-v5-independent-validation.json','review-proof-v6-independent-validation.json').replace('source_expansion_v6','source_expansion_v7').replace('final v5 parent','final v6 parent').replace('final v6 runtime','final v7 runtime').replace('MS19 separate','BN19 separate').replace("default=BASE/'kit-v6'","default=BASE/'kit-v7'").replace("default=HERE/'parent-v5'","default=HERE/'parent-v6'")
s=s.replace("('bg','ms')","('bg','ms','bn')").replace("('bg', 'ms')","('bg', 'ms', 'bn')")
s=s.replace("p=load_program();m=read", "require(all(isinstance(agent,str)and agent.startswith('/root/')for agent in ROLES.values())and len(set(ROLES.values()))==3,'actual final role roster is pending; do not infer adversary identity')\n p=load_program();m=read")
# Root supplies the actual adversary identity explicitly, rather than guessing a future agent.
s=s.replace("parser.add_argument('--write',action='store_true');args=parser.parse_args();proof,_=assemble", "parser.add_argument('--write',action='store_true');parser.add_argument('--roles',type=Path,default=HERE/'actual-role-roster.json');args=parser.parse_args();roster=read(args.roles);require(set(roster)==set(ROLES),'actual role roster fields differ');ROLES.update(roster);proof,_=assemble")
(H/'assemble.py').write_text(s)
(H/'actual-role-roster.json').write_text(json.dumps({'semantic':'/root/v7_meaning','editor':'/root/v7_editor','adversarial':None},indent=2)+'\n')
packet=B/'kit-v7/bg-full-affected-batches-review-input.json';j=json.loads(packet.read_text());scope={'source_sha256':j['source_sha256'],'batches':[e['id']for e in j['batches']],'expected_entries':72,'candidate_packet':str(packet),'candidate_packet_sha256':sha(packet),'context_reuse':[],'scope_status':'PRELIMINARY machine candidate; root must bind actual final edited candidate packet before validation','author':'/root/draft_tooling'};(B/'kit-v7/final-review-scope.json').write_text(json.dumps(scope,indent=2)+'\n')
# Keep independent validator as a scaffold: no proof/record exists until actual final reports.
s=(B/'v6-review-assembler/validate_written.py').read_text().replace("K=B/'kit-v6'","K=B/'kit-v7'").replace("/'parent-v5'","/'parent-v6'").replace('review-proof-v6-validation.json','review-proof-v7-validation.json').replace('review-proof-v6-independent-validation.json','review-proof-v7-independent-validation.json').replace('source_expansion_v6','source_expansion_v7').replace('6377','6378').replace('6149','6306').replace('228','72').replace("len(proof['source_added_ids'])==105 and proof['target_changed_existing_ids']==[]","len(proof['source_added_ids'])==1")
s=s.replace("for surface in psource:\n for key,value in psource[surface].items():assert source[surface][key]==value and target[surface][key]==ptarget[surface][key]", "for surface in psource:\n for key,value in psource[surface].items():assert source[surface][key]==value")
s=s.replace("['/root','/root/v5_semantic','/root/v5_editor','/root/v5_adversary']", "['/root',*actual_roles.values()]")
s=s.replace("m=read(K/'manifest.json');", "actual_roles=read(Path(__file__).resolve().parent/'actual-role-roster.json');assert all(isinstance(v,str)for v in actual_roles.values())\nm=read(K/'manifest.json');")
s=s.replace("parent['source_expansion_v5']", "parent['source_expansion_v6']").replace("record['source_expansion_v5']", "record['source_expansion_v6']")
# V6 parent has no new context approvals, but retains V5 music-context lineage.
s=s.replace("assert len(parent['source_expansion_v6']['context_reuse'])==3", "assert parent['source_expansion_v6']['context_reuse']==[]")
s=s.replace("'parent_context_approvals_preserved':3", "'parent_context_approvals_preserved':'Exact V6 lineage, including original V5 music-context records'")
(H/'validate_written.py').write_text(s)
