from pathlib import Path
from decimal import Decimal
from collections import Counter
import hashlib,importlib.util,json,shutil,subprocess
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'kit-v6';OLD=B/'kit-v5';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
spec=importlib.util.spec_from_file_location('v6validate',B/'v6-tool-shadow/tools/localization/translation_program.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);manifest=load(K/'manifest.json');pre=load(K/'preflight.json');assert m.sources()[4]==manifest['source_sha256']=='dca9d5dac7b077148101c5feb29e9321c93d59a922925fbcd3138da678c3d353'
native=load(K/'source/native.json');online=load(K/'source/online.json');invariants=load(K/'source/invariants.json');ledger=load(K/'machine/spend-ledger.json');old_ledger=load(OLD/'machine/spend-ledger.json');assert ledger['reservations'][:88]==old_ledger['reservations'];assert len(ledger['reservations'])==90 and sum((Decimal(r['reserved_usd'])for r in ledger['reservations']),Decimal())==Decimal('5.36788')
for rel,expected in pre['prior_machine_sha256'].items():
 if rel=='spend-ledger.json':continue
 if rel=='bg/provider-drafts.json':
  previous=load(OLD/'machine'/rel);current=load(K/'machine'/rel);assert all(current.get(k)==v for k,v in previous.items());continue
 assert sha(K/'machine'/rel)==expected,rel
raw=list((K/'machine').rglob('*.response.bin'));assert len(raw)==90
for p in raw:
 request,num=p.name.removesuffix('.response.bin').rsplit('-',1);assert ledger['reservations'][int(num)-1]['request_sha256']==request
# The provider helper serializes native rows in English-table order even for
# online-only requests; restore untouched BG native bytes after exact pair check.
old_bg,e=m.CHECKER.read_table(R/'data/texts.bg.txt');draft_bg,de=m.CHECKER.read_table(K/'drafts/bg/texts.bg.txt');assert not e and not de and old_bg==draft_bg
shutil.copy2(R/'data/texts.bg.txt',K/'drafts/bg/texts.bg.txt')
catalogs={};results={};allrows={}
for locale,count in [('bg',105),('ms',19)]:
 paths=m.catalog_paths(K,locale);table,errors=m.CHECKER.read_table(paths['native']);assert not errors;obj=load(paths['online']);catalogs[locale]={'native':table,'online':obj};provider=load(K/f'machine/{locale}/provider-drafts.json');ids=load(K/f'{locale}-delta-only-keys.json');assert len(ids)==count
 # Original provider cache/draft history remains separate from edited candidates.
 folder=K/f'provider-drafts/{locale}';folder.mkdir(parents=True,exist_ok=True)
 for surface,path in paths.items():shutil.copy2(path,folder/path.name)
 rows=[]
 for entry_id in ids:
  surface,key=entry_id.split(':',1);source=(native if surface=='native'else online)[key];target=catalogs[locale][surface][key];protected,replacements=m.protect_text(source,invariants.get(key,[])if surface=='online'else[]);item=provider[json.dumps([surface,key,''],ensure_ascii=False)];assert item['source']==source and item['translation']==target and target.strip()
  for token in set(replacements.values()):assert source.count(token)==target.count(token),(locale,key,token)
  request_hash=item['request_sha256'];request_file=list((K/f'machine/{locale}/raw').glob(request_hash+'-*.request.json'))[-1];request=load(request_file);response_file=request_file.with_name(request_file.name.replace('.request.json','.response.bin'));raw_body=response_file.read_bytes();response=json.loads(raw_body);payload=request['payload'];assert payload['targetLanguageCode']==locale and payload['sourceLanguageCode']=='en' and payload['mimeType']=='text/plain';assert payload['model']=='projects/bradley-personal-20261027/locations/global/models/general/nmt';assert len(payload['contents'])==len(response['translations']);index=payload['contents'].index(protected);assert m.restore_text(response['translations'][index]['translatedText'],replacements)==target
  rows.append({'id':entry_id,'surface':surface,'key':key,'source':source,'target':target,'protected_tokens':list(replacements.values()),'source_sha256':m.digest(source.encode()),'target_sha256':m.digest(target.encode()),'request_sha256':request_hash,'raw_provider_sha256':m.digest(raw_body),'raw_provider_path':str(response_file.relative_to(B)),'approval':None})
 for surface in ('native','online'):
  original_path=R/pre['baseline'][locale][surface]['path'];assert sha(original_path)==pre['baseline'][locale][surface]['sha256'];original=m.CHECKER.read_table(original_path)[0]if surface=='native'else load(original_path);assert all(catalogs[locale][surface][k]==v for k,v in original.items()),(locale,surface)
 result=m.check_draft(K,locale);assert not result['errors'],(locale,result['errors']);allrows[locale]=rows;results[locale]={'new_entries':count,'original_native_pairs_preserved':pre['baseline'][locale]['native']['preserved_pairs'],'original_online_pairs_preserved':pre['baseline'][locale]['online']['preserved_pairs'],'catalog_sha256':{surface:sha(path)for surface,path in paths.items()},'delta_all_tokens_exact':True,'provider_raw_and_cache_validated':True,'check_draft_errors':result['errors'],'check_draft_untranslated_count':len(result['untranslated'])}
 m.write_json(K/f'{locale}-delta-review-input.json',{'source_sha256':manifest['source_sha256'],'manifest_sha256':sha(K/'manifest.json'),'locale':locale,'catalog_sha256':results[locale]['catalog_sha256'],'entries':rows,'status':'Machine first drafts; actual independent linguistic review required; no approval supplied.'})
affected={r['id']for r in pre['affected_batches_full_review_required']};full=[]
for batch in manifest['batches']:
 if batch['id']not in affected:continue
 for entry in load(K/batch['path'])['entries']:
  surface,key=entry['id'].split(':',1);full.append({**entry,'batch_id':batch['id'],'surface':surface,'target':catalogs['bg'][surface][key],'source_sha256':m.digest(json.dumps(entry['source'],ensure_ascii=False,sort_keys=True).encode())if not isinstance(entry['source'],str)else m.digest(entry['source'].encode()),'approval':None})
assert len(full)==228 and len({e['id']for e in full})==228
m.write_json(K/'bg-full-affected-batches-review-input.json',{'source_sha256':manifest['source_sha256'],'catalog_sha256':results['bg']['catalog_sha256'],'locale':'bg','batches':pre['affected_batches_full_review_required'],'entries':full,'entry_count':228,'new_pairs':105,'existing_pairs_requiring_fresh_full_batch_read':123,'status':'All three roles must actually read both full batches; no approval automatically carried.'})
# Correct an overly strict preparation assumption: this star is source punctuation.
marker={'key':'[no fullscreen]','source':native['[no fullscreen]'],'ms_target':catalogs['ms']['native']['[no fullscreen]'],'bg_target':catalogs['bg']['native']['[no fullscreen]'],'classification':'Intentional source UI marker; exact unchanged value preserved, not a translation omission or extra drafting scope.','initial_preparation_assumption':'First preparation halted before machine calls on this marker; preserved failed partial kit; explicit source comparison resolves false alarm.'};assert marker['source'].startswith('*')
pre.pop('master_ms_marked_entry_preserved_outside_scope',None);pre['intentional_source_marker_preserved']=marker;m.write_json(K/'preflight.json',pre)
validation={'source_sha256':manifest['source_sha256'],'source_keys':6377,'initial_ledger':{'reservations':88,'reserved_usd':'5.29466','sha256':pre['copied_ledger_sha256']},'current_ledger':{'reservations':90,'reserved_usd':'5.36788','sha256':sha(K/'machine/spend-ledger.json'),'raw_bodies':90,'exact88reservation_prefix':True,'prior_machine_files_exact_except_updated_ledger_and_bg_provider_index':True},'results':results,'full_review_batches':pre['affected_batches_full_review_required'],'full_bg_review_entries':228,'intentional_source_marker':marker,'gates':'All runtime/platform gates pending; no linguistic approvals invented','tool_sha256':pre['tool_sha256']}
m.write_json(K/'machine-validation.json',validation);print(json.dumps(validation,ensure_ascii=False,indent=2))
# New active kit only after validation; never overwrite source catalogs.
(B/'active-machine-kit.txt').write_text(str(K.relative_to(R))+'\n')
