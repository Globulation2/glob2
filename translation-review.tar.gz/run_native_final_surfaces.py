from pathlib import Path
import json,os,subprocess,time,hashlib,sys
root=Path.cwd();base=root/'artifacts/bulgarian/native-captures/final-ui';base.mkdir(parents=True,exist_ok=True);binary=Path(sys.argv[1]).resolve();kit=root/'artifacts/bulgarian/kit-v2/render-input/bg';jobs=[];entries=[]
for presentation,w,h in [('desktop',1280,1024),('phone',480,960)]:
 for name in ['settings','settings-ais','settings-online','settings-player']+(['settings-controls']if presentation=='desktop'else[]):jobs.append((presentation,w,h,100,'screen',name))
for w,h in [(480,960),(360,720)]:
 for growth in [100,150]:jobs.append(('phone',w,h,growth,'game','gameplay'))
for presentation,w,h,growth,mode,name in jobs:
 tag=f'{presentation}-{w}x{h}-{growth}-{name}';output=base/tag;output.mkdir(exist_ok=True);profile=output/'profile';user=profile/'user';user.mkdir(parents=True,exist_ok=True);(user/'preferences.txt').write_text(f'textSizePercent={growth}\nlanguage=bg\n')
 env=dict(os.environ,LD_LIBRARY_PATH=str(root/'artifacts/bulgarian/sdl3/prefix/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''),GLOB2_USER_DATA_DIR=str(user),XDG_DATA_HOME=str(profile/'data'),XDG_CONFIG_HOME=str(profile/'config'),XDG_CACHE_HOME=str(profile/'cache'),SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='x11',GLOB2_RENDERER='software')
 if presentation=='phone':env['GLOB2_MOBILE_UI']='1'
 else:env.pop('GLOB2_MOBILE_UI',None)
 cmd=['xvfb-run','-a','-s','-screen 0 1600x1400x24',str(binary),mode,str(root),str(kit),str(output),str(w),str(h),name];start=time.monotonic();print('START',tag,flush=True)
 with (output/'capture.log').open('w')as log:
  try:rc=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
  except subprocess.TimeoutExpired:rc='timeout'
 entries.append({'tag':tag,'command':cmd,'returncode':rc,'seconds':round(time.monotonic()-start,2),'text_size_percent':growth,'fresh_profile':str(user)});(base/'execution.json').write_text(json.dumps({'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'jobs':entries},indent=2)+'\n');print('END',tag,rc,flush=True)
 if rc!=0:print((output/'capture.log').read_text()[-2000:],flush=True)
print('COMPLETE',sum(x['returncode']==0 for x in entries),'/',len(entries),flush=True)
