from pathlib import Path
import importlib.util,json,hashlib
from decimal import Decimal
R=Path.cwd();K=R/'artifacts/bulgarian/kit-v6';T=R/'artifacts/bulgarian/v6-tool-shadow/tools/localization/translation_program.py';P=json.loads((K/'preflight.json').read_text());assert hashlib.sha256(T.read_bytes()).hexdigest()==P['tool_sha256'];ledger=json.loads((K/'machine/spend-ledger.json').read_text());assert len(ledger['reservations'])==88 and sum((Decimal(x['reserved_usd'])for x in ledger['reservations']),Decimal())==Decimal('5.29466')
spec=importlib.util.spec_from_file_location('exact_v6_tool',T);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results={}
for locale,count in [('bg',105),('ms',19)]:
 ids=json.loads((K/f'{locale}-delta-only-keys.json').read_text());assert len(ids)==count
 results[locale]=m.machine_draft(K,locale,'bradley-personal-20261027',max_cost_usd='10',rate_per_million='20',retries=0,only_keys=ids)
 assert results[locale]['filled']==count and results[locale]['paid_requests']==1
 print(json.dumps({locale:results[locale]}),flush=True)
 m.write_json(K/'machine-results.json',results)
