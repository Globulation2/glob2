from pathlib import Path
from decimal import Decimal
import hashlib,importlib.util,json,shutil,subprocess
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'kit-v8';OLD=B/'kit-v7';S=B/'v8-tool-shadow';assert not K.exists()and not S.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
for name in('tools/localization/translation_program.py','data/check_translations.py'):
 q=S/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/name,q)
shutil.copytree(R/'tools/tutorials',S/'tools/tutorials',ignore=shutil.ignore_patterns('__pycache__'))
spec=importlib.util.spec_from_file_location('v8tool',S/'tools/localization/translation_program.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);assert m.NMT_TARGETS['mr']=='mr' and m.NMT_TARGETS['ta']=='ta'
for name in m.SOURCE_PATHS:
 data=(R/name).read_bytes();assert b'<<<<<<< 'not in data and b'>>>>>>> 'not in data,name
 q=S/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
m.prepare(K,root=S,locales=('bg','mr','ta'));manifest=load(K/'manifest.json');assert (manifest['native_keys'],manifest['online_keys'])==(3430,2978)
manifest.update(revision=None,merge_context={'worktree_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'merge_head':subprocess.check_output(['git','rev-parse','MERGE_HEAD'],text=True).strip(),'description':'Exact marker-free resolved five SOURCE_PATHS bytes from in-progress merge; not committed source identity.'});m.write_json(K/'manifest.json',manifest)
native=load(K/'source/native.json');online=load(K/'source/online.json');oldnative=load(OLD/'source/native.json');oldonline=load(OLD/'source/online.json');assert sha(OLD/'reviews/bg.json')=='1a2e8d54d39de0cf1e8202b421419cca2055f54e9f3a52b2e1f83b5bc0cd5e93';assert all(native.get(k)==v for k,v in oldnative.items())and all(online.get(k)==v for k,v in oldonline.items());newkeys=set(online)-set(oldonline);assert native==oldnative and len(newkeys)==30
keys=(K/'source/native-keys.txt').read_text().splitlines();scopes={};baselines={}
for locale in('bg','mr','ta'):
 m.draft(K,locale);npath=R/f'data/texts.{locale}.txt';opath=R/f'platform/packages/i18n/locales/{locale}.json';n,errors=m.CHECKER.read_table(npath);assert not errors;obj=load(opath);assert set(n)<=set(native)and set(obj)<=set(online);missing_n=[k for k in keys if k not in n];missing_o=[k for k in online if k not in obj]
 if locale=='bg':
  oldn,e=m.CHECKER.read_table(OLD/'drafts/bg/texts.bg.txt');assert not e and oldn==n and obj==load(OLD/'drafts/bg/bg.json');assert not missing_n and set(missing_o)==newkeys
 else:assert len(missing_n)==18 and not missing_o,(missing_n,missing_o)
 scopes[locale]=['native:'+k for k in missing_n]+['online:'+k for k in missing_o];paths=m.catalog_paths(K,locale);paths['native'].write_text(''.join(k+'\n'+n.get(k,'')+'\n'for k in keys),encoding='utf-8');m.write_json(paths['online'],{k:obj.get(k,'')for k in online});baselines[locale]={}
 for surface,path in(('native',npath),('online',opath)):
  q=K/'baselines'/locale/path.name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,q);baselines[locale][surface]={'path':str(path.relative_to(R)),'snapshot':str(q.relative_to(K)),'sha256':sha(path),'pairs':len(n)if surface=='native'else len(obj)}
shutil.copytree(OLD/'machine',K/'machine')
for folder in('rejected','provider-history'):
 if(OLD/folder).exists():shutil.copytree(OLD/folder,K/folder)
ledger=load(K/'machine/spend-ledger.json');spent=sum((Decimal(r['reserved_usd'])for r in ledger['reservations']),Decimal());assert len(ledger['reservations'])==92 and spent==Decimal('5.39284')and sha(K/'machine/spend-ledger.json')==sha(OLD/'machine/spend-ledger.json');raw=list((K/'machine').rglob('*.response.bin'));assert len(raw)==92
for path in raw:
 request,num=path.name.removesuffix('.response.bin').rsplit('-',1);assert ledger['reservations'][int(num)-1]['request_sha256']==request
inv=load(K/'source/invariants.json');tot=Decimal();entries={}
for locale,ids in scopes.items():
 m.write_json(K/f'{locale}-delta-only-keys.json',ids);rows=[]
 for i in ids:
  surface,key=i.split(':',1);source=(native if surface=='native'else online)[key];assert isinstance(source,str);protected,replacements=m.protect_text(source,inv.get(key,[])if surface=='online'else[]);assert len(protected)<=5000;rows.append({'id':i,'surface':surface,'key':key,'source':source,'target':None,'protected_codepoints':len(protected),'protected_tokens':list(replacements.values())})
 chars=sum(r['protected_codepoints']for r in rows);cost=Decimal(chars)*20/1000000;tot+=cost;entries[locale]={'source_sha256':manifest['source_sha256'],'locale':locale,'NMT_target':locale,'entries':rows,'protected_codepoints':chars,'expected_usd':str(cost),'approval':None};m.write_json(K/f'{locale}-machine-input.json',entries[locale])
oldb={b['id']:b for b in load(OLD/'manifest.json')['batches']};affected=[]
for batch in manifest['batches']:
 old=oldb.get(batch['id']);changed=not old or batch['keys']!=old['keys']
 if changed:affected.append({'id':batch['id'],'entries':len(batch['keys']),'old_entries':len(old['keys'])if old else 0,'membership_changed':True})
for name,expected in manifest['source_files'].items():
 data=(S/name).read_bytes();assert hashlib.sha256(data).hexdigest()==expected;q=K/'frozen-source-inputs'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
record={'revision':None,'merge_context':manifest['merge_context'],'source_sha256':manifest['source_sha256'],'source_files':manifest['source_files'],'native_keys':3430,'online_keys':2978,'tool_sha256':sha(S/'tools/localization/translation_program.py'),'NMT_target_mapping':{'bg':'bg','mr':'mr','ta':'ta'},'official_mapping_reference':'https://docs.cloud.google.com/translate/docs/languages#nmt','mapping_verified':'Marathi mr and Tamil ta are listed in the official NMT table; explicit approved addition only.','baseline':baselines,'prior_reservations':92,'prior_reserved_usd':str(spent),'copied_ledger_sha256':sha(K/'machine/spend-ledger.json'),'prior_machine_sha256':{str(p.relative_to(K/'machine')):sha(p)for p in(K/'machine').rglob('*')if p.is_file()},'prior_raw_bodies':92,'delta_counts':{l:len(v['entries'])for l,v in entries.items()},'codepoints':{l:v['protected_codepoints']for l,v in entries.items()},'expected_additional_usd':str(tot),'expected_total_usd':str(spent+tot),'rate_per_million':'20','cap_usd':'10','affected_full_BG_batches':affected,'paid_calls':0,'reviews':'No approvals; all runtime/platform gates pending','active_pointer_before':(B/'active-machine-kit.txt').read_text()};assert spent+tot<10;m.write_json(K/'preflight.json',record);print(json.dumps({k:v for k,v in record.items()if k!='prior_machine_sha256'},ensure_ascii=False,indent=2))
