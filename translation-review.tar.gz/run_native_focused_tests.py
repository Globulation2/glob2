from pathlib import Path
import os,subprocess,json,time,hashlib
root=Path.cwd();out=root/'artifacts/bulgarian/native-tests-retry';out.mkdir(exist_ok=True);build=root/'build/linux/client/debug/dev-dev_fast-true-linker-auto'
filters=['SystemLanguage/*','FontKerning/*','CommunityMusicUI/*','GUIInteractionCoverage/Bulgarian*','MapGeneratorDefaults/*defaults*']
cmd=['xvfb-run','-a','-s','-screen 0 1600x1400x24','python3','test/run_tests.py','--build-dir',str(build),'--binary','engine','-j','2','--display-jobs','1','--timeout','600','--junit',str(out/'junit.xml'),'--artifacts',str(out),'--write-inventory',str(out/'inventory.json'),'--write-timings',str(out/'timings.json')]
for f in filters:cmd+=['--filter',f]
env=dict(os.environ,XDG_SESSION_TYPE='x11',LD_LIBRARY_PATH=str(root/'artifacts/bulgarian/sdl3/prefix/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''))
for key in ['WAYLAND_DISPLAY','WAYLAND_SOCKET','SDL_VIDEODRIVER','SDL_VIDEO_DRIVER']:env.pop(key,None)
identity={'environment_note':'Inherited Wayland variables cleared; XDG_SESSION_TYPE=x11. SDL automatic selection verified X11 under own Xvfb. Timeout600s for host contention; prior failed/timeout attempt retained native-tests.', 'command':cmd,'filters':filters,'runtime_library_path':env['LD_LIBRARY_PATH'],'binary_sha256':hashlib.sha256((build/'test/glob2-engine-tests').read_bytes()).hexdigest(),'compiled_revision':'63c9d875a51094b28930296d07a5a7ec6a9a808d','limits':'Focused rendering/language/UI/defaults checks on Linux dev_fast producer; not release, cross-platform or simulation-network equivalence verification.'}
(out/'command.json').write_text(json.dumps(identity,indent=2)+'\n');start=time.monotonic()
with (out/'run.log').open('w')as log:rc=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
identity.update(returncode=rc,seconds=round(time.monotonic()-start,2));(out/'command.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity,indent=2));raise SystemExit(rc)
