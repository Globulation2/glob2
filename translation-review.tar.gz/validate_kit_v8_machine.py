from pathlib import Path
from decimal import Decimal
import hashlib,importlib.util,json,shutil,subprocess
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'kit-v8';OLD=B/'kit-v7';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
spec=importlib.util.spec_from_file_location('v8',B/'v8-tool-shadow/tools/localization/translation_program.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);manifest=load(K/'manifest.json');pre=load(K/'preflight.json');assert m.sources()[4]==manifest['source_sha256'];ledger=load(K/'machine/spend-ledger.json');assert ledger['reservations'][:92]==load(OLD/'machine/spend-ledger.json')['reservations'];assert len(ledger['reservations'])==95 and sum((Decimal(x['reserved_usd'])for x in ledger['reservations']),Decimal())==Decimal('5.46822')
for rel,expected in pre['prior_machine_sha256'].items():
 if rel=='spend-ledger.json':continue
 if rel=='bg/provider-drafts.json':
  prior=load(OLD/'machine'/rel);now=load(K/'machine'/rel);assert all(now.get(k)==v for k,v in prior.items());continue
 assert sha(K/'machine'/rel)==expected,rel
native=load(K/'source/native.json');online=load(K/'source/online.json');inv=load(K/'source/invariants.json');membership={i:b['id']for b in manifest['batches']for i in b['keys']};catalogs={};results={}
for locale,count in [('bg',30),('mr',18),('ta',18)]:
 ids=load(K/f'{locale}-delta-only-keys.json');assert len(ids)==count;paths=m.catalog_paths(K,locale);n,e=m.CHECKER.read_table(paths['native']);assert not e;obj=load(paths['online']);bnpath=K/pre['baseline'][locale]['native']['snapshot'];oldn,e=m.CHECKER.read_table(bnpath);assert not e and all(n[k]==v for k,v in oldn.items());new_native=[i[7:]for i in ids if i.startswith('native:')]
 # Preserve existing native row order and literal bytes; append only new rows.
 basebytes=bnpath.read_bytes();assert basebytes.endswith(b'\n');paths['native'].write_bytes(basebytes+''.join(k+'\n'+n[k]+'\n'for k in new_native).encode());n,e=m.CHECKER.read_table(paths['native']);assert not e;catalogs[locale]={'native':n,'online':obj};provider=load(K/f'machine/{locale}/provider-drafts.json');rows=[]
 for i in ids:
  surface,key=i.split(':',1);source=(native if surface=='native'else online)[key];target=catalogs[locale][surface][key];protected,replacements=m.protect_text(source,inv.get(key,[])if surface=='online'else[]);pr=provider[json.dumps([surface,key,''],ensure_ascii=False)];assert pr['source']==source and pr['translation']==target and target.strip()
  for token in set(replacements.values()):assert source.count(token)==target.count(token),(locale,key,token)
  req=next((K/f'machine/{locale}/raw').glob(pr['request_sha256']+'-*.request.json'));request=load(req);raw=req.with_name(req.name.replace('.request.json','.response.bin'));response=load(raw);payload=request['payload'];assert payload['sourceLanguageCode']=='en'and payload['targetLanguageCode']==locale and payload['mimeType']=='text/plain'and payload['model']=='projects/bradley-personal-20261027/locations/global/models/general/nmt';assert len(payload['contents'])==len(response['translations']);index=payload['contents'].index(protected);assert m.restore_text(response['translations'][index]['translatedText'],replacements)==target
  rows.append({'id':i,'surface':surface,'key':key,'batch_id':membership[i],'locale':locale,'source':source,'target':target,'source_sha256':m.digest(source.encode()),'target_sha256':m.digest(target.encode()),'protected_tokens':list(replacements.values()),'request_sha256':pr['request_sha256'],'raw_provider_path':str(raw.relative_to(B)),'raw_provider_sha256':sha(raw),'approval':None})
 for surface in ('native','online'):
  baseline=pre['baseline'][locale][surface];path=K/baseline['snapshot'];assert sha(path)==baseline['sha256'];old=m.CHECKER.read_table(path)[0]if surface=='native'else load(path);assert all(catalogs[locale][surface][k]==v for k,v in old.items())
 checked=m.check_draft(K,locale);assert not checked['errors']and not checked['untranslated'],checked;hashes={s:sha(p)for s,p in paths.items()};results[locale]={'new_entries':count,'catalog_sha256':hashes,'old_native_pairs_exact':pre['baseline'][locale]['native']['pairs'],'old_online_pairs_exact':pre['baseline'][locale]['online']['pairs'],'old_native_bytes_exact_prefix':True,'protected_tokens_exact':True,'check_draft_errors':[],'untranslated':0};m.write_json(K/f'{locale}-delta-review-input.json',{'source_sha256':manifest['source_sha256'],'catalog_sha256':hashes,'locale':locale,'entries':rows,'status':'Machine first draft only; no linguistic approval','caller_context':'BG online additions: soundtrack/project names and credits, 3D skin pose/views, account/match statistics, generation availability and saving status. Untitled skin is a blank-name fallback only; newDesign/guest initial name remains existing My colony. MR/TA18nativecompatibility: ScriptEditor compilation/load/save and line/column captions, GameSession stopped/remediation, missing generator, Hive app-owned acknowledgments; preserve diagnostics/UGC and interpolation. Inspect caller references and V7 source context before approval.'})
 for surface,path in paths.items():
  q=K/'provider-drafts'/locale/path.name;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.copy2(path,q)
raw=list((K/'machine').rglob('*.response.bin'));assert len(raw)==95
for path in raw:
 request,num=path.name.removesuffix('.response.bin').rsplit('-',1);assert ledger['reservations'][int(num)-1]['request_sha256']==request
full=[]
for batch in manifest['batches']:
 if batch['id']not in{r['id']for r in pre['affected_full_BG_batches']}:continue
 for e in load(K/batch['path'])['entries']:
  surface,key=e['id'].split(':',1);full.append({**e,'surface':surface,'locale':'bg','batch_id':batch['id'],'target':catalogs['bg'][surface][key],'approval':None})
assert len(full)==98;m.write_json(K/'bg-full-affected-batches-review-input.json',{'source_sha256':manifest['source_sha256'],'catalog_sha256':results['bg']['catalog_sha256'],'locale':'bg','entries':full,'entry_count':98,'batches':pre['affected_full_BG_batches'],'new_pairs':30,'existing_pairs_requiring_fresh_full_batch_read':68,'status':'Fresh actual original-three-role full-batch reading required; no approval carried automatically'})
result={'result':'passed','source_sha256':manifest['source_sha256'],'source_keys':6408,'prior92_ledger_exact_prefix':True,'all_prior_machine_files_unchanged_except_extended_ledger_and_bg_provider_index':True,'ledger_reservations':95,'reserved_usd':'5.46822','machine_raw_bodies':95,'results':results,'full_BG_review_batches':pre['affected_full_BG_batches'],'full_BG_review_entries':98,'runtime_platform_gates':'all pending; no linguistic approvals produced'};m.write_json(K/'machine-validation.json',result);(B/'active-machine-kit.txt').write_text(str(K.relative_to(R))+'\n');print(json.dumps(result,indent=2))
