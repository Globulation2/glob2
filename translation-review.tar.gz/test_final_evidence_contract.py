"""Mock final publisher contexts; these fixtures are not product review evidence."""
import ast,copy,hashlib,json,subprocess,sys,unittest
from pathlib import Path
from final_evidence_contract import validate_final_evidence,REQUIRED_GATES,LAYOUT_FINDINGS
import test_publisher_curation as curation
class FinalEvidenceTests(unittest.TestCase):
 def setUp(self):
  self.fixture=curation.CurationTests();self.fixture.setUp();self.addCleanup(self.fixture.doCleanups);self.base=self.fixture.base;self.freeze=self.fixture.ns['validate']
  report=self.fixture.write('runtime.json',b'{"mock_runtime":"pass"}');self.ref={'path':'runtime.json','sha256':hashlib.sha256(report.read_bytes()).hexdigest()};self.record_path=self.base/'review.json';self.path=self.base/'final.json'
  self.context={'revision':'a'*40,'source_sha256':'b'*64,'catalog_sha256':{'native':'c'*64,'online':'d'*64},'review_evidence_root':self.base,'audit_issues':[]}
  self.record={'source_sha256':self.context['source_sha256'],'catalog_sha256':self.context['catalog_sha256'],'findings':[],'technical_findings':[{'id':i,'severity':'major','state':'resolved','evidence':[self.ref]}for i in LAYOUT_FINDINGS],'gates':{gate:{'passed':True,'evidence':[self.ref]}for gate in REQUIRED_GATES}}
  self.data={'schema_version':1,'mode':'full-audit','revision':self.context['revision'],'source_sha256':self.context['source_sha256'],'catalog_sha256':self.context['catalog_sha256'],'scope':'Mock final Linux/Chromium scope','limits':['Mock fixture only; no real product approval.'],'reports':[self.ref],'findings':[],'gates':{gate:{'status':'passed','scope':'Actual mock test scope','evidence':[self.ref]}for gate in REQUIRED_GATES},'coverage':[{'id':'mock-runtime','status':'verified','scope':'Mock tested runtime','gate_ids':list(REQUIRED_GATES),'evidence':[self.ref]}]}
 def sync(self):
  self.record_path.write_text(json.dumps(self.record));ref={'path':'review.json','sha256':hashlib.sha256(self.record_path.read_bytes()).hexdigest()};self.context['review_record_ref']=ref;self.context['review_record']=self.record;self.data['review_record']=ref;self.data['reports']=[self.ref,ref];self.path.write_text(json.dumps(self.data))
 def validate(self):
  self.sync();return validate_final_evidence(self.path,self.base,self.context,self.freeze)
 def scoped(self):
  self.data['mode']='scoped-verification'
  for gate in ('native_platforms','mobile_platforms'):
   self.record['gates'][gate]={'passed':False,'evidence':[]};self.data['gates'][gate]={'status':'unavailable','scope':'Untested physical platform coverage','reason':'No physical devices available.','evidence':[]};self.context['audit_issues'].append(gate+' is pending or lacks evidence');self.data['coverage'].append({'id':gate,'status':'unavailable','scope':'Physical devices untested','reason':'Unavailable devices.','gate_ids':[gate],'evidence':[]})
 def test_full_audit_requires_all_nine_actual_passes(self):
  result=self.validate();self.assertTrue(result['full_audit_passed']);self.assertTrue(result['publication_ready_for_declared_scope']);self.assertFalse(result['unavailable_gates'])
 def test_scoped_retains_unavailable_false_and_exact_audit_issues(self):
  self.scoped();result=self.validate();self.assertFalse(result['full_audit_passed']);self.assertEqual(result['unavailable_gates'],['mobile_platforms','native_platforms']);self.assertEqual(result['audit_issues_retained'],self.context['audit_issues']);self.assertFalse(self.record['gates']['mobile_platforms']['passed'])
 def test_full_audit_cannot_waive_unavailable_platforms(self):
  self.scoped();self.data['mode']='full-audit'
  with self.assertRaises(ValueError):self.validate()
 def test_scoped_cannot_waive_structural_or_other_linguistic_gate(self):
  self.scoped();self.data['gates']['structural']={'status':'unavailable','scope':'Unknown','reason':'Not run.','evidence':[]};self.record['gates']['structural']['passed']=False
  with self.assertRaises(ValueError):self.validate()
 def test_unknown_non_gate_audit_error_rejected(self):
  self.scoped();self.context['audit_issues'].append('finding has an unknown key or severity')
  with self.assertRaisesRegex(ValueError,'non-waivable'):self.validate()
 def test_pending_layout_and_unresolved_major_fail(self):
  self.record['technical_findings'][0]['state']='pending-runtime-verification'
  with self.assertRaises(ValueError):self.validate()
 def test_missing_report_and_mismatched_hash_fail(self):
  (self.base/'runtime.json').write_bytes(b'{"changed":true}')
  with self.assertRaisesRegex(ValueError,'mismatched'):self.validate()
 def test_missing_actual_report_fails(self):
  (self.base/'runtime.json').unlink()
  with self.assertRaisesRegex(ValueError,'missing'):self.validate()
 def test_verified_gate_cannot_be_claimed_when_actual_record_false(self):
  self.record['gates']['phone_rendering']['passed']=False
  with self.assertRaises(ValueError):self.validate()
 def test_unavailable_cannot_be_labeled_passed_or_omit_coverage(self):
  self.scoped();self.data['coverage'][-1]['passed']=True
  with self.assertRaises(ValueError):self.validate()
 def test_actual_final_render_branches_keep_unavailable_scope_explicit(self):
  self.scoped();summary=self.validate();out=self.fixture.out;readiness=out/'curation-readiness.json';readiness.write_text(json.dumps({'status':'PREP','pending_categories':['pending']}));readme=out/'README.md'
  publisher=Path(__file__).with_name('publish_evidence.py');tree=ast.parse(publisher.read_text());branches=[node for node in tree.body if isinstance(node,ast.If)and isinstance(node.test,ast.Name)and node.test.id=='final_summary']
  self.assertEqual(len(branches),2);ns={'final_summary':summary,'revision':self.context['revision'],'context':self.context,'out':out,'readiness':readiness,'readme':readme,'files':{},'json':json,'manifest':{'publication_ready':False}}
  exec(compile(ast.Module(body=branches,type_ignores=[]),str(publisher),'exec'),ns)
  self.assertIn('Full nine-gate audit: incomplete',readme.read_text());self.assertIn('unavailable',readme.read_text());self.assertFalse(ns['manifest']['full_audit_passed']);self.assertTrue(ns['manifest']['publication_ready']);self.assertFalse(json.loads(readiness.read_text())['final_verification_scope']['full_audit_passed'])
 def test_unfilled_v6_template_is_pending_and_rejected(self):
  template=Path(__file__).with_name('v6-publication-prep')/'final-evidence-v6.template.json';self.data=json.loads(template.read_text());self.assertTrue(self.data['_template_only']);self.assertIsNone(self.data['revision']);self.assertIsNone(self.data['review_record']['sha256']);self.assertEqual(self.data['reports'],[]);self.assertTrue(all(g['status']=='pending'for g in self.data['gates'].values()))
  # Even supplying mock current identities/reports cannot turn pending gates into pass.
  for field in ('revision','source_sha256','catalog_sha256'):self.data[field]=self.context[field]
  self.data['findings']=[]
  with self.assertRaisesRegex(ValueError,'pending/unknown gate'):self.validate()
 def test_actual_cli_rejects_bad_final_record_before_rebuilding_archives(self):
  publisher=Path(__file__).with_name('publish_evidence.py');manifest=publisher.parent/'published/manifest.json';before=manifest.read_bytes();self.path.write_text(json.dumps({'schema_version':1,'mode':'full-audit','revision':'wrong','review_record':{'path':'kit-v4/reviews/bg.json','sha256':hashlib.sha256((publisher.parent/'kit-v4/reviews/bg.json').read_bytes()).hexdigest()}}))
  result=subprocess.run([sys.executable,str(publisher),'--final-evidence',str(self.path)],capture_output=True,text=True)
  self.assertNotEqual(result.returncode,0);self.assertTrue(any(message in result.stderr for message in ('revision does not match','source kit differs','catalog kit differs')),result.stderr);self.assertEqual(before,manifest.read_bytes())
if __name__=='__main__':unittest.main(verbosity=2)
