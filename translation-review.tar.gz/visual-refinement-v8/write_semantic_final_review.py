import json,hashlib,re
from pathlib import Path
R=Path('artifacts/bulgarian');V=R/'visual-refinement-v8';p=V/'bg320-after-editor-candidate-input.json';cp=V/'three-caller-context-input.json';initial=V/'semantic-review.json'
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
c=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
s=lambda v:hashlib.sha256((v if isinstance(v,str) else c(v)).encode()).hexdigest()
d=json.loads(p.read_text());ctx=json.loads(cp.read_text());old=json.loads(initial.read_text());prior={e['id']:e for e in old['entries']}
assert h(p)==ctx['candidate_packet']['sha256']
for f,expected in ctx['caller_sha256'].items():assert h(f)==expected
for f,x in ctx['caller_snapshots'].items():assert h(x['snapshot'])==x['snapshot_sha256']==x['sha256']==h(f)
es=[]
for e in d['entries']:
 x={k:e[k] for k in ['id','key','source','target','surface','locale','batch_id']};src=e['source'];tgt=e['target'];sv=src if isinstance(src,dict) else {'flat':src};tv=tgt if isinstance(tgt,dict) else {'flat':tgt};assert set(sv)==set(tv)
 variants=[]
 for k,v in sv.items():
  assert all(v.count(t)==tv[k].count(t) for t in re.findall(r'\{\w+\}|%\d+',v));variants.append({'variant':k,'source':v,'target':tv[k],'source_sha256':s(v),'target_sha256':s(tv[k]),'actual_fresh_complete_final_variant_read':True,'protected_tokens_preserved':True,'status':'approved','verdict':'accept','findings':[]})
 x.update(source_sha256=s(src),target_sha256=s(tgt),identity_sha256=s(c(['bg',e['id'],src,tgt])),status='approved',verdict='accept',actual_fresh_complete_final_pair_read=True,meaning_gameplay_checked=True,protected_tokens_preserved=True,variants=variants,findings=[],acceptance='Final complete source/target freshly reread after union of semantic and editorial corrections. Meaning, quantities, placeholder roles, grammatical count behavior and relevant software/game instruction preserved.')
 if 'caller_evidence' in prior[e['id']]:x['caller_evidence']=prior[e['id']]['caller_evidence']
 es.append(x)
assert len(es)==320 and sum(len(x['variants']) for x in es)==325
catalogs={}
for surf,path in [('native',R/'kit-v8/drafts/bg/texts.bg.txt'),('online',R/'kit-v8/drafts/bg/bg.json')]:
 assert h(path)==d['catalog_sha256'][surf];catalogs[surf]={'path':str(path),'sha256':h(path)}
contextpairs=[]
for e in ctx['catalog_pairs']:
 contextpairs.append({**e,'locale':'bg','source_sha256':s(e['source']),'target_sha256':s(e['target']),'identity_sha256':s(c(['bg',e['id'],e['source'],e['target']])), 'actual_fresh_complete_source_target_read':True,'actual_fresh_caller_context_read':True,'status':'approved','findings':[]})
checks=[{'id':'map-wallet-and-dialog','actual_fresh_production_caller_read':True,'assessment':'Visible and ARIA wallet both use same formatted Кредити за карти: {value0}; zero/one/two/ellipsis work without noun agreement error. Dialog uses standalone category Кредити за карти. Authored title copied unchanged.','status':'approved'}, {'id':'music-wallet-visible-and-aria','actual_fresh_production_caller_read':True,'assessment':'Visible and ARIA wallet both use same formatted Музикални кредити: {value0}; zero/one/two/ellipsis work. Dialog remains standalone Музикални кредити.','status':'approved'},{'id':'music-like-action-slot','actual_fresh_production_caller_read':True,'assessment':'value0 now translates paired Like/Unlike action before interpolation; in this toggle context Харесвам/Не харесвам indicates adding/removing current like, with no separate dislike action. value1 authored title remains literal and value2 numeric likes uses noun-first Харесвания label, valid for one and multiple.','status':'approved'}]
out={'reviewer_identity':{'agent':'/root/v7_meaning','role':'Independent final postvisual meaning/gameplay reviewer','human_native_reviewer':False,'assessment_kind':'agent-reviewed only'},'packet_path':str(p),'packet_sha256':h(p),'source_sha256':d['source_sha256'],'catalog_sha256':d['catalog_sha256'],'actual_draft_catalogs_bound':catalogs,'caller_context_packet_path':str(cp),'caller_context_packet_sha256':h(cp),'caller_sha256':{f:h(f) for f in old['caller_sha256']},'bound_caller_snapshots':ctx['caller_snapshots'],'initial_report_path':str(initial),'initial_report_sha256':h(initial),'hash_scheme':old['hash_scheme'],'coverage':{'expected':320,'actual_fresh_complete_final_pairs_read':320,'actual_fresh_complete_final_variants_read':325,'approved':320,'lineage_only':0,'protected_token_passes':320,'findings_remaining':0,'caller_contexts_freshly_read_and_approved':3,'context_pairs_freshly_read':7},'method':'Actually freshly reread every final320 complete English/Bulgarian pair and all325 variants; unchanged pairs were also re-evaluated, not accepted from lineage. Independently read actual updated three callers and verified frozen snapshots match live bytes. Mathematical normals, density, inspected-version state, credits-domain argument, flat count-neutral strings and count-aware plural calls checked.','context_pairs':contextpairs,'context_checks':checks,'runtime_evidence_limit':'Static caller/source/linguistic review only; this report does not claim expanded focused-test execution or runtime captures.','status':'approved','final_approval':True,'approval':'All320 exact final pairs/325 variants and all3 exact caller contexts accepted with no remaining semantic findings.','findings':[],'limits':['Agent review only; no native-human certification.','No source edits, staging, builds or tests performed.','Only exact bound packet/catalog/source/caller bytes approved; subsequent edits require fresh review.'],'entries':es}
dest=V/'semantic-final-review.json';dest.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(dest,h(dest))
