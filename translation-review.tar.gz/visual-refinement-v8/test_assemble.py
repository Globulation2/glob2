"""Temporary marked fixtures exercise mechanics; no reviewer approvals are emitted."""
import copy,importlib.util,json,shutil,tempfile,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('assembler',HERE/'assemble.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
class AssemblyTests(unittest.TestCase):
 def setUp(self):
  a.ROLES.update(semantic='/root/v7_meaning',editor='/root/v7_editor',adversarial='/root/mock-v7-adversary');self.temp=tempfile.TemporaryDirectory(dir=HERE,prefix='mock-test-');self.addCleanup(self.temp.cleanup);self.folder=Path(self.temp.name);self.path=self.folder/'mock.json';self.sourcehash='mock-source';self.hashes={'native':'n','online':'o'}
  self.expected={'native:[Mock]':{'source':'Source','target':'Превод'},'online:Mock plural':{'source':{'one':'One','other':'Many'},'target':{'one':'Едно','other':'Много'}}}
  self.entries=[]
  for i,v in self.expected.items():
   surface,key=i.split(':',1);self.entries.append({'id':i,'key':key,'surface':surface,**v,'status':'approved','final_read':True,'source_sha256':a.digest(v['source']if isinstance(v['source'],str)else a.canonical(v['source'])),'target_sha256':a.digest(v['target']if isinstance(v['target'],str)else a.canonical(v['target'])),'source_target_sha256':a.digest(a.canonical([i,v['source'],v['target']]))})
  self.data={'test_fixture':True,'reviewer_identity':{'agent':a.ROLES['semantic']},'status':'approved','source_sha256':self.sourcehash,'catalog_sha256':self.hashes,'coverage':{'expected':2,'reviewed':2,'approved':2,'fresh_final_pairs_read':2},'entries':self.entries,'findings':[]}
 def report(self):
  self.path.write_text(json.dumps(self.data,ensure_ascii=False));return a.verify_report(self.path,'semantic',self.expected,self.sourcehash,self.hashes)
 def test_valid_literal_and_plural_hashes(self):
  _,proof=self.report();self.assertEqual(proof['reading_lineage'],{'actual-reading':2,'own-exact-carry':0})
 def test_missing_final_report(self):
  with self.assertRaisesRegex(ValueError,'missing final'):a.verify_report(self.path,'semantic',self.expected,self.sourcehash,self.hashes)
 def test_pending_report_and_entry_rejected(self):
  self.data['status']='pending'
  with self.assertRaises(ValueError):self.report()
  self.data['status']='approved';self.entries[0]['status']='proposed_edit'
  with self.assertRaises(ValueError):self.report()
 def test_stale_source_and_target_catalog(self):
  self.data['source_sha256']='stale'
  with self.assertRaises(ValueError):self.report()
  self.data['source_sha256']=self.sourcehash;self.data['catalog_sha256']={'native':'wrong','online':'o'}
  with self.assertRaises(ValueError):self.report()
 def test_wrong_actual_role_identity(self):
  self.data['reviewer_identity']['agent']=a.ROLES['editor']
  with self.assertRaises(ValueError):self.report()
 def test_literal_pair_and_coverage_mismatch(self):
  self.entries[0]['target']='Wrong'
  with self.assertRaisesRegex(ValueError,'literal final pair'):self.report()
 def test_duplicate_and_missing_entries(self):
  self.data['entries']=[self.entries[0],self.entries[0]]
  with self.assertRaisesRegex(ValueError,'membership'):self.report()
 def test_value_hash_and_compound_hash_fail(self):
  self.entries[0]['source_sha256']='bad'
  with self.assertRaises(ValueError):self.report()
  self.entries[0]['source_sha256']=a.digest('Source');self.entries[0]['source_target_sha256']='bad'
  with self.assertRaisesRegex(ValueError,'combined'):self.report()
 def test_canonical_value_and_literal_variant_hashes(self):
  self.data['coverage']['literal_variants']=3
  for e in self.entries:
   e['source_sha256']=a.digest(a.canonical(e['source']));e['target_sha256']=a.digest(a.canonical(e['target']));e['pair_sha256']=e.pop('source_target_sha256')
   pairs={'literal':(e['source'],e['target'])}if isinstance(e['source'],str)else{k:(e['source'][k],e['target'][k])for k in e['source']}
   e['variants']={k:{'source_sha256_utf8':a.digest(v[0]),'target_sha256_utf8':a.digest(v[1]),'decision':'accepted'}for k,v in pairs.items()}
  _,proof=self.report();self.assertEqual(proof['value_hash_schemes'],['canonical-json'])
  self.entries[0]['variants']['literal']['target_sha256_utf8']='bad'
  with self.assertRaisesRegex(ValueError,'variant'):self.report()
 def test_wrong_batch_assignment_rejected(self):
  for value in self.expected.values():value['batch_id']='mock-batch'
  for e in self.entries:e['batch_id']='wrong-batch'
  with self.assertRaisesRegex(ValueError,'wrong batch'):self.report()
 def test_reading_claim_required(self):
  self.entries[0]['final_read']=False
  with self.assertRaisesRegex(ValueError,'actual fresh reading'):self.report()
 def test_fresh_full_batch_rejects_old_own_lineage(self):
  prior=self.folder/'prior.json';prior.write_text(json.dumps(self.data,ensure_ascii=False));self.entries[0]['final_read']=False;self.entries[0]['lineage']={'prior_report':str(prior),'prior_report_sha256':a.sha(prior)};self.data['coverage']['fresh_final_pairs_read']=1
  with self.assertRaisesRegex(ValueError,'actual fresh reading'):self.report()
 def test_false_fresh_count_rejected(self):
  self.data['coverage']['fresh_final_pairs_read']=1
  with self.assertRaisesRegex(ValueError,'contradicts'):self.report()
 def test_english_exception_requires_exact_parent_or_three_actual_reasons(self):
  src={'native':{'X':'X'},'online':{}};target=copy.deepcopy(src);old={'native':{'X':'old'},'online':{}};parent={'native:X':{'key':'native:X','reason':'Identifier'}};roles={r:{}for r in a.ROLES}
  accepted=a.english_exceptions({'native:X'},parent,src,target,src,target,set(),roles);self.assertEqual(accepted,list(parent.values()))
  with self.assertRaises(ValueError):a.english_exceptions({'native:X'},parent,src,target,old,target,{'native:X'},roles)
  for role in roles:roles[role]['accepted_english']=[{'key':'native:X','reason':'Actual mock identifier exception'}]
  self.assertEqual(len(a.english_exceptions({'native:X'},parent,src,target,old,target,{'native:X'},roles)),1)
 def test_context_requires_three_actual_acceptances_and_literal_hashes(self):
  reuse={'context_id':'mock-context','source':'Building','target':'Изграждане','catalog_key':'Build','catalog_source':'Build','reports_pending':True};scope={'context_reuse':[reuse]};source={'online':{'Build':'Build'}};target={'online':{'Build':'Изграждане'}};e={**reuse,'status':'approved','actual_fresh_read':True,'source_sha256':a.digest('Building'),'target_sha256':a.digest('Изграждане')};roles={role:{'context_reuse':[copy.deepcopy(e)]}for role in a.ROLES};proofs=[{'role':role}for role in a.ROLES]
  self.assertEqual(len(a.verify_contexts(scope,roles,proofs,source,target)),3)
  roles['editor']['context_reuse']=[]
  with self.assertRaises(ValueError):a.verify_contexts(scope,roles,proofs,source,target)
 def test_actual_v6_fresh_flags_and_locale_identity_hash(self):
  for index,e in enumerate(self.entries):
   e.pop('final_read');e['actual_fresh_complete_final_pair_read'if index==0 else 'final_fresh_read']=True;e['locale']='bg';e['identity_sha256']=a.digest(a.canonical(['bg',e['id'],e['source'],e['target']]))
  self.data['coverage']['actual_fresh_complete_final_pairs_read']=2
  self.report()
  self.entries[0]['identity_sha256']='bad'
  with self.assertRaisesRegex(ValueError,'identity hash'):self.report()
 def test_exact_aggregate_decision_and_report_fresh_read(self):
  self.data.pop('status');self.data['decision']='accepted_all_2';self.data['coverage'].update(fresh_read=True,entries=2)
  for e in self.entries:e.pop('final_read')
  self.report();self.data['decision']='accepted_all_3'
  with self.assertRaises(ValueError):self.report()
 def test_contradictory_approval_rejected(self):
  self.data['status']='pending';self.data['final_approval']=True
  with self.assertRaises(ValueError):self.report()
  self.data['status']='approved';self.entries[0]['decision']='reject'
  with self.assertRaises(ValueError):self.report()
 def test_malay_explicit_locale_and_identity_hashes(self):
  self.data['locale']='ms'
  for e in self.entries:e['locale']='ms';e['identity_sha256']=a.digest(a.canonical(['ms',e['id'],e['source'],e['target']]))
  self.path.write_text(json.dumps(self.data));_,proof=a.verify_report(self.path,'semantic',self.expected,self.sourcehash,self.hashes,locale='ms');self.assertEqual(proof['entries'],2)
 def test_report_and_entry_locale_must_match_scope(self):
  self.data['locale']='ms'
  with self.assertRaisesRegex(ValueError,'report locale'):self.report()
  self.data['locale']='bg';self.entries[0]['locale']='ms'
  with self.assertRaisesRegex(ValueError,'mixed report locale'):self.report()
 def test_changed_caller_context_rejected(self):
  caller=self.folder/'caller.cpp';caller.write_text('fixture original')
  self.data['caller_sha256']={str(caller):a.sha(caller)};self.report();caller.write_text('fixture changed')
  with self.assertRaisesRegex(ValueError,'caller context'):self.report()
 def test_agent_owned_normalization_preserves_original_entries_and_hash(self):
  original=self.folder/'actual-original.json';original.write_text(json.dumps(self.data));self.data['original_report']={'path':str(original),'sha256':a.sha(original)};self.report()
  self.entries[0]['extra_unreviewed_assertion']=True
  with self.assertRaisesRegex(ValueError,'unknown entry assertions'):self.report()
  self.entries[0].pop('extra_unreviewed_assertion');original.write_text('{}')
  with self.assertRaisesRegex(ValueError,'original report identity'):self.report()
 def test_two_exact_identity_hash_formats_and_consistency(self):
  for e in self.entries:e['identity_sha256']=a.digest(a.canonical([e['id'],e['source'],e['target']]))
  _,proof=self.report();self.assertEqual(proof['identity_hash_schemes'],['canonical-id-source-target'])
  e=self.entries[0];e['identity_sha256']=a.digest(a.canonical(['bg',e['id'],e['source'],e['target']]))
  with self.assertRaisesRegex(ValueError,'inconsistent role identity'):self.report()
 def test_agent_id_identity_and_explicit_approval_reader(self):
  self.data.pop('reviewer_identity');self.data['reviewer']={'agent_id':a.ROLES['semantic']}
  for e in self.entries:e['approval']=e.pop('status')
  self.report();self.entries[0]['decision']='reject'
  with self.assertRaises(ValueError):self.report()
 def test_mutated_unaffected_pair_rejected_before_missing_roles(self):
  original=a.BASE/'kit-v8';clone=self.folder/'kit';clone.mkdir()
  shutil.copy2(original/'manifest.json',clone/'manifest.json');shutil.copy2(HERE/'final-review-scope-after-editor.json',clone/'final-review-scope.json')
  shutil.copytree(original/'source',clone/'source');shutil.copytree(original/'drafts',clone/'drafts');m=a.read(clone/'manifest.json');scope=a.read(clone/'final-review-scope.json');fresh={i for b in m['batches']if b['id']in scope['batches']for i in b['keys']};path=clone/'drafts/bg/texts.bg.txt';lines=path.read_text().splitlines();key=next(k for k in lines[::2]if'native:'+k not in fresh);index=lines.index(key);lines[index+1]='MOCK OUT OF SCOPE';path.write_text('\n'.join(lines)+'\n');reports={r:self.folder/'missing.json'for r in a.ROLES}
  packet=a.read(a.resolve_reference(scope['candidate_packet']));packet['catalog_sha256']['native']=a.sha(path);packetpath=clone/'packet.json';packetpath.write_text(json.dumps(packet));scope['candidate_packet']=str(packetpath);scope['candidate_packet_sha256']=a.sha(packetpath);(clone/'final-review-scope.json').write_text(json.dumps(scope))
  with self.assertRaisesRegex(ValueError,'outside final full-batch scope'):a.assemble(clone,HERE/'before/kit-v8',clone/'final-review-scope.json',reports)
 def test_marathi_tamil_explicit_locales_and_identity_hashes(self):
  for locale in ('mr','ta'):
   self.data['locale']=locale
   for e in self.entries:e['locale']=locale;e['identity_sha256']=a.digest(a.canonical([locale,e['id'],e['source'],e['target']]))
   self.path.write_text(json.dumps(self.data));_,proof=a.verify_report(self.path,'semantic',self.expected,self.sourcehash,self.hashes,locale=locale);self.assertEqual(proof['entries'],2)
 def test_report_count_false_claim_rejected(self):
  self.data['reviewed_count']=3
  with self.assertRaisesRegex(ValueError,'total count'):self.report()
 def test_exact_packaging_closure_preserves_original_caller_binding(self):
  caller=self.folder/'caller.py';original=self.folder/'original.py';original.write_text("locales=('en', 'mr', 'ta')\n");caller.write_text("locales=('en', 'mr', 'ta', 'bg')\n");self.data['caller_sha256']={str(caller):a.sha(original)};self.path.write_text(json.dumps(self.data));closure={str(caller):{'original_path':str(original),'original_sha256':a.sha(original),'current_sha256':a.sha(caller),'old_literal':"('en', 'mr', 'ta')",'new_literal':"('en', 'mr', 'ta', 'bg')"}}
  a.verify_report(self.path,'semantic',self.expected,self.sourcehash,self.hashes,context_closure=closure)
  caller.write_text(caller.read_text()+'unreviewed_behavior=True\n');closure[str(caller)]['current_sha256']=a.sha(caller)
  with self.assertRaisesRegex(ValueError,'exact authorized packaging delta'):a.verify_report(self.path,'semantic',self.expected,self.sourcehash,self.hashes,context_closure=closure)
 def test_compatibility_scope_cannot_infer_unapproved_locale(self):
  spec=importlib.util.spec_from_file_location('compat',a.BASE/'v8-review-assembler/validate_compat18.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
  with self.assertRaisesRegex(ValueError,'unsupported compatibility'):c.validate({},locale='bn')
 def test_platform_resource_duplicate_and_decoding(self):
  spec=importlib.util.spec_from_file_location('platform_resources',a.BASE/'v8-review-assembler/validate_platform3.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);path=self.folder/'strings.xml';path.write_text('<resources><string name="name">A &amp; B</string></resources>');self.assertEqual(v.resource_value(path,'name'),'A & B');path.write_text('<resources><string name="name">A</string><string name="name">B</string></resources>')
  with self.assertRaisesRegex(ValueError,'duplicate'):v.resource_value(path,'name')
 def test_list_variants_exact_flat_and_plural_with_reading_assertions(self):
  for e in self.entries:
   pairs={'flat':(e['source'],e['target'])}if isinstance(e['source'],str)else{k:(e['source'][k],e['target'][k])for k in e['source']}
   e['variants']=[{'variant':k,'source':sv,'target':tv,'source_sha256':a.digest(sv),'target_sha256':a.digest(tv),'status':'approved','actual_fresh_complete_final_variant_read':True}for k,(sv,tv)in pairs.items()]
  self.report();self.entries[1]['variants'][0]['target']='Wrong'
  with self.assertRaisesRegex(ValueError,'variant literals'):self.report()
 def test_list_variant_duplicate_and_missing_fresh_reading_rejected(self):
  e=self.entries[0];v={'form':'flat','source':e['source'],'target':e['target'],'source_sha256':a.digest(e['source']),'target_sha256':a.digest(e['target']),'status':'approved','actual_fresh_complete_source_target_read':True};e['variants']=[v,v]
  with self.assertRaisesRegex(ValueError,'membership'):self.report()
  e['variants']=[v];v['actual_fresh_complete_source_target_read']=False
  with self.assertRaisesRegex(ValueError,'fresh reading'):self.report()
if __name__=='__main__':unittest.main(verbosity=2)
