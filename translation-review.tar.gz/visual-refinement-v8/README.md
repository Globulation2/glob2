Pre-edit V8 snapshot is immutable and fully SHA inventoried. No main source/catalog/gates changed by this preparation.

After root edits exactly the two ignored targets, run:

    python3 artifacts/bulgarian/visual-refinement-v8/prepare_scope.py --write

The command fails any third changed target, membership/source change, stale parent/snapshot, incorrect proposed target or budget change. It emits a320pair/two-full-batch packet and source/catalog/packet-bound scope. Every role must actually read all320pairs. The initial V8 proof and exact role identities outside these batches remain historical and must be preserved.

Future finalizer policy is only a constraint document; it makes no runtime carry claim or gate pass. Wallet caller/context, current bundle/embedded catalog,24fontmeasurement supplement and actual targeted captures still need real evidence. All96providerreservations/$5.47148remain unchanged; no paid requests permitted by this preparation.
