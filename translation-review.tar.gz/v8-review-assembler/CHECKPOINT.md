V8 scaffold only: no executable assembler or tests have been completed.

Parent V7 record/proof snapshots are exact read-only copies. shared_readers.reference.py is an unmodified reference copied from the tested V7 assembler, not a runnable V8 assembler; it still contains old paths/constants. Adapt only against actual supplied role report schemas and hashes. Root is integrating semantic/editor candidates; do not fix a candidate packet before final targets.

Required work: derive actual final scope98/full batch and6310exact parent carry; validate actual3roleIDs/read/approval/source-target/report/packet hashes; preserve108English exceptions only if still exact; independently prove no other pair changes. Build a generic native18 compatibility validator for MR and TA from V7 BN19 code with explicit locale allowlist and actual final reports. Platform3 is separate proof, not game/online keys. Mock stale/missing/rejected/coverage/identity/hash failures before writing any actual record. Runtime/platform gates and original technical pending findings remain unchanged.

Machine history now96/$5.47148 in mainV8 and companion; initial V8 historical machine-validation remains truthful95-at-phase-completion. Companion machine-validation binds the later extension. Do not rerun paid launchers.
