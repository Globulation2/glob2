Actual V8 validation complete.

BG:6408pairs/19224rolebindings;98full-batchfreshpairs per actual role and6310exactparentpairs outside the batch. All6378oldV7pairs remain exact,30newsourcepairs only,108English exceptions exactly carried. Original V7 record/proof/independentproof and catalogs/source are preserved under parent-v7. MR18 and TA18 compatibility each have54actualrolebindings plus independent written validation. Platform3 has9bindings in a separate synthetic-source proof plus independent parsed-resource/application verification; synthetic IDs are absent from the main source.

All9runtime/platform gates remain pending. Original technical findings are unchanged. No runtime evidence is relabeled. Main and companion candidates match actual registered bytes; root application references remain separate.

Commands (repo root):

    python3 artifacts/bulgarian/v8-review-assembler/assemble.py --semantic artifacts/bulgarian/linguistics/v8-semantic-bg98-final.json --editor artifacts/bulgarian/linguistics/v8-editor-bg98-final.json --adversarial artifacts/bulgarian/linguistics/v8-adversarial-bg98-final.json
    python3 artifacts/bulgarian/v8-review-assembler/validate_written.py
    python3 artifacts/bulgarian/v8-review-assembler/validate_compat_written.py --locale mr
    python3 artifacts/bulgarian/v8-review-assembler/validate_compat_written.py --locale ta
    python3 artifacts/bulgarian/v8-review-assembler/validate_platform3.py
    python3 artifacts/bulgarian/v8-review-assembler/validate_platform_written.py
    python3 -m unittest discover -s artifacts/bulgarian/v8-review-assembler -p test_assemble.py

Default assembler is read-only; --write already executed once against the actual role reports. Do not use --write after runtime gate finalization. Current separate validation-inputs.json binds outputs, implementation/report identities and actual30+22+13passingtests. Publisher allowlists now cover kit-v8, platform-companion-v8 exact raw providers, v8 assembler and master-mr-ta-integration; native-v9 evidence is auto-discovered and captures still need explicit selection. No PREP inventory or publication executed.
