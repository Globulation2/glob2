"""Independent written-record binding check; no linguistic or runtime approval."""
from pathlib import Path
import hashlib,json,importlib.util
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';K=B/'kit-v8';P=Path(__file__).resolve().parent/'parent-v7';read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
s=importlib.util.spec_from_file_location('program',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
actual_roles=read(Path(__file__).resolve().parent/'actual-role-roster.json');assert all(isinstance(v,str)for v in actual_roles.values())
m=read(K/'manifest.json');record=read(K/'reviews/bg.json');proof=read(K/'review-proof-v8-validation.json');scope=read(K/'final-review-scope.json');parent=read(P/'reviews/bg.json');pm=read(P/'manifest.json');source={s:read(K/'source'/f'{s}.json')for s in ('native','online')};psource={s:read(P/'source'/f'{s}.json')for s in source};target={'native':p.CHECKER.read_table(K/'drafts/bg/texts.bg.txt')[0],'online':read(K/'drafts/bg/bg.json')};ptarget={'native':p.CHECKER.read_table(P/'drafts/bg/texts.bg.txt')[0],'online':read(P/'drafts/bg/bg.json')}
assert record['source_sha256']==proof['source_sha256']==m['source_sha256'];assert record['catalog_sha256']==proof['catalog_sha256']=={s:sha(path)for s,path in p.catalog_paths(K,'bg').items()};assert record['review_proof']['sha256']==sha(K/'review-proof-v8-validation.json');assert record['source_expansion_v8']==proof
assert sha(P/'reviews/bg.json')==proof['parent_record']['sha256']and sha(P/'manifest.json')==proof['parent_manifest']['sha256'];assert sha(K/'final-review-scope.json')==proof['scope']['sha256']
allids={s+':'+k for s in source for k in source[s]};fresh={i for batch in m['batches']if batch['id']in scope['batches']for i in batch['keys']};unchanged=allids-fresh;assert len(allids)==6408 and len(fresh)==98 and len(unchanged)==6310;assert set(proof['unchanged_key_ids'])==unchanged
assert len(proof['source_added_ids'])==30
for surface in psource:
 for key,value in psource[surface].items():assert source[surface][key]==value
for i in unchanged:
 s,k=i.split(':',1);assert source[s][k]==psource[s][k]and target[s][k]==ptarget[s][k]
rows={b['id']:b for b in record['batches']};oldrows={b['id']:b for b in parent['batches']};bindings=0
for batch in m['batches']:
 row=rows[batch['id']];assert row['source_sha256']==m['source_sha256'];assert row['target_sha256']==h({i:target[i.split(':',1)[0]][i.split(':',1)[1]]for i in batch['keys']})
 for field in ('reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys'):assert row[field]==batch['keys']
 if batch['id']in scope['batches']:assert [row[k]for k in ('author','reviewer','editor','adversarial_reviewer')]==['/root',*[actual_roles[k]for k in ('semantic','editor','adversarial')]]
 else:
  for field in ('author','reviewer','editor','adversarial_reviewer'):assert row[field]==oldrows[batch['id']][field]
 bindings+=3*len(batch['keys'])
for role in proof['role_evidence']:
 path=B/role['path'];assert sha(path)==role['sha256'];d=read(path);identity=d.get('reviewer_identity',{}).get('agent',d.get('reviewer',{}).get('agent_path'));assert identity==role['actual_agent'];assert d['source_sha256']==m['source_sha256']and d['catalog_sha256']==record['catalog_sha256'];assert len(d['entries'])==98
 assert {e['id']for e in d['entries']}==fresh
 if role.get('original_report_binding'):
  original=role['original_report_binding'];assert sha(B/original['path'])==original['sha256'];raw=read(B/original['path']);raw_rows={e['id']:e for e in raw['entries']};assert set(raw_rows)==fresh
  for e in d['entries']:assert all(e.get(k)==v for k,v in raw_rows[e['id']].items())
 packet_name=d.get('packet_path',d.get('packet'));packet_path=R/packet_name if packet_name.startswith('artifacts/')else B/packet_name;assert sha(packet_path)==d['packet_sha256'];assert d.get('status',d.get('decision'))in ('approved','accepted_all_98')
 for e in d['entries']:
  s,k=e['id'].split(':',1);assert e['source']==source[s][k]and e['target']==target[s][k]
  valuehash=lambda v:hashlib.sha256((v if isinstance(v,str)else json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))).encode()).hexdigest()
  canonicalhash=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
  assert e['source_sha256']in(valuehash(e['source']),canonicalhash(e['source']))and e['target_sha256']in(valuehash(e['target']),canonicalhash(e['target']))
  assert any(e.get(f)is True for f in ('actual_fresh_complete_final_pair_read','final_fresh_read','actual_final_reading','actual_reading','fresh_reading','actual_fresh_read','actual_fresh_complete_source_target_read'))or(d.get('coverage',{}).get('fresh_read')is True and d['coverage']['entries']==98)
  if 'identity_sha256'in e:assert e['identity_sha256']in(canonicalhash(['bg',e['id'],e['source'],e['target']]),canonicalhash([e['id'],e['source'],e['target']]))
  if 'pair_sha256'in e:assert e['pair_sha256']==canonicalhash([e['id'],e['source'],e['target']])
  if 'variants'in e:
   pairs={'literal':(e['source'],e['target'])}if isinstance(e['source'],str)else{k:(e['source'][k],e['target'][k])for k in e['source']}
   assert set(e['variants'])==set(pairs)
   for name,(sv,tv)in pairs.items():assert e['variants'][name]['source_sha256_utf8']==hashlib.sha256(sv.encode()).hexdigest()and e['variants'][name]['target_sha256_utf8']==hashlib.sha256(tv.encode()).hexdigest()and e['variants'][name]['decision']=='accepted'
assert proof['context_reuse']==[];assert parent['source_expansion_v7']['context_reuse']==[];assert record['source_expansion_v7']==parent['source_expansion_v7']
assert record['technical_findings']==parent['technical_findings'];assert len(record['accepted_english'])==108;assert {e['key']:e for e in record['accepted_english']}=={e['key']:e for e in parent['accepted_english']};assert all(not g['passed']and not g['evidence']for g in record['gates'].values());issues=p.audit_locale(K,m,record,'bg');assert set(issues)=={g+' is pending or lacks evidence'for g in p.GATES}
result={'result':'passed','scope':'Independent written-file binding verification only; no linguistic or rendering approval generated','total_keys':6408,'role_bindings':bindings,'fresh_complete_batches':len(scope['batches']),'actual_final_pairs_per_role':98,'exact_parent_pairs':6310,'accepted_english_exact_parent':108,'fresh_context_approvals':0,'parent_context_approvals_preserved':'Exact V7 lineage, including original V5 music-context records','all9_gates_pending':True,'non_gate_core_audit_errors':[],'proof_sha256':sha(K/'review-proof-v8-validation.json'),'record_sha256':sha(K/'reviews/bg.json'),'catalog_sha256':record['catalog_sha256'],'source_sha256':m['source_sha256'],'candidate_live_registration_not_inferred':True}
(B/'review-proof-v8-independent-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
