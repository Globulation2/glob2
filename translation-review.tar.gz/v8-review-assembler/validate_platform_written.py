"""Independent parsed-resource/literal/report binding verification, no approval created."""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';K=B/'platform-companion-v8';read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rawhash=lambda v:hashlib.sha256(v.encode()).hexdigest();ch=lambda v:rawhash(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')))
proof=read(K/'platform3-review-validation.json');packetpath=B/proof['packet']['path'];assert sha(packetpath)==proof['packet']['sha256'];packet=read(packetpath);expected={e['id']:e for e in packet['entries']};assert len(expected)==3 and proof['entries']==3 and proof['role_bindings']==9;assert proof['source_sha256']==packet['source_sha256']!=proof['main_source_sha256'];assert proof['main_source_sha256']==read(B/'kit-v8/manifest.json')['source_sha256'];assert packet['companion_source_only']and packet['no_game_online_keys_added'];roles={'semantic':'/root/v7_meaning','editor':'/root/v7_editor','adversarial':'/root/v7_adversary'}
for ev in proof['actual_role_evidence']:
 path=B/ev['path'];assert sha(path)==ev['sha256'];d=read(path);assert d['reviewer_identity']['agent']==roles[ev['role']]==ev['actual_agent'];assert d['status']=='approved'and d['final_approval']is True;assert d['source_sha256']==proof['source_sha256']and d['catalog_sha256']==proof['catalog_sha256'];assert d['packet_sha256']==sha(packetpath);assert len(d['entries'])==3 and{e['id']for e in d['entries']}==set(expected)
 for e in d['entries']:
  q=expected[e['id']];assert e['source']==q['source']and e['target']==q['target'];assert e.get('status',e.get('verdict'))in('approved','approve')and all(e[k]in('approved','approve','accept','accepted')for k in('status','verdict','approval')if e.get(k)is not None);assert any(e.get(k)is True for k in('actual_fresh_complete_final_pair_read','actual_fresh_complete_source_target_read','final_fresh_read'));assert e['source_sha256']in(rawhash(e['source']),ch(e['source']))and e['target_sha256']in(rawhash(e['target']),ch(e['target']))
  if 'identity_sha256'in e:assert e['identity_sha256']in(ch(['bg',e['id'],e['source'],e['target']]),ch([e['id'],e['source'],e['target']]))
for row in proof['resources']:
 q=expected[row['id']];source=R/row['source_path'];target=R/row['target_path'];assert sha(source)==row['source_sha256']and sha(target)==row['target_sha256'];field=q['resource_field']
 def value(path):
  if path.suffix=='.xml':
   found=ET.fromstring(path.read_bytes()).findall("string[@name='"+field+"']");assert len(found)==1;return found[0].text
  found=re.findall(r'"'+re.escape(field)+r'"\s*=\s*("(?:[^"\\]|\\.)*")\s*;',path.read_text());assert len(found)==1;return json.loads(found[0])
 assert value(source)==q['source']==row['source']and value(target)==q['target']==row['target'];assert q['source'].count('Globulation 2')==q['target'].count('Globulation 2');assert q['key']not in read(B/'kit-v8/source/online.json')
closurepath=B/proof['packaging_closure']['path'];assert sha(closurepath)==proof['packaging_closure']['sha256'];closure=read(closurepath)
for name,c in closure['changes'].items():
 before=R/c['original_path'];current=R/name;assert sha(before)==c['original_sha256']and sha(current)==c['current_sha256'];assert before.read_bytes().count(c['old_literal'].encode())==1;assert before.read_bytes().replace(c['old_literal'].encode(),c['new_literal'].encode())==current.read_bytes()
assert sha(R/closure['contracts']['path'])==closure['contracts']['sha256'];assert sha(B/proof['registered_application']['path'])==proof['registered_application']['sha256']
result={'result':'passed','source_sha256':proof['source_sha256'],'main_source_sha256':proof['main_source_sha256'],'entries':3,'role_bindings':9,'proof_sha256':sha(K/'platform3-review-validation.json'),'exact_current_resource_bytes_and_parsed_values':True,'exact_only_bg_packaging_delta':True,'all_runtime_platform_gates':'pending','limits':'Mechanical independent binding check only; no linguistic or device execution approval created'};(K/'platform3-independent-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
