from pathlib import Path
from decimal import Decimal
from collections import Counter
import json,hashlib,importlib.util,os
R=Path.cwd();B=R/'artifacts/bulgarian';new=B/'kit-v3-native-compat-v2';old=B/'kit-v3-native-compat';tool=B/'legacy-native-drafting-v2/stage/tools/localization/translation_program.py';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();spec=importlib.util.spec_from_file_location('m',tool);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
pre=json.loads((new/'compat-v2-preflight.json').read_text());manifest=json.loads((new/'manifest.json').read_text());delta=[i[7:]for i in json.loads((new/'delta-only-keys.json').read_text())];native=json.loads((new/'source/native.json').read_text());rows=[]
for locale in manifest['locales']:
 p=m.catalog_paths(new,locale)['native'];table,errors=m.CHECKER.read_table(p);assert not errors
 for key in delta:
  value=table[key];assert value.strip() and value!=native[key],(locale,key,'blank or English copy');assert m.CHECKER.placeholders(value)==m.CHECKER.placeholders(native[key]),(locale,key,'placeholder mismatch');assert not m.CHECKER.invalid_percent(value);assert not any(c in value for c in ['\x00','\ufffd','\n','\r']);assert not __import__('re').search(r'ZXQ[A-F0-9]{12}Q\d+QXZ',value)
 if locale=='pt-BR':baseline,e=m.CHECKER.read_table(R/'data/texts.br.txt')
 elif locale=='bg':baseline,e=m.CHECKER.read_table(m.catalog_paths(old,locale)['native']);baseline={k:v for k,v in baseline.items()if k not in delta}
 else:baseline,e=m.CHECKER.read_table(R/'data'/('texts.'+m.game_code(locale)+'.txt'))
 assert not e and len(baseline)==3393 and all(table[k]==v for k,v in baseline.items()),locale
 if locale!='pt-BR':
  for rel,digest in pre['carried_drafts_sha256'][locale].items():assert sha(new/'drafts'/locale/rel)==digest
 rows.append({'locale':locale,'native_code':m.game_code(locale),'native_sha256':sha(p),'old3393_equal':True,'strict18_nonblank_not_English_exact_placeholders':True})
ledger=json.loads((new/'machine/spend-ledger.json').read_text());original=json.loads((old/'machine/spend-ledger.json').read_text());assert ledger['reservations'][:-1]==original['reservations'];assert len(ledger['reservations'])==83
last=ledger['reservations'][-1];assert last['locale']=='pt-BR' and last['codepoints']==1196 and Decimal(last['reserved_usd'])==Decimal('0.02392') and last['state']=='response-received';total=sum((Decimal(x['reserved_usd'])for x in ledger['reservations']),Decimal());assert total==Decimal('5.28264')
request=next((new/'machine/pt-BR/raw').glob('*.request.json'));payload=json.loads(request.read_text())['payload'];assert payload['targetLanguageCode']=='pt-BR' and payload['sourceLanguageCode']=='en' and payload['model']=='projects/bradley-personal-20261027/locations/global/models/general/nmt';assert sum(map(len,payload['contents']))==1196
br,e=m.CHECKER.read_table(new/'drafts/pt-BR/texts.br.txt');assert br['[language]']=='Português do Brasil' and br['[language-code]']=='br';assert 'br' not in manifest['locales'] and not (new/'drafts/br').exists()
for rel,digest in pre['original_kit_file_sha256'].items():assert sha(old/rel)==digest,rel
assert sha(B/'legacy-native-drafting/stage/tools/localization/translation_program.py')=='7c0036ca79969accc0224004089b7e76ed1c7f7832949bde9f25448d660b1a7d'
result={'kit':str(new.relative_to(R)),'source_sha256':manifest['source_sha256'],'module_sha256':sha(tool),'locales':rows,'strict_delta_checks':648,'carried_good_drafts_exact':35,'metadata':{'pt-BR':{'language':br['[language]'],'language_code':br['[language-code]'],'API_target':payload['targetLanguageCode']}},'spend':{'prior_reservations':82,'new_paid_requests':1,'new_codepoints':1196,'new_reserved_usd':'0.02392','cumulative_reservations':83,'cumulative_reserved_usd':str(total),'ledger_sha256':sha(new/'machine/spend-ledger.json'),'prefix_exact_to_original':True},'original_kit_and_v1_module_unchanged':True,'wrong_br_draft':'rejected/wrong-br-breton-mapping; excluded from active scopes/drafts, historical provider bytes retained','linguistic_approval':'Pending independent semantic/editorial/adversarial review for replacement pt-BR18; structural checks do not approve language','active_pointer_switched_only_after_validation':True}
(new/'compat-v2-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');pointer=B/'active-machine-kit.txt';temporary=pointer.with_suffix('.tmp');temporary.write_text(str(new.relative_to(R))+'\n');os.replace(temporary,pointer)
print(json.dumps({'kit':str(new.relative_to(R)),'pt_BR_native_sha256':sha(new/'drafts/pt-BR/texts.br.txt'),'new_requests':1,'cumulative_reserved_usd':str(total),'strict18_checks':648,'active_pointer':pointer.read_text().strip()},indent=2))
