from pathlib import Path
p=Path('tools/TranslationPreviewHarness.cpp');s=p.read_text()
s=s.replace('#include "Race.h"\n','#include "Race.h"\n#include "OnlineServices.h"\n#include "PlatformClient.h"\n')
s=s.replace('''        this->beginExecution(globalContainer->gfx);
        this->paintFrame(SDL_GetTicks());''','''        this->beginExecution(globalContainer->gfx);
        redraw();
    }
    bool hasControl(const std::string &key) {
        return this->GAGGUI::ui::UIScreen::host().find(key) != nullptr;
    }
    void redraw() {
        this->paintFrame(SDL_GetTicks());''',1)
needle='''    globals.settings.language = pilotLocale(pilot);
    Json controls;'''
replacement='''    globals.settings.language = pilotLocale(pilot);
    const bool onlineSettings = screen == "settings-ais" || screen == "settings-online";
    if (onlineSettings) require(NET_Init(), "Initialize SDL_net for offline Settings captures");
    struct NetworkScope { bool active; ~NetworkScope() { if (active) NET_Quit(); } } network{onlineSettings};
    // Real client and real library controls, with no external account/provider
    // requests: loopback port1 is deliberately unavailable in this capture.
    Online::ServicesOwner services;
    if (onlineSettings) services.get().client.start("http://127.0.0.1:1");
    Json controls, actions = Json::array();'''
assert needle in s;s=s.replace(needle,replacement,1)
needle='''        } else if (screen == "settings" || screen == "settings-audio") {
            Preview<SettingsScreen> preview;
            if (screen == "settings-audio") preview.selectCategory(SettingsScreen::Category::Audio);
            preview.render(); controls = preview.bounds();'''
replacement='''        } else if (screen == "settings" || screen == "settings-audio" || screen == "settings-ais" ||
                   screen == "settings-online" || screen == "settings-player" || screen == "settings-controls") {
            require(screen != "settings-controls" || !GAGCore::phonePresentationRequested(),
                "Keyboard Controls category is unavailable in the phone presentation");
            Preview<SettingsScreen> preview;
            if (screen == "settings-audio") preview.selectCategory(SettingsScreen::Category::Audio);
            else if (screen == "settings-ais") preview.selectCategory(SettingsScreen::Category::CustomAIs);
            else if (screen == "settings-online") preview.selectCategory(SettingsScreen::Category::Online);
            else if (screen == "settings-player") preview.selectCategory(SettingsScreen::Category::Player);
            else if (screen == "settings-controls") preview.selectCategory(SettingsScreen::Category::Controls);
            preview.render();
            if (screen == "settings-ais") {
                require(preview.hasControl("ai.browse"), "Community AI Library is available in this build");
                preview.activateSetting("ai.browse");
                preview.redraw();
                actions.push_back("Opened AI Library through its production button; client uses unavailable loopback origin.");
                if (preview.hasControl("ais/gotit")) {
                    preview.activateSetting("ais/gotit");
                    preview.redraw();
                    actions.push_back("Dismissed the local AI Library introduction through its production button.");
                }
                for (const auto *tag : {"Balanced", "Rush", "Defensive", "Economy", "Expansion", "Experimental", "Beginner-friendly"})
                    require(preview.hasControl(std::string("ais/tag/") + tag), "Production AI tag control: " + std::string(tag));
            }
            controls = preview.bounds();'''
assert needle in s;s=s.replace(needle,replacement,1)
s=s.replace('''        {"controls", controls}, {"limits",''','''        {"controls", controls}, {"screen_actions", actions},
        {"online_environment", onlineSettings ? "Unavailable loopback origin; no remote account/provider action or online-flow verification." : "Not exercised."}, {"limits",''',1)
s=s.replace('''             "src/map/editor/PhoneEditor.cpp",
''','''             "src/map/editor/PhoneEditor.cpp", "src/ui/settings/SettingsScreenGeneral.cpp",
             "src/ui/settings/SettingsScreenCustomAIs.cpp", "src/ui/settings/SettingsScreenOnline.cpp",
             "src/ui/settings/SettingsScreenKeyboard.cpp",
''',1)
p.write_text(s)
p=Path('docs/development/ui-framework.md');s=p.read_text();s=s.replace('''(`main`, `settings`, `settings-audio`, `lobby`, `lobby-players` or `new-map`); `game` adds''','''(`main`, `settings`, `settings-audio`, `settings-ais`, `settings-online`,
`settings-player`, desktop-only `settings-controls`, `lobby`, `lobby-players` or
`new-map`). The AI library capture uses its real buttons and an unavailable
loopback server, so it verifies local labels without remote account or provider
actions. `game` adds''');p.write_text(s)
print('Settings dispatch extension applied; compile and run before accepting captures.')
