from pathlib import Path
from decimal import Decimal
import hashlib,json,shutil,subprocess,importlib.util
R=Path.cwd();B=R/'artifacts/bulgarian';OUT=B/'terrain-supplement-v5';SHADOW=B/'terrain-supplement-tool-shadow';TREE='b9267f871a7cdc29e4eeee072801fdddd2a511d4';OLD=B/'kit-v4';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not OUT.exists()and not SHADOW.exists()
shutil.copytree(B/'v4-tool-shadow',SHADOW,ignore=shutil.ignore_patterns('__pycache__'));tool=SHADOW/'tools/localization/translation_program.py';assert sha(tool)==json.loads((OLD/'preflight.json').read_text())['tool_sha256']
spec=importlib.util.spec_from_file_location('terrain_tool',tool);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
source_bytes={}
for name in m.SOURCE_PATHS:
 data=subprocess.check_output(['git','show',TREE+':'+name]);path=SHADOW/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);source_bytes[name]=hashlib.sha256(data).hexdigest()
m.prepare(OUT,root=SHADOW,locales=('bg',));manifest=json.loads((OUT/'manifest.json').read_text());manifest.update(revision=None,staged_merge_tree=TREE,source_provenance='Exact five SOURCE_PATHS bytes read from git merge-tree tree; not a committed source revision.',preparation_worktree_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip());m.write_json(OUT/'manifest.json',manifest);assert manifest['native_keys']==3429 and manifest['online_keys']==2843 and manifest['source_files']==source_bytes
source=json.loads((OUT/'source/native.json').read_text());prior_source=json.loads((OLD/'source/native.json').read_text());delta=[k for k in source if k not in prior_source];assert set(delta)=={'[dry_grass]','[dune_sand]','[lush_grass]','[pale_sand]'}and all(source[k]==v for k,v in prior_source.items())
assert json.loads((OUT/'source/online.json').read_text())==json.loads((OLD/'source/online.json').read_text())
m.draft(OUT,'bg');native,errors=m.CHECKER.read_table(OLD/'drafts/bg/texts.bg.txt');assert not errors and len(native)==3425 and sha(OLD/'drafts/bg/texts.bg.txt')=='dfc3638b84e9d90272a093c7fe0f6e9112b3af0c8a6b3cca7d45ff26c69ca10c'
order=(OUT/'source/native-keys.txt').read_text().splitlines();(OUT/'drafts/bg/texts.bg.txt').write_text(''.join(k+'\n'+native.get(k,'')+'\n'for k in order));shutil.copy2(OLD/'drafts/bg/bg.json',OUT/'drafts/bg/bg.json');assert sha(OUT/'drafts/bg/bg.json')=='69de8f4cf769924db105fe166cf25a352967e5ca3263951dd1753c3d8f263813'
shutil.copytree(OLD/'machine',OUT/'machine');shutil.copytree(OLD/'rejected',OUT/'rejected');(OUT/'provider-history').mkdir();shutil.copy2(B/'kit/machine/bg/provider-drafts.json',OUT/'provider-history/original-kit-bg-provider-drafts.json');shutil.copy2(OLD/'machine/bg/provider-drafts.json',OUT/'provider-history/bg-provider-drafts-before-terrain.json')
# The older46 BG bodies/caches live in the original kit, not kit-v4. Merge them
# without changing the cumulative ledger or current per-locale draft index.
merged_old=[]
for folder in ('raw','cache'):
 for p in(B/'kit/machine/bg'/folder).iterdir():
  if not p.is_file():continue
  dest=OUT/'machine/bg'/folder/p.name;dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists():assert sha(dest)==sha(p)
  else:shutil.copy2(p,dest)
  merged_old.append(str(dest.relative_to(OUT)))
ledger=json.loads((OUT/'machine/spend-ledger.json').read_text());spent=sum((Decimal(x['reserved_usd'])for x in ledger['reservations']),Decimal());assert len(ledger['reservations'])==84 and spent==Decimal('5.29170')and sha(OUT/'machine/spend-ledger.json')==sha(OLD/'machine/spend-ledger.json')
raw=list((OUT/'machine').rglob('*.response.bin'));assert len(raw)==84
seen=set()
for p in raw:
 request,n=p.name.removesuffix('.response.bin').split('-');n=int(n);assert ledger['reservations'][n-1]['request_sha256']==request;seen.add(n)
assert seen==set(range(1,85))
ids=['native:'+k for k in delta];(OUT/'delta-only-keys.json').write_text(json.dumps(ids,indent=2)+'\n');protected={k:m.protect_text(source[k])for k in delta};codepoints=sum(len(v[0])for v in protected.values());assert codepoints==37
# The old batch memberships are not blindly approved after source insertion.
old_manifest=json.loads((OLD/'manifest.json').read_text());before_batches={b['id']:b for b in old_manifest['batches']};changed_batches=[]
for batch in manifest['batches']:
 if batch['id']not in before_batches or batch['keys']!=before_batches[batch['id']]['keys']:changed_batches.append({'id':batch['id'],'entries':len(batch['keys']),'old_entries':len(before_batches.get(batch['id'],{}).get('keys',[]))})
nb_native_raw=subprocess.check_output(['git','show',TREE+':data/texts.nb.txt']);nb_file=OUT/'provider-history/master-nb-native-baseline.txt';nb_file.write_bytes(nb_native_raw);nb,errors=m.CHECKER.read_table(nb_file);assert not errors
nb_online=json.loads(subprocess.check_output(['git','show',TREE+':platform/packages/i18n/locales/nb.json']));online=json.loads((OUT/'source/online.json').read_text());native_ids=json.loads((B/'legacy-native-drafting-v2/new-native-entry-ids.json').read_text());nb_native_keys=[x[7:]for x in native_ids];nb_online_keys=[k for k in online if k not in nb_online];assert len(nb_native_keys)==18 and len(nb_online_keys)==7 and all(k not in nb for k in nb_native_keys)
nb_entries=[{'id':'native:'+k,'surface':'native','key':k,'source':source[k],'target':None,'draft_method':'Agent draft and independent review required; no NMT target guessed.'}for k in nb_native_keys]+[{'id':'online:'+k,'surface':'online','key':k,'source':online[k],'target':None,'draft_method':'Agent draft and independent review required; no NMT target guessed.'}for k in nb_online_keys]
nb_baseline_missing=[k for k in source if k not in nb and k not in nb_native_keys];assert len(nb_baseline_missing)==16
(OUT/'nb25-agent-review-input.json').write_text(json.dumps({'source_sha256':manifest['source_sha256'],'staged_merge_tree':TREE,'locale':'nb','native_metadata':{'language':nb['[language]'],'code':nb['[language-code]']},'scope':25,'entries':nb_entries,'baseline_native_sha256':hashlib.sha256(nb_native_raw).hexdigest(),'baseline_missing16_outside_scope':nb_baseline_missing,'existing_marked_values_outside_scope':[k for k,v in nb.items()if v.startswith('*')],'old_metadata_or_UGC_edits':False,'NMT_mapping':None,'approval':None},ensure_ascii=False,indent=2)+'\n')
contexts=[]
for k in delta:
 found=subprocess.run(['git','grep','-n','-F',k[1:-1],TREE,'--','src','browser','platform'],capture_output=True,text=True).stdout.splitlines()
 contexts.append({'id':'native:'+k,'source':source[k],'target':None,'source_contexts':found[:40],'protected_tokens':list(protected[k][1].values())})
(OUT/'bg4-context-input.json').write_text(json.dumps({'source_sha256':manifest['source_sha256'],'staged_merge_tree':TREE,'entries':contexts,'existing_reviewed_terrain_glossary':[{'key':k,'source':prior_source[k],'target':v}for k,v in native.items()if k in prior_source and any(t in k.lower()for t in ['grass','sand','terrain'])],'affected_batches_require_actual_original_three_role_reading':changed_batches,'approval':None},ensure_ascii=False,indent=2)+'\n')
preflight={'tool':str(tool.relative_to(R)),'tool_sha256':sha(tool),'source_sha256':manifest['source_sha256'],'source_files':source_bytes,'revision':None,'staged_merge_tree':TREE,'native_keys':3429,'online_keys':2843,'mapping':{'locale':'bg','native':'bg','NMT_target':m.NMT_TARGETS['bg']},'old_native_values_exact':3425,'online_sha256':sha(OUT/'drafts/bg/bg.json'),'prior_reservations':84,'prior_reserved_usd':str(spent),'copied_ledger_sha256':sha(OUT/'machine/spend-ledger.json'),'expected_new_codepoints':codepoints,'expected_new_usd':'0.00074','expected_total_usd':'5.29244','ids':ids,'complete_prior_raw_response_bodies':84,'original46_body_caches_merged':merged_old,'machine_file_sha256':{str(p.relative_to(OUT/'machine')):sha(p)for p in(OUT/'machine').rglob('*')if p.is_file()},'affected_batches_require_full_review':changed_batches,'nb_agent_entries':25,'paid_calls_in_preparation':0,'active_pointer_unchanged':(B/'active-machine-kit.txt').read_text()}
(OUT/'preflight.json').write_text(json.dumps(preflight,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in preflight.items()if k not in('machine_file_sha256','original46_body_caches_merged')},ensure_ascii=False,indent=2))
