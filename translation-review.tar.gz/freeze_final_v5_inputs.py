from pathlib import Path
import json,hashlib,subprocess,importlib.util
R=Path(__file__).resolve().parents[2];B=R/'artifacts/bulgarian';K=B/'kit-v4'
s=importlib.util.spec_from_file_location('p',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip(),'Freeze only a clean committed candidate'
rev=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
n,errors=p.CHECKER.read_table(R/'data/texts.bg.txt');assert not errors and len(n)==3425
online=json.loads((R/'platform/packages/i18n/locales/bg.json').read_text());oldnative=p.CHECKER.read_table(B/'kit-v2/drafts/bg/texts.bg.txt')[0]
assert (R/'data/texts.bg.txt').read_bytes()==(K/'drafts/bg/texts.bg.txt').read_bytes();assert (R/'platform/packages/i18n/locales/bg.json').read_bytes()==(K/'drafts/bg/bg.json').read_bytes()
delta={k:v for k,v in n.items()if oldnative.get(k)!=v};assert len(delta)==52
base_metadata=json.loads((B/'kit-v2/render-input/bg/metadata.json').read_text());m=json.loads((K/'manifest.json').read_text())
code={str(f.relative_to(R)):sha(f) for directory in ['src/ui','src/hive','src/scripting/map','libgag/src','libgag/include']for f in (R/directory).rglob('*')if f.is_file()and f.suffix in {'.cpp','.h'}};code['tools/TranslationPreviewHarness.cpp']=sha(R/'tools/TranslationPreviewHarness.cpp')
meta={'locale':'bg','language':'Български','source_revision':rev,'candidate_revision':rev,'compiled_runtime_revision':rev,'source_sha256':m['source_sha256'],'original_catalog_sha256':{'native':sha(R/'data/texts.bg.txt'),'online':sha(R/'platform/packages/i18n/locales/bg.json')},'review_proof_sha256':sha(B/'review-proof-v4-visual-validation.json'),'rendering_code_sha256':code,'certification':'Agent-reviewed; not native-human-certified','runtime_identity_note':'Final post-visual source/catalog inputs. Actual executable hash and compiled provenance are embedded per capture; no earlier capture is relabeled.'}
for out,native_values,online_values in [(K,n,online),(B/'v5-font-supplement-input',delta,{})]:
 pilot=out/'render-input/bg';pilot.mkdir(parents=True,exist_ok=True)
 p.write_json(out/'manifest.json',m) if out!=K else None
 p.write_json(pilot/'native.json',native_values);p.write_json(pilot/'online.json',online_values);p.write_json(pilot/'metadata.json',dict(meta,scope='Complete final catalog'if out==K else 'Native values added or changed since v2; exact unchanged render values retain earlier producer evidence, with counts in v5-frozen-inputs.json.'))
p.write_json(B/'v5-frozen-inputs.json',{'revision':rev,'source_sha256':m['source_sha256'],'catalog_sha256':meta['original_catalog_sha256'],'delta_native_keys':list(delta),'unchanged_render_values':6295-len(delta),'delta_render_values':len(delta),'final_render_values':6295,'code_hashes':code})
print(rev,'full6295 anddelta'+str(len(delta))+' inputs frozen')
