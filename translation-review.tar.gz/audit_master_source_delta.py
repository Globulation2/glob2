import subprocess,json,hashlib,importlib.util
from pathlib import Path
base=Path(__file__).resolve().parent;a='82394c1563b8e324da54770d037d319b9f27c072';b=subprocess.check_output(['git','rev-parse','e9275c2ae1'],text=True).strip()
def read(rev):
 raw=subprocess.check_output(['git','show',rev+':data/texts.en.txt']); lines=raw.decode().splitlines();return raw,{lines[i]:lines[i+1] for i in range(0,len(lines)-1,2)}
ra,old=read(a);rb,new=read(b)
spec=importlib.util.spec_from_file_location('draft',base.parents[1]/'tools/localization/translation_program.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
entries=[]
for key,value in new.items():
 if key not in old or old[key]!=value:
  protected,tokens=m.protect_text(value);hits=subprocess.run(['git','grep','-n','-F',key,b,'--','src'],text=True,capture_output=True).stdout.splitlines()
  entries.append(dict(key=key,english=value,prior=old.get(key),tokens=list(tokens.values()),source_codepoints=len(value),protected_codepoints=len(protected),contexts=hits,context_note='No direct exact-key consumer found; preserve source key nonetheless.' if not hits else ''))
r=dict(status='Read-only master delta; not merged/frozen; no paid call',base=a,master=b,base_source_sha256=hashlib.sha256(ra).hexdigest(),master_source_sha256=hashlib.sha256(rb).hexdigest(),added_or_changed_count=len(entries),entries=entries,branch_only_keys=[k for k in old if k not in new],source_codepoints=sum(e['source_codepoints'] for e in entries),protected_codepoints=sum(e['protected_codepoints'] for e in entries),rate_usd_per_million=20)
r['estimated_one_target_usd']=r['protected_codepoints']*20/1000000
(base/'master-source-delta.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(len(entries),r['protected_codepoints'],r['estimated_one_target_usd'])
