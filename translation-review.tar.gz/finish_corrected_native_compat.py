from pathlib import Path
from decimal import Decimal
import json,hashlib,importlib.util
R=Path.cwd();B=R/'artifacts/bulgarian';old=B/'kit-v3-native-compat';new=B/'kit-v3-native-compat-v2';tool=B/'legacy-native-drafting-v2/stage/tools/localization/translation_program.py';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(tool)=='47f5f68af625050ae0a178c22aba459d34bcc18f9f524ad915102228a12f1004'
spec=importlib.util.spec_from_file_location('v2',tool);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);manifest=json.loads((new/'manifest.json').read_text());prior=json.loads((old/'manifest.json').read_text());assert manifest['source_sha256']==prior['source_sha256'];locales=manifest['locales'];ids=json.loads((new/'delta-only-keys.json').read_text());delta=[i[7:]for i in ids];assert len(delta)==18
original_snapshot={str(p.relative_to(old)):sha(p)for p in old.rglob('*')if p.is_file()};carried={};identities={}
for locale in locales:
 paths=m.catalog_paths(new,locale);current,e=m.CHECKER.read_table(paths['native']);assert not e
 if locale=='bg':baseline,e=m.CHECKER.read_table(m.catalog_paths(old,locale)['native']);baseline={k:v for k,v in baseline.items()if k not in delta};identity_source='Original good kit BG draft including four reviewed changes; byte-identical carry'
 else:baseline,e=m.CHECKER.read_table(R/'data'/('texts.'+m.game_code(locale)+'.txt'));identity_source='Live registered native catalog, unchanged old3393'
 assert not e and len(baseline)==3393 and all(current[k]==v for k,v in baseline.items()),locale
 assert sum(not current[k].strip()for k in delta)==(18 if locale=='pt-BR'else 0),locale
 identities[locale]={'native_code':m.game_code(locale),'identity_source':identity_source,'old_keys_equal':3393,'delta_blank':sum(not current[k].strip()for k in delta),'native_sha256':sha(paths['native'])}
 if locale!='pt-BR':
  carried[locale]={str(p.relative_to(new/'drafts'/locale)):sha(p)for p in (new/'drafts'/locale).iterdir()if p.is_file()}
  for rel,digest in carried[locale].items():assert sha(old/'drafts'/locale/rel)==digest
for p in (old/'machine').rglob('*'):
 if p.is_file():assert sha(p)==sha(new/'machine'/p.relative_to(old/'machine'))
ledger=json.loads((new/'machine/spend-ledger.json').read_text());spent=sum((Decimal(r['reserved_usd'])for r in ledger['reservations']),Decimal());assert len(ledger['reservations'])==82 and spent==Decimal('5.25872')
native=json.loads((new/'source/native.json').read_text());protected=[m.protect_text(native[k],[])[0]for k in delta];assert sum(map(len,protected))==1196
record={'kit':str(new.relative_to(R)),'source_sha256':manifest['source_sha256'],'module':str(tool.relative_to(R)),'module_sha256':sha(tool),'scope':locales,'mapping':{'canonical':'pt-BR','native':m.game_code('pt-BR'),'target':m.NMT_TARGETS['pt-BR']},'prior_reservations':82,'prior_reserved_usd':str(spent),'copied_ledger_sha256':sha(new/'machine/spend-ledger.json'),'expected_new_codepoints':1196,'expected_extra_usd':'0.02392','expected_total_usd':'5.28264','carried_drafts_sha256':carried,'old_values_identity':identities,'original_kit_file_sha256':original_snapshot,'wrong_br_evidence':'rejected/wrong-br-breton-mapping','active_pointer_before':(B/'active-machine-kit.txt').read_text(),'preparation_paid_calls':0}
(new/'compat-v2-preflight.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');(new/'rejected/wrong-br-breton-mapping/rejection.json').write_text(json.dumps({'reason':'Native br is Brazilian Portuguese; all18 Breton drafts rejected by semantic review','active_locale':'pt-BR','no_wrong_delta_carry_forward':True,'original_draft_sha256':sha(old/'drafts/br/texts.br.txt'),'quarantined_draft_sha256':sha(new/'rejected/wrong-br-breton-mapping/drafts/texts.br.txt')},indent=2)+'\n');print('Preflight passed:35 good locale drafts exact,36×3393 old values exact to proper baseline,82 reservations/$5.25872,pt-BR18blank/1196 protected codepoints')
