"""Independent Telugu18 written-proof binding check; no new linguistic approval."""
from pathlib import Path
import hashlib,json,importlib.util,argparse
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';K=B/'telugu-compat-v8';H=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rawhash=lambda v:hashlib.sha256(v.encode()).hexdigest();canonical=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'));canonicalhash=lambda v:rawhash(canonical(v))
s=importlib.util.spec_from_file_location('p',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
parser=argparse.ArgumentParser();parser.add_argument('--locale',choices=('te',),required=True);locale=parser.parse_args().locale
proof=read(K/('compatibility-'+locale+'18-review-validation.json'));packet=read(K/'te18-after-editor-review-input.json');source={s:read(K/'source'/f'{s}.json')for s in ('native','online')};target={'native':p.CHECKER.read_table(K/('drafts/'+locale+'/texts.'+locale+'.txt'))[0],'online':read(K/('drafts/'+locale+'/'+locale+'.json'))};baseline={'native':p.CHECKER.read_table(K/('baselines/'+locale+'/texts.'+locale+'.txt'))[0],'online':read(K/('baselines/'+locale+'/'+locale+'.json'))};expected={e['id']:e for e in packet['entries']};assert len(expected)==18;assert proof['source_sha256']==read(K/'manifest.json')['source_sha256'];assert proof['catalog_sha256']=={s:sha(path)for s,path in p.catalog_paths(K,locale).items()};assert proof['packet']['sha256']==sha(K/'te18-after-editor-review-input.json')
for surface in baseline:
 assert all(target[surface][k]==v for k,v in baseline[surface].items())
assert set(expected)=={s+':'+k for s in source for k in source[s]if k not in baseline[s]}
role_ids={'semantic':'/root/v7_meaning','editor':'/root/v7_editor','adversarial':'/root/v7_adversary'}
for evidence in proof['actual_role_evidence']:
 path=B/evidence['path'];assert sha(path)==evidence['sha256'];d=read(path);actual=d.get('reviewer_identity',{}).get('agent',d.get('reviewer',{}).get('agent_path'));assert actual==role_ids[evidence['role']];assert d['source_sha256']==proof['source_sha256']and d['catalog_sha256']==proof['catalog_sha256'];assert d.get('status',d.get('decision'))in('approved','accepted_all_18');assert len(d['entries'])==18 and {e['id']for e in d['entries']}==set(expected)
 if evidence.get('original_report_binding'):
  original=evidence['original_report_binding'];assert sha(B/original['path'])==original['sha256'];raw=read(B/original['path']);raw_rows={e['id']:e for e in raw['entries']};assert set(raw_rows)==set(expected)
  for e in d['entries']:assert all(e.get(k)==v for k,v in raw_rows[e['id']].items())
 for e in d['entries']:
  surface,key=e['id'].split(':',1);assert e['locale']==locale;assert e['source']==source[surface][key]and e['target']==target[surface][key];assert e.get('batch_id',expected[e['id']]['batch_id'])==expected[e['id']]['batch_id'];assert e['source_sha256']in(rawhash(e['source']),canonicalhash(e['source']))and e['target_sha256']in(rawhash(e['target']),canonicalhash(e['target']));assert e.get('status',e.get('verdict',e.get('decision')))in('approved','approve','accepted','accept');assert any(e.get(k)is True for k in('actual_fresh_complete_final_pair_read','final_fresh_read','actual_fresh_complete_source_target_read'))or(d.get('coverage',{}).get('fresh_read')is True and d['coverage']['entries']==18)
  if 'identity_sha256'in e:assert e['identity_sha256']in(canonicalhash([locale,e['id'],e['source'],e['target']]),canonicalhash([e['id'],e['source'],e['target']]))
  if 'pair_sha256'in e:assert e['pair_sha256']==canonicalhash([e['id'],e['source'],e['target']])
assert proof['entries']==18 and proof['role_bindings']==54 and proof['new_english_matches']==[]
result={'result':'passed','scope':'Independent mechanical Telugu18 compatibility proof only; no whole-language or runtime approval generated','source_sha256':proof['source_sha256'],'catalog_sha256':proof['catalog_sha256'],'actual_pairs_per_role':18,'locale':locale,'role_bindings':54,'unchanged_native_pairs':len(baseline['native']),'unchanged_online_pairs':len(baseline['online']),'proof_sha256':sha(K/('compatibility-'+locale+'18-review-validation.json')),'runtime_platforms':'pending'}
(K/('compatibility-'+locale+'18-independent-validation.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
