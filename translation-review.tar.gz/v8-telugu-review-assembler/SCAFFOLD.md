Telugu18 actual approval assembler scaffold; no report or proof written.

Wait for root-integrated te18-after-editor-review-input.json and actual v8-{semantic,editor,adversarial}-te18-final.json. Exact source3d16,18nativepairs,3412oldnative+2978oldonline exact. Machine history97/$5.49540 includes exact96prefix.

Use validate_compat18.py --locale te --semantic <actualfile> --editor <actualfile> --adversarial <actualfile> (read-only default). --write only after actual3reports approve exactfinalcandidate. validate_compat_written.py --locale te independently checks writtenproof. assemble.py is copied shared-reader support; its main BG assemble entry point is not a Telugu assembler. Missing final packet/reports currently fail closed.

Need final meaningful mocks/adapters run against actual report schemas before writing; no linguistic judgment/approval may be manufactured. No full-locale/runtime pass is claimed.
