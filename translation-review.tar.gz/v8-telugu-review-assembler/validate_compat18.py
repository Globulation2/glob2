"""Bind eighteen supplied Telugu compatibility reviews; never approve the full locale."""
from pathlib import Path
from collections import Counter
import argparse,importlib.util,json,hashlib
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v6review',HERE/'assemble.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
def validate(reports,write=False,locale="te"):
 a.require(locale in ("te",),"unsupported compatibility locale")
 roster=a.read(HERE/'actual-role-roster.json');a.require(all(isinstance(v,str)for v in roster.values()),'actual role roster pending');a.ROLES.update(roster)
 kit=a.BASE/'telugu-compat-v8';p=a.load_program();manifest=a.read(kit/'manifest.json');packetpath=kit/'te18-after-editor-review-input.json';packet=a.read(packetpath);paths=p.catalog_paths(kit,locale);hashes={s:a.sha(path)for s,path in paths.items()};a.require(packet['source_sha256']==manifest['source_sha256']and packet['catalog_sha256']==hashes,'TE packet source/catalog stale')
 source={s:a.read(kit/'source'/f'{s}.json')for s in ('native','online')};target={'native':p.CHECKER.read_table(paths['native'])[0],'online':a.read(paths['online'])};expected={e['id']:e for e in packet['entries']};a.require(len(expected)==len(packet['entries'])==18,'TE scope must be distinct eighteen entries');a.require(set(expected)==set(a.read(kit/'only-keys.json')),'TE scope differs from original machine supplement')
 membership={i:b['id']for b in manifest['batches']for i in b['keys']}
 for i,e in expected.items():
  s,k=i.split(':',1);a.require(e['source']==source[s][k]and e['target']==target[s][k]and e['batch_id']==membership[i],'TE packet literal/batch differs')
 baseline={'native':p.CHECKER.read_table(kit/('baselines/'+locale+'/texts.'+locale+'.txt'))[0],'online':a.read(kit/('baselines/'+locale+'/'+locale+'.json'))};pre=a.read(kit/'preflight.json')
 for s,name in [('native','texts.'+locale+'.txt'),('online',locale+'.json')]:
  a.require(a.sha(kit/'baselines'/locale/name)==pre['baseline_sha256'][name],'TE baseline identity differs');a.require(all(target[s].get(k)==v for k,v in baseline[s].items()),'old TE pair changed outside compatibility supplement')
 a.require({s+':'+k for s in source for k in source[s]if k not in baseline[s]}==set(expected),'TE new pair scope differs')
 checked=p.check_draft(kit,locale);a.require(not checked['errors']and not checked['untranslated'],'TE draft contract errors');proofs=[]
 for role in a.ROLES:
  report,proof=a.verify_report(reports[role],role,expected,manifest['source_sha256'],hashes,locale=locale);a.require(report.get('packet_sha256')==a.sha(packetpath),'TE report binds different packet');proofs.append(proof)
 result={'result':'passed','scope':'Eighteen compatibility additions only; not full locale linguistic review or platform readiness','source_sha256':manifest['source_sha256'],'catalog_sha256':hashes,'packet':{'path':str(packetpath.relative_to(a.BASE)),'sha256':a.sha(packetpath)},'entries':18,'locale':locale,'role_bindings':54,'actual_role_evidence':proofs,'unchanged_prior_native_pairs':len(baseline['native']),'unchanged_prior_online_pairs':len(baseline['online']),'new_english_matches':[i for i,e in expected.items()if e['source']==e['target']],'runtime_platform_gates':'pending, no approvals produced','candidate_only':True}
 # Source-equal new literals require actual individual exception rationales in all roles.
 if result['new_english_matches']:
  approved={role:a.read(path)for role,path in reports.items()};a.english_exceptions(set(result['new_english_matches']),{},source,target,{'native':{},'online':{}},{'native':{},'online':{}},set(expected),approved)
 if write:
  a.require(all(a.sha(reports[r])==next(e['sha256']for e in proofs if e['role']==r)for r in a.ROLES),'TE report changed during validation');a.require({s:a.sha(path)for s,path in paths.items()}==hashes,'TE candidate changed during validation');p.write_json(kit/('compatibility-'+locale+'18-review-validation.json'),result)
 return result
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 for role in a.ROLES:parser.add_argument('--'+role,type=Path,required=True)
 parser.add_argument('--locale',choices=('te',),required=True);parser.add_argument('--write',action='store_true');args=parser.parse_args();print(json.dumps(validate({r:getattr(args,r)for r in a.ROLES},args.write,args.locale),indent=2))
