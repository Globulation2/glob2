import json,re,hashlib
from pathlib import Path
P=Path('artifacts/bulgarian/linguistics');K=Path('artifacts/bulgarian/kit-v3');load=lambda p:json.loads(Path(p).read_text());h=lambda v:hashlib.sha256(v.encode()).hexdigest();raw=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=K/'changed-batches-final-candidate.json';candidate=load(f);src=load(K/'source/native.json');targetpath=K/'drafts/bg/texts.bg.txt';t=dict(re.findall(r'^(\[[^\n]+\])\n([^\n]*)',targetpath.read_text(),re.M));assert raw(targetpath)==candidate['native_catalog_sha256']=='dbd1c1c47e5ef46e7e513a329d66e91228257458e70315c4193c0c4e7396444e';assert len(t)==3411
new={r['key']:r for r in load(P/'semantic-v3-delta-recheck.json')['entries']}
notes={
'[lesson defensive-tactics guard marker]':'Guard zone preparation marker; охранителна зона retains the guard-zone mechanic and polite plural preparation action.',
'[lesson defensive-tactics repel hint]':'All clauses preserved: maintained guard coverage and inn supplies, small attack after preparation, both raiders may retreat, warriors temporarily eat, earlier save/restart recovery. Покрита denotes defended coverage in this tactical context, not terrain reveal or completed construction.',
'[lesson defensive-tactics repel title]':'Repel/отблъснете and practice/training attack meaning retained; plural imperative.',
'[lesson defensive-tactics repel instruction]':'Enemy attacking, guard zone defended and inns supplied; no replacement with attack orders or guarantee that guards never leave.',
'[lesson defensive-tactics repel help]':'Two enemies and retreat/temporary eating conditions retained; recovery uses earlier saved game or restart, no promise of automatic checkpoint.',
'[lesson defensive-tactics repel marker]':'Same repel-practice-attack instruction as matching title, appropriate marker.',
'[lesson defensive-tactics counterattack hint]':'War flag at enemy Swarm, request3 warriors and radius4 or lower. Guard/flag competition, removing guard cells and maintaining food all retained; no teleport or guaranteed assignment claim.',
'[lesson defensive-tactics counterattack title]':'Фокусирана контраатака denotes concentrating the counterattack; valid tactical category, not camera focus.',
'[lesson defensive-tactics counterattack instruction]':'Боен флаг/рояк established building terms,3warriors and radius4orlower exact.',
'[lesson defensive-tactics counterattack help]':'Guard cells can keep warriors from war flags; removing guard tiles and food availability preserved. Плочките с охрана denotes painted guard cells, not a separate building.',
'[lesson defensive-tactics counterattack marker]':'Same focused-counterattack meaning as title; marker action preserved.',
'[lesson healing build compact]':'Hospital build-menu path, leave access and request builders. Заявете conveys autonomous worker request rather than manual creation.',
'[lesson healing heal compact]':'The wounded worker heals at Hospital; no training or resurrection meaning introduced.',
'[lesson walking-training build compact]':'Build Racetrack and leave room around its edges, preserving building term and free perimeter requirement.',
'[lesson walking-training train compact]':'Worker completes Racetrack training; completion requirement retained, not merely visiting.',
'[lesson swimming build compact]':'Swimming Pool placement west of pond retained; not east or inside water.',
'[lesson swimming train compact]':'Worker learns swimming; definite worker in lesson context natural.',
'[lesson swimming water-job compact]':'School construction with requested builders and wood/algae materials retained; does not order workers to gather different resources.',
'[lesson schools build compact]':'Same School build path/material staffing requirement as swimming water-job; consistent.',
'[lesson schools learn compact]':'Worker completes School training, not generic school attendance; actual training level increase is lesson condition.',
'[lesson upgrades upgrade compact]':'Select Racetrack, Upgrade, request trained/skilled builders; no arbitrary staffing level added.',
'[lesson upgrades train compact]':'Worker trains at already upgraded Racetrack, preserving building-state precondition.',
'[lesson fortifications tower compact]':'Tower build-menu path and marked-area placement retained.',
'[lesson fortifications walls compact]':'Explicit2walls and free passage west of tower; проход is natural spatial-access instruction and preserves open lane, not a closed defensive line.',
'[lesson fortifications supply compact]':'Select tower, suppliers and wait for2stone. Снабдители established supply workers;2камъка correct fixed-count form.',
'[lesson fortifications hold compact]':'Maintain tower supply while facing attacker; no contradictory attack/move order or unconditional victory claim.',
'[lesson defensive-tactics scout compact]':'Exploration flag at enemy and request1explorer retained; разузнавач is established scouting unit, not scholar.',
'[lesson defensive-tactics guard compact]':'Flags→Guard, paint4cells and allow2warriors to arrive; distinguishes painted zone from placing a guard building.',
'[lesson defensive-tactics repel compact]':'Hold guard zone and maintain Inn supplies; consistent compact objective.',
'[lesson defensive-tactics counterattack compact]':'Enemy Swarm, war flag, request3warriors andradius≤4 all exact.',
'[intro attack destination]':'Attack-here map destination label; Атака тук is concise and not a promise of instant attack.',
'[Grassland]':'Actually read savannah grassland control0–100 and golden-grass share implementation. Тревни площи names areas covered with grass, not a mandatory flat plain, city lawn or farming crop. Accept changed value in landscape setting.',
'[Kopjes]':'Actually read granite core, rocky flanks and scree feature code. Скалисти хълмове is clear descriptive Bulgarian for these isolated rocky hills; not a village or proper placename.',
'[Game trails]':'Game means wildlife in savannah landscape metaphor, supported by five references. Пътеки за дивеч communicates animal trails rather than game UI routes; does not assert simulated animals exist.',
'[Fish amount]':'Resource abundance slider, Количество риба natural mass-noun label; no monetary/food conversion invented.',
'[scenario messages]':'Scenario message-history affordance, plural messages and rightward disclosure glyph preserved.',
'[Camp-site amount]':'Savannah camp-site resource abundance control; Количество лагери preserves resource amount rather than campsite size or number of players.',
'[terrain palette hint]':'Brush selection and shared terrain-group rules with visual-only member variation retained. Членовете refers to group elements in context; no different simulation rules implied.',
'[terrain rule algae grow]':'Shown only when terrain rule allows resource growth and is swimmable; водорасли names algae rather than all crops.',
'[editor map saved]':'Past completed map save, not a save action or publication claim.',
'[editor map shared]':'Past completed online map sharing. Actually read finishShare(shared) guard; онлайн removes ambiguity with local save without asserting public visibility.',
'[editor menu import terrain]':'Import terrain definitions, not just terrain artwork. Defиниции is appropriate editor technical term and ellipsis signals follow-up picker.',
'[library All generators]':'All-generator filter label, no filtering to playable/editor-only introduced.',
'[library Downloading generator…]':'Ongoing download state, not installed/completed; ellipsis retained.',
'[library Each landscape is shown as a real map at the size and colony count below, which you can change here. Use one to play the map shown.]':'Preview is real map at editable displayed size/colony count, selecting one plays shown map. No seed or regenerated-layout guarantee invented.',
'[library Editor tool: generates terrain for the map editor.]':'Editor-only terrain tool purpose retained; does not promise a colony-playable map.',
'[library Enable installed families below. Selection is saved in this local profile; existing maps and saves keep their own buildings. For online play, generate a map with these families, publish it in the map library, then choose that map in your room.]':'Building families activated locally for future maps; existing maps/saves keep embedded buildings. Online workflow generate→publishmap→chooseinroom exact. Saved-files wording is understandable for game saves in this library context.',
'[library Generator file hash mismatch]':'File hash mismatch names technical integrity failure, no claim that package identity itself is wrong.',
'[library Generator installed. Future selections use this release.]':'Successful install affects future selections; does not rewrite already selected/frozen maps or saved game.',
'[library Generator package identity mismatch]':'Package identity mismatch distinct from filehash mismatch, exact technical diagnosis.',
'[library Generators]':'Generator category plural, no accidental power-generator sense in map library context.',
'[library Map generators]':'Explicit map-generation category; idiomatic Bulgarian plural.',
'[library My generators]':'Ownership filter label, no installed-only restriction added.',
'[library Playable generator]':'Generator suitable for playable colony games, distinguished from editor-only terrain tool.',
'[library Saving generator library…]':'Ongoing persistence stage, not confirmed installed/save completed.',
}
rows=[];batches=[]
for batch in candidate['batches']:
 e=[]
 for x in batch['entries']:
  k=x['key'];assert x['source']==src[k] and x['translation']==t[k]
  assert sorted(re.findall(r'%\d+',x['source']))==sorted(re.findall(r'%\d+',x['translation']))
  if k in new:
   reason='Actually reread again in this73-key batch renewal. '+new[k]['reason'];ctx=new[k]['contexts_read']
  else:
   reason=notes[k]
   if k.startswith('[lesson '):
    lesson=k[len('[lesson '):].split(' ')[0];ctx=['scripts/tutorials/'+lesson+'.json','src/tutorial/TutorialModel.cpp','src/tutorial/IntroductionTest.cpp:454-485']
   elif k in ['[Grassland]','[Kopjes]','[Game trails]','[Fish amount]','[Camp-site amount]']:ctx=['src/map/generator/generators/SavannahGenerator.cpp:388-410,435-490,697-730,867-895']
   elif k.startswith('[terrain '):ctx=['src/map/editor/BrushCatalog.cpp:336-355']
   elif k=='[intro attack destination]':ctx=['scripts/tutorials/introduction.json:367']
   elif k=='[scenario messages]':ctx=['src/hud/touch/GameGUITouchView.cpp:612,687']
   elif k.startswith('[editor map '):ctx=['src/map/editor/MapEditFlows.cpp:169-184']
   elif k=='[editor menu import terrain]':ctx=['src/map/editor/MapEditFlows.cpp terrain import picker/flow']
   else:ctx=['src/online/screens/OnlineGeneratorsScreen.cpp:153-226,270-340','src/online/screens/BuildingLibraryScreen.cpp installed-family selection and persistence text','src/game/screens/LandscapePickerScreen.cpp landscape preview']
  row=dict(surface='native',id=x['id'],key=k,source=x['source'],target=x['translation'],source_sha256=h(x['source']),target_sha256=h(x['translation']),decision='acceptable',actual_reading=True,method='explicit_all73_changed_batch_rereading',reviewer_agent='/root/semantic_reviewer',contexts_read=ctx,reason=reason)
  rows.append(row);e.append(row)
 # Binding all entries in order, explicit portable scheme rather than implicit tool hash.
 binding=json.dumps([{'id':r['id'],'source':r['source'],'target':r['target']}for r in e],ensure_ascii=False,sort_keys=True,separators=(',',':'))
 batches.append(dict(batch_id=batch['id'],source_batch_sha256=batch['source_batch_sha256'],entries_examined=len(e),decision='approved',findings=[],source_target_binding_sha256=h(binding),source_target_binding_serialization='UTF8 json.dumps ordered list of id/source/target objects, ensure_ascii=False, sort_keys=True, separators=(comma,colon)',keys=[r['key']for r in e]))
assert len(rows)==73 and len({r['key']for r in rows})==73
paths=[f,targetpath,K/'source/native.json',K/'manifest.json',P/'semantic-v3-delta-recheck.json',Path('src/map/generator/generators/SavannahGenerator.cpp'),Path('src/map/editor/MapEditFlows.cpp'),Path('src/map/editor/BrushCatalog.cpp'),Path('src/tutorial/TutorialModel.cpp'),Path('src/tutorial/IntroductionTest.cpp'),Path('src/game/screens/LandscapePickerScreen.cpp'),Path('src/online/screens/OnlineGeneratorsScreen.cpp'),Path('src/online/screens/BuildingLibraryScreen.cpp')]+list(Path('scripts/tutorials').glob('*.json'))+list((K/'references').glob('texts.*.txt'))
out={'reviewer_agent':'/root/semantic_reviewer','role':'independent-semantic-gameplay','source_sha256':candidate['source_sha256'],'native_catalog_sha256':raw(targetpath),'online_catalog_sha256':candidate['online_catalog_sha256'],'input_files_sha256':{str(p):raw(p)for p in paths},'scope':'Actually reread all73 final source/target pairs, including18newkeys and55existingkeys in both changed batches. Four revised OLD targets independently assessed; no reliance on adversarial conclusions.','coverage':{'entries':73,'native_general_017':54,'native_maps_002':19,'new_keys':18,'old_keys':55,'other41_batches':'Not freshly read here; require exact prior-review carry-forward proof.'},'batch_approvals':batches,'entries':rows,'findings':[],'reference_reading':'Read Serbian/Russian/Ukrainian/French/German entries for Grassland,Kopjes,Game trails,Camp-site amount,editor map shared,terrain palette/rules, compiler/commander terminology; tutorial compact entries in those snapshots are blank, so no reference linguistic coverage claimed for them. Frozen English and actual tutorial definitions control these instructions.','hash_scheme':'Per-key source/target SHA256 literal UTF8 strings without JSON quoting; whole files raw bytes. Each batch additionally bound by explicit orderedid/source/target serialization documented above; provided source_batch_sha256 retained exactly.','limitations':'AI semantic review, not human certification. No live edits, builds, execution tests or new rendered capture inspection. Full corpus outside these73 is not re-read or implicitly reapproved by this delta.'}
P.joinpath('semantic-v3-final-batches.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('Actuallyreviewed73: bothsourcebatchesapproved, findings0, nativeSHAverified.')
