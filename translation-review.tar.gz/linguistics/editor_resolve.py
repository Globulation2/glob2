import json
from pathlib import Path
p=Path('artifacts/bulgarian/linguistics');d=json.loads((p/'editor-conflicts.json').read_text())
# All 198 pairs read individually in three displayed chunks. Retain the semantic
# wording where both are idiomatic and it keeps established terms coherent.
editor={4,9,12,14,18,20,21,22,23,24,25,26,27,28,29,30,31,32,36,38,40,45,47,52,53,55,59,66,69,70,71,76,78,89,104,106,107,109,110,111,113,114,115,117,119,121,123,130,134,136,139,140,145,146,148,160,178,180,183,184,186,187,194,195,196}
custom={
0:('Назначени','Assigned staffing are units appointed to a task, not generic assigned property values.'),
15:('Искате ли да запазите играта, преди да излезете?','Complete natural Bulgarian subordinate clause while retaining explicit game object.'),
40:('Настройки за надграждане по подразбиране','Keep existing надграждане label terminology in settings.'),
46:('И вие, и ИИ издавате заповеди. Използват се два слота за контролери.','Plural slots for controllers with grammatical impersonal subject.'),
51:('Промяна на броя назначени единици с колелцето. При изключена настройка задръжте Ctrl. Shift променя радиуса на флага. Настройката управлява и използването на колелцето в другите менюта.','Noun setting description; retain explicit subject in last sentence.'),
56:('Брой единици, назначени по време на надграждане на сграда.','Staffing setting; retain existing надграждане terminology.'),
58:('Свързаност на обходните пътища','Loopiness is the extent of alternate looping routes; зацикляне implies malfunction.'),
68:('Обучен върху мачове:','Short label appropriate before sample count.'),
120:('Брифинг за мисията · докоснете за редактиране, плъзнете за превъртане','Use Брифинг matching existing native briefing label.'),
122:('Докъде продължават да се превъртат списъците и панелите след рязко плъзгане с пръст.','Retain distance meaning and clarify touch gesture.'),
124:('Докъде продължава да се мести картата след рязко плъзгане с пръст.','Retain distance meaning and clarify touch gesture.'),
131:('%0 загуби връзка. Играта продължава; колонията на играча продължава да работи, докато връзката се възстановява (остават %1).','Explicit colony ownership avoids ambiguous detached clause.'),
137:('Влезте или създайте акаунт в браузъра си. Мачовете ви като гост ще се прехвърлят към акаунта.','Keep transfer meaning and make destination clear.'),
158:('Място, заето от ИИ','AI-filled identifies seat completion, avoid generic попълнено.'),
161:('медианна продължителност на мачовете ви','Explicit median statistic, not average or physical length.'),
192:('Товарите от всеки материал, събрани от работници. Разделете графиката, за да видите всеки материал.','Correct plurality of gathered loads and explicit chart action.'),
}
out=[]
for i,r in enumerate(d):
 v=r['value'] if i in editor else r['current'];reason='Both proposals read; retain idiomatic semantic wording and its established terminology.'
 if i in editor:reason='Both proposals read; editorial wording improves idiom, agreement, concise labels or consistent presentation.'
 if i in custom:v,reason=custom[i]
 out.append(dict(surface='native',key=r['key'],value=v,reason=reason,current=r['current'],editor_proposal=r['value'],decision='custom' if i in custom else ('editor' if i in editor else 'semantic')))
(p/'editor-conflict-resolutions.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(len(out),{x:sum(r['decision']==x for r in out) for x in ['semantic','editor','custom']})
