from pathlib import Path
import difflib,json,hashlib
p=Path('artifacts/bulgarian/linguistics');f=Path('src/ui/settings/SettingsScreenGeneral.cpp');old=f.read_text();new=old
needle='\tauto &s = globalContainer->settings;\n'
addition='''\t// Localize generic display labels; protocol/backend names stay canonical.
\tconst auto rendererLabel = [](RendererBackend backend) -> std::string
\t{
\t\tif (backend == RendererBackend::Software) return tr("Software");
\t\tif (backend == RendererBackend::Auto) return tr("Automatic");
\t\treturn std::string(rendererBackendLabel(backend));
\t};
'''
new=new.replace(needle,needle+addition,1)
for a,b in [('std::string(rendererBackendLabel(globalContainer->gfx->backendSwitchStatus().active))','rendererLabel(globalContainer->gfx->backendSwitchStatus().active)'),('std::string(rendererBackendLabel(entry.backend))','rendererLabel(entry.backend)'),('.arg(rendererBackendLabel(status.active))','.arg(rendererLabel(status.active))')]:
 assert new.count(a)==1;new=new.replace(a,b)
def patch(text,name):p.joinpath(name).write_text(''.join(difflib.unified_diff(old.splitlines(keepends=True),text.splitlines(keepends=True),fromfile='a/'+str(f),tofile='b/'+str(f))))
patch(new,'settings-renderer-labels-proposed.patch')
a='            if (!status.reason.empty()) info(status.reason);';assert new.count(a)==1
new=new.replace(a,'''            // Backend diagnostics may contain untranslated driver messages. Keep
            // the detailed reason in backend status and show a catalog notice.
            if (!status.reason.empty()) info(tr("Renderer unavailable"));''')
patch(new,'settings-renderer-labels-and-diagnostic-proposed.patch')
p.joinpath('settings-renderer-localization-reviewed.json').write_text(json.dumps({'role':'independent-semantic-gameplay','source_file':str(f),'source_sha256':hashlib.sha256(old.encode()).hexdigest(),'decision':'approve narrowly localizing Software/Automatic at all three display sites','display_sites':[{'line':79,'context':'Current display backend slot'},{'line':220,'context':'Renderer choice display label; enum callback payload unchanged'},{'line':232,'context':'Active renderer backend slot'}],'existing_keys':['[settings Software]','[settings Automatic]','[settings Renderer unavailable]'],'reason':'Software/Automatic are generic display labels with existing translations. RendererSelection.cpp machine-name API is separate. Helper preserves SDL GPU, Programmable GL, WebGPU, Portable SDL and Legacy OpenGL labels; enum selection/persistence unchanged.','diagnostic_assessment':{'raw_player_site':235,'actual_sources_read':['GraphicContextRenderer.cpp rendererAvailability/requestBackendSwitch','GraphicContextRenderer.cpp switch failure/restore/fallback branches','GraphicContextRenderer.cpp handleDeviceFailure','GraphicContext.cpp startup unavailable requested renderer'],'recommended_fallback':'Renderer unavailable','reason':'Reason contains English literals, SDL diagnostics or exceptions. The requested/failed device is unavailable even when another active backend remains usable; active backend is explicitly shown above. Generic catalog notice avoids asserting restoration. Raw detailed reason remains in engine status unchanged; this reduces visible diagnostic detail without altering behavior.','rejected_fallback':'Could not change display mode. The previous mode was restored.','rejection_reason':'Actual restore and software fallback can both fail, so restored-state claim is not justified.'},'prepared_patches':{'labels_only':'settings-renderer-labels-proposed.patch','recommended_combined':'settings-renderer-labels-and-diagnostic-proposed.patch'},'active_sources_modified':False,'tests_or_builds_run':False,'catalog_edits':False,'limitation':'Prepared patch only. Parent integrates after active producer completes and repeats relevant Settings captures/checks.'},ensure_ascii=False,indent=2)+'\n')
print('Prepared both patch variants without touching active source.')
