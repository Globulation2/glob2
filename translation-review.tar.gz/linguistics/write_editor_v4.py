from pathlib import Path
import json,hashlib,re
p=Path('artifacts/bulgarian/linguistics');inp=p/'v4-editorial-candidate.json';d=json.loads(inp.read_text());h=lambda s:hashlib.sha256(s.encode()).hexdigest();context=json.loads(Path('artifacts/bulgarian/kit-v4/semantic-review-input.json').read_text());cm={e['key']:e for e in context['entries']}
reasons=[
'Natural concise heading; identical to the existing reviewed overview label.',
'Standard Bulgarian economic topic label, parallel to the other noun headings.',
'Bare noun Свят is natural in this topic selector; it does not imply a map title or map name.',
'Natural coordinated heading for idle workforce and blocked construction; no awkward ampersand.',
'Отбрана is the military category term and agrees with existing defence-statistics vocabulary.',
'Natural preview-history action for the metric canvas accessible label; definite history is appropriate to that metric.',
'Neutral impersonal waiting status, with the source ellipsis; does not present missing data as zero or failure.',
'Natural Bulgarian UI wording with plural units, matching the colony-wide aggregate details.',
'Concise map overlay heading; слоеве is appropriate to toggled visual data on the existing map.',
'Tема is a correct short generic topic label; no invented direct consumer is asserted.',
'Grammatical polite-plural instruction, consistent with the reviewed UI register, and preserves the full-history action.',
'Записана стойност is a natural numeric reading; показател identifies the selectable statistic clearly. The missing-data dash and not-yet meaning remain intact.',
'Победа denotes match victory and correctly avoids the monetary sense of печалба.',
'Use разположението по картата to unambiguously describe spatial distribution on the map. Разположението на картата can instead read as the placement or layout of the map itself. Estimated probability, whole-match sampling, shared alliance estimate, AI training limitation, planned moves and old-save-history caveat all remain explicit.'
]
entries=[]
for i,e in enumerate(d['entries']):
 old=e['target'];new=old
 if e['key']=='[stat win probability about]':
  assert old.count('разположението на картата')==1;new=old.replace('разположението на картата','разположението по картата')
 assert sorted(re.findall(r'%\d+',e['source']))==sorted(re.findall(r'%\d+',new))
 if 'AI' in cm[e['key']]['tokens']: assert new.count('AI')==1
 entries.append({'surface':'native','key':e['key'],'source':e['source'],'input':old,'proposed':new,'target':new,'source_value_sha256':h(e['source']),'input_value_sha256':h(old),'target_value_sha256':h(new),'actual_reading':True,'decision':'replace' if old!=new else 'accept','reason':reasons[i],'contexts_examined':cm[e['key']]['contexts'],'context_note':cm[e['key']]['context_note'],'severity':'minor' if old!=new else None,'confidence':'high'})
files=['src/hud/InGameStatistics.cpp','src/hud/draw/GameGUIDraw.cpp','src/team/stats/TeamStatChart.cpp','artifacts/bulgarian/kit-v4/semantic-review-input.json']
r={'reviewer_agent':'/root/compat_editor','review_role':'Independent Bulgarian editorial reviewer','scope':'All14 new native keys introduced by current-master integration; no reread of unchanged corpus claimed.','certification':'Agent-reviewed, not native-human certification.','source_sha256':d['source_sha256'],'candidate_native_catalog_sha256':d['native_catalog_sha256'],'input_file_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'examined_count':14,'proposed_correction_count':1,'context_file_sha256':{f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files},'context_method':'Read English14 and existing Bulgarian statistics glossary, actual topic selector/unitDetails/metric/history/missing-reading/overlay consumers before reading the integrated candidate. Source meaning controls; coordinator reasoning is not an approval substitute.','entries':entries,'unresolved_questions':[],'status':'Editorial proposals; root integration then semantic/adversarial checks required.'}
(p/'editor-v4-new14.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');(p/'editor-v4-new14-proposed-edits.json').write_text(json.dumps([e for e in entries if e['decision']=='replace'],ensure_ascii=False,indent=2)+'\n');print('examined14 proposed1',hashlib.sha256((p/'editor-v4-new14.json').read_bytes()).hexdigest())
