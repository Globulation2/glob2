# Targeted API catalog audit

Read-only audit, after 6229-key semantic draft review. No source/catalog changes made.

Inspected actual `pageHtml` runtime translation in `platform/apps/api/src/web/pages.ts`, tagged templates/text nodes and alt/title/aria-label/placeholder attributes in `routes/signin.ts` and `routes/invite.ts`, direct pageText/sendPage/errorPage literals, plus literal apiError messages throughout `platform/apps/api/src`. AST audit scripts and raw results are beside this file. This is a targeted audit, not a claim that all dynamically assembled server text is covered.

Sign-in/invite result: **no missing English catalog keys found** in actual runtime node/attribute extraction, including interpolation index pN and whitespace normalization. Proper-name Globulation 2 brand aria label is intentional. Sign-in local form fields, provider handoff/confirmation/conflict messages, invite fallback and static errors reviewed all have keys. No definite server-rendered fallback gap identified there.

Three unique API error literals absent from the English catalog (four callsites), covered by localized generic handling:

| Key | Callsites | Trigger | Proposed Bulgarian |
|---|---|---|---|
| Skin purchases are not available on this instance. | `platform/apps/api/src/publicFeatures.ts:34`, `platform/apps/api/src/skins/billing/routes.ts:108` | Attempt checkout when skin sales/designer disabled | Покупките на облици не са достъпни на този сървър. |
| This creation tool is not available on this instance. | `platform/apps/api/src/publicFeatures.ts:39` | POST to disabled creation tool, e.g. stale open studio page | Този инструмент за създаване не е достъпен на този сървър. |
| The skin designer is not available on this instance. | `platform/apps/api/src/publicFeatures.ts:47` | POST draft/publish/design while skin designer disabled | Дизайнерът на облици не е достъпен на този сървър. |

Correction after tracing the actual error presenter: the earlier inference that these literals would fall back to English was incorrect. `apiError` emits each literal as messageKey, but `platform/packages/i18n/src/index.ts:275` translates only recognized catalog keys and otherwise returns the localized generic message `Something went wrong. Please try again.`. `platform/apps/web/src/api.ts:39` defines ApiError.message as a getter through translateError; therefore even Store.tsx buy/reconcile catch handlers that use e.message receive localized generic text. Studio displayMessage routes object errors through translateError too. These three missing keys do not establish a shipped English leak; they reduce error specificity while preserving localized presentation. No catalog/source-freeze expansion is needed for this audit. No new keys or tests have been added by this reviewer. A focused test of all three unknown messageKey literals returning the Bulgarian generic message would document this existing boundary.
