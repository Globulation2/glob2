import json,re,hashlib
from pathlib import Path
P=Path('artifacts/bulgarian/linguistics');K=Path('artifacts/bulgarian/kit-v3');load=lambda p:json.loads(Path(p).read_text());h=lambda s:hashlib.sha256(s.encode()).hexdigest()
draft=load(K/'delta-machine-draft.json');src=load(K/'source/native.json');manifest=load(K/'manifest.json');assert manifest['source_sha256']==draft['source_sha256']=='f8d14316709d155e55ce55a95f474763a34b22b897d0134494fb84aaf17e10ee'
values=[
'Успешна компилация',
'Грешка на ред %0, колона %1: %2',
'Неуспешна компилация: %0:%1:(%2): %3',
'Неуспешна компилация: %0',
'Зареждането на скрипта от %0 не бе успешно',
'Запазването на скрипта в %0 не бе успешно',
'Ред: %0 · колона: %1',
'Играта е прекратена: %0',
'Прегледайте вградения JavaScript код и потреблението му на ресурси, преди да стартирате тази игра отново.',
'Липсва генератор на карти: %0. Избран е вграден пейзаж.',
'Постоянна заповед изисква внимание и е поставена на пауза.',
'Връзката се промени. Прегледайте постоянните си заповеди на пауза, преди да ги възобновите.',
'Постоянната заповед изисква ново указание след повторното свързване. Можете да я отмените или да помолите командира да я замени.',
'Една заповед не можа да бъде потвърдена. Прегледайте постоянните си заповеди, преди да ги възобновите.',
'Предишната ви заповед все още се изпраща. Това съобщение е запазено; отворете командира, за да го изпратите отново.',
'Получена заповед: %0',
'Заповедта не е потвърдена. Отворете командира, за да опитате отново; съобщението ви е запазено.',
'Актуализацията на постоянната заповед не бе успешна. Заповедта ви е на пауза локално; повторете действието чрез съответната контрола.'
]
reasons=[
'Accept precise successful-compilation status. Existing Compile/compile labels use компилиране; noun компилация is natural for result. No failure or game state implied.',
'Explicitly name line and column, matching actual USL coordinate arguments; Грешка в %0:%1 is less idiomatic/clear. Keep diagnostic summary slot separate and exact order.',
'Use concise natural failure heading, preserving line, column, source offset and diagnostic slots. Add only readable spacing before summary; retain coordinate punctuation and source-offset parentheses.',
'Use same clear unsuccessful-compilation heading as coordinate case. The draft is semantically correct; this is consistency/conciseness refinement.',
'Accept exact file-load failure with original filename slot; loading from filename, not server download or compile failure.',
'Accept exact file-save failure with original filename slot and established native Запазване term; no false claim file is restored or written.',
'Keep both one-based coordinates, add a visible separator and sentence-style lowercase колона; improves distinction without changing offset or cursor meaning.',
'Actual Script::SessionFailure calls abortSession and leaves the session; прекратена clearly means terminated, distinct from paused or failed to start. Draft Играта спряна lacks an auxiliary and can sound like an incomplete label.',
'Explicit JavaScript код clarifies embedded script, and потреблението му на ресурси means CPU/memory/runtime resource use rather than terrain goods. Polite plural Прегледайте; restart this same game, not a new game.',
'Native means built-in generator/landscape here, not local/native-country scenery. Preferences already retain native legacy fallback when customId lookup fails. Keep existing landscape term пейзаж and exact generator identifier slot.',
'Use established persistent commander term постоянна заповед, not нареждане variant or purchase. State actual pause after rejected work; do not infer remote cancellation.',
'Use established term and clear на пауза construction. Actual connection/lease transition pauses local programs; plural ги refers to paused standing orders being resumed.',
'Use established standing-order term and ново указание (neuter), so я unambiguously refers to feminine заповед when cancelling/replacing. Existing command action wording uses отмена; English means replace order after reconnect, not merely resend network request.',
'Draft Поръчката wrongly means purchase, and я възобновите wrongly resumes one unconfirmed order. Actual response failure pauses all standing orders: plural ги preserves code/source scope.',
'Accept: source previous order still in flight, newly attempted text kept as commandDraft, commander can resend preserved message. No promise previous send failed or new request was transmitted.',
'Draft purchase-order sense Поръчка wrong for colony instruction. Use established заповед; exact user text in %0 is literal content, never translated or recursively substituted.',
'Draft purchase-order sense wrong. Use established заповед; retain not-confirmed state without falsely asserting operation failed remotely, preserve saved-message/retry instruction.',
'Use established persistent заповед throughout; NMT mixes нареждане/поръчка. Actual local control immediately pauses and server update may fail; локално restricts state claim. Retry the same UI control action, not vaguely attempt to manage the order.'
]
contexts=[['src/scripting/map/ScriptEditorScreen.cpp:143-179'],['src/scripting/map/ScriptEditorScreen.cpp:154-168'],['src/scripting/map/ScriptEditorScreen.cpp:171-188'],['src/scripting/map/ScriptEditorScreen.cpp:192-195','src/scripting/map/ScriptEditorScreen.cpp:208-260'],['src/scripting/map/ScriptEditorScreen.cpp:375-393'],['src/scripting/map/ScriptEditorScreen.cpp:395-400'],['src/scripting/map/ScriptEditorScreen.cpp:419-433'],['src/game/screens/GameSessionScreen.cpp:45-59'],['src/game/screens/GameSessionScreen.cpp:45-59'],['src/game/screens/CustomGameScreen.cpp:140-149','src/game/rules/CustomGamePreferences.h:251-278'],['src/hive/HiveClient.cpp:335-346'],['src/hive/HiveClient.cpp:443-452'],['src/hive/HiveClient.cpp:462-480'],['src/hive/HiveClient.cpp:582-596'],['src/hive/HiveClient.cpp:599-610'],['src/hive/HiveClient.cpp:624-635'],['src/hive/HiveClient.cpp:632-637'],['src/hive/HiveClient.cpp:661-688','src/hive/HiveDialog.cpp:136-161']]
entries=[];proposal=[]
for i,(x,value,reason,ctx) in enumerate(zip(draft['entries'],values,reasons,contexts)):
 assert src[x['key']]==x['value'];tokens=lambda t:sorted(re.findall(r'%\d+',t));assert tokens(value)==tokens(x['value'])==tokens(x['translation'])
 changed=value!=x['translation'];entry=dict(surface='native',key=x['key'],source=x['value'],input_target=x['translation'],proposed_target=value,source_sha256=h(x['value']),input_target_sha256=h(x['translation']),proposed_target_sha256=h(value),examined=True,reviewer_agent='/root/semantic_reviewer',role='independent-semantic-gameplay',decision='replace' if changed else 'accept_machine_value',reason=reason,contexts_read=ctx,source_contract_context=x['context'],placeholder_tokens=tokens(value))
 entries.append(entry);proposal.append(dict(surface='native',key=x['key'],value=value))
assert len(entries)==18
paths=[K/'delta-machine-draft.json',K/'delta-review-brief.json',K/'source/native.json',K/'manifest.json',P/'semantic-language-brief.md',Path('artifacts/bulgarian/comprehensive-error-surfaces/proposed-native-sources.json'),Path('data/texts.bg.txt'),Path('platform/packages/i18n/locales/bg.json'),Path('src/scripting/map/ScriptEditorScreen.cpp'),Path('src/game/screens/GameSessionScreen.cpp'),Path('src/game/screens/CustomGameScreen.cpp'),Path('src/game/rules/CustomGamePreferences.h'),Path('src/hive/HiveClient.cpp'),Path('src/hive/HiveDialog.cpp')]+list((K/'references').glob('texts.*.txt'))
out={'reviewer_agent':'/root/semantic_reviewer','role':'independent-semantic-gameplay','round':1,'certification':'AI linguistic review, not human certification','source_sha256':manifest['source_sha256'],'input_files_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths},'coverage':{'expected_new_native_keys':18,'examined_keys':18,'accepted_without_change':sum(e['decision']=='accept_machine_value'for e in entries),'proposed_replacements':sum(e['decision']=='replace'for e in entries),'unchanged_old3393':'Not reread in this delta; no fresh coverage claim.'},'hash_scheme':'Per-key values: SHA256 of literal UTF-8 string bytes, no JSON quoting. input_files hashes are raw file bytes. Top source_sha256 is frozen kit manifest source identity.','references_actually_read':{'native_catalogs':['texts.sr.txt','texts.ru.txt','texts.uk.txt','texts.fr.txt','texts.de.txt'],'representative_keys':['[compile]','[Compile]','[load script]','[save script]','[settings The commander may follow up on standing orders. Follow-ups use credits; installed orders keep running without credits.]','[hive give order]','[open commander]','[hive resume]'],'assessment':'References establish compiler/file and persistent-command senses; they are not Bulgarian authority or translations of these newly added keys. Bulgarian current catalog already uses заповед/постоянна заповед, командир, пейзаж, компилиране, зареждане/запазване.'},'entries':entries,'findings':[e for e in entries if e['decision']=='replace'],'placeholder_check':'All18 preserve exact multiset of positional tokens; literal user filename/ID/text payloads not translated. No dynamic values synthesized.','limitations':'No catalog/code edits, renderer/screenshots, execution tests or human certification. Need editorial and independent adversarial checks plus semantic final recheck before binding integrated values.'}
P.joinpath('semantic-v3-delta-round1.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');P.joinpath('semantic-v3-delta-round1-proposed-values.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n')
print('18actuallyexamined;',out['coverage']['proposed_replacements'],'proposals;',out['coverage']['accepted_without_change'],'unchangedaccepted; allplaceholdersexact.')
