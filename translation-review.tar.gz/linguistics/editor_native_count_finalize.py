exec(open('artifacts/bulgarian/linguistics/editor_review.py').read().split("if __name__")[0])
import hashlib
proposals=json.load(open(OUT/'semantic-native-count-findings.json'));by={r['key']:r for r in rows()[:3393]};old={r['key']:r for r in json.load(open(OUT/'editor-native-final-examined.json'))};review=[]
for i,f in enumerate(proposals):
 r=by[f['key']];v=r['target']; samples=[]
 for n in [0,1,2]:
  vals={'%0':str(n),'%1':str(n),'%2':str(n)}
  if i==11:vals['%0']='Рояк'
  if i==13:vals['%1']='2'
  if i==21:vals['%0']='256 × 256'
  if i==28:vals['%0']=str(n)+' s'
  if i==36:vals['%0']='Играч';vals['%1']=str(n)+' s'
  x=v
  for k,z in vals.items():x=x.replace(k,z)
  samples.append(dict(count=n,text=x))
 r.update(source_sha256=digest(r['source']),target_sha256=digest(v),result='acceptable',role='editorial',method='actual-native-count37-reread',count_samples=samples,reason='Read source/current wording and tested 0, 1 and 2: noun-before-number labels or invariant abbreviations avoid grammatical number agreement; meaning preserved. Longer help is explicit; compact count labels remain concise.')
 review.append(r);old[r['key']]=r
changed={k for k,r in by.items() if digest(r['target'])!=old[k]['target_sha256']};assert not changed,changed
(OUT/'editor-native-count-reread.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');(OUT/'editor-native-count-residual-findings.json').write_text('[]\n');(OUT/'editor-native-final-examined.json').write_text(json.dumps(list(old.values()),ensure_ascii=False,indent=2)+'\n')
s=json.load(open(OUT/'editor-final-summary.json'));s['file_sha256']={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path('artifacts/bulgarian/kit/drafts/bg/texts.bg.txt'),Path('artifacts/bulgarian/kit/drafts/bg/bg.json')]};s['outstanding_findings']=0;s['final_native_count_keys_rechecked']=37
for f in ['editor-native-count-reread.json','editor-native-count-residual-findings.json']:
 if f not in s['evidence']:s['evidence'].append(f)
(OUT/'editor-final-summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n');print('reviewed',len(review));print(json.dumps(s['file_sha256']))
