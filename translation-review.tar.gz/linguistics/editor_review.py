import re,json,hashlib,sys
from pathlib import Path
ROOT=Path('artifacts/bulgarian'); OUT=ROOT/'linguistics'
def native(p):return dict(re.findall(r'^(\[[^\n]+\])\n([^\n]*)',Path(p).read_text(),re.M))
def rows():
 en=native('data/texts.en.txt'); bg=native(ROOT/'kit/drafts/bg/texts.bg.txt')
 items=[dict(surface='native',key=k,source=v,target=bg[k]) for k,v in en.items()]
 en=json.loads(Path('platform/packages/i18n/locales/en.json').read_text()); bg=json.loads((ROOT/'kit/drafts/bg/bg.json').read_text())
 items.extend(dict(surface='online',key=k,source=v,target=bg[k]) for k,v in en.items())
 return items
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
if __name__=='__main__':
 items=rows(); start=int(sys.argv[1]);end=int(sys.argv[2])
 for i in range(start,min(end,len(items))):
  r=items[i];print(str(i)+' '+r['surface']+' '+r['key']);print('EN '+json.dumps(r['source'],ensure_ascii=False));print('BG '+json.dumps(r['target'],ensure_ascii=False))
