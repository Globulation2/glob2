exec(open('artifacts/bulgarian/linguistics/editor_state.py').read())
def batch(a,b,indexfix):
 items=rows();record(a,b,{items[i]['key']:v for i,v in indexfix.items()})
