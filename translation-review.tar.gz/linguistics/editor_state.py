exec(open('artifacts/bulgarian/linguistics/editor_review.py').read().split("if __name__")[0])
F=OUT/'editor-findings.json'; E=OUT/'editor-examined.json'; findings=json.loads(F.read_text()) if F.exists() else []; examined=json.loads(E.read_text()) if E.exists() else []
def record(start,end,fixes):
 items=rows()
 for i in range(start,end):
  r=items[i];k=r['key'];f=fixes.get(k)
  old=r['target']; r.update(source_sha256=digest(r['source']),target_sha256=digest(old),result='finding' if f else 'acceptable',role='editorial',batch=f'{start}-{end-1}')
  if f:
   value,reason=f if isinstance(f,tuple) else (f,'Idiomatic Bulgarian, grammar, terminology or concise label; see proposed wording.')
   findings.append(dict(surface=r['surface'],key=k,original=old,original_sha256=digest(old),value=value,reason=reason))
  examined.append(r)
 F.write_text(json.dumps(findings,ensure_ascii=False,indent=2)+'\n'); E.write_text(json.dumps(examined,ensure_ascii=False,indent=2)+'\n')
 print('examined',len(examined),'findings',len(findings))
