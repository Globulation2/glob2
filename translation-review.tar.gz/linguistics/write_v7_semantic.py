import json,hashlib,re
from pathlib import Path
D=Path('artifacts/bulgarian/linguistics')
sha=lambda v:hashlib.sha256(v.encode()).hexdigest()
canon=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
identity={'agent':'/root/v7_meaning','role':'Independent meaning/gameplay reviewer','human_native_reviewer':False,'assessment_kind':'agent-reviewed only'}
bgnotes=[
'Tower access, supply, defeat/repel condition, ammo warning and restart/save recovery retained.',
'Fortifications test imperative retained.', 'Approaching exercise enemy and accessible supplied tower retained.',
'Hold outcome, blocking suppliers and recovery retained.', 'Fortification test marker retained.',
'Guard-zone and flag-tactics topic retained.', 'Scout, prepare guard zone, defend, counterattack sequence retained.',
'Requested unit staffing and radius work area retained; no direct unit-control promise.',
'Placement, requested explorer count, fog and eating retained; automatic-request clause needs correction.',
'Enemy-base scouting objective retained.', 'Enemy-base flag and one requested explorer retained.',
'Fog visibility and eating retained; automatic-request clause needs correction.',
'Enemy-base scouting marker retained.',
'Guard painting, two arrivals, four minimum tiles, idle attraction and other zone functions retained.',
'Guard-zone preparation objective retained.', 'Marked guard area and two warriors reaching it retained.',
'Flags/Guard controls, four minimum tiles, idle attraction and forbidden/clearing distinction retained.',
'Guard-zone preparation marker retained.',
'Enemy attack, covered guard zone, supplied Inns, two raiders, retreat/eating and recovery retained; covered wording could be clearer editorially.',
'Exercise attack repel objective retained.', 'Enemy attack, defended guard zone and supplied Inns retained.',
'Attack after preparation, both raiders, retreat, eating and recovery retained.', 'Exercise attack repel marker retained.',
'War Flag on named Swarm building, three warriors, radius <=4, competing guard staffing and food retained.',
'Focused counterattack objective retained.', 'Swarm-building target, three requested warriors and radius <=4 retained.',
'Competing guard/war-flag requests, guard removal and available food retained.', 'Focused counterattack marker retained.',
'Hospital build path, access and requested builders retained.', 'Wounded worker heals at Hospital retained.',
'Racetrack build path and edge clearance retained; existing native Racetrack glossary is Хиподрум.',
'Worker finishes Racetrack training retained.', 'Swimming Pool placement west of pond retained.',
'Worker learning swimming retained.', 'School build and wood/algae builders retained.',
'School build and wood/algae builders retained.', 'Worker finishes School training retained.',
'Select Racetrack/Upgrade and trained builders retained.', 'Training at upgraded Racetrack retained.',
'Tower build and marked location retained.', 'Exactly two walls and west access lane retained.',
'Tower suppliers and waiting for two stone retained.', 'Keep tower supplied against attacker retained.',
'Flags/Exploration, enemy location and one requested explorer retained.',
'Flags/Guard, four tiles and two arriving warriors retained.', 'Hold guard area and supply Inns retained.',
'War Flag target is Swarm building; three warriors and <=4 radius retained.',
'Attack location marker retained.', 'Grassland terrain setting retained.', 'Rocky hill landform retained.',
'Wildlife trail sense retained; no computer-game trail mistranslation.', 'Fish quantity retained.',
'Message disclosure label and arrow retained.', 'Camp-site quantity retained.', 'Compilation success retained.',
'Caller line and column numbers plus diagnostic message retained and clarified.',
'Compilation failure plus line/column/position/message tuple retained.', 'Compilation failure diagnostic retained.',
'Failed script loading from path retained.', 'Failed script saving to path retained.',
'Line and column cursor location retained.', 'Game termination reason retained.',
'Embedded JavaScript and resource review before restarting retained.', 'Standing order needs attention and paused state retained.',
'Connection change, paused orders review and resume retained.',
'Reconnection needs fresh instruction; cancel or commander replacement choices retained.',
'Failed confirmation and standing-order review before resume retained.',
'Previous order still sending, preserved message and commander retry retained.', 'Order receipt plus supplied text retained.',
'No confirmation, preserved message and commander retry retained.',
'Update failure, pause on this device and corresponding control retry retained.',
'Shared AI strategy selector for all computer colonies retained; computer-controlled wording is optional clarity.'
]
bnnotes=[
'Technical script compilation success retained; matches existing সংকলন glossary.',
'Location suffix attaches to diagnostic %2 instead of source location; correct explicit line/column structure.',
'Technical compilation failure and complete line/column/position/message tuple retained.',
'Technical compilation failure plus diagnostic retained.', 'Script loading from supplied path failed retained.',
'Script saving to supplied path failed retained.', 'Cursor line and column retained.',
'Game stopped and diagnostic retained.', 'Embedded JavaScript resource-use review before restart retained.',
'Native means built-in fallback landscape here, not natural landscape; correct mistranslation.',
'Standing order needing attention and paused state retained.', 'Connection change, paused-order review and resume retained.',
'Reconnection/fresh instruction and cancel/commander replacement choices retained.',
'Failed order confirmation and standing-order review before resume retained.',
'Previous sending state, kept message and commander retry retained.', 'Order receipt plus parameter retained.',
'Unconfirmed order, kept message and commander retry retained.',
'Update failure and local pause retained, but control-specific retry omitted; restore it.',
'Soundtrack artist metadata; শিল্পী covers music creator/performer and is correct.'
]
changes={
'bg':{
'[lesson defensive-tactics scout hint]':('Поставете разузнавателен флаг във вражеската база; заявете 1 разузнавач. Флаговете автоматично заявяват единици. Разузнавачът разкрива текущите действия зад мъглата на войната; може да спре, за да се нахрани.','Autonomously modifies flags requesting units in English; target shifts it to units acting independently and omits automatic requests.'),
'[lesson defensive-tactics scout help]':('Флаговете автоматично заявяват единици. Разузнавачът разкрива текущите действия зад мъглата на войната; може да спре, за да се нахрани.','Autonomously modifies flags requesting units in English; target shifts it to units acting independently and omits automatic requests.')},
'bn':{
'[script error at %0:%1: %2]':('লাইন %0, কলাম %1-এ ত্রুটি: %2','Current suffix -এ attaches to %2 diagnostic, misidentifying error location; caller confirms %0=line %1=column %2=message.'),
'[missing map generator %0]':('মানচিত্র জেনারেটর অনুপস্থিত: %0। একটি অন্তর্নির্মিত ভূদৃশ্য নির্বাচন করা হয়েছে।','Natural ভূদৃশ্য is not built-in native fallback; preferences fallback selects compiled generator.'),
'[hive standing order update failed]':('স্থায়ী অর্ডার আপডেট ব্যর্থ হয়েছে। আপনার অর্ডারটি স্থানীয়ভাবে স্থগিত করা হয়েছে; সংশ্লিষ্ট নিয়ন্ত্রণটি আবার ব্যবহার করুন।','Target omits retry the control, leaving only generic retry; actual caller concerns specific standing-order pause/remove/resume control.')}
}
for locale,packet,notes in [('bg','bg-full-affected-batches-review-input.json',bgnotes),('bn','bn-delta-review-input.json',bnnotes)]:
 p=Path('artifacts/bulgarian/kit-v7')/packet; d=json.loads(p.read_text());print(locale,len(notes),len(d['entries']));assert len(notes)==len(d['entries'])
 entries=[]
 for e,n in zip(d['entries'],notes):
  x=dict(e); tokens=re.findall(r'%\d+|\{[A-Za-z_]\w*\}',e['source'])
  x.update(source_sha256=sha(e['source']),target_sha256=sha(e['target']),identity_sha256=sha(canon([e['id'],e['source'],e['target']])),actual_fresh_complete_source_target_read=True,semantic_assessment=n,protected_tokens_preserved=all(e['target'].count(t)==e['source'].count(t) for t in tokens),findings=[],status='no_semantic_blocker')
  if e['key'] in changes[locale]:
   target,finding=changes[locale][e['key']];x.update(status='proposed_edit',proposed_target=target,finding=finding)
  if locale=='bn' and e['key']=='Artist': callers=['platform/apps/web/src/music/Library.tsx:716-730']
  elif e['key'].startswith('[hive '):callers=['src/ui/HiveReportText.h:15-24','src/hive/HiveClient.cpp:595-623']
  elif e['key'].startswith('[script '):callers=['src/scripting/map/ScriptEditorScreen.cpp:190-245']
  elif 'missing map' in e['key']:callers=['src/game/screens/CustomGameScreen.cpp:143-150','src/game/rules/CustomGamePreferences.h:250-265']
  elif 'AI for all' in e['key']:callers=['src/game/screens/CustomGameScreen.cpp:1484-1504']
  elif e['key'].startswith('[lesson '):callers=['src/tutorial/IntroductionTest.cpp:445-483','data/generators/training/lessons/defensive-tactics.js','data/generators/training/lessons/fortifications.js']
  elif e['key'] in ['[Grassland]','[Kopjes]','[Game trails]','[Fish amount]','[Camp-site amount]']:callers=['src/map/generator/generators/SavannahGenerator.cpp:388-410,875-892']
  else:callers=['frozen English source; native UI label/diagnostic context']
  x['caller_evidence']=callers;entries.append(x)
 out={'reviewer_identity':identity,'packet_path':str(p),'packet_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_sha256':d['source_sha256'],'catalog_sha256':d['catalog_sha256'],'hash_scheme':'SHA256 exact UTF8 strings; identity SHA256 canonical JSON [id,source,target] ensure_ascii=false sort_keys=true separators=(comma,colon). Packet hashes exact bytes.','coverage':{'expected':len(entries),'actual_fresh_complete_pairs_read':len(entries),'proposed_edits':len(changes[locale]),'no_semantic_blocker':len(entries)-len(changes[locale]),'native':sum(x['surface']=='native' for x in entries),'online':sum(x['surface']=='online' for x in entries)},'status':'proposals_pending_editor_and_full_final_semantic_recheck','limits':['Independent agent review only; no native-human certification.','Every final pair must be rechecked after editorial changes; initial review grants no final approval.','No tracked source edits, builds, or provider calls performed.'],'terminology_evidence':{'brief':'artifacts/bulgarian/linguistics/semantic-language-brief.md','catalogs_independently_read':['data/texts.bn.txt','data/texts.ru.txt','data/texts.uk.txt','data/texts.sr.txt','data/texts.fr.txt','data/texts.de.txt'],'notes':'Existing Swarm/Racetrack/Flags/Guard/Compile/commander labels checked; French/German/Slavic built-in landscape translations corroborate English caller, not authority over it.'},'entries':entries}
 (D/f'v7-semantic-{locale}{len(entries)}-initial.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(locale,len(entries),len(changes[locale]))
