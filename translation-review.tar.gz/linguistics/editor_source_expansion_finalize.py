import json,re,hashlib
from pathlib import Path
P=Path('artifacts/bulgarian');O=P/'linguistics';K=P/'kit-v2'
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
en=json.load(open(K/'source/online.json'));bg=json.load(open(K/'drafts/bg/bg.json'));ne=json.load(open(K/'source/native.json'));nb=dict(re.findall(r'^(\[[^\n]+\])\n([^\n]*)',Path(K/'drafts/bg/texts.bg.txt').read_text(),re.M))
a=json.load(open(O/'editor-online-final-examined.json'));n=json.load(open(O/'editor-native-final-examined.json'));assert len(a)==2836 and len(n)==3393
oldkeys={r['key'] for r in a};newkeys=['Artist','Beginner-friendly','Defensive','Economy','Expansion','Experimental','Rush'];new=[];nnew=[]
assert set(en)-oldkeys==set(newkeys)
for r in a:
 k=r['key'];assert digest(en[k])==r['source_sha256'] and digest(bg[k])==r['target_sha256'],k
 r['source_expansion_method']='unchanged-source-and-target-exact-hash-carryforward';r['source_expansion_proof']='source-expansion-v1/linguistics/editor-online-final-examined.json'
reasons={'Artist':'Music creator/performance metadata field: Изпълнител is the Bulgarian music-artist term, not visual-art художник. Short noun label matches existing music search.','Rush':'Ранна атака clearly names early offensive pressure without gamer transliteration. Concise two-word tag.','Defensive':'Отбранителен describes the masculine ИИ/controller/opponent consistently with existing Балансиран.','Experimental':'Експериментален describes masculine ИИ/controller/opponent consistently with Балансиран.','Beginner-friendly':'Подходящ за начинаещи agrees with masculine ИИ/controller/opponent. Clear brief badge.','Economy':'Икономика is a concise standard taxonomy noun for economic strategy.','Expansion':'Разширяване is a concise noun for expansion strategy.'}
for k in newkeys:
 r=dict(surface='online',key=k,source=en[k],target=bg[k],source_sha256=digest(en[k]),target_sha256=digest(bg[k]),result='acceptable',role='editorial',method='actual-final-source-expansion7-reread',reason=reasons[k]);a.append(r);new.append(r)
rev={'[Beginner-friendly]','[Defensive]','[Experimental]','[Rush]'}
for r in n:
 k=r['key'];assert digest(ne[k])==r['source_sha256'],k
 if k in rev:
  r.update(target=nb[k],target_sha256=digest(nb[k]),result='acceptable',method='actual-source-expansion-native4-reread',reason=reasons[k[1:-1]]);nnew.append(r)
 else:
  assert digest(nb[k])==r['target_sha256'],k
  r['source_expansion_method']='unchanged-source-and-target-exact-hash-carryforward';r['source_expansion_proof']='source-expansion-v1/linguistics/editor-native-final-examined.json'
(O/'editor-online-final-examined.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');(O/'editor-native-final-examined.json').write_text(json.dumps(n,ensure_ascii=False,indent=2)+'\n');(O/'editor-source-expansion7-final-examined.json').write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n');(O/'editor-source-expansion-native4-reread.json').write_text(json.dumps(nnew,ensure_ascii=False,indent=2)+'\n');(O/'editor-source-expansion-residual-findings.json').write_text('[]\n')
s=json.load(open(O/'editor-final-summary.json'));s.update(native_keys=3393,online_keys=2843,total_keys=6236,active_kit='kit-v2',outstanding_findings=0,source_expansion=dict(new_online_keys_actually_read=7,native_targets_actually_reread=4,old_online2836='Exact source/target hash carryforward; no fresh reading claimed.',native3389='Exact source/target hash carryforward; no fresh reading claimed.',original_proof_snapshot='source-expansion-v1/linguistics',context_read=['platform/apps/web/src/messages.ts:4','platform/apps/web/src/pages/Ais.tsx:126','platform/apps/web/src/pages/Ais.tsx:339','platform/apps/web/src/pages/Ais.tsx:488','platform/apps/web/src/music/Library.tsx:691']))
s['file_sha256']={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [K/'drafts/bg/texts.bg.txt',K/'drafts/bg/bg.json']}
for f in ['editor-source-expansion7-final-examined.json','editor-source-expansion-native4-reread.json','editor-source-expansion-residual-findings.json']:
 if f not in s['evidence']:s['evidence'].append(f)
(O/'editor-final-summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n');print(len(a),len(n));print(json.dumps(s['file_sha256']))
