import json,hashlib
from pathlib import Path
P=Path('artifacts/bulgarian/linguistics');old=json.load(open('artifacts/bulgarian/source-expansion-v1/linguistics/semantic-online-final-examined.json'));assert len(old)==2836
source=json.load(open('platform/packages/i18n/locales/en.json'));target=json.load(open('artifacts/bulgarian/kit-v2/drafts/bg/bg.json'));live=json.load(open('platform/packages/i18n/locales/bg.json'));assert len(source)==len(target)==2843
h=lambda v:hashlib.sha256((json.dumps(v,ensure_ascii=False,sort_keys=True)if isinstance(v,dict)else v).encode()).hexdigest()
for x in old:
 assert source[x['key']]==x['source'] and target[x['key']]==live[x['key']]==x['target'],x['key']
 x['source_expansion_carryforward']='Exact source and target unchanged from archived 2836-key final semantic proof; no fresh reading claimed.'
rationale={
'Rush':'Approved canonical strategy tag: Ръш is the established RTS early-attack loanword already used by the native AI library. Category identifies aggressive early pressure, not speed of animation.',
'Defensive':'Approved strategy tag: Защитна denotes defensive strategy. Standalone badge/filter/category, same native canonical context.',
'Economy':'Approved strategy tag: Икономика denotes economic development and food/workforce planning rather than thrift or a subscription plan.',
'Expansion':'Approved strategy tag: Разширяване denotes colony expansion, not a downloadable expansion pack.',
'Experimental':'Approved tag: Експериментално denotes experimental AI status/strategy, same native canonical context.',
'Beginner-friendly':'Approved tag: Подходящо за начинаещи conveys suitability for beginning players, not child-specific or an absolute difficulty guarantee.',
'Artist':'Approved music metadata label: Изпълнител names the musical artist in the title/artist/description/licence publishing form; avoids visual-art-only художник.'}
new=[]
for k,reason in rationale.items():
 assert k not in {x['key']for x in old};assert live[k]==target[k]
 new.append(dict(surface='online',key=k,source=source[k],target=target[k],source_sha256=h(source[k]),target_sha256=h(target[k]),result='acceptable',method='explicit_new_ui_source_reading',rationale=reason,role='semantic-gameplay'))
P.joinpath('semantic-online-expansion7-examined.json').write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n');P.joinpath('semantic-online-expansion7-findings.json').write_text('[]\n');P.joinpath('semantic-online-final-examined.json').write_text(json.dumps(old+new,ensure_ascii=False,indent=2)+'\n')
# Balanced was already in the old reviewed source inventory; explicitly rechecked in the newly wired AI context.
x=next(x for x in old if x['key']=='Balanced');P.joinpath('semantic-balanced-ai-context.json').write_text(json.dumps(dict(x,rationale='Explicitly reread Ais.tsx tag selector/list badges/detail badges and messages.ts aiTagLabel. Балансиран is a natural standalone balanced-AI descriptor, with unchanged canonical wire tag.'),ensure_ascii=False,indent=2)+'\n')
paths=['data/texts.en.txt','platform/packages/i18n/locales/en.json','artifacts/bulgarian/kit-v2/manifest.json','artifacts/bulgarian/kit-v2/drafts/bg/texts.bg.txt','artifacts/bulgarian/kit-v2/drafts/bg/bg.json','data/texts.bg.txt','platform/packages/i18n/locales/bg.json'];P.joinpath('semantic-final-file-hashes.json').write_text(json.dumps({f:hashlib.sha256(Path(f).read_bytes()).hexdigest()for f in paths},indent=2)+'\n')
print('2843 bound: old2836 exact carryforward, new7 explicitly read. Native3393 unchanged. Total6236.')
