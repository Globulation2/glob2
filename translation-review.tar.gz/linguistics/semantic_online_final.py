import json,hashlib
from pathlib import Path
P=Path('artifacts/bulgarian/linguistics');old=json.load(open(P/'semantic-online-examined.json'));fix={x['key']:x['value']for x in json.load(open(P/'semantic-online-findings.json'))};delta={x['key']:x['current']for x in json.load(open(P/'semantic-online-delta.json'))};t=json.load(open('artifacts/bulgarian/kit/drafts/bg/bg.json'));rows=[];unseen=[]
def h(v):return hashlib.sha256((json.dumps(v,ensure_ascii=False,sort_keys=True)if isinstance(v,dict)else v).encode()).hexdigest()
for x in old:
 k=x['key'];v=t[k]
 if v==x['target']:method='carryforward_exact_source_target_hash'
 elif v==fix.get(k):method='authored_and_examined_semantic_replacement_exact_hash'
 elif v==delta.get(k):method='explicit_editor_delta_reread'
 else:unseen.append((k,v));continue
 rows.append(dict(surface='online',key=k,source_sha256=x['source_sha256'],target_sha256=h(v),source=x['source'],target=v,result='acceptable',method=method,role='semantic-gameplay'))
assert not unseen,unseen
P.joinpath('semantic-online-final-examined.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');P.joinpath('semantic-online-final-findings.json').write_text('[]\n');print(len(rows));print({k:sum(x['method']==k for x in rows)for k in set(x['method']for x in rows)})
