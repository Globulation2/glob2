import json,hashlib,re,collections
from pathlib import Path
base=Path('artifacts/bulgarian')
fixbg={
0:('Приближава воин от учебния противник. Поддържайте кулата снабдена и достъпна. Удържайте позицията, докато нападателят не бъде победен или отблъснат. Стена, която блокира снабдителите, може да лиши кулата от боеприпаси. Ако колонията се провали, рестартирайте или заредете по-ранна записана игра.','Natural practice-enemy phrasing; complete hold-position imperative, with attacker vocabulary consistent with other defense text.'),
2:('Приближава воин от учебния противник. Поддържайте кулата снабдена и достъпна.','Remove unnatural учебен вражески воин adjective stack.'),
3:('Удържайте позицията, докато нападателят не бъде победен или отблъснат. Стена, която блокира снабдителите, може да лиши кулата от боеприпаси. Ако колонията се провали, рестартирайте или заредете по-ранна записана игра.','Complete hold-position imperative; align repeated help/hint.'),
5:('Зони за охрана и тактики с флагове','Bulgarian instrumental preposition for tactics using flags.'),
7:('Разузнахте, защитихте зона за охрана и насочихте контраатака. Заявеният брой при флаговете определя търсените единици; радиусът определя къде работят те.','Use established guard-zone term rather than guarded area.'),
14:('Подгответе зона за охрана','Use existing guard-area terminology.'),
15:('Очертайте зона за охрана в маркираната област и оставете 2 воини да я достигнат.','Align repeated hint/instruction and guard-area term.'),
16:('Отворете „Флагове“, изберете „Охрана“ и оцветете поне 4 клетки в областта. Зоните за охрана привличат незаети воини. Забранените зони блокират придвижването; зоните за разчистване заявяват премахване на ресурси.','Align repeated help/hint: cells and guard zones use established terms.'),
17:('Подгответе зона за охрана','Align marker/title terminology.'),
18:('Врагът атакува. Защитавайте зоната за охрана и поддържайте хановете снабдени. Малката атака започва след вашите приготовления. Победете или отблъснете и двамата нападатели; ранените врагове могат да се оттеглят. Воините могат временно да напуснат, за да се хранят. Ако защитата се провали, използвайте по-ранна записана игра или рестартирайте.','Avoid literal покрита for defensive coverage; keep named zone consistent.'),
20:('Врагът атакува. Защитавайте зоната за охрана и поддържайте хановете снабдени.','Align instruction with full hint; established guard-zone terminology.'),
23:('Поставете боен флаг над вражеския рояк; поискайте 3 воини и използвайте радиус 4 или по-малък. Зоните за охрана и бойните флагове се конкурират за воини. Премахнете клетките за охрана, ако те задържат армията ви. Осигурявайте храна, докато воините пътуват и атакуват.','Replace inconsistent literal tiles with cells and awkward food availability calque with natural verb.'),
24:('Насочете съсредоточена контраатака','Natural military phrasing instead of фокусирана calque.'),
26:('Зоните за охрана и бойните флагове се конкурират за воини. Премахнете клетките за охрана, ако те задържат армията ви. Осигурявайте храна, докато воините пътуват и атакуват.','Align repeated help/hint and natural cell/food phrasing.'),
27:('Насочете съсредоточена контраатака','Align marker with title.'),
36:('Нека работникът завърши обучението си в училището.','Natural reference to training at named game building rather than generic school education.'),
41:('Изберете кулата → снабдители. Изчакайте 2 камъка.','Definite article for already built tower; retain count form камъка.'),
42:('Снабдявайте кулата, докато отблъсква нападателя.','Remove unidiomatic снабдена срещу; express ongoing supply during defense.'),
44:('Флагове → Охрана. Оцветете 4 клетки; нека пристигнат 2 воини.','Consistent map-cell terminology and unchanged person plural воини.'),
53:('Брой лагери','Countable camps require брой rather than количество.'),
71:('ИИ за всички компютърни колонии','Use established Bulgarian AI abbreviation ИИ from main AI label.')}
fixbn={
2:('সংকলন ব্যর্থ: %0:%1:(%2):%3','Use established সংকলন term; remove unnatural failure noun and pre-colon space.'),
3:('সংকলন ব্যর্থ হয়েছে: %0','Use established compile terminology consistent with compile button and success.'),
4:('%0 থেকে স্ক্রিপ্ট লোড করা যায়নি','Natural Bengali failed-action construction.'),
5:('%0-এ স্ক্রিপ্ট সংরক্ষণ করা যায়নি','Natural Bengali failed-action construction.'),
12:('পুনরায় সংযোগ করার পর একটি স্থায়ী আদেশের জন্য নতুন নির্দেশ প্রয়োজন। আপনি এটি বাতিল করতে পারেন অথবা কমান্ডারকে এটি প্রতিস্থাপন করতে বলতে পারেন।','Current instruction requirement, avoiding generic habitual প্রয়োজন হয়.'),
13:('একটি আদেশ নিশ্চিত করা যায়নি। পুনরায় শুরু করার আগে আপনার স্থায়ী আদেশগুলো পর্যালোচনা করুন।','Use আদেশ consistently for commander/game orders rather than commercial অর্ডার.'),
14:('আপনার আগের আদেশটি এখনও পাঠানো হচ্ছে। এই বার্তাটি সংরক্ষণ করা হয়েছে; এটি আবার পাঠাতে কমান্ডার খুলুন।','Consistent game order term; natural saved-message wording and concise command.'),
15:('আদেশ পাওয়া গেছে: %0','Consistent game order term and natural receipt status.'),
16:('আদেশ নিশ্চিত করা হয়নি। আবার চেষ্টা করতে কমান্ডার খুলুন; আপনার বার্তাটি সংরক্ষণ করা হয়েছে।','Consistent game order term and compact retry imperative.'),
17:('স্থায়ী আদেশ আপডেট ব্যর্থ হয়েছে। আপনার আদেশটি স্থানীয়ভাবে স্থগিত করা হয়েছে; সংশ্লিষ্ট নিয়ন্ত্রণটি আবার ব্যবহার করুন।','Consistent game order term; preserve semantic fix identifying the control.')}
def hs(x):return hashlib.sha256((x if isinstance(x,str) else json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))).encode()).hexdigest()
for l,fix,n in [('bg',fixbg,72),('bn',fixbn,19)]:
 p=base/f'kit-v7/{l}-after-semantic-review-input.json';d=json.loads(p.read_text()); entries=[]
 assert len(d['entries'])==n
 for i,e in enumerate(d['entries']):
  e=dict(e);e.update(review_index=i,source_sha256=hs(e['source']),target_sha256=hs(e['target']),identity_sha256=hs([e['id'],e['source'],e['target']]),actual_fresh_complete_source_target_read=True,final_fresh_read=False,verdict='changes_requested' if i in fix else 'approve_current_pair',editorial_review=fix[i][1] if i in fix else 'Complete post-semantic source/target pair freshly read; grammar, terminology, register, punctuation, numeric forms and textual compactness accepted.',proposed_target=fix[i][0] if i in fix else None)
  e['token_multiset_equal']=collections.Counter(re.findall(r'%\d+|\{\{.*?\}\}',e['source']))==collections.Counter(re.findall(r'%\d+|\{\{.*?\}\}',e.get('proposed_target') or e['target']))
  assert e['token_multiset_equal'];entries.append(e)
 out={'reviewer_identity':{'agent':'/root/v7_editor','role':'Independent Bulgarian/Bengali grammar and style editor','model_identity':'Codex GPT-6-family agent; no external provider/model calls','assessment_kind':'agent-reviewed only','human_native_reviewer':False},'locale':l,'source_sha256':d['source_sha256'],'catalog_sha256':d['catalog_sha256'],'packet_path':str(p),'packet_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'hash_scheme':'SHA256 exact UTF8 strings; objects and identity [id,source,target] use canonical ensure_ascii=false sorted compact JSON. Packet hashes exact bytes.','batch_ids':sorted(set(e['batch_id'] for e in entries)),'coverage':{'expected':n,'reviewed':n,'actual_fresh_complete_pairs_read':n,'changes_requested':len(fix),'accepted_current_pairs':n-len(fix),'plural_objects':sum(isinstance(e['target'],dict) for e in entries)},'method':'Independent complete grammar/style review AFTER five semantic corrections integrated. Every literal source/current target pair freshly read; no inherited V6 approval. Reviewed all affected entries including long and compact duplicates, articles/counts, placeholder order, idiom, established glossary and label compactness.','references':['artifacts/bulgarian/linguistics/semantic-language-brief.md','artifacts/bulgarian/kit-v3/references/texts.{ru,uk,sr,fr,de}.txt','data/texts.bg.txt [AI], [guard area], [Cell size]','data/texts.bn.txt [compile]'],'limits':['Agent review only; no native-human certification.','No visual fit or physical-device validation asserted.','Proposed targets require integration and exact final complete reread, then final semantic and adversarial review.','No tracked source/catalog edits, builds or provider calls performed.'],'entries':entries}
 q=base/f'linguistics/v7-editor-{l}{n}.json';q.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(q,len(fix),hashlib.sha256(q.read_bytes()).hexdigest())
