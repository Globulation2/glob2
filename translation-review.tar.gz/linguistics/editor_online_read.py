exec(open('artifacts/bulgarian/linguistics/editor_review.py').read().split("if __name__")[0])
for i,r in enumerate(rows()[int(sys.argv[1]):int(sys.argv[2])],int(sys.argv[1])):print(str(i)+' '+r['key']+' => '+json.dumps(r['target'],ensure_ascii=False))
