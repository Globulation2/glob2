exec(open('artifacts/bulgarian/linguistics/editor_review.py').read().split("if __name__")[0])
old={(r['surface'],r['key']):r for r in json.load(open(OUT/'editor-examined.json'))}
changed=[r for r in rows() if r['surface']=='native' and digest(r['target'])!=old[(r['surface'],r['key'])]['target_sha256']]
(OUT/'editor-native-final-delta.json').write_text(json.dumps(changed,ensure_ascii=False,indent=2)+'\n')
for i,r in enumerate(changed[int(sys.argv[1]):int(sys.argv[2])],int(sys.argv[1])):print(str(i)+' '+r['key']+'\n'+json.dumps(r['target'],ensure_ascii=False))
print('TOTAL DELTA',len(changed))
