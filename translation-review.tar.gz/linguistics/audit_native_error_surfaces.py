from pathlib import Path
import re,json,hashlib,collections,subprocess
P=Path('artifacts/bulgarian/linguistics');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
# Every .what() source line was reviewed in the initial rg inventory; record all
# occurrences, including repeated uses on one line, and their raw context.
rows=[]
for f in sorted(Path('src').rglob('*')):
 if not f.is_file() or f.suffix not in ('.cpp','.h','.mm','.c'):continue
 lines=f.read_text(errors='replace').splitlines();name=str(f)
 for i,line in enumerate(lines):
  count=len(re.findall(r'\.what\s*\(',line))
  if not count:continue
  if any(s in name for s in ('Test','Harness','Benchmark')):cat='test_harness_benchmark';reason='Assertions, test diagnostics or explicitly invoked benchmark; no ordinary player notice here.'
  elif '/app/cli/' in name:cat='cli';reason='Command-line/tool output, preserve diagnostic contract.'
  elif '/relay/' in name:cat='service_diagnostic';reason='Relay service error/log payload, not native player UI rendering.'
  elif any(s in line for s in ('std::cerr','std::cout','fprintf(','SDL_Log','cerr <<','logLine(')):cat='log_only';reason='Explicit log/console sink at this line. Other propagated copies are inventoried separately.'
  elif name=='src/ui/PresentedError.h' or 'musicError(' in line:cat='localized_boundary_already';reason='Existing marker/summary presenter or musicError logs raw and localizes primary notice.'
  elif any(s in name for s in ('SettingsScreenCustomGenerators','ScriptEditorScreen','MapEditFlows','MapEditDelegate','SetLibraryDialog','LANFindScreen','LANMenuScreen','GameLoadScreen')):cat='remaining_player_boundary';reason='Raw exception enters a player-facing notice, status or eventual failureMessage; included in boundary report.'
  elif name.endswith('CustomGameScreen.cpp'):cat='remaining_player_boundary';reason='Catch assigns raw exception prose to message shown in Custom Game.'
  elif name.endswith('GameSessionScreen.cpp') and 'MessageScreen' in line:cat='remaining_player_boundary';reason='Raw script-session failure concatenated into hardcoded English modal.'
  elif name.endswith('GeneratorStudioScreen.cpp') or ('GameSessionScreen.cpp' in name and 'studioError' in line):cat='raw_authoring_report';reason='Raw machine-readable authoring report/bridge diagnostic; native catch does not draw it. Preserve report, handle actual UI consumer separately.'
  elif name.startswith('src/mcp/'):
   cat='upstream_to_mcp_settings' if name.endswith('UIService.cpp') and 'failure =' in line else 'developer_tool_result'
   reason='Listener failure is displayed by SettingsScreenMCP::failureReason.' if cat=='upstream_to_mcp_settings' else 'MCP protocol/tool result, not a direct player screen; preserve API diagnostic.'
  elif '/field/' in name:cat='upstream_to_gradient_settings';reason='Accelerator status error is displayed in SettingsScreenGeneral350; change display boundary, preserve status.'
  elif name.endswith('OnlineMatch.cpp'):cat='upstream_to_match_start';reason='Raw fail() state consumed by MatchStartScreen138; keep model state, present there.'
  elif name.endswith('LanClient.cpp'):cat='upstream_to_lan_close';reason='Malformed protocol exception closes client; detail enters LanRoom describeClose unknown/detail slot.'
  elif name.endswith('MusicLibrary.cpp'):cat='upstream_to_existing_music_presenter';reason='ImportJob error flows to existing musicError boundary.'
  elif any(s in name for s in ('EngineInit','EngineLoaders','MapIO','BuildingCatalog')):cat='upstream_load_or_validation';reason='Raw model/load diagnostic; presentation covered by load/import/library boundary list, not direct translation in simulation code.'
  elif name.endswith('PlatformRoom.cpp'):cat='raw_diagnostic_state_only';reason='Private problem capture at applyDraft, no player event at that catch; other actual events audited separately.'
  else:cat='diagnostic_propagation';reason='Exception is forwarded through runtime, generator, transport or report state, not directly rendered at this line. Related ordinary UI consumers traced separately; no blanket technical-prose exemption.'
  rows.append({'file':name,'line':i+1,'occurrences':count,'statement':line.strip(),'context':'\n'.join(lines[max(0,i-2):i+3]),'category':cat,'reason':reason,'source_sha256':h(f)})
assert len(rows)==176 and sum(x['occurrences']for x in rows)==180
P.joinpath('semantic-native-what-inventory.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'lines':176,'occurrences':180,'method':'All src C/C++/ObjC source/header .what( occurrences, line text inspected; potentially visible collectors and raw assignment sinks traced into actual screen/render consumers. Tests/logs/CLI retained separately.','category_line_counts':dict(collections.Counter(x['category']for x in rows)),'entries':rows},ensure_ascii=False,indent=2)+'\n')
