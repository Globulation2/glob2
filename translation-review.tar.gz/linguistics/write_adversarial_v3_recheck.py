import pathlib,json,hashlib,re,collections
root=pathlib.Path('artifacts/bulgarian');kit=root/'kit-v3';out=root/'linguistics'
def sha(b):return hashlib.sha256(b).hexdigest()
def tsh(s):return sha(s.encode('utf-8'))
previous=out/'adversarial-v3-final-batches.json';before_raw=previous.read_bytes();before=json.loads(before_raw);old={e['key']:e for e in before['entries']}
candidate=kit/'changed-batches-final-candidate.json';current=json.loads(candidate.read_text());raw=(kit/'drafts/bg/texts.bg.txt').read_bytes()
assert sha(raw)==current['native_catalog_sha256']=='dbd1c1c47e5ef46e7e513a329d66e91228257458e70315c4193c0c4e7396444e'
assert current['source_sha256']==before['source_sha256']=='f8d14316709d155e55ce55a95f474763a34b22b897d0134494fb84aaf17e10ee'
source=json.loads((kit/'source/native.json').read_text());targets={};key=None
for line in raw.decode().splitlines():
 if line.startswith('[') and line.endswith(']'):key=line
 elif key is not None:targets[key]=line;key=None
reread={
 '[Kopjes]':'Скалисти хълмове accurately names the stone/granite hill features with scree flanks; natural Bulgarian noun label.',
 '[Grassland]':'Тревни площи accurately describes the percentage of dry plain covered in tall grass, without implying livestock pasture.',
 '[lesson fortifications walls compact]':'The revised imperative preserves building exactly2 walls and keeping the access corridor west of the tower clear. Natural polite plural, no new placeholder or mechanics change.',
 '[editor map shared]':'Completed successful-share confirmation is natural and parallel to the map-saved status. Онлайн preserves the destination.'}
entries=[];batches=[];resolved=[];unchanged=0
for b in current['batches']:
 path=kit/'batches'/(b['id']+'.json');assert sha(path.read_bytes())==b['source_batch_sha256'];batchsource={e['key']:e['source'] for e in json.loads(path.read_text())['entries']}
 batches.append({'id':b['id'],'source_batch_sha256':b['source_batch_sha256'],'entries':len(b['entries'])})
 for e in b['entries']:
  k=e['key'];prior=old[k];s=e['source'];t=e['translation'];assert source[k]==batchsource[k]==s==prior['source'];assert targets[k]==t
  assert collections.Counter(re.findall(r'%\d+',s))==collections.Counter(re.findall(r'%\d+',t))
  record={'id':e['id'],'surface':'native','batch':b['id'],'key':k,'source':s,'target':t,'key_sha256':tsh(k),'source_sha256':tsh(s),'target_sha256':tsh(t),'decision':'accept','new_key':prior.get('new_key',False)}
  if k in reread:
   assert t==prior['proposed_target'];record.update(review_method='Fresh targeted rereading of exact revised source/target and actual usage after prior full73-entry reading.',usage=prior['usage'],reason=reread[k])
   resolved.append({'key':k,'status':'resolved','severity':{'medium':'major','low':'minor'}[prior['severity']],'original_severity_label':prior['severity'],'severity_mapping':'Original medium→major, low→minor; no critical findings.','old_target':prior['target'],'final_target':t,'original_reason':prior['reason'],'resolution':reread[k],'usage':prior['usage'],'source_sha256':tsh(s),'target_sha256':tsh(t)})
  else:
   assert s==prior['source'] and t==prior['target'] and tsh(s)==prior['source_sha256'] and tsh(t)==prior['target_sha256'];unchanged+=1
   record.update(review_method='Exact unchanged source/target carryforward from this reviewer’s fresh73-entry reading.',prior_report_sha256=sha(before_raw),reason=prior['reason'])
  entries.append(record)
assert len(entries)==73 and len(resolved)==4 and unchanged==69 and sum(e['new_key'] for e in entries)==18
report={'schema_version':1,'reviewer':'adversarial_reviewer','source_sha256':current['source_sha256'],'candidate_file_sha256':sha(raw),'candidate_batch_file_sha256':sha(candidate.read_bytes()),'source_native_json_sha256':sha((kit/'source/native.json').read_bytes()),'prior_report':str(previous),'prior_report_sha256':sha(before_raw),'prior_report_preserved':True,'scope':'Complete73-entry changed-batch coverage from prior independent fresh reading plus fresh4-value usage rechecks.69 unchanged entries bound by exact source and target hashes. Other41 batches remain explicitly carried under prior review proofs and are not fresh readings.','native_human_certification':False,'serialization':'key/source/target SHA256 are raw UTF-8 decoded string bytes, no JSON quotes or trailing newline. File and batch SHA256 are exact file bytes.','batches':batches,'entries_covered':73,'new_keys_covered':18,'fresh_targeted_rereads':4,'unchanged_exact_carryforward':69,'resolved_findings':resolved,'unresolved_findings':[],'placeholder_mismatches':0,'english_identical_count':sum(e['source']==e['target'] for e in entries),'entries':entries}
path=out/'adversarial-v3-final-recheck.json';path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');assert previous.read_bytes()==before_raw
print(json.dumps({'report':str(path),'sha256':sha(path.read_bytes()),'candidate_file_sha256':sha(raw),'covered':73,'reread':4,'unchanged':69,'unresolved':0}))
