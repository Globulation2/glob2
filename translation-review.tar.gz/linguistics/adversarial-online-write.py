import json,hashlib
from pathlib import Path
base=Path('artifacts/bulgarian/linguistics');rows=json.load(open(base/'adversarial-online-snapshot.json'));fix=[]
def add(n,text,reason,severity='P2'):
 r=rows[n-1];fix.append(dict(key=r['key'],source=r['source'],target=r['target'],replacement=text,reason=reason,severity=severity,ordinal=n))
add(314,'Парична сума','Stripe finances report records monetary transactions, not physical cash. В брой wrongly means banknotes/coins.')
add(453,'Потвърдени парични суми','Stripe charge/refund statistics concern payments, not cash-in-hand.')
add(454,'Таблица на потвърдените парични суми','Match corrected heading and already correct surrounding financial explanation.', 'P3')
add(543,'Отчетено за текущия период','Overview.tsx column contains aggregate measured values for current period, not a recording/current record (Текущ запис).')
add(1459,'Отчетено за предишния период','Overview.tsx column contains measured totals for previous period, not an earlier recording.')
for n in [546,547]:
 r=rows[n-1]; old=r['target'];opening='Текущ и предишен отчетен период в дни: {slot0} и {slot1}.'
 def neutral(v):return opening+v[v.index(' Общата активност'):]
 add(n,{f:neutral(v) for f,v in old.items()} if isinstance(old,dict) else neutral(old),'Independent day values must not force the prior period to plural дни when it can be 1. Neutral period-in-days construction works for both placeholders and all plural branches.')
add(603,'Подробни тарифи за потреблението','Commander.tsx heading introduces credit prices per million tokens. Проценти на използване means usage percentages and misidentifies the pricing table.')
add(664,'Плъзнете, за да завъртите и наклоните · превъртете или щипнете, за да промените мащаба','Zoom includes both directions; увеличите мащаба narrows it to zoom in.')
add(782,'Пълен ключ за съвместимост: {slot0}','BuildingLibrary.tsx displays the complete simulation version key. Ключ за пълна съвместимост promises complete compatibility instead of saying that the key is complete.')
add(1196,'Забрана за чат за {slot0}','Accounts.tsx button invokes adminMute with a duration; this restricts messaging. Без звук suggests muting audio, which is a different action.')
add(1488,'Публично — показва се в списъците за всички','Public listing is discoverability, whereas unlisted content is also accessible to anyone with link. Достъпно за всички loses the discoverability distinction.')
for n in [1528,1529]:
 old=rows[n-1]['target']
 def price(v):return v.replace('за кеширани записи','за записи в кеша').replace('включително обосновка','включително разсъжденията')
 add(n,{f:price(v) for f,v in old.items()} if isinstance(old,dict) else price(old),'Cache writes are writes into the cache, not cached records. Reasoning tokens cover model reasoning rather than an explanatory justification delivered to the player. All branches retain exact placeholders.')
add(1552,'Уточнете неприключените резервации на кредити, преди да изтриете този проект.','Outstanding credit reservations are unresolved holds, not unpaid credit debt (непогасени кредитни резервации).')
add(2400,'проверка изисква','ValidationPanel.tsx assembles count + check needs + attention. Current imperative проверете нуждите produces 1 проверете нуждите внимание.')
add(2402,'проверки изискват','Plural fragment in the same assembled validation headline: N проверки изискват внимание, not проверките са необходими внимание.')
add(2419,'изтекло време за стартиране','Timeout status denotes failure after allowed time expired. Време за изчакване при стартиране describes a configured duration without indicating expiration.')
add(2674,'Валидирането в игровия двигател не бе успешно.','Validation tests the content using the game engine, not validation of the engine itself.')
add(2675,'Валидирането в игровия двигател е успешно','Content was validated by the engine; current на двигателя says engine itself passed validation.')
add(2676,'Валидирането в игровия двигател е успешно.','Same content validation status, with final punctuation.')
add(803,'Генерираният изходен код е приет като редакция {slot0}. Изпълнете проверки в игровия двигател преди публикуване.','Generated source here is code, not a generic source reference. Engine checks validate it in engine, rather than checking the engine.')
add(2663,'Заявките за програмиране използват до {value0} {value1} кредита. Приемането на изходния код не означава, че проверките в игровия двигател са преминали успешно.','The distinction is code acceptance versus testing in the engine, not tests of the engine.')
# English-identical entries were all individually inspected in their numbered contexts and in the final identical inventory.
def serial(v):return v if isinstance(v,str) else json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(v):return hashlib.sha256(serial(v).encode('utf-8')).hexdigest()
exam=[]
for r in rows:
 e=dict(ordinal=r['ordinal'],key=r['key'],source_sha256=sha(r['source']),target_sha256=sha(r['target']),status='examined',finding=any(x['key']==r['key'] for x in fix))
 if isinstance(r['target'],dict):e['plural_forms_examined']=list(r['target']);e['plural_form_sha256']={f:dict(source_sha256=sha(r['source'][f]),target_sha256=sha(v)) for f,v in r['target'].items()}
 if r['source']==r['target']:
  n=r['ordinal']; e['english_identical_disposition']=('intentional route/API/cache/MIME technical literal' if n in [53,54,2449,2467] else 'intentional exact licence identifier, preserve legal licence/version spelling' if n in [275,276,278,279,280,281,282,284] else 'intentional proper name, brand, language or standard technical abbreviation' if n in [315,830,853,1009,1013] else 'intentional conventional short confirmation button' if n==1334 else 'intentional symbolic/placeholder-only label, measurement, UI marker or version identifier; contains no translatable prose')
 exam.append(e)
json.dump(fix,open(base/'adversarial-online-findings.json','w'),ensure_ascii=False,indent=2)
json.dump(dict(reviewer='independent AI adversarial linguistic reviewer; no human certification',coverage='All 2836 online keys actually read in numbered source-target output; all 27 plural objects and all 54 branches inspected; 74 identical entries separately inventoried',hash_serialization='String: exact decoded value encoded UTF-8, no quotes, escaping, key or appended newline. Plural object: json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(comma,colon)), then UTF-8, no appended newline. Per-form hashes use raw decoded strings. Raw candidate file SHA256 is independent.',candidate_file_sha256=hashlib.sha256(Path('artifacts/bulgarian/kit/drafts/bg/bg.json').read_bytes()).hexdigest(),entries=exam),open(base/'adversarial-online-examined.json','w'),ensure_ascii=False,indent=2)
print('entries',len(exam),'plural',sum('plural_forms_examined'in e for e in exam),'identical',sum('english_identical_disposition'in e for e in exam),'findings',len(fix))
