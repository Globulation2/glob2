import json,hashlib,pathlib,re,collections
base=pathlib.Path('artifacts/bulgarian');kit=base/'kit-v3';out=base/'linguistics'
def sha(b):return hashlib.sha256(b).hexdigest()
def txtsha(t):return sha(t.encode('utf-8'))
candidate=kit/'changed-batches-final-candidate.json';d=json.loads(candidate.read_text());source=json.loads((kit/'source/native.json').read_text())
raw=(kit/'drafts/bg/texts.bg.txt').read_bytes();assert sha(raw)==d['native_catalog_sha256']=='b046b341db72065d3dfafb3f4ec2ea752fd14178c8892074bd82d7bd6dc58d5a'
lines=raw.decode().splitlines();targets={};key=None
for line in lines:
 if line.startswith('[') and line.endswith(']'):key=line
 elif key is not None:targets[key]=line;key=None
proposals={
 '[Kopjes]':('Скалисти хълмове','medium','The amount control places granite/stone hill cores and scree skirts. The opaque foreign transliteration does not explain the landform; all five frozen reference catalogs use rocky hills.','src/map/generator/generators/SavannahGenerator.cpp:435-463'),
 '[Grassland]':('Тревни площи','low','This percentage sets tall-grass coverage of the dry plain. Пасища implies pasture used for grazing, whereas the generator models grass cover and expansion friction.','src/map/generator/generators/SavannahGenerator.cpp:697-727'),
 '[lesson fortifications walls compact]':('Изградете 2 стени. Оставете прохода западно от кулата свободен.','medium','The instruction must preserve the access corridor beside the tower for suppliers. Лента на кулата suggests a strip belonging to the tower rather than the traversable lane west of it.','scripts/tutorials/fortifications.json:77-87,161,202'),
 '[editor map shared]':('Картата е споделена онлайн','low','This is the completed successful-share confirmation, parallel to Картата е запазена; the current noun phrase sounds like a description of a map.','src/map/editor/MapEditFlows.cpp:180-184')}
entries=[];batches=[];counter=0
for batch in d['batches']:
 bf=kit/'batches'/(batch['id']+'.json');assert sha(bf.read_bytes())==batch['source_batch_sha256'];bd=json.loads(bf.read_text());original={x['key']:x for x in bd['entries']}
 batches.append({'id':batch['id'],'source_batch_sha256':batch['source_batch_sha256'],'entries_read':len(batch['entries'])})
 for e in batch['entries']:
  counter+=1;k=e['key'];s=e['source'];t=e['translation'];assert source[k]==s==original[k]['source'];assert targets[k]==t
  assert collections.Counter(re.findall(r'%\d+',s))==collections.Counter(re.findall(r'%\d+',t)),k
  rec={'ordinal':counter,'batch':batch['id'],'surface':'native','key':k,'source':s,'target':t,'key_sha256':txtsha(k),'source_sha256':txtsha(s),'target_sha256':txtsha(t),'decision':'propose_change' if k in proposals else 'accept','reading':'Fresh independent reading of this exact source and target in the 73-entry changed batches.'}
  if k in proposals:
   replacement,severity,reason,context=proposals[k];rec.update(proposed_target=replacement,severity=severity,reason=reason,usage=context)
  elif 38<=counter<=54 or counter==73:
   if counter<=44:reason='Script-editor display wrapper preserves compilation outcome, line/column/path/diagnostic parameters; raw diagnostic content is supplied by the code.';context='staged src/scripting/map/ScriptEditorScreen.cpp:140-235,411-453'
   elif counter<=46:reason='Correctly reports a running session that was stopped, and advises reviewing embedded JavaScript/resource use before restarting.';context='staged src/game/screens/GameSessionScreen.cpp updateExecution catch Script::SessionFailure'
   elif counter<=54:reason='Persistent commander order meaning retained; pause/reconnect/retry/preserved-message outcome is accurate. Parameters remain exact code/user content.';context='staged src/ui/HiveReportText.h local report branches; staged src/hive/HiveClient.cpp local report call sites'
   else:reason='Missing generator identifier remains exact; message correctly states that a bundled landscape was selected as the fallback.';context='staged src/game/screens/CustomGameScreen.cpp:147'
   rec.update(reason=reason,usage=context,new_key=True)
  else:rec['reason']='Meaning, Bulgarian wording and mechanics agree with English and neighbouring controls/tutorial context; positional placeholders checked.'
  if s==t:rec['english_identical_disposition']='Intentional identifier or shared term checked in context.'
  entries.append(rec)
assert counter==73 and sum(x.get('new_key',False) for x in entries)==18
report={'schema_version':1,'reviewer':'adversarial_reviewer','scope':'Fresh independent reading of all 73 entries in final changed batches (54 general +19 maps), including all18 new native keys. Unchanged entries outside these batches retain prior exact-hash review; no claim of rereading them.','native_human_certification':False,'candidate_file_sha256':sha(raw),'source_sha256':d['source_sha256'],'candidate_batch_file_sha256':sha(candidate.read_bytes()),'source_native_json_sha256':sha((kit/'source/native.json').read_bytes()),'serialization':'key/source/target SHA256 are raw UTF-8 bytes of the decoded string, with no JSON quotes or newline. Catalog/batch hashes are exact file bytes.','batches':batches,'entries_read':73,'new_entries_read':18,'findings_count':4,'placeholder_mismatches':0,'english_identical_count':sum(x['source']==x['target'] for x in entries),'references':'English controls meaning; five frozen native reference catalogs sr/ru/uk/fr/de and semantic-language-brief.md consulted; other reviewers findings not read.','entries':entries}
(out/'adversarial-v3-final-batches.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
findings=[x for x in entries if x['decision']=='propose_change'];(out/'adversarial-v3-proposed-edits.json').write_text(json.dumps({'candidate_file_sha256':sha(raw),'findings':findings,'catalog_edits_applied':False},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'read':counter,'new':18,'findings':len(findings),'report_sha256':sha((out/'adversarial-v3-final-batches.json').read_bytes())}))
