exec(open('artifacts/bulgarian/linguistics/editor_review.py').read().split("if __name__")[0])
d=json.load(open(OUT/'editor-online-final-delta.json')); findings=[]
f={
'Colony still standing':'Колонията още съществува',
'By {slot0} · {slot1} terrain · {slot2} resources':{'one':'От {slot0} · {slot1} терен · ресурси: {slot2}','other':'От {slot0} · {slot1} терена · ресурси: {slot2}'},
'By {slot0} · {slot1} terrains · {slot2} resources':'От {slot0} · {slot1} терена · ресурси: {slot2}',
'{slot0} terrain · {slot1} resources · revision {slot2}':{'one':'{slot0} терен · ресурси: {slot1} · редакция {slot2}','other':'{slot0} терена · ресурси: {slot1} · редакция {slot2}'},
'{slot0} terrain · {slot1} resources · {slot2}':{'one':'{slot0} терен · ресурси: {slot1} · {slot2}','other':'{slot0} терена · ресурси: {slot1} · {slot2}'},
'{slot0} terrains · {slot1} resources · revision {slot2}':'{slot0} терена · ресурси: {slot1} · редакция {slot2}',
'{slot0} terrains · {slot1} resources · {slot2}':'{slot0} терена · ресурси: {slot1} · {slot2}',
}
for r in d:
 r.update(source_sha256=digest(r['source']),target_sha256=digest(r['target']),role='editorial',method='actual-final-delta-reread',result='finding' if r['key'] in f else 'acceptable')
 if r['key'] in f: findings.append(dict(surface='online',key=r['key'],original=r['target'],value=f[r['key']],reason='Final reread: independent resource count can be 1, so noun-before-count avoids wrong 1 ресурса; or natural present-state phrase.'))
(OUT/'editor-online-final-reread.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');(OUT/'editor-online-final-findings.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2)+'\n');print(len(d),len(findings))
