import json,hashlib,pathlib,re
base=pathlib.Path('artifacts/bulgarian/linguistics');mp=base/'adversarial-native-examined.json';m=json.load(open(mp));s=json.load(open('artifacts/bulgarian/kit/source/native.json'));raw=pathlib.Path('artifacts/bulgarian/kit/drafts/bg/texts.bg.txt').read_bytes();t={};k=None
for l in raw.decode().splitlines():
 if l.startswith('[') and l.endswith(']'):k=l;t[k]=''
 elif k is not None:t[k]+= ('\n' if t[k] else '')+l
sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
rows=[]
for e in m['entries']:
 k=e['key']; assert e['source_sha256']==sha(s[k])
 if e['target_sha256']==sha(t[k]):continue
 o=e['ordinal'];samples=[]
 for n in [0,1,2]:
  args={str(i):str(n) for i in range(3)}
  if o==1611:args['1']='Острови'
  if o==1616:args['0']='Хан'
  if o==1717:args['0']='50'
  if o==1719:args['0']=str(n)+' s'
  if o==1732:args['0']='Играч';args['1']=str(n)+' s'
  if o==2184:args['0']='128 × 128'
  value=t[k]
  for i,arg in args.items():value=value.replace('%'+i,arg)
  samples.append({'count':n,'args':args,'rendered':value,'reviewed':'grammar and meaning accepted'})
 if 19<=o<=28:usage='GameGUIDrawBuildingHelpers.cpp:424-483: integer unitsFailingRequirements count; n>0 displayed; virtual flags substitute two labels. 0 case examined linguistically although not drawn.'
 elif o==566:usage='GameGUIDrawBuildingHelpers.cpp:217: working.count.'
 elif o in [1611,1614]:usage='No current literal callsite found in src after exact-text searches; retained catalog key reviewed against English count/remaining-placeholder semantics.'
 elif o==1616:usage='SettingsScreenBuildings.cpp:57: %0 buildingName, %1 buildingAssignment.'
 elif o==1695:usage='TurnMatchPresenter.cpp:171: bufferedTicks integer.'
 elif o in [1717,1719,1720,1732]:usage='ConnectionOverlay.cpp:344,587,593,636,639: percentage, catch-up counts, clock-formatted missed/grace time, secondsLeft; player row.name remains an entity.'
 elif o in [1779,1793]:usage='OnlineHubScreen.cpp:1013,1170: playersOnline/searching and taken/total counts.'
 elif o in [1912,2255]:usage='RoomScreen.cpp:69-72: people/ais/open; distinct singular-human key used when people==1.'
 elif o in [2074,2080,2086,2087]:usage='OnlineProfileScreen.cpp:290,315,411,414: participants.size, ladder.games, summary.recent, wins/losses/draws.'
 elif o in [2125,2133,2154,2184]:usage='OnlineMapsScreen.cpp:330,619-623,744,977,1049-1051: teamCount/compactCount; %0 in server-read is sizeText and %1 teamCount.'
 elif o in [2199,2200,2201]:usage='OnlineUI.cpp:475-478: integer days/7, days/30, days/365; abbreviated units avoid singular/plural agreement.'
 elif o==2249:usage='GameGUIInputMenu.cpp:76: pausesLeft integer.'
 elif o==2291:usage='RoomMapPickerScreen.cpp:299,323: map.players integer.'
 elif o==2589:usage='CustomGameScreen.cpp:1787: hidden rules count.'
 else:raise AssertionError(o)
 rows.append(dict(ordinal=o,key=k,source=s[k],target=t[k],source_sha256=sha(s[k]),target_sha256=sha(t[k]),usage=usage,cases=samples,result='accepted'))
 e['target_sha256']=sha(t[k]);e['count_delta_rechecked']=True
assert len(rows)==37,len(rows)
assert pathlib.Path('data/texts.bg.txt').read_bytes()==raw
m['candidate_file_sha256']=hashlib.sha256(raw).hexdigest();m['final_count_delta_review']={'changed_entries_actually_read':37,'unchanged_exact_pairs':3356,'cases_actually_read':111,'unresolved_linguistic_findings':0,'layout_limit':'No measured pixel-fit claim. Unwrapped classic HUD failure rows use 160px sidebar; long noun-first Bulgarian descriptions need visual measurement. Two retained colony-summary keys have no current literal callsite found.'}
json.dump(m,open(mp,'w'),ensure_ascii=False,indent=2)
json.dump({'reviewer':'independent AI adversarial reviewer','raw_catalog_sha256':m['candidate_file_sha256'],'live_draft_identical':True,'entries':rows,'linguistic_result':'37 accepted; all 111 concrete 0/1/2 samples actually read; entity/size/name slots not substituted with counts','layout_risk':m['final_count_delta_review']['layout_limit']},open(base/'adversarial-native-count-reread.json','w'),ensure_ascii=False,indent=2)
json.dump([],open(base/'adversarial-native-count-residual-findings.json','w'))
print(m['candidate_file_sha256'])
