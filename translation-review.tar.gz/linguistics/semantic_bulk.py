import json,hashlib
from pathlib import Path
P=Path('artifacts/bulgarian/linguistics');snapshot=json.load(open(P/'native-snapshot.json'))
def batch(a,b):
 print('\n'.join(json.dumps([i,x['key'],x['source'],x['target']],ensure_ascii=False) for i,x in enumerate(snapshot[a:b],a)))
def record(a,b,fixes):
 fp=P/'semantic-native-findings.json';f=json.load(open(fp)) if fp.exists() else []
 ep=P/'semantic-native-examined.json';e=json.load(open(ep)) if ep.exists() else []
 for i,value,reason in fixes:
  x=snapshot[i];f=[v for v in f if v['key']!=x['key']];f.append(dict(surface='native',key=x['key'],value=value,reason=reason,source=x['source'],target=x['target']))
 keys={x['key'] for x in f}
 for x in snapshot[a:b]:
  v=dict(x,source_sha256=hashlib.sha256(x['source'].encode()).hexdigest(),target_sha256=hashlib.sha256(x['target'].encode()).hexdigest(),result='finding' if x['key'] in keys else 'acceptable',role='semantic-gameplay');e=[y for y in e if y['key']!=x['key']];e.append(v)
 fp.write_text(json.dumps(f,ensure_ascii=False,indent=2)+'\n');ep.write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')
 print('examined',len(e),'findings',len(f))
