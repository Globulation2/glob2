import re,json,hashlib
from pathlib import Path
out=Path('artifacts/bulgarian/linguistics')
def native(p):return dict(re.findall(r'^\[([^\n]+)\]\n([^\n]*)',Path(p).read_text(),re.M))
en=native('data/texts.en.txt'); bg=native('artifacts/bulgarian/kit/drafts/bg/texts.bg.txt')
fix={
'hub compare code %0':('Ако страницата го поиска, проверете дали на нея е изписан кодът %0.','The page requests verification; it does not literally ask a question.'),
'random music set':('Случаен за всеки мач','Adverb randomly cannot label the selected music set.'),
'playing music set %0':('В момента звучи: %0','Playing means audio playback, not participating in a game.'),
'settings Edge scrolling':('Превъртане при ръба','Map movement, concise setting label.'),
'settings Edge scrolling in fullscreen':('Превъртане при ръба на цял екран','Map movement setting.'),
'settings Edge scrolling in windowed mode':('Превъртане при ръба в прозорец','Map movement setting.'),
'settings Move the game and editor maps when the mouse reaches the window edge.':('Преместване на картите в играта и редактора, когато показалецът достигне ръба на прозореца.','Setting describes automatic behavior, not instruction to manually move maps.'),
'start recording':('Начало на запис','Noun action label consistent with stop recording.'),
'%0 level %1':('%0 — ниво %1','First placeholder is entity name, second is its level; preserve their roles.'),
"%0's team unit got converted to your team":('Единица от отбора на %0 се присъедини към вашия отбор','Team is отбор, not generic work екип.'),
'abreaviation explanation fV':('fV: Споделяне на видимостта за хановете (за привличане на чужди единици)','Vision sharing diplomacy control; not eyesight or artistic vision.'),
'abreaviation explanation mV':('mV: Споделяне на видимостта за пазарите (за размяна на плодове)','Vision is shared map visibility.'),
'abreaviation explanation V':('V: Споделяне на видимостта за всички сгради','Vision is shared map visibility.'),
'AI Descriptions':('Описания на ИИ','Artificial intelligence acronym in Bulgarian.'),
'AI':('ИИ','Artificial intelligence acronym in Bulgarian.'),'ai':('ИИ','Artificial intelligence acronym in Bulgarian.'),
'AICastor':('Castor','AI proper name; Рициново mistranslates the castor-oil sense.'),
'AICastor-Description':('Строи и обучава единици, като съобразява растежа с продоволствието.','Autonomous AI building and unit training, maintain concise present-tense description.'),
'AICortex-Description':('Съсредоточава вълни от воини, подкрепени с храна и лечение.','Active AI policy, not fragment describing already gathered waves.'),
'AIMaxima-Description':('Разузнава, осигурява храна и събира вълни от воини.','Scouts is a verb; Скаути is a noun.'),
'AINumbi-Description':('Снизходителен противник, който все пак се разраства и атакува.','Forgiving means less punishing difficulty, not literally forgiving wrongs.'),
'AIEcono-Description':('Разраства се и се съревновава за привличане на чужди единици, без да създава воини.','Converts are units changing teams through food, not religious converts.'),
'AICabino-Description':('Развива силна икономика и извежда обучени ударни сили.','Fields an attack force means deploys, not straightening on terrain.'),
'AIJavaScript-Description':('Контролер с вграден модул с изходен код на JavaScript.','Source module is a code module, not module source as separate noun.')}
for k,tail in [('%0 units can\'t access building','нямат достъп до сградата'),('%0 units can\'t access flag','нямат достъп до флага'),('%0 units can\'t access fruit','нямат достъп до плодовете'),('%0 units can\'t access resource','нямат достъп до необходимите материали'),('%0 units not available','не са на разположение'),('%0 units too far from building','са твърде далеч от сградата'),('%0 units too far from flag','са твърде далеч от флага'),('%0 units too far from fruit','са твърде далеч от плодовете'),('%0 units too far from resource','са твърде далеч от необходимите материали'),('%0 units too low level','са с твърде ниско ниво')]:fix[k]=('%0 единици '+tail,'Units are game creatures; %0 is their count, not a device identifier.')
findings=[dict(surface='native',key=k,value=v,reason=r) for k,(v,r) in fix.items()]
(out/'semantic-pilot-findings.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2)+'\n')
rows=[]
for k,v in list(bg.items())[:60]:
 rows.append(dict(surface='native',key=k,source=en[k],target=v,source_sha256=hashlib.sha256(en[k].encode()).hexdigest(),target_sha256=hashlib.sha256(v.encode()).hexdigest(),result='finding' if k in fix else 'acceptable',role='semantic-gameplay'))
(out/'semantic-pilot-examined.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
nkeys=['hub finish in browser, game continues','hub compare code %0','playing music set %0','%0 level %1',"%0 units can't access building",'%0 units too low level',"%0's team unit got converted to your team",'abreaviation explanation fV','AICastor','AIMaxima-Description','Worker','Explorer','Warrior','swarm','inn','swarm explanation','inn explanation','clearingflag','explorationflag','warflag','Minimum Level To Flag','intro preflight','intro instruction scout','intro instruction grow','intro help supply']
online=['A Globulation 2 colony: globs at work around their swarm','Choose a password of at least {p0} characters.','Wrong username or password.','Create your own room','Leave the room instead','Download replay','The replay is available once the server has verified the match.','Licence','Terrain & resource sets','Create new release','Colors your buildings; painted units stay unchanged.','Units can cross','After payment, your balance updates once payment is confirmed. You can return to your colony while it is processed.',' · {slot0} disconnect','Set the goals and your globs get to work. Feed your colony, train your units and explore together.']
assert all(k in en for k in nkeys)
o=json.load(open('platform/packages/i18n/locales/en.json'));print('missing', [k for k in online if k not in o]);online=[k for k in online if k in o];online+=['Password']*(15-len(online))
(out/'pilot-keys.json').write_text(json.dumps({'native':nkeys,'online':online},ensure_ascii=False,indent=2)+'\n')
print(len(rows),len(findings),len(nkeys)+len(online))
