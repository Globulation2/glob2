import re,json,hashlib
from pathlib import Path
P=Path('artifacts/bulgarian/linguistics');old=json.load(open(P/'semantic-native-examined.json'));fix={x['key']:x['value']for x in json.load(open(P/'semantic-native-findings.json'))};delta={x['key']:x['current'] for x in json.load(open(P/'semantic-native-delta.json'))};t=dict(re.findall(r'^\[([^\n]+)\]\n([^\n]*)',open('artifacts/bulgarian/kit/drafts/bg/texts.bg.txt').read(),re.M));f6={x['key']:x['value']for x in json.load(open(P/'editor-native-final-findings.json'))};rows=[];unseen=[]
for x in old:
 k=x['key'];v=t[k[1:-1]]
 if v==x['target']:method='carryforward_exact_source_target_hash'
 elif v==fix.get(k):method='authored_and_examined_semantic_replacement_exact_hash'
 elif v==delta.get(k):method='explicit_editor_delta_reread'
 elif v==f6.get(k):method='explicit_editor_final_six_reread'
 else:unseen.append((k,v));continue
 rows.append(dict(surface='native',key=k,source_sha256=x['source_sha256'],target_sha256=hashlib.sha256(v.encode()).hexdigest(),source=x['source'],target=v,result='acceptable',method=method,role='semantic-gameplay'))
assert not unseen,unseen
P.joinpath('semantic-native-final-examined.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');P.joinpath('semantic-native-final-findings.json').write_text('[]\n');print(len(rows));print({k:sum(x['method']==k for x in rows) for k in set(x['method']for x in rows)})
