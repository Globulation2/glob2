import json,hashlib,pathlib
b=pathlib.Path('artifacts/bulgarian');out=b/'linguistics';kit=b/'kit-v2';manifest=json.load(open(kit/'manifest.json'))
def serial(v):return v if isinstance(v,str) else json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(v):return hashlib.sha256(serial(v).encode()).hexdigest()
def filehash(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def native(p):
 d={};k=None
 for line in p.read_text().splitlines():
  if line.startswith('[')and line.endswith(']'):k=line;d[k]=''
  elif k is not None:d[k]+= ('\n'if d[k]else'')+line
 return d
sn=json.load(open(kit/'source/native.json'));so=json.load(open(kit/'source/online.json'));tn=native(kit/'drafts/bg/texts.bg.txt');to=json.load(open(kit/'drafts/bg/bg.json'));mn=json.load(open(out/'adversarial-native-examined.json'));mo=json.load(open(out/'adversarial-online-examined.json'));oldn={e['key']:e for e in mn['entries']};oldo={e['key']:e for e in mo['entries']}
newkeys=['Artist','Beginner-friendly','Defensive','Economy','Expansion','Experimental','Rush'];changed=['[Beginner-friendly]','[Defensive]','[Experimental]','[Rush]'];native_delta=[]
for k,e in oldn.items():
 assert sha(sn[k])==e['source_sha256'],k
 if sha(tn[k])!=e['target_sha256']:native_delta.append(k)
assert set(native_delta)==set(changed),native_delta
assert set(so)-set(oldo)==set(newkeys)
for k,e in oldo.items():assert sha(so[k])==e['source_sha256']and sha(to[k])==e['target_sha256'],k
reason={'Artist':'Music upload metadata field beside Title/Description/Credits & sources; Изпълнител means music performer, matching existing Bulgarian music search vocabulary. Attribution field remains Автори и източници; not currency.', 'Rush':'Ранна атака describes early military pressure, avoiding opaque English borrowing Ръш. Strategy noun label needs no controller adjective agreement.', 'Defensive':'Отбранителен naturally describes masculine ИИ/контролер, consistent with existing Балансиран. Defense strategy retained.', 'Experimental':'Експериментален naturally describes masculine ИИ/контролер, consistent with Балансиран; status is still experimental.', 'Beginner-friendly':'Подходящ за начинаещи naturally describes masculine ИИ/контролер. Friendly difficulty meaning retained without promising any tested strength.', 'Economy':'Икономика is concise strategy/category noun for economic development; established native label.', 'Expansion':'Разширяване is concise strategy/category noun for expansion; established native label.'}
review=[]
for k in newkeys:
 review.append(dict(surface='online',key=k,source=so[k],target=to[k],reason=reason[k],source_sha256=sha(so[k]),target_sha256=sha(to[k]),status='actually read and accepted'))
for k in changed:
 label=k[1:-1];review.append(dict(surface='native',key=k,source=sn[k],target=tn[k],reason=reason[label],source_sha256=sha(sn[k]),target_sha256=sha(tn[k]),status='actually reread and accepted'))
for i,(k,v) in enumerate(so.items(),1):
 if k not in oldo:
  oldo[k]=dict(ordinal=i,key=k,source_sha256=sha(v),target_sha256=sha(to[k]),status='examined',finding=False,source_expansion_actually_read=True)
 else:oldo[k]['ordinal']=i
mo['entries']=[oldo[k]for k in so]
for i,(k,v) in enumerate(sn.items(),1):
 oldn[k]['ordinal']=i
 if k in changed:oldn[k]['target_sha256']=sha(tn[k]);oldn[k]['source_expansion_delta_rechecked']=True
mn['entries']=[oldn[k]for k in sn]
for d,path,count,unchanged in [(mn,kit/'drafts/bg/texts.bg.txt',4,3389),(mo,kit/'drafts/bg/bg.json',7,2836)]:
 d['candidate_file_sha256']=filehash(path);d['candidate_path']=str(path);d['source_bundle_sha256']=manifest['source_sha256'];d['source_expansion_review']={'actually_read_new_or_revised':count,'unchanged_exact_source_target_hash_pairs_carried_forward':unchanged,'unchanged_not_freshly_read':True,'old_proof_snapshot':'artifacts/bulgarian/source-expansion-v1/linguistics','unresolved_findings':0}
mo['coverage']='Cumulative coverage of all 2843 online keys: prior full 2836-key actual reading carried forward only through exact source/target hashes, plus 7 new keys actually read in source/UI context. Existing 27 plural objects retain exact hashes; no new plural forms.'
mn['coverage']='Cumulative coverage of all3393 native keys: prior full reading and successive exact delta reviews; this expansion actually reread4 revised labels and exact-compared3389 unchanged source/target pairs.'
json.dump(mn,open(out/'adversarial-native-examined.json','w'),ensure_ascii=False,indent=2);json.dump(mo,open(out/'adversarial-online-examined.json','w'),ensure_ascii=False,indent=2)
assert tn==native(pathlib.Path('data/texts.bg.txt'));assert to==json.load(open('platform/packages/i18n/locales/bg.json'))
report={'source_bundle_sha256':manifest['source_sha256'],'native_raw_sha256':mn['candidate_file_sha256'],'online_raw_sha256':mo['candidate_file_sha256'],'entries_actually_read':review,'existing_balanced_context':{'source':'Balanced','target':to['Balanced'],'result':'actually read; masculine controller agreement is consistent with new Defensive/Experimental/Beginner-friendly'},'callsites_actually_read':['platform/apps/web/src/messages.ts:3-14','platform/apps/web/src/pages/Ais.tsx:104-126,336-340,483-490','platform/apps/web/src/music/Library.tsx:687-700','src/ui/settings/SettingsScreenCustomAIs.cpp:235-236'],'artist37_skim':'Compact standalone Artist values for37locales actually displayed and skimmed for obvious context mismatch. No new obvious meaning blocker; generic artist terms are broad but appropriate music metadata. This is not complete 37-language native review/certification.','no_fresh_reading_claim_for_unchanged':True,'pixel_fit':'No new pixel-fit claim.','unresolved_findings':0}
json.dump(report,open(out/'adversarial-source-expansion-reread.json','w'),ensure_ascii=False,indent=2);json.dump([],open(out/'adversarial-source-expansion-residual-findings.json','w'))
print(json.dumps({k:report[k]for k in ['source_bundle_sha256','native_raw_sha256','online_raw_sha256']},indent=2))
