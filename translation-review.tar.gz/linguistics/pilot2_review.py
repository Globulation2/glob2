exec(open('artifacts/bulgarian/linguistics/semantic_prepare.py').read().split('fix={')[0])
p=json.load(open(out/'pilot-keys.json'));oe=json.load(open('platform/packages/i18n/locales/en.json'));ob=json.load(open('artifacts/bulgarian/kit/drafts/bg/bg.json'))
f=[]
def add(surface,key,value,reason):f.append(dict(surface=surface,key='['+key+']' if surface=='native' else key,value=value,reason=reason))
for k,v,r in [
('Explorer','Разузнавач','Scouting unit term, consistent with flags and attack capabilities.'),
('inn explanation','Храни вашите единици','Feeds living creatures; захранва suggests power supply.'),
('clearingflag','Флаг за разчистване','Клиринг is financial clearing, not removal of resources.'),
('explorationflag','Разузнавателен флаг','Scouting area flag and explorer terminology.'),
('warflag','Боен флаг','Consistent flag noun and concise military purpose.'),
('intro preflight','Вашите глобули действат самостоятелно. Избирате задачите им чрез сгради и флагове. В това кратко въведение разузнайте ориентир, осигурете повече храна, увеличете броя на работниците и насочете малка атака.','Landmark is orientation marker, not tourist sight; remove spurious comma and align flags.'),
('intro instruction scout','Отворете „Флагове“ и поставете разузнавателен флаг върху каменния участък източно от вашата колония. Заявете един разузнавач. Наблюдавайте как се придвижва до флага.','Consistent label and request-based staffing mechanics.'),
('intro instruction grow','Изберете рояка. Задайте заявения брой работници на поне 2 и съотношението на създаваните единици така, че да се създават само работници. Поддържайте и двата хана снабдени, докато се роди нов работник.','Worker target is a staffing request, production ratios choose creature mix.'),
('intro help supply','За строителството и ежедневното снабдяване се задава отделен брой работници. Изберете завършения хан и увеличете заявения брой работници за снабдяване. Снабдител събира пшеница и я носи тук. Гладните глобули се хранят в хановете; сграда без снабдители накрая остава без храна. Поддържайте достъпа до участъка с пшеница.','Operating target requests suppliers; run out means food exhaustion, not building finishing.')]:add('native',k,v,r)
for k,v,r in [
('A Globulation 2 colony: globs at work around their swarm','Колония в Globulation 2: глобули, които работят около своя рояк','Preserve game proper name.'),
('Create your own room','Създаване на собствена стая','Noun label consistent with interface; avoid singular imperative.'),
('Download replay','Изтегляне на повторение','Replay terminology distinguishes simulation playback from generic recording.'),
('The replay is available once the server has verified the match.','Повторението е достъпно, след като сървърът провери мача.','Verification means checking match execution, not simply confirming it.'),
('Terrain & resource sets','Комплекти с терени и ресурси','Sets contain terrain types and resources.'),
('Create new release','Създаване на ново издание','Published package release, distinct from arbitrary revision/version.'),
(' · {slot0} disconnect',{'one':' · {slot0} прекъсване на връзката','other':' · {slot0} прекъсвания на връзката'},'Both variants are count noun labels; preserve leading separator whitespace.'),
('Set the goals and your globs get to work. Feed your colony, train your units and explore together.','Задайте целите и вашите глобули ще се заемат с работа. Хранете колонията си, обучавайте единиците си и разузнавайте заедно.','Globs are creatures, not globes; units include workers and explorers, not only military units.')]:add('online',k,v,r)
rows=[]
for surface,keys in p.items():
 for k in keys:
  s=en[k] if surface=='native' else oe[k];t=bg[k] if surface=='native' else ob[k]
  h=lambda v:hashlib.sha256((json.dumps(v,ensure_ascii=False,sort_keys=True) if isinstance(v,dict) else v).encode()).hexdigest()
  rows.append(dict(surface=surface,key='['+k+']' if surface=='native' else k,source=s,target=t,source_sha256=h(s),target_sha256=h(t),result='finding' if any(x['surface']==surface and x['key']==('['+k+']' if surface=='native' else k) for x in f) else 'acceptable',role='semantic-gameplay'))
(out/'semantic-pilot2-findings.json').write_text(json.dumps(f,ensure_ascii=False,indent=2)+'\n')
(out/'semantic-pilot2-examined.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
(out/'semantic-pilot2-gate.md').write_text('Semantic pilot gate: changes required. All 40 proposed pilot keys actually examined against English, including corrected earlier keys. 17 findings: resource clearing was translated as financial clearing; globs as globes; worker operating target and food exhaustion meanings lost; informal singular address and release/replay terminology inconsistent. Proposed replacements recorded in semantic-pilot2-findings.json. After applying these and adding glossary guidance to translation, bulk drafting may proceed. Bulk output still requires independent full review; this pilot is not evidence of all-key quality.\n')
print(len(rows),len(f))
