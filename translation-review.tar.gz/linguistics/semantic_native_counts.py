import re,json,hashlib
from pathlib import Path
P=Path('artifacts/bulgarian/linguistics')
s=dict(re.findall(r'^\[([^\n]+)\]\n([^\n]*)',open('data/texts.en.txt').read(),re.M));t=dict(re.findall(r'^\[([^\n]+)\]\n([^\n]*)',open('artifacts/bulgarian/kit/drafts/bg/texts.bg.txt').read(),re.M))
f={}
def add(k,v,reason,ref):f[k]=dict(surface='native',key='['+k+']',source=s[k],target=t[k],value=v,reason=reason,callsite=ref)
ref='src/hud/draw/GameGUIDrawBuildingHelpers.cpp:430-485; src/building/Step.cpp:85-95'
for k,v in {
"%0 units can't access building":'Единици без достъп до сградата: %0',"%0 units can't access flag":'Единици без достъп до флага: %0',"%0 units can't access fruit":'Единици без достъп до плодовете: %0',"%0 units can't access resource":'Единици без достъп до нужните материали: %0',"%0 units not available":'Единици, които не са на разположение: %0',"%0 units too far from building":'Единици твърде далеч от сградата: %0',"%0 units too far from flag":'Единици твърде далеч от флага: %0',"%0 units too far from fruit":'Единици твърде далеч от плодовете: %0',"%0 units too far from resource":'Единици твърде далеч от нужните материали: %0',"%0 units too low level":'Единици с твърде ниско ниво: %0'}.items():add(k,v,'The placeholder is integer n=unitsFailingRequirements[j], displayed when n>0 including1. Flat count-first plural produces1 единици plus plural predicate. Category-label then number works for all counts. NotAvailable counts busy/unwell candidates, distinct from access failure.',ref)
for k,v,ref in [
('Units still working: %0','Все още работещи: %0','src/hud/draw/GameGUIDrawBuildingHelpers.cpp:217; working.count'),
('settings %0 · %1 Units','%0 · единици: %1','src/ui/settings/SettingsScreenBuildings.cpp:57; buildingAssignment'),
('hub online now %0 %1','Играчи онлайн: %0 · търсещи в тази опашка: %1','src/online/screens/OnlineHubScreen.cpp:1013; playersOnline/searching counts'),
('hub seats %0 %1','Места: %0/%1','src/online/screens/OnlineHubScreen.cpp:1170; taken/total'),
('room seats summary %0 %1 %2','Играчи: %0 · ИИ: %1 · свободни места: %2','src/online/screens/RoomScreen.cpp:68-72; people!=1 but open can1'),
('room seats one person %0 %1','1 играч · ИИ: %0 · свободни места: %1','src/online/screens/RoomScreen.cpp:68-72; people==1, open can1'),
('profile room with %0','Стая · колонии: %0','src/online/screens/OnlineProfileScreen.cpp:290; participants.size()'),
('profile provisional %0 games','временен · мачове: %0','src/online/screens/OnlineProfileScreen.cpp:315; ladder.games'),
('profile win rate last %0','Процент победи · последни мачове: %0','src/online/screens/OnlineProfileScreen.cpp:411; summary.recent'),
('profile %0 w %1 l %2 d','%0 П · %1 З · равенства: %2','src/online/screens/OnlineProfileScreen.cpp:414; summary.draws'),
('maps %0 colonies','Колонии: %0','src/online/screens/OnlineMapsScreen.cpp:330,977; teamCount/colonies'),
('maps server read %0 %1','Сървърът разчете картата като %0; брой колонии: %1.','src/online/screens/OnlineMapsScreen.cpp:1049-1052; sizeText then teamCount'),
('maps stats %0 %1 %2','▶ изигравания: %0 · ⬇ изтегляния: %1 · ♥ %2','src/online/screens/OnlineMapsScreen.cpp:619-623; compactCount(plays/downloads/likes)'),
('maps %0 plays','Изигравания: %0','src/online/screens/OnlineMapsScreen.cpp:744; compactCount(map.plays)'),
('room picker players %0','Играчи: %0','src/online/screens/RoomMapPickerScreen.cpp:299,323; map.players may1'),
('turn catching up %0','Наваксване · изоставане в ходове: %0','src/net/turn/TurnMatchPresenter.cpp:171; bufferedTicks count'),
('conn card progress %0 %1 %2','%0 % · тактове: %1 от %2','src/net/ConnectionOverlay.cpp:636; catchupDone/catchupTotal'),
('conn card seconds left %0','Оставащо време: около %0 s','src/net/ConnectionOverlay.cpp:639; secondsLeft integer'),
('conn card replaying %0','Възпроизвеждане на пропуснатото време: %0. Екранът се обновява, когато наваксате до настоящия момент.','src/net/ConnectionOverlay.cpp:587,593; clock(missedSeconds) duration'),
('pause game left %0','Пауза на играта (налични паузи: %0)','src/hud/input/GameGUIInputMenu.cpp:76; pausesLeft'),
('%0 more rules are at their Standard values.','Още правила със стандартни стойности: %0.','src/game/screens/CustomGameScreen.cpp:1787; hidden>0 includes1'),
('online %0 weeks ago','преди %0 седм.','src/ui/OnlineUI.cpp:475; int(days/7) starts1'),
('online %0 months ago','преди %0 мес.','src/ui/OnlineUI.cpp:477; int(days/30) starts1'),
('online %0 years ago','преди %0 г.','src/ui/OnlineUI.cpp:478; int(days/365) starts1'),
('%0 colonies · %1','Колонии: %0 · %1','Catalog metadata key; no active C++ callsite found by exact literal search'),
('%0 colonies · %1 AI','Колонии: %0 · ИИ: %1','Catalog metadata key; no active C++ callsite found by exact literal search')]:add(k,v,'Numeric quantity or formatted duration can be1; preserve category/meaning while using a count-neutral label or invariant abbreviation. Do not change entity-name placeholders.',ref)
# Notification contains duration, not player name, in slot1.
add('conn notice lost %0 %1','%0 загуби връзка. Играта продължава; колонията на играча продължава да работи, докато връзката се възстановява (време за връщане: %1).','%0 is player name and must remain in place; %1 is clock(graceSeconds), not an entity/count. Avoid plural remaining-time predicate at1 second.','src/net/ConnectionOverlay.cpp:344')
rows=[]
for k,v in s.items():
 if re.search(r'%\d',v):
  reason='Targeted numeric/template audit: unchanged. Label before quantity, ordinal/ID, invariant unit, named entity placeholder or no singular-sensitive dependent noun.'
  if k in ['room waiting for players %0','room close body %0','room picker for %0','room picker too small %0','ruleset changes %0 %1']:
   reason='Explicit caller singular branch uses another key: PlatformRoom.cpp waiting.size()==1; RoomScreen.cpp others==1; RoomMapPickerScreen.cpp people==1; CustomGameRules.cpp changes==1. Plural branch safe.'
  if k in f:reason=f[k]['reason']
  rows.append(dict(surface='native',key='['+k+']',source=v,target=t[k],source_sha256=hashlib.sha256(v.encode()).hexdigest(),target_sha256=hashlib.sha256(t[k].encode()).hexdigest(),result='finding'if k in f else'unchanged_after_count_audit',rationale=reason))
P.joinpath('semantic-native-count-findings.json').write_text(json.dumps(list(f.values()),ensure_ascii=False,indent=2)+'\n');P.joinpath('semantic-native-count-examined.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('all interpolated native templates examined',len(rows),'findings',len(f))
