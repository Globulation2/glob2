exec(open('artifacts/bulgarian/linguistics/editor_review.py').read().split("if __name__")[0])
P=OUT/'editor-native-final-reread.json';Q=OUT/'editor-native-final-findings.json'
done=json.loads(P.read_text()) if P.exists() else []; fixes=json.loads(Q.read_text()) if Q.exists() else []
def note(start,end,changes={}):
 d=json.load(open(OUT/'editor-native-final-delta.json'))
 for r in d[start:end]:
  if r['key'] in changes:fixes.append(dict(surface='native',key=r['key'],original=r['target'],value=changes[r['key']],reason='Final editorial delta reread: grammar or glossary consistency.'))
  r.update(source_sha256=digest(r['source']),target_sha256=digest(r['target']),result='finding' if r['key'] in changes else 'acceptable',batch=f'final-delta-{start}-{end-1}');done.append(r)
 P.write_text(json.dumps(done,ensure_ascii=False,indent=2)+'\n');Q.write_text(json.dumps(fixes,ensure_ascii=False,indent=2)+'\n');print(len(done),len(fixes))
