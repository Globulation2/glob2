import json,re,hashlib
from pathlib import Path
P=Path('artifacts/bulgarian/linguistics')
h=lambda v:hashlib.sha256((json.dumps(v,ensure_ascii=False,sort_keys=True) if isinstance(v,dict) else v).encode()).hexdigest()
read=lambda f:json.loads(Path(f).read_text())
parse=lambda f:dict(re.findall(r'^\[([^\n]+)\]\n([^\n]*)',Path(f).read_text(),re.M))
expected={'Rush':'Ранна атака','Defensive':'Отбранителен','Experimental':'Експериментален','Beginner-friendly':'Подходящ за начинаещи'}
reasons={'Rush':'Ранна атака directly names the RTS strategy of attacking early and removes the opaque loanword. A category noun phrase is natural beside adjectival AI tags.', 'Defensive':'Отбранителен naturally describes a defensive AI/controller, with masculine agreement matching existing Балансиран; it refers to military strategy rather than a generic protective measure.', 'Experimental':'Експериментален correctly describes an experimental AI/controller, with masculine agreement matching existing Балансиран.', 'Beginner-friendly':'Подходящ за начинаещи naturally describes an AI/controller suitable for beginning players, matching masculine Балансиран and retaining the suitability meaning without promising a win.'}
ns=parse('data/texts.en.txt');nt=parse('data/texts.bg.txt');nd=parse('artifacts/bulgarian/kit-v2/drafts/bg/texts.bg.txt')
os=read('platform/packages/i18n/locales/en.json');ot=read('platform/packages/i18n/locales/bg.json');od=read('artifacts/bulgarian/kit-v2/drafts/bg/bg.json')
assert nt==nd and ot==od
all_delta=[]
for surface,source,target in [('native',ns,nt),('online',os,ot)]:
 path=P/f'semantic-{surface}-final-examined.json'; rows=read(path); oldrows=json.loads(json.dumps(rows)); assert len(rows)==len(source)==len(target)
 changed=[]
 for row in rows:
  k=row['key'].strip('[]') if surface=='native' else row['key']; assert row['source']==source[k]
  if k in expected:
   assert target[k]==expected[k];assert row['target']!=target[k]
   before=row['target'];row.update(target=target[k],target_sha256=h(target[k]),source_sha256=h(source[k]),method='explicit_ai_tag_refinement_delta_reading',rationale=reasons[k],result='acceptable')
   row.pop('source_expansion_carryforward',None)
   changed.append(dict(row,previous_target=before,context='Native custom AI library canonical tag filter and list (SettingsScreenCustomAIs.cpp); online Ais.tsx selector/list/detail via messages.ts aiTagLabel. Actual code read for this delta.'))
  else:
   assert row['target']==target[k] and row['source_sha256']==h(source[k]) and row['target_sha256']==h(target[k]),row['key']
 assert len(changed)==4
 # Preserve immediately preceding proof separately; original source-expansion-v1 snapshot untouched.
 backup=P/f'semantic-{surface}-before-ai-refinement4.json'
 assert not backup.exists();backup.write_text(json.dumps(oldrows,ensure_ascii=False,indent=2)+'\n')
 path.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');all_delta.extend(changed)
P.joinpath('semantic-ai-refinement4-delta-examined.json').write_text(json.dumps(all_delta,ensure_ascii=False,indent=2)+'\n')
P.joinpath('semantic-ai-refinement4-findings.json').write_text('[]\n')
# Independently establish archived carryforward claims, no fresh reading of the unchanged keys.
arch=Path('artifacts/bulgarian/source-expansion-v1/linguistics')
native_old=read(arch/'semantic-native-final-examined.json'); online_old=read(arch/'semantic-online-final-examined.json')
native_changed=[]
for row in native_old:
 k=row['key'].strip('[]');assert row['source']==ns[k]
 if row['target']!=nt[k]:native_changed.append(row['key']);assert k in expected
assert len(native_changed)==4
for row in online_old:assert row['source']==os[row['key']] and row['target']==ot[row['key']]
carry=read('artifacts/bulgarian/source-expansion-carryforward.json');assert carry['unchanged_native_keys']==3389 and set(carry['revised_native_keys'])==set(native_changed) and carry['unchanged_online_keys']==2836
paths=['data/texts.en.txt','platform/packages/i18n/locales/en.json','artifacts/bulgarian/kit-v2/manifest.json','artifacts/bulgarian/kit-v2/drafts/bg/texts.bg.txt','artifacts/bulgarian/kit-v2/drafts/bg/bg.json','data/texts.bg.txt','platform/packages/i18n/locales/bg.json']
hashes={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in paths}
assert hashes['data/texts.bg.txt']=='ccd9b28467ec8a4e5272d2d3780d6813107eed945e424f8fac1d6ff2656d38ed'
assert hashes['platform/packages/i18n/locales/bg.json']=='3597f1d21d3b8e8d55ec79368b7c10d66c88752a411c6c31b24a52e9cc421313'
P.joinpath('semantic-final-file-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
P.joinpath('semantic-ai-refinement4-carryforward.json').write_text(json.dumps({'inventory':6236,'native':3393,'online':2843,'explicit_delta_readings':8,'native_unchanged_from_archived':3389,'native_changed_from_archived':native_changed,'online_unchanged_from_archived':2836,'online_new_since_archive':7,'method':'Exact literal source/target comparisons and recorded SHA256s retain prior coverage for unchanged keys; only the four revised labels on each surface explicitly reread in this delta. No fresh reading claimed for carried entries.','source_expansion_carryforward_report_verified':True},ensure_ascii=False,indent=2)+'\n')
with P.joinpath('semantic-review-conclusion.md').open('a') as f:f.write('\n\nFinal AI-label refinement: explicitly reread four revised native labels and the same four online labels in the actual canonical AI filter/list/detail context. Approved Ранна атака, Отбранителен, Експериментален, Подходящ за начинаещи; masculine descriptors agree with the implied AI/controller and existing Балансиран, while Ранна атака makes the early-attack strategy clear. No residual findings. Final 6236 per-key proofs and kit-v2/live raw hashes refreshed. Independently verified archived carryforward: 3389 native source/target pairs unchanged, four native targets revised; all original 2836 online pairs unchanged and seven new online entries retained. Unchanged values are carried by exact comparison, without claiming a fresh reading. Original archived evidence and immediate pre-refinement proofs preserved. See semantic-ai-refinement4-delta-examined.json and semantic-ai-refinement4-carryforward.json.\n')
print('Approved 8 explicit delta readings; final 6236 bound; native3389 and online2836 archived pairs exact. Raw hashes match parent.')
