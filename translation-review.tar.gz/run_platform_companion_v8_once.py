from pathlib import Path
from decimal import Decimal
import hashlib,importlib.util,json
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'platform-companion-v8';S=B/'platform-companion-v8-tool-shadow';load=lambda p:json.loads(p.read_text());pre=load(K/'preflight.json');assert hashlib.sha256((S/'tools/localization/translation_program.py').read_bytes()).hexdigest()==pre['tool_sha256'];ledger=load(K/'machine/spend-ledger.json');assert len(ledger['reservations'])==95 and sum((Decimal(r['reserved_usd'])for r in ledger['reservations']),Decimal())==Decimal('5.46822')
spec=importlib.util.spec_from_file_location('companion',S/'tools/localization/translation_program.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
result=m.machine_draft(K,'bg','bradley-personal-20261027',max_cost_usd='10',rate_per_million='20',retries=0,only_keys=load(K/'only-keys.json'));m.write_json(K/'machine-results.json',result);assert result['filled']==3 and result['paid_requests']==1;print(json.dumps(result))
