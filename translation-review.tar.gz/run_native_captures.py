from pathlib import Path
import json,os,subprocess,time,hashlib,sys
root=Path.cwd();base=root/'artifacts/bulgarian/native-captures';binary=Path(sys.argv[1]).resolve();kit=root/'artifacts/bulgarian/kit-v2/render-input/bg'
base.mkdir(exist_ok=True);entries=[]
layout=[('desktop',1280,1024),('phone',480,960)]
jobs=[]
for presentation,w,h in layout:
 for mode,name in [('matrix','matrix')]+[('screen',s)for s in ['main','settings','settings-audio','lobby','lobby-players','new-map']]+[('editor','editor')]+[('game',g)for g in ['gameplay','tutorial','tutorial:swimming','tutorial:warrior-training','tutorial:fortifications']]:
  jobs.append((presentation,w,h,mode,name))
jobs += [(presentation,w,h,'matrix-probe','font-probe') for presentation,w,h in layout]
stage = sys.argv[2] if len(sys.argv)>2 else 'all'
extra = stage=='extras'
if stage=='surfaces':jobs=[job for job in jobs if job[3]!='matrix']
if stage=='matrices':jobs=[job for job in jobs if job[3]=='matrix']
if extra:
 jobs=[(presentation,w,h,'screen',name) for presentation,w,h in layout for name in ['settings-ais','settings-online','settings-player']+(['settings-controls'] if presentation=='desktop' else [])]
for presentation,w,h,mode,name in jobs:
 tag=presentation+'-'+name.replace(':','-');output=base/tag;output.mkdir(exist_ok=True);profile=output/'profile';profile.mkdir(exist_ok=True)
 env=dict(os.environ,LD_LIBRARY_PATH=str(root/'artifacts/bulgarian/sdl3/prefix/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''),GLOB2_USER_DATA_DIR=str(profile/'user'),XDG_DATA_HOME=str(profile/'data'),XDG_CONFIG_HOME=str(profile/'config'),XDG_CACHE_HOME=str(profile/'cache'),SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='x11',GLOB2_RENDERER='software')
 if presentation=='phone':env['GLOB2_MOBILE_UI']='1'
 else:env.pop('GLOB2_MOBILE_UI',None)
 input_kit=root/'artifacts/bulgarian/native-probe-kit/drafts/bg' if mode=='matrix-probe' else kit
 actual_mode='matrix' if mode=='matrix-probe' else mode
 command=[str(binary),actual_mode,str(root),str(input_kit),str(output),str(w),str(h)]
 if mode in ['screen','game']:command.append(name)
 if actual_mode!='matrix':command=['xvfb-run','-a','-s','-screen 0 1600x1400x24']+command
 start=time.monotonic();print('START',tag,flush=True)
 with (output/'capture.log').open('w')as log:
  try:rc=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=3600 if actual_mode=='matrix' else 300).returncode
  except subprocess.TimeoutExpired:rc='timeout'
 entries.append(dict(tag=tag,command=command,environment={k:env.get(k) for k in ['LD_LIBRARY_PATH','GLOB2_USER_DATA_DIR','GLOB2_MOBILE_UI','GLOB2_RENDERER','SDL_AUDIODRIVER','SDL_VIDEODRIVER']},returncode=rc,seconds=round(time.monotonic()-start,2),log=str(output/'capture.log')))
 (base/('execution-'+stage+'.json')).write_text(json.dumps({'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'jobs':entries},indent=2)+'\n')
 print('END',tag,rc,entries[-1]['seconds'],flush=True)
 if rc!=0:print((output/'capture.log').read_text()[-1600:],flush=True)
print('COMPLETE',sum(e['returncode']==0 for e in entries),'/',len(entries),flush=True)
