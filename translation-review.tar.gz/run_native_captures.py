from pathlib import Path
import json,os,subprocess,time,hashlib,sys
root=Path.cwd();base=root/'artifacts/bulgarian/native-captures';binary=Path(sys.argv[1]).resolve();kit=root/'artifacts/bulgarian/kit-v2/render-input/bg'
base.mkdir(exist_ok=True);entries=[]
layout=[('desktop',1280,1024),('phone',480,960)]
jobs=[]
for presentation,w,h in layout:
 for mode,name in [('matrix','matrix')]+[('screen',s)for s in ['main','settings','settings-audio','lobby','lobby-players','new-map']]+[('editor','editor')]+[('game',g)for g in ['gameplay','tutorial','tutorial:swimming','tutorial:warrior-training','tutorial:fortifications']]:
  jobs.append((presentation,w,h,mode,name))
for presentation,w,h,mode,name in jobs:
 tag=presentation+'-'+name.replace(':','-');output=base/tag;output.mkdir(exist_ok=True);profile=output/'profile';profile.mkdir(exist_ok=True)
 env=dict(os.environ,LD_LIBRARY_PATH=str(root/'artifacts/bulgarian/sdl3/prefix/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''),XDG_DATA_HOME=str(profile/'data'),XDG_CONFIG_HOME=str(profile/'config'),XDG_CACHE_HOME=str(profile/'cache'),SDL_AUDIODRIVER='dummy')
 if presentation=='phone':env['GLOB2_MOBILE_UI']='1'
 else:env.pop('GLOB2_MOBILE_UI',None)
 command=[str(binary),mode,str(root),str(kit),str(output),str(w),str(h)]
 if mode in ['screen','game']:command.append(name)
 if mode!='matrix':command=['xvfb-run','-a','-s','-screen 0 1600x1400x24']+command
 start=time.monotonic();print('START',tag,flush=True)
 with (output/'capture.log').open('w')as log:
  try:rc=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
  except subprocess.TimeoutExpired:rc='timeout'
 entries.append(dict(tag=tag,command=command,returncode=rc,seconds=round(time.monotonic()-start,2),log=str(output/'capture.log')))
 (base/'execution.json').write_text(json.dumps({'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'jobs':entries},indent=2)+'\n')
 print('END',tag,rc,entries[-1]['seconds'],flush=True)
 if rc!=0:print((output/'capture.log').read_text()[-1600:],flush=True)
print('COMPLETE',sum(e['returncode']==0 for e in entries),'/',len(entries),flush=True)
