import os,subprocess,json,time
from pathlib import Path
R=Path.cwd();B=R/'artifacts/ci-recovery';D=B/'editor-overlay-current';W=B/'browser-recovery-70319';env=dict(os.environ,GLOB2_TEST_URL='http://127.0.0.1:8854',GLOB2_TEST_BUILD_DIR=str(W/'build/emscripten/client/release'),GLOB2_TEST_RENDERER='software',GLOB2_BUILD_DIR=str(R/'build/local-release'),LD_LIBRARY_PATH=str(R/'build/sdl3-ci/prefix/lib'));env['PATH']=str(B/'node/node_modules/.bin')+':'+env['PATH']
state=dict(pid=os.getpid(),phase='readonly current Chromium threaded editor diagnostic',revision='fb08271f50fb2141e0aedeadb2ac0edda82d43bd',note='Original current master test/helper/assertions/deadlines; read-only transition snapshot logger; compiled56a production inputs identical fb082; no native helper execution; no active worktree edits.')
def save():(D/'status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
with(D/'server.log').open('w')as log:
 server=subprocess.Popen(['python3',str(B/'serve_ci_layout.py'),'8854','--directory',env['GLOB2_TEST_BUILD_DIR']],stdout=log,stderr=subprocess.STDOUT)
 try:
  time.sleep(1);assert server.poll() is None
  cmd=['taskset','-c','0,2','node',str(W/'browser/node_modules/@playwright/test/cli.js'),'test','--config='+str(D/'playwright.config.js'),'--project=chromium','--grep','threaded: editor stays open','--workers=1'];state['command']=cmd;save()
  with(D/'run.log').open('w')as out:child=subprocess.Popen(cmd,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT);state['child_pid']=child.pid;save();code=child.wait()
  state.update(exit_code=code,phase='finished; inspect final snapshot and trace');save()
 finally:server.terminate();server.wait()
