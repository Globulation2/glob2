"""Final-head focused validation after rebasing to current master."""
import json,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=root/'artifacts/pr1194-refinement'
while True:
 text=(out/'dev-latest-master.log').read_text()
 if text.rstrip().endswith('scons: done building targets.'):break
 if 'scons: building terminated because of errors.' in text:raise SystemExit('Native build failed')
 time.sleep(5)
common=['python3','test/run_tests.py','--build-dir','build/darwin/client/debug/dev-dev_fast-true-linker-auto','--no-display','--timeout','900']
commands={
 'latest-focused':common+['--binary','engine','-j3']+sum((['--filter',name] for name in ['ImmobileUnitGradient/*','FetchHiringScore/*','DelayedGradientPublication/*','BuildingGradientInvalidation/*','MapGradientInvalidation/*','GradientPreparation/*','TurnEngineHarness/the committed*','ReplayStepCounter/*','ResourceRuntimeBenchmark/exported*']),[]),
 'latest-unit':common+['--binary','unit','--exclude-tag','benchmark','-j3'],
 'latest-unit-recheck':common+['--binary','unit','--filter','ImageAssets/*16-bit*','--filter','OpenCLGradient/*full fields*','--filter','Maxima.Farming/*corridor*'],
 'latest-resource-stress':common+['--binary','engine','--filter','ResourceRuntimeBenchmark/large eight-team*'],
}
for name,argv in commands.items():
 argv+=['--junit',str(out/(name+'.xml')),'--artifacts',str(out/name)]
(out/'final-validation-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
results={}
for name,argv in commands.items():
 print('Starting',name,flush=True)
 with (out/(name+'.log')).open('w') as stream:results[name]=subprocess.run(argv,cwd=root,stdout=stream,stderr=subprocess.STDOUT).returncode
 print('Finished',name,results[name],flush=True)
 (out/'final-validation-results.json').write_text(json.dumps(results,indent=2)+'\n')
