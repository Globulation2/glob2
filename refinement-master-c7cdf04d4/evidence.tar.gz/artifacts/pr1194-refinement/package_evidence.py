"""Bundle portable PR verification evidence; never commit this to the product branch."""
from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[2]
out=root/'artifacts/pr1194-refinement'
selected=[]
for p in out.iterdir():
 if p.is_file() and p.name not in {'pr-before','archive-manifest.json'} and p.suffix in {'.log','.xml','.json','.jsonl','.txt','.py','.csv'}: selected.append(p)
for directory in ['verify','verify-master-latest','timing','latest-focused','latest-resource-stress-exports']:
 selected.extend(p for p in (out/directory).rglob('*') if p.is_file())
selected.extend(p for p in (root/'artifacts/pr1194-performance/inputs').rglob('*') if p.is_file())
selected.extend(root/'artifacts/pr1194-performance'/name for name in ['manifest.json','final-build-provenance.json'] if (root/'artifacts/pr1194-performance'/name).exists())
selected.extend(p for p in (out/'timing-interrupted-contended').glob('*') if p.is_file() and p.suffix in {'.json','.jsonl'})
selected=sorted(set(selected))
index=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in selected]
(out/'archive-manifest.json').write_text(json.dumps(index,indent=2)+'\n')
destination=root/'artifacts/pr1194-refinement-publication';destination.mkdir(exist_ok=True)
with tarfile.open(destination/'evidence.tar.gz','w:gz',compresslevel=6) as archive:
 for p in selected+[out/'archive-manifest.json']:archive.add(p,arcname=p.relative_to(root))
print(len(selected),'files;', (destination/'evidence.tar.gz').stat().st_size,'bytes')
