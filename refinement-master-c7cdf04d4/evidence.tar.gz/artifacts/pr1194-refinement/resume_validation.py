import json,re,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=root/'artifacts/pr1194-refinement';sys.path.insert(0,str(root/'test'));import run_tests
passed=set(json.loads((out/'completed-before-disk-error.json').read_text()))
allcases=(out/'test-inventory.txt').read_text().splitlines()[:-1]
remaining=[s for s in allcases if s not in passed]
assert len(passed)==80 and len(remaining)==1532
literal=lambda s: ''.join({'[':'[[]','*':'[*]','?':'[?]'}.get(c,c) for c in s)
args=['--build-dir','build/darwin/client/debug/dev-dev_fast-true-linker-auto','--binary','engine','--exclude-tag','benchmark','--no-display','-j4','--timeout','1200','--artifacts','artifacts/pr1194-refinement/engine','--junit','artifacts/pr1194-refinement/engine-resumed.xml','--write-inventory','artifacts/pr1194-refinement/engine-resumed-inventory.json']
for s in remaining:args+=['--filter',literal(s)]
(out/'engine-resume-command.json').write_text(json.dumps({'argv':args,'completed_before_disk_error':sorted(passed)},indent=2)+'\n')
print('Resuming',len(remaining),'uncompleted engine cases',flush=True)
with (out/'engine-resumed.log').open('w') as f:
 previous=sys.stdout;sys.stdout=f
 try:code=run_tests.main(args)
 finally:sys.stdout=previous
print('Engine result',code,flush=True)
if code:sys.exit(code)
commands=json.loads((out/'commands.json').read_text())
for name in ['unit','sim-contract-unit','sim-contract','whitespace']:
 print('Starting',name,flush=True)
 with (out/(name+'.log')).open('w') as f:code=subprocess.run(commands[name],shell=True,cwd=root,stdout=f,stderr=subprocess.STDOUT).returncode
 print('Finished',name,code,flush=True)
 if code:sys.exit(code)
