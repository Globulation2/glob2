"""Local release comparison of master, reviewed PR, and refined PR."""
import argparse, gzip, hashlib, json, math, platform, shutil, statistics, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'test'))
from benchmark_parallel_compute import execute, digest
p=argparse.ArgumentParser();p.add_argument('--verify',action='store_true');p.add_argument('--verify-base',action='store_true');a=p.parse_args()
if a.verify_base:a.verify=True
manifest=json.loads((ROOT/'artifacts/pr1194-performance/manifest.json').read_text())
variants=[('master',Path('/Users/bradley/.codex/worktrees/pr1194-perf-base/glob2/build/darwin/client/release/src/glob2'),Path('/Users/bradley/.codex/worktrees/pr1194-perf-base/glob2')),('before',ROOT/'artifacts/pr1194-refinement/pr-before',ROOT),('pr',ROOT/'build/darwin/client/release/src/glob2',ROOT)]
if a.verify: variants=[variants[0] if a.verify_base else variants[-1]]
out=ROOT/'artifacts/pr1194-refinement'/('verify-master-latest' if a.verify_base else 'verify' if a.verify else 'timing');out.mkdir(exist_ok=False)
(out/'metadata.json').write_text(json.dumps({'platform':platform.platform(),'manifest':manifest,'mode':'per-tick verification' if a.verify else 'release timing','repetitions':1 if a.verify else 10,'discarded_warmups':0 if a.verify else 1,'verification_prefix_ticks':1024 if a.verify else None,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD'])).hexdigest(),'binaries':{v:digest(b) for v,b,c in variants}},indent=2)+'\n')
# Gate measured runs on a quiet compiler/linker inventory. Checks run outside
# the benchmark's measured interval; interrupted samples are retained separately.
last_busy=time.monotonic()
def build_active():
 names=subprocess.check_output(['ps','-axo','pcpu=,comm='],text=True).splitlines()
 for row in names:
  cpu,command=row.strip().split(None,1);name=Path(command).name
  if name in {'clang','clang++','cc1','cc1plus','ccache','ld','ld.lld','lld','ninja','make','glob2-engine-tests','glob2-unit-tests','glob2'}:return True
  if name.lower().startswith('python') and float(cpu)>20:return True
 return False
def execute_quiet(binary,args,dest,cwd):
 global last_busy
 if a.verify:return execute(binary,args,dest,cwd=cwd)
 attempt=0;announced=False
 while True:
  while True:
   now=time.monotonic()
   if build_active():last_busy=now
   if now-last_busy>=45:break
   if not announced:print('Waiting for45 compiler/linker-free seconds',flush=True);announced=True
   time.sleep(1)
  actual=dest if attempt==0 else dest.with_name(dest.name+'-retry'+str(attempt))
  result=execute(binary,args,actual,cwd=cwd)
  if not build_active():return result
  last_busy=time.monotonic();attempt+=1
  with (out/'discarded-contended.jsonl').open('a') as f:f.write(json.dumps({'reason':'compiler/linker active at run completion','attempt':str(actual),'measurement':result})+'\n')
  print('Discarding contended sample',actual,flush=True);announced=False
rows=[];refs={}
with (out/'measurements.jsonl').open('w') as log:
 for scenario in manifest['scenarios']:
  assert digest(Path(scenario['args'][1]))==scenario['input_sha256']
  for repeat in ([0] if a.verify else range(-1,10)):
   jobs=[(v,b,c,n) for v,b,c in variants for n in [1,8]]
   shift=(repeat+1)%len(jobs);jobs=jobs[shift:]+jobs[:shift]
   if repeat%2:jobs.reverse()
   for version,binary,cwd,participants in jobs:
    args=scenario['args']+['--compute-threads',str(participants),'--gradient-backend','cpu','--compute-telemetry','off']
    if a.verify:
     # Full timing windows retain end-state equality. Per-tick diagnostics use
     # a bounded prefix to fit the shared machine's available disk space.
     limit=args.index('--ticks')+1
     args[limit]=str((12000 if scenario['id']=='playground-12k' else 24000 if scenario['id']=='playground-24k' else 0)+1024)
     args+=['--telemetry','checksums']
    dest=out/scenario['id']/str(repeat)/f'{version}-{participants}'
    row={'scenario':scenario['id'],'version':version,'participants':participants,'repeat':repeat,**execute_quiet(binary,args,dest,cwd=cwd)}
    result=row['result']; assert result['compute_threads']==participants
    signature={k:result[k] for k in ['ticks','termination','initialChecksum','finalChecksum']}
    if a.verify:
     signature['traces']={f.name:digest(f) for f in sorted(dest.glob('*.checksums'))}
     assert len(signature['traces'])==3
     for f in sorted(dest.glob('*.checksums')):
      if f.name=='game.replay.checksums':
       # Keep its exact comparison digest; avoid retaining bulky component detail.
       f.unlink()
      else:
       with f.open('rb') as src,gzip.open(str(f)+'.gz','wb',compresslevel=6) as dst:shutil.copyfileobj(src,dst)
       f.unlink()
    key=(scenario['id'],version)
    if key in refs:assert refs[key]==signature,(key,refs[key],signature)
    refs[key]=signature;row['signature']=signature
    row['simulation_s']=result['run_ns']/1e9;row['run_cpu_s']=result['benchmark_run_cpu_ns']/1e9
    row['p99_ms']=result['tick_p99_ns']/1e6;row['rss_mib']=row['peak_rss_bytes']/1024**2
    row['units']=sum(t['units'] for t in result['teams'])
    ticks=result['ticks']-(12000 if scenario['id']=='playground-12k' else 24000 if scenario['id']=='playground-24k' else 0)
    row['tps']=ticks/row['simulation_s']
    rows.append(row);log.write(json.dumps(row)+'\n');log.flush()
    print(scenario['id'],repeat,version,participants,round(row['simulation_s'],4),flush=True)
summary=[]
if not a.verify:
 for scenario in manifest['scenarios']:
  for n in [1,8]:
   entry={'scenario':scenario['id'],'participants':n}
   for metric in ['simulation_s','run_cpu_s','p99_ms','rss_mib','units','tps']:
    values={v:statistics.median(r[metric] for r in rows if r['scenario']==scenario['id'] and r['participants']==n and r['version']==v and r['repeat']>=0) for v,b,c in variants}
    values['vs_master_pct']=100*(values['pr']/values['master']-1);values['vs_before_pct']=100*(values['pr']/values['before']-1)
    entry[metric]=values
   summary.append(entry)
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Completed',len(rows),'runs',flush=True)
