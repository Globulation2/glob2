import json,xml.etree.ElementTree as E
from pathlib import Path
out=Path(__file__).resolve().parent
label=lambda c:c.get('classname','')+'/'+c.get('name','')
failed=lambda c:c.find('failure') is not None or c.find('error') is not None
cases=E.parse(out/'engine-resumed.xml').findall('.//testcase')
initial_fail={label(c) for c in cases if failed(c)}
final_files=['army-final.xml','catalog-final.xml','farm-final.xml','map-win-final.xml','goldens-final.xml','maxima-final.xml','js-final.xml','js-economic-final.xml','final-focused.xml']
passed=set()
for name in final_files:
 passed.update(label(c) for c in E.parse(out/name).findall('.//testcase') if not failed(c) and c.find('skipped') is None)
resolved=initial_fail & passed
pending=initial_fail-passed
unit=E.parse(out/'unit.xml').findall('.//testcase')
unit_failed={label(c) for c in unit if failed(c)}
unit_passed={label(c) for c in E.parse(out/'unit-recheck.xml').findall('.//testcase') if not failed(c)}
base_failed={label(c) for c in E.parse(out/'master-unit.xml').findall('.//testcase') if failed(c)}
summary={'native':{'selected':1612,'initial_completed_passes':80,'resumed_cases':len(cases),'resumed_passes':sum(not failed(c) for c in cases),'new_renamed_absence_case_passed':1,'resolved_failure_count':len(resolved),'resolved_failures':sorted(resolved),'unresolved_cases':sorted(pending),'final_passed_count':80+sum(not failed(c) for c in cases)+1+len(resolved),'note':'Broad run retained old fixture failures; listed focused reruns resolve these. Timeout is coverage limit, not a passing case.'},'unit':{'selected':len(unit),'skipped':sum(c.find('skipped') is not None for c in unit),'original_failed_cases':sorted(unit_failed),'resolved_on_recheck':sorted(unit_failed & unit_passed),'confirmed_baseline_failures':sorted(unit_failed & base_failed),'final_passed_count':len(unit)-len(unit_failed)-sum(c.find('skipped') is not None for c in unit)+len(unit_failed & unit_passed)}}
(out/'coverage-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
