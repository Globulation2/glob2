# Independent review of gameplay recording PR 622

Reviewed the feature diff against master `525d165aa` and surrounding SDL3 presentation, immutable-scene, mixer, lifecycle, process-launch and test code. This report describes findings in the initial implementation inspected during the parent agent's ongoing revisions, so line numbers and implementation may subsequently change. No production files were edited and no comments were published.

## Prioritized actionable findings

### P1: SDL3 multi-buffer refills discard recorded audio

Locations: `src/SoundMixer.cpp:264-281`; `libgag/src/GameplayRecording.cpp:192-205,307-319`.

The SDL3 callback supports `additional` spanning several device buffers, divides it into 1024 stereo-frame chunks, and calls `Recorder::audio()` separately for every chunk. Each call starts a new timestamp at `now()`. Two chunks submitted in the same callback consequently have almost the same start time, although they represent consecutive PCM. After writing the first 1024 frames, the encoder sees the second chunk as approximately 1024 frames behind. This exceeds its 882-frame jitter tolerance, so the second chunk is dropped as an overlap. Larger refill requests lose proportionally more audio, and later padding inserts silence. This can happen with a normal SDL3 device request rather than queue overflow; the dropped sample counter does not expose it.

Give the complete SDL callback one timestamp and advance it by the frames mixed throughout that callback. Keep drift correction between callbacks, not between artificially split chunks. Add a regression case delivering distinguishable adjacent 1024-frame buffers in a single callback/burst and inspect decoded PCM to ensure both are present in order. The current unit fixture sends only 441-frame buffers separated by 10 ms, and the presentation fixtures mute their actual mixer, so neither covers this production behavior.

### P2: Final publication is no-overwrite but not atomic

Location: `libgag/src/GameplayRecording.cpp:405-409` in the original implementation.

Copying the finished video directly to its ordinary final path exposes a partially copied file. Disk exhaustion or interruption can leave a truncated normal `.mp4`, while an independently created JSON/events sidecar can cause a later copy to fail after the video has already been published. If the events copy fails after the manifest copy, a complete=true ordinary manifest can coexist with a Failed recorder and an incomplete retained work manifest. An exclusive reservation prevents cooperating recorder instances choosing the same name; it does not make the three copies transactional or protect against external files arriving later.

Stage and validate metadata first, publish the video with a same-filesystem atomic no-replace operation as the completion point, and define rollback/recovery for owned metadata. Do not delete externally created paths. Treat cleanup failures after successful publication separately from encoding failure. Parent acknowledged and plans to implement this.

### P2: Producer failures can be finalized as successful recordings

Locations: `libgag/src/GameplayRecording.cpp:94-98,178-180,353-356,389-411`; `libgag/src/GraphicContext.cpp:952-955`.

`frame()` can call `Impl::fail()` when surface conversion fails. This sets Failed and a stop time, but the worker merely checks !active(), drains the duration and executes the normal successful mux/publication path, eventually overwriting Failed with Complete and publishing complete=true. Separately, presentation capture exceptions log an event and call stop(), leaving `status.error` empty. That contradicts documentation promising capture errors in recording controls.

Represent a producer failure distinctly from an ordinary stop and propagate it into the worker's terminal result; retain failed-session diagnostics instead of declaring success. Provide a supported producer error method for the presentation integration. Snapshot `error` under the same mutex used by `fail()` before writing a manifest: the manifest currently reads the string without synchronization, while a main-thread frame failure may mutate it. Verify a forced capture failure during encoding produces a stable Failed status and incomplete manifest.

### P2: Journal append order is not chronological

Locations: `libgag/src/GameplayRecording.cpp:359-383`; `docs/features/gameplay-recording.md` events-file description.

Each output iteration drains every pending event, irrespective of its timestamp, before writing derived chapter/resize/gap records for the current video slot. The intentional 50 ms presentation delay means an event at 140 ms can be written first, followed by a chapter at 100 ms. This happens in ordinary operation and violates the documented chronological JSONL contract. Downstream sequential consumers can apply an event before the earlier context transition.

Drain timestamped events only through the current output slot and merge them with generated entries in timestamp order. Handle the final residual events explicitly. Alternatively establish a documented event-sequence contract and require consumers to sort timestamps, but avoid the current inaccurate chronology promise.

## Integration observations and limits

- The original serial `drawFrame()` briefly contained an undefined `scene` use alongside its existing serial matchFrame call. Parent removed it while this review was in progress. The threaded `drawSession()` correctly uses the immutable scene's tick and tickInterval; main-thread capture/context ownership should remain explicit.
- The worker queues are bounded: three queued frames, 128 preallocated audio blocks and a separate two-second sample budget, and 1024 context events. Worker-side write deadlines and bounded child waits provide eventual stop progress rather than an unbounded pipe wait. The frame capture itself still performs synchronous readback and allocations on the main thread, as documented.
- The audioError handoff is protected by the atomic audioFailed flag and eventual join. Context accesses are main-thread-owned and copied into queued frames; the worker uses its copied Context rather than the live Context. Public options/control/context ownership should be more explicitly documented, especially status() versus main-thread-only start/stop/frame calls and audio's interleaved stereo sample count.
- POSIX subprocess arguments and Windows command-line quoting avoid a shell. Child handles/descriptors are explicitly managed; output file paths remain UTF-8-aware on Windows. Supported desktop platform behavior still requires actual compilation/encoding coverage; this static review does not establish it.
- Exact extraction command construction is reasonable: accurate input seek plus re-encoding by default, explicit approximate stream copy, stripping source chapters and retaining source semantic context in a sidecar. Five Python recording-tool tests passed locally. They test argument construction and manifest selection, not decoded clip boundaries or sound alignment.
- The real-encoder unit test validates metadata using substring searches and video file size. It does not establish an AAC track exists, expected video frames/colors survived, audio is synchronized, or chapter cuts start/end at the desired decoded frames. Add meaningful decoder/probe-based assertions for those boundaries.
- Integration checksum comparison runs serial stepSession calls and then presents; it does not exercise the production simulation runner. The new immutable-scene metadata integration deserves a threaded rendering fixture, with checksums taken through an appropriate parked/simulation-side mechanism rather than concurrent reads of live Game state.
- The standalone multiplayer process provides useful isolation for SDL driver changes and user profiles. Comparing two recording peers establishes they agree with each other, but not equivalence to unrecorded peers. Keep that validation claim scoped precisely.

## Code-quality cleanup suggestions

1. Separate the large worker routine into audio timeline/encoding, video scheduling/canvas, chapter/journal, and manifest/publication responsibilities. Preserve ownership through small private implementation objects rather than exposing game state or proliferating public methods.
2. Centralize state transitions and terminal outcomes so Failed cannot be overwritten by a normal stop path. Define when error/path remain readable and when recording can restart.
3. Use named sample-rate, channel-count, callback-capacity and latency constants; `882`, `44100 * 2 * 2`, `4096`, `50000` and `250000` currently scatter timing policy across callbacks and workers.
4. Name the frame/timestamp units directly and make the stereo sample count API clear. Add callback burst semantics rather than inferring a new wall-clock start for every chunk.
5. Prefer local stream helpers and conventional formatting over compound single-line condition/update/throw statements. The current style makes resource lifetime, error paths and timing arithmetic harder to review.
6. Keep the feature guide durable; retain test artifacts, transient build reports and this review only under ignored evidence/work directories. Report remaining platform and playtesting gaps honestly.

No claim of a current full build, cross-platform checksums, actual GPU footage, or human playtesting is made by this report. Parent is performing integration builds and revisions independently.

## Re-review of the revised live worktree

The four original findings are resolved in the revised implementation for their reported failure conditions:

- **Audio batching:** `SoundMixer::streamAudio()` now takes one callback timestamp and advances it by the cumulative frames before each chunk. `Recorder::audio()` advances timestamps inside a larger submission. Consecutive 1024-frame chunks therefore reach the encoder with successive starts rather than overlapping starts. The remaining per-block integer rounding is under one sample and lies comfortably within the jitter tolerance. The decoded four-chunk PCM regression now checks the interiors all retain energy; it directly covers the original silent-chunk regression, though checking the different tones would additionally prove ordering.
- **Publication:** metadata is linked first and the finished video is hard-linked last. Each link is no-replace and exposes a completed inode atomically. A collision rolls back only paths equivalent to the sources linked by this operation. Cleanup failure after publication is a warning rather than a false encoding failure. Filesystems without hard-link support fail safely while retaining compressed intermediates; that portability limitation should be mentioned in the feature guide.
- **Producer failure:** `abort()` records a capture error and marks the recorder failed. The worker checks capture health before encoding and after encoder completion, and manifest serialization snapshots error under its mutex. GraphicContext now calls abort for capture exceptions. The new forced-abort regression covers stable Failed/incomplete output. There remains a separate control/failure state-transition race described below.
- **Journal chronology:** the worker drains only events whose timestamps are no later than its current video slot, then emits generated entries for that slot. Residual events are drained through final duration. Given the documented main-thread event ownership and monotonic clock, this preserves chronological append order.

Code organization is improved by extracting audio encoding and metadata/context/publication responsibilities. Named budgets and timing constants, explicit thread/sample-count contracts, and conventional formatting make the lifecycle substantially easier to inspect. Windows temporary launch resources now use RAII and handle allow-list failures are checked. No simultaneous builds or platform tests were run during this re-review.

### Remaining P2: stop can overwrite an encoder failure with permanent Finalizing

Location: `libgag/src/GameplayRecording.cpp`, `Recorder::stop()`.

The main thread checks active(), then unconditionally stores stoppedAt and State::Finalizing. The encoder worker can call fail() between that check and the state store. In this interleaving, the worker sets Failed and finishes, but stop() overwrites Failed with Finalizing. No worker remains to advance the state. Starts then always reject, and the shutdown screen waits forever for finalization despite the worker being finished. An ordinary quit/stop concurrent with a preflight, pipe, or storage failure can trigger this; no undocumented concurrent control caller is needed.

Make the active-to-Finalizing transition conditional/atomic and serialize the stop timestamp/state publication against fail(). For example, coordinate both mutations under the state/error mutex, or use an appropriate compare-exchange transition while preserving the stop-time publication order. Preserve terminal Failed/Complete states. The parent was notified immediately.

### Remaining P2: final journal close failure is not checked

Location: `libgag/src/GameplayRecording.cpp`, final `journal.close()` before `publishCompletedRecording()`.

Most journal paths flush and verify, but a resize record can be written without a chapter, gap or event flush in that iteration. If the final buffered write/close fails, the code still publishes the completed video and manifest and the truncated journal. Check the stream after closing before publishing. The parent was notified.

Coverage improvements inspected: a real decoded PCM burst regression, forced abort/publication collisions, FFprobe codec/chapter/duration/journal checks, decoded extraction first-frame checks, and a production threaded runner comparison using replay checksum sidecars after runner shutdown. These address the previously identified coverage omissions in structure; their current passing status and platform coverage remain the parent's validation responsibility.

## Final follow-up verification

Both remaining P2 findings are now resolved in the live code:

- `fail()` publishes its error, stop time and Failed state while holding the same mutex used by `stop()`. Stop conditionally transitions Starting/Recording to Finalizing, preserving terminal states, and sets the timestamp before the transition. The worker's Starting-to-Recording compare-exchange cannot undo Finalizing or Failed. The reported quit/failure interleaving therefore no longer leaves an orphan Finalizing state.
- `journal.close()` is checked before publication, and a close/write failure follows the retained-intermediate failure path.

The durable feature guide now explains atomic metadata-first hard-link publication, the video completion point, and safe retention on filesystems without hard-link support.

The final mixer adjustment adds already-queued input PCM duration to the callback's initial timestamp, then advances by cumulative refill frames. I checked the local SDL3 header contract: `SDL_GetAudioStreamQueued()` reports original input bytes not yet consumed/conversion-ready output bytes, and the callback runs before the stream obtains its requested data while holding its stream lock. The mixer fixes its input format at signed 16-bit stereo/44100 Hz, so converting that queued byte count with its input bytes-per-second is appropriate and avoids assigning newly appended PCM the same start as preceding queued PCM. This remains a software stream timeline rather than a direct measurement of hardware presentation latency; no stronger device-level synchronization claim is established by static review.

No unresolved concrete correctness findings remain from this independent review. The reviewed changes retain explicit failure behavior and substantially clearer ownership/resource lifetime. Current build results, Windows/Linux execution, GPU recordings, and actual playback feel remain external validation limits, not inferred successes from this code inspection.
