import sys,subprocess,json,hashlib
from pathlib import Path
sys.path.insert(0,'test')
from check_telemetry_simulation import SCENARIOS
binary=str(Path('build/native-coverage-torus/src/glob2').resolve())
for workers in (1,4):
 for save,ticks,fixture in SCENARIOS:
  out=Path('artifacts/telemetry-c204')/f'{save.stem}-workers{workers}';out.mkdir(exist_ok=True)
  cmd=[binary,'--run-game','--load-game',str(save),'--ticks',str(ticks),'--telemetry','checksums','--output-dir',str(out),'--compute-threads',str(workers),'--compute-experiments','ai']
  (out/'command.json').write_text(json.dumps(cmd));r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/'run.log').write_text(r.stdout)
  trace=out/'game.replay.checksums';print(workers,save.name,r.returncode,hashlib.sha256(trace.read_bytes()).hexdigest() if trace.exists() else 'MISSING',flush=True)
