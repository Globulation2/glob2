from pathlib import Path
import json,math,random,statistics,collections
V=Path(__file__).resolve().parent
rows=[]
for h in ['therig','devlaptop']:
 p=V/f'{h}-results.json'
 if p.exists():rows+=json.loads(p.read_text())
assert len(rows)==128,len(rows)
groups=collections.defaultdict(list)
for r in rows:groups[r['case']['generator']].append(r)
def total(rs,v,k):return sum(r['variants'][v][k] for r in rs)
def ratio(rs,k):return total(rs,'permanent',k)/total(rs,'master',k)-1
def cpu(rs):return math.exp(statistics.mean(math.log(r['variants']['permanent']['cpu_ms_per_tick']/r['variants']['master']['cpu_ms_per_tick']) for r in rs))-1
def starve(rs):return (total(rs,'permanent','starved_common_window')/total(rs,'permanent','sampled_unit_ticks_common_window'))/(total(rs,'master','starved_common_window')/total(rs,'master','sampled_unit_ticks_common_window'))-1
metrics={'harvest':lambda rs:ratio(rs,'harvested_common_window'),'meals':lambda rs:ratio(rs,'meals_common_window'),'population_time':lambda rs:ratio(rs,'sampled_unit_ticks_common_window'),'cpu_per_tick':cpu,'starvation_rate':starve}
rng=random.Random(92928);samples={k:[] for k in metrics};families=sorted(groups)
for _ in range(5000):
 sample=[r for family in rng.choices(families,k=len(families)) for r in groups[family]]
 for k,f in metrics.items():samples[k].append(f(sample))
summary={}
for k,f in metrics.items():
 vals=sorted(samples[k]);summary[k]={'change':f(rows),'ci95':[vals[125],vals[4874]]}
summary['totals']={v:{k:total(rows,v,k) for k in ['harvested_common_window','meals_common_window','starved_common_window','sampled_unit_ticks_common_window','cpu_seconds']} for v in ['master','permanent']}
summary['cpu_by_host']={h:cpu([r for r in rows if r['case']['host']==h]) for h in ['therig','devlaptop']}
summary['families']={str(g):{k:f(rs) for k,f in metrics.items() if k!='starvation_rate'} for g,rs in groups.items()}
compute=json.loads((V/'compute-results.json').read_text());summary['crowded_cpu']={v:statistics.mean(r['cpu_seconds'] for r in compute if r['variant']==v) for v in ['master','permanent']}
summary['crowded_cpu']['change']=summary['crowded_cpu']['permanent']/summary['crowded_cpu']['master']-1
(V/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='families'},indent=2))
lines=['# Permanent wheat versus master','', '128 paired starts: 16 map families × four map seeds × two orientations. Runs capped at 32,768 ticks. Food and population measurements use each pair’s common observed window. CPU uses whole-run process CPU per tick. Confidence intervals bootstrap whole map families (5,000 draws); rotations are not treated as independent samples. These retained maps are exploratory, not a new holdout.','', '| Metric | Change | 95% interval |','|---|---:|---:|']
for k,d in summary.items():
 if 'ci95' in d:lines.append(f"| {k} | {d['change']:+.1%} | {d['ci95'][0]:+.1%} to {d['ci95'][1]:+.1%} |")
d=summary['crowded_cpu'];lines+=['',f"Crowded save: {d['master']:.3f}s master → {d['permanent']:.3f}s permanent ({d['change']:+.1%}), mean of four matched physical-core repetitions of 8,192 ticks.",'','All machine-level commands, map seeds and binary hashes are retained alongside this report. CPU differences include altered game trajectories/population, not only planner overhead. An unrelated build overlapped devlaptop tournament runs, so CPU is also reported separately by host in summary.json. The initial devlaptop isolated CPU attempt is excluded; the reported crowded-save test ran on therig after its tournament. This measures removing maturity from current master; it does not isolate the benefits of expansion support or wood reserves, which both versions contain.','', 'Windows parity and human gameplay review are not verified.']
(V/'REPORT.md').write_text('\n'.join(lines)+'\n')
