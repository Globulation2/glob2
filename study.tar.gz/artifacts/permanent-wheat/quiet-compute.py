from pathlib import Path
import subprocess,time,runpy
V=Path('artifacts/permanent-wheat')
deadline=time.monotonic()+3600
while not (V/'therig-results.json').exists():
 if time.monotonic()>deadline:raise TimeoutError('tournament not finished')
 time.sleep(10)
# Refuse to label this idle-machine timing if competing game/build jobs remain.
p=subprocess.run(['pgrep','-x','glob2|cc1plus|clang|clang++'],capture_output=True,text=True)
if p.returncode==0:raise RuntimeError('Competing game/compiler processes: '+p.stdout)
runpy.run_path(str(V/'compute.py'),run_name='__main__')
