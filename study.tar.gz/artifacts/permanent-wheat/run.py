from pathlib import Path
import subprocess,json,random,concurrent.futures,sys,socket,time,hashlib
from metrics import analyze
R=Path.cwd();V=R/'artifacts/permanent-wheat';host=sys.argv[1];slots=int(sys.argv[2]);cases=[c for c in json.loads((V/'cases.json').read_text()) if c['host']==host]
def run(c):
 order=['master','permanent'];random.Random(c['seed']+c['rotation']).shuffle(order)
 for variant in order:
  out=V/'games'/c['id']/variant;out.mkdir(parents=True,exist_ok=True)
  binary=V/f'glob2-{variant}'
  cmd=[str(binary),'--run-game','--map-file',str(V/'maps'/f"{c['id']}.map"),'--game-seed',str(c['seed']),'--player','maxima','--player',c['opponent'],'--ticks','32768','--output-dir',str(out),'--telemetry','team-timeline','--replay','false']
  (out/'command.json').write_text(json.dumps(cmd))
  with (out/'stdout.log').open('w') as log:subprocess.run(['/usr/bin/time','-f','%U %S %e','-o',str(out/'cpu.txt'),*cmd],stdout=log,stderr=log,check=True,timeout=1800)
  assert json.loads((out/'result.json').read_text())['ticks']>0
 outs={v:V/'games'/c['id']/v for v in order};end=min(json.loads((o/'result.json').read_text())['ticks'] for o in outs.values())
 row={'case':c,'host':socket.gethostname(),'variants':{v:analyze(o,end=end) for v,o in outs.items()}}
 (V/'games'/c['id']/'metrics.json').write_text(json.dumps(row,indent=2));print('PAIR_DONE',c['id'],flush=True)
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=slots) as pool:rows=list(pool.map(run,cases))
(V/f'{host}-results.json').write_text(json.dumps(rows,indent=2));print('DONE',len(rows),flush=True)
