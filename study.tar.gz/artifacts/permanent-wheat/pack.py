from pathlib import Path
import json,tarfile,hashlib,io,sys,time
V=Path('artifacts/permanent-wheat');host=sys.argv[1];deadline=time.monotonic()+3600
while not (V/f'{host}-results.json').exists() or (host=='therig' and not (V/'compute-results.json').exists()):
 if time.monotonic()>deadline:raise TimeoutError('runs unfinished')
 time.sleep(10)
manifest={}
with tarfile.open(V/f'{host}-evidence.tar.gz','w:gz') as t:
 for p in sorted(list((V/'games').rglob('*')) + (list((V/'compute').rglob('*')) if host=='therig' else [])):
  if not p.is_file() or p.name not in ['stdout.log','cpu.txt','command.json','result.json','metrics.json']:continue
  if p.name=='stdout.log':
   raw=p.read_bytes();manifest[str(p.relative_to(V))]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
   data=b''.join(l for l in raw.splitlines(keepends=True) if l.startswith((b'GLOB2_PERF_FINAL ',b'GLOB2_ECON ',b'GLOB2_MEASURE ')))
   info=tarfile.TarInfo(str(p.relative_to(V)));info.size=len(data);t.addfile(info,io.BytesIO(data))
  else:t.add(p,arcname=str(p.relative_to(V)))
 for p in [V/f'{host}-results.json',V/'compute-results.json']:
  if p.exists():t.add(p,arcname=p.name)
 data=json.dumps(manifest,indent=2).encode();info=tarfile.TarInfo('original-stdout-hashes.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
print('PACKED',host,flush=True)
