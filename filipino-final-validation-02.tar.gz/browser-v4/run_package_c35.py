from pathlib import Path
import subprocess,os,json,hashlib,time
R=Path.cwd();K=R/'artifacts/filipino-localization';O=K/'browser-v4/attempt-c35a7b2e-85634fec8639';revision='c35a7b2ebbdb83b264ecc6b0bcf29d89ef926fab'
def source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==revision
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True).strip()
source();exe=subprocess.check_output(['python3','tools/package_assets.py','--encoder-python'],text=True).strip();env=dict(os.environ,PYTHONPATH=str(K/'python-tools'));assert subprocess.check_output([exe,'-c','import fontTools;print(fontTools.__version__)'],env=env,text=True).strip()=='4.66.1'
cmd=[exe,str(K/'packaging/verify_browser_v5.py'),'--revision',revision,'--build-log',str(K/'browser-kit6-final-build.log'),'--output',str(O/'packaging'),'--static',str(O/'static-release'),'--font-base','0a5d4f68d9b8ad6faa6f4a67ab7167f3104101eb','--startup-font-revision','43444d65bf8b4b6405bdc528de836f5174abb378','--startup-font-sha256','466fb75762954c81cd683538f08c4e36773dc27cb5c11339e3e1a675777a6048','--require-glyphs','--require-http','--caddy',str(K/'packaging/bin/caddy')];t=time.monotonic()
with (O/'packaging-standalone.log').open('x') as stream:r=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=1800)
source();(O/'packaging-execution.json').write_text(json.dumps({'revision':revision,'source_clean_before_after':True,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-t,'log_sha256':hashlib.sha256((O/'packaging-standalone.log').read_bytes()).hexdigest()},indent=2)+'\n');print(r.returncode);raise SystemExit(r.returncode)
