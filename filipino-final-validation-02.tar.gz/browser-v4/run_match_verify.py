"""Run only the two existing production-Wasm committed-match checks with source-bound evidence."""
from pathlib import Path
import argparse,subprocess,json,hashlib,os,time,uuid,datetime,shutil,importlib.util
R=Path(__file__).resolve().parents[3];K=R/'artifacts/filipino-localization'
p=argparse.ArgumentParser();p.add_argument('--revision',required=True);p.add_argument('--build-receipt',type=Path,required=True);a=p.parse_args()
H=lambda x:hashlib.sha256(x).hexdigest()
spec=importlib.util.spec_from_file_location('P',R/'test/build_provenance.py');P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)
def source():
 s=P.source_identity(R);assert s['revision']==a.revision and not s['dirty'],s;return s
before=source();b=json.loads(a.build_receipt.read_text());assert b['status']=='passed' and b['source']==b['source_after']==before,b
O=K/'browser-matchverify'/('attempt-'+a.revision[:8]+'-'+uuid.uuid4().hex[:12]);O.mkdir(parents=True);print('MATCH_VERIFY_ATTEMPT '+str(O),flush=True)
paths=['browser/tests/determinism.spec.js','browser/tests/runtime-host.js','test/fixtures/multiplayer/FourSquares1.g2mr','test/fixtures/multiplayer/FourSquares1.verify-trace.txt','maps/FourSquares1.map.gz','src/game/SimRevision.h','src/app/Version.h','build/emscripten/client/release/index.js','build/emscripten/client/release/index.wasm','build/emscripten/client/release/threaded/index.js','build/emscripten/client/release/threaded/index.wasm']
# The tracked test also writes these six legacy paths; freeze any previous own outputs first.
legacy=[]
for sub in ['', 'verify-threaded']:
 for name in ['verify-match.checksums.txt','verify-match.verdict.json','verify-match.log']:
  f=R/'artifacts/browser-determinism/wasm'/sub/name;legacy.append(f)
  if f.exists():
   assert f.stat().st_size<=2*1024*1024,'Unexpected legacy evidence size; do not truncate'
   dest=O/'prior-global-wasm'/sub/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
record={'status':'running','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_before':before,'build_receipt_sha256':H(a.build_receipt.read_bytes()),'runner_sha256':H(Path(__file__).read_bytes()),'input_sha256':{x:H((R/x).read_bytes()) for x in paths if (R/x).exists()},'prior_outputs_frozen':True}
(O/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,PATH='/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH'],GLOB2_TEST_URL='http://127.0.0.1:45221',GLOB2_TEST_BUILD_DIR=str(R/'build/emscripten/client/release'),PLAYWRIGHT_JSON_OUTPUT_NAME=str(O/'playwright-results.json'))
cmd=['npx','--no-install','playwright','test','tests/determinism.spec.js','--grep','WebAssembly verifies the committed match record','--project=chromium','--reporter=line,json','--output='+str(O/'playwright')];start=time.monotonic()
with (O/'run.log').open('x') as stream:r=subprocess.run(cmd,cwd=R/'browser',env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=900)
record.update(command=cmd,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,source_after=source(),log_sha256=H((O/'run.log').read_bytes()))
golden=(R/'test/fixtures/multiplayer/FourSquares1.verify-trace.txt').read_text().replace('\r\n','\n');traces=list((O/'playwright').rglob('verify-match.checksums.txt'));rows=[]
for f in traces:
 text=f.read_text().replace('\r\n','\n');rows.append({'path':str(f.relative_to(O)),'sha256':H(f.read_bytes()),'lines':len(text.splitlines()),'matches_committed_native_golden':text==golden})
record['traces']=rows
for f in legacy:
 if f.exists():
  dest=O/'actual-global-wasm'/f.relative_to(R/'artifacts/browser-determinism/wasm');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
js=json.loads((O/'playwright-results.json').read_text());record['playwright_stats']=js['stats'];ok=r.returncode==0 and len(rows)==2 and all(x['matches_committed_native_golden'] and x['lines']>600 for x in rows) and record['source_after']==before
record['status']='passed' if ok else 'failed';record['limits']='Linux Chromium production serial/threaded Wasm vs exact committed native golden. Does not establish physical Android/iOS, Windows or macOS execution.'
(O/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(record['status'],flush=True);raise SystemExit(0 if ok else 1)
