from pathlib import Path
import subprocess
K=Path('artifacts/filipino-localization/master-delta6/runner-candidate');master='0a5d4f68d9';old='d5f8d22f666f79a8363a47e5000875b5de8a197e'
show=lambda rev,p:subprocess.check_output(['git','show',rev+':'+p],text=True)
main=show(master,'tools/localization/google_draft.py');seg=show(old,'tools/localization/google_draft.py');tests=show(master,'test/test_google_draft.py');segtests=show(old,'test/test_google_draft.py')
# Preserve upstream cross-backend control lock; old editorial outer lock participates.
oldlock="    with file_lock(output / '.google-draft.lock'):\n        yield"
newlock="""    with file_lock(output / 'google-draft-control' / '.lock'), file_lock(output / '.google-draft.lock'):
        plain_ledger = output / 'google-nmt' / 'ledger.json'
        if plain_ledger.exists() and json.loads(plain_ledger.read_text(encoding='utf-8')).get('attempts'):
            raise ValueError('This kit has a paid ledger for the other protection mode; retain its original plain backend. Ledgers are never merged or reset.')
        yield"""
assert oldlock in seg;seg=seg.replace(oldlock,newlock)
# Main Tamil entry keeps its unchanged provider/cache implementations. Legacy entry dispatch is explicit.
needle="    if mode in ('plan', 'blank-fill') or any(value.split('=', 1)[0] in segmented_flags for value in arguments):"
replacement="""    legacy_editorial_flags = ('--max-usd', '--batch-characters')
    if mode in ('plan', 'blank-fill', 'editorial') or any(value.split('=', 1)[0] in segmented_flags + legacy_editorial_flags for value in arguments):"""
assert needle in main;main=main.replace(needle,replacement)
needle='    segmented_ledger = output / \'google-budget.json\''
replacement="""    if any(p.stat().st_size for p in (output / 'google').glob('*/attempts.jsonl')):
        raise ValueError('This kit has a paid editorial ledger for the other protection mode; retain --mode editorial. Ledgers are never merged or reset.')
    segmented_ledger = output / 'google-budget.json'"""
assert needle in main;main=main.replace(needle,replacement)
# Keep established Python run() callers working; overlapping protection/translate names use explicit backends.
needle='\ndef main():'
wrapper='''
def run(*args, **kwargs):
    """Compatibility entry for established editorial/segmented Python callers."""
    spec = importlib.util.spec_from_file_location('google_draft_segmented', Path(__file__).with_name('google_draft_segmented.py'))
    backend = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(backend)
    return backend.run(*args, **kwargs)

'''
assert needle in main;main=main.replace(needle,'\n'+wrapper+needle,1)
segtests=segtests.replace("'tools/localization/google_draft.py'","'tools/localization/google_draft_segmented.py'").replace('class GoogleDraftTest(unittest.TestCase):','class SegmentedGoogleDraftTest(unittest.TestCase):',1)
# The existing ASCII subprocess must exercise this module, not a main-module protection API.
segtests=segtests.replace("/ 'google_draft.py'", "/ 'google_draft_segmented.py'")
# Master imports one segmented suite; import all retained distinct suites so ordinary existing command covers them.
tests=tests.replace('from test_google_draft_segmented import SegmentedGoogleDraftTest','from test_google_draft_segmented import (SegmentedGoogleDraftTest, GooglePlanDraftTest,\n    GoogleMergedApiTest, NorwegianGoogleDraftTest, FilipinoEditorialGoogleDraftTest, GoogleWorkflowDispatchTest)')
needle='class BackendIsolationTest(unittest.TestCase):\n';assert needle in tests
tests=tests.replace(needle,needle+'''    def test_plain_and_html_reject_existing_filipino_editorial_campaign(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            ledger = output / 'google/fil/attempts.jsonl'
            ledger.parent.mkdir(parents=True)
            ledger.write_text('{"characters": 10}\\n', encoding='utf-8')
            for mode in ('plain', 'html'):
                with self.subTest(mode=mode):
                    with self.assertRaisesRegex(ValueError, 'paid editorial ledger'):
                        DRAFT.assert_backend_budget(output, mode)

''')
for rel,value in [('tools/localization/google_draft.py',main),('tools/localization/google_draft_segmented.py',seg),('test/test_google_draft.py',tests),('test/test_google_draft_segmented.py',segtests)]:
 p=K/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(value)
print('Prepared four ignored candidates only')
