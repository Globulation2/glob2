from pathlib import Path
import subprocess,os,hashlib,json,shlex,importlib.util,time
R=Path.cwd();O=R/'artifacts/filipino-localization/master-delta6/unit-focused';O.mkdir(exist_ok=False);H='1ff627f329996159ccbe8b5369857ba6814f04cd';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();E=dict(os.environ,GLOB2_SDL3_PREFIX=str(R/'artifacts/filipino-localization/sdl-reused'),LD_LIBRARY_PATH=str(R/'artifacts/filipino-localization/sdl-reused/lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''));rec={'revision':H,'scope':'Focused unit harness only; ordinary full unit link keeps all production/stub/support/library flags, omits only nonselected registry UNIT_TESTS','commands':[],'script_sha256':sha(__file__)}
def guard():assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==H and not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
def run(name,args):
 guard();p=O/(name+'.log');t=time.monotonic()
 with p.open('x') as f:q=subprocess.run(args,cwd=R,env=E,stdout=f,stderr=subprocess.STDOUT)
 guard();rec['commands'].append({'name':name,'argv':args,'exit_code':q.returncode,'seconds':time.monotonic()-t,'log_sha256':sha(p)});(O/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n');assert q.returncode==0;return p
p=run('dryrun',['python3','tools/dev_build.py','unit-tests','-n']);links=[shlex.split(l) for l in p.read_text().splitlines() if ' -o ' in l and '/test/glob2-unit-tests ' in l];assert len(links)==1;original=links[0]
spec=importlib.util.spec_from_file_location('registry',R/'test/tests.py');reg=importlib.util.module_from_spec(spec);spec.loader.exec_module(reg)
def name(entry):
 source=entry if isinstance(entry,str) else entry[0];return 'unit-'+source.lstrip('#').replace('/','_').rsplit('.',1)[0]+'.o'
alltests={name(e) for e in reg.UNIT_TESTS};selected={'unit-libgag_src_AssetLoaderTest.o','unit-libgag_src_SpriteSheetTest.o'};removed=[a for a in original if Path(a).name in alltests-selected];link=[a for a in original if a not in removed];assert all(sum(Path(v).name==x for v in link)==1 for x in selected)
rec.update(original_link_argv=original,focused_link_argv=link,omitted_registry_object_paths=removed,production_support_stubs_flags_identical=True);targets=[v for v in link if '/test/unit-' in v and v.endswith('.o')];rec['kept_object_targets']=targets
out=O/'build/test/glob2-unit-tests';out.parent.mkdir(parents=True);link[link.index('-o')+1]=str(out);run('ordinary-selected-build',['python3','tools/dev_build.py',*targets,'-j10']);run('link',link);normal=R/Path(original[original.index('-o')+1]).parent.parent;(O/'build/shaders').symlink_to(normal/'shaders',target_is_directory=True);run('actual-provenance',[str(out),'--list-test-cases']);rec['binary_sha256']=sha(out);rec['kept_object_sha256']={v:sha(R/v) for v in targets};rec['status']='built-focused';(O/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print('READY',out,flush=True)
