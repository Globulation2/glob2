from pathlib import Path
import json,hashlib,subprocess
D=Path(__file__).resolve().parent;R=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=lambda s:hashlib.sha256(s.encode()).hexdigest();s=json.loads((D/'source.json').read_text());t=json.loads((D/'final.json').read_text())
rationales=[
'Tanaw sa harap identifies the model front camera view rather than an instruction to move the model forward; stable front asset/view ID is untouched.',
'Tanaw sa likod names the rear camera angle without implying undo/back navigation; paired front/back model views are explicit.',
'Tanaw sa kaliwa names the left camera view; it does not swap the left and right model-side labels.',
'Tanaw sa kanan names the right camera view and remains parallel to the other three angle labels.',
'Nakapirming pose clearly names the nonanimated rest pose represented by an empty action ID; no freeze/stop gameplay action is implied.',
'Artista works as the broad music-release artist metadata label, covering credited performers/creators rather than restricting it to a composer or actor. Authored artist text is untouched.',
'Sinimulan is the completed-start state used for the matches-started chart series, not an imperative to start a game or a currently-running-only count.',
'Mga account bawat araw identifies the daily account count on the chart axis; it does not suggest account creation quotas.',
'Mga laban bawat araw identifies daily match counts and preserves the series context alongside started/completed/cancelled states.',
'Mga account ng bisita correctly distinguishes guest accounts from registered accounts without changing actual account IDs or sign-in behavior.',
'Mga nakarehistrong account identifies registered accounts and stays parallel to the guest series label.',
'Bagong soundtrack labels a newly composed music set rather than a new album release; it is the composer target when no parent generation is selected.',
'Hintaying matapos ang kasalukuyang kahilingan is a clear wait instruction for an active/busy request and does not ask the player to resubmit or spend another credit.',
'Hindi magamit ang pagbuo separates unavailable generation from saved content access; Mabubuksan pa rin explicitly preserves access to already saved music.',
'Magagamit na kredito para sa musika identifies an available Music-wallet credit needed for chat or creation. It does not claim that chatting consumes that credit.',
'The complete pricing sentence preserves all four conditions: discussion spends zero; one available Music credit is still required; creation starts automatically and deducts one on delivery; all three game moods are included. It does not charge per mood or per discussion turn.',
'Lumot at liwanag ng umaga translates the built-in suggestion title without treating it as a user-authored release or changing its stable English suggestion key.',
'The prompt preserves woodland warmth, flute/harp and plucked-string pizzicato, wandering-and-returning melody, quiet combat drums and a bassoon counterline. Labanan matches the actual Combat mood label rather than an unrelated player action.',
'Munting harding de-susi captures the small clockwork garden image as a suggestion title; de-susi conveys clockwork mechanism rather than a literal garden key or clock timetable.',
'The prompt retains gentle glass bells, rounded/full-bodied synth pads, curious unhurried character, an answering melody and a deeper pulse as the colony grows; it does not impose faster game speed.',
'Isang waltz para sa ulan preserves the built-in rain-waltz suggestion, including its dance/music genre, without translating authored content later entered by a player.',
'The prompt preserves folk waltz instrumentation, sparse breathing calm phrases, lilting building rhythm and warm low-register combat strings. Recorder is explicitly plawtang recorder, avoiding a recording device; Kalmado/Pagtatayo/Labanan match the existing three runtime mood names.',
'The unavailable-generation notice still promises access to saved projects; plural mga proyekto distinguishes the saved project collection from just the current draft.',
'The available Map-wallet credit requirement applies to both chat and building, without implying that a credit is consumed merely by starting discussion.',
'The Map pricing sentence keeps zero discussion spending, one available credit prerequisite, automatic creation on a creation request and exactly one deduction on delivery. No irreversible purchase or extra confirmation is invented.',
'Sine-save ang iyong proyekto names saving in progress and preserves the ellipsis; it does not say the save is already complete or instruct another save.',
'Hindi magamit ang pagbuo names unavailable generation without conflating the service state with insufficient credits or failed saves.',
'The Terrain pricing sentence preserves the same zero-cost discussion/available-credit prerequisite/automatic creation/one-credit-on-delivery contract using lupain for the Terrain wallet, not mapa.',
'Mga guhit ng kolonya correctly describes the fixed colony-stripe skin product/preset; it does not rename arbitrary user-authored skin names or suggest map grid lines.',
'Mga batik ng kolonya identifies the fixed spotted colony skin/preset and remains distinct from stripes; stable server SKU and preset-switch source names stay untouched.',
'Skin na walang pamagat is an untitled visual-skin fallback, not an anonymous player or missing artwork asset error. Authored nonblank skin titles remain unchanged.'
]
assert len(rationales)==len(s['entries'])==len(t)==31
loans={
'Static pose':{'pose':'Recognizable character/3D-editor posture term; kept for the nonanimated rest-pose selector, not a simulation action.'},
'Accounts per day':{'account':'Established Filipino online-interface noun; consistent with native/website account terminology.'},
'Guest accounts':{'account':'Established online identity noun; guest account status is distinct from registration.'},
'Registered accounts':{'account':'Established online identity noun, with Filipino registered modifier.'},
'New soundtrack':{'soundtrack':'Established music/game loan for a complete composed background-music set.'},
'Generation is unavailable. Saved music remains accessible.':{'save':'The inflected na-save is established interface usage and consistently names persisted music.'},
'An available Music credit is needed to chat or build.':{'chat':'Established conversational interface loan; makapag-chat is a natural Filipino verb form.'},
'Discussion spends no credits; 1 available Music credit is required. Creation requests build automatically · 1 credit on delivery. Includes all three moods.':{'mood':'Existing soundtrack term for the three game-responsive musical arrangements, not a new charge category.'},
'A warm woodland piece with flute, harp and gentle pizzicato. Let the melody wander and return; combat adds quiet drums and a bassoon counterline.':{'bassoon':'Precise instrument name; retaining it avoids substituting another wind instrument. Pizzicato is explained as string plucking in Filipino.'},
'Soft glass bells and rounded synth pads, curious and unhurried. A playful answering melody, with a deeper pulse as the colony grows.':{'synth pad':'Precise established electronic-music sound-layer term; surrounding Filipino describes its rounded/full-bodied sound.'},
'A waltz for the rain':{'waltz':'Specific musical dance genre; retaining it preserves the three-beat folk-waltz suggestion.'},
'A cozy folk waltz with recorder and kalimba. Sparse, breathing phrases for calm, a lilting rhythm for building, and warm low strings for combat.':{'folk waltz':'Specific music/dance style, not generic pleasant music.','recorder':'Precise instrument name, explicitly disambiguated by plawtang.','kalimba':'Specific thumb-piano instrument name; replacing it with a generic keyboard would alter the prompt.'},
'Generation is unavailable. Saved projects remain accessible.':{'save':'Inflected na-save consistently names persisted projects without claiming unsaved work is retained.'},
'An available Map credit is needed to chat or build.':{'chat':'Established conversational-interface loan in natural makapag-chat construction.'},
'Saving your project…':{'save':'Sine-save is the established ongoing-action Filipino UI form, distinct from completed na-save.'},
'Untitled skin':{'skin':'Established game appearance/customization noun; literal balat would misleadingly describe a biological surface rather than the saved visual design.'}}
entries=[]
for (key,source),why in zip(s['entries'].items(),rationales):
 value=t[key];e={'id':'online:'+key,'source':source,'source_value_sha256':h(source),'final_value':value,'final_value_sha256':h(value),'status':'approved','rationale':why}
 if key in loans:e['intentional_english_terms']=loans[key]
 entries.append(e)
ctx=['platform/apps/web/src/messages.ts','platform/apps/web/src/admin/Overview.tsx','platform/apps/web/src/music/Library.tsx','platform/apps/web/src/pages/music-studio/ideas.ts','platform/apps/web/src/pages/music-studio/Workspace.tsx','platform/apps/web/src/pages/studio/StudioWorkspace.tsx','platform/apps/web/src/pages/TerrainStudio.tsx','platform/apps/web/src/pages/Skins.tsx','platform/apps/web/src/skins/labels.ts','platform/apps/web/src/skins/useSkinDocument.ts']
r={'identity':'/root/adversarial_reviewer','role':'adversarial_reviewer','stage':'Independent Round3 final adversarial actual31pair reread after all prior stages','status':'approved','source_revision':s['merge_revision'],'source_program_sha256':s['source_sha256'],'source_snapshot_sha256':sha(D/'source.json'),'final_snapshot_sha256':sha(D/'final.json'),'reviewed_ids':[e['id'] for e in entries],'entries':entries,'entry_count':31,'accepted_english':[],'findings':[],'unresolved_major':0,'unresolved_critical':0,'unresolved_linguistic_uncertainty':0,'context_actually_read':[{'path':p,'sha256':sha(R/p),'scope':'Relevant labels/usage read, not a whole-file code review'} for p in ctx],'reference_terms':{'Calm':'Kalmado','Building':'Pagtatayo','Combat':'Labanan','Music':'Musika','Map':'Mapa','Terrain':'Lupain'},'limits':['Direct final31English/Filipino pairs only; existing6359 source/target pairs not freshly reread.','Agent-reviewed, no human speaker certification.','No target/source edits, paid calls, runtime or rendered-fit approval.','All31source values are simple strings; no plural or placeholder branch newly introduced.']}
out=D/'adversarial-review.json';assert not out.exists();out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(sha(out))
