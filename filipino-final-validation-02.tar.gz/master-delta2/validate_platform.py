from pathlib import Path
import subprocess,os,json,time,hashlib,concurrent.futures
r=Path.cwd();k=r/'artifacts/filipino-localization';env=dict(os.environ,PATH='/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin'+os.pathsep+os.environ['PATH']);commands=[('final-i18n-check',['npm','run','i18n:check']),('final-i18n-tests',['npm','test','--','packages/i18n/test']),('final-platform-typecheck',['npm','run','typecheck']),('final-platform-lint',['npm','run','lint'])]
def run(v):
 n,a=v;t=time.monotonic()
 with (k/(n+'.log')).open('wb') as log:q=subprocess.run(a,cwd=r/'platform',env=env,stdout=log,stderr=subprocess.STDOUT)
 return {'name':n,'argv':a,'exit_code':q.returncode,'seconds':time.monotonic()-t,'log':n+'.log','log_sha256':hashlib.sha256((k/(n+'.log')).read_bytes()).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:out=list(pool.map(run,commands))
x={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'commands':out};(k/'final-platform-results.json').write_text(json.dumps(x,indent=2)+'\n');print([(v['name'],v['exit_code']) for v in out]);assert all(not v['exit_code'] for v in out)
