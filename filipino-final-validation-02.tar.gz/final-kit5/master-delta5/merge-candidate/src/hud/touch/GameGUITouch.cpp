// SPDX-License-Identifier: GPL-3.0-or-later
#include "InGameTouchTheme.h"
#include "GameGUITouch.h"
#include <TouchText.h>
#include <FormatableString.h>
#include <InterfacePresentation.h>
#include "MobileSafeArea.h"
#include <HostViewport.h>
#include "ThumbSide.h"
#include "BrushCoverage.h"
#include <map>
#include <set>
#include "GameGUI.h"
#include "GameGUIDialog.h"
#include "GameGUIInternal.h"
#include "GlobalContainer.h"
#include "Unit.h"
#include "BuildingType.h"
#include "Order.h"
#include "Player.h"
#include "TeamStat.h"
#include "stats/MetricCatalog.h"
#include "render/Minimap.h"
#include "render/UnitMotion.h"
#include "render/UnitDrawGeometry.h"
#include <Toolkit.h>
#include <StringTable.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#ifdef __ANDROID__
#include <SDL3/SDL_system.h>
#include <jni.h>
#endif
#if defined(SDL_PLATFORM_IOS)
#include "mobile/ios/SafeArea.h"
#endif
using namespace GAGCore;

GameGUITouch::GameGUITouch(GameGUI &gui) : gui(gui)
{
	touchActive = phonePresentationRequested();
	hudMinimap = std::make_unique<Minimap>(globalContainer->runNoX, 128, 128, 0, 0, 128, 128,
										   Minimap::ShowFOW);
}
bool GameGUITouch::usesHUD() const
{
	return phonePresentationRequested();
}
MobileLayout GameGUITouch::layout() const
{
	auto *gfx = globalContainer->gfx;
	const double unit = gfx->logicalUnitsPerPoint();
	const auto insets = presentationSafeInsets(gfx);
	auto input = presentationInput;
	input.touch = true;
	const auto resolved =
		resolvePresentation(presentationOverride().value_or(presentationPreference),
							{gfx->getW() / unit, gfx->getH() / unit, 1, insets}, input);
	auto result = MobileLayout::calculate(
		gfx->getW() / unit, gfx->getH() / unit, insets, 0, 1, panelOpen,
		resolved.layout == PresentationLayout::Spacious,
		resolved.layout == PresentationLayout::Spacious ? resolved.panelWidth : 288);
	// Keep the icon band, then reserve the actual wrapped label height and
	// bottom padding. Tall scripts and accessibility text grow upward into
	// the world; drawing and hit regions share the resulting action strip.
	const auto &navigation = measureNavigation(result.actions.w);
	const double labelHeight = navigation.height;
	result.actions.h = std::max(result.actions.h, 32 + labelHeight + (labelHeight > 16 ? 4 : 0)) *
		(6 / navigation.columns);
	result.actions.y = result.safe.y + result.safe.h - result.actions.h;
	// Persistent palettes float too: the map remains visible below their last
	// icon, and opening an inspector never changes the camera's framing.
	result.world = result.safe;
	result.world.h -= result.actions.h;
	result.status.h = 28;
	if ((result.persistentPanel || panelOpen) && showsBuildPalette())
	{
		const int columns = paletteColumns(result);
		const double stride = InGameTouchTheme::paletteCell + InGameTouchTheme::gap;
		const double rows = std::ceil(paletteItems().size() / double(columns));
		if (result.persistentPanel)
		{
			const double width = std::min(result.safe.w, columns * 60.0 + 8);
			const double height = std::min(result.world.h - 80, rows * 60 + 8);
			result.panel = {result.safe.x + result.safe.w - width, result.safe.y + 104, width, height};
		}
		else
		{
			// A rail opposite the thumb corner; taller palettes scroll.
			const double width = std::min(result.safe.w - InGameTouchTheme::railInset,
										  columns * stride + InGameTouchTheme::gap);
			const double height =
				std::min(result.world.h - 80,
						 std::min(rows, double(InGameTouchTheme::railMaximumRows)) * stride +
							 InGameTouchTheme::gap);
			result.panel = ThumbSide::corner(result.safe, width, height, InGameTouchTheme::railInset,
											 result.actions.y, ThumbSide::toolboxLeft());
		}
	}
	// Resolve the HUD and the dial-fit policy in drawable units, just as drawing
	// and input do. Neither helper calls layout(), so this cannot recurse.
	auto drawable = result;
	for (auto *rect : {&drawable.safe, &drawable.world, &drawable.actions})
	{
		rect->x *= unit;
		rect->y *= unit;
		rect->w *= unit;
		rect->h *= unit;
	}
	const auto hud = hudLayout(drawable);
	const double minimapBottom = (hud.minimap.y + hud.minimap.h) / unit + 4;
	const bool dial = (result.persistentPanel || panelOpen) && inspecting() && usesDial(drawable);
	if ((result.persistentPanel || panelOpen) && inspecting() && !dial)
	{
		// Use horizontal room before introducing overflow. Ordinary inspectors
		// fit completely; only genuinely constrained/large-text views scroll.
		result.panel.w = std::min(result.safe.w, result.safe.w > result.safe.h
			? InGameTouchTheme::inspectorLandscapeWidth : InGameTouchTheme::inspectorPortraitWidth);
		result.panel.x = result.safe.x + result.safe.w - result.panel.w;
		// Compact stocks live beneath the HUD identity; spacious stocks are
		// part of the inspector and reserve space before its scrollable actions.
		drawable.panel = {result.panel.x * unit, minimapBottom * unit,
			result.panel.w * unit, 0};
		const auto inventory = buildingInventory(drawable).bounds;
		const double top = result.persistentPanel ? minimapBottom :
			std::max(minimapBottom, (inventory.y + inventory.h) / unit + 4);
		const double available = std::max(0.0, result.actions.y - top);
		const double height = std::min(available,
			(result.persistentPanel ? InGameTouchTheme::inspectorHeader + inventory.h / unit : 0) + buildingActionsHeight(result.panel.w));
		result.panel.y = result.persistentPanel ? minimapBottom : result.actions.y - height;
		result.panel.h = height;
	}
	if ((result.persistentPanel || panelOpen) && gui.selectionMode == GameGUI::UNIT_SELECTION)
	{
		const double width = std::min(320., result.safe.w - 24);
		const double available = std::max(0.0, result.actions.y - minimapBottom - 12);
		const double height = std::min(available,
			(result.persistentPanel ? InGameTouchTheme::inspectorHeader : 0) +
			InGameTouchTheme::unitStatsTitle + 8 + unitInfoRows().size() *
			InGameTouchTheme::unitStatRow * InGameTouchTheme::textGrowth());
		result.panel = ThumbSide::corner(result.safe, width, height, 12, result.actions.y, !ThumbSide::left());
	}
	if (result.persistentPanel && inspectingResource())
	{
		const double width = std::min(240.0, result.safe.w - 2 * InGameTouchTheme::railInset);
		result.panel = ThumbSide::corner(result.safe, width, InGameTouchTheme::inspectorHeader, InGameTouchTheme::railInset,
			result.actions.y - 8, !ThumbSide::left());
	}
	if (gui.selectionMode == GameGUI::BRUSH_SELECTION)
		result.panel = {}; // Brush controls live in the bottom toolbar.
	// Independent HUD components reserve their bounds in the overlay layer.
	if (result.panel.w > 0 && result.panel.y < minimapBottom)
	{
		const double bottom = result.panel.y + result.panel.h;
		result.panel.y = minimapBottom;
		result.panel.h = std::max(0.0, bottom - minimapBottom);
	}
	for (auto *rect : {&result.safe, &result.status, &result.world, &result.actions, &result.panel})
	{
		rect->x *= unit;
		rect->y *= unit;
		rect->w *= unit;
		rect->h *= unit;
	}
	if (panelOpen && inspectingResource() && !result.persistentPanel)
		result.panel = hudLayout(result).identity;
	if (dial && gui.selectionMode != GameGUI::BRUSH_SELECTION)
		result.panel = dialLayout(result).bounds;
	// The compact lens strip replaces the tactical list's drawer.
	if (lensOpen && usesHUD() && !result.persistentPanel && gui.selectionMode == GameGUI::NO_SELECTION &&
		gui.displayMode == GameGUI::STAT_TEXT_VIEW && !globalContainer->isViewingGame() && !peekOpen && !statsOpen)
	{
		const auto rects = lensRects(result);
		double x0 = rects.front().x, y0 = rects.front().y, x1 = x0, y1 = y0;
		for (const auto &r : rects)
		{
			x0 = std::min(x0, r.x);
			y0 = std::min(y0, r.y);
			x1 = std::max(x1, r.x + r.w);
			y1 = std::max(y1, r.y + r.h);
		}
		result.panel = {x0, y0, x1 - x0, y1 - y0};
	}
	return result;
}
double GameGUITouch::scenarioMessagePitch() const
{
	return scenarioMessageLineStep * InGameTouchTheme::textGrowth();
}
double GameGUITouch::scenarioMessageFooterHeight() const
{
	return gui.swallowSpaceKey ? std::max(48.0, scenarioMessageFontHeight * InGameTouchTheme::textGrowth() + 16) : 0;
}
double GameGUITouch::scenarioMessageMaximum() const
{
	const double unit = globalContainer->gfx->logicalUnitsPerPoint();
	return std::max(0.0, scenarioMessageLines.size() * scenarioMessagePitch() - scenarioMessageRect().h / unit + 16 +
							 scenarioMessageContinueRect().h / unit);
}
void GameGUITouch::clampScroll()
{
	if (nativeScrolling && nativeAxis().externallyMoved(nativeOffset()))
	{
		nativeScroll.cancel(nativeAxis().axis);
		nativeScrolling = false; // sync below applies the requested external offset
	}
	const auto content = panelContent();
	const double unit = globalContainer->gfx->logicalUnitsPerPoint();
	actionAxis.sync(actionScroll,
					std::max(0.0, buildingActionsHeight(content.w / unit) - content.h / unit),
					content.h / unit);
	const auto ui = layout();
	const int columns = paletteColumns(ui);
	const double height =
		showsBuildPalette()
			? std::ceil(paletteItems().size() / double(columns)) *
					  (paletteRail(ui) ? InGameTouchTheme::paletteCell + InGameTouchTheme::gap : 60) +
				  (paletteRail(ui) ? InGameTouchTheme::gap : 8)
			: gui.selectionMode == GameGUI::UNIT_SELECTION
				? 8 + unitInfoRows().size() * InGameTouchTheme::unitStatRow * InGameTouchTheme::textGrowth()
				: inspectingResource() ? 0 : tacticalActions().size() * 56;
	panelAxis.sync(panelScroll, std::max(0.0, height - content.h / unit), content.h / unit);
	scenarioMessageAxis.sync(scenarioMessageScroll, scenarioMessageMaximum(), scenarioMessageRect().h / unit);
}
void GameGUITouch::stopScrolling()
{
	if (nativeScrolling)
	{
		nativeScroll.cancel(nativeAxis().axis);
		nativeAxis().publish(nativeOffset());
		nativeScrolling = false;
	}
	mapMotion.interrupt();
	panelAxis.axis.interrupt();
	actionAxis.axis.interrupt();
	scenarioMessageAxis.axis.interrupt();
}
// A blank-map tap is a dismissal, not navigation back through inspector history.
void GameGUITouch::dismissMapPanels()
{
	const bool hadPanels = panelOpen || lensOpen || statsOpen || peekOpen || showStatistics || restorePalette;
	restorePalette = false;
	readOnlyPanelShown = false;
	panelOpen = lensOpen = statsOpen = peekOpen = showStatistics = false;
	panelScroll = actionScroll = 0;
	keyboardFocus = -1;
	if (hadPanels) lastMapTapTicks.reset();
	gui.clearSelection();
	stopScrolling();
}

bool GameGUITouch::scrollAnimating() const
{
	return (nativeScrolling && nativeScroll.needsFrames()) || mapMotion.isAnimating() || panelAxis.axis.isAnimating() ||
		   actionAxis.axis.isAnimating() || scenarioMessageAxis.axis.isAnimating();
}
Uint64 GameGUITouch::eventTime(const SDL_Event &event) const
{
	return (event.common.timestamp / SDL_NS_PER_MS);
}
void GameGUITouch::advanceScroll(Uint64 now)
{
	lastStepTime = now;
	if (nativeScrolling && (!usesHUD() || activeDialog() || (nativePanel == 2 && !inspecting()))) stopScrolling();
	if (mapMotion.isAnimating() && usesHUD() && inputBlocked(touchPoint)) mapMotion.interrupt();
	if (mapMotion.isAnimating())
	{
		const auto [dx, dy] = mapMotion.stepDelta(now);
		if (dx != 0 || dy != 0)
		{
			gui.updateCamera();
			gui.camera.originX += dx / gui.camera.zoom;
			gui.camera.originY += dy / gui.camera.zoom;
			gui.camera.normalize();
			gui.viewportX = gui.camera.tileX();
			gui.viewportY = gui.camera.tileY();
		}
	}
	if (!usesHUD())
		return;
	if (nativeScrolling && !scrollAllowed(nativePanel)) stopScrolling();
	if (nativeScrolling) nativeScroll.update(now, nativeAxis().axis);
	int surface = 0;
	for (auto *panel : {&panelAxis, &actionAxis, &scenarioMessageAxis})
	{
		++surface;
		if (!panel->axis.isAnimating()) continue;
		if (!scrollAllowed(surface)) panel->axis.interrupt();
		else panel->axis.step(now);
	}
	clampScroll();
}
GameGUITouch::~GameGUITouch()
{
	if (!gestureExclusion.empty())
		hostGestureExclusion(globalContainer->gfx, {});
}
void GameGUITouch::syncGestureExclusion()
{
	std::vector<ViewRect> wanted;
	if (usesHUD() && !activeDialog())
	{
		const auto ui = layout();
		if (((showsBuildPalette() && paletteRail(ui)) || (inspecting() && !ui.persistentPanel) ||
			 lensVisible()) &&
			ui.panel.w > 0 && ui.panel.h > 0)
			wanted.push_back(ui.panel);
	}
	auto same = [](const ViewRect &a, const ViewRect &b)
	{ return a.x == b.x && a.y == b.y && a.w == b.w && a.h == b.h; };
	if (wanted.size() == gestureExclusion.size() &&
		std::equal(wanted.begin(), wanted.end(), gestureExclusion.begin(), same))
		return;
	gestureExclusion = std::move(wanted);
	++gestureExclusionUpdates;
	hostGestureExclusion(globalContainer->gfx, gestureExclusion);
}
ViewRect GameGUITouch::world() const
{
	if (usesHUD())
		return layout().world;
	return {0, 16, double(globalContainer->gfx->getW() - RIGHT_MENU_WIDTH),
			double(globalContainer->gfx->getH() - 16)};
}
ViewRect GameGUITouch::controls() const
{
	if (usesHUD())
		return layout().actions;
	auto rect = world();
	rect.h = std::min(rect.h, 48 * globalContainer->gfx->logicalUnitsPerPoint());
	rect.y = globalContainer->gfx->getH() - rect.h;
	return rect;
}
// The phone HUD puts OK on the thumb's side of the bar; the legacy touch
// layout keeps OK on the left.
ViewRect GameGUITouch::confirmRect() const
{
	auto rect = controls();
	rect.w /= 2;
	if (usesHUD() && !ThumbSide::left())
		rect.x += rect.w;
	return rect;
}
ViewRect GameGUITouch::cancelRect() const
{
	auto rect = controls();
	rect.w /= 2;
	if (!(usesHUD() && !ThumbSide::left()))
		rect.x += rect.w;
	return rect;
}
ViewPoint GameGUITouch::previewCursor() const
{
	const auto &map = gui.drawnScene().map;
	auto wrap = [](double v, double n) { return v - std::floor(v / n) * n; };
	return {wrap(preview->x - gui.viewportX * 32, map.getW() * 32),
			wrap(preview->y - gui.viewportY * 32, map.getH() * 32)};
}
GAGGUI::ui::UIDialog *GameGUITouch::activeDialog() const
{
	return gui.activeDialog();
}

void GameGUITouch::cancel(bool preservePreview)
{
	if (placement)
	{
		gui.clearSelection();
		panelOpen = true;
	}
	placement.reset();
	placementHold.reset();
	releaseFlagDrag(true); // An interrupted carry returns the flag.
	strokeHold.reset();
	railTouched = -1;
	peekOpen = false;
	minimapPress.reset();
	allocation.reset();
	stroke.cancel();
	commitDeferredStroke(); // A completed tap is not undone by an interruption.
	gui.toolManager.cancelDrag(gui.localTeamNo);
	gesture.cancel();
	stopScrolling();
	lastMapTapTicks.reset();
	fingers.clear();
	ignoreTouchSequence = false;
	confirmDestroy = false;
	if (!preservePreview)
	{
		preview.reset();
		previewType.clear();
	}
	panX = panY = 0;
}

int GameGUITouch::interfaceRegion(ViewPoint point) const
{
	if (gui.inGameMenu || gui.typingInputScreen || gui.scrollableText)
		return 4;
	if (usesHUD() && peekOpen)
	{
		// The map peek owns every touch until it closes.
		if (peekRect().contains(point))
			return 40;
		const auto buttons = peekButtons();
		for (int i = 0; i < int(buttons.size()); ++i)
			if (buttons[i].contains(point))
				return 41 + i;
		return 44;
	}
	if (usesHUD() && statsOpen && !activeDialog())
	{
		const auto stats = statsLayout();
		if (stats.close.contains(point))
			return 45;
		if (stats.sheet.contains(point))
			return 48;
	}
	if (gui.selectionMode == GameGUI::BRUSH_SELECTION && controls().contains(point))
		return 9;
	if (usesHUD() && gui.selectionMode == GameGUI::BRUSH_SELECTION &&
		BrushHUD::hit(brushHUD(), point).part != BrushHUD::Part::None)
		return 16;
	if (gui.selectionMode == GameGUI::TOOL_SELECTION && controls().contains(point))
		return confirmRect().contains(point) ? 1 : 2;
	if (usesHUD())
	{
		if (minimapRect().contains(point))
			return 8;
		if (speedRect().contains(point))
			return 49;
		const auto navigation = layout();
		if (navigation.actions.contains(point))
			return 10 + navigationButtonAt(navigation, point);
		const auto header = allocationRect();
		if (header.contains(point) &&
			point.x >= header.x + header.w - 48 * globalContainer->gfx->logicalUnitsPerPoint())
			return 38;
		if (header.contains(point))
			return 3;
		if (buildingInventory(layout()).bounds.contains(point))
			return 3;
		// The dial answers only on its rings, chips and header; the map shows
		// (and stays tappable) between them.
		if (inspecting() && usesDial())
		{
			if (dialRegionAt(point))
				return 3;
		}
		else if (layout().panel.contains(point))
			return 3;
		if (scenarioMessageRect().contains(point))
			return 7;
		return world().contains(point) ? 0 : 6;
	}
	if (point.x >= world().w)
		return 3;
	if (globalContainer->replaying && point.y >= REPLAY_BAR_Y)
		return 5;
	return world().contains(point) ? 0 : 6;
}

std::vector<ViewRect> GameGUITouch::keyboardTargets()
{
	std::vector<ViewRect> targets;
	if (activeDialog())
		return targets;
	const auto ui = layout();
	for (int i = 0; i < 6; ++i)
		targets.push_back(navigationButtonRect(ui, i));
	if (gui.selectionMode == GameGUI::TOOL_SELECTION)
	{
		targets = {confirmRect(), cancelRect()};
	}
	if (peekOpen)
	{
		targets = peekButtons();
		targets.insert(targets.begin(), peekRect());
		return targets;
	}
	if (statsOpen)
	{
		const auto stats = statsLayout();
		return {stats.close};
	}
	if (lensVisible())
		return lensRects(layout());
	if (gui.selectionMode == GameGUI::BRUSH_SELECTION)
	{
		targets = brushBarButtons();
		const auto rail = brushHUD();
		targets.insert(targets.end(), rail.detents.begin(), rail.detents.end());
		for (const auto &r : {rail.mode, rail.pan, rail.undo})
			if (r.w > 0)
				targets.push_back(r);
		return targets;
	}
	if (inspectingResource())
	{
		targets.push_back(readOnlyCloseRect());
		return targets;
	}
	const auto content = panelContent();
	if (showsBuildPalette())
	{
		for (size_t i = 0; i < paletteItems().size(); ++i)
		{
			const auto rect = paletteItemRect(i);
			if (content.contains({rect.x + rect.w / 2, rect.y + rect.h / 2}))
				targets.push_back(rect);
		}
	}
	else if (gui.selectionMode == GameGUI::UNIT_SELECTION && ui.panel.h > 0)
	{
		targets.push_back(readOnlyCloseRect());
	}
	else if (inspecting() && globalContainer->isViewingGame())
	{
		// Disabled configuration controls are visible, but never keyboard targets.
		const auto header = allocationRect();
		const double target = 48 * globalContainer->gfx->logicalUnitsPerPoint();
		targets.push_back({header.x + header.w - target, header.y, target, header.h});
	}
	else if (inspecting() && usesDial())
	{
		for (const auto &region : dialRegions())
			if (region.part != DialRegion::Arc)
				targets.push_back(region.box);
	}
	else if (inspecting())
	{
		for (size_t i = 0; i < buildingActions().size(); ++i)
		{
			const auto rect = buildingActionRect(i);
			if (rect.y >= content.y && rect.y + rect.h <= content.y + content.h)
				targets.push_back(rect);
		}
	}
	return targets;
}

bool GameGUITouch::process(SDL_Event &event)
{
	if (dispatching)
		return false;
	if (auto sample = scrollGesture(event))
	{
		GraphicContext::translateMouseEvent(&event);
		sample = scrollGesture(event);
		if (sample->phase == ScrollGesturePhase::Began && sample->sequence != nativeSequence)
		{
			const int previousPanel = nativeScrolling ? nativePanel : 0;
			const auto previousAxis = nativeAxis().axis;
			stopScrolling();
			nativeSequence = sample->sequence;
			nativePanel = 0;
			if (usesHUD() && gui.inputState.hasFocus() && !activeDialog())
			{
				const int region = interfaceRegion({sample->x, sample->y});
				if (region == 7) nativePanel = 3;
				else if (region == 3) nativePanel = inspecting() ? 2 : 1;
				if (nativePanel && !scrollAllowed(nativePanel)) return true;
				if (nativePanel)
				{
					clampScroll();
					if (nativePanel == previousPanel)
					{
						nativeAxis().axis = previousAxis;
						nativeAxis().publish(nativeOffset());
					}
					auto &axis = nativeAxis().axis;
					nativeScroll.begin(*sample, axis, nativeOffset(), axis.maximum(), nativePanel == 3 ? scenarioMessageRect().h / globalContainer->gfx->logicalUnitsPerPoint() : panelContent().h / globalContainer->gfx->logicalUnitsPerPoint());
					nativeScrolling = true;
				}
			}
		}
		if (sample->sequence != nativeSequence) return true;
		if (!nativePanel) return false;
		if (nativeScrolling && !scrollAllowed(nativePanel)) { stopScrolling(); return true; }
		if (nativeScrolling)
		{
			nativeScroll.handle(*sample, nativeAxis().axis, 1 / globalContainer->gfx->logicalUnitsPerPoint(), nativePanel == 1 ? paletteScrollSign() : 1);
			clampScroll();
		}
		return true;
	}
	if (nativeScrolling && (event.type == SDL_EVENT_MOUSE_WHEEL || event.type == SDL_EVENT_MOUSE_BUTTON_DOWN || event.type == SDL_EVENT_KEY_DOWN || event.type == SDL_EVENT_FINGER_DOWN)) stopScrolling();
	if (usesHUD() && event.type == SDL_EVENT_KEY_DOWN)
	{
		const auto key = event.key.key;
		if (key == SDLK_TAB)
		{
			const auto targets = keyboardTargets();
			const int count = int(targets.size());
			const int direction = (event.key.mod & SDL_KMOD_SHIFT) ? -1 : 1;
			int next = keyboardFocus;
			keyboardFocus = -1;
			for (int tried = 0; tried < count; ++tried)
			{
				next = (next + direction + count) % count;
				const auto &r = targets[next];
				const ViewPoint center{r.x + r.w / 2, r.y + r.h / 2};
				if (!pointerControlKey(center).empty() && pointerControlAllowed(center))
				{
					keyboardFocus = next;
					break;
				}
			}
			return true;
		}
		if ((key == SDLK_RETURN || key == SDLK_SPACE) && keyboardFocus >= 0 &&
			!gui.typingInputScreen && !event.key.repeat)
		{
			const auto targets = keyboardTargets();
			if (keyboardFocus < int(targets.size()))
			{
				const auto rect = targets[keyboardFocus];
				SDL_Event pointer{};
				pointer.type = SDL_EVENT_MOUSE_BUTTON_DOWN;
				pointer.button.button = SDL_BUTTON_LEFT;
				pointer.button.x = int(rect.x + rect.w / 2);
				pointer.button.y = int(rect.y + rect.h / 2);
				process(pointer);
				pointer.type = SDL_EVENT_MOUSE_BUTTON_UP;
				process(pointer);
			}
			return true;
		}
		if (key == SDLK_PAGEDOWN || key == SDLK_PAGEUP)
		{
			if (!scrollAllowed(inspecting() ? 2 : 1)) return true;
			const double delta = key == SDLK_PAGEDOWN ? 144 : -144;
			panelScroll += delta * paletteScrollSign();
			actionScroll += delta;
			clampScroll();
			return true;
		}
	}
	if ((event.type == SDL_EVENT_MOUSE_MOTION && event.motion.which == SDL_TOUCH_MOUSEID) ||
		((event.type == SDL_EVENT_MOUSE_BUTTON_DOWN || event.type == SDL_EVENT_MOUSE_BUTTON_UP) &&
		 event.button.which == SDL_TOUCH_MOUSEID))
		return true;
	if (event.type == SDL_EVENT_MOUSE_BUTTON_UP && swallowMouseRelease)
	{
		swallowMouseRelease = false;
		return true;
	}
	if (usesHUD() && event.type == SDL_EVENT_MOUSE_WHEEL)
	{
        // process() receives logical event coordinates from the shared input boundary.
        // The OS pointer can differ for queued or remotely supplied events.
        const float x = event.wheel.mouse_x, y = event.wheel.mouse_y;
		const int region = interfaceRegion({double(x), double(y)});
		const double delta =
			event.wheel.y * (event.wheel.direction == SDL_MOUSEWHEEL_FLIPPED ? -48 : 48);
		if (region == 3)
		{
			if (!scrollAllowed(inspecting() ? 2 : 1)) return true;
			if (inspecting())
				actionScroll -= delta;
			else
				panelScroll -= delta * paletteScrollSign();
			clampScroll();
			return true;
		}
	}
	if (usesHUD() && (event.type == SDL_EVENT_MOUSE_BUTTON_DOWN || event.type == SDL_EVENT_MOUSE_BUTTON_UP ||
					  event.type == SDL_EVENT_MOUSE_MOTION))
	{
		if (event.type != SDL_EVENT_MOUSE_MOTION && event.button.button != SDL_BUTTON_LEFT)
			return false;
		const bool motion = event.type == SDL_EVENT_MOUSE_MOTION;
		if (motion && !(event.motion.state & SDL_BUTTON_LMASK))
			return false;
		SDL_Event pointer{};
		pointer.type = motion                              ? SDL_EVENT_FINGER_MOTION
					   : event.type == SDL_EVENT_MOUSE_BUTTON_DOWN ? SDL_EVENT_FINGER_DOWN
														   : SDL_EVENT_FINGER_UP;
		pointer.tfinger.timestamp = event.common.timestamp;
		pointer.tfinger.touchID = -1;
		pointer.tfinger.fingerID = 0;
		pointer.tfinger.x =
			float(motion ? event.motion.x : event.button.x) / globalContainer->gfx->getW();
		pointer.tfinger.y =
			float(motion ? event.motion.y : event.button.y) / globalContainer->gfx->getH();
		return process(pointer);
	}
	if ((event.type >= SDL_EVENT_WINDOW_FIRST && event.type <= SDL_EVENT_WINDOW_LAST) && (event.type == SDL_EVENT_WINDOW_FOCUS_LOST ||
										  event.type == SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED || event.type == SDL_EVENT_WINDOW_RESIZED || event.type == SDL_EVENT_WINDOW_DISPLAY_SCALE_CHANGED))
		cancel();
	if (event.type != SDL_EVENT_FINGER_DOWN && event.type != SDL_EVENT_FINGER_UP &&
		event.type != SDL_EVENT_FINGER_MOTION)
		return false;
	const ViewPoint pointerPoint{event.tfinger.x * globalContainer->gfx->getW(),
								 event.tfinger.y * globalContainer->gfx->getH()};
	if (usesHUD() && (inputBlocked(pointerPoint) ||
		(event.type == SDL_EVENT_FINGER_DOWN && !pointerControlAllowed(pointerPoint))))
	{
		cancel();
		if (event.type != SDL_EVENT_FINGER_UP)
		{
			fingers.emplace_back(event.tfinger.touchID, event.tfinger.fingerID);
			ignoreTouchSequence = true;
		}
		return true;
	}
	// An outside press dismisses confirmation and consumes its whole sequence,
	// so restoring the normal controls cannot activate one underneath the tap.
	if (usesHUD() && gui.inputState.hasFocus() && !ignoreTouchSequence &&
		confirmDestroy && fingers.empty() && event.type == SDL_EVENT_FINGER_DOWN)
	{
		const auto action = actionAt(pointerPoint);
		if (!action || (action->kind != 4 && action->kind != 5))
		{
			confirmDestroy = false;
			stopScrolling();
			fingers.emplace_back(event.tfinger.touchID, event.tfinger.fingerID);
			ignoreTouchSequence = true;
			return true;
		}
	}
	if (usesHUD() && gui.inputState.hasFocus() && !ignoreTouchSequence &&
		processAllocationPointer(event, pointerPoint))
		return true;
	if (usesHUD() && gui.inputState.hasFocus() && !ignoreTouchSequence &&
		processPalettePointer(event, pointerPoint))
		return true;
	if (!gui.inputState.hasFocus())
		return true;
	if (ignoreTouchSequence)
	{
		const auto key = std::make_pair(event.tfinger.touchID, event.tfinger.fingerID);
		if (event.type == SDL_EVENT_FINGER_DOWN &&
			std::find(fingers.begin(), fingers.end(), key) == fingers.end())
			fingers.push_back(key);
		if (event.type == SDL_EVENT_FINGER_UP)
			std::erase(fingers, key);
		if (fingers.empty())
			ignoreTouchSequence = false;
		return true;
	}
	gui.checkSelection();
	if (!fingers.empty() &&
		(ownerSelection != gui.selectionMode || ownerMenu != gui.inGameMenu ||
		 ownerBuilding != (gui.selectionMode == GameGUI::BUILDING_SELECTION
							   ? std::get<BuildingRef>(gui.selection)
							   : BuildingRef{}) ||
		 ownerDialog != activeDialog() || ownerTool != gui.toolManager.getBuildingName() ||
		 ownerOverlay != bool(gui.typingInputScreen || gui.scrollableText)))
	{
		cancel();
		return true;
	}
	// Input validates against the live building (authoritative state).
	const auto* held = inspecting() ? gui.inputBuildingPanel() : nullptr;
	if (!fingers.empty() && held &&
		(heldBuildingState != held->state().buildingState ||
		 heldConstructionState != held->state().constructionResultState))
	{
		cancel();
		return true;
	}
	ViewPoint point{event.tfinger.x * globalContainer->gfx->getW(),
					event.tfinger.y * globalContainer->gfx->getH()};
	const auto key = std::make_pair(event.tfinger.touchID, event.tfinger.fingerID);
	const Uint64 time = eventTime(event);
	if (event.type == SDL_EVENT_FINGER_DOWN)
	{
		// A second finger while a flag is carried puts the flag back and ignores the
		// rest of the touch. Before the flag moved, the touch becomes a pinch.
		if (!fingers.empty() && flagDrag)
		{
			if (flagDrag->dragging)
			{
				releaseFlagDrag(true);
				if (std::find(fingers.begin(), fingers.end(), key) == fingers.end())
					fingers.push_back(key);
				ignoreTouchSequence = true;
				return true;
			}
			flagDrag.reset();
		}
		if (fingers.empty())
		{
			touchActive = true;
			// A touch catches coasting content where it is. Presets are re-read
			// here so the settings sliders apply to the next gesture.
			stopScrolling();
			fingerIsTouch = event.tfinger.touchID != -1;
			GAGCore::ScrollPhysicsConfig mapConfig = ScrollPresets::mapViewport();
			mapConfig.momentum = mapConfig.momentum && fingerIsTouch;
			mapMotion.setConfig(mapConfig);
			mapDragStartTime = time;
			const auto hud = fingerIsTouch ? ScrollPresets::hudPanel() : ScrollPresets::mouse();
			panelAxis.axis.setConfig(hud);
			actionAxis.axis.setConfig(hud);
			scenarioMessageAxis.axis.setConfig(hud);
			gui.viewportSpeedX = gui.viewportSpeedY = 0;
			gui.lastMouseButtonState = 0;
			gui.selectionPushed = gui.panPushed = gui.miniMapPushed = false;
			scale = globalContainer->gfx->logicalUnitsPerPoint();
			ownerRegion = interfaceRegion(point);
			heldActionKind = -1;
			heldActionConfirmation = confirmDestroy;
			if (const auto* building = inspecting() ? gui.inputBuildingPanel() : nullptr)
			{
				heldBuildingState = building->state().buildingState;
				heldConstructionState = building->state().constructionResultState;
				if (ownerRegion == 3)
					if (const auto row = actionAt(point))
					{
						heldActionKind = row->kind;
						heldActionValue = row->value;
						heldActionLabel = row->label;
					}
			}
			interfaceGesture = ownerRegion != 0;
			ownerSelection = gui.selectionMode;
			ownerMenu = gui.inGameMenu;
			ownerBuilding = gui.selectionMode == GameGUI::BUILDING_SELECTION
								? std::get<BuildingRef>(gui.selection)
								: BuildingRef{};
			ownerDialog = activeDialog();
			ownerOverlay = gui.typingInputScreen || gui.scrollableText;
			ownerTool = gui.toolManager.getBuildingName();
			touchStart = touchPoint = point;
			touchTravelled = false;
			const TouchMode natural = interfaceGesture                                ? TouchMode::Navigate
									  : gui.selectionMode == GameGUI::TOOL_SELECTION  ? TouchMode::Placement
									  : gui.selectionMode == GameGUI::BRUSH_SELECTION && !brushPan ? TouchMode::Paint
																					  : TouchMode::Navigate;
			// A contact on or near one of the player's flags carries the flag rather
			// than the map, even straight after a tap.
			auto grabbed = !interfaceGesture && natural == TouchMode::Navigate ? grabbableFlag(point) : nullptr;
			if (grabbed)
				beginFlagDrag(*grabbed, key, point);
			else
				flagDrag.reset();
			// The second contact of a double-tap zooms; any other contact first
			// lets a waiting paint tap land, so nothing reorders the player's input.
			const bool zoomDrag = !interfaceGesture && !grabbed && natural != TouchMode::Placement &&
								  zoomTapArmed(event.tfinger.timestamp / SDL_NS_PER_MS, point);
			if (zoomDrag)
				deferredStroke.reset(); // That tap was the first half of the zoom.
			else
				commitDeferredStroke();
			lastMapTapTicks.reset();
			gesture.setMode(zoomDrag ? TouchMode::ZoomDrag : natural);
			gesture.setZoomDragDirection(globalContainer->settings.dragUpZoomsIn());
			// Touching a size on the brush rail selects it at once, so its magnified
			// preview follows the thumb while it scrubs along the rail.
			railTouched = -1;
			if (ownerRegion == 16)
			{
				const auto hit = BrushHUD::hit(brushHUD(), point);
				if (hit.part == BrushHUD::Part::Detent && controlAllowed("touch/brush/shape/" + std::to_string(hit.index), GAGGUI::ui::ActionKind::Activate))
				{
					gui.brush.setFigure(unsigned(hit.index));
					railTouched = hit.index;
				}
			}
			statsDrag = 0;
			// A still press on the minimap opens the map peek (see prepareDraw).
			if (ownerRegion == 8)
				minimapPress = SDL_GetTicks();
			else
				minimapPress.reset();
			if (natural == TouchMode::Paint && !zoomDrag && ownerRegion == 0)
				strokeHold = TouchPlacementSession{key, point, {}, true, {}, point, SDL_GetTicks(), gui.localTeamNo};
			else
				strokeHold.reset();
		}
		else
			strokeHold.reset(); // A second finger navigates instead of painting.
		if (fingers.empty() && ownerRegion == 0 && gui.selectionMode == GameGUI::TOOL_SELECTION)
			placementHold = TouchPlacementSession{key, point, gui.toolManager.getBuildingName(),
				true, {}, point, SDL_GetTicks(), gui.localTeamNo};
		else
			placementHold.reset(); // A navigation gesture cannot resume edge panning.
		if (std::find(fingers.begin(), fingers.end(), key) == fingers.end())
			fingers.push_back(key);
		actions(gesture.down(key.first, key.second, {point.x / scale, point.y / scale}, time));
	}
	else if (event.type == SDL_EVENT_FINGER_MOTION)
	{
		if (flagDrag && flagDrag->pointer == key)
		{
			flagDrag->position = point;
			if (!flagDrag->dragging &&
				std::hypot(point.x - flagDrag->start.x, point.y - flagDrag->start.y) >= TouchInput::slop * scale)
			{
				// Past the tap threshold the finger carries the flag; the map stays put.
				flagDrag->dragging = true;
				gesture.cancel();
				stopScrolling();
				lastMapTapTicks.reset();
				minimapPress.reset();
			}
			if (flagDrag->dragging)
			{
				advanceFlagDrag();
				return true;
			}
		}
		if (placementHold && placementHold->pointer == key)
			placementHold->pointerPosition = point;
		if (strokeHold && strokeHold->pointer == key)
			strokeHold->pointerPosition = point;
		if (ownerRegion == 16 && railTouched >= 0 && fingers.size() == 1 && fingers.front() == key)
			if (const int detent = BrushHUD::detentAt(brushHUD(), point); detent >= 0 && controlAllowed("touch/brush/shape/" + std::to_string(detent), GAGGUI::ui::ActionKind::Activate))
			{
				gui.brush.setFigure(unsigned(detent));
				railTouched = detent;
			}
		// A single finger that landed on the minimap keeps steering the camera,
		// as a held mouse button does on desktop. Leaving the minimap clamps to
		// its edge so a fast sweep never drops the drag.
		if (usesHUD() && ownerRegion == 8 && fingers.size() == 1 && fingers.front() == key && controlAllowed("touch/minimap", GAGGUI::ui::ActionKind::Activate))
			navigateMinimap(minimapRect().clamp(point));
		if (usesHUD() && ownerRegion == 40 && peekOpen && fingers.size() == 1 && fingers.front() == key && controlAllowed("touch/minimap", GAGGUI::ui::ActionKind::Activate))
			navigatePeek(point);
		if (!fingers.empty() && fingers.front() == key)
		{
			touchPoint = point;
			touchTravelled = touchTravelled || std::hypot(point.x - touchStart.x, point.y - touchStart.y) >=
													TouchInput::slop * scale;
		}
		actions(gesture.move(key.first, key.second, {point.x / scale, point.y / scale}, time));
	}
	else
	{
		if (flagDrag && flagDrag->pointer == key)
		{
			if (flagDrag->dragging)
			{
				flagDrag->position = point;
				advanceFlagDrag();
				releaseFlagDrag(false);
				std::erase(fingers, key);
				lastMapTapTicks.reset();
				return true;
			}
			flagDrag.reset(); // A tap selects the flag as before.
		}
		if (placementHold && placementHold->pointer == key)
			placementHold.reset();
		if (strokeHold && strokeHold->pointer == key)
			strokeHold.reset();
		if (fingers.size() <= 1)
		{
			railTouched = -1;
			minimapPress.reset();
		}
		auto changes = gesture.up(key.first, key.second, {point.x / scale, point.y / scale}, time);
		// A completed tap on the world arms one-finger zoom for the next contact.
		const bool worldTap = changes.size() == 1 && !interfaceGesture && world().contains(point) &&
							  !controls().contains(point);
		const bool paintTap = worldTap && changes.front().kind == TouchActionKind::EndStroke &&
							  !touchTravelled && !stroke.points.empty() && strokeMatchesTool(stroke) &&
							  interfaceRegion(point) == 0;
		if (paintTap)
		{
			// Hold a painted tap for one double-tap window; see commitDeferredStroke.
			deferredStroke = TouchDeferredStroke{stroke, SDL_GetTicks()};
			stroke.cancel();
			changes.clear();
		}
		if (paintTap || (worldTap && changes.front().kind == TouchActionKind::Select))
		{
			lastMapTapTicks = event.tfinger.timestamp / SDL_NS_PER_MS;
			lastMapTapPoint = point;
		}
		else
			lastMapTapTicks.reset();
		actions(changes);
		std::erase(fingers, key);
		if (fingers.empty())
		{
			// A touch that stopped a bounce without dragging lets it finish.
			for (auto *panel : {&panelAxis, &actionAxis, &scenarioMessageAxis})
				panel->axis.settle(time);
			if (usesHUD())
				clampScroll();
		}
	}
	return true;
}

void GameGUITouch::dragStatistics(double deltaPoints)
{
	if (!statsOpen) return;
	statsDrag += deltaPoints;
	if (statsDrag > InGameTouchTheme::target) statsOpen = false;
}

void GameGUITouch::actions(const std::vector<TouchAction> &changes)
{
	for (const auto &action : changes)
	{
		const ViewPoint point{action.point.x * scale, action.point.y * scale};
		if (action.kind == TouchActionKind::Cancel)
		{
			placementHold.reset();
			strokeHold.reset();
			stroke.cancel();
			preview.reset();
			gui.toolManager.cancelDrag(gui.localTeamNo);
			stopScrolling();
			continue;
		}
		if (interfaceGesture)
		{
			if (usesHUD() && (ownerRegion == 7 || ownerRegion == 3) &&
				(action.kind == TouchActionKind::Pan || action.kind == TouchActionKind::PanEnd))
			{
				if (!scrollAllowed(ownerRegion == 7 ? 3 : inspecting() ? 2 : 1))
				{ stopScrolling(); continue; }
				const double unit = globalContainer->gfx->logicalUnitsPerPoint();
				clampScroll();
				auto &panel = ownerRegion == 7 ? scenarioMessageAxis : inspecting() ? actionAxis : panelAxis;
				if (action.kind == TouchActionKind::Pan)
					// The thumb rail fills from the bottom, so its content follows the
					// finger with the opposite sign.
					panel.axis.drag(action.time, -point.y / unit *
													 (&panel == &panelAxis ? paletteScrollSign() : 1));
				else
					panel.axis.endDrag(action.time);
				clampScroll();
			}
			if (usesHUD() && ownerRegion == 48 && action.kind == TouchActionKind::Pan)
			{
				if (!controlAllowed("touch/statistics/sheet", GAGGUI::ui::ActionKind::Scroll))
					continue;
				dragStatistics(point.y / globalContainer->gfx->logicalUnitsPerPoint());
			}
			if (action.kind == TouchActionKind::Select && interfaceRegion(point) == ownerRegion)
				interfaceTap(point);
			continue;
		}
		if (action.kind == TouchActionKind::Pan)
		{
			lastMapTapTicks.reset();
			gui.updateCamera();
			gui.camera.originX -= point.x / gui.camera.zoom;
			gui.camera.originY -= point.y / gui.camera.zoom;
			gui.camera.normalize();
			const int oldX = gui.viewportX, oldY = gui.viewportY;
			gui.viewportX = gui.camera.tileX();
			gui.viewportY = gui.camera.tileY();
			gui.viewportChanged(oldX, gui.viewportX, oldY, gui.viewportY);
			// The same finger motion feeds the release velocity, in logical pixels.
			if (!mapMotion.isDragging())
				mapMotion.beginDrag(mapDragStartTime);
			mapMotion.drag(action.time, -point.x, -point.y);
		}
		else if (action.kind == TouchActionKind::PanEnd)
		{
			// Intent must be present near release, even after a long drag. Small
			// lift-off movements cannot inherit eligibility from before a stop.
			mapMotion.endDrag(action.time, scale * InGameTouchTheme::mapFlingTravelPoints,
							 scale * InGameTouchTheme::mapReleaseSlopPoints);
		}
		else if (action.kind == TouchActionKind::Zoom)
		{
			lastMapTapTicks.reset();
			if (action.factor > 0)
				gui.zoomMap(std::log(action.factor) / std::log(1.1), int(point.x), int(point.y));
		}
		else if (action.kind == TouchActionKind::DoubleTap)
		{
			// Without a zoomable renderer the second tap still selects, as before.
			if (!zoomIn(point) && world().contains(point))
				select(point);
		}
		else if (action.kind == TouchActionKind::Preview && world().contains(point) &&
				 !controls().contains(point))
		{
			preview = ViewPoint{double(gui.mapMouseX(point.x) + gui.viewportX * 32),
								double(gui.mapMouseY(point.y) + gui.viewportY * 32)};
			previewType = gui.toolManager.getBuildingName();
			prepareDraw();
		}
		else if (action.kind == TouchActionKind::Select && world().contains(point))
		{
			select(point);
		}
		else if (!globalContainer->isViewingGame() && gui.selectionMode == GameGUI::BRUSH_SELECTION)
		{
			if (action.kind == TouchActionKind::BeginStroke)
			{
				stroke.cancel();
				stroke.team = gui.localTeamNo;
				stroke.zone = gui.toolManager.getZoneType();
				stroke.figure = gui.brush.getFigure();
				stroke.mode = gui.brush.getType();
			}
			if (stroke.team != gui.localTeamNo || stroke.zone != gui.toolManager.getZoneType() ||
				stroke.figure != int(gui.brush.getFigure()) ||
				stroke.mode != int(gui.brush.getType()))
			{
				stroke.cancel();
				continue;
			}
			if ((action.kind == TouchActionKind::BeginStroke ||
				 action.kind == TouchActionKind::Stroke) &&
				interfaceRegion(point) == 0)
				stroke.points.push_back({double(gui.mapMouseX(point.x) + gui.viewportX * 32),
										 double(gui.mapMouseY(point.y) + gui.viewportY * 32)});
			else if (action.kind == TouchActionKind::EndStroke)
			{
				if (interfaceRegion(point) == 0 && !stroke.points.empty())
					replayStroke(stroke);
				stroke.cancel();
			}
		}
	}
}

bool GameGUITouch::zoomTapArmed(Uint32 ticks, ViewPoint point) const
{
	return lastMapTapTicks && Uint32(ticks - *lastMapTapTicks) <= InGameTouchTheme::doubleTapWindowMs &&
		   std::hypot(point.x - lastMapTapPoint.x, point.y - lastMapTapPoint.y) <=
			   InGameTouchTheme::doubleTapRadius * scale &&
		   world().contains(point) && !controls().contains(point);
}

bool GameGUITouch::zoomIn(ViewPoint point)
{
	return gui.zoomMap(std::log(InGameTouchTheme::doubleTapZoomFactor) / std::log(1.1), int(point.x), int(point.y));
}

std::string GameGUITouch::zoomReadout() const
{
	char value[16];
	std::snprintf(value, sizeof(value), "%.1f", gui.camera.zoom);
	return FormattableString(Toolkit::getStringTable()->getString("[zoom factor %0]")).arg(value);
}

bool GameGUITouch::strokeMatchesTool(const TouchStrokeSession &candidate) const
{
	return gui.selectionMode == GameGUI::BRUSH_SELECTION && !globalContainer->isViewingGame() &&
		   candidate.team == gui.localTeamNo && candidate.zone == gui.toolManager.getZoneType() &&
		   candidate.figure == int(gui.brush.getFigure()) && candidate.mode == int(gui.brush.getType());
}

void GameGUITouch::replayStroke(const TouchStrokeSession &completed)
{
	// Record which displayed cells this stroke changes, so undo can revert
	// exactly those and nothing that was already painted before it.
	const auto &map = gui.drawnScene().map;
	const bool adding = completed.mode == BrushTool::MODE_ADD;
	std::vector<BrushCoverage::Cell> centres;
	for (const auto &p : completed.points)
		centres.push_back({(int(p.x) >> 5) & map.getMaskW(), (int(p.y) >> 5) & map.getMaskH()});
	const auto zone = static_cast<GameGUIToolManager::ZoneType>(completed.zone);
	const auto &view = gui.toolManager.displayedViewForZone(zone);
	std::set<BrushCoverage::Cell> changed;
	for (const auto &[cx, cy] : BrushCoverage::cells(completed.figure, centres))
	{
		const int x = cx & map.getMaskW(), y = cy & map.getMaskH();
		const bool before = view.get(map.coordToIndex(x, y));
		// The farm brush skips ground nothing can grow on, so those cells never change.
		if (zone == GameGUIToolManager::Farm && adding && !gui.toolManager.canPaintFarmArea(x,y))
			continue;
		if (before != adding)
			changed.insert({x, y});
	}
	for (size_t i = 0; i < completed.points.size(); ++i)
	{
		const auto p = completed.points[i];
		if (i == 0)
			gui.toolManager.handleMouseDown(int(p.x), int(p.y), gui.localTeamNo, 0, 0);
		else
			gui.toolManager.handleMouseDrag(int(p.x), int(p.y), gui.localTeamNo, 0, 0);
	}
	gui.toolManager.finishPointerGesture(gui.localTeamNo);
	zoneUndo.reset();
	if (changed.empty())
		return;
	// Inverse orders in map-aligned blocks of at most 32x32 cells.
	ZoneUndo undo;
	undo.zone = completed.zone;
	undo.expires = SDL_GetTicks() + InGameTouchTheme::brushUndoMs;
	std::map<std::pair<int, int>, std::vector<std::pair<int, int>>> blocks;
	for (const auto &[x, y] : changed)
	{
		blocks[{x / 32, y / 32}].push_back({x, y});
		undo.displayed.push_back({size_t(map.coordToIndex(x, y)), !adding});
	}
	const Uint8 inverse = adding ? BrushTool::MODE_DEL : BrushTool::MODE_ADD;
	for (const auto &[block, cells] : blocks)
	{
		const int left = block.first * 32, top = block.second * 32;
		const int width = std::min(32, map.getW() - left), height = std::min(32, map.getH() - top);
		Utilities::BitArray mask(size_t(width * height));
		for (const auto &[x, y] : cells)
			mask.set(size_t((y - top) * width + (x - left)), true);
		undo.orders.push_back(GameGUIToolManager::makeZoneOrder(zone, Uint8(gui.localTeamNo), inverse,
																left, top, width, height, mask));
	}
	zoneUndo = std::move(undo);
}

// The last stroke's changes are reverted by inverse orders sent after its own,
// and the displayed zones return to what the player saw before it.
void GameGUITouch::applyZoneUndo()
{
	if (!zoneUndo || globalContainer->isViewingGame())
		return;
	while (auto pending = gui.toolManager.getOrder())
		gui.enqueueOrder(pending);
	for (const auto &order : zoneUndo->orders)
		gui.enqueueOrder(order);
	auto &view = gui.toolManager.displayedViewForZone(static_cast<GameGUIToolManager::ZoneType>(zoneUndo->zone));
	for (const auto &[index, value] : zoneUndo->displayed)
		view.set(index, value);
	zoneUndo.reset();
}

BrushHUD::Layout GameGUITouch::brushHUD() const
{
	const auto ui = layout();
	const double unit = globalContainer->gfx->logicalUnitsPerPoint();
	const auto mini = minimapRect();
	const double top = mini.y + mini.h + 8 * unit, inset = InGameTouchTheme::railInset * unit;
	return BrushHUD::layout({ui.safe.x + inset, top, ui.safe.w - 2 * inset, ui.actions.y - 8 * unit - top},
							ThumbSide::toolboxLeft(), unit, true, true, bool(zoneUndo));
}

// Zone choices then Done, with Done under the thumb.
std::vector<ViewRect> GameGUITouch::brushBarButtons() const
{
	const auto rect = controls();
	const int count = gui.toolManager.zoneTypeCount() + 1;
	std::vector<ViewRect> buttons;
	for (int i = 0; i < count; ++i)
	{
		const int slot = ThumbSide::left() ? count - 1 - i : i;
		buttons.push_back({rect.x + slot * rect.w / count, rect.y, rect.w / count, rect.h});
	}
	return buttons;
}

// A held paint tap lands when its double-tap window closes, when any other
// contact begins, or when input is interrupted. It is dropped only if the
// brush it was painted with is no longer the active tool.
void GameGUITouch::commitDeferredStroke()
{
	if (!deferredStroke)
		return;
	const auto held = std::move(deferredStroke->stroke);
	deferredStroke.reset();
	if (!held.points.empty() && strokeMatchesTool(held))
		replayStroke(held);
}

void GameGUITouch::activateNavigation(int button)
{
	if (button == 2)
		showStatistics = false;
	if (globalContainer->replaying && button < 2)
	{
		if (button == 0)
			gui.gamePaused = !gui.gamePaused;
		else
		{
			globalContainer->replayFastForward = !globalContainer->replayFastForward;
			gui.gamePaused = false;
		}
		return;
	}
	if (button < 3)
	{
		if ((button == 0 && (gui.hiddenGUIElements & GameGUI::HIDABLE_BUILDINGS_LIST)) ||
			(button == 1 && (gui.hiddenGUIElements & GameGUI::HIDABLE_FLAGS_LIST)))
			return;
		// Explicit navigation wins over inspector restoration and pending
		// invalidation, even when a client step already cleared selection.
		if (inspecting() || inspectingReadOnly() || readOnlyPanelShown)
			dismissMapPanels();
		if (button < 2)
		{
			lensOpen = false;
			statsOpen = false;
			const auto mode = button == 0 ? GameGUI::CONSTRUCTION_VIEW : GameGUI::FLAG_VIEW;
			panelOpen = !(panelOpen && gui.displayMode == mode &&
						  gui.selectionMode == GameGUI::NO_SELECTION);
			gui.clearSelection();
			gui.displayMode = mode;
		}
		else if (gui.selectionMode == GameGUI::NO_SELECTION && !globalContainer->isViewingGame() &&
				 !layout().persistentPanel)
		{
			// Compact: Tools opens the lens strip opposite the thumb corner.
			lensOpen = !(lensOpen && !panelOpen && gui.displayMode == GameGUI::STAT_TEXT_VIEW);
			panelOpen = false;
			gui.displayMode = GameGUI::STAT_TEXT_VIEW;
			gui.replayDisplayMode = GameGUI::RDM_STAT_TEXT_VIEW;
		}
		else
		{
			panelOpen = !panelOpen || (gui.selectionMode == GameGUI::NO_SELECTION &&
									   gui.displayMode != GameGUI::STAT_TEXT_VIEW);
			if (gui.selectionMode == GameGUI::NO_SELECTION)
			{
				gui.displayMode = GameGUI::STAT_TEXT_VIEW;
				gui.replayDisplayMode = GameGUI::RDM_STAT_TEXT_VIEW;
			}
		}
		panelScroll = 0;
		clampScroll();
		return;
	}
	if (button == 4 && globalContainer->isViewingGame())
	{
		// Replay statistics are explicit navigation too: consume any
		// inspector restoration or pending invalidation before opening.
		dismissMapPanels();
		gui.displayMode = GameGUI::STAT_TEXT_VIEW;
        gui.replayDisplayMode = GameGUI::RDM_STAT_TEXT_VIEW;
        statsOpen = true;
		return;
	}
	// Touch opens dialogs by intent, never by synthesizing desktop pixels.
	const auto open = [&]
	{
		if (button == 3)
			gui.openDialog(GameGUI::IGM_OBJECTIVES,
						   std::make_unique<InGameObjectivesScreen>(&gui, false));
		else if (button == 4)
			gui.openDialog(GameGUI::IGM_ALLIANCE, std::make_unique<InGameAllianceScreen>(&gui));
		else
			gui.openMainMenu();
	};
	if (button == 3 || button == 4 || !gui.parkForClient(open))
		open();
	return;
}
void GameGUITouch::interfaceTap(ViewPoint point)
{
	if (activeDialog())
		return;

	if (usesHUD() || (active() && gui.selectionMode == GameGUI::TOOL_SELECTION))
	{
		// Polar dial contacts retain their exact ring hit test, rather than a
		// bounding-box approximation. All discrete surfaces use the shared model.
		if (!peekOpen && !statsOpen && inspecting() && usesDial() && dialRegionAt(point))
		{
			tapBuildingAction(point);
			return;
		}
		const auto controls = describeControls();
		const GAGGUI::ui::Point p{int(point.x), int(point.y)};
		for (auto it = controls.rbegin(); it != controls.rend(); ++it)
			if (it->contains(p))
			{
				if (it->enabled && it->tap && !it->actions.empty() && controlAllowed(it->key, it->actions.front())) it->tap(p);
				return;
			}
		if (usesHUD()) return;
	}
	// Some shared panel hit tests read the current cursor instead of the event.
	gui.mouseX = gui.view.mouseX = gui.lastMouseX = int(point.x);
	gui.mouseY = gui.view.mouseY = gui.lastMouseY = int(point.y);
	dispatching = true;
	SDL_Event click{};
	click.type = SDL_EVENT_MOUSE_BUTTON_DOWN;
	click.button.button = SDL_BUTTON_LEFT;
	click.button.x = int(point.x);
	click.button.y = int(point.y);
	gui.processEvent(&click);
	click.type = SDL_EVENT_MOUSE_BUTTON_UP;
	gui.processEvent(&click);
	dispatching = false;
	if (usesHUD() && (gui.selectionMode == GameGUI::TOOL_SELECTION ||
					  gui.selectionMode == GameGUI::BRUSH_SELECTION))
		panelOpen = false;
	gui.lastMouseButtonState = 0;
	gui.selectionPushed = gui.panPushed = gui.miniMapPushed = false;
}

// The visible unit drawn under a screen point, matching draw order: ground units
// first, then flying units, using their interpolated rectangles.
UnitRef GameGUITouch::unitAt(ViewPoint screenPoint, double reachPoints) const
{
	const ViewPoint point{double(gui.mapMouseX(int(screenPoint.x))), double(gui.mapMouseY(int(screenPoint.y)))};
	UnitRef found, nearest;
	const double radius = reachPoints * globalContainer->gfx->logicalUnitsPerPoint() / gui.camera.zoom;
	double nearestDistance = radius * radius;
	const int tiles = 1 + int(std::ceil(radius / 32));
	// Hit the positions presented to the player, including optional between-tick
	// motion. Input runs with the simulation parked; resolve snapshot identities
	// before returning so a dead/replaced unit can never be selected.
	const PresentationFrame *scene = gui.view.scene;
	if (!scene || !scene->world.occupancy) return {};
	auto scan = [&](const auto &map)
	{
		const int mx = int(point.x) / 32 + gui.viewportX, my = int(point.y) / 32 + gui.viewportY;
		const Uint32 visible =
			globalContainer->replaying ? globalContainer->replayVisibleTeams : Team::teamNumberToMask(gui.localTeamNo);
		const bool wholeMap = globalContainer->replaying && !globalContainer->replayShowFog;
		// Match draw order: ground units first, then flying units, using their interpolated rectangles.
		for (bool air : {false, true})
			for (int y = my - tiles; y <= my + tiles; ++y)
				for (int x = mx - tiles; x <= mx + tiles; ++x)
				{
					const Uint16 gid = air ? map.getAirUnit(x, y) : map.getGroundUnit(x, y);
					if (gid == NOGUID)
						continue;
					const SnapshotUnit *shown = scene ? scene->entities.unit(gid) : nullptr;
					if (scene && !shown) continue;
                    if (!shown) continue;
                    const int ux=shown->posX, uy=shown->posY;
                    const int moveX=shown->dx, moveY=shown->dy;
                    const int action=shown->action;
                    const int delta=drawnUnitDelta(*shown,gui.view.render.unitMotion);
					if (!wholeMap && !map.isFOWDiscovered(x, y, visible) &&
						!map.isFOWDiscovered(x - moveX, y - moveY, visible))
						continue;
					int px = unitDrawTile(x - gui.viewportX, gui.viewportX, ux, map.getW()) * 32;
					int py = unitDrawTile(y - gui.viewportY, gui.viewportY, uy, map.getH()) * 32;
					if (action < BUILD)
					{
						px -= (moveX * (255 - delta)) >> 3;
						py -= (moveY * (255 - delta)) >> 3;
					}
					const double dx = MapCamera::wrap(point.x - px - 16 + map.getW() * 16., map.getW() * 32.) - map.getW() * 16.;
					const double dy = MapCamera::wrap(point.y - py - 16 + map.getH() * 16., map.getH() * 32.) - map.getH() * 16.;
					const double distance = dx * dx + dy * dy;
					if ((wholeMap || map.isFOWDiscovered(x, y, visible) || Unit::GIDtoTeam(gid) == gui.localTeamNo) &&
						(distance < nearestDistance || (distance == nearestDistance && !nearest.empty() && gid < nearest.gid)))
					{
						nearest = shown->identity;
						nearestDistance = distance;
					}
					if (point.x > px && point.x < px + 32 && point.y > py && point.y < py + 32 &&
						(wholeMap || map.isFOWDiscovered(x, y, visible) ||
						 Unit::GIDtoTeam(gid) == gui.localTeamNo))
						found = shown->identity;
				}
	};
	if (scene) scan(scene->map);
	return !found.empty() ? found : nearest;
}

void GameGUITouch::select(ViewPoint point)
{
    const auto& map = gui.drawnScene().map;
    if (!gui.drawnScene().world.occupancy) return;
	const auto screenPoint = point;
	point = {double(gui.mapMouseX(point.x)), double(gui.mapMouseY(point.y))};
	if (gui.putMark && !globalContainer->isViewingGame())
	{
		gui.enqueueOrder(std::make_shared<MapMarkOrder>(
			gui.localTeamNo, (int(point.x) / 32 + gui.viewportX) & map.getMaskW(),
			(int(point.y) / 32 + gui.viewportY) & map.getMaskH()));
		gui.putMark = false;
		return;
	}
	auto hitUnit = unitAt(screenPoint);
	// Exact flags/buildings/resources retain precedence; the halo fills nearby ground.
	const int tileX = int(point.x) / 32 + gui.viewportX, tileY = int(point.y) / 32 + gui.viewportY;
    const bool resourceHit = map.getResource(tileX, tileY).type != NO_RES_TYPE &&
        map.isMapDiscovered(tileX, tileY, Team::teamNumberToMask(gui.localTeamNo));
	if (hitUnit.empty() && usesHUD() && !resourceHit && gui.drawnScene().map.getBuilding(tileX,tileY) == NOGBID &&
		!gui.flagAt(int(point.x), int(point.y), gui.flagReachAt(screenPoint.x, screenPoint.y)))
		hitUnit = unitAt(screenPoint, InGameTouchTheme::flagReach);
	gui.view.mouseUnit = hitUnit;
	const bool wasInspecting = inspecting();
	// A read-only card is not a palette to restore after a building inspector.
	const bool wasOpen = panelOpen && !inspectingReadOnly();
	const int oldDisplay = gui.displayMode;
	// Desktop selection deliberately sticks on empty terrain. A completed map
	// tap on touch dismisses the inspector; the shared picker can immediately
	// select the same building, another building, a unit or a resource instead.
	// Pan/cancel/UI gestures never reach this selection path.
	if (usesHUD() && gui.selectionMode != GameGUI::TOOL_SELECTION &&
		gui.selectionMode != GameGUI::BRUSH_SELECTION) gui.clearSelection();
	gui.handleMapClick(int(screenPoint.x), int(screenPoint.y), SDL_BUTTON_LEFT);
	if (!wasInspecting && inspecting())
	{
		restorePalette = true;
		previousPanelOpen = wasOpen;
		previousDisplayMode = oldDisplay;
	}
	gui.selectionPushed = false;
	if (usesHUD() && gui.selectionMode == GameGUI::NO_SELECTION)
	{
		dismissMapPanels();
		return;
	}
	if (usesHUD() && gui.selectionMode != GameGUI::NO_SELECTION)
	{
		panelOpen = true;
		panelScroll = inspectingReadOnly() ? 0 : 144;
		if (inspectingReadOnly())
		{
			restorePalette = false;
			lensOpen = statsOpen = peekOpen = showStatistics = false;
			readOnlyPanelShown = true;
		}
	}
}

void GameGUITouch::prepareDraw()
{
	if (!active())
		return;
	gui.checkSelection();
	// The simulation/client step can invalidate selection before this method.
	// Remember what was presented, rather than sampling the already-cleared mode.
	if (readOnlyPanelShown && gui.selectionMode == GameGUI::NO_SELECTION)
		dismissMapPanels();
	readOnlyPanelShown = inspectingReadOnly();
	advancePlacement();
	advanceFlagDrag();
	if (deferredStroke &&
		SDL_GetTicks() - deferredStroke->ticks >= InGameTouchTheme::doubleTapWindowMs)
		commitDeferredStroke();
	if (minimapPress && !controlAllowed("touch/minimap", GAGGUI::ui::ActionKind::Activate)) minimapPress.reset();
	if (minimapPress && (touchTravelled || fingers.size() != 1 || ownerRegion != 8))
		minimapPress.reset();
	if (minimapPress && SDL_GetTicks() - *minimapPress >= InGameTouchTheme::peekPressMs)
	{
		// The press became a request for the large map; its release does nothing.
		peekOpen = true;
		minimapPress.reset();
		ignoreTouchSequence = true;
	}
	if (gui.selectionMode != GameGUI::BRUSH_SELECTION)
	{
		zoneUndo.reset();
		brushPan = false;
	}
	else if (zoneUndo && SDL_GetTicks() >= zoneUndo->expires)
		zoneUndo.reset();
	// A stroke held at a map edge pans, and keeps painting under the still finger.
	if (strokeHold && !stroke.points.empty() && gui.selectionMode == GameGUI::BRUSH_SELECTION)
	{
		const auto point = strokeHold->pointerPosition;
		if (edgePan(point, strokeHold->lastUpdate) && interfaceRegion(point) == 0)
			stroke.points.push_back({double(gui.mapMouseX(int(point.x)) + gui.viewportX * 32),
									 double(gui.mapMouseY(int(point.y)) + gui.viewportY * 32)});
	}
	if (restorePalette && !inspecting() && !inspectingReadOnly())
	{
		panelOpen = previousPanelOpen;
		gui.displayMode = static_cast<GameGUI::DisplayMode>(previousDisplayMode);
		restorePalette = false;
	}
	// Compare the selected building's identity (gid and generation).
	const BuildingRef inspected = inspecting() ? std::get<BuildingRef>(gui.selection) : BuildingRef();
	if (!(inspected == lastInspectedBuilding))
	{
		confirmDestroy = false;
		actionScroll = 0;
		lastInspectedBuilding = inspected;
	}
	if (usesHUD())
	{
		prepareScenarioMessage();
		clampScroll();
	}
	syncGestureExclusion();
	if (gui.selectionMode != GameGUI::TOOL_SELECTION ||
		previewType != gui.toolManager.getBuildingName())
		preview.reset();
	if (preview)
	{
		const auto cursor = previewCursor();
		gui.view.mouseX = int(cursor.x);
		gui.view.mouseY = int(cursor.y);
		gui.mouseX =
			int((cursor.x - gui.camera.fractionX()) * gui.camera.zoom + gui.camera.offsetX);
		gui.mouseY =
			int((cursor.y - gui.camera.fractionY()) * gui.camera.zoom + gui.camera.offsetY);
	}
}

void GameGUITouch::menuAction(int action)
{
    if(gui.parkForClient([&]{menuAction(action);})) return;
	if (action == -2)
		return;
	if (action == -1)
	{
		showStatistics = false;
		panelScroll = 0;
		return;
	}
	if (action == -10)
	{
		// No overlay.
		gui.showStarvingMap = gui.showDamagedMap = gui.showDefenseMap = gui.showFertilityMap = false;
		return;
	}
	if (action == 50)
	{
		peekOpen = true;
		return;
	}
	gui.closeDialog();
	if (action >= 20 && action < 24)
	{
		bool *states[] = {&gui.showStarvingMap, &gui.showDamagedMap, &gui.showDefenseMap,
						  &gui.showFertilityMap};
		const bool enabled = !*states[action - 20];
		for (auto *state : states)
			*state = false;
		*states[action - 20] = enabled;
		// The next frame's scene extraction computes the newly chosen overlay.
		return;
	}
	if (globalContainer->isViewingGame() && action >= 31 && action < 56)
	{
		if (action == 31)
			globalContainer->replayShowFog = !globalContainer->replayShowFog;
		else if (action == 32)
			globalContainer->replayVisibleTeams =
				globalContainer->replayVisibleTeams == 0xffffffff ? Team::teamNumberToMask(gui.localTeamNo) : 0xffffffff;
		else if (action == 33)
			globalContainer->replayShowAreas = !globalContainer->replayShowAreas;
		else if (action == 34)
			globalContainer->replayShowFlags = !globalContainer->replayShowFlags;
		else if (action >= 40 && gui.drawnScene().world.teams && size_t(action - 40) < gui.drawnScene().world.teams->values.size())
		{
            gui.selectViewedTeam(action - 40);
		}
		return;
	}
	switch (action)
	{
	case 0:
		if (globalContainer->replaying)
			gui.gamePaused = !gui.gamePaused;
		else if (!globalContainer->isViewingGame())
			gui.requestPause(!gui.gamePaused);
		break;
	case 1:
		gui.openChat();
		break;
	case 2:
		panelOpen = true;
		gui.clearSelection();
		panelScroll = 0;
		break;
	case 3:
        if (usesHUD()) {
            gui.clearSelection();
            statsOpen = true;
            break;
        }
		showStatistics = true;
		panelOpen = true;
		gui.clearSelection();
		gui.replayDisplayMode = GameGUI::RDM_STAT_TEXT_VIEW;
		gui.displayMode = GameGUI::STAT_TEXT_VIEW;
		panelScroll = 0;
		break;
	case 4:
		gui.toggleHistory();
		break;
	case 5:
		gui.putMark = true;
		break;
	case 6:
		gui.drawHealthFoodBar = !gui.drawHealthFoodBar;
		break;
	case 30:
		globalContainer->replayFastForward = !globalContainer->replayFastForward;
		gui.gamePaused = false;
		break;
	}
}
