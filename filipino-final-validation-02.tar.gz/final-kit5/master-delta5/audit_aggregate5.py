from pathlib import Path
import hashlib,json,sys,subprocess
R=Path.cwd();K=R/'artifacts/filipino-localization';F=K/'final-kit5';B=K/'final-kit4';D=F/'master-delta5';sys.path.insert(0,str(R/'tools/localization'));import translation_program as P
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=lambda s:hashlib.sha256(s.encode()).hexdigest();checks=[];issues=[]
def ck(v,label):
 checks.append({'check':label,'passed':bool(v)})
 if not v:issues.append(label)
m=read(F/'manifest.json');rp=F/'reviews/fil-pre-runtime-gates.json';r=read(rp);pr=read(F/'reviews/fil-provenance.json');br=read(B/'reviews/fil.json');bp=read(B/'reviews/fil-provenance.json');c=read(D/'source-target-carry.json');s=read(D/'source.json')['entries'];a=read(D/'author-final.json');t=read(D/'final.json');ids={'native:'+k for k in s}
ck(sha(rp)==sha(F/'reviews/fil.json'),'Immutable pre-runtime review snapshot byte-equals canonical at audit')
old={x:read(B/'source'/(x+'.json')) for x in ['native','online']};new={x:read(F/'source'/(x+'.json')) for x in old};ot={x:read(B/'drafts/fil'/(x+'.json')) for x in old};nt={x:read(F/'drafts/fil'/(x+'.json')) for x in old}
ck(sum(map(len,old.values()))==6358 and len(s)==1 and not(set(s)&set(old['native'])),'6358old plus1new nonoverlapping native ID')
ck(new['native']==dict(old['native'],**s) and new['online']==old['online'],'All6358 previous source values exact, only1native addition')
ck(nt['native']==dict(ot['native'],**t) and nt['online']==ot['online'],'All6358 previous target values exact, only1native addition')
for x in old:ck(set(c['unchanged_'+x+'_ids'])=={x+':'+k for k in old[x]} and len(c['unchanged_'+x+'_ids'])==len(old[x]),x+' exactcarry IDs')
ck(set(c['added_ids'])==ids and a==t and not c['actual_editorial_changed_ids'] and set(c['new_unchanged_after_editor_ids'])==ids,'Single new entry unchanged after author/editor')
_,ns,os,files,source=P.sources(R);paths=P.catalog_paths(F,'fil');catalog={x:sha(p) for x,p in paths.items()}
ck(source==m['source_sha256']==r['source_sha256']==pr['source_sha256']==c['source_after_sha256']=='83c8ad6f00500ade4ac1aa67f340bfb0647f9d559356231d88d81ce6f0235f7e','Current source contract83c8 exact')
ck(catalog==r['catalog_sha256']==pr['catalog_sha256']==c['catalog_after_sha256']=={'native':'287f03d772739957b96fc86ddc7fcc7073e4580436dd63fd2078ab1137d42827','online':'30c1e0e2f79104b31ba14b7704b0df44b82065436bbee22dd2963bf1116e948c'},'Actual final catalog287f/30c1 hashes exact')
ck(ns==new['native'] and os==new['online'] and files==m['source_files'],'Snapshot English source/files equals installed current source')
ck(sha(R/'data/texts.fil.txt')==catalog['native'] and sha(R/'platform/packages/i18n/locales/fil.json')==catalog['online'],'Installed Filipino catalogs exact kit5')
expected={b['id']:set(b['keys']) for b in m['batches']};flat=[k for b in m['batches'] for k in b['keys']];allids={'native:'+k for k in ns}|{'online:'+k for k in os};ck(len(expected)==len(m['batches'])==len(r['batches'])==48 and set(flat)==allids and len(flat)==len(set(flat))==6359,'48batches exactly cover6359IDs once')
th=P.batch_target_hashes(m,paths);oldb={b['id']:b for b in br['batches']}
for b in r['batches']:
 bid=b['id'];ck(b['source_sha256']==source and b['target_sha256']==th[bid],bid+' source/target hashes');ck(len({b[x] for x in ['author','reviewer','editor','adversarial_reviewer']})==4 and b['rechecked_by']==b['reviewer'],bid+' distinct4roles/finalmeaning')
 for x in ['reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys']:ck(set(b[x])==expected[bid] and len(b[x])==len(set(b[x])),bid+' '+x)
 if bid in oldb:
  prev=oldb[bid];ck(all(b[x]==v for x,v in prev.items() if x not in ['source_sha256','provenance']),bid+' previous identities/coverage/targets unchanged');ck(all(b['provenance'].get(x)==v for x,v in prev['provenance'].items() if x!='master_source_carry'),bid+' old role refs preserved')
roles={'author-review.json':'/root/draft_editor','meaning-review.json':'/root/meaning_reviewer','editor-review.json':'/root/language_editor','meaning-final-review.json':'/root/meaning_reviewer','adversarial-review.json':'/root/adversarial_reviewer'};direct=[]
for name,who in roles.items():
 p=D/name;v=read(p);entries={e['id']:e for e in v['entries']};ck(v.get('identity',v.get('reviewer'))==who and len(v['entries'])==1 and set(entries)==ids,name+' actual identity/single exact ID')
 for k,value in t.items():
  e=entries['native:'+k];valueactual=e.get('author_final',e.get('final_value',e.get('target')));vh=e.get('final_value_sha256',e.get('target_value_sha256'));ck(e['source']==s[k] and e['source_value_sha256']==h(s[k]) and valueactual==value and vh==h(value),name+' direct source/final value hashes');ck(bool(e.get('rationale')),name+' individual rationale')
  if name!='author-review.json':ck('approved' in e['status'],name+' explicit independent approval')
 direct.append({'path':str(p.relative_to(F)),'sha256':sha(p)})
ck(sha(D/'author-final.json')==sha(D/'final.json')==c['author_stage_sha256']==c['final_stage_sha256']=='5539c83d0d157e5723f9bcf9698e04f02cb9e33130b64c54bbfba41fe64372d7','Author/final stages5539 exact unchanged')
for e in c['stage_values']:
 k=e['id'].split(':',1)[1];ck(e['author']==a[k] and e['final']==t[k] and e['source_sha256']==h(s[k]) and e['author_sha256']==h(a[k]) and e['final_sha256']==h(t[k]) and not e['edited_after_author'],'Exact before/final stage value proof')
ck(pr['role_evidence'][:35]==bp['role_evidence'] and len(pr['role_evidence'])==40 and all(x in pr['role_evidence'] for x in direct),'35old refs unchanged plus5actual new direct role hashes')
ck(r['accepted_english']==br['accepted_english'] and len(r['accepted_english'])==268,'All268 individual English exceptions unchanged')
checked=P.check_draft(F,'fil');ck(set(checked['same_as_english_review_queue'])=={e['key'] for e in r['accepted_english']},'Actual English match queue exactly268 justified IDs')
refs=[]
def walk(v,at):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=Path(v['path']);p=p if p.is_absolute() else F/p;ok=p.is_file() and sha(p)==v['sha256'];refs.append({'at':at,'path':v['path'],'sha256':v['sha256'],'passed':ok});ck(ok,at+' reference SHA')
  for k,x in v.items():walk(x,at+'.'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):walk(x,at+'['+str(i)+']')
for v,at in [(pr,'provenance'),(c,'carry'),(r['language_brief'],'brief'),(r['provenance'],'review')]:walk(v,at)
for b in r['batches']:walk(b['provenance'],'batch:'+b['id'])
ck(len(r['gates'])==9 and all(g['passed'] is False for g in r['gates'].values()),'Nine canonical gates intentionally pending at snapshot')
ck(sorted(P.audit_locale(F,m,r,'fil'))==sorted(g+' is pending or lacks evidence' for g in P.GATES),'Tool audit only9expected gate issues')
rows=len(ns)+sum(len(v) if isinstance(v,dict) else 1 for v in nt['online'].values());ck(rows==6386 and rows*6==38316,'6386rows/38316matrixsamples')
ck(m['revision']=='ae20bdb4f9771e61f748fd6be8c6513a29169079','Final source ae20 envelope');ck(subprocess.run(['git','merge-base','--is-ancestor','1801e6a832657e183557f225abecee35e23250c2','HEAD']).returncode==0,'Frozen new master1801 actual ancestor')
result={'identity':'/root/adversarial_reviewer','status':'pass' if not issues else 'issues found','scope':'Independent source/catalog/schema/per-ID/stage/identity/hash aggregate audit only. Previous6358 source/target pairs exact carry; one new pair has five direct stages/four identities. No fresh6359-entry linguistic reread or runtime approval.','issues':issues,'checks':checks,'evidence_reference_checks':refs,'source_sha256':source,'catalog_sha256':catalog,'total_ids':6359,'unchanged_previous_ids':6358,'new_direct_review_ids':1,'batches':48,'english_exception_count':268,'role_evidence_count':40,'new_direct_reviews':direct,'expected_matrix_rows':rows,'expected_matrix_samples':rows*6,'expected_pending_gates':list(P.GATES),'snapshot_sha256':{str(p.relative_to(F)):sha(p) for p in [F/'manifest.json',rp,F/'reviews/fil-provenance.json',D/'source-target-carry.json']},'actual_checkout_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'limits':['Nine runtime gates deliberately pending; mutable canonical fil.json not pinned, immutable pre-runtime snapshot pinned instead.','Historical kit4 and earlier evidence unchanged and not relabeled ae20.','No tracked source, catalog, gate edits, API calls or build execution by reviewer.']}
P.write_json(D/'independent-aggregate-audit.json',result);print(json.dumps({'status':result['status'],'checks':len(checks),'refs':len(refs),'issues':issues,'sha256':sha(D/'independent-aggregate-audit.json')}))
