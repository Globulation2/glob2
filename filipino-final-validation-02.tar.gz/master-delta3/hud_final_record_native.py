from pathlib import Path
import subprocess,json,hashlib,os,time,sys
r=Path.cwd();k=r/'artifacts/filipino-localization';rev='4ffe6b1ec042c35cced022ddf496065118051ac5';sys.path.insert(0,str(r/'test'));from build_provenance import source_identity,build_issues
while not (k/'rendering/bin/TranslationPreviewHarness-final-hud-final').exists():time.sleep(2)
assert source_identity()['revision']==rev and source_identity()['dirty'] is False
b=r/'build/linux/client/debug/dev-dev_fast-true-linker-auto/test/glob2-engine-tests';args=[str(b),'--list-test-cases','--test-suite=SystemLanguage'];env=dict(os.environ,LD_LIBRARY_PATH=str(k/'sdl-reused/lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''))
p=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=k/'native-hud-final-executable-provenance.log';log.write_bytes(p.stdout);assert p.returncode==0
producer=json.loads(next(x.split('GLOB2_TEST_PROVENANCE ',1)[1] for x in p.stdout.decode().splitlines() if x.startswith('GLOB2_TEST_PROVENANCE ')));assert not build_issues(producer,source_identity())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[b,r/'build/linux/client/debug/dev-dev_fast-true-linker-auto/test/TranslationPreviewHarness',k/'rendering/bin/TranslationPreviewHarness-final-hud-final']
record={'revision':rev,'producer':producer,'argv':args,'exit_code':p.returncode,'scope':'Read-only listing binds executed engine provenance. Separate focused-test and matrix receipts determine actual passes. No binaries published.','files_sha256':{str(p.relative_to(r)):sha(p) for p in files},'log_sha256':sha(log),'pinned_sdl_libraries':{str(p.relative_to(k)):sha(p) for p in [k/'sdl-reused/lib/libSDL3.so.0',k/'sdl-reused/lib/libSDL3_ttf.so.0']}}
(k/'native-hud-final-executables.json').write_text(json.dumps(record,indent=2)+'\n')
print('PASS final4ffe native executable provenance',flush=True)
