from pathlib import Path
import json,hashlib,time,sys,collections
r=Path.cwd();k=r/'artifacts/filipino-localization';out=k/'rendering/native-final-6980-full-matrix'
while not (out/'current-matrix-proof.json').exists():time.sleep(5)
sys.path.insert(0,str(r/'test'));from build_provenance import source_identity,build_issues
sys.path.insert(0,str(r/'data'));from check_translations import read_table
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();draft=k/'final-kit3/drafts/fil';native=json.loads((draft/'native.json').read_text());online=json.loads((draft/'online.json').read_text());live,errors=read_table(r/'data/texts.fil.txt');assert not errors and native==live;assert online==json.loads((r/'platform/packages/i18n/locales/fil.json').read_text())
m=json.loads((out/'font-matrix.json').read_text());proof=json.loads((out/'current-matrix-proof.json').read_text());issues=build_issues(m['evidence_identity']['producer'],source_identity());assert not issues
expected={('native',q,'') for q in native}
for q,v in online.items():
 for branch in (v.keys() if isinstance(v,dict) else ['']):expected.add(('online',q,branch))
counts=collections.Counter((v['surface'],v['key'],v['branch']) for v in m['samples']);assert set(counts)==expected and set(counts.values())=={6};assert len(m['samples'])==37644
for n,h in proof['input_sha256'].items():assert sha(draft/n)==h
assert not proof['missing_glyphs'] and not proof['drawn_fit_failures'];assert proof['manifest_sha256']==sha(out/'font-matrix.json')
record={'status':'passed','source_issues':issues,'producer':m['evidence_identity']['producer'],'catalog_sha256':{'native':sha(r/'data/texts.fil.txt'),'online':sha(r/'platform/packages/i18n/locales/fil.json')},'native_rows':len(native),'online_variants':len(expected)-len(native),'samples':len(m['samples']),'each_entry_branch_combinations':6,'missing_glyphs':0,'drawn_fit_failures':0,'raw_raster_diagnostics':proof['raw_raster_diagnostics'],'matrix_sha256':sha(out/'font-matrix.json'),'proof_sha256':sha(out/'current-matrix-proof.json'),'scope':'Actualfinal6980engine/font/harness identity matches current clean checkout. Exact consumed draftinput hashes match installed catalogs semantically; every native key andonlinepluralvariant has six matrixsamples. Rawrastermetrics arediagnostic; authored destinations define actualdrawnfit. Pixelinspection recordedseparately.'};(out/'catalog-source-binding.json').write_text(json.dumps(record,indent=2)+'\n');print('PASS final6980 catalog/source/matrix binding',flush=True)
