from pathlib import Path
import json,hashlib,subprocess,re,collections
r=Path.cwd();o=r/'artifacts/filipino-localization/master-delta4';a='81e09c3b646c7055e1281bf84d2471a84d890f8f';b='1bb5155e96b61144583466a00041fb1d04fc9def';git=lambda *v:subprocess.check_output(['git',*v],cwd=r);sha=lambda q:hashlib.sha256(q).hexdigest()
paths=['data/texts.keys.txt','data/texts.en.txt','platform/packages/i18n/locales/en.json','platform/packages/i18n/plural-sources.json','platform/packages/i18n/invariants.json']
def snap(rev):
 data={p:git('show',rev+':'+p) for p in paths}; lines=data[paths[1]].decode('utf-8-sig').splitlines();native=dict(zip(lines[::2],lines[1::2]));keys=data[paths[0]].decode('utf-8-sig').splitlines();assert len(native)==len(keys) and set(native)==set(keys)
 hashes={p:sha(v) for p,v in data.items()};return {'native':native,'online':json.loads(data[paths[2]]),'file_sha256':hashes,'source_sha256':sha(json.dumps(hashes,sort_keys=True).encode())}
x=snap(a);y=snap(b)
def contract(v):
 def c(t):return {'sha256':sha(t.encode()),'placeholders':sorted(re.findall(r'\{[A-Za-z][A-Za-z0-9_]*\}|%\d+',t)),'leading_whitespace':re.match(r'^\s*',t).group(),'trailing_whitespace':re.search(r'\s*$',t).group(),'urls':re.findall(r'https?://\S+',t),'newlines':t.count('\n')}
 return {k:c(t) for k,t in v.items()} if isinstance(v,dict) else c(v)
report={'reviewer':'/root/meaning_reviewer','ours':a,'frozen_merge_head':b,'actual_merge_head':git('rev-parse','MERGE_HEAD').decode().strip(),'source_contract_paths':paths,'before':{'counts':{s:len(x[s]) for s in ['native','online']},'file_sha256':x['file_sha256'],'source_sha256':x['source_sha256']},'incoming':{'counts':{s:len(y[s]) for s in ['native','online']},'file_sha256':y['file_sha256'],'source_sha256':y['source_sha256']},'surfaces':{}}
assert report['actual_merge_head']==b
for s in ['native','online']:
 added={k:y[s][k] for k in y[s] if k not in x[s]};changed={k:{'before':x[s][k],'after':y[s][k]} for k in x[s].keys()&y[s].keys() if x[s][k]!=y[s][k]};removed={k:x[s][k] for k in x[s] if k not in y[s]};report['surfaces'][s]={'added':added,'changed':changed,'removed':removed,'added_contracts':{k:contract(v) for k,v in added.items()},'unchanged_key_values':sum(k in y[s] and v==y[s][k] for k,v in x[s].items())}
added=report['surfaces']['online']['added'];patterns=o/'online-added-patterns.txt';patterns.write_text('\n'.join(added)+'\n')
cmd=['git','grep','-n','-F','-f',str(patterns),b,'--','platform/apps/web/src','platform/packages/protocol/src'];p=subprocess.run(cmd,cwd=r,capture_output=True,text=True);assert p.returncode==0
(o/'online-source-context-matches.txt').write_text(p.stdout);matches=collections.defaultdict(list)
for line in p.stdout.splitlines():
 prefix,path,num,text=line.split(':',3)
 for key in added:
  if key in text:matches[key].append({'path':path,'line':int(num),'text':text})
report['added_online_context_references']={k:matches[k] for k in added};report['context_source_file_sha256']={p:sha(git('show',b+':'+p)) for p in sorted({v['path'] for m in matches.values() for v in m})};report['context_unmatched_keys']=[k for k in added if not matches[k]]
report['working_merged_source_bytes_match_incoming']={p:sha((r/p).read_bytes())==y['file_sha256'][p] for p in paths}
report['source_contract_changes']=[p for p in paths if x['file_sha256'][p]!=y['file_sha256'][p]]
report['scope_conclusion']='Native3411sourcekey/value pairs unchanged exactly; existingFil native reviews remain valid. Online111newEnglishkeys require drafting and four-role source-context reviews. Existing2836online values unchanged; no removed/changed existing key. Four new publication/download/completion metric-label strings preserve {value0}; publication/download value0 is libraryName(dimension), not a numeric count; no new plural branches, URLs, or leading/trailing whitespace. Plural-source and invariant contracts unchanged. No target catalog edits or API requests by this inventory.'
report['script_sha256']=sha(Path(__file__).read_bytes());(o/'source-inventory.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'counts_before':report['before']['counts'],'counts_incoming':report['incoming']['counts'],'added':{s:len(report['surfaces'][s]['added']) for s in ['native','online']},'changed':{s:len(report['surfaces'][s]['changed']) for s in ['native','online']},'context_files':len(report['context_source_file_sha256']),'unmatched':report['context_unmatched_keys'],'sourcehash':y['source_sha256']}))
