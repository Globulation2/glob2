from pathlib import Path
import json,hashlib,subprocess
r=Path.cwd();d=r/'artifacts/filipino-localization/master-delta4';read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=lambda t:hashlib.sha256(t.encode()).hexdigest();source=read(d/'source.json')['entries'];target=read(d/'author-final.json');assert sha(d/'author-final.json')=='5351e5c9dd0d3438a17bc64001ec4a5fce8c3f92abfed8c573b75ccf14bb808b'
notes='''Early aggression is the AI strategy tag, not a speed boost or hurry command.
Defensive AI posture is preserved by a compact adjective.
AI economic focus keeps the established economy noun.
AI expansion strategy describes territorial growth.
Experimental is the AI tag, not a promise of tested stability.
Beginner-friendly means suitable for newcomers, not restricted to them.
File and API profile denotes validator interface/file contract; API is an intentional identifier loan.
Syntax and profile restrictions denote coding constraints, not player personality.
Startup and callback are controller lifecycle checks; callback retained as programming term.
Persistent state denotes controller state kept across calls; no new save behavior claimed.
Seeded gameplay retains the technical seed concept and fixed reproducibility input, not agriculture.
Repeatable simulation denotes reproducibility, not merely repeat button behavior.
Save and resume checks saving and continuing; established save loan retained.
Good is a connection quality category, not an ethical judgment.
Fair denotes intermediate connection quality rather than equitable play.
Poor denotes weak connection quality rather than poverty.
Ping explanation preserves roundtrip, pre-match regional probe, and estimate limitations.
Delay is the input-delay metric label, not lagging behind clock.
Input-delay formula preserves half-ping plus jitter buffer and everyone seeing the action.
Behind-clock explanation preserves under-one-second normal range and relay slow threshold starting2s.
Classic glossy retains traditional shiny material appearance.
Basics groups basic surface materials.
Matte means non-shiny, not a doormat.
Riveted metal describes fasteners on a surface; rivet technical loan retains that specific texture.
Metal is a standard Filipino material loan and matches existing vocabulary.
Hairy denotes surface fur, not player hair style.
Organic is material family rather than organic food certification.
Cartoon preserves stylized drawn rendering sense.
Woven fabric retains interlaced cloth appearance.
Craft groups handmade material appearances.
Dripping goo sense is retained; editor may supply explicit likido head noun for smoother phrasing.
Wet is surface-material family, not a gameplay wetness mechanic.
Wood remains wood material rather than forest terrain.
Stone remains stone surface rather than collectible resource count.
Mineral is standard Filipino material loan and family name.
Scales correctly names animal surface scales, not numeric measuring scales.
Leather correctly means hide material rather than shoes.
Crystal retains crystalline surface rather than a graphics API term.
Lava is established Filipino material loan; no damage rule promised.
Chrome names chromium-like metallic finish, not browser application.
Carbon fibre describes fibrous carbon finish; Spanish/Indonesian references confirm material sense.
Velvet becomes pelus fabric texture rather than a color name.
Saray is dictionary-attested bahay-pukyutan sense; compound identifies honeycomb cells, distinct from honey liquid.
Ice denotes icy glasslike surface, no temperature rule.
Cloud denotes fluffy cloudlike material, no online hosting service.
Hammered metal preserves worked/dimpled metal surface rather than a weapon.
Candy retains sweet candy-like surface finish.
Lusak implies mud/slush, while shaderID21 is translucent slime with bubbles; revise material noun to gel.
AI player is an automated participant, not a human AI developer.
Finances identifies financial administration section.
Accounts means user accounts; established account loan avoids bank-only sense.
Audit labels history/examination of administrative events.
One hour duration and numeral preserved.
One day duration and numeral preserved.
One week duration and numeral preserved.
Thirty-day period is preserved exactly.
Most played sorts by number of plays, not longest session duration.
Musical structure and progression are preserved as listening criteria.
Three moods are playable arrangements; mood technical loan refers Calm/Building/Combat.
Unexpected volume jumps between moods are preserved, not pitch changes.
Click, gap, abrupt loop seam distinctions retained; loop is established playback term.
Mechanical short musical repetition distinguished from normal loop repetition.
Switch moods then listen for timing/harmony changes preserves imperative sequence.
Building/Combat/Calm are actual musical mood names, not construction/combat sound effects.
Hiss and scratchy noise in quiet passages remain audio quality checks.
Baho has dictionary-attested musical bass meaning; malabo describes muddy indistinct low frequencies.
Mahihinang narrows calm to low volume; prefer kalmadong mga bahagi to retain calm wording.
Unexpected note cutoffs retain the dropout test meaning.
Worker matches native manggagawa unit role.
Warrior matches native mandirigma unit role.
Explorer matches native tagapaggalugad unit role.
Swarm uses established native Pugad building name rather than a moving mob.
Classic names original swarm mesh appearance.
Crown names crown-like shape rather than monarchy mechanic.
Clutch is cluster of brood eggs, not gripping action or vehicle clutch.
Toadstool is mushroom mesh, not stool furniture.
Broad mushroom cap and nearby young caps preserved; geometry reference supports surrounding small mushrooms.
Coral names branching coral-like structure.
Skep is traditional woven hive; Spanish/Indonesian references support descriptive woven beehive phrase.
Coiled hive, supporting stand and forward-facing entrance are all preserved.
Bloom names flowerlike mesh, not shader bloom effect.
Public listing means discoverable in catalog, not merely link-accessible.
Unlisted means link-accessible without catalog listing; anyone condition preserved.
Private means only owner can access, not members-only sharing.
Verified match replay agreement of every player preserved, without equating it to a live spectator replay.
Pending server check gates rating changes until verification.
Diverged client/server replay retains server authoritative result.
Unreproducible match changes no rating; not counted as automatic loss.
Not-applicable check status remains unchecked rather than failed.
Failed check preserves temporary no-rating effect and administrator retry possibility.
Walk is animation clip action rather than a movement order.
Swim is animation clip action rather than a swim upgrade instruction.
Harvest is animation clip action and keeps resource harvesting sense.
Fight is combat animation clip action.
Fly is flying animation clip action, not a fly insect.
Live payments are real transactions rather than livestream payments.
Test payments are test-mode transactions rather than a command to test payment.
Unclassified payments retain unclassified mode, not unpaid transactions.
Current reporting period preserved without implying calendar month.
Previous reporting period preserved without fixing its duration.
Credit grant is awarded wallet credits rather than a loan or card.
Returned credits are returned wallet units rather than refunded currency promised.
Dispute is specifically payment dispute in financial ledger.
Closed payment dispute retains closure without claiming win/loss outcome.
Started-match count label remains distinct from completed matches.
Completed-match count label remains distinct from started/cancelled.
Cancelled matches remain distinct from failed verification.
value0 is libraryName, not number; publications in named library retained after placeholder repositioning.
value0 is libraryName, not number; recorded download label retains recorded qualification.
value0 is productName; completion duration retains seconds unit explicitly.
value0 is productName; completion samples means recorded completion observations, not downloadable examples.'''.splitlines()
assert len(notes)==111,(len(notes));assert len(source)==111
findings=[{'id':'meaning-slime-material','key':'online:Slime','severity':'minor','state':'open','source':'Slime','target':target['Slime'],'proposed':'Malapot na gel','reason':'Actual skin-material.glsl408-425 defines translucent slime/bubbles, not mud/slush. Replace lusak material sense.'},{'id':'meaning-calm-passage-precision','key':'online:Check that calm passages remain audible alongside game sound.','severity':'minor','state':'open','source':'Check that calm passages remain audible alongside game sound.','target':target['Check that calm passages remain audible alongside game sound.'],'proposed':'Tiyaking naririnig pa rin ang mga kalmadong bahagi kasabay ng mga tunog ng laro.','reason':'Preserve calm quality of musical passage rather than narrowing it to low loudness; category is audibility, not a volume instruction.'}]
entries=[]
for (key,value),note in zip(source.items(),notes):
 entries.append({'id':'online:'+key,'source':value,'source_value_sha256':h(value),'target':target[key],'target_value_sha256':h(target[key]),'status':'minor revision requested' if any(f['key']=='online:'+key for f in findings) else 'approved at first meaning pass','rationale':note})
contexts=['platform/packages/protocol/src/ais.ts','platform/packages/protocol/src/connectionQuality.ts','platform/packages/protocol/src/skins.ts','platform/apps/web/src/skins/swarmShapes.ts','platform/apps/web/src/skins/geometry.ts','platform/apps/web/src/music/Validation.tsx','platform/apps/web/src/music/Player.tsx','platform/apps/web/src/admin/presentation.ts','platform/apps/web/src/pages/Maps.tsx','platform/apps/web/src/pages/Match.tsx','libgag/shaders/skin-material.glsl']
rec={'reviewer':'/root/meaning_reviewer','stage':'independent first meaning review of every111 author-stage source/target pair','source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_snapshot_sha256':sha(d/'source.json'),'author_target_snapshot_sha256':sha(d/'author-final.json'),'source_program_sha256':read(d/'source.json')['source_sha256'],'reviewed_ids':[e['id'] for e in entries],'entries':entries,'findings':findings,'unresolved_major':0,'unresolved_critical':0,'unresolved_uncertainty':[],'context_actually_read_sha256':{n:sha(r/n) for n in contexts},'selected_reference_catalog_sha256':{n:sha(r/n) for n in ['platform/packages/i18n/locales/es.json','platform/packages/i18n/locales/id.json','data/texts.fil.txt']},'reference_scope':'Selected Spanish/Indonesian material/swarm/music references and established Filipino unit/building/mood vocabulary consulted; references are context, not Filipino authority. All111English/author-target pairs directly read.','consulted_dictionary_sources':[{'url':'https://diksiyonaryo.ph/word/saray','use':'Attested beehive sense supports saray; not a generic layer assumption.'},{'url':'https://diksiyonaryo.ph/word/baho','use':'Attested lowest musical register/instrument/tone supports musical baho; distinguished from bad-smell homograph.'},{'url':'https://diksiyonaryo.ph/word/uhog','use':'Nasal mucus sense excludes uhog as preferred cosmetic slime replacement.'}],'accepted_english':[{'key':'online:Metal','reason':'Metal is an established Filipino material noun; identical spelling preserves the actual material family.'},{'key':'online:Mineral','reason':'Mineral is established Filipino scientific/material vocabulary and accurately names this material family.'},{'key':'online:Lava','reason':'Lava is established Filipino geological vocabulary and identifies the cosmetic lava material.'}],'limits':['No native-human certification.','First-pass author snapshot only; final editor values must be independently reread.','No tracked source/catalog edits or paid requests by reviewer.']}
(d/'meaning-review.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');print('Actual111first meaning review recorded;2minor findings,0major/critical/linguistic uncertainty')
