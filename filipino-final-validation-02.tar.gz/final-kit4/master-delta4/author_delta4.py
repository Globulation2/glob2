import json,hashlib,re,datetime
from pathlib import Path
P=Path(__file__).parent
H=lambda s:hashlib.sha256(s.encode()).hexdigest()
FH=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=json.loads((P/'source.json').read_text());draft=json.loads((P/'draft.json').read_text());inv=json.loads((P/'source-inventory.json').read_text())
values='''Maagang pag-atake
Depensibo
Ekonomiya
Pagpapalawak
Eksperimental
Para sa mga baguhan
File at profile ng API
Syntax at mga limitasyon ng profile
Pagsisimula at callback
Nananatiling estado
Paglalaro na may takdang seed
Nauulit na simulasyon
Pag-save at pagpapatuloy
Maganda
Katamtaman
Mahina
Oras ng pagpunta at pagbalik ng datos sa pagitan ng manlalaro at relay. Bago ang laban (mabilis na laban, listahan bago magsimula), pagtatantya ito batay sa pagsubok sa rehiyon.
Pagkaantala
Pagkaantala ng iyong input: mula sa pag-click mo hanggang sa maganap ito para sa lahat. Kalahati ng iyong ping, dagdag ang reserbang oras ng laro para sa pabago-bagong pagkaantala.
Gaano katagal nahuhuli ang laro ng isang manlalaro sa oras ng laban. Normal ang wala pang isang segundo (kasama rito ang pagkaantala ng kanilang input); mula 2 s, minamarkahan na ng relay na mabagal ang manlalaro.
Klasikong makintab
Mga batayan
Di-makintab
Metal na may mga rivet
Metal
Mabalahibo
Organiko
Kartun
Hinabing tela
Gawang-kamay
Umaagos na malagkit
Basa
Kahoy
Bato
Mineral
Kaliskis
Katad
Kristal
Lava
Kromo
Hiblang karbon
Pelus
Saray ng pulot-pukyutan
Yelo
Ulap
Pinukpok na metal
Kendi
Malapot na lusak
Manlalarong AI
Pananalapi
Mga account
Pag-audit
1 oras
1 araw
1 linggo
30 araw
Pinakamaraming beses nilaro
Pakinggan ang pagkakabuo at pag-usad ng musika.
Tiyaking tama ang pagtugtog ng lahat ng tatlong mood.
Pakinggan kung may di-inaasahang biglang pagbabago sa lakas ng tunog sa pagitan ng mga mood.
Pakinggan kung may tik, patlang, o biglang pagbabago kapag umuulit ang loop.
Pakinggan kung may maiikling pariralang musikal na paulit-ulit na parang makina.
Magpalit ng mood at pakinggan kung may pagbabago sa tiyempo o harmonya.
Tiyaking naiiba ang dating ng Pagtatayo at Labanan sa Kalmado.
Pakinggan kung may pagsitsit o magaspang na ingay sa mahihinang bahagi.
Pakinggan kung malabo ang tunog ng baho o masakit sa tainga ang matataas na tunog.
Tiyaking naririnig pa rin ang mahihinang bahagi kasabay ng mga tunog ng laro.
Pakinggan kung may mga notang biglang napuputol.
Manggagawa
Mandirigma
Tagapaggalugad
Pugad
Klasiko
Korona
Kumpol ng mga itlog
Kabute
Kabuteng may malapad na payong at mga batang kabute sa paligid.
Koral
Hinabing bahay-pukyutan
Nakapulupot na bahay-pukyutan sa isang patungan, na nakaharap sa iyo ang pasukan.
Bulaklak
Pampubliko: nakalista sa katalogo
Hindi nakalista: sinumang may link
Pribado: ikaw lang
Muling pinatakbo ng server ang laban at tumugma rito ang laro ng bawat manlalaro.
Sinusuri ng server ang laban. Magbabago ang mga rating kapag napatunayan na ang resulta.
Hindi tumugma ang laro ng isang manlalaro sa muling pagpapatakbo ng server sa laban; ang resulta ng server ang susundin.
Hindi muling mabuo ng server ang laban, kaya wala itong binabagong rating.
Hindi sinusuri ang laban na ito.
Hindi matapos ng server ang pagsusuri sa laban, kaya wala muna itong binabagong rating. Maaaring ulitin ng tagapangasiwa ang pagsusuri.
Paglakad
Paglangoy
Pag-aani
Pakikipaglaban
Paglipad
Mga tunay na pagbabayad
Mga pansubok na pagbabayad
Mga pagbabayad na walang kategorya
Kasalukuyang panahon
Nakaraang panahon
Pagbibigay ng kredito
Mga ibinalik na kredito
Pagtutol sa bayad
Sarado na ang pagtutol sa bayad
Mga sinimulang laban
Mga natapos na laban
Mga kinanselang laban
Mga paglalathala sa {value0}
Mga naitalang pag-download sa {value0}
Oras ng pagkumpleto sa {value0} (segundo)
Mga naitalang pagkumpleto sa {value0}'''.splitlines()
assert len(values)==len(s['entries'])==111,(len(values),len(s['entries']))
final=dict(zip(s['entries'],values))
loans={
'File and API profile':{'File':'Established computing term for a stored source-code file; no user-authored filename is translated.','profile':'Programming API profile means the allowed interface/version, not a biography.','API':'Standard technical acronym identifies the JavaScript interface.'},
'Syntax and profile restrictions':{'Syntax':'Recognizable programming grammar term for this code-validation check.','profile':'The allowed controller/API profile, consistent with the adjacent check.'},
'Startup and callback':{'callback':'Programming function invoked by the engine; literal pagtawag pabalik suggests a telephone call.'},
'Seeded gameplay':{'seed':'Existing generator/gameplay technical loan for deterministic random initialization, not an agricultural seed.'},
'Save and resume':{'save':'Established saved-game operation, consistent with existing catalog save terminology.'},
'Riveted metal':{'Metal':'Shared Filipino/English material term identifies a metallic finish.','rivet':'Recognizable fastener/material detail; avoids inventing a mechanically different bolt or screw.'},
'Metal':{'Metal':'Shared Filipino/English material term; this is the skin finish group.'},
'Mineral':{'Mineral':'Established Filipino scientific material term, identical spelling to English.'},
'Lava':{'Lava':'Established Filipino volcanic-material term, identical spelling to English.'},
'AI player':{'AI':'Established game acronym identifies an automated player, not a human playing against one.'},
'Accounts':{'account':'Existing sign-in/account-management term; these are user accounts, not financial ledger accounts.'},
'Audit':{'audit':'Recognizable administrative examination/log term, carried as Filipino Pag-audit.'},
'Unlisted: anyone with the link':{'link':'Existing browser term for an address that grants access to an unlisted item.'},
}
for k in final:
 if 'mood' in final[k]:loans.setdefault(k,{})['mood']='Existing soundtrack selector term for Calm/Building/Combat arrangements; preserves the established UI terminology, not a player emotion.'
 if 'loop' in final[k]:loans.setdefault(k,{})['loop']='Existing audio term for the repeating music segment and its seam.'
 if 'server' in final[k]:loans.setdefault(k,{})['server']='Established multiplayer host/service term; distinguishes authoritative replay from each player’s local game.'
 if 'rating' in final[k]:loans.setdefault(k,{})['rating']='Existing competitive ranking measure, not a content review score.'
 if 'relay' in final[k]:loans.setdefault(k,{})['relay']='Network relay service, consistent with multiplayer technical terminology.'
 if 'input' in final[k]:loans.setdefault(k,{})['input']='Player-issued game action; established control/network term.'
 if 'ping' in final[k]:loans.setdefault(k,{})['ping']='Named connection metric for measured round-trip latency.'
 if 'download' in final[k]:loans.setdefault(k,{})['download']='Established browser transfer operation, consistent with library download counters.'
context={}
for i,k in enumerate(final):
 if i<=12:r='AI strategy tag or controller validation stage; distinguishes early aggression, persistent state and deterministic seeded/repeatable simulation from literal everyday meanings.'
 elif i<=19:r='Connection-quality table: round-trip latency, input buffer and time behind match clock. Fair is an intermediate quality grade, not fairness; units and thresholds preserved.'
 elif i<=47:r='Skin material/group label from COLONY_SKIN_MATERIALS; describes surface appearance rather than a gameplay effect. Corrected literal or unrelated machine senses.'
 elif i<=56:r='Administrative navigation/time filter or map popularity order; descriptive label, not an imperative or claim that an action already happened.'
 elif i<=67:r='MusicValidation listening guidance for Calm/Building/Combat arrangements; passages are audio sections and phrases are musical, with loop seam/noise/frequency distinctions preserved.'
 elif i<=71:r='Skin preview unit/building selector uses the established game glossary.'
 elif i<=80:r='Swarm mesh shape from SWARM_SHAPES; translates visible form, not a unit mechanic or asset identifier.'
 elif i<=83:r='Visibility setting preserves public catalog listing, link access and owner-only access distinctions.'
 elif i<=89:r='Match verification status: authoritative server replay compared with local games; preserves when ratings change and whether an administrator may retry.'
 elif i<=94:r='Unit animation preview action label; noun form describes the selected clip, not a game command.'
 else:r='Admin presentation mapping for payment modes, finance journal, reporting intervals or analytics. Completion placeholders name products; publication/download placeholders name libraries, not numeric counts.'
 context[k]=r
context['Clutch']='Six brood eggs nested in a low rim; Kumpol ng mga itlog follows actual mesh description, supported by Spanish Nidada de huevos and Indonesian Kelompok telur. Not a grip or vehicle clutch.'
context['Scales']='Reptile-like surface material, confirmed by material table and Spanish Escamas/Indonesian Sisik; Kaliskis, not weighing instruments.'
context['Chrome']='Metallic chromium-like finish under Metal group; Kromo, not the Chrome browser.'
context['Velvet']='Soft fabric finish: Pelus, correcting the unrelated Google Pelvis.'
context['Honeycomb']='Pattern of honeycomb cells rather than the honey itself; Saray ng pulot-pukyutan distinguishes structure from substance.'
context['Skep']='Coiled traditional woven hive on a stand; descriptive Hinabing bahay-pukyutan supported by Spanish Colmena tejida/Indonesian Sarang lebah anyaman; no unexplained English mesh name.'
context['Persistent state']='Controller state that persists across callbacks/serialization; Nananatiling estado avoids suggesting continuous change.'
context['Repeatable simulation']='Determinism validation means the same result can be reproduced, not merely a simulation repeatedly running.'
context['{value0} completion samples']='Admin completionStats counts successful completion observations, not audio samples or example tasks; {value0} is productName, not a number.'
context['Most played']='Map order by plays; Pinakamaraming beses nilaro expresses actual match play count rather than generic use.'
context['Live payments']='Production real-money payment journal, distinguished from sandbox test mode; avoids literal live-broadcast reading.'
context['Credit grant']='Administrative issuance of studio-generation credits; not a bank loan or attribution.'
context['Dispute']='Payment dispute journal event, not a general argument between players.'
context['Dispute closed']='Closed payment dispute event; does not invent whether it was won or lost.'
entries=[]
for k,v in final.items():
 assert re.findall(r'\{[^}]+\}',k)==re.findall(r'\{[^}]+\}',v),(k,v)
 assert v==v.strip() and '\n' not in v
 entries.append({'id':'online:'+k,'source':s['entries'][k],'source_value_sha256':H(s['entries'][k]),'google_draft':draft[k],'draft_value_sha256':H(draft[k]),'author_final':v,'final_value_sha256':H(v),'edited':v!=draft[k],'status':'author-edited-awaiting-independent-reviews','rationale':context[k],'intentional_english_terms':loans.get(k,{})})
files=['platform/apps/web/src/admin/presentation.ts','platform/apps/web/src/skins/swarmShapes.ts','platform/packages/protocol/src/skins.ts','platform/packages/protocol/src/ais.ts','platform/packages/protocol/src/connectionQuality.ts','platform/apps/web/src/music/Validation.tsx','platform/apps/web/src/skins/geometry.ts','platform/packages/i18n/locales/fil.json','platform/packages/i18n/locales/es.json','platform/packages/i18n/locales/id.json']
for n,obj in [('author-final.json',final),('author-review.json',{'role':'draft editor / author','reviewer':'/root/draft_editor','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual source/Google draft/final read and author edit of exactly111 newly added online keys; no claim of a new full-catalog read or independent approval. No tracked catalogs changed.','source_revision':s['merge_revision'],'source_program_sha256':s['source_sha256'],'input_sha256':{n:FH(P/n) for n in ['source.json','draft.json','source-inventory.json']},'context_files_actually_read_sha256':{n:FH(n) for n in files},'final_file_sha256':None,'entry_count':111,'edited_count':sum(x['edited'] for x in entries),'entries':entries})]:
 if n=='author-review.json':obj['final_file_sha256']=FH(P/'author-final.json')
 (P/n).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print('author-final',FH(P/'author-final.json'),'entries',len(entries),'edits',sum(x['edited'] for x in entries))
