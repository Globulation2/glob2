from pathlib import Path
import hashlib,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[4];K=ROOT/'artifacts/filipino-localization';F=K/'final-kit4';B=K/'final-kit3';sys.path.insert(0,str(ROOT/'tools/localization'));import translation_program as P
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=lambda s:hashlib.sha256(s.encode()).hexdigest();issues=[];checks=[]
def ck(v,label):checks.append({'check':label,'passed':bool(v)});issues.extend([] if v else [label])
m=read(F/'manifest.json');r=read(F/'reviews/fil.json');prov=read(F/'reviews/fil-provenance.json');br=read(B/'reviews/fil.json');bp=read(B/'reviews/fil-provenance.json');bm=read(B/'manifest.json');d=F/'master-delta4';carry=read(d/'source-target-carry.json');final=read(d/'final.json');author=read(d/'author-final.json');S=read(d/'source.json')['entries'];ids={'online:'+k for k in final}
old={s:read(B/'source'/(s+'.json')) for s in ['native','online']};new={s:read(F/'source'/(s+'.json')) for s in old};ot={s:read(B/'drafts/fil'/(s+'.json')) for s in old};nt={s:read(F/'drafts/fil'/(s+'.json')) for s in old}
ck(len(old['native'])==3411 and len(old['online'])==2836,'Previous6247source inventory');ck(new['native']==old['native'] and new['online']==dict(old['online'],**S) and not(set(old['online'])&set(S)) and len(S)==len(final)==111,'Exactly111online additions, native/source values unchanged')
ck(nt['native']==ot['native'] and nt['online']==dict(ot['online'],**final),'Every6247previous target unchanged, only111final additions')
for surf in old:ck(set(carry['unchanged_'+surf+'_ids'])=={surf+':'+k for k in old[surf]} and len(carry['unchanged_'+surf+'_ids'])==len(old[surf]),surf+': exactcarry IDs/no duplicates')
ck(set(carry['added_ids'])==ids and len(carry['added_ids'])==111,'Exact111added carry IDs')
keys,ns,os,sourcefiles,source=P.sources(ROOT);paths=P.catalog_paths(F,'fil');catalog={s:sha(p) for s,p in paths.items()};ck(source==m['source_sha256']==r['source_sha256']==prov['source_sha256']==carry['source_after_sha256']=='822cf8613451177b0e2fa803451eaf2308168f21f4d04b7af2aa36cfe64bc3fc','Final822cfsource contract hash exact')
ck(catalog==r['catalog_sha256']==prov['catalog_sha256']==carry['catalog_after_sha256'] and catalog['native']=='017c3da56738d3005d434fbe5160240b3dc342e4d4ffd8f97fc4991ce14fe54a' and catalog['online']=='30c1e0e2f79104b31ba14b7704b0df44b82065436bbee22dd2963bf1116e948c','Finalnative017c/online30c1catalog hashes exact')
ck(ns==new['native'] and os==new['online'] and sourcefiles==m['source_files'] and sha(ROOT/'data/texts.fil.txt')==catalog['native'] and sha(ROOT/'platform/packages/i18n/locales/fil.json')==catalog['online'],'Snapshot equals actual installed English/Fil source+targets')
ck(all(sourcefiles[n]==bm['source_files'][n] for n in P.SOURCE_PATHS if n!='platform/packages/i18n/locales/en.json'),'All other source/native/plural/invariant contracts unchanged')
expected={b['id']:set(b['keys']) for b in m['batches']};flat=[k for b in m['batches'] for k in b['keys']];allids={'native:'+k for k in ns}|{'online:'+k for k in os};ck(len(expected)==len(m['batches'])==len(r['batches'])==47,'Exactly47source/review batches');ck(set(flat)==allids and len(flat)==len(set(flat))==6358,'All6358IDs covered exactlyonce')
th=P.batch_target_hashes(m,paths);oldb={b['id']:b for b in br['batches']}
for b in r['batches']:
 bid=b['id'];ck(b['source_sha256']==source and b['target_sha256']==th[bid],bid+': correct source envelope/targetbatch hash');ck(len({b[k] for k in ['author','reviewer','editor','adversarial_reviewer']})==4 and b['rechecked_by']==b['reviewer'],bid+':4distinctroles/meaning final recheck')
 for field in ['reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys']:ck(set(b[field])==expected[bid] and len(b[field])==len(set(b[field])),bid+':'+field+' coverage')
 if bid in oldb:
  prev=oldb[bid];ck(all(b[k]==v for k,v in prev.items() if k not in ['source_sha256','provenance']),bid+':previous identity/coverage/targethash fields preserved');ck(all(b['provenance'].get(k)==v for k,v in prev['provenance'].items() if k!='master_source_carry'),bid+':previousrole reference paths retained')
roles={'author-review.json':'/root/draft_editor','meaning-review.json':'/root/meaning_reviewer','editor-review.json':'/root/language_editor','meaning-final-review.json':'/root/meaning_reviewer','adversarial-review.json':'/root/adversarial_reviewer'};direct=[]
for name,who in roles.items():
 p=d/name;v=read(p);stage=author if name in ['author-review.json','meaning-review.json'] else final;entries={e['id']:e for e in v['entries']};ck(v.get('identity',v.get('reviewer'))==who and len(v['entries'])==111 and set(entries)==ids,name+':actualidentity/exact111IDs')
 for key,value in stage.items():
  e=entries['online:'+key];target=e.get('author_final',e.get('final_value',e.get('target')));targethash=e.get('final_value_sha256',e.get('target_value_sha256'));ck(e['source']==S[key] and e['source_value_sha256']==h(S[key]) and target==value and targethash==h(value),name+':actual stage source/value hashes '+key)
  if name not in ['author-review.json','meaning-review.json']:ck('approved' in e.get('status',''),name+':explicitfinalstageapproval '+key)
  if name=='meaning-review.json':ck('approved' in e.get('status','') or (e.get('status')=='minor revision requested' and any(x['key']==e['id'] and x['severity']=='minor' for x in v['findings'])),name+':actual firstpass approval-or-recordedminor '+key)
 direct.append({'path':str(p.relative_to(F)),'sha256':sha(p),'identity':who,'stage':'author5351' if stage is author else 'final235b'})
ck(sha(d/'author-final.json')==carry['author_stage_sha256']=='5351e5c9dd0d3438a17bc64001ec4a5fce8c3f92abfed8c573b75ccf14bb808b' and sha(d/'final.json')==carry['final_stage_sha256']=='235bc9c6ae1e6c8a3ffb676027520f398b8373e631428167d2aa1983bdc61bbb','Author/final immutable stage snapshots exact')
changed={k for k in final if author[k]!=final[k]};ck(len(changed)==5 and set(carry['actual_editorial_changed_ids'])=={'online:'+k for k in changed},'Exactly5editorial changes and106unchanged new targets')
ck(len(carry['stage_values'])==111 and {e['id'] for e in carry['stage_values']}==ids,'All111carry stagevalue records present')
for e in carry['stage_values']:
 key=e['id'].split(':',1)[1];ck(e['author']==author[key] and e['final']==final[key] and e['source_sha256']==h(S[key]) and e['author_sha256']==h(author[key]) and e['final_sha256']==h(final[key]) and e['edited_after_author']==(key in changed),'Exactactual author/final delta '+key)
a=read(d/'author-review.json');fm=read(d/'meaning-review.json');ed=read(d/'editor-review.json');lm=read(d/'meaning-final-review.json');ad=read(d/'adversarial-review.json')
ck(a['final_file_sha256']==fm['author_target_snapshot_sha256']==ed['author_snapshot_sha256']==lm['author_target_snapshot_sha256']==sha(d/'author-final.json'),'Allstage author snapshot pointers5351exact')
ck(ed['final_snapshot_sha256']==lm['final_target_snapshot_sha256']==ad['final_snapshot_sha256']==sha(d/'final.json'),'Allfinalstage snapshot pointers235bexact')
ck(fm['source_snapshot_sha256']==ed['source_snapshot_sha256']==lm['source_snapshot_sha256']==ad['source_snapshot_sha256']==sha(d/'source.json'),'Directsource111snapshot SHA exact')
initial_findings={e['id']:e for e in fm['findings']};resolved={e['id']:e for e in lm['resolved_first_pass_findings']}
ck(len(initial_findings)==2 and set(initial_findings)==set(resolved),'Exactly2historical firstmeaning findings separatelyresolved')
for label,e in initial_findings.items():
 x=resolved[label];key=e['key'].split(':',1)[1];ck(e['state']=='open' and e['severity']=='minor' and x['state']=='resolved' and x['key']==e['key'] and x['previous_target']==author[key] and x['previous_target_sha256']==h(author[key]) and x['final_target']==final[key] and x['final_target_sha256']==h(final[key]) and key in changed,'Actual before/final hashes and editorial correction resolve '+label)
ck(lm['unresolved_major']==0 and lm['unresolved_critical']==0 and not lm['unresolved_uncertainty'],'Finalmeaning explicitly has0major/critical/uncertainty')
ck(ed['meaning_first_pass_sha256']==lm['first_meaning_review_sha256']==sha(d/'meaning-review.json') and lm['editor_review_sha256']==sha(d/'editor-review.json'),'Editor/finalmeaning previous-stage receipt pointers exact')
ck(prov['role_evidence'][:30]==bp['role_evidence'] and len(prov['role_evidence'])==35,'All30historical role references preserved plus5new records');ck(all({'path':e['path'],'sha256':e['sha256']} in prov['role_evidence'] for e in direct),'All5actualnewrole SHA references present')
checked=P.check_draft(F,'fil');accepted=r['accepted_english'];ck(len(accepted)==268 and accepted[:265]==br['accepted_english'],'All265previousEnglish exceptions preserved plus3new');ck({e['key'] for e in accepted}==set(checked['same_as_english_review_queue']),'All268actualEnglish matches have exactindividual exception IDs')
newaccepted={e['key']:e for e in accepted[265:]};directenglish={e['id']:e for e in ad['accepted_english']}
for term in ['Metal','Mineral','Lava']:
 label='online:'+term;e=newaccepted[label];v=directenglish[label];ck(e['reason']==v['rationale'] and v['value']==final[term]==S[term] and v['value_sha256']==h(final[term]),label+':individualsharedFilipino word rationale and actualhash')
comp=read(d/'adversarial-fragment-composition.json');ck(comp['main_review_sha256']==sha(d/'adversarial-review.json') and comp['final_snapshot_sha256']==sha(d/'final.json') and comp['existing_catalog_sha256']==sha(P.catalog_paths(B,'fil')['online']),'Fragment supplement pins originalreview/final/actualhistoricalcatalog')
ck(len(comp['examples'])==4,'All4value0template compositions directlychecked')
for e in comp['examples']:
 key=e['id'].split(':',1)[1];ck(e['status']=='approved' and e['composed']==final[key].replace('{value0}',e['value0']) and re.findall(r'\{\w+\}',S[key])==re.findall(r'\{\w+\}',final[key])==['{value0}'],'Exactproduct/library-name template composition '+key)
ck(comp['examples'][2]['value0']==nt['online']['Map Studio']=='Mapa Studio','Completion examples use actual translatedproductname, supplementary clarification retained')
refs=[]
def walk(v,at):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=Path(v['path']);p=p if p.is_absolute() else F/p;ok=p.is_file() and sha(p)==v['sha256'];refs.append({'at':at,**v,'passed':ok});ck(ok,at+':actual referencedfile SHA')
  for k,x in v.items():walk(x,at+'.'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):walk(x,at+'['+str(i)+']')
walk(prov,'provenance');walk(carry,'carry');walk(r['language_brief'],'brief');walk(r['provenance'],'currentreview')
for b in r['batches']:walk(b['provenance'],'batch:'+b['id'])
ck(all(g['passed'] is False for g in r['gates'].values()),'All9newenvelope gates deliberatelyinvalidated');ck(sorted(P.audit_locale(F,m,r,'fil'))==sorted(g+' is pending or lacks evidence' for g in P.GATES),'Toolaudit only9expected pending gate issues')
rows=len(ns)+sum(len(v) if isinstance(v,dict) else 1 for v in nt['online'].values());ck(rows==6385 and rows*6==38310,'Final6385rows/38310matrixsamples inventory');ck(m['revision']=='6e288c852e861648a270fc54e2d435f0d2b33b64','Source envelope final6e revision');ck(subprocess.run(['git','merge-base','--is-ancestor','1bb5155e96b61144583466a00041fb1d04fc9def','HEAD']).returncode==0,'Actualintegratedmaster1bb ancestor')
result={'identity':'/root/adversarial_reviewer','status':'pass; aggregate linguistic provenance/schema only, all9gates intentionallypending' if not issues else 'issues found','issues':issues,'checks':checks,'source_sha256':source,'catalog_sha256':catalog,'total_ids':6358,'unchanged_previous_ids':6247,'new_direct_review_ids':111,'batches':47,'english_exception_count':268,'old_english_exception_count':265,'new_english_exception_count':3,'role_evidence_count':35,'new_direct_reviews':direct,'actual_editorial_changed_ids':sorted('online:'+k for k in changed),'evidence_reference_checks':refs,'expected_pending_gates':list(P.GATES),'expected_matrix_rows':rows,'expected_matrix_samples':rows*6,'snapshot_sha256':{str(p.relative_to(F)):sha(p) for p in [F/'manifest.json',F/'reviews/fil.json',F/'reviews/fil-provenance.json',d/'source-target-carry.json',d/'adversarial-fragment-composition.json']},'actual_checkout_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'precheck_correction':{'path':'master-delta4/independent-aggregate-audit-precheck.json','sha256':sha(d/'independent-aggregate-audit-precheck.json'),'explanation':'Initial audit incorrectly required firstmeaning approval for two actual minor findings. Corrected audit preserves those historical open records and verifies their exact author/final values and finalmeaning resolutions. Not a product/translation failure.'},'scope':'Exactsnapshot/per-ID/source/target/stage/identity/hash audit. All6247previousvalues carry unchanged and111newentries have actual5stage directrecords from4identities; author+firstmeaning5351,final235b,5editorial changes. No fresh6358entry complete linguisticread or runtime approval claimed.','limits':['All9gates remainpending for actualnewfinalcode/build/rendering/packageevidence.','Originalroot/kit1/kit2/kit3 and their receipts remainhistorical, notrelabeled final6e.','No officialgate, translation, trackedsource, APIcall or build action performed.']}
P.write_json(d/'independent-aggregate-audit.json',result);print(json.dumps({'status':result['status'],'checks':len(checks),'refs':len(refs),'issues':issues}))
