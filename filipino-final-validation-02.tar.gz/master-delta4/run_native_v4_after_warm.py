from pathlib import Path
import subprocess,time,json
R=Path.cwd();K=R/'artifacts/filipino-localization';H='43444d65bf8b4b6405bdc528de836f5174abb378';deadline=time.monotonic()+5400
while True:
 p=K/'integration-a88-native-build.json'
 try:
  if p.exists():
   result=json.loads(p.read_text());print('Intermediate native compilation ended',result['exit_code'],flush=True);break
 except json.JSONDecodeError:pass
 assert time.monotonic()<deadline,'Intermediate own native build wait exceeded90minutes'
 time.sleep(2)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==H and not subprocess.check_output(['git','status','--porcelain'],text=True)
raise SystemExit(subprocess.call(['python3',str(K/'master-delta4/validate_native_v4.py'),H]))
