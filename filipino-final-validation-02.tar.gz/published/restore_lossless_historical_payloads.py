"""Verify (default) or restore exact gzip-preserved historical evidence bytes."""
from pathlib import Path,PurePosixPath
import argparse,gzip,hashlib,json
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('manifest',type=Path);ap.add_argument('--restore',action='store_true');a=ap.parse_args();K=Path(__file__).resolve().parents[1];v=json.loads(a.manifest.read_text());count=0
for e in v.get('compressed_historical_payloads',[]):
 rel=PurePosixPath(e['original_kit_relative_path']);src=PurePosixPath(e['compressed']['path']);assert not rel.is_absolute() and '..' not in rel.parts and not src.is_absolute() and '..' not in src.parts
 p=K/str(src);assert hashlib.sha256(p.read_bytes()).hexdigest()==e['compressed']['sha256'];raw=gzip.decompress(p.read_bytes());assert len(raw)==e['uncompressed_bytes'] and hashlib.sha256(raw).hexdigest()==e['original_sha256']
 if a.restore:
  out=K/str(rel);assert out.resolve().is_relative_to(K)
  if out.exists():assert out.read_bytes()==raw,'Refuse to replace changed historical evidence'
  else:out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 count+=1
print(json.dumps({'verified_exact_historical_payloads':count,'restored':a.restore}))
