#!/usr/bin/env python3
"""Plan-driven bounded evidence publisher. Default validates only; --publish is explicit."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[3];KIT=ROOT/'artifacts/filipino-localization';PUB=KIT/'published'
def git(*args,**kwargs):return subprocess.check_output(['git',*args],cwd=ROOT,**kwargs).decode().strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('plan',type=Path);ap.add_argument('--publish',action='store_true');args=ap.parse_args();plan=json.loads(args.plan.read_text());branch=plan['branch'];assert branch=='codex/filipino-localization-evidence','Evidence branch only'
 base=plan['base_commit'];assert len(base)==40 and all(c in '0123456789abcdef' for c in base)
 entries=plan['files'];assert 1<=len(entries)<=512;seen=set();total=0
 for e in entries:
  dst=PurePosixPath(e['destination']);assert not dst.is_absolute() and all(p not in {'..','.git'} for p in dst.parts) and str(dst) not in seen;seen.add(str(dst))
  rel=PurePosixPath(e['kit_path']);assert not rel.is_absolute() and '..' not in rel.parts
  p=KIT/str(rel);assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(KIT.resolve());assert 'profile' not in rel.parts
  assert p.name.endswith(('.tar.gz','.json','.md','.png','.xml','.log','.log.gz','.txt','.diff')),'Reject unreviewed executable/asset format'
  size=p.stat().st_size;assert size<=60*1024**2,'Per-file60MiB bound';total+=size;assert sha(p)==e['sha256'],'Pinned input changed: '+str(rel)
 assert total<=256*1024**2,'Campaign256MiB bound'
 result={'mode':'publish' if args.publish else 'validate-only','branch':branch,'parent':base,'files':len(entries),'bytes':total,'plan_sha256':sha(args.plan)}
 if not args.publish:print(json.dumps(result));return
 # No branch checkout, source index edit, or source-tree mutation. Remote advance rejects publication.
 remote=git('ls-remote','--heads','origin','refs/heads/'+branch).split()[0];assert remote==base,'Evidence branch advanced; refresh reviewed plan'
 subprocess.run(['git','fetch','--no-tags','origin','refs/heads/'+branch],cwd=ROOT,check=True)
 assert git('rev-parse','FETCH_HEAD')==base,'Evidence fetch differs from reviewed parent'
 fd,index=tempfile.mkstemp(prefix='final-evidence-',suffix='.gitindex',dir=PUB);os.close(fd);os.unlink(index);env=dict(os.environ,GIT_INDEX_FILE=index)
 try:
  subprocess.run(['git','read-tree',base],cwd=ROOT,env=env,check=True)
  for e in entries:
   p=KIT/e['kit_path'];assert sha(p)==e['sha256'],'Pinned input changed during publish'
   blob=git('hash-object','-w',str(p));subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+e['destination']],cwd=ROOT,env=env,check=True)
  tree=git('write-tree',env=env);commit=git('commit-tree',tree,'-p',base,input=b'Attach final Filipino localization validation evidence\n')
  subprocess.run(['git','push','origin',commit+':refs/heads/'+branch],cwd=ROOT,check=True)
  result['commit']=commit;result['published_file_hashes']={e['destination']:e['sha256'] for e in entries};(PUB/'final-evidence-publish.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
 finally:
  try:os.unlink(index)
  except FileNotFoundError:pass
if __name__=='__main__':main()
