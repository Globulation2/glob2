#!/usr/bin/env python3
"""Prepare a bounded evidence plan; never build/publish archives or mutate reviews.

Default writes an UNFROZEN candidate; --freeze requires an exact clean revision and
nine passed gates. JS inclusion requires an explicit previously reviewed SHA.
"""
from pathlib import Path
import argparse
import base64
import gzip
import hashlib
import json
import re
import subprocess

K = Path(__file__).resolve().parents[1]
P = K / 'published'
FORBIDDEN = {'.git', 'profiles', 'profile', 'node_modules', 'trace', 'traces',
             'runtime-assets', 'assets', 'bin', 'lib', 'include', 'db', 'database',
             '__pycache__', 'cache', 'caches', 'build'}
SUFFIX = ('.json', '.jsonl', '.md', '.log', '.log.gz', '.txt', '.txt.gz',
          '.json.gz', '.jsonl.gz', '.xml', '.png', '.diff', '.py', '.sh', '.cpp', '.h', '.ts', '.tsx')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--kit', default='final-kit6', help='Authoritative kit directory, e.g. final-kit4')
    ap.add_argument('--revision', required=True, help='Exact 40-hex final source revision')
    ap.add_argument('--tag', required=True, help='Evidence directory/filename tag')
    ap.add_argument('--browser-dir', help='Kit-relative actual browser evidence directory (including unique attempt folder); defaults to browser-final-TAG')
    ap.add_argument('--native-dir', help='Exact kit-relative native producer directory; includes ui-artifacts and text receipts, excludes build outputs')
    ap.add_argument('--web-dir', default='final-web-v4', help='Exact independently reviewed website evidence directory')
    ap.add_argument('--data-dir', help='Exact current data/check report directory, independent of historical matrix/screens tag')
    ap.add_argument('--mobile-dir', help='Exact current mobile asset-export directory, independent of matrix/screens tag')
    ap.add_argument('--extra-tree', action='append', default=[], help='Additional explicitly named kit-relative evidence tree; existing safe suffix/bounds/privacy rules apply')
    ap.add_argument('--reconciliations', type=Path, help='Explicit historical mismatch resolutions, required for every discrepancy before freeze')
    ap.add_argument('--matrix-tag', help='Actual matrix producer tag; defaults to --tag. Use 6980 only with explicit unchanged-input carry proof.')
    ap.add_argument('--freeze', action='store_true')
    ap.add_argument('--plan-label', help='Unique output label, separate from actual producer tag; preserves earlier partial candidates')
    ap.add_argument('--reviewed-script', action='append', default=[], metavar='PATH=SHA256',
                    help='Explicit hash-pinned JS/MJS allowlist after actual source review')
    args = ap.parse_args()
    assert re.fullmatch(r'final-kit(?:[1-9][0-9]*)?', args.kit), 'Unsafe kit name'
    F = K / args.kit
    manifest = json.loads((F / 'manifest.json').read_text())
    inventory = {'native_keys': manifest['native_keys'], 'online_keys': manifest['online_keys'],
                 'total_keys': manifest['native_keys'] + manifest['online_keys']}
    delta_name = 'master-delta' + (args.kit.removeprefix('final-kit') or '')
    assert re.fullmatch(r'[0-9a-f]{40}', args.revision), 'Full source revision required'
    assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', args.tag), 'Unsafe tag'
    plan_label = args.plan_label or args.tag
    assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', plan_label), 'Unsafe output label'
    matrix_tag = args.matrix_tag or args.tag
    assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', matrix_tag), 'Unsafe matrix tag'
    reviewed_scripts = {}
    for spec in args.reviewed_script:
        name, digest = spec.rsplit('=', 1)
        assert re.fullmatch(r'[0-9a-f]{64}', digest)
        q = (K / name).resolve()
        assert q.is_relative_to(K) and q.suffix in {'.js', '.mjs'} and q.stat().st_size <= 128 * 1024
        assert sha(q) == digest, 'Reviewed script changed: ' + name
        reviewed_scripts[str(q.relative_to(K))] = digest

    review = json.loads((F / 'reviews/fil.json').read_text())
    assert len(review['gates']) == 9
    pending = [name for name, gate in review['gates'].items() if gate.get('passed') is not True]
    observed_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    observed_status = subprocess.check_output(['git', 'status', '--porcelain'], text=True)
    if args.freeze:
        assert observed_head == args.revision and not observed_status, 'Exact clean final source required'
        assert not pending, 'Pending actual runtime gates: ' + ', '.join(pending)

    external_index_path = P / 'existing-archive-hash-index.json'
    external_index = json.loads(external_index_path.read_text())
    externally_archived = {}
    for archive in external_index['archives']:
        archive_path = K / archive['archive']
        assert archive_path.is_file() and sha(archive_path) == archive['sha256'], 'External evidence archive changed'
        for e in archive['entries']:
            externally_archived.setdefault((e['kit_relative_path'], e['sha256']), []).append({'archive': archive['archive'], 'archive_sha256': archive['sha256'], 'archive_path': e['archive_path']})
    external_payload_references = []
    files, pinned, excluded, queue = set(), {}, [], []
    reference_discrepancies = []
    excluded_hash_references = []
    traversed_external = set()

    def allowed(p):
        return (p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(K)
                and not set(p.relative_to(K).parts) & FORBIDDEN
                and not any(x.endswith('-assets') for x in p.relative_to(K).parts)
                and p.name != 'ROOT-STATE.json' and p.stat().st_size <= 60 * 1024**2
                and (p.name.endswith(SUFFIX) or str(p.relative_to(K)) in reviewed_scripts))

    compacted_reports = {}
    compressed_historical_payloads = []
    def compact_playwright(p):
        if 'playwright-results' not in p.name or p.suffix != '.json' or p.stat().st_size < 1024 * 1024:
            return None
        original_sha = sha(p)
        if original_sha in compacted_reports: return compacted_reports[original_sha]
        data = json.loads(p.read_text()); images = []
        def walk_images(value):
            if isinstance(value, dict):
                body = value.get('body')
                if value.get('contentType') == 'image/png' and isinstance(body, str):
                    try: raw = base64.b64decode(body, validate=True)
                    except ValueError: raw = b''
                    if raw.startswith(b'\x89PNG\r\n\x1a\n'):
                        digest = hashlib.sha256(raw).hexdigest()
                        image_path = P / 'compacted-playwright-images' / (digest + '.png')
                        image_path.parent.mkdir(exist_ok=True)
                        if image_path.exists(): assert image_path.read_bytes() == raw
                        else: image_path.write_bytes(raw)
                        value['body'] = '[binary PNG body omitted; exact pixels in archive attachment reference]'
                        value['exact_png_attachment'] = {'path': str(image_path.relative_to(K)), 'sha256': digest, 'bytes': len(raw)}
                        images.append({'path': str(image_path.relative_to(K)), 'sha256': digest})
                for item in value.values(): walk_images(item)
            elif isinstance(value, list):
                for item in value: walk_images(item)
        walk_images(data)
        if not images: return None
        out = P / 'compacted-playwright-results' / (original_sha + '.json')
        out.parent.mkdir(exist_ok=True)
        report = {'scope': 'Lossless test diagnostics except relocated binary PNG attachment bodies. All test outcomes/errors/stdout/stderr remain; every omitted PNG body decoded and preserved exactly as a standalone archive member. Original report hash retained; no failed result suppressed.', 'original_source_name': str(p.relative_to(K)), 'original_source_sha256': original_sha, 'actual_results': data, 'relocated_pngs': images}
        encoded = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
        if out.exists(): assert out.read_text() == encoded
        else: out.write_text(encoded)
        compacted_reports[original_sha] = out
        return out

    def add(p, expected=None):
        p = p.resolve()
        if not allowed(p):
            excluded.append(str(p))
            if expected:
                excluded_hash_references.append({'path': str(p), 'sha256': expected, 'reason': 'Excluded asset/binary/profile/matrix-page or unreviewed script; hash identity retained, bytes not packaged'})
            return
        if expected:
            assert sha(p) == expected, 'Referenced evidence changed: ' + str(p)
            pinned[str(p.relative_to(K))] = expected
        compacted = compact_playwright(p)
        if compacted is not None:
            excluded_hash_references.append({'path': str(p.relative_to(K)), 'sha256': sha(p), 'reason': 'Binary PNG bodies relocated exactly to standalone image files to avoid duplicate base64 encoding; all test statuses/errors/diagnostics retained in compacted report', 'compacted': {'path': str(compacted.relative_to(K)), 'sha256': sha(compacted)}})
            add(compacted, sha(compacted))
            return
        rel = str(p.relative_to(K))
        actual_sha = sha(p)
        external = externally_archived.get((rel, actual_sha))
        if external:
            external_payload_references.append({'path': rel, 'sha256': actual_sha, 'available_in': external, 'reason': 'Exact payload already in published historical archive; no current bytes substituted'})
            # JSON still traversed once so historical references remain accountable.
            if p.suffix == '.json' and p.name != 'font-matrix.json' and p not in traversed_external:
                traversed_external.add(p)
                queue.append(p)
            return
        historical_matrix = p.name == 'font-matrix.json' and ('full-matrix' in str(p)) and f'native-final-{args.matrix_tag or args.tag}-full-matrix' not in str(p)
        historical_large_log = p.suffix == '.log' and p.stat().st_size > 8 * 1024**2
        if historical_matrix or historical_large_log:
            raw = p.read_bytes()
            destination = P / 'compressed-historical-payloads' / (actual_sha + p.suffix + '.gz')
            destination.parent.mkdir(exist_ok=True)
            if destination.exists(): assert gzip.decompress(destination.read_bytes()) == raw
            else: destination.write_bytes(gzip.compress(raw, compresslevel=6, mtime=0))
            record = {'original_kit_relative_path': rel, 'original_sha256': actual_sha, 'uncompressed_bytes': len(raw), 'compressed': {'path': str(destination.relative_to(K)), 'sha256': sha(destination)}, 'reason': 'Historical exact payload preserved losslessly as gzip; decompress to original path to reproduce every original measurement/log byte. Current final matrix remains uncompressed JSON.'}
            compressed_historical_payloads.append(record)
            excluded_hash_references.append(record)
            add(destination, sha(destination))
            return
        if p not in files:
            files.add(p)
            if p.suffix == '.json' and p.name != 'font-matrix.json':
                queue.append(p)

    def tree(name):
        root = K / name
        assert root.is_dir(), 'Missing final evidence directory: ' + str(root)
        for p in root.rglob('*'):
            if p.is_file() and allowed(p):
                add(p)

    aggregate = f'{delta_name}/independent-aggregate-audit.json'
    add(external_index_path, sha(external_index_path))
    remote_binding = P / 'external-archives-remote-binding.json'
    assert remote_binding.is_file(), 'Published archive remote binding required'
    add(remote_binding, sha(remote_binding))
    for name in ['v8-actual-helper-code-review.json', 'privacy-base64-png-false-positive-resolution.json', 'final-v8-readiness-audit.json', 'audit_final_v8_readiness.py', 'restore_lossless_historical_payloads.py']:
        add(P / name, sha(P / name))
    add(P / 'native-evidence-manifest.json', sha(P / 'native-evidence-manifest.json'))
    add(P / 'native-omitted-matrix-pngs.json', sha(P / 'native-omitted-matrix-pngs.json'))
    for name in ['manifest.json', 'reviews/fil.json', 'reviews/fil-pre-runtime-gates.json', 'reviews/fil-provenance.json', aggregate]:
        q = F / name
        add(q, sha(q))
    pending_gate_reference_mismatches = []
    for gate_name, gate in review['gates'].items():
        for e in gate.get('evidence', []):
            q = (F / e['path']).resolve()
            if not q.is_file() or sha(q) != e['sha256']:
                assert gate.get('passed') is not True and not args.freeze, 'Passed gate reference mismatch: ' + e['path']
                pending_gate_reference_mismatches.append({'gate': gate_name, 'path': e['path'], 'historical_expected_sha256': e['sha256'], 'actual_current_sha256': sha(q) if q.is_file() else None, 'scope': 'Pending gate invalidated historical evidence; not substituted or approved'})
                continue
            add(q, e['sha256'])

    tag = args.tag
    browser_dir = args.browser_dir or f'browser-final-{tag}'
    browser_path = (K / browser_dir).resolve()
    assert not Path(browser_dir).is_absolute() and '..' not in Path(browser_dir).parts and browser_path.is_relative_to(K), 'Unsafe browser directory'
    native_dir = args.native_dir or f'native-{tag}-focused'
    data_dir = args.data_dir or f'data-{tag}'
    mobile_dir = args.mobile_dir or f'mobile-{tag}'
    for directory in [native_dir, args.web_dir, browser_dir, data_dir, mobile_dir] + args.extra_tree:
        q = Path(directory)
        assert not q.is_absolute() and '..' not in q.parts and (K / q).resolve().is_relative_to(K), 'Unsafe evidence directory'
    for d in [args.web_dir, browser_dir, native_dir, f'rendering/native-final-{tag}-screens', data_dir, mobile_dir] + args.extra_tree:
        tree(d)
    # Retain exact old focused producer evidence only through its explicit current carry receipts.
    for optional in [f'native-{tag}-render-units']:
        if (K / optional).is_dir(): tree(optional)
    for pat in [f'native-{tag}*', f'browser-{tag}*', f'data-{tag}*', f'final-{tag}*', f'mobile-{tag}*',
                f'{tag}-*', f'web-roundtrip-{tag}*', f'roundtrip_{tag}.py',
                'native-243*', 'browser-243*', 'data-243*', 'final-243*',
                'mobile-243*', 'mobile-*-243-export.log', 'mobile-*-243-assets.json',
                'web-roundtrip-243*', 'roundtrip_243.py', 'data-f0f*', 'final-f0f*',
                'web-roundtrip-f0f*', 'roundtrip_f0f.py', 'f0f-*',
                'mobile-*-f0f-assets.json', '*434*', 'browser-hud-verified*', 'native-fixture-final*', 'native-fixture-x11-final*',
                'native-hud-fixture-diagnostic*', 'final-pending-fix-*']:
        for q in K.glob(pat):
            if q.is_file() and allowed(q):
                add(q)
    matrix = K / f'rendering/native-final-{matrix_tag}-full-matrix'
    for name in ['font-matrix.json', 'current-matrix-proof.json', 'process.log']:
        q = matrix / name
        assert q.is_file(), q
        add(q)
    binding = matrix / 'catalog-source-binding.json'
    if binding.is_file(): add(binding, sha(binding))
    else:
        assert args.kit == 'final-kit6', 'Missing explicit matrix source/catalog binding'
        closure = K / 'master-delta6/native-v8-final-closure.json'
        value = json.loads(closure.read_text())
        assert value['final_data_revision'] == args.revision
        assert value['matrix']['samples'] == 57753 and value['matrix']['missing_glyphs'] == value['matrix']['drawn_fit_failures'] == 0
        assert value['matrix']['manifest_sha256'] == sha(matrix / 'font-matrix.json') and value['matrix']['proof_sha256'] == sha(matrix / 'current-matrix-proof.json')
        add(closure, sha(closure))
    # Bounded current matrix pixel examples, one per authored-size/raster-scale combination; measurements contain all page hashes.
    for size in [10, 13, 20]:
        for scale in ([1, 1.5, 2] if args.kit == 'final-kit6' else [1, 2]):
            q = matrix / f'font-{size}-scale-{scale}-page-001.png'
            assert q.is_file(), q
            add(q, sha(q))
    # Preserve negative startup/editor evidence and its narrow actual 6980 closure.
    # JSON traversal adds referenced pixels, never every historical matrix page.
    for pat in [f'*{tag}*.json', '*434*.json', '*font*.json', '*f0f*.json', '*6980*legacy*.json', '*6980*producer-binding*.json']:
        for q in (K / 'visual').glob(pat):
            add(q)
    # Matrix pixel review stays tied to the actual producer, even when current UI differs.
    matrix_review = K / 'visual' / f'native-final-matrix-review-{matrix_tag}.json'
    if matrix_review.is_file():
        add(matrix_review, sha(matrix_review))
    if matrix_tag != tag:
        carry_reviews = list((K / 'visual').glob(f'*{tag}*matrix*carry*.json'))
        assert carry_reviews, 'Distinct matrix producer requires an explicit current-tag matrix carry review'
        for q in carry_reviews:
            add(q, sha(q))
    for name in ['browser-final-f0f/threaded-startup-finding.json',
                 'browser-final-6980/gameplay-phone150-nav-finding.json',
                 'published/prepare_final_evidence_plan.py',
                 'published/final-evidence-planner-preparation-review.json']:
        q = K / name
        assert q.is_file(), q
        add(q)
    # Browser orchestration preflights and historical hold/finding resolutions live
    # beside unique attempts. Preserve compact root receipts without importing all attempts.
    for q in (K / 'browser-v4').glob('*.json'):
        if q.name != 'server.json': add(q)
    for q in (K / 'browser-v4').glob('*.py'):
        add(q)
    for name, digest in reviewed_scripts.items():
        add(K / name, digest)

    def resolve_ref(value, origin, expected):
        q = Path(value)
        candidates = [q] if q.is_absolute() else [origin.parent / q, F / q, K / q]
        if value.startswith('artifacts/filipino-localization/'):
            candidates.insert(0, K / value.removeprefix('artifacts/filipino-localization/'))
        candidates += [matrix / q, K / 'visual' / q, K.parents[1] / q]
        existing = list(dict.fromkeys(p.resolve() for p in candidates if p.is_file()))
        if expected:
            matching = [p for p in existing if sha(p) == expected]
            identity_only = q.suffix.lower() in {'.ttf', '.otf', '.woff', '.woff2', '.wasm', '.data', '.a', '.so', '.dll', '.exe', '.ogg', '.wav', '.bmp'} or bool(set(q.parts) & FORBIDDEN)
            if not matching and identity_only:
                excluded_hash_references.append({'origin': str(origin.relative_to(K)), 'path': value, 'sha256': expected, 'reason': 'Runtime asset/binary/profile bytes deliberately outside evidence archive; original hash identity retained'})
            elif not matching:
                # Historical receipts can deliberately pin superseded source/aggregate
                # bytes. Never silently substitute current bytes for those hashes.
                reference_discrepancies.append({'origin': str(origin.relative_to(K)),
                                                'reference': value, 'expected_sha256': expected,
                                                'action': 'not substituted; root must reconcile historical reference',
                                                'found_different_bytes': bool(existing)})
            return matching[0] if matching else None
        return existing[0] if existing else None

    def refs(value, origin):
        if isinstance(value, dict):
            for name, item in value.items():
                if name in {'path', 'png', 'file', 'image', 'original_bmp', 'viewed_lossless_png', 'log', 'manifest'} and isinstance(item, str):
                    expected = value.get('sha256') if name == 'path' else value.get(name + '_sha256')
                    if not isinstance(expected, str) or not re.fullmatch(r'[0-9a-f]{64}', expected):
                        expected = None
                    q = resolve_ref(item, origin, expected)
                    if q is not None:
                        if q.suffix == '.png' and ('full-matrix' in str(q) or q.name.startswith('font-')) and q not in files:
                            excluded_hash_references.append({'origin': str(origin.relative_to(K)), 'path': str(q.relative_to(K)), 'sha256': expected or sha(q), 'reason': 'Complete matrix page inventory retained; bounded combination samples plus actual visual-review references included'})
                        else:
                            add(q, expected)
                refs(item, origin)
        elif isinstance(value, list):
            for item in value:
                refs(item, origin)

    if args.reconciliations:
        add(args.reconciliations.resolve(), sha(args.reconciliations.resolve()))
        for item in json.loads(args.reconciliations.read_text()):
            add(K / item['resolution_evidence_path'], item['resolution_evidence_sha256'])
    while queue:
        q = queue.pop()
        refs(json.loads(q.read_text()), q)
    entries = [{'path': str(q.relative_to(K)), 'sha256': sha(q)} for q in sorted(files)]
    payload_bytes = sum(q.stat().st_size for q in files)
    if len(entries) > 5000 or payload_bytes > 512 * 1024**2:
        diagnostics = {'status': 'selection bounds exceeded; no plan/archive produced', 'file_count': len(entries), 'payload_bytes': payload_bytes, 'entries': [{'path': str(q.relative_to(K)), 'bytes': q.stat().st_size} for q in sorted(files)], 'reference_discrepancies': reference_discrepancies}
        out = P / f'final-{plan_label}-selection-bounds.json'
        assert not out.exists(), 'Preserve prior bounds diagnostic'
        out.write_text(json.dumps(diagnostics, indent=2) + '\n')
        raise AssertionError('Selection bounds exceeded; see ' + str(out))
    matrix_proof = json.loads((matrix / 'current-matrix-proof.json').read_text())
    inventory['matrix_samples'] = matrix_proof['samples']
    matrix_combinations = 9 if args.kit == 'final-kit6' else 6
    assert inventory['matrix_samples'] % matrix_combinations == 0
    inventory['matrix_rows'] = inventory['matrix_samples'] // matrix_combinations
    inventory['matrix_combinations'] = matrix_combinations
    online = json.loads((F / 'drafts/fil/online.json').read_text())
    expected_rows = inventory['native_keys'] + sum(len(v) if isinstance(v, dict) else 1 for v in online.values())
    assert inventory['matrix_rows'] == expected_rows and inventory['matrix_samples'] == expected_rows * matrix_combinations, inventory
    if args.kit == 'final-kit6':
        assert inventory == {'native_keys': 3412, 'online_keys': 2978, 'total_keys': 6390, 'matrix_samples': 57753, 'matrix_rows': 6417, 'matrix_combinations': 9}, inventory
        assert matrix_tag == tag, 'Kit6 adds31online keys and requires a fresh full current-tag matrix'
    if args.kit == 'final-kit5':
        assert inventory == {'native_keys': 3412, 'online_keys': 2947, 'total_keys': 6359, 'matrix_samples': 38316, 'matrix_rows': 6386, 'matrix_combinations': 6}, inventory
        assert matrix_tag == tag, 'Kit5 adds a new label and requires a fresh full current-tag matrix'
    reconciliations = json.loads(args.reconciliations.read_text()) if args.reconciliations else []
    for item in reconciliations:
        assert all(item.get(x) for x in ['origin', 'reference', 'expected_sha256', 'reason', 'resolution_evidence_path', 'resolution_evidence_sha256'])
        q = (K / item['resolution_evidence_path']).resolve()
        assert q.is_relative_to(K) and q.is_file() and sha(q) == item['resolution_evidence_sha256']
        # Reconciliation bytes must already be present in the explicit closure to avoid a second unbounded walk.
        assert q in files, 'Resolution receipt missing from selected transitive closure: ' + str(q)
    unresolved = [e for e in reference_discrepancies if not any(all(e[k] == x[k] for k in ['origin', 'reference', 'expected_sha256']) for x in reconciliations)]
    if args.freeze:
        assert not unresolved, 'Unreconciled historical hash references; inspect candidate discrepancy list'
    plan = {'final_receipts_frozen': args.freeze, 'authoritative_kit': args.kit, 'inventory': inventory, 'revision': args.revision, 'tag': tag, 'matrix_actual_producer_tag': matrix_tag,
            'actual_browser_evidence_directory': browser_dir, 'actual_native_evidence_directory': native_dir, 'actual_website_evidence_directory': args.web_dir, 'actual_data_evidence_directory': data_dir, 'actual_mobile_evidence_directory': mobile_dir, 'explicit_extra_trees': args.extra_tree,
            'observed_head': observed_head, 'observed_dirty': bool(observed_status),
            'pending_gates': pending, 'pending_gate_reference_mismatches': pending_gate_reference_mismatches,
            'reviewed_scripts': [{'path': n, 'sha256': d} for n, d in sorted(reviewed_scripts.items())],
            'extra_files': entries,
            'frozen_receipts': [{'path': n, 'sha256': d} for n, d in sorted(pinned.items())],
            'excluded_reference_paths': sorted(set(excluded)),
            'reference_discrepancies_for_explicit_root_review': reference_discrepancies,
            'historical_reference_reconciliations': reconciliations, 'unresolved_reference_discrepancies': unresolved, 'excluded_hash_references': excluded_hash_references,
            'compressed_historical_payloads': compressed_historical_payloads,
            'external_archive_index': {'path': str(external_index_path.relative_to(K)), 'sha256': sha(external_index_path)}, 'externally_archived_exact_payloads': external_payload_references,
            'scope': f'Authoritative {args.kit} {inventory["total_keys"]}-key source/target envelope and four-role carry histories; actual {tag} native/browser runtime and current tag visual receipts; matrix actual producer {matrix_tag} with explicit carry when different; website actual producer and exact current-input carry; historical negative f0f evidence and actual 6980 editor closure retained by producer.',
            'limits': ['Agent-reviewed, no human language certification.',
                       'Linux/Chromium only; physical Android/iOS and native Windows/macOS not claimed.',
                       'Original and new delta four-role histories are included by curator BASE_TREES; this plan closes current runtime/gate references without inventing new linguistic reads.',
                       'Complete matrix measurements/page hashes retained; actual independently reviewed representative PNGs selected, not every generated matrix page.',
                       'Historical failures and prior producer revisions remain explicitly historical; old editor closure does not close separate gameplay findings.',
                       'Candidate selection is not publication approval. Root must review exact path closure, privacy scan, bounds and archive extraction hashes before publishing.']}
    out = P / f'final-{plan_label}-evidence-plan.json'
    assert not out.exists(), 'Refuse to overwrite an existing plan; preserve historical bytes'
    out.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'plan': str(out), 'frozen': args.freeze, 'extra_files': len(entries),
                      'pinned_receipts': len(pinned), 'pending_gates': pending, 'pending_gate_reference_mismatches': pending_gate_reference_mismatches,
                      'note': 'No archive built or published. Curator rejects unfrozen candidates.'}))


if __name__ == '__main__':
    main()
