from pathlib import Path
import argparse,subprocess,json,hashlib,os,time,concurrent.futures
R=Path.cwd();O=R/'artifacts/filipino-localization/data-v8';p=argparse.ArgumentParser();p.add_argument('--revision',required=True);A=p.parse_args();H=A.revision
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def guard():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==H
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
guard();assert not (O/'results.json').exists(),'Refuse overwrite'
E=dict(os.environ,PATH='/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH'],GLOB2_SDL3_PREFIX=str(R/'artifacts/filipino-localization/sdl-reused'),LD_LIBRARY_PATH=str(R/'artifacts/filipino-localization/sdl-reused/lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''))
C=[('strict',['python3','data/check_translations.py','--strict'],R),('translations',['python3','test/test_translations.py'],R),('font',['python3','test/test_font_coverage.py'],R),('translation-program',['python3','test/test_translation_program.py'],R),('google-runner',['python3','test/test_google_draft.py'],R),('mobile-contracts',['python3','test/test_mobile_asset_bundle.py'],R),('apple-localizations',['python3','test/build_system/test_apple_localizations.py'],R),('web-roundtrip-unmodified',['python3','test/build_system/test_web_assets.py','WebAssetPackageTests.test_packages_round_trip_and_are_content_addressed'],R)]
inputs=['data/texts.en.txt','data/texts.keys.txt','data/texts.fil.txt','platform/packages/i18n/locales/en.json','platform/packages/i18n/locales/fil.json','platform/packages/i18n/plural-sources.json','platform/packages/i18n/invariants.json','libgag/src/TrueTypeFont.cpp'];before={n:sha(R/n) for n in inputs};out={'revision':H,'commands':[],'concurrency':1,'input_sha256_before':before,'runner_sha256':sha(__file__)}
def run(x):
 n,a,cwd=x;guard();t=time.monotonic();log=O/(n+'.log')
 with log.open('x') as f:
  try:q=subprocess.run(a,cwd=cwd,env=E,stdout=f,stderr=subprocess.STDOUT,timeout=1200);code=q.returncode;error=None
  except subprocess.TimeoutExpired:code=None;error='timeout1200s'
 guard();print(n,code,flush=True);return {'name':n,'argv':a,'cwd':str(cwd),'exit_code':code,'error':error,'seconds':time.monotonic()-t,'log':str(log),'log_sha256':sha(log)}
with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
 for f in concurrent.futures.as_completed([pool.submit(run,x) for x in C]):out['commands'].append(f.result());(O/'results.json').write_text(json.dumps(out,indent=2)+'\n')
guard();out['input_sha256_after']={n:sha(R/n) for n in inputs};assert out['input_sha256_after']==before;out['all_passed']=all(x['exit_code']==0 for x in out['commands']);(O/'results.json').write_text(json.dumps(out,indent=2)+'\n');raise SystemExit(0 if out['all_passed'] else 1)
