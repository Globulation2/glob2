from pathlib import Path
import subprocess,os,json,time,hashlib,argparse,concurrent.futures
R=Path.cwd();O=R/'artifacts/filipino-localization/data-v8';p=argparse.ArgumentParser();p.add_argument('--revision',required=True);A=p.parse_args();H=A.revision
E=dict(os.environ,PATH='/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH'])
def guard():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==H
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
def run(pair):
 name,argv=pair;guard();t=time.monotonic();log=O/(name+'.log')
 with log.open('x') as f:q=subprocess.run(argv,cwd=R/'platform',env=E,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 guard();row={'name':name,'argv':argv,'exit_code':q.returncode,'seconds':time.monotonic()-t,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};print(name,q.returncode,flush=True);return row
checks=[('online-strict',['npm','run','i18n:check']),('i18n-units',['npm','test','--','packages/i18n/test']),('merged-typescript-style',['npx','--no-install','eslint','apps/web/e2e/i18n.spec.ts','apps/web/e2e/tamil.spec.ts','packages/i18n/src/index.ts','packages/i18n/src/locales.ts','packages/i18n/test/runtime.test.ts']),('merged-typescript-format',['npx','--no-install','prettier','--check','apps/web/e2e/i18n.spec.ts','apps/web/e2e/tamil.spec.ts','packages/i18n/src/index.ts','packages/i18n/src/locales.ts','packages/i18n/test/runtime.test.ts'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: rows=list(pool.map(run,checks))
r={'revision':H,'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'commands':rows,'all_passed':all(x['exit_code']==0 for x in rows),'scope':'Current merged locale runtime, generated browser bundle and both independent locale test additions. Previous complete platform typecheck retains its actual producer; this is focused current integration coverage.'}
(O/'platform-results.json').write_text(json.dumps(r,indent=2)+'\n');raise SystemExit(0 if r['all_passed'] else 1)
