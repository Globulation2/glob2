import json,sys
from pathlib import Path
r=Path('artifacts/filipino-localization'); edits=r/'editor'/('online-edits.json' if sys.argv[1].startswith('online-') else 'native-edits.json'); current=json.loads(edits.read_text()) if edits.exists() else {}; incoming=json.load(sys.stdin);current.update(incoming);edits.write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n')
p=r/'linguistic/language-editor-record.json';record=json.loads(p.read_text());batch=next(b for b in record['batches'] if b['id']==sys.argv[1]);batch['status']='read; editorial corrections queued; final hash pending';batch['preliminary_read_keys']=batch['expected_keys'];p.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
