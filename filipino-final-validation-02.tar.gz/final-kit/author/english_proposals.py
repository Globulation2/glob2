import json,re
from pathlib import Path
folder=Path('artifacts/filipino-localization');queue=json.loads((folder/'author/check-after-online.json').read_text())['same_as_english_review_queue']
needs={
'native:[Magic At. Air]':'Pinsala sa himpapawid', 'native:[Levee]':'Dike', 'native:[Sloughs]':'Mga latian',
'native:[Amphitheatre]':'Ampiteatro','native:[Moat]':'Kanal na pangdepensa','native:[Warp]':'Pagbaluktot',
'native:[Fingerprint]':'Bakas ng daliri','native:[Drumlin field]':'Lupaing may mga drumlin',
'native:[Bastioned enclosure]':'Bakod na may mga balwarte','native:[Isolation]':'Pagkakahiwalay',
'native:[hive resume]':'Ipagpatuloy','online:TOOLBOX':'MGA KAGAMITAN',
'online:{value0}% saturation, {value1}% brightness':'{value0}% saturation, {value1}% liwanag',
}
proper={'Castor','Cortex','Cabino','Econo','Maxima','Nicowar','Numbi','Warrush','Toubib','Globulation 2','Hive Mind','JavaScript','OpenGL','Discord','AI'}
loan={'Cherry':'Seresa is also possible; reviewer should choose the shared fruit term.', 'Prune':'The English value is Plum, the fresh fruit; retain that specific fruit identity rather than confusing it with dried prunes or tropical sirwelas.'}
proposals=[]
for item in queue:
 if item in needs:continue
 label=item.split(':',1)[1]
 words=re.sub(r'%\d+|\{[A-Za-z0-9_]+\}|\[|\]|/one$','',label).strip()
 if '/ais/' in label:reason=f'{label} is an application route and must remain byte-for-byte unchanged for navigation.'
 elif re.search(r'CC[ -]?(?:BY|0)',label):reason=f'{label} identifies a Creative Commons licence; changing its standard identifier would change the attribution contract.'
 elif 'text/html' in label or 'max-age=' in label:reason=f'{label} is a literal HTTP MIME/cache value rather than translatable prose.'
 elif re.fullmatch(r'[^A-Za-z]*',words):reason=f'{label} is a numeric, punctuation or interpolation-only display template; there is no English prose to translate.'
 elif any(term in label for term in ['AI','JavaScript','OpenGL','Discord','Hive Mind','Studio','Globulation']):reason=f'{label} retains the proper product, programming or AI name used to identify the same feature in links and game configuration.'
 elif re.search(r'\[(?:f\d+|alt %0|control %0|meta %0|shift %0|backspace|caps lock|numlock|tab)\]',label):reason=f'{label} names the actual keyboard key or modifier printed on common keyboards; translating the legend would make the shortcut harder to identify.'
 elif any(name in label for name in proper):reason=f'{label} is the authored name of an AI opponent or product and must preserve that identity.'
 elif label.strip('[]') in ['Cherry','Prune']:reason=loan[label.strip('[]')]
 else:reason=f'{label} uses an established software, gaming, music or scientific loanword/abbreviation in this specific label. Retention is proposed for independent Filipino idiom review; the surrounding translatable prose has been localized.'
 proposals.append({'id':item,'rationale':reason,'status':'author-proposed; requires independent reviewer/editor decision'})
(folder/'author/intentional-english-proposals.json').write_text(json.dumps({'proposals':proposals,'do_not_accept_without_translation':needs},ensure_ascii=False,indent=2)+'\n')
print(len(proposals),len(needs))
