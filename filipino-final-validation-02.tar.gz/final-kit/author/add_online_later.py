import json
from pathlib import Path
p=Path('artifacts/filipino-localization/author/online-overrides.json');n=json.loads(p.read_text());n.update({
'No owned building family.':'Walang pamilya ng gusaling pag-aari mo.',
'No set validator is available. Your draft is saved; try checks later.':'Walang available na validator ng set. Na-save na ang draft mo; subukan ang mga pagsusuri mamaya.',
'No such blob.':'Walang ganoong blob.',
'No such building family.':'Walang ganoong pamilya ng gusali.',
'No such release.':'Walang ganoong release.',
'Not run':'Hindi pa pinatakbo',
'Only the host can change the room.':'Ang host lamang ang maaaring magbago ng mga setting ng silid.',
'Opacity ':'Opacity ',
'Open music release':'Buksan ang release ng musika',
'Playable':'Maaaring laruin',
'Plays':'Mga paglalaro',
'Previous mean':'Nakaraang average',
'Published family name':'Na-publish na pangalan ng pamilya',
'Rate':'Singil',
'Refused':'Tinanggihan',
'Remove stage':'Alisin ang yugto',
'Report':'Iulat',
'Report reason':'Dahilan ng pag-uulat',
'Request cap':'Limitasyon ng kahilingan',
'Reroll seed':'Gumamit ng bagong random na seed',
'Ladders':'Mga ranggo',
'No worker leases are recorded.':'Walang naitalang lease para sa worker.',
'One-time purchases stay with your account. Preview and paint before buying.':'Mananatili sa account mo ang mga minsanang pagbili. Mag-preview at magpinta bago bumili.',
'Pad ends with silence to longest':'Dagdagan ng katahimikan sa dulo hanggang maging singhaba ng pinakamahaba',
'Quiet passage audibility':'Pagkarinig sa mahihinang bahagi ng musika'
});
key='Open Building families when creating a new game or a new map in the editor, install a compatible release, and enable it. Enabled families apply to future generated maps alongside stock buildings. Existing maps and saves keep their own buildings.'
n[key]='Buksan ang Mga pamilya ng gusali kapag gumagawa ng bagong laro o bagong mapa sa editor, mag-install ng katugmang release at paganahin ito. Isasama ang mga pinaganang pamilya sa karaniwang mga gusali sa mga susunod na mabubuong mapa. Pananatilihin ng mga kasalukuyang mapa at save ang sarili nilang mga gusali.'
p.write_text(json.dumps(n,ensure_ascii=False,indent=2)+'\n')
