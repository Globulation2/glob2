import json,pathlib,sys
root=pathlib.Path('artifacts/filipino-localization');a=json.loads((root/'editor/online-editor.json').read_text());n=json.loads((root/'source/online.json').read_text());man=json.loads((root/'manifest.json').read_text())
for b in man['batches']:
 if b['id'] not in sys.argv[1:]:continue
 print('BATCH',b['id'])
 for id in b['keys']:
  k=id.split(':',1)[1];print(k+' ⇒ '+json.dumps(a[k],ensure_ascii=False))
