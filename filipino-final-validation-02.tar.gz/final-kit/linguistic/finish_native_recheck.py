import json,pathlib,hashlib,importlib.util
r=pathlib.Path('artifacts/filipino-localization');s=importlib.util.spec_from_file_location('p','tools/localization/translation_program.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
man=json.loads((r/'manifest.json').read_text());first=json.loads((r/'linguistic/native-meaning-first-pass.json').read_text());src=json.loads((r/'source/native.json').read_text());a,e=m.CHECKER.read_table(r/'editor/native-editor.txt');old,e=m.CHECKER.read_table(r/'author/native-author.txt');bs=[b for b in man['batches'] if b['id'].startswith('native-')];h=m.batch_target_hashes(man,{'native':r/'editor/native-editor.txt','online':r/'author/online-author.json'})
reason={}
def group(keys,why):
 for k in keys.split('|'):reason['['+k+']']=why

group('AI|ai|conn ai|match ai|qm ai|qm ai badge|AIJavaScript|AICastor|AIMaxima|AICortex|AINicowar|AINumbi|AIEcono|AIWarrush|AICabino','Proper AI name or established AI/JavaScript identifier; preserve recognizable identity across both interfaces.')
group('alt %0|backspace|caps lock|control %0|meta %0|numlock|shift %0|tab','Physical keyboard name or binding template; matches keycap/shortcut notation rather than prose.')
for i in range(1,16):reason[f'[f{i}]']='Function key name f'+str(i)+'; preserve physical key identification.'
group('OpenGL|settings Hive Mind|Globulation 2 Discord','Named product/API/community identity; changing the name would obstruct recognition.')
group('Everglades|Oceania','Geographical proper name used for a landscape/continent, preserved as its recognizable name.')
group('Carousel|Polder|Caravanserai|Savannah|Bajada|Playa|Mesas|Kopjes|Silica|Metal|lava|terrain group lava|loam','Specific landscape/material term retained as a recognizable technical loan; its context supplies the terrain/resource meaning.')
group('Cyan|Magenta|Teal','Specific color name retained to distinguish selectable hues without ambiguous invented equivalents.')
group('online mar|online may','Filipino abbreviated month form matches English spelling (Marso/Mayo); deliberate abbreviation, not English fallback.')
group('hp|Stats low HP ranges|zoom factor %0|%0 / %1 HP · %2|CPU load %0|%0 · %1|%0 %1|profile draw letter|maps 256|maps %0 kb|stat per minute short|stat page %0 of %1','Numeric/unit/punctuation template with no translatable prose; preserve placeholders, units and mathematical structure.')
group('Prune','Plum is the recognized fruit loan/name here, not the English verb prune; retained resource identity.')
group('swimmingpool','Swimming pool is an established comprehensible Filipino loan phrase; same building label is used in instruction references.')
group('editor|Layout|settings Default|settings Display|settings Key|settings Radius|settings Renderer|settings Software|Random|Elite|Emoji|Regular|Normal|Minimap|menu|Menu|Brush %0|Script|= Normal|Preview|settings Simple|conn ping|conn relay %0|hub account menu|hub leaderboard|hub online at %0|hub online|hub sim %0|results ladder rating %0|room address|room ai %0|room host %0|room host|room seed|settings Online|settings Server|qm online|profile title|hub leaderboard %0|Blitz|Sandbox|music Preview|music Tag|editor menu file|dock minimap|dock brush|set library set|set library release %0|settings MCP server|settings Port|settings Error: %0|library Seed|library Release %0|library Seed: %0','Recognizable software/game-interface loan, standard abbreviation or technical label; retained deliberately in contemporary Filipino register.')
reason['[FFA]']='Established free-for-all match abbreviation; preserves recognizable multiplayer format label.'
accepted=[]
for k,v in a.items():
 if v and v==src.get(k):
  assert k in reason,k
  accepted.append({'key':'native:'+k,'reason':reason[k]+' Exact entry: '+k+'.','value_sha256':hashlib.sha256(v.encode()).hexdigest()})
res=[]
for f in first['findings']:
 k=f['key'].split(':',1)[1];assert a[k]!=old[k],k
 res.append({**f,'state':'resolved','resolution':'Editor wording directly reread against the frozen English source and gameplay; original meaning issue resolved.','final_value':a[k]})
out={'reviewer':'/root/meaning_reviewer','source_sha256':man['source_sha256'],'native_catalog_sha256':hashlib.sha256((r/'editor/native-editor.txt').read_bytes()).hexdigest(),'stage':'independent-final-recheck','method':'Direct reread of all3393 final native key/value entries after full source/author review; full profiles read separately; truncated tool segments explicitly reread. No inferred completion from hashes.','batches':[{'id':b['id'],'source_sha256':man['source_sha256'],'target_sha256':h[b['id']],'reviewed_keys':b['keys'],'rechecked_keys':b['keys'],'rechecked_by':'/root/meaning_reviewer'} for b in bs],'findings':res,'accepted_english':accepted,'remaining_major_or_critical':[],'unresolved_uncertainty':[],'limits':['Agent-reviewed, not native-human-certified.','This record certifies linguistic review only, not rendering or platform execution.','Later source/target mutations invalidate affected batch sign-offs.']}
(r/'linguistic/native-meaning-final-recheck.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(len(a),'rechecked;',len(accepted),'individual English exceptions;',len(res),'findings resolved')
