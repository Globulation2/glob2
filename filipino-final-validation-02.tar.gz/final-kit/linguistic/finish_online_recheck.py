import json,pathlib,hashlib,importlib.util,re
r=pathlib.Path('artifacts/filipino-localization');s=importlib.util.spec_from_file_location('p','tools/localization/translation_program.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
man=json.loads((r/'manifest.json').read_text());first=json.loads((r/'linguistic/online-meaning-first-pass.json').read_text());src=json.loads((r/'source/online.json').read_text());a=json.loads((r/'editor/online-editor.json').read_text());old=json.loads((r/'author/online-author.json').read_text());bs=[b for b in man['batches'] if b['id'].startswith('online-')];hs=m.batch_target_hashes(man,{'native':r/'editor/native-after-adversary.txt','online':r/'editor/online-editor.json'})
reason={}
def group(keys,why):
 for k in keys.split('|'):reason[k]=why

group('AI|AI Building Studio|AI MAP STUDIO|AI MUSIC STUDIO|AI Map Studio|AI Music Studio|AI Studio|AI Terrain Studio|Building Studio|COLONY STUDIO|Cabino|Castor|Cortex|Econo|Generator Studio|Globulation 2|Hive Mind|Maxima|Nicowar|Numbi|Toubib|Warrush|AI Colony Studio','Proper product, studio or AI identity, or established AI abbreviation; preserve recognition across game and browser.')
group('/ais/favourites|/ais/mine|public, max-age=604800|text/html; charset=utf-8|1.0.0','Literal route, protocol header or version identifier; these bytes are technical data rather than prose.')
group('Engine {slot0} · suite {slot1}|Engine {slot0} · {slot1}|HTTP {value0}|JSON|JavaScript · {slot0}|format {value0}, network {value1}','Technical engine/protocol/code label with interpolated identifiers; established names retained rather than translated into misleading ordinary senses.')
group('Address|Brush|Draft|File|Frame|Generator|Hex|Leaderboard|Manifest|Moderator|Offline|Opacity |Password|Ping|Pose|Preview|Preview · {value0}|Rating|Release|Seed|Source code|Sprite key|Sprite manifest JSON|Spritesheet|Studio|Tag|Timeline|icon {value0}|live|{slot0} loop|{slot0}: default {slot1}{slot2}|{value0} waveform|{value0}, frame {value1}|{slot0} · seed {slot1} · {slot2}|{slot0} · seed {slot1} · {slot2}{slot3}','Recognizable software, network, painting, media or game-interface loan/technical label; deliberate contemporary Filipino usage with all identifiers preserved.')
group('{slot0} credit · {slot1}  {slot2}|{slot0} credit — {slot1}','Credit is the chosen recognizable purchasable unit loan in this template; singular English branch matches by design, while Filipino count grammar remains invariant.')
group('V|A · V{slot0}|B{slot0}|V{slot0} · {slot1}|b-|r{slot0} · {slot1}|v{slot0}','Compact version/badge identifier with no translatable prose; preserve exact marker and placeholder.')
accepted=[]
for k,v in a.items():
 for cat,x in (v.items() if isinstance(v,dict) else [('other',v)]):
  orig=src[k].get(cat) if isinstance(src[k],dict) else src[k]
  if x!=orig:continue
  why=reason.get(k)
  if k.startswith('CC'):why='Exact Creative Commons licence identifier; preserve legal licence identity and version.'
  if not why:
   stripped=re.sub(r'\{[a-zA-Z][a-zA-Z0-9_]*\}','',k)
   if not re.search('[a-zA-Z]',stripped):why='Symbol, numeric or placeholder-only template; preserve punctuation, units and variable structure with no prose to translate.'
  assert why,k
  accepted.append({'key':'online:'+k+('/'+cat if cat!='other' else ''),'reason':why+' Exact reviewed entry: '+k+'.','value_sha256':hashlib.sha256(x.encode()).hexdigest()})
res=[]
for f in first['findings']:
 k=f['key'].split(':',1)[1];assert a[k]!=old[k],k
 res.append({**f,'state':'resolved','resolution':'Final editor wording directly reread against the frozen English source/context; original semantic issue resolved.','final_value':a[k]})
previous=json.loads((r/'editor/online-editor-through-012.json').read_text());firstkeys=[k.split(':',1)[1] for b in bs[:12] for k in b['keys']];diff=[k for k in firstkeys if a[k]!=previous[k]];assert diff==['Map credits']
d={'reviewer':'/root/meaning_reviewer','source_sha256':man['source_sha256'],'online_catalog_sha256':hashlib.sha256((r/'editor/online-editor.json').read_bytes()).hexdigest(),'stage':'independent-final-recheck','method':'Direct reread of all2836 final online keys and every target plural branch, serialized through006, through012 and final snapshots. Truncated batch014 segment reread explicitly. Three early deltas (COLONY STUDIO and duplicate diagnostics) reread; later Map credits delta reread against actual paid-wallet UI source.','batches':[{'id':b['id'],'source_sha256':man['source_sha256'],'target_sha256':hs[b['id']],'reviewed_keys':b['keys'],'rechecked_keys':b['keys'],'rechecked_by':'/root/meaning_reviewer'} for b in bs],'findings':res,'accepted_english':accepted,'additional_recheck_findings':[{'key':'online:Duplicate rig clip','severity':'major','state':'resolved','reason':'Editor converted validator error into copy imperative; restored correct noun diagnostic and independently reread.'},{'key':'online:Duplicate shape clip','severity':'major','state':'resolved','reason':'Editor converted validator error into copy imperative; restored correct noun diagnostic and independently reread.'},{'key':'online:finding','severity':'minor','state':'open','reason':'music/Validation.tsx:121 uses count1 diagnostic finding, not searching; current paghahanap means search.','recommended':'natuklasang isyu'}],'remaining_major_or_critical':[],'unresolved_uncertainty':[],'carry_forward_proof':{'from_through012_snapshot_sha256':hashlib.sha256((r/'editor/online-editor-through-012.json').read_bytes()).hexdigest(),'first1920_changed_keys':['online:Map credits'],'first1920_unchanged_keys':1919,'result':'All1919 unchanged values individually equality-compared with previously directly read snapshot; Map credits paidwallet correction approved against MapStudio.tsx:305-353.'},'limits':['Agent-reviewed, not native-human-certified.','This is linguistic review only, not platform or rendering certification.','One final minor diagnostic-label correction remains pending; delta recheck required.','Later target/source changes invalidate affected batch sign-offs.']}
(r/'linguistic/online-meaning-final-recheck.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(len(a),'rechecked;',len(accepted),'individual English exceptions;',len(res),'initial findings resolved; pending1minor')
