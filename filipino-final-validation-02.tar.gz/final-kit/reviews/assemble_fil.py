"""Assemble existing independently authored evidence; never manufacture approvals."""
import copy, hashlib, importlib.util, json
from pathlib import Path
ROOT=Path.cwd();KIT=ROOT/'artifacts/filipino-localization'
spec=importlib.util.spec_from_file_location('program',ROOT/'tools/localization/translation_program.py');P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)
def read(path):return json.loads((KIT/path).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def evidence(path):return {'path':path,'sha256':sha(KIT/path)}
def write(path,data):P.write_json(KIT/path,data)
manifest=read('manifest.json');paths=P.catalog_paths(KIT,'fil');hashes={surface:sha(path) for surface,path in paths.items()}
assert hashes=={'native':'5c86dff4c8e9fb03c89bae1185740767dfc56959003e55e81c3bb84479531f61','online':'99ed554f753390682d437318e20ed9d7ddbd54fbe2c798df41b42d4fb3fb2446'}
source=manifest['source_sha256'];assert P.sources()[4]==source
brief=read('linguistic/meaning-brief.json');pilot=read('linguistic/pilot-meaning-review.json')
author={surface:read('author/'+surface+'-author-review.json') for surface in paths}
meaning={surface:read('linguistic/'+surface+'-meaning-final-recheck.json') for surface in paths}
editor=read('linguistic/language-editor-record.json');adversary=read('adversary/review.json');exceptions=read('editor/accepted-english-editor.json')
checked=P.check_draft(KIT,'fil');assert not checked['errors'] and not checked['untranslated']
assert editor['identity']=='/root/language_editor' and adversary['identity']=='/root/adversarial_reviewer'
assert editor['source_sha256']==adversary['source_sha256']==exceptions['source_sha256']==source
assert exceptions['catalog_sha256']==adversary['catalog_sha256']==hashes
actual_keys={key for batch in manifest['batches'] for key in batch['keys']}
assert len(actual_keys)==6229 and len(manifest['batches'])==43
for surface in paths:
    expected={key for key in actual_keys if key.startswith(surface+':')}
    assert set(author[surface]['read_keys'])==expected and len(author[surface]['read_keys'])==len(expected)
    assert author[surface]['identity']=='draft_editor' and author[surface]['source_sha256']==source
    snapshot=KIT/('author/native-author.txt' if surface=='native' else 'author/online-author.json')
    assert sha(snapshot)==author[surface]['catalog_sha256']
    assert meaning[surface]['source_sha256']==source
    assert meaning[surface][surface+'_catalog_sha256']==editor[surface+'_catalog_sha256']==adversary[surface+'_catalog_sha256']==hashes[surface]
    assert meaning[surface]['reviewer']=='/root/meaning_reviewer'
    assert not meaning[surface]['remaining_major_or_critical'] and not meaning[surface]['unresolved_uncertainty']

role_files=['author/native-author-review.json','author/online-author-review.json','linguistic/native-meaning-first-pass.json','linguistic/online-meaning-first-pass.json','linguistic/native-meaning-editor-recheck.json','linguistic/online-meaning-editor-recheck.json','linguistic/native-meaning-final-recheck.json','linguistic/online-meaning-final-recheck.json','linguistic/language-editor-record.json','adversary/review.json','editor/accepted-english-editor.json','linguistic/meaning-brief.json','linguistic/pilot-meaning-review.json','google/fil/summary.json','google/fil/config.json']
role_evidence=[evidence(path) for path in role_files]
carry={surface:{key:copy.deepcopy(value) for key,value in meaning[surface].items() if key in ['carry_forward_proof','delta_recheck','final_delta_recheck']} for surface in paths}
carry['editor']={key:copy.deepcopy(value) for key,value in editor.items() if key.endswith('_approval')}
carry['adversary']={batch['id']:{key:copy.deepcopy(value) for key,value in batch.items() if key in ['snapshot_sha256','snapshot_path','final_snapshot_sha256','final_snapshot_path','delta_rechecked_keys','unchanged_key_carry_forward','carry_forward_proof']} for batch in adversary['batches']}
provenance={'locale':'fil','source_sha256':source,'catalog_sha256':hashes,'role_evidence':role_evidence,
 'identity_aliases':{'draft_editor':'/root/draft_editor'},
 'method':'Assembled existing role-authored records only after exact final catalog, source, batch-hash and key-coverage comparisons. Original stage records and snapshots are retained unmodified. Changes after complete readings rely on each reviewer\'s explicit delta approvals and entry-equality proofs; this is not another fresh full reading.',
 'carry_forward':carry,
 'pilot':{'original_decision':pilot['decision'],'original_evidence':evidence('linguistic/pilot-meaning-review.json'),'source_brief_evidence':evidence('linguistic/meaning-brief.json'),'binding':'The source-based pilot permitted Google draft expansion only. Historical pilot findings remain preserved in the original record; final linguistic release judgments come from the explicit final all-entry rechecks, editorial approvals and adversarial record, all bound above to these final catalogs.','not_native_human_certified':True}}
write('reviews/fil-provenance.json',provenance)

mb={batch['id']:batch for record in meaning.values() for batch in record['batches']};eb={batch['id']:batch for batch in editor['batches']};ab={batch['id']:batch for batch in adversary['batches']};target=P.batch_target_hashes(manifest,paths)
batches=[]
for expected in manifest['batches']:
    name=expected['id'];keys=set(expected['keys']);m,e,a=mb[name],eb[name],ab[name]
    assert m['target_sha256']==e['target_sha256']==a['target_sha256']==target[name]
    for values in [m['reviewed_keys'],m['rechecked_keys'],e['edited_keys'],a['adversarial_reviewed_keys']]:assert set(values)==keys and len(values)==len(keys)
    assert m['rechecked_by']=='/root/meaning_reviewer' and a['adversarial_reviewer']=='/root/adversarial_reviewer'
    batches.append({'id':name,'source_sha256':source,'target_sha256':target[name],
      'author':'/root/draft_editor','reviewer':'/root/meaning_reviewer','editor':'/root/language_editor',
      'reviewed_keys':m['reviewed_keys'],'edited_keys':e['edited_keys'],'rechecked_keys':m['rechecked_keys'],'rechecked_by':m['rechecked_by'],
      'adversarial_reviewer':a['adversarial_reviewer'],'adversarial_reviewed_keys':a['adversarial_reviewed_keys'],
      'provenance':{'author_stage_record':'author/'+name.split('-')[0]+'-author-review.json','final_reviewer_record':'linguistic/'+name.split('-')[0]+'-meaning-final-recheck.json','editor_record':'linguistic/language-editor-record.json','adversarial_record':'adversary/review.json','carry_forward':'reviews/fil-provenance.json'}})

meaning_exceptions={x['key']:x for record in meaning.values() for x in record['accepted_english']}
editor_exceptions={x['id']:x for x in exceptions['accepted_english']};queue=set(checked['same_as_english_review_queue'])
assert set(meaning_exceptions)==set(editor_exceptions)==set(adversary['english_match_review']['reviewed_keys'])==queue and len(queue)==265
accepted=[]
for key in checked['same_as_english_review_queue']:
    e,m=editor_exceptions[key],meaning_exceptions[key]
    assert e['rationale'].strip() and m['reason'].strip()
    accepted.append({'key':key,'reason':e['rationale'],'meaning_reason':m['reason'],'value_sha256':m.get('value_sha256'),
      'reviewer':'/root/meaning_reviewer','editor':'/root/language_editor','adversarial_reviewer':'/root/adversarial_reviewer'})
findings=[]
for surface,record in meaning.items():
    for field in ['findings','additional_recheck_findings']:
        for finding in record.get(field,[]):
            assert finding['state']=='resolved';f=copy.deepcopy(finding);f['reported_by']=record['reviewer'];f['evidence_record']='linguistic/'+surface+'-meaning-final-recheck.json';findings.append(f)
for finding in adversary['findings']:
    assert finding['state']=='resolved';f=copy.deepcopy(finding);f['reported_by']=adversary['identity'];f['evidence_record']='adversary/review.json';findings.append(f)
record={'locale':'fil','source_sha256':source,'catalog_sha256':hashes,'batches':batches,'findings':findings,'accepted_english':accepted,
 'language_brief':{'variety':brief['variety'],'script':brief['script'],'region':brief['region'],'sources':brief['sources'],
   'terminology_rationales':brief['glossary'],'orthography_defaults':brief['orthography_defaults'],'unresolved_uncertainty':brief['unresolved_uncertainty'],
   'certification':brief['certification'],'original_evidence':evidence('linguistic/meaning-brief.json')},
 'provenance':evidence('reviews/fil-provenance.json'),'gates':{gate:{'passed':False,'evidence':[]} for gate in P.GATES}}
for gate,files in [('language_brief',['linguistic/meaning-brief.json','reviews/fil-provenance.json','linguistic/native-meaning-final-recheck.json','linguistic/online-meaning-final-recheck.json']),('source_based_pilot',['linguistic/pilot-meaning-review.json','linguistic/meaning-brief.json','reviews/fil-provenance.json','google/fil/summary.json'])]:
    record['gates'][gate]={'passed':True,'source_sha256':source,'catalog_sha256':hashes,'evidence':[evidence(path) for path in files]}
write('reviews/fil.json',record)
print(json.dumps({'batches':len(batches),'covered_ids':sum(len(b['reviewed_keys']) for b in batches),'accepted_english':len(accepted),'resolved_findings':len(findings),'catalog_sha256':hashes},indent=2))
