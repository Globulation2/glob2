"""Narrow final two-caption review carry-forward; never changes gate records."""
import copy,hashlib,importlib.util,json,pathlib,subprocess
R=pathlib.Path(__file__).resolve().parents[3];K=R/'artifacts/filipino-localization';S=K/'author/compact-labels'
def read(p):return json.loads((K/p).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def vh(x):return hashlib.sha256(x.encode()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def evidence(p):return {'path':p,'sha256':sha(K/p)}
spec=importlib.util.spec_from_file_location('P',R/'tools/localization/translation_program.py');P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)
a=read('author/compact-labels/author-delta.json');m=read('linguistic/compact-labels-meaning-final.json');e=read('linguistic/compact-labels-editor-final.json');v=read('adversary/compact-labels-final.json');old=read('author/compact-labels/official-before.json');oldp=read('author/compact-labels/provenance-before.json');record=read('reviews/fil.json');prov=read('reviews/fil-provenance.json');gates=copy.deepcopy(record['gates']);manifest=read('manifest.json');paths=P.catalog_paths(K,'fil');hashes={surface:sha(p) for surface,p in paths.items()}
assert record['catalog_sha256']==old['catalog_sha256'],'Already refreshed or changed unexpectedly'
assert prov==oldp,'Provenance changed unexpectedly'
assert sha(S/'native-before.txt')==a['catalog_before_sha256']==old['catalog_sha256']['native']
assert sha(S/'native-after.txt')==a['catalog_after_sha256']==hashes['native']==m['native_final_sha256']==e['native_catalog_sha256']==v['catalog_after_sha256']
assert m['reviewer']=='/root/meaning_reviewer' and e['identity']=='/root/language_editor' and v['identity']=='/root/adversarial_reviewer' and a['identity']=='/root/draft_editor'
assert e['status']=='approved'
assert a['source_sha256']==m['source_sha256']==e['source_sha256']==v['source_sha256']==manifest['source_sha256']==P.sources()[4]
assert hashes['online']==sha(S/'online-before.json')==old['catalog_sha256']['online']==m['online_unchanged_sha256']==e['online_catalog_sha256']
before=read('author/compact-labels/native-before.json');after=read('drafts/fil/native.json');parsed,errors=P.CHECKER.read_table(paths['native']);assert not errors and parsed==after
changes={k for k in after if before[k]!=after[k]};assert changes=={'[Rules]','[Editor tools]'}
changed={'native:'+k for k in changes};unchanged={'native:'+k for k in after if k not in changes};online={'online:'+k for k in read('drafts/fil/fil.json')}
assert len(unchanged)==3391 and len(online)==2836
assert set(a['unchanged_native_keys'])==set(m['carry_forward']['native_keys'])==unchanged
assert set(a['unchanged_online_keys'])==online
source=read('source/native.json');mm={x['id']:x for x in m['entries']};ee={x['id']:x for x in e['approved_entries']};vv={x['key']:x for x in v['changes']};aa={x['key']:x for x in a['changes']};assert set(mm)==set(ee)==set(vv)==set(aa)==changed
for id in changed:
 key=id.split(':',1)[1];mv,ev,av,vv_=mm[id],ee[id],aa[id],vv[id]
 assert mv['source']==ev['source']==av['source']==vv_['source']==source[key]
 assert mv['source_value_sha256']==ev['source_value_sha256']==av['source_value_sha256']==vv_['source_value_sha256']==vh(source[key])
 assert mv['final']==ev['target']==av['after']==vv_['after']==after[key]
 assert mv['final_value_sha256']==ev['target_value_sha256']==av['after_value_sha256']==vv_['after_value_sha256']==vh(after[key])
 assert mv['before']==av['before']==vv_['before']==before[key]
 assert mv['meaning_approval']=='approved after direct final-entry reread' and ev['status']=='approved' and vv_['adversarial_rechecked'] and vv_['approved_wording']
 assert mv['rationale'].strip() and e['rationales'][id].strip() and vv_['rationale'].strip()
target=P.batch_target_hashes(manifest,paths);affected={b['id'] for b in manifest['batches'] if set(b['keys'])&changed};assert affected=={'native-general-007'}
for batch in record['batches']:
 if batch['id'] not in affected:assert batch['target_sha256']==target[batch['id']]
 else:
  assert e['batch']['target_sha256']==target[batch['id']]
  for entry in m['entries']:assert entry['batch_target_sha256']==target[batch['id']]
assert not P.check_draft(K,'fil')['errors']
files=['author/compact-labels/author-delta.json','linguistic/compact-labels-meaning-final.json','linguistic/compact-labels-editor-final.json','adversary/compact-labels-final.json']
proof={'scope':'Two actual compact-caption author edits and independent final meaning, language and adversarial rereads; exact-value carry-forward for all other entries. No new full-catalog reread or pixel-fit approval implied.','source_sha256':manifest['source_sha256'],'catalog_before_sha256':old['catalog_sha256'],'catalog_after_sha256':hashes,'changed_keys':sorted(changed),'unchanged_native_keys':sorted(unchanged),'unchanged_online_keys':sorted(online),'unchanged_native_count':3391,'unchanged_online_count':2836,'affected_batches':{bid:{'before':next(b['target_sha256'] for b in old['batches'] if b['id']==bid),'after':target[bid],'actually_reread_keys':sorted(changed)} for bid in affected},'evidence':[evidence(p) for p in files],'original_official_snapshot':evidence('author/compact-labels/official-before.json'),'original_provenance_snapshot':evidence('author/compact-labels/provenance-before.json'),'native_before_snapshot':evidence('author/compact-labels/native-before.txt'),'native_after_snapshot':evidence('author/compact-labels/native-after.txt'),'intentional_loan_rationales':{'native:[Editor tools]':{'meaning':mm['native:[Editor tools]']['rationale'],'language_editor':e['rationales']['native:[Editor tools]'],'adversarial':vv['native:[Editor tools]']['rationale']}},'gates':'Retained byte-equivalent objects at old catalog hashes for root to explicitly invalidate/refresh; pending rendering/execution is not relabeled.'}
write(K/'reviews/compact-labels-carry-forward.json',proof)
prov['catalog_sha256']=hashes
prov.setdefault('post_review_deltas',[]).append(evidence('reviews/compact-labels-carry-forward.json'))
prov['method']+=' Two compact captions were later revised after actual visual findings. Original stage evidence remains historical and unchanged. The separate compact-labels carry-forward proof binds all3391 identical native entries and2836 online entries; only the two changed keys have new direct final approvals.'
write(K/'reviews/fil-provenance.json',prov)
record['catalog_sha256']=hashes
for batch in record['batches']:
 if batch['id'] in affected:
  batch['target_sha256']=target[batch['id']]
  batch['provenance']['targeted_delta']=evidence('reviews/compact-labels-carry-forward.json')
record['provenance']=evidence('reviews/fil-provenance.json')
assert record['gates']==gates
write(K/'reviews/fil.json',record)
result={'status':'linguistic_delta_validated','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'catalog_sha256':hashes,'updated_batch_ids':sorted(affected),'batch_count':len(record['batches']),'entry_count':sum(len(b['reviewed_keys']) for b in record['batches']),'evidence':[evidence('reviews/fil.json'),evidence('reviews/fil-provenance.json'),evidence('reviews/compact-labels-carry-forward.json')],'gates_preserved_exactly':record['gates']==read('author/compact-labels/official-before.json')['gates'],'gate_snapshot_sha256':vh(json.dumps(gates,sort_keys=True,ensure_ascii=False))}
write(K/'reviews/compact-labels-update-result.json',result);print(json.dumps(result,indent=2))
