"""Carry unchanged reviewed values into a new source snapshot; never approve gates."""
from pathlib import Path
import shutil,json,hashlib,importlib.util,subprocess,copy
R=Path.cwd();K=R/'artifacts/filipino-localization';F=K/'final-kit'
spec=importlib.util.spec_from_file_location('P',R/'tools/localization/translation_program.py');P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):P.write_json(p,x)
def ev(p):return {'path':str(p.relative_to(F)),'sha256':sha(p)}
assert not F.exists(),'Refuse to reset any final evidence'
assert not subprocess.check_output(['git','status','--porcelain'],text=True),'Final source must be committed before snapshot'
final=read(K/'master-delta/final.json');newkeys=set(final);assert newkeys=={'[stat win probability]','[stat win probability about]'}
source_delta=read(K/'master-delta/source.json')['entries']
review_files={'author-review.json':'/root/draft_editor','meaning-review.json':'/root/meaning_reviewer','editor-review.json':'/root/language_editor','meaning-final-review.json':'/root/meaning_reviewer','adversarial-review.json':'/root/adversarial_reviewer'}
for name,identity in review_files.items():
 v=read(K/'master-delta'/name);assert v.get('identity',v.get('reviewer'))==identity
 rows={e['id']:e for e in v['entries']};assert set(rows)=={'native:'+k for k in final}
 for key,value in final.items():
  e=rows['native:'+key];assert e['source']==source_delta[key]
  assert e['source_value_sha256']==P.digest(source_delta[key].encode())
  assert e.get('final_value_sha256',e.get('target_value_sha256'))==P.digest(value.encode())
  assert e.get('author_final',e.get('final_value',e.get('final_target',e.get('final'))))==value
  if name!='author-review.json':assert e['status']=='approved'
for n in ['source','batches','drafts','reviews','author','editor','linguistic','adversary','master-delta']:shutil.copytree(K/n,F/n,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copyfile(K/'manifest.json',F/'manifest.json')
before=F/'master-delta/before';before.mkdir()
for src,name in [(F/'manifest.json','manifest.json'),(F/'reviews/fil.json','official.json'),(F/'reviews/fil-provenance.json','provenance.json'),(F/'source/native.json','source-native.json'),(F/'drafts/fil/native.json','target-native.json')]:shutil.copyfile(src,before/name)
oldsource=read(before/'source-native.json');oldtarget=read(before/'target-native.json');keys,native,online,files,source=P.sources(R);target,errors=P.CHECKER.read_table(R/'data/texts.fil.txt');assert not errors
assert set(native)-set(oldsource)==newkeys and not(set(oldsource)-set(native));assert all(native[k]==v for k,v in oldsource.items());assert target==dict(oldtarget,**final);assert online==read(F/'source/online.json')
manifest=read(F/'manifest.json');oldmanifest=copy.deepcopy(manifest)
assert all(files[n]==oldmanifest['source_files'][n] for n in P.SOURCE_PATHS if n not in ['data/texts.en.txt','data/texts.keys.txt'])
assert sha(F/'drafts/fil/fil.json')==read(before/'official.json')['catalog_sha256']['online']
assert sha(F/'drafts/fil/texts.fil.txt')==read(before/'official.json')['catalog_sha256']['native']
manifest.update(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_sha256=source,source_files=files,native_keys=len(native));bid='native-master-delta-001';ids=['native:'+k for k in final];manifest['batches'].append({'id':bid,'path':'batches/'+bid+'.json','keys':ids})
write(F/'source/native.json',native);(F/'source/native-keys.txt').write_text('\n'.join(keys)+'\n');write(F/'manifest.json',manifest)
for b in oldmanifest['batches']:
 p=F/b['path'];v=read(p);v['source_sha256']=source;v['source_carry_forward']='../master-delta/source-target-carry.json';write(p,v)
write(F/'batches'/ (bid+'.json'),{'id':bid,'source_sha256':source,'surface':'native','domain':'statistics','context':'New master statistics probability axis (%) and explanatory tooltip. Agent reviews are direct new-entry reads.','entries':[{'id':'native:'+k,'key':k,'source':native[k]} for k in final]})
shutil.copyfile(R/'data/texts.fil.txt',F/'drafts/fil/texts.fil.txt');write(F/'drafts/fil/native.json',target)
paths=P.catalog_paths(F,'fil');hashes={s:sha(p) for s,p in paths.items()};meta=read(F/'drafts/fil/metadata.json');meta.update(source_sha256=source,source_revision=manifest['revision'],catalog_sha256=hashes);write(F/'drafts/fil/metadata.json',meta)
proof={'scope':'3393 native and2836 online entries retain identical English sources and exact final targets; existing independent reviews carry only for those unchanged values. Two new master entries have direct new reviews. No whole-catalog reread is claimed.','source_before_sha256':oldmanifest['source_sha256'],'source_after_sha256':source,'catalog_before_sha256':read(before/'official.json')['catalog_sha256'],'catalog_after_sha256':hashes,'unchanged_native_ids':['native:'+k for k in oldsource],'unchanged_online_ids':['online:'+k for k in online],'added_ids':ids,'before_evidence':[ev(before/n) for n in ['manifest.json','official.json','provenance.json','source-native.json','target-native.json']]}
write(F/'master-delta/source-target-carry.json',proof)
record=read(F/'reviews/fil.json');prov=read(F/'reviews/fil-provenance.json');targethash=P.batch_target_hashes(manifest,paths)
for b in record['batches']:
 assert b['target_sha256']==targethash[b['id']];b['source_sha256']=source;b.setdefault('provenance',{})['master_source_carry']=ev(F/'master-delta/source-target-carry.json')
record['batches'].append({'id':bid,'source_sha256':source,'target_sha256':targethash[bid],'author':'/root/draft_editor','reviewer':'/root/meaning_reviewer','editor':'/root/language_editor','rechecked_by':'/root/meaning_reviewer','adversarial_reviewer':'/root/adversarial_reviewer','reviewed_keys':ids,'edited_keys':ids,'rechecked_keys':ids,'adversarial_reviewed_keys':ids,'provenance':{'source_carry':ev(F/'master-delta/source-target-carry.json'),'direct_reviews':[ev(F/'master-delta'/n) for n in ['author-review.json','meaning-review.json','editor-review.json','meaning-final-review.json','adversarial-review.json']]}})
prov.setdefault('role_evidence',[]).extend(ev(F/'master-delta'/n) for n in review_files)
prov.update(source_sha256=source,catalog_sha256=hashes);prov.setdefault('post_review_deltas',[]).append(ev(F/'master-delta/source-target-carry.json'));prov['method']+=' Master added two statistics entries; unchanged6229values carry exact source+target comparisons and the two additions have separate direct reviews.';write(F/'reviews/fil-provenance.json',prov)
record.update(source_sha256=source,catalog_sha256=hashes,provenance=ev(F/'reviews/fil-provenance.json'))
for gate in record['gates'].values():gate['passed']=False;gate['invalidated_by']='New final source/catalog snapshot; root must bind scoped existing evidence with exact carry proof and new2entry validation.'
write(F/'reviews/fil.json',record);assert not P.check_draft(F,'fil')['errors'];print(json.dumps({'source':source,'hashes':hashes,'keys':len(native)+len(online),'batches':len(record['batches'])}))
