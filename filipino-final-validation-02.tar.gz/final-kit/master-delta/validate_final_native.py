from pathlib import Path
import subprocess,os,json,hashlib,time
r=Path.cwd();k=r/'artifacts/filipino-localization';rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert rev.startswith('46a7d1c473');assert not subprocess.check_output(['git','status','--porcelain'],text=True)
env=dict(os.environ,GLOB2_SDL3_PREFIX=str(k/'sdl-reused'),LD_LIBRARY_PATH=str(k/'sdl-reused/lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''),SDL_VIDEO_DRIVER='x11');[env.pop(n,None) for n in ['DISPLAY','WAYLAND_DISPLAY','XAUTHORITY']]
record={'revision':rev,'commands':[]}
commands=[('native-final-master-build',['python3','tools/dev_build.py','translation-preview-harness','engine-tests','-j6']),('native-final-master-focused',['python3','test/run_tests.py','--build-dir','build/linux/client/debug/dev-dev_fast-true-linker-auto','--binary','engine','--filter','SystemLanguage/*','--filter','FontKerning/*','--filter','EditorPresentation/*','--filter','Settings/large Filipino touch footers*','--display-jobs','1','-j','4','--timeout','240','--artifacts',str(k/'native-final-master-focused'),'--junit',str(k/'native-final-master-junit.xml')])]
for name,argv in commands:
 start=time.monotonic()
 with (k/(name+'.log')).open('w') as log:p=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
 record['commands'].append({'name':name,'argv':argv,'exit_code':p.returncode,'seconds':time.monotonic()-start,'log':name+'.log','log_sha256':hashlib.sha256((k/(name+'.log')).read_bytes()).hexdigest()});(k/'native-final-master-results.json').write_text(json.dumps(record,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
