from pathlib import Path
import subprocess,json,os,hashlib
root=Path('/dev/shm/glob2-air-evidence'); original=root/'determinism-final';out=root/'uninstrumented';out.mkdir(exist_ok=True)
binary=Path('/dev/shm/glob2-unified-air-release/src/glob2');results=[]
for case in ['midgame','islands','swamp','lava','stress']:
 promoted=original/(case+'-promoted');save=promoted/'final.game.gz'
 if not save.exists():save=promoted/'final.game'
 stop=json.loads((original/(case+'-p4')/'result.json').read_text())['ticks']
 destination=out/case;destination.mkdir(exist_ok=True)
 command=[str(binary),'game','run','--load-game',str(save),'--ticks',str(stop),'--compute-threads','4','--gpu','off','--compute-telemetry','off','--telemetry','checksums','--output-dir',str(destination)]
 env=dict(os.environ,GLOB2_USER_DIR=str(destination/'profile'),GLOB2_USER_DATA_DIR=str(destination/'profile'))
 with (destination/'run.log').open('w') as stream:subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=180)
 actual=(destination/'game.replay.checksums').read_bytes(); expected=(original/(case+'-p4')/'game.replay.checksums').read_bytes()
 assert actual==expected,case
 (destination/'command.json').write_text(json.dumps({'command':command,'input_sha256':hashlib.sha256(save.read_bytes()).hexdigest()},indent=2))
 results.append({'case':case,'all_checksum_bytes_match_instrumented_build':True,'checksum_sha256':hashlib.sha256(actual).hexdigest()});print(case,flush=True)
(out/'summary.json').write_text(json.dumps({'revision':'b2264eb567c7b6a8ff33282f9ffaf59fd202ef4e','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'results':results},indent=2))
