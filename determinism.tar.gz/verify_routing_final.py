import hashlib,json,os,struct,subprocess,time
from pathlib import Path
ROOT=Path('/home/bradley/glob2')
SOURCE=Path('/home/bradley/.codex/worktrees/unified-air-routing/glob2')
BINARY=Path('/dev/shm/glob2-unified-air-release/src/glob2')
OUT=Path('/dev/shm/glob2-air-evidence/determinism-final')
OUT.mkdir(exist_ok=True)

def run(name,save,stop,threads=4,extra=()):
    directory=OUT/name;directory.mkdir()
    command=[str(BINARY),'game','run','--load-game',str(save),'--ticks',str(stop),'--compute-threads',str(threads),'--gpu','off','--compute-telemetry','off','--output-dir',str(directory),*extra]
    env=dict(os.environ,GLOB2_USER_DIR=str(directory/'profile'),GLOB2_USER_DATA_DIR=str(directory/'profile'))
    started=time.time()
    with (directory/'run.log').open('w') as log:subprocess.run(command,cwd=SOURCE,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
    result=json.loads((directory/'result.json').read_text())
    (directory/'command.json').write_text(json.dumps({'command':command,'cwd':str(SOURCE),'input_sha256':hashlib.sha256(save.read_bytes()).hexdigest(),'wall_seconds':time.time()-started},indent=2))
    assert result['ticks']==stop,(name,result['ticks'],stop)
    print(name,result['finalChecksum'],flush=True)
    return directory,result

def hashes(path):
    # Retain each aggregate checksum as well as every team/entity byte. All
    # verification inputs are first promoted to one common format-171 save.
    with path.open('rb') as f:
        head=f.read(20);assert head[:4]==b'GCS1'
        teams,players,count,flags=struct.unpack('<4I',head[4:]);result={}
        def read(n):
            data=f.read(n);assert len(data)==n;return data
        for _ in range(count):
            prefix=read(8);tick,aggregate=struct.unpack('<2I',prefix);h=hashlib.sha256(prefix[4:])
            for _ in range(teams):
                h.update(read(4))
                for _ in range(2):
                    data=read(4);h.update(data);entities=struct.unpack('<I',data)[0]
                    for _ in range(entities):
                        data=read(10);h.update(data);fields=struct.unpack_from('<I',data,6)[0];h.update(read(4*fields))
            result[tick]=h.hexdigest()
        assert not f.read(1)
        return result

stress=next(Path('/dev/shm/glob2-air-evidence/policy-regressions').rglob('air-routing-stress.game'))
cases=[('midgame',ROOT/'artifacts/pr1193/handoff/fixtures/midgame24k.game.gz',24000),('islands',ROOT/'artifacts/hiring-refresh-shortlists-20261015/performance/checkpoints/performance-islands/original/game/final.game.gz',8192),('swamp',ROOT/'artifacts/hiring-refresh-shortlists-20261015/performance/checkpoints/performance-swamp/original/game/final.game.gz',8192),('lava',ROOT/'artifacts/air-field-callgrind/lava-fixture/final.game.gz',8192),('stress',stress,0)]
report=[]
for name,save,start in cases:
    promoted,_=run(name+'-promoted',save,start+1,extra=('--save','final'))
    save=promoted/'final.game.gz'
    if not save.exists():save=promoted/'final.game'
    expected=None
    for participants in (1,2,4,8):
        directory,result=run(f'{name}-p{participants}',save,start+129,participants,('--telemetry','checksums'))
        actual=hashes(directory/'game.replay.checksums');assert len(actual)==128
        if expected is None:expected=actual
        else:assert actual==expected,(name,participants,'thread divergence')
    if name in ('lava','stress'):
        for phase in range(8):
            checkpoint,_=run(f'{name}-checkpoint-{phase}',save,start+33+phase,extra=('--save','final'))
            checkpoint=checkpoint/'final.game.gz' if (checkpoint/'final.game.gz').exists() else checkpoint/'final.game'
            directory,_=run(f'{name}-resume-{phase}',checkpoint,start+129,(1,2,4,8)[phase%4],('--telemetry','checksums'))
            actual=hashes(directory/'game.replay.checksums')
            assert actual and all(expected[tick]==value for tick,value in actual.items()),(name,phase,'save divergence')
    report.append({'case':name,'participants':[1,2,4,8],'ticks_compared':128,'aggregate_and_all_team_entity_fields_match':True,'save_phases':list(range(8)) if name in ('lava','stress') else []})
(OUT/'summary.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),'binary_sha256':hashlib.sha256(BINARY.read_bytes()).hexdigest(),'results':report,'platforms':['Linux x86_64 GCC 13'],'omitted_platforms':['Windows','macOS','Android','iOS','browser']},indent=2))
