Windows networking teardown mixes two Boost.Asio thread layouts: worker entry points use POSIX threads, while destruction reaches Win32 joins. The resulting invalid handles crash the MCP HTTP test and hang LAN/Wss shutdown. Set `BOOST_ASIO_HAS_PTHREADS` consistently across the MinGW build so header order cannot select incompatible private classes.

The existing pthread runtime is already linked and loaded; no dependency additions or upgrades. Other platforms retain their compiler flags. Document the build-wide constraint.

Validation: [exact-candidate Windows run](https://github.com/Globulation2/glob2/actions/runs/38892452936) passes all20 selected cases, including the six original networking regressions and the repaired turret fixture; three desktop-capture cases are explicitly unavailable. The embedded provenance confirms the build-wide define. All567 local Python build contracts pass (2 optional skips), and documentation checks pass.

Full master verification and cross-platform traces remain pending; focused testing does not replace that coverage. No simulation/save/replay changes. [Raw Windows stacks, JUnit/case outputs, full hosted log and exact toolchain/command provenance](https://github.com/Globulation2/glob2/tree/evidence/master-ci-recovery-1198/windows-asio). [Upstream Asio configuration contract](https://www.boost.org/latest/doc/html/boost_asio/using.html).
