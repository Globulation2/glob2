from pathlib import Path
import subprocess,json,sys
b=Path('artifacts/ci-recovery/windows-asio');files={'SConstruct':b/'SConstruct','docs/development/build-options.md':b/'build-options.md'}
original={name:Path(name).read_bytes() for name in files}
subprocess.run(['git','diff','--exit-code','--',*files],check=True,stdout=subprocess.DEVNULL)
r={'candidate':'974496f2a7463ef0a30affd834fcdb1a224f29e3','workingBase':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'interpreter':sys.executable,'method':'Overlay exact candidate SConstruct and documentation, run local contracts in the pinned requirements-dev environment, restore original files in finally. Browser fixture changes do not affect this compiler setting. Initial system-Python run delegated mocked image tests because Pillow10.2/libwebp1.3.2 differed from required12.2/1.6; failed initial evidence is retained separately.','commands':[]}
try:
 for name,source in files.items():Path(name).write_bytes(source.read_bytes())
 for name,command in [('build-contracts-pinned',[sys.executable,'-m','unittest','discover','-s','test/build_system','-p','test_*.py']),('docs-pinned',[sys.executable,'tools/check_docs.py'])]:
  with (b/(name+'.log')).open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  r['commands'].append({'command':command,'exitCode':result.returncode})
finally:
 for name,data in original.items():Path(name).write_bytes(data)
 (b/'local-verification-pinned.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r));raise SystemExit(any(c['exitCode'] for c in r['commands']))
