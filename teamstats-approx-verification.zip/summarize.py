import json,statistics,collections,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('artifacts/teamstats/approx'); rows=json.loads((root/'profiles.json').read_text()); rev=json.loads((root/'revisions.json').read_text())
def med(rs,k):return statistics.median(r[k]/r['ticks']/1000 for r in rs)
s='''# Worker-finalized smoothing verification

Final revision: `'''+rev['revision']+'''`; fetched master: `'''+rev['base']+'''`.
macOS ARM64, Apple Clang 21.0.0/libc++; dev via tools/dev_build.py, release with dev_fast=0 linker=default release=1. Link inputs and compile commands are attached; dependencies unchanged.

## Behavior

Workers finish aggregate smoothing from the latest 31 published raw samples plus the current sample. Only full-aggregate submissions (every 32 source samples per team) capture the ring. K=0/1 are exact; K>1 omits K-1 pending samples and substitutes older published rows. Published raw samples stay consecutive and never contain smoothed approximations. Delayed maxima may omit or prolong a peak and change AI decisions.

Owner publication updates changed measurement fields in place, retains spatial diagnostics until their 512-tick update, accumulates labour deltas and installs finalized aggregates. It does not perform the normal 32-row reduction or copy unchanged diagnostics out and back. Histories keep source ticks and pending samples keep fixed deadlines.

Format 157 stores an explicit finalized flag on aggregate samples. Old 155/156 pending aggregates load as raw, retain exact owner reduction, and preserve that mode on current-format resave. Format-155 digests remain read-and-discarded. No old world snapshots/windows are needed to restore completed pending results. Minimum save version stays 58; replay floor 157, protocol 69, SIM_REVISION 52 with refreshed golden record and trace. New-game delay remains 8; rules still allow 0–8.

## Correctness

- Native selected suite: 136 cases, 132 passed, 4 display cases skipped, no failures.
- Release selected suite: 77 cases, 76 passed, 1 display case skipped, no failures.
- Includes extracted/live equivalence, K=0/1/2/8 with zero/one/multiple workers, early/late completion, snapshots/observer generations, old save migrations, pending save/resave, current/old raw aggregate persistence, labour/cargo/spatial/custom catalogs, pause/reset/failure and AI continuation.
- New peak tests demonstrate exact K=1, missing recent peaks at larger K, older peaks lingering and eventual expiry without compounding.
- Golden regeneration and normal verification passed; sim-version check passed.
- Release advancing full checksums: 32 scenarios × 520 ticks = 16,640 raw per-tick checksum records. All 16 pairs match across zero/two workers (2/4 teams, K=0/1/2/8, controlled/Numbi-Castor matches). Heavy checking completes pending computation but does not publish early. Final checksums also agree across repeated profiling on/off trials and worker configurations.

Limitations: full-engine Linux/Windows/web/mobile checksum comparisons, display/visual tests, packaging, sanitizers, hosted CI and maintainer play review unavailable/not run. Keep draft. The MCP repair remains separate (#1157) and this PR remains stacked on it. No new runtime dependencies.

## Release profiling

Five paired before/after static trials at 2048 ticks, seed 1234567, 2 teams/256 static units, two workers, K=8. Before binary corresponds to 2d612a65c (SHA in revisions.json). After binary uses the new implementation. Additional advancing 2/4-team matches start with 128 units/team, stocked inns/swarms, wheat/wood/stone; no controllers or alternating Numbi/Castor, AI order delay 8. K=0/1/2/8 and zero/two workers. Exact invocations are in profile.py. Compile/test activity from this task finished before profiling; VM/other host activity remains a wall-clock limitation. Measurements are observations, not evidence of a general speedup.

Times in microseconds per advancing tick. Worker calculation sums both teams, includes only published batches; the last K unpublished jobs remain omitted. Capture is shared across consumers, not an isolated incremental statistics cost. Allocation/setup includes aggregate-window capture. Deadline waits include queue/backlog/scheduling effects and serial fallback; they must not be added to worker time as independent work.

| Static K=8, profiled | Total owner | Shared capture | Setup/window | Submission | Publication | Deadline wait | Worker calculation |
|---|---:|---:|---:|---:|---:|---:|---:|
'''
for when in ['before','after']:
 rs=[r for r in rows if r['file'].startswith('static-'+when+'-profile1') and r['mode']=='snapshot_delayed']
 s+='| '+when+' | '+' | '.join(f'{med(rs,k):.3f}' for k in ['owner_ns','capture_ns','allocation_ns','submission_ns','publication_ns','deadline_wait_ns','calculation_ns'])+' |\n'
for when in ['before','after']:
 rs=[r for r in rows if r['file'].startswith('static-'+when+'-profile0') and r['mode']=='snapshot_delayed']
 s+=f'\nUnprofiled static {when} owner median: {med(rs,"owner_ns"):.3f} us.\n'
s+='''
Publication decreased about 13% in this paired static workload (1.00 → 0.87 us). Aggregate-window capture slightly increases setup and worker reduction replaces owner work, so total owner time remains essentially unchanged (~7 us). This remains an update/reducer, not a pointer-only append.

| AI matches, 2 workers | K | Total owner | Shared capture extraction | Setup/window | Submission | Publication | Deadline wait | Worker calculation |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
'''
for teams in [2,4]:
 for delay in [0,1,2,8]:
  rs=[r for r in rows if r['file'].startswith('advancing-after-profile1') and r['ai']=='numbi-castor' and r['teams']==teams and r['workers']==2 and r['delay']==delay]
  s+=f'| {teams} teams | {delay} | '+' | '.join(f'{med(rs,k):.3f}' for k in ['owner_ns','capture_ns','stats_allocation_ns','stats_submission_ns','stats_publication_ns','stats_deadline_wait_ns','stats_worker_ns'])+' |\n'
s+='''
Short deadlines exposed substantial waiting with the existing shared executor: K=1 ~47–53 us/tick; K=2 ~7–18 us/tick in these AI cases, despite calculation time being much shorter. With workers enabled, deferred joins wait for completion; the queue includes other non-preemptible engine jobs. These observations do not isolate backlog versus host scheduling, and no executor behavior was changed in this follow-up. Keep default 8; smaller K remains configurable. Changing K can change AI orders/trajectories, so whole-match numbers are not causal before/after speedup estimates.
'''
checks=collections.defaultdict(set)
for r in rows:
 if r['file'].startswith('advancing'):checks[r['ai'],r['teams'],r['delay']].add(r['checksum'])
assert all(len(c)==1 for c in checks.values())
(root/'verification.md').write_text(s)
