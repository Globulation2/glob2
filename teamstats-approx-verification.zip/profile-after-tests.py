import time,subprocess
from pathlib import Path
while not Path('artifacts/teamstats/approx/verification-ready').exists():time.sleep(2)
subprocess.run(['python3','artifacts/teamstats/approx/profile.py'],check=True)
