import os,subprocess,json
from pathlib import Path
root=Path('artifacts/teamstats/approx'); env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_PERF_DISABLE='1',GLOB2_STATS_BENCHMARK='1',GLOB2_STATS_BENCHMARK_TICKS='2048',GLOB2_USER_DATA_DIR=str((root/'profile-user').resolve()))
exe=str((root/'glob2-engine-tests').resolve());before=str((root/'before-engine-tests').resolve())
for trial in range(5):
 for prof in [1,0]:
  e=dict(env,GLOB2_STATS_PROFILE=str(prof))
  for name,binary in [('before',before),('after',exe)]:
   with open(root/f'static-{name}-profile{prof}-{trial}.log','w') as out:subprocess.run([binary,'--test-suite=TeamStatsPipeline','--test-case=pipeline versus*'],env=e,stdout=out,stderr=subprocess.STDOUT,check=True)
  with open(root/f'advancing-after-profile{prof}-{trial}.log','w') as out:subprocess.run([exe,'--test-suite=TeamStatsPipeline','--test-case=advancing match statistics timing*'],env=e,stdout=out,stderr=subprocess.STDOUT,check=True)
# Short-delay static cases, opt-in timings; default-delay comparison above remains identical.
for delay in [1,2]:
 for trial in range(5):
  with open(root/f'static-k{delay}-{trial}.log','w') as out:subprocess.run([exe,'--test-suite=TeamStatsPipeline','--test-case=pipeline versus*'],env=dict(env,GLOB2_STATS_PROFILE='1',GLOB2_STATS_BENCHMARK_DELAY=str(delay)),stdout=out,stderr=subprocess.STDOUT,check=True)
with open(root/'advancing-traces.log','w') as out:subprocess.run([exe,'--test-suite=TeamStatsPipeline','--test-case=advancing match statistics timing*'],env=dict(env,GLOB2_STATS_PROFILE='0',GLOB2_STATS_BENCHMARK_TICKS='520',GLOB2_STATS_BENCHMARK_CHECKSUM='1'),stdout=out,stderr=subprocess.STDOUT,check=True)
rows=[]
for path in root.glob('*-profile*-*.log'):
 for line in path.read_text().splitlines():
  if line.startswith(('STATS_BENCH ','STATS_ADVANCING ')):
   row=dict(x.split('=',1) for x in line.split()[1:]);row={k:int(v) if v.isdigit() else v for k,v in row.items()};row['file']=path.name;rows.append(row)
(root/'profiles.json').write_text(json.dumps(rows,indent=2)+'\n')
