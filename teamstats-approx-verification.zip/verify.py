import subprocess,time,os,json
from pathlib import Path
while 'scons: done building targets.' not in Path('/tmp/stats-approx-debug-build.log').read_text(): time.sleep(2)
base=['python3','test/run_tests.py','--build-dir','build/darwin/client/debug/dev-dev_fast-true-linker-auto','--binary','all','--no-display','--timeout','600','-j','2']
with open('artifacts/teamstats/approx/correctness.log','w') as out:
 subprocess.run(base+sum((['--filter',x+'/*'] for x in ['ComputeExecutor','ReadOnlyPhase','WorldSnapshot','TeamStatsPipeline','TeamStatsSave','AIPipeline','MCP']),[])+['--junit','artifacts/teamstats/approx/correctness.xml'],stdout=out,stderr=subprocess.STDOUT,check=True)
for update in [True,False]:
 name='golden-update' if update else 'golden-verify'
 with open('artifacts/teamstats/approx/'+name+'.log','w') as out: subprocess.run(base+['--filter','TurnEngineHarness/the committed*','--junit','artifacts/teamstats/approx/'+name+'.xml']+(['--update-fixtures'] if update else []),stdout=out,stderr=subprocess.STDOUT,check=True)
while 'scons: done building targets.' not in Path('/tmp/stats-approx-release-build.log').read_text(): time.sleep(2)
args=json.loads(Path('artifacts/teamstats/efficient/release-integrated-link-args.json').read_text());args[2]='artifacts/teamstats/approx/glob2-engine-tests';subprocess.run(args,check=True)
Path('artifacts/teamstats/approx/release/test').mkdir(parents=True,exist_ok=True)
link=Path('artifacts/teamstats/approx/release/test/glob2-engine-tests')
if not link.exists():link.symlink_to('../../glob2-engine-tests')
with open('artifacts/teamstats/approx/release-correctness.log','w') as out:
 subprocess.run(['python3','test/run_tests.py','--build-dir','artifacts/teamstats/approx/release','--binary','engine','--no-display','--timeout','600','-j','2']+sum((['--filter',x+'/*'] for x in ['WorldSnapshot','TeamStatsPipeline','TeamStatsSave','AIPipeline']),[])+['--junit','artifacts/teamstats/approx/release-correctness.xml'],stdout=out,stderr=subprocess.STDOUT,check=True)
Path('artifacts/teamstats/approx/verification-ready').write_text('passed\n')
