set pagination off
set confirm off
python
import gdb
active=None
position=0
class Save(gdb.Breakpoint):
 def stop(self):
  global active,position
  active=int(gdb.parse_and_eval('$rsi'));position=0
  gdb.write('SAVE START stream '+hex(active)+'\n')
  return False
class Write(gdb.Breakpoint):
 def __init__(self,func,bulk=False):
  super().__init__("*'"+func+"'");self.bulk=bulk
 def stop(self):
  global position
  if active!=int(gdb.parse_and_eval('$rdi')):return False
  size=int(gdb.parse_and_eval('$rdx'))*(2 if self.bulk else 1)
  if position+size>=1032900 and position<1033150:
   try:
    length=int(gdb.parse_and_eval('$rcx'));ptr=int(gdb.parse_and_eval('$r8'))
    name=bytes(gdb.selected_inferior().read_memory(ptr,min(length,100))).decode(errors='replace')
   except Exception as e:name=str(e)
   gdb.write(f'FIELD {position} size {size} name {name!r}\n')
  position+=size
  return False
Save("*'Game::save'")
Write('GAGCore::BinaryOutputStream::write')
Write('GAGCore::BinaryOutputStream::writeEndianIndependent')
Write('GAGCore::BinaryOutputStream::writeUint16Sections',True)
end
run
