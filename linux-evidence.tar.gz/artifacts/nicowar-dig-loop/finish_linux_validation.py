from pathlib import Path
import subprocess,json,os,time,hashlib,traceback
p=Path(__file__).resolve().parent;root=p.parents[1];os.chdir(root)
status=p/'validation-status.json'
try:
 status.write_text(json.dumps({'stage':'waiting for initial release build'}))
 pid=int((p/'release-build.pid').read_text())
 while True:
  try:os.kill(pid,0)
  except ProcessLookupError:break
  time.sleep(15)
 assert 'scons: done building targets.' in (p/'release-build.log').read_text(),'Initial release build failed'
 subprocess.run(['git','fetch','/home/bradley/nicowar-dig-fix-final.bundle','HEAD'],check=True)
 subprocess.run(['git','checkout','--detach','e65b48024143f15b6fe683e820f19d961b3c2a4e'],check=True)
 env=os.environ.copy();env['GLOB2_SDL3_PREFIX']='/home/bradley/glob2-hiring-cohort-20261013/build/sdl3/prefix'
 status.write_text(json.dumps({'stage':'building final clean head'}))
 for targets,logname in [(['engine-tests'],'release-final-build.log'),([],'release-client-build.log')]:
  with (p/logname).open('w') as log:subprocess.run(['python3','tools/dev_build.py','dev_fast=0','release=1','linker=auto','pch=0','unity=0','-j6',*targets],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 status.write_text(json.dumps({'stage':'running final native checks'}))
 cmd=['python3','test/run_tests.py','--build-dir','build/linux/client/release/dev-linker-auto','--binary','engine','--no-display','--junit',str(p/'linux-tests.xml'),'--artifacts',str(p/'linux-tests')]
 for pattern in ['AIRecoveryCoverage/*','AIStateContinuation/*','AISavePortability/*','AIRules/*','AICustomCatalog/*','LegacyAIState/*','MatchSetup/*','TurnEngineHarness/the committed match record*']:cmd+=['--filter',pattern]
 with (p/'linux-tests.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
 verify=['build/linux/client/release/dev-linker-auto/src/glob2','match','verify','test/fixtures/multiplayer/FourSquares1.g2mr','--map-file','maps/FourSquares1.map.gz','--output-dir',str(p/'golden-cli'),'--compute-threads','4']
 with (p/'golden-cli.log').open('w') as log:subprocess.run(verify,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 assert (p/'golden-cli/checksums.txt').read_bytes()==Path('test/fixtures/multiplayer/FourSquares1.verify-trace.txt').read_bytes()
 subprocess.run(['python3','test/check_sim_revision.py','--base','277510840054b1416f2defd7d86fe1431dd0ddc0'],check=True)
 status.write_text(json.dumps({'stage':'complete','passed':True,'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'test_command':cmd,'verify_command':verify,'golden_trace_sha256':hashlib.sha256((p/'golden-cli/checksums.txt').read_bytes()).hexdigest()},indent=2));print('Clean final Linux release validation passed',flush=True)
except Exception as e:
 status.write_text(json.dumps({'stage':'failed','error':str(e),'traceback':traceback.format_exc()},indent=2));raise
