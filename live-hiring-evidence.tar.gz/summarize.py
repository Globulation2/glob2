import json,statistics,random
from pathlib import Path
p=Path('artifacts/hiring-study/live-measurement');out=p/'measurements';rows=[json.loads(x) for x in (out/'samples.jsonl').read_text().splitlines()];rng=random.Random(713)
def pair(values):
 ratio=[b/a for a,b in values];boots=sorted(statistics.median(rng.choices(ratio,k=len(ratio))) for _ in range(10000));return {'samples':len(ratio),'baseline_median':statistics.median(a for a,b in values),'trial_median':statistics.median(b for a,b in values),'median_ratio':statistics.median(ratio),'ratio_95_ci':[boots[250],boots[9750]],'paired_ratios':ratio}
report={'protocol':json.loads((out/'metadata.json').read_text()),'workloads':[],'limitations':['Isolated material-only ground live consumer in a real Game.syncStep harness; no shipped live option, saves/replays/network or realistic full economy.','Owner-side batch times come from separate diagnostics, which add instrumentation overhead; undiagnosed timing supplies total CPU/elapsed/p95 evidence.','Cohort delay excludes right-censored final wave and prewarmup waves; repeated unmet demand and actual delivered wheat reported separately.','Total time includes admitted-work drain without early publication. Artificial demand/availability reset every64ticks on the churn case.','Main branch only fixes scheduled pruning options; cold initialization, empty-generation admission and live consumption are retained measurement patches.','macOS arm64 only. No cross-platform game equivalence, sanitizer, hunger/health/attraction/markets/flying gameplay qualification or production persistence validation.','Any groups overlapping observed compiler/test activity excluded and retained with reasons. Other background host activity uncontrolled.']}
for workload in ['steady','churn']:
 chosen=[r for r in rows if r['workload']==workload and r['repetition']>=0 and not r['rejected_group']];by={}
 for r in chosen:by.setdefault(r['repetition'],{})[r['mode']]=r['result']
 assert len(by)==10 and all(len(v)==4 for v in by.values())
 comparisons={}
 for mode in ['shadow','owner','pool']:
  comparisons[mode]={metric:pair([(v['original'][metric],v[mode][metric]) for v in by.values()]) for metric in ['cpu_ns','elapsed_ns','tick_p50_ns','tick_p95_ns']}
 outputs={mode:{key:sorted(set(v[mode][key] for v in by.values())) for key in ['hires','wheat_delivered','final_wheat_stock','cohorts_filled','cohorts_unfilled_before_next_wave','cohort_p95_ticks','minimum_population']} for mode in ['original','shadow','owner','pool']}
 diag={}
 for mode in ['original','shadow','owner','pool']:
  d=out/f'{workload}-{mode}-diagnostics';result=json.loads((d/'result.json').read_text());stats=json.loads((d/'hiring-stats.json').read_text());pipeline=json.loads((d/'hiring-study.json').read_text())
  diag[mode]={'owner_tasks_ns':result['owner_tasks_ns'],'capture_submit_ns':result['capture_submit_ns'],'publication_ns':result['publication_ns'],'population_scan_visits':sum(b['counters']['visits'] for b in stats['buildings']),'suggestions_examined':result['suggestions_examined'],'pipeline':{k:pipeline.get(k) for k in ['submitted','published','deadline_wait_ns','owner_jobs','worker_jobs','peak_accounted_bytes','planning_ns','supplement_ns']}}
 report['workloads'].append({'workload':workload,'comparisons_against_original':comparisons,'output_counts':outputs,'separate_diagnostics':diag})
report['rejected_timing_groups']=sum(r['rejected_group'] for r in rows)//4
report['determinism']=json.loads((p/'verification/verification.json').read_text())['deterministic_across_participants']
(p/'findings.json').write_text(json.dumps(report,indent=2))
for w in report['workloads']:
 print(w['workload'])
 for mode,m in w['comparisons_against_original'].items():print(mode,{k:round(v['median_ratio'],4) for k,v in m.items()})
 print('counts',w['output_counts']);print('diagnostics',w['separate_diagnostics'])
