#include "GlobalContainer.h"
#include "GameGUI.h"
#include "Game.h"
#include "Unit.h"
#include "Team.h"
#include "Building.h"
#include "BuildingType.h"
#include "IntBuildingType.h"
#include "Race.h"
#include "HiringStudy.h"
#include "HiringDiagnostics.h"
#include "LiveHiringTrial.h"
#include <nlohmann/json.hpp>
#include <fstream>
#include <iostream>
#include <filesystem>
#include <algorithm>
#include <ctime>
#include <span>
GlobalContainer* globalContainer=nullptr;
int main(int argc,char** argv)try {
 if(argc!=7)throw std::invalid_argument("workload steady|churn, mode original|shadow|owner|pool, participants, measured ticks, diagnostics0|1, output");
 const std::string workload=argv[1],mode=argv[2];const unsigned participants=std::stoul(argv[3]),ticks=std::stoul(argv[4]);const bool diagnostic=std::stoul(argv[5]);
 if((workload!="steady"&&workload!="churn") || (mode!="original"&&mode!="shadow"&&mode!="owner"&&mode!="pool"))throw std::invalid_argument("Unknown control");
 const std::filesystem::path output=argv[6];if(std::filesystem::exists(output))throw std::invalid_argument("Existing output");std::filesystem::create_directories(output);
 GlobalContainer globals;globalContainer=&globals;globals.runNoX=true;globals.settings.rememberUnit=false;
 globals.buildingsTypes.init();IntBuildingType::init();Race::loadDefault();GameGUI gui(false);auto& game=gui.game;
 game.map.setSize(7,7,GRASS);game.map.setGame(&game);
 for(int t=0;t<2;++t){game.addTeam(t);game.teams[t]->race.loadDefault();}
 GameHeader header;header.setNumberOfPlayers(2);header.setRandomSeed(713);
 for(int t=0;t<2;++t)header.getBasePlayer(t)=BasePlayer(t,"hiring live measurement",t,BasePlayer::playerTypeFromImplementationID(AI::NONE));
 game.setGameHeader(header,true);game.map.setMapDiscovered();game.setWaitingOnMask(0);
 const int type=game.buildingsTypes.getTypeNum("inn",0,false);std::vector<Building*> buildings;
 for(int t=0;t<2;++t){game.teams[t]->startPosX=t*64+4;game.teams[t]->startPosY=4;
  for(int n=0;n<24;++n){auto* b=game.addBuilding(t*64+3+(n%8)*7,40+(n/8)*9,type,t,4,4);if(!b)throw std::runtime_error("Building placement");
   b->priority=workload=="churn"?(n%3)-1:0;buildings.push_back(b);
   if(b->runtime->attractionRoles || b->type->runtimeFlyingCarriers)throw std::runtime_error("Unsupported building/air trial");
   for(int material=0;material<MaterialSlotCount;++material)b->materials[material]=b->type->maxMaterial[material];b->materials[WHEAT]=0;b->updateCallLists();
  }
  for(int y=85;y<120;++y)for(int x=t*64+1;x<t*64+60;x+=3)for(int n=0;n<20;++n)game.map.incResourceByIndex(x,y,WHEAT,0);
  for(int n=0;n<600;++n){auto* u=game.addUnit(t*64+1+n%60,4+n/60,t,WORKER,0,n%256,0,0);if(!u)throw std::runtime_error("Worker placement");u->hungry=u->trigHungry+u->hungriness*8192;u->medical=Unit::MED_FREE;}
  game.teams[t]->createLists();
 }
 game.map.configureGradientPipeline(participants,8);game.map.configureCompute(participants);
 LiveHiringTrial::active=mode=="pool"||mode=="owner";
 if(mode!="original")HiringStudy::configureScheduled({.delay=4,.refresh=4,.capacity=128,.parallel=mode!="owner",.extras=2,.availableOnly=true,.coordinate=true});
 else HiringStudy::configure(false);
 // Initial observation precedes the first team step, as the normal engine.
 game.captureReadBoundary({},false);
 std::vector<std::uint64_t> durations;std::vector<unsigned> delays;
 std::vector<bool> completed(buildings.size());unsigned waveTick=0,cohorts=0,unfilled=0;int minimum=1200;
 std::uint64_t delivered=0,cpuStart=0;std::chrono::steady_clock::time_point wallStart;std::vector<Uint32> checksums;
 const unsigned warmup=256,total=warmup+ticks;
 for(unsigned tick=0;tick<total;++tick){
  if(workload=="churn" && tick%64==63){
   if(tick>=warmup)for(unsigned b=0;b<buildings.size();++b)if(!completed[b])++unfilled;
   waveTick=tick;std::fill(completed.begin(),completed.end(),false);
   for(int t=0;t<2;++t)for(auto* u:game.teams[t]->liveUnits.entries()){
    if(u->attachedBuilding)u->attachedBuilding->removeUnitFromWorking(u);
    u->standardRandomActivity();u->carriedMaterial=-1;u->hungry=u->trigHungry+u->hungriness*8192;u->medical=Unit::MED_FREE;
   }
   for(auto* b:buildings){for(int m=0;m<MaterialSlotCount;++m)b->materials[m]=b->type->maxMaterial[m];b->materials[WHEAT]=0;b->updateCallLists();}
   // Wave is injected on a non-admission boundary; boundary t+1 captures it.
   game.snapshotStore().invalidateBoundary();
  }
  if(tick==warmup){LiveHiringTrial::ns.fill(0);LiveHiringTrial::examined=LiveHiringTrial::missing=LiveHiringTrial::rejected=LiveHiringTrial::destinationFailures=LiveHiringTrial::hires=0;
   LiveHiringTrial::collect=diagnostic;HiringDiagnostics::configure(diagnostic);cpuStart=std::clock();wallStart=std::chrono::steady_clock::now();}
  std::vector<int> beforeFood;for(auto* b:buildings)beforeFood.push_back(b->materials[WHEAT]);
  const auto start=std::chrono::steady_clock::now();game.syncStep(0);
  if(tick>=warmup)for(unsigned bi=0;bi<buildings.size();++bi)delivered+=std::max(0,buildings[bi]->materials[WHEAT]-beforeFood[bi]);
  if(tick>=warmup)durations.push_back(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count());
  for(unsigned bi=0;bi<buildings.size();++bi)if(!completed[bi] && buildings[bi]->unitsWorking.size()>=4){completed[bi]=true;if(waveTick>=warmup && waveTick+8<total){delays.push_back(tick-waveTick);++cohorts;}}
  int population=0;for(int t=0;t<2;++t)population+=game.teams[t]->liveUnits.size();minimum=std::min(minimum,population);
  if(diagnostic)checksums.push_back(game.checkSum(nullptr,nullptr,nullptr,true));
 }
 // Account for all admitted computation; do not publish future outputs early.
 const auto drainStart=std::chrono::steady_clock::now();HiringStudy::drain(game);
 const auto endingDrain=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-drainStart).count();
 const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-wallStart).count();
 const auto cpu=std::uint64_t((std::clock()-cpuStart)*1000000000.0/CLOCKS_PER_SEC);
 LiveHiringTrial::collect=false;
 std::sort(durations.begin(),durations.end());std::sort(delays.begin(),delays.end());
 const auto percentile=[](const auto& v,unsigned p)->std::uint64_t{return v.empty()?0:v[(v.size()*p+99)/100-1];};
 int finalFood=0;for(auto* b:buildings)finalFood+=b->materials[WHEAT];
 nlohmann::json result={{"scope","Isolated real-simulation material-only live consumer; no save/replay/network support; original rounds and swaps retained"},{"workload",workload},{"mode",mode},{"participants",participants},{"warmup",warmup},{"ticks",ticks},{"diagnostics",diagnostic},{"cpu_ns",cpu},{"elapsed_ns",elapsed},{"tick_p50_ns",percentile(durations,50)},{"tick_p95_ns",percentile(durations,95)},{"owner_tasks_ns",LiveHiringTrial::ns[LiveHiringTrial::Tasks]},{"capture_submit_ns",LiveHiringTrial::ns[LiveHiringTrial::Capture]},{"publication_ns",LiveHiringTrial::ns[LiveHiringTrial::Publication]},{"ending_drain_ns",endingDrain},{"hires",LiveHiringTrial::hires},{"wheat_delivered",delivered},{"final_wheat_stock",finalFood},{"suggestions_examined",LiveHiringTrial::examined},{"missing_lists",LiveHiringTrial::missing},{"rejections",LiveHiringTrial::rejected},{"destination_failures",LiveHiringTrial::destinationFailures},{"cohorts_filled",cohorts},{"cohorts_unfilled_before_next_wave",unfilled},{"cohort_p95_ticks",percentile(delays,95)},{"cohort_max_ticks",percentile(delays,100)},{"minimum_population",minimum},{"final_checksum",game.checkSum(nullptr,nullptr,nullptr,true)}};
 if(diagnostic){std::ofstream trace(output/"checksums.json");trace<<nlohmann::json(checksums).dump();std::ofstream phase(output/"hiring-stats.json");HiringDiagnostics::write(phase);std::ofstream pipeline(output/"hiring-study.json");HiringStudy::write(pipeline);}
 std::ofstream report(output/"result.json");report<<result.dump(2)<<'\n';
 HiringStudy::clear(game);HiringStudy::configure(false);HiringDiagnostics::configure(false);return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
