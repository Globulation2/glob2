import json,subprocess,hashlib
from pathlib import Path
p=Path('artifacts/hiring-study/live-measurement').resolve();out=p/'verification';out.mkdir(exist_ok=False);results=[]
for workload in ['steady','churn']:
 for mode in ['original','shadow','owner','pool']:
  expected=None
  for n in [1,2,4,8]:
   dest=out/f'{workload}-{mode}-{n}';cmd=[str(p/'hiring-live'),workload,mode,str(n),'1024','1',str(dest)]
   with (out/(dest.name+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
   r=json.loads((dest/'result.json').read_text());digest=hashlib.sha256((dest/'checksums.json').read_bytes()).hexdigest()
   pipeline=None
   if (dest/'hiring-study.json').exists():pipeline=json.loads((dest/'hiring-study.json').read_text()).get('output_digest')
   identity=(digest,pipeline)
   if expected is None:expected=identity
   assert expected==identity,(workload,mode,n,'nondeterminism')
   assert r['minimum_population']==1200
   if workload=='churn':assert r['cohorts_filled']==720 and r['cohorts_unfilled_before_next_wave']==0 and r['cohort_p95_ticks']<=8
   results.append({'command':cmd,'result':r,'trace_sha256':digest,'pipeline_digest':pipeline});print(workload,mode,n,r['hires'],r['cohort_p95_ticks'],flush=True)
(out/'verification.json').write_text(json.dumps({'deterministic_across_participants':True,'results':results},indent=2))
