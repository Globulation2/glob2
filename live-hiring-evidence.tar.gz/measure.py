import subprocess,json,time,hashlib,platform
from pathlib import Path
p=Path('artifacts/hiring-study/live-measurement').resolve();out=p/'measurements';out.mkdir(exist_ok=False)
def busy():
 s=subprocess.check_output(['ps','-axo','command'],text=True)
 return any((l.startswith('/Applications/Xcode') and 'clang -cc1 ' in l) or (l.startswith('/') and ' -c ' not in l and ('engine-tests ' in l or 'unit-tests ' in l or '--test-suite=' in l or '--test-case=' in l)) or (l.startswith('/opt/homebrew/') and ' test/run_tests.py ' in l) for l in s.splitlines())
metadata={'source_baseline':'dda12cd3be7d7e21296da109a996a99921c78f71','source_diff':subprocess.check_output(['git','diff'],text=True),'host':platform.platform(),'machine':platform.machine(),'binary_sha256':hashlib.sha256((p/'hiring-live').read_bytes()).hexdigest(),'protocol':'one warmup plus ten four-control rotated paired repetitions, 256 warmup ticks+1024 measured real Game.syncStep ticks, four participants. No diagnostics/checksum exports in timing. End drain included without early publication. Material-only ground fixtures; no saves/replays/network/live game option.','limitations':['Simulation-only harness, no rendering/AI/network and no broad economy qualification.','Churn resets demand/availability every64ticks on a nonadmission boundary. All nonwheat service stock remains full.','Incomplete last wave censored in staffing latency. Hires and actual delivered wheat also recorded.','Host uncontrolled; pause while compiler/test processes detected. Reject any pair overlapping detected activity.']}
(out/'metadata.json').write_text(json.dumps(metadata,indent=2));rows=[]
with (out/'samples.jsonl').open('w') as log:
 for rep in range(-1,10):
  for workload in ['steady','churn']:
   attempt=0
   while True:
    while busy():print('waiting for host build/test activity',flush=True);time.sleep(5)
    modes=['original','shadow','owner','pool'];rotation=(rep+1)%4;modes=modes[rotation:]+modes[:rotation]
    sample=[]
    for mode in modes:
     dest=out/f'{workload}-{mode}-r{rep}-a{attempt}';cmd=[str(p/'hiring-live'),workload,mode,'4','1024','0',str(dest)]
     activeBefore=busy()
     with (out/(dest.name+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
     r=json.loads((dest/'result.json').read_text());sample.append({'repetition':rep,'attempt':attempt,'workload':workload,'mode':mode,'command':cmd,'host_activity_detected':activeBefore or busy(),'result':r})
    rejected=any(r['host_activity_detected'] for r in sample)
    for r in sample:r['rejected_group']=rejected;log.write(json.dumps(r)+'\n');log.flush();rows.append(r)
    if rejected:print('retaining and rejecting host-contaminated group',rep,workload,attempt,flush=True);attempt+=1;continue
    print(rep,workload,[(r['mode'],r['result']['cpu_ns'],r['result']['elapsed_ns']) for r in sample],flush=True);break
 # Diagnostic pass after timing; broad counters stay out of timing.
 for workload in ['steady','churn']:
  for mode in ['original','shadow','owner','pool']:
   dest=out/f'{workload}-{mode}-diagnostics';cmd=[str(p/'hiring-live'),workload,mode,'4','1024','1',str(dest)]
   with (out/(dest.name+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
