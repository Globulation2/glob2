from pathlib import Path
import subprocess,shlex,json
p=Path('artifacts/hiring-study/live-measurement').resolve()
# Isolated instrumentation/replacement. No live mode is compiled into the app.
for source in ['src/building/Step.cpp','src/building/HiringStudy.cpp','src/team/TeamStep.cpp','src/game/GameAI.cpp']:
 s=Path(source).read_text();s='#include "LiveHiringTrial.h"\n'+s
 if source.endswith('HiringStudy.cpp'):
  marker='bool enabled(){return collectingStudy;}'
  accessor='''namespace LiveAccessor {
const HiringPlanner::BuildingLists* get(const Building& b) {
 if(!session || session->game!=b.owner->game || !session->schedule)return nullptr;
 const auto team=b.owner->teamNumber;if(session->history[team].empty())return nullptr;
 for(const auto& lists:session->history[team].back()->buildings)
  if(lists.building==Game::refOf(&b) && lists.type==b.typeNum && lists.configuration==HiringPlanner::configuration(b))return &lists;
 return nullptr;
}
}
'''
  s=s.replace(marker,accessor+marker).replace('{ if(session && session->game==&game && session->schedule)session->joinDue(game.stepCounter); }','{ LiveHiringTrial::Scope scope(LiveHiringTrial::Publication); if(session && session->game==&game && session->schedule)session->joinDue(game.stepCounter); }')
  s=s.replace('auto& work=*static_cast<Work*>(context);','auto& work=*static_cast<Work*>(context);if(work.output)return;')
  demand="""bool trialDemand(const Game& game,unsigned team) {
 for(auto* b:std::span(game.teams[team]->myBuildings,Building::MAX_COUNT))
  if(b && b->buildingState==Building::ALIVE && b->desiredMaxUnitWorking>0 && b->unitsWorking.size()<unsigned(b->desiredMaxUnitWorking))
   for(unsigned m=0;m<MaterialCount;++m)if(b->materialDeliveryNeed(m)>0)return true;
 return false;
}
"""
  s=s.replace('bool enabled(){return collectingStudy;}',demand+'bool enabled(){return collectingStudy;}')
  s=s.replace('admit|=game.stepCounter%selectedSchedule->refresh==unsigned(t)%selectedSchedule->refresh;','admit|=game.stepCounter%selectedSchedule->refresh==unsigned(t)%selectedSchedule->refresh && (!LiveHiringTrial::active || trialDemand(game,t));')
  key='            if(!inputs){const auto start=std::chrono::steady_clock::now();inputs=HiringPlanner::capture(game,world);'
  empty="""            if(LiveHiringTrial::active && !trialDemand(game,team)) {
                auto work=std::make_unique<Work>();work->team=team;work->cache=session->caches[team].get();
                auto result=std::make_shared<Output>();result->tick=world.tick;result->team=team;result->metrics.refreshes=1;
                work->output=result;work->outputBound=sizeof(Output);batch->jobs.push_back(std::move(work));continue;
            }
"""
  s=s.replace(key,empty+key)
  s='#include <span>\n'+s
  s+='\nconst HiringPlanner::BuildingLists* LiveHiringTrial::suggestions(const Building& b) {return HiringStudy::LiveAccessor::get(b);}\n'
 elif source.endswith('TeamStep.cpp'):
  s=s.replace('void Team::updateAllBuildingTasks()\n{','void Team::updateAllBuildingTasks()\n{\n LiveHiringTrial::Scope scope(LiveHiringTrial::Tasks);')
 elif source.endswith('GameAI.cpp'):
  preparation=''' LiveHiringTrial::Scope scope(LiveHiringTrial::Capture);
 if(LiveHiringTrial::active && HiringStudy::requirements(*this,paused)) {
  // The controlled harness permits ground material-only inns (movement class0).
  // Initialize existing lazy fields here; never borrow an absent generation.
  for(int t=0;t<teamsCount();++t) {
   bool resourceNeeded=false;
   for(auto* b:std::span(teams[t]->myBuildings,Building::MAX_COUNT))if(b && b->buildingState==Building::ALIVE &&
      b->unitsWorking.size()<unsigned(b->desiredMaxUnitWorking) && b->materialDeliveryNeed(WHEAT)>0) {
    const_cast<Game*>(this)->map.buildingGradient(b,0,BuildingRoute::Footprint);resourceNeeded=true;
   }
   if(resourceNeeded)const_cast<Game*>(this)->map.getMaterialGradientSlot(t,WHEAT,0);
  }
 }
 auto world=worldSnapshots.captureBoundary(*this,requirements);'''
  s=s.replace(' auto world=worldSnapshots.captureBoundary(*this,requirements);',preparation)
  s='#include "Team.h"\n#include "Building.h"\n#include <span>\n'+s
 else:
  start=s.index('\t// A unit already holding something we want delivers',s.index('bool Building::hireMaterialUnit('));end=s.index('\n\tif (sel.choosen)\n',start)
  old=s[start:end]
  replacement='''
 bool delivery=false;
 if(LiveHiringTrial::active) {
  const auto* lists=LiveHiringTrial::suggestions(*this);
  if(!lists){++LiveHiringTrial::missing;return false;}
  const auto choose=[&](Hiring::Job job,int material) {
   if(!wantsAnotherDelivery(material,targets,served))return false;
   for(const auto& list:lists->jobs)if(list.key==Hiring::Key{job,material})
    for(const auto* pool:{&list.combined,&list.available,&list.busy})for(const auto& suggestion:*pool) {
     ++LiveHiringTrial::examined;
     auto* u=owner->game->resolveUnit(suggestion.unit);
     if(!u || u->owner!=owner || !u->hasCapability(UnitRuntimeTraits::Transport) || !u->performance[BUILD] ||
        u->activity!=Unit::ACT_RANDOM || u->medical!=Unit::MED_FREE){++LiveHiringTrial::rejected;continue;}
     int distance=0;
     if(job==Hiring::Job::Delivery) {
      if(!u->hasDeliverableCargo(*this,material) || !considerUnitForBuilding(u,&distance)){++LiveHiringTrial::rejected;continue;}
     }else {
      if(!u->performance[HARVEST] || u->hasCarriedMaterial(material) || !considerUnitForMaterial(u,material,&distance)){++LiveHiringTrial::rejected;continue;}
      Sint32 x=0,y=0;
      if(!u->findMaterialDestination(material,&x,&y,nullptr,fetchesFromMarkets(),this)){++LiveHiringTrial::destinationFailures;continue;}
     }
     u->destinationPurpose=material;sel.choosen=u;return true;
    }
   return false;
  };
  // This harness only permits material-only buildings. Surrounding quotas,
  // priority buckets, fair rounds, normal subscription and swaps stay intact.
  for(int material=0;material<MaterialSlotCount && !sel.choosen;++material)
   if(choose(Hiring::Job::Delivery,material))delivery=true;
  if(!sel.choosen) {
   int order[MaterialSlotCount];const auto count=FetchApportionment::rank(targets,served,MaterialSlotCount,order);
   for(int i=0;i<count && !sel.choosen;++i)choose(Hiring::Job::Fetch,order[i]);
  }
 }else {
'''
  old=old.replace('const bool delivery=sel.choosen!=nullptr;','delivery=sel.choosen!=nullptr;')
  s=s[:start]+replacement+old+'\n }\n'+s[end:]
  s=s.replace('\tif (sel.choosen)\n\t{\n\t\tHiringDiagnostics::hired','\tif (sel.choosen)\n\t{\n        ++LiveHiringTrial::hires;\n\t\tHiringDiagnostics::hired',1)
 target=p/Path(source).name;target.write_text(s)
# Reuse only matching baseline objects; compile changed TUs with the original
# ordinary release command/flags and replace just those objects at linkage.
log=Path('artifacts/hiring-study/quotas/integrated-build.log').read_text().splitlines()
commands=[];replacements={}
for source in ['src/building/Step.cpp','src/building/HiringStudy.cpp','src/team/TeamStep.cpp','src/game/GameAI.cpp']:
 line=next(l for l in log if l.startswith('/opt/homebrew/bin/ccache g++ ') and l.endswith(' '+source))
 args=shlex.split(line);dest=str(p/(Path(source).stem+'.o'));args[args.index('-o')+1]=dest;args[-1]=str(p/Path(source).name)
 args=[a.replace('\\"','"') if a.startswith('-D') else a for a in args];args+=['-I'+str(p)]
 commands.append(args);replacements['build/darwin/client/release/dev-linker-auto/'+source[:-4]+'.o']=dest
linklog=Path('artifacts/hiring-study/planner-final/baseline-harness-build.log').read_text().splitlines()
link=shlex.split(next(l for l in linklog if l.startswith('g++ -o ') and '/test/HiringStudyHarness ' in l))
compileline=next(l for l in linklog if l.startswith('/opt/homebrew/bin/ccache g++ ') and l.endswith(' test/HiringStudyHarness.cpp'))
args=shlex.split(compileline);args[args.index('-o')+1]=str(p/'Harness.o');args[-1]=str(p/'Harness.cpp');args=[a.replace('\\"','"') if a.startswith('-D') else a for a in args];args+=['-I'+str(p)];commands.append(args)
link=[replacements.get(a,a) for a in link];link[link.index('-o')+1]=str(p/'hiring-live');link[link.index('build/darwin/client/release/dev-linker-auto/test/program-HiringStudyHarness.o')]=str(p/'Harness.o')
(p/'compile-commands.json').write_text(json.dumps(commands,indent=2));(p/'link-command.json').write_text(json.dumps(link,indent=2))
