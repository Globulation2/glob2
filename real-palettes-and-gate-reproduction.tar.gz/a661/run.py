import json,os,subprocess,time,signal
from pathlib import Path
R=Path.cwd();D=R/'artifacts/ci-recovery/music-transition-validation';M=R/'artifacts/ci-recovery/runs/70319a0da0/music';W=R/'artifacts/ci-recovery/music-integration-repair'
REV=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();state=dict(pid=os.getpid(),revision=REV,base='9e903ff54a26b8bb26d67f5359fc4a9b43b8a02e',phase='setup',results=[],container=None)
def save():(D/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def stop(signum,frame):raise SystemExit('interrupted')
signal.signal(signal.SIGTERM,stop);container=None;save()
try:
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=W,text=True).strip(),'source dirty'
 image='sha256:275447c94b11b151decd1f29877965301d5a77032037c46de93d990f739f00a9'
 container=subprocess.check_output(['docker','run','-d','--rm','--pull=never','--name','glob2-ci-music-transition','-e','POSTGRES_USER=glob2','-e','POSTGRES_PASSWORD=glob2','-p','127.0.0.1:55433:5432','--tmpfs','/var/lib/postgresql/data:rw,nosuid,size=2g',image,'-c','max_locks_per_transaction=1024'],text=True).strip();state.update(container=container,postgres_image=image);save()
 for _ in range(120):
  if subprocess.call(['docker','exec',container,'pg_isready','-U','glob2','-d','postgres'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)==0:break
  time.sleep(.5)
 else:raise RuntimeError('DB not ready')
 old=json.loads((M/'canonical-status.json').read_text());cmd=old['command'];cmd=[c for c in cmd if not c.startswith('--outputFile.junit=')];cmd+=['--outputFile.junit='+str(D/'junit.xml')];cmd.insert(cmd.index('npm'),'TEST_DATABASE_URL=postgres://glob2:glob2@127.0.0.1:55433/postgres');cmd.insert(cmd.index('--maxWorkers=1'),'apps/ai-music-worker/test/pipeline.test.ts');cmd=[c.replace('--maxWorkers=1','--maxWorkers=2')for c in cmd]
 state.update(phase='running full original music runner integrations and pipeline tests',command=cmd,note='Originalsandbox/CPUrenderchecksunchangedexceptrequiredtransitioninventory;bothpalettesmustcomplete. Pinnedassets/venvfromcompletedsetupreused,readonlyprivatecanonicalhostlibraries,4GiBtmpfsand12GiBcgroup. Freshisolatednpmci;rootfullbrowser/nativefrozen.');save();start=time.monotonic()
 with(D/'tests.log').open('w')as log:code=subprocess.call(cmd,cwd=W/'platform',stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 state.update(phase='finished; inspect JUnit and both palette artifacts',exit_code=code,seconds=round(time.monotonic()-start,1),palette_evidence=str(W/'artifacts/music-studio-renders'));save()
except BaseException as error:state.update(phase='stopped; inspect error',error=repr(error));save();raise
finally:
 if container:state['container_cleanup_exit_code']=subprocess.call(['docker','rm','-f',container],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);state['container']=None;save()
