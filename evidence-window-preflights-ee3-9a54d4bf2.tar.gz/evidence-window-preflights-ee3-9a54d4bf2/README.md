# Paired fixed-window correctness preflight

Correctness evidence only. All runs overlapped other work; none supplies valid timing evidence.

The original 98-window corpus and three eight-team windows were run against pure upstream ee3 and resource-refactor candidate9a54 (CLI is byte-identical to later a1 fixture-only revision). Arms ran sequentially, each with two jobs. Both arms used their respective data directories and identical frozen inputs/settings.

| Arm | Binary SHA256 |
|---|---|
| baseline | `0d62ae957e9094fa2c5f785c1d068923d11104945897aa2cd01769841e7a054c` |
| candidate | `5d4b5672ebfbdc7eddd5fd49bffad5b3e8a4f0d5c3a1c604ed05c03c19af0e29` |

All 202 original arm/window results have completed terminal records. Three shortened scenarios were rerun with identical fixed prefixes on both arms, all six completing fully:

| Scenario | Baseline actual/original | Candidate actual/original | Validated common ticks |
|---|---:|---:|---:|
| land-2-1002-mixed-late | 8192/8192 | 5346/8192 | 5120 |
| water-2-1001-maxima-late | 7938/8192 | 8192/8192 | 7680 |
| control-land-2-1002-mixed-64-middle | 8192/8192 | 6594/8192 | 6144 |

All other legacy windows completed their original requested length. Both eight-team arms completed all three 2048-tick windows. `legacy-matched-windows.json` and `eight-team-matched-windows.json` are the validated performance inputs; their adjustments retain original manifest hashes and observed endings.

The original wrapper unexpectedly exited143 after 201 completed terminal records; cause unknown. No agent reported a relevant termination action, and inspection found no surviving original processes. The sole unfinished candidate eight-team middle window was rerun in `recovery/unfinished/`. Original partial files were retained. `recovery/provenance.json` lists reused terminal record/log hashes, the rerun, and all paired prefix validations. No partial result was counted complete. Original and final binary, data, resolved shared-library, helper and manifest identities matched.

Commands and logic are preserved in `../run_ee3_window_preflights.py`, `../recover_ee3_window_preflights.py`, per-arm command files, original helper metadata, and recovery per-run command files. Both wrappers used `LD_LIBRARY_PATH=/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib`. Environment digests avoid publishing unrelated credentials. `final-summary.json` is the complete combined result; original `provenance.json` deliberately retains its interrupted state.

## Archive layout

- `accounting.json`: all202 terminal original-window records and six paired-prefix records; requested/actual tick counts, termination, paths and hashes.
- `runs/`: terminal result JSON, corresponding engine log, exact command and accounting for each record. Commands for original runs are transparently reconstructed from the frozen helper/manifest; recovery commands were captured at execution.
- `inputs/`: original unadjusted manifests. Top-level matched manifests include validated adjustments.
- `phase-metadata/`, `provenance.json`, `recovery/provenance.json`: immutable input inventories and interrupted/completed phase records.
- `interruption/`: original exit143 status and preserved unfinished stress-window log/progress; no cause is claimed.
- `tools/`: wrappers, unchanged execution helper and parser/provenance sources needed to reconstruct commands.
- `integrity.json`: SHA256 of every other packaged file.

All timing fields retained in raw result JSON are explicitly INVALID for performance comparisons. No binaries, save files, source trees, profile directories or duplicated fixture payloads are included. Fixture identities and original paths are retained in manifests; this archive alone does not contain the fixtures required to rerun engines.
