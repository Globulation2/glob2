"""Recover verified terminal results after unexplained SIGTERM, without overwrites."""
import concurrent.futures,copy,json,pathlib,sys
from paired_provenance import runtime_snapshot,stable_runtime,environment_snapshot,sha
b=pathlib.Path(__file__).resolve().parent;root=b.parents[1];out=b/'window-preflights-ee3-9a54d4bf2';recovery=out/'recovery';recovery.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'test'))
from benchmark_parallel_compute import execute,digest
p=json.load(open(out/'provenance.json')); variants={k:(pathlib.Path(v['binary']),pathlib.Path(v['cwd'])) for k,v in p['runtime'].items()}
def stable():
 assert all(stable_runtime(runtime_snapshot(*v))==stable_runtime(p['runtime'][k]) for k,v in variants.items())
 assert all(sha(m['path'])==m['sha256'] for m in p['manifests'].values())
 assert sha(b/'preflight_final_windows.py')==p['helper_sha256']
 assert sha(root/'test/benchmark_parallel_compute.py')==p['execute_source_sha256']
stable()
record={'reason':'Original session33586 exited143; cause unknown; no root-directed process signals','timing_valid':False,'original_provenance_sha256':sha(out/'provenance.json'),'environment_sha256':environment_snapshot(),'wrapper_sha256':sha(__file__),'reuse':[],'rerun':[]}
results={};pending=[]
for group,m in p['manifests'].items():
 results[group]={};scenarios=json.load(open(m['path']))['scenarios']
 for arm,(binary,cwd) in variants.items():
  results[group][arm]={}
  for s in scenarios:
   for path,h in s['fixture_sha256'].items():assert digest(path)==h
   directory=out/f'{group}-{arm}'/s['id'];file=directory/'result.json';expected=int(s['args'][s['args'].index('--ticks')+1])-s['start_tick']
   if file.exists():
    r=json.load(open(file));assert r['status']=='completed';actual=r['benchmark_measured_ticks']
    assert 0<actual<=expected and r['ticks']==s['start_tick']+actual
    assert actual==expected or r['termination']=='engine_end'
    row={'scenario':s['id'],'expected_ticks':expected,'actual_ticks':actual,'termination':r['termination'],'timing_valid':False}
    results[group][arm][s['id']]=row
    record['reuse'].append({'group':group,'arm':arm,'scenario':s['id'],'result_sha256':sha(file),'log_sha256':sha(directory/'engine.log'),'terminal_record_validated':True})
   else:pending.append((group,arm,s,expected))
(recovery/'provenance.json').write_text(json.dumps(record,indent=2)+'\n')
def run(job,stage='unfinished'):
 group,arm,s,ticks=job;binary,cwd=variants[arm];directory=recovery/stage/group/arm/s['id']
 row=execute(binary,s['args']+['--benchmark-warmup','0'],directory,cwd=cwd)
 r=row['result'];assert r['status']=='completed';actual=r['benchmark_measured_ticks']
 assert 0<actual<=ticks and r['ticks']==s['start_tick']+actual
 assert actual==ticks or r['termination']=='engine_end'
 (directory/'command.json').write_text(json.dumps({'argv':row['command'],'cwd':str(cwd)},indent=2)+'\n')
 result={'scenario':s['id'],'expected_ticks':ticks,'actual_ticks':actual,'termination':r['termination'],'timing_valid':False}
 print(group,arm,s['id'],actual,ticks,flush=True);return group,arm,result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for group,arm,row in pool.map(run,pending):results[group][arm][row['scenario']]=row;record['rerun'].append({'group':group,'arm':arm,**row})
matched={};validation=[]
for group,m in p['manifests'].items():
 doc=copy.deepcopy(json.load(open(m['path'])));changes=[]
 for s in doc['scenarios']:
  pair={arm:results[group][arm][s['id']] for arm in variants};expected=next(iter(pair.values()))['expected_ticks'];limit=min(r['actual_ticks'] for r in pair.values())
  if limit==expected:continue
  ticks=((limit-1)//512)*512;assert ticks>0
  idx=s['args'].index('--ticks')+1;old=s['args'][idx];s['args'][idx]=str(s['start_tick']+ticks)
  changes.append({'scenario':s['id'],'original_stop':old,'common_ticks':ticks,'arms':pair,'reason':'Largest complete512-tick prefix strictly before earliest observed ending; both arms rerun.'})
  for arm in variants:validation.append((group,arm,s,ticks))
 doc['window_adjustments']={'timing_valid':False,'source_manifest_sha256':m['sha256'],'changes':changes};matched[group]=doc
checks=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for group,arm,row in pool.map(lambda j:run(j,'prefix-validation'),validation):
  assert row['actual_ticks']==row['expected_ticks'];checks.append({'group':group,'arm':arm,**row})
stable()
for group,doc in matched.items():(out/f'{group}-matched-windows.json').write_text(json.dumps(doc,indent=2)+'\n')
record['runtime_stable']=True;record['complete']=True;record['prefix_validation']=checks
(recovery/'provenance.json').write_text(json.dumps(record,indent=2)+'\n')
(out/'final-summary.json').write_text(json.dumps({'timing_valid':False,'runtime_stable':True,'complete':True,'arms':results,'adjustments':{k:v['window_adjustments'] for k,v in matched.items()},'recovery_provenance_sha256':sha(recovery/'provenance.json')},indent=2)+'\n')
print('Recovered all202 original correctness windows; both-arm common prefixes validated',flush=True)
