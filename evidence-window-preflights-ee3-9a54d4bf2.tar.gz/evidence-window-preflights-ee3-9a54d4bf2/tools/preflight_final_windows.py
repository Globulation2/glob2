"""Correctness-only full final matched-window preflight; never timing evidence."""
import argparse, concurrent.futures, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'test'))
from benchmark_parallel_compute import execute,digest
p=argparse.ArgumentParser(__doc__)
p.add_argument('binary',type=Path);p.add_argument('manifest',type=Path);p.add_argument('output',type=Path)
p.add_argument('--jobs',type=int,default=2)
p.add_argument('--cwd',type=Path,default=ROOT)
a=p.parse_args();binary=a.binary.resolve();manifest=a.manifest.resolve();output=a.output.resolve()
output.mkdir(exist_ok=False)
inputs=json.loads(manifest.read_text());binary_sha=digest(binary)
(output/'metadata.json').write_text(json.dumps({'timing_valid':False,'reason':'Concurrent platform validation; correctness only','binary':str(binary),'cwd':str(a.cwd.resolve()),'binary_sha256':binary_sha,'manifest_sha256':digest(manifest),'manifest':inputs},indent=2))
def run(s):
 for path,expected in s['fixture_sha256'].items():
  assert digest(path)==expected
 args=s['args']+['--benchmark-warmup','0']
 row=execute(binary,args,output/s['id'],cwd=a.cwd.resolve())
 expected=int(args[args.index('--ticks')+1])-s['start_tick']
 result={'scenario':s['id'],'expected_ticks':expected,'actual_ticks':row['result']['benchmark_measured_ticks'],'termination':row['result']['termination'],'timing_valid':False}
 print(json.dumps(result),flush=True)
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as pool:
 results=list(pool.map(run,inputs['scenarios']))
assert digest(binary)==binary_sha
(output/'summary.json').write_text(json.dumps(results,indent=2))
raise SystemExit(1 if any(r['expected_ticks']!=r['actual_ticks'] for r in results) else 0)
