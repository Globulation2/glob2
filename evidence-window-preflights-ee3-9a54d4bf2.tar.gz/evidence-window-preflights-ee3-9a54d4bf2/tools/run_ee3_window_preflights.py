"""Both-arm window correctness checks; all timings invalid under concurrent load."""
import concurrent.futures,copy,json,pathlib,subprocess,sys
from paired_provenance import runtime_snapshot,stable_runtime,environment_snapshot,sha,tools_snapshot
base=pathlib.Path(__file__).resolve().parent;root=base.parents[1]
sys.path.insert(0,str(root/'test'))
from benchmark_parallel_compute import execute,digest
out=base/'window-preflights-ee3-9a54d4bf2';out.mkdir(exist_ok=False)
variants={'baseline':(base/'master-ee3-pure-frozen/glob2',base/'master-ee3-pure-source'),'candidate':(base/'candidate-9a54d4bf2/glob2',root)}
manifests={'legacy':base/'full-baseline-corpus/performance-windows.json','eight-team':base/'eight-team-corpus/windows.json'}
provenance={'timing_valid':False,'reason':'Concurrent builds and tournaments; correctness only','runtime':{k:runtime_snapshot(*v) for k,v in variants.items()},'environment_sha256':environment_snapshot(),'manifests':{k:{'path':str(p),'sha256':sha(p)} for k,p in manifests.items()},'tools_sha256':tools_snapshot(),'helper_sha256':sha(base/'preflight_final_windows.py'),'execute_source_sha256':sha(root/'test/benchmark_parallel_compute.py'),'wrapper_sha256':sha(__file__),'completed':[]}
def save(): (out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
def inputs_stable():
 return all(stable_runtime(runtime_snapshot(*v))==stable_runtime(provenance['runtime'][k]) for k,v in variants.items()) and all(sha(p)==provenance['manifests'][k]['sha256'] for k,p in manifests.items())
save(); all_results={}
for group,manifest in manifests.items():
 all_results[group]={}
 for arm,(binary,cwd) in variants.items():
  directory=out/f'{group}-{arm}';command=[sys.executable,str(base/'preflight_final_windows.py'),str(binary),str(manifest),str(directory),'--cwd',str(cwd),'--jobs','2']
  (out/f'{group}-{arm}.command.json').write_text(json.dumps(command,indent=2)+'\n')
  with (out/f'{group}-{arm}.log').open('w') as log: result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  assert result.returncode in (0,1),result.returncode
  rows=json.loads((directory/'summary.json').read_text())
  scenarios=json.loads(manifest.read_text())['scenarios']
  assert len(rows)==len(scenarios)
  for s,row in zip(scenarios,rows):
   actual=json.loads((directory/s['id']/'result.json').read_text())
   assert actual['status']=='completed' and row['scenario']==s['id']
   assert actual['ticks']==s['start_tick']+row['actual_ticks']
   assert 0<row['actual_ticks']<=row['expected_ticks']
   assert row['actual_ticks']==row['expected_ticks'] or row['termination']=='engine_end'
  assert inputs_stable()
  all_results[group][arm]={r['scenario']:r for r in rows}
  provenance['completed'].append({'group':group,'arm':arm,'scenarios':len(rows),'short':sum(r['actual_ticks']!=r['expected_ticks'] for r in rows),'summary_sha256':sha(directory/'summary.json')});save()
  print(json.dumps(provenance['completed'][-1]),flush=True)
# A shortened window is proposed from the earliest observed ending in either arm,
# then actually rerun at that same fixed length on BOTH arms before publication.
matched={};validation=[]
for group,manifest in manifests.items():
 doc=copy.deepcopy(json.loads(manifest.read_text()));changes=[]
 for s in doc['scenarios']:
  pair={arm:all_results[group][arm][s['id']] for arm in variants}
  limit=min(r['actual_ticks'] for r in pair.values());expected=next(iter(pair.values()))['expected_ticks']
  if limit==expected:continue
  ticks=((limit-1)//512)*512
  assert ticks>0,('No positive 512-tick prefix',s['id'],pair)
  index=s['args'].index('--ticks')+1;old=s['args'][index];s['args'][index]=str(s['start_tick']+ticks)
  changes.append({'scenario':s['id'],'original_stop':old,'common_ticks':ticks,'arms':pair,'reason':'Largest complete512-tick prefix strictly before the earliest observed ending.'})
  for arm,(binary,cwd) in variants.items():validation.append((group,s,arm,binary,cwd,ticks))
 doc['window_adjustments']={'timing_valid':False,'source_manifest_sha256':sha(manifest),'changes':changes};matched[group]=doc

def verify(job):
 group,s,arm,binary,cwd,ticks=job
 for p,h in s['fixture_sha256'].items():assert digest(p)==h
 result=execute(binary,s['args']+['--benchmark-warmup','0'],out/'shortened-validation'/group/s['id']/arm,cwd=cwd)['result']
 assert result['status']=='completed' and result['benchmark_measured_ticks']==ticks and result['ticks']==s['start_tick']+ticks
 return {'group':group,'scenario':s['id'],'arm':arm,'measured_ticks':ticks,'termination':result['termination']}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: checks=list(pool.map(verify,validation))
assert inputs_stable()
for group,doc in matched.items():(out/f'{group}-matched-windows.json').write_text(json.dumps(doc,indent=2)+'\n')
provenance['runtime_stable']=True;provenance['shortened_validation']=checks;provenance['complete']=True;save()
print('All both-arm correctness preflights and matched-prefix validations complete',flush=True)
