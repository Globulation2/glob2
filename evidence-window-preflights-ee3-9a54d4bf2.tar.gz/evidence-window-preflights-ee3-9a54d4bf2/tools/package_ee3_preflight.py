import pathlib,json,hashlib,shutil,tarfile
base=pathlib.Path(__file__).resolve().parent;source=base/'window-preflights-ee3-9a54d4bf2';dest=base/'evidence-window-preflights-ee3-9a54d4bf2';dest.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,rel):
 q=dest/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
p=json.load(open(source/'provenance.json'));final=json.load(open(source/'final-summary.json'));recovery=json.load(open(source/'recovery/provenance.json'))
for name in ['README.md','provenance.json','final-summary.json','legacy-matched-windows.json','eight-team-matched-windows.json','recovery/provenance.json']:
 copy(source/name,name)
for f in source.glob('*.command.json'):copy(f,'commands/'+f.name)
for f in source.glob('*.log'):copy(f,'logs/'+f.name)
for name in ['window-preflights-ee3-9a54d4bf2.log','window-preflights-ee3-9a54d4bf2-recovery.log']:copy(base/name,'logs/'+name)
for name in ['run_ee3_window_preflights.py','recover_ee3_window_preflights.py','preflight_final_windows.py','paired_provenance.py','package_ee3_preflight.py']:copy(base/name,'tools/'+name)
copy(base.parents[1]/'test/benchmark_parallel_compute.py','tools/benchmark_parallel_compute.py')
for group,m in p['manifests'].items():copy(pathlib.Path(m['path']),'inputs/'+group+'-original-windows.json')
records=[]
def add(group,arm,s,d,stage):
 r=json.load(open(d/'result.json'));expected=int(s['args'][s['args'].index('--ticks')+1])-s['start_tick'];actual=r['benchmark_measured_ticks']
 assert r['status']=='completed' and r['ticks']==s['start_tick']+actual and actual<=expected
 if stage=='prefix-validation':assert actual==expected
 rel=pathlib.Path('runs')/stage/group/arm/s['id']
 for name in ['result.json','engine.log']:copy(d/name,rel/name)
 existing=d/'command.json'
 if existing.exists():command=json.load(open(existing));command['recording']='Recorded at invocation by recovery wrapper'
 else:
  command={'argv':[p['runtime'][arm]['binary'],'--run-game',*s['args'],'--benchmark-warmup','0','--output-dir',str(d)],'cwd':p['runtime'][arm]['cwd'],'recording':'Reconstructed exactly from frozen helper and original invocation manifest; original helper did not emit per-run command files'}
 (dest/rel/'command.json').write_text(json.dumps(command,indent=2)+'\n')
 row={'group':group,'arm':arm,'scenario':s['id'],'stage':stage,'requested_measured_ticks':expected,'actual_measured_ticks':actual,'initial_tick':s['start_tick'],'terminal_tick':r['ticks'],'status':r['status'],'termination':r['termination'],'timing_valid':False,'result':str(rel/'result.json'),'result_sha256':sha(d/'result.json'),'engine_log_sha256':sha(d/'engine.log'),'original_directory':str(d)}
 records.append(row);(dest/rel/'accounting.json').write_text(json.dumps(row,indent=2)+'\n')
for group,m in p['manifests'].items():
 for arm in p['runtime']:
  stage=source/f'{group}-{arm}'
  for name in ['metadata.json','summary.json']:
   if (stage/name).exists():copy(stage/name,'phase-metadata/'+group+'-'+arm+'/'+name)
  for s in json.load(open(m['path']))['scenarios']:
   d=stage/s['id']
   if not (d/'result.json').exists():d=source/'recovery/unfinished'/group/arm/s['id']
   add(group,arm,s,d,'original-window')
for row in recovery['prefix_validation']:
 group,arm=row['group'],row['arm'];s=next(s for s in json.load(open(source/f'{group}-matched-windows.json'))['scenarios'] if s['id']==row['scenario']);add(group,arm,s,source/'recovery/prefix-validation'/group/arm/s['id'],'prefix-validation')
partial=source/'eight-team-candidate/land-8-1001-mixed-512-middle'
for name in ['engine.log','progress.jsonl']:copy(partial/name,'interruption/partial-eight-team-candidate-middle/'+name)
(dest/'interruption/status.json').write_text(json.dumps({'session':33586,'exit_code':143,'cause':'unknown','agent_scope_checks':'Root and both other agents reported no relevant process signal; no causal attribution established.','completed_terminal_results_before_interruption':201,'missing_result':'eight-team-candidate/land-8-1001-mixed-512-middle','recovery':'Only the missing stress window was rerun; completed original records were hash-validated and retained. Six common-prefix runs were then executed.','timing_valid':False},indent=2)+'\n')
assert len(records)==208 and sum(r['stage']=='original-window' for r in records)==202
(dest/'accounting.json').write_text(json.dumps({'timing_valid':False,'original_window_records':202,'prefix_validation_records':6,'records':records},indent=2)+'\n')
readme=dest/'README.md';s=readme.read_text();s+='''
## Archive layout

- `accounting.json`: all202 terminal original-window records and six paired-prefix records; requested/actual tick counts, termination, paths and hashes.
- `runs/`: terminal result JSON, corresponding engine log, exact command and accounting for each record. Commands for original runs are transparently reconstructed from the frozen helper/manifest; recovery commands were captured at execution.
- `inputs/`: original unadjusted manifests. Top-level matched manifests include validated adjustments.
- `phase-metadata/`, `provenance.json`, `recovery/provenance.json`: immutable input inventories and interrupted/completed phase records.
- `interruption/`: original exit143 status and preserved unfinished stress-window log/progress; no cause is claimed.
- `tools/`: wrappers, unchanged execution helper and parser/provenance sources needed to reconstruct commands.
- `integrity.json`: SHA256 of every other packaged file.

All timing fields retained in raw result JSON are explicitly INVALID for performance comparisons. No binaries, save files, source trees, profile directories or duplicated fixture payloads are included. Fixture identities and original paths are retained in manifests; this archive alone does not contain the fixtures required to rerun engines.
''';readme.write_text(s)
integrity={str(f.relative_to(dest)):sha(f) for f in sorted(dest.rglob('*')) if f.is_file()};(dest/'integrity.json').write_text(json.dumps(integrity,indent=2)+'\n')
archive=dest.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:tar.add(dest,arcname=dest.name)
print(json.dumps({'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(integrity)+1,'terminal_records':202,'prefix_validations':6},indent=2))
