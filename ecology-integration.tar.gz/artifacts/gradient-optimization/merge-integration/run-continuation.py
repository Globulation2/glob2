from pathlib import Path
import hashlib,json,os,platform,struct,subprocess,sys,time
ROOT=Path.cwd(); OUT=ROOT/'artifacts/gradient-optimization/merge-integration/continuation';sys.path.insert(0,str(ROOT/'test'))
from benchmark_parallel_compute import execute
OUT.mkdir(parents=True,exist_ok=True)
BINS={'baseline':ROOT/'artifacts/gradient-optimization/merge-integration/ecology-integrated-glob2','candidate':ROOT/'artifacts/gradient-optimization/merge-integration/gradient-integrated-glob2'}
MAPS={'classic128':ROOT/'artifacts/ecology-optimization/maps/allotments-1427/map-r0.map.gz','mixed128_markets':ROOT/'artifacts/gradient-optimization/maps/allotments-1427-mixed.map'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def saved(p):return p if p.exists() else Path(str(p)+'.gz')
def records(p):
 data=p.read_bytes(); assert data[:4]==b'GCS1'; teams,_,count,_=struct.unpack_from('<4I',data,4);pos=20;out={}
 for _ in range(count):
  start=pos;tick=struct.unpack_from('<I',data,pos)[0];pos+=8
  for _ in range(teams):
   pos+=4
   for _ in range(2):
    n=struct.unpack_from('<I',data,pos)[0];pos+=4
    for _ in range(n):fields=struct.unpack_from('<I',data,pos+6)[0];pos+=10+4*fields
  out[tick]=data[start:pos]
 assert pos==len(data);return out
HASHES={n:sha(p) for n,p in BINS.items()}
manifest={'platform':platform.platform(),'binaries':{n:{'path':str(p),'sha256':HASHES[n]} for n,p in BINS.items()},'maps':{n:{'path':str(p),'sha256':sha(p)} for n,p in MAPS.items()},'source_sha256':sha(__file__),'runs':[],'comparisons':[]}
def flush():(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
def run(label,variant,args):
 assert sha(BINS[variant])==HASHES[variant],'binary changed';dest=OUT/label
 result=execute(BINS[variant],args,dest); result.update(label=label,variant=variant,binary_sha256=HASHES[variant])
 result['artifacts']={p.name:sha(p) for p in dest.iterdir() if p.is_file() and p.name!='engine.log'}
 manifest['runs'].append(result);flush();print(label,result['result']['ticks'],flush=True);return dest
for name,mapfile in MAPS.items():
 setup=['--map-file',str(mapfile),'--game-seed','12345','--player','maxima','--player','nicowar']
 if name.endswith('_markets'): setup += ['--experiment','markets-v2']
 for workers in (1,4):
  settings=['--compute-threads',str(workers),'--compute-experiments','ai','--gradient-workers',str(0 if workers==1 else 3)]
  common=['--telemetry','checksums','--replay','true','--save','final',*settings]
  checkpoint=run(f'{name}-w{workers}-checkpoint','baseline',[*setup,'--ticks','1024',*common])
  groups={}
  for stage in ('full','resume'):
   dirs={}
   for variant in ('baseline','candidate'):
    initial=setup if stage=='full' else ['--load-game',str(saved(checkpoint/'final.game'))]
    dirs[variant]=run(f'{name}-w{workers}-{stage}-{variant}',variant,[*initial,'--ticks','4096',*common])
   a,b=dirs.values(); comparisons={file:sha(saved(a/file))==sha(saved(b/file)) for file in ('game.replay.checksums','game.replay','final.game')}
   assert comparisons['game.replay.checksums'],(name,workers,stage,'per-tick mismatch')
   assert comparisons['game.replay'],(name,workers,stage,'replay mismatch')
   assert comparisons['final.game'],(name,workers,stage,'save mismatch')
   assert json.loads((a/'result.json').read_text())['finalChecksum']==json.loads((b/'result.json').read_text())['finalChecksum']
   manifest['comparisons'].append(dict(scenario=name,workers=workers,stage=stage,baseline_candidate=comparisons));groups[stage]=records(a/'game.replay.checksums');flush()
  mismatches=[tick for tick,value in groups['resume'].items() if groups['full'].get(tick)!=value]
  assert not mismatches,(name,workers,'save-boundary mismatch')
  manifest['comparisons'].append(dict(scenario=name,workers=workers,stage='save_boundary',resumed_ticks=len(groups['resume']),uninterrupted_mismatch_count=len(mismatches),first_mismatch=mismatches[0] if mismatches else None));flush()
 # Worker-count execution must preserve every tick of the same setup/stage.
 for stage in ('full','resume'):
  a=OUT/f'{name}-w1-{stage}-candidate/game.replay.checksums';b=OUT/f'{name}-w4-{stage}-candidate/game.replay.checksums'
  equal=sha(a)==sha(b);manifest['comparisons'].append(dict(scenario=name,stage=stage,serial_parallel_trace_equal=equal));flush();assert equal,(name,stage,'worker divergence')
record=ROOT/'test/fixtures/multiplayer/FourSquares1.g2mr';mapfile=ROOT/'maps/FourSquares1.map.gz';golden=ROOT/'test/fixtures/multiplayer/FourSquares1.verify-trace.txt'
for variant,binary in BINS.items():
 dest=OUT/f'verify-{variant}';cmd=[str(binary),'--verify-match',str(record),'--map',str(mapfile),'--out',str(dest)]
 with (OUT/f'verify-{variant}.log').open('w') as log:subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True,env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy'))
 trace=dest/'checksums.txt';assert trace.read_bytes()==golden.read_bytes()
 manifest['comparisons'].append(dict(stage='verify-match',variant=variant,command=cmd,binary_sha256=HASHES[variant],record_sha256=sha(record),map_sha256=sha(mapfile),golden_sha256=sha(golden),trace_sha256=sha(trace),verdict=json.loads((dest/'verdict.json').read_text())));flush()
print('PASS baseline/candidate every tick, worker equivalence, continued saves and match golden')
