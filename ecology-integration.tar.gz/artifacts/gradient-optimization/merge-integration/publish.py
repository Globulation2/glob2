from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,tempfile
root=Path.cwd(); evidence=root/'artifacts/gradient-optimization/merge-integration'; out=root/'artifacts/gradient-optimization/published'; stage=sys.argv[1]
report=evidence/f'{stage}-REPORT.md'; assert report.exists()
files=[p for p in evidence.rglob('*') if p.is_file() and p.suffix in {'.md','.py','.log','.json','.jsonl','.xml','.txt','.gz','.replay','.checksums'}]
files += [p for p in (root/'artifacts/gradient-optimization/merge-review').rglob('*') if p.is_file()]
manifest={str(p.relative_to(root)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files}
manifest_path=out/f'{stage}-files.json';manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
archive=out/f'{stage}-integration.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(root)))
 tar.add(manifest_path,arcname=f'artifacts/gradient-optimization/merge-integration/{stage}-files.json')
assert archive.stat().st_size<95*1024*1024,archive.stat().st_size
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/codex/evidence-gradient-optimization'],text=True).split()[0]
subprocess.run(['git','fetch','origin','codex/evidence-gradient-optimization'],check=True,stdout=subprocess.DEVNULL)
name=f'{stage.upper()}-INTEGRATION.md'
published=report.read_text()+f'\n[Raw evidence archive]({archive.name}), SHA-256 `{hashlib.sha256(archive.read_bytes()).hexdigest()}`. Extract at a separate repository root; its files stay under ignored `artifacts/`.\n'
(out/name).write_text(published)
with tempfile.TemporaryDirectory(prefix='gradient-merge-evidence-') as tmp:
 env=dict(os.environ,GIT_INDEX_FILE=str(Path(tmp)/'index'))
 def git(*args,input=None):return subprocess.check_output(['git',*args],env=env,input=input).decode().strip()
 git('read-tree',remote)
 for p in [out/name,archive]:
  blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo','100644',blob,p.name)
 tree=git('write-tree');commit=git('commit-tree',tree,'-p',remote,input=f'Attach {stage} master integration validation\n'.encode())
 subprocess.run(['git','push','origin',commit+':refs/heads/codex/evidence-gradient-optimization'],check=True)
 (evidence/f'{stage}-evidence-commit.txt').write_text(commit+'\n')
 print('https://github.com/Globulation2/glob2/blob/'+commit+'/'+name)
