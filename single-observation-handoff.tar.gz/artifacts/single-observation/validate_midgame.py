#!/usr/bin/env python3
"""Local evidence driver: exact per-tick determinism and pending-job continuation."""
import argparse, gzip, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('binary',type=Path)
parser.add_argument('fixtures',type=Path)
parser.add_argument('output',type=Path)
args=parser.parse_args()
binary=args.binary.resolve(); output=args.output.resolve(); output.mkdir(parents=True,exist_ok=True)
root=Path.cwd();sys.path.insert(0,str(root/'test'))
from compare_save_continuation import compare
manifest={'binary':str(binary),'cases':[]}
def run(name,fixture,target,participants,save='final'):
 folder=output/name
 command=[str(binary),'game','run','--load-game',str(fixture),'--ticks',str(target),'--compute-threads',str(participants),'--gpu','off','--telemetry','checksums','--save',save,'--output-dir',str(folder)]
 with (output/(name+'.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 if result.returncode:raise RuntimeError(f'{name}: exit {result.returncode}; see log')
 data=json.loads((folder/'result.json').read_text())
 if data['ticks']!=target:raise RuntimeError(f'{name}: stopped at {data["ticks"]}')
 trace=(folder/'world.checksums').read_bytes()
 manifest['cases'].append({'name':name,'command':command,'ticks':data['ticks'],'initialChecksum':data['initialChecksum'],'finalChecksum':data['finalChecksum'],'trace_sha256':hashlib.sha256(trace).hexdigest(),'trace_lines':len(trace.splitlines()),'ai_pipeline':data['ai_pipeline']})
 print('PASS run',name,'final',data['finalChecksum'],flush=True)
 return folder,data,trace
for tick in [12000,24000]:
 fixture=(args.fixtures/f'midgame-{tick//1000}k-v164.game.gz').resolve()
 # A nonperiodic midpoint exercises pending jobs across different deadline rings.
 end=tick+1024; midpoint=tick+509
 one,a,at=run(f'{tick}-one',fixture,end,1)
 many,b,bt=run(f'{tick}-eight',fixture,end,8)
 assert at==bt, f'{tick}: per-tick world checksum differs by participant count'
 assert a['finalChecksum']==b['finalChecksum'],f'{tick}: final checksum differs'
 print('PASS exact participant determinism',tick,flush=True)
 # Upgrade the input once so aggregate checksums have the same format header.
 normalized,_,_=run(f'{tick}-normalized',fixture,tick+1,8)
 full,fd,ft=run(f'{tick}-normalized-full',normalized/'final.game.gz',end,8)
 checkpoint,_,_=run(f'{tick}-checkpoint',normalized/'final.game.gz',midpoint,8)
 resumed,rd,rt=run(f'{tick}-resumed',checkpoint/'final.game.gz',end,8)
 expected=b'\n'.join(row for row in ft.splitlines() if int(row.split()[0])>=midpoint)+b'\n'
 assert expected==rt, f'{tick}: resumed per-tick world checksum differs'
 assert fd['finalChecksum']==rd['finalChecksum'],f'{tick}: resumed final checksum differs'
 count=compare(full/'game.replay.checksums',resumed/'game.replay.checksums')
 manifest['cases'][-1]['matching_continuation_records']=count
 print('PASS save continuation',tick,count,'team/entity records',flush=True)
 (output/'validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
 # Retain lossless detailed evidence without filling the shared development disk.
 for sidecar in output.glob(f'{tick}-*/game.replay.checksums'):
  with sidecar.open('rb') as source, gzip.open(str(sidecar)+'.gz','wb',compresslevel=1) as target:
   shutil.copyfileobj(source,target)
  sidecar.unlink()
