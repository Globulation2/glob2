#!/usr/bin/env python3
"""Extract exclusive source costs and call edges from an Ir-only Callgrind dump."""
import collections
import json
import re
import sys

names = {"file": {}, "fn": {}, "ob": {}}
def resolve(kind, value):
    match = re.match(r"\((\d+)\)(?: (.*))?$", value)
    if not match:
        return value
    key, text = match.groups()
    if text is not None:
        names[kind][key] = text
    return names[kind][key]

self_cost = collections.Counter()
lines = collections.Counter()
edges = collections.Counter()
file = function = callee = "???"
call_file = "???"
edge = False
position = 0
summary = None
for raw in open(sys.argv[1]):
    row = raw.strip()
    if row.startswith("summary:"):
        summary = int(row.split()[1])
    elif row.startswith(("fl=", "fi=", "fe=")):
        file = resolve("file", row.split("=", 1)[1])
    elif row.startswith(("cfl=", "cfi=")):
        call_file = resolve("file", row.split("=", 1)[1])
    elif row.startswith("fn="):
        function = resolve("fn", row[3:])
    elif row.startswith("cfn="):
        callee = resolve("fn", row[4:])
    elif row.startswith(("ob=", "cob=")):
        resolve("ob", row.split("=", 1)[1])
    elif row.startswith("calls="):
        edge = True
    elif row and row[0] in "0123456789+-*":
        fields = row.split()
        p = fields[0]
        if p != "*":
            position = position + int(p) if p[0] in "+-" else int(p)
        cost = int(fields[1])
        if edge:
            edges[function, callee] += cost
            edge = False
        else:
            self_cost[function] += cost
            lines[file, position, function] += cost

result = {
    "summary": summary,
    "self_total": sum(self_cost.values()),
    "functions": [{"function": k, "ir": v} for k, v in self_cost.most_common()],
    "lines": [{"file": k[0], "line": k[1], "function": k[2], "ir": v} for k, v in lines.most_common()],
    "edges": [{"caller": k[0], "callee": k[1], "ir": v} for k, v in edges.most_common()],
}
json.dump(result, open(sys.argv[2], "w"), indent=2)
print("Summary:", summary, "exclusive total:", result["self_total"])
for row in result["functions"][:45]:
    print(f'{row["ir"] / result["self_total"] * 100:7.3f}% {row["ir"]:16,d} {row["function"]}')
