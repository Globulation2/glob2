#!/usr/bin/env python3
"""Explicitly run matched release-reference/Callgrind evidence; importing does nothing.

Run only after the owner has synced and validated the final source and built the
clean release binary. All instrumentation is temporary inside the dedicated
container. No host production source is written and no clean symbol binary is
copied: the reference is created directly with strip --strip-all -o.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import signal
import subprocess
import sys

PROBE = '''
    // Local profiling probe only: no world or scheduling mutations.
    static const unsigned profileBegin = std::getenv("GLOB2_CG_BEGIN") ? std::strtoul(std::getenv("GLOB2_CG_BEGIN"), nullptr, 10) : 0;
    static const unsigned profileEnd = std::getenv("GLOB2_CG_END") ? std::strtoul(std::getenv("GLOB2_CG_END"), nullptr, 10) : 0;
    if (profileBegin && gui.game.stepCounter == profileBegin) {
        CALLGRIND_START_INSTRUMENTATION;
        CALLGRIND_ZERO_STATS;
    }
    if (profileEnd && gui.game.stepCounter == profileEnd) {
        CALLGRIND_STOP_INSTRUMENTATION;
    }
'''
SIGNATURE = 'bool Engine::advanceSession(Uint64 now, const std::function<void()>& clientWork, bool handleExit)\n{'
ENGINE = '/work/src/engine/EngineRun.cpp'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--container', default='glob2-single-observation-callgrind')
    parser.add_argument('--with-12k', action='store_true')
    parser.add_argument('--binary', default='/work/build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2')
    parser.add_argument('--fixture-24k', default='/profile/fixtures/midgame-24k-v164.game.gz')
    parser.add_argument('--fixture-12k', default='/profile/fixtures/midgame-12k-v164.game.gz')
    parser.add_argument('--container-output', default='/profile/new-callgrind')
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent/'new-callgrind')
    parser.add_argument('--min-free-gib', type=float, default=2)
    parser.add_argument('--sdl-prefix', default='/opt/glob2-sdl')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    # Existing evidence must be preserved, including after a failed prior run.
    output.mkdir(parents=True, exist_ok=False)
    remote = args.container_output.rstrip('/')
    clean_source = remote + '/EngineRun.clean.cpp'
    reference = remote + '/glob2-clean-stripped'
    manifest = {'status': 'starting', 'commands': [], 'cases': [],
                'container': args.container, 'container_output': remote,
                'started_utc': datetime.now(timezone.utc).isoformat(),
                'build_environment': {'GLOB2_SDL3_PREFIX': args.sdl_prefix,
                                      'PYTHONPATH': '/work', 'PATH': '/opt/asset-tools/bin:$PATH',
                                      'CCACHE': '0', 'CCACHE_DISABLE': '1'},
                'build_options': ['release=1', 'retain_symbols=1', 'linker=auto', '-j2'],
                'notes': ['No --telemetry option; 8 compute participants; CPU gradients.',
                          'Instrumentation text is identical to the original instrumentation.patch.',
                          'Only temporary container source is modified; clean source is restored in finally.',
                          'Owner is explicitly Callgrind thread 1 in serial headless execution.',
                          'Inclusive/function-label costs are not used for conclusions.',
                          'Raw dumps are gzip archived on host; parser output is compacted to exclusive file/line costs.']}

    def save_manifest():
        (output/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')

    def run(command, *, stdin=None, log=None):
        entry = {'argv': [str(x) for x in command], 'started_utc': datetime.now(timezone.utc).isoformat()}
        manifest['commands'].append(entry); save_manifest()
        handle = (output/log).open('w') if log else subprocess.PIPE
        try:
            result = subprocess.run(command, input=stdin, text=True, stdout=handle,
                                    stderr=subprocess.STDOUT, check=False)
            entry['returncode'] = result.returncode
            if log: entry['log'] = log
            save_manifest()
            if result.returncode:
                raise RuntimeError(f'Command failed ({result.returncode}); log={log}: {command[:5]}')
            return result.stdout or ''
        finally:
            if log: handle.close()

    def remote_python(code, *, log=None):
        return run(['docker','exec','-i','-w','/work',args.container,'python3','-'], stdin=code, log=log)

    def copy_out(source, destination):
        destination.parent.mkdir(parents=True, exist_ok=True)
        run(['docker','cp',args.container+':'+source,str(destination)])

    def interrupt(signum, _frame):
        raise KeyboardInterrupt(f'signal {signum}')

    signal.signal(signal.SIGTERM, interrupt)
    signal.signal(signal.SIGINT, interrupt)
    backup_created = False
    try:
        expected_engine = hashlib.sha256((root/'src/engine/EngineRun.cpp').read_bytes()).hexdigest()
        preparation = remote_python(f'''
from pathlib import Path
import hashlib,json,shutil,subprocess,os,runpy
out=Path({remote!r});out.mkdir(parents=True,exist_ok=False)
p=Path({ENGINE!r});binary=Path({args.binary!r})
assert binary.is_file(), 'Build the clean final release binary before invoking this script'
assert '#include <valgrind/callgrind.h>' not in p.read_text(), 'Source already instrumented'
assert hashlib.sha256(p.read_bytes()).hexdigest()=={expected_engine!r}, 'Host/container EngineRun source differs'
free=shutil.disk_usage('/work').free
assert free >= {int(args.min_free_gib*1024**3)}, 'Insufficient free disk for bounded probe build/dumps'
Path({clean_source!r}).write_bytes(p.read_bytes())
subprocess.run(['strip','--strip-all','-o',{reference!r},str(binary)],check=True)
def sha(path):
 digest=hashlib.sha256()
 with Path(path).open('rb') as stream:
  while chunk:=stream.read(1024*1024):digest.update(chunk)
 return digest.hexdigest()
fixture_hashes=dict((f,sha(f)) for f in {[args.fixture_24k]+([args.fixture_12k] if args.with_12k else [])!r})
result={{'clean_binary_sha256':sha(binary),
 'reference_sha256':sha({reference!r}),
 'clean_source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'clean_binary_bytes':binary.stat().st_size,'reference_bytes':Path({reference!r}).stat().st_size,
 'free_bytes_before':free,
 'fixtures':fixture_hashes,
 'build_path':'/opt/asset-tools/bin:'+os.environ['PATH'],
 'source_identity':runpy.run_path('/work/test/build_provenance.py')['source_identity'](Path('/work'))}}
for key,cmd in [('uname',['uname','-a']),('compiler',['g++','--version']),('valgrind',['valgrind','--version']),('git_revision',['git','rev-parse','HEAD']),('git_status',['git','status','--short'])]:
 result[key]=subprocess.check_output(cmd,text=True).strip()
result['git_diff_sha256']=hashlib.sha256(subprocess.check_output(['git','diff','--binary','HEAD'])).hexdigest()
(out/'provenance.json').write_text(json.dumps(result,indent=2)+'\\n')
print(json.dumps(result))
''')
        backup_created = True
        manifest['provenance'] = json.loads(preparation)
        manifest['restore_command'] = ['docker','exec',args.container,'cp',clean_source,ENGINE]
        save_manifest()
        remote_python(f'''
from pathlib import Path
import difflib
p=Path({ENGINE!r});before=p.read_text();needle={SIGNATURE!r}
assert before.count(needle)==1
instrumented='#include <valgrind/callgrind.h>\\n'+before.replace(needle,needle+{PROBE!r})
p.write_text(instrumented)
Path({remote+'/instrumentation.patch'!r}).write_text(''.join(difflib.unified_diff(before.splitlines(True),instrumented.splitlines(True),fromfile='EngineRun.clean.cpp',tofile='src/engine/EngineRun.cpp')))
''')
        copy_out(remote+'/instrumentation.patch', output/'instrumentation.patch')
        print('Building temporary release probe (-j2); clean stripped reference retained.', flush=True)
        build = ['docker','exec','-w','/work',args.container,'env',
                 'GLOB2_SDL3_PREFIX='+args.sdl_prefix,'PYTHONPATH=/work',
                 'PATH='+manifest['provenance']['build_path'],'CCACHE=0','CCACHE_DISABLE=1',
                 '/opt/asset-tools/bin/python','/usr/bin/scons','release=1','retain_symbols=1','linker=auto','-j2']
        manifest['build_environment']['PATH']=manifest['provenance']['build_path']
        run(build, log='probe-build.log')
        manifest['probe_binary'] = json.loads(remote_python(f'''
from pathlib import Path
import hashlib,json,shutil,runpy
path=Path({args.binary!r});digest=hashlib.sha256()
with path.open('rb') as stream:
 while chunk:=stream.read(1024*1024):digest.update(chunk)
print(json.dumps({{'sha256':digest.hexdigest(),'bytes':path.stat().st_size,'free_bytes_after_build':shutil.disk_usage('/work').free,
 'source_identity':runpy.run_path('/work/test/build_provenance.py')['source_identity'](Path('/work'))}}))
'''))
        manifest['status'] = 'profiling'; save_manifest()
        cases = [('24k', args.fixture_24k, 24128, 25152)]
        if args.with_12k: cases.append(('12k', args.fixture_12k, 12128, 13152))
        for name, fixture, begin, end in cases:
            print(f'Running {name}: reference then Callgrind [{begin},{end}), ending {end+1}.', flush=True)
            folder = remote+'/'+name
            result_text = remote_python(f'''
from pathlib import Path
import json,os,subprocess,hashlib,shutil
folder=Path({folder!r});folder.mkdir()
env=dict(os.environ)
# Match the original ordinary headless run, without test/diagnostic overrides.
for key in ['GLOB2_CG_BEGIN','GLOB2_CG_END','GLOB2_SIM_THREAD','GLOB2_COMPUTE_TELEMETRY','GLOB2_SNAPSHOT_VERIFY']:
 env.pop(key,None)
common=['game','run','--load-game',{fixture!r},'--compute-threads','8','--gpu','off','--ticks',{str(end+1)!r}]
reference=[{reference!r}]+common+['--output-dir',str(folder/'reference')]
probe_native=[{args.binary!r}]+common+['--output-dir',str(folder/'probe-native')]
measured=['valgrind','--tool=callgrind','--instr-atstart=no','--collect-atstart=yes','--separate-threads=yes','--read-inline-info=yes','--callgrind-out-file='+str(folder/'callgrind.out.%p'),'--log-file='+str(folder/'valgrind.log'),{args.binary!r}]+common+['--output-dir',str(folder/'measured')]
(folder/'commands.json').write_text(json.dumps({{'reference':reference,'probe_native':probe_native,'measured':measured,'profile_environment':{{'GLOB2_CG_BEGIN':str({begin}),'GLOB2_CG_END':str({end})}}}},indent=2)+'\\n')
with (folder/'reference.log').open('w') as log:subprocess.run(reference,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
with (folder/'probe-native.log').open('w') as log:subprocess.run(probe_native,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
env.update(GLOB2_CG_BEGIN=str({begin}),GLOB2_CG_END=str({end}))
with (folder/'measured.log').open('w') as log:subprocess.run(measured,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
a=json.loads((folder/'reference/result.json').read_text());b=json.loads((folder/'measured/result.json').read_text());native=json.loads((folder/'probe-native/result.json').read_text())
assert a['ticks']==b['ticks']==native['ticks']=={end+1}, 'Did not reach requested end tick'
for key in ['ticks','initialChecksum','finalChecksum']:assert a[key]==native[key]==b[key], (key,a[key],native[key],b[key])
dumps=[]
for path in sorted(folder.glob('callgrind.out.*')):
 if not path.stat().st_size:continue
 header=path.read_text().split('events:',1)[0]
 thread=next(int(line.split(':',1)[1]) for line in header.splitlines() if line.startswith('thread:'))
 dumps.append({{'path':str(path),'thread':thread,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}})
assert len([r for r in dumps if r['thread']==1])==1, 'Expected one serial headless owner thread dump'
result={{'name':{name!r},'begin_inclusive':{begin},'end_exclusive':{end},'measured_ticks':{end-begin},'continued_to_tick':{end+1},'native_reference_final_checksum':a['finalChecksum'],'instrumented_native_final_checksum':native['finalChecksum'],'callgrind_final_checksum':b['finalChecksum'],'matching_final_checksums':True,'dumps':dumps,'free_bytes_after':shutil.disk_usage('/work').free}}
(folder/'comparison.json').write_text(json.dumps(result,indent=2)+'\\n');print(json.dumps(result))
''')
            case = json.loads(result_text)
            manifest['cases'].append(case); save_manifest()
            host_case = output/name; host_case.mkdir()
            for filename in ('commands.json','comparison.json','reference.log','probe-native.log','measured.log','valgrind.log',
                             'reference/result.json','probe-native/result.json','measured/result.json'):
                copy_out(folder+'/'+filename, host_case/filename)
            thread_totals = {}
            for dump in case['dumps']:
                path = Path(dump['path']); raw = host_case/path.name
                copy_out(str(path), raw)
                parsed = host_case/f'thread-{dump["thread"]}.json'
                run([sys.executable,str(root/'artifacts/single-observation/parse_callgrind.py'),str(raw),str(parsed)],
                    log=f'{name}/parse-thread-{dump["thread"]}.log')
                data=json.loads(parsed.read_text()); counts=Counter()
                for row in data['lines']:counts[(row['file'],row['line'])]+=row['ir']
                compact={'self_total':data['self_total'],'thread':dump['thread'],
                         'lines':[{'file':f,'line':line,'ir':cost} for (f,line),cost in counts.most_common()]}
                parsed.write_text(json.dumps(compact,separators=(',',':'))+'\n')
                thread_totals[str(dump['thread'])]=data['self_total']
                with raw.open('rb') as source,gzip.open(str(raw)+'.gz','wb') as target:
                    import shutil
                    shutil.copyfileobj(source,target)
                raw.unlink()
                if dump['thread']==1:
                    owner=host_case/'owner.json';owner.write_bytes(parsed.read_bytes())
                    run([sys.executable,str(root/'artifacts/single-observation/classify_owner.py'),str(owner),
                         '--source-root',str(root),'-o',str(host_case/'micro.json')])
            case['thread_ir']=thread_totals
            case['owner_ir']=thread_totals['1']
            case['all_threads_ir']=sum(thread_totals.values())
            case['owner_ir_per_measured_tick']=case['owner_ir']/case['measured_ticks']
            save_manifest()
        manifest['status']='complete'
    except BaseException as error:
        manifest['status']='failed';manifest['error']=repr(error)
        raise
    finally:
        if backup_created:
            try:
                remote_python(f'''
from pathlib import Path
import hashlib,json,runpy
backup=Path({clean_source!r});target=Path({ENGINE!r})
target.write_bytes(backup.read_bytes())
assert hashlib.sha256(target.read_bytes()).hexdigest()=={expected_engine!r}
identity=runpy.run_path('/work/test/build_provenance.py')['source_identity'](Path('/work'))
assert identity['sourceTreeSha256']=={manifest['provenance']['source_identity']['sourceTreeSha256']!r}, 'Source changed beyond temporary instrumentation'
print(json.dumps({{'restored_source_identity':identity}}))
print('Restored clean EngineRun source; retained probe executable, stripped reference and raw evidence.')
''', log='restore-source.log')
                manifest['source_restored']=True
            except BaseException as error:
                manifest['source_restored']=False;manifest['restore_error']=repr(error)
                print('SOURCE RESTORE FAILED: use manifest restore_command.', file=sys.stderr)
                save_manifest()
                raise
        manifest['finished_utc']=datetime.now(timezone.utc).isoformat()
        save_manifest()
    print('Complete:',output/'manifest.json',flush=True)


if __name__=='__main__':
    main()
