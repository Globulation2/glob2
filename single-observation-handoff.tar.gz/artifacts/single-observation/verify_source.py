import hashlib,json,os
from pathlib import Path
manifest=json.loads(Path('/tmp/source-sha256.json').read_text())
errors=[]
for name,expected in manifest.items():
 p=Path('/work')/name
 kind='symlink' if p.is_symlink() else 'file'
 try:
  data=os.readlink(p).encode() if kind=='symlink' else p.read_bytes()
  actual=hashlib.sha256(data).hexdigest()
 except OSError as e:
  errors.append(f'{name}: {e}');continue
 if kind!=expected['kind'] or actual!=expected['sha256']:errors.append(name)
if errors:raise SystemExit('\n'.join(errors))
print(f'Verified {len(manifest)} tracked source files against worktree hashes')
