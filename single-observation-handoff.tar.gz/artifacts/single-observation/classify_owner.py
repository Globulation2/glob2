#!/usr/bin/env python3
"""Exclusive source-line partition of parsed owner Callgrind JSON.

Example: python3 artifacts/single-observation/classify_owner.py owner.json -o micro.json
The input is the existing parser's {self_total, lines:[{file,line,ir,...}]}.
Function labels, edges and inclusive costs are deliberately ignored.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path


def source_file(path):
    path = str(path).replace('\\', '/')
    for marker in ('src/', 'libgag/', 'libusl/'):
        at = path.find('/' + marker)
        if at >= 0:
            return path[at + 1:]
        if path.startswith(marker):
            return path
    return path


def anchors(root):
    """Resolve narrow operation sites against source, not unstable debug names."""
    files = ('src/map/Map.h', 'src/team/Team.cpp', 'src/team/TeamStep.cpp',
             'src/field/GradientRelaxation.h', 'src/unit/UnitSerialization.cpp',
             'src/building/Misc.cpp', 'src/team/TeamSerialization.cpp',
             'src/team/stats/TeamStat.cpp', 'src/team/stats/TeamStatsPipeline.cpp',
             'libgag/include/WordChecksum.h', 'src/team/stats/StatsChecksum.h')
    lines = {f: (root / f).read_text().splitlines() for f in files}
    result = {}

    def selected(file, predicate):
        return {i for i, line in enumerate(lines[file], 1) if predicate(line.strip())}

    def span(file, signature):
        start = next(i for i, line in enumerate(lines[file], 1) if signature in line)
        end = next(i for i in range(start + 1, len(lines[file]) + 1)
                   if lines[file][i - 1] == '}')
        return set(range(start, end + 1))

    result['map_coordinates'] = selected('src/map/Map.h', lambda s:
        s.startswith('return ((y & hMask)') or s in ('return x & wMask;', 'return y & hMask;'))
    # Include the tiny inline bodies, since debug attribution may land at their
    # opening/closing lines rather than at the return itself.
    result['map_coordinates'] |= {i + d for i in list(result['map_coordinates']) for d in (-1, 1)}
    integrity = span('src/team/Team.cpp', 'bool Team::integrity(')
    result['team_integrity'] = integrity
    result['integrity_capacity'] = selected('src/team/Team.cpp', lambda s:
        s.startswith(('for (int id=0; id<Building::MAX_COUNT;',
                      'for (int i=0; i<Unit::MAX_COUNT;')) or
        s in ('Building *b=myBuildings[id];', 'Unit *u=myUnits[i];', 'if (b)', 'if (u)')) & integrity
    team_step = span('src/team/TeamStep.cpp', 'void Team::syncStep(')
    result['update_capacity'] = selected('src/team/TeamStep.cpp', lambda s:
        s.startswith(('for (int i = 0; i < Unit::MAX_COUNT;',
                      'for (int i=0; i<Building::MAX_COUNT;')) or
        s in ('Unit *u = myUnits[i];', 'if (u)', 'if(myBuildings[i])')) & team_step
    result['gradient_coordinates'] = selected('src/field/GradientRelaxation.h', lambda s:
        s.startswith(tuple('const size_t ' + variable + ' =' for variable in
                           ('x', 'y', 'left', 'right', 'above', 'row', 'below'))))
    # Both ARM NEON and x86 SSE2 implementations have explicit pointer sites.
    result['gradient_neighbor_pointers'] = selected('src/field/GradientRelaxation.h', lambda s:
        s.startswith(tuple('std::uint16_t *' + name + ' =' for name in
                           ('aboveRun', 'rowRun', 'belowRun'))))
    for file, signature, key in (
        ('src/unit/UnitSerialization.cpp', 'Uint32 Unit::checkSum(', 'unit_checksum'),
        ('src/building/Misc.cpp', 'Uint32 Building::checkSum(', 'building_checksum'),
        ('src/team/TeamSerialization.cpp', 'Uint32 Team::checkSum(', 'team_checksum')):
        result[key] = span(file, signature)
        # Integrated master's diagnostic/non-diagnostic templates perform the
        # actual work; the public wrappers cover only dispatch and return.
        implementation = signature.replace('::checkSum(', '::checkSumImpl(')
        if any(implementation in line for line in lines[file]):
            result[key] |= span(file, implementation)
    stats = 'src/team/stats/TeamStat.cpp'
    result['stats_checksum'] = set()
    for signature in ('Uint32 teamStatsCoreChecksum(', 'Uint32 TeamStats::checkSum(',
                      'Uint32 TeamStats::measurementChecksum(',
                      'void unitStatValue(GAGCore::WordChecksum*'):
        result['stats_checksum'] |= span(stats, signature)
    # These overloads are exclusively fingerprints. The later generic field
    # walkers also serve save/load, so their costs get an ambiguity bucket.
    first = next(i for i, line in enumerate(lines[stats], 1)
                 if line.startswith('template<class T> concept StatisticsChecksum'))
    last = next(i for i in range(first + 1, len(lines[stats]) + 1)
                if lines[stats][i - 1].startswith('// Second byte of each cold'))
    result['stats_checksum'] |= set(range(first, last))
    result['stats_shared_serialization'] = set()
    for signature in ('void measurementFields(', 'void liveStatFields(', 'void smoothedStatFields('):
        result['stats_shared_serialization'] |= span(stats, signature)
    result['stats_pipeline_checksum'] = span('src/team/stats/TeamStatsPipeline.cpp',
                                              'Uint32 TeamStatsPipeline::checkSum(')
    if not all(result.values()):
        raise ValueError('A source anchor matched no lines; review the classifier before use')
    metadata = {
        'source_root': str(root),
        'source_sha256': {f: hashlib.sha256((root / f).read_bytes()).hexdigest() for f in files},
        'line_sites': {k: sorted(v) for k, v in result.items()},
    }
    return result, metadata


def classify(file, line, sites):
    if ((file == 'src/team/Team.cpp' and line in sites['integrity_capacity']) or
            (file == 'src/team/TeamStep.cpp' and line in sites['update_capacity'])):
        return 'Capacity slot iteration and null tests'
    if ((file == 'src/map/Map.h' and line in sites['map_coordinates']) or
            (file == 'src/field/GradientRelaxation.h' and line in sites['gradient_coordinates'])):
        return 'Explicit coordinate wrapping and row/index arithmetic (lower bound)'
    if file == 'src/field/GradientRelaxation.h' and line in sites['gradient_neighbor_pointers']:
        return 'Explicit gradient neighbor row pointer construction (lower bound)'
    if any(x in file for x in ('memcpy.S', 'memmove.S', 'memset.S', 'string_fortified.h',
                               'memcpy_aarch64', 'memset_aarch64')):
        return 'Bulk copying and zeroing'
    if (file.endswith(('/ChecksumStream.h', '/WordChecksum.h', '/StatsChecksum.h')) or
            (file == 'src/unit/UnitSerialization.cpp' and line in sites['unit_checksum']) or
            (file == 'src/building/Misc.cpp' and line in sites['building_checksum']) or
            (file == 'src/team/TeamSerialization.cpp' and line in sites['team_checksum']) or
            (file == 'src/team/stats/TeamStat.cpp' and line in sites['stats_checksum']) or
            (file == 'src/team/stats/TeamStatsPipeline.cpp' and line in sites['stats_pipeline_checksum'])):
        return 'Checksum serialization and direct entity/stat hashing'
    if 'malloc.c' in file:
        return 'Heap allocator implementation'
    if 'shared_ptr_base.h' in file or 'ext/atomicity.h' in file:
        return 'Shared ownership and reference count implementation'
    if any(x in file for x in ('basic_string.h', 'basic_string.tcc', 'char_traits.h', 'strlen_asimd.S')):
        return 'String implementation and strlen'
    if file.startswith(('src/field/', 'src/map/gradient/')) or file.endswith('/arm_neon.h'):
        return 'Other gradient relaxation/frontier/seeding/terrain work'
    if file.startswith('src/building/'):
        return 'Building/material demand/state logic'
    if file == 'src/team/Team.cpp' and line in sites['team_integrity']:
        return 'Other team integrity checks'
    if file.startswith('src/engine/sim/snapshot/'):
        return 'Snapshot packing and bookkeeping in project source'
    if file == 'src/team/stats/TeamStat.cpp' and line in sites['stats_shared_serialization']:
        return 'Shared statistics field serialization (checksum/save attribution ambiguous)'
    if file.startswith('src/team/stats/'):
        return 'Other statistics source work'
    if file.startswith('src/unit/'):
        return 'Other unit state and action source work'
    if file.startswith('src/map/'):
        return 'Other map queries and map maintenance source work'
    if 'stl_vector.h' in file or 'vector.tcc' in file:
        return 'Vector operations attributed to STL headers'
    return 'Other owner bookkeeping/control/runtime'


def analyze(profile, sites, metadata, limit):
    source_lines = Counter()
    for row in profile['lines']:
        cost = int(row['ir'])
        if cost < 0:
            raise ValueError('Negative exclusive instruction count')
        source_lines[(source_file(row['file']), int(row['line']))] += cost
    attributed = sum(source_lines.values())
    total = int(profile.get('self_total', attributed))
    if total < attributed:
        raise ValueError(f'Line total {attributed} exceeds self_total {total}; inspect parser output')
    buckets, files = defaultdict(Counter), defaultdict(Counter)
    for (file, line), cost in source_lines.items():
        buckets[classify(file, line, sites)][(file, line)] += cost
        files[file][(file, line)] += cost

    def top(counter):
        return [{'file': f, 'line': line, 'ir': cost,
                 'percent_owner': round(cost * 100 / total, 6) if total else 0}
                for (f, line), cost in counter.most_common(limit)]

    partition = [{'bucket': name, 'ir': sum(costs.values()),
                  'percent_owner': round(sum(costs.values()) * 100 / total, 6) if total else 0,
                  'top_source_lines': top(costs)} for name, costs in buckets.items()]
    if total > attributed:
        partition.append({'bucket': 'Unattributed exclusive instructions', 'ir': total - attributed,
                          'percent_owner': round((total-attributed)*100/total, 6), 'top_source_lines': []})
    partition.sort(key=lambda x: x['ir'], reverse=True)
    rollup = [{'file': file, 'ir': sum(costs.values()),
               'percent_owner': round(sum(costs.values()) * 100 / total, 6) if total else 0,
               'top_source_lines': top(costs)} for file, costs in files.items()]
    rollup.sort(key=lambda x: x['ir'], reverse=True)
    return {
        'total_owner_ir': total, 'attributed_owner_ir': attributed,
        'partition_ir': sum(b['ir'] for b in partition),
        'caveats': [
            'Input must already contain only the selected simulation owner thread; this helper does not infer thread identity.',
            'Mutually exclusive exclusive-source partition; never inclusive function or edge costs.',
            'Function labels are ignored, including when aggregating identical file/line pairs.',
            'Source buckets mix explicit operation sites with source-domain remainders; they are not independent feature budgets.',
            'Both coordinate buckets are explicit lower bounds: inlined arithmetic may be attributed to callers or surrounding statements.',
            'Optimized debug line attribution does not measure hardware operation counts, cache misses, waiting, or elapsed time.',
            'Checksum source attribution includes WordChecksum, legacy stream hashing, diagnostic/non-diagnostic entity templates and explicit statistics fingerprints. Shared generic stats field walkers are separated because exclusive file/line costs cannot distinguish hashing from save/load instantiations.',
            'Bulk copy covers recognized libc/fortified sites only.',
            'Source anchors must match the profiled binary revision; source hashes and resolved line sites are recorded below.',
        ],
        'source_attribution': metadata, 'micro_buckets': partition,
        'exclusive_file_rollup': rollup, 'top_source_lines': top(source_lines),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('owner_json', type=Path)
    parser.add_argument('-o', '--output', type=Path)
    parser.add_argument('--source-root', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--top-lines', type=int, default=8)
    args = parser.parse_args()
    if args.top_lines < 1:
        parser.error('--top-lines must be positive')
    sites, metadata = anchors(args.source_root.resolve())
    result = analyze(json.loads(args.owner_json.read_text()), sites, metadata, args.top_lines)
    result['input'] = str(args.owner_json.resolve())
    output = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(output)
    else:
        print(output, end='')


if __name__ == '__main__':
    main()
