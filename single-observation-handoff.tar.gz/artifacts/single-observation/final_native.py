#!/usr/bin/env python3
import os,subprocess,sys,time
from pathlib import Path
root=Path.cwd();evidence=root/'artifacts/single-observation';build='build/darwin/client/debug/dev-dev_fast-true-linker-auto'
if len(sys.argv)>1:
 pid=int(sys.argv[1])
 while True:
  try:os.kill(pid,0)
  except ProcessLookupError:break
  time.sleep(1)
env=dict(os.environ,PYTHONPATH=str(root))
def run(label,command,log):
 print('START',label,flush=True)
 with Path(log).open('w') as out:
  result=subprocess.run(command,env=env,stdout=out,stderr=subprocess.STDOUT)
 print('END',label,'exit',result.returncode,'log',str(log),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
command=['python3','tools/dev_build.py','engine-tests','unit-tests',build+'/src/glob2','-j3']
run('consolidated final build',command,'/tmp/single-observation-native-consolidated.log')
base=['python3','test/run_tests.py','--build-dir',build,'--no-display','--timeout','600']
run('regenerate sim64 match',base+['--binary','engine','--update-fixtures','--filter','TurnEngineHarness/the committed*','-j1','--junit',str(evidence/'golden-update.xml')],evidence/'golden-update.log')
run('embed final fixture provenance',command,'/tmp/single-observation-native-provenance-build.log')
filters=['WorldSnapshot/*','ClientChannels/*','SimulationReadPhase/*','SharedWorkerLifecycle/*','AIOrderScheduler/*','AIPipeline/*','TeamStatsPipeline/*','HiringPipeline/*','TurretTargeting/*','EngineSession/*','TurnEngineHarness/*','*Gradient*/*','ResourceGrowth/*','*Save*/*','*Replay*/*','*Version*/*']
args=base+['--binary','engine','-j2','--junit',str(evidence/'final-focused-tests.xml')]
for pattern in filters:args+=['--filter',pattern]
run('final focused engine tests',args,evidence/'final-focused-tests.log')
run('unit suite',base+['--binary','unit','-j2','--junit',str(evidence/'unit-tests.xml')],evidence/'unit-tests.log')
run('native midgame compatibility', ['python3',str(evidence/'validate_midgame.py'),build+'/src/glob2',str(evidence/'fixtures'),str(evidence/'native-validation')],evidence/'native-validation.log')
print('NATIVE VALIDATION COMPLETE',flush=True)
