from pathlib import Path
import re
def edit(name,replacements):
 p=Path(name);s=p.read_text()
 for old,new in replacements:
  assert old in s,(name,old);s=s.replace(old,new)
 p.write_text(s)
# Eligibility now depends only on geometry/resource properties, shared by teams.
for p in Path('src').rglob('*'):
 if p.suffix not in ('.cpp','.h'):continue
 s=p.read_text()
 if 'hasAirRoutingConstraints(' in s:p.write_text(re.sub(r'hasAirRoutingConstraints\([^)]*\)','hasAirRoutingConstraints()',s))
edit('src/map/MapCells.cpp',[
 ('if (flags & (ResourceSeedCache::Terrain | ResourceSeedCache::Forbidden))','if (flags & ResourceSeedCache::Terrain)'),
 ('flags & (ResourceSeedCache::Terrain | ResourceSeedCache::Forbidden));','flags & ResourceSeedCache::Terrain);'),
 ('        cached.forbiddenTeams = 0;\n',''),
 ('            cached.forbiddenTeams |= areaCells[i].forbidden;\n',''),
 ('return cached.resourceBlockers || (cached.forbiddenTeams & teamMask);','return cached.resourceBlockers;')])
edit('src/map/gradient/GradientRuntime.h',[('        Uint32 forbiddenTeams = 0;\n','')])
edit('src/map/Map.h',[
 ('return isFreeForAirUnit(x,y) && !(getForbidden(x,y)&teamMask);','return isFreeForAirUnit(x,y);'),
 ('// Transient air traffic uses local avoidance, never disables direct flight.','// Forbidden paint applies only to ground movement. Transient air traffic\n    // uses local avoidance; neither disables direct flight.')])
edit('src/map/gradient/SeedCells.h',[
 ('const Uint32 mask=Uint32(1)<<team;','const Uint32 mask=swim==AIR_MOVEMENT_CLASS ? 0 : Uint32(1)<<team;'),
 ('(view.areas[i].forbidden&b.teamMask)','(!air && (view.areas[i].forbidden&b.teamMask))')])
edit('src/map/gradient/ResourceSeedCache.cpp',[
 ('// Goals override terrain/buildings, but not immobile units or forbidden paint.','// Ground goals still respect immobile units and forbidden paint.'),
 ('visit(s.forbidden[team], [&](std::size_t index) { output[index] = GRADIENT_FORBIDDEN; });','if (swim!=AIR_MOVEMENT_CLASS)\n        visit(s.forbidden[team], [&](std::size_t index) { output[index] = GRADIENT_FORBIDDEN; });')])
edit('src/map/gradient/SnapshotGradient.cpp',[
 ('visitSeedBits(forbidden[team],[&](size_t i) { output[i]=GRADIENT_FORBIDDEN; });','if(swim!=AIR_MOVEMENT_CLASS)\n        visitSeedBits(forbidden[team],[&](size_t i) { output[i]=GRADIENT_FORBIDDEN; });'),
 ('if (!(view.areas[i].forbidden & mask) && view.occupancy[i].immobileUnit == IMMOBILE_UNIT_NONE)','if (request.swim==AIR_MOVEMENT_CLASS || (!(view.areas[i].forbidden & mask) && view.occupancy[i].immobileUnit == IMMOBILE_UNIT_NONE))')])
edit('src/map/gradient/MapGradientMaterial.cpp',[
 ('if (!(areas[i].forbidden & teamMask) && occupancy[i].immobileUnit == IMMOBILE_UNIT_NONE)','if (swim==AIR_MOVEMENT_CLASS || (!(areas[i].forbidden & teamMask) && occupancy[i].immobileUnit == IMMOBILE_UNIT_NONE))')])
edit('src/map/gradient/MapGradientArea.cpp',[
 ('else if (areaCells[i].forbidden&teamMask)','else if (swimClass!=AIR_MOVEMENT_CLASS && (areaCells[i].forbidden&teamMask))')])
edit('src/map/pathfind/MapPathfindBuilding.cpp',[
 ('if (((areaCells[coordToIndex(x, y)].forbidden) & building->owner->me)!=0)','if (swimClass!=AIR_MOVEMENT_CLASS && ((areaCells[coordToIndex(x, y)].forbidden) & building->owner->me)!=0)')])
edit('src/unit/UnitAction.cpp',[
 ('owner->map->terrainPropertiesAt(posX,posY).airHealthQ8 < 0 || owner->map->isForbidden(posX,posY,owner->me)','owner->map->terrainPropertiesAt(posX,posY).airHealthQ8 < 0')])
edit('src/unit/UnitMovement.cpp',[
 ('&& !(map->areaState()[index].forbidden & owner->me)','&& (performance[FLY] || !(map->areaState()[index].forbidden & owner->me))'),
 ('&& !(owner->map->isForbidden(x, y, owner->me))','&& (performance[FLY] || !map->isForbidden(x, y, owner->me))'),
 ('else if (map->getForbidden(posX, posY)&owner->me)','else if (!performance[FLY] && (map->getForbidden(posX, posY)&owner->me))')])
edit('src/map/pathfind/MapTerrainSafety.cpp',[
 ('const bool forbidden = (map.getForbidden(x, y) & team);','const bool forbidden = !air && (map.getForbidden(x, y) & team);'),
 ('terrain.flyable && !map.resourceBlocksAir(index) && (!forbidden || escapeForbidden)','terrain.flyable && !map.resourceBlocksAir(index)'),
 ('if (air) return map.isFreeForAirUnit(x,y) && (escapeForbidden || !(map.getForbidden(x,y)&team));','if (air) return map.isFreeForAirUnit(x,y);'),
 ('bool(getForbidden(unit->posX, unit->posY) & unit->owner->me)','!air && bool(getForbidden(unit->posX, unit->posY) & unit->owner->me)')])
edit('src/game/SimRevision.h',[('#define SIM_REVISION 71','#define SIM_REVISION 72')])
