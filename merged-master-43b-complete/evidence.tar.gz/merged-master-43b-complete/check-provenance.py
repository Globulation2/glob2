from pathlib import Path
import json,hashlib,subprocess,sys
root=Path.cwd();base=root/'artifacts/ci-recovery/merged-43b';rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();checks=[]
for relative,threaded in [('script-corpus/chromium/manifest.json',False),('script-corpus-threaded/chromium/manifest.json',True),('shared-generators/serial/chromium/manifest.json',False),('shared-generators/threaded/chromium/manifest.json',True)]:
 p=root/'artifacts/browser-determinism'/relative;m=json.loads(p.read_text());binary=root/'build/ci-recovery-web';binary=binary/'threaded' if threaded else binary
 match=all(hashlib.sha256((binary/name).read_bytes()).hexdigest()==digest for name,digest in m['binaries'].items())
 source=m['revision']==m['build']['revision']==rev and not m['dirty'] and not m['build']['dirty'] and not m['provenanceIssues'] and m['sourceTreeSha256']==m['build']['sourceTreeSha256']
 checks.append({'manifest':relative,'binaryHashesMatch':match,'sourceAndEmbeddedRevisionMatch':source,'revision':m['revision'],'dirty':m['dirty']});assert match and source,checks[-1]
sys.path.insert(0,str(root/'.github/scripts'));import ci_policy
selection=json.loads((base/'ci-selection.json').read_text());assert selection['sha']==rev and selection['full_matrix'] and selection['checkpoint_eligible'] and not selection['tiers_enabled'] and all(selection['selection'].values());assert selection['policy_fingerprint']==ci_policy.fingerprint()
result={'source':rev,'manifests':checks,'hostedFullSelectionMatchesCurrentPolicy':True,'policyFingerprint':ci_policy.fingerprint()};(base/'manifest-integrity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
