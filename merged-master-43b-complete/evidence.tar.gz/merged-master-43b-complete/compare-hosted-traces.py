from pathlib import Path
import subprocess,json,zipfile,io,hashlib
b=Path('artifacts/ci-recovery/merged-43b');out=b/'hosted-match-traces';out.mkdir(exist_ok=True);receipt=[];traces=[]
for line in (b/'hosted-trace-artifacts.jsonl').read_text().splitlines():
 a=json.loads(line);raw=subprocess.check_output(['gh','api',f"repos/Globulation2/glob2/actions/artifacts/{a['id']}/zip"]);found=[]
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  for name in z.namelist():
   if name.endswith('verify-match.checksums.txt'):
    p=out/a['name']/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name));traces.append(p);found.append(str(p.relative_to(out)))
 receipt.append(dict(a,archiveSha256=hashlib.sha256(raw).hexdigest(),matchTraces=found))
ref=Path('test/fixtures/multiplayer/FourSquares1.verify-trace.txt').read_bytes().replace(b'\r\n',b'\n');assert ref.count(b'\n')>600
for p in traces:assert p.read_bytes().replace(b'\r\n',b'\n')==ref,p
assert len(traces)==10,len(traces)
result={'run':38916805749,'revision':'43b153739838207983c922ab4cbeed7773459de9','allTenSelectedMatchVerifyTracesMatchCommittedGolden':True,'normalizedSha256':hashlib.sha256(ref).hexdigest(),'artifacts':receipt};(b/'hosted-match-traces.json').write_text(json.dumps(result,indent=2)+'\n');print('All 10 selected hosted Linux, Windows, macOS and browser match-verify traces match the committed per-tick golden')
