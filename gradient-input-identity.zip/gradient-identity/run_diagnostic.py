"""Untimed sequential prepared-input identity plus full priority trace parity."""
import json,os,sys,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'test'))
from benchmark_resource_refactor import capture_inputs,digest,stable_campaign,write_json
from compare_save_continuation import compare
os.environ['LD_LIBRARY_PATH']='/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib'
DATA=BASE/'merged-reference';MANIFEST=BASE/'priority-recovery/priority-windows.json'
BINS={'baseline':DATA/'glob2','diagnostic':HERE/'glob2'}
manifest=json.loads(MANIFEST.read_text());OUT=HERE/'runs';OUT.mkdir(exist_ok=False)
fixtures={Path(p) for s in manifest['scenarios'] for p in s['fixture_sha256']}
fixtures|={Path(__file__),HERE/'provenance.json',HERE/'diagnostic.patch'}
report={'timing_valid':False,'scope':'Two single-map8192-tick CLI continuations. Registry/profile pointer misses conservatively undercount duplicates. No reuse or optimization.','runs':[],'comparisons':[]}
with stable_campaign(OUT,lambda:capture_inputs(BINS,{'merged':DATA},MANIFEST,fixtures)):
 for scenario in manifest['scenarios']:
  traces={}
  for arm,binary in BINS.items():
   dest=OUT/scenario['id']/arm;dest.mkdir(parents=True)
   env=dict(os.environ);env['GLOB2_GRADIENT_IDENTITY_OUTPUT']=str(dest/'identity.json')
   command=[str(binary),'--run-game',*scenario['args'],'--benchmark-warmup','0','--telemetry','checksums','--save','final','--output-dir',str(dest)]
   write_json(dest/'command.json',{'command':command,'cwd':str(DATA),'diagnostic_env':env['GLOB2_GRADIENT_IDENTITY_OUTPUT'],'timing_valid':False})
   with (dest/'engine.log').open('w') as log:
    process=subprocess.Popen(command,cwd=DATA,env=env,stdout=log,stderr=subprocess.STDOUT)
    try: code=process.wait(timeout=600)
    except BaseException:
     process.kill();process.wait();raise
   if code: raise RuntimeError(f'{arm} failed {code}: {dest}')
   result=json.loads((dest/'result.json').read_text())
   if result['benchmark_measured_ticks']!=8192 or result['ticks']!=32768: raise RuntimeError('Incomplete priority window')
   traces[arm]=dest/'game.replay.checksums'
   row={'scenario':scenario['id'],'arm':arm,'ticks':result['ticks'],'measured_ticks':result['benchmark_measured_ticks'],'trace_sha256':digest(traces[arm]),'gradient_jobs':result['gradient_jobs'],'gradient_published':result['gradient_published']}
   if arm=='diagnostic':
    identity=json.loads((dest/'identity.json').read_text());row['identity']=identity
    row['totals']={key:sum(f[key] for f in identity['fields']) for key in ('submissions','comparable','identical','seed_changed','other_changed','registry_pointer_misses','profile_pointer_misses')}
   report['runs'].append(row);write_json(OUT/'summary.json',report)
   print(scenario['id'],arm,'complete',row.get('totals'),flush=True)
  count=compare(traces['baseline'],traces['diagnostic'])
  full=digest(traces['baseline'])==digest(traces['diagnostic'])
  if count!=8192 or not full: raise RuntimeError('Diagnostic trace mismatch')
  report['comparisons'].append({'scenario':scenario['id'],'consecutive_records':count,'full_trace_identical':full})
  write_json(OUT/'summary.json',report)
print('Both full priority traces identical; diagnostic evidence retained',flush=True)
