from pathlib import Path
import hashlib,json,zipfile,sys,datetime
root=Path.cwd(); base=root/'artifacts/resource-refactor'; out=base/'native-4ca-publication';out.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
groups={
 'native-4ca-broad': ['native-da80-all*'],
 'native-4ca-focused-display': ['native-prepared-query*','display-da80*','native-da80-final-build.log','native-4ca-final-build.log','native-da80-determinism','native-4ca-determinism','browser-replay-140-refresh.json','building-material-name-audit'],
 'native-4ca-performance-diagnostics': ['calibration-4ca*','performance-4ca-legacy*','middle-diagnostics-4ca','window-preflights-f0-da80dbaac*','master-f0-controls-summary.json','master-f0-pure-provenance.json','master-f0-approved-provenance.json','master-f0-approved-actual.patch','query-optimization-diagnostic/prepared-query-comparison.json','candidate-da80dbaac/*.json','candidate-4ca3b6eb6/*.json']}
summary={'source_revision':'4ca3b6eb63bd6b71055ba238be9fd33de15da79d','production_revision':'da80dbaac80284db77c5ee6e1de64ac6c772fe00','base_revision':'e53a673b2609175e781ad2608a15a220866cf2fa','candidate_cli_sha256':'6233113cc96911197f7c44248dc225499248efa8cf590ea998fa61189b99a68a','production_identity':'4ca merges browser fixture changes only; clean 4ca CLI byte-identical to frozen da80 CLI. Native broad/focused/display executed at da80; 4ca clean build and traces retained. No embedded Git label is claimed.','native':{'broad':{'cases':1911,'passed':1763,'skipped':148,'failures':0,'errors':0},'focused':{'cases':362,'passed':361,'skipped':1,'failures':0,'errors':0},'display':{'passed':9,'failures':0}},'performance_acceptance':False,'performance_status':'Full98 campaign stopped after completed eight-pair middle scenario credibly failed individual5%CPU limit. Ratio1.1858837664, CI[1.1766913936,1.1957015741]. Every row retained; inputs unchanged. No full-corpus aggregate. Three-arm diagnosis reproduces candidate terminalstate with approvedfixcontrol; fixes do not waive user gate.','limitations':['Final platform refresh pending for current source.','Final candidate gameplay tournament pending.','Eight-team and component stress pending.','macOS/iOS/physical ARM and human gameplay review not verified.','Executables, symbolized binaries, dependencies and full source not bundled; hashes and source revisions identify them.','Raw diagnostics are not acceptance CPU measurements.'], 'archives':[]}
for name,patterns in groups.items():
 paths=set()
 for pattern in patterns:
  matches=list(base.glob(pattern))
  if not matches:print('No match',pattern,flush=True)
  for p in matches:
   if p.is_file():paths.add(p)
   else:paths.update(q for q in p.rglob('*') if q.is_file())
 if 'performance' in name:
  paths.add(root/'test/benchmark_resource_refactor.py');paths.add(root/'test/benchmark_parallel_compute.py')
  paths.add(base/'run_aligned_window_preflights.py')
 paths.add(Path(__file__).resolve())
 inventory={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(paths)}
 dest=out/(name+'.zip')
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(paths):z.write(p,str(p.relative_to(root)))
  z.writestr('file-inventory.json',json.dumps(inventory,indent=2)+'\n')
 with zipfile.ZipFile(dest) as z:
  assert set(z.namelist())==set(inventory)|{'file-inventory.json'}
  for p,record in inventory.items():
   h=hashlib.sha256()
   with z.open(p) as f:
    for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
   assert h.hexdigest()==record['sha256'],p
 assert dest.stat().st_size<95_000_000,(dest,dest.stat().st_size)
 summary['archives'].append({'path':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest),'files':len(inventory),'verification':'Every decompressed member SHA256 matches retained source bytes.'})
 print(summary['archives'][-1],flush=True)
(out/'native-4ca-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
