import json, sys
sys.path.insert(0, '.')
from tools import gradient_depth_fit as F
summary = json.load(open('tools/gradient_depth_model.json'))
table = F.table_from_summary(summary)
out = {}
for name, path in (('all', '../depth-all.json.gz'), ('busy', '../depth-busy.json.gz'),
                   ('tournament', '../depth-dataset.json.gz')):
    games, lives = F.load_dataset(path)
    model = [(l, F.predict(table, summary['keys'], summary['per_size'], l)) for l in lives]
    hint = [(l, max(32, (l.previous * 5 // 4) if l.previous is not None else 32)) for l in lives]
    full = [(l, F.MAX_DEPTH) for l in lives]
    out[name] = {'fitted_in_sample': F.metrics(model), 'hint_prev_5_4': F.metrics(hint), 'full_depth': F.metrics(full)}
    print(name, json.dumps(out[name]))
json.dump(out, open('../compare.json', 'w'), indent=2)
