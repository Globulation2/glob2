#!/usr/bin/env python3
"""Field-search share of process CPU per scenario (flag off, pinned, serial)."""
import json, os, shlex, subprocess, sys
from pathlib import Path
base = Path.home() / 'gradient-campaign/pr-a'
src = base / 'src'
binary = str(base / 'bin/glob2-branch2')
os.environ['LD_LIBRARY_PATH'] = '/home/bradley/glob2-verify/sdl3/prefix/lib'
checkpoint = Path.home() / 'glob2-building-gradient-20261004-9520/evidence/busy.game.gz'
oazis = ['--map-file', str(src / 'maps/Oazis.map.gz')] + ['--player', 'maxima'] * 11
scenarios = {
    'busy-window': ['--load-game', str(checkpoint), '--ticks', sys.argv[1] if len(sys.argv) > 1 else '8048'],
    'busy-19': oazis + ['--game-seed', '19', '--ticks', '18048', '--ai-order-delay', '8'],
    'mixed-19': ['--generator', '26', '--map-seed', '4242', '--game-seed', '19', '--param', 'width=7', '--param',
                 'height=7', '--param', 'teams=4', '--param', 'pattern=1', '--player', 'maxima', '--player', 'cortex',
                 '--player', 'nicowar', '--player', 'maxima', '--ticks', '18048', '--ai-order-delay', '8'],
    'small-1': ['--generator', '15', '--map-seed', '1', '--game-seed', '1', '--param', 'width=6', '--param', 'height=6',
                '--param', 'teams=2', '--player', 'maxima', '--player', 'maxima', '--ticks', '18048',
                '--ai-order-delay', '8'],
}
SCOPES = ('gradient.building', 'gradient.building_resume', 'simulation.tick', 'gradient.round_trip', 'gradient.area')
rows = {}
for name, args in scenarios.items():
    d = base / 'share' / name
    d.mkdir(parents=True, exist_ok=True)
    with open(d / 'engine.log', 'w') as log:
        code = subprocess.call([binary, '--run-game', *args, '--benchmark-warmup', '0', '--telemetry', 'team-timeline', '--output-dir', str(d)],
                               stdout=log, stderr=subprocess.STDOUT, cwd=src)
    if code:
        rows[name] = {'exit': code}
        print(name, 'exit', code, flush=True)
        continue
    result = json.loads((d / 'result.json').read_text())
    scopes = {}
    for line in (d / 'engine.log').read_text(errors='replace').splitlines():
        if line.startswith('GLOB2_PERF_FINAL'):
            f = dict(p.split('=', 1) for p in shlex.split(line)[1:] if '=' in p)
            if f.get('scope') in SCOPES and f.get('total_ns', 'na') != 'na':
                scopes[f['scope']] = int(float(f['total_ns']))
    cpu = result['benchmark_run_cpu_ns']
    field = scopes.get('gradient.building', 0) + scopes.get('gradient.building_resume', 0)
    rows[name] = dict(ticks=result['benchmark_measured_ticks'], process_cpu_s=cpu / 1e9, run_s=result['run_ns'] / 1e9,
                      scopes_s={k: v / 1e9 for k, v in scopes.items()},
                      field_s=field / 1e9, field_share=field / cpu,
                      resume_share=scopes.get('gradient.building_resume', 0) / cpu)
    print(name, json.dumps(rows[name]), flush=True)
    (d / 'engine.log').unlink()
(base / 'share.json').write_text(json.dumps(rows, indent=2) + '\n')
