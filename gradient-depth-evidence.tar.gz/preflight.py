import json, os, subprocess, shutil
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
base = Path.home() / 'gradient-campaign/pr-a'
binary = base / 'bin/glob2-branch2'
os.environ['LD_LIBRARY_PATH'] = '/home/bradley/glob2-verify/sdl3/prefix/lib'
cat = json.load(open(base / 'catalog.json'))
gens = [g['method'] for g in cat['generators'] if not g.get('editorOnly')]
configs = [(6, 2), (7, 2), (7, 4), (8, 2), (8, 4)]
out = base / 'preflight'


def one(task):
    g, (size, teams) = task
    d = out / f'{g}-{size}-{teams}'
    shutil.rmtree(d, ignore_errors=True)
    try:
        subprocess.run([str(binary), '--generate-map', '--generator', str(g), '--map-seed', '1', '--param', f'width={size}',
                        '--param', f'height={size}', '--param', f'teams={teams}', '--candidates', '5', '--output-dir', str(d)],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=300, cwd=base / 'src')
        status = json.load(open(d / 'result.json'))['status']
    except Exception as e:
        status = 'error:' + type(e).__name__
    shutil.rmtree(d, ignore_errors=True)
    return g, size, teams, status


with ThreadPoolExecutor(6) as pool:
    rows = list(pool.map(one, [(g, c) for g in gens for c in configs]))
json.dump(rows, open(base / 'preflight.json', 'w'), indent=1)
ok = {c: [g for g, s, t, st in rows if (s, t) == c and st == 'completed'] for c in configs}
for c in configs:
    print(c, len(ok[c]))
print('all', sorted(set.intersection(*[set(v) for v in ok.values()])))
