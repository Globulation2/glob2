import hashlib, json, os, subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
base = Path.home() / 'gradient-campaign/pr-a'
src = base / 'src'
os.environ['LD_LIBRARY_PATH'] = '/home/bradley/glob2-verify/sdl3/prefix/lib'
common = ['--ticks', '18048', '--ai-order-delay', '8', '--telemetry', 'team-timeline', '--telemetry', 'checksums',
          '--replay', 'true']
busy = ['--map-file', str(src / 'maps/Oazis.map.gz'), '--game-seed', '19'] + ['--player', 'maxima'] * 11
small = ['--generator', '15', '--map-seed', '1', '--game-seed', '1', '--param', 'width=6', '--param', 'height=6',
         '--param', 'teams=2', '--player', 'maxima', '--player', 'maxima']
runs = {'busy-19-on': ('glob2-head', busy, True), 'busy-19-off': ('glob2-head', busy, False),
        'small-1-on': ('glob2-head', small, True), 'small-1-off': ('glob2-head', small, False),
        'small-1-master': ('glob2-master', small, False), 'busy-19-master': ('glob2-master', busy, False)}


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def run(item):
    name, (binary, args, on) = item
    d = base / 'pairs' / name
    extra = ['--telemetry', 'gradient-stats'] if on else []
    with open(base / 'pairs' / f'{name}.log', 'w') as log:
        code = subprocess.call([str(base / 'bin' / binary), '--run-game', *args, *common, *extra, '--output-dir', str(d)],
                               stdout=log, stderr=subprocess.STDOUT, cwd=src)
    return name, dict(exit=code, binary_sha256=digest(base / 'bin' / binary), checksums_sha256=digest(d / 'game.replay.checksums'),
                      replay_sha256=digest(d / 'game.replay'),
                      final=json.loads((d / 'result.json').read_text())['finalChecksum'],
                      stats_csv=(d / 'gradient-stats.csv').exists())


(base / 'pairs').mkdir(exist_ok=True)
with ThreadPoolExecutor(6) as pool:
    result = dict(pool.map(run, runs.items()))
(base / 'pairs.json').write_text(json.dumps(result, indent=2) + '\n')
for k, v in result.items():
    print(k, json.dumps(v))
