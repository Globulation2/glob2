#!/usr/bin/env python3
"""Telemetry overhead: master vs branch (flag off) vs branch (flag on), interleaved."""
import json, os, resource, subprocess, sys, time
from pathlib import Path
base = Path.home() / 'gradient-campaign/pr-a'
out = base / sys.argv[1]
arms = json.loads(sys.argv[2])  # {name: [binary, extra args...]}
repeats = int(sys.argv[3]) if len(sys.argv) > 3 else 5
os.environ['LD_LIBRARY_PATH'] = '/home/bradley/glob2-verify/sdl3/prefix/lib'
src = base / 'src'
game = ['--map-file', str(src / 'maps/Oazis.map.gz'), '--game-seed', '19', '--ticks', os.environ.get('TICKS', '4096'),
        '--ai-order-delay', '8'] + ['--player', 'maxima'] * 11
rows = []
names = list(arms)
for rep in range(repeats):
    order = names[rep % len(names):] + names[:rep % len(names)]
    if rep % 2: order.reverse()
    for name in order:
        binary, *extra = arms[name]
        d = out / f'{name}-{rep}'
        d.mkdir(parents=True, exist_ok=True)
        load = os.getloadavg()
        start = time.perf_counter()
        with open(d / 'engine.log', 'w') as log:
            p = subprocess.Popen([binary, '--run-game', *game, *extra, '--output-dir', str(d)], stdout=log,
                                 stderr=subprocess.STDOUT, cwd=src)
            _, status, usage = os.wait4(p.pid, 0)
        wall = time.perf_counter() - start
        result = json.loads((d / 'result.json').read_text())
        tick = None
        for line in (d / 'engine.log').read_text(errors='replace').splitlines():
            if line.startswith('GLOB2_PERF_FINAL') and ' scope=simulation.tick ' in line:
                tick = float(line.split(' total_ns=')[1].split()[0]) / 1e9
        row = dict(arm=name, repeat=rep, exit=status, wall_s=wall, run_s=result['run_ns'] / 1e9,
                   tick_s=tick, cpu_s=usage.ru_utime + usage.ru_stime, load=load,
                   final_checksum=result['finalChecksum'])
        rows.append(row)
        print(json.dumps(row), flush=True)
        (d / 'engine.log').unlink()
(out / 'overhead.json').write_text(json.dumps(rows, indent=2) + '\n')
