import subprocess, shutil, json, hashlib
from pathlib import Path
ROOT=Path('/home/bradley/.codex/worktrees/eded/glob2')
CHECKOUT=Path('/home/bradley/.codex/worktrees/resource-browser-7baf/glob2')
OUTPUT=ROOT/'artifacts/resource-followup/platform-closure/browser-reuse'
NATIVE=ROOT/'artifacts/resource-followup/platform-closure/native-determinism'
summary={}
for browser in ['chromium','firefox','webkit']:
    target=OUTPUT/f'parity-{browser}'
    target.mkdir(exist_ok=False)
    command=['npx','playwright','test','determinism.spec.js','--project='+browser,'--grep','WebAssembly produces|WebAssembly verifies|runtime resource composition','--reporter=line']
    with (target/'playwright.log').open('w') as log:
        result=subprocess.run(command,cwd=CHECKOUT/'browser',stdout=log,stderr=subprocess.STDOUT,timeout=2400)
    artifact=CHECKOUT/'artifacts/browser-determinism'
    if artifact.exists():shutil.copytree(artifact,target/'evidence');shutil.rmtree(artifact)
    source=json.loads(subprocess.check_output(['python3','test/build_provenance.py'],cwd=CHECKOUT))
    checks=[]
    for trace in (target/'evidence/wasm').glob('*/*.replay.checksums'):
        checks.append({'file':str(trace.relative_to(target)), 'kind':'stock','matches_native':trace.read_bytes()==(NATIVE/'native.replay.checksums').read_bytes()})
    for trace in (target/'evidence/wasm').rglob('verify-match.checksums.txt'):
        checks.append({'file':str(trace.relative_to(target)), 'kind':'official-match','matches_native':trace.read_text()==(NATIVE/'verify-match.checksums.txt').read_text()})
    for trace in (target/'evidence/resources').rglob('seeded-compositions.trace'):
        checks.append({'file':str(trace.relative_to(target)), 'kind':'composition','rows':len(trace.read_text().splitlines()),'matches_native':trace.read_text()==(ROOT/'test/fixtures/resources/seeded-compositions.trace').read_text()})
    counts={kind:sum(c['kind']==kind for c in checks) for kind in ['stock','official-match','composition']}
    complete=counts=={'stock':4,'official-match':2,'composition':2} and all(c['matches_native'] for c in checks)
    summary[browser]={'complete_matches':complete,'counts':counts,'command':command,'returncode':result.returncode,'source':source,'checks':checks}
    (OUTPUT/'parity-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(browser,result.returncode, len(checks),flush=True)

assert all(s["returncode"]==0 and s["complete_matches"] and not s["source"]["dirty"] for s in summary.values()), summary
