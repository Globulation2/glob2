#!/usr/bin/env python3
"""Summarize PR A campaign runs: verdict shares, kept work, scope seconds, go/no-go."""
import json
import re
import shlex
import sys
from collections import defaultdict
from pathlib import Path

runs = Path(sys.argv[1])
SCOPES = ['gradient.building', 'gradient.building_resume', 'gradient.round_trip', 'gradient.area',
          'gradient.resource', 'gradient.propagation', 'gradient.propagation.round_trip',
          'gradient.propagation.area', 'gradient.propagation.resource', 'simulation.tick']
KEEP = ('keep_team_filter', 'keep_noop', 'keep_untouched')


def scopes(log):
    found = {}
    for line in log.read_text(errors='replace').splitlines():
        if not line.startswith('GLOB2_PERF_FINAL'):
            continue
        fields = dict(part.split('=', 1) for part in shlex.split(line)[1:] if '=' in part)
        if fields.get('scope') in SCOPES:
            total = fields.get('total_ns', fields.get('estimated_total_ns', 'na'))
            found[fields['scope']] = float(total) / 1e9 if total != 'na' else None
    return found


table = defaultdict(list)
for directory in sorted(runs.iterdir()):
    if not (directory / 'result.json').exists() or directory.name.endswith('-off'):
        continue
    result = json.loads((directory / 'result.json').read_text())
    stats = result['building_gradient']
    scenario = directory.name.split('-')[0]
    gen = stats['rebuilds']['generation']
    verdicts = stats['generation_verdicts']
    row = dict(run=directory.name, ticks=result['ticks'], run_s=result['run_ns'] / 1e9,
               rebuilds=stats['rebuilds'], generation=gen, verdicts=verdicts,
               keep_share=sum(verdicts[k] for k in KEEP) / gen if gen else 0.0,
               easy_share=(verdicts['keep_team_filter'] + verdicts['keep_noop']) / gen if gen else 0.0,
               popped_total=stats['popped_total'], popped_kept=stats['popped_kept'],
               popped_generation=stats['popped_by_lifetime_reason']['generation'],
               journal=stats['journal'], unbumped=stats['unbumped'], scopes=scopes(directory / 'engine.log'))
    table[scenario].append(row)

summary = {}
for scenario, rows in table.items():
    gen = sum(r['generation'] for r in rows)
    verdicts = defaultdict(int)
    for r in rows:
        for k, v in r['verdicts'].items():
            verdicts[k] += v
    popped_total = sum(r['popped_total'] for r in rows)
    popped_kept = sum(r['popped_kept'] for r in rows)
    popped_gen = sum(r['popped_generation'] for r in rows)
    scope_mean = {s: sum((r['scopes'].get(s) or 0) for r in rows) / len(rows) for s in SCOPES}
    reasons = defaultdict(int)
    for r in rows:
        for k, v in r['rebuilds'].items():
            reasons[k] += v
    summary[scenario] = dict(
        runs=[r['run'] for r in rows], generation_rebuilds_total=gen,
        generation_rebuilds_per_run=gen / len(rows), rebuilds_by_reason=dict(reasons),
        verdict_shares={k: v / gen if gen else 0 for k, v in verdicts.items()},
        keep_share=sum(verdicts[k] for k in KEEP) / gen if gen else 0,
        easy_share=(verdicts['keep_team_filter'] + verdicts['keep_noop']) / gen if gen else 0,
        kept_popped_share_of_total=popped_kept / popped_total if popped_total else 0,
        kept_popped_share_of_generation=popped_kept / popped_gen if popped_gen else 0,
        generation_popped_share_of_total=popped_gen / popped_total if popped_total else 0,
        scope_seconds_mean=scope_mean, per_run=rows)
busy = summary.get('busy')
if busy:
    summary['go_no_go'] = dict(
        pr_c=busy['keep_share'] >= 0.5 or busy['kept_popped_share_of_total'] >= 0.3,
        easy_wins=busy['easy_share'] >= 0.2,
        keep_share=busy['keep_share'], kept_popped_share_of_total=busy['kept_popped_share_of_total'],
        easy_share=busy['easy_share'])
json.dump(summary, sys.stdout, indent=2)
print()
