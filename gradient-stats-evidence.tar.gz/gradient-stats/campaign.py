#!/usr/bin/env python3
"""PR A data campaign: gradient-stats runs plus telemetry on/off checksum pairs."""
import hashlib
import json
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

base = Path.home() / 'gradient-campaign/pr-a'
src = base / 'src'
binary = src / 'build/linux/client/release/src/glob2'
out = base / 'runs'
os.environ['LD_LIBRARY_PATH'] = '/home/bradley/glob2-verify/sdl3/prefix/lib'
TICKS = '18048'
COMMON = ['--ticks', TICKS, '--ai-order-delay', '8', '--telemetry', 'team-timeline']


def scenario(name, seed):
    if name == 'busy':
        return ['--map-file', str(src / 'maps/Oazis.map.gz'), '--game-seed', str(seed)] + ['--player', 'maxima'] * 11
    if name == 'mixed':
        return ['--generator', '26', '--map-seed', '4242', '--game-seed', str(seed), '--param', 'width=7',
                '--param', 'height=7', '--param', 'teams=4', '--param', 'pattern=1', '--player', 'maxima',
                '--player', 'cortex', '--player', 'nicowar', '--player', 'maxima']
    if name == 'small':
        return ['--generator', '15', '--map-seed', str(seed), '--game-seed', str(seed), '--param', 'width=6',
                '--param', 'height=6', '--param', 'teams=2', '--player', 'maxima', '--player', 'maxima']
    raise ValueError(name)


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def run(label, args):
    directory = out / label
    if (directory / 'result.json').exists():
        return label, json.loads((directory / 'run.json').read_text())
    directory.mkdir(parents=True, exist_ok=True)
    command = [str(binary), '--run-game', *args, '--output-dir', str(directory)]
    started = time.time()
    with open(directory / 'engine.log', 'w') as log:
        code = subprocess.call(command, stdout=log, stderr=subprocess.STDOUT, cwd=src)
    info = dict(label=label, command=command, exit=code, wall_s=time.time() - started)
    checksums = directory / 'game.replay.checksums'
    if checksums.exists():
        info['checksums_sha256'] = digest(checksums)
        info['checksums_bytes'] = checksums.stat().st_size
    (directory / 'run.json').write_text(json.dumps(info, indent=2) + '\n')
    return label, info


jobs = []
pairs = {('busy', 19), ('mixed', 19), ('small', 1)}
for name, seeds in (('busy', (19, 23, 29, 31, 37)), ('mixed', (19, 20, 21)), ('small', (1, 2, 3))):
    for seed in seeds:
        args = scenario(name, seed) + COMMON + ['--telemetry', 'gradient-stats']
        if (name, seed) in pairs:
            args += ['--telemetry', 'checksums', '--replay', 'true']
        jobs.append((f'{name}-{seed}', args))
for name, seed in sorted(pairs):
    jobs.append((f'{name}-{seed}-off', scenario(name, seed) + COMMON + ['--telemetry', 'checksums', '--replay', 'true']))
# Longest first.
jobs.sort(key=lambda j: (not j[0].startswith('busy'), not j[0].startswith('mixed')))
workers = int(sys.argv[1]) if len(sys.argv) > 1 else 12
results = {}
with ThreadPoolExecutor(workers) as pool:
    futures = [pool.submit(run, label, args) for label, args in jobs]
    for future in as_completed(futures):
        label, info = future.result()
        results[label] = info
        print('DONE', label, info['exit'], round(info['wall_s'], 1), info.get('checksums_sha256', ''), flush=True)
(out / 'campaign.json').write_text(json.dumps(results, indent=2) + '\n')
for name, seed in sorted(pairs):
    on, off = results[f'{name}-{seed}'], results[f'{name}-{seed}-off']
    print('PAIR', name, seed, on.get('checksums_sha256') == off.get('checksums_sha256'), on.get('checksums_sha256'))
