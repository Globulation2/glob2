from pathlib import Path
import json
root=Path('artifacts/food-redesign/rotations-final');rows=[]
for g in [58,70,62,64,65]:
 for rotation in range(4):
  p=root/f'{g}-r{rotation}/result.json'
  if not p.exists():continue
  d=json.loads(p.read_text());log=root/f'{g}-r{rotation}.log';last={}
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-8*1024*1024));tail=f.read().decode(errors='replace')
  for line in tail.splitlines():
   if line.startswith('GLOB2_MEASURE '):
    t=dict(s.split('=',1) for s in line.split()[1:]);last[t['team']]=t
  for p in d['players']:
   t=last.get(str(p['team']),{});rows.append(dict(generator=g,rotation=rotation,team=p['team'],ai=p['ai'],ticks=d['ticks'],termination=d['termination'],delivered_food=int(t.get('delivered_1',0)),workers_born=int(t.get('births_0',0)),warriors_born=int(t.get('births_2',0)),worker_starvation=int(t.get('deaths_0_1',0)),warrior_starvation=int(t.get('deaths_2_1',0)),worker_combat_deaths=int(t.get('deaths_0_0',0)),warrior_combat_deaths=int(t.get('deaths_2_0',0))))
(root.parent/'rotation-summary.json').write_text(json.dumps(rows,indent=2))
for g in [58,70,62,64,65]:
 print('generator',g)
 for ai in ['nicowar','maxima','cortex','cabino']:
  rs=[r for r in rows if r['generator']==g and r['ai']==ai]
  print(ai,[(r['rotation'],r['delivered_food'],r['warriors_born'],r['worker_starvation']) for r in rs])
