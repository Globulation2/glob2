from pathlib import Path
import subprocess,concurrent.futures,json,sys
prefix=sys.argv[1]
b=str(Path(sys.argv[2] if len(sys.argv)>2 else 'build/darwin/client/release/src/glob2').resolve())
def gen(g):
 p=Path(f'artifacts/food-redesign/{prefix}-{g}').resolve()
 cmd=[b,'--generate-map','--generator',str(g),'--map-seed','7','--param','width=8','--param','height=8','--param','teams=4','--write-map','true','--report','terrain','--output-dir',str(p)]
 with open(str(p)+'.log','w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 result=json.loads((p/'result.json').read_text());print(g,r.returncode,result.get('diagnostic'),flush=True)
 if not r.returncode:
  records=result['map_report']['generation']['telemetry']['records']
  print([(x['key'],x['value']) for x in records if 'meadow' in x['key']],flush=True)
  subprocess.run([sys.executable,'.agents/skills/glob2-map-design/scripts/render_terrain.py',str(p/'terrain.txt'),str(p)+'.png','--scale','3'],check=True)
  colonies=result['map_report']['map']['colonies']
  args=[str(v) for c in colonies for v in [c['start']['x'],c['start']['y']]]
  with (p/'growth.txt').open('w') as f:subprocess.run(['artifacts/food-redesign/growth-potential',str(p/'terrain.txt'),*args],stdout=f,check=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(gen,[int(x) for x in sys.argv[3:]] or [58,70,62,64]))
