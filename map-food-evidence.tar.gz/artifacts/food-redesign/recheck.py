import json,sys,concurrent.futures
from pathlib import Path
sys.path.insert(0,str(Path('.').resolve()))
from tools.map_generation_study import generate_map,report_metrics
b=str(Path(sys.argv[1]).resolve());name=sys.argv[2];g=int(sys.argv[3]);limit=int(sys.argv[4])
rows=json.loads(Path('artifacts/food-redesign/sweep-v6.metadata.json').read_text())['jobs'];rows=[r for r in rows if r['g']==g][int(sys.argv[5]) if len(sys.argv)>5 else 0:limit]
def run(j):
 r=generate_map(b,j['g'],j['seed'],j['w'],j['h'],j['teams'],j['options']);n=r.pop('native');r.update(j)
 if n and n.get('map_report'):r['metrics'],r['telemetry']=report_metrics(n['map_report'])
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p,open(f'artifacts/food-redesign/{name}.jsonl','w') as f:
 for r in p.map(run,rows):
  f.write(json.dumps(r)+'\n');f.flush()
  if r['category']!='completed':print(r['seed'],r['detail'],flush=True)
