import json,sys,re
from pathlib import Path
rows=[]
for prefix in sys.argv[1:]:
 for file in sorted(Path('artifacts/food-redesign').glob(prefix+'-*-*.log')):
  m=re.fullmatch(re.escape(prefix)+r'-(\d+)-(nicowar|maxima|cortex|cabino)',file.stem)
  if not m:continue
  last={}
  with file.open("rb") as handle:
   handle.seek(max(0,file.stat().st_size-8*1024*1024));tail=handle.read().decode(errors="replace")
  for line in tail.splitlines():
   if line.startswith('GLOB2_MEASURE '):
    d=dict(s.split('=',1) for s in line.split()[1:]);last[d['team']]=d
  if len(last)<4:
   for line in file.open():
    if line.startswith("GLOB2_MEASURE "):
     d=dict(s.split("=",1) for s in line.split()[1:]);last[d["team"]]=d
  if not last:continue
  sums={k:sum(int(v.get(k,0)) for v in last.values()) for k in ['births_0','births_2','harvested_1','delivered_1','harvested_0','deaths_0_1','deaths_2_1','deaths_0_0','deaths_2_0']}
  resultPath=file.with_suffix('')/'result.json'
  if not resultPath.exists():resultPath=Path('artifacts/food-redesign/artifacts/food-redesign')/file.stem/'result.json'
  result=json.loads(resultPath.read_text()) if resultPath.exists() else {}
  row=dict(prefix=prefix,generator=int(m[1]),ai=m[2],ticks=result.get('ticks',max(int(v['tick']) for v in last.values())),termination=result.get('termination','running'),totals=sums,teams=last);rows.append(row)
  print(prefix,m[1],m[2],row['ticks'],sums)
Path('artifacts/food-redesign/economy-summary.json').write_text(json.dumps(rows,indent=2))
