from pathlib import Path
import sys,subprocess,concurrent.futures,json
b=str(Path(sys.argv[1]).resolve());root=Path('artifacts/food-redesign/rotations-final').resolve();root.mkdir(exist_ok=True)
generators=[int(g) for g in sys.argv[2:]] or [58,70,62,64,65]
for g in generators:
 out=root/str(g)
 cmd=[b,'--generate-map','--generator',str(g),'--map-seed','401','--candidates','5','--param','width=8','--param','height=8','--param','teams=4','--write-map','true','--rotations','4','--report','terrain','--output-dir',str(out)]
 with (root/f'{g}-generation.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print('generation',g,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
def run(j):
 g,rotation=j;out=root/f'{g}-r{rotation}'
 cmd=[b,'--run-game','--map-file',str(root/str(g)/f'map-r{rotation}.map'),'--game-seed','19','--ticks','15000','--save','final','--telemetry','team-timeline','--output-dir',str(out)]
 for ai in ['nicowar','maxima','cortex','cabino']:cmd+=['--player',ai]
 with Path(str(out)+'.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print('game',g,rotation,r.returncode,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:list(p.map(run,[(g,r) for g in generators for r in range(4)]))
