import subprocess, concurrent.futures,sys
from pathlib import Path
prefix=sys.argv[1];binary=str(Path(sys.argv[2]).resolve())
jobs=[(g,ai) for g in ([int(g) for g in sys.argv[3:]] or [58,70]) for ai in ['nicowar','maxima','cortex','cabino']]
def run(job):
 g,ai=job;out=Path(f'artifacts/food-redesign/{prefix}-{g}-{ai}').resolve()
 cmd=[binary,'--run-game','--map-file',str(Path(f'artifacts/food-redesign/{prefix}-{g}/map-r0.map').resolve()),'--game-seed','1','--ticks','25000','--telemetry','team-timeline','--save','final','--output-dir',str(out)]
 for _ in range(4):cmd+=['--player',ai]
 with Path(str(out)+'.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 print(prefix,g,ai,r.returncode,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:list(p.map(run,jobs))
