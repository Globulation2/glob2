import json, sys
from pathlib import Path
from collections import Counter

def check(folder):
    path=Path(folder)
    result=json.loads((path/'result.json').read_text())
    assert result['status']=='completed', result
    rows=(path/'terrain.txt').read_text().splitlines()
    w,h=map(int,rows[0].split()); grid=[int(x) for row in rows[1:] for x in row.split()]
    seen=set(); islands=[]
    for i,v in enumerate(grid):
        if i in seen or v in (2,9): continue
        todo=[i]; seen.add(i)
        for p in todo:
            x,y=p%w,p//w
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    q=((y+dy)%h)*w+(x+dx)%w
                    if q not in seen and grid[q] not in (2,9): seen.add(q);todo.append(q)
        if len(todo)>1000: continue
        counts=Counter(grid[p] for p in todo)
        assert counts[0]==40, (path, i, 'unplanted grass outside 40-tile court',counts)
        assert counts[4]>0 and not any(counts[k] for k in (5,6,7,8)), (path,i,counts)
        islands.append(dict(counts))
    assert islands, path
    return {'directory':str(path),'islets':len(islands),'wheat':sum(i.get(4,0) for i in islands),'seconds':result['seconds']}
if __name__=='__main__':
    for folder in sys.argv[1:]: print(json.dumps(check(folder)))
