import concurrent.futures, itertools, json, subprocess
from pathlib import Path
from check_islets import check
root=Path.cwd(); out=root/'artifacts/city-states-wheat'
binary=root/'build/darwin/client/release/src/glob2'
jobs=list(itertools.product([(7,7),(8,8),(9,8),(8,9),(9,9)], [1,7,31], [0,100,200]))
def run(job):
    (w,h),seed,amount=job
    folder=out/f'case-{w}-{h}-{seed}-{amount}'
    cmd=[str(binary),'--generate-map','--generator','17','--map-seed',str(seed),'--param','teams=4','--param',f'width={w}','--param',f'height={h}','--report','terrain','--output-dir',str(folder)]
    for name in ('wheat','wood','stone','fruit','algae'):cmd += ['--param',f'{name}-amount={amount}']
    with (out/f'{folder.name}.log').open('w') as log:
        completed=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
    assert completed.returncode==0, (cmd,completed.returncode)
    return check(folder)|{'command':cmd}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    rows=list(pool.map(run,jobs))
(out/'sweep-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print(f'PASS {len(rows)} maps; {sum(r["islets"] for r in rows)} islets; full wheat cover and exactly 40 clear grass tiles per islet')
