"""Plan-only by default; coordinator-scheduled profiles are never timing evidence."""
import argparse,hashlib,importlib.util,json,os,pwd,signal,struct,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('campaign',BASE/'final-campaign/run_final_timing.py');campaign=importlib.util.module_from_spec(spec);spec.loader.exec_module(campaign)
SYMBOLS={'merged':BASE/'symbolized-merged/glob2','reuse-v2':BASE/'symbolized-reuse-v2/glob2'}
SELECT=[('water-2-1002-nicowar-early',BASE/'final-campaign/legacy-98-windows.json',('merged','reuse-v2')),('land-2-1002-maxima-late',BASE/'priority-recovery/priority-windows.json',('reuse-v2','merged')),('stress-512-0',BASE/'final-campaign/custom-stress-timing-windows.json',('merged','reuse-v2'))]
RESULT_ROOTS={'water-2-1002-nicowar-early':BASE/'final-campaign/isolated-v2-legacy-01/v2-legacy','land-2-1002-maxima-late':BASE/'priority-timing/gradient-reuse-v2-isolated-01/v2-priority','stress-512-0':BASE/'final-campaign/isolated-v2-custom-01/v2-custom'}
def expected_checksums(name):
 rows=[json.loads((RESULT_ROOTS[name]/name/'0'/arm/'result.json').read_text()) for arm in ('baseline','candidate')]
 assert all(row['status']=='completed' for row in rows)
 values=[{key:row[key] for key in ('initialChecksum','finalChecksum')} for row in rows]
 assert values[0]==values[1]
 return values[0]
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def allocated(p):
 b=Path(p).read_bytes();assert b[:6]==b'\x7fELF\x02\x01'
 e=struct.unpack_from('<16sHHIQQQIHHHHHH',b);sections=[struct.unpack_from('<IIQQQQIIQQ',b,e[6]+i*e[11]) for i in range(e[12])];names=sections[e[13]];strings=b[names[4]:names[4]+names[5]]
 return {strings[s[0]:].split(b'\0')[0].decode():(s[1],s[2],s[3],s[5],None if s[1]==8 else hashlib.sha256(b[s[4]:s[4]+s[5]]).hexdigest()) for s in sections if s[2]&2}
def snapshot():
 result=campaign.input_snapshot({'v2-priority'});result['symbolized']={};result['selected_manifests']={}
 for arm,path in SYMBOLS.items():
  reference=allocated(campaign.BINS[arm]);candidate=allocated(path);diff={k for k in reference.keys()|candidate.keys() if reference.get(k)!=candidate.get(k)}
  if diff-{'.note.gnu.build-id'}:raise RuntimeError(f'Allocated sections differ: {arm}: {diff}')
  result['symbolized'][arm]={'sha256':sha(path),'frozen_sha256':sha(campaign.BINS[arm]),'allocated_differences':sorted(diff),'provenance_sha256':sha(path.parent/'provenance.json')}
 for name,manifest,_ in SELECT:
  row=next(s for s in json.loads(manifest.read_text())['scenarios'] if s['id']==name)
  for p,h in row['fixture_sha256'].items():assert sha(p)==h
  result['selected_manifests'][name]={'sha256':sha(manifest),'scenario':row}
 result['reference_results']={str(RESULT_ROOTS[name]/name/'0'/arm/'result.json'):sha(RESULT_ROOTS[name]/name/'0'/arm/'result.json') for name,_,_ in SELECT for arm in ('baseline','candidate')}
 result['script_sha256']=sha(__file__);return result
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=Path);p.add_argument('--run',action='store_true');args=p.parse_args();out=args.output.resolve()
 plan=[]
 for name,manifest,arms in SELECT:
  row=next(s for s in json.loads(manifest.read_text())['scenarios'] if s['id']==name)
  for arm in arms:
   dest=out/(name+'-'+arm)
   engine=[str(SYMBOLS[arm]),'--run-game',*row['args'],'--benchmark-warmup','0','--output-dir',str(dest/'run')]
   command=['sudo','-n','perf','record','-e','cycles:u','-F','499','--call-graph','dwarf,8192','-o',str(dest/'perf.data'),'--','sudo','-n','-u',pwd.getpwuid(os.getuid()).pw_name,'env','LD_LIBRARY_PATH='+campaign.LIBS,'GLOB2_USER_DIR='+str(dest/'profile'),'GLOB2_USER_DATA_DIR='+str(dest/'profile'),*engine]
   plan.append({'scenario':name,'arm':arm,'command':command,'cwd':str(campaign.ROOTS[arm]),'destination':str(dest),'expected_end_tick':int(row['args'][row['args'].index('--ticks')+1]),'expected_measured_ticks':int(row['args'][row['args'].index('--ticks')+1])-row['start_tick'],'expected_checksums':expected_checksums(name)})
 print(json.dumps({'timing_valid':False,'launch_requires':'Coordinator reservation; cpuset outer, governor inner, taskset0-7; six separate callchain diagnostic runs only. Symbol twins must match all allocated sections including NOBITS geometry.','plan':plan},indent=2),flush=True)
 if not args.run:return 0
 os.environ['LD_LIBRARY_PATH']=campaign.LIBS;out.mkdir(parents=True,exist_ok=False);before=snapshot();(out/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');report={'timing_valid':False,'scope':'Process-tree samples include launcher/startup; instrumented wall/CPU are not acceptance evidence. Per-TID stacks distinguish foreground tasks from background gradient workers.','runs':[]}
 def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 starting_child=False;deferred_signal=None
 def interrupted(signum,frame):
  nonlocal deferred_signal
  if starting_child:deferred_signal=signum;return
  raise InterruptedError(f'signal {signum}')
 old_handlers={sig:signal.signal(sig,interrupted) for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP)}
 primary_error=None
 try:
  for row in plan:
   dest=Path(row['destination']);dest.mkdir();report['runs'].append(row);save()
   with (dest/'record.log').open('x') as log:
    child=None
    try:
     starting_child=True
     try:child=subprocess.Popen(row['command'],cwd=row['cwd'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
     finally:starting_child=False
     if deferred_signal is not None:raise InterruptedError(f'signal {deferred_signal} during startup')
     code=child.wait(timeout=600)
    finally:
     cleanup_handlers={sig:signal.signal(sig,signal.SIG_IGN) for sig in old_handlers}
     try:
      if child is not None and child.poll() is None:
       subprocess.run(['sudo','-n','kill','-INT','--','-'+str(child.pid)],check=False)
       try:child.wait(timeout=15)
       except subprocess.TimeoutExpired:subprocess.run(['sudo','-n','kill','-KILL','--','-'+str(child.pid)],check=True);child.wait()
     finally:
      for sig,handler in cleanup_handlers.items():signal.signal(sig,handler)
   row['returncode']=code;save();assert code==0
   result=json.loads((dest/'run/result.json').read_text());assert result['status']=='completed' and result['ticks']==row['expected_end_tick'] and result['benchmark_measured_ticks']==row['expected_measured_ticks']
   actual={key:result[key] for key in ('initialChecksum','finalChecksum')};assert actual==row['expected_checksums'];row['verified_checksums']=actual
   subprocess.run(['sudo','-n','chown',f'{os.getuid()}:{os.getgid()}',str(dest/'perf.data')],check=True)
   for filename,command in [('flat-by-thread.txt',['perf','report','--stdio','--no-children','--sort','pid,symbol','--percent-limit','0','-i',str(dest/'perf.data')]),('samples.txt',['perf','script','-i',str(dest/'perf.data'),'-F','comm,pid,tid,time,event,ip,sym,dso,period']),('header.txt',['perf','report','--header-only','--stdio','-i',str(dest/'perf.data')])]:
    with (dest/filename).open('x') as f:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
   row['perf_sha256']=sha(dest/'perf.data');row['status']='complete';save()
  report['status']='complete'
 except BaseException as error:primary_error=error;report.update(status='failed',error=repr(error));raise
 finally:
  for sig in old_handlers:signal.signal(sig,signal.SIG_IGN)
  audit_error=None
  try:
   try:
    after=snapshot();(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');report['inputs_unchanged']=after==before
    if after!=before:raise RuntimeError('Diagnostic inputs changed')
   except BaseException as error:
    audit_error=error;report.update(status='failed',inputs_unchanged=False,post_audit_error=repr(error))
   try:save()
   except BaseException as error:
    if primary_error is None and audit_error is None:raise
    print(f'Cannot save final diagnostic report: {error!r}',file=sys.stderr)
   if audit_error is not None and primary_error is None:raise audit_error
  finally:
   for sig,handler in old_handlers.items():signal.signal(sig,handler)
 return 0
if __name__=='__main__':raise SystemExit(main())
