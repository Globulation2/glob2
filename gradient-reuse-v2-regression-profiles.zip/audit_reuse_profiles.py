import json,re,hashlib,importlib.util,os
from pathlib import Path
BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('profiles',BASE/'profile_reuse_regressions.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=BASE/'reuse-regression-profiles-01';report=json.loads((base/'report.json').read_text());before=json.loads((base/'inputs-before.json').read_text());after=json.loads((base/'inputs-after.json').read_text())
assert report['status']=='complete' and report['inputs_unchanged'] and before==after and len(report['runs'])==6
os.environ['LD_LIBRARY_PATH']=m.campaign.LIBS
assert m.snapshot()==before
cp=json.loads((BASE/'reuse-regression-profiles-01-cpuset.json').read_text());gov=json.loads((BASE/'reuse-regression-profiles-01-governors.json').read_text())
assert cp['state']=='completed' and cp['exit_code']==0 and cp['cgroup_restored'] and cp['wrapper_affinity_restored'] and not cp['forced_cgroup_kill']
assert gov['state']=='completed' and gov['exit_code']==0 and gov['restored'] and not gov['restoration_errors']
records=[]
for run in report['runs']:
 d=Path(run['destination']);result=json.loads((d/'run/result.json').read_text());assert run['returncode']==0 and run['status']=='complete'
 assert result['status']=='completed' and result['ticks']==run['expected_end_tick'] and result['benchmark_measured_ticks']==run['expected_measured_ticks']
 assert {k:result[k]for k in run['expected_checksums']}==run['expected_checksums']==m.expected_checksums(run['scenario'])
 assert m.sha(d/'perf.data')==run['perf_sha256']
 flat=(d/'flat-by-thread.txt').read_text();record=(d/'record.log').read_text();header=(d/'header.txt').read_text();samples=(d/'samples.txt').read_text()
 lost=re.search(r'Total Lost Samples:\s*(\d+)',flat);assert lost and int(lost[1])==0
 advertised=re.search(r'\((\d+) samples\)',record);assert advertised
 sample_headers=re.findall(r'^(\S+)\s+(\d+)/(\d+)\s+([\d.]+):\s+(\d+)\s+cycles:u:',samples,re.M)
 assert len(sample_headers)==int(advertised[1])
 threads={}
 for comm,pid,tid,time,period in sample_headers:
  k=f'{comm}:{pid}/{tid}';v=threads.setdefault(k,{'samples':0,'period':0});v['samples']+=1;v['period']+=int(period)
 warnings=[line for line in header.splitlines()if line.startswith('Invalid ')or'not available or unable'in line]
 records.append({'scenario':run['scenario'],'arm':run['arm'],'ticks':result['benchmark_measured_ticks'],'checksums':run['expected_checksums'],'perf_sha256':run['perf_sha256'],'record_advertised_samples':int(advertised[1]),'parsed_sample_headers':len(sample_headers),'reported_lost_samples':int(lost[1]),'header_warnings':warnings,'threads':threads,'unknown_symbol_mentions':samples.count('[unknown]')})
audit={'status':'verified','timing_valid':False,'runs':records,'inputs_before_after_current_equal':True,'symbol_twins':before['symbolized'],'cpuset_restored':True,'governors_restored':True,'notes':'All allocated ELF section content/address/size/flags/type including NOBITS geometry match frozen binaries except build-id. This binds machine-code inputs, not measured time equivalence. Perf header event-description parsing warning retained; requested command/raw samples decode cycles:u, all advertised sample headers retained, reports indicate zero lost samples. Unknown/truncated stacks and short sampling duration limit attribution; zero reported loss does not prove complete stacks. Privileged perf process-tree includes sudo/launcher/startup, while engine runs original user. Instrumented CPU/wall and sample ratios are diagnostics, not acceptance effect sizes.'}
(base/'independent-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps({'status':'verified','runs':[{'scenario':r['scenario'],'arm':r['arm'],'samples':r['parsed_sample_headers'],'lost':r['reported_lost_samples'],'warnings':r['header_warnings']}for r in records]},indent=2))
