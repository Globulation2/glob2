import hashlib,json,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'artifacts/movement-planning/fix-retest/paired-large-k1';out.mkdir(exist_ok=True)
binaries={'before':root/'artifacts/movement-planning/fix-retest/glob2-before','after':root/'build/movement-release/src/glob2'}
records=[]
for repetition in range(-1,10):
 order=['before','after'] if repetition%2==0 else ['after','before']
 for label in order:
  folder=out/('warmup' if repetition<0 else f'rep-{repetition:02d}')/label;folder.mkdir(parents=True,exist_ok=False)
  cmd=[str(binaries[label]),'game','run','--load-game',str(root/'artifacts/movement-planning/fixtures/large-colony.game'),'--ticks','128','--gradient-backend','cpu','--compute-threads','4','--output-dir',str(folder),'--movement-shadow','1']
  (folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
  with (folder/'run.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
  d=json.loads((folder/'result.json').read_text());m=d['movement_shadow'];r={'repetition':repetition,'variant':label,'run_ns':d['run_ns'],'checksum':d['finalChecksum'],'captures':d['ai_pipeline']['captures'],'fields':m['planner_fields'],'visited':m['planner_visited'],'capture_ns':m['snapshot_extraction_ns']+m['snapshot_preparation_ns'],'admission_ns':m['admission_ns'],'deadline_wait_ns':m['deadline_wait_ns']};records.append(r)
  print(json.dumps(r),flush=True)
 (out/'samples.json').write_text(json.dumps(records,indent=2)+'\n')
(out/'binaries.json').write_text(json.dumps({label:{'path':str(b),'sha256':hashlib.sha256(b.read_bytes()).hexdigest()} for label,b in binaries.items()},indent=2)+'\n')
