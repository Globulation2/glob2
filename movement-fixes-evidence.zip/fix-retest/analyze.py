import json,math,csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
samples=json.loads((p/'paired-large-k1/samples.json').read_text());before=[next(s for s in samples if s['repetition']==i and s['variant']=='before') for i in range(10)];after=[next(s for s in samples if s['repetition']==i and s['variant']=='after') for i in range(10)]
b=np.array([r['run_ns']/1e6 for r in before]);a=np.array([r['run_ns']/1e6 for r in after]);logs=np.log(a/b);rng=np.random.default_rng(713);draws=rng.integers(0,10,size=(20000,10));ratios=np.exp(logs[draws].mean(axis=1));ci=np.quantile(ratios,[.025,.975]);ratio=np.exp(logs.mean())
result={'paired_samples':10,'ticks_per_run':128,'warmup_runs_per_variant':1,'before_mean_engine_ms':float(b.mean()),'after_mean_engine_ms':float(a.mean()),'geometric_mean_after_before_ratio':float(ratio),'reduction_percent':float(100*(1-ratio)),'paired_bootstrap_95_ratio_interval':ci.tolist(),'paired_bootstrap_95_reduction_interval_percent':[float(100*(1-ci[1])),float(100*(1-ci[0]))],'all_final_checksums_equal':len({r['checksum'] for r in before+after})==1,'counts':{label:{key:rows[0][key] for key in ['captures','fields','visited']} for label,rows in [('before',before),('after',after)]},'limits':['One seed and preliminary 128-tick fixture','Before/after includes integrated master executor diagnostics change; telemetry off','Timing excludes correctness exports','No live movement adoption or full gameplay acceptance']}
(p/'paired-summary.json').write_text(json.dumps(result,indent=2)+'\n')
rows=[]
for w in ['ordinary-control','large-colony','contention','team-imbalance']:
 for k in [1,2,4,8]:
  root=p/f'pilot/{w}';d=json.loads((root/str(k)/'result.json').read_text());ref=json.loads((root/'0/result.json').read_text());m=d['movement_shadow'];baseline=ref['movement_shadow'];bound=sum(v for key,v in baseline.items() if key.endswith(tuple(f'reference_phase_{i}_ns' for i in range(4))));extra=max(0,m['snapshot_extraction_ns']+m['snapshot_preparation_ns']-baseline['snapshot_extraction_ns']-baseline['snapshot_preparation_ns']);stable=sum(v for key,v in m.items() if key.endswith('_stable_opportunities'));valid=sum(v for key,v in m.items() if key.endswith('_valid'))
  rows.append({'workload':w,'K':k,'overhead_ratio':(extra+m['admission_ns'])/bound,'coverage':valid/stable,'engine_ms':d['run_ns']/1e6,'reference_engine_ms':ref['run_ns']/1e6,'capture_admission_ms':(extra+m['admission_ns'])/1e6,'pre_visibility_bound_ms':bound/1e6,'wait_ms':m['deadline_wait_ns']/1e6,'fields':m['planner_fields'],'visited':m['planner_visited'],'captures':d['ai_pipeline']['captures'],'checksum':d['finalChecksum']})
(p/'pilot-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
with (p/'pilot-summary.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,2,figsize=(11,5.2))
for x,y in zip(b,a):axes[0].plot([0,1],[x,y],color='#999999',alpha=.55,lw=1)
axes[0].scatter(np.zeros(10),b,c='#bd6318',s=35,label='Before');axes[0].scatter(np.ones(10),a,c='#00876c',s=35,label='After');axes[0].set(xticks=[0,1],xticklabels=['Before','After'],ylabel='128-tick engine elapsed time (ms)',title=f'Large colony, K=1: {100*(1-ratio):.1f}% less elapsed time');axes[0].set_ylim(0,float(b.max())*1.1);axes[0].grid(axis='y',alpha=.2)
workloads=['ordinary-control','large-colony','contention','team-imbalance'];colors=['#2166ac','#00876c','#bd6318','#8d4b9a']
for w,color in zip(workloads,colors):
 r=[x for x in rows if x['workload']==w];axes[1].plot(range(4),[x['overhead_ratio'] for x in r],marker='o',color=color,label=w)
axes[1].axhline(1,color='#ad2525',linestyle='--',label='Entire removable-cost bound');axes[1].set(xticks=range(4),xticklabels=[1,2,4,8],xlabel='Delay K (ticks)',ylabel='Capture + admission / reference bound',title='Remaining owner overhead after the fixes',ylim=(0,max(1.2,max(r['overhead_ratio'] for r in rows)*1.15)));axes[1].grid(axis='y',alpha=.2);axes[1].legend(fontsize=8,frameon=False,loc='upper center',bbox_to_anchor=(.5,-.22),ncol=2)
fig.suptitle('Movement planning retest: faster shadow execution; live gates still apply',fontsize=14,fontweight='bold',y=.99)
fig.text(.035,.035,'Left: 10 rotated pairs after warmup. Right: preliminary four-delay pilot. One seed; no live movement adoption.',fontsize=9,color='#555555');fig.subplots_adjust(top=.79,bottom=.3,left=.09,right=.98,wspace=.38);fig.savefig(p/'retest-charts.png',dpi=175);fig.savefig(p/'retest-charts.pdf');fig.savefig(p/'retest-charts.svg')
print(json.dumps(result,indent=2));print('PILOT',json.dumps(rows,indent=2))
