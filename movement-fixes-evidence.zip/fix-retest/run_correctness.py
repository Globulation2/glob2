import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();out=root/'artifacts/movement-planning/fix-retest/correctness'
variants={'before-reference':('artifacts/movement-planning/fix-retest/glob2-before',0),'after-reference':('build/movement-release/src/glob2',0),'after-shadow':('build/movement-release/src/glob2',4)}
for label,(binary,k) in variants.items():
 folder=out/label;folder.mkdir(parents=True,exist_ok=False)
 cmd=[str(root/binary),'game','run','--load-game',str(root/'artifacts/movement-planning/fixtures/large-colony.game'),'--ticks','64','--gradient-backend','cpu','--compute-threads','4','--output-dir',str(folder),'--write-replay','--telemetry','checksums','--save','final']
 cmd+=['--movement-profile'] if k==0 else ['--movement-shadow',str(k)]
 (folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (folder/'run.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
comparison={}
for name in ['game.replay','game.replay.checksums','world.checksums','final.game.gz']:
 hashes={label:hashlib.sha256((out/label/name).read_bytes()).hexdigest() for label in variants}
 comparison[name]={'equal':len(set(hashes.values()))==1,'sha256':hashes}
(out/'comparison.json').write_text(json.dumps(comparison,indent=2)+'\n');print(json.dumps(comparison,indent=2));assert all(d['equal'] for d in comparison.values())
