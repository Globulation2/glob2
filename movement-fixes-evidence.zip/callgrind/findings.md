# Movement shadow Callgrind investigation

Matched release profiles of the existing 1,024-worker colony fixture: seed 713, 16 simulation ticks, CPU gradient backend, four compute participants, reference profiling versus K=1 shadow planning. Source revision 16ae31c224f633c8c483cee54b76382f6d134d70. Valgrind 3.26.0, instruction-read events, per-thread output. Original release objects were relinked without stripping; no tracked source changes. Function names retained, no DWARF line tables. Commands and raw profiles accompany this report.

Reference and shadow final simulation checksums both equal 33499183. Whole-program profiles include initialization; figures isolate named function costs. Valgrind wall time is not release performance evidence. Inclusive costs contain children and cannot be added to nested costs. Worker breakdown uses exclusive counts. This short, single-seed profile is diagnostic, not acceptance evidence.

## Owner capture and admission

Reference capture count 17, shadow 33. Store capture inclusive instruction count rises from 3,938,160 to 13,903,560. Shadow boundary inclusive instruction count is 13,362,555; 8,699,929 are exclusive instructions within the boundary routine. It performs one substantive unit scan per tick (16,384 task extractions across 16 ticks), comparing actor records, predicting completions, assembling requests, sorting and submitting. Same-tick repeated boundary calls return before another scan, but only after the snapshot capture has already occurred.

The matching call graph shows 16 versus 32 calls from Game::captureReadBoundary into Store::captureBoundary, plus one Map::preparePendingWorld call in each run. Thus pending-world invalidation does not explain the doubling in this run.

A separate four-tick diagnostic binary changes only Store::captureBoundary to print validity checks. The trace shows the same-tick second capture has matching map/configuration/exploration stamps but a changed observation revision. Engine::executeOrdersAndStep executes a null order between normal observation and Game::syncStep. Game::executeOrderAndNotify publishes ClientEvent::OrderExecuted even for null orders, and Game::publishClientEvent invalidates the snapshot for that acknowledgement. Game::syncStep calls the movement read boundary again; admission detects the repeated tick only after the additional capture. The acknowledgement invalidation serves other snapshot consumers and should not simply be removed. The direct-caller movement guard should instead avoid recapturing when this tick has already been admitted, with transition validity checked at consumption as specified by the contract.

AINull requests no observation components; the reference snapshots are mainly requested for existing gradient/resource preparation. The movement prototype requests the full Simulation mask plus Exploration. It adds entity extraction rather than merely sharing a full AI/rendering snapshot already present in this headless control. Captured byte accounting rises from 1.125 to 14.610 MiB in these 16 ticks. These totals are copied payloads, not retained or peak memory.

## Worker route construction

The shadow planner builds 637 route fields, records 301 cache hits, and expands 9,621,248 cells. Route-field construction consumes 26,080,396,710 inclusive instructions, approximately 99.9% of the planning worker's 26,108,976,372 instructions. Other workers cannot split this single team's movement job under the current one-job-per-team scheduling.

Legality checks call Handle::view 82,208,713 times. Each call reconstructs the same aggregate MapState::View. Exclusive instructions: view construction 9,701,012,304 (37.2% of worker instructions), search/heap body 8,990,199,491 (34.4%), legality excluding view 5,629,819,646 (21.6%), terrain step-cost lookup 1,636,092,678 (6.3%). These exclusive categories do not overlap.

The source builds one view outside Planner::build's search loop, but legal() builds another for every neighbor and seed test. Passing the existing view through legality is a concrete first optimization. Reducing view construction alone will not establish viability: field construction also repeats substantial searches. Cache-key compatibility, global invalidation dependencies, bounded route horizons and reuse of prepared fields need separate investigation before policy adoption.

## Next implementation candidates

1. Gate direct-caller movement capture before extracting the world when admission already happened at the tick.
2. Pass a single prepared immutable view through route legality and movement-cost loops.
3. Narrow capture requirements and remove admission bookkeeping only after profiling the revised result.
4. Audit field keys and invalidation to share compatible goals without changing legality or horizons.

Repeat matched native release measurements and correctness checks after any changes. No performance acceptance, confidence interval, full memory ceiling, cross-platform or live gameplay claim follows from this investigation.
