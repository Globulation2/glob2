import json,shlex,subprocess
from pathlib import Path
root=Path.cwd(); out=root/'artifacts/movement-planning/callgrind'
source=(root/'src/engine/sim/snapshot/SnapshotStore.cpp').read_text()
source=source.replace('#include <algorithm>','#include <algorithm>\n#include <cstdio>')
needle='\tconst auto requested = required;'
probe='''\tstd::fprintf(stderr,"SNAP_TRACE tick=%u previous=%lld req=%u oldreq=%u obs_match=%d config_match=%d map_match=%d explore_match=%d obs=%llu oldobs=%llu waiting=%d mask=%u\\n",unsigned(game.stepCounter),latest ? (long long)latest->tick : -1LL,unsigned(required),latest ? unsigned(latest->requirements) : 0u,latest && latest->observationRevision==observationRevision,latest && latest->configurationRevision==game.gameHeader.observationRevision(),latest && latest->mapGenerations==game.map.snapshotGenerations(),latest && latest->explorationGenerations==game.map.explorationGenerations(),(unsigned long long)observationRevision,latest?(unsigned long long)latest->observationRevision:0ULL,game.anyPlayerWaited,unsigned(game.maskAwayPlayer));
'''
assert needle in source
file=out/'SnapshotStoreProbe.cpp'; file.write_text(source.replace(needle,probe+needle))
entries=json.loads((root/'build/movement-release/compile_commands.json').read_text()); entry=next(e for e in entries if e['file'].endswith('SnapshotStore.cpp'))
args=shlex.split(entry['command']);args=[a for a in args if a!='-s'];args[args.index('-o')+1]=str(out/'SnapshotStoreProbe.o');args[-1]=str(file)
# The duplicate source stays in artifacts, so preserve its original quoted-include search path.
args+=['-Isrc/engine/sim/snapshot'];
# compilation database preserves escaped quote characters one level deeper than argv.
args=[a.replace('\\"','"') for a in args]
(out/'probe-compile-command.json').write_text(json.dumps(args,indent=2)+'\n')
subprocess.run(args,check=True)
link=json.loads((out/'link-command.json').read_text());link[2]=str(out/'glob2-boundary-probe');index=link.index('build/movement-release/src/engine/sim/snapshot/SnapshotStore.o');link[index]=str(out/'SnapshotStoreProbe.o');subprocess.run(link,check=True)
for label,k in [('reference',0),('shadow',1)]:
 folder=out/('probe-v2-'+label);folder.mkdir(exist_ok=True)
 args=json.loads((root/f'artifacts/movement-planning/current-master-pilot/large-colony/{k}/command.json').read_text());args[0]=str(out/'glob2-boundary-probe');args[args.index('--ticks')+1]='4';args[args.index('--output-dir')+1]=str(folder)
 with (folder/'run.log').open('w') as f: subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(label,flush=True)
 for line in (folder/'run.log').read_text().splitlines():
  if line.startswith('SNAP_TRACE'):print(line,flush=True)
