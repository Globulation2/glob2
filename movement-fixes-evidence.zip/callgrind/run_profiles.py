import json, subprocess, os, time
from pathlib import Path
root=Path.cwd(); out=root/'artifacts/movement-planning/callgrind'
for label,delay in [('reference',0),('shadow-k1',1)]:
 folder=out/(label+'-symbols'); folder.mkdir(exist_ok=True)
 args=json.loads((root/'artifacts/movement-planning/current-master-pilot/large-colony'/str(delay)/'command.json').read_text())
 args[0]=str(out/'glob2-symbols'); args[args.index('--ticks')+1]='16'; args[args.index('--output-dir')+1]=str(folder)
 cmd=['valgrind','--tool=callgrind','--separate-threads=yes','--callgrind-out-file='+str(folder/'callgrind.out.%p'),'--log-file='+str(folder/'valgrind.log'),*args]
 (folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 env=os.environ.copy(); env['SDL_VIDEODRIVER']='dummy'; env['SDL_AUDIODRIVER']='dummy'; env['GLOB2_PROFILE_DIR']=str(folder/'profile')
 start=time.monotonic()
 with (folder/'run.log').open('w') as log: completed=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(label,'exit',completed.returncode,'seconds',round(time.monotonic()-start,1),flush=True)
 if completed.returncode: break
