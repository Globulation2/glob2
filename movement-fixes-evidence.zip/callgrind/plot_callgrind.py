import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent; d=json.loads((p/'callgraph-data.json').read_text())
ref=d['reference'][0]['nodes']; owner=d['shadow-k1'][0]['nodes']; worker=d['shadow-k1'][1]['nodes']
def find(nodes,text):return next(v for name,v in nodes.items() if name.startswith(text))
vals=[find(ref,'SimulationSnapshot::Store::captureBoundary(')['inclusive_Ir']/1e6,find(owner,'SimulationSnapshot::Store::captureBoundary(')['inclusive_Ir']/1e6,find(owner,'MovementPlanning::Shadow::boundary(Game')['inclusive_Ir']/1e6]
total=d['shadow-k1'][1]['total_self_Ir']; portions=[find(worker,'SimulationSnapshot::Handle::view()')['self_Ir'],find(worker,'MovementPlanning::Planner::build(')['self_Ir'],find(worker,'MovementPlanning::legal(')['self_Ir'],find(worker,'MovementPlanning::(anonymous namespace)::step(')['self_Ir']];portions.append(total-sum(portions))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,(ax,bx)=plt.subplots(1,2,figsize=(12,5))
ax.bar(range(3),vals,color=['#888888','#2166ac','#00876c'],width=.6)
for i,v in enumerate(vals):ax.text(i,v+.3,f'{v:.2f} M',ha='center')
ax.set(xticks=range(3),xticklabels=['Reference\ncapture\n17 captures','Shadow\ncapture\n33 captures','Shadow boundary\nscan / submit / publish'],ylabel='Inclusive instructions (millions)',ylim=(0,17));ax.set_title('Owner work: extra captures and bookkeeping',fontsize=12,pad=15);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
names=['Repeated map-view construction','Route-search loop / heap','Legality checks, excluding view','Terrain movement-cost lookup','Other worker instructions'];percent=[v/total*100 for v in portions]
bx.barh(range(5),percent,color=['#bd6318','#2166ac','#00876c','#8d4b9a','#aaaaaa']);bx.invert_yaxis();bx.set(yticks=range(5),yticklabels=names,xlabel='Share of planning worker instructions (%)',xlim=(0,43));bx.set_title('Worker work: 637 fields, 9.6 million expansions',fontsize=12,pad=15)
for i,v in enumerate(percent):bx.text(v+.4,i,f'{v:.1f}%',va='center',fontsize=10)
bx.grid(axis='x',alpha=.15);bx.set_axisbelow(True)
fig.suptitle('Callgrind identifies avoidable work in the prototype',fontsize=17,fontweight='bold',y=.98)
fig.text(.025,.022,'Matched 16-tick release profiles · 1,024-worker colony · seed 713 · K=1 · 4 participants · instruction counts, not elapsed time',fontsize=9,color='#555555')
fig.subplots_adjust(top=.8,bottom=.23,left=.08,right=.98,wspace=.9)
fig.savefig(p/'callgrind-findings.png',dpi=180);fig.savefig(p/'callgrind-findings.pdf');fig.savefig(p/'callgrind-findings.svg')
