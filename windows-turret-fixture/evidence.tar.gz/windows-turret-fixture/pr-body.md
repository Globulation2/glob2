The turret encounter-order fixture replaces its building catalog while a live turret still points into the previous catalog. `configureBuildingCatalog()` then reads the freed type before the test rebinds it, crashing Windows CI. Rebind immediately after replacement, before configuration inspects live buildings.

Validation: the original Windows GDB stack points to catalog configuration. Targeted AddressSanitizer instrumentation reproduces the old use-after-free at `Game.cpp:203`; the corrected case passes all 7271 assertions, and all 24 turret cases / 33738 assertions pass with the same instrumentation. No production code or simulation change. Actual Windows candidate coverage remains for subsequent master CI.

[Before/after sanitizer logs, Windows crash stack, source patch and exact compiler/link commands](https://github.com/Globulation2/glob2/tree/evidence/master-ci-recovery-1198/windows-turret-fixture).
