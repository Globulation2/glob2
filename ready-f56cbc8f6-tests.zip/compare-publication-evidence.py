#!/usr/bin/env python3
"""Compare portable publication traces and validate retained owner-kernel audits."""
import argparse
import csv
import json
import io
import re
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('first', type=Path)
parser.add_argument('second', type=Path)
args = parser.parse_args()

def traces(root):
    return {str(p.relative_to(root)): p.read_bytes() for p in root.rglob('*.tsv')
            if not p.name.endswith('-kernel-entries.tsv')}

def validate_trace(name, contents):
    rows = list(csv.DictReader(io.StringIO(contents.decode()), delimiter='\t'))
    if name.endswith('-continuation.tsv'):
        expected = 24 if '/air-' in name else 33
    else:
        expected = 16 if '/air-participants-' in name else 48
    assert len(rows) == expected, f'{name}: expected {expected} rows, found {len(rows)}'
    assert rows and 'boundary' in rows[0], f'{name}: missing boundary header'
    for row in rows:
        original = next((key for key in row if key.startswith('original_')), None)
        restored = next((key for key in row if key.startswith('resumed_')), None)
        if original or restored:
            assert original and restored and row[original] == row[restored], f'{name}: continuation differs at {row["boundary"]}'

def audits(root):
    result = []
    covered = {'AirFieldInitialization', 'AirFieldExpansion', 'AirTraversalPlane', 'AirGoalEnumeration'}
    files = sorted(root.rglob('*-kernel-entries.tsv'))
    assert len(files) == 8, f'{root}: expected eight participant audit files, found {len(files)}'
    for path in files:
        match = re.search(r'participants-(1|2|4|8)-kernel-entries\.tsv$', path.name)
        assert match, f'Unknown participant audit: {path}'
        participants = int(match.group(1))
        with path.open() as source:
            rows = list(csv.DictReader(source, delimiter='\t'))
        selected = [row for row in rows if 'category' not in row or row['category'] in covered]
        assert selected, f'No covered kernel counters: {path}'
        owner = sum(int(row['owner']) for row in selected)
        other = sum(int(row['other']) for row in selected)
        assert owner == 0 if participants > 1 else owner > 0, f'Unexpected owner kernel count: {path}: {owner}'
        if participants > 1:
            assert other > 0, f'No worker kernels recorded: {path}'
        result.append({'file': str(path.relative_to(root)), 'participants': participants,
                       'covered_owner_entries': owner, 'covered_other_entries': other})
    return result

first, second = traces(args.first), traces(args.second)
assert len(first) == 38, f'Expected 38 portable traces, found {len(first)}'
assert first.keys() == second.keys(), f'Trace inventories differ: {first.keys() ^ second.keys()}'
for name in sorted(first):
    validate_trace(name, first[name])
    validate_trace(name, second[name])
    assert first[name] == second[name], f'Boundary/state trace differs: {name}'
print(json.dumps({'portable_traces_identical': len(first),
                  'first_audits': audits(args.first), 'second_audits': audits(args.second)}, indent=2))
