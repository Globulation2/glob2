#!/usr/bin/env python3
"""Curate correctness evidence; omit profiles, binaries and development caches."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

root = Path(__file__).resolve().parent
names = [
    'ready-final-provenance', 'ready-final-mac-publication-complete',
    'ready-final-mac-consumers', 'ready-final-mac-integration',
    'final-mac-owner-pipelines-retry', 'final-mac-ground-goldens',
    'ready-final-mac-unit', 'ready-final-mac-midgame',
    'ready-final-linux-publication', 'ready-final-linux-unit',
    'ready-final-linux-midgame', 'windows-gradient-bundle',
    'ready-review.md', 'ready-final-mac-publication-complete.log',
    'ready-final-linux-publication.log', 'ready-final-linux-unit.log',
    'ready-final-mac-publication-enospc.log', 'final-mac-owner-pipelines/run.log',
    'ready-final-mac-unit.xml', 'ready-final-mac-integration.xml',
    'ready-final-mac-integration-inventory.json',
    'ready-final-linux-unit.xml', 'ready-final-cross-platform.json',
    'ready-final-publication-comparison.json', 'ready-final-sim-revision.log',
    'ready-final-sim-contracts.log', 'observation-docs-final.log',
    'observation-random.log', 'compare-publication-evidence.py',
    'package_ready_evidence.py', 'mac-midgame/run_continuations.py',
]
logs = {
    '/tmp/glob2-ready-final-native-build.log': 'logs/native-build.log',
    '/tmp/glob2-ready-final-mac-unit.log': 'logs/mac-unit.log',
    '/tmp/glob2-ready-final-mac-integration.log': 'logs/mac-integration.log',
    '/tmp/glob2-ready-final-mac-midgame.log': 'logs/mac-midgame.log',
}
files = {}
for name in names:
    path = root / name
    if not path.exists():
        raise SystemExit(f'Missing required evidence: {path}')
    for item in sorted(path.rglob('*')) if path.is_dir() else [path]:
        relative = item.relative_to(root)
        if not item.is_file() or any(part in ('profile', '__pycache__', '.playwright-mcp') for part in relative.parts):
            continue
        if item.name in ('preferences.txt', 'preferences.ini', '.DS_Store'):
            continue
        files[str(relative)] = item
for path, name in logs.items():
    files[name] = Path(path)
files['README.md'] = root.parents[1] / 'docs/.work/delayed-gradients-verification.md'
manifest = {name: {'bytes': path.stat().st_size,
                   'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            for name, path in sorted(files.items())}
groups = {'tests': {}, 'mac-midgame': {}, 'linux-midgame': {}}
for name, path in files.items():
    group = ('mac-midgame' if name.startswith('ready-final-mac-midgame/') else
             'linux-midgame' if name.startswith('ready-final-linux-midgame/') else 'tests')
    groups[group][name] = path
results = []
for group, entries in groups.items():
    if len(sys.argv) > 1 and group not in sys.argv[1:]:
        continue
    destination = root / f'ready-f56cbc8f6-{group}.zip'
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for name, path in sorted(entries.items()):
            output.write(path, name)
        output.writestr('manifest.json', json.dumps({n: manifest[n] for n in entries}, indent=2) + '\n')
    if destination.stat().st_size >= 100_000_000:
        raise SystemExit(f'Archive exceeds evidence branch file limit: {destination}')
    results.append({'file': str(destination), 'files': len(entries), 'bytes': destination.stat().st_size,
                    'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()})
print(json.dumps(results, indent=2))
