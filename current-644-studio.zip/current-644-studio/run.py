import hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path('/home/bradley/.codex/worktrees/studio-644-validation/glob2')
out=Path(__file__).resolve().parent
inputs=json.loads((out/'build-inputs.json').read_text())
binary=root/'build/linux/client/release/src/glob2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=lambda:json.loads(subprocess.check_output(['python3','test/build_provenance.py'],cwd=root))
assert source()==inputs['source']
assert inputs['source']['revision']=='644611925c66ee9a1259bbd90e72744d387bc59c' and not inputs['source']['dirty']
for p,h in inputs['inputs'].items():assert sha(root/p)==h
shutil.copy2(binary,out/'glob2')
env=dict(os.environ,**inputs['environment'],GLOB2_USER_DATA_DIR=str(out/'profile'),SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_CHECKSUM_SIDECAR='1')
ldd=subprocess.check_output(['ldd',str(out/'glob2')],env=env,text=True);(out/'ldd.txt').write_text(ldd)
libs={}
for line in ldd.splitlines():
 for item in line.split():
  if item.startswith('/') and Path(item).is_file():libs[item]=sha(item)
command=[str(out/'glob2'),'--run-game','--map-file','platform/apps/engine-agent/fixtures/ais/two.map.gz','--game-seed','19','--player','javascript','--ai-script','0:examples/javascript/studio-starter.js','--player','numbi','--ticks','1024','--replay','true','--telemetry','checksums','--save','initial','--save','final','--output-dir',str(out/'result')]
meta={'command':command,'cwd':str(root),'source':inputs['source'],'binary_sha256':sha(out/'glob2'),'runtime_libraries':libs,'inputs':inputs['inputs'],'environment':{k:env[k] for k in ['LD_LIBRARY_PATH','GLOB2_USER_DATA_DIR','SDL_VIDEODRIVER','SDL_AUDIODRIVER','GLOB2_CHECKSUM_SIDECAR']}}
(out/'run-provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
with (out/'run.log').open('w') as log:p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
assert p.returncode==0,p.returncode
assert source()==inputs['source']
assert sha(out/'glob2')==meta['binary_sha256']
for p,h in libs.items():assert sha(p)==h
for p,h in inputs['inputs'].items():assert sha(root/p)==h
trace=out/'result/game.replay.checksums'
report={'revision':inputs['source']['revision'],'sourceTreeSha256':inputs['source']['sourceTreeSha256'],'exit_code':0,'inputs_unchanged':True,'binary_sha256':meta['binary_sha256'],'traceSha256':sha(trace),'traceBytes':trace.stat().st_size,'traceRecords':int.from_bytes(trace.read_bytes()[12:16],'little')}
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
