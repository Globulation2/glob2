from pathlib import Path
import json,tarfile,subprocess,hashlib,zipfile,csv
from paired_provenance import sha
ROOT=Path.cwd();A=ROOT/'artifacts/resource-refactor';R=A/'tournament-f0-candidate-b3fab1a48';J=A/'tournament-f0-approved-vs-b3fab1a48';D=A/'final-tournament-publication';D.mkdir(exist_ok=True)
allrows=json.loads((R/'runs.json').read_text());rows=[r for r in allrows if r['variant']=='candidate'];summary=json.loads((R/'summary.json').read_text());prov=json.loads((R/'provenance.json').read_text());assert prov['runtime_stable'] and len(rows)==42 and not summary['failed_runs']
index={'timing_valid':False,'candidate':'b3fab1a48','candidate_binary_sha256':prov['runtime']['candidate']['binary_sha256'],'reused_controls':'https://github.com/Globulation2/glob2/tree/963b0fe','artifacts':[],'logs':[],'limitations':summary['caution'],'recovery':'Wrapper exit143 after all42new engines and stable-runtime audit; strict84record analysis-only recovery, no reruns. Exact cause unconfirmed; approximately30min enclosing-session lifetime suspected.','data_chronology':'Later41678773c translations followed completed run audit. ZIP reconstructs exact recorded b3 data hashes, not later workspace files.'}
for group in ['land-2','land-4','water-2','water-4','control']:
 selected=[r for r in rows if ('control' if r['control'] else '-'.join(r['scenario'].split('-')[:2]))==group]
 dest=D/(group+'-candidate-logs.tar.zst');process=subprocess.Popen(['zstd','-q','-6','-T1','-f','-o',str(dest)],stdin=subprocess.PIPE)
 with tarfile.open(fileobj=process.stdin,mode='w|') as tar:
  for row in selected:
   p=Path(row['engine_log']);assert sha(p)==row['artifact_sha256']['engine_log'];name=str(p.relative_to(ROOT));tar.add(p,arcname=name,recursive=False);index['logs'].append({'archive':dest.name,'path':name,'sha256':row['artifact_sha256']['engine_log'],'bytes':p.stat().st_size})
 process.stdin.close();assert process.wait()==0
 expected={x['path']:x['sha256'] for x in index['logs'] if x['archive']==dest.name};seen=set();proc=subprocess.Popen(['zstd','-q','-d','-c',str(dest)],stdout=subprocess.PIPE)
 with tarfile.open(fileobj=proc.stdout,mode='r|') as tar:
  for member in tar:
   source=tar.extractfile(member);digest=hashlib.sha256()
   for block in iter(lambda:source.read(1024*1024),b''):digest.update(block)
   assert digest.hexdigest()==expected[member.name];seen.add(member.name)
 assert proc.wait()==0 and seen==set(expected) and dest.stat().st_size<50_000_000
 index['artifacts'].append({'path':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest),'logs':len(selected),'verification':'Every decompressed raw log SHA256 matches original completed run.'});print(group,dest.stat().st_size,flush=True)
paths=set(p for parent in [R,J] for p in parent.rglob('*') if p.is_file() and p.name!='engine.log')
for name in ['paired_behavior.py','paired_telemetry.py','paired_provenance.py','recover_b3fab_candidate_analysis.py','monitor_b3fab_candidate.py','package_final_tournament.py','final-b3fab-tournament-plan.json','final-b3fab-tournament-launch.json','final-b3fab-tournament-completion.json','recover-b3fab-candidate-analysis.log','tournament-f0-candidate-b3fab1a48.log','tournament-f0-approved-vs-b3fab1a48.log','full-baseline-corpus/completion.json']:
 paths.add(A/name)
paths.add(ROOT/'tools/tournaments/game_telemetry.py')
compact=D/'summaries-commands-provenance.zip'
with zipfile.ZipFile(compact,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths):
  if p.is_file():z.write(p,str(p.relative_to(ROOT)))
 for name,expected in prov['runtime']['candidate']['data_inputs'].items():
  p=ROOT/name
  data=p.read_bytes()
  if hashlib.sha256(data).hexdigest()!=expected:data=subprocess.check_output(['git','show','b3fab1a48:'+name])
  assert hashlib.sha256(data).hexdigest()==expected,name
  z.writestr('candidate-runtime-inputs/'+name,data)
 for label,parent in [('pure-to-candidate',R),('approved-to-candidate',J)]:
  s=json.loads((parent/'summary.json').read_text());csvpath=D/(label+'-all-metrics.csv');columns=['group','metric','games','available_pairs','missing_pairs','baseline_mean','candidate_mean','paired_mean_change','geometry_balanced_mean_change','geometry_clusters','bootstrap95','directional_interpretation']
  with csvpath.open('w',newline='') as f:
   writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
   for group,g in s['groups'].items():
    for metric,v in g['metrics'].items():writer.writerow({**{k:v.get(k) for k in columns},'group':group,'metric':metric,'games':g['games']})
  z.write(csvpath,csvpath.name)
with zipfile.ZipFile(compact) as z:assert z.testzip() is None
assert compact.stat().st_size<50_000_000
index['artifacts'].append({'path':compact.name,'bytes':compact.stat().st_size,'sha256':sha(compact),'contents':'All commands/results/run records/provenance, both summaries, all metrics, telemetry extractions, exact driver/parser, verified recorded candidate data. Reused fixtures and pure/approved raw logs linked to963b0fe. No executables/dependency caches/performance datasets.'})
index['raw_log_bytes']=sum(x['bytes'] for x in index['logs']);index['compressed_log_bytes']=sum(x['bytes'] for x in index['artifacts'] if x['path'].endswith('.zst'));(D/'inventory.json').write_text(json.dumps(index,indent=2)+'\n');print('done',flush=True)
