from pathlib import Path
import json
out=Path('artifacts/compact-live');results=[]
for case in sorted((out/'correctness').iterdir()):
 if not case.is_dir():continue
 versions={v:{t[0]:t[4] for t in json.loads((case/'warmup'/v/'observations.json').read_text())['ticks']} for v in ['reference','compact']}
 common=sorted(versions['reference'].keys()&versions['compact'].keys())
 assert common and common==list(range(common[0],common[-1]+1)),case
 mismatch=[t for t in common if versions['reference'][t]!=versions['compact'][t]]
 results.append({'case':case.name,'common_ticks':len(common),'range':[common[0],common[-1]],'mismatches':mismatch,'last_ticks':{v:max(t) for v,t in versions.items()}})
 assert not mismatch,results[-1]
(out/'correctness-summary.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
