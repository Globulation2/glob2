#include "sim/snapshot/WorldRecords.h"
#include <cstdio>
int main(){printf("state=%zu record=%zu\n",sizeof(UnitState),sizeof(SimulationSnapshot::UnitView));}
