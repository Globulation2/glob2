from pathlib import Path
import subprocess,os,json,re,time,hashlib
root=Path.cwd();out=root/'artifacts/compact-live';mode=os.environ.get('LIVE_RUN_MODE','timing');seconds=os.environ.get('LIVE_RUN_SECONDS','15');warm=os.environ.get('LIVE_RUN_WARM','3');reps=int(os.environ.get('LIVE_RUN_REPS','10'))
cases=[('ordinary-control','normal',60,0,0),('large-colony','normal',60,0,0),('large-colony','uncapped-render',0,0,0),('large-colony','max-speed',60,10,1024),('cortex-colony','normal',60,0,0)]
if mode=='pilot':cases=[cases[1],cases[3]]
if mode=='correctness':cases=[cases[0],cases[1],cases[2],cases[3],cases[4]]
if mode=='ai-pilot':cases=[cases[4]]
rows=[]
for repeat in range(-1,reps):
 for ci,(fixture,scenario,fps,speed,ticks) in enumerate(cases):
  for variant in (('reference','compact') if (repeat+ci)%2 else ('compact','reference')):
   folder=out/mode/f'{fixture}-{scenario}'/('warmup' if repeat<0 else f'rep-{repeat:02d}')/variant;folder.mkdir(parents=True,exist_ok=True)
   env=os.environ.copy();env.update(SDL_VIDEODRIVER='x11',SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(folder/'user'),PROFILE_SAVE=str(root/(f'artifacts/compact-live/fixtures/{fixture}.game' if fixture=='cortex-colony' else f'artifacts/movement-planning/fixtures/{fixture}.game')),PROFILE_MODE='interactive',PROFILE_VISIBLE='1',PROFILE_FPS=str(fps),PROFILE_SECONDS=seconds,LIVE_SPEED=str(speed),LIVE_WARM_SECONDS=warm,LIVE_OUTPUT=str(folder/'observations.json'))
   if ticks:env.update(LIVE_TICKS=str(ticks if mode in ('timing','correctness') else 256),LIVE_WARM_TICKS='128' if mode in ('timing','correctness') else '32')
   if mode=='correctness':env['LIVE_CHECKSUMS']='1'
   binary=out/f'{variant}-live-probe';cmd=[str(binary),'--renderer','software','--window-size','640x480','--compute-threads','4','--mute','--no-fullscreen']
   (folder/'command.json').write_text(json.dumps({'command':cmd,'env':{k:v for k,v in env.items() if k.startswith(('GLOB2_','SDL_','PROFILE_','LIVE_'))}},indent=2))
   started=time.monotonic()
   with (folder/'run.log').open('w') as f:
    process=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
    audit=[]
    while process.poll() is None:
     if time.monotonic()-started>240:process.terminate();raise RuntimeError('Run timeout')
     if len(audit)<2 or time.monotonic()-started>2 and len(audit)<3:
      threads=[]
      for thread in Path(f'/proc/{process.pid}/task').glob('*'):
       try:
        status=(thread/'status').read_text();allowed=re.search(r'Cpus_allowed_list:\s*(.*)',status)[1]
        group=(thread/'cgroup').read_text().strip();assert allowed in ('4-7','4-7,20-23') and 'glob2-benchmark-' in group,(thread,allowed,group)
        tid=int(thread.name);original=allowed
        if allowed!='4-7':
         os.sched_setaffinity(tid,{4,5,6,7});allowed=re.search(r'Cpus_allowed_list:\s*(.*)',(thread/'status').read_text())[1]
        assert allowed=='4-7',(tid,allowed)
        threads.append({'tid':tid,'name':re.search(r'Name:\s*(.*)',status)[1],'cpus':allowed,'original_cpus':original,'cgroup':group})
       except FileNotFoundError:pass
      audit.append({'elapsed_s':time.monotonic()-started,'threads':threads})
     time.sleep(.25)
    assert process.returncode==0,(process.returncode,folder)
    (folder/'thread-audit.json').write_text(json.dumps(audit,indent=2))
   log=(folder/'run.log').read_text();match=re.search(r'^LIVE .*',log,re.M)
   if not match:raise RuntimeError(log[-3000:])
   players=[{k:int(v) for k,v in re.findall(r'(\w+)=(-?\d+)',m)} for m in re.findall(r'^LIVE_PLAYER .*',log,re.M)]
   assert players and players[0]['ai']==(6 if fixture=='cortex-colony' else 0),(fixture,players)
   values={k:float(v) for k,v in re.findall(r'([a-zA-Z0-9_]+)=([\d.]+)',match[0])}
   row={'repeat':repeat,'fixture':fixture,'scenario':scenario,'variant':variant,'players':players,'values':values,'elapsed_s':time.monotonic()-started,'loadavg':os.getloadavg(),'frequency_khz':{str(c):int(Path(f'/sys/devices/system/cpu/cpu{c}/cpufreq/scaling_cur_freq').read_text()) for c in (4,5,6,7)}}
   for key in ('draw_and_present','displayed_scene_age','last_simulation_deadline_lateness','frame_interval','owner_tick_wall','owner_tick_cpu'):
    line=re.search(rf'^{key} .*',log,re.M)[0];row[key]={k:float(v) for k,v in re.findall(r'(\w+)=([\d.]+)',line)}
   row['capture_measured_ticks']={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',re.search(r'^MEASURED_TICK_CAPTURE .*',log,re.M)[0])}
   row['capture_whole_session']={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',re.search(r'^LIVE_CAPTURE .*',log,re.M)[0])}
   assert values['ticks']>0 and values['frames']>0 and (fixture=='cortex-colony' or values['initial_units']==values['final_units']),row
   rows.append(row);(out/mode/'samples.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
