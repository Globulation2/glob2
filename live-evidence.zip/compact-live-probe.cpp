// SPDX-License-Identifier: GPL-3.0-or-later
#include "CommandLine.h"
// Opt-in loaded-game CPU benchmark. PROFILE_* overrides are local diagnostics.
#include "GlobalContainer.h"
#include "GameGUI.h"
#include "Engine.h"
#include "ComputeThreads.h"
#include "Team.h"
#include "Player.h"
#include "Unit.h"
#include "Building.h"
#include "render/SoftwareTerrainCache.h"
#include <RenderBackend.h>
#include <PresentationWork.h>
#include <GameplayRecording.h>
#include <stdexcept>
#include <cmath>
#include "FileManager.h"
#include "Stream.h"
#include "BinaryStream.h"
#include "Toolkit.h"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <vector>
#ifdef WIN32
#define NOMINMAX
#include <windows.h>
#else
#include <sys/resource.h>
#endif
#include <time.h>
#include "PerformanceTelemetry.h"
GlobalContainer *globalContainer = nullptr;
static double cpu()
{
#ifdef WIN32
	FILETIME created, exited, kernel, user;
	if (!GetProcessTimes(GetCurrentProcess(), &created, &exited, &kernel, &user))
		throw std::runtime_error("GetProcessTimes failed");
	auto seconds = [](FILETIME t)
	{
		ULARGE_INTEGER value;
		value.LowPart = t.dwLowDateTime;
		value.HighPart = t.dwHighDateTime;
		return value.QuadPart * 1e-7;
	};
	return seconds(kernel) + seconds(user);
#else
	rusage r{};
	if (getrusage(RUSAGE_SELF, &r))
		throw std::runtime_error("getrusage failed");
	return r.ru_utime.tv_sec + r.ru_utime.tv_usec * 1e-6 + r.ru_stime.tv_sec +
		   r.ru_stime.tv_usec * 1e-6;
#endif
}
static std::uint64_t cpuClock()
{
#if defined(CLOCK_THREAD_CPUTIME_ID) && !defined(WIN32)
	timespec t{};
	if (clock_gettime(CLOCK_THREAD_CPUTIME_ID, &t))
		throw std::runtime_error("thread CPU clock failed");
	return std::uint64_t(t.tv_sec) * 1000000000ull + t.tv_nsec;
#else
	return std::uint64_t(cpu() * 1e9);
#endif
}
static void distribution(const char *label, std::vector<double> values)
{
    if (values.empty())
        throw std::runtime_error("Benchmark produced no displayed frames");
    double total = 0;
    for (const auto value : values)
        total += value;
    std::sort(values.begin(), values.end());
    printf("%s mean_ms=%.4f median_ms=%.4f p95_ms=%.4f p99_ms=%.4f\n", label, total / values.size(),
           values[values.size() / 2], values[(values.size() - 1) * 95 / 100],
           values[(values.size() - 1) * 99 / 100]);
}

#include <atomic>
#include <fstream>
struct LiveTick { unsigned tick; Uint64 end, wall, cpu, captureNs, captureBytes, captures; unsigned checksum; };
static std::vector<LiveTick> liveTicks;
static std::atomic<unsigned> liveCompleted{0};
static Uint64 liveStart=0,liveEnd=0;
static unsigned liveFirstTick=0,liveLastTick=0;
static bool liveCorrectness=false;
static Uint64 liveFixedStart=0,liveFixedEnd=0;
extern "C" bool __real__ZN6Engine14simulationStepEm(Engine*,Uint64);

class SoftwareRenderBenchmark
{
 public:
 static bool observedStep(Engine* engine,Uint64 now)
{
    const auto before=engine->gui.game.stepCounter;
    const auto captureNs=engine->gui.game.snapshots().metrics.captureNs, captureBytes=engine->gui.game.snapshots().metrics.bytesCopied, captures=engine->gui.game.snapshots().metrics.captures;
    const auto c=cpuClock(),start=SDL_GetTicksNS();
    const bool result=__real__ZN6Engine14simulationStepEm(engine,now);
    const auto end=SDL_GetTicksNS(),cost=cpuClock()-c;
    const auto after=engine->gui.game.stepCounter;
    if(after>before) {
        if(liveLastTick && after==liveFirstTick)liveFixedStart=end;
        if(liveLastTick && after==liveLastTick)liveFixedEnd=end;
        const bool timed=liveLastTick ? (after>liveFirstTick && after<=liveLastTick) : (end>=liveStart && end<liveEnd);
        if(timed || liveCorrectness)liveTicks.push_back({after,end,end-start,cost,engine->gui.game.snapshots().metrics.captureNs-captureNs,engine->gui.game.snapshots().metrics.bytesCopied-captureBytes,engine->gui.game.snapshots().metrics.captures-captures,liveCorrectness ? engine->gui.game.checkSum(nullptr,nullptr,nullptr,true):0});
        liveCompleted.store(after,std::memory_order_release);
    }
    return result;
}


static void interactiveBenchmark()
{
    if(std::getenv("GLOB2_PERF_DISABLE"))throw std::runtime_error("Live probe requires telemetry");
    const auto path=std::getenv("PROFILE_SAVE");
    if(!path)throw std::runtime_error("Missing fixture");
    Engine engine;
    if(engine.initCustom(path)!=Engine::EE_NO_ERROR)throw std::runtime_error("Cannot load live fixture");
    if(const char* output=std::getenv("LIVE_GENERATE_CORTEX")) {
        auto header=engine.gui.game.gameHeader;header.getBasePlayer(0).makeItAI(AI::CORTEX);
        engine.gui.game.setGameHeader(header,false);
        auto* backend=new GAGCore::MemoryStreamBackend;GAGCore::BinaryOutputStream stream(backend);
        engine.gui.save(&stream,"Live Cortex colony fixture");stream.flush();const auto bytes=backend->takeContents();
        std::ofstream file(output,std::ios::binary);file.write(bytes.data(),bytes.size());
        if(!file.good())throw std::runtime_error("Cannot save fixture");return;
    }
    globalContainer->settings.gameSpeed=std::getenv("LIVE_SPEED")?std::stoi(std::getenv("LIVE_SPEED")):0;
    globalContainer->settings.clouds=false;globalContainer->settings.cloudShadows=false;
    const int fps=std::getenv("PROFILE_FPS")?std::stoi(std::getenv("PROFILE_FPS")):60;
    const double warm=std::getenv("LIVE_WARM_SECONDS")?std::stod(std::getenv("LIVE_WARM_SECONDS")):3;
    const double seconds=std::getenv("PROFILE_SECONDS")?std::stod(std::getenv("PROFILE_SECONDS")):15;
    const unsigned measuredTicks=std::getenv("LIVE_TICKS")?std::stoul(std::getenv("LIVE_TICKS")):0;
    const unsigned warmTicks=std::getenv("LIVE_WARM_TICKS")?std::stoul(std::getenv("LIVE_WARM_TICKS")):128;
    if(fps<0 || fps>1000 || seconds<=0 || warm<0)throw std::runtime_error("Invalid live timing");
    const Uint64 period=fps?1000000000ULL/fps:0;
    globalContainer->gfx->setTargetRenderFps(0); // sole pacing authority is this loop
    if(std::getenv("PROFILE_SELECT")) {
        for(int i=0;i<Unit::MAX_COUNT;i++)if(auto* unit=engine.gui.localTeam->myUnits[i]) {
            engine.gui.setSelection(GameGUI::UNIT_SELECTION,unit);break;
        }
    }
    for(int p=0;p<engine.gui.game.gameHeader.getNumberOfPlayers();p++)printf("LIVE_PLAYER player=%d type=%d ai=%d\n",p,int(engine.gui.game.players[p]->type),engine.gui.game.players[p]->ai?int(engine.gui.game.players[p]->ai->implementationID):-1);
    const auto initial=engine.gui.game.stepCounter;
    unsigned initialUnits=0;
    for(int t=0;t<engine.gui.game.mapHeader.getNumberOfTeams();t++)
        for(int i=0;i<Unit::MAX_COUNT;i++)initialUnits+=engine.gui.game.teams[t]->myUnits[i]!=nullptr;
    liveCompleted.store(initial);liveCorrectness=std::getenv("LIVE_CHECKSUMS")!=nullptr;
    liveTicks.reserve(measuredTicks?measuredTicks+warmTicks+1024:10000);
    const Uint64 began=SDL_GetTicksNS();
    liveStart=began+Uint64(warm*1e9);liveEnd=liveStart+Uint64(seconds*1e9);
    liveFirstTick=measuredTicks?initial+warmTicks:0;liveLastTick=measuredTicks?liveFirstTick+measuredTicks:0;
    engine.beginSession(SDL_GetTicks());
    if(!engine.startSimulationThread(SDL_GetTicks()))throw std::runtime_error("No simulation owner thread");
    std::vector<double> draw,age,lateness,frameInterval;
    unsigned missed=0,opportunities=0;
    Uint64 due=began,measuredStart=0,measuredEnd=0,lastFrame=0;
    double cpuStart=0,cpuEnd=0;bool measuring=false;
    while(true) {
        const auto now=SDL_GetTicksNS();
        const auto completed=liveCompleted.load(std::memory_order_acquire);
        if(!measuring && (measuredTicks?completed>=liveFirstTick:now>=liveStart)) {
            measuring=true;measuredStart=now;cpuStart=cpu();lastFrame=0;
        }
        if(measuring && (measuredTicks?completed>=liveLastTick:now>=liveEnd)) {measuredEnd=now;cpuEnd=cpu();break;}
        if(now-began>180ULL*1000000000ULL)throw std::runtime_error("Live run timed out");
        if(period && now<due){SDL_Delay(Uint32(std::min(Uint64(5),(due-now)/1000000)));continue;}
        if(!engine.threadedClientFrame(SDL_GetTicks(),{}))throw std::runtime_error("Match stopped early");
        const auto renderedBefore=PerformanceTelemetry::collector().calls[static_cast<unsigned>(PerformanceTelemetry::Id::Render)];
        const auto start=SDL_GetTicksNS();
        if(globalContainer->gfx->beginRenderFrame())engine.drawSession();
        const auto end=SDL_GetTicksNS();
        if(measuring) {
            ++opportunities;
            if(PerformanceTelemetry::collector().calls[static_cast<unsigned>(PerformanceTelemetry::Id::Render)]!=renderedBefore) {
                draw.push_back((end-start)/1e6);
                const auto displayed=SDL_GetTicks();const auto &scene=engine.gui.drawnScene();
                age.push_back(displayed>=scene.tickTime?double(displayed-scene.tickTime):0);
                lateness.push_back(engine.simulationDeadlineLatenessNs()/1e6);
                if(lastFrame)frameInterval.push_back((end-lastFrame)/1e6);lastFrame=end;
                if(period)missed+=end>due+period;
            }
        }
        if(period){due+=period;if(end>due+period)due=end;}
    }
    engine.stopSimulationThread();
    const auto final=engine.gui.game.stepCounter;
    if(liveCompleted.load()!=final)throw std::runtime_error("Authoritative tick hook mismatch");
    const double duration=(measuredEnd-measuredStart)/1e9;
    const double tickDuration=measuredTicks?(liveFixedEnd-liveFixedStart)/1e9:duration;
    std::vector<double> tickWall,tickCpu;unsigned ticks=0;Uint64 captureNs=0,captureBytes=0,capturesCount=0;
    for(const auto&tick:liveTicks) {
        const bool measured=measuredTicks?(tick.tick>liveFirstTick && tick.tick<=liveLastTick):(tick.end>=liveStart && tick.end<liveEnd);
        if(measured){++ticks;captureNs+=tick.captureNs;captureBytes+=tick.captureBytes;capturesCount+=tick.captures;tickWall.push_back(tick.wall/1e6);tickCpu.push_back(tick.cpu/1e6);}
    }
    unsigned finalUnits=0;
    for(int t=0;t<engine.gui.game.mapHeader.getNumberOfTeams();t++)
        for(int i=0;i<Unit::MAX_COUNT;i++)finalUnits+=engine.gui.game.teams[t]->myUnits[i]!=nullptr;
    printf("LIVE seconds=%.9f tick_seconds=%.9f frames=%zu ticks=%u fps=%.6f tps=%.6f cpu_seconds=%.9f missed=%u opportunities=%u initial_tick=%u final_tick=%u initial_units=%u final_units=%u target_fps=%d speed=%d tick_ns=%llu render_interval=%d\n",duration,tickDuration,draw.size(),ticks,draw.size()/duration,ticks/tickDuration,cpuEnd-cpuStart,missed,opportunities,initial,final,initialUnits,finalUnits,fps,globalContainer->settings.gameSpeed,(unsigned long long)globalContainer->settings.getGameSpeedStepDurationNs(),globalContainer->settings.getGameSpeedRenderInterval());
    distribution("draw_and_present",draw);distribution("displayed_scene_age",age);
    distribution("last_simulation_deadline_lateness",lateness);distribution("frame_interval",frameInterval);
    distribution("owner_tick_wall",tickWall);distribution("owner_tick_cpu",tickCpu);
    printf("MEASURED_TICK_CAPTURE captures=%llu ns=%llu bytes=%llu\n",(unsigned long long)capturesCount,(unsigned long long)captureNs,(unsigned long long)captureBytes);
    const auto &captures=engine.gui.game.snapshots().metrics;
    printf("LIVE_CAPTURE captures=%llu ns=%llu bytes=%llu allocations=%llu\n",(unsigned long long)captures.captures,(unsigned long long)captures.captureNs,(unsigned long long)captures.bytesCopied,(unsigned long long)captures.allocations);
    if(const char* output=std::getenv("LIVE_OUTPUT")) {
        std::ofstream file(output);file<<"{\"draw_ms\":[";
        auto values=[&](const auto&v){bool first=true;for(const auto &x:v){if(!first)file<<',';first=false;file<<x;}};
        values(draw);file<<"],\"age_ms\":[";values(age);file<<"],\"lateness_ms\":[";values(lateness);
        file<<"],\"frame_interval_ms\":[";values(frameInterval);file<<"],\"ticks\":[";
        bool first=true;for(const auto&tick:liveTicks){if(!first)file<<',';first=false;file<<'['<<tick.tick<<','<<tick.end<<','<<tick.wall<<','<<tick.cpu<<','<<tick.checksum<<','<<tick.captureNs<<','<<tick.captureBytes<<','<<tick.captures<<']';}
        file<<"]}\n";
    }
    PerformanceTelemetry::collector().write(std::cout,"interactive",final,true);
    engine.gui.isRunning=false;engine.finishSession();
}

  public:
	static int run(int argc, char **argv)
	{
		SDL_SetHint(SDL_HINT_MAC_BACKGROUND_APP, "1");
		// Keep -s dimensions as measured pixels across display densities. Opt in
		// to native Retina/HiDPI presentation explicitly for lifecycle profiling.
		const bool nativeDisplay = getenv("PROFILE_NATIVE_DISPLAY") != nullptr;
		globalContainer = new GlobalContainer;
		std::vector<std::string> launchArgs{"play"};
        launchArgs.insert(launchArgs.end(),argv+1,argv+argc);
        globalContainer->applyCommand(Cli::parse(launchArgs));
		globalContainer->settings.mute = getenv("PROFILE_AUDIO") ? 0 : 1;
		globalContainer->settings.autosaveGames = false;
		globalContainer->load();
		auto *gfx = globalContainer->gfx;
        if (!nativeDisplay && !gfx->setRes(gfx->getRequestedW(), gfx->getRequestedH(),
                gfx->getOptionFlags() | GraphicContext::LOWPIXELDENSITY))
            throw std::runtime_error(std::string("Cannot create fixed-pixel benchmark window: ") + SDL_GetError());
        const int version = SDL_GetVersion();
        printf("SDL version=%d.%d.%d revision=%s\n", SDL_VERSIONNUM_MAJOR(version),
            SDL_VERSIONNUM_MINOR(version), SDL_VERSIONNUM_MICRO(version), SDL_GetRevision());
		if (!getenv("PROFILE_VISIBLE"))
			SDL_HideWindow(SDL_GetWindowFromID(gfx->windowID()));
		if (!getenv("PROFILE_RECORD") && gfx->rendererCapabilities().accelerated)
			throw std::runtime_error("Benchmark requires the software backend (-G)");
        if (const char *mode = std::getenv("PROFILE_MODE");
            mode && std::string(mode) == "interactive")
        {
            interactiveBenchmark();
            delete globalContainer;
            globalContainer = nullptr;
            return 0;
        }
		{
			GameGUI gui;
            GAGCore::PresentationWorkScope cpuWork(gui.game.map.computeExecutor());
			const char *path = getenv("PROFILE_SAVE");
			if (!path || !*path)
				throw std::runtime_error("PROFILE_SAVE must name a saved game");
			BinaryInputStream stream(
				glob2OpenMapOrSaveInputStreamBackend(*Toolkit::getFileManager(), path));
			if (!gui.load(&stream, true))
				throw std::runtime_error("Cannot load benchmark save");
            // Standalone GameGUI loading does not start an Engine session.
            // Apply the same compute budget before measuring rendering batches.
            gui.game.map.configureCompute(resolveComputeThreadCount(globalContainer->computeThreads));
            printf("compute_threads=%zu\n", gui.game.map.computeExecutor().threadCount());
			auto &terrainCache = gui.view.render.terrainCache(gui.game.map.identity());
			if (const char *c = getenv("PROFILE_TERRAIN_CACHE"))
				terrainCache.enabled = atoi(c) != 0;
			gui.localPlayer = gui.localTeamNo = 0;
			gui.adjustLocalTeam();
			gui.adjustInitialViewport();
			gui.gamePaused = getenv("PROFILE_PAUSED") != nullptr;
			// PROFILE_SELECT=building|flag|unit selects the local team's first such entity,
			// so captures include the selection panel and the map-view selection markers.
			if (const char *select = getenv("PROFILE_SELECT"))
			{
				const std::string kind = select;
				Team *team = gui.game.teams[0];
				bool selected = false;
				for (int i = 0; i < Building::MAX_COUNT && !selected && kind != "unit"; i++)
					if (Building *b = team->myBuildings[i])
						if (kind == "flag" ? b->type->isVirtual : (!b->type->isVirtual && b->type->maxUnitWorking))
						{
							gui.setSelection(GameGUI::BUILDING_SELECTION, b);
							selected = true;
						}
				for (int i = 0; i < Unit::MAX_COUNT && !selected && kind == "unit"; i++)
					if (Unit *u = team->myUnits[i])
					{
						gui.setSelection(GameGUI::UNIT_SELECTION, u);
						selected = true;
					}
				if (!selected)
					throw std::runtime_error("PROFILE_SELECT found nothing to select");
			}
			// PROFILE_TOOL=<building type> activates the building tool with the cursor
			// over the middle of the map view, so captures include the placement preview.
			if (const char *tool = getenv("PROFILE_TOOL"))
			{
				gui.toolManager.activateBuildingTool(tool);
				gui.selectionMode = GameGUI::TOOL_SELECTION;
				gui.mouseX = (gfx->getW() - 160) / 2;
				gui.mouseY = gfx->getH() / 2;
			}
			if (const char *z = getenv("PROFILE_ZOOM"))
			{
				gui.updateCamera();
				const float zoom = std::stof(z);
				if (!std::isfinite(zoom) || zoom <= 0)
					throw std::runtime_error("Zoom must be finite and positive");
				gui.camera.setZoom(zoom, 300, 300);
				gui.viewportX = gui.camera.tileX();
				gui.viewportY = gui.camera.tileY();
			}
			int units = 0, buildings = 0;
			for (int t = 0; t < gui.game.mapHeader.getNumberOfTeams(); t++)
			{
				for (int i = 0; i < Unit::MAX_COUNT; i++)
					units += gui.game.teams[t]->myUnits[i] != nullptr;
				for (int i = 0; i < Building::MAX_COUNT; i++)
					buildings += gui.game.teams[t]->myBuildings[i] != nullptr;
			}
			if (getenv("PROFILE_FRACTION"))
			{
				gui.updateCamera();
				gui.camera.originX += .5;
				gui.viewportX = gui.camera.tileX();
			}
			if (const char *x = getenv("PROFILE_OFFSET_X"))
				gui.camera.originX += std::stof(x);
			if (const char *y = getenv("PROFILE_OFFSET_Y"))
				gui.camera.originY += std::stof(y);
			if (!std::isfinite(gui.camera.originX) || !std::isfinite(gui.camera.originY))
				throw std::runtime_error("Camera offsets must be finite");
			gui.viewportX = gui.camera.tileX();
			gui.viewportY = gui.camera.tileY();
			gui.view.render.minimumZoom = gui.camera.minimumZoom();
			printf("CAMERA zoom=%.4f fractional=%.4f,%.4f offset=%.4f,%.4f\n", gui.camera.zoom,
				   gui.camera.fractionX(), gui.camera.fractionY(), gui.camera.offsetX,
				   gui.camera.offsetY);
			const int frames = getenv("PROFILE_FRAMES") ? atoi(getenv("PROFILE_FRAMES")) : 240;
			const int warmup = getenv("PROFILE_WARMUP") ? atoi(getenv("PROFILE_WARMUP")) : 30;
			if (frames < 1 || warmup < 0)
				throw std::runtime_error("frames must be positive and warmup nonnegative");
			const char *mode = getenv("PROFILE_MODE");
			if (!mode)
				mode = "gui";
			const bool clouds = !(getenv("PROFILE_CLOUDS") && atoi(getenv("PROFILE_CLOUDS")) == 0);
			globalContainer->settings.clouds = clouds;
			globalContainer->settings.cloudShadows = clouds;
			// PROFILE_ADAPTIVE_ZOOM=0 draws overlays scaled with the map, as before
			// adaptive zoom detail, for before/after captures from one build.
			if (const char *adaptive = getenv("PROFILE_ADAPTIVE_ZOOM"))
				globalContainer->settings.adaptiveZoomDetail = atoi(adaptive) != 0;
			printf("READY save=%s tick=%u map=%dx%d teams=%d units=%d buildings=%d surface=%dx%d "
				   "camera=%d,%d mode=%s clouds=%d frames=%d driver=%s\n",
				   path, gui.game.stepCounter, gui.game.map.getW(), gui.game.map.getH(),
				   gui.game.mapHeader.getNumberOfTeams(), units, buildings, gfx->getW(),
				   gfx->getH(), gui.viewportX, gui.viewportY, mode, clouds, frames,
				   SDL_GetCurrentVideoDriver());
			fflush(stdout);
			if (getenv("PROFILE_CPU_SCOPES"))
			{
				PerformanceTelemetry::collector().clock = cpuClock;
				PerformanceTelemetry::collector().reset();
			}
			auto &recorder = GAGCore::Recording::recorder();
			if (const char *record = getenv("PROFILE_RECORD"); record && std::string(record) != "off")
			{
				if (getenv("PROFILE_RECORD_SOFTWARE")) recorder.options.encoder = GAGCore::Recording::EncoderPreference::Software;
				if (!recorder.start(record)) throw std::runtime_error(recorder.status().error);
				recorder.beginMatch("benchmark",path,0,gui.game.stepCounter);
				recorder.matchFrame(gui.game.stepCounter,false,1);
			}
			const double seconds = getenv("PROFILE_SECONDS") ? std::stod(getenv("PROFILE_SECONDS")) : 0;
			Uint64 measuredStart = 0;
			std::vector<double> draw, present;
			RenderOperations initialOps{};
            decltype(terrainCache.workMetrics) initialWork{};
            if (const char* mode = getenv("PROFILE_COMPUTE_TELEMETRY"))
                gui.game.map.computeExecutor().configureTelemetry(ComputeTelemetry::parseMode(mode));
            auto initialGraphics = gui.game.map.computeExecutor().graphicsMetrics();
			std::uint64_t initialHits = 0, initialRebuilds = 0;
			double c0 = 0;
			double freq = SDL_GetPerformanceFrequency();
			const auto checksum = gui.game.checkSum(nullptr, nullptr, nullptr, true);
			for (int i = -warmup; i < frames || (seconds > 0 && (i < 0 || (SDL_GetPerformanceCounter()-measuredStart)/freq < seconds)); i++)
			{
				SDL_PumpEvents();
				if (i == 0)
				{
					c0 = cpu(); measuredStart = SDL_GetPerformanceCounter();
					initialOps = gfx->backendOperations();
                    initialWork = terrainCache.workMetrics;
                    initialGraphics = gui.game.map.computeExecutor().graphicsMetrics();
					initialHits = terrainCache.cacheHits();
					initialRebuilds = terrainCache.cacheRebuilds();
					PerformanceTelemetry::collector().reset();
				}
				if (getenv("PROFILE_PAN"))
				{ gui.camera.originX += .25; gui.viewportX = gui.camera.tileX(); }
				Uint64 a = SDL_GetPerformanceCounter();
				// Isolate the retention-copy cost without a production graphics setting.
				if (getenv("PROFILE_PRESERVE_FRAME"))
					gfx->beginFrame(GraphicContext::FrameMode::PreserveContent);
				// Standalone tools observe through the production snapshot boundary.
				gui.game.snapshots().invalidateBoundary();
				gui.prepareLocalPresentation();
				if (std::string(mode) == "gui")
					gui.drawAll(0);
				else
				{
					gfx->beginFrame(GraphicContext::FrameMode::FullRedraw);
					gfx->setClipRect();
					Game::drawMap(0, 0, gfx->getW() - 160, gfx->getH(), 0, 0, gui.viewportX,
									 gui.viewportY, 0, gui.view, Game::DRAW_AREA |
                                         (getenv("PROFILE_WHOLE_MAP") ? Game::DRAW_WHOLE_MAP : 0),
                                         nullptr, nullptr, gui.gamePaused);
				}
				Uint64 b = SDL_GetPerformanceCounter();
				if (!getenv("PROFILE_NO_PRESENT"))
					gfx->nextFrame();
				Uint64 c = SDL_GetPerformanceCounter();
				if (i >= 0)
				{
					draw.push_back(1000. * (b - a) / freq);
					present.push_back(1000. * (c - b) / freq);
				}
			}
			double totalCpu = cpu() - c0;
			const double elapsed = (SDL_GetPerformanceCounter()-measuredStart)/freq;
			printf("render_fps=%.4f elapsed_seconds=%.4f frames=%zu\n",draw.size()/elapsed,elapsed,draw.size());
			recorder.stop(); recorder.shutdown();
			if (const char *record = getenv("PROFILE_RECORD"); record && std::string(record) != "off")
			{
				const auto status = recorder.status();
				printf("recording encoder=%s dimensions=%dx%d dropped_frames=%llu dropped_audio_samples=%llu\n",status.encoder.c_str(),status.width,status.height,(unsigned long long)status.droppedFrames,(unsigned long long)status.droppedAudioSamples);
				if (status.state != GAGCore::Recording::State::Complete) throw std::runtime_error(status.error);
			}
#ifndef WIN32
			rusage memory{}; getrusage(RUSAGE_SELF,&memory);
			printf("peak_rss_bytes=%llu\n",(unsigned long long)memory.ru_maxrss *
#ifdef __APPLE__
				1ull
#else
				1024ull
#endif
			);
#endif
			if (gui.game.checkSum(nullptr, nullptr, nullptr, true) != checksum)
				throw std::runtime_error("rendering changed simulation checksum");
			printf("simulation_checksum=%u\n", checksum);
            distribution("draw", draw);
            distribution("present", present);
			printf("process_cpu_ms_per_frame=%.4f\n", totalCpu * 1000 / draw.size());
			fflush(stdout);
			auto ops = gfx->backendOperations();
			printf("backend_ops blits=%llu fills=%llu triangles=%llu\n",
				   (unsigned long long)(ops.blits - initialOps.blits),
				   (unsigned long long)(ops.fills - initialOps.fills),
				   (unsigned long long)(ops.triangles - initialOps.triangles));
			printf("terrain_cache bytes=%zu mask_bytes=%zu hits=%llu rebuilds=%llu\n",
				   terrainCache.bytes(), terrainCache.maskBytes(),
				   (unsigned long long)(terrainCache.cacheHits() - initialHits),
				   (unsigned long long)(terrainCache.cacheRebuilds() -
										initialRebuilds));
            const auto work = terrainCache.workMetrics;
            const auto graphics = gui.game.map.computeExecutor().graphicsMetrics();
            printf("terrain_cpu batches=%llu jobs=%llu cells=%llu serial_pages=%llu "
                   "batch_ns=%llu peak_reserved_bytes=%zu\n",
                   (unsigned long long)(work.batches - initialWork.batches), (unsigned long long)(work.jobs - initialWork.jobs),
                   (unsigned long long)(work.cells - initialWork.cells), (unsigned long long)(work.serialPages - initialWork.serialPages),
                   (unsigned long long)(work.batchNs - initialWork.batchNs), work.peakReservedBytes);
            printf("raster_cpu batches=%llu tiles=%llu references=%llu "
                   "serial_batches=%llu snapshot_bytes=%llu peak_retained_bytes=%llu "
                   "fallback_operations=%llu\n",
                   (unsigned long long)(ops.rasterBatches - initialOps.rasterBatches), (unsigned long long)(ops.rasterTiles - initialOps.rasterTiles),
                   (unsigned long long)(ops.rasterReferences - initialOps.rasterReferences),
                   (unsigned long long)(ops.rasterSerialBatches - initialOps.rasterSerialBatches),
                   (unsigned long long)(ops.rasterSnapshotBytes - initialOps.rasterSnapshotBytes),
                   (unsigned long long)ops.rasterPeakRetainedBytes,
                   (unsigned long long)(ops.rasterFallbacks - initialOps.rasterFallbacks));
            const auto computeMode = gui.game.map.computeExecutor().telemetryMode();
            const bool graphicsAvailable = computeMode == ComputeTelemetryMode::Trace;
            const auto field = [](std::uint64_t value, bool available) { return available ? std::to_string(value) : std::string("na"); };
            printf("graphics_executor mode=%s worker_available=%s batches=%s parallel_batches=%s jobs=%s "
                   "summed_queue_ns=%s summed_active_ns=%s owner_wait_ns=%s\n",
                   ComputeTelemetry::ModeNames[unsigned(computeMode)].data(), graphicsAvailable ? "true" : "false",
                   field(graphics.batches-initialGraphics.batches,graphicsAvailable).c_str(),
                   field(graphics.parallelBatches-initialGraphics.parallelBatches,graphicsAvailable).c_str(),
                   field(graphics.jobs-initialGraphics.jobs,graphicsAvailable).c_str(),
                   field(graphics.queueNs-initialGraphics.queueNs,graphicsAvailable).c_str(),
                   field(graphics.activeNs-initialGraphics.activeNs,graphicsAvailable).c_str(),
                   field(graphics.waitNs-initialGraphics.waitNs,computeMode!=ComputeTelemetryMode::Off).c_str());
			PerformanceTelemetry::collector().write(std::cout, "profile", gui.game.stepCounter,
													false);
			if (const char *p = getenv("PROFILE_CAPTURE"))
				SDL_SaveBMP(gfx->getSDLSurface(), p);
		}
		delete globalContainer;
		globalContainer = nullptr;
		return 0;
	}
};
int main(int argc, char **argv)
{
	try
	{
		return SoftwareRenderBenchmark::run(argc, argv);
	}
	catch (const std::exception &e)
	{
		fprintf(stderr, "%s\n", e.what());
		delete globalContainer;
		globalContainer = nullptr;
		return 1;
	}
}

extern "C" bool __wrap__ZN6Engine14simulationStepEm(Engine* e,Uint64 now){ return SoftwareRenderBenchmark::observedStep(e,now); }
