from pathlib import Path
import json,subprocess
root=Path.cwd();out=root/'artifacts/compact-live';old=root/'artifacts/compact-runtime'
wrap=r'''
#include <atomic>
#include <fstream>
struct LiveTick { unsigned tick; Uint64 end, wall, cpu, captureNs, captureBytes, captures; unsigned checksum; };
static std::vector<LiveTick> liveTicks;
static std::atomic<unsigned> liveCompleted{0};
static Uint64 liveStart=0,liveEnd=0;
static unsigned liveFirstTick=0,liveLastTick=0;
static bool liveCorrectness=false;
static Uint64 liveFixedStart=0,liveFixedEnd=0;
extern "C" bool __real__ZN6Engine14simulationStepEm(Engine*,Uint64);
extern "C" bool __wrap__ZN6Engine14simulationStepEm(Engine* engine,Uint64 now)
{
    const auto before=engine->gui.game.stepCounter;
    const auto captureNs=engine->gui.game.snapshots().metrics.captureNs, captureBytes=engine->gui.game.snapshots().metrics.bytesCopied, captures=engine->gui.game.snapshots().metrics.captures;
    const auto c=cpuClock(),start=SDL_GetTicksNS();
    const bool result=__real__ZN6Engine14simulationStepEm(engine,now);
    const auto end=SDL_GetTicksNS(),cost=cpuClock()-c;
    const auto after=engine->gui.game.stepCounter;
    if(after>before) {
        if(liveLastTick && after==liveFirstTick)liveFixedStart=end;
        if(liveLastTick && after==liveLastTick)liveFixedEnd=end;
        const bool timed=liveLastTick ? (after>liveFirstTick && after<=liveLastTick) : (end>=liveStart && end<liveEnd);
        if(timed || liveCorrectness)liveTicks.push_back({after,end,end-start,cost,engine->gui.game.snapshots().metrics.captureNs-captureNs,engine->gui.game.snapshots().metrics.bytesCopied-captureBytes,engine->gui.game.snapshots().metrics.captures-captures,liveCorrectness ? engine->gui.game.checkSum(nullptr,nullptr,nullptr,true):0});
        liveCompleted.store(after,std::memory_order_release);
    }
    return result;
}
'''
function=r'''
static void interactiveBenchmark()
{
    if(std::getenv("GLOB2_PERF_DISABLE"))throw std::runtime_error("Live probe requires telemetry");
    const auto path=std::getenv("PROFILE_SAVE");
    if(!path)throw std::runtime_error("Missing fixture");
    Engine engine;
    if(engine.initCustom(path)!=Engine::EE_NO_ERROR)throw std::runtime_error("Cannot load live fixture");
    if(const char* output=std::getenv("LIVE_GENERATE_CORTEX")) {
        auto header=engine.gui.game.gameHeader;header.getBasePlayer(0).makeItAI(AI::CORTEX);
        engine.gui.game.setGameHeader(header,false);
        auto* backend=new GAGCore::MemoryStreamBackend;GAGCore::BinaryOutputStream stream(backend);
        engine.gui.save(&stream,"Live Cortex colony fixture");stream.flush();const auto bytes=backend->takeContents();
        std::ofstream file(output,std::ios::binary);file.write(bytes.data(),bytes.size());
        if(!file.good())throw std::runtime_error("Cannot save fixture");return;
    }
    globalContainer->settings.gameSpeed=std::getenv("LIVE_SPEED")?std::stoi(std::getenv("LIVE_SPEED")):0;
    globalContainer->settings.clouds=false;globalContainer->settings.cloudShadows=false;
    const int fps=std::getenv("PROFILE_FPS")?std::stoi(std::getenv("PROFILE_FPS")):60;
    const double warm=std::getenv("LIVE_WARM_SECONDS")?std::stod(std::getenv("LIVE_WARM_SECONDS")):3;
    const double seconds=std::getenv("PROFILE_SECONDS")?std::stod(std::getenv("PROFILE_SECONDS")):15;
    const unsigned measuredTicks=std::getenv("LIVE_TICKS")?std::stoul(std::getenv("LIVE_TICKS")):0;
    const unsigned warmTicks=std::getenv("LIVE_WARM_TICKS")?std::stoul(std::getenv("LIVE_WARM_TICKS")):128;
    if(fps<0 || fps>1000 || seconds<=0 || warm<0)throw std::runtime_error("Invalid live timing");
    const Uint64 period=fps?1000000000ULL/fps:0;
    globalContainer->gfx->setTargetRenderFps(0); // sole pacing authority is this loop
    if(std::getenv("PROFILE_SELECT")) {
        for(int i=0;i<Unit::MAX_COUNT;i++)if(auto* unit=engine.gui.localTeam->myUnits[i]) {
            engine.gui.setSelection(GameGUI::UNIT_SELECTION,unit);break;
        }
    }
    for(int p=0;p<engine.gui.game.gameHeader.getNumberOfPlayers();p++)printf("LIVE_PLAYER player=%d type=%d ai=%d\n",p,int(engine.gui.game.players[p]->type),engine.gui.game.players[p]->ai?int(engine.gui.game.players[p]->ai->implementationID):-1);
    const auto initial=engine.gui.game.stepCounter;
    unsigned initialUnits=0;
    for(int t=0;t<engine.gui.game.mapHeader.getNumberOfTeams();t++)
        for(int i=0;i<Unit::MAX_COUNT;i++)initialUnits+=engine.gui.game.teams[t]->myUnits[i]!=nullptr;
    liveCompleted.store(initial);liveCorrectness=std::getenv("LIVE_CHECKSUMS")!=nullptr;
    liveTicks.reserve(measuredTicks?measuredTicks+warmTicks+1024:10000);
    const Uint64 began=SDL_GetTicksNS();
    liveStart=began+Uint64(warm*1e9);liveEnd=liveStart+Uint64(seconds*1e9);
    liveFirstTick=measuredTicks?initial+warmTicks:0;liveLastTick=measuredTicks?liveFirstTick+measuredTicks:0;
    engine.beginSession(SDL_GetTicks());
    if(!engine.startSimulationThread(SDL_GetTicks()))throw std::runtime_error("No simulation owner thread");
    std::vector<double> draw,age,lateness,frameInterval;
    unsigned missed=0,opportunities=0;
    Uint64 due=began,measuredStart=0,measuredEnd=0,lastFrame=0;
    double cpuStart=0,cpuEnd=0;bool measuring=false;
    while(true) {
        const auto now=SDL_GetTicksNS();
        const auto completed=liveCompleted.load(std::memory_order_acquire);
        if(!measuring && (measuredTicks?completed>=liveFirstTick:now>=liveStart)) {
            measuring=true;measuredStart=now;cpuStart=cpu();lastFrame=0;
        }
        if(measuring && (measuredTicks?completed>=liveLastTick:now>=liveEnd)) {measuredEnd=now;cpuEnd=cpu();break;}
        if(now-began>180ULL*1000000000ULL)throw std::runtime_error("Live run timed out");
        if(period && now<due){SDL_Delay(Uint32(std::min(Uint64(5),(due-now)/1000000)));continue;}
        if(!engine.threadedClientFrame(SDL_GetTicks(),{}))throw std::runtime_error("Match stopped early");
        const auto renderedBefore=PerformanceTelemetry::collector().calls[static_cast<unsigned>(PerformanceTelemetry::Id::Render)];
        const auto start=SDL_GetTicksNS();
        if(globalContainer->gfx->beginRenderFrame())engine.drawSession();
        const auto end=SDL_GetTicksNS();
        if(measuring) {
            ++opportunities;
            if(PerformanceTelemetry::collector().calls[static_cast<unsigned>(PerformanceTelemetry::Id::Render)]!=renderedBefore) {
                draw.push_back((end-start)/1e6);
                const auto displayed=SDL_GetTicks();const auto &scene=engine.gui.drawnScene();
                age.push_back(displayed>=scene.tickTime?double(displayed-scene.tickTime):0);
                lateness.push_back(engine.simulationDeadlineLatenessNs()/1e6);
                if(lastFrame)frameInterval.push_back((end-lastFrame)/1e6);lastFrame=end;
                if(period)missed+=end>due+period;
            }
        }
        if(period){due+=period;if(end>due+period)due=end;}
    }
    engine.stopSimulationThread();
    const auto final=engine.gui.game.stepCounter;
    if(liveCompleted.load()!=final)throw std::runtime_error("Authoritative tick hook mismatch");
    const double duration=(measuredEnd-measuredStart)/1e9;
    const double tickDuration=measuredTicks?(liveFixedEnd-liveFixedStart)/1e9:duration;
    std::vector<double> tickWall,tickCpu;unsigned ticks=0;Uint64 captureNs=0,captureBytes=0,capturesCount=0;
    for(const auto&tick:liveTicks) {
        const bool measured=measuredTicks?(tick.tick>liveFirstTick && tick.tick<=liveLastTick):(tick.end>=liveStart && tick.end<liveEnd);
        if(measured){++ticks;captureNs+=tick.captureNs;captureBytes+=tick.captureBytes;capturesCount+=tick.captures;tickWall.push_back(tick.wall/1e6);tickCpu.push_back(tick.cpu/1e6);}
    }
    unsigned finalUnits=0;
    for(int t=0;t<engine.gui.game.mapHeader.getNumberOfTeams();t++)
        for(int i=0;i<Unit::MAX_COUNT;i++)finalUnits+=engine.gui.game.teams[t]->myUnits[i]!=nullptr;
    printf("LIVE seconds=%.9f tick_seconds=%.9f frames=%zu ticks=%u fps=%.6f tps=%.6f cpu_seconds=%.9f missed=%u opportunities=%u initial_tick=%u final_tick=%u initial_units=%u final_units=%u target_fps=%d speed=%d tick_ns=%llu render_interval=%d\n",duration,tickDuration,draw.size(),ticks,draw.size()/duration,ticks/tickDuration,cpuEnd-cpuStart,missed,opportunities,initial,final,initialUnits,finalUnits,fps,globalContainer->settings.gameSpeed,(unsigned long long)globalContainer->settings.getGameSpeedStepDurationNs(),globalContainer->settings.getGameSpeedRenderInterval());
    distribution("draw_and_present",draw);distribution("displayed_scene_age",age);
    distribution("last_simulation_deadline_lateness",lateness);distribution("frame_interval",frameInterval);
    distribution("owner_tick_wall",tickWall);distribution("owner_tick_cpu",tickCpu);
    printf("MEASURED_TICK_CAPTURE captures=%llu ns=%llu bytes=%llu\n",(unsigned long long)capturesCount,(unsigned long long)captureNs,(unsigned long long)captureBytes);
    const auto &captures=engine.gui.game.snapshots().metrics;
    printf("LIVE_CAPTURE captures=%llu ns=%llu bytes=%llu allocations=%llu\n",(unsigned long long)captures.captures,(unsigned long long)captures.captureNs,(unsigned long long)captures.bytesCopied,(unsigned long long)captures.allocations);
    if(const char* output=std::getenv("LIVE_OUTPUT")) {
        std::ofstream file(output);file<<"{\"draw_ms\":[";
        auto values=[&](const auto&v){bool first=true;for(const auto &x:v){if(!first)file<<',';first=false;file<<x;}};
        values(draw);file<<"],\"age_ms\":[";values(age);file<<"],\"lateness_ms\":[";values(lateness);
        file<<"],\"frame_interval_ms\":[";values(frameInterval);file<<"],\"ticks\":[";
        bool first=true;for(const auto&tick:liveTicks){if(!first)file<<',';first=false;file<<'['<<tick.tick<<','<<tick.end<<','<<tick.wall<<','<<tick.cpu<<','<<tick.checksum<<','<<tick.captureNs<<','<<tick.captureBytes<<','<<tick.captures<<']';}
        file<<"]}\n";
    }
    PerformanceTelemetry::collector().write(std::cout,"interactive",final,true);
    engine.gui.isRunning=false;engine.finishSession();
}
'''
for variant,source in [('reference',root/'artifacts/compact-unit-state/reference-source'),('compact',old/'compact-source')]:
 text=(source/'src/render/SoftwareRenderBenchmark.cpp').read_text().replace('#include "Team.h"','#include "Team.h"\n#include "Player.h"')
 header,method=wrap.split('extern \"C\" bool __wrap__ZN6Engine14simulationStepEm',1)
 text=text.replace('class SoftwareRenderBenchmark\n{',header+'\nclass SoftwareRenderBenchmark\n{\n public:\n static bool observedStep'+method)
 text+='\nextern \"C\" bool __wrap__ZN6Engine14simulationStepEm(Engine* e,Uint64 now){ return SoftwareRenderBenchmark::observedStep(e,now); }\n'
 a=text.index('static void interactiveBenchmark()');b=text.index('  public:',a)
 text=text[:a]+function+'\n'+text[b:]
 cpp=out/f'{variant}-live-probe.cpp';cpp.write_text(text)
 obj=out/f'{variant}-live-probe.o';binary=out/f'{variant}-live-probe'
 compile=json.loads((old/f'{variant}-probe-compile.json').read_text())
 compile=[str(cpp) if x.endswith(f'{variant}-runtime-probe.cpp') else str(obj) if x.endswith(f'{variant}-runtime-probe.o') else x for x in compile]
 (out/f'{variant}-compile.json').write_text(json.dumps(compile));subprocess.run(compile,check=True)
 link=json.loads((old/f'{variant}-probe-link.json').read_text())
 link=[str(binary) if x.endswith(f'{variant}-runtime-probe') else str(obj) if x.endswith(f'{variant}-runtime-probe.o') else x for x in link]
 link.insert(3,'-Wl,--wrap=_ZN6Engine14simulationStepEm')
 (out/f'{variant}-link.json').write_text(json.dumps(link));subprocess.run(link,check=True)
