from pathlib import Path
import json,math,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=Path('artifacts/compact-live');rows=json.loads((out/'timing/samples.json').read_text());rows=[r for r in rows if r['repeat']>=0]
rng=np.random.default_rng(71320261013)
metrics={
 'fps':(lambda r:r['values']['fps'],True),
 'tps':(lambda r:r['values']['tps'],True),
 'cpu_cores':(lambda r:r['values']['cpu_seconds']/r['values']['seconds'],False),
 'draw_mean_ms':(lambda r:r['draw_and_present']['mean_ms'],False),
 'draw_p99_ms':(lambda r:r['draw_and_present']['p99_ms'],False),
 'tick_mean_ms':(lambda r:r['owner_tick_wall']['mean_ms'],False),
 'tick_p99_ms':(lambda r:r['owner_tick_wall']['p99_ms'],False),
 'tick_cpu_mean_ms':(lambda r:r['owner_tick_cpu']['mean_ms'],False),
 'age_mean_ms':(lambda r:r['displayed_scene_age']['mean_ms'],False),
 'age_p99_ms':(lambda r:r['displayed_scene_age']['p99_ms'],False),
 'capture_us_per_tick':(lambda r:r['capture_measured_ticks']['ns']/r['values']['ticks']/1000,False),
 'capture_bytes_per_tick':(lambda r:r['capture_measured_ticks']['bytes']/r['values']['ticks'],False),
}
primary={('large-colony','normal','cpu_cores'),('large-colony','uncapped-render','fps'),('large-colony','max-speed','tps')}
cases=[('ordinary-control','normal'),('large-colony','normal'),('large-colony','uncapped-render'),('large-colony','max-speed'),('cortex-colony','normal')]
summary=[]
for fixture,scenario in cases:
 case=[r for r in rows if r['fixture']==fixture and r['scenario']==scenario]
 paired={i:{r['variant']:r for r in case if r['repeat']==i} for i in range(10)}
 assert all(set(p)=={'reference','compact'} for p in paired.values()),(fixture,scenario)
 result={'fixture':fixture,'scenario':scenario,'pairs':10,'metrics':{}}
 for key,(value,higher) in metrics.items():
  before=np.array([value(paired[i]['reference']) for i in range(10)]);after=np.array([value(paired[i]['compact']) for i in range(10)])
  ratios=after/before;logs=np.log(ratios);sample=rng.integers(0,10,size=(100000,10));boot=np.exp(logs[sample].mean(axis=1))
  benefit=lambda ratio:100*(ratio-1 if higher else 1-ratio)
  confidence=lambda tail:sorted([float(benefit(x)) for x in np.quantile(boot,[tail,1-tail])])
  result['metrics'][key]={'before_mean':float(before.mean()),'after_mean':float(after.mean()),'benefit_percent':float(benefit(np.exp(logs.mean()))),'ci95':confidence(.025),'paired_before':before.tolist(),'paired_after':after.tolist(),'primary':(fixture,scenario,key) in primary}
  if (fixture,scenario,key) in primary:result['metrics'][key]['family_ci98_333']=confidence(.05/6)
 result['missed']={v:sum(int(p[v]['values']['missed']) for p in paired.values()) for v in ('reference','compact')}
 result['frames']={v:sum(int(p[v]['values']['frames']) for p in paired.values()) for v in ('reference','compact')}
 result['population_ranges']={v:[min(p[v]['values']['final_units'] for p in paired.values()),max(p[v]['values']['final_units'] for p in paired.values())] for v in ('reference','compact')}
 result['capture_fraction_owner_percent']={v:float(np.mean([100*(p[v]['capture_measured_ticks']['ns']/1e6)/(p[v]['owner_tick_wall']['mean_ms']*p[v]['values']['ticks']) for p in paired.values()])) for v in ('reference','compact')}
 summary.append(result)
(out/'summary.json').write_text(json.dumps(summary,indent=2))
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white'})
labels=['32 workers\nnormal','1,024 workers\nnormal','1,024 workers\nuncapped drawing','1,024 workers\nmax simulation','1,024 + Cortex\nnormal']
colors={'reference':'#627d98','compact':'#117864'}
fig,axs=plt.subplots(2,2,figsize=(13,9))
for ax,key,title in zip(axs.flat,['fps','tps','cpu_cores','capture_us_per_tick'],['Achieved displayed FPS','Authoritative completed TPS','Game process CPU (core equivalents)','Capture time per measured advancing tick (µs)']):
 x=np.arange(5)
 for vi,v in enumerate(('reference','compact')):
  values=[s['metrics'][key][v.replace('reference','before').replace('compact','after')+'_mean'] for s in summary]
  ax.bar(x+(vi-.5)*.34,values,.32,color=colors[v],label='Old full unit records' if v=='reference' else 'Shared compact unit core')
  for i,s in enumerate(summary):
   y=s['metrics'][key]['paired_before' if v=='reference' else 'paired_after'];ax.scatter(np.full(10,x[i]+(vi-.5)*.34),y,s=8,color='black',alpha=.35,zorder=3)
 ax.set_xticks(x,labels);ax.set_title(title);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
 if key=='fps':ax.axhline(60,color='black',ls=':',lw=1)
 if key=='tps':ax.axhline(30,color='black',ls=':',lw=1)
axs[0,0].legend(loc='upper left',fontsize=8)
fig.suptitle('Live threaded matches: capture at production boundaries\nExclusive four physical cores • ten paired runs • Linux SDL software/Xvfb • 640×480',fontsize=13)
fig.text(.5,.012,'Dots are whole-run repetitions. Capped FPS/TPS do not measure spare throughput. Max-speed uses preset 10; native threaded drawing stays at 60 FPS.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.04,1,.93))
for ext in ('png','svg','pdf'):fig.savefig(out/f'live-throughput.{ext}',dpi=170)
fig,axs=plt.subplots(1,3,figsize=(13,5))
for ax,(fixture,scenario,key),title in zip(axs,[('large-colony','normal','cpu_cores'),('large-colony','uncapped-render','fps'),('large-colony','max-speed','tps')],['Normal colony: CPU reduction','Uncapped drawing: FPS increase','Max simulation: TPS increase']):
 s=next(s for s in summary if (s['fixture'],s['scenario'])==(fixture,scenario));m=s['metrics'][key];b=m['benefit_percent'];lo,hi=m['ci95'];flo,fhi=m['family_ci98_333'];ax.axvline(0,color='gray',lw=1)
 ax.errorbar(b,0,xerr=[[b-flo],[fhi-b]],color='#7f8c8d',capsize=8,lw=2,label='98.333% family CI');ax.errorbar(b,0,xerr=[[b-lo],[hi-b]],color=colors['compact'],capsize=5,lw=4,label='95% CI');ax.plot(b,0,'o',color=colors['compact']);ax.set_yticks([]);ax.set_xlabel('Benefit (%)');ax.set_title(title);ax.set_ylim(-.6,.6);ax.text(.5,.85,f'{b:+.2f}% [{lo:+.2f}, {hi:+.2f}]',transform=ax.transAxes,ha='center',fontsize=10)
axs[0].legend(loc='lower left',fontsize=8);fig.suptitle('Three predeclared primary outcomes • paired run-level bootstrap intervals',fontsize=12);fig.tight_layout(rect=(0,0,1,.9))
for ext in ('png','svg','pdf'):fig.savefig(out/f'live-benefit.{ext}',dpi=170)
fig,axs=plt.subplots(1,2,figsize=(12,5))
for ax,key,title in zip(axs,['draw_p99_ms','tick_p99_ms'],['Per-run p99 draw + presentation (ms)','Per-run p99 owner tick-step (ms)']):
 for vi,v in enumerate(('reference','compact')):
  ax.bar(np.arange(5)+(vi-.5)*.34,[s['metrics'][key]['before_mean' if v=='reference' else 'after_mean'] for s in summary],.32,label=v,color=colors[v])
 ax.set_xticks(np.arange(5),labels);ax.set_title(title);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
axs[0].axhline(16.667,color='gray',ls=':',lw=1,label='60 FPS budget');axs[1].axhline(33.333,color='gray',ls=':',lw=1,label='normal tick budget');axs[0].legend(fontsize=8);axs[1].legend(fontsize=8)
fig.suptitle('Tail latency while the match advances • no checksum instrumentation in timing runs');fig.tight_layout(rect=(0,0,1,.93))
for ext in ('png','svg','pdf'):fig.savefig(out/f'live-latency.{ext}',dpi=170)
print(json.dumps([{**{k:s[k] for k in ('fixture','scenario','missed','population_ranges')},'metrics':{k:{a:m[a] for a in ('before_mean','after_mean','benefit_percent','ci95')} for k,m in s['metrics'].items() if k in ('fps','tps','cpu_cores','capture_us_per_tick')}} for s in summary],indent=2))
