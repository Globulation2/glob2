from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json
out=Path('artifacts/braided-delta-resource-redesign/sweep');out.mkdir(exist_ok=True)
binary=str(Path('artifacts/braided-delta-resource-redesign/after-glob2').resolve())
cases=[]
shapes=[(128,128,2,{}),(128,128,4,{'rejoining-frequency':3}),(256,256,4,{}),(256,128,4,{}),(128,256,4,{}),(256,256,12,{'braid-count':4,'rejoining-frequency':3}),(512,256,8,{}),(256,512,8,{}),(512,512,12,{'braid-count':5,'island-size':48,'rejoining-frequency':3})]
for width,height,teams,layout in shapes:
 for seed in [7,29]:
  for wheat,wood,other in [(100,100,100),(0,0,0),(300,300,300),(300,0,300),(0,300,300)]:
   cases.append(dict(width=width,height=height,teams=teams,seed=seed,workers=8 if seed==29 else 4,options={**layout,'wheat-amount':wheat,'wood-amount':wood,'stone-amount':other,'fruit-amount':other,'algae-amount':other}))
for braids in [2,3,4]:
 for size in [40,48]:
  for spacing in [32,96]:
   cases.append(dict(width=256,height=256,teams=4,seed=401,workers=8,options={'braid-count':braids,'island-size':size,'crossing-spacing':spacing,'fruit-amount':300}))
(out/'requests.json').write_text(json.dumps(cases,indent=2))
def run(item):
 k,c=item;cmd=[binary,'map','generate','braided-delta','--width',str(c['width']),'--height',str(c['height']),'--teams',str(c['teams']),'--seed',str(c['seed']),'--workers',str(c['workers']),'--report-file',str(out/f'{k:03d}.json')]
 for key,value in c['options'].items():cmd+=['--set',f'{key}={value}']
 with (out/f'{k:03d}.log').open('w') as log:
  try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 return {'case':k,'returncode':code}
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,enumerate(cases)))
(out/'results.json').write_text(json.dumps(results,indent=2));print('Cases',len(results),'failures',[r for r in results if r['returncode']],flush=True)
