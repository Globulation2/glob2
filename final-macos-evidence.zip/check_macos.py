from pathlib import Path
import subprocess,json,hashlib,gzip
root=Path('/Users/bradley/.codex/worktrees/building-recruitment/glob2');p=Path('/Users/bradley/glob2/artifacts/building-recruitment');out=p/'final'
binary=root/'build/darwin/client/release/src/glob2';inputs=Path('/Users/bradley/glob2/artifacts/sim-callgrind-master-486a2230a/inputs');results={};commands=[]
for name,save,ticks,threads,expected in [('12k','midgame12k.game.gz',13153,8,'canonical12k'),('24k','midgame24k.game.gz',25153,8,'reuse-experiment/macos-baseline24k'),('24k-serial','midgame24k.game.gz',25153,1,'canonical24k-serial')]:
 dest=out/('macos-'+name)
 cmd=[str(binary),'game','run','--load-game',str(inputs/save),'--compute-threads',str(threads),'--gpu','off','--ticks',str(ticks),'--telemetry','checksums','--save','final','--output-dir',str(dest)]
 commands.append(cmd);print(name,flush=True)
 if not (dest/'result.json').exists():
  with (out/('macos-'+name+'.log')).open('w') as f:subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
 checks={}
 for n in ['world.checksums','snapshot.checksums']:
  a=(p/expected/n).read_bytes();b=(dest/n).read_bytes();checks[n]={'identical':a==b,'rows':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest()}
 a=gzip.decompress((p/expected/'final.game.gz').read_bytes());b=gzip.decompress((dest/'final.game.gz').read_bytes());checks['save']={'identical':a==b,'sha256':hashlib.sha256(b).hexdigest()}
 assert all(x['identical'] for x in checks.values()),(name,checks)
 for f in dest.glob('*.replay.checksums'):
  checks['sidecar']={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size};f.unlink()
 results[name]=checks
 (out/'macos-behavior.json').write_text(json.dumps(results,indent=2))
(out/'macos-commands.json').write_text(json.dumps(commands,indent=2))
print('MACOS BEHAVIOR MATCHES',flush=True)
