from pathlib import Path
import subprocess,json,shlex,os,hashlib
p=Path(__file__).resolve().parent;out=p/'mac-regression';out.mkdir(exist_ok=True)
entries=json.load(open('build/darwin/client/release/dev-linker-auto/compile_commands.json'));entry=next(e for e in entries if str(e['file']).endswith('src/ai/nicowar/Attack.cpp'));args=entry.get('arguments') or shlex.split(entry['command']);old=args[args.index('-o')+1];args[args.index('-o')+1]=str(out/'Attack-fixed.o');idx=next(i for i,a in enumerate(args) if a.endswith('src/ai/nicowar/Attack.cpp'));args[idx]=str(p.parents[1]/'src/ai/nicowar/Attack.cpp');args=[a.replace('\\"','"') if a.startswith('-D') else a for a in args];subprocess.run(args,check=True)
link=json.load(open('artifacts/hiring-study/ai-matches/link-command.json'));link=[str(out/'Attack-fixed.o') if a==old else a for a in link];assert str(out/'Attack-fixed.o') in link;link[link.index('-o')+1]=str(out/'glob2-trial-ai-fixed');subprocess.run(link,check=True)
(out/'build-commands.json').write_text(json.dumps({'compile':args,'link':link},indent=2));records=[]
for n in [1,4]:
 dest=out/f'cached-{n}';env=os.environ.copy();env.update(SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='dummy',GLOB2_ISOLATED_LIVE_HIRING='1',GLOB2_ISOLATED_TRACE='1');env.pop('GLOB2_SIM_THREAD',None)
 cmd=['/usr/bin/time','-l',str(out/'glob2-trial-ai-fixed'),'game','run','--map-file',str(p/'river-nicowar-019.map.gz'),'--game-seed','3907061736','--ticks','32768','--benchmark-warmup','0','--compute-threads',str(n),'--gpu','off','--output-dir',str(dest),'--hiring-schedule','4:4:128:combined','--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds','--hiring-execution','pool']
 for _ in range(8):cmd+=['--player','nicowar']
 with (out/f'cached-{n}.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 assert r.returncode==0;trace=(dest/'world.checksums').read_bytes();result=json.load(open(dest/'result.json'));assert len(trace.splitlines())==result['ticks']==32768
 records.append({'participants':n,'ticks':result['ticks'],'trace_sha256':hashlib.sha256(trace).hexdigest(),'command':cmd})
assert all(r['trace_sha256']=='065037267cec018b0d345a6d04175f282973e9fae04bfddb02e5dcc5a062d6e8' for r in records)
(out/'verification.json').write_text(json.dumps({'passed':True,'scope':'Isolated corrected material-consumer regression with only Attack.cpp replaced over prior release objects; not clean production build. Matching failing-input traces macOSarm64/Linuxx86-64 for1/4participants. Mac address-space limit not applied.','source_sha256':hashlib.sha256((p.parents[1]/'src/ai/nicowar/Attack.cpp').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((out/'glob2-trial-ai-fixed').read_bytes()).hexdigest(),'runs':records},indent=2));print('Mac/Linux failing-seed traces match',flush=True)
