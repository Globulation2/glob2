from pathlib import Path
import subprocess,json,csv,hashlib
c=Path('/home/bradley/glob2/artifacts/gradient-reconciliation');out=c/'production-fix/quality';out.mkdir(parents=True,exist_ok=True);root=Path('/home/bradley/glob2-gradient-final-512-validation');save=c/'controlled/8v8-master-checkpoint/final.game.gz';summary={}
for name,b in [('before',c/'bin/final512'),('fixed',root/'build/final-pr-release/src/glob2')]:
 d=out/name;d.mkdir(exist_ok=True);cmd=[str(b),'game','run','--load-game',str(save),'--ticks','38912','--compute-threads','1','--gpu','off','--compute-telemetry','off','--benchmark-warmup','4096','--resource-gradient-probe','--output-dir',str(d)];(d/'command.json').write_text(json.dumps(cmd,indent=2))
 with (d/'run.log').open('w') as f:subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
 r=json.loads((d/'result.json').read_text());q=[x for x in csv.DictReader((d/'gradient-quality.csv').open()) if int(x['tick'])>=36864];metrics=['extra_cost','flagged','false_unreachable','false_reachable'];summary[name]={'source':'df25376f8' if name=='before' else '2bb153e24','binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'ticks':r['ticks'],'finalChecksum':r['finalChecksum'],'gradient_jobs':r['gradient_jobs'],'sampled_queries':len(q),'mean':{m:sum(int(x[m]) for x in q)/len(q) for m in metrics}}
 print(name,summary[name],flush=True)
reference=json.loads((c/'no-cap/8v8-warm4096-capped/result.json').read_text());assert summary['fixed']['finalChecksum']==reference['finalChecksum'] and summary['fixed']['gradient_jobs']==reference['gradient_jobs'],'production differs from research negative-only control'
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
