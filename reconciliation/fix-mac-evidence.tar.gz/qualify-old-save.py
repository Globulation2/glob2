from pathlib import Path
import subprocess,json,sys,hashlib
root,out,source=map(Path,sys.argv[1:]);out.mkdir(parents=True,exist_ok=True);binary=root/'build/final-pr-release/src/glob2';report={}
for name,initial,ticks in [('released173',source,1024),('resaved174',out/'released173/final.game.gz',1280)]:
 d=out/name;d.mkdir(exist_ok=True);cmd=[str(binary),'game','run','--load-game',str(initial),'--ticks',str(ticks),'--compute-threads','1','--gpu','off','--save','final','--telemetry','checksums','--output-dir',str(d)];(d/'command.json').write_text(json.dumps(cmd,indent=2))
 with (d/'run.log').open('w') as f:subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
 report[name]={n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in ['world.checksums','snapshot.checksums','game.replay.checksums']}
(out/'status.json').write_text(json.dumps({'status':'passed','hashes':report},indent=2)+'\n')
