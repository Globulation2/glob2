from pathlib import Path
import subprocess,os,json
c=Path('/home/bradley/glob2/artifacts/gradient-reconciliation');out=c/'production-fix';out.mkdir(exist_ok=True);root=Path('/home/bradley/glob2-gradient-final-512-validation');env=os.environ.copy();env.update(GLOB2_SDL3_PREFIX='/home/bradley/glob2/build/sdl3/prefix',PYTHONPATH=str(root))
steps=[('build',['scons','release=1','CXXFLAGS=','--build=build/final-pr-release','-j8','build/final-pr-release/src/glob2','engine-tests']),('focused',['python3','test/run_tests.py','--build-dir','build/final-pr-release','--binary','engine','--filter','DelayedGradientPublication/*','--filter','ResourceGradientPolicy/*','--filter','RuntimeResources/*','--filter','SharedWorkerLifecycle/*','--filter','TurnEngineHarness/*','--filter','HiringPlanner/*','--filter','HiringPipeline/*','--filter','HiringBucket/*','--filter','FetchHiringScore/*','--filter','ResourceFetchTarget/*','--filter','FetchApportionment/*','--jobs','3','--junit',str(out/'focused-linux.xml'),'--artifacts',str(out/'focused-linux')]),('native',['python3',str(c/'qualify-native.py'),str(root),str(out/'native-linux'),'/home/bradley/glob2/artifacts/adaptive-final-512-20261018/final-performance-maps/3ffa/map.map.gz'])]
for name,cmd in steps:
 (out/'status.json').write_text(json.dumps({'phase':name,'command':cmd}));(out/(name+'-command.json')).write_text(json.dumps(cmd,indent=2))
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(f'{name} failed {r.returncode}')
 print(name,'PASS',flush=True)
(out/'status.json').write_text(json.dumps({'phase':'complete','source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()}))
