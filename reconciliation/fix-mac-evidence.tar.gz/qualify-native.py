from pathlib import Path
import subprocess,json,sys,hashlib
root=Path(sys.argv[1]);out=Path(sys.argv[2]);mapfile=Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True);binary=root/'build/final-pr-release/src/glob2'
for name,threads,probe in [('one',1,False),('four',4,False),('probe',1,True)]:
 d=out/name;cmd=[str(binary),'game','run','--map-file',str(mapfile),'--game-seed','859231393']
 for _ in range(3):cmd+=['--player','warrush']
 cmd+=['--ticks','4096','--compute-threads',str(threads),'--gpu','off','--telemetry','checksums','--save','every:512','--output-dir',str(d)]
 if probe:cmd+=['--resource-gradient-probe']
 d.mkdir(exist_ok=True);(d/'command.json').write_text(json.dumps(cmd,indent=2))
 with (d/'run.log').open('w') as f:subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
for f in ['world.checksums','snapshot.checksums','game.replay.checksums']:
 assert (out/'one'/f).read_bytes()==(out/'four'/f).read_bytes()==(out/'probe'/f).read_bytes(),f
for name,source,threads in [('control174',out/'one/checkpoint-512.game.gz',1),('resume174',out/'one/checkpoint-2048.game.gz',4)]:
 d=out/name;d.mkdir(exist_ok=True);cmd=[str(binary),'game','run','--load-game',str(source),'--ticks','4096','--compute-threads',str(threads),'--gpu','off','--telemetry','checksums','--save','final','--output-dir',str(d)];(d/'command.json').write_text(json.dumps(cmd,indent=2))
 with (d/'run.log').open('w') as f:subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
for f in ['world.checksums','snapshot.checksums']:
 def rows(p):return {int(l.split()[0]):l for l in p.read_text().splitlines()}
 a,b=rows(out/'control174'/f),rows(out/'resume174'/f);ov=set(a)&set(b);assert len(ov)>=2048 and all(a[t]==b[t] for t in ov),(f,'resume')
report={'status':'passed','source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'one_four_probe':{f:hashlib.sha256((out/'one'/f).read_bytes()).hexdigest() for f in ['world.checksums','snapshot.checksums','game.replay.checksums']},'save_resume':'2048plus overlapping raw world/snapshot checksums exact, matched174headers'};(out/'status.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
