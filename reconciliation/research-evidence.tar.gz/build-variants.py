from pathlib import Path
import os,subprocess,json,time,hashlib
c=Path('/home/bradley/glob2/artifacts/gradient-reconciliation');root=Path('/home/bradley/glob2-gradient-reconciliation')
while json.loads((c/'reproduction/status.json').read_text()).get('phase')!='complete':time.sleep(5)
env=os.environ.copy();env.update(GLOB2_SDL3_PREFIX='/home/bradley/glob2/build/sdl3/prefix',PYTHONPATH=str(root))
for name,rev in [('master','3d896cbb95293da6d24caddd247a62c9ca99d77f'),('oldmodel','df25376f8b681dcd8d87dd6832b4e93a935cad96')]:
 subprocess.run(['git','checkout','--detach',rev],cwd=root,check=True)
 if name=='oldmodel':
  h=subprocess.check_output(['git','show','4d16ada10:src/map/gradient/ResourceGradientModel.h'],cwd=root);(root/'src/map/gradient/ResourceGradientModel.h').write_bytes(h)
 cmd=['scons','release=1','CXXFLAGS=','--build=build/final-pr-release','-j8','build/final-pr-release/src/glob2'];(c/'build-status.json').write_text(json.dumps({'active':name,'command':cmd}))
 with (c/f'build-{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(f'build{name}failed{p.returncode}')
 b=(root/'build/final-pr-release/src/glob2').read_bytes();(c/'bin'/name).write_bytes(b);(c/'bin'/name).chmod(0o755);(c/f'binary-{name}.json').write_text(json.dumps({'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'patch':subprocess.check_output(['git','diff'],cwd=root,text=True)}))
 if name=='oldmodel':subprocess.run(['git','restore','src/map/gradient/ResourceGradientModel.h'],cwd=root,check=True)
(c/'build-status.json').write_text(json.dumps({'phase':'complete'}))
