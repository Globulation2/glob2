# Adaptive-gradient reconciliation — working evidence

Production PR remains unchanged and draft. This investigation follows the user's request for a firm causal explanation; do not treat candidate ablations as accepted fixes.

Confirmed:
- Historical dashboard gains reproduce on preserved engine/binary: old River4FFA rotation .3258→A32 .2378 ms/tick at1thread, .4530→.3219 at8threads; ticks28514→24194; counted periodic jobs28513→8088. River4v4 likewise1thread1.5188→1.1333ms/tick,8threads1.9793→1.4269.
- Current Mac River bridge (same master173generated mapbytes, seed2002,4Nicowar): two counterbalanced repetitions master .1434/.1346→A32 .1536/.1568ms/tick; ticks24450→33218; jobs24447→36119. Host differs from preserved reproduction, so do not compare absolute cross-host timings.
- Final production scheduler removed naturalground roundrobin turns; historical prototype consumed rejected turns as idle observations. Remaining periodic families can backfill. Source fact; quantitative causal share pending instrumented controls.
- Seven same-row feature values give newmodel selection subset of old across476107episodes; selection1.155%→.523%. Does not rule out collector semantic/population drift.
- Label window changed +7..31→+8..31. Collector lacks never-movement distance-onlyfields; final scalar recruitment demand introduces such refreshes.
- Sharedformat164 River commonancestor map generated from unchanged generator/serializer of preserved commonbase hiring-only experiment binary; both oldprototype andfinal preflightloadPASS. Exactgeneration provenance underremotecommon-base-map. Not pristine commonbase runtimebinary.

Owned processes:
Remote root buildqueue3608959(master completed,oldmodel building), researchcheckout/home/bradley/glob2-gradient-reconciliation. Agentpolicy_code_audit exclusively owns successorbuilds/timings/variant mutations; do not start competingLinuxCPUwork. Remoteartifact/home/bradley/glob2/artifacts/gradient-reconciliation, controlled/run-controlled.py. Master/final immutablebinaries. Agent will comparecommonmapoldrotation/fixed32/A32/currentmaster/final/newoldcoeff/fixed32/turnpreservation/nodistance/noreactive and classifyjobs, plus1024tick continuation ofsame master1738v8checkpoint.

Local audits: historical-findings.md,baseline-architecture.md,code/audit.md,model-data/README.md,final-data/README.md. No production changes or new PR performance claims until controlled results and independent review.
