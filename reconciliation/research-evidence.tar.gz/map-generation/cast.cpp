// Isolated reproduction of HeightMap::makeRiver coordinate conversion.
// Compile on both hosts: c++ -O3 river-negative-coordinate-cast.cpp -o river-cast
// Additional diagnostic: -fsanitize=float-cast-overflow
#include <cstdio>
int main() {
  volatile float source=-87.5f;
  const float reachedPointY=source;
  const unsigned direct=static_cast<unsigned>(reachedPointY);
  const unsigned intendedWrap=static_cast<unsigned>(static_cast<int>(reachedPointY));
  std::printf("coordinate=%.2f direct=%u direct-mod128=%u signed-then-wrap=%u wrapped-mod128=%u\n",reachedPointY,direct,direct%128,intendedWrap,intendedWrap%128);
}
