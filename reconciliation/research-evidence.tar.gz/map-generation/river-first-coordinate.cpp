// Isolates GenerationContext::deriveSeed and HeightMap::makeRiver at t=0.
// Matches constructor external rng consumption: _pn(rng()), then X,Y,direction.
#include <random>
#include <cstdint>
#include <cmath>
#include <cstdio>
std::uint32_t derive(std::uint32_t seed,const char* name) {
 std::uint32_t h=2166136261u^seed;
 for(;*name;++name){h^=static_cast<unsigned char>(*name);h*=16777619u;}
 h^=h>>16;h*=0x7feb352du;h^=h>>15;h*=0x846ca68bu;h^=h>>16;return h;
}
int main() {
 std::mt19937 rng(derive(385001,"heightmap"));
 const auto noiseSeed=rng();
 const float startX=int(rng()&0x7fffffffu)%128;
 const float startY=int(rng()&0x7fffffffu)%128;
 const unsigned choice=int(rng()&0x7fffffffu)%3;
 const float targetX=startX+(choice>0?128:0);
 const float targetY=startY+128-(choice%2)*128;
 const float angle=std::asin((targetY-startY)/std::sqrt(std::pow(targetX-startX,2)+std::pow(targetY-startY,2)));
 const float dirX=std::cos(double(angle));
 const float dirY=std::sin(double(angle));
 // Noise(0)=0, so makeRiver's winding t=0 expression yields offset=-350.
 volatile float offset=-350.f;
 volatile float x=-dirY*offset/4;
 volatile float y=dirX*offset/4;
 std::printf("seed=385001 namedSeed=%u noiseSeed=%u start=(%.0f,%.0f) directionChoice=%u dir=(%.9g,%.9g) first=(%.9g,%.9g) firstUnsigned=(%u,%u)\n",derive(385001,"heightmap"),unsigned(noiseSeed),startX,startY,choice,dirX,dirY,float(x),float(y),unsigned(x),unsigned(y));
}
