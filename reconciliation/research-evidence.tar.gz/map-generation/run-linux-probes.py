from pathlib import Path
import subprocess,json,time
C=Path('/home/bradley/glob2/artifacts/gradient-reconciliation');A=C/'map-generation';A.mkdir(exist_ok=True)
while True:
 status=json.loads((C/'controlled/status.json').read_text())
 if status['phase'] in ('build','complete'):break
 time.sleep(.5)
out=[]
for source in ['cast.cpp','river-first-coordinate.cpp']:
 for variant,flags in [('ordinary',[]),('ubsan',['-fsanitize=float-cast-overflow'])]:
  exe=A/(source.removesuffix('.cpp')+'-linux-'+variant);cmd=['g++','-O3',*flags,str(C/source),'-o',str(exe)];b=subprocess.run(cmd,capture_output=True,text=True);assert b.returncode==0,b.stderr;r=subprocess.run([str(exe)],capture_output=True,text=True);out.append(dict(source=source,variant=variant,build_command=cmd,command=[str(exe)],exit=r.returncode,stdout=r.stdout,stderr=r.stderr));(A/(source.removesuffix('.cpp')+'-linux-'+variant+'.log')).write_text(r.stdout+r.stderr)
result=dict(status_before=status,status_after=json.loads((C/'controlled/status.json').read_text()),platform=subprocess.check_output(['uname','-sm'],text=True),compiler=subprocess.check_output(['g++','--version'],text=True),runs=out)
(A/'linux-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(out,indent=2))
