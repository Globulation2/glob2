# Controlled experiment handoff

All owned Linux research campaigns completed. No owned game, compiler, profiler, watcher, paused process group or runner remains active. The isolated root builder group3608959 was resumed after the fast bridge and subsequently exited normally.

Completed status paths on devlaptop.local:
- /home/bradley/glob2/artifacts/gradient-reconciliation/controlled/status.json:32runs.
- /home/bradley/glob2/artifacts/gradient-reconciliation/negative-followup/status.json:15runs.
- /home/bradley/glob2/artifacts/gradient-reconciliation/no-cap/status.json:8runs.
- bridge-fast/status.json:5immutable-binary controls.

Linux CPU/build ownership has been released to the parent task, which is validating production SIM81 in /home/bradley/glob2-gradient-final-512-validation. Do not start more experiments/builds while that validation runs. No production cap or round-robin change was made by this research subagent.

Research checkout: /home/bradley/glob2-gradient-reconciliation, base df25376f8. Parent requested the final research state remain inspectable: it is the age-quality-uncapped variant (negative-only scalar enrollment, minimum8 model-only refresh, opt-in age/oracle instrumentation). Its source diff/header hash/binary hash are recorded under no-cap/binary-age-quality-uncapped.json. The checkout is not production. Ordinary compiled objects there may correspond to the research variant; use immutable bin/* paths for reproduction.

All essential dataset JSON/CSV, command files, source patches, build logs and metadata have been copied to /Users/bradley/glob2/artifacts/gradient-reconciliation/{controlled,negative-followup,no-cap,bridge-fast,terrain-current-linux,code}. The binaries remain in remote artifacts/gradient-reconciliation/bin with recorded SHA256. The master173 save is controlled/8v8-master-checkpoint/final.game.gz. No huge compiler caches or repeated full replay checksum vectors were copied.

Primary narrative: code/README.md. Machine-readable analyses: controlled/analysis.json, negative-followup/analysis.json, no-cap/analysis.json. Analyze-no-cap.py is the final age/quality analyzer, including distinct fields/captures for sparse false negatives. No-cap all4 observer/plain pairs pass checksum/ticks/jobs; all12 main and6 follow-up pairs also pass.

Production source/test/documentation/replay gates, source commit, platform checks, evidence publication and PR update are owned by the parent task. The source/model from frozen training remains available separately; this subagent did not change coefficients or retrain.
