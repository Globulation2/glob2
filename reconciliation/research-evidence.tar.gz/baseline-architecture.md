# Baseline architecture bridge: source evidence and limits

## Enrollment and periodic eligibility

None of the three configurations eagerly allocates every team×material×movement-class field at startup. The material getter allocates or requests one key when a caller needs it; AI observation queries can also enroll a locally initialized field. Natural materials proven absent use a shared inert negative field and avoid per-key propagation. Thus number of theoretical keys is not a measured count of active keys.

**Common ancestordd493 / research rotation:** `getMaterialGradientSlot` returns a usable field immediately, allocating a full plane and synchronously seeding/propagating on a cold key. The research fork adds stale-on-unused logic and movement-class eligibility. Its periodic natural loop requires classactive, sourcepresent, fieldnonnull and not-yet-visited; there are eight ground classes and no shared AIR ninth class. The cold construction and consumer-specific cached routes are synchronous and not included in pipeline.metrics.jobs.

**Current master3d896:** ground getters on owner enqueue cold requests and returnnull/Pending; compute workers cannot mutate scheduling or allocate shared fields. Cold and regular warm requests share one deduplicated FIFO admission per observation. Already queued or in-flight destinations coalesce. AIR cold fields still initialize synchronously. Consumer-specific/supplier caches now use delayed complete-field jobs,128tickage,stock/topology invalidation and first-read retention. Master natural periodic eligibility is sourcepresent, fieldnonnull, notvisited, over all9movementclasses; it does NOT have TeamStats class eligibility. Once enrolled, a warm natural field remains periodic even without further demand. AIR remains included in rotation.

**Final adaptivePR:** retains master's cold/cache/Pending semantics, adds8ground-class TeamStats filtering, moves warm natural ground to demand/min8/max128/predictedbenefit scheduling, while AIR remains masterperiodic. It also broadens demand beyond movement to scalar distance/availability reads for recruitment liveness. Ground natural keys no longer occupy dummy round-robin turns; other families backfill those opportunities. This is separate from cold field laziness.

The cold rewrite reduces synchronous bursts, unbounded worker-side cold allocation and redundant pending requests. It also changes when hiring/movement sees a route (Pending followed by fixed publication), so later populations/game lengths can differ. It does not on source evidence already implement demand-based skipping of all warm natural work. It is therefore unsupported to assert that the new baseline already captured most adaptive savings without measurements.

## Existing measurements cannot recover exact enrollment counts

Historical `gradient-metrics.json` retains natural_jobs,total_jobs,depth/lazy/snapshot counters, but no field-key census or per-class counts. `result.json` retains aggregate pipeline/building job totals, not per-key allocation. Quality/study CSVs contain sampled queried keys in rotating windows; unique keys are a lower bound on queried/enrolled fields, not an exhaustive population. A larger map class with zero sampled rows is not proof of no allocation or refresh.

`GradientPipeline::reserve` increments totaljobs; old instrumented `prepare` increments naturalJobs when Kind::Materials. Consequently pipeline job counts exclude old synchronous first builds and cached supply fields, while current deferred supply work may enter the counted pipeline. Do not equate totaljobs across engine generations with total propagations or total compute. Within the same old binary, rotation/A32 pipeline counts remain a meaningful demonstration of its unfilled turns.

To isolate baseline gains, collect on the common164map: allocated unique keys by family/class, currentlyclassactive/pointerpresent counts, coldadmissions, periodicturns, warm natural accepts, otherfamily accepts, and synchronous propagations. Cost each family by processedcells/CPU scope. Same source with old/new admission is necessary to attribute observed CPU savings; finalunit counts alone do not normalize lifetime population.

## Key formulas and actual old rates

At a static eligibility set, old round-robin periodN is the number of enrolled eligible natural+market+guard+clear keys; oldA32 still consumes thoseN visitation turns, suppressing most natural propagations. Other families retain approximately1/N each. Final removes naturalground keys from that visitation set. Ignoring coalescing/FIFOcold demand, remaining otherkeys refresh approximately1/Nother, potentially much faster when Nnatural is large. This is the source of the phantom-turn/backfill hypothesis.

On old first-sweep river1284ffa, rotation28,513pipelinejobs over28,514ticks includes20,906natural and7,607other. A32 has8,088over24,194ticks, including1,363natural and6,725other. Natural rate falls.7332→.0563/tick while other rate stays.2668→.2780/tick. The integratedscheduler can instead fill close to1otherjob/tick in steady state; if propagationweights are similar, this alone can replace more work than was saved. Actualfinalfamilymix must determine the cost.
