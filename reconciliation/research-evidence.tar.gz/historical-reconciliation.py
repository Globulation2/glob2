import json,collections,statistics,math
from pathlib import Path
A=Path('/Users/bradley/glob2/artifacts');D=json.loads((A/'gradient-live/data.json').read_text());F=json.loads((A/'gradient-training-1024/final-performance/summary.json').read_text());T={(r['seed'],r['case']):r for r in D['timing']};Q={(r['seed'],r['case']):r for r in D['quality']};C=D['plan']['cases']
complete=[s for s in D['plan']['states'] if all((s['seed'],c) in T and Q.get((s['seed'],c),{}).get('queries',0)>0 for c in C)]
rows=[]
for s in D['plan']['states']:
 if (s['seed'],'rotation') in T and (s['seed'],'refit-32000') in T:
  a=T[s['seed'],'refit-32000'];b=T[s['seed'],'rotation'];rows.append(dict(s,adaptive=a,rotation=b,cpu_change_pct=100*(a['cpu']/b['cpu']-1),eligible_all_policies=s in complete))
def aggregation(rr):
 ratios=[r['adaptive']['cpu']/r['rotation']['cpu']for r in rr]
 pool={p:sum(r[p]['cpu']*r[p]['ticks']for r in rr)/sum(r[p]['ticks']for r in rr)for p in ['adaptive','rotation']}
 return dict(arithmetic_pair_pct=100*(statistics.mean(ratios)-1),geometric_pair_pct=100*(math.prod(ratios)**(1/len(ratios))-1),pooled_cpu_per_tick_pct=100*(pool['adaptive']/pool['rotation']-1))
old={}
for c in ['rotation','demand32','refit-32000']:
 groups=collections.defaultdict(list)
 for s in complete:
  r=T[s['seed'],c];b=T[s['seed'],'rotation'];q=Q[s['seed'],c]
  groups[s['id']].append(dict(cpu_change_pct=100*(r['cpu']/b['cpu']-1),extra_per_query=q['extra'],refreshes_per_tick=r['refreshes'],cpu_ms_per_tick=r['cpu']))
 old[c]={k:statistics.mean(statistics.mean(x[k]for x in v)for v in groups.values())for k in next(iter(groups.values()))[0]}
fc=sum(r['adaptive32']['simulation_cpu_seconds']-r['master']['simulation_cpu_seconds']for r in F['formats'])
contrib=[dict(format=r['format'],cpu_excess_seconds=r['adaptive32']['simulation_cpu_seconds']-r['master']['simulation_cpu_seconds'],excess_share_pct=100*(r['adaptive32']['simulation_cpu_seconds']-r['master']['simulation_cpu_seconds'])/fc)for r in F['formats']]
out=dict(historical_source='gradient-live/data.json',historical_common_count=len(complete),historical_timing_count=len(D['timing']),historical_quality_count=len(D['quality']),historical_equal_format_common=old,historical_all8_pair_aggregation=aggregation(rows),historical_pairs=rows,final_equal_format_arithmetic_pct=statistics.mean(r['cpu_ms_per_tick_change_pct']for r in F['formats']),final_equal_format_geometric_pct=F['equal_format_geometric_mean_cpu_per_tick_change_pct'],final_pooled_pct=F['pooled_change_pct'],final_cpu_excess_contributions=contrib)
(A/'gradient-reconciliation/historical-reconciliation.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items()if k!='historical_pairs'},indent=2))
