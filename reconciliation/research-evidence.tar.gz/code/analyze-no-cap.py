from pathlib import Path
from collections import Counter,defaultdict
import json,csv,sys
root=Path(sys.argv[1]);rows=json.loads((root/'manifest.json').read_text());by={r['key']:r for r in rows};out={'runs':[],'equivalence':[],'age_histogram_definition':'Exact serving capture age in ticks, weighted by individual movement/planning reads or warm natural refresh admissions. Bins0..131071 exact,131072 overflow; max is exact separately. Unknown capture epochs excluded and counted.','quality_note':'Movement oracle uses permanent deterministic sampled-field/window collector. Scalar oracle samples1/8keys, first scalar read per field at deterministic128tick boundaries; percentages describe these samples, not all recruitment queries.'}
labels=['movement','positive_planning','negative_planning','warm_refresh']
def summary(hist,maxvalue=None):
 total=sum(hist.values())
 def q(p):
  if not total:return None
  target=max(1,__import__('math').ceil(p*total));running=0
  for age,count in sorted(hist.items()):
   running+=count
   if running>=target:return age
 return {'count':total,'p50':q(.5),'p90':q(.9),'p99':q(.99),'max':maxvalue if maxvalue is not None else (max(hist) if hist else None),'age_fraction':{str(t):sum(n for a,n in hist.items() if a>=t)/total if total else None for t in [128,256,512,1024,4096,8192]},'overflow':hist.get(131072,0)}
for r in rows:
 d=root/r['key'];result=r['result'];cmd=json.load(open(d/'command.json'))['command'];warm=int(cmd[cmd.index('--benchmark-warmup')+1]);n=result['benchmark_measured_ticks'];s={'key':r['key'],'final_ticks':result['ticks'],'measured_ticks':n,'sim_cpu_ms_tick':result['benchmark_run_cpu_ns']/n/1e6,'process_cpu_s':r['process_cpu_s'],'wall_s':r['wall_s'],'gradient_jobs_whole_prefix':result['gradient_jobs'],'executed_ticks':n+warm,'jobs_per_executed_tick':result['gradient_jobs']/(n+warm),'finalChecksum':result['finalChecksum']}
 if (d/'audit.json').exists():
  audit=json.load(open(d/'audit.json'));hist=defaultdict(Counter)
  for row in csv.DictReader(open(d/'audit.json.ages.csv')):hist[int(row['histogram'])][int(row['age'])]+=int(row['count'])
  s['ages']={}
  fields=list(csv.DictReader(open(d/'audit.json.field-ages.csv')))
  for i,label in enumerate(labels):
   all=hist[i*2];changed=hist[i*2+1];unchanged={age:count-changed.get(age,0) for age,count in all.items() if count-changed.get(age,0)}
   s['ages'][label]={'all':summary(all,audit['age_max'][i*2]),'sources_changed':summary(changed,audit['age_max'][i*2+1]),'sources_unchanged':summary(unchanged),'unknown_reads':audit['age_unknown'][i],'fields_queried':sum(int(f['reader'])==i for f in fields),'fields_with_old_read':{str(t):sum(int(f['reader'])==i and int(f['max_age'])>=t for f in fields) for t in [128,512,4096]}}
  start=0 if r['key'].startswith('river') else 36864
  # Each permanent probe row is one actual sampled movement decision.
  qrows=[q for q in csv.DictReader(open(d/'gradient-quality.csv')) if int(q['tick'])>=start]
  nquery=len(qrows);metrics=['extra_cost','false_unreachable','false_reachable','depleted_goal','missed_move','unreachable_step','left_fresh_goal','flagged'];s['movement_quality']={'queries':nquery,'sum':{k:sum(int(q[k]) for q in qrows) for k in metrics},'mean':{k:sum(int(q[k]) for q in qrows)/nquery if nquery else None for k in metrics}}
  oq=list(csv.DictReader(open(d/'audit.json.planning-oracle.csv'))) if (d/'audit.json.planning-oracle.csv').exists() else []
  falseNegative=sum(int(q['old_value'])<=1<int(q['fresh_value']) for q in oq);falsePositive=sum(int(q['fresh_value'])<=1<int(q['old_value']) for q in oq);negative=sum(int(q['old_value'])<=1 for q in oq)
  s['planning_quality']={'samples':len(oq),'old_negative_samples':negative,'false_unreachable':falseNegative,'false_unreachable_distinct_fields':len({q['key'] for q in oq if int(q['old_value'])<=1<int(q['fresh_value'])}),'false_unreachable_distinct_captures':len({(q['key'],int(q['tick'])-int(q['age'])) for q in oq if int(q['old_value'])<=1<int(q['fresh_value'])}),'false_reachable':falsePositive,'false_unreachable_among_old_negative':falseNegative/negative if negative else None,'false_reachable_among_old_positive':falsePositive/(len(oq)-negative) if len(oq)>negative else None,'false_unreachable_ages':summary(Counter(int(q['age']) for q in oq if int(q['old_value'])<=1<int(q['fresh_value'])))}
 out['runs'].append(s)
for scenario in ['river164','8v8-warm4096']:
 for policy in ['capped','uncapped']:
  a,b=by.get(scenario+'-'+policy),by.get(scenario+'-age-quality-'+policy)
  if a and b:out['equivalence'].append({'pair':[a['key'],b['key']],'same_ticks':a['result']['ticks']==b['result']['ticks'],'same_checksum':a['result']['finalChecksum']==b['result']['finalChecksum'],'same_jobs':a['result']['gradient_jobs']==b['result']['gradient_jobs']})
(root/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for r in out['runs']:
 print(r['key'],r['final_ticks'],round(r['sim_cpu_ms_tick'],4),r['gradient_jobs_whole_prefix'])
 for label,s in r.get('ages',{}).items():print(' ',label,s['all'],'unknown',s['unknown_reads'])
 if 'movement_quality' in r:print(' movement',r['movement_quality']);print(' planning',r['planning_quality'])
print('Equivalence',out['equivalence'])
