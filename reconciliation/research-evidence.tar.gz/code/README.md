# Adaptive-gradient reconciliation: controlled experiments

The earlier research gain reproduces. The final implementation was a different scheduling policy around the model, and two integration changes consume substantial CPU. The model's own evaluation cost is small. Removing its128-tick demand cap is not an acceptable shortcut with the current model: it saves CPU but permits long-lived wrong planning answers and worse movement decisions.

## Reproduction and source boundaries

Research source: frozen final PRdf25376f8b681dcd8d87dd6832b4e93a935cad96; baseline master3d896cbb95293da6d24caddd247a62c9ca99d77f; historical prototyped860c600ae1c84c90d644907650cfae0a596272d. Historical refit coefficients exactly match4d16ada10's ResourceGradientModel.h. All final-model controls use the512-game coefficients, including the no-cap test.

Every runtime comparison uses ordinary release=1, CXXFLAGS empty (normalO3), one compute participant, GPUoff and compute telemetryoff. There are no concurrent campaign builds/timing runs. Recorded commands include the binary hash, overrides, map/save paths and seeds. Binary metadata includes source diff, base revision, build command and research-header hash. Source/header generators in this directory reconstruct the untracked instrumentation header omitted by git diff.

All changes are diagnostic variants in the isolated Linux research checkout. The shipping scalar fix, simulation gates, tests and PR updates belong to the parent task. These research changes were not applied to production. Timing runs omit both the private audit and the permanent quality probe. Separate diagnostic runs observe identical simulation decisions; all22 diagnostic/plain comparisons across the campaigns matched final ticks, final checksum and gradient-job count.

## Inputs and campaign inventory

* `bridge-fast/`: five immutable-binary runs on exactly the same River164 map, with the builder's entire isolated process group paused and subsequently resumed.
* `controlled/`:32 runs covering current/historical rotation, fixed32, A32, model-only swaps, three scheduler controls and their audited counterparts. Includes the master173 8v8 save.
* `negative-followup/`:15 runs, including2048-tick warmup and1024 measured ticks, negative-only scalar demand, and audit windows restricted to the measured interval.
* `no-cap/`:8 runs, capped-negative-only versus uncapped-negative-only, both with clean runtime measurements and separate age/fresh-reference observations.
* `terrain-current-linux/`: categorical terrain export comparisons.

River uses map seed385001, game seed2002,128×128, four Nicowar players with separate alliances. The common164 container is readable by all compared binaries; its categorical terrain matches historical169 and current Linux-generated173.

The8v8 state is the final comparison's City States512×256 map,16 Cabino players, game seed892606048. A current-master save at32768 provides identical starting bytes. Short suffix runs end at33792. The settled follow-up warms2048 ticks then measures34816–35840. The no-cap comparison warms4096 ticks then measures36864–38912; its fresh movement-probe window is36864–37888. The command files and shared-checkpoint.json contain exact inputs and hashes.

Native gradient_jobs counts the entire executed suffix including warmup; it must not be divided by only the measured CPU ticks. Audited admission counters in negative-followup cover only the1024-tick measured window. The no-cap age and oracle records cover the2048-tick measured window. CPU per tick uses benchmark_run_cpu_ns / benchmark_measured_ticks; process CPU and wall time are separately recorded.

## What caused the apparent reversal

### Other gradient families backfill removed resource turns

The research prototype marked natural-resource round-robin turns visited without actually rebuilding them when adaptive refresh was enabled. Final code removed these visits entirely. Guard/clear refreshes consequently occupy many of the vacated turns.

On the full common River game, final guard/clear periodic admissions were11175/14918; restoring the skipped resource visits reduced them to2842/4093. Combined guard/clear seed+propagation scope time fell2.261s→0.727s. Natural seed+propagation remained essentially constant,0.556s→0.557s. This is a concrete work ledger, not an inference from CPU alone. The ordinary release CPU/tick changed0.2912→0.2558ms, with game lengths28738→27394 ticks.

This mechanism did not explain the late8v8 regression: preserved turns left its total work almost unchanged because other queued requests filled the FIFO opportunity. It therefore cannot be the sole explanation across all maps.

### Reachable recruitment answers created a new refresh workload

Final review added scalar distance-query demand to prevent stale negative recruitment answers persisting indefinitely. It enrolled both reachable and unreachable answers. This expanded demand far beyond movement queries, triggering the age cap on many fields with no recent movement.

The steady1024-tick8v8 audit observed586291 scalar enrollments:582427 reachable and3864 unreachable, versus9883 movement queries. There were967 actual cap admissions and13 actual model admissions. The much larger capAccepted counter is an attempted decision count and must not be described as rebuilt fields.

Restricting enrollment to negative answers retained the liveness path and reduced natural admissions1046→637 in that same measured window. Natural seed+propagation dropped1.032s→0.615s. Other families were nearly unchanged. The diagnostic measured CPU reduction was about0.461s, of which0.417s is explained directly by this natural rebuild scope. Policy-loop time was only0.041s before the change.

The model alone is not responsible: swapping yesterday's coefficients into final source left the late8v8 CPU regression nearly unchanged. In actual final-model accepted records, the independent data audit found no new-model-only threshold crossings in the examined River/8v8 samples. The frozen training collector also predates broad scalar demand and samples recently moved-on fields; q128=0 was only432/476107 complete training episodes, whereas zero-movement cap admissions are common at runtime. These percentages use different observation units and are not a statistical prevalence ratio.

### Same seeds did not imply the same map across architectures

Linux current173, common164 and historical169 categorical RGB SHA256 all equal8bd87d680f3b44fa0dc098422cdda1cc57e66ba89466de218a110f1a907cf5b5. Mac current173 differs:0e495a11ff804691e50bd8bb5bab2bf3f7d86bc0e6ffe5a980c2805d7b6d0c7c. Water/algae cells are5669 on Linux versus5433 on Mac. Thus comparisons using regenerated same-seed maps across platforms used different terrain. The common-file controls eliminate this confound; they do not establish the root cause of the generator difference, which the separate historical audit investigates.

## Representative clean CPU results

Values are ms per measured simulation tick. These are one-state controls, not a replacement for a varied performance tournament.

| Policy | Common River full game |8v8 after2048 warmup |
|---|---:|---:|
| Current master |0.3013 |6.3515 |
| Final A32 |0.2912 |7.3203 |
| Final source, yesterday model |0.2782 |7.3009 |
| A32, restored skipped resource turns |0.2558 |7.3718 |
| A32, no scalar demand (diagnostic liveness risk) |0.2393 |6.7661 |
| A32, negative-only scalar demand |0.2784 |6.7627 |
| Negative-only plus restored turns |0.2079 |6.9449 |

The historical common-file bridge reproduces the earlier result: rotation0.3487, fixed320.2808, A320.2480ms/tick. Final source fixed32 was0.3270ms/tick on River and9.3862ms/tick in the original1024-tick8v8 suffix versus A320.2912 and7.2215 respectively. Fixed32 means demanded warm natural fields at32 ticks; cold/reactive FIFO requests still bypass that cadence. Its fresh pathfinding quality was not measured in this new control campaign, so CPU results do not establish dominance.

Do not compare all entries as if populations and game lengths were fixed: policy changes alter trajectories. In particular, fixed32+preserved-turns River lasted77090 ticks. Kernel ledgers, shared-save prefixes, observer equivalence and repeated baseline checks establish mechanisms more strongly than whole-game CPU differences alone. Timing phases also showed several-percent absolute drift, and the campaign was serial but not a fully counterbalanced repeated statistical design.

## Removing the128-tick cap

Both policies below already use negative-only scalar enrollment. Uncapped retains minimum8-tick spacing and requires a model score>=32000 at every warm admission; there is no age override. Reactive FIFO remains unchanged.

| Scenario | Capped CPU ms/tick | Uncapped CPU ms/tick | Capped→uncapped ticks |
|---|---:|---:|---|
| River full game |0.3025 |0.2435 |25154→20322 |
|8v8,4096 warmup then2048 measured |7.0716 |6.8325 |Same32768→38912 continuation |

The River CPU result includes changed game outcome/length.8v8 clean CPU/tick improves about3.4%, while whole-prefix jobs fall9406→6329. This saving has a substantial quality cost.

Ages below are weighted by individual reads, in ticks. The128 cap limits demanded submission spacing; it is not an absolute maximum age for a formerly idle field's first new read, so occasional capped tails can be much older.

| Scenario / reader | Policy |p50 |p90 |p99 |max |
|---|---|---:|---:|---:|---:|
| River movement | Capped |64 |124 |173 |11936 |
| River movement | Uncapped |74 |451 |4560 |13461 |
| River negative planning | Capped |67 |129 |984 |7363 |
| River negative planning | Uncapped |1762 |15832 |17587 |17953 |
|8v8 movement | Capped |79 |163 |269 |5872 |
|8v8 movement | Uncapped |156 |3693 |5689 |6118 |
|8v8 negative planning | Capped |79 |177 |1508 |5607 |
|8v8 negative planning | Uncapped |1608 |4768 |5829 |6077 |

All River ages are known. Uncapped8v8 has57 unknown movement ages out of19474 reads(~0.29%),1556 unknown positive-planning ages(~0.13%) and no unknown negative-planning ages. Unknown capture epochs from the pre-adaptive save are excluded rather than assigned invented ages. Source-changed/unchanged histograms and distinct queried-field counts are in no-cap/analysis.json and the age CSVs. Unchanged resource-source epochs do not prove route validity: occupancy, visibility or area changes can still change a fresh answer.

| Fresh movement comparison | Capped | Uncapped |
|---|---:|---:|
| River sampled queries |615 |164 |
| River extra cost/query |0.328 |0.220 |
| River flagged decisions |5.20% |4.88% |
|8v8 sampled queries |879 |848 |
|8v8 extra cost/query |1.736 |4.390 |
|8v8 flagged decisions |14.90% |35.73% |
|8v8 false-reachable decisions |5 |50 |

The apparently improved River movement score is not evidence that no-cap is safe: a unit denied recruitment by a stale negative answer may generate no movement query and disappear from this metric.

The sparse private planning oracle catches that blindspot. On River it found0 false-unreachable answers among17 sampled old-negative answers capped, versus15/30 uncapped. The15 observations span two fields and ten captured generations, not15 independent games. Their stale ages have median491 and maximum2926.8v8 has only three sampled old-negative answers per policy (1 false capped,2 uncapped); that sample is too small for a broad rate claim. These observations nevertheless demonstrate concrete wrong recruitment answers and reinforce the movement deterioration on8v8. The oracle samples1/8field keys at deterministic128-tick boundaries and only the first scalar read for that field/tick; it is not a weighted census of all recruitment queries.

## Limits and conclusion

The paired inputs and invariant job counts show that yesterday's algorithm did not suddenly become expensive to evaluate. Its surrounding scheduler changed, broad scalar demand activated cap-driven work, and some same-seed terrain comparisons differed across platforms. The production negative-only correction directly addresses the unnecessary positive-demand component while retaining negative-answer liveness. Round-robin policy remains a separate measured issue. Keep the128 fallback with this model: the uncapped experiment produces substantially older used fields, worse late movement decisions, and long-lived false negative planning answers.

There are only two initial states in these targeted causal controls, with policy-dependent trajectories, sparse quality oracles and single timing measurements per control (plus repeated bridge baselines). Do not extrapolate these exact CPU percentages to all maps, default multicore gameplay, platforms or future rules. Full output, source diffs, integer inputs, hashes and commands are retained so a larger follow-up can reproduce the mechanisms.
