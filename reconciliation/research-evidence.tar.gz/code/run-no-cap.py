from pathlib import Path
import json,time
C=Path('/home/bradley/glob2/artifacts/gradient-reconciliation')
assert json.loads((C/'negative-followup/status.json').read_text())['phase']=='complete'
prefix=(C/'run-controlled.py').read_text().split('try:\n status(')[0].replace("O=C/'controlled'","O=C/'no-cap'").replace("str(C/'apply-research-instrumentation.py')","str(C/'apply-research-instrumentation-ages.py')")
n={};exec(prefix,n);execute=n['execute'];cmdmap=n['cmdmap'];build=n['build'];status=n['status'];river=n['river'];O=n['O'];R=n['R']
checkpoint=json.loads((C/'controlled/shared-checkpoint.json').read_text())['path']
def suffix(b):return [str(b),'game','run','--load-game',checkpoint,'--ticks','38912','--compute-threads','1','--gpu','off','--compute-telemetry','off','--benchmark-warmup','4096']
try:
 # Two ordinary uninstrumented release policies; diagnostic clocks never stand in for gameplay CPU.
 capped=C/'bin/negative-only'
 uncapped=build('no-cap-negative-only',False,['negative-only-distance','no-cap'])
 for label,b in [('capped',capped),('uncapped',uncapped)]:
  execute('river164-'+label,cmdmap(b,river,2002,['nicowar']*4,[1,2,3,4],90000))
  execute('8v8-warm4096-'+label,suffix(b))
 # Identical decisions with opt-in age/reference observations. Fresh movement
 # oracle is the permanent collector; sparse scalar oracle exposes recruitment blindspots.
 for label,variants in [('capped',['negative-only-distance']),('uncapped',['negative-only-distance','no-cap'])]:
  b=build('age-quality-'+label,True,variants)
  for scenario,cmd,start in [('river164',cmdmap(b,river,2002,['nicowar']*4,[1,2,3,4],90000),0),('8v8-warm4096',suffix(b),36864)]:
   key=scenario+'-age-quality-'+label
   execute(key,cmd+['--resource-gradient-probe'],{'GLOB2_GRADIENT_AUDIT':str(O/key/'audit.json'),'GLOB2_GRADIENT_AUDIT_START_TICK':str(start),'GLOB2_GRADIENT_PLANNING_ORACLE':'1'})
 n['restore']();status('complete')
except Exception as e:
 status('failed',error=repr(e));raise
