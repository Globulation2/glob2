from pathlib import Path
import json,time,subprocess,hashlib
C=Path('/home/bradley/glob2/artifacts/gradient-reconciliation');R=Path('/home/bradley/glob2-gradient-reconciliation');O=C/'terrain-current-linux';O.mkdir(exist_ok=True)
while True:
 d=json.loads((C/'controlled/status.json').read_text())
 if d['phase']=='complete':break
 if d['phase']=='failed':raise RuntimeError('Controlled campaign failed; defer terrain until resolved')
 time.sleep(5)
b=C/'bin/master';p=O/'river173.map.gz';commands=[]
def run(cmd):
 commands.append(cmd)
 with (O/'commands.log').open('a') as f:subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
run([str(b),'map','generate','river','--seed','385001','--width','128','--height','128','--teams','4','--output',str(p)])
for label,binary,input in [('linux173',b,p),('common164',b,C/'common-base-map/river164.map.gz'),('old169',Path('/home/bradley/glob2/artifacts/gradient-refit-sweep/glob2-experimental'),Path('/home/bradley/glob2/artifacts/gradient-refit-sweep/maps/2002.map.gz')),('mac173',b,C/'river-current-mac.map.gz')]:
 run([str(binary),'map','export-image',str(input),'--output',str(O/(label+'.png'))])
(O/'manifest.json').write_text(json.dumps({'commands':commands,'files':{str(p.name):hashlib.sha256(p.read_bytes()).hexdigest() for p in O.iterdir() if p.is_file()}},indent=2)+'\n')
print('Terrain export complete',flush=True)
