from pathlib import Path
import os,subprocess,json,time,hashlib,resource,shutil,traceback
C=Path('/home/bradley/glob2/artifacts/gradient-reconciliation');R=Path('/home/bradley/glob2-gradient-reconciliation');O=C/'controlled';O.mkdir(exist_ok=True)
rows=[];phases=[]
def save(path,obj):
 temp=Path(str(path)+'.tmp');temp.write_text(json.dumps(obj,indent=2)+'\n');temp.replace(path)
def status(phase,**kw):save(O/'status.json',dict(phase=phase,time=time.time(),completed=len(rows),**kw));print(phase,kw,flush=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseenv={k:v for k,v in os.environ.items() if not k.startswith('GLOB2_RESOURCE_') and not k.startswith('GLOB2_GRADIENT_AUDIT') and k not in ['GLOB2_EXPERIMENT_GRADIENT_METRICS','GLOB2_EXPERIMENT_RESOURCE_DEMAND8']}
baseenv.update(GLOB2_SDL3_PREFIX='/home/bradley/glob2/build/sdl3/prefix',PYTHONPATH=str(R))
river=C/'common-base-map/river164.map.gz';hist=Path('/home/bradley/glob2/artifacts/gradient-refit-sweep/glob2-experimental')
manifest=json.loads(Path('/home/bradley/glob2/artifacts/adaptive-final-512-20261018/final-performance-maps/manifest.json').read_text());spec=next(x['spec'] for x in manifest if x['format']=='8v8');map8=Path('/home/bradley/glob2/artifacts/adaptive-final-512-20261018/final-performance-maps/8v8/map.map.gz')
def cmdmap(binary,mapfile,seed,ais,alliances,ticks):
 cmd=[str(binary),'game','run','--map-file',str(mapfile),'--game-seed',str(seed)]
 for ai,alliance in zip(ais,alliances):cmd+=['--player',ai,'--alliance',str(alliance)]
 return cmd+['--ticks',str(ticks),'--compute-threads','1','--gpu','off','--compute-telemetry','off','--benchmark-warmup','0']
def execute(key,cmd,env=None):
 d=O/key;d.mkdir(exist_ok=True);cmd=cmd+['--output-dir',str(d)];env=baseenv.copy()|dict(env or {});save(d/'command.json',{'command':cmd,'env':{k:v for k,v in env.items() if k.startswith('GLOB2_')},'binary_sha256':sha(cmd[0])});status('run',active=key)
 start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (d/'run.log').open('w') as f:p=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 after=resource.getrusage(resource.RUSAGE_CHILDREN);r={'key':key,'rc':p.returncode,'wall_s':time.monotonic()-start,'process_cpu_s':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime}
 if p.returncode:raise RuntimeError(f'Run {key} failed {p.returncode}; see {d}/run.log')
 r['result']=json.loads((d/'result.json').read_text())
 if (d/'audit.json').exists():r['audit']=json.loads((d/'audit.json').read_text())
 rows.append(r);save(O/'manifest.json',rows);return r
files=['src/map/MapStep.cpp','src/map/MapResources.cpp','src/map/pathfind/MapPathfindMaterial.cpp','src/map/gradient/MapGradientMaterial.cpp','src/map/gradient/ResourceGradientPolicy.h']
def restore():
 subprocess.run(['git','restore','--']+files,cwd=R,check=True)
def build(name,instrument=False,variants=()):
 restore()
 if instrument:subprocess.run(['python3',str(C/'apply-research-instrumentation.py'),str(R)],check=True)
 for variant in variants:subprocess.run(['python3',str(C/'apply-research-variant.py'),variant,str(R)],check=True)
 cmd=['scons','release=1','CXXFLAGS=','--build=build/final-pr-release','-j8','build/final-pr-release/src/glob2'];status('build',active=name)
 with (O/f'build-{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=R,env=baseenv,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(f'Build {name} failed {p.returncode}')
 b=C/'bin'/name;shutil.copy2(R/'build/final-pr-release/src/glob2',b);save(O/f'binary-{name}.json',{'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'sha256':sha(b),'instrumentation':instrument,'variants':list(variants),'command':cmd,'patch':subprocess.check_output(['git','diff'],cwd=R,text=True),'audit_header_sha256':sha(R/'src/map/gradient/GradientResearchAudit.h') if instrument else None});return b
try:
 status('waiting-for-root-build')
 while json.loads((C/'build-status.json').read_text()).get('phase')!='complete':time.sleep(5)
 assert subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()==''
 for label,binary,env in [('old-rotation',hist,{'GLOB2_RESOURCE_PROBE_LIVE_ONLY':'1'}),('old-fixed32',hist,{'GLOB2_RESOURCE_PROBE_LIVE_ONLY':'1','GLOB2_EXPERIMENT_RESOURCE_DEMAND8':'1','GLOB2_RESOURCE_INTERVAL':'32'}),('old-adaptive32',hist,{'GLOB2_RESOURCE_PROBE_LIVE_ONLY':'1','GLOB2_EXPERIMENT_RESOURCE_DEMAND8':'1','GLOB2_RESOURCE_INTERVAL':'8','GLOB2_RESOURCE_PORTABLE_MODEL':'1','GLOB2_RESOURCE_PORTABLE_THRESHOLD':'32000','GLOB2_RESOURCE_REFIT_MODEL':'1'}),('final512',C/'bin/final512',{}),('master',C/'bin/master',{}),('oldmodel',C/'bin/oldmodel',{})]:
  execute('river164-'+label,cmdmap(binary,river,2002,['nicowar']*4,[1,2,3,4],90000),env)
 # A current-master late checkpoint, identical bytes for all modern controls.
 start=execute('8v8-master-checkpoint',cmdmap(C/'bin/master',map8,spec['game_seed'],spec['ais'],spec['alliances'],32768)+['--save','final'])
 checkpoints=list((O/'8v8-master-checkpoint').rglob('*.game*'));assert len(checkpoints)==1,checkpoints;checkpoint=checkpoints[0];save(O/'shared-checkpoint.json',{'path':str(checkpoint),'sha256':sha(checkpoint),'source':'master3d896','tick':32768,'map_sha256':sha(map8),'spec':spec})
 def suffix(binary):return [str(binary),'game','run','--load-game',str(checkpoint),'--ticks','33792','--compute-threads','1','--gpu','off','--compute-telemetry','off','--benchmark-warmup','0']
 for name in ['master','final512','oldmodel']:execute('8v8-shared-'+name,suffix(C/'bin'/name))
 # Uninstrumented controls first: representative release CPU, no audit branches.
 controls=[('preserve-turns',['preserve-natural-rotation-turns']),('fixed32',['fixed32']),('fixed32-preserve-turns',['fixed32','preserve-natural-rotation-turns']),('no-distance',['no-distance-request']),('no-reactive',['no-reactive-natural-ground-fifo'])]
 for name,variant in controls:
  b=build(name,False,variant);execute('river164-'+name,cmdmap(b,river,2002,['nicowar']*4,[1,2,3,4],90000));execute('8v8-shared-'+name,suffix(b))
 # Counter runs. Their timing is diagnostic only; CPU comparisons above are clean.
 for name,variant in [('instrumented-final',[])]+[('instrumented-'+n,v) for n,v in controls]:
  b=build(name,True,variant)
  execute('river164-'+name,cmdmap(b,river,2002,['nicowar']*4,[1,2,3,4],90000),{'GLOB2_GRADIENT_AUDIT':str(O/('river164-'+name)/'audit.json')})
  execute('8v8-shared-'+name,suffix(b),{'GLOB2_GRADIENT_AUDIT':str(O/('8v8-shared-'+name)/'audit.json')})
 restore();status('complete',runs=len(rows))
except Exception as e:
 status('failed',error=repr(e));traceback.print_exc();raise
