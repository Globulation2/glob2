from pathlib import Path
import json,sys
root=Path(sys.argv[1]);rows=json.loads((root/'manifest.json').read_text());out=[]
for r in rows:
 v=r['result'];n=v.get('benchmark_measured_ticks',v['ticks']);cmd=json.loads((root/r['key']/'command.json').read_text())['command'];warmup=int(cmd[cmd.index('--benchmark-warmup')+1]) if '--benchmark-warmup' in cmd else 0;executed=n+warmup;item={'case':r['key'],'ticks_final':v['ticks'],'measured_ticks':n,'sim_cpu_ms_tick':v.get('benchmark_run_cpu_ns',0)/n/1e6,'process_cpu_s':r['process_cpu_s'],'wall_s':r['wall_s'],'finalChecksum':v.get('finalChecksum'),'gradient_jobs':v.get('gradient_jobs'),'gradient_count_window_ticks':executed,'jobs_per_tick':v.get('gradient_jobs',0)/executed,'note':'CPU/tick uses measured ticks; gradient jobs cover whole executed prefix including warmup'}
 if 'audit' in r:
  a=r['audit'];cats=a['categories'];causes=a['causes'];width=len(causes);item['admissions']={cat:{cause:a['admissions_category_major'][i*width+j] for j,cause in enumerate(causes) if a['admissions_category_major'][i*width+j]} for i,cat in enumerate(cats)};item['timers_wall_ms']={k:a.get(k,0)/1e6 for k in ['stageNs','policyNs','queryNs']};item['seed_wall_ms']={cat:a['seed_wall_ns'][i]/1e6 for i,cat in enumerate(cats)};item['propagate_wall_ms']={cat:a['propagate_wall_ns'][i]/1e6 for i,cat in enumerate(cats)};item['policy']={k:a.get(k) for k in ['capAccepted','modelAccepted','modelRejected','fieldsVisited','modelEvaluations','movementQueries','distanceQueries']}
 out.append(item)
by={r['case']:r for r in out};equivalence=[]
for prefix in ['river164-','8v8-shared-']:
 for name,plain in [('instrumented-final','final512'),('instrumented-preserve-turns','preserve-turns'),('instrumented-fixed32','fixed32'),('instrumented-fixed32-preserve-turns','fixed32-preserve-turns'),('instrumented-no-distance','no-distance'),('instrumented-no-reactive','no-reactive')]:
  if prefix+name in by and prefix+plain in by:
   a,b=by[prefix+name],by[prefix+plain];equivalence.append({'pair':[a['case'],b['case']],'same_ticks':a['ticks_final']==b['ticks_final'],'same_checksum':a['finalChecksum']==b['finalChecksum'],'same_jobs':a['gradient_jobs']==b['gradient_jobs']})
if root.name=='negative-followup':
 external=json.loads((root.parent/'controlled/manifest.json').read_text())
 raw={r['key']:r['result'] for r in rows+external}
 for prefix in ['river164-','8v8-warm2048-']:
  for diagnostic,plain in [('distance-audit-final','final512'),('distance-audit-negative-only','negative-only'),('distance-audit-negative-only-preserve-turns','negative-only-preserve-turns')]:
   a,b=raw.get(prefix+diagnostic),raw.get(prefix+plain)
   if a and b:equivalence.append({'pair':[prefix+diagnostic,prefix+plain],'same_ticks':a['ticks']==b['ticks'],'same_checksum':a['finalChecksum']==b['finalChecksum'],'same_jobs':a['gradient_jobs']==b['gradient_jobs']})
(root/'analysis.json').write_text(json.dumps({'rows':out,'instrumentation_equivalence':equivalence},indent=2)+'\n')
for r in out: print(r['case'],r['measured_ticks'],round(r['sim_cpu_ms_tick'],4),r['gradient_jobs'],round(r['jobs_per_tick'],4))
print('Equivalence:',equivalence)
