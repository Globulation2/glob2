from pathlib import Path
import os,signal,json,time
p=Path('/home/bradley/glob2/artifacts/gradient-reconciliation/run-controlled.py');prefix=p.read_text().split('try:\n status(')[0].replace("O=C/'controlled'","O=C/'bridge-fast'")
namespace={};exec(prefix,namespace)
status=namespace['status'];execute=namespace['execute'];cmdmap=namespace['cmdmap'];C=namespace['C'];river=namespace['river'];hist=namespace['hist']
pgid=3608959
assert os.getpgid(pgid)==pgid
try:
 os.killpg(pgid,signal.SIGSTOP);time.sleep(2);status('builder-paused',pgid=pgid)
 for label,binary,env in [('old-rotation',hist,{'GLOB2_RESOURCE_PROBE_LIVE_ONLY':'1'}),('old-fixed32',hist,{'GLOB2_RESOURCE_PROBE_LIVE_ONLY':'1','GLOB2_EXPERIMENT_RESOURCE_DEMAND8':'1','GLOB2_RESOURCE_INTERVAL':'32'}),('old-adaptive32',hist,{'GLOB2_RESOURCE_PROBE_LIVE_ONLY':'1','GLOB2_EXPERIMENT_RESOURCE_DEMAND8':'1','GLOB2_RESOURCE_INTERVAL':'8','GLOB2_RESOURCE_PORTABLE_MODEL':'1','GLOB2_RESOURCE_PORTABLE_THRESHOLD':'32000','GLOB2_RESOURCE_REFIT_MODEL':'1'}),('final512',C/'bin/final512',{}),('master',C/'bin/master',{})]:
  execute('river164-'+label,cmdmap(binary,river,2002,['nicowar']*4,[1,2,3,4],90000),env)
 status('complete')
finally:
 os.killpg(pgid,signal.SIGCONT)
