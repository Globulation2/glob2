from pathlib import Path
import time,json,subprocess
C=Path('/home/bradley/glob2/artifacts/gradient-reconciliation')
while True:
 s=json.loads((C/'controlled/status.json').read_text())
 if s['phase']=='complete' and (C/'terrain-current-linux/manifest.json').exists():break
 if s['phase']=='failed':raise RuntimeError('Main campaign failed; do not overlap recovery')
 time.sleep(3)
prefix=(C/'run-controlled.py').read_text().split('try:\n status(')[0].replace("O=C/'controlled'","O=C/'negative-followup'").replace("str(C/'apply-research-instrumentation.py')","str(C/'apply-research-instrumentation-distance.py')")
n={};exec(prefix,n);execute=n['execute'];cmdmap=n['cmdmap'];build=n['build'];status=n['status'];river=n['river'];O=n['O'];R=n['R'];save=n['save']
checkpoint=json.loads((C/'controlled/shared-checkpoint.json').read_text())['path']
def suffix(b):return [str(b),'game','run','--load-game',checkpoint,'--ticks','35840','--compute-threads','1','--gpu','off','--compute-telemetry','off','--benchmark-warmup','2048']
try:
 for name in ['master','final512','oldmodel','preserve-turns','no-distance']:
  execute('8v8-warm2048-'+name,suffix(C/'bin'/name))
 controls=[('negative-only',['negative-only-distance']),('negative-only-preserve-turns',['negative-only-distance','preserve-natural-rotation-turns'])]
 for name,variants in controls:
  b=build(name,False,variants)
  execute('river164-'+name,cmdmap(b,river,2002,['nicowar']*4,[1,2,3,4],90000))
  execute('8v8-warm2048-'+name,suffix(b))
 for name,variants in [('distance-audit-final',[])]+[('distance-audit-'+n,v) for n,v in controls]:
  b=build(name,True,variants)
  execute('river164-'+name,cmdmap(b,river,2002,['nicowar']*4,[1,2,3,4],90000),{'GLOB2_GRADIENT_AUDIT':str(O/('river164-'+name)/'audit.json')})
  execute('8v8-warm2048-'+name,suffix(b),{'GLOB2_GRADIENT_AUDIT':str(O/('8v8-warm2048-'+name)/'audit.json'),'GLOB2_GRADIENT_AUDIT_START_TICK':'34816'})
 n['restore']();status('complete')
except Exception as e:
 status('failed',error=repr(e));raise
