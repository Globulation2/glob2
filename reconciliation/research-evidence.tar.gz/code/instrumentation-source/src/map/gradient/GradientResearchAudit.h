// RESEARCH ONLY. Runtime opt-in; never commit to production.
#pragma once
#include <array>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <cstdint>
#include <string>
namespace GradientResearchAudit {
enum Cause { Other, ColdOrStale, ReactiveDepleted, ReactiveBlocked, AdaptiveCap, AdaptiveModel, Periodic, CauseCount };
inline thread_local Cause cause=Other;
struct Scope { Cause previous; explicit Scope(Cause c):previous(cause) {cause=c;} ~Scope(){cause=previous;} };
// Category: natural ground, natural AIR, markets, guard, clear, forbidden.
inline int category(int kind,int swim) {return kind==0 ? (swim<8 ? 0:1) : kind+1;}
struct State {
    const char* path=std::getenv("GLOB2_GRADIENT_AUDIT");
    std::array<std::atomic<std::uint64_t>,6*CauseCount> enqueues{},admissions{};
    std::array<std::atomic<std::uint64_t>,6> warm{},cold{},cells{},seedNs{},propNs{};
    std::atomic<std::uint64_t> movementQueries{0},distanceQueries{0},distanceZeroMovement{0},capAccepted{0},modelAccepted{0},modelRejected{0},noDemand{0},minimumSpacing{0},adaptiveZeroMovement{0},stageNs{0},policyNs{0},queryNs{0},fieldsVisited{0},modelEvaluations{0},seedJobs{0},propJobs{0};
    // All enqueue/admit calls are owner-only; no worker reads this map.
    std::map<void*,Cause> origins;
    FILE* decisions=nullptr;
    void decision(unsigned tick,int key,bool cap,const std::array<std::int64_t,7>& inputs) {
        if(!enabled())return;
        if(!decisions) {const auto filename=std::string(path)+".decisions.csv";decisions=std::fopen(filename.c_str(),"w");if(decisions)std::fputs("tick,key,cap,age,q32,q128,source_added,source_removed,source_added_frac_q12,source_removed_frac_q12\n",decisions);}
        if(!decisions)return;std::fprintf(decisions,"%u,%d,%d",tick,key,int(cap));for(auto v:inputs)std::fprintf(decisions,",%lld",(long long)v);std::fputc('\n',decisions);
    }
    bool enabled() const {return path && *path;}
    ~State() {
        if(decisions)std::fclose(decisions);
        if(!enabled())return;FILE* f=std::fopen(path,"w");if(!f)return;
        std::fputs("{\"schema\":1,\"note\":\"Research diagnostic counters; nanoseconds are summed wall scope durations, not total process CPU\",",f);
        const auto array=[&](const char* name,const auto& x){std::fprintf(f,"\"%s\":[",name);bool first=true;for(const auto& v:x){std::fprintf(f,"%s%llu",first?"":",",(unsigned long long)v.load());first=false;}std::fputs("],",f);};
        std::fputs("\"categories\":[\"natural_ground\",\"natural_air\",\"markets\",\"guard\",\"clear\",\"forbidden\"],\"causes\":[\"other\",\"cold_or_stale\",\"reactive_depleted\",\"reactive_blocked\",\"adaptive_cap\",\"adaptive_model\",\"periodic\"],",f);
        array("enqueues_category_major",enqueues);array("admissions_category_major",admissions);array("warm_admissions",warm);array("cold_admissions",cold);array("admitted_cells",cells);array("seed_wall_ns",seedNs);array("propagate_wall_ns",propNs);
#define AUDIT_OUT(n) std::fprintf(f,"\"" #n "\":%llu,",(unsigned long long)n.load())
        AUDIT_OUT(movementQueries);AUDIT_OUT(distanceQueries);AUDIT_OUT(distanceZeroMovement);AUDIT_OUT(capAccepted);AUDIT_OUT(modelAccepted);AUDIT_OUT(modelRejected);AUDIT_OUT(noDemand);AUDIT_OUT(minimumSpacing);AUDIT_OUT(adaptiveZeroMovement);AUDIT_OUT(stageNs);AUDIT_OUT(policyNs);AUDIT_OUT(queryNs);AUDIT_OUT(fieldsVisited);AUDIT_OUT(modelEvaluations);AUDIT_OUT(seedJobs);AUDIT_OUT(propJobs);
#undef AUDIT_OUT
        std::fprintf(f,"\"remaining_origin_entries\":%zu}\n",origins.size());std::fclose(f);
    }
};
inline State state;
inline void queued(void* slot,int kind,int swim) {if(!state.enabled())return;state.enqueues[category(kind,swim)*CauseCount+cause].fetch_add(1,std::memory_order_relaxed);state.origins[slot]=cause;}
inline void admitted(void* slot,int kind,int swim,bool isWarm,std::uint64_t size) {if(!state.enabled())return;const int cat=category(kind,swim);const auto it=state.origins.find(slot);const Cause origin=it==state.origins.end()?Other:it->second;if(it!=state.origins.end())state.origins.erase(it);state.admissions[cat*CauseCount+origin].fetch_add(1,std::memory_order_relaxed);(isWarm?state.warm[cat]:state.cold[cat]).fetch_add(1,std::memory_order_relaxed);state.cells[cat].fetch_add(size,std::memory_order_relaxed);}
struct Timer {std::atomic<std::uint64_t>* output=nullptr;std::chrono::steady_clock::time_point start;explicit Timer(std::atomic<std::uint64_t>& target){if(state.enabled()){output=&target;start=std::chrono::steady_clock::now();}}~Timer(){if(output)output->fetch_add(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count(),std::memory_order_relaxed);}};
}
