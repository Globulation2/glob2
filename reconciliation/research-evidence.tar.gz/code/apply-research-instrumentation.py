#!/usr/bin/env python3
"""Instrument a disposable final-source checkout. Never use for production timing."""
from pathlib import Path
import argparse
p=argparse.ArgumentParser();p.add_argument('checkout',type=Path);a=p.parse_args();root=a.checkout.resolve()
header=r'''// RESEARCH ONLY. Runtime opt-in; never commit to production.
#pragma once
#include <array>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <cstdint>
#include <string>
namespace GradientResearchAudit {
enum Cause { Other, ColdOrStale, ReactiveDepleted, ReactiveBlocked, AdaptiveCap, AdaptiveModel, Periodic, CauseCount };
inline thread_local Cause cause=Other;
struct Scope { Cause previous; explicit Scope(Cause c):previous(cause) {cause=c;} ~Scope(){cause=previous;} };
// Category: natural ground, natural AIR, markets, guard, clear, forbidden.
inline int category(int kind,int swim) {return kind==0 ? (swim<8 ? 0:1) : kind+1;}
struct State {
    const char* path=std::getenv("GLOB2_GRADIENT_AUDIT");
    std::array<std::atomic<std::uint64_t>,6*CauseCount> enqueues{},admissions{};
    std::array<std::atomic<std::uint64_t>,6> warm{},cold{},cells{},seedNs{},propNs{};
    std::atomic<std::uint64_t> movementQueries{0},distanceQueries{0},distanceZeroMovement{0},capAccepted{0},modelAccepted{0},modelRejected{0},noDemand{0},minimumSpacing{0},adaptiveZeroMovement{0},stageNs{0},policyNs{0},queryNs{0},fieldsVisited{0},modelEvaluations{0},seedJobs{0},propJobs{0};
    // All enqueue/admit calls are owner-only; no worker reads this map.
    std::map<void*,Cause> origins;
    FILE* decisions=nullptr;
    void decision(unsigned tick,int key,bool cap,unsigned submittedAge,const std::array<std::int64_t,7>& inputs) {
        if(!enabled())return;
        if(!decisions) {const auto filename=std::string(path)+".decisions.csv";decisions=std::fopen(filename.c_str(),"w");if(decisions)std::fputs("tick,key,cap,submitted_age,age,q32,q128,source_added,source_removed,source_added_frac_q12,source_removed_frac_q12\n",decisions);}
        if(!decisions)return;std::fprintf(decisions,"%u,%d,%d,%u",tick,key,int(cap),submittedAge);for(auto v:inputs)std::fprintf(decisions,",%lld",(long long)v);std::fputc('\n',decisions);
    }
    bool enabled() const {return path && *path;}
    ~State() {
        if(decisions)std::fclose(decisions);
        if(!enabled())return;FILE* f=std::fopen(path,"w");if(!f)return;
        std::fputs("{\"schema\":1,\"note\":\"Research diagnostic counters; nanoseconds are summed wall scope durations, not total process CPU\",",f);
        const auto array=[&](const char* name,const auto& x){std::fprintf(f,"\"%s\":[",name);bool first=true;for(const auto& v:x){std::fprintf(f,"%s%llu",first?"":",",(unsigned long long)v.load());first=false;}std::fputs("],",f);};
        std::fputs("\"categories\":[\"natural_ground\",\"natural_air\",\"markets\",\"guard\",\"clear\",\"forbidden\"],\"causes\":[\"other\",\"cold_or_stale\",\"reactive_depleted\",\"reactive_blocked\",\"adaptive_cap\",\"adaptive_model\",\"periodic\"],",f);
        array("enqueues_category_major",enqueues);array("admissions_category_major",admissions);array("warm_admissions",warm);array("cold_admissions",cold);array("admitted_cells",cells);array("seed_wall_ns",seedNs);array("propagate_wall_ns",propNs);
#define AUDIT_OUT(n) std::fprintf(f,"\"" #n "\":%llu,",(unsigned long long)n.load())
        AUDIT_OUT(movementQueries);AUDIT_OUT(distanceQueries);AUDIT_OUT(distanceZeroMovement);AUDIT_OUT(capAccepted);AUDIT_OUT(modelAccepted);AUDIT_OUT(modelRejected);AUDIT_OUT(noDemand);AUDIT_OUT(minimumSpacing);AUDIT_OUT(adaptiveZeroMovement);AUDIT_OUT(stageNs);AUDIT_OUT(policyNs);AUDIT_OUT(queryNs);AUDIT_OUT(fieldsVisited);AUDIT_OUT(modelEvaluations);AUDIT_OUT(seedJobs);AUDIT_OUT(propJobs);
#undef AUDIT_OUT
        std::fprintf(f,"\"remaining_origin_entries\":%zu}\n",origins.size());std::fclose(f);
    }
};
inline State state;
inline void queued(void* slot,int kind,int swim) {if(!state.enabled())return;state.enqueues[category(kind,swim)*CauseCount+cause].fetch_add(1,std::memory_order_relaxed);state.origins[slot]=cause;}
inline void admitted(void* slot,int kind,int swim,bool isWarm,std::uint64_t size) {if(!state.enabled())return;const int cat=category(kind,swim);const auto it=state.origins.find(slot);const Cause origin=it==state.origins.end()?Other:it->second;if(it!=state.origins.end())state.origins.erase(it);state.admissions[cat*CauseCount+origin].fetch_add(1,std::memory_order_relaxed);(isWarm?state.warm[cat]:state.cold[cat]).fetch_add(1,std::memory_order_relaxed);state.cells[cat].fetch_add(size,std::memory_order_relaxed);}
struct Timer {std::atomic<std::uint64_t>* output=nullptr;std::chrono::steady_clock::time_point start;explicit Timer(std::atomic<std::uint64_t>& target){if(state.enabled()){output=&target;start=std::chrono::steady_clock::now();}}~Timer(){if(output)output->fetch_add(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count(),std::memory_order_relaxed);}};
}
'''
def edit(rel,old,new):
    path=root/rel;text=path.read_text();assert text.count(old)==1,(rel,old[:100],text.count(old));path.write_text(text.replace(old,new))
(root/'src/map/gradient/GradientResearchAudit.h').write_text(header)
for rel in ['src/map/MapStep.cpp','src/map/MapResources.cpp','src/map/pathfind/MapPathfindMaterial.cpp','src/map/gradient/MapGradientMaterial.cpp']:
    edit(rel,'#include "Map.h"','#include "Map.h"\n#include "gradient/GradientResearchAudit.h"')
edit('src/map/MapStep.cpp','''\tstageBuildingGradientPreparation();
    suspendUnusedGradientClasses();''','''    GradientResearchAudit::Timer auditStage(GradientResearchAudit::state.stageNs);
    stageBuildingGradientPreparation();
    suspendUnusedGradientClasses();''')
edit('src/map/MapStep.cpp','''        auto dispatch = [&](Uint16 **slot, Kind kind, int team, int material, int swim) {
            return requestGradientField''','''        auto dispatch = [&](Uint16 **slot, Kind kind, int team, int material, int swim) {
            GradientResearchAudit::Scope auditCause(GradientResearchAudit::Periodic);
            return requestGradientField''')
edit('src/map/MapStep.cpp','''    const auto admit=[&](const GradientRuntime::FieldRequest& request) {
        auto* job''','''    const auto admit=[&](const GradientRuntime::FieldRequest& request) {
        GradientResearchAudit::admitted(request.slot,int(request.request.kind),request.request.swim,*request.slot!=nullptr,size);
        auto* job''')
edit('src/map/MapStep.cpp','''    auto& policy=gradientRuntime->resources;
    for (auto& [key,field]:policy.fields) {''','''    auto& policy=gradientRuntime->resources;
    GradientResearchAudit::Timer auditPolicy(GradientResearchAudit::state.policyNs);
    for (auto& [key,field]:policy.fields) {
        if(GradientResearchAudit::state.enabled())++GradientResearchAudit::state.fieldsVisited;''')
edit('src/map/MapStep.cpp','''        if (!field.refresh(game->stepCounter,policy.sources[material])) continue;
        if (!requestGradientField''','''        const bool auditCap=unsigned(game->stepCounter-field.submitted)>=ResourceGradientPolicy::MaximumInterval;
        const bool auditRequested=field.requested;
        const bool auditMinimum=unsigned(game->stepCounter-field.submitted)<ResourceGradientPolicy::MinimumInterval;
        const bool auditAccepted=field.refresh(game->stepCounter,policy.sources[material]);
        if(GradientResearchAudit::state.enabled()) {
            auto& a=GradientResearchAudit::state;
            if(auditRequested && !auditMinimum && !auditCap)++a.modelEvaluations;
            if(!auditRequested)++a.noDemand;
            else if(auditMinimum)++a.minimumSpacing;
            else if(!auditAccepted)++a.modelRejected;
            else {++(auditCap?a.capAccepted:a.modelAccepted);if(field.count128==0)++a.adaptiveZeroMovement;}
        }
        if (!auditAccepted) continue;
        GradientResearchAudit::Scope auditCause(auditCap?GradientResearchAudit::AdaptiveCap:GradientResearchAudit::AdaptiveModel);
        if (!requestGradientField''')
edit('src/map/MapStep.cpp','''    gradientRuntime->fieldRequests.push_back({slot,request});
    return true;''','''    gradientRuntime->fieldRequests.push_back({slot,request});
    GradientResearchAudit::queued(slot,kind,swim);
    return true;''')
edit('src/map/MapStep.cpp','''        gradient_preparation::seed(job.request,*job.snapshotLease,job.data.get(),*job.crowding);''','''        const auto cat=GradientResearchAudit::category(int(job.request.kind),job.request.swim);
        GradientResearchAudit::Timer auditSeed(GradientResearchAudit::state.seedNs[cat]);
        if(GradientResearchAudit::state.enabled())++GradientResearchAudit::state.seedJobs;
        gradient_preparation::seed(job.request,*job.snapshotLease,job.data.get(),*job.crowding);''')
edit('src/map/MapStep.cpp','''            gradient_preparation::propagateCPU(job.request,*job.snapshotLease,job.data.get(),scratch);''','''            const auto cat=GradientResearchAudit::category(int(job.request.kind),job.request.swim);
            GradientResearchAudit::Timer auditProp(GradientResearchAudit::state.propNs[cat]);
            if(GradientResearchAudit::state.enabled())++GradientResearchAudit::state.propJobs;
            gradient_preparation::propagateCPU(job.request,*job.snapshotLease,job.data.get(),scratch);''')
edit('src/map/MapResources.cpp','''\t\tgradientRuntime->resources.fields[(team*MaterialCount+material)*SWIM_CLASS_COUNT+swim].requested=true;''','''        auto& auditField=gradientRuntime->resources.fields[(team*MaterialCount+material)*SWIM_CLASS_COUNT+swim];
        if(GradientResearchAudit::state.enabled()) {++GradientResearchAudit::state.distanceQueries;if(auditField.count128==0)++GradientResearchAudit::state.distanceZeroMovement;}
        auditField.requested=true;''')
edit('src/map/pathfind/MapPathfindMaterial.cpp','''        field.queried(game->stepCounter,gradient[coordToIndex(x,y)]!=GRADIENT_FORBIDDEN);''','''        if(GradientResearchAudit::state.enabled())++GradientResearchAudit::state.movementQueries;
        GradientResearchAudit::Timer auditQuery(GradientResearchAudit::state.queryNs);
        field.queried(game->stepCounter,gradient[coordToIndex(x,y)]!=GRADIENT_FORBIDDEN);''')
edit('src/map/pathfind/MapPathfindMaterial.cpp','''        if (!materialAmountAtSlot(hereIndex,resourceType)) refresh();''','''        if (!materialAmountAtSlot(hereIndex,resourceType)) {GradientResearchAudit::Scope auditCause(GradientResearchAudit::ReactiveDepleted);refresh();}''')
edit('src/map/pathfind/MapPathfindMaterial.cpp','''    refresh();
    return false;''','''    {GradientResearchAudit::Scope auditCause(GradientResearchAudit::ReactiveBlocked);refresh();}
    return false;''')
# Getter cold/stale enrollments, distinct from reactivity and model acceptance.
edit('src/map/gradient/MapGradientMaterial.cpp','''    if ((!gradient || stale) && !compute.insideJob())
        requestGradientField(&gradient, int(withMarkets ? gradient_preparation::Kind::Markets : gradient_preparation::Kind::Materials), teamNumber, resourceType, swimClass);''','''    if ((!gradient || stale) && !compute.insideJob()) {
        GradientResearchAudit::Scope auditCause(GradientResearchAudit::ColdOrStale);
        requestGradientField(&gradient, int(withMarkets ? gradient_preparation::Kind::Markets : gradient_preparation::Kind::Materials), teamNumber, resourceType, swimClass);
    }''')
print('Research instrumentation applied. Enable with GLOB2_GRADIENT_AUDIT=/absolute/output.json; use CPU backend. Diagnostic overhead is not representative performance.')

edit('src/map/MapStep.cpp','''        const auto request=gradientRuntime->fieldRequests.back();
        gradientRuntime->fieldRequests.pop_back();''','''        if(GradientResearchAudit::state.enabled()) {
            auto diagnostic=field;
            GradientResearchAudit::state.decision(game->stepCounter,key,auditCap,unsigned(game->stepCounter-field.submitted),diagnostic.inputs(game->stepCounter,policy.sources[material]));
        }
        const auto request=gradientRuntime->fieldRequests.back();
        gradientRuntime->fieldRequests.pop_back();''')
