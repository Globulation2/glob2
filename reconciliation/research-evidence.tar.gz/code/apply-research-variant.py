#!/usr/bin/env python3
"""Research-only ablations. Run on a disposable df253 checkout, never production."""
import argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('variant',choices=['no-distance-request','no-reactive-natural-ground-fifo','preserve-natural-rotation-turns','fixed32','negative-only-distance','no-cap']);p.add_argument('checkout',type=Path);a=p.parse_args();root=a.checkout.resolve()
if a.variant=='no-distance-request':
    path=root/'src/map/MapResources.cpp';text=path.read_text()
    block='''\tif (game && !compute.insideJob() && swim<SWIM_CLASS_COUNT
\t\t&& field==materialGradients[team][material][swim]) {
\t\t// Recruitment must eventually reconsider an old negative answer even
\t\t// when no unit can start walking toward it. This is demand, not a
\t\t// movement sample: keep the fitted q32/q128 feature definitions intact.
\t\tgradientRuntime->initializeResourcePolicy(*this);
\t\tgradientRuntime->resources.fields[(team*MaterialCount+material)*SWIM_CLASS_COUNT+swim].requested=true;
\t}
'''
    if text.count(block)==1:
        text=text.replace(block,'\t// RESEARCH ONLY: exclude scalar recruitment demand from adaptive scheduling.\n')
    else:
        prefix='\tif (game && !compute.insideJob() && swim<SWIM_CLASS_COUNT\n\t\t&& field==materialGradients[team][material][swim]) {'
        assert text.count(prefix)==1 and 'auditField.requested=true;' in text,'Expected final instrumented distance block'
        start=text.index(prefix);end=text.index('\n\t}\n',start)+len('\n\t}\n')
        text=text[:start]+'\t// RESEARCH ONLY: exclude scalar recruitment demand from adaptive scheduling.\n'+text[end:]
elif a.variant=='no-reactive-natural-ground-fifo':
    path=root/'src/map/pathfind/MapPathfindMaterial.cpp';text=path.read_text()
    block='''    const auto refresh=[&] {
        using Kind=gradient_preparation::Kind;
'''
    assert text.count(block)==1,'Expected exact reactive refresh lambda'
    text=text.replace(block,'''    const auto refresh=[&] {
        // RESEARCH ONLY: let adaptive policy alone schedule warmed natural ground refreshes.
        // Cold allocation, stale-class reactivation, suppliers and AIR stay unchanged.
        if (naturalGround) return;
        using Kind=gradient_preparation::Kind;
''')
elif a.variant=='preserve-natural-rotation-turns':
    path=root/'src/map/MapStep.cpp';text=path.read_text()
    block='''            for (int t=0; t<numberOfTeam; t++)
                for (int r=0; r<MaterialCount; r++)
                    for (int s=AIR_MOVEMENT_CLASS; s<MOVEMENT_CLASS_COUNT; s++)
'''
    assert text.count(block)==1,'Expected exact AIR round-robin prefix'
    text=text.replace(block,'''            // RESEARCH ONLY: restore the historical prototype's skipped natural
            // ground turns, without actually enqueueing those periodic jobs.
            for (int t=0; t<numberOfTeam; t++)
                for (int r=0; r<MaterialCount; r++)
                    for (int s=0; s<SWIM_CLASS_COUNT; s++)
                        if (periodicGradientClassActive(t,s) && hasMaterialSourceSlot(r)
                            && materialGradients[t][r][s] && !gradientUpdated[t][r][s]) {
                            gradientUpdated[t][r][s]=true;
                            return;
                        }
'''+block)
elif a.variant=='fixed32':
    path=root/'src/map/MapStep.cpp';text=path.read_text()
    expression='field.refresh(game->stepCounter,policy.sources[material])'
    assert text.count(expression)==1,'Expected warm adaptive refresh call'
    # Equivalent to Field::refresh with MinimumInterval=MaximumInterval=32:
    # a demanded field at age32 always takes the cap, with no model evaluation.
    text=text.replace(expression,'(std::exchange(field.requested,false) && unsigned(game->stepCounter-field.submitted)>=32)')
    text=text.replace('>=ResourceGradientPolicy::MaximumInterval','>=32')
    text=text.replace('<ResourceGradientPolicy::MinimumInterval','<32')
elif a.variant=='negative-only-distance':
    path=root/'src/map/MapResources.cpp';text=path.read_text()
    block='&& field==materialGradients[team][material][swim]) {'
    assert text.count(block)==1,'Expected scalar natural-field comparison'
    text=text.replace(block,'&& field==materialGradients[team][material][swim] && field[coordToIndex(x,y)]<=GRADIENT_UNREACHABLE) {')
else:
    path=root/'src/map/MapStep.cpp';text=path.read_text()
    expression='field.refresh(game->stepCounter,policy.sources[material])'
    assert text.count(expression)==1,'Expected adaptive refresh call'
    text=text.replace(expression,'(std::exchange(field.requested,false) && unsigned(game->stepCounter-field.submitted)>=ResourceGradientPolicy::MinimumInterval && ResourceGradientModel::predict(field.inputs(game->stepCounter,policy.sources[material]))>=ResourceGradientPolicy::Threshold)')
    text=text.replace('const bool auditCap=unsigned(game->stepCounter-field.submitted)>=ResourceGradientPolicy::MaximumInterval;','const bool auditCap=false; // RESEARCH: uncapped admissions always require the model')
path.write_text(text)
print(path)
