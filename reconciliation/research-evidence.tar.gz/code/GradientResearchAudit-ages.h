// RESEARCH ONLY. Runtime opt-in; never commit to production.
#pragma once
#include <array>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <cstdint>
#include <string>
namespace GradientResearchAudit {
enum Cause { Other, ColdOrStale, ReactiveDepleted, ReactiveBlocked, AdaptiveCap, AdaptiveModel, Periodic, CauseCount };
inline thread_local Cause cause=Other;
struct Scope { Cause previous; explicit Scope(Cause c):previous(cause) {cause=c;} ~Scope(){cause=previous;} };
// Category: natural ground, natural AIR, markets, guard, clear, forbidden.
inline int category(int kind,int swim) {return kind==0 ? (swim<8 ? 0:1) : kind+1;}
struct State {
    const char* path=std::getenv("GLOB2_GRADIENT_AUDIT");
    unsigned startTick=std::getenv("GLOB2_GRADIENT_AUDIT_START_TICK")?unsigned(std::strtoul(std::getenv("GLOB2_GRADIENT_AUDIT_START_TICK"),nullptr,10)):0;
    std::atomic<unsigned> currentTick{0};
    std::array<std::atomic<std::uint64_t>,6*CauseCount> enqueues{},admissions{};
    std::array<std::atomic<std::uint64_t>,6> warm{},cold{},cells{},seedNs{},propNs{};
    std::atomic<std::uint64_t> movementQueries{0},distanceQueries{0},distanceReachable{0},distanceUnreachable{0},distanceZeroMovement{0},capAccepted{0},modelAccepted{0},modelRejected{0},noDemand{0},minimumSpacing{0},adaptiveZeroMovement{0},stageNs{0},policyNs{0},queryNs{0},fieldsVisited{0},modelEvaluations{0},seedJobs{0},propJobs{0};
    // All enqueue/admit calls are owner-only; no worker reads this map.
    std::map<void*,Cause> origins;
    static constexpr unsigned AgeLimit=131072;
    std::array<std::array<std::uint64_t,AgeLimit+1>,8> ageHist{};
    std::array<std::atomic<std::uint64_t>,8> ageMax{};
    std::array<std::atomic<std::uint64_t>,4> ageUnknown{};
    std::map<unsigned,std::array<std::uint64_t,6>> fieldAge;
    std::map<int,unsigned> oracleTicks;
    bool oracleEnabled=std::getenv("GLOB2_GRADIENT_PLANNING_ORACLE")!=nullptr;
    FILE* oracle=nullptr;
    void age(unsigned reader,unsigned key,unsigned value,bool changed) {
        if(!enabled())return;
        const auto bin=std::min(value,AgeLimit);
        ++ageHist[reader*2][bin];if(value>ageMax[reader*2])ageMax[reader*2]=value;
        if(changed){++ageHist[reader*2+1][bin];if(value>ageMax[reader*2+1])ageMax[reader*2+1]=value;}
        auto& f=fieldAge[key*4+reader];++f[0];f[1]+=value>=128;f[2]+=value>=512;f[3]+=value>=4096;f[4]=std::max(f[4],std::uint64_t(value));f[5]+=changed;
    }
    void scalar(unsigned tick,int key,unsigned oldValue,unsigned freshValue,unsigned age,bool changed) {
        if(!enabled())return;
        if(!oracle){const auto filename=std::string(path)+".planning-oracle.csv";oracle=std::fopen(filename.c_str(),"w");if(oracle)std::fputs("tick,key,old_value,fresh_value,age,sources_changed\n",oracle);}
        if(oracle)std::fprintf(oracle,"%u,%d,%u,%u,%u,%d\n",tick,key,oldValue,freshValue,age,int(changed));
    }
    FILE* decisions=nullptr;
    void decision(unsigned tick,int key,bool cap,unsigned submittedAge,const std::array<std::int64_t,7>& inputs) {
        if(!enabled())return;
        if(!decisions) {const auto filename=std::string(path)+".decisions.csv";decisions=std::fopen(filename.c_str(),"w");if(decisions)std::fputs("tick,key,cap,submitted_age,age,q32,q128,source_added,source_removed,source_added_frac_q12,source_removed_frac_q12\n",decisions);}
        if(!decisions)return;std::fprintf(decisions,"%u,%d,%d,%u",tick,key,int(cap),submittedAge);for(auto v:inputs)std::fprintf(decisions,",%lld",(long long)v);std::fputc('\n',decisions);
    }
    bool configured() const {return path && *path;}
    bool enabled() const {return configured() && currentTick.load(std::memory_order_relaxed)>=startTick;}
    ~State() {
        if(oracle)std::fclose(oracle);
        if(configured()) {
            const auto name=std::string(path)+".ages.csv";if(FILE* h=std::fopen(name.c_str(),"w")){std::fputs("histogram,age,count\n",h);for(unsigned kind=0;kind<8;++kind)for(unsigned age=0;age<=AgeLimit;++age)if(ageHist[kind][age])std::fprintf(h,"%u,%u,%llu\n",kind,age,(unsigned long long)ageHist[kind][age]);std::fclose(h);}
            const auto name2=std::string(path)+".field-ages.csv";if(FILE* h=std::fopen(name2.c_str(),"w")){std::fputs("key,reader,queries,age128,age512,age4096,max_age,sources_changed\n",h);for(const auto& [key,f]:fieldAge){std::fprintf(h,"%u,%u",key/4,key%4);for(auto v:f)std::fprintf(h,",%llu",(unsigned long long)v);std::fputc('\n',h);}std::fclose(h);}
        }
        if(decisions)std::fclose(decisions);
        if(!enabled())return;FILE* f=std::fopen(path,"w");if(!f)return;
        std::fputs("{\"schema\":1,\"note\":\"Research diagnostic counters; nanoseconds are summed wall scope durations, not total process CPU\",",f);
        const auto array=[&](const char* name,const auto& x){std::fprintf(f,"\"%s\":[",name);bool first=true;for(const auto& v:x){std::fprintf(f,"%s%llu",first?"":",",(unsigned long long)v.load());first=false;}std::fputs("],",f);};
        std::fputs("\"categories\":[\"natural_ground\",\"natural_air\",\"markets\",\"guard\",\"clear\",\"forbidden\"],\"causes\":[\"other\",\"cold_or_stale\",\"reactive_depleted\",\"reactive_blocked\",\"adaptive_cap\",\"adaptive_model\",\"periodic\"],",f);
        array("age_max",ageMax);array("age_unknown",ageUnknown);array("enqueues_category_major",enqueues);array("admissions_category_major",admissions);array("warm_admissions",warm);array("cold_admissions",cold);array("admitted_cells",cells);array("seed_wall_ns",seedNs);array("propagate_wall_ns",propNs);
#define AUDIT_OUT(n) std::fprintf(f,"\"" #n "\":%llu,",(unsigned long long)n.load())
        AUDIT_OUT(movementQueries);AUDIT_OUT(distanceQueries);AUDIT_OUT(distanceReachable);AUDIT_OUT(distanceUnreachable);AUDIT_OUT(distanceZeroMovement);AUDIT_OUT(capAccepted);AUDIT_OUT(modelAccepted);AUDIT_OUT(modelRejected);AUDIT_OUT(noDemand);AUDIT_OUT(minimumSpacing);AUDIT_OUT(adaptiveZeroMovement);AUDIT_OUT(stageNs);AUDIT_OUT(policyNs);AUDIT_OUT(queryNs);AUDIT_OUT(fieldsVisited);AUDIT_OUT(modelEvaluations);AUDIT_OUT(seedJobs);AUDIT_OUT(propJobs);
#undef AUDIT_OUT
        std::fprintf(f,"\"remaining_origin_entries\":%zu}\n",origins.size());std::fclose(f);
    }
};
inline State state;
inline void queued(void* slot,int kind,int swim) {if(!state.configured())return;state.origins[slot]=cause;if(!state.enabled())return;state.enqueues[category(kind,swim)*CauseCount+cause].fetch_add(1,std::memory_order_relaxed);}
inline void admitted(void* slot,int kind,int swim,bool isWarm,std::uint64_t size) {if(!state.configured())return;const int cat=category(kind,swim);const auto it=state.origins.find(slot);const Cause origin=it==state.origins.end()?Other:it->second;if(it!=state.origins.end())state.origins.erase(it);if(!state.enabled())return;state.admissions[cat*CauseCount+origin].fetch_add(1,std::memory_order_relaxed);(isWarm?state.warm[cat]:state.cold[cat]).fetch_add(1,std::memory_order_relaxed);state.cells[cat].fetch_add(size,std::memory_order_relaxed);}
struct Timer {std::atomic<std::uint64_t>* output=nullptr;std::chrono::steady_clock::time_point start;explicit Timer(std::atomic<std::uint64_t>& target){if(state.enabled()){output=&target;start=std::chrono::steady_clock::now();}}~Timer(){if(output)output->fetch_add(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count(),std::memory_order_relaxed);}};
}
