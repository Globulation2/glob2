# Source reconciliation (read-only audit)

Compared finaldf25376f8, baseline3d896cbb9, previousconsolidated4d16ada10, and exacthistorical refit prototype archived from d860c600ae. Productioncheckout untouched. Fullhistoricalprototype notpresent inlocalGitobjectdatabase, so extracted fourrelevantfiles from preservedprototype-full-source.tar.gz; independentprovenance archive records sourcehashmatches.

## What actually stayed the same

The old consolidated production header4d16ada10 contains exactlythe fourcoefficientheads in the historical refit model used by yesterday's refit32000 results. model-delta.json records old/newheads. yesterday-model.h/json are exported verbatim from4d16. Both use age,q32,q128,sourceadded,removed,addedfraction,removedfraction; integerlog/sigmoid; threshold32000. Source-turnover means positive-stocktile zero crossings, not each unit of stock consumed. Minspacing8 and demandedmax128 already existed in historicalprototype. Thefinal rolling128-slotcounterimplementation replaces historical deque scans but preserves the stated querywindows; no evidence of a featureordering or units mismatch.

## Critical policy changes between yesterday's prototype and final integration

1. Historical adaptive scheduling intentionally kept natural-ground round-robin turns, marking each visited and returning EVEN WHEN it skipped the actual periodic refresh because adaptive was enabled. This suppressed market/guard/clear scheduling for those turns. Final removes natural-ground fields from the round-robin entirely, retaining AIR/market/guard/clear. One regular FIFO job per tick can therefore coexist with additional adaptive jobs. This is a concrete structural explanation for final totaljobs increasing despite the model selecting few refreshes. It requires instrumented family counters to quantify actual magnitude. Merely comparing threshold32 is insufficient because the surrounding scheduler changed.

2. Masterfc7cf5ecc introduced reactive FIFO requests when pathfindMaterial finds a depleted goal or fails both direction attempts. Historical prototype had neither: it returnedfalse or wandered until another refresh. Final retained masterreactivity. Natural ground FIFO admissions bypass adaptive score/min8 interval; when admitted, they reset policy submitted time. Consequently the final learned controller does not control all resource rebuilds. Both master and final have reactive FIFO, but interactions with different aging and population trajectories may amplify or suppress the effect. A no-reactive-ground ablation isolates it.

3. Final5b3 added scalar queryMaterialDistance demand enrollment to repair a correctness/liveness hole: a stale unreachable recruitment answer may otherwise never generate a movement query and never refresh. Historicalprototype enrolled demand only from movement. The new scalar demand does NOT enter q32/q128, preserving model input semantics, but it can activate128-tick capped refreshes on fields that the model training population did not actively query. Removing it is a diagnostic control with known liveness risk, not an automatically acceptable optimization.

4. Baseline/source changed from pre-rewrite research assumptions to current master cold ground scheduling, AIR routing, consumer snapshot ownership and first-read behavior. Coldresource fields were synchronously available in historicalprototype; now they have delayedFIFOadmission. Currentmaster also has AIRclass8 fields and directflight behavior. The final8formats include previously unseen large rectangular maps andgenerators. These are separatechanges from modelcoefficients and require samebase ablations.

5. Final512model differs in all fourheads. On frozen heldout episodes it selected0.4173% rather thanold0.9608%, with lowerMAE but slightlyhigherMSE. That does not byitself predict higherrefresh compute: the cap, scalar recruitment, reactive FIFO and otherfieldfamilies can dominate actualjobs. A model-only swap on identical currentfinalsource is necessary.

## Other costs/risks

Everytick suspendUnusedGradientClasses visits allteam×groundclass×material slots; then scheduler iterates a std::map of every historical naturalfield, including dormant ones. Movement query counters and per-field modelevaluation add cost. These can matter in smallmatches, but there is no measurement yet establishing they explain16% pooledCPU. Jobs,cells,seedtime,propagationtime,population histories and cappedgame trajectories must be separated before attribution.

The model has no direct rebuild-cost feature. Its output is predicted direction-cost benefit over a32-tick observation, and the constantthreshold is an absolute benefit threshold. A rebuild on512×256 or256×512 costs more than64×64. Therefore an absolutebenefit model trained on balancedformats is not a compute-budget optimizer and is not guaranteed to sit on the CPU frontier acrossmaps. This is an architectural limit, not evidence of a codingbug.

## Research controls prepared

apply-research-variant.py provides independent no-distance-request, no-reactive-natural-ground-fifo, and preserve-natural-rotation-turns controls. See RESEARCH-VARIANTS.txt for exactsemantics and risks. yesterday-model.h permits coefficient-onlyswap.

research-instrumentation.patch / apply-research-instrumentation.py add opt-in per-processJSON using GLOB2_GRADIENT_AUDIT=/absolute/output.json. Captures successfulenqueue/admit categories and causes, warm/cold counts, cells, model/cap acceptance, and wallscopes for scheduler, seed and CPUpropagation. Categories/cause arrays are named in JSON. Pure researchinstrumentation: use paired uninstrumented runs for runtime claims. Storedzero-movement counters are conservative because they do not advance expiredhistory on cap/scalarqueries. Stage includes scheduling and buildingstaging; propagationscope excludesbuildingpipeline. GPUoff required for full CPUpropagationaccounting.

## Recommended causal sequence

Use same current source, same master-generated map bytes, same seeds, ordinaryrelease flags. Atleast two historicalstates and two finalstates. First compare currentmaster, final, final+oldmodel, final+nodistance, final+noreactive. Run a short common initialprefix and a late common releasedsave ifcompatible; then whole closed-loop games. If totaljobs family counts indicate enlarged nonnaturalroundrobinwork, add restorednaturalrotationturn control to quantify it. Examine CPU per tick alongside gradient jobs/cells/times, population/building trajectories, and unfinished caps. Do not infer algorithm deterioration solely from longer/larger matches; do not infer success solely from fewer gradients either.
