# Reconciliation of historical A32 claims with final release comparison

The old results really did show CPU savings. This is not explained by the user misreading the chart. The final result measures a different model, integrated policy, baseline engine, hardware/thread configuration, map population and aggregate statistic. None of the available historical data isolates those changes. We need controlled bridge experiments before diagnosing the cause or declaring the idea failed.

## Reproduced historical figures

`historical-reconciliation.py` independently reproduces the frozen dashboard from `artifacts/gradient-live/data.json`. The dashboard stopped for consolidation with 177 quality games and 125 accepted timings, not a completed 256-pair matrix. Seven initial states had all 16 policies timed and nonzero quality queries. Coverage was two isles64 duels, two river128 four-player FFAs, two river256 4v4s, and one savannah256 sixteen-player FFA. The chart used equal format weights, then equal state weights within a format.

On that exact common population:

|Policy|CPU/tick relative to rotation|Extra direction cost/query|Natural refreshes/tick|
|---|---:|---:|---:|
|Rotation|0%|1.671744|0.717341|
|Fixed32|-1.462%|0.971074|0.480808|
|Adaptive32|-18.587%|1.092729|0.137675|

Thus A32 reduced sampled extra direction cost by34.6% and natural refresh counts by80.8% while reducing matched CPU/tick18.6%. These are sampled closed-loop policy outcomes, not isolated kernel measurements or robust cross-map guarantees. The same four original states had already been used for threshold selection; only three fresh states entered the full common chart before consolidation. The eighth A32/rotation pair (savannah seed3004) was available but other policies were unfinished; all eight individual A32 pairs showed CPU savings, from5.3% to29.5%.

## Aggregation explains part, not all, of the headline reversal

|Population|Mean paired CPU/tick change|Geometric mean paired change|Pooled CPU/tick change|
|---|---:|---:|---:|
|Historical eight available A32 pairs|-17.99%|-18.42%|-10.13%|
|Final eight states|+0.41%|-1.37%|+16.51%|

Final paired geometric mean and pooled headline differ by17.9 percentage points. Pooling weights long/expensive games heavily. This is a real aggregate, but does not mean the typical equally weighted format got16.5% slower. Nor does reweighting recover the historical18% win: using only the four format names shared with the historical experiment, final arithmetic change is+1.63%, geometric+0.72%, on different maps. A real behavior/model/baseline/population difference remains.

One final 8v8 city-states state contributes82.4% of the excess total simulation CPU:94.33 additional CPU seconds per repetition. Master ends at68,770 ticks while A32 is capped at90,000. The observed total is censored for A32; it does not measure its full finish cost. This state accounts for32% of baseline simulation CPU, while the cheap3ffa state is0.2%. 4ffa contributes16.1% of excess,16ffa13.6%, offset by4v4−10.9%. These contributions sum100% with smaller cases.

## Changed conditions

Historical exact measured source is preservation commit `d860c600ae1c84c90d644907650cfae0a596272d`, a research snapshot based on `dd493d7e71d21e5ab6cbaee0fe168a37e076860a` (Publish hiring candidates after one tick). It is in the preserved thin bundle/full archive under `artifacts/gradient-prototypes-preserved-20261018/devlaptop/`. All nine source hashes match the measured binary. It is not current production source.

Historical executable SHA256:`a20b93cf05054bb35870e677be69d138fd29912b7bb2ab178f8f2bdc8504fdf2`; model JSON SHA256:`8e50d0540bf65358a4d79a088f6cb5bef50dc01406b6a6a52f3c0989f5ebcc34`.

Historical timings ran Linuxx86_64,8compute threads, GPU/probeoff, warmup0,90ktickcap. Quality ran separately with4threads and was excluded from timings. Same binary selected rotation/fixed/adaptive using environment variables. The research rotation already had unused-class/source suppression; comparison is not against installed legacy Glob2. The final comparison ran MacARM64,1compute thread, same cap/warmup/probeoff but eight entirely different maps across eight formats including rectangles64..512, a new512trained model, and final integrated source against master3d896cbb9.

Between the research base and final master are material changes including delayed cold ground fields(#1194), shared air routing(#1196), unified completed observation(#1195), intrusive populations(#1188), inline hot helpers(#1193), and checksum work(#1187/#1221). Those are shared by final master/PR, but change the baseline against which historical percentage savings were earned.

A concrete adaptive semantic difference is visible in preserved source: only `pathfindMaterial` movement reads request natural refreshes, and only when the current cell is not FORBIDDEN. Scalar `Map::getGradient` reads resolve lazy state but do not request refreshes. Final integrated policy intentionally also requests refreshes from distance/availability reads to prevent stale-unreachable recruitment liveness failures. That can broaden the demanded field population and refresh frequency. It should be ablated separately, without assuming it is optional correctness-wise.

The nominal A32 number is a threshold of32000 predicted benefit, not a refresh interval. Identical threshold with newly fitted coefficient heads does not guarantee identical acceptance rate. The old and512models have the same seven inputs, four-head form and fixed-point representation, but substantially changed coefficients/biases. E.g positive source_removed coefficient changes sign in probability head; q128 coefficient changes sign in positive conditional mean. Offline better MAE/ranking does not imply fewer refreshes or lower total runtime at the old threshold. Need evaluate admission calibration and closed-loop refresh count on shared states.

## Exact reproducible historical states for bridge tests

Files remain on devlaptop under `/home/bradley/glob2/artifacts/gradient-refit-sweep/`:

- `maps/2002.map.gz`: river128x128,mapseed385001,gameseed2002,4Nicowar,alliances1,2,3,4,SHAe180488732141cf618aeed2fe445f4f26ed38a5cccb2f21b303d98eebacd8b3d.
- `maps/2003.map.gz`: river256x256,mapseed385002,gameseed2003,8Nicowar,alliances1,1,1,1,2,2,2,2,SHA10e75c97e99d671a10cef592aac0e6c4a80fcfb33351c00915a81d1dddd54806.
- Oldbinary:`glob2-experimental`. Exact command/env for each record in `runs/seed-2002-rotation-guarded-repeat-sweep0-t8/command.json` etc.

A32 env: GLOB2_RESOURCE_PROBE_LIVE_ONLY=1,GLOB2_EXPERIMENT_RESOURCE_DEMAND8=1,GLOB2_RESOURCE_INTERVAL=8,GLOB2_RESOURCE_PORTABLE_MODEL=1,GLOB2_RESOURCE_PORTABLE_THRESHOLD=32000,GLOB2_RESOURCE_REFIT_MODEL=1. Rotation has only LIVE_ONLY; gradient metrics path optionally enabled in both. Historical model compiled into binary; file path does not replace it.

Historical map containers may predate currentmaster accepted TeamStats layout. Regenerate same logical specs using master for shared currentmaster/PR inputs, preserving original map hashes and explicitly noting regeneration may change terrain. Better bridge old-new model on identical final source, and original rotation-A32 on original exact maps, then cross-map runs inside each binary family. Do not treat different format containers as byte-identical states.

## Tests needed

1. Reproduce old rotation/A32 pair on historical exact Linux maps with1and8threads to establish gains were real and thread sensitivity.
2. Currentmaster/finalPR on matched heldout maps under both1and8threads, interleaved, release, sameCPUhost. Repeat problematic8v8 plus a historical winner.
3. Finalsource oldmodel versus newmodel on same current-compatible states to isolate retraining. Report warm natural submissions, cold FIFO/AIR/market/area/building jobs separately; aggregate gradient_jobs alone conflates families and work sizes.
4. Distance-only demand ablation on a diagnostic branch, verifying recruitment liveness and per-tick determinism; count these reads/accepted fields. Source-only correct default remains intact.
5. Separate same-state scheduling overhead from downstream populations/trajectory effects. CPU/tick and final-unit counts alone cannot infer per-unit costs. Use accumulated unit-ticks, request counts, propagation cells and CPU scope counters across matching time windows if available.

No engine modifications or timing runs were made by this analysis subagent. Reproducible JSON calculations are alongside this note.

## Additional source finding: removed natural turns are being backfilled

The preserved prototype's `src/map/MapStep.cpp`, lines585–592, explicitly preserves the natural field's round-robin turn even when adaptive mode suppresses its propagation:

```
if (!gradientRuntime->demandEnabled) { dispatch(...); }
// Preserve rotation turns for other field families.
gradientUpdated[t][r][s]=true;
return;
```

Final integrated `stagePeriodicGradientPreparation()` removes natural ground keys from that round-robin entirely: its natural loop starts at `AIR_MOVEMENT_CLASS`. Market/guard/clear jobs can now fill the single FIFO admission on boundaries that used to be deliberately idle natural turns, while accepted natural adaptive jobs run alongside them. This is a materially different scheduler from the measured research policy. It can erase savings by replacing rejected natural work with faster periodic work in other families; requires instrumented counts and controlled turn-preservation ablation to quantify.

Historical first-sweep all resource/area pipeline jobs per tick:

|State|Rotation total|A32 total|Rotation natural|A32 natural|Rotation other|A32 other|
|---|---:|---:|---:|---:|---:|---:|
|isles64duel|.99993|.43245|.59374|.02920|.40620|.40325|
|river1284ffa|.99996|.33430|.73318|.05634|.26678|.27796|
|river2564v4|.99998|.43609|.74713|.18138|.25285|.25471|
|savannah25616ffa|.99999|.46634|.77431|.25407|.22568|.21228|

Other-family job rates remained roughly constant in research; total jobs fell sharply. Final job counts often exceed one per tick, consistent with this changed scheduling, though those are different maps/populations and cannot alone prove attribution.

## Generation bridge verification

`generator-bridge-source.json` compares123 River/core/shared generator files from the exact prototype source archive against currentmaster3d896. Only two differ: `core/GenerationValidation.cpp` and `shared/Settlements.cpp`, both replacing slot-array entity counting with equivalent live population traversal. River generator code, shared map primitives and core defaults are byte-identical. Historical generation log reports river revision5. Commands had no nondefault generator parameters:

```
MASTER_BINARY map generate river --seed 385001 --width 128 --height 128 --teams 4 --output OUTPUT_2002
MASTER_BINARY map generate river --seed 385002 --width 256 --height 256 --teams 8 --output OUTPUT_2003
```

Map container hashes will change with saveformat. Terrain/object plane equivalence remains to be verified independently if claiming exact initial-state identity across binary generations.

## Shared-ancestor map format and available generator

The actual Git common ancestor of prototype parentdd493 and finaldf253 is `dd493d7e71d21e5ab6cbaee0fe168a37e076860a`. It writes format164. Prototype source writes165, not169; directly parsing the gzip2002map header confirms0xa5=165. The prototype appended movement counts under format>=165, while final integration moved that gate to174. Thus research165containers carry an incompatible nonreleased statistics layout; both readers should accept released commonbase164maps without those extra fields. Avoid editing binary headers.

No exact pristine commonbase executable has been identified yet. An existing generator-only candidate is `/home/bradley/glob2/artifacts/hiring-refresh-shortlists-20261015/bin/glob2-frozen` (SHA8cf38bd6427b776e3bd41e0c14cd834464d7ba0f40c5f4fc76d31b2ad5910a4c). Its source.json records basedd493, and recorded Version.h SHA`c7dc32b52034a662bbe449bfaeb57c0616e69699774cee1a9382c453fcf13d57` matches Gitdd493 exactly. Its experimental patch changes hiring/telemetry, not map generators or TeamStat serialization. It is therefore a candidate for generating common164input maps, not a valid pristine commonbase runtime benchmark binary. Verify both readers load its output, and preserve the source/binary provenance if used. A clean dd493build is preferable if strict executable provenance is desired.

## Candidate cause of different Linux/Mac River geometry

Observed common164Linux-generated and current173Mac-generated River maps are different, despite matching generator source. Do not claim they reconstruct identical terrain. Same-file loading still makes the policy comparison fair within each shared input.

`HeightMap::makeRiver` computes float meander offset then `reachedPointX/Y`, and calls `lower((unsigned int)reachedPointX,(unsigned int)reachedPointY)`. At t=0, noise(0)=0, so winding offset is approximately−350 and Y is−87.5×cos(direction); for horizontal/diagonal rivers that is negative. Converting a negative floating-point value whose truncated integer is outside unsigned range has undefined behavior in C++. Common x86 conversion sequences wrap via signed integer, while AArch64 unsigned floating-point conversion instructions can saturate atzero. That can turn a toroidal meander into clamped geometry and alter hundreds of tiles. This is a concrete source-level candidate, not yet an experimentally proven explanation for these particular two mapfiles.

`river-negative-coordinate-cast.cpp` provides a tiny isolated diagnostic for each compiler/architecture. A signed representable conversion followed by explicit unsigned wrap produces a defined comparison. Confirm by generating currentmaster on Linux and comparing with common164 on Linux; compare old165 categorical export using its own compatible reader. This source issue is independent of adaptive runtime scheduling and should not be silently fixed in benchmark inputs.

The isolated seed probe now confirms the actual385001 trajectory begins with the offending coordinate. Named heightmap seed71533194; first external draw initializes noise with2976462499, start(22,24), directionChoice1(horizontal), direction(1,0), first reachedpoint(0,−87.5). On Appleclang21arm64 atO3, direct float→unsigned yields(0,0), whereas defined signed-then-unsigned wrap yieldsY4294967209, toroidalY41. UBSan float-cast-overflow reports the direct conversion as out of representable range. Commands and logs are under `map-generation/mac-first-results.json` and `mac-results.json`. Linux comparison is queued until controlled timing is idle. This establishes an actual source portability defect affecting the seed; the full geometry difference still needs same-platform generation comparison before attribution.

Linux confirmation is now complete, executed only while controlled coordinator reported `phase=build, active=no-reactive` both before and after. GCC13.3x86_64 atO3 converts−87.5 directly to4294967209 (mod128=41); Appleclang21arm64 atO3 converts it to0 (mod128=0). Both UBSan builds report out-of-range float→unsigned. Actual385001first-coordinate probes show identical seeded stream/direction and opposite conversion results. `map-generation/linux-results.json`, `mac-results.json`, `mac-first-results.json` preserve exact commands, compiler/platform, stdout and diagnostics; `source-provenance.json` records the production file hash and relevant lines. This proves a generator portability defect at this seed. Attribution of the full map delta remains qualified pending same-platform full generation. No production generator changes made.
