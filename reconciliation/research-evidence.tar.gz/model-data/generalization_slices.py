import csv,gzip,json,pathlib,collections,numpy as np,sys,importlib.util
P=pathlib.Path(__file__).resolve().parent;A=pathlib.Path('/Users/bradley/glob2/artifacts/gradient-training-1024');manifest=json.loads((A/'training-manifest-512.json').read_text());a=np.load(P/'row-predictions.npz');meta=[]
for r in manifest:
 with gzip.open(r['episodes'],'rt') as f:
  n=sum(s['complete']=='1' for s in csv.DictReader(f))
 meta.extend([{'group':r['map_group'],'format':r['format'],'generator':r['spec']['generator'],'size':f"{r['spec']['width']}x{r['spec']['height']}",'collection':r['group']}]*n)
assert len(meta)==len(a['raw'])
s=importlib.util.spec_from_file_location('m','/Users/bradley/.codex/worktrees/adaptive-final-integration/glob2/tools/resource_gradient_model.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
held=a['heldout'];w=np.zeros(len(meta));w[held]=m.weights([r for r,b in zip(meta,held) if b]);y=a['target'];pred={'old':a['old'],'new':a['new']}
def metrics(mask):
 d={'episodes':int(mask.sum()),'heldout_maps':len({r['group'] for r,b in zip(meta,mask) if b}),'development_maps':0}
 if not mask.any():return d
 for name,p in pred.items():
  take=mask&(p>=32);positive=mask&(y>0)
  d[name]={'mae':float(np.average(abs(p[mask]-y[mask]),weights=w[mask])),'mse':float(np.average((p[mask]-y[mask])**2,weights=w[mask])),'selected_pct':100*float(np.average(p[mask]>=32,weights=w[mask])),'selected_mean_actual_benefit':float(np.average(y[take],weights=w[take])) if take.any() else None,'positive_benefit_capture_pct':100*float(sum(w[take]*np.maximum(y[take],0))/sum(w[positive]*y[positive])) if positive.any() else None}
 return d
out={}
for key in ['generator','size','format']:
 out[key]={}
 for v in sorted({r[key] for r in meta}):
  match=np.array([r[key]==v for r in meta]);d=metrics(match&held);d['development_maps']=len({r['group'] for r,b in zip(meta,match&~held) if b});out[key][v]=d
(P/'generalization-slices.json').write_text(json.dumps(out,indent=2)+'\n')
focus=['city-states','hilbert-river','coral','everglades','spider-web','stone-highlands','fjord-continent'];lines=['| Generator | Development/heldout maps | Old→new MAE | Old→new ≥32 | Old→new positive benefit captured |','|---|---:|---:|---:|---:|']
for g in focus:
 d=out['generator'][g];o=d.get('old');n=d.get('new')
 if o:
  lines.append(f"|{g}|{d['development_maps']}/{d['heldout_maps']}|{o['mae']:.2f}→{n['mae']:.2f}|{o['selected_pct']:.3f}%→{n['selected_pct']:.3f}%|{o['positive_benefit_capture_pct']:.2f}%→{n['positive_benefit_capture_pct']:.2f}%|")
 else:lines.append(f"|{g}|{d['development_maps']}/0|—|—|—|")
(P/'generalization-table.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
for key in ['format','size']:
 print(key)
 for name,d in out[key].items():print(name,d)
