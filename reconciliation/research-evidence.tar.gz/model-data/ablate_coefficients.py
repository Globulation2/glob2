import numpy as np,json,pathlib,copy,importlib.util
P=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('m','/Users/bradley/.codex/worktrees/adaptive-final-integration/glob2/tools/resource_gradient_model.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
old=json.loads((P.parent/'code/yesterday-model.json').read_text());new=json.loads(pathlib.Path('/Users/bradley/glob2/artifacts/gradient-training-1024/fit-512/model.json').read_text());data=np.load(P/'row-predictions.npz');raw=data['raw'];w=data['weights'];X=np.empty_like(raw)
for j in range(7):
 u,inv=np.unique(raw[:,j],return_inverse=True);X[:,j]=np.array([m.log_integer(i) for i in u])[inv]
def trunc(a,d):return np.sign(a)*(np.abs(a)//d)
def sigmoid(z):
 n=np.clip(z,-12000,12000)+12000;i=np.minimum(n//50,479);ss=np.array(m.SIG);return ss[i]+(ss[i+1]-ss[i])*(n-i*50)//50

def predict(model):
 h={k:np.clip(trunc(X@np.array(model[k]['coef'])+model[k]['bias'],1<<model[k]['shift']),-10**9,10**9) for k in m.HEADS};return trunc(sigmoid(h['positive_probability'])*np.maximum(h['positive_mean'],0)-sigmoid(h['negative_probability'])*np.maximum(h['negative_mean'],0),65536)/1000
out=[]
for label,source,target in [('old_base_swap_one_new',old,new),('new_base_revert_one_old',new,old)]:
 for j,key in enumerate([*m.FEATURES,'bias','all']):
  model=copy.deepcopy(source)
  for h in m.HEADS:
   if key=='bias':model[h]['bias']=target[h]['bias']
   elif key=='all':model=target
   else:model[h]['coef'][j]=target[h]['coef'][j]
  pred=predict(model);out.append({'experiment':label,'feature':key,'mean_prediction':float(np.average(pred,weights=w)),'selected_pct':float(np.average(pred>=32,weights=w)*100)})
(P/'coefficient-ablation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
