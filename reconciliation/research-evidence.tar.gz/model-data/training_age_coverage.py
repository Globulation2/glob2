import numpy as np,pathlib,json,csv,gzip
P=pathlib.Path(__file__).resolve().parent;A=pathlib.Path('/Users/bradley/glob2/artifacts/gradient-training-1024');d=np.load(P/'row-predictions.npz');raw=d['raw'];w=d['weights'];held=d['heldout'];qs=[]
for r in json.loads((A/'training-manifest-512.json').read_text()):
 with gzip.open(r['episodes'],'rt') as f:qs.extend(int(s['queries']) for s in csv.DictReader(f) if s['complete']=='1')
qs=np.array(qs);assert len(qs)==len(raw)
def stats(mask,base):
 n=int(mask.sum());den=int(base.sum());return {'episodes':n,'raw_pct':100*n/den if den else None,'balanced_pct':100*float(w[mask].sum()/w[base].sum()) if w[base].sum() else None,'mean_future_queries_raw':float(qs[mask].mean()) if n else None,'mean_future_queries_balanced':float(np.average(qs[mask],weights=w[mask])) if n else None,'positive_target_raw_pct':100*float((d['target'][mask]>0).mean()) if n else None,'mean_target_balanced':float(np.average(d['target'][mask],weights=w[mask])) if n else None,'max_age':int(raw[mask,0].max()) if n else None}
out={}
for split,base in [('all',np.ones(len(raw),bool)),('development',~held),('heldout',held)]:
 out[split]={}
 for q,mask in [('all',base),('q128_zero',base&(raw[:,2]==0)),('q128_ge1',base&(raw[:,2]>=1)),('q128_ge8',base&(raw[:,2]>=8)),('q128_ge32',base&(raw[:,2]>=32)),('q128_ge128',base&(raw[:,2]>=128)),('q32_ge8',base&(raw[:,1]>=8)),('q32_ge32',base&(raw[:,1]>=32)),('q32_ge128',base&(raw[:,1]>=128))]:
  report={'population':stats(mask,base),'age_above':{}}
  for age in [128,136,144,256,512,1024,4096]:report['age_above'][str(age)]=stats(mask&(raw[:,0]>age),mask)
  out[split][q]=report
old=np.load(P/'old-row-predictions.npz');o=old['raw'];out['old_raw']={'episodes':len(o),'max_age':int(o[:,0].max()),'age_above':{str(age):{'episodes':int((o[:,0]>age).sum()),'raw_pct':100*float((o[:,0]>age).mean())} for age in [128,136,144,256,512,1024,4096]},'high_query_age_above':{str(q):{str(age):int(((o[:,0]>age)&(o[:,2]>=q)).sum()) for age in [128,136,144,256,512,1024,4096]} for q in [1,8,32,128]}}
(P/'training-age-coverage.json').write_text(json.dumps(out,indent=2)+'\n')
for split in ['all','heldout']:
 print(split)
 for q,v in out[split].items():print(q,'population',v['population']['episodes'],'maxage',v['population']['max_age'],'age-above',[(k,x['episodes'],round(x['balanced_pct'],5) if x['balanced_pct'] is not None else None,round(x['mean_future_queries_balanced'],2) if x['mean_future_queries_balanced'] is not None else None) for k,x in v['age_above'].items()])
print('oldraw',out['old_raw'])
