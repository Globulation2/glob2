# Feature and label contract audit: prototype → 512 collector → final engine

Audited preserved historical source `d860c600ae1c84c90d644907650cfae0a596272d`, original512collector `e9713dc8b82745daa4c6665842bdd2e9724a8319`, recovery collector `f58a3c20dc3791dcda0eb20cab73cc308e762243`, and final `df25376f8b681dcd8d87dd6832b4e93a935cad96`. Historical source was extracted from the verified preserved full-source archive. `contract-source-hashes.json` proves ResourceGradientPolicy.h, ResourceGradientProbe.cpp and the permanent fitter are each byte-identical across the two512collector cohorts and final. Thus no seven-feature construction drift occurred between collection and export/runtime in those files.

## Main result

**No feature reordering, unit conversion, source-turnover definition, rolling-window off-by-one or log-preprocessing discrepancy was found.** There is one real **label-time** difference between the historical and current observation architecture: historical scores future offsets7..31, current scores8..31 at the default delay. It matches a change in actual capture/publication boundary ordering, rather than a newly invented scale.

There are substantial **population and policy-environment changes**, and an objective mismatch between average prediction error and the compute/quality frontier. They warrant controlled model-only tests. They do not establish a need for a mixture of experts, and the same-input results do not support the claim that the refit directly requests more rebuilds.

## Exact seven-feature meanings

| Feature | Historical construction | Current construction | Finding |
|---|---|---|---|
|age|`tick-demand.serving`, where serving is immutable capture tick, updated when the field publishes|`tick-field.serving.tick`, captured from foundation.tick and published with job.capture|Same meaning: capture age, not publication age and not last-submission age|
|q32|Count all natural-ground pathfindMaterial queries satisfying unsigned tick-query.tick<32|128 ring, expired at exact32, increment once for each natural-ground owner movement query|Same inclusive window tick through tick-31|
|q128|Same, <128|Expired at exact128|Same inclusive window tick through tick-127|
|source_added/removed|Positive-stock tile zero-crossing epochs since serving capture|Same source epoch differences|Counts tiles crossing zero, not units of material consumed; all-map counters, not team-visible/reachable sources|
|source_added_frac_q12/source_removed_frac_q12|`min(1e6, min(1e6,delta)*4096/max(1,captured.count))`|Same|Denominator is source count at capture, never current source count|

Historical references: `code/historical/src/map/gradient/ResourceExperiment.h:27–35`; `model-data/contract-sources/historical-GradientRuntime.h:46–56`; historical `MapStep.cpp:283,344`; historical `MapGradientMaterial.cpp:82–83`. Current: `src/map/gradient/ResourceGradientPolicy.h:36–59,74–79`; `src/map/MapStep.cpp:275–277,333–335`.

The historical CSV stores bounded raw deltas and captured source count; fit.py derives fractions by4096/captured.count. Historical collector asserts its derived seven inputs equal the runtime adaptiveInputs for known captures (`MapPathfindMaterial.cpp:155–159`). Current collector copies the exact runtime policy field and calls inputs on that copy (`ResourceGradientProbe.cpp:55–58`). The largest observed old/new raw source delta is534/1568, nowhere near the1e6 clamp; no clamp-order ambiguity affects these datasets.

`check_counter_contract.py` exercises the literal final ring expiration against historical deque filtering on100,000 observations with550,923 simulated queries, including same-tick queries, long gaps, exact32/128 boundaries and uint32 wrap: **PASS**. This is a small semantic diagnostic independent of the engine's existing C++ tests, not a new production test.

Near-goal distance, mean gradient cost, material ID, class ID, class population, obstacle/visibility generation deltas and source-count levels existed in the old research CSV but **were not selected as inputs** to the seven-feature model. Their removal from the compact CSV does not change model semantics.

## Movement/query ownership and missing domain

Historical `pathfindMaterial` increments the deque only when the selected gradient equals the team's natural material field; forbidden reads still count but do not request adaptive refresh (`MapPathfindMaterial.cpp:24–27,55–61`). Final applies the same count/request distinction, adds explicit ground/owner/nonnull checks needed for master AIR and cold FIFO, and copies the RNG only with collection enabled (`src/map/pathfind/MapPathfindMaterial.cpp:20–33,79–82`). No evidence was found that worker jobs supplied historical movement-query samples; material movement decisions are owner simulation calls. The extra guards narrow unsupported execution contexts rather than rename q32/q128.

**Distance-only request enrollment is a runtime-policy change, not a q32/q128 feature change.** Final scalar distance/availability reads can set requested without incrementing either count. It was added after the frozen512collection source. Neither old nor current episode populations include never-movement-observed distance-only fields: stageEpisodes iterates probe fields created by movement observe, requires movement lastQuery within128ticks and a256-tick warmup. Consequently this additional demanded domain is not represented in the fitting labels. A score nearzero does not prevent such demanded fields refreshing at the hard128 cap. This is a meaningful train/runtime environment gap even though individual feature values retain their definitions.

## Label and sampling contract

Both collectors use deterministic1,024-tick windows every4,096ticks, hash-sample1/8 of field keys per window, wait256ticks after the field is first seen, require a movement query within128ticks and at least8ticks since last submission, and stage at most one episode per field per32ticks. Both require active movement class, a remaining source slot and an existing live natural field.

For each episode they copy the serving field (defer) and build a full private field from the episode's current state (refresh). They retain both arrays. On later *actual live-policy positions and queries*, they score directions selected using copies of the same unit RNG against a private fresh reference rebuilt for each query. Labels accumulate **extra direction cost**; target is `defer_extra-refresh_extra`. They do not roll out hypothetical unit trajectories under the two arrays. False-unreachable, missed-move, depleted-goal and other flags are diagnostics, not added penalties in this target. In particular recruitment availability benefit and all unscored no-move cases are outside the fitted target.

Concrete target-time change:

- Historical `MapPathfindMaterial.cpp:279`: `tick>=e.tick+7`; finished episodes are removed at+32 before scoring, giving offsets7..31,25possible tick offsets.
- Current `ResourceGradientProbe.cpp:131`: `tick-e.tick>=e.delay && tick-e.tick<32`; normaldelay8, giving offsets8..31,24possible offsets.
- This corresponds to architecture: historical Game_sync stages after stepCounter++ but the periodic pipeline advances at the next sync's start, making nominal8 pipeline advances publish at capture+7 gameplay tick. Current `GameAI.cpp:57–80` publishes before capture and submits from that same completed observation (`ResourceGrowth.cpp:555–572`), making capture-to-gameplay publication8ticks. The new target uses the new actual delay.

The target horizon is therefore similar but not byte-for-byte equivalent between old and new datasets. Existing aggregate CSVs cannot retrospectively remove offset7 from old labels because they do not retain per-offset label contributions. One early tick can matter for individual examples, but there is no evidence it accounts for the large CPU difference. Average future query count is almost unchanged: old4.3348 vs new4.3077 per balanced complete episode.

Current collector flushes completed quiet episodes during staging (`ResourceGradientProbe.cpp:36–40`) rather than waiting for another query. Historical final/window flush already retained complete quiet episodes (`MapPathfindMaterial.cpp:93–100,264–266`); no demonstrated systematic dropping of zero-query examples was found. Both exclude incomplete episode tails. Current probe calls inputs on a copy to avoid expiring authoritative rings merely because collection is on. Historical deque features are const reads. Published per-tick collector-on/off equivalence checks support this observational contract.

## Quantified distribution/support changes

`compare_training_populations.py` recovered the exact original246,924 complete, known-capture episodes used by yesterday's model:231diverse-policy collection games plus16original Playground games,32development/8heldout starting states. It reproduces old fit weighting. New data is476,107complete episodes,374development/126heldout labelled map groups, drawn from512games/67actual generators.

| Balanced development population | Old training | New training |
|---|---:|---:|
|Mean capture age|67.24|79.90|
|Mean q32|5.61|5.93|
|Mean q128|23.18|24.45|
|Mean added sources|5.16|5.32|
|Mean removed sources|5.54|3.90|
|Mean added fraction Q12|22.57|11.38|
|Mean removed fraction Q12|26.15|17.23|
|Positive-benefit episodes|14.69%|10.82%|
|Mean actual target|5.048|3.170|
|Old model score≥32|2.955%|1.221%|
|New model score≥32|1.588%|0.558%|

These shifts precede coefficient replacement: the same old model selects much less often in the new observations. q32/q128 means barely change, while turnover fractions and benefit prevalence change substantially. Different AI behavior, generators, dimensions and underlying scheduler affect this distribution. Raw new inputs extend some old support (age1053vs1039,q32289vs223,q1281141vs897,sourceadded1568vs343,fractions4096vs2048), but stay far below all integer clamps. Target tails extend from old[-656,1150] to new[-778,2298].

Old scenarios were fixed square64/128/256 maps from Playground,isles,river,old-town,savannah, predominantly Nicowar; policies repeated the same small set of map/game states. New tournament balances eight format buckets and samples map dimensions, generators, rosters and parameters broadly, including rectangles and512dimensions. Weights are equal **format** in the new fitter, equal **scenario** in old (a scenario fixes format+generator+size). These are not the same population objective.

Current final benchmark is another shift: eight maps with Cabino throughout; these are not the same rosters/maps used in historical Nicowar comparisons. There is no claim that every generator or roster lies outside new training support; the point is that conditional distribution is different.

## Fitting, splits and objective

The fitting family is unchanged: log2(1+x)Q12 seven features; weighted training-fold standardization; positive/negative LogisticRegression(C=1) probabilities and conditional Ridge(alpha=100) magnitudes; four exported integer heads; fixed threshold32000. Both normalize weights to training row count. With more rows, a fixed alpha/C does not preserve identical effective data-to-penalty ratio, although this is ordinary refitting behavior, not a feature-unit bug. The new fitter adds constant-class guards for tiny datasets; those are irrelevant to this full corpus.

Old split holds out the fourth replicate of each of eight fixed scenarios; original Playground data stays in development. Earlier reports had inspected those heldout states. New split groups map identity globally (generator/dimensions/player count/map seed/parameters), keeps roster swaps together, stratifies formats with fixed seeds, and creates three grouped development CV folds. It prevents episode leakage across the same map. It is **not leave-generator-out**, leave-size-out or leave-engine-version-out validation and does not by itself demonstrate robustness to future rules or new generators.

The four-head fit optimizes logistic likelihood and conditional squared error, not CPU savings. MAE is an evaluation statistic, not the training loss and not the scheduler frontier objective. On the original eight heldout states, the new model also **improves MAE7.561→7.038** while worsening MSE535.849→551.707. It is not simply a model that forgot the old data. On new heldout126maps, MAE6.119→5.581 while positive-benefit capture at threshold32 falls16.05%→11.73%. A threshold calibrated for old coefficients/old environment does not transfer automatically.

Most importantly, across all476,107new frozen observations the final model's threshold-selected set is a strict subset of the old model's set, with **zero new-only selections**. Lower scores from refitting can change quality and downstream trajectories, but do not directly explain more immediate rebuild admissions on these observations. Count actual model/cap/reactive/FIFO/other-family admissions in the controlled model-only run before assigning cause or designing experts.
