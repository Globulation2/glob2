# Actual accepted adaptive inputs: coefficient versus cap

Copied completed `audit.json.decisions.csv` and sibling counters from the controlled Linux campaign to `runtime-inputs/`, then evaluated both exact integer predictors locally on Mac. No Linux analysis workload was started. `analyze_admission_csv.py` checks its vectorized scores against permanent scalar prediction, retains source hashes, and writes classified rows. `summarize_actual_admissions.py` separates legacy migration and later windows.

These CSV rows are **successful warm adaptive request enrollments**, not every attempted request or every periodic gradient. Parent counters may report many more cap attempts because already queued destinations coalesce. Reactive/cold/area/AIR work is excluded here and appears in `audit.json` instead.

## Final policy, fresh River game

River starts from tick0, avoiding the released173checkpoint migration issue.

|Accepted warm adaptive work|Count|
|---|---:|
|Hard-cap admissions|3,379(97.89%)|
|Model admissions|73(2.11%)|
|Model admissions selected by both old and final models|73|
|Final-only selected admission|0|
|Cap admissions with q32=0|1,738(51.44% of cap)|
|Cap admissions with q32=q128=0|1,490(44.10% of cap)|

Of the cap rows,3,347score below32 in both models and32score above32 only in yesterday's model. All actual model admissions are in the shared selected set. The final coefficient update is not causing extra immediate threshold admissions in these observed states.

More than half the cap rows have no movement query in the last32ticks, and44.1%have none in128ticks. With requested cleared each scheduling pass, a recent movement query would produce q32>0. Apart from explicitly separated migration state, these zero-q32 requests demonstrate scalar distance/availability demand rather than movement demand. q32=q128=0 is the stronger, long-idle subset.

The73model admissions have no marginal input outside the frozen training ranges.64have q128/q32 between3and5;9between1.5and3; none are the recent-burst category(q128/q32≤1.5) that produced synthetic final-only counterexamples.

## Final policy,8v8 released-save suffix

This run begins from an old-format checkpoint at tick32768 and ends33792. Newly initialized policy metadata can have very large first submitted ages. Exactly3accepted rows have submitted_age>32768; all are cap rows with zero query counts. Their first ages are32770..32778. These must not be presented as normal steady-state data.

|Window|Accepted cap/model|Cap share|Cap q32=0|Cap both query counts0|Actual final-only selected|
|---|---:|---:|---:|---:|---:|
|Whole suffix|689/6|99.14%|60.96%|53.56%|0|
|After first128ticks(tick≥32896)|686/5|99.28%|60.79%|53.35%|0|
|After first512ticks(tick≥33280)|491/4|99.19%|59.88%|52.14%|0|

All model admissions in every window score≥32 under both coefficient sets. All cap admissions score below32 under both. The zero-movement/cap pattern persists after excluding the three enormous-age migration rows; however a longer warmup is still needed to separate broader transient save effects. Proper2048-tick warmup controls are being collected by the campaign owner.

## Other controls already copied

Preserving historical natural round-robin turns gives River3,494cap+59model and8v8 692cap+4model. No final-only selected observations appear in either. Fixed32controls record all warm admissions as cap, as expected; final/old learned scores are diagnostic there rather than the admission rule.

## What this resolves and does not

These observations **do not support a story that the new coefficients suddenly became more eager and caused excess compute**. Actual learned admissions are tiny relative to cap admissions; the same old model would also approve every observed model-triggered admission. This is stronger evidence than the frozen-episode comparison because it uses actual accepted runtime states.

It does not prove coefficient replacement has zero closed-loop effect. Yesterday's model might have refreshed earlier at states this trajectory never visits, changing subsequent paths and populations. The controlled old-coefficients run is still required for that question. Nor does removing scalar demand automatically become a valid fix: it was added to prevent stale unreachable recruitment answers from persisting without any movement query. The mechanism needs a correctness-preserving policy for that distinct read purpose.

No target labels or pathfinding-quality outcomes are measured in these admission CSVs. They diagnose *what caused rebuilding*, not whether any particular cap refresh was useful.
