import csv,gzip,json,pathlib,collections,importlib.util,numpy as np
P=pathlib.Path(__file__).resolve().parent;A=pathlib.Path('/Users/bradley/glob2/artifacts')
s=importlib.util.spec_from_file_location('m','/Users/bradley/.codex/worktrees/adaptive-final-integration/glob2/tools/resource_gradient_model.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
plan=json.loads((A/'gradient-diverse-confirmation/plan.json').read_text());states={x['seed']:x for x in plan['states']};runs=json.loads((A/'gradient-diverse-confirmation/quality.json').read_text());rows=[]
for run in runs:
 f=P/'old-episodes'/pathlib.Path(run['directory']).name/'episodes.csv.gz'
 with gzip.open(f,'rt') as h:
  for r in csv.DictReader(h):
   if r['complete']!='1' or r['source_capture_known']!='1':continue
   r={k:int(v) for k,v in r.items()};r.update(seed=run['seed'],case=run['case'],scenario=states[run['seed']]['id'],replicate=states[run['seed']]['replicate'],origin='new');rows.append(r)
with gzip.open(A/'gradient-cheap-features/episodes.csv.gz','rt') as h:
 for r in csv.DictReader(h):
  if r['complete']!='1' or r['source_capture_known']!='1':continue
  r={k:v if k in ['case','split'] else int(v) for k,v in r.items()};r.update(scenario='playground-128-8ffa',replicate=-1,origin='original');rows.append(r)
assert len(rows)==246924
old=json.loads((P.parent/'code/yesterday-model.json').read_text());new=json.loads((A/'gradient-training-1024/fit-512/model.json').read_text())
for r in rows:
 for k in ['source_added','source_removed']:r[k+'_frac_q12']=min(1000000,r[k]*4096//max(1,r['source_capture_count']))
raw=np.array([[r[k] for k in m.FEATURES] for r in rows],np.int64);X=np.empty_like(raw)
for j in range(7):
 u,inv=np.unique(raw[:,j],return_inverse=True);X[:,j]=np.array([m.log_integer(i) for i in u])[inv]
def trunc(a,d):return np.sign(a)*(np.abs(a)//d)
def sigmoid(z):
 n=np.clip(z,-12000,12000)+12000;i=np.minimum(n//50,479);ss=np.array(m.SIG);return ss[i]+(ss[i+1]-ss[i])*(n-i*50)//50

def predict(model):
 h={k:np.clip(trunc(X@np.array(model[k]['coef'])+model[k]['bias'],1<<model[k]['shift']),-10**9,10**9) for k in m.HEADS};return trunc(sigmoid(h['positive_probability'])*np.maximum(h['positive_mean'],0)-sigmoid(h['negative_probability'])*np.maximum(h['negative_mean'],0),65536)/1000
pred={'old':predict(old),'new':predict(new)};y=np.array([r['defer_extra']-r['refresh_extra'] for r in rows]);qs=np.array([r['queries'] for r in rows]);out={}
for label,mask in [('all',np.ones(len(rows),bool)),('development',np.array([r['replicate']!=3 for r in rows])),('heldout',np.array([r['replicate']==3 for r in rows]))]:
 rr=[r for r,b in zip(rows,mask) if b];counts=collections.Counter((r['scenario'],r['seed'],r['case']) for r in rr);ss=collections.defaultdict(set);cc=collections.defaultdict(set)
 for sc,seed,c in counts:ss[sc].add(seed);cc[sc,seed].add(c)
 w=np.array([1/(len(ss[r['scenario']])*len(cc[r['scenario'],r['seed']])*counts[r['scenario'],r['seed'],r['case']]) for r in rr]);avg=lambda v:float(np.average(v[mask],weights=w))
 d={'episodes':len(rr),'states':len({r['seed'] for r in rr}),'scenarios':sorted(ss),'mean_episode_queries':avg(qs),'positive_pct':100*avg(y>0),'nonzero_pct':100*avg(y!=0),'mean_actual_benefit':avg(y),'input_mean':{k:avg(raw[:,j]) for j,k in enumerate(m.FEATURES)},'input_percentiles_raw':{k:np.percentile(raw[mask,j],[0,25,50,75,90,95,99,100]).tolist() for j,k in enumerate(m.FEATURES)},'models':{}}
 for name,p in pred.items():d['models'][name]={'mean_prediction':avg(p),'selected_pct':100*avg(p>=32),'mae':avg(abs(p-y)),'mse':avg((p-y)**2)}
 out[label]=d
(P/'old-population.json').write_text(json.dumps(out,indent=2)+'\n');np.savez_compressed(P/'old-row-predictions.npz',raw=raw,old=pred['old'],new=pred['new'],target=y,queries=qs)
print(json.dumps(out,indent=2))
