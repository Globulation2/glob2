"""Counter-score accepted warm adaptive admissions; never run on the timing host."""
import argparse,csv,gzip,json,pathlib,collections,importlib.util,hashlib
import numpy as np
P=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('m','/Users/bradley/.codex/worktrees/adaptive-final-integration/glob2/tools/resource_gradient_model.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
models={'old':json.loads((P.parent/'code/yesterday-model.json').read_text()),'new':json.loads(pathlib.Path('/Users/bradley/glob2/artifacts/gradient-training-1024/fit-512/model.json').read_text())}
training=np.load(P/'row-predictions.npz')['raw'];maxima=training.max(axis=0);minima=training.min(axis=0)
def transformed(raw):
 X=np.empty_like(raw)
 for j in range(7):
  u,inv=np.unique(raw[:,j],return_inverse=True);X[:,j]=np.array([m.log_integer(v) for v in u])[inv]
 return X

def trunc(a,d):return np.sign(a)*(np.abs(a)//d)
def sigmoid(z):
 n=np.clip(z,-12000,12000)+12000;i=np.minimum(n//50,479);ss=np.array(m.SIG);return ss[i]+(ss[i+1]-ss[i])*(n-i*50)//50

def predict(model,X):
 h={k:np.clip(trunc(X@np.array(model[k]['coef'])+model[k]['bias'],1<<model[k]['shift']),-10**9,10**9) for k in m.HEADS};return trunc(sigmoid(h['positive_probability'])*np.maximum(h['positive_mean'],0)-sigmoid(h['negative_probability'])*np.maximum(h['negative_mean'],0),65536)
def hist(a):return dict(sorted(collections.Counter(map(str,a)).items()))
def burst(raw):
 q=raw[:,1];r=raw[:,2];return np.select([q==0,r*2<=q*3,r<q*3,r<=q*5],['zero_q32','recent_burst_ratio_le_1.5','ratio_1.5_to_3','steady_ratio_3_to_5'],default='falling_ratio_gt_5')
def selection(old,new):return np.select([(old>=32000)&(new>=32000),(old>=32000)&(new<32000),(old<32000)&(new>=32000)],['both','old_only','new_only'],default='neither')
# Coarse powers-of-two bins; this is a support diagnostic, never a probabilistic OOD test.
trainbins=transformed(training)//4096;support=set(map(tuple,trainbins.tolist()))
parser=argparse.ArgumentParser();parser.add_argument('paths',nargs='+');parser.add_argument('--out',type=pathlib.Path,required=True);args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
allout={}
for filename in args.paths:
 path=pathlib.Path(filename)
 with (gzip.open(path,'rt') if path.suffix=='.gz' else path.open()) as f:rows=[{k:int(v) for k,v in r.items()} for r in csv.DictReader(f)]
 label=path.parent.name if path.name=='audit.json.decisions.csv' else path.stem
 if not rows:allout[label]={'admissions':0};continue
 raw=np.array([[r[k] for k in m.FEATURES] for r in rows],np.int64);X=transformed(raw);scores={k:predict(v,X) for k,v in models.items()};kind=selection(scores['old'],scores['new']);cap=np.array([r['cap'] for r in rows],bool);bu=burst(raw);outside=((raw<minima)|(raw>maxima)).any(axis=1);unsupported=np.array([tuple(x) not in support for x in X//4096]);qzero=raw[:,1]==0
 for name,model in models.items():
  for i in np.linspace(0,len(raw)-1,min(1000,len(raw))).astype(int):assert int(scores[name][i])==m.predict(model,raw[i])
 d={'path':str(path.resolve()),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'admissions':len(rows),'unique_fields':len({r['key'] for r in rows}),'ticks_min_max':[min(r['tick'] for r in rows),max(r['tick'] for r in rows)],'cap_admissions':int(cap.sum()),'model_admissions':int((~cap).sum()),'cap_fraction_pct':float(cap.mean()*100),'classification_all':hist(kind),'classification_cap':hist(kind[cap]),'classification_model':hist(kind[~cap]),'burst_all':hist(bu),'burst_new_only':hist(bu[kind=='new_only']),'burst_model_new_only':hist(bu[(kind=='new_only')&~cap]),'q32_zero_count':int(qzero.sum()),'q32_q128_both_zero_count':int(((raw[:,1]==0)&(raw[:,2]==0)).sum()),'outside_any_training_marginal_count':int(outside.sum()),'outside_coarse_joint_bins_count':int(unsupported.sum()),'new_only_outside_coarse_joint_bins_count':int((unsupported&(kind=='new_only')).sum()),'input_percentiles':{k:np.percentile(raw[:,j],[0,25,50,75,90,95,99,100]).tolist() for j,k in enumerate(m.FEATURES)},'submitted_age_percentiles':np.percentile([r['submitted_age'] for r in rows],[0,25,50,75,90,95,99,100]).tolist(),'new_only_examples':[],'note':'Accepted warm adaptive enrollment only. Reactive/cold/FIFO/area/AIR work absent; count those from sibling audit.json. Model-only classifications counter-score one actually visited state, not closed-loop counterfactual runs. Coarse support bins have no calibrated OOD meaning.'}
 for i in np.where(kind=='new_only')[0][:30]:d['new_only_examples'].append({**rows[int(i)],'old_score_milli':int(scores['old'][i]),'new_score_milli':int(scores['new'][i]),'burst':str(bu[i]),'outside_coarse_training_bins':bool(unsupported[i])})
 with gzip.open(args.out/(label+'-classified.csv.gz'),'wt',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=[*rows[0],'old_score_milli','new_score_milli','classification','burst','outside_marginal','outside_coarse_joint_bins']);writer.writeheader()
  for i,row in enumerate(rows):writer.writerow({**row,'old_score_milli':int(scores['old'][i]),'new_score_milli':int(scores['new'][i]),'classification':kind[i],'burst':bu[i],'outside_marginal':int(outside[i]),'outside_coarse_joint_bins':int(unsupported[i])})
 allout[label]=d;print(label,'admissions',len(rows),'cap%',round(d['cap_fraction_pct'],2),'modelclasses',d['classification_model'],flush=True)
(args.out/'summary.json').write_text(json.dumps(allout,indent=2)+'\n')
