import itertools,json,pathlib,importlib.util,numpy as np
P=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('m','/Users/bradley/.codex/worktrees/adaptive-final-integration/glob2/tools/resource_gradient_model.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
old=json.loads((P.parent/'code/yesterday-model.json').read_text());new=json.loads(pathlib.Path('/Users/bradley/glob2/artifacts/gradient-training-1024/fit-512/model.json').read_text());rr=[];den=[]
for age,q,mult,added,removed,count in itertools.product([8,16,32,64,96,128],[0,1,4,8,16,32,64,128,256,512,1024],[1,2,4,8],[0,1,4,16,64,256,1024],[0,1,4,16,64,256,1024],[1,8,64,512,4096,32768]):
 if removed>count+added:continue
 r=(age,q,q*mult,added,removed,min(1000000,added*4096//count),min(1000000,removed*4096//count))
 rr.append(r);den.append(count)
raw=np.array(rr,np.int64);X=np.empty_like(raw)
for j in range(7):
 u,inv=np.unique(raw[:,j],return_inverse=True);X[:,j]=np.array([m.log_integer(i) for i in u])[inv]
def trunc(a,d):return np.sign(a)*(np.abs(a)//d)
def sigmoid(z):
 n=np.clip(z,-12000,12000)+12000;i=np.minimum(n//50,479);ss=np.array(m.SIG);return ss[i]+(ss[i+1]-ss[i])*(n-i*50)//50

def predict(model):
 h={k:np.clip(trunc(X@np.array(model[k]['coef'])+model[k]['bias'],1<<model[k]['shift']),-10**9,10**9) for k in m.HEADS};return trunc(sigmoid(h['positive_probability'])*np.maximum(h['positive_mean'],0)-sigmoid(h['negative_probability'])*np.maximum(h['negative_mean'],0),65536)/1000
po=predict(old);pn=predict(new);newonly=(pn>=32)&(po<32);inside=(raw<=np.array([1053,289,1141,1568,514,4096,4096])).all(axis=1)
def sample(mask):
 idx=np.where(mask)[0];idx=sorted(idx,key=lambda i:(max(raw[i,5:]),raw[i,0],raw[i,1],max(raw[i,3:5])))[:20]
 return [{'inputs':raw[i].tolist(),'captured_sources':int(den[i]),'old_score':float(po[i]),'new_score':float(pn[i])} for i in idx]
out={'points':len(raw),'new_only':int(newonly.sum()),'old_only':int(((po>=32)&(pn<32)).sum()),'new_only_within_marginal_observed_ranges':int((newonly&inside).sum()),'new_only_examples':sample(newonly),'new_only_examples_inside_marginal_ranges':sample(newonly&inside),'new_only_examples_sources_le_4096':sample(newonly&inside&(np.array(den)<=4096)&(raw[:,0]<128)),'warning':'Handchosen synthetic grid, not frequency/likelihood or joint support. Physical count>=0 constraint only. Some tuples are far outside observed joint domain. No actual observed final-only selections existed.'}
(P/'out-of-support-grid.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
