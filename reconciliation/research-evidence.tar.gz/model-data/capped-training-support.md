# Was training support censored by the cap?

**Yes, especially for fields with sustained recent demand.** This supports a train/deployment support explanation for the *no-cap experiment*, not an explanation by itself for the earlier capped master/PR CPU comparison.

`training_age_coverage.py` joins the frozen476,107complete episodes to their future-query counts, evaluates raw and balanced mass in age×demand slices, and retains heldout counts separately. `training-age-coverage.json` is the full reproducible table. Reported balanced percentages condition the original full-dataset format/map/collection/episode weights; heldout conditional percentages use the same original weights restricted to heldout, rather than a newly rebalanced population.

## Frozen512 corpus

|Capture age|Episodes|Raw percentage|Balanced percentage|Balanced mean future movement queries|
|---|---:|---:|---:|---:|
|>128|45,661|9.5905%|11.5774%|0.72|
|>136|37,062|7.7844%|9.5801%|0.60|
|>256|6,693|1.4058%|1.7515%|1.72|
|>512|1,339|0.2812%|0.3414%|2.36|
|>1024|7|0.00147%|0.00184%|1.22|
|>4096|0|0|0|—|

The maximum recorded age is1,053. Older observations do exist because the cap applies only to demanded fields, idle cached fields can age arbitrarily, the feature measures serving **capture age** rather than time since submission, and publication is delayed. The cap therefore does not imply an absolute128bound on every observed capture age.

The decisive distinction is **joint age and demand support**:

- q128≥8:325,313episodes, max age206; **zero age>256**.
- q128≥32:111,323episodes, max age155; only4age>144; **zero age>256**.
- q128≥128:16,147episodes, max age128; **zero age>128**.
- q32≥8:115,246episodes, max age140; **zero age>144**.
- q32≥32:15,925episodes, max age125; **zero age>128**.
- Every age>256 observation has q128<8. These are observations of lightly queried/idle fields, not examples of a busy field left stale for thousands of ticks.

Recent query counts are demand proxies, not proof that every tick was continuously queried; counts may include bursts. Even with that qualification, the absence of busy+old joint support is clear.

Heldout repeats the same limitation: among120,006episodes, only1has age>1024(max1026), none>4096; q128≥8 max206, q128≥32 max155, q128≥128 max116. Heldout validation drawn under the same capped collection policy cannot demonstrate safe uncapped behavior in the missing regimes.

## Comparison with yesterday's dataset

Yesterday's exact246,924episode dataset also has no ages>4096 and a maximum1,039; only1episode exceeds1024. But it mixed several refresh policies (rotation/fixed intervals/adaptive/budget), so it was **not entirely capped adaptive behavior**. It contains258examples with q128≥128 and age>256, whereas the new512corpus has none. Its older adaptive component had a cap, but other collection policies supplied some busier old-field examples. The new tournament expanded map/roster coverage while narrowing this policy-induced age/demand support.

Thus both “there were no old fields at all” and “every old training game used the same cap” would be incorrect. The accurate claim is that long-stale, still-demanded fields, particularly the multi-thousand-tick states reached without the cap, are absent or severely underrepresented in the fitted observations.

## Separate negative-planning label gap

The corpus only stages episodes for movement-observed fields queried within128ticks, and labels only extra movement direction cost over future32ticks. Scalar-only negative planning answers have no direct training label, and no-move/unreachable cases often contribute zero extra direction cost. Removing the cap can therefore leave a stale negative field scoring below32 indefinitely even though recruitment is wrong. More experts trained on the same absent/blind examples cannot solve this evidence gap alone.

The no-cap experiment's River negative planning median age1,762,p90=15,832,max17,953 and late8v8movementp99age5,689 are far beyond this support. Safe investigation of a different cap requires deliberate uncensored/varied-age data collection, proper planning/reachability outcomes, and a prospective closed-loop comparison—not merely choosing another model family or trusting the capped holdout error.
