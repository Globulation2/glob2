# Additional generalization slices and a discriminator for runtime input shift

`generalization_slices.py` joins the frozen per-row predictions to the verified512manifest metadata. It retains the global grouped heldout format/map/collection weights when conditioning on a generator or size; it does not silently rebalance every generator to a different target population. See generalization-slices.json and generalization-table.md.

On this frozen heldout population, final MAE improves in **all8formats, all10dimension buckets, and56of57represented generators**. The lone generator with worse MAE is shattered-coast:1.145→1.147 across2maps. MSE improves in only4/8formats,6/10dimensions,38/57generators. Ten of the67dataset generators have **no heldout map**. These results do not support a broad claim that one shared model cannot generalize or that every generator needs its own expert. They also do not establish prospective unseen-generator robustness.

Relevant final-performance generator slices:

|Generator|Development/heldout maps|Old→new MAE|Old→new score≥32|Old→new positive benefit covered|
|---|---:|---:|---:|---:|
|city-states|3/5|6.62→6.33|0.620%→0.323%|17.21%→15.76%|
|hilbert-river|4/1|7.28→7.07|0→0|0→0|
|coral|2/3|2.70→2.05|0→0|0→0|
|everglades|6/3|4.62→4.13|0.061%→0|3.22%→0|
|spider-web|12/4|8.95→8.16|2.098%→0.566%|12.90%→3.71%|
|stone-highlands|10/3|2.72→2.43|0.042%→0|0→0|
|fjord-continent|7/4|6.32→5.99|0.955%→0.706%|24.57%→23.45%|

These are **generator slices across all heldout formats/seeds/rosters**, not the CPU-measured final eight individual trajectories. For example a city-states5-map aggregate cannot explain a particular8v8 game's CPU. Small counts, especially1hilbert-river map, preclude strong generalization claims. Still, both old and final score almost nothing above32 on some entire slices: any observed periodic field work there can be cap, cold, reactive, or other gradient families rather than model-triggered early refresh.

For the large rectangular dimensions, final remains more conservative and improves MAE:256x512 MAE6.39→6.06 and threshold selection0.822%→0.288%;512x256 MAE7.27→6.68, selection1.659%→0.806%;512x512 MAE6.35→5.83, selection0.917%→0.254%. Therefore the eight-game large-map CPU regression is not evidence of worse average prediction error on large-map heldout episodes. The metric and policy operating point are different questions.

## A useful counterexample to global model ordering

The empirical fact “final-selected is a subset of old-selected on476,107complete observations” is **not a global theorem about the two functions**.

`out_of_support_grid.py` evaluates63,096hand-selected tuples with q128≥q32, nonnegative source counts after changes, age8..128, coherent fractional features computed from a captured count, and a range of query burst/turnover patterns. It finds143tuples with final≥32 and old<32;89fall within each feature's observed marginal range. This grid is not a sampled gameplay distribution and these counts are **not estimated frequencies**. Being within every marginal range is not evidence of joint support.

A plausible recent-burst example:

```
age32, q32=32, q128=32,
source_added=1, source_removed=64,
captured_sources4096 → added_fraction1, removed_fraction64
old score29.353; final score34.429
```

Another has age32,q32=32,q128=64 with the same source inputs: old31.638,new33.635. The changed q128 and removal coefficients can make final more eager under some **recent burst plus removal** combinations while being more conservative for the steady q128≈4q32 patterns. No such final-only combination occurred in the frozen complete-episode corpus, but a changed live scheduler could visit it.

**Discriminating measurement:** for actual final-only model admissions in the controlled same-engine old/new experiment, capture the seven inputs and both model scores, plus admission cause. Check whether q32/q128 indicates bursts and whether turnover differs from the frozen training support. That distinguishes runtime input-distribution shift from a claim based only on averaged offline selection. Record sampled inputs only when diagnostic collection is enabled. This is more informative than immediately adding generator IDs or experts.
