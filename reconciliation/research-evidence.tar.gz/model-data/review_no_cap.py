import csv,json,pathlib,collections,math
P=pathlib.Path('/Users/bradley/glob2/artifacts/gradient-reconciliation/no-cap');O=pathlib.Path(__file__).resolve().parent;official=json.loads((P/'analysis.json').read_text());by={r['key']:r for r in official['runs']};checks=[]
for name in ['river164-age-quality-capped','river164-age-quality-uncapped','8v8-warm4096-age-quality-capped','8v8-warm4096-age-quality-uncapped']:
 root=P/name;audit=json.loads((root/'audit.json').read_text());hist=collections.defaultdict(collections.Counter)
 with (root/'audit.json.ages.csv').open() as f:
  for r in csv.DictReader(f):hist[int(r['histogram'])][int(r['age'])]+=int(r['count'])
 ages={}
 for reader,label in enumerate(['movement','positive_planning','negative_planning','warm_refresh']):
  H=hist[2*reader];count=sum(H.values());stat=by[name]['ages'][label]['all'];assert stat['count']==count
  def pct(p):
   target=math.ceil(count*p);n=0
   for age,c in sorted(H.items()):
    n+=c
    if n>=target:return age
  for p in [50,90,99]:assert pct(p/100)==stat['p'+str(p)]
  assert max(H)==stat['max'] # no overflow in this campaign
  for t in [128,256,512,1024,4096,8192]:assert abs(sum(c for age,c in H.items() if age>=t)/count-stat['age_fraction'][str(t)])<1e-12
  assert all(hist[2*reader+1][age]<=c for age,c in H.items())
  assert by[name]['ages'][label]['sources_changed']['count']+by[name]['ages'][label]['sources_unchanged']['count']==count
  assert by[name]['ages'][label]['unknown_reads']==audit['age_unknown'][reader]
  ages[label]={'known_reads':count,'unknown_reads':audit['age_unknown'][reader],'unknown_pct':100*audit['age_unknown'][reader]/(count+audit['age_unknown'][reader])}
 with (root/'audit.json.planning-oracle.csv').open() as f:rr=[{k:int(v) for k,v in r.items()} for r in csv.DictReader(f)]
 neg=sum(r['old_value']<=1 for r in rr);fn=sum(r['old_value']<=1 and r['fresh_value']>1 for r in rr);fp=sum(r['old_value']>1 and r['fresh_value']<=1 for r in rr);oracle=by[name]['planning_quality'];assert len(rr)==oracle['samples'] and neg==oracle['old_negative_samples'] and fn==oracle['false_unreachable'] and fp==oracle['false_reachable']
 with (root/'gradient-quality.csv').open() as f:mr=[{k:int(v) for k,v in r.items()} for r in csv.DictReader(f)]
 # Log all sampled-field/window movement rows, exactly as the published summary.
 mr=[r for r in mr if r['tick']>=(36864 if name.startswith('8v8') else 0)]
 ms=by[name]['movement_quality'];assert len(mr)==ms['queries']
 for metric in ['extra_cost','false_unreachable','false_reachable','depleted_goal','missed_move','unreachable_step','left_fresh_goal','flagged']:assert sum(r[metric] for r in mr)==ms['sum'][metric]
 checks.append({'run':name,'histograms_quantiles_subsets_and_unknowns':'PASS','planning_oracle':'PASS','movement_oracle':'PASS','age_read_populations':ages,'movement_sample_tick_min_max':[min(r['tick'] for r in mr),max(r['tick'] for r in mr)],'movement_sample_windows':dict(collections.Counter(r['window'] for r in mr)),'planning_sample_tick_min_max':[min(r['tick'] for r in rr),max(r['tick'] for r in rr)],'planning_false_negative_distinct_fields':len({r['key'] for r in rr if r['old_value']<=1 and r['fresh_value']>1}),'planning_false_negative_distinct_captures':len({(r['key'],r['tick']-r['age']) for r in rr if r['old_value']<=1 and r['fresh_value']>1})})
for pair in official['equivalence']:
 a,b=[json.loads((P/k/'result.json').read_text()) for k in pair['pair']]
 assert all(a[k]==b[k] for k in ['ticks','finalChecksum','gradient_jobs']);assert pair['same_ticks'] and pair['same_checksum'] and pair['same_jobs']
(O/'no-cap-independent-checks.json').write_text(json.dumps({'checks':checks,'equivalence_pairs':4,'result':'PASS'},indent=2)+'\n');print(json.dumps(checks,indent=2))
