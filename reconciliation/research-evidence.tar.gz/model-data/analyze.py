import sys,json,pathlib,importlib.util,collections,time
import numpy as np
P=pathlib.Path('/Users/bradley/glob2/artifacts/gradient-training-1024');OUT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('rgm','/Users/bradley/.codex/worktrees/adaptive-final-integration/glob2/tools/resource_gradient_model.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
rows=mod.dataset([P/'training-manifest-512.json']);print('loaded',len(rows),flush=True)
models={'yesterday':json.loads((OUT.parent/'code/yesterday-model.json').read_text()),'final':json.loads((P/'fit-512/model.json').read_text())}
raw=np.array([[r[k] for k in mod.FEATURES] for r in rows],dtype=np.int64);X=np.empty_like(raw)
for j in range(7):
 u,inv=np.unique(raw[:,j],return_inverse=True);X[:,j]=np.array([mod.log_integer(i) for i in u])[inv]
def trunc(a,d):return np.sign(a)*(np.abs(a)//d)
def sigmoid(z):
 n=np.clip(z,-12000,12000)+12000;i=np.minimum(n//50,479);ss=np.array(mod.SIG);return ss[i]+(ss[i+1]-ss[i])*(n-i*50)//50
pred={}
for name,m in models.items():
 heads={k:np.clip(trunc(X@np.array(m[k]['coef'])+m[k]['bias'],1<<m[k]['shift']),-10**9,10**9) for k in mod.HEADS}
 pred[name]=np.clip(trunc(sigmoid(heads['positive_probability'])*np.maximum(heads['positive_mean'],0)-sigmoid(heads['negative_probability'])*np.maximum(heads['negative_mean'],0),65536),-10**9,10**9)/1000
 for i in np.linspace(0,len(rows)-1,1000).astype(int):assert int(round(pred[name][i]*1000))==mod.predict(m,raw[i])
 print('predicted',name,flush=True)
y=np.array([r['defer_extra']-r['refresh_extra'] for r in rows]);w=mod.weights(rows);held=np.array([r['group'] in set(models['final']['provenance']['heldout_states']) for r in rows]);positive=y>0

def mean(v,mask,ww=None):return float(np.average(v[mask],weights=(w if ww is None else ww)[mask])) if mask.any() else None
def summary(mask,reweight=False):
 if not mask.any():return {"episodes":0}
 ww=w.copy()
 if reweight:ww[mask]=mod.weights([r for r,b in zip(rows,mask) if b])
 avg=lambda v,m:mean(v,m,ww)
 d={'episodes':int(mask.sum()),'states':len({r['group'] for r,b in zip(rows,mask) if b}),'weight_fraction_pct':100*float(w[mask].sum()/w.sum()),'actual_positive_pct':100*avg(positive,mask),'actual_mean_benefit':avg(y,mask),'inputs':{k:{'weighted_mean':avg(raw[:,j],mask),'raw_percentiles':np.percentile(raw[mask,j],[0,25,50,75,90,95,99,100]).tolist()} for j,k in enumerate(mod.FEATURES)}}
 for name,p in pred.items():
  take=p>=32;d[name]={'weighted_mean_prediction':avg(p,mask),'prediction_percentiles':np.percentile(p[mask],[0,25,50,75,90,95,99,100]).tolist(),'mae':avg(abs(p-y),mask),'mse':avg((p-y)**2,mask),'selected_pct':100*avg(take,mask),'selected_actual_benefit':avg(y,mask&take),'benefit_capture_pct':100*float(np.sum(ww[mask&take]*np.maximum(y[mask&take],0))/np.sum(ww[mask]*np.maximum(y[mask],0))) if np.sum(ww[mask]*np.maximum(y[mask],0)) else None}
 d['selection_transition_pct']={key:100*avg(val,mask) for key,val in {'both':(pred['yesterday']>=32)&(pred['final']>=32),'old_only':(pred['yesterday']>=32)&(pred['final']<32),'new_only':(pred['yesterday']<32)&(pred['final']>=32),'neither':(pred['yesterday']<32)&(pred['final']<32)}.items()}
 return d
out={'all':summary(np.ones(len(rows),bool)),'heldout':summary(held,True),'development':summary(~held,True),'format':{},'age':{},'q32':{},'turnover':{},'holdout_format':{}}
for f in sorted({r['format'] for r in rows}):
 mask=np.array([r['format']==f for r in rows]);out['format'][f]=summary(mask);out['holdout_format'][f]=summary(mask&held,True)
for key,j,bounds in [('age',0,[0,8,16,32,64,96,128,256,100000000]),('q32',1,[0,1,2,8,32,128,512,2048,100000000])]:
 for lo,hi in zip(bounds,bounds[1:]):
  mask=(raw[:,j]>=lo)&(raw[:,j]<hi)
  if mask.any():out[key][f'{lo}-{hi-1}']=summary(mask)
turn=raw[:,3]+raw[:,4]
for lo,hi in zip([0,1,8,64,512,4096],[1,8,64,512,4096,100000000]):
 mask=(turn>=lo)&(turn<hi)
 if mask.any():out['turnover'][f'{lo}-{hi-1}']=summary(mask)
# Model deltas on identical raw feature rows, both marginal and selected cohorts.
out['delta']={'mean_prediction_change':mean(pred['final']-pred['yesterday'],np.ones(len(rows),bool)),'raw_prediction_change_percentiles':np.percentile(pred['final']-pred['yesterday'],[0,1,5,25,50,75,95,99,100]).tolist()}
for label,mask in [('old_only',(pred['yesterday']>=32)&(pred['final']<32)),('new_only',(pred['yesterday']<32)&(pred['final']>=32)),('both',(pred['yesterday']>=32)&(pred['final']>=32))]:
 out[label]=summary(mask)
(OUT/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
np.savez_compressed(OUT/'row-predictions.npz',raw=raw,old=pred['yesterday'],new=pred['final'],target=y,weights=w,heldout=held)
print('all',json.dumps({k:out['all'][k] for k in ['episodes','yesterday','final','selection_transition_pct']},indent=2))
for section in ['format','age','q32','turnover']:
 print(section)
 for key,d in out[section].items():print(key,d['episodes'],'old/newtake',round(d['yesterday']['selected_pct'],3),round(d['final']['selected_pct'],3),'old/newmean',round(d['yesterday']['weighted_mean_prediction'],2),round(d['final']['weighted_mean_prediction'],2))
