| Generator | Development/heldout maps | Old→new MAE | Old→new ≥32 | Old→new positive benefit captured |
|---|---:|---:|---:|---:|
|city-states|3/5|6.62→6.33|0.620%→0.323%|17.21%→15.76%|
|hilbert-river|4/1|7.28→7.07|0.000%→0.000%|0.00%→0.00%|
|coral|2/3|2.70→2.05|0.000%→0.000%|0.00%→0.00%|
|everglades|6/3|4.62→4.13|0.061%→0.000%|3.22%→0.00%|
|spider-web|12/4|8.95→8.16|2.098%→0.566%|12.90%→3.71%|
|stone-highlands|10/3|2.72→2.43|0.042%→0.000%|0.00%→0.00%|
|fjord-continent|7/4|6.32→5.99|0.955%→0.706%|24.57%→23.45%|
