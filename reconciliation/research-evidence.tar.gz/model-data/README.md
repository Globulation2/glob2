# Old versus final model on identical frozen observations

`analyze.py` loads and verifies every episode CSV hash through the permanent dataset loader, keeps476,107 complete episodes across500 labelled map groups, and evaluates the exact seven-input integer model exported yesterday against the final512-game refit. Vectorized integer arithmetic is checked against the permanent scalar predictor on1,000 observations per model. No engine workloads or source changes were made. Run with the campaign venv Python. `analysis.json` has format, age, q32, turnover and selection-transition slices; `row-predictions.npz` holds arrays for repeatable follow-ups.

## Result: refit is more conservative on these observations

| Same heldout126 maps,120,006 episodes | Yesterday | Final |
|---|---:|---:|
| MAE |6.11865|5.58149|
| MSE |573.84171|576.67565|
| Weighted mean predicted benefit |3.76467|2.95202|
| Score≥32 |0.96079%|0.41729%|
| Mean observed benefit among selected |56.71431|96.60798|
| Share of all positive observed benefit captured by selected rows |16.04973%|11.73111%|

These reproduce existing heldout metrics exactly. Overall and slice weights balance formats, then map groups, then collection games, then episodes. Heldout/development subsets rederive those weights to match permanent validation. Other conditional slices keep original dataset weights; raw percentiles are explicitly unweighted.

Across **all476,107 complete rows**, old selects8,798 unweighted examples and final4,004. **Every single final-selected row is also selected by old**;4,794 rows are old-only and zero are new-only. Weighted selection falls1.15488%→0.52294%. The old-only cohort's mean observed benefit is24.32, below threshold32; this helps explain why a better calibrated model removes them. It is not proof that delaying all those refreshes improves closed-loop quality.

The lower MAE does not establish every relevant objective improved: heldout MSE rises0.49%, and the total positive benefit covered by threshold-selected rows falls. Selection becomes smaller and more concentrated. This is an expected model/threshold tradeoff, requiring new online quality measurements.

## What changes with demand and age

-80.0% of balanced data weight has fewer than8 queries in the last32 ticks. Neither model meaningfully selects these rows before the cap.
-For q32 between32 and127, weighted selection drops40.30%→16.16%. At q32≥128, both select100% of observed rows.
-For age16–127, final selection is below0.01% in each age slice. Most model-selected rows are ages8–15 with high query demand.
-For age≥128, essentially no observed rows score above32. Such fields, if still requested and their **time since submission** reaches128, refresh because of the explicit cap; their low model score does not stop them.
-CSV `age` is time since the serving capture, whereas the hard cap uses `tick-submitted`. The CSV lacks submitted tick and requested state, so it cannot determine the fraction of actual admissions caused by cap versus model. The fixed publication delay also separates serving and submission clocks. Do not treat age≥128 rows as exact cap-admission records.

The final model's above-threshold share drops in **every heldout format**; see heldout-table.md. For example8v8 falls0.686%→0.243%,4ffa0.240%→0.101%,4v4 0.221%→0.007%.

## Controlled coefficient sensitivity

`ablate_coefficients.py` swaps one feature's coefficient across all four heads, keeping all other coefficients fixed. This is a numeric sensitivity experiment, not feature importance or a valid retrained model. Raw features remain identical. The q128 coefficient change has the largest downward effect: transplanting only new q128 coefficients into old lowers selected share1.155%→0.160%; reverting only q128 in the final model raises0.523%→0.849%. q32 also lowers scores; source-removal changes partly offset that. Coefficients and bias interact, so effects do not add.

A controlled input example (`feature-grid.json`) illustrates this: age64,q32=64,q128=256,no source turnover predicts45.552 old versus31.213 final. That crosses the same threshold32 in the conservative direction. No new coefficient change can explain **more immediate selections on the frozen observed rows**, because none were observed.

## Why these measurements do not explain higher final gradient counts by themselves

Final whole-game periodic jobs rise despite this conservative refit. The direct coefficient effect on identical observed features points toward fewer, not more, model-selected jobs. Additional refresh requests, cold/area/AIR work, hard128 cap refreshes, and changed game trajectories must be separated before blaming model inference or coefficients.

The collector has a material coverage limit relevant to distance-only demand: `stageEpisodes` iterates probe fields created by movement `observe`, requires a movement query within128 ticks, and uses those future movement queries to accumulate direction-cost labels. A field queried **only for distance/recruitment**, with no movement observations, does not enter this episode population. Production can request such a field and eventually refresh it through the128 cap despite zero q32/q128. The current fitted model has no label measuring the recruitment benefit of those distance-only refreshes.

These are sampled **32-tick counterfactual episodes**, collected in selected windows under the frozen collection policy. They are not every scheduler decision, refresh events, or an execution of the new policy. The identical-input subset result does not mathematically guarantee that final closed-loop runs refresh less: changing decisions changes subsequent inputs and trajectories.
