"""Exercise literal final ring expiration versus historical deque <32/<128 definitions."""
import collections,random,json,pathlib
R=random.Random(713);q=collections.deque();b=[0]*128;c32=c128=0;known=False;qt=0;tick=0;events=checks=0
for step in range(100000):
 tick=(tick+R.choice([0,0,1,1,2,7,31,32,33,127,128,129,256]))&0xffffffff
 if step==50000:tick=0xfffffff0;q.clear();b=[0]*128;c32=c128=0;known=False
 # Advance is called on a model-input read or movement query. Historical deque
 # may physically retain expired entries; each feature lookup filters by age.
 if not known or ((tick-qt)&0xffffffff)>=128:
  b=[0]*128;c32=c128=0;qt=tick;known=True
 else:
  while qt!=tick:
   qt=(qt+1)&0xffffffff;c32-=b[(qt-32)&127];c128-=b[qt&127];b[qt&127]=0
 count=R.randrange(12)
 for _ in range(count):b[tick&127]+=1;c32+=1;c128+=1;q.append(tick);events+=1
 while q and ((tick-q[0])&0xffffffff)>=128:q.popleft()
 expected128=sum(((tick-t)&0xffffffff)<128 for t in q);expected32=sum(((tick-t)&0xffffffff)<32 for t in q)
 assert (c32,c128)==(expected32,expected128),(step,tick,c32,c128,expected32,expected128)
 checks+=1
out={'checks':checks,'movement_events':events,'wraparound_tested':True,'result':'PASS','definition':'same tick through tick-31 inclusive and same tick through tick-127 inclusive; expiry at exact32/128'}
p=pathlib.Path(__file__).with_name('counter-contract.json');p.write_text(json.dumps(out,indent=2)+'\n');print(out)
