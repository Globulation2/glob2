import pathlib,csv,gzip,json,collections
P=pathlib.Path(__file__).resolve().parent;D=P/'runtime-classified';out={}
for f in sorted(D.glob('*-classified.csv.gz')):
 with gzip.open(f,'rt') as h:rows=[{k:(int(v) if k not in ['classification','burst'] else v) for k,v in r.items()} for r in csv.DictReader(h)]
 name=f.name.removesuffix('-classified.csv.gz');groups={'all':rows}
 if name.startswith('8v8'):
  groups['after_migration128']=[r for r in rows if r['tick']>=32896];groups['after_migration512']=[r for r in rows if r['tick']>=33280];groups['legacy_first_submitted_age_gt32768']=[r for r in rows if r['submitted_age']>32768]
 out[name]={}
 for label,rr in groups.items():
  if not rr:out[name][label]={'admissions':0};continue
  caps=[r for r in rr if r['cap']];mods=[r for r in rr if not r['cap']];nc=sum(r['q32']==r['q128']==0 for r in caps);nz=sum(r['q32']==0 for r in caps)
  out[name][label]={'admissions':len(rr),'cap':len(caps),'model':len(mods),'cap_pct':len(caps)*100/len(rr),'cap_zero_q32':nz,'cap_zero_q32_pct':nz*100/len(caps) if caps else None,'cap_both_query_counts_zero':nc,'cap_both_zero_pct':nc*100/len(caps) if caps else None,'model_score_classes':dict(collections.Counter(r['classification'] for r in mods)),'cap_score_classes':dict(collections.Counter(r['classification'] for r in caps)),'new_only_examples':[r for r in rr if r['classification']=='new_only'][:10],'submitted_age_minmax':[min(r['submitted_age'] for r in rr),max(r['submitted_age'] for r in rr)]}
(P/'actual-admissions-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
