from pathlib import Path
import json,subprocess,os,time,hashlib,resource
c=Path('/home/bradley/glob2/artifacts/gradient-reconciliation');out=c/'reproduction';out.mkdir(exist_ok=True)
old=Path('/home/bradley/glob2/artifacts/gradient-refit-sweep/glob2-experimental');new=c/'bin/final512';rows=[]
baseenv={k:v for k,v in os.environ.items() if not k.startswith('GLOB2_RESOURCE_') and k!='GLOB2_EXPERIMENT_GRADIENT_METRICS' and k!='GLOB2_EXPERIMENT_RESOURCE_DEMAND8'}
for seed in [2002,2003]:
 historical=json.loads(Path(f'/home/bradley/glob2/artifacts/gradient-refit-sweep/runs/seed-{seed}-rotation-guarded-repeat-sweep0-t8/command.json').read_text())['command']
 for threads in [1,8]:
  for policy in ['old-rotation','old-adaptive32','final512']:
   key=f'{seed}-{threads}-{policy}';d=out/key;d.mkdir(exist_ok=True);cmd=historical.copy();cmd[0]=str(new if policy=='final512' else old);cmd[cmd.index('--compute-threads')+1]=str(threads);cmd[cmd.index('--output-dir')+1]=str(d)
   env=baseenv.copy()
   if policy.startswith('old-'):
    env['GLOB2_RESOURCE_PROBE_LIVE_ONLY']='1'
    if policy=='old-adaptive32':env.update(GLOB2_EXPERIMENT_RESOURCE_DEMAND8='1',GLOB2_RESOURCE_INTERVAL='8',GLOB2_RESOURCE_PORTABLE_MODEL='1',GLOB2_RESOURCE_PORTABLE_THRESHOLD='32000',GLOB2_RESOURCE_REFIT_MODEL='1')
   (d/'command.json').write_text(json.dumps({'command':cmd,'env':{k:v for k,v in env.items() if k.startswith('GLOB2_RESOURCE') or k.startswith('GLOB2_EXPERIMENT')}},indent=2));(out/'status.json').write_text(json.dumps({'active':key,'complete':len(rows),'total':12}));start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
   with (d/'run.log').open('w') as f:p=subprocess.run(cmd,cwd='/home/bradley/glob2-gradient-reconciliation',env=env,stdout=f,stderr=subprocess.STDOUT)
   after=resource.getrusage(resource.RUSAGE_CHILDREN);r={'key':key,'rc':p.returncode,'wall':time.monotonic()-start,'cpu':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime}
   if p.returncode==0:r['result']=json.loads((d/'result.json').read_text())
   rows.append(r);(out/'manifest.json').write_text(json.dumps(rows,indent=2));print(key,p.returncode,flush=True)
(out/'status.json').write_text(json.dumps({'phase':'complete','complete':len(rows),'total':12}))
