import json, pathlib, math, statistics, collections
ROOT=pathlib.Path('/Users/bradley/glob2/artifacts/gradient-training-1024/final-performance')
OUT=pathlib.Path(__file__).resolve().parent
m=json.loads((ROOT/'manifest.json').read_text());plan=json.loads((ROOT/'plan.json').read_text());s=json.loads((ROOT/'summary.json').read_text())
records=[]
for row in m:
 r=json.loads(pathlib.Path(row['result']).read_text()); spec=next(g['spec'] for g in plan['games'] if g['format']==row['format'])
 histories=[t['history'] for t in r['teams']]; n=min(map(len,histories)); pop=[sum(t[i][0] for t in histories) for i in range(n)];bld=[sum(t[i][1] for t in histories) for i in range(n)]
 q={**row,'width':spec['width'],'height':spec['height'],'cells':spec['width']*spec['height'],'players':len(r['players']),'final_checksum':r['finalChecksum'],'gradient_jobs':r['gradient_jobs'],'building_jobs':r['building_gradient_jobs'],'building_sync':r['building_gradient_synchronous'],'mean_sampled_units':statistics.mean(pop),'mean_sampled_buildings':statistics.mean(bld),'peak_sampled_units':max(pop),'population_history':pop,'building_history':bld,'periodic_jobs_per_tick':r['gradient_jobs']/r['ticks'],'building_jobs_per_tick':r['building_gradient_jobs']/r['ticks'],'entity_bytes_per_tick':r['ai_pipeline']['entity_bytes_copied']/r['ticks'],'map_bytes_per_tick':r['ai_pipeline']['map_bytes_copied']/r['ticks'],'history_samples':n}
 records.append(q)
formats=[]
for f in [r['format'] for r in s['formats']]:
 a={p:[r for r in records if r['format']==f and r['policy']==p] for p in ['master','adaptive32']}; d={'format':f,'cells':a['master'][0]['cells']}
 for metric in ['cpu_ms_per_tick','total_cpu_seconds','ticks','gradient_jobs','building_jobs','building_sync','periodic_jobs_per_tick','building_jobs_per_tick','mean_sampled_units','mean_sampled_buildings','entity_bytes_per_tick','map_bytes_per_tick']:
  mm={p:statistics.mean(x[metric] for x in rr) for p,rr in a.items()};d[metric]={**mm,'change_pct':100*(mm['adaptive32']/mm['master']-1)}
 common=min(a['master'][0]['history_samples'],a['adaptive32'][0]['history_samples'])
 d['common_prefix_population_ratio']=statistics.mean(a['adaptive32'][0]['population_history'][:common])/statistics.mean(a['master'][0]['population_history'][:common])
 d['common_prefix_building_ratio']=statistics.mean(a['adaptive32'][0]['building_history'][:common])/statistics.mean(a['master'][0]['building_history'][:common])
 d['timing_repeat_change_pct']={p:100*(rr[1]['cpu_ms_per_tick']/rr[0]['cpu_ms_per_tick']-1) for p,rr in a.items()}
 d['repeat_checksum_match']={p:len({r['final_checksum'] for r in rr})==1 for p,rr in a.items()}
 formats.append(d)
basecpu=sum(r['simulation_cpu_seconds'] for r in records if r['policy']=='master'); delta=sum(r['simulation_cpu_seconds']*(1 if r['policy']=='adaptive32' else -1) for r in records)
for d in formats:
 d['pooled_cpu_delta_seconds']=sum(r['simulation_cpu_seconds']*(1 if r['policy']=='adaptive32' else -1) for r in records if r['format']==d['format'])
 d['share_of_net_cpu_regression_pct']=100*d['pooled_cpu_delta_seconds']/delta
 d['master_cpu_weight_pct']=100*sum(r['simulation_cpu_seconds'] for r in records if r['format']==d['format'] and r['policy']=='master')/basecpu
for d in formats:
 t=d['ticks'];r=d['cpu_ms_per_tick'];d['cpu_delta_decomposition_per_repetition_seconds']={'length_effect':(t['adaptive32']-t['master'])*(r['adaptive32']+r['master'])/2000,'rate_effect':(r['adaptive32']-r['master'])*(t['adaptive32']+t['master'])/2000}
metrics={}
for name,pred in [('all',lambda r:True),('small_le_16384',lambda r:r['cells']<=16384),('large_131072',lambda r:r['cells']==131072),('excluding_8v8',lambda r:r['format']!='8v8')]:
 rr=[r for r in records if pred(r)]; x={p:{'cpu_s':sum(r['simulation_cpu_seconds'] for r in rr if r['policy']==p),'ticks':sum(r['ticks'] for r in rr if r['policy']==p),'periodic_jobs':sum(r['gradient_jobs'] for r in rr if r['policy']==p),'building_jobs':sum(r['building_jobs'] for r in rr if r['policy']==p)} for p in ['master','adaptive32']}
 for v in x.values():v['cpu_ms_per_tick']=v['cpu_s']*1000/v['ticks']
 x['cpu_per_tick_change_pct']=100*(x['adaptive32']['cpu_ms_per_tick']/x['master']['cpu_ms_per_tick']-1);metrics[name]=x
output={'formats':formats,'subsets':metrics,'equal_format_arithmetic_cpu_ratio_pct':statistics.mean(d['cpu_ms_per_tick']['change_pct'] for d in formats),'equal_format_geomean_pct':100*(math.exp(statistics.mean(math.log(d['cpu_ms_per_tick']['adaptive32']/d['cpu_ms_per_tick']['master']) for d in formats))-1),'records':records}
output['periodic_cell_job_proxy']={p:sum(r['gradient_jobs']*r['cells'] for r in records if r['policy']==p) for p in ['master','adaptive32']}
output['building_cell_job_proxy']={p:sum(r['building_jobs']*r['cells'] for r in records if r['policy']==p) for p in ['master','adaptive32']}
(OUT/'breakdown.json').write_text(json.dumps(output,indent=2)+'\n')
lines=['| Format | CPU/tick change | Master CPU weight | Net CPU delta s | Periodic jobs/tick M→A | Building jobs/tick M→A | Mean units M→A | Mean buildings M→A |','|---|---:|---:|---:|---:|---:|---:|---:|']
for d in formats:
 fm=lambda k:f"{d[k]['master']:.2f}→{d[k]['adaptive32']:.2f}"
 lines.append(f"|{d['format']}|{d['cpu_ms_per_tick']['change_pct']:+.1f}%|{d['master_cpu_weight_pct']:.1f}%|{d['pooled_cpu_delta_seconds']:+.1f}|{fm('periodic_jobs_per_tick')}|{fm('building_jobs_per_tick')}|{fm('mean_sampled_units')}|{fm('mean_sampled_buildings')}|")
(OUT/'table.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines));print(json.dumps(metrics,indent=2));print('arithmetic',output['equal_format_arithmetic_cpu_ratio_pct'],'geo',output['equal_format_geomean_pct'])
