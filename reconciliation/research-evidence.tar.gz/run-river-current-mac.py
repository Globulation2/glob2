from pathlib import Path
import subprocess,json,time,resource,os
c=Path(__file__).parent/'river-current-mac';b=Path('/Users/bradley/glob2/artifacts/gradient-training-1024/bin');root='/Users/bradley/.codex/worktrees/adaptive-final-integration/glob2';rows=[]
for rep,policies in enumerate([['master','adaptive32'],['adaptive32','master']]):
 for policy in policies:
  d=c/f'{policy}-r{rep}';d.mkdir(exist_ok=True);binary=b/('glob2-master-3d896cbb9' if policy=='master' else 'glob2-final-ca6365e83');cmd=[str(binary),'game','run','--map-file',str(c/'river.map.gz'),'--game-seed','2002']
  for i in range(4):cmd+=['--player','nicowar','--alliance',str(i+1)]
  cmd+=['--ticks','90000','--compute-threads','1','--gpu','off','--compute-telemetry','off','--benchmark-warmup','0','--output-dir',str(d)];(d/'command.json').write_text(json.dumps(cmd,indent=2));start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
  with (d/'run.log').open('w') as f:p=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
  after=resource.getrusage(resource.RUSAGE_CHILDREN);rows.append({'policy':policy,'repetition':rep,'rc':p.returncode,'wall':time.monotonic()-start,'cpu':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'result':json.loads((d/'result.json').read_text()) if p.returncode==0 else None});(c/'manifest.json').write_text(json.dumps(rows,indent=2));print(policy,rep,p.returncode,flush=True)
(c/'status.json').write_text(json.dumps({'phase':'complete'}))
