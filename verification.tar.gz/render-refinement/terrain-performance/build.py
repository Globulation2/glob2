from pathlib import Path
import subprocess,shlex,json,hashlib
root=Path.cwd();p=root/'artifacts/render-refinement/terrain-performance';old=Path('/home/bradley/.codex/worktrees/parallel-rendering/glob2');ref=p/'SoftwareTerrainCacheReference'
for ext in ('.h','.cpp'):
 text=subprocess.check_output(['git','show','f9eae2549:src/render/SoftwareTerrainCache'+ext],text=True).replace('SoftwareTerrainCache','SoftwareTerrainCacheReference').replace('GpuTerrainPageCache','GpuTerrainPageCacheReference')
 (ref.with_suffix(ext)).write_text(text)
base=shlex.split((old/'artifacts/render-parallel/terrain-reference/release-compile.line').read_text().strip());base=base[:-1]
# Absolute old include/build paths keep immutable generated config and dependency inputs.
base=[('-I'+str(old/x[2:])) if x.startswith('-I') and not x[2:].startswith('/') else x for x in base]
base.extend(['-I'+str(root/'src/render'),'-I'+str(root/'src/render/terrain'),'-I'+str(p)])
objects=[]
for source,name in [(root/'src/render/SoftwareTerrainCache.cpp','current'),(ref.with_suffix('.cpp'),'reference'),(p/'probe.cpp','probe')]:
 cmd=base.copy();cmd[cmd.index('-o')+1]=str(p/(name+'.o'));cmd.append(str(source))
 if name=='probe':cmd.insert(1,'-fno-access-control')
 (p/(name+'.command.json')).write_text(json.dumps(cmd,indent=2))
 with (p/(name+'.compile.log')).open('w')as out:r=subprocess.run(cmd,cwd=old,stdout=out,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 objects.append(str(p/(name+'.o')))
lines=(old/'artifacts/render-parallel/release-final-benchmark.log').read_text().splitlines();line=next(x for x in lines if x.startswith('g++ -o ') and '/test/SoftwareRenderBenchmark ' in x and ' -c ' not in x);cmd=shlex.split(line);cmd[cmd.index('-o')+1]=str(p/'probe')
cmd=[x for x in cmd if not x.endswith('/test/program-src_render_SoftwareRenderBenchmark.o') and not x.endswith('/src/render/SoftwareTerrainCache.o')];cmd.extend(objects)
(p/'link.command.json').write_text(json.dumps(cmd,indent=2))
with(p/'link.log').open('w')as out:r=subprocess.run(cmd,cwd=old,stdout=out,stderr=subprocess.STDOUT)
print('link',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
meta={'base':'f9eae2549','scope':'O3 synchronous serial CPU page planning/material snapshot/private output/install; no production scheduling or full frame timing','compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'source_sha256':{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest()for f in [root/'src/render/SoftwareTerrainCache.cpp',root/'src/render/SoftwareTerrainCache.h',p/'probe.cpp',ref.with_suffix('.cpp'),ref.with_suffix('.h')]},'linked_input_sha256':{str(old/x if not x.startswith('/')else Path(x)):hashlib.sha256((old/x if not x.startswith('/')else Path(x)).read_bytes()).hexdigest()for x in cmd if x.endswith(('.o','.a'))}}
(p/'metadata.json').write_text(json.dumps(meta,indent=2))
with(p/'result.csv').open('w')as out,(p/'run.log').open('w')as err:r=subprocess.run([str(p/'probe')],cwd=root,stdout=out,stderr=err)
print('run',r.returncode,flush=True);raise SystemExit(r.returncode)
