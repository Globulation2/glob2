# Release CPU terrain cache refinement probe

This standalone O3 comparison compiles the original `f9eae2549` cache and the
current cache with identical flags, renames only the reference class/symbols,
and links the same existing release compositor and dependency object inventory.
The probe alone uses `-fno-access-control` to call the private CPU page builder;
production kernels and admission logic remain unchanged. Exact command JSONs,
source SHA256 values and every linked object/archive SHA256 are recorded.
The latest final benchmark link command is used; an earlier stored link inventory
omitted later MCP/UI objects and its unsuccessful link log was superseded.

Four deterministic cases cover a 256-cell forced rebuild and a single-cell edit,
with opaque terrain or uniform transparent holes. Each changed cell is uniform;
there is no mixed-cell coverage generation in this probe. Material revisions are
prepared before timing, and each measured run retains the most recent material
lease. Therefore “cold” means forcing all page cells to recompose, not a cold
artwork/catalog load or the first rendered frame. Sparse runs leave water/ice
elsewhere in the unchanged page and edit one distant grass cell, exercising
changed-only material selection. Each path uses an inline serial dispatcher;
this measures planning, snapshot admission/reuse, result allocation, composition,
opacity classification and canonical installation without native worker scheduling.
The probe does not time scene extraction, map lookup, SDL upload, frame rasterization,
recording, presentation or simulation contention.

Ten paired rounds per case rotate original/current execution order. Final pixels
match exactly in all 40 pairs. Current median paired ratios to the original are:

| Case | Before us/call | After us/call | Paired ratio |
| --- | ---: | ---: | ---: |
| Forced page, opaque | 349.176 | 344.656 | 0.988 |
| Forced page, holes | 359.086 | 352.125 | 0.970 |
| Sparse edit, opaque | 6.918 | 4.875 | 0.702 |
| Sparse edit, holes | 6.982 | 4.934 | 0.705 |

The small full-page differences should be treated conservatively; individual
round ratios overlap parity. Sparse-case medians improve about 30% in this narrow
fixture. These are local microbenchmarks, not whole-renderer or platform-wide gains.
The first combined scalar alpha scan regressed full pages by 34–35%; its evidence
is preserved under `before-classifier-fix/`. First-alpha dispatch to a single
constant-predicate scan removed that observed regression while preserving pixels.

Reproduce while matching old release objects remain available:

```
python3 artifacts/render-refinement/terrain-performance/build.py
```

The ignored probe binary and object files are development artifacts. Publish
source, commands, metadata, raw CSV, logs and this note as review evidence;
exclude executables/objects from the feature PR and evidence bundle.
