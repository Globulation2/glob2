#include "GlobalContainer.h"
#include "FileManager.h"
#include "SoftwareTerrainCache.h"
#include "SoftwareTerrainCacheReference.h"
#include "TerrainCatalogIO.h"
#include <PresentationWork.h>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <type_traits>
GlobalContainer *globalContainer = nullptr;
struct InlineWork : GAGCore::PresentationWork {
 void executePresentationJobs(std::size_t count,const std::function<void(std::size_t)>& job)override {
  for(std::size_t i=0;i<count;++i)job(i);
 }
};
template<class Cache> long long run(TerrainVisual::Compositor& compositor, bool sparse, bool holes, int iterations, SDL_Surface* output) {
 auto c=compositor.catalog();const auto sand=c.find("sand"),water=c.find("water"),ice=c.find("ice"),grass=c.find("grass"),hole=c.find("void_hole");
 auto recipe=[&](int x,int y,auto id) {
  TerrainVisual::Recipe r;r.x=x;r.y=y;r.width=r.height=32;r.seed=73;r.corners.fill(id);return r;
 };
 Cache cache;
 typename Cache::Chunk page;
 std::array<typename Cache::Tile,256> tiles;
 for(unsigned i=0;i<tiles.size();++i){auto id=i%3==0?water:i%3==1?ice:sand;
  if(holes&&i%3==0)id=hole;
  tiles[i]={recipe(i%16,i/16,id),true};page.tiles[i]=tiles[i];
 }
 if(sparse)tiles[221].recipe=recipe(13,13,grass);
 page.materialRevisions={{sand,compositor.materialRevision(sand)},{water,compositor.materialRevision(water)},{ice,compositor.materialRevision(ice)},{hole,compositor.materialRevision(hole)}};
 auto started=std::chrono::steady_clock::now();
 for(int i=0;i<iterations;++i){
  bool ok;
  if constexpr(std::is_same_v<Cache,SoftwareTerrainCache>)ok=cache.tryBuildCpuPage(page,tiles,compositor,output,sparse,Cache::Budget);
  else ok=cache.buildCpuPage(page,tiles,compositor,output,sparse,Cache::Budget);
  if(!ok)throw std::runtime_error("Batch not admitted");
 }
 return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-started).count();
}
int main(){
 SDL_setenv_unsafe("SDL_VIDEODRIVER","dummy",1);SDL_setenv_unsafe("SDL_AUDIODRIVER","dummy",1);
 auto profile=std::filesystem::absolute("artifacts/render-refinement/terrain-performance/profile");std::filesystem::create_directories(profile);
 SDL_setenv_unsafe("GLOB2_USER_DATA_DIR",profile.c_str(),1);SDL_setenv_unsafe("GLOB2_RENDER_EXECUTION","serial",1);
 GlobalContainer globals("terrain-refinement");globalContainer=&globals;globals.fileManager->addDir(std::filesystem::current_path().string());
 globals.runNoX=false;globals.settings.mute=1;globals.settings.screenWidth=640;globals.settings.screenHeight=480;globals.settings.rendererBackend=GAGCore::RendererBackend::Software;globals.load();
 TerrainVisual::Compositor compositor(TerrainVisual::loadCatalog());compositor.prepare(false,0);
 InlineWork dispatcher;GAGCore::PresentationWorkScope scope(dispatcher);
 SDL_Surface* outputs[2]={SDL_CreateSurface(512,512,SDL_PIXELFORMAT_ARGB8888),SDL_CreateSurface(512,512,SDL_PIXELFORMAT_ARGB8888)};
 for(auto* output:outputs)if(!output)throw std::bad_alloc();
 printf("case,round,iterations,before_ns,after_ns,exact\n");
 for(bool sparse:{false,true})for(bool holes:{false,true}){
  int iterations=sparse?1000:100;
  for(int round=0;round<10;++round){
   long long times[2];
   for(auto* output:outputs)SDL_FillSurfaceRect(output,nullptr,0xff123456);
   for(int step=0;step<2;++step){int path=(round+step)%2;
    times[path]=path?run<SoftwareTerrainCache>(compositor,sparse,holes,iterations,outputs[1]):run<SoftwareTerrainCacheReference>(compositor,sparse,holes,iterations,outputs[0]);
   }
   for(int y=0;y<512;++y)if(std::memcmp(static_cast<char*>(outputs[0]->pixels)+y*outputs[0]->pitch,static_cast<char*>(outputs[1]->pixels)+y*outputs[1]->pitch,512*4))throw std::runtime_error("Pixels differ");
   printf("%s_%s,%d,%d,%lld,%lld,true\n",sparse?"sparse":"cold",holes?"holes":"opaque",round,iterations,times[0],times[1]);fflush(stdout);
  }
 }
 for(auto* output:outputs)SDL_DestroySurface(output);globalContainer=nullptr;
}
