#include "ComputeExecutor.h"
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <thread>
static std::atomic<unsigned> checks;
static void require(bool v) { ++checks; if (!v) throw std::runtime_error("check failed"); }
template<class F> static void rejected(F f) { bool caught=false; try { f(); } catch(const std::logic_error&) { caught=true; } require(caught); }
int main() {
 try {
 for (unsigned threads : {1u, 4u}) {
  ComputeExecutor ex; ex.configure(threads);
  ex.executePresentationJobs(0,{}); require(ex.graphicsMetrics().batches==0);
  const auto owner=std::this_thread::get_id();
  ex.executePresentationJobs(1,[&](auto index) {
   require(index==0);
#ifdef __EMSCRIPTEN__
   require(std::this_thread::get_id()==owner);
#else
   require((std::this_thread::get_id()==owner)==(threads==1));
#endif
   rejected([&]{ ex.configure(1); });
   rejected([&]{ ex.executePresentationJobs(0,{}); });
   rejected([&]{ ex.submitPresentationBatch(0,{2},{}); });
   ComputeExecutor::PresentationBatchTicket ticket;
   rejected([&]{ ex.finishPresentationBatch(ticket); });
  });
  require(ex.graphicsMetrics().batches==1 && ex.graphicsMetrics().jobs==1 );
  for (unsigned iteration=0;iteration<100;++iteration) {
   std::array<std::atomic<unsigned>,17> output{};
   ex.executePresentationJobs(output.size(),[&](auto i){ ++output[i]; rejected([&]{ex.configure(1);}); });
   for (auto &n:output) require(n.load()==1);
  }
  bool failure=false; try { ex.executePresentationJobs(1,[](auto){throw std::runtime_error("expected");}); }
  catch(const std::runtime_error& e){failure=std::string(e.what())=="expected";} require(failure);
  ex.configure(1); unsigned scene=0, simulation=0, graphics=0;
  auto preparation=ex.submitPresentation(1,[&](auto){++scene;});
  ComputeExecutor::Group group{1,{[](void* p,std::size_t){++*static_cast<unsigned*>(p);},&simulation}};
  auto pending=ex.submit(std::span(&group,1));
  try { ex.executePresentationJobs(10,[&](auto i){++graphics;if(i==1)throw std::runtime_error("expected");}); } catch(const std::runtime_error&){}
  require(graphics==2 && scene==0 && simulation==0 && ex.graphicsMetrics().jobs==2);
  ex.executePresentationJobs(2,[&](auto){++graphics;}); require(graphics==4);
  ex.join(pending); ex.cancelPresentationAndWait(); require(simulation==1);
 }
 setenv("GLOB2_RENDER_WORKERS","1",1);
 ComputeExecutor ex;ex.configure(4);const auto owner=std::this_thread::get_id();
 ex.executePresentationJobs(17,[&](auto){
#ifdef __EMSCRIPTEN__
 require(std::this_thread::get_id()==owner);
#else
 require(std::this_thread::get_id()!=owner);
#endif
 rejected([&]{ex.configure(1);}); });
 require(ex.graphicsMetrics().parallelBatches==0 && ex.graphicsMetrics().jobs==17);
 ex.configure(1); auto admitted=ex.submitPresentationBatch(3,{2},[](auto){});
 rejected([&]{ex.executePresentationJobs(1,[](auto){});});
 ex.finishPresentationBatch(admitted);
#ifdef __EMSCRIPTEN_PTHREADS__
 ex.configure(2);std::atomic<bool> entered{false}, release{false}, overlap{false};
 auto scene=ex.submitPresentation(1,[&](auto){entered.store(true);while(!release.load())std::this_thread::yield();});
 while(!entered.load())std::this_thread::yield();
 std::thread unblock([&]{std::this_thread::sleep_for(std::chrono::milliseconds(20));release.store(true);});
 ex.executePresentationJobs(3,[&](auto){if(!release.load())overlap.store(true);});
 unblock.join();require(!overlap.load());require(scene->finished());
 for(unsigned iteration=0;iteration<20;++iteration) {
  entered.store(false);release.store(false);
  auto heldScene=ex.submitPresentation(1,[&](auto){entered.store(true);while(!release.load())std::this_thread::yield();});
  while(!entered.load())std::this_thread::yield();
  auto raw=ex.submitPresentationBatch(3,{1},[](auto){});
  std::thread canceller([&]{std::this_thread::sleep_for(std::chrono::milliseconds(2));raw.cancel();});
  ex.finishPresentationBatch(raw);canceller.join();
  require(raw.finished() && raw.status()==ComputeExecutor::Presentation::Status::Canceled);
  require(!heldScene->finished());release.store(true);ex.cancelPresentationAndWait();
 }
#endif
 std::printf("PASS adapter checks=%u\n", checks.load());
 } catch(const std::exception& e) {std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}
}
