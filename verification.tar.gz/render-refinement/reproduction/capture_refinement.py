import hashlib,json,os,subprocess,tempfile
from pathlib import Path
from PIL import Image,ImageChops
root=Path.cwd();out=root/'artifacts/render-refinement/stable-captures';out.mkdir(exist_ok=True)
base=Path('/home/bradley/glob2/artifacts/pr-1148-parallel-rendering/release-benchmarks/SoftwareRenderBenchmark');candidate=root/'build/linux/client/release/test/SoftwareRenderBenchmark';fixture=Path('/home/bradley/.codex/worktrees/parallel-rendering/glob2/artifacts/render-parallel/fixture.game')
results={'scope':'600 fixed frames +20 warmup, identical camera updates, enough elapsed GUI drawing to stabilize the nonadvancing simulation tick-rate readout; retained original 120-frame captures separately','runs':[],'cases':[]}
for case in ['half-gui','fractional-gui']:
 hashes=[]
 for mode in ['auto','serial','parallel']:
  for variant in ['baseline','candidate']:
   name=f'{case}-{mode}-{variant}';bmp=out/f'{name}.bmp'
   configured={'PROFILE_SAVE':str(fixture),'PROFILE_MODE':'gui','PROFILE_ZOOM':'0.5','PROFILE_FRAMES':'600','PROFILE_WARMUP':'20','PROFILE_CLOUDS':'0','PROFILE_NO_PRESENT':'1','PROFILE_CAPTURE':str(bmp),'GLOB2_RENDER_EXECUTION':mode,'GLOB2_RENDER_WORKERS':'2','GLOB2_UI_SCALE':'1'}
   configured['PROFILE_PAN' if case=='half-gui' else 'PROFILE_FRACTION']='1'
   with tempfile.TemporaryDirectory(prefix='glob2-stable-capture-') as profile:
    configured['GLOB2_USER_DATA_DIR']=profile
    env={k:v for k,v in os.environ.items() if not k.startswith('PROFILE_')};env.update(configured)
    command=['xvfb-run','-a',str(base if variant=='baseline' else candidate),'--compute-threads','4','--renderer','software','--window-size','1280x800','--mute','--no-fullscreen'];r=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
   (out/f'{name}.log').write_text(r.stdout)
   if r.returncode:raise RuntimeError(f'{name} failed')
   image=Image.open(bmp).convert('RGBA');image.save(out/f'{name}.png');digest=hashlib.sha256(image.tobytes()).hexdigest();hashes.append(digest)
   results['runs'].append({'name':name,'command':command,'environment':configured,'rgba_sha256':digest});print(name,digest,flush=True)
  (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 results['cases'].append({'case':case,'all_six_identical':len(set(hashes))==1,'rgba_sha256':hashes});(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 if len(set(hashes))!=1:raise RuntimeError(f'{case}: stable pixel mismatch')
