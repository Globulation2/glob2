import hashlib,json,os,re,subprocess,tempfile,time
from pathlib import Path
root=Path.cwd();out=root/'artifacts/render-refinement/interactive';out.mkdir(exist_ok=True)
base=Path('/home/bradley/glob2/artifacts/pr-1148-parallel-rendering/release-benchmarks/SoftwareRenderBenchmark');candidate=root/'build/linux/client/release/test/SoftwareRenderBenchmark';fixture=Path('/home/bradley/.codex/worktrees/parallel-rendering/glob2/artifacts/render-parallel/fixture.game')
results={'scope':'three alternating pairs per mode; production simulation/scene/render contention; run distributions, not pooled percentiles or statistical FPS claims','runs':[]}
for mode in ['auto','serial','parallel']:
 for repeat in range(3):
  for variant in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
   name=f'{mode}-{repeat}-{variant}'
   configured={'PROFILE_SAVE':str(fixture),'PROFILE_MODE':'interactive','PROFILE_SECONDS':'10','PROFILE_FPS':'60','PROFILE_PAN':'1','PROFILE_CLOUDS':'0','GLOB2_RENDER_EXECUTION':mode,'GLOB2_RENDER_WORKERS':'2','GLOB2_UI_SCALE':'1'}
   with tempfile.TemporaryDirectory(prefix='glob2-interactive-refinement-') as profile:
    configured['GLOB2_USER_DATA_DIR']=profile
    env={k:v for k,v in os.environ.items() if not k.startswith('PROFILE_')};env.update(configured)
    command=['xvfb-run','-a',str(base if variant=='baseline' else candidate),'--compute-threads','4','--renderer','software','--window-size','1280x800','--mute','--no-fullscreen']
    load=os.getloadavg();r=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
   (out/f'{name}.log').write_text(r.stdout)
   if r.returncode: raise RuntimeError(f'{name} failed {r.returncode}')
   distributions={}
   for label in ['draw_and_present','displayed_scene_age','last_simulation_deadline_lateness']:
    match=re.search(rf'{label} mean_ms=([\d.]+) median_ms=([\d.]+) p95_ms=([\d.]+) p99_ms=([\d.]+)',r.stdout)
    if not match:raise RuntimeError(f'Missing {label} in {name}')
    distributions[label]=dict(zip(['mean_ms','median_ms','p95_ms','p99_ms'],map(float,match.groups())))
   results['runs'].append({'name':name,'variant':variant,'mode':mode,'repeat':repeat,'command':command,'environment':configured,'load_average_before':load,'distributions':distributions})
   (out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,distributions['draw_and_present'],flush=True)
