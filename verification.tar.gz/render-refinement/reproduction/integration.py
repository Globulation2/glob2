import json,os,subprocess
from pathlib import Path
root=Path.cwd();out=root/'artifacts/render-refinement'
env=os.environ.copy();env.update(GLOB2_TEST_SHADER_DIRECTORY='/home/bradley/glob2/artifacts/pr-1148-parallel-rendering/native-shaders',GLOB2_RENDERER_SHADER_DIR='/home/bradley/glob2/artifacts/pr-1148-parallel-rendering/native-shaders',GLOB2_RENDER_EXECUTION='parallel',GLOB2_RENDER_WORKERS='2')
filters=['SoftwareRenderer/*','TerrainMaterials/*','TerrainPresentation/*','RendererSwitchIntegration/*','MapRenderResize/*','EngineSession/*','GameplayRecording.Integration/*','GradientPreparation/*','SharedWorkerLifecycle/*','LegacyRoundTripSave/*','ClientChannels/*','TurnEngineHarness/*','ResourceGrowth/*','SceneExtract/*','SimulationReadPhase/*','MCP/*']
command=['python3','test/run_tests.py','--build-dir','build/linux/client/debug/dev-dev_fast-true-linker-auto','--binary','engine','-j4','--display-jobs','1','--timeout','600','--write-inventory',str(out/'engine-inventory.json'),'--junit',str(out/'engine.xml'),'--artifacts',str(out/'engine')]
for f in filters:command+=['--filter',f]
(out/'engine-command.json').write_text(json.dumps({'command':command,'environment':{k:v for k,v in env.items() if k.startswith('GLOB2_') and k!='GLOB2_OFFICIAL_INSTANCE_TOKEN'}},indent=2)+'\n')
with (out/'engine.log').open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(r.returncode)
