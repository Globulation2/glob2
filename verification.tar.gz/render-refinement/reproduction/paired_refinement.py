import hashlib,json,os,re,statistics,subprocess,tempfile,time
from pathlib import Path
root=Path.cwd();out=root/'artifacts/render-refinement/whole-renderer'
base=Path('/home/bradley/glob2/artifacts/pr-1148-parallel-rendering/release-benchmarks/SoftwareRenderBenchmark')
candidate=root/'build/linux/client/release/test/SoftwareRenderBenchmark'
fixture=Path('/home/bradley/.codex/worktrees/parallel-rendering/glob2/artifacts/render-parallel/fixture.game')
common={'PROFILE_SAVE':str(fixture),'PROFILE_FRAMES':'120','PROFILE_WARMUP':'20','PROFILE_NO_PRESENT':'1','PROFILE_CPU_SCOPES':'1','PROFILE_CLOUDS':'0','GLOB2_RENDER_WORKERS':'2','GLOB2_UI_SCALE':'1'}
cases={'static-map':{'PROFILE_MODE':'map','PROFILE_WHOLE_MAP':'1','PROFILE_PAUSED':'1'},'animated-map':{'PROFILE_MODE':'map','PROFILE_WHOLE_MAP':'1'},'half-gui':{'PROFILE_MODE':'gui','PROFILE_ZOOM':'0.5','PROFILE_PAN':'1'},'fractional-gui':{'PROFILE_MODE':'gui','PROFILE_ZOOM':'0.5','PROFILE_FRACTION':'1'},'streamed-map':{'PROFILE_MODE':'map','PROFILE_WHOLE_MAP':'1','PROFILE_TERRAIN_CACHE':'0'}}
def compiler_count():
 count=0
 for p in Path('/proc').glob('[0-9]*/comm'):
  try: count+=p.read_text().strip() in {'cc1plus','cc1'}
  except OSError: pass
 return count
results={'baseline_revision':'f9eae2549f608f804c240709df819bfe5f09f3fb','candidate_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [base,candidate,fixture]},'runs':[],'summary':[]}
for case,extra in cases.items():
 for mode in (['parallel'] if case=='streamed-map' else ['auto','serial','parallel']):
  values={'baseline':[],'candidate':[]}; captures={}
  for repeat in range(7):
   for variant in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
    name=f'{case}-{mode}-{repeat}-{variant}'
    configured={**common,**extra,'GLOB2_RENDER_EXECUTION':mode}
    if repeat==0: configured['PROFILE_CAPTURE']=str(out/f'{name}.bmp')
    with tempfile.TemporaryDirectory(prefix='glob2-refinement-') as profile:
     configured['GLOB2_USER_DATA_DIR']=profile
     env={k:v for k,v in os.environ.items() if not k.startswith('PROFILE_')};env.update(configured)
     command=['xvfb-run','-a',str(base if variant=='baseline' else candidate),'--compute-threads','4','--renderer','software','--window-size','1280x800','--mute','--no-fullscreen']
     load_before=os.getloadavg();compilers_before=compiler_count();start=time.time();r=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
    (out/f'{name}.log').write_text(r.stdout)
    if r.returncode: raise RuntimeError(f'{name} failed {r.returncode}')
    cpu=float(re.search(r'process_cpu_ms_per_frame=([\d.]+)',r.stdout)[1]);draw=float(re.search(r'draw mean_ms=.*?median_ms=([\d.]+)',r.stdout)[1]) if re.search(r'draw mean_ms=.*?median_ms=([\d.]+)',r.stdout) else None
    values[variant].append(cpu)
    if repeat==0: captures[variant]=hashlib.sha256((out/f'{name}.bmp').read_bytes()).hexdigest()
    results['runs'].append({'name':name,'case':case,'mode':mode,'variant':variant,'repeat':repeat,'command':command,'environment':configured,'cpu_ms':cpu,'draw_median_ms':draw,'elapsed_wall_s':time.time()-start,'load_average_before':load_before,'compiler_processes_before':compilers_before})
    print(name,cpu,flush=True)
  before=statistics.median(values['baseline']);after=statistics.median(values['candidate'])
  row={'case':case,'mode':mode,'baseline_cpu_ms':before,'candidate_cpu_ms':after,'ratio':after/before,'captures_identical':captures['baseline']==captures['candidate'],'capture_hashes':captures,'values':values}
  results['summary'].append(row);print('SUMMARY',row,flush=True)
  (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
