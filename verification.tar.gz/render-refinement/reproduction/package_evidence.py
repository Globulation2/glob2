from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path.cwd();source=root/'artifacts/render-refinement';stage=source/'publish';stage.mkdir(exist_ok=True)
allowed={'.log','.json','.csv','.xml','.md','.txt','.cpp','.h','.py','.game','.gz','.rep','.replay','.trace','.g2mr','.checksums','.map','.jsonl','.value','.png','.bmp','.mp4','.webm'}
excluded={'publish','before-classifier-fix','baseline','profile','profiles','crash-diagnostics'}
files={}
with tarfile.open(stage/'verification.tar.gz','w:gz') as tar:
 for p in sorted(source.rglob('*')):
  relative=p.relative_to(source)
  if not p.is_file() or any(part in excluded for part in relative.parts) or 'superseded' in p.name or p.name in {'files.json','adapter-perf.cpp','build-round1.log','release-round1.log'}:continue
  if p.suffix not in allowed:continue
  if p.stat().st_size>50*1024*1024:continue
  files[str(relative)]=hashlib.sha256(p.read_bytes()).hexdigest();tar.add(p,arcname=Path('render-refinement')/relative)
 for p in [root/'docs/.work/paired_refinement.py',root/'docs/.work/integration.py',root/'docs/.work/interactive_refinement.py',root/'docs/.work/capture_refinement.py',root/'docs/.work/package_evidence.py',Path('/home/bradley/.codex/worktrees/parallel-rendering/glob2/artifacts/render-parallel/fixture.game')]:
  relative=Path('reproduction')/p.name;files[str(relative)]=hashlib.sha256(p.read_bytes()).hexdigest();tar.add(p,arcname=Path('render-refinement')/relative)
 manifest=source/'files.json';manifest.write_text(json.dumps(files,indent=2)+'\n');tar.add(manifest,arcname='render-refinement/files.json')
(stage/'SHA256SUMS').write_text(hashlib.sha256((stage/'verification.tar.gz').read_bytes()).hexdigest()+'  verification.tar.gz\n')
print('Included',len(files),'files; archive bytes',(stage/'verification.tar.gz').stat().st_size)
