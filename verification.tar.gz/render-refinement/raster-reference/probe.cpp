#include <SurfaceRaster.h>
#include "SurfaceRasterReference.h"
#include <SDL3/SDL.h>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <random>
int main() {
 std::mt19937 random(9713); unsigned checks=0;
 for(auto format:{SDL_PIXELFORMAT_ARGB8888,SDL_PIXELFORMAT_RGBA32,SDL_PIXELFORMAT_XRGB8888})
 for(unsigned iteration=0;iteration<1200;++iteration) {
  auto* source=SDL_CreateSurface(23,19,format);auto* a=SDL_CreateSurface(267,61,format);auto* b=SDL_CreateSurface(267,61,format);assert(source&&a&&b);
  const bool opaque=iteration%7==0;
  for(int y=0;y<19;++y)for(int x=0;x<23;++x)reinterpret_cast<Uint32*>(static_cast<Uint8*>(source->pixels)+y*source->pitch)[x]=random()|(opaque?0xff000000u:0u);
  for(int y=0;y<61;++y)for(int x=0;x<267;++x) { auto value=random(); std::memcpy(static_cast<Uint8*>(a->pixels)+y*a->pitch+x*4,&value,4);std::memcpy(static_cast<Uint8*>(b->pixels)+y*b->pitch+x*4,&value,4); }
  const SDL_Rect clip{int(random()%7),int(random()%7),253,47};SDL_SetSurfaceClipRect(a,&clip);SDL_SetSurfaceClipRect(b,&clip);
  SDL_Rect src{int(random()%15)-7,int(random()%13)-6,int(random()%31)+1,int(random()%29)+1};
  SDL_Rect dst{int(random()%31)-15,int(random()%29)-14,int(random()%391)+1,int(random()%83)+1};
  if(iteration%4==0) {src={0,0,23,19};dst.w=23;dst.h=19;}
  const Uint8 alpha=iteration%5==0?255:random()%256;
  if(iteration%11==0)SDL_SetSurfaceColorKey(source,true,0);
  if(iteration%13==0)SDL_SetSurfaceColorMod(source,91,173,37);
  if(iteration%17==0)SDL_SetSurfaceAlphaMod(source,119);
  const auto blend=iteration%3;
  GAGCore::SurfaceRaster::blit(a,source,src,dst,alpha,opaque,static_cast<GAGCore::SurfaceRaster::BlitBlend>(blend));
  GAGCore::SurfaceRasterReference::blit(b,source,src,dst,alpha,opaque,static_cast<GAGCore::SurfaceRasterReference::BlitBlend>(blend));
  for(int y=0;y<61;++y)if(std::memcmp(static_cast<Uint8*>(a->pixels)+y*a->pitch,static_cast<Uint8*>(b->pixels)+y*b->pitch,267*4)) {fprintf(stderr,"blit mismatch format=%u iteration=%u blend=%u alpha=%u row=%d\n",format,iteration,blend,alpha,y);return 1;}
  const auto color=SDL_MapSurfaceRGBA(a,random()%256,random()%256,random()%256,255);
  GAGCore::SurfaceRaster::fill(a,dst,color,alpha,static_cast<GAGCore::SurfaceRaster::FillBlend>(iteration%2));
  GAGCore::SurfaceRasterReference::fill(b,dst,color,alpha,static_cast<GAGCore::SurfaceRasterReference::FillBlend>(iteration%2));
  for(int y=0;y<61;++y)assert(!std::memcmp(static_cast<Uint8*>(a->pixels)+y*a->pitch,static_cast<Uint8*>(b->pixels)+y*b->pitch,267*4));
  ++checks;SDL_DestroySurface(source);SDL_DestroySurface(a);SDL_DestroySurface(b);
 }
 printf("PASS independent base-revision raster parity: %u blit/fill pairs (seed 9713)\n",checks);
}
