#include <RenderBackend.h>
#include <RenderFrame.h>
#include <PresentationWork.h>
#include <PerformanceTelemetry.h>
#include <SurfaceRaster.h>
#include "SurfaceRasterMerged.h"
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <vector>
#include <stdexcept>
namespace GAGMerged {
std::unique_ptr<GAGCore::RenderBackend> makeSoftwareRenderBackend(SDL_Surface *);
std::unique_ptr<GAGCore::RenderBackend> makeSDLSoftwareGeometryBackend(SDL_Surface *) {throw std::logic_error("unused geometry");}
void setSDLSoftwareTargetScissor(GAGCore::RenderBackend &, const SDL_Rect *) {throw std::logic_error("unused geometry");}
}
namespace GAGCore {
std::unique_ptr<RenderBackend> makeSDLSoftwareGeometryBackend(SDL_Surface *) {throw std::logic_error("unused geometry");}
void setSDLSoftwareTargetScissor(RenderBackend &, const SDL_Rect *) {throw std::logic_error("unused geometry");}
namespace detail { SDL_Rect intersectTargetScissor(SDL_Rect r, const std::optional<SDL_Rect>& clip) {if(clip)SDL_GetRectIntersection(&r,&*clip,&r);return r;} }
}
namespace PerformanceTelemetry {
Scope::Scope(Id value,int) : id(value) {}
Scope::~Scope() {}
}

int main() {
 for(bool negativeSource : {false,true}) {
  std::vector<Uint32> actual(16),expected;
  for(unsigned i=0;i<16;++i)actual[i]=0xff000000u+i*977;
  expected=actual;
  int sourceOffset=negativeSource?7:3,sourceHeight=negativeSource?4:1,sourcePitch=negativeSource?-8:8;
  int targetOffset=negativeSource?4:8,targetHeight=negativeSource?1:4,targetPitch=negativeSource?8:-8;
  const auto format=*SDL_GetPixelFormatDetails(SDL_PIXELFORMAT_ARGB8888);
  GAGCore::SurfaceRaster::RasterCommand command;command.kind=decltype(command.kind)::Blit;command.opaque=true;
  command.source={reinterpret_cast<const Uint8*>(actual.data()+sourceOffset),2,sourceHeight,sourcePitch,format};
  command.sourceRect={0,0,2,sourceHeight};command.destination=command.clip={0,0,2,targetHeight};
  for(int y=0;y<targetHeight;++y){int sy=(2*y+1)*sourceHeight/(2*targetHeight);for(int x=0;x<2;++x)expected[targetOffset+y*(targetPitch/4)+x]=expected[sourceOffset+sy*(sourcePitch/4)+x];}
  GAGCore::SurfaceRaster::executeCommand(command,{reinterpret_cast<Uint8*>(actual.data()+targetOffset),2,targetHeight,targetPitch,format},command.destination);
  assert(actual==expected);
 }
 struct OwnerJobs : GAGCore::PresentationWork {unsigned calls=0; void executePresentationJobs(std::size_t count,const std::function<void(std::size_t)> &job) override {++calls; for(std::size_t i=0;i<count;++i)job(i);}} work;
 std::vector<Uint32> expected;
 for(const char* mode : {"auto","serial","parallel"}) {
  setenv("GLOB2_RENDER_EXECUTION",mode,1);
  GAGCore::PresentationWorkScope scope(work);
  auto *target=SDL_CreateSurface(271,263,SDL_PIXELFORMAT_ARGB8888); assert(target);
  SDL_FillSurfaceRect(target,nullptr,0xff173b61);
  auto backend=GAGCore::makeSoftwareRenderBackend(target);
  auto* first=SDL_CreateSurface(19,17,SDL_PIXELFORMAT_ARGB8888);assert(first);
  SDL_FillSurfaceRect(first,nullptr,0xff759bc1);
  backend->blitPixels(first,{0,0,19,17},{1,2,267,257},173);
  SDL_DestroySurface(first);backend->flush();
  if(!std::strcmp(mode,"parallel"))assert(work.calls>0);
  for(int i=0;i<1030;++i) {
   auto* source=SDL_CreateSurface(19,17,SDL_PIXELFORMAT_ARGB8888);assert(source);
   SDL_FillSurfaceRect(source,nullptr,0xff000000u+Uint32(i*977));
   backend->blitPixels(source,{0,0,19,17},{i%211,i%197,39,35},173);
   SDL_FillSurfaceRect(source,nullptr,0xffcc9966);
   SDL_DestroySurface(source);
  }
  backend->flush();
  std::vector<Uint32> pixels;
  for(int y=0;y<263;++y){const auto* row=reinterpret_cast<const Uint32*>(static_cast<const Uint8*>(target->pixels)+y*target->pitch);pixels.insert(pixels.end(),row,row+271);}
  if(expected.empty())expected=pixels;else assert(pixels==expected);
  const auto batches=backend->operations().rasterBatches, bytes=backend->operations().rasterSnapshotBytes;
  auto* source=SDL_CreateSurface(19,17,SDL_PIXELFORMAT_ARGB8888);assert(source);
  backend->fillPixels({1,2,17,13},{31,77,123,0});backend->blitPixels(source,{0,0,19,17},{1,2,39,35},0);
  backend->fillPixels({300,2,17,13},{31,77,123,255});backend->blitPixels(source,{0,0,19,17},{300,2,39,35},173);
  backend->flush();assert(backend->operations().rasterBatches==batches);assert(backend->operations().rasterSnapshotBytes==bytes);
  SDL_DestroySurface(source);backend.reset();SDL_DestroySurface(target);
 }
 assert(GAGCore::RenderWorkReservation::available()==GAGCore::RenderWorkReservation::Limit);
 puts("PASS negative source/target pitch aliasing, 1030 destroyed/mutated source captures per mode, auto/serial/tiled parity, transparent/clipped no-ops, and reservation release");
}
