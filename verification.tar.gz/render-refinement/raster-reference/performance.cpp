#include <RenderBackend.h>
#include <RenderFrame.h>
#include <PresentationWork.h>
#include <PerformanceTelemetry.h>
#include <SurfaceRaster.h>
#include "SurfaceRasterMerged.h"
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <vector>
#include <stdexcept>
namespace GAGMerged {
std::unique_ptr<GAGCore::RenderBackend> makeSoftwareRenderBackend(SDL_Surface *);
std::unique_ptr<GAGCore::RenderBackend> makeSDLSoftwareGeometryBackend(SDL_Surface *) {throw std::logic_error("unused geometry");}
void setSDLSoftwareTargetScissor(GAGCore::RenderBackend &, const SDL_Rect *) {throw std::logic_error("unused geometry");}
}
namespace GAGCore {
std::unique_ptr<RenderBackend> makeSDLSoftwareGeometryBackend(SDL_Surface *) {throw std::logic_error("unused geometry");}
void setSDLSoftwareTargetScissor(RenderBackend &, const SDL_Rect *) {throw std::logic_error("unused geometry");}
namespace detail { SDL_Rect intersectTargetScissor(SDL_Rect r, const std::optional<SDL_Rect>& clip) {if(clip)SDL_GetRectIntersection(&r,&*clip,&r);return r;} }
}
namespace PerformanceTelemetry {
Scope::Scope(Id value,int) : id(value) {}
Scope::~Scope() {}
}
using Clock=std::chrono::steady_clock;
template<class Fn> long long ns(Fn fn) {const auto start=Clock::now();fn();return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count();}
int main() {
 setenv("GLOB2_RENDER_EXECUTION","serial",1);
 auto* wide=SDL_CreateSurface(300000,1,SDL_PIXELFORMAT_ARGB8888);assert(wide);
 auto old=GAGMerged::makeSoftwareRenderBackend(wide), current=GAGCore::makeSoftwareRenderBackend(wide);
 auto narrow=[&](auto &backend){for(int n=0;n<12;++n){for(int i=0;i<1024;++i)backend->fillPixels({149000+i%17,0,3,1},{Uint8(i),31,117,79});backend->flush();}};
 const auto format=*SDL_GetPixelFormatDetails(SDL_PIXELFORMAT_ARGB8888);
 std::vector<Uint32> source(128*128,0x7f759bc1),target(128*128,0x10305070);
 GAGCore::SurfaceRaster::RasterCommand command;command.kind=decltype(command.kind)::Blit;
 command.source={reinterpret_cast<const Uint8*>(source.data()),128,128,128*4,format};command.sourceRect={0,0,128,128};command.destination=command.clip=command.sourceRect;command.opaque=true;
 GAGCore::SurfaceRasterMerged::RasterCommand original;original.kind=decltype(original.kind)::Blit;original.source={command.source.pixels,128,128,128*4,format};original.sourceRect=original.destination=original.clip=command.sourceRect;original.opaque=true;
 GAGCore::SurfaceRaster::WritablePixelView output{reinterpret_cast<Uint8*>(target.data()),128,128,128*4,format};
 GAGCore::SurfaceRasterMerged::WritablePixelView previous{output.pixels,128,128,128*4,format};
 auto rowsOld=[&]{for(int i=0;i<12000;++i)GAGCore::SurfaceRasterMerged::executeCommand(original,previous,original.clip);};
 auto rowsNew=[&]{for(int i=0;i<12000;++i)GAGCore::SurfaceRaster::executeCommand(command,output,command.clip);};
 std::puts("trial,narrow_old_ns,narrow_new_ns,rows_old_ns,rows_new_ns");
 for(int trial=0;trial<7;++trial){long long a,b,c,d;if(trial%2){b=ns([&]{narrow(current);});a=ns([&]{narrow(old);});d=ns(rowsNew);c=ns(rowsOld);}else{a=ns([&]{narrow(old);});b=ns([&]{narrow(current);});c=ns(rowsOld);d=ns(rowsNew);}std::printf("%d,%lld,%lld,%lld,%lld\n",trial,a,b,c,d);}
 assert(target==source);current.reset();old.reset();SDL_DestroySurface(wide);
}
