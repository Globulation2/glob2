from pathlib import Path
import hashlib,json,platform,subprocess,tarfile,xml.etree.ElementTree as ET
r=Path.cwd();o=r/'artifacts/render-execution-names';m=json.loads((o/'validation.json').read_text());m.update(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),base=subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip(),platform=platform.platform(),compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],build_command='GLOB2_SDL3_PREFIX=/home/bradley/glob2/build/sdl3/prefix python3 tools/dev_build.py -j8 unit-tests engine-tests',build_flags='dev_fast=1, linker=auto, -O0 -g1; no new performance claims',runtime_dependencies='existing pinned prefix; SDL3.4.16',limits='Linux native naming/dispatch/pixel/terrain checks; other platforms not executed. No rendering algorithms, simulation scheduling/state, save/replay/network formats or runtime dependencies changed.')
for b in ['unit','engine']:
 p=r/'build/linux/client/debug/dev-dev_fast-true-linker-auto/test'/f'glob2-{b}-tests';m[f'{b}_binary_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();x=ET.parse(o/f'{b}.xml').getroot();suites=[x] if x.tag=='testsuite' else list(x.findall('testsuite'));m[f'{b}_junit']={k:int(x.get(k,0)) for k in ['tests','failures','errors','skipped']}
(o/'validation.json').write_text(json.dumps(m,indent=2)+'\n')
(o/'change.patch').write_bytes(subprocess.check_output(['git','diff','HEAD^','HEAD']))
with tarfile.open(o/'verification.tar.gz','w:gz') as t:
 for p in sorted(o.rglob('*')):
  if p.is_file() and p.suffix in {'.json','.xml','.log','.cpp','.py','.patch','.png','.bmp'} and p.name not in {'build.log','build-final.log'} and '__pycache__' not in p.parts:t.add(p,arcname=p.relative_to(o))
(o/'SHA256SUMS').write_text(hashlib.sha256((o/'verification.tar.gz').read_bytes()).hexdigest()+'  verification.tar.gz\n')
print(json.dumps(m,indent=2))
