// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "CustomGameSetup.h"
#include "LegacyGenerationDescriptor.h"
#include "RulesetCatalog.h"
#include "Settings.h"
#include <FileManager.h>
#include <Stream.h>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <memory>
#include <sstream>
#include <vector>

// Preferences contain a reusable draft, never a generated world or RNG state.
// Decode into a temporary object so a corrupt/truncated file cannot partially
// replace the current setup. Invalid but editable drafts (e.g. all Closed) are
// intentionally preserved; launch validation still belongs to the setup model.
struct CustomGamePreferences
{
	static constexpr const char *filename = "custom-game-settings.txt";
	CustomGameSetup setup;
    std::string missingGeneratorId;
	bool userMaps = false;
	std::string librarySelection[2];
	bool expanded[3] = {false, false, false};
	// The landscape picker's sort order (LandscapePickerScreen::SortOrder): 0 random (its
	// catalog order, shuffled once so no landscape is favoured), 1 alphabetical. Kept as a plain
	// int here, the same way other UI choices in this struct are, so the wire format does not
	// depend on that screen's header.
	int landscapeSortOrder = 0;

	struct Field
	{
		const char *name;
		Sint32 MapGenerationDescriptor::*member;
		int minimum, maximum;
	};
	static const std::vector<Field> &fields()
	{
		// Bounds are a safe envelope across every generator method's current
		// registry range for the reused legacy field (e.g. riverDiameter also
		// stands in for river width, lake size - Fjord's reaches 0 and 90, Old
		// growth's 160 - channel width and bridge width; craterDensity also
		// stands in for Ring world's lake density, which reaches 0; grassRatio
		// also stands in for Isles' island size; extraIslands also counts Tidal
		// flats' oases, which reach 10). This only needs to be at least as wide
		// as what setMethodDefaults() and every registered control can
		// produce; it is not a tight per-method bound. Controls with no
		// legacy field are saved in the options section instead.
		static const std::vector<Field> values = {
#define FIELD(name, lo, hi) {#name, &MapGenerationDescriptor::name, lo, hi}
			FIELD(wDec, 6, 9), FIELD(hDec, 6, 9),
			FIELD(waterRatio, 0, 100), FIELD(sandRatio, 0, 100),
			FIELD(grassRatio, 0, 100), FIELD(desertRatio, 0, 100),
			FIELD(wheatRatio, 0, 64), FIELD(woodRatio, 0, 64),
			FIELD(fruitRatio, 0, 64), FIELD(algaeRatio, 0, 64),
			FIELD(stoneRatio, 0, 64), FIELD(riverDiameter, 0, 160),
			FIELD(craterDensity, 0, 64), FIELD(extraIslands, 0, 10),
			FIELD(oldIslandSize, 1, 70), FIELD(oldBeach, 0, 4),
			FIELD(smooth, 1, 8), FIELD(nbTeams, 2, Team::MAX_COUNT),
			FIELD(nbWorkers, 1, 8)
#undef FIELD
		};
		return values;
	}
	std::string encode() const
	{
		// Keep the legacy descriptor fields and corruption-recovery bounds for old
		// native preferences. Version 8 adds a custom string ID and stores every
		// custom option separately; it never persists a session numeric handle.
		auto legacy = toLegacyDescriptor(setup.generator);
		const auto &selected = setup.generator.definition();
		const bool custom = !selected.packageHash.empty();
		if (custom)
			legacy.method = MapGenerationDescriptor::Method(
				GeneratorRegistry::builtins().methods(false).front());
		std::ostringstream out;
		out << "glob2-custom-game 8\n"
			<< "setup " << setup.random << ' ' << setup.capacity << ' ' << setup.prestige << ' '
			<< setup.revealed << ' ' << setup.locked << ' ' << setup.speed << ' ' << userMaps
			<< '\n'
			<< "rules " << setup.noResourceGrowth << ' ' << setup.resourceScarcity << ' '
			<< setup.instantConstruction << ' ' << setup.stockpileStart << ' ' << setup.noHunger
			<< ' ' << setup.unitUpgradesDisabled << ' ' << setup.glassCannonLevel << ' '
			<< setup.unitsFearless << ' ' << setup.permadeathDisabled << ' ' << setup.peacefulMode
			<< ' ' << setup.buildingHpLevel << ' ' << setup.startingUnitLevel << ' '
			<< setup.suddenDeathMinutes << '\n'
			<< "probability " << setup.winProbabilityPermille << '\n'
			<< "labels " << std::quoted(std::string(setup.legacyFormat())) << ' '
			<< std::quoted(setup.rulesetId) << '\n'
			<< "map " << std::quoted(setup.premadeMap) << '\n'
			<< "libraries " << std::quoted(librarySelection[0]) << ' '
			<< std::quoted(librarySelection[1]) << '\n'
			<< "sections " << expanded[0] << ' ' << expanded[1] << ' ' << expanded[2] << '\n'
			<< "picker " << landscapeSortOrder << '\n'
			<< "generator " << int(legacy.method) << ' ' << legacy.logRepeatAreaTimes << '\n';
		out << "custom-generator " << std::quoted(custom ? std::string(selected.id) : std::string{})
			<< '\n';
		for (const auto &f : fields())
			out << f.name << ' ' << legacy.*(f.member) << '\n';
		out << "resources";
		for (auto value : legacy.resource) out << ' ' << value;
		// Every control the legacy fields can't hold (newer generators' options, switches
		// included). Files written before this section still load, with those at defaults.
		std::vector<const GeneratorControl *> options;
		for (const auto &c : setup.generator.definition().controls)
			if (custom || !hasLegacyField(setup.generator.method, c.id))
				options.push_back(&c);
		out << "\noptions " << options.size() << '\n';
		for (const auto *c : options)
			out << c->id << ' ' << c->get(setup.generator) << '\n';
		out << "colonies " << setup.colonies.size() << '\n';
		for (const auto &c : setup.colonies)
			out << int(c.controller) << ' ' << int(c.ai) << ' ' << c.alliance << ' '
				<< std::quoted(c.aiLibraryId) << '\n';
		out << "end\n";
		return out.str();
	}
	// Versions 1-6 stored the ruleset's English name, "Custom" once edited; version 7 stores
	// its id. The saved rule values are kept either way, so "Custom" reads as Standard with
	// its changes. A ruleset this build does not have (a removed or local one) also falls
	// back to Standard rather than discarding the whole draft.
	static std::string rulesetIdFromLabel(int version, const std::string &label)
	{
		std::string id = label;
		if (version < 7)
			id = label == "Quick clash"			 ? "quick-clash"
				 : label == "Open book"			 ? "open-book"
				 : label == "Last colony standing" ? "last-colony-standing"
												   : "standard";
		return RulesetCatalog::shipped().find(id) ? id : "standard";
	}
	bool decode(const std::string &text)
	{
		if (text.size() > 65536) return false;
		CustomGamePreferences draft;
		auto &s = draft.setup;
		std::istringstream in(text);
		auto word = [&](const char *expected) {
			std::string actual;
			return bool(in >> actual) && actual == expected;
		};
		auto number = [&](int &value, int lo, int hi) {
			return bool(in >> value) && value >= lo && value <= hi;
		};
		auto boolean = [&](bool &value) {
			int parsed;
			if (!number(parsed, 0, 1)) return false;
			value = parsed;
			return true;
		};
		int version, random, prestige, revealed, locked, user, method, repeat;
		if (!word("glob2-custom-game") || !number(version, 1, 8) || !word("setup") ||
			!number(random, 0, 1) || !number(s.capacity, 1, Team::MAX_COUNT) ||
			!number(prestige, 0, 1) || !number(revealed, 0, 1) || !number(locked, 0, 1) ||
			!number(s.speed, 0, Settings::GAME_SPEED_MAXIMUM) || !number(user, 0, 1))
			return false;
		// Older preferences did not store these rules; retain their normal defaults.
		if (version >= 3) {
			if (!word("rules") || !boolean(s.noResourceGrowth) || !number(s.resourceScarcity, 0, 3) ||
				!boolean(s.instantConstruction) || !number(s.stockpileStart, 0, 3) || !boolean(s.noHunger) ||
				!boolean(s.unitUpgradesDisabled) || !number(s.glassCannonLevel, 0, 2) ||
				!boolean(s.unitsFearless) || !boolean(s.permadeathDisabled) || !boolean(s.peacefulMode) ||
				!number(s.buildingHpLevel, 0, 2) || !number(s.startingUnitLevel, 0, 3) ||
				!number(s.suddenDeathMinutes, 0, 90)) return false;
			const auto &minutes = CustomGameSetup::suddenDeathMinuteChoices;
			if (std::find(minutes.begin(), minutes.end(), s.suddenDeathMinutes) == minutes.end()) return false;
		}
		if (version >= 6) {
			if (!word("probability") || !number(s.winProbabilityPermille, 0, 1000)) return false;
			const auto &choices = CustomGameSetup::winProbabilityChoices;
			if (std::find(choices.begin(), choices.end(), s.winProbabilityPermille) == choices.end()) return false;
		}
		// The teams' format name is still written for older builds, which refuse a draft
		// without one of theirs; this build reads the format from the saved alliances.
		std::string format, ruleset;
		if (!word("labels") || !(in >> std::quoted(format) >> std::quoted(ruleset))) return false;
		s.rulesetId = rulesetIdFromLabel(version, ruleset);
		if (!word("map") || !(in >> std::quoted(s.premadeMap)) || !word("libraries") ||
			!(in >> std::quoted(draft.librarySelection[0]) >> std::quoted(draft.librarySelection[1])) ||
			!word("sections")) return false;
		for (auto &expanded : draft.expanded) {
			int value;
			if (!number(value, 0, 1)) return false;
			expanded = value;
		}
		// The sort-order line was added at version 2; a version-1 file keeps the random default.
		if (version >= 2 && (!word("picker") || !number(draft.landscapeSortOrder, 0, 1))) return false;
		if (!word("generator") || !number(method, 0, 1000) || !number(repeat, 0, 5)) return false;
		// Method validity is checked against the live registry rather than a
		// hardcoded range, so it stays correct as generators are added or
		// retired. Uniform is editor-only and never a valid lobby selection.
		const auto playable = GeneratorRegistry::builtins().methods(false);
		if (std::find(playable.begin(), playable.end(), method) == playable.end()) return false;
		std::string customId;
		if (version >= 8 &&
			(!word("custom-generator") || !(in >> std::quoted(customId)) || customId.size() > 128))
			return false;
		MapGenerationDescriptor legacy;
		legacy.method = MapGenerationDescriptor::Method(method);
		for (const auto &f : fields()) {
			int value;
			if (!word(f.name) || !number(value, f.minimum, f.maximum)) return false;
			legacy.*(f.member) = value;
		}
		if (!word("resources")) return false;
		for (auto &value : legacy.resource) {
			int parsed;
			if (!number(parsed, 0, 64)) return false;
			value = parsed;
		}
		std::vector<std::pair<std::string, int>> options;
		std::string section;
		if (!(in >> section)) return false;
		if (section == "options") {
			int count;
			if (!number(count, 0, 256)) return false;
			for (int i = 0; i < count; ++i) {
				std::string id;
				int value;
				if (!(in >> id >> value)) return false;
				options.emplace_back(id, value);
			}
			if (!word("colonies")) return false;
		} else if (section != "colonies") return false;
		// Versions 1–3 wrote exactly twelve uncounted colony records. Keep
		// that wire size independent of the live cap; version 4 stores a count.
		constexpr int legacyColonyCount = 12;
		int colonyCount = legacyColonyCount;
		if (version >= 4 && !number(colonyCount, 1, Team::MAX_COUNT)) return false;
		if (s.capacity > colonyCount) return false;
		int humans = 0;
		for (int i = 0; i < colonyCount; ++i) {
			auto &c = s.colonies[i];
			int controller, ai;
			if (!number(controller, 0, CustomGameSetup::Closed) || !number(ai, 0, AI::SIZE - 1) ||
				!number(c.alliance, 0, Team::MAX_COUNT - 1)) return false;
			c.controller = CustomGameSetup::Controller(controller);
			c.ai = AI::ImplementationID(ai);
			if (version >= 5 && (!(in >> std::quoted(c.aiLibraryId)) || c.aiLibraryId.size() > 128))
				return false;
			humans += controller == CustomGameSetup::Human || controller == CustomGameSetup::Shared;
		}
		if (humans > 1 || !word("end")) return false;
		in >> std::ws;
		if (!in.eof()) return false;
		s.random = random; s.prestige = prestige; s.revealed = revealed; s.locked = locked;
		draft.userMaps = user;
		legacy.logRepeatAreaTimes = repeat;
		s.generator = fromLegacyDescriptor(legacy, 0);
		bool missingCustom = false;
		if (!customId.empty())
		{
			try
			{
				const auto catalog = GeneratorRegistry::activeSnapshot();
				method = catalog->idOf(customId);
				s.generator.setMethodDefaults(method, catalog);
			}
			catch (const std::exception &)
			{
				missingCustom = true; draft.missingGeneratorId=customId;
			}
		}
		const auto &controls = s.generator.definition().controls;
		for (const auto &[id, value] : options) {
			const auto c = std::find_if(controls.begin(), controls.end(),
				[&](const GeneratorControl &control) { return control.id == id; });
			// An option this build no longer has is dropped; a value outside its control's
			// domain means the file is corrupt.
			if (missingCustom || c == controls.end() ||
				(customId.empty() && hasLegacyField(method, id)))
				continue;
			if (c->normalize(value) != value) return false;
			c->set(s.generator, value);
		}
		if (s.random) s.capacity = s.generator.nbTeams;
		*this = draft;
		return true;
	}
	bool load(GAGCore::FileManager &files)
	{
		std::unique_ptr<std::ifstream> input(files.openIFStream(filename));
		if (!input || !*input) return false;
		char buffer[65537];
		input->read(buffer, sizeof(buffer));
		return !input->bad() && decode(std::string(buffer, size_t(input->gcount())));
	}
	bool save(GAGCore::FileManager &files) const
	{
		const auto text = encode();
		return files.writeAtomically(filename, [&](GAGCore::OutputStream &out) {
			out.write(text.data(), text.size(), "preferences");
		});
	}
};
