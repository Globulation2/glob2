// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2007 Bradley Arsenault

#pragma once

#include "BasePlayer.h"
#include "ExperimentalFeatures.h"
#include "Stream.h"
#include <list>
#include <optional>
#include <memory>
class BuildingArtwork;
class UnitCatalog;
#include <vector>
#include "WinningConditions.h"
#include <assert.h>
#include <stdexcept>

///This is the game header. It is dynamic, and can change from game to game, even
///if the map doesn't. It holds all configurable information for a game, from team
///alliances to customized victory conditions
class GameHeader
{
	Uint64 observationRevisionValue = 1;
public:
	///Gives default values to all entries
	GameHeader();

	///Resets the GameHeader to a "blank" state with default values
	void reset();	

	///Loads game header information from the stream
	bool load(GAGCore::InputStream *stream, Sint32 versionMinor, Sint32 historicalGrowthVersion = 0);
	
	///Saves game header information to the stream
	void save(GAGCore::OutputStream *stream) const;

	///This loads the game header information from the stream, excluding BasePlayer information
	bool loadWithoutPlayerInfo(GAGCore::InputStream *stream, Sint32 versionMinor);

	///This saves all game header information to the stream, but excluding the BasePlayer information
	void saveWithoutPlayerInfo(GAGCore::OutputStream *stream) const;

	///This loads only the player information from the game header from the stream
	bool loadPlayerInfo(GAGCore::InputStream *stream, Sint32 versionMinor);

	///This saves only the player information from the game header from the stream
	void savePlayerInfo(GAGCore::OutputStream *stream) const;

	///Returns the number of players in the game
	inline Sint32 getNumberOfPlayers() const { return numberOfPlayers; }
	
	///Sets the number of players in the game
	inline void setNumberOfPlayers(Sint32 players) { numberOfPlayers=players;  ++observationRevisionValue; }
	
	///Returns the games latency. This would be 0 for local games, but higher for networked games.
	inline Sint32 getGameLatency() const { return gameLatency; }
	
	///Sets the latency of the game.
	Uint64 observationRevision() const { return observationRevisionValue; }
	unsigned getAIOrderDelay() const { return aiOrderDelay; }
	void setAIOrderDelay(unsigned ticks) { if (ticks > 8) throw std::invalid_argument("AI order delay must be 0..8 ticks"); aiOrderDelay = ticks; ++observationRevisionValue; }
	///Ticks between capturing a scheduled building walking field and publishing it (1..8).
	static constexpr unsigned DEFAULT_BUILDING_GRADIENT_DELAY = 8;
	unsigned getBuildingGradientDelay() const { return buildingGradientDelay; }
	void setBuildingGradientDelay(unsigned ticks) { if (ticks < 1 || ticks > 8) throw std::invalid_argument("Building gradient delay must be 1..8 ticks"); buildingGradientDelay = ticks; ++observationRevisionValue; }
	inline void setGameLatency(Sint32 latency) { gameLatency = latency;  ++observationRevisionValue; }
	
	///Returns the order rate. 1 means an order is sent across the net for every frame,
	///2 sends at every second frame, 3 at every 3'rd and so on
	inline Uint8 getOrderRate() const { return orderRate; }
	
	///Sets the order frame rate
	inline void setOrderRate(Uint8 orderRate) { this->orderRate = orderRate;  ++observationRevisionValue; }
	
	///Provides access to the base player. n must be between 0 and 31.
	inline BasePlayer& getBasePlayer(const int n)
	{
		assert(n<Team::MAX_COUNT && n>=0);
		return players[n];
	}
	
	///Provides access to the base player. n must be between 0 and 31.
	inline const BasePlayer& getBasePlayer(const int n) const
	{
		assert(n<Team::MAX_COUNT && n>=0);
		return players[n];
	}

	///True if any player in this game is a live network peer (BasePlayer::P_IP,
	///online or LAN). Used to disable local-only controls such as
	///hard-pause that would desync a networked game if one client toggled them.
	inline bool hasNetworkPlayer() const
	{
		for (int n=0; n<numberOfPlayers; n++)
			if (players[n].type==BasePlayer::P_IP)
				return true;
		return false;
	}

	///Returns the ally-team number for the given team for pre-game alliances.
	///Ally team numbers are 1-based (the constructor assigns team i the value
	///i+1); 0 only appears in a malformed or hand-edited header.
	inline Uint8 getAllyTeamNumber(int teamNumber) const
	{
		assert(teamNumber >= 0 && teamNumber < Team::MAX_COUNT);
		return allyTeamNumbers[teamNumber];
	}

	///Sets the ally-team number (1-based, see getAllyTeamNumber) for the given
	///team. The header is replicated to all clients, so an out-of-range write
	///here would silently corrupt shared state -- hence the assert.
	inline void setAllyTeamNumber(int teamNumber, Uint8 allyTeam)
	{
		assert(teamNumber >= 0 && teamNumber < Team::MAX_COUNT);
		allyTeamNumbers[teamNumber]=allyTeam;
	}

	///Applies the custom-game default alliance layout. All ally-team numbers
	///are first reset to the free-for-all default (team i on singleton group
	///i+1, as in reset()), then the human's team joins ally team 1 and every
	///AI team with a different color joins ally team 2. An AI sharing the
	///human's color shares its team -- alliances are per-team -- so it stays
	///on the human's ally group. With no human selection (humanColor empty)
	///the free-for-all layout is kept: a human-vs-AI split is meaningless
	///without a human. Colors are team indices, [0, Team::MAX_COUNT).
	void setDefaultAlliances(std::optional<int> humanColor, const std::vector<int>& aiColors);
	
	///Returns whether allying and de-allying are allowed mid-game
	inline bool areAllyTeamsFixed() const { return allyTeamsFixed; }
	
	///Sets whether ally-teams are fixed during the game
	inline void setAllyTeamsFixed(bool fixed) { allyTeamsFixed = fixed;  ++observationRevisionValue; }
	
	///Returns the list of winning conditions. This list can be modified. Mind, though, the pecking order of winning conditions.
	///Ones first on the list are considered first.
	inline std::list<std::shared_ptr<WinningCondition> >& getWinningConditions() { return winningConditions; }
	inline const std::list<std::shared_ptr<WinningCondition>>& getWinningConditions() const { return winningConditions; }
	
	///Returns the random generator seed thats being used
	inline Uint32 getRandomSeed() const { return seed; }
	
	///Sets the random generator seed to be used
	inline void setRandomSeed(Uint32 s) { seed = s;  ++observationRevisionValue; }
	
	///Returns whether the map is discovered at game start
	inline bool isMapDiscovered() const { return mapDiscovered; }
	
	///Sets whether the map is discovered at game start
	inline void setMapDiscovered(bool discovered) { mapDiscovered=discovered;  ++observationRevisionValue; }
	/// Canonical resolved runtime values; empty means legacy/default resolution.
	const std::string& getAIConfig(int player) const { assert(player >= 0 && player < Team::MAX_COUNT); return aiConfig[player]; }
	void setAIConfig(int player, const std::string& values) { assert(player >= 0 && player < Team::MAX_COUNT); aiConfig[player] = values;  ++observationRevisionValue; }

	///Returns whether resources are allowed to grow/spread over time (custom-game rule)
	inline bool isResourceGrowthDisabled() const { return resourceGrowthDisabled; }

	///Sets whether resources are allowed to grow/spread over time (custom-game rule)
	inline void setResourceGrowthDisabled(bool disabled) { resourceGrowthDisabled=disabled;  ++observationRevisionValue; }

	///Returns the resource-scarcity tier (0=off/today's rate, 1-3=progressively slower growth)
	inline Uint8 getResourceScarcityLevel() const { return resourceScarcityLevel; }

	///Sets the resource-scarcity tier (custom-game rule)
	inline void setResourceScarcityLevel(Uint8 level) { resourceScarcityLevel=level;  ++observationRevisionValue; }

	///Returns whether buildings complete construction instantly (custom-game rule)
	inline bool isInstantConstructionEnabled() const { return instantConstruction; }

	///Sets whether buildings complete construction instantly (custom-game rule)
	inline void setInstantConstructionEnabled(bool enabled) { instantConstruction=enabled;  ++observationRevisionValue; }

	///Returns the stockpile-start tier (0=none/today's default, 1-3=progressively larger
	///starting amount seeded into each team's shared market/exchange resource pool)
	inline Uint8 getStockpileStartLevel() const { return stockpileStartLevel; }

	///Sets the stockpile-start tier (custom-game rule)
	inline void setStockpileStartLevel(Uint8 level) { stockpileStartLevel=level;  ++observationRevisionValue; }

	///Returns whether units are exempt from hunger and starvation (custom-game rule)
	inline bool isHungerDisabled() const { return hungerDisabled; }

	///Sets whether units are exempt from hunger and starvation (custom-game rule)
	inline void setHungerDisabled(bool disabled) { hungerDisabled=disabled;  ++observationRevisionValue; }

	///Returns whether unit training and building upgrades are disabled (custom-game rule)
	inline bool isUnitUpgradesDisabled() const { return unitUpgradesDisabled; }

	///Sets whether unit training and building upgrades are disabled (custom-game rule)
	inline void setUnitUpgradesDisabled(bool disabled) { unitUpgradesDisabled=disabled;  ++observationRevisionValue; }

	///Returns the "glass cannon" tier (0=off/today's balance, 1-2=progressively higher
	///damage dealt and lower HP/armor)
	inline Uint8 getGlassCannonLevel() const { return glassCannonLevel; }

	///Sets the "glass cannon" tier (custom-game rule)
	inline void setGlassCannonLevel(Uint8 level) { glassCannonLevel=level;  ++observationRevisionValue; }

	///Resolves the "glass cannon" tier to its actual scale factor: multiplies
	///attack strength (melee and magic), divides HP and armor. The single canonical place this
	///scale is defined, mirroring getBuildingHpMultiplier() below; every read
	///of it (Unit::init's HP scaling, UnitStats.cpp's getRealAttackStrength()/
	///getRealArmor(), any AI or UI code that needs a unit's *effective*
	///combat stats rather than its base performance[]) should go through this
	///rather than re-deriving or re-duplicating the tier->scale mapping.
	inline int getGlassCannonScale() const
	{
		static constexpr int scale[] = {1, 2, 3};
		return scale[glassCannonLevel];
	}

	///Returns whether units fight to the death instead of retreating when damaged (custom-game rule)
	inline bool isUnitsFearless() const { return unitsFearless; }

	///Sets whether units fight to the death instead of retreating when damaged (custom-game rule)
	inline void setUnitsFearless(bool fearless) { unitsFearless=fearless;  ++observationRevisionValue; }

	///Returns whether units are exempt from permanent death (custom-game rule)
	inline bool isPermadeathDisabled() const { return permadeathDisabled; }

	///Sets whether units are exempt from permanent death (custom-game rule)
	inline void setPermadeathDisabled(bool disabled) { permadeathDisabled=disabled;  ++observationRevisionValue; }

	///Returns whether all combat is disabled for this match (custom-game rule)
	inline bool isPeacefulModeEnabled() const { return peacefulMode; }

	///Sets whether all combat is disabled for this match (custom-game rule)
	inline void setPeacefulModeEnabled(bool enabled) { peacefulMode=enabled;  ++observationRevisionValue; }

	///Returns the "fortress buildings" tier (0=off/today's HP, 1-2=progressively higher
	///building HP)
	inline Uint8 getBuildingHpLevel() const { return buildingHpLevel; }

	///Sets the "fortress buildings" tier (custom-game rule)
	inline void setBuildingHpLevel(Uint8 level) { buildingHpLevel=level;  ++observationRevisionValue; }

	///Resolves the "fortress buildings" tier to its actual HP multiplier.
	///The single canonical place this scale is defined; Building's
	///getEffectiveMaxHp()/getEffectiveInitHp() and any other type->hpMax/
	///hpInit read that isn't tied to a live Building instance should go
	///through this rather than re-deriving the tier->multiplier mapping.
	inline int getBuildingHpMultiplier() const
	{
		static constexpr int multiplier[] = {1, 5, 10};
		return multiplier[buildingHpLevel];
	}

	///The experimental features this game carries (ExperimentalFeatures.h). Set
	///from Settings > Experiments when a game is created; saves, replays and
	///multiplayer peers keep the set the game was started with.
	inline const ExperimentSet& getExperiments() const { return experiments; }
	///Mutable access, for building a header before the game starts only: changing
	///it once the game runs would desync peers and replays.
	inline ExperimentSet& getExperiments() { ++observationRevisionValue; return experiments; }
	inline void setExperiments(const ExperimentSet& set) { experiments = set;  ++observationRevisionValue; }
	///The hot-path read for simulation code: is this experiment on in this game?
	inline bool hasExperiment(ExperimentId id) const { return experiments.has(id); }
	// Empty only in pre-catalog files or an unresolved setup. A Game fills this
	// before saving or sending its setup so later local edits cannot change it.
	const std::string& getBuildingCatalogSnapshot() const { return buildingCatalogSnapshot; }
	void setBuildingCatalogSnapshot(const std::string& snapshot);
	const std::shared_ptr<const BuildingArtwork>& getBuildingArtwork() const { return buildingArtwork; }
	void setBuildingArtwork(const std::string& bytes);
	const std::vector<std::string>& buildingExperimentKeys() const { return buildingCatalogExperimentKeys; }
	const std::vector<CatalogExperimentDefinition>& resourceExperiments() const { return resourceCatalogExperiments; }
	void setResourceExperiments(const std::vector<CatalogExperimentDefinition>& definitions);
	std::vector<std::string> catalogExperimentKeys() const;
	const std::shared_ptr<const UnitCatalog>& getUnitCatalog() const { return unitCatalogValue; }
	void setUnitCatalog(std::shared_ptr<const UnitCatalog> catalog);
	void setUnitCatalogSnapshot(const std::string& snapshot);
	std::string getUnitCatalogSnapshot() const;
private:
	std::shared_ptr<const UnitCatalog> unitCatalogValue;
	std::string buildingCatalogSnapshot;
	std::shared_ptr<const BuildingArtwork> buildingArtwork;
	std::vector<std::string> buildingCatalogExperimentKeys;
	std::vector<CatalogExperimentDefinition> resourceCatalogExperiments;
	std::string aiConfig[Team::MAX_COUNT];
	bool loadAIConfig(GAGCore::InputStream *stream, Sint32 versionMinor);
	void saveAIConfig(GAGCore::OutputStream *stream) const;
	///The number of players in the game
	Sint32 numberOfPlayers;

	///The number of ticks between an order issue, and the execution of the order.
	///Used for net games to hide latency.
	Sint32 gameLatency;
	Uint8 aiOrderDelay = 8;
	Uint8 buildingGradientDelay = DEFAULT_BUILDING_GRADIENT_DELAY;

	///Sets the order rate
	Uint8 orderRate;

	///Represents the basic player information in the game
	BasePlayer players[Team::MAX_COUNT];
	
	///Represents the ally team numbers
	Uint8 allyTeamNumbers[Team::MAX_COUNT];
	
	///Represents whether the ally-teams are fixed for the whole game, so no allying/unallying can take place
	bool allyTeamsFixed;
	
	///Represents the winning conditions of the game.
	std::list<std::shared_ptr<WinningCondition> > winningConditions;

	///Represents the random seed used for the game
	Uint32 seed;
	
	///Represents whether fog of war is enabled or disabled
	bool mapDiscovered;

	///Custom-game rule: resources never grow/spread (see Map::growResources)
	bool resourceGrowthDisabled;

	///Custom-game rule: 0-3 tier scaling down how often resources grow/spread
	Uint8 resourceScarcityLevel;

	///Custom-game rule: building sites complete immediately, skipping resource delivery
	bool instantConstruction;

	///Custom-game rule: 0-3 tier seeding each team's shared resource pool at game start
	Uint8 stockpileStartLevel;

	///Custom-game rule: units never grow hungry or starve
	bool hungerDisabled;

	///Custom-game rule: unit training and building upgrades are disabled (repairs remain available)
	bool unitUpgradesDisabled;

	///Custom-game rule: 0-2 tier scaling damage dealt up and HP/armor down
	Uint8 glassCannonLevel;

	///Custom-game rule: units never retreat to heal when damaged
	bool unitsFearless;

	///Custom-game rule: units never permanently die
	bool permadeathDisabled;

	///Custom-game rule: no team can ever target another in combat
	bool peacefulMode;

	///Custom-game rule: 0-2 tier scaling building max HP
	Uint8 buildingHpLevel;

	///Experimental features enabled for this game; empty is the default game
	ExperimentSet experiments;
};
