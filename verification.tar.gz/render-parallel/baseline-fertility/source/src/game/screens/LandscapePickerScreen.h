// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "GenerationRequest.h"
#include "ui/FrontendUI.h"
#include "LandscapePreviewer.h"
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

/// A full-window modal showing every landscape as a freshly generated map, for picking one by
/// sight. execute() returns the chosen entry's index, CANCEL, or QUIT_APPLICATION; chosenSeed()
/// then reproduces the map that was shown for it, and chosenRequest() carries the parameters it
/// was rolled with - the entry's own, or a random set when "Randomize parameters" was used, so
/// the lobby can take over exactly what was shown. Entries are just a localized name and the
/// request to preview, so any screen that selects a landscape can run it. The returned index and
/// tiles[]/entries[] are always in the constructor's order; sorting and tag filtering only
/// change which entries are visible and in what order they are drawn (`visible`), not their
/// identity, so a caller's mapping from index back to its own data (a generator method, say)
/// stays valid regardless of how the sheet was browsed.
class LandscapePickerScreen : public Glob2UI::Screen
{
	friend struct CustomGameSetupHarness;
	friend struct MobileGallerySetup;

  public:
	const char *recordingId() const override { return "landscape_picker"; }
	enum
	{
		CANCEL = -2
	};
	/// How the sheet orders its tiles. Random is the registry's own catalog order (shuffled once
	/// so browsing favours no landscape); Alphabetical sorts by each entry's shown name.
	enum class SortOrder
	{
		Random,
		Alphabetical
	};
	struct Entry
	{
		std::string name;
		GenerationRequest request;
		// The generator this entry previews, for the tag filter row and the live compatibility
		// check against the sheet's own size/colony count; -1 if the caller has none (the entry
		// is then never filtered out and never shown disabled).
		int method = -1;
		// This entry's generator's catalog tags (GeneratorDefinition::tags), for the filter row.
		std::vector<std::string> tags;
	};
	LandscapePickerScreen(const std::string &title, std::vector<Entry> entries, int selected,
						  SortOrder sortOrder = SortOrder::Random);
	~LandscapePickerScreen() override;
	Glob2UI::Element build(const Glob2UI::Presentation &presentation) override;
	void onTimer(Uint32 tick) override;
	/// Selects entries[index] and reveals its card.
	void select(int index);
	/// Finishes with the selection once its preview is ready.
	void confirm();
	int selection() const { return selected; }
	/// The seed behind the preview shown for the selection, once that preview is ready.
	std::optional<std::uint32_t> chosenSeed() const;
	/// The request the selection's preview was rolled with (see randomizeParameters).
	GenerationRequest chosenRequest() const;
	/// The sort order currently shown, random or alphabetical, as last changed by the person
	/// (starts at the constructor's `sortOrder`) - a caller persists this the way it persists any
	/// other lobby preference.
	SortOrder currentSortOrder() const { return sortOrder; }
	/// Draws every landscape's own controls at random (GenerationRequest::randomizeControls) and
	/// rolls them all again. A random set the world then refuses is drawn again, up to
	/// kRandomDraws times per landscape, so the sheet fills with maps that exist.
	void randomizeParameters();
	/// Puts every landscape back on its registered controls, at the sheet's size and colony
	/// count, and rolls them all again (the way back from randomizeParameters).
	void resetParameters();
	static constexpr int kRandomDraws = 6;
	/// Includes off-screen slots, which cooperative hosts defer until browsed.
	bool busy() const { return previewer.busy(); }
	bool presentationSettled() const;
	/// The shared width/height (tile exponents) and colony count every entry is currently shown
	/// at - uniform across entries[] by construction (the caller's GenerationHistory already
	/// carries these shared fields onto every method) and kept uniform by setShared(). A caller
	/// reads these back after execute() returns, on any exit, and applies them to its own lobby
	/// setup, the same two-way relationship currentSortOrder() has with a caller's preferences:
	/// this sheet is a live view onto shared lobby settings, not a disconnected copy of them.
	int sharedWDec() const { return entries.empty() ? 0 : entries.front().request.wDec; }
	int sharedHDec() const { return entries.empty() ? 0 : entries.front().request.hDec; }
	int sharedTeams() const { return entries.empty() ? 0 : entries.front().request.nbTeams; }
	/// Sets one shared control (width/height/teams, from GenerationRequest::sharedControls) to
	/// `value` on every entry, then rerolls every visible preview immediately at the new size or
	/// colony count - no separate "Regenerate all" step - and recomputes which generators are
	/// still compatible with it. FEEDBACK 2026-09-17: the point is instant comparison across the
	/// whole grid of how every landscape responds, not editing one map's parameters in isolation.
	void setShared(const GeneratorControl &control, int value);

  protected:
	void onEscape() override { endExecute(CANCEL); }
	void onEvent(const SDL_Event &event) override;
	bool interceptEvent(const SDL_Event &event) override;

  private:
	struct Tile
	{
		LandscapePreviewer::Preview preview;
		// Screen-owned preview (see previews), retained while its replacement rolls.
		MapPreview *widget = nullptr;
		unsigned revision = ~0u;
	};
	std::vector<std::unique_ptr<MapPreview>> previews;
	static std::vector<GenerationRequest> requestsOf(const std::vector<Entry> &);
	Glob2UI::Element tile(int index, const Glob2UI::Presentation &presentation, bool compact);
	void refresh();
	void updatePreviewPriority();
	/// Whether entries[index] matches every active filter except filterCategories[skip] (skip < 0
	/// checks all of them) - the faceted-search rule that keeps a category's own dropdown, and
	/// `rebuild`'s final list, from ever offering a choice that empties the results: a category's
	/// options are drawn only from what the OTHER active filters still allow.
	bool matchesFilters(int index, int skip) const;
	/// Refills `incompatible` from a fresh validateGenerationRequest per entry, against each
	/// entry's own (shared, per setShared) size and colony count.
	void recomputeIncompatible();
	/// Recomputes `visible` (entries[] indices, filtered by the active tag choices and ordered by
	/// `sortOrder`) and `incompatible` (each entry's live validateGenerationRequest reason against
	/// the sheet's own size/colony count, empty when it can generate). Called once at construction
	/// and again whenever the person changes the sort order or a filter.
	void rebuild();
	std::string title;
	std::vector<Entry> entries;
	std::vector<Tile> tiles;
	/// Per entry, random draws still allowed after a refused set (0 when the parameters are the
	/// entry's own or the draws are spent).
	std::vector<int> redraws;
	/// entries[] indices currently shown, filtered and ordered; empty-filter/Random means the
	/// identity order 0..entries.size()-1.
	std::vector<int> visible;
	/// Parallel to entries[]: the live reason this entry cannot generate at the sheet's size and
	/// colony count, or empty when it can. Recomputed at construction and by setShared() whenever
	/// that size or count changes; a validateGenerationRequest check, so it costs no worker time.
	std::vector<std::string> incompatible;
	/// Every tag category present across entries[]'s own tags (each generator's own
	/// GeneratorDefinition::tags, carried in by the caller), fixed at construction in a stable
	/// order, and one chosen filter value per category (empty meaning "Any" - no filter on that
	/// category), parallel to it.
	std::vector<std::string> filterCategories;
	std::vector<std::string> filters;
	int selected, columns = 1;
	bool reveal = true;
	bool layoutReady = false;
	int priorityOffset = 0;
	Uint32 nextPreviewTick = 0;
	std::vector<std::size_t> priorityOrder;
	std::vector<std::size_t> viewportSlots;
	SortOrder sortOrder;
	LandscapePreviewer previewer;
};
