// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2008 Bradley Arsenault

#pragma once

#include <memory>
#include <SDL3_net/SDL_net.h>
#include <list>
#include <optional>


class Game;

namespace GAGCore
{
	class OutputStream;
	class InputStream;
};

///These are the type of winning conditions there are
enum WinningConditionType
{
	WCUnknown,
	WCDeath,
	WCAllies,
	WCPrestige,
	WCScript,
	WCOpponentsDefeated,
	WCSuddenDeath,
	WCWinProbability,
};

///This represents a generic winning condition. Each condition may specify which teams have won,
///which have lost, or possibly, both
class WinningCondition
{
public:
	virtual ~WinningCondition() = default;

	///Returns true if the particular player has won according to this winning condition
	virtual bool hasTeamWon(int team, const Game* game) const = 0;
	///Returns true if the particular player has lost according to this winning condition
	virtual bool hasTeamLost(int team, const Game* game) const = 0;
	///Returns the winning condition type
	virtual WinningConditionType getType() const=0;
	///This will encode the data in this winning condition to a stream. All derived class must start by saving a Uint8 from getType()
	virtual void encodeData(GAGCore::OutputStream* stream) const = 0;
	///This will decode data. It is important that, unlike encodeData, this must ignore the initial Uint8
	virtual void decodeData(GAGCore::InputStream* stream, Uint32 versionMinor)=0;

	///This will reconstruct a winning condition from serialized data.
	///Returns null if the stream ends before the type tag or the tag is not a
	///known WinningConditionType -- corrupt or truncated input, which the
	///caller must handle. Prefer loadWinningConditions for reading a whole list.
	static std::shared_ptr<WinningCondition> getWinningCondition(GAGCore::InputStream* stream, Uint32 versionMinor);
	///Reads a serialized winning-condition list section ("winningConditions":
	///a Uint32 size followed by one numbered subsection per condition, the
	///format written by GameHeader::save). On success `conditions` holds the
	///decoded list and true is returned. On corrupt or truncated input (EOF
	///mid-list, unrecognized type tag) false is returned; `conditions` then
	///holds only the entries decoded so far -- never a null pointer -- and the
	///stream position is undefined.
	static bool loadWinningConditions(GAGCore::InputStream* stream, Uint32 versionMinor, std::list<std::shared_ptr<WinningCondition> >& conditions);
	///This will set the given list to the default set of winning conditions, in their default order
	static std::list<std::shared_ptr<WinningCondition> > getDefaultWinningConditions();
	///Enables or disables the prestige winning condition, editing `conditions`
	///in place: every other entry is left untouched. List order is evaluation
	///priority -- Team::checkWinConditions stops at the first condition that
	///declares a win or loss -- so when prestige is re-added it is inserted at
	///its default-order position (see getDefaultWinningConditions), not
	///appended. Enabling when present and disabling when absent are no-ops.
	static void setPrestigeWinCondition(std::list<std::shared_ptr<WinningCondition> >& conditions, bool enabled);
	///Enables, retunes or disables the sudden-death timer, editing `conditions`
	///in place: every other entry is left untouched. Unlike setPrestigeWinCondition,
	///a newly-enabled instance is appended at the very end of the list rather
	///than at a fixed rank -- it is meant to fire only as a last resort, after
	///every other condition has already had its say that tick. Passing a value
	///retunes an already-present instance in place instead of removing and
	///re-adding it, so its list position (end, by construction) never moves.
	///An empty optional disables it; disabling when absent is a no-op.
	static void setSuddenDeathWinCondition(std::list<std::shared_ptr<WinningCondition> >& conditions, std::optional<Uint32> endStepTick);
	///Enables, retunes or disables the win-probability rule, editing `conditions`
	///in place. Like setSuddenDeathWinCondition a newly-enabled instance is
	///appended at the very end: it is a last resort, so an actual elimination or
	///prestige win always speaks first. `thresholdPermille` is the confidence at
	///which the game is called; an empty optional disables the rule, and
	///disabling when absent is a no-op.
	static void setWinProbabilityWinCondition(std::list<std::shared_ptr<WinningCondition> >& conditions, std::optional<Uint32> thresholdPermille);

};

///A team has lost if its dead.
class WinningConditionDeath : public WinningCondition
{
public:
	bool hasTeamWon(int team, const Game* game) const override;
	bool hasTeamLost(int team, const Game* game) const override;
	WinningConditionType getType() const override;
	void encodeData(GAGCore::OutputStream* stream) const override;
	void decodeData(GAGCore::InputStream* stream, Uint32 versionMinor) override;
};

///A team has won if one of its allies has won
class WinningConditionAllies : public WinningCondition
{
public:
	bool hasTeamWon(int team, const Game* game) const override;
	bool hasTeamLost(int team, const Game* game) const override;
	WinningConditionType getType() const override;
	void encodeData(GAGCore::OutputStream* stream) const override;
	void decodeData(GAGCore::InputStream* stream, Uint32 versionMinor) override;
};

///A team has won if the prestige limit is reached and its above the prestige amount
///and a team has lost if the prestige limit is reached and its below the prestige amount
class WinningConditionPrestige : public WinningCondition
{
public:
	bool hasTeamWon(int team, const Game* game) const override;
	bool hasTeamLost(int team, const Game* game) const override;
	WinningConditionType getType() const override;
	void encodeData(GAGCore::OutputStream* stream) const override;
	void decodeData(GAGCore::InputStream* stream, Uint32 versionMinor) override;
};

///A team has won if the script says it has won, and lost if the script says it has lost.
///In server builds, hasTeamWon/hasTeamLost are stubbed to false: SGSL.cpp is not in the
///server link, and Team::checkWinConditions (the sole caller) is client-only.
class WinningConditionScript : public WinningCondition
{
public:
	bool hasTeamWon(int team, const Game* game) const override;
	bool hasTeamLost(int team, const Game* game) const override;
	WinningConditionType getType() const override;
	void encodeData(GAGCore::OutputStream* stream) const override;
	void decodeData(GAGCore::InputStream* stream, Uint32 versionMinor) override;
};

///A team has won if all enemies have lost
class WinningConditionOpponentsDefeated : public WinningCondition
{
public:
	bool hasTeamWon(int team, const Game* game) const override;
	bool hasTeamLost(int team, const Game* game) const override;
	WinningConditionType getType() const override;
	void encodeData(GAGCore::OutputStream* stream) const override;
	void decodeData(GAGCore::InputStream* stream, Uint32 versionMinor) override;
};

///Custom-game "sudden-death timer" rule. Before endStepTick, never declares
///a winner or loser. At or after it, resolves exactly like
///WinningConditionPrestige (won if tied for the most prestige, lost if
///strictly below it) but against the game's *current* prestige standing
///instead of a configured threshold -- so the match simply ends with
///whoever is ahead at the buzzer.
class WinningConditionSuddenDeath : public WinningCondition
{
public:
	bool hasTeamWon(int team, const Game* game) const override;
	bool hasTeamLost(int team, const Game* game) const override;
	WinningConditionType getType() const override;
	void encodeData(GAGCore::OutputStream* stream) const override;
	void decodeData(GAGCore::InputStream* stream, Uint32 versionMinor) override;

	Uint32 endStepTick = 0;
};

///How a decided game reads from one team's point of view. Presentation only:
///it is derived from the per-team hasWon/hasLost flags and never changes them.
enum class TeamOutcome
{
	Undecided,
	Won,
	///The team won, but so did a team it is not mutually allied with -- e.g. a
	///sudden-death or prestige finish tied at the top across alliances.
	Draw,
	Lost,
};
///Optional custom-game rule: the game ends as soon as the fitted win
///probability model is `thresholdPermille` sure of the result, so a match that
///is already decided does not have to be played out.
///
///Off unless a player turns it on -- a normal game is unaffected. It is
///evaluated only on the 512-tick sample boundary TeamStats already measures at,
///which is the cadence the model was fitted on, and never before
///WinProbability::MINIMUM_DECISION_TICK, since the opening samples can look
///lopsided for reasons that mean nothing.
///
///The whole evaluation is integer arithmetic (see WinProbability.h): this runs
///inside the synchronised simulation and decides the outcome, so every platform
///has to reach the same answer on the same tick or a network game desynchronises.
class WinningConditionWinProbability : public WinningCondition
{
public:
	bool hasTeamWon(int team, const Game* game) const override;
	bool hasTeamLost(int team, const Game* game) const override;
	WinningConditionType getType() const override;
	void encodeData(GAGCore::OutputStream* stream) const override;
	void decodeData(GAGCore::InputStream* stream, Uint32 versionMinor) override;

	///Confidence the model must reach, in permille. 970 is the default the
	///custom-game rule offers; measured on games already played it ended about a
	///tenth of the tournament's compute early and named the eventual winner in
	///over 99% of the games it called.
	Uint32 thresholdPermille = 970;
};


///Teams someone plays, as a mask with bit `t` set for team `t`: a team counts when
///at least one of its players is a human or a real AI. An empty online seat is a
///player with AI::NONE whose colony stays on the map, alive and idle; it is nobody's
///win or draw. When no team has such a player -- a replay drives every player as
///AI::NONE -- every team counts.
Uint32 contestedTeamsMask(const Game* game);

///Classifies `team`'s result for end-of-game messages. Won only when every other
///winning team in `contestedTeams` is mutually allied with `team` (allied teams that
///win together still see a win); Draw when `team` won alongside a non-allied winner
///that someone plays. Winners outside `contestedTeams` (empty seats) never make a draw.
TeamOutcome classifyTeamOutcome(const Game* game, int team, Uint32 contestedTeams = ~Uint32(0));
///True when the winning teams in `contestedTeams` span more than one alliance (a
///spectator's draw).
bool isGameDrawn(const Game* game, Uint32 contestedTeams = ~Uint32(0));
