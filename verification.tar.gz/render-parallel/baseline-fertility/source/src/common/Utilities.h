// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#pragma once

#include <stdlib.h>
#include <errno.h>

#include <string>

#include <SDL3_net/SDL_net.h>

#include "MersenneTwister.h"

namespace GAGCore
{
	class InputStream;
	class OutputStream;
}

// Historical test diagnostics only. Production simulation, generation, setup
// and AI use explicit owner streams; test/check_entity_random.py enforces this.
// Keep the function-local TLS wrapper for portable legacy test state access.
MersenneTwister &syncRandEngine();

// Bind historical RNG state in compatibility test fixtures.
// The scope is thread-local and restores the previous stream on exit.
class SyncRandScope
{
public:
	explicit SyncRandScope(MersenneTwister &engine);
	~SyncRandScope();
	SyncRandScope(const SyncRandScope &) = delete;
	SyncRandScope &operator=(const SyncRandScope &) = delete;
private:
	MersenneTwister *previous;
};

// While a requirement is alive (an engine session), every synchronized draw must come
// from a bound game stream. An unbound draw is a determinism bug: it would read the
// calling thread's default stream instead of the simulated game's. Such draws are
// counted, and abort when GLOB2_SYNC_RAND_STRICT is set.
class SyncRandRequirement
{
public:
	SyncRandRequirement();
	~SyncRandRequirement();
	SyncRandRequirement(const SyncRandRequirement &) = delete;
	SyncRandRequirement &operator=(const SyncRandRequirement &) = delete;
};
//! Number of synchronized draws made without a bound stream while required.
unsigned unboundSyncRandDraws();

inline Uint32 syncRand(void)
{
	return syncRandEngine()();
}

// 32-bit right-rotate by 1 bit. Used to mix per-section checksums into the
// running game/network checksum so that re-ordered identical inputs produce
// different outputs. Open-coded as `(x<<31)|(x>>1)` so the compiler emits a
// single ROR instruction without a branch on the shift amount; modern
// compilers also recognize this exact named-helper form.
//
// Determinism note: this rotate feeds the on-the-wire lockstep checksum --
// match it exactly in the Rust port (use `u32::rotate_right(1)`). Do not
// substitute a similar-looking expression like `x >> 1` (a divide).
inline Uint32 rotr1(Uint32 x) { return (x << 31) | (x >> 1); }

// 32-bit left-rotate by 1 bit. Sibling of rotr1 -- used by Unit and Map
// checksum mixers. Same determinism caveats apply: the Rust port must use
// `u32::rotate_left(1)`.
inline Uint32 rotl1(Uint32 x) { return (x << 1) | (x >> 31); }

///The actual random seeds are stored in GameHeader, which automatically randomizes them.
///Seeding and state access apply to the bound stream (see SyncRandScope), else the default.
void setSyncRandSeed();
void setSyncRandSeed(Uint32 seed);
void setRandomSyncRandSeed();
// Preserve synchronized randomness when a private loading/generation job is cancelled.
std::string getSyncRandState();
bool setSyncRandState(const std::string& state);

int distSquare(int x1, int y1, int x2, int y2);
#define SIGN(s) ((s) == 0 ? 0 : ((s)>0 ? 1 : -1) )

class Game;

namespace Utilities
{
	// color space conversion
	//! do a color space conversion from HSV to RGB
	void HSVtoRGB( float *r, float *g, float *b, float h, float s, float v );

	//! Data for computing minimap
	/**
		Inputs
		\param resolution Resolution of minimap (in pixels)
		\param mW Width of the map (in case)
		\param mH Height of the map (in case)
		Outputs
		\param maxSize Max of mw and mH (in case)
		\param sizeX Width of the minimap (in pixels)
		\param sizeY Height of the minimap (in pixels)
		\param decX Displacement of the beginning of the minimap on x (in pixels)
		\param decY Displacement of the beginning of the minimap on y (in pixels)
	*/
	void computeMinimapData(int resolution, int mW, int mH, int *maxSize, int *sizeX, int *sizeY, int *decX, int *decY);

	//! return the memory size of a string. Maximum return value is "max".
	int strmlen(const char *s, int max);

	//! read a string from a stream
	char *gets(char *dest, int size, GAGCore::InputStream *stream);
	void streamprintf(GAGCore::OutputStream *stream, const char *format, ...);

	//! If s starts with prefix, return s without that prefix; otherwise return s
	//! unchanged. Never throws. Used by the LoadSaveScreen filename-to-display-name
	//! callbacks to remove the listing-root directory (e.g. "replays/") from a full
	//! virtual path while leaving unexpected names intact.
	std::string stripPrefix(const std::string& s, const std::string& prefix);
	//! If s ends with suffix, return s without that suffix; otherwise return s
	//! unchanged. Never throws. Counterpart of stripPrefix for file extensions
	//! (e.g. ".replay"): a stray file without the expected extension passes
	//! through instead of crashing the dialog.
	std::string stripSuffix(const std::string& s, const std::string& suffix);
	
	//! helpers for fixed points manipulation
	inline int intToFixed(int i, const int precision = 256) {return  i * precision; }
	inline int fixedToInt(int f, const int precision = 256) {return  f / precision; }
	
	
	// sockets helpers
	namespace Exception
	{
		struct FileDescriptor
		{
		
		};
	
		//! An error (not normal disconnection) occurred while reading or writing on the file descriptor.
		struct FileDescriptorError : public FileDescriptor
		{
			FileDescriptorError(int errNumber) : errNumber(errNumber) {}
			int errNumber;
		};
		
		//! The socket was file descriptor by remote peer, this may happen if file descriptor is a socket for instance.
		struct FileDescriptorDisconnected : public FileDescriptor
		{
		};
	}
	
	
	/*! Read data on a file descriptor
		\param fd source file descriptor,
		\param buf destination pointer where to put the data,
		\param count exact amount to read. The function only returns when this amount of data has been written or if an exception has been raised.
	*/
	void read(int fd, void *buf, size_t count);
};
