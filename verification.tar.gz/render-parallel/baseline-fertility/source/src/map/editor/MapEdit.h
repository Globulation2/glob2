// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière
// Copyright (C) 2006 Bradley Arsenault

#pragma once
#include <MapCamera.h>
#include <BackgroundFileWriter.h>
#include <InputState.h>
#include <utility>
#include <functional>

#include "Brush.h"
#include "BrushCatalog.h"
#include "BrushSwatches.h"
#include "MapEditPresentation.h"
#include "TerrainPresentation.h"
#include "GAGSys.h"
#include "LoadSaveDialog.h"
#include <memory>
#include "Game.h"
#include "KeyboardManager.h"
#include "MapEditDialog.h"
#include "WidgetRectangle.h"
#include <algorithm>
#include <optional>
#include <set>
#include "render/Minimap.h"
#include "OverlayAreas.h"
#include "ScriptEditorScreen.h"
#include "EditorDialogs.h"
#include "SetLibraryDialog.h"
#include <string>
#include <vector>

#define RIGHT_MENU_WIDTH 160
#define RIGHT_MENU_OFFSET (160-128)/2

//! Panel-local x of the flag view's zone button `index` of `count`. The same
//! layout as the game's zone strip (zoneStripButtonX in gui/GameGUIInternal.h):
//! three buttons at a 40px pitch from 8px inside the brush panel, or, with the
//! farm-areas experiment's fourth, centred on the panel at a 38px pitch.
constexpr int mapEditZoneButtonX(int index, int count)
{
	return count > 3 ? 7 + index * 38 : (RIGHT_MENU_OFFSET) + 8 + index * 40;
}


class MapEdit;
class PhoneEditor;
class EditorDock;
struct InspectorModel;

///This is a map editor widget, which is a widget that works within the map editor. Now to answer the crucial question, why not
///use libgag? Indeed, I had pondered on the use of libgag for quite some time, considering all of the odds and ends that would
///be required (I lied in bed for almost 3 hours thinking about it). I eventually decided, after much consideration, that libgag
///was not suited for amount of coupling between the widgets required in the map editor. The resulting classes from using libgag
///would be very tightly coupled. It would not improve maintainability, which is the ultimate goal, and the amount of work-arounds
///would not save much time from the code re-use. So, instead I made my own semi-widget system. These widgets do just enough to
///make the map editor easily maintained. They are, like libgag, very tightly coupled to the map editor, and can not be re-used.
///However, they do solve a few other problems. They automatically detect clicks of the mouse and send the appropriate action
///to be carried out to the map editor, which saves from tedious maintaining of x,y coordinates.
class MapEditorWidget
{
public:
	///This is the standard constructor. All of the members sent to it can be accessed by derived classes.
	MapEditorWidget(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action);
	virtual ~MapEditorWidget() { }
	void drawSelf();
	///This disables the widget, it will not draw itself or respond to mouse clicks
	void disable();
	///This enables the widget.
	void enable();
	///This tests whether the x,y coordinates are within this particular widgets area.
	bool is_in(int x, int y);
	///This function handles a click with mouse positions relative to the widget. It can be overridden, but derived classes
	///should be careful to call the base class version after there customized code
	virtual void handleClick(int relMouseX, int relMouseY);
    /// Invoke this widget's named action without desktop hit-test coordinates.
    void activate();
	///This function must be implemented by all derived classes. This is where the widget draws itself. It should use area.x
	///and area.y to get the coordinates.
	virtual void draw()=0;
	friend class MapEdit;
    friend class PhoneEditor;
protected:
	MapEdit& me;
	RightAnchoredWidgetRectangle area;
	std::string group;
	std::string name;
	std::string action;
	bool enabled;
};


///This widget allows the selection of a building, of any type. When MapEdit::selectionName matches this widgets building_type, it will draw a selection
///around its building as well. The large selector (56x46) is default, but if largeSelector is false, it will use the smaller selector, which is
///(32x32).
class BuildingSelectorWidget : public MapEditorWidget
{
public:
	BuildingSelectorWidget(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, const std::string& building_type, bool largeSelector);
	void draw();
private:
	std::string building_type;
	bool largeSelector;
};


///This draws the selector of the selected team color. It darkens the currently selected team. (this is used when picking what team to place a building, flag, unit or zone for).
class TeamColorSelector : public MapEditorWidget
{
public:
	// Share geometry between drawing, hit testing and widget bounds. Eight
	// columns fit the desktop sidebar and keep all sixteen teams in two rows.
	static constexpr int SWATCH_SIZE = 16;
	static constexpr int COLUMNS = (RIGHT_MENU_WIDTH - 2 * RIGHT_MENU_OFFSET) / SWATCH_SIZE;
	static constexpr int ROWS = (Team::MAX_COUNT + COLUMNS - 1) / COLUMNS;
	static constexpr int WIDTH = COLUMNS * SWATCH_SIZE;
	static constexpr int HEIGHT = ROWS * SWATCH_SIZE;
	TeamColorSelector(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action);
	void draw();
};


///This is a level selector. It draws a small picture denoting the level, and darkens if this selectors level is the currently selected one. Its at the bottom
///of the building and flag views. 
class SingleLevelSelector : public MapEditorWidget
{
public:
	SingleLevelSelector(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, int level, int& levelNum, bool catalogPages=false);
	void draw();
	void handleClick(int relMouseX,int relMouseY) override;
private:
	int level;
	int& levelNum;
	bool catalogPages;
};


///This is an under-the-minimap icon.
class PanelIcon : public MapEditorWidget
{
public:
	PanelIcon(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, int iconNumber, int panelModeHighlight);
	void draw();
private:
	int iconNumber;
	int panelModeHighlight;
};


///This is the small icon to the left of the minimap tat you use to open the in-game menu.
class MenuIcon : public MapEditorWidget
{
public:
	MenuIcon(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action);
	void draw();
};


///This is a selector for a type of zone: forbidden, guarding, clearing, or farming
///(only offered when the player has the farm-areas experiment switched on).
class ZoneSelector : public MapEditorWidget
{
public:
	enum ZoneType
	{
		ForbiddenZone,
		GuardingZone,
		ClearingZone,
		FarmingZone,
	};
	
	ZoneSelector(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, ZoneType zoneType);
	void draw();
private:
	ZoneType zoneType;
};


///This is a brush selector. It draws that tool with the various shapes you can place terrain and zones in
///Its in the middle of the flag panel and the bottom of the terrain panel
class BrushSelector : public MapEditorWidget
{
public:
	BrushSelector(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, BrushTool& brushTool);
	void draw();
private:
	BrushTool& brushTool;
};


///This allows the selection of a particular type of unit. It draws a selector around the unit when that unit type is the one selected.
class UnitSelector : public MapEditorWidget
{
public:
	UnitSelector(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, int unitType);
	void draw();
private:
	int unitType;
};



///This is a terrain selector. It allows for the selection of a variety of terrains and resources. It draws a selector around the particular terrain type
///when that terrain is selected.
class TerrainSelector : public MapEditorWidget
{
public:
	enum TerrainType : int
	{
		Grass,
		Sand,
		Water,
		Wheat,
		Trees,
		Stone,
		Algae,
		Papyrus,
		CherryTree,
		OrangeTree,
		PruneTree,
        NoTerrain,
        RegisteredBegin,
        // Compatibility aliases for callers selecting the example materials.
        Ice = RegisteredBegin + ICE,
        Trail = RegisteredBegin + TRAIL,
        ResourceBegin = RegisteredBegin + TerrainRegistry::Capacity,
    };
    static bool isBaseTerrain(TerrainType type)
    {
		return (type >= Grass && type <= Water) ||
			   (type >= RegisteredBegin &&
				type < int(RegisteredBegin) + int(TerrainRegistry::Capacity));
	}
    static ::TerrainType baseTerrain(TerrainType type)
    {
        constexpr ::TerrainType legacy[] = {GRASS,SAND,WATER};
        assert(isBaseTerrain(type));
        return type <= Water ? legacy[type] : static_cast<::TerrainType>(type - RegisteredBegin);
    }
    static TerrainType selectorFor(::TerrainType type)
    {
        if (type == GRASS) return Grass;
        if (type == SAND) return Sand;
        if (type == WATER) return Water;
        return static_cast<TerrainType>(int(RegisteredBegin) + int(type));
    }
    static bool isResource(TerrainType type)
    {
        return (type >= Wheat && type <= PruneTree) ||
            (type >= ResourceBegin && type < int(ResourceBegin) + int(ResourceRegistry::Capacity));
    }
    static TerrainType selectorForResource(ResourceId type)
    {
        return static_cast<TerrainType>(int(ResourceBegin) + int(resourceIndex(type)));
    }
    static ResourceId resourceType(TerrainType type, const ResourceRegistry& registry)
    {
        if (type >= ResourceBegin) return static_cast<ResourceId>(int(type) - int(ResourceBegin));
        static constexpr const char* legacyKeys[] = {"wheat", "trees", "rocks", "algae", "papyrus", "cherry-tree", "orange-tree", "prune-tree"};
        if (type < Wheat || type > PruneTree) return NoResource;
        return registry.find(legacyKeys[type - Wheat]).value_or(NoResource);
    }
	TerrainSelector(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, TerrainType terrainType);
	void draw();
private:
	TerrainType terrainType;
};

/// Opens the terrain palette filtered to one catalogue group. Its icon follows the
/// active brush while that brush belongs to the group, otherwise the group's first
/// enabled member, and it carries the selection frame whenever a member is active.
class TerrainGroupSelector : public MapEditorWidget
{
public:
	TerrainGroupSelector(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, TerrainGroup catalogueGroup, ::TerrainType fallback);
	void draw();
	TerrainGroup catalogueGroup;
private:
	::TerrainType fallback;
};


///This is a generic blue button. It can be selected and unselected, but not automatically. Its takes the un-translated from of the text, still inside [brackets]
class BlueButton : public MapEditorWidget
{
public:
	BlueButton(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, const std::string& text);
	void draw();
	void setSelected();
	void setUnselected();
private:
	std::string text;
	bool selected;
};



///This is the plus icon on the teams view that is used to add another team to the map
class PlusIcon : public MapEditorWidget
{
public:
	PlusIcon(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action);
	void draw();
};



///This is the minus icon on the teams view that is used to remove a team from the map
class MinusIcon : public MapEditorWidget
{
public:
	MinusIcon(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action);
	void draw();
};



///This is the title shown when you select a unit for editing. It is just text.
class UnitInfoTitle : public MapEditorWidget
{
public:
	UnitInfoTitle(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action);
	void draw();
};



///This is the picture shown when you select a unit for editing.
class UnitPicture : public MapEditorWidget
{
public:
	UnitPicture(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action);
	void draw();
};



///This is a small text object. It shows two values and a label, like "label 1/2". The denominator can be fixed or variable. Either way, the numerator is done 
///by pointer because this class is used for the convenient editing of values in a Unit or Building
using EditorValueReader=std::function<Sint32(const PresentationFrame&)>;

class FractionValueText : public MapEditorWidget
{
public:
	FractionValueText(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, const std::string& label, Sint32* numerator, Sint32* denominator);
	FractionValueText(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, const std::string& label, Sint32* numerator, Sint32 denominator);
	~FractionValueText();
	void draw();
	void setValues(Sint32* numerator, Sint32* denominator, EditorValueReader readValue, EditorValueReader readMax);
	void setValues(Sint32* numerator, EditorValueReader readValue);
private:
	std::string label;
	Sint32* numerator;
    EditorValueReader readValue,readMax;
	Sint32* denominator;
	bool isDenominatorPreset;
};



///This is a scroll box, similar to FractionValueText, that allows for the changing of its two values. 
class ValueScrollBox : public MapEditorWidget
{
public:
	ValueScrollBox(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, Sint32* value, Sint32* max);
	ValueScrollBox(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, Sint32* value, Sint32 max);
	~ValueScrollBox();
	void draw();
	void handleClick(int relMouseX, int relMouseY);
	void setValues(Sint32* value, Sint32* max, EditorValueReader readValue, EditorValueReader readMax);
    // Semantic value access shared by desktop and touch presentations.
    int currentValue() const;
    int maximumValue() const;
    void setValue(int requested);
	void setValues(Sint32* value, EditorValueReader readValue);
private:
	Sint32* value;
    EditorValueReader readValue,readMax;
	Sint32* max;
	bool isMaxPreset;
};



///This is the title shown at the top of the menu when you select a building
class BuildingInfoTitle : public MapEditorWidget
{
public:
	BuildingInfoTitle(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action);
	void draw();
};



///This is the picture shown at the top of the menu when you select a building
class BuildingPicture : public MapEditorWidget
{
public:
	BuildingPicture(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action);
	void draw();
};



///This is a generic textual label that takes its label pre-translated. It simply draws its text, and it can be centered or un-centered in its space.
class TextLabel : public MapEditorWidget
{
public:
	TextLabel(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, const std::string& label, bool centered, const std::string& emptyLabel);
	void draw();
	void setLabel(const std::string& label);
private:
	std::string label;
	std::string emptyLabel;
	bool centered;
};



///This widget cycles between multiple numbers. It draws the number, and increments it when clicked. If it goes over its max, it goes back to 1.
class NumberCycler : public MapEditorWidget
{
public:
	NumberCycler(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, int maxNumber);
	void draw();
	int getIndex();
	// Selects number `index`+1, clamped to 1..maxNumber.
	void setIndex(int index) { currentNumber = std::clamp(index + 1, 1, maxNumber); }
	int maximum() const { return maxNumber; }
	void handleClick(int relMouseX, int relMouseY);
private:
	int maxNumber;
	int currentNumber;
};



///This widget has a checkbox, when set, it adjusts the given variable
class Checkbox : public MapEditorWidget
{
public:
	Checkbox(MapEdit& me, const widgetRectangle& area, const std::string& group, const std::string& name, const std::string& action, const std::string& text, bool& isActivated);
	void draw();
	void handleClick(int relMouseX, int relMouseY);
private:
	std::string text;
	bool& isActivated;
};



///This is the map editor class in all its glory.
class MapEdit
{
	friend class HighResolutionIntegrationHarness;
    friend class PhoneEditor;
    friend class GameGUITouchHarness;
	friend class MobileGalleryGameplay;
	std::unique_ptr<PhoneEditor> phone;
    bool editing = false;
    int editingResult = 0;
    GAGCore::InputState inputState;
    bool fertilityRequested = false;
    bool pendingSettings = false;
    std::string pendingSaveFilename, pendingSaveName, pendingLoadFilename, pendingShareFilename;
    std::unique_ptr<GAGCore::BackgroundFileWriter> saveWriter;
    // Keep retry/export available if a save fails after a window-close request.
    bool quitAfterSave = false;
public:
	MapEdit();
	~MapEdit();
	///Loads the game given by a particular file name
	bool load(const std::string filename);
    GAGCore::CooperativeTask loadTask(std::string filename);
	///Writes a map after the owned fertility job has committed its results
	bool save(const std::string filename, const std::string name);

	///Updates the editor after map generation
	void update();

    bool takeSettingsRequest() { return std::exchange(pendingSettings, false); }
    bool usesPhone() const { return bool(phone); }
    // Touch content is coasting or bouncing; the screen frames faster meanwhile.
    bool touchAnimating() const;
    void beginEditing();
    void viewportResized(int oldWidth, int oldHeight, int width, int height);
    void requestLoad(std::string filename) { pendingLoadFilename = std::move(filename); }
    std::string takeLoadRequest() { return std::exchange(pendingLoadFilename, {}); }
    // "Share online…" from the menu: the saved map file to upload to the catalog.
    std::string takeShareRequest() { return std::exchange(pendingShareFilename, {}); }
    void suspendInput();
    bool advanceEditing(const std::vector<SDL_Event>& events, Uint32 tick);
    void drawEditing();
	///The dialog receiving input: a menu, file dialog, editor or the area name box.
	bool hasDialog() const;
	Glob2UI::InGameDialog *activeDialog() const;
	void attachDialog(Glob2UI::InGameDialog &dialog);
	void drawDialog();
    bool needsFertility() const { return fertilityRequested; }
    bool finishFertility(bool completed);
    bool needsQuitDecision() const { return confirmPurpose == ConfirmPurpose::Quit || confirmPurpose == ConfirmPurpose::QuitApplication; }
    void resolveQuitDecision(int choice);
    int editingReturnCode() const { return editingResult; }

	void mapHasBeenModified(void) { hasMapBeenModified=true; }
	
	///This function regenerates a game header for use in campaigns
	void regenerateGameHeader();

	Game game;

	///Per-client viewer state (selection + mouse). NOT simulation state — see
	///Game::ViewState. Owned here (not on Game) and passed into game.drawMap.
	///The editor only ever uses selectedUnit.
	Game::ViewState view;

	// --- WS-A brush catalogue ---
	// One brush model for every presentation; see BrushCatalog.h for entry ids
	// and actions. The catalogue is rebuilt lazily whenever the map's terrain or
	// resource definitions, the enabled experiments or the building catalog change.
	const std::vector<BrushGroup>& brushCatalog();
	// Increases whenever brushCatalog() content may have changed; presentations
	// rebuild their cards when it differs from the value they last saw.
	std::uint64_t catalogRevision();
	// The catalogue entry with this id, or nullptr.
	const BrushEntry* findBrush(std::string_view id);
	// Catalogue id of the active brush ("terrain/grass", "resource/wheat",
	// "building/swarm", "zone/guard", "tool/delete", ...), empty when nothing is
	// selected. Presentations highlight the entry whose id matches.
	std::string currentBrushId() const;
	// Whether the edited map may use an experiment: switched on in the player's
	// settings or already carried by the map's game header.
	bool experimentEnabled(const std::string& key) const;
	// Carries the experiment in this map's game header, marks the map modified and
	// refreshes the catalogue. Returns false for keys the map cannot carry.
	bool enableExperimentForMap(const std::string& key);
	// The shared swatch cache, bound to the map's current registries.
	BrushSwatches& brushSwatches();
private:
	ExperimentGate experimentGate() const;
	BrushCatalogInputs brushCatalogInputs() const;
	std::string brushCatalogSignature() const;
	// Maps legacy resource selectors (Wheat..PruneTree) and terrain aliases to the
	// canonical selector, so equal brushes compare equal.
	TerrainSelector::TerrainType canonicalSelector(TerrainSelector::TerrainType type) const;
	std::vector<BrushGroup> brushCatalogCache;
	std::string brushCatalogKey;
	std::uint64_t brushCatalogRevision = 0;
	std::unique_ptr<BrushSwatches> swatches;
public:
	// --- end WS-A brush catalogue ---

	// --- WS-C dock ---
	// The desktop/tablet brush browser (EditorDock.h). Presentations without a
	// dock (the phone editor) report width 0. createDock() replaces any existing
	// dock; destroyDock() drops it and returns the map to the full width.
	bool hasDock() const { return bool(dock); }
	void createDock();
	void destroyDock();
	// Logical width the dock takes from the right of the editor surface; the
	// legacy sidebar width when neither dock nor phone presentation exists.
	int dockWidth() const;
	EditorDock *editorDock() const { return dock.get(); }
	// Map status strip (bottom-left of the map): pointer coordinates plus the
	// transient status from showStatus().
	const std::string &coordinatesText() const { return coordinates; }
private:
	friend class EditorDock;
	friend InspectorModel buildInspectorModel(MapEdit &editor);
	std::unique_ptr<EditorDock> dock;
	// Dock sections the author collapsed ("<section>/<group>"), kept across
	// dock rebuilds and presentation switches.
	std::set<std::string> dockCollapsed;
	std::string coordinates;
	// Dock navigation for "open terrain palette [group]" and "open resource palette".
	void revealBrushGroup(BrushSection section, const std::string &group);
	// Whether the pointer is over the dock or a dialog (no map brush preview).
	bool pointerOverInterface() const;
	// Centres the map view on the map cell under a point of the placed minimap.
	void centerViewOnMinimap(int x, int y);
	// Sends a pointer or key event to the dock when it owns it; false for the map.
	bool routeToDock(SDL_Event &event);
	bool swallowSearchKeyText = false;
	// Updates and paints the dock over the map (beneath any dialog).
	void drawDock(Uint32 tick);
public:
	// --- end WS-C dock ---
	// --- WS-D presentation ---
	// The phone tray or the dock, chosen live from the window and input
	// (MapEditPresentation.h).
	EditorPresentation presentation() const;
	// Re-chooses the presentation (viewportResized and construction call it). On a
	// change, unfinished strokes and drags are cancelled and the brush, panel
	// mode, team and levels kept. Returns whether the presentation changed.
	bool syncPresentation();
	// The dock sizes its targets for touch.
	bool presentationTouchTargets() const;
	// MapEditorScreen requests a point-sized (responsive) viewport.
	bool wantsResponsiveViewport() const;
private:
	EditorPresentation wantedPresentation() const;
	// Seam for the EditorDock (WS-C): createDock()/destroyDock().
	void enterDockPresentation();
	void leaveDockPresentation();
public:
	// --- end WS-D presentation ---

	friend class MapEditorWidget;
	friend class BuildingSelectorWidget;
	friend class TeamColorSelector;
	friend class SingleLevelSelector;
	friend class PanelIcon;
	friend class MenuIcon;
	friend class ZoneSelector;
	friend class BrushSelector;
	friend class UnitSelector;
	friend class TerrainSelector;
	friend class TerrainGroupSelector;
	friend class BlueButton;
	friend class PlusIcon;
	friend class MinusIcon;
	friend class TeamInfo;
	friend class BuildingInfoTitle;
	
	///This is used for the Fertility Overlay
	OverlayArea overlay;
	///Tells whether the fertility overlay is set or not
	bool isFertilityOn;
private:
	void draw(Uint64 frameTick);

	///If this is set, the map editor will exit as soon as it finishes drawing and processing events
	bool doQuit;
	///If this is set, the map editor will do a full quit, from glob2 entirely
	bool doFullQuit;
	///Tells whether the game should quit after the load/save menu closes
	bool doQuitAfterLoadSave;

	///This draws the map and various on-map elements
	void drawMap(int sx, int sy, int sw, int sh);

	///This draws the minimap
	void drawMiniMap(void);

	///This is the mode of the right-hand-side panel
	enum PanelMode
	{
		AddBuildings,
		AddFlagsAndZones,
		Terrain,
		Teams,
		UnitEditor,
		BuildingEditor,
	};

	///This draws the right side menu in its entirety
	void drawMenu(void);
	///Draws some of the fancy bars, and the bar at the top of the screen, the eye-candy so to speak
	void drawMenuEyeCandy();
	///Draws a unit under the cursor. This should be done and only done when the user is placing a unit.
	void drawPlacingUnitOnMap();
	///Draws a building under the cursor. Like drawPlacingUnitOnMap, it should only be done when placing a building
	void drawBuildingSelectionOnMap();

	///This processes an event from the SDL
	void processEvent(SDL_Event& event);
	///Dispatches a mouse button press or release. processEvent has already
	///resynced mouseX/mouseY to the event's own position when this runs.
	void handleMouseButtonEvent(SDL_Event& event);
	///Handles a key pressed. For most keys, this means going to the keyboard shortcuts. For the arrow keys, it starts or stops scrolling the map
	void handleKeyPressed(SDL_KeyboardEvent key, bool pressed);
	///This performs an action in the form of the string. This is where a lot of code goes. As opposed to using separate functions for such a large
	///number of possible actions, or just inlining them, this system locates them all here, and every small bit has a name as well. It makes debugging
	///easy in some ways, and it also greatly improves readability. All of the widget "actions" come to here.
	void performAction(const std::string& action, float relMouseX=0, float relMouseY=0);
    void selectActiveTeam(int selected);
	///Handles view, scrolling, minimap and screen/dialog actions. Returns true if the action was handled.
	bool performViewAction(const std::string& action, float relMouseX, float relMouseY);
	///Handles building placement, terrain, zone, area and team-selection actions. Returns true if the action was handled.
	bool performTerrainAction(const std::string& action, float relMouseX, float relMouseY);
	///Handles unit placement and unit-editor actions. Returns true if the action was handled.
	bool performUnitAction(const std::string& action, float relMouseX, float relMouseY);
	///Handles the building-editor actions. Returns true if the action was handled.
	bool performBuildingAction(const std::string& action, float relMouseX, float relMouseY);
	///This delegates a sdl event to one of the menus, if they are open, and handle end codes of the menus appropriately
	void delegateMenu(SDL_Event& event);
	///Handles the scrolling of the map, by arrow keys and by putting the mouse near the edge of the screen
	void handleMapScroll();
	///Updates the coordinates label, should be called when scrolling or moving the mouse
	void updateCoordinatesLabel();

	///This states whether the minimap was rendered or not
	bool wasMinimapRendered;

	///This is the x position of the map that is being painted on the screen
	int viewportX;
	///This is the y position of the map that is being painted on the screen
	int viewportY;
	MapCamera camera;
	void updateCamera();
	bool zoomMap(double steps, int x, int y);
	int mapMouseX(int x) const { return camera.localX(x); }
	int mapMouseY(int y) const { return camera.localY(y); }
	///This is the x-scrolling speed
	int xSpeed;
	///This is the y-scrolling speed
	int ySpeed;
	///This is the mouse x position, updated whenever the mouse moves
	int mouseX;
	///This is the mouse y position, updated whenever the mouse moves
	int mouseY;
	///This is the mouse x position relative to its last position
	float relMouseX;
	///This is the mouse y position relative to its last position
	float relMouseY;
	///True while either mouse button is dragging the map camera
	bool isScrollDragging;
	bool isLeftScrollDragging;
	bool isMiddleScrollDragging;

	///the keyboardManager handles keyboard shortcuts
	KeyboardManager keyboardManager;

	bool hasMapBeenModified;
	///Provides the currently active team number
	int team;

	PanelMode panelMode;

	//Miscellaneous panel icons and coordinates label
	PanelIcon* buildingView;
	PanelIcon* flagsView;
	PanelIcon* terrainView;
	PanelIcon* teamsView;
	MenuIcon* menuIcon;
	TextLabel* mapCoordinatesLabel;

	///Building view
	///@{
	std::vector<BuildingSelectorWidget*> buildingSelectors;
	std::vector<BuildingSelectorWidget*> flagSelectors;
	TeamColorSelector* building_view_tcs;
	SingleLevelSelector* building_view_level1;
	SingleLevelSelector* building_view_level2;
	SingleLevelSelector* building_view_level3;
	TextLabel* buildingLevelNextPage=nullptr;
	int buildingLevelCount=1;
	///@}

	///Flag, zone, and unit view
	///@{
	ZoneSelector* forbiddenZone;
	ZoneSelector* guardZone;
	ZoneSelector* clearingZone;
	///Null unless Settings > Experiments > Farm areas was on when the editor opened
	ZoneSelector* farmingZone = nullptr;
	BrushSelector* zoneBrushSelector;
	UnitSelector* worker;
	UnitSelector* explorer;
	UnitSelector* warrior;
	BlueButton* deleteButton;
	TeamColorSelector* flag_view_tcs;
	SingleLevelSelector* flag_view_level1;
	SingleLevelSelector* flag_view_level2;
	SingleLevelSelector* flag_view_level3;
	SingleLevelSelector* flag_view_level4;
	///@}

	///Terrain, resources and areas view
	///@{
	TerrainSelector* grass;
	TerrainSelector* sand;
	TerrainSelector* water;
    // One per enabled catalogue group: a TerrainSelector when the group has a
    // single enabled member, otherwise a TerrainGroupSelector opening the palette.
    std::vector<MapEditorWidget*> additionalTerrainSelectors;
	TerrainSelector* wheat;
	TerrainSelector* trees;
	TerrainSelector* stone;
	TerrainSelector* algae;
	TerrainSelector* papyrus;
	TerrainSelector* orange;
	TerrainSelector* cherry;
	TerrainSelector* prune;
	BlueButton* noResourceGrowthButton;
	BlueButton* areasButton;
	NumberCycler* areaNumber;
	TextLabel* areaNameLabel;
	BrushSelector* terrainBrushSelector;
	Checkbox* showFertilityOverlay;
	///@}

	///Teams view
	///@{
	PlusIcon* increaseTeams;
	MinusIcon* decreaseTeams;
	TeamColorSelector* team_view_tcs;
	///@}

	///Unit editor view
	///@{
	UnitInfoTitle* unitInfoTitle;
	UnitPicture* unitPicture;
	FractionValueText* unitHPLabel;
	ValueScrollBox* unitHPScrollBox;
	FractionValueText* unitWalkLevelLabel;
	ValueScrollBox* unitWalkLevelScrollBox;
	FractionValueText* unitSwimLevelLabel;
	ValueScrollBox* unitSwimLevelScrollBox;
	FractionValueText* unitBuildLevelLabel;
	ValueScrollBox* unitBuildLevelScrollBox;
	FractionValueText* unitAttackSpeedLevelLabel;
	ValueScrollBox* unitAttackSpeedLevelScrollBox;
	FractionValueText* unitAttackStrengthLevelLabel;
	ValueScrollBox* unitAttackStrengthLevelScrollBox;
	FractionValueText* unitMagicGroundAttackLevelLabel;
	ValueScrollBox* unitMagicGroundAttackLevelScrollBox;
	///@}

	///Building editing view
	///@{
	BuildingInfoTitle* buildingInfoTitle;
	BuildingPicture* buildingPicture;
	std::array<FractionValueText*, MaterialCount> buildingResourceLabels{};
	std::array<ValueScrollBox*, MaterialCount> buildingResourceControls{};
	std::vector<std::pair<FractionValueText*,ValueScrollBox*>> buildingEditRows;
	int buildingEditFirstRow=0;
	Sint32 buildingBombingRequirement=0;
	FractionValueText* buildingWorkerLevelLabel;
	ValueScrollBox* buildingWorkerLevelScrollBox;
	FractionValueText* buildingBombingLabel;
	ValueScrollBox* buildingBombingScrollBox;
	void layoutBuildingEditRows();
	FractionValueText* buildingHPLabel;
	ValueScrollBox* buildingHPScrollBox;
	FractionValueText* buildingAssignedLabel;
	ValueScrollBox* buildingAssignedScrollBox;
	FractionValueText* buildingWorkerRatioLabel;
	ValueScrollBox* buildingWorkerRatioScrollBox;
	FractionValueText* buildingExplorerRatioLabel;
	ValueScrollBox* buildingExplorerRatioScrollBox;
	FractionValueText* buildingWarriorRatioLabel;
	ValueScrollBox* buildingWarriorRatioScrollBox;
	FractionValueText* buildingBulletsLabel;
	ValueScrollBox* buildingBulletsScrollBox;
	FractionValueText* buildingMinimumLevelLabel;
	ValueScrollBox* buildingMinimumLevelScrollBox;
	FractionValueText* buildingRadiusLabel;
	ValueScrollBox* buildingRadiusScrollBox;
	///@}

	///This is the name of the currently selected building type
	std::string selectionName;
	///This is the level of the buildings in the menu. It is
    ///changed by the buttons at the bottom of the building menu
	int buildingLevel;
	///Returns whether the particular type of building is upgradable
	int buildingSelectionType(const std::string& key);
    int displayedBuildingSelectionType(const std::string& key) const;
	void rebuildBuildingSelectors();
	void layoutBuildingSelectors();
	bool scrollBuildingSelectors(double delta);
	int buildingSelectorRow=0, flagSelectorRow=0;

	///A pointer to the editor sprites
	Sprite *menu;

	///Denotes the mode the cursor is in, such as placing a building, terrain, removing objects, editing a building, etc..
	enum SelectionMode
	{
		PlaceNothing,
		PlaceBuilding,
		PlaceZone,
		PlaceTerrain,
		PlaceUnit,
		RemoveObject,
		EditingUnit,
		EditingBuilding,
		ChangeAreas,
		ChangeNoResourceGrowthAreas,
	} selectionMode;

	///Adds a widget to be drawn and respond to clicks
	void addWidget(MapEditorWidget* widget);
	///Finds and runs the action associated with a particular mouse x and mouse y position. Returns false if none is found, true otherwise
	bool findAction(int x, int y);
	///Enables only widgets with this particular groupname, or the name "any" as a special name
	void enableOnlyGroup(const std::string& group);
	///Draws all enabled widgets
	void drawWidgets();
	std::vector<MapEditorWidget*> mew;

	///Translates a mouse x and mouse y position to coordinates on the Map
	void minimapMouseToPos(int mx, int my, int *cx, int *cy, bool forScreenViewport);
	///Denotes whether the user is holding the mouse button down, dragging the minimap
	bool isDraggingMinimap;
	///The minimap
	Minimap minimap;

	///This is the last placement of terrain, zones, or else, so that the game doesn't use a lot of cpu by small mouse movements
	int lastPlacementX;
	///This is the last placement of terrain, zones, or else, so that the game doesn't use a lot of cpu by small mouse movements
	int lastPlacementY;
	///Map coordinates recorded at the start of a brush stroke, the anchor for
	///checkerboard parity alignment in BrushTool. Empty until the stroke's first click.
	struct FirstPlacement
	{
		int x;
		int y;
	};
	std::optional<FirstPlacement> firstPlacement;

	///Tells whether the menu screen is being drawn right now
	bool showingMenuScreen;
	std::unique_ptr<MapEditMenuScreen> menuScreen;
    std::unique_ptr<SetLibraryDialog> setLibraryDialog;
    bool importingSet = false;

	///Tells whether the load-game menu screen is being drawn right now
	bool showingLoad;
	///Tells whether the save-game menu screen is being drawn right now
	bool showingSave;
	std::unique_ptr<LoadSaveDialog> loadSaveScreen;
	bool importingResources = false;
	void importResourceFile(const std::string& filename);
	bool importingTerrain = false;
	void importTerrainFile(const std::string &filename);

	///Tells whether the script editor is being drawn
	bool showingScriptEditor;
	std::unique_ptr<ScriptEditorScreen> scriptEditor;
	
	///Tells whether the teams editor is being drawn
	bool showingTeamsEditor;
	std::unique_ptr<TeamsEditor> teamsEditor;



	///The various types of brushes for placing a zone
	enum BrushType
	{
		ForbiddenBrush,
		GuardAreaBrush,
		ClearAreaBrush,
		FarmAreaBrush,
		NoBrush,
		
	} brushType;
	///This is a brush tool that the BrushSelector widget uses
	BrushTool brush;
	///This is an accumulator, it builds up a list of positions to be changes
	BrushAccumulator brushAccumulator;
	///Handles brush click to place a zone
	void handleBrushClick(int mx, int my);
	///The pair of map fields a zone brush edits: the per-tile team bitmask and the local (display-only) overlay
	struct AreaBrushTarget
	{
		Uint32 Tile::* tileMask;
		Utilities::BitArray& view;
	};
	///Returns the map fields edited by the current brushType
	AreaBrushTarget areaBrushTarget();
	///Tells whether the user is dragging the brush, continually placing zone
	bool isDraggingZone;


	///The type of terrain that is selected
	TerrainSelector::TerrainType terrainType;
	///Handles a click or drag of the mouse when placing terrain
	void handleTerrainClick(int mx, int my);
	///Tells whether the terrain is being dragged, continually placing more
	bool isDraggingTerrain;
	// --- WS-B brush painting ---
public:
	//! A point of the brush lattice: a map cell, or a vertex for terrain brushes.
	using BrushCell = std::pair<int, int>;
	//! Terrain is stored per vertex, so base-terrain brushes stamp vertices
	//! (the smallest figure is a single vertex); resource brushes stamp cells.
	bool brushOnVertices() const;
	//! Lattice point under a map-local pointer position: the cell under it, or
	//! for a vertex brush the nearest vertex. Preview and commit share it.
	BrushCell brushCellAt(int mx, int my) const;
	//! Pixels a lattice point's square starts at, relative to its cell's origin:
	//! a vertex's square is centred on the vertex.
	int brushSquareOffset() const { return brushOnVertices() ? -16 : 0; }
	//! The brush figure's lattice points centred on one, in unwrapped coordinates
	//! around it, aligned to the current stroke's checkerboard origin.
	std::vector<BrushCell> terrainBrushCells(int mapX, int mapY) const;
	//! The cells of a footprint where the selected resource cannot be placed.
	std::vector<BrushCell> invalidResourceCells(const std::vector<BrushCell> &footprint);
	//! "<Resource> can only be placed on: <terrains>" for the selected resource.
	std::string resourcePlacementHint() const;
	//! A short non-interactive message at the bottom left of the map.
	void showStatus(std::string text, Uint32 durationMs = 4000);
	const std::string &lastStatus() const { return statusText; }
private:
	std::string statusText;
	Uint64 statusUntil = 0;
	int strokeCoveredCells = 0, strokePlacedResources = 0;
	void finishTerrainStroke();
	void drawTerrainBrushPreview();
public:
    // Explicit owner observation for editor drawing and standalone editor tools.
    void preparePresentation();
private:
	void drawStatus();
	// --- end WS-B brush painting ---
	///Handles a click or drag of the mouse when removing objects
	void handleDeleteClick(int mx, int my);
	///Tells whether the delete tool is being dragged
	bool isDraggingDelete;

	void handleClick(int mx, int my, BrushTool::ClickType clickType);

	enum class TerrainPlacementMode
	{
		BaseTerrain,
		Resource,
	};

	void beginZonePlacement(BrushType type);
	void beginTerrainPlacement(TerrainSelector::TerrainType type, TerrainPlacementMode mode);
	void resetPlacementTracking();
	void refreshSelectedUnitPerformance(int stat);
	void addBuildingEditRow(FractionValueText* label, ValueScrollBox* scrollBox, bool shown);

	///This vector of the keys on the team view. It allows one to choose between AI and human teams for campaign games
	std::vector<std::string> teamViewSelectorKeys;

	///Tells the type of unit that is being placed
	enum PlacingUnit
	{
		Worker,
		Explorer,
		Warrior,
		NoUnit,
	} placingUnit;
	///Tells the level of skills of the unit that is being placed
	int placingUnitLevel;

	///The gid of the unit that is currently selected
	int selectedUnitGID;
	///The gid of the building that is currently selected
	int selectedBuildingGID;
	
	///Tells whether the text input box
	bool isShowingAreaName;
	std::unique_ptr<AskForTextInput> areaName;
	///Tells whether we are dragging the area placement tool
	bool isDraggingArea;
	///Handles a click or drag of the script area placement tool
	void handleAreaClick(int mx, int my);

	///Tells whether where dragging the no resource growth area placement tool
	bool isDraggingNoResourceGrowthArea;
	///Handles a click or drag of the no resource growth area placement tool
	void handleNoResourceGrowthClick(int mx, int my);

	// --- WS-E flows ---
	// Saving, loading, sharing and quitting stay inside the editor: decisions
	// are EditorConfirmDialog cards and fertility runs in an EditorProgressDialog
	// over the live map (implemented in MapEditFlows.cpp).
public:
	bool hasUnsavedChanges() const { return hasMapBeenModified; }
	// A window close or application quit (SDL_EVENT_QUIT, Cmd+Q, Alt+F4).
	void requestApplicationQuit();
	// MapShareScreen returned with this result.
	void finishShare(bool shared);
	bool fertilityOverlayStale() const { return isFertilityOn && fertilityStale; }
	enum class ConfirmPurpose
	{
		None,
		Quit,
		QuitApplication,
		LoadUnsaved,
		ShareSaveFirst,
		RerollTerrain
	};
	ConfirmPurpose pendingConfirm() const { return confirmPurpose; }
	EditorConfirmDialog *confirmation() const { return confirmDialog.get(); }
	EditorProgressDialog *fertilityProgress() const { return progressDialog.get(); }
	// The map file this editor last loaded or saved; empty for a map never saved.
	const std::string &savedMapFile() const { return savedFilename; }

private:
	enum FlowChoice
	{
		ChoiceSave,
		ChoiceDiscard,
		ChoiceCancel,
		ChoiceShareSaved,
		ChoiceConfirm
	};
	std::unique_ptr<EditorConfirmDialog> confirmDialog;
	ConfirmPurpose confirmPurpose = ConfirmPurpose::None;
	std::vector<FlowChoice> confirmChoices;
	void openConfirm(ConfirmPurpose purpose);
	void resolveConfirm(int index);
	std::unique_ptr<EditorProgressDialog> progressDialog;
	void openFertilityProgress();
	void finishFertilityProgress();
	bool fullQuitAfterSave = false, shareAfterSave = false, loadAfterSave = false;
	bool fertilityStale = false, fertilityChipPressed = false;
	std::string savedFilename;
	// The load picker, after any unsaved-changes decision.
	void openLoadDialog();
	// Close menus and pickers before a flow opens the save dialog.
	void closeDialogsForFlow();
	void saveSucceeded();
	void clearSaveFollowUps();
	// Device file picker for definition imports.
	std::unique_ptr<GAGCore::ApplicationHost::FileSelection> deviceSelection;
	void beginDeviceImport();
	void pollDeviceImport();
	void importTerrainJson(const std::string &json);
    void importSetJson(const std::string& json, const std::vector<std::string>& selected = {});
    void importSetFile(const std::string& filename);
	void importResourceJson(const std::string &json);
	// Snapshots taken when the teams or scenario editor opens; OK marks the map
	// modified only when the result differs.
	std::vector<TeamsEditor::Slot> teamSlotsAtOpen;
	std::vector<BaseTeam> baseTeamsAtOpen;
	std::string scenarioAtOpen;
	std::string scenarioFingerprint();
	bool teamSlotsChanged() const;
	// The "refresh fertility" chip shown over the map while the overlay is stale.
	bool handleFlowEvent(const SDL_Event &event);
	void drawFlowOverlays();
	widgetRectangle fertilityChipRect() const;
	// --- end WS-E flows ---
};
