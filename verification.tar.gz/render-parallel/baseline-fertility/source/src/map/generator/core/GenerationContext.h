// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "GenerationRequest.h"
#include "GenerationTelemetry.h"
#include "Team.h"
#include <array>
#include <map>
#include <random>
#include <utility>
class Game;
struct GenerationContext
{
	const GenerationRequest &request;
	std::array<int, Team::MAX_COUNT> bootX{}, bootY{};
	std::string stage = "terrain";
	std::string detail;
	GenerationTelemetry telemetry;
	explicit GenerationContext(const GenerationRequest &r, bool collectTelemetry = false)
		: request(r), telemetry(collectTelemetry)
	{
	}
	std::mt19937 &stream(const std::string &name);
	std::uint32_t bounded(const std::string &name, std::uint32_t bound);
	/// Shuffles a range, one bounded draw per element from the back forward.
	template <typename It> void shuffle(It first, It last, const std::string &name)
	{
		for (auto n = last - first; n > 1; --n)
			std::swap(first[n - 1], first[bounded(name, std::uint32_t(n))]);
	}
	/// Every stream asked for so far, by name, in its current state.
	const std::map<std::string, std::mt19937> &namedStreams() const { return streams; }
	static std::uint32_t deriveSeed(std::uint32_t seed, const std::string &name);
	// Pure variant resolution: repeated validation/design calls make the same choice and do
	// not advance any geometry stream. Callers supply only feasible concrete variants.
	static int choiceFromSeed(std::uint32_t seed, const std::string &name,
							  const std::vector<int> &values);
	static std::uint32_t randomSeed();

  private:
	std::map<std::string, std::mt19937> streams;
};
