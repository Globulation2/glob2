// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <string>
#include <optional>
#include <utility>
#include <vector>
struct GenerationRequest;
class MapGenerationDescriptor;
enum class ControlGroup
{
	Terrain,
	Resources,
	Layout,
	Shared
};
struct GeneratorControl
{
	// Nested rather than a top-level ControlKind: macOS' Carbon headers, which Glob2.cpp pulls in
	// through SDL, already declare a struct by that name, and the two clash in that one
	// translation unit. Keep it scoped here.
	enum class Kind
	{
		// A number from minimum to maximum in steps, or one of allowedValues.
		Range,
		// An on/off switch, stored as 0 or 1 and shown as a checkbox.
		Toggle
	};
	std::string id;
	const char *label;
	int minimum, maximum, step, defaultValue;
	ControlGroup group = ControlGroup::Terrain;
	bool powerOfTwo = false;
	bool terrainWeight = false;
	// Optional ordered domain, e.g. {4, 8, 16}; values are stored literally.
	std::vector<int> allowedValues;
	Kind kind = Kind::Range;
	// A choice's name for each of its values 0, 1, 2... in order, translated where shown. Empty for
	// a number.
	std::vector<const char *> valueLabels;
	// The player-facing randomizer samples this domain; manual controls keep values().
	// Exactly one declaration is required, even when the search domain is the full domain.
	std::optional<std::pair<int, int>> searchRange;
	std::optional<std::vector<int>> searchAllowedValues;
	GeneratorControl withSearchRange(int low, int high) const;
	GeneratorControl withSearchValues(std::vector<int> values) const;
	std::vector<int> searchValues() const;
	bool validSearchDomain() const;
	static GeneratorControl toggle(std::string id, const char *label, bool on,
								   ControlGroup group = ControlGroup::Layout);
	// A resource amount as a percentage of the generator's own default, which is 100.
	static GeneratorControl percentage(std::string id, const char *label, int maximum = 300);
	// One of several named options, stored as its index: a cell shape, say, rather than a number.
	static GeneratorControl choice(std::string id, const char *label,
								   std::vector<const char *> names, int defaultIndex,
								   ControlGroup group = ControlGroup::Layout);
	bool isToggle() const { return kind == Kind::Toggle; }
	bool isChoice() const { return !valueLabels.empty(); }
	// The untranslated name a choice shows for `value`, or nullptr for a number.
	const char *valueLabel(int value) const;
	std::vector<int> values() const;
	int indexOf(int value) const;
	int valueAt(int index) const;
	int displayValue(int value) const;
	int normalize(int value) const;
	int get(const GenerationRequest &) const;
	void set(GenerationRequest &, int) const;
	int get(const MapGenerationDescriptor &) const;
	void set(MapGenerationDescriptor &, int) const;
};
const std::vector<GeneratorControl> &sharedGeneratorControls();
//! The editor also offers 32 x 32 maps, the natural source for repeating a map (MapTiling).
//! The lobby keeps 64 as its smallest size; many landscapes cannot seat colonies on less.
static constexpr int EDITOR_MINIMUM_SIZE_SHIFT = 5;
//! `shared` with the editor's smaller minimum when it is the width or height control.
GeneratorControl editorSizeControl(const GeneratorControl &shared);
