// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "StartQuality.h"
#include "GenerationTelemetry.h"
#include <cstdint>
#include <stdexcept>
#include <string>
class GenerationFailure : public std::runtime_error
{
  public:
	using std::runtime_error::runtime_error;
};
enum class GenerationError
{
	None,
	InvalidRequest,
	NonEmptyTarget,
	PlacementFailed,
	InvalidWorld,
	ScriptFailed,
	BudgetExceeded
};
class ScriptGenerationFailure : public GenerationFailure
{
  public:
	GenerationError error;
	ScriptGenerationFailure(GenerationError error, const std::string &detail)
		: GenerationFailure(detail), error(error)
	{
	}
};
struct GenerationResult
{
	std::string generatorId;
	std::string packageHash;
	unsigned apiVersion = 0;
	unsigned revision = 0;
	std::uint32_t seed = 0;
	std::string stage;
	GenerationError error = GenerationError::None;
	std::string detail;
	/// How good a start each colony got, and how evenly. Only filled on success.
	MapGeneration::StartQualityReport quality;
	/// Generator-supplied observations, including the partial trace when generation fails.
	GenerationTelemetry telemetry;
	explicit operator bool() const { return error == GenerationError::None; }
	std::string diagnostic() const;
};
