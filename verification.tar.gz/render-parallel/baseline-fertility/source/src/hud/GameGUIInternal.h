// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

// Constants shared between the split GameGUI*.cpp translation units.
// This header is intentionally private to those files; do not include it elsewhere.

#pragma once

#include <string>

#include <GUIBase.h>
#include <GraphicContext.h>

#include "GlobalContainer.h"
#include "BuildingPresentation.h"

using namespace GAGCore;
using namespace GAGGUI;

// These values are manually laid out for readability.
#define YPOS_BASE_DEFAULT 180
#define YPOS_BASE_CONSTRUCTION (YPOS_BASE_DEFAULT + 5)
#define YPOS_BASE_FLAG (YPOS_BASE_DEFAULT + 5)
#define YPOS_BASE_STAT YPOS_BASE_DEFAULT
#define YPOS_BASE_BUILDING (YPOS_BASE_DEFAULT + 10)
#define YPOS_BASE_UNIT (YPOS_BASE_DEFAULT + 10)
#define YPOS_BASE_RESOURCE YPOS_BASE_DEFAULT

#define YOFFSET_NAME 28
#define YOFFSET_ICON 52
#define YOFFSET_CARRYING 34
#define YOFFSET_BAR 32
#define YOFFSET_INFOS 12
#define YOFFSET_TOWER 22

#define YOFFSET_B_SEP 6

#define YOFFSET_TEXT_BAR 16
#define YOFFSET_TEXT_PARA 14
#define YOFFSET_TEXT_LINE 12

#define YOFFSET_PROGRESS_BAR 10

#define YOFFSET_BRUSH 56

// The flag view's zone-type strip (forbidden/guard/clearing, plus farm with
// the farm-areas experiment) sits at YPOS_BASE_FLAG+YOFFSET_BRUSH and is this
// tall; the brush tool panel starts directly below it. Shared by the draw path
// (GameGUIDrawMiscPanels.cpp) and the click path (GameGUIInputMenuClick.cpp) so
// they cannot drift apart.
constexpr int ZONE_STRIP_HEIGHT = 40;

inline int buildingExtraHeaderHeight(const BuildingType& type)
{
    return buildingHasSeparateAttractionHeader(type) ? YOFFSET_ICON+YOFFSET_B_SEP : 0;
}

// Per-row pitches inside the building info panel resource/swarm sections.
#define YOFFSET_RESOURCE_LINE 11
#define YOFFSET_RESOURCE_SECTION_PAD 5
#define YOFFSET_SWARM_PROGRESS_BAR 15
#define YOFFSET_SWARM_RATIO_LINE 20

// Dimensions of the production-timeout progress bar that sits above the swarm
// ratio scrollboxes. The width matches the right-menu content area (same
// literal appears in RIGHT_MENU_OFFSET below).
#define SWARM_PROGRESS_BAR_WIDTH 128
#define SWARM_PROGRESS_BAR_HEIGHT 7

// Y-offsets (measured from the bottom of the screen) of the repair/upgrade
// and destroy action buttons in the building info panel, and the button height
// used for hit-testing the upgrade-preview tooltip hover.
#define BOTTOM_BUTTON_PRIMARY_YOFFSET 76
#define BOTTOM_BUTTON_SECONDARY_YOFFSET 52
#define BOTTOM_BUTTON_HEIGHT 16

// The speed chevrons in the top bar: spacing of the chevrons and the width
// they take before the tick rate.
#define TOP_BAR_CHEVRON_PITCH 7
#define TOP_BAR_SPEED_WIDTH 40
// Two coloured Glob-and-arrow counters before the speed control.
#define TOP_BAR_CONVERSION_WIDTH 110

// The sidebar on the right
#include "GameGUIViewport.h"
#define RIGHT_MENU_WIDTH GAME_GUI_RIGHT_MENU_WIDTH
#define RIGHT_MENU_HALF_WIDTH (RIGHT_MENU_WIDTH / 2)
#define RIGHT_MENU_OFFSET ((RIGHT_MENU_WIDTH -128)/2)
#define RIGHT_MENU_RIGHT_OFFSET (RIGHT_MENU_WIDTH - RIGHT_MENU_OFFSET)

// The zone strip's buttons, one per GameGUIToolManager::ZoneType the game offers,
// in that order, in panel-local x. Draw, hover and click all take positions from
// the functions below, so the drawn and clickable grids cannot drift apart.
//
// Three buttons (the default game) sit at a 40px pitch from 8px inside the brush
// panel, exactly where they always have. A fourth (the farm-areas experiment) at
// that pitch would run off the panel, so four are centred on it at a 38px
// pitch: 7, 45, 83 and 121, leaving 7px at each edge of the 160px panel.
constexpr int ZONE_STRIP_BUTTON_SIZE = 32;
constexpr int ZONE_STRIP_PITCH_3 = 40;
constexpr int ZONE_STRIP_PITCH_4 = 38;
constexpr int ZONE_STRIP_X0_3 = RIGHT_MENU_OFFSET + 8;
constexpr int ZONE_STRIP_X0_4 = (RIGHT_MENU_WIDTH - 3 * ZONE_STRIP_PITCH_4 - ZONE_STRIP_BUTTON_SIZE) / 2;

constexpr int zoneStripButtonX(int index, int count)
{
	return count > 3 ? ZONE_STRIP_X0_4 + index * ZONE_STRIP_PITCH_4 : ZONE_STRIP_X0_3 + index * ZONE_STRIP_PITCH_3;
}

//! Panel-local x where the strip's hover and click region starts.
constexpr int zoneStripLeft(int count)
{
	return count > 3 ? ZONE_STRIP_X0_4 - (ZONE_STRIP_PITCH_4 - ZONE_STRIP_BUTTON_SIZE) / 2 : RIGHT_MENU_OFFSET;
}

//! The zone button under panel-local x, or -1 for none. With three buttons this
//! is the strip's original hit test: each button owns 40px from 4px left of its
//! sprite, and the space left of the first button belongs to it. With four, the
//! 6px gaps are split between neighbours.
constexpr int zoneStripButtonAt(int panelX, int count)
{
	if (count <= 3)
	{
		const int x = panelX - RIGHT_MENU_OFFSET;
		return x < 44 ? 0 : x < 84 ? 1 : x < 124 ? 2 : -1;
	}
	const int offset = panelX - zoneStripLeft(count);
	if (offset < 0)
		return -1;
	const int index = offset / ZONE_STRIP_PITCH_4;
	return index < count ? index : -1;
}

static_assert(RIGHT_MENU_OFFSET == (RIGHT_MENU_WIDTH - 128) / 2, "the three-button strip is anchored on the 128px brush panel");
static_assert(zoneStripButtonX(0, 3) == RIGHT_MENU_OFFSET + 8 && zoneStripButtonX(2, 3) == RIGHT_MENU_OFFSET + 88,
	"the default strip keeps its original positions");
static_assert(zoneStripButtonX(0, 4) == RIGHT_MENU_WIDTH - (zoneStripButtonX(3, 4) + ZONE_STRIP_BUTTON_SIZE),
	"four buttons are centred on the panel");
static_assert(zoneStripButtonAt(zoneStripButtonX(0, 4) + ZONE_STRIP_BUTTON_SIZE - 1, 4) == 0
	&& zoneStripButtonAt(zoneStripButtonX(1, 4), 4) == 1
	&& zoneStripButtonAt(zoneStripButtonX(3, 4) + ZONE_STRIP_BUTTON_SIZE - 1, 4) == 3
	&& zoneStripButtonAt(zoneStripLeft(4) - 1, 4) == -1 && zoneStripButtonAt(RIGHT_MENU_WIDTH, 4) == -1,
	"every four-button sprite pixel hits its own button");

// Explorer attraction has an independent bombing requirement. Ground attraction
// retains a minimum training level, so a combined provider exposes both controls.
constexpr int EXPLORATION_FLAG_OPTION_ANY_EXPLORER = 0;
constexpr int EXPLORATION_FLAG_OPTION_GROUND_ATTACK = 1;
constexpr int EXPLORATION_FLAG_OPTION_COUNT = 2;

// Geometry of the three-zone scrollbox widget used for worker count, flag
// stay-range and swarm-ratio sliders. The visual strip is laid out as
//   [<-arrow][===proportional drag track===][->arrow]
// inside the right-menu's 128px content area. Click x-coordinates are
// interpreted relative to the strip's left edge (see
// interpretScrollBoxClick in GameGUIInputMenuClickBuilding.cpp).
constexpr int SCROLLBOX_BAR_WIDTH = 128;
constexpr int SCROLLBOX_ARROW_WIDTH = 18;

// Icons for main menu, alliance and objectives buttons.
#define IGM_ICON_HEIGHT 36
#define IGM_MAIN_MENU_ICON_Y 0
#define IGM_ALLIANCE_ICON_Y IGM_ICON_HEIGHT
#define IGM_OBJECTIVES_ICON_Y (IGM_ICON_HEIGHT * 2)

// Settings for the right sidebar in replays
#define REPLAY_PANEL_XOFFSET 25
#define REPLAY_PANEL_YOFFSET (YPOS_BASE_STAT+10)
#define REPLAY_PANEL_SPACE_BETWEEN_OPTIONS 22
#define REPLAY_PANEL_PLAYERLIST_YOFFSET (5*REPLAY_PANEL_SPACE_BETWEEN_OPTIONS+5)

// The actual progress bar (including buttons)
#define REPLAY_PROGRESS_BAR_X_OFFSET 4
#define REPLAY_PROGRESS_BAR_Y_OFFSET 3
#define REPLAY_PROGRESS_BAR_BUTTON_WIDTH 15
#define REPLAY_PROGRESS_BAR_CAP_WIDTH 10
#define REPLAY_PROGRESS_BAR_NUM_BUTTONS 3

// The panel around the actual progress bar
// Sized from the live surface (globalContainer->gfx->getW()/getH()), like the
// rest of the GUI, rather than the persisted settings.screenWidth/screenHeight
// which do not track a resizable window's current size.
#define REPLAY_BAR_WIDTH (globalContainer->gfx->getW() - RIGHT_MENU_WIDTH - 4)
#define REPLAY_BAR_HEIGHT (2*REPLAY_PROGRESS_BAR_Y_OFFSET + 20)
#define REPLAY_BAR_Y (globalContainer->gfx->getH() - REPLAY_BAR_HEIGHT)
#define REPLAY_BAR_TIMER_X (REPLAY_PROGRESS_BAR_X_OFFSET + REPLAY_PROGRESS_BAR_CAP_WIDTH + 5)

// Sprites for the replay bar
#define REPLAY_BAR_LEFT_CAP_SPRITE 56
#define REPLAY_BAR_RIGHT_CAP_SPRITE 57
#define REPLAY_BAR_PLAY_BUTTON_SPRITE 51
#define REPLAY_BAR_PLAY_BUTTON_ACTIVE_SPRITE 50
#define REPLAY_BAR_PAUSE_BUTTON_SPRITE 53
#define REPLAY_BAR_PAUSE_BUTTON_ACTIVE_SPRITE 52
#define REPLAY_BAR_FAST_FORWARD_BUTTON_SPRITE 55
#define REPLAY_BAR_FAST_FORWARD_BUTTON_ACTIVE_SPRITE 54

enum GameGUIGfxId
{
	EXCHANGE_BUILDING_ICONS = 21
};


