// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#pragma once

namespace Cli { struct Request; }

//! This class is used to handle the whole game
class Glob2
{
	static const bool verbose = false;
public:
	// Graphical completion is reported by the application host.
	static constexpr int HOSTED_RUN = -1000;

public:
	int runNoX();
	///Runs random games non stop until the game crashes
	int runTestGames();
	///Generates random maps non stop until the game crashes
	int runTestMapGeneration();
	int run(const Cli::Request &request);
};

