// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

// FileFormatVersions.h
//
// Save-format minor-version gates and 4-byte ASCII section signatures used
// throughout the save / replay loaders. Every `if (versionMinor >= N)` /
// `< N` comparison in Game_io / GameHeader / Player / Lifecycle / etc. has
// a corresponding named constant here, so that adding a new save-format
// feature only requires touching this one file plus the consumer.
//
// Per-AI minor-version gates (Nicowar's 59 / 60 / 66, etc.) live in their
// own AI tuning headers so that AI internals do not bleed into the
// engine-wide loader.

#pragma once

// === Save-format minor-version feature gates ===
// Each constant is the FIRST versionMinor at which the named feature
// appears in the save stream. Loaders write/read the new field if
// versionMinor >= FILE_FORMAT_VERSION_*; otherwise they fall back to the
// pre-feature default. VALUES MUST NEVER MOVE — they are wire-locked.

//! Building::underAttackTimer added (Lifecycle.cpp:201; UnitSerialization.cpp:62).
static constexpr int FILE_FORMAT_VERSION_UNDER_ATTACK_TIMER = 61;

//! Pre-fertility marker — saves before this lacked the fertility map.
static constexpr int FILE_FORMAT_VERSION_PRE_FERTILITY = 63;

//! Unified seed introduced; "GaBt" sig appeared (Game_io.cpp:134, 146, 417;
//! GameHeader.cpp:54, 75, 77, 129, 150, 152).
static constexpr int FILE_FORMAT_VERSION_UNIFIED_SEED = 64;

//! Building::maxUnitWorkingPrevious field added (Lifecycle.cpp:423).
static constexpr int FILE_FORMAT_VERSION_MAX_UNIT_WORKING_PREVIOUS = 65;

//! Building::maxUnitWorkingFuture field added (Lifecycle.cpp:427).
static constexpr int FILE_FORMAT_VERSION_MAX_UNIT_WORKING_FUTURE = 70;

//! Allies + winning conditions added (GameHeader.cpp:54, 129).
static constexpr int FILE_FORMAT_VERSION_ALLIES_AND_WIN_CONDITIONS = 71;

//! mapDiscovered flag added (GameHeader.cpp:77, 152).
static constexpr int FILE_FORMAT_VERSION_MAP_DISCOVERED_FLAG = 72;

//! Team::race field added (TeamSerialization.cpp:135).
static constexpr int FILE_FORMAT_VERSION_RACE_FIELD = 73;

//! Building::unitsFailingRequirements stored as int (Lifecycle.cpp:432).
//! Predates the array form (see _ARRAY below).
static constexpr int FILE_FORMAT_VERSION_UNITS_FAILING_REQUIREMENTS_INT = 74;

//! Campaign text / objectives section added (Game_io.cpp:204).
static constexpr int FILE_FORMAT_VERSION_CAMPAIGN_TEXT_OBJECTIVES = 75;

//! Briefing + hints + objective `failed` flag (Game_io.cpp:215;
//! GameObjectives.cpp:225).
static constexpr int FILE_FORMAT_VERSION_BRIEFING_HINTS_OBJ_FAILED = 76;

//! Building::unitsFailingRequirements promoted from int to array
//! (Lifecycle.cpp:432).
static constexpr int FILE_FORMAT_VERSION_UNITS_FAILING_REQUIREMENTS_ARRAY = 77;

//! OrderCreate payload grew 20 -> 28 bytes to carry flagRadius
//! (OrderBuilding.cpp:47-49).
static constexpr int FILE_FORMAT_VERSION_ORDER_CREATE_FLAG_RADIUS = 78;

//! Building::priority field added (Lifecycle.cpp:211).
static constexpr int FILE_FORMAT_VERSION_BUILDING_PRIORITY_FIELD = 79;

//! Building::unitsHarvesting list added (Lifecycle.cpp:459).
static constexpr int FILE_FORMAT_VERSION_UNITS_HARVESTING_LIST = 80;

//! Building::canNotConvertUnitTimer added (Lifecycle.cpp:205, 208).
static constexpr int FILE_FORMAT_VERSION_CANNOT_CONVERT_TIMER = 81;

//! USL mapscript serialization (Game_io.cpp:197).
static constexpr int FILE_FORMAT_VERSION_USL_MAPSCRIPT = 82;

//! Drop unit-skin name into the save stream (UnitSerialization.cpp:25).
static constexpr int FILE_FORMAT_VERSION_DROP_UNIT_SKIN_NAME = 84;

//! Live team statistics, smoothing history and sampling positions.
static constexpr int FILE_FORMAT_VERSION_LIVE_TEAM_STATS = 89;

//! Pending building sites waiting for units to clear their footprint.
static constexpr int FILE_FORMAT_VERSION_PENDING_CONSTRUCTION = 90;

//! Saved-game live RNG, occupancy, fog buffers and cached routing fields.
static constexpr int FILE_FORMAT_VERSION_CONTINUATION_STATE = 91;

//! A building's round-trip fields and gradient use stamps join the cached routing fields.
//! The round-trip fields are read and discarded from FILE_FORMAT_VERSION_GREEDY_FETCHING on.
static constexpr int FILE_FORMAT_VERSION_ROUND_TRIP_FIELDS = 95;

//! The map's topology generation and each cached field's generation stamp
//! (MapIO.cpp:350, 410, 451, 514).
static constexpr int FILE_FORMAT_VERSION_TOPOLOGY_GENERATION = 97;

//! Harvest and build became one worker level. Saves before this could hold the
//! two apart — the map editor offered a box for each — so the loader evens a
//! worker out to the higher of the two (UnitSerialization.cpp:90).
static constexpr int FILE_FORMAT_VERSION_ONE_WORKER_LEVEL = 99;

//! Custom-game economy rules: resourceGrowthDisabled, resourceScarcityLevel,
//! instantConstruction, stockpileStartLevel, hungerDisabled (GameHeader.cpp).
static constexpr int FILE_FORMAT_VERSION_ECONOMY_RULES = 102;

//! Custom-game combat rules: unitUpgradesDisabled, glassCannonLevel,
//! unitsFearless, permadeathDisabled, peacefulMode, buildingHpLevel
//! (GameHeader.cpp).
static constexpr int FILE_FORMAT_VERSION_COMBAT_RULES = 103;
//! Diagnostic gameplay measurements; no simulation or protocol change.
static constexpr int FILE_FORMAT_VERSION_GAMEPLAY_STATS = 105;

static constexpr int FILE_FORMAT_VERSION_AI_TELEMETRY = 106;
//! Sampled blockage, health-band and nearby natural growth diagnostics.
static constexpr int FILE_FORMAT_VERSION_EXTENDED_GAMEPLAY_STATS = 108;

//! The optional win-probability win condition. No new GameHeader field: the
//! condition serialises itself through the existing winning-condition list, so a
//! save only carries the new tag when a player enabled the rule. Older saves load
//! unchanged, and MINIMUM_VERSION_MINOR does not move.
static constexpr int FILE_FORMAT_VERSION_WIN_PROBABILITY_RULE = 131;

// === Save-file section signatures (4-byte ASCII tags) ===
// Embedded as four chars at the start of each save section so a corrupted
// stream fails fast. NEVER change these values — old saves on disk depend
// on them.

//! Length in bytes of every section signature above.
static constexpr int FILE_SIG_LEN = 4;

//! Top-level "Game Begin" sig (Game_io.cpp:128, 415).
inline constexpr const char FILE_SIG_GAME_BEGIN[5]   = "GaBe";
//! "Game Sync" — pre-step state (Game_io.cpp:141, 428).
inline constexpr const char FILE_SIG_GAME_SYNC[5]    = "GaSy";
//! "Game Built" — post-construction marker for unified-seed saves
//! (Game_io.cpp:146).
inline constexpr const char FILE_SIG_GAME_BUILT[5]   = "GaBt";
//! "Game Team" sig (Game_io.cpp:160, 435).
inline constexpr const char FILE_SIG_GAME_TEAM[5]    = "GaTe";
//! "Game Map" sig (Game_io.cpp:167, 446).
inline constexpr const char FILE_SIG_GAME_MAP[5]     = "GaMa";
//! "Game Player" sig (Game_io.cpp:180).
inline constexpr const char FILE_SIG_GAME_PLAYER[5]  = "GaPl";
//! Player section "begin" sig (Player.cpp:107).
inline constexpr const char FILE_SIG_PLAYER_BEGIN[5] = "PLYb";
//! Player section "end" sig (Player.cpp:152).
inline constexpr const char FILE_SIG_PLAYER_END[5]   = "PLYe";
//! Game checksum sidecar v1 magic (ChecksumSidecar.cpp:41).
inline constexpr const char FILE_SIG_CHECKSUM_SIDECAR[5] = "GCS1";

//! SHA-1 hash byte length, used by the checksum sidecar (Game_io.cpp:459-461).
static constexpr int SHA1_BYTE_LEN = 20;

//! Unit clearing/idle state, building service state and ordered team/unit lists.
static constexpr int FILE_FORMAT_VERSION_SIMULATION_CONTINUATION = 113;

//! Team cooldown that temporarily blocks new construction orders.
static constexpr int FILE_FORMAT_VERSION_CONSTRUCTION_COOLDOWN = 114;

//! Shared AI runtime gradient fields, queued refreshes and construction scheduling.
static constexpr int FILE_FORMAT_VERSION_SHARED_RUNTIME_CONTINUATION = 119;

//! Each shared-runtime controller stores its own gradient manager.
static constexpr int FILE_FORMAT_VERSION_SHARED_RUNTIME_PRIVATE_GRADIENTS = 122;

// Completed private fields and remaining fixed publication deadlines.
static constexpr int FILE_FORMAT_VERSION_GRADIENT_PIPELINE = 120;

//! The experiments list in GameHeader (ExperimentalFeatures.h). The default
//! simulation is unchanged; only a game that carries an experiment differs.
static constexpr int FILE_FORMAT_VERSION_EXPERIMENTS = 124;

//! JavaScript AI/map state and per-entity identities with generation counters.
//! Version 124 remains the released experiments layout without these fields.
static constexpr int FILE_FORMAT_VERSION_JAVASCRIPT = 125;

//! Counted team-dependent state: Maxima opponents and JavaScript generation planes.
static constexpr int FILE_FORMAT_VERSION_COUNTED_TEAM_STATE = 127;

//! Lossless packed arrays and histories; existing save readers remain supported.
static constexpr int FILE_FORMAT_VERSION_COMPACT_STATE = 128;

//! Custom AI profile 2, named telemetry and replay diagnostic trailers.
static constexpr int FILE_FORMAT_VERSION_CUSTOM_AI = 129;

//! Tile::farmArea joins the per-tile area masks in the map section (MapIO.cpp),
//! for the farm-areas experiment. Older maps and saves load with no farm painted.
static constexpr int FILE_FORMAT_VERSION_FARM_AREA = 130;

//! Worker time use, combat-death place and assignment, and the defence snapshot in
//! gameplay measurements (diagnostic only; older saves start them at load).
static constexpr int FILE_FORMAT_VERSION_LABOUR_STATS = 133;

//! Canonical terrain identities, terrain experiment requirements and exposure state.
static constexpr int FILE_FORMAT_VERSION_TERRAIN_PROPERTIES = 134;

//! Optional market resource fields and their scheduling/publication state.
static constexpr int FILE_FORMAT_VERSION_MARKET_GRADIENTS = 135;

//! Immutable map-owned custom terrain definitions.
static constexpr int FILE_FORMAT_VERSION_RUNTIME_TERRAIN = 136;

//! Per-game immutable building specifications and capability state.
static constexpr int FILE_FORMAT_VERSION_BUILDING_CATALOG = 137;

//! The map's terrain look seed (Map::terrainSeed), presentation only.
static constexpr int FILE_FORMAT_VERSION_TERRAIN_SEED = 138;

//! Runtime map resources, fixed material inventory, and independent material stocks.
static constexpr int FILE_FORMAT_VERSION_RUNTIME_RESOURCES = 140;

//! Built-in terrain catalogue: TERRAIN_COUNT grew from 7 to 31, so earlier files
//! carry custom terrain IDs starting at 7 that the loader renumbers.
static constexpr int FILE_FORMAT_VERSION_TERRAIN_CATALOGUE = 141;

//! Hazard-weighted routing fields; older cached fields must be rebuilt.
static constexpr int FILE_FORMAT_VERSION_HAZARD_ROUTING = 142;

//! Shared AI scheduling and pending command execution state.
static constexpr int FILE_FORMAT_VERSION_AI_PIPELINE = 143;

// Historical growth-draft gates below overlap released artwork/terrain versions.
// Resolve the save lineage before using these gates; integrated saves start at 149.
// Immutable growth batches and per-deposit incarnation counters.
static constexpr int FILE_FORMAT_VERSION_RESOURCE_GROWTH = 144;

// Compact signed resource deltas; no per-cell incarnation plane.
static constexpr int FILE_FORMAT_VERSION_SIMPLE_RESOURCE_GROWTH = 145;
//! Map-owned custom artwork and attribution.
static constexpr int FILE_FORMAT_VERSION_MAP_ASSETS = 144;

// Combined artwork and compact growth. Formats 144/145 predate integration.
static constexpr int FILE_FORMAT_VERSION_ASSETS_AND_RESOURCE_GROWTH = 146;
//! Portable, content-addressed building sprite frames in maps, saves and replays.
static constexpr int FILE_FORMAT_VERSION_BUILDING_ARTWORK = 145;

//! Terrain is stored once per map vertex; cells derive their rules from their
//! four corners. Earlier files carry an undermap, per-cell sprites and (from 134)
//! per-cell terrain IDs, converted to vertices on load. The two shore types are
//! retired and the catalogue IDs behind TRAIL move down by two.
static constexpr int FILE_FORMAT_VERSION_VERTEX_TERRAIN = 146;

//! Resource fetching is greedy only: buildings save their walking fields' last-use
//! steps without the retired round-trip fields that formats 95-146 carried.
static constexpr int FILE_FORMAT_VERSION_GREEDY_FETCHING = 147;

//! Scheduled building gradients: the match-wide delay (GameHeader::buildingGradientDelay)
//! and the pending building gradient pipeline state.
static constexpr int FILE_FORMAT_VERSION_BUILDING_GRADIENT_PIPELINE = 148;
// Building artwork and both resource-growth save lineages.
static constexpr int FILE_FORMAT_VERSION_ALL_ARTWORK_AND_RESOURCE_GROWTH = 147;

// Typed delayed growth proposals preserve configured seed stocks and variety.
static constexpr int FILE_FORMAT_VERSION_CONFIGURED_GROWTH_SEEDS = 148;

//! Integrated vertex terrain, scheduled building gradients and delayed resource growth.
static constexpr int FILE_FORMAT_VERSION_INTEGRATED_RESOURCE_GROWTH = 149;

//! Building area-effect funding and fractional pulse services.
static constexpr int FILE_FORMAT_VERSION_AREA_EFFECTS = 150;

//! Salted, persistent private PCG32 streams for units and buildings.
static constexpr int FILE_FORMAT_VERSION_ENTITY_RANDOM = 151;
//! Private PCG32 streams for map operations and legacy stories.
static constexpr int FILE_FORMAT_VERSION_PRIVATE_RANDOM = 152;

//! Immutable unit catalogs, counted race tables and composable unit state.
static constexpr int FILE_FORMAT_VERSION_UNIT_CATALOG = 153;
