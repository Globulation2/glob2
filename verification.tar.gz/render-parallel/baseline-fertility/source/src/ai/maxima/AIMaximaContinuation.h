#ifndef AI_MAXIMA_CONTINUATION_H
#define AI_MAXIMA_CONTINUATION_H

// Portable field-wise serialization for Maxima execution state.
// Never serialize object layouts, pointers, padding, or host-sized containers.
#include "AIMaximaDistanceField.h"
#include "Version.h"
#include <Stream.h>
#include <BinaryStream.h>
#include <PackedArray.h>
#include <bit>
#include <cstring>
#include <algorithm>
#include <cstdint>
#include <map>
#include <limits>
#include <set>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>

namespace AIMaximaContinuation
{
class Writer;
class Reader;
template<class A,class X,class Y> void fields(A& a,std::pair<X,Y>& v)
{ a("first",v.first); a("second",v.second); }

// Run the existing field descriptions into a bounded
// binary byte buffer. A root Writer call flushes before returning, preserving
// interleaved writes made directly to the original stream by its callers.
class BufferedBinaryWriter
{
    GAGCore::BinaryOutputStream* stream;
    unsigned char bytes[16384];
    size_t used=0;
    void word(uint32_t x)
    {
        if(used+4>sizeof(bytes)) flush();
        bytes[used++]=x>>24;bytes[used++]=x>>16;
        bytes[used++]=x>>8;bytes[used++]=x;
    }
    void raw(const char* data,size_t length)
    {
        while(length)
        {
            const size_t n=std::min(length,sizeof(bytes)-used);
            std::memcpy(bytes+used,data,n);used+=n;data+=n;length-=n;
            if(used==sizeof(bytes))flush();
        }
    }
public:
    explicit BufferedBinaryWriter(GAGCore::BinaryOutputStream* s):stream(s) {}
    int version() const { return VERSION_MINOR; }
    void flush() {if(used){stream->write(bytes,used,"");used=0;}}
    template<class T> typename std::enable_if<std::is_integral<T>::value || std::is_enum<T>::value>::type
    operator()(const char*,const T& value)
    {
        const uint64_t bits=static_cast<uint64_t>(value);
        word(uint32_t(bits));
        if constexpr(sizeof(T)>4)word(uint32_t(bits>>32));
    }
    void index(const char* name,const size_t& value)
    {const uint64_t portable=value;(*this)(name,portable);}
    void operator()(const char*,const std::string& value)
    {word(uint32_t(value.size()));raw(value.data(),value.size());}
    template<class T,size_t N> void operator()(const char*,const T (&value)[N])
    {for(size_t i=0;i<N;++i)(*this)("value",value[i]);}
    template<class T> void operator()(const char*,const std::vector<T>& value)
    {
        word(uint32_t(value.size()));
        if constexpr ((std::is_integral<T>::value || std::is_enum<T>::value) && sizeof(T)<=8)
        {
            constexpr size_t stride=sizeof(T)>4?8:4;
            for(size_t off=0;off<value.size();)
            {
                if(sizeof(bytes)-used<stride)flush();
                const size_t n=std::min(value.size()-off,(sizeof(bytes)-used)/stride);
                for(size_t i=0;i<n;++i)
                {
                    const uint64_t x=static_cast<uint64_t>(value[off+i]);
                    unsigned char* out=bytes+used+i*stride;
                    out[0]=x>>24;out[1]=x>>16;out[2]=x>>8;out[3]=x;
                    if constexpr(sizeof(T)>4)
                    {out[4]=x>>56;out[5]=x>>48;out[6]=x>>40;out[7]=x>>32;}
                }
                used+=n*stride;off+=n;
            }
        }
        else for(size_t i=0;i<value.size();++i)(*this)("value",value[i]);
    }
    template<class Wire, class T, class Encode, class Decode>
    void legacyVector(const char*, const std::vector<T>& value, Encode encode, Decode)
    {
        word(uint32_t(value.size()));
        for(const auto& item:value) { const Wire wire=encode(item); (*this)("value",wire); }
    }
    void operator()(const char* name,const AIMaximaPlacement::DistanceField& value)
    {
        legacyVector<int32_t>(name,value.storage(),
            [](uint16_t x){return x==UINT16_MAX?INT_MAX:int(x);},[](int32_t){return uint16_t{};});
    }
    template<class T> void operator()(const char*,const std::set<T>& value)
    {word(uint32_t(value.size()));for(const auto& item:value)(*this)("value",item);}
    template<class K,class V> void operator()(const char*,const std::map<K,V>& value)
    {word(uint32_t(value.size()));for(const auto& item:value){(*this)("key",item.first);(*this)("value",item.second);}}
    template<class T> typename std::enable_if<!std::is_integral<T>::value && !std::is_enum<T>::value>::type
    operator()(const char*,const T& value)
    {fields(*this,const_cast<T&>(value));}
};

// Record overloads live in their type's namespace and are found through ADL.
class Writer
{
    GAGCore::OutputStream* stream;
    bool compact_;
public:
    explicit Writer(GAGCore::OutputStream* stream,bool compact=false):stream(stream),compact_(compact && GAGCore::PackedArray::binary(stream)) {}
    bool compact() const { return compact_; }
    int version() const { return VERSION_MINOR; }
    template<class T> typename std::enable_if<std::is_integral<T>::value || std::is_enum<T>::value>::type
    operator()(const char* name,const T& value)
    {
        if(sizeof(T)>4)
        {
            stream->writeEnterSection(name);
            const uint64_t bits=static_cast<uint64_t>(value);
            stream->writeUint32(uint32_t(bits),"low");
            stream->writeUint32(uint32_t(bits>>32),"high");
            stream->writeLeaveSection();
        }
        else if(std::is_signed<T>::value || std::is_enum<T>::value)
            stream->writeSint32(static_cast<int32_t>(value),name);
        else stream->writeUint32(static_cast<uint32_t>(value),name);
    }
    void index(const char* name,const size_t& value)
    { const uint64_t portable=value; (*this)(name,portable); }
    void operator()(const char* name,const std::string& value) { stream->writeText(value,name); }
    template<class T,size_t N> void operator()(const char* name,const T (&value)[N])
    {
        // The legacy buffered writer expands narrow fields to their old widths.
        // Compact streams must traverse fields here so nested arrays are packed.
        if (!compact_)
        {
            if (auto* binary = dynamic_cast<GAGCore::BinaryOutputStream*>(stream))
            {
                BufferedBinaryWriter packed(binary);
                packed(name, value);
                packed.flush();
                return;
            }
        }
        stream->writeEnterSection(name);
        for(size_t i=0;i<N;++i) { stream->writeEnterSection(i); (*this)("value",value[i]); stream->writeLeaveSection(); }
        stream->writeLeaveSection();
    }
    template<class Wire, class T, class Encode, class Decode>
    void legacyVector(const char* name,const std::vector<T>& value,Encode encode,Decode decode)
    {
        if(compact_) { (*this)(name,value); return; }
        if (auto* binary = dynamic_cast<GAGCore::BinaryOutputStream*>(stream))
        {
            BufferedBinaryWriter packed(binary);
            packed.legacyVector<Wire>(name, value, encode, decode);
            packed.flush();
            return;
        }
        stream->writeEnterSection(name); stream->writeUint32(value.size(),"size");
        for(size_t i=0;i<value.size();++i)
        { stream->writeEnterSection(i); const Wire wire=encode(value[i]); (*this)("value",wire); stream->writeLeaveSection(); }
        stream->writeLeaveSection();
    }
    void operator()(const char* name,const AIMaximaPlacement::DistanceField& value)
    {
        if(compact_) { (*this)(name,value.storage()); return; }
        legacyVector<int32_t>(name,value.storage(),
            [](uint16_t x){return x==UINT16_MAX?INT_MAX:int(x);},[](int32_t){return uint16_t{};});
    }
    template<class T> void operator()(const char* name,const std::vector<T>& value)
    {
        if constexpr(std::is_integral_v<T>)
            if(compact_)
            {
                using U=std::conditional_t<sizeof(T)==1,Uint8,std::conditional_t<sizeof(T)==2,Uint16,std::conditional_t<sizeof(T)==4,Uint32,Uint64>>>;
                stream->writeUint32(value.size(),"size");
                GAGCore::PackedArray::write<U>(stream,value.size(),[&](size_t i){return U(value[i]);});
                return;
            }
        // The legacy buffered writer expands narrow fields to their old widths.
        // Compact streams must traverse fields here so nested arrays are packed.
        if (!compact_)
        {
            if (auto* binary = dynamic_cast<GAGCore::BinaryOutputStream*>(stream))
            {
                BufferedBinaryWriter packed(binary);
                packed(name, value);
                packed.flush();
                return;
            }
        }
        stream->writeEnterSection(name); stream->writeUint32(value.size(),"size");
        for(size_t i=0;i<value.size();++i) { stream->writeEnterSection(i); (*this)("value",value[i]); stream->writeLeaveSection(); }
        stream->writeLeaveSection();
    }
    template<class T> void operator()(const char* name,const std::set<T>& value)
    { (*this)(name,std::vector<T>(value.begin(),value.end())); }
    template<class K,class V> void operator()(const char* name,const std::map<K,V>& value)
    {
        stream->writeEnterSection(name); stream->writeUint32(value.size(),"size");
        size_t i=0;
        for(const auto& item:value)
        { stream->writeEnterSection(i++); (*this)("key",item.first); (*this)("value",item.second); stream->writeLeaveSection(); }
        stream->writeLeaveSection();
    }
    template<class T> typename std::enable_if<!std::is_integral<T>::value && !std::is_enum<T>::value>::type
    operator()(const char* name,const T& value)
    {
        // The legacy buffered writer expands narrow fields to their old widths.
        // Compact streams must traverse fields here so nested arrays are packed.
        if (!compact_)
        {
            if (auto* binary = dynamic_cast<GAGCore::BinaryOutputStream*>(stream))
            {
                BufferedBinaryWriter packed(binary);
                packed(name, value);
                packed.flush();
                return;
            }
        }
        stream->writeEnterSection(name);
        // fields() is shared with Reader; Writer's operators never modify data.
        fields(*this,const_cast<T&>(value));
        stream->writeLeaveSection();
    }
};
class Reader
{
    GAGCore::InputStream* stream;
    int version_;
    bool compact_;
    uint32_t count()
    {
        // Canonical nine-neighbor tables exceed the generic one-million limit
        // on 512x512 maps. Keep Maxima's explicit existing collection bound.
        const uint32_t size=stream->readCount("size", 16777216u);
        if(size>16777216u) throw std::runtime_error("Invalid Maxima continuation container size");
        return size;
    }
public:
    explicit Reader(GAGCore::InputStream* stream,bool compact=false,int version=VERSION_MINOR):stream(stream),version_(version),compact_(compact && GAGCore::PackedArray::binary(stream)) {}
    int version() const { return version_; }
    bool compact() const { return compact_; }
    template<class T> typename std::enable_if<std::is_integral<T>::value || std::is_enum<T>::value>::type
    operator()(const char* name,T& value)
    {
        if(sizeof(T)>4)
        {
            stream->readEnterSection(name);
            const uint64_t low=stream->readUint32("low");
            const uint64_t high=stream->readUint32("high");
            value=static_cast<T>(low|(high<<32));
            stream->readLeaveSection();
        }
        else if(std::is_signed<T>::value || std::is_enum<T>::value)
            value=static_cast<T>(stream->readSint32(name));
        else value=static_cast<T>(stream->readUint32(name));
    }
    void index(const char* name,size_t& value)
    {
        uint64_t portable=0; (*this)(name,portable);
        if(portable>std::numeric_limits<size_t>::max()) throw std::runtime_error("Continuation index overflow");
        value=static_cast<size_t>(portable);
    }
    void operator()(const char* name,std::string& value) { value=stream->readText(name); }
    template<class T,size_t N> void operator()(const char* name,T (&value)[N])
    {
        stream->readEnterSection(name);
        for(size_t i=0;i<N;++i) { stream->readEnterSection(i); (*this)("value",value[i]); stream->readLeaveSection(); }
        stream->readLeaveSection();
    }
    template<class Wire, class T, class Encode, class Decode>
    void legacyVector(const char* name,std::vector<T>& value,Encode,Decode decode)
    {
        if(compact_) { (*this)(name,value); return; }
        stream->readEnterSection(name); value.clear(); value.resize(count());
        for(size_t i=0;i<value.size();++i)
        { stream->readEnterSection(i); Wire wire{}; (*this)("value",wire); value[i]=decode(wire); stream->readLeaveSection(); }
        stream->readLeaveSection();
    }
    void operator()(const char* name,AIMaximaPlacement::DistanceField& value)
    {
        if(compact_) { (*this)(name,value.storage()); return; }
        legacyVector<int32_t>(name,value.storage(),[](uint16_t){return int32_t{};},
            [](int32_t x){
                if(x==INT_MAX) return uint16_t(UINT16_MAX);
                if(x<0 || x>=UINT16_MAX) throw std::runtime_error("Invalid compact distance");
                return uint16_t(x);
            });
    }
    template<class T> void operator()(const char* name,std::vector<T>& value)
    {
        if constexpr(std::is_integral_v<T>)
            if(compact_)
            {
                using U=std::conditional_t<sizeof(T)==1,Uint8,std::conditional_t<sizeof(T)==2,Uint16,std::conditional_t<sizeof(T)==4,Uint32,Uint64>>>;
                value.clear(); value.resize(count());
                GAGCore::PackedArray::read<U>(stream,value.size(),[&](size_t i,U v){
                    if constexpr(std::is_same_v<T,bool>) { if(v>1) GAGCore::PackedArray::fail(); value[i]=v; }
                    else value[i]=std::bit_cast<T>(v);
                });
                return;
            }
        stream->readEnterSection(name); value.clear(); value.resize(count());
        for(size_t i=0;i<value.size();++i) { stream->readEnterSection(i); (*this)("value",value[i]); stream->readLeaveSection(); }
        stream->readLeaveSection();
    }
    template<class T> void operator()(const char* name,std::set<T>& value)
    {
        std::vector<T> entries; (*this)(name,entries); value.clear();
        for(const auto& entry:entries) if(!value.insert(entry).second) throw std::runtime_error("Duplicate continuation set entry");
    }
    template<class K,class V> void operator()(const char* name,std::map<K,V>& value)
    {
        stream->readEnterSection(name); const uint32_t size=count(); value.clear();
        for(uint32_t i=0;i<size;++i)
        {
            stream->readEnterSection(i); K key{}; V item{};
            (*this)("key",key); (*this)("value",item);
            if(!value.emplace(key,item).second) throw std::runtime_error("Duplicate continuation map entry");
            stream->readLeaveSection();
        }
        stream->readLeaveSection();
    }
    template<class T> typename std::enable_if<!std::is_integral<T>::value && !std::is_enum<T>::value>::type
    operator()(const char* name,T& value)
    { stream->readEnterSection(name); fields(*this,value); stream->readLeaveSection(); }
};
}
#endif
