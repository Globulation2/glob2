/*
  Deterministic development and placement planner used only by Maxima.

  The planner deliberately consumes a plain grid snapshot.  Keeping the engine
  adapter in AIMaxima.cpp makes geometry, routing, utility and persistence
  independently testable and prevents another shared-AI dependency.
 */

#ifndef AI_MAXIMA_PLACEMENT_H
#define AI_MAXIMA_PLACEMENT_H

#include "Material.h"
#include "AIMaximaOperatingDemand.h"
#include "field/Frontier.h"
#include "AIMaximaFoodLedger.h"
#include "AIMaximaBuildingRoles.h"
#include "AIMaximaDistanceField.h"
#include <memory>

#include <stdint.h>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace GAGCore
{
	class InputStream;
	class OutputStream;
}

namespace AIMaximaPlacement
{

enum DevelopmentActionType
{
	BuildCampusMember,
	BuildStandalone,
	UpgradeBuilding,
	RepairBuilding
};

enum DevelopmentPurpose
{
	CoreCapacity,
	ColonySeed,
	/// Build a replacement for an existing inn or swarm at a better site; the
	/// executor destroys the old one once the replacement is completed.
	Relocation,
	/// Spend spare construction capacity only after ordinary development.
	Fortification
};

// Catalog-generated identities exceed the named styles; preserve the signed
// 32-bit representation used by planner persistence, including sentinel bits.
enum TemplateId : int32_t
{
	NoTemplate=0,
	InnCompact,
	InnExpandable,
	HospitalCompact,
	HospitalDispersed,
	SchoolProtectedCampus,
	StandaloneReserved,
	BarracksDefended,
	TowerDefended
};

enum ActionLifecycleState
{
	QueuedIntent,
	ParcelReserved,
	CreateIssued,
	SiteObserved,
	Completed,
	InvalidatedBeforeIssue,
	CreateTimedOut,
	DestroyedDuringConstruction,
	UpgradeBlocked,
	RequiredSourceMissing,
	EngineRejected
};

enum RejectionReason
{
	RejectedUndiscovered,
	RejectedTerrain,
	RejectedBuilding,
	RejectedPermanentResource,
	RejectedClearableResource,
	RejectedReservation,
	RejectedCirculation,
	RejectedWaterTier,
	RejectedAccess,
	RejectedIslandBuilders,
	RejectedQuarantine,
	RejectedUpgradeContract,
	RejectedRequiredSource,
	RejectedColonyDistance,
	RejectedColonyCorn,
	RejectedColonyThreat,
	RejectedNegativeUtility,
	RejectedAuthorization,
	/// No unclaimed protected farm capacity backs this inn or swarm.
	RejectedFoodCapacity,
	RejectionReasonCount
};

struct Footprint
{
	Footprint();
	Footprint(int left, int top, int width, int height);
	int left;
	int top;
	int width;
	int height;
	int area() const;
	bool empty() const;
};

struct TileMask
{
	TileMask();
	TileMask(int width, int height);
	void reset(int width, int height);
	bool get(int x, int y) const;
	void set(int x, int y, bool value=true);
	int count() const;
	int width;
	int height;
	std::vector<uint8_t> cells;
};

struct PlannedSlot
{
	PlannedSlot();
	int index;
	int centerX;
	int centerY;
	int initialLevel;
	int maximumLevel;
	Footprint initialFootprint;
	Footprint terminalFootprint;
};

struct DevelopmentTemplate
{
	DevelopmentTemplate();
	TemplateId id;
	TemplateId style;
	int buildingType;
	std::vector<PlannedSlot> slots;
	Footprint parcel;
	TileMask accessRing;
	bool compact;
};

struct CampusSlotState
{
	CampusSlotState();
	int buildingId;
	int actionId;
	int currentLevel;
	bool unusable;
};

struct Campus
{
	Campus();
	int id;
	TemplateId templateId;
	int originX;
	int originY;
	std::vector<CampusSlotState> slots;
	bool fallbackWaterTier;
};

struct BuildingLevelProfile
{
	BuildingLevelProfile();
	int level;
	int engineType;
	Footprint footprint;
	int constructionMaterials[MaterialCount];
	int completedType=-1;
	unsigned roles=0;
	int serviceRates[AIMaximaBuildings::RoleCount]{};
	unsigned productionUnitMask=0;
	int productionRates[3]{};
	int operatingMaterials[MaterialCount]{}; // recurring carried packets, FoodLedger::RateScale per tick
	int feedingRate=0; // visits per tick, FoodLedger::RateScale
    unsigned feedingMask=0;
    std::vector<Uint8> feedingRecipients;
    int feedingMaterials[MaterialCount]{};
    int operatingAssignmentLimit=1024;
    int initialCarriers=-1; // -1 only for legacy/planner-only unknown staffing
    int productionDemandPercent=100;
    AIMaxima::ProductionRecipeModel productionRecipes;
    int independentMaterials[MaterialCount]{};
    int productionMaterials[MaterialCount]{}; // mechanical production-only packet ceiling // component already included in operatingMaterials
	int seats=0;
	int assignmentLimit=20;
	int requiredWorkerLevel=0;
	bool foodRetirable=true; // false for independent services outside bounded policy roles
	bool repairable=true;
	bool available=true;
	int serviceThroughput;
	int durability;
	int capability;
};

struct BuildingProfile
{
	BuildingProfile();
	int buildingType;
	std::vector<BuildingLevelProfile> levels;
	const BuildingLevelProfile* atLevel(int level) const;
	int maximumLevel() const;
	Footprint envelope(int throughLevel) const;
};

struct WorldTile
{
	WorldTile();
	bool discovered;
	bool foodTraversable;
	bool buildable;
	bool swimmable;
	bool growthInhibiting;
	bool walkable;
	bool fertilitySource;
	bool canWalk() const { return walkable && !swimmable; }
	bool canTravel(bool swim) const { return canWalk() || (swim && swimmable); }
	bool permanentResource;
	/// Renewable seed or harvest outlet reserved against new construction.
	bool woodReserve;
	bool blocksConstruction() const { return permanentResource || woodReserve; }
	bool clearableResource;
    bool resourceBlocksGround=false;
	bool occupied;
	bool ownOccupied;
	// Selected material slot and its stock; -1 denotes no selected supply.
	// These in-memory widths are independent of the legacy serialized widths.
	int16_t materialType;
	uint32_t materialAmount;
    MaterialMask materialSources=0;
    MaterialMask sources() const { return materialSources ? materialSources : materialType>=0 && materialType<MaterialCount ? MaterialMask(1u<<materialType) : 0; }
	uint32_t fertility;
	uint32_t farmCapacity;
	uint32_t foodOpportunity;
	/// Equilibrium wheat supply of a protected cell that currently carries
	/// wheat, in micro-wheat per tick. Unprotected wheat is harvested away
	/// rather than kept, so it is deliberately not standing supply here.
	uint32_t protectedYield;
	int threat;
	int protectedness;
	int conqueredOpportunity;
};

struct WorldBuilding
{
	WorldBuilding();
    int plannedCarriers=-1;
    int productionRatios[3]{1,1,1};
	int id;
	int gid;
	int buildingType;
	int level;
	int centerX;
	int centerY;
	int hp;
	int hpMax;
	int age;
	bool site;
	bool upgrading;
};

struct FeedingColony
{
    int x=0,y=0;
    std::vector<int> demand{0,0,0}; // recipient-class meals/tick, FoodLedger::RateScale
};

struct WorldState
{
	WorldState();
	void reset(int width, int height);
	int normalizeX(int x) const;
	int normalizeY(int y) const;
	int index(int x, int y) const;
	int wrappedManhattan(int ax, int ay, int bx, int by) const;
	const WorldTile& tile(int x, int y) const;
	WorldTile& tile(int x, int y);
	const BuildingProfile* profile(int buildingType) const;
	void invalidateProfileIndex() const;
    uint64_t retainedProfileIndexBytes() const noexcept { return profileIndexes.capacity() * sizeof(int); }
	const WorldBuilding* building(int id) const;
	uint32_t computeSignature() const;

	int width;
	int height;
	int tick;
	int swimmingBuilders;
	int accessibleSupplies[MaterialCount];
    std::vector<FeedingColony> feedingColonies;
    int feedingColonyAt(int x,int y) const;
	std::vector<WorldTile> tiles;
	std::vector<WorldBuilding> buildings;
	std::vector<BuildingProfile> profiles;
private:
	// Derived per-snapshot lookup. Copying a world changes profiles.data(), so
	// copied caches rebuild before use; deserialization invalidates explicitly.
	mutable const BuildingProfile* indexedProfiles=nullptr;
	mutable size_t indexedProfileCount=0;
	mutable std::vector<int> profileIndexes;
};

struct DevelopmentIntent
{
	DevelopmentIntent();
	int buildingType;
	DevelopmentPurpose purpose;
	int unmetCount;
	int priority;
	int workers;
	int requiredMaterialType;
	bool emergency;
	/// Relocation only: the building this intent replaces.
	int replacesBuildingId;
};

struct DevelopmentLimits
{
	DevelopmentLimits();
	int newConstruction;
	int level1Upgrades;
	int level2Upgrades;
	int activeNewConstruction;
	int activeLevel1Upgrades;
	int activeLevel2Upgrades;
	bool allowUpgrades;
	bool allowLevel2Upgrades;
	bool allowRepairs;
	// Missing entries retain the planner's generic upgrade demand. Zero vetoes
	// the upgrade; positive values supply its director demand score. Level zero
	// is reserved for a repair veto, sharing the existing saved priority map.
	std::map<std::pair<int, int>, int> upgradePriorities;
	int upgradePriority(int buildingType, int fromLevel) const;
	bool repairAllowed(int buildingType) const
	{ return allowRepairs && upgradePriority(buildingType,0)!=0; }
	int totalCapacity() const;
};

struct UtilityComponents
{
	UtilityComponents();
	int unmetDemand;
	int serviceGain;
	int capabilityGain;
	int parallelismGain;
	int redundancyGain;
	int roleLocationQuality;
	int defendedness;
	int compactness;
	int projectedFarmLoss;
	int foodZonePressure;
	int newlyReservedLand;
	int materialScarcity;
	int constructionLabor;
	int serviceDowntime;
	int threatExposure;
	int newArteryLength;
	int frontierGain;
	int conqueredGain;
	int friendlyDistance;
	int cornDistance;
	int total;
};

struct PlacementPolicy
{
	PlacementPolicy();
	bool arteryRoutingEnabled;
	int unmetDemandWeight;
	int serviceGainWeight;
	int capabilityGainWeight;
	int parallelismGainWeight;
	int redundancyGainWeight;
	int roleLocationQualityWeight;
	int defendednessWeight;
	int compactnessWeight;
	int spacingTargetTiles;
	int spacingWeight;
	int projectedFarmLossWeight;
	int foodZonePenaltyWeight;
	int newlyReservedLandWeight;
	int materialScarcityWeight;
	int constructionLaborWeight;
	int serviceDowntimeWeight;
	int threatExposureWeight;
	int newArteryLengthWeight;
	int upgradeLevel1Workers;
	int upgradeLevel2Workers;
	int unmetCountWeight;
	int unmetCountCap;
	int upgradeUnmetDemand;
	int serviceGainScale;
	int capabilityGainScale;
	int parallelServiceBase;
	int parallelBuildBonus;
	int parallelNoService;
	int duplicateFirstScore;
	int duplicateScoreScale;
	int materialDistanceWeight;
	int foodZoneRadius;
	int innerFoodZoneMultiplier;
	int hospitalFoodZoneMultiplier;
	int towerFoodZoneMultiplier;
	int towerCriticalDistanceWeight;
	int towerSpacingTarget;
	int towerSpacingWeight;
	int towerThreatTarget;
	int towerThreatWeight;
	int laborScale;
	int downtimeWorkerScale;
	int arteryLengthScale;
	int repairBaseDemand;
	int actionTimeoutTicks;
	int routeClearableResourceCost;
	int routeFarmCost;
	int routeFertilityCost;
	int colonyMinimumAnchorDistance;
	int colonySupplyRadius;
	int colonyMinimumFood;
	int colonyMinimumValue;
	int colonyMaximumThreat;
	/// Food ledger. Disabled by default so a planner that was never configured
	/// with engine demand rates keeps its previous behavior.
	bool foodLedgerEnabled;
	int foodSupplyRadius;
	/// Unclaimed capacity a new or upgraded food building must reach, as a
	/// percentage of its full-capacity demand.
	int foodMarginPercent;
	int foodQualityBandTiles;
	int foodUnreachablePenaltyTiles;
	/// Full-capacity demand per inn level and for a swarm, in micro-wheat per
	/// tick, as derived from the engine's own building rates.
	int foodInnDemand[3];
	int foodSwarmDemand;
	/// Relocation economics, all in worker-ticks. A relocated building saves
	/// its carriers a shorter round trip per unit of wheat and stops paying the
	/// unreachable penalty for wheat it could not get; it costs every level it
	/// must rebuild, one hauled unit and one build step at a time. The
	/// realisation percentage converts a ledger quality gain into the tiles
	/// carriers actually stop walking, as measured for inn carriers.
	bool relocationEnabled;
	int relocationMinGainTiles;
	int relocationMinCoverageGainPercent;
	int relocationPaybackHorizonTicks;
	int relocationCostMarginPercent;
	int carrierTicksPerTile;
	int carrierFixedTicksPerTrip;
	int builderTicksPerStep;
	int relocationDistanceRealisationPercent;
	int score(const UtilityComponents& components,
		DevelopmentPurpose purpose=CoreCapacity,
		int spacingQuality=100) const;
};

struct DevelopmentAction
{
	DevelopmentAction();
	int id;
	DevelopmentActionType type;
	DevelopmentPurpose purpose;
	ActionLifecycleState state;
	TemplateId templateId;
	int campusId;
	int slotId;
	int buildingId;
	int buildingType;
	int fromLevel;
	int targetLevel;
	int centerX;
	int centerY;
	int workers;
	bool fallbackWaterTier;
	bool requiresSwimmingBuilders;
	int reservationId;
	int issuedTick;
	uint32_t worldSignature;
	Footprint initialFootprint;
	Footprint terminalFootprint;
	std::vector<int> parcelTiles;
	std::vector<int> accessTiles;
	std::vector<int> arteryTiles;
	UtilityComponents utility;
	/// Relocation only: the building this action replaces.
	int replacesBuildingId;
};

struct PlacementDiagnostics
{
	PlacementDiagnostics();
	void clear();
	int candidateCount;
	int strictCandidateCount;
	int fallbackCandidateCount;
	int waterTier;
	int reservationId;
	int selectedActionId;
	int rejected[RejectionReasonCount];
	UtilityComponents selectedUtility;
};

enum SelectionProgress
{
	SelectionPending,
	SelectionFound,
	SelectionEmpty
};

struct Reservation
{
	Reservation();
	int id;
	int campusId;
	int buildingId;
	int actionId;
	std::vector<int> footprintTiles;
	std::vector<int> circulationTiles;
	bool permanent;
};

struct StandaloneContract
{
	StandaloneContract();
	int buildingId;
	int buildingType;
	int centerX;
	int centerY;
	int maximumLevel;
	int reservationId;
	bool preexisting;
};

class Planner
{
public:
	Planner();
    uint64_t retainedQueryVectorBytes() const noexcept;
	void reset();
	void configure(const std::vector<BuildingProfile>& profiles,
		int innType, int hospitalType, int schoolType,
		int barracksType, int towerType, int swarmType=0);
	const std::vector<DevelopmentTemplate>& templates() const { return templateList; }
	bool validateTemplates(std::string* error=NULL) const;

	void adoptStartingBuildings(const WorldState& world);
	void observe(const WorldState& world);
	void observe(const WorldState& world, uint32_t occupancySignature);
	bool selectAction(const WorldState& world,
		const std::vector<DevelopmentIntent>& intents,
		const DevelopmentLimits& limits, DevelopmentAction& selected);
	bool selectAction(const WorldState& world,
		const std::vector<DevelopmentIntent>& intents,
		const DevelopmentLimits& limits, DevelopmentAction& selected,
		uint32_t occupancySignature);
	///Continue one deterministic selection using at most originBudget candidate
	///origins. The first call snapshots every input; later calls retain the
	///same candidate ordering and scoring caches until a winner is finalized.
	SelectionProgress selectActionIncremental(const WorldState& world,
		const std::vector<DevelopmentIntent>& intents,
		const DevelopmentLimits& limits, DevelopmentAction& selected,
		uint32_t occupancySignature, int originBudget=2048);
	bool selectionPending() const { return incrementalSelectionActive; }
	const WorldState& selectionWorld() const { return incrementalWorld; }
	const std::vector<DevelopmentIntent>& selectionIntents() const
		{ return incrementalIntents; }
	const DevelopmentLimits& selectionLimits() const
		{ return incrementalLimits; }
	uint32_t selectionOccupancySignature() const
		{ return incrementalOccupancySignature; }
	///Validate a finished snapshot selection against current director authority
	///and world state, without rescoring or reserving the selected action.
	bool revalidateSelection(const WorldState& world,
		const std::vector<DevelopmentIntent>& intents,
		const DevelopmentLimits& limits, const DevelopmentAction& action,
		RejectionReason* reason=NULL);
	bool reserve(const WorldState& world, DevelopmentAction& action);
	bool revalidate(const WorldState& world, const DevelopmentAction& action,
		RejectionReason* reason=NULL, bool beforeIssue=false) const;
	void markIssued(int actionId, int buildingId, int tick);
	void markInvalidated(int actionId, ActionLifecycleState state,
		uint32_t signature, int coordinateKey=-1);
	void releaseDestroyedCampuses(const WorldState& world);

	const PlacementPolicy& policy() const { return placementPolicy; }
	PlacementPolicy& mutablePolicy() { return placementPolicy; }
	const PlacementDiagnostics& diagnostics() const { return lastDiagnostics; }
	/// The same record under the name the regressions use: what the last
	/// selection considered, chose, and rejected.
	const PlacementDiagnostics& selectionSummary() const { return lastDiagnostics; }
	uint32_t spatialRevision() const { return footprintReferenceRevision; }
	const std::vector<Campus>& campuses() const { return campusList; }
	const std::vector<StandaloneContract>& standaloneContracts() const { return standaloneList; }
	const std::map<int, Reservation>& reservations() const { return reservationMap; }
	const std::map<int, DevelopmentAction>& actions() const { return actionMap; }
	int committedBuildingCount(const WorldState& world, int buildingType) const;
	int committedRoleCount(const WorldState& world,int role,unsigned productionMask=0) const;
	int activeRoleBuildCount(int role,DevelopmentPurpose purpose) const;
	int activeBuildCount(int buildingType, DevelopmentPurpose purpose) const;
	/// True once a Relocation intent for this building has been scanned to the
	/// end without a single acceptable site, so the executor can stop offering
	/// it instead of waiting out the offer window. Cleared when a replacement
	/// is reserved or the executor nominates the building again.
	bool relocationRefused(int replacesBuildingId) const
	{ return refusedRelocations.count(replacesBuildingId)>0; }
	void clearRelocationRefusal(int replacesBuildingId)
	{ refusedRelocations.erase(replacesBuildingId); }
	/// End the replacement relationship without discarding building contracts or
	/// action history. A later nomination must not follow this attempt again.
	void finishRelocation(int replacesBuildingId);
	const std::vector<unsigned short>& footprintReferences() const { return footprintRefs; }
	const std::vector<unsigned short>& circulationReferences() const { return circulationRefs; }
	bool isFootprintReserved(int index) const;
	bool isCirculationReserved(int index) const;
	uint32_t blockedSignature(int buildingType,
		DevelopmentPurpose purpose=CoreCapacity) const;
	/// Rebuilds and returns the food ledger for this snapshot. Retirement and
	/// the director's targets read the same result the placement checks use.
	/// Economics of replacing `replacesBuildingId` with a building at `action`,
	/// judged with the old building removed from the ledger.
	struct RelocationAppraisal
	{
		RelocationAppraisal();
		bool viable;
		int oldQuality;
		int newQuality;
		int oldCoverage;
		int newCoverage;
		/// Worker-ticks saved per tick, scaled by the ledger's RateScale.
		long long savingPerTick;
		/// Worker-ticks to rebuild, already including the cost margin.
		long long cost;
		long long paybackTicks;
	};
	RelocationAppraisal appraiseRelocation(const WorldState& world,
		const DevelopmentAction& action, int replacesBuildingId) const;
	const AIMaximaFoodLedger::Result& evaluateFoodLedger(
		const WorldState& world) const;

	void save(GAGCore::OutputStream* stream) const;
	void saveExecutionState(GAGCore::OutputStream* stream) const;
	void loadExecutionState(GAGCore::InputStream* stream, int versionMinor);
	bool load(GAGCore::InputStream* stream, int versionMinor);

private:
	template<class Archive> void executionState(Archive& archive);
	struct Candidate;
	static void preferUpgrades(std::vector<Candidate>& candidates,
		const std::vector<DevelopmentIntent>& intents);
	void clearIncrementalSelection();
	void buildTemplates();
	const BuildingProfile* configuredProfile(int type) const;
	bool serves(int type,int role,int level=1) const;
	const DevelopmentTemplate* findTemplate(TemplateId id) const;
	std::vector<int> footprintTiles(const WorldState& world, int centerX,
		int centerY, const Footprint& footprint) const;
	std::vector<int> parcelTiles(const WorldState& world, int originX,
		int originY, const DevelopmentTemplate& developmentTemplate) const;
	std::vector<int> parcelRingTiles(const WorldState& world, int originX,
		int originY, const DevelopmentTemplate& developmentTemplate) const;
	std::vector<int> ringTiles(const WorldState& world,
		const std::vector<int>& parcel) const;
	bool legalTiles(const WorldState& world, const std::vector<int>& tiles,
		bool allowClearable, RejectionReason& reason, int ignoredBuildingId=-1,
		int ignoredReservationId=-1) const;
	bool waterTierPasses(const WorldState& world,
		const std::vector<int>& parcel, int minimumDistance) const;
	void prepareWaterDistanceCache(const WorldState& world) const;
	void prepareMaterialSources(const WorldState& world) const;
	void prepareScoringCaches(const WorldState& world) const;
	int materialDistanceAt(const WorldState& world,int materialType,
		int index) const;
	bool requiredSourcePresent(const WorldState& world,
		const DevelopmentIntent& intent) const;
	// Claims include pending food buildings. Revalidation excludes only itself.
	void prepareColonyClaims(const WorldState& world, int excludeAction=-1) const;
	/// Rebuilds the whole food ledger from the snapshot. Nothing about claims is
	/// retained between passes, so destruction, upgrades and farm changes need
	/// no incremental bookkeeping.
	void prepareFoodLedger(const WorldState& world, int excludeAction=-1,
		int excludeBuilding=-1, int candidateType=-1, int candidateLevel=1, int candidateColony=-1) const;
    int prepareFeedingCandidate(const WorldState& world,const DevelopmentAction& action) const;
    void prepareFeedingCandidateSet(const WorldState& world,int type,int level,int excludedAction,int excludedBuilding) const;
    struct CandidateFoodLedger { AIMaximaFoodLedger::Result result; int demand=0,feeding=0; std::array<int,MaterialCount> independent{},production{}; };
    mutable std::vector<CandidateFoodLedger> candidateFoodLedgers;
    mutable int candidateSetType=-1,candidateSetLevel=1,candidateSetExcludedAction=-1,candidateSetExcludedBuilding=-1;
    mutable unsigned foodLedgerEpoch=0,candidateSetEpoch=0;
    mutable const CandidateFoodLedger* activeFoodCandidate=nullptr;
    const AIMaximaFoodLedger::Result& selectedFoodResult() const { return activeFoodCandidate?activeFoodCandidate->result:foodResult; }
	bool relocationCandidatePasses(const WorldState& world,
		const DevelopmentIntent& intent, const DevelopmentAction& action,
		RejectionReason& reason) const;
	bool foodManagedType(int buildingType) const;
	int foodDemandFor(int buildingType, int level) const;
	/// A new inn or swarm must reach its full demand plus the configured margin
	/// in capacity no existing claimant already holds.
	bool foodCandidatePasses(const WorldState& world,
		const DevelopmentIntent* intent, const DevelopmentAction& action,
		RejectionReason& reason) const;
	/// An upgrade is judged on what the building could reach at its new level,
	/// because its own claim is released and retaken by the rebuilt ledger.
	bool foodUpgradePasses(const WorldState& world,
		const DevelopmentAction& action, RejectionReason& reason) const;
	int foodLocationQuality(const WorldState& world,
		const DevelopmentAction& action) const;
	mutable AIMaximaFoodLedger::Ledger foodLedger;
	mutable AIMaximaFoodLedger::Input foodInput;
	mutable AIMaximaFoodLedger::Result foodResult;
    mutable AIMaximaFoodLedger::Result foodServiceBaseline; // only immutable service layer and funded total
    mutable int foodCandidateFeeding=0;
	mutable int foodLedgerExcludedAction;
	mutable int foodLedgerExcludedBuilding;
	mutable bool foodLedgerPrepared;
    mutable int foodCandidateType=-1,foodCandidateLevel=1,foodCandidateColony=-1,foodCandidateDemand=0;
    mutable std::array<int,MaterialCount> foodCandidateIndependent{},foodCandidateProduction{};
    mutable bool foodQueryValid=false;
    mutable unsigned foodQueryEpoch=0;
    mutable std::array<int,12> foodQueryKey{};
    mutable AIMaximaFoodLedger::OperatingQuery foodQuery;
    std::array<int,MaterialCount> operatingTrips(const WorldState& world,int x,int y,
        const std::array<int,MaterialCount>& independent,const std::array<int,MaterialCount>& production) const;
	/// Consumer results of the last ledger that excluded nothing, so an
	/// appraisal can read the old building's standing while the prepared
	/// ledger already excludes it.
	mutable std::vector<AIMaximaFoodLedger::ConsumerResult> foodBaselineConsumers;
	mutable bool foodBaselineValid;
	std::vector<int> colonyFoodTiles(const WorldState& world, int x, int y,
		const Footprint& footprint) const;
	int colonyAnchorDistance(const WorldState& world, int x, int y) const;
	std::pair<int,int> colonyBenefit(const WorldState& world,
		const DevelopmentAction& action) const;
	mutable std::vector<uint8_t> colonyFoodClaims;
	mutable std::vector<std::pair<int,int> > colonyAnchors;
	bool colonyCandidatePasses(const WorldState& world,
		const DevelopmentIntent& intent, const DevelopmentAction& action,
		RejectionReason& reason) const;
	int nearestCompletedBuildingDistance(const WorldState& world,
		int x, int y) const;
	bool routeArtery(const WorldState& world, const std::vector<int>& ring,
		int workers, bool hasNetwork, uint32_t cacheSignature,
		std::vector<int>& route,
		RejectionReason& reason) const;
	void prepareRouteCache(const WorldState& world, int orientation) const;
	void addBuildCandidates(const WorldState& world,
		const DevelopmentIntent& intent, uint32_t stateSignature,
		bool hasNetwork, std::vector<Candidate>& candidates);
	bool addBuildCandidatesRange(const WorldState& world,
		const DevelopmentIntent& intent, uint32_t stateSignature,
		bool hasNetwork, std::vector<Candidate>& candidates,
		size_t& originCursor, size_t originBudget,
		DevelopmentAction& bestStrict, bool& hasStrict, size_t& strictCount,
		DevelopmentAction& bestFallback, bool& hasFallback, size_t& fallbackCount);
	void addUpgradeAndRepairCandidates(const WorldState& world,
		const DevelopmentLimits& limits, std::vector<Candidate>& candidates);
	UtilityComponents scoreCandidate(const WorldState& world,
		const DevelopmentIntent* intent, const Candidate& candidate) const;
	bool candidateBetter(const Candidate& lhs, const Candidate& rhs) const;
	int adjoiningBarracks(const WorldState& world, const DevelopmentAction& action,
		std::vector<int>& sharedEdge, std::vector<int>& neighborFootprint) const;
	bool campusMemberSlot(const DevelopmentTemplate& campus, size_t slotIndex,
		int buildingType, PlannedSlot& slot) const;
	int contractMaximumLevel(int buildingId, int buildingType) const;
	int contractReservationId(int buildingId, int buildingType) const;
	int findCampusIndex(int campusId) const;
	int findStandaloneIndex(int buildingId) const;
	void addReservationReferences(const Reservation& reservation);
	void removeReservation(int reservationId);
	void ensureMaskSize(int size);
	void prepareRetrySignature(const WorldState& world);
	uint32_t retrySignature(const DevelopmentIntent& intent, uint32_t spatialSignature) const;
	uint32_t retryInputSignature;
	void recordBlocked(const std::vector<DevelopmentIntent>& intents,
		uint32_t signature);
	bool incrementalSelectionActive;
	size_t incrementalIntentIndex;
	WorldState incrementalWorld;
	std::vector<DevelopmentIntent> incrementalIntents;
	DevelopmentLimits incrementalLimits;
	uint32_t incrementalSignature;
	uint32_t incrementalOccupancySignature;
	bool incrementalHasNetwork;
	bool incrementalCachesPrepared;
	int incrementalRoutePreparation;
	std::vector<DevelopmentAction> incrementalCandidates;
	size_t incrementalBuildOriginCursor;
	DevelopmentAction incrementalBestStrict;
	DevelopmentAction incrementalBestFallback;
	bool incrementalHasStrict;
	bool incrementalHasFallback;
	size_t incrementalStrictCount;
	size_t incrementalFallbackCount;
	uint32_t stateSignature(const WorldState& world) const;
	uint32_t stateSignature(uint32_t worldSignature) const;

	PlacementPolicy placementPolicy;
	PlacementDiagnostics lastDiagnostics;
	std::vector<BuildingProfile> configuredProfiles;
    std::vector<uint8_t> foodManagedTypes;
	std::vector<int> profileIndexes;
	std::vector<DevelopmentTemplate> templateList;
	std::vector<Campus> campusList;
	std::vector<StandaloneContract> standaloneList;
	std::map<int, Reservation> reservationMap;
	std::map<int, DevelopmentAction> actionMap;
	std::map<std::pair<int, int>, uint32_t> blockedIntentSignatures;
	std::set<int> refusedRelocations;
	std::map<int, uint32_t> coordinateQuarantines;
	std::vector<unsigned short> footprintRefs;
	std::vector<unsigned short> circulationRefs;
	uint32_t circulationReservedTileCount;
	mutable uint32_t routeCacheSignature;
	mutable std::vector<int> routeDistanceCache[2];
	mutable std::vector<int> routeParentCache[2];
	mutable std::vector<uint8_t> waterMaskCache;
	mutable DistanceField waterDistanceCache;
	mutable field::Frontier distanceFrontiers[3]; // transient scratch
	mutable DistanceField footprintDistanceCache;
	mutable uint32_t footprintDistanceCacheSignature;
	mutable std::vector<MaterialMask> materialSourceCache;
	mutable DistanceField materialDistanceCache[MaterialCount];
	mutable bool materialDistanceCacheValid[MaterialCount];
	mutable uint64_t maximumFarmCapacityCache;
	mutable uint64_t maximumFoodOpportunityCache;
	mutable std::vector<uint32_t> foodOpportunitySourceCache;
	mutable std::vector<uint64_t> foodHaloMaximumCache;
	mutable int foodHaloRadiusCache;
	mutable std::vector<int> threatProtectionSourceCache;
	mutable std::vector<int> threatPrefixCache;
	mutable std::vector<int> protectionPrefixCache;
	mutable std::vector<int> buildingDistanceSourceCache;
	mutable DistanceField completedBuildingDistanceCache;
	mutable DistanceField criticalBuildingDistanceCache;
	mutable DistanceField towerBuildingDistanceCache;
	mutable std::map<int,int> completedBuildingCountCache;
	mutable std::vector<uint32_t> scoringReservedGeneration;
	mutable std::vector<uint32_t> scoringAffectedGeneration;
	mutable std::vector<uint8_t> scoringBlockedNeighbors;
	mutable std::shared_ptr<const std::vector<int>> scoringNeighborhoodCache;
	mutable int scoringNeighborhoodWidth;
	mutable int scoringNeighborhoodHeight;
	mutable std::vector<int> scoringReservedScratch;
	mutable std::vector<int> scoringAffectedScratch;
	mutable uint32_t scoringGeneration;
	uint32_t footprintReferenceRevision;
	int configuredInnType;
	int configuredHospitalType;
	int configuredSchoolType;
	int configuredBarracksType;
	int configuredTowerType;
	int configuredSwarmType;
	int nextCampusId;
	int nextReservationId;
	int nextActionId;
};

const char* lifecycleName(ActionLifecycleState state);
const char* rejectionName(RejectionReason reason);

}

#endif
