/*
  Copyright (C) 2006 Bradley Arsenault

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef AIMaxima_h
#define AIMaxima_h

#include "AIMaximaRuntime.h"
#include "AIMaximaDefense.h"
#include "AIMaximaFarming.h"
#include "AIMaximaFeedingDemand.h"
#include "AIMaximaFruit.h"
#include "AIMaximaPlacement.h"
#include "AIMaximaRecon.h"
#include "AIMaximaForceModel.h"
#include "AIMaximaLabour.h"
#include "AIMaximaStaffingControl.h"
#include "AIMaximaStrategy.h"
#include "AIMaximaTactics.h"
#include <map>
#include <set>

namespace GameDiagnostics { struct FieldSink; }

namespace AIMaxima
{

/// Maxima coordinates a shared strategic plan and specialized executors.
class Maxima : public AIImplementation, private AIMaximaRuntime::RuntimeAI
{
public:
	std::shared_ptr<GameDiagnostics::FieldSink> fieldDiagnostics; // session-owned, never serialized
  void captureTelemetry() override;
  std::optional<Uint64> retainedQueryVectorBytes() const override;
  const std::vector<AITelemetry::Field> &telemetrySchema() const override
  {
	  return AITelemetry::schema(7);
  }
	explicit Maxima(Player *player);
	Maxima(GAGCore::InputStream *stream, Player *player, Sint32 versionMinor);
	bool load(GAGCore::InputStream *stream, Player *player, Sint32 versionMinor) override;
	/// Restore the current Maxima state after the runtime has loaded.
	bool loadState(GAGCore::InputStream *stream, Player *player, Sint32 versionMinor);
	void save(GAGCore::OutputStream *stream) override;
	std::shared_ptr<Order> getOrder() override;
    std::shared_ptr<Order> getOrder(const AIEngine::DecisionContext&) override;
    bool supportsObservation() const override {return true;}
	void orderExecutionCompleted(const Order& order, bool accepted) override;
	std::string auditStrategyJson() const;
	std::string canonicalStrategy() const;
	void tick(AIMaximaRuntime::Context& runtime) override;
	void handle_event(AIMaximaRuntime::Context& runtime, const AIMaximaRuntime::RuntimeEvent& event) override;
private:
	AIMaximaRuntime::Context context;
	///Owns strategic cadence and invalidation. Maxima's remaining methods are
	///snapshot collectors and policy modules invoked through this boundary.
	class StrategyDirector
	{
	public:
		StrategyDirector() : initialized(false), dirty(true) {}
		void evaluate(Maxima& owner,
			AIMaximaRuntime::Context& runtime);
		void invalidate() { dirty=true; }
		void committed() { initialized=true; dirty=false; }
		bool initialized;
		bool dirty;
	};
	enum StrategicPosture
	{
		PostureExpand,
		PostureDevelop,
		PostureMobilize,
		PostureCampaign,
		PostureFinish,
		PostureDefend,
		PostureRecover,
		PostureCount
	};

	struct StrategicSnapshot
	{
		StrategicSnapshot();
		int tick;
		int population;
		int workers;
		int free_warriors;
		int explorers;
		int trained_explorers;
		int warriors;
		int trained_workers;
		int trained_workers_level2;
		int trained_warriors;
		int swimming_workers;
		int swimming_explorers;
		int swimming_warriors;
		int amphibious_attack_explorers;
		int free_workers;
		int worker_jobs_open;
		int hungry;
		int critical_food;
		int unserved_food;
        std::vector<int> feeding_demand{0,0,0}; // recurring meals/tick, FoodLedger RateScale
		int need_heal;
		int buildings;
		int building_sites;
		int swarms;
		int completed_swarms;
		int inns;
		int inn_level1;
		int inn_level2;
		int inn_level3;
		int barracks;
		int schools;
		int school_level1;
		int school_level2;
		int school_level3;
		int pools;
		int hospitals;
		int racetracks;
		int towers;
		int own_buildings_under_attack;
		int own_units_under_attack;
		int visible_enemy_warriors;
		int visible_enemy_explorers;
		int visible_enemy_attack_explorers;
		int visible_colony_explorer_threat;
		int visible_colony_threat;
		int alive_enemies;
		int total_hp;
		int attack_power;
		int prestige;
		int enemy_prestige;
		int tower_stone;
		int tower_bullets;
	};

	struct StrategicTrends
	{
		StrategicTrends();
		int population;
		int workers;
		int warriors;
		int food_pressure;
		int colony_pressure;
	};

	///Immutable output of the strategic director for one strategic cadence.
	///Executors consume this value and may only perform tactical validation,
	///geometry, pathfinding, and order issuance.
	struct DirectorPlan
	{
		DirectorPlan();
		int construction_sites;
		int desired_inns;
		int desired_swarms;
		int desired_barracks;
		int desired_schools;
		int desired_pools;
		int desired_racetracks;
		int desired_hospital_beds;
		int desired_towers;
		int swarm_workers;
		int worker_ratio;
		int explorer_ratio;
		int warrior_ratio;
		int desired_explorers;
		int desired_warriors;
		int defense_reserve;
		int attack_flags;
		int attack_units;
		bool allow_upgrades;
		bool allow_level2_upgrades;
		int upgrade_level1_workers;
		int upgrade_level2_workers;
		int upgrade_level1_trained_units_per_slot;
		int upgrade_level2_trained_units_per_slot;
		int upgrade_level1_inn_weight;
		int upgrade_level1_hospital_weight;
		int upgrade_level1_racetrack_weight;
		int upgrade_level1_pool_weight;
		int upgrade_level1_barracks_weight;
		int upgrade_level2_inn_weight;
		int upgrade_level2_hospital_weight;
		int upgrade_level2_racetrack_weight;
		int upgrade_level2_pool_weight;
		int upgrade_level2_barracks_weight;
		int first_prestige_trained_workers;
		int second_prestige_trained_workers;
		int second_prestige_population_min;
		///Food ledger authority. The director decides whether the ledger runs,
		///what coverage counts as a burden and how long one must persist. The
		///executor only measures coverage and issues the retirement order.
		bool food_ledger_enabled;
		bool food_retirement_enabled;
		int food_inn_burden_percent;
		int food_swarm_burden_percent;
		int food_recovered_percent;
		int food_burden_confirm_ticks;
		int food_retirement_cooldown_ticks;
		///Relocation authority: whether the executor may nominate a far or
		///starved inn or swarm for rebuilding elsewhere, how far counts as far,
		///and the cadence. The economics of a candidate site belong to the
		///placement policy, which prices and accepts or refuses the rebuild.
		bool food_relocation_enabled;
		int food_relocation_min_quality_tiles;
		int food_relocation_confirm_ticks;
		int food_relocation_cooldown_ticks;
		int food_relocation_offer_ticks;
		///Reliable seats a completed inn of each level actually serves, already
		///discounted, so the executor never needs the economic model itself.
		int food_inn_seats_level1;
		int food_inn_seats_level2;
		int food_inn_seats_level3;
		///Per-building staffing control. Every inn and swarm regulates its own
		///worker request from its own wheat stock and its actual staffing;
		///there is no colony budget and no apportionment between buildings.
		int staffing_window_samples;
		int staffing_low_permille;
		int staffing_high_permille;
		int staffing_slack;
		int staffing_minimum_workers;
		int staffing_maximum_workers;
		int staffing_cooldown_passes;
		///Workers a newly completed building starts with, before the loop runs.
		int staffing_new_inn_workers;
		int staffing_new_swarm_workers;
		int swarm_supply_radius;
		int attack_clearing_workers;
		bool can_swim;
		bool recovery_active;
		bool food_emergency;
		bool colony_emergency;
		bool colony_swarm_requested;
		int colony_swarm_priority;
		bool explorer_campaign_active;
		int explorer_campaign_flags;
		int explorer_campaign_units_per_flag;
		bool fruit_active;
		int fruit_units_per_flag;
		int fruit_flag_radius;
		bool reactive_defense_enabled;
		int reactive_defense_flag_radius;
		int reactive_defense_move_radius;
		int reactive_defense_move_deadband;
		int reactive_defense_unit_cap;
		int reactive_defense_advantage_min;
		int reactive_defense_advantage_percent;
		bool preemptive_defense_active;
		bool preemptive_amphibious_active;
		int preemptive_effective_zone_max;
		int target_switch_margin;
		int preemptive_recompute_ticks;
		int preemptive_inner_distance;
		int preemptive_band_width;
		int preemptive_path_slack;
		int preemptive_probe_radius;
		int preemptive_cross_section_max;
		int preemptive_zone_radius;
		int preemptive_zone_max;
		bool reconnaissance_suspended;
		int reconnaissance_flag_radius;
		int reconnaissance_review_interval;
		int reconnaissance_economic_watch_revisit;
		std::vector<Recon::MissionObjective> reconnaissance_objectives;
		int farming_normal_interval;
		int farming_urgent_interval;
		bool farming_enabled;
		bool farming_protection_enabled;
		bool farming_maintenance_clearing_enabled;
		bool farming_resource_preserving_circulation_enabled;
		bool farming_wheat_invasion_clearing_enabled;
		bool farming_wood_firebreak_enabled;
		bool farming_proactive_clearing_enabled;
			bool farming_urgent;
			int farming_wood_pressure;
			Uint32 farming_minimum_wood_fertility;
		bool farming_allow_proactive_clearing;
		bool farming_clearing_for_placement;
		int farming_min_workers_for_clearing;
		int farming_clearing_cooldown;
		int farming_clearing_duration;
		int farming_clearing_quota;
		int farming_management_radius;
		int farming_wheat_fertility_min;
		int farming_wood_fertility_base_percent;
		int farming_wood_fertility_pressure_percent;
		int farming_wood_pressure_base;
		int farming_wood_pressure_space_divisor;
		int farming_wood_pressure_supply_divisor;
		int farming_wood_pressure_construction_divisor;
		int farming_wood_pressure_growth_divisor;
		int farming_economic_envelope_radius;
		int priority_inns;
		int priority_swarms;
		int priority_barracks;
		int priority_schools;
		int priority_pools;
		int priority_racetracks;
		int priority_hospitals;
		int priority_towers;
		Tactics::MissionKind tactical_kind;
		int tactical_target_team;
		int tactical_dig_out_team;
		int tactical_target_gid;
		int tactical_target_x;
		int tactical_target_y;
		int tactical_candidate_score;
		int tactical_requested_force;
		int tactical_review_interval;
		bool tactics_enabled;
		int tactical_flag_level;
		int tactical_siege_radius;
		int raid_flag_radius;
		int tactical_stall_ticks;
		bool tactical_quarantine_enabled;
		int tactical_quarantine_ticks;
	};

	enum PolicyKind
	{
		PolicySurvival,
		PolicyGrowth,
		PolicyAccess,
		PolicyTechnology,
		PolicyDefense,
		PolicyOffense,
		PolicyCount
	};

	///A policy bid describes the marginal resources one strategic concern would
	///buy if it controlled the next slice of capacity. The arbiter can combine
	///compatible bids while making conflicts explicit.
	struct PolicyBid
	{
		PolicyBid();
		int utility;
		int construction_sites;
		int desired_inns;
		int desired_swarms;
		int desired_barracks;
		int desired_schools;
		int desired_pools;
		int desired_racetracks;
		int desired_hospital_beds;
		int desired_towers;
		int swarm_workers;
		int worker_ratio;
		int explorer_ratio;
		int warrior_ratio;
		int desired_explorers;
		int desired_warriors;
		int defense_reserve;
		int attack_flags;
		int attack_units;
		bool request_upgrades;
	};

	///A smoothed, map-name-independent model of what this colony can currently
	///support.  These are independent axes rather than an exclusive map mode: a
	///water-heavy start can be food-rich, and a formerly rich colony can become
	///capacity constrained after rapid growth.
	struct EnvironmentModel
	{
		EnvironmentModel();
		int known_tiles;
		int accessible_corn;
		int accessible_corn_fraction; // Remaining Q16 fertility units, 0..65535.
		int accessible_wood;
		int accessible_stone;
		int accessible_algae;
		int buildable_tiles;
		int water_tiles;
		int feeding_capacity;
		int food_headroom;
		int resource_capacity;
		int space_capacity;
		int food_security;
		int abundance;
		int terrain_abundance;
		int connected_abundance;
		int mobility_opportunity;
		int economic_momentum;
		int mobility_constraint;
		int topology_complexity;
		int threat_pressure;
		int confidence;
	};

	///Continuous competing demands used by the allocator.  Several demands may
	///be funded together; postures provide commitment and emergency overrides,
	///not a single global script for the whole economy.
	struct StrategicDemands
	{
		StrategicDemands();
		int survival;
		int food;
		int growth;
		int expansion;
		int access;
		int technology;
		int mobility;
		int military;
		int aggression;
	};

	struct OpponentAssessment
	{
		OpponentAssessment();
		bool alive;
		int visible_warriors;
		int estimated_warriors;
		int last_observed_warriors;
		int visible_explorers;
		int visible_buildings;
		int known_buildings;
		int reachable_buildings;
		int strategic_value;
		int nearest_building;
		int score;
		int last_seen_tick;
		int last_force_seen_tick;
		int last_building_seen_tick;
		int intel_confidence;
	};

	enum CampaignState
	{
		CampaignIdle,
		CampaignPreparing,
		CampaignActive,
		CampaignPaused,
		CampaignRetreating
	};

	struct CampaignPlan
	{
		CampaignPlan();
		CampaignState state;
		int target_team;
		int started_tick;
		int last_progress_tick;
		int last_target_buildings;
		int buildings_destroyed;
		int cooldown_until;
	};

	/// Ephemeral explanation of the most recent tactical authorization pass.
	/// This is deliberately not serialized: it is derived from the same fog-safe
	/// observations as DirectorPlan and exists only for the in-game debug HUD.
	/// Explanation of the most recent offensive plan for the F10 panel and telemetry.
	struct OffenseDiagnostics
	{
		OffenseDiagnostics() { reset(0); }
		void reset(int currentTick);
		int tick;
		std::string gate;
		std::string decision;
		int eligibleWarriors;
		int openTrainingSlots;
		int buildingCandidates;
		int viableBuildings;
		int clusterCandidates;
		int viableClusters;
		int bestScore;
		std::map<std::string, int> rejections;
	};

	struct ClearedEnemySite
	{
		ClearedEnemySite();
		ClearedEnemySite(int siteX, int siteY, int tick);
		int x;
		int y;
		int confirmedTick;
	};

	void evaluate_strategy(AIMaximaRuntime::Context& runtime);
	StrategicSnapshot collect_snapshot(AIMaximaRuntime::Context& runtime);
	void update_trends();
	void update_opponent_models(AIMaximaRuntime::Context& runtime);
	void sample_reconnaissance_forces(AIMaximaRuntime::Context& runtime);
	void update_reconnaissance(AIMaximaRuntime::Context& runtime);
	void remember_cleared_enemy_site(AIMaximaRuntime::Context& runtime,
		const Recon::BuildingSighting& sighting);
	void prune_cleared_enemy_sites();
	void plan_reconnaissance_objectives(AIMaximaRuntime::Context& runtime);
	void update_reconnaissance_missions(AIMaximaRuntime::Context& runtime);
	void remove_reconnaissance_missions(AIMaximaRuntime::Context& runtime,
		const char* reason);
	std::vector<unsigned char> reconnaissance_discovery_map(
		AIMaximaRuntime::Context& runtime) const;
	void initialize_topology_profile(AIMaximaRuntime::Context& runtime);
	void update_environment_model(AIMaximaRuntime::Context& runtime);
	void score_demands();
	void score_postures();
	void select_posture();
	void allocate_resources();
	void build_policy_bids();
	void arbitrate_policy_bids();
	const char* policy_name(PolicyKind policy) const;
	void finalize_director_plan(AIMaximaRuntime::Context& runtime);
	void plan_offense(AIMaximaRuntime::Context& runtime);
	void emit_telemetry(AIMaximaRuntime::Context& runtime, const std::string& event,
		const std::string& fields=std::string()) const;
	void emit_ablation_opportunities(AIMaximaRuntime::Context& runtime) const;
	void emit_director_snapshot(AIMaximaRuntime::Context& runtime) const;
	const char* posture_name(StrategicPosture posture) const;
	bool severe_food_emergency() const;
	bool severe_colony_emergency() const;
	bool explorer_defense_active() const;
	bool explorer_defense_emergency() const;
	bool abundance_surge_active() const;
	bool large_economy_established() const;
	void saveDirector(GAGCore::OutputStream*) const;
	void saveExecutionState(GAGCore::OutputStream*);
	void loadExecutionState(GAGCore::InputStream*, Sint32 versionMinor);
	template<class Archive> void executionState(Archive&);
	bool loadDirector(GAGCore::InputStream*, Sint32 versionMinor);

	StrategicSnapshot snapshot;
	StrategicSnapshot previous_snapshot;
	StrategicTrends trends;
	DirectorPlan budget;
	// Versions 86-88 serialized both derived plans and their blend state.
	DirectorPlan dynamic_plan;
	DirectorPlan classic_plan;
	EnvironmentModel environment;
	StrategicDemands demands;
	PolicyBid policy_bids[PolicyCount];
	OpponentAssessment opponents[Team::MAX_COUNT];
	Recon::Program reconnaissance;
	std::map<int, ForceModel::State> force_beliefs;
	void apply_force_beliefs();
	int last_recon_mission_tick;
	bool reconnaissance_suspended;
	CampaignPlan campaign;
	Tactics::Program tactics;
	Tactics::Mission tactical_mission;
	std::vector<Tactics::Wave> offense_waves;
	std::map<int, Tactics::WaveDelivery> wave_delivery;
	// Four consecutive failures permanently select the streaming controller.
	int failed_waves=0;
	void observe_wave_delivery();
	void fall_back_to_streaming();
	bool control_offense_waves(AIMaximaRuntime::Context& runtime);
	OffenseDiagnostics offense_diagnostics;
	std::vector<ClearedEnemySite> cleared_enemy_sites;
	// Runtime startup latch.
	std::set<int> operating_colonies;
	int last_colony_completed_tick;
	int last_colony_accounted_action_id;
	int established_colonies;
	std::string colony_gate_reason;
	StrategicPosture posture;
	int posture_utilities[PostureCount];
	int posture_since;
	bool director_initialized;
	StrategyDirector director;
	int last_director_telemetry_tick;
	int explorer_threat_until;
	int explorer_colony_threat_until;
	bool large_economy_committed;
	bool topology_initialized;
	int global_water_percent;
	int global_shoreline_density;
	int global_land_components;
	int global_largest_land_percent;
	int global_start_land_percent;
	int global_chokepoint_density;
	int global_water_tiles;
	int global_grass_tiles;
	int global_land_tiles;
	int global_buildable_tiles;
	int global_corn_tiles;
	int global_wood_tiles;
	int global_stone_tiles;
	int global_algae_tiles;
	int global_fruit_tiles;
	int global_terrain_abundance;
	int global_connected_abundance;
	int global_mobility_opportunity;
	// Preserve the current reachability observation until its scheduled refresh.
	int known_algae_units;
	int walk_accessible_algae_units;
	int swim_accessible_algae_units;
	int accessible_algae_units;
	std::map<int, int> attack_flag_targets;
	std::map<int, int> attack_flag_started_ticks;
	std::map<int, std::string> attack_flag_end_reasons;
	std::map<int, int> attack_target_quarantine_until;
	///The immutable, fully resolved strategy used for this match.
	MaximaStrategy strategy;
	///False until ensure_strategy() has resolved `strategy` from the final header.
	bool strategy_resolved;
	///Resolves the strategy from the game's current header and applies it.
	void resolve_strategy(bool announce);
	///Re-resolves once, before the first order or save. A new game constructs
	///its AIs while Game::setGameHeader is still copying the header in, so the
	///constructor may have resolved against the previous header.
	void ensure_strategy();

	///This function is called at the very begginning of the game,
	///to initialize the existing buildings with the right amount of units
	void initialize(AIMaximaRuntime::Context& runtime);

	///Recalculate the sole strategic plan.
	void check_phases(AIMaximaRuntime::Context& runtime);


	///Unified deterministic construction, upgrade and repair selector.
	void development_cycle(AIMaximaRuntime::Context& runtime);
	void configure_development_planner();
	AIMaximaPlacement::WorldState collect_development_world(
		AIMaximaRuntime::Context& runtime, uint32_t* signature=NULL) const;
	const AIMaximaPlacement::BuildingLevelProfile* profile_variant(int root,int position=1) const;
	bool profile_serves(int root,int role,int position=1) const;
	int preferred_profile(int role) const;
	int feeding_capacity(int root,int position) const;
    int feeding_capacity_for_type(int concreteType) const;
    int aggregate_feeding_capacity(const std::vector<long long>& rates) const;
    long long recipient_meal_rate(const AIEngine::UnitView& unit) const;
    long long base_recipient_meal_rate(unsigned unit) const;
    long long birth_food_acreage() const;
	const std::vector<AIMaximaPlacement::BuildingProfile>&
		collect_building_profiles() const;
	std::vector<AIMaximaPlacement::DevelopmentIntent>
		collect_development_intents(
			const AIMaximaPlacement::WorldState& world) const;
	int committed_hospital_beds(
		const std::vector<AIMaximaPlacement::WorldBuilding>& buildings,
		int excludedAction=-1) const;
	// Operational seats, then seats after observed/issued upgrades finish.
	std::pair<int,int> barracks_capacity(AIMaximaRuntime::Context& runtime,
		int excludedAction=-1) const;
	AIMaximaPlacement::DevelopmentLimits collect_development_limits(
		AIMaximaRuntime::Context& runtime, int excludedAction=-1) const;
	bool issue_development_action(AIMaximaRuntime::Context& runtime,
		AIMaximaPlacement::DevelopmentAction& action);
	void emit_placement_diagnostics(AIMaximaRuntime::Context& runtime,
		const char* outcome,
		const AIMaximaPlacement::DevelopmentAction* action) const;
	mutable std::vector<AIMaximaPlacement::BuildingProfile>
		development_building_profiles;
	mutable std::vector<int> development_profile_index;
	mutable std::vector<int> development_feeding_visit_rate; // planned visits/tick, not headcount
    mutable std::vector<int> development_feeding_pause;
    // Immutable admission rows compiled once with the building profiles. Only
    // rates and the demand workspace change during candidate retirement checks.
    mutable std::vector<FeedingCapacity> development_feeding_providers;
    mutable std::vector<unsigned> development_feeding_provider_types;
    mutable std::vector<int> development_feeding_provider_index;
    mutable std::vector<int> development_feeding_demand;
	mutable bool development_profiles_initialized=false;
	AIMaximaPlacement::Planner development_planner;
	bool development_planner_initialized;
	std::map<int, AIMaximaPlacement::ActionLifecycleState>
		development_reported_states;
	///One independent controller per inn and swarm, keyed by building id. This
	///is the controller's integral state, so it is carried across saves.
	std::map<int, StaffingControl::State> staffing_control;
	///Runs one control pass and issues the order when the request changes.
	int staff_building(AIMaximaRuntime::Context& runtime, int id);
	/// One control pass for a building: advances its loop and returns the
	/// request, without issuing it.
	int update_staffing_request(AIMaximaRuntime::Context& runtime, int id);
	/// Labour snapshots retained between scheduler passes and saved from v109.
	Labour::Observation labour_observation;
	Labour::Plan labour_plan;
	/// Carriers each completed swarm may hold, from the last labour budget.
	/// It deliberately outlives the building pass: `manage_swarm` is also
	/// reached from the UpdateSwarm event, and clearing this at the end of the
	/// pass let that path reissue the untrimmed request and undo the budget.
	/// A swarm with no entry yet is unbounded until the next pass.
	std::map<int, int> swarm_allowance;
	Labour::Policy labour_policy() const;
	bool labour_swimming_matters() const;
	Labour::Observation observe_labour(AIMaximaRuntime::Context& runtime) const;
	///Food ledger retirement. A building whose protected farm capacity stays
	///below its burden threshold for the confirmation window is removed, but
	///only while doing so cannot leave the population without inn seats.
	std::map<int, int> food_burden_since;
	std::set<int> food_retirement_issued;
	int last_food_retirement_tick;
	///Food ledger relocation. A building whose ledger quality stays above the
	///threshold for the confirmation window is nominated; the planner sites
	///and prices its replacement as a Relocation action, and the old building
	///is destroyed once the replacement stands. One nomination at a time.
	std::map<int, int> relocation_since;
	int relocation_target_building;
	int relocation_target_since;
	///Tick the replacement was first seen completed, so a destroy that keeps
	///being deferred is eventually given up rather than blocking the slot.
	int relocation_completed_tick;
	int last_food_relocation_tick;
	std::set<int> relocation_destroy_issued;
	bool food_building_pending_deletion(AIMaximaRuntime::Context& runtime, int id) const;
	const AIMaximaPlacement::DevelopmentAction* current_food_relocation() const;
	void finish_food_relocation();
	void update_food_relocation(AIMaximaRuntime::Context& runtime,
		const AIMaximaPlacement::WorldState& world);
	///Colony swarms whose settlement is not yet running: exempt from both
	///retirement and relocation until their own farm exists.
	std::set<int> establishing_colony_buildings() const;
	///Targets the ledger can actually supply, carried across saves so a loaded
	///game plans from the same numbers as the run that saved it.
	int food_supported_inns;
	int food_supported_swarms;
    int food_birth_crop_rate=0; // recurring wheat packets/tick, FoodLedger RateScale
	bool food_ledger_valid;
	void update_food_retirement(AIMaximaRuntime::Context& runtime,
		const AIMaximaPlacement::WorldState& world);
	///Neighbouring cells a protected stack's growth can actually spread into.
	///Unlike farm expansion, a partly harvested wheat neighbour absorbs growth.
	int growth_absorbing_neighbors(AIMaximaRuntime::Context& runtime,
		int x, int y) const;
	///Placement pressure drives small, wheat-safe clearing campaigns. Clearing
	///damages workers, so campaigns are rate-limited and health-gated.
	int recent_construction_failures;
	int last_construction_failure_tick;
	bool opening_space_constrained;
	void record_construction_space_failure();
	int proactive_clearing_flag;
	int proactive_clearing_started_tick;
	int proactive_clearing_initial_wood;
	int proactive_clearing_campaigns;
	int last_proactive_clearing_tick;
	void manage_land_clearing(AIMaximaRuntime::Context& runtime);
	bool continue_clearing_campaign(AIMaximaRuntime::Context& runtime);
	void retire_clearing_campaign(AIMaximaRuntime::Context& runtime,
		const char* reason, const std::string& details=std::string());
	struct WoodClearingTarget;
	WoodClearingTarget select_wood_clearing_target(
		AIMaximaRuntime::Context& runtime) const;
	///Keeps planner parcels and circulation routes under durable clearing
	///orders. Only cells owned by this subsystem are removed.
	void update_maintenance_clearing_areas(AIMaximaRuntime::Context& runtime);
	std::vector<Uint8> worker_reachable_circulation(
		AIMaximaRuntime::Context& runtime, bool after_harvest=false) const;
	std::vector<std::vector<int> > reservation_member_footprints(
		AIMaximaRuntime::Context& runtime,
		const AIMaximaPlacement::Reservation& contract) const;
	struct MaintenanceClearingPlan;
	MaintenanceClearingPlan build_maintenance_clearing_plan(
		AIMaximaRuntime::Context& runtime);
	void apply_maintenance_clearing_plan(AIMaximaRuntime::Context& runtime,
		const MaintenanceClearingPlan& plan);
	void initialize_farming_cache(AIMaximaRuntime::Context& runtime);
	int available_expansion_neighbors(AIMaximaRuntime::Context& runtime,
		int x, int y) const;


	///This function updates all of the buildings that are not under construction.
	void manage_buildings(AIMaximaRuntime::Context& runtime);
	///This function updates the units assigned to a particular Inn.
	///Using the messaging system, it is called after the completion
	///of a new Inn and periodically thereafter
	void manage_inn(AIMaximaRuntime::Context& runtime, int id);
	///This function updated the units assigned and the creation
	///ratios of a particular Swarm. Its done afeter the completion
	///of a new swarm and periodically thereafter
	long long nearby_farm_capacity(AIMaximaRuntime::Context& runtime, int id,
		std::set<int>* shared_tiles=NULL);
	void manage_swarm(AIMaximaRuntime::Context& runtime, int id);


	///This function chooses an enemy building to be destroyed. It returns -1 if there are no accessible buildings
	int choose_building_to_attack(AIMaximaRuntime::Context& runtime);
	///This function starts an attack on another enemy building
	void attack_building(AIMaximaRuntime::Context& runtime);
	///Keep one war flag on the planned offensive target; runs every review tick.
	void control_offense(AIMaximaRuntime::Context& runtime);
	void end_offense(AIMaximaRuntime::Context& runtime, const char* reason);
	///This function chooses the enemy team to target
	void choose_enemy_target(AIMaximaRuntime::Context& runtime);
	///This function digs out an enemy building that is surrounded by resources.
	///It will also cause Maxima to dig itself out in certain situations.
	///Returns true if there are buildings that it can dig out, false otherwise
	bool dig_out_enemy(AIMaximaRuntime::Context& runtime);

	///This integer stores the currently targetted enemy
	int target;
	///This integer stores whether a building is being dug out at the current moment
	bool is_digging_out;
	///This vector stores the ID's for all current war flags
	std::vector<int> attack_flags;


	///This function calculates the positions of defense flags
	void compute_defense_flag_positioning(AIMaximaRuntime::Context& runtime);
	///This function adds the specific value to the counts arround the given pos, used in compute_defense_flag_positioning
	void modify_points(Uint16* counts, int w, int h, int x, int y, int dist, int value, std::list<int>& locations);
	///This vector stores the ID's for all current defense flags
	std::vector<int> defense_flags;

	///Refreshes fog-safe guard zones on narrow enemy approach corridors.
	void update_preemptive_defense(AIMaximaRuntime::Context& runtime);
	void clear_preemptive_defense(AIMaximaRuntime::Context& runtime);
	Uint32 compute_preemptive_building_signature(AIMaximaRuntime::Context& runtime) const;
	///Only cells added by this subsystem are owned and therefore removable.
	std::set<int> preemptive_guard_tiles;
	int last_preemptive_defense_tick;
	Uint32 preemptive_building_signature;
	int last_preemptive_effective_zone_max;
	bool last_preemptive_amphibious_active;

	///This function calculates the positions of explorer flags for explorer flag attacks
	void compute_explorer_flag_attack_positioning(AIMaximaRuntime::Context& runtime);
	///This vector stores the list of explorer attack flags
	std::vector<int> explorer_attack_flags;

	///This function updates the restricted areas for farming
	void update_farming(AIMaximaRuntime::Context& runtime);
	///Classify the layout and
	///reconcile the final plan with the engine-owned forbidden area.
	bool has_hard_farming_contract(int index) const;
	struct WoodReserve
	{
		// 1: live protected seed, 2: unprotected growing/harvesting cell.
		std::vector<Uint8> cells;
		int seeds;
		explicit WoodReserve(int size): cells(size,0), seeds(0) {}
	};
	WoodReserve select_wood_reserve(AIMaximaRuntime::Context& runtime,
        const std::vector<Uint8>* seedEligibility=nullptr) const;
	bool wheat_invasion_clearing_required(AIMaximaRuntime::Context& runtime,
		int index, const std::vector<Uint8>& protected_wheat,
		const WoodReserve& wood_reserve) const;
	struct FarmProtectionPlan;
	void resolve_wheat_invasion_clearing(AIMaximaRuntime::Context& runtime,
		FarmProtectionPlan& plan);
	void release_farming_protection(AIMaximaRuntime::Context& runtime);
	FarmProtectionPlan build_farming_protection_plan(
		AIMaximaRuntime::Context& runtime);
	void apply_farming_protection(AIMaximaRuntime::Context& runtime,
		const FarmProtectionPlan& plan, int& added, int& removed);
	Farming::ExactFertilityCache fertility_cache;
	/// Terrain-only adjacency, built with fertility once per map load.
	std::vector<Uint8> farming_shoreline_mask;
	std::vector<Uint8> farming_cardinal_shoreline_mask;
	std::vector<Uint8> applied_farm_protection_mask;
	std::vector<Uint8> applied_maintenance_clearing_mask;
	std::vector<Uint8> maintenance_circulation_mask;
	std::vector<Uint8> wood_firebreak_mask;
	std::vector<Uint8> farm_protection_mask;
	/// Protected wheat pattern only, used to detect adjacent wood invasion.
	std::vector<Uint8> wheat_farm_protection_mask;
	int last_farming_tick;
	bool farming_urgent;
	///Map-area orders produced by farming and placement are intentionally applied
	///on later ticks so their scans cannot extend the calculation that created
	///them. Pending work is serialized to retain exact order timing.
	bool land_clearing_pending;
	bool maintenance_clearing_pending;
	bool development_cycle_pending;
	bool preemptive_defense_pending;
	bool reactive_defense_pending;

	///Maintain explorer vision for reachable fruit varieties at completed inns.
	void update_fruit_flags(AIMaximaRuntime::Context& runtime);
	AIMaximaFruit::Field collect_fruit_field(AIMaximaRuntime::Context& runtime) const;


	int timer;
};


}


#endif
