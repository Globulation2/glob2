/*
  Deterministic protected-wheat food ledger used only by Maxima.

  The ledger answers one question: which inns and swarms are actually backed by
  farm capacity, and how much capacity is still unclaimed.  It is rebuilt from
  scratch on every planning pass, so a destroyed building releases its claim, an
  upgraded inn claims its new demand, and a burned or regrown farm changes
  supply without any incremental bookkeeping.

  Only protected wheat cells that currently carry wheat are supply.  Protected
  cells are the producers: their growth spreads into the harvestable cells
  around them, while unprotected wheat is harvested away and cannot be counted
  as a standing equilibrium supply.

  Like the placement planner this consumes a plain grid snapshot and holds no
  engine types, so its geometry and ordering stay independently testable.  All
  arithmetic is integral and ordering is total, because placement decisions are
  simulation inputs in lockstep games.
 */

#ifndef AI_MAXIMA_FOOD_LEDGER_H
#define AI_MAXIMA_FOOD_LEDGER_H

#include "Material.h"
#include <stdint.h>
#include <array>
#include <vector>

namespace AIMaximaFoodLedger
{

/// Supply, demand and claims are rates in millionths of a wheat unit per tick.
const long long RateScale=1000000;

enum ConsumerKind
{
	InnConsumer,
	SwarmConsumer
};

/// Lifecycle rank of a claimer. Completed buildings claim before construction
/// sites, which claim before parcels that are only reserved.
enum ConsumerStage
{
	CompletedStage,
	SiteStage,
	ReservedStage
};

// A cold operating forecast. Negative carriers preserves planner-only legacy
// fixtures; real providers always supply a bounded requested allowance.
struct OperatingPlan
{
    int carriers=-1;
    int fixedTicks=1,ticksPerTile=0;
    std::array<int,MaterialCount> independent{},production{},trips{};
};
struct OperatingQuery
{
    int demand=0,productionDemand=0,quality=0;
    long long residual=0; // actual candidate components funded, capped by demand
    long long transferred=0; // funded feeding reservation credited only against margin
    bool feasible=true;
};

/// One inn or swarm that eats wheat, including planned ones. Colony swarms are
/// ordinary claimers: they compete for the same wheat, they simply keep their
/// own placement rules and are exempt from retirement while establishing.
struct ConsumerInput
{
	ConsumerInput();
	/// Stable identity chosen by the caller. Building ids and planned actions
	/// must not collide; the adapter encodes planned actions as negative keys.
	int key;
	ConsumerKind kind;
	ConsumerStage stage;
	/// Recurring operating claim in micro-wheat packets per tick.
	int demand;
    int productionDemand=0; // component of demand from planned production
    OperatingPlan operating;
	/// Demand level, used only to break quality ties between claimers.
	int level;
	int centerX;
	int centerY;
	/// Footprint relative to the centre, matching the planner's convention.
	int left;
	int top;
	int width;
	int height;
	bool colony;
	bool retirable;
};

struct Policy
{
	Policy();
	/// Maximum harvesting-route distance, in eight-neighbour path steps.
	int supplyRadius;
	/// Quality is quantised into bands of this many tiles so that small farm
	/// changes cannot reorder claimers and move shortages between them.
	int qualityBandTiles;
	/// Distance charged for demand a claimer cannot reach at all, expressed in
	/// tiles beyond the supply radius. It keeps unreachable sites ranked last
	/// without making quality depend on map size.
	int unreachablePenaltyTiles;
};

struct ConsumerResult
{
	ConsumerResult();
	int key;
    int level; // exact profile stage charged, including authorized upgrades
	ConsumerKind kind;
	bool colony;
	bool retirable;
	int demand;
    int productionDemand=0; // component of demand from planned production
	/// Supply this claimer actually took, capped by its demand.
	int claimed;
    int claimedProduction=0; // exact second-phase allocation
	/// claimed plus the unclaimed supply it could still reach. An upgrade is
	/// judged against this, because its own claim is released and retaken.
	long long available;
	int coveragePercent;
	/// Coverage by reachable recurring supply before competing claims, capped
	/// at full demand. This describes site viability, not spendable funding.
	int uncontestedCoveragePercent = 0;
	int availablePercent;
	/// Supply-weighted mean route distance to the wheat covering full demand,
	/// ignoring every other claimer, in hundredths of a tile.
	int quality;
	int qualityBand;
	/// Final position in the interleaved claim order.
	int order;

	int retirementCoveragePercent() const
	{
		// Feeding priority can leave a viable producer temporarily unfunded.
		// Services without production still use their actual allocation.
		return productionDemand > 0 ? uncontestedCoveragePercent : coveragePercent;
	}
};

struct Input
{
	Input();
	/// Precompute wrapping masks; direct dimension writes remain supported.
	void setDimensions(int width, int height);
	int width;
	int height;
	Policy policy;
	/// Micro-wheat per tick produced by each protected wheat cell.
	std::vector<uint32_t> yield;
	/// Cells a harvesting worker may walk through, including protected wheat.
	std::vector<uint8_t> traversable;
	std::vector<ConsumerInput> consumers;
	int index(int x, int y) const;
	int normalizeX(int x) const;
	int normalizeY(int y) const;

private:
	// An invalid mask cannot match a positive dimension. Stale masks fall back
	// to modulo if a caller changes the public dimensions directly.
	unsigned widthMask = ~0u;
	unsigned heightMask = ~0u;
};

struct Result
{
	Result();
    uint64_t retainedVectorBytes() const noexcept;
	/// Invalidate the snapshot while retaining buffers for the next evaluation.
	void clear();
	std::vector<ConsumerResult> consumers;
	/// Supply still unclaimed on every cell, in the same micro-wheat units.
	std::vector<uint32_t> residual;
    std::vector<uint32_t> serviceResidual; // after independent services, before production
    long long independentClaimed=0;
	long long totalSupply;
	long long totalDemand;
	long long totalClaimed;
	long long totalResidual;
	/// Largest unclaimed supply inside any single supply-radius square. This is
	/// an upper bound on what one new building could reach, so it bounds how
	/// many further inns or swarms the map can still support.
	long long bestSiteResidual;
	const ConsumerResult* consumer(int key) const;

private:
	friend class Ledger;
	// Prepared together with residual by evaluate. Keeping the table in the
	// snapshot makes copies and queries of older results independent of the
	// ledger's scratch buffers. Treat evaluated results as read-only.
	std::vector<long long> residualSums;
    std::vector<long long> serviceResidualSums;
	int residualSumsWidth;
	int residualSumsHeight;
};

enum class EvaluationMode { Full, CandidateQuery };

/// Holds the reusable scratch buffers. Queries never allocate once a map size
/// has been seen, which keeps the per-candidate placement check cheap.

class Ledger
{
public:
	Ledger();
    uint64_t retainedVectorBytes() const noexcept;
	// Candidate snapshots retain exact allocation/query layers, but omit the
    // final-residual economic bound used only by the authoritative baseline.
	void evaluate(const Input& input, Result& result,
        EvaluationMode mode=EvaluationMode::Full) const;
    void reserveQueryFootprint(const Input& input,int width,int height) const;
    /// Combines the existing exact residual walk with uncontested supply work.
    /// The result can be reused by the candidate's feasibility and score calls.
    OperatingQuery operatingQuery(const Input& input,const Result& result,
        const ConsumerInput& candidate,int marginPercent,
        const Result* transferBaseline=nullptr,int feedingTransferLimit=0) const;

	/// Unclaimed supply a building with this footprint could reach, stopping
	/// once `cap` is met so a satisfied candidate never walks its whole radius.
	long long reachableResidual(const Input& input, const Result& result,
		int centerX, int centerY, int left, int top, int width, int height,
		long long cap) const;

	/// Supply-weighted mean route distance, in hundredths of a tile, to the
	/// unclaimed supply that would cover `demand` from this footprint, charging
	/// demand that cannot be reached at the unreachable penalty exactly as
	/// `evaluate` does. This is the quality a relocated building would have
	/// among the current claimants, where `evaluate` measures each claimant
	/// alone.
	int residualQuality(const Input& input, const Result& result,
		int centerX, int centerY, int left, int top, int width, int height,
		long long demand) const;

	/// Sound upper bound for the same query, from a summed-area table over the
	/// residual. Reach is contained in the Chebyshev square, so a candidate
	/// rejected here would also fail the exact walk. Requires an unmodified
	/// result from evaluate; reads its prepared table without scanning,
	/// allocating or rebuilding. A candidate snapshot without a final-residual
    /// table uses total residual as a conservative bound. A default/invalid
    /// result returns zero.
	long long residualUpperBound(const Input& input, const Result& result,
		int centerX, int centerY, int left, int top, int width,
		int height,bool services=false) const;

private:
	struct ReachCell
	{
		int index;
		int distance;
	};
	void walk(const Input& input, int centerX, int centerY, int left, int top,
		int width, int height, std::vector<ReachCell>& reach,
		const std::vector<uint32_t>* residual = nullptr, long long cap = 0) const;
	void prepareResidualSums(const Input& input, Result& result, EvaluationMode mode) const;
	void prepareWorkCurve(const Input& input,const std::vector<ReachCell>& reach,
        const OperatingPlan& plan) const;
    long long wheatWork(long long quantity) const;
    mutable std::vector<long long> workSupply,workQuantity,workPrefix;
    mutable int workFixed=1,workStep=0,workTail=1;
    mutable std::vector<int> distanceScratch;
	mutable std::vector<uint32_t> distanceGeneration;
	mutable uint32_t generation;
	mutable std::vector<ReachCell> reachScratch;
	mutable std::vector<ReachCell> queryScratch;
};

/// Supply of one protected wheat cell, in micro-wheat per tick:
/// fertility/65536 growth chance, one sample per `growthPeriodTicks`, scaled by
/// the share of neighbouring cells its growth can actually spread into.
uint32_t cellYield(uint32_t fertility, int openNeighbors, int growthPeriodTicks);

/// Full-capacity demand of a swarm, in micro-wheat per tick.
int swarmDemand(int foodPerUnit, int unitProductionTime, int percent);

/// Full-capacity demand of an inn serving `servedUnits`, in micro-wheat per
/// tick, where a fed unit eats one wheat every `ticksPerMeal` ticks.
int innDemand(int servedUnits, int ticksPerMeal, int percent);

}

#endif
