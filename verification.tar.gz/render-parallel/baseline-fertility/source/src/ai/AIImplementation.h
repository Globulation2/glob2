// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#pragma once

/*
What's in AI ?
AI represents the behaviour of an artificial intelligence player.
The main method is std::shared_ptr<Order> getOrder() which return the order to be used by the AI's team.
*/

#include "BuildingType.h"
#include "AITelemetry.h"
#include "MersenneTwister.h"
#include "ai/engine/AIDiagnostics.h"
#include "sim/snapshot/Requirements.h"
#include <cassert>
#include <memory>
#include <optional>
#include <stdexcept>

namespace AIEngine { struct DecisionContext; }

namespace GAGCore
{
	class InputStream;
	class OutputStream;
}
class Player;
class Order;

/*
Howto make a new AI ?
If you want to build a new way AI behave, you have to:
Add a new Strategy to the AI::ImplementationID enum.
Add a new case in the AI::load method.
Create a subclass of AIImplementation.
Fill AIImplementation's methods correctly for that subclass.

Warning:
You have to understand how the Order class is used.
Use the controller-provided random stream for AI decisions. Never use rand().
Be sure to return at least a *NullOrder, not NULL.

Decision inputs:
Use the immutable world in DecisionContext and controller-private query caches.
Live Player/Game access belongs only to simulation-owner construction and load.

Fairness:
AI don't have restricted access to hidden part of the map.
You have to check it yourself, please do it.
Please don't use too much CPU either.
Test games with a lot of AI for that.

Gameplay:
Player and AI may play together, in the same team.
Think if your AI is able to play with a human player?
*/

class AIImplementation
{
public:
	// Bound by the owning AI when the implementation is created or loaded.
	void setRandomEngine(MersenneTwister &engine) { randomEngine = &engine; }
	MersenneTwister snapshotRandom() const { assert(randomEngine); return *randomEngine; }
	void restoreRandom(const MersenneTwister& state) { assert(randomEngine); *randomEngine=state; }
	MersenneTwister& privateRandomEngine() const { assert(randomEngine); return *randomEngine; }
	Uint32 random() const { assert(randomEngine); return (*randomEngine)(); }
  AITelemetry::Sink telemetry;
  mutable std::vector<AIEngine::DiagnosticRecord> bufferedDiagnostics;
  virtual void captureTelemetry() {}
  virtual Uint32 telemetrySchemaVersion() const { return 1; }
  virtual const std::vector<AITelemetry::Field> &telemetrySchema() const
  {
	  return AITelemetry::schema(0);
  }
	AIImplementation(){}
	virtual ~AIImplementation(){}
	
	virtual bool load(GAGCore::InputStream *stream, Player *player, Sint32 versionMinor)=0;
	virtual void save(GAGCore::OutputStream *stream)=0;
	
	virtual std::shared_ptr<Order> getOrder(void)=0;
	// Safe worker execution is opt-in only after every decision read has moved
	// to owned observation inputs. The default cannot accidentally call the
	// legacy live-world implementation on a background thread.
	virtual bool supportsObservation() const { return false; }
	virtual SimulationSnapshot::Requirements observationRequirements() const { return SimulationSnapshot::Simulation; }
	// Sampled only by the controller's own lane after a decision. Empty means
	// this controller has not supplied retained vector-capacity accounting.
	virtual std::optional<Uint64> retainedQueryVectorBytes() const { return std::nullopt; }
	virtual std::shared_ptr<Order> getOrder(const AIEngine::DecisionContext&)
	{
		throw std::logic_error("AI has not migrated to immutable observations");
	}
	// Called on the controller's own lane when reconciling immutable receipts.
	// Acceptance is command admission, not completion of construction.
	virtual void orderExecutionCompleted(const Order&, bool accepted) {}
private:
	MersenneTwister *randomEngine = nullptr;
};


 
