// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 The Globulation 2 Authors

#pragma once

// Persist policy selection and its immutable inference blob.
static constexpr int AI_CORTEX_SAVE_FORMAT_POLICY_STATE = 132;

#include "CortexConstants.h"
#include <string>

namespace Cortex
{
	/// Runtime policy knobs. Each AICortex owns a resolved copy; getOrder scopes
	/// helper access to that instance. Versioned GameHeaders carry these values
	/// across saves and network messages. Structured commands validate explicit
	/// per-player overrides without consuming ambient tuning files.
	///
	/// Legacy new-game invocations read GLOB2_CORTEX_TUNING once as their default
	/// vector. Its format is one "key value" pair per line with '#' comments;
	/// invalid, duplicate or unreadable entries abort as before. Normal defaults
	/// preserve the existing policy. Saved resolved values take precedence.
	struct CortexTuning
	{
		// --- second-swarm trigger face (when "wants a fresh patch" fires) -----
		/// Food level below which a cap-pinned swarm counts as DRAINING (the
		/// expansion-trigger use of CORTEX_SWARM_WHEAT_ADD_LO, split from the
		/// hauler-tuning use, which stays on the constant). Also the severity
		/// scale's top: field-depleted severity == this value.
		int expandWheatLo = CORTEX_SWARM_WHEAT_ADD_LO;
		/// The swarm hauler cap: tuneWorkers' early/mid-game maxUnitWorking
		/// ceiling AND the "pinned at the cap" test of the capped-draining face
		/// (one knob on purpose — "capped" always means the operative cap).
		int swarmWorkerCap = CORTEX_SWARM_WORKER_CAP;
		/// Food level at which tuneWorkers releases a hauler. Governs the
		/// cap-latch: on thin-food maps the buffer never reaches the release
		/// line, so maxUnitWorking sticks at the cap and the capped-draining face
		/// fires on every production-cycle food dip.
		int swarmWheatRemHi = CORTEX_SWARM_WHEAT_REM_HI;
		/// Harvestable-food tile count below which a catchment is DEAD: the
		/// field-depleted trigger face and tuneWorkers' food-starved single-
		/// hauler clamp (shared, as in the committed code).
		int wheatStarvedTiles = CORTEX_SWARM_WHEAT_STARVED_TILES;
		/// Wheat-abundance veto on the capped-draining face: when > 0, a swarm
		/// with harvestableFoodSourcesNearby >= this many tiles is NOT capped-draining —
		/// a low food buffer beside plentiful food is production-cycle noise, not
		/// a spent catchment (the Muka seed-1 misfire: food=3 with 47 tiles).
		/// 0 = veto disabled (committed behavior).
		int expandWheatVeto = 0;
		/// Consecutive decision cycles (~25 ticks each) anySwarmWantsFreshPatch
		/// must hold before the second-swarm scorer may fire. 1 = fire on the
		/// first cycle (committed behavior); higher values debounce transient
		/// food-buffer dips that self-heal within a few cycles.
		int expandDebounceCycles = 1;

		// --- second-swarm ranking (when it wins the cycle) --------------------
		/// Kept in lockstep with CortexScore::SCORE_SECOND_SWARM_BASE/_STEP by a
		/// static_assert in CortexPolicyEconomy.cpp.
		int scoreSecondSwarmBase = 6100;
		int scoreSecondSwarmStep = 100;
		/// Minimum fresh-patch severity (1..expandWheatLo) the worst swarm must
		/// reach before the scorer fires at all; expandWheatLo = field-depleted
		/// only. 1 = any severity (committed behavior).
		int expandSeverityFloor = 1;

		// --- combat envelope (attack range / war preparation) -----------------
		/// Base attack range in Chebyshev tiles: an offensive commit requires a
		/// known target within this distance of our nearest FINISHED inn (maxed
		/// with the nearest finished hospital when one exists) — a war party
		/// fights only as far from food/healing as the hunger clock allows. When
		/// every target is out of range Cortex builds a FORWARD inn/hospital
		/// toward the front instead of attacking and melting (scoreForwardBase);
		/// if no legal forward site exists the gate is waived. <= 0 disables the
		/// gate entirely (pre-v18 behavior).
		int attackRangeBase = 32;
		/// Range added per WALK level of the wave's SLOWEST warrior (racetrack
		/// training): faster marchers survive longer supply round-trips.
		int attackRangePerWalkLevel = 8;
		/// War-preparation level match: when 1, the normal offense commit counts
		/// only warriors whose ATTACK_STRENGTH level >= the highest enemy-warrior
		/// level ever observed (FOW-gated, latched), capped by what our barracks
		/// can currently train (finished barracks level + 1) so the gate creates
		/// training pressure instead of a deadlock. The famine blitz ignores it.
		/// 0 disables (raw-count commit, pre-v18 behavior).
		int warPrepLevelMatch = 1;
		/// Grace window (ticks) the attack-range gate may BIND — the army wants to
		/// attack and every known target is out of the support envelope — before the
		/// gate is WAIVED and the offense commits out-of-envelope anyway (pre-v18
		/// behavior) while the forward base keeps building. Prevents a "possible" but
		/// never-ordered forward base from holding the gate shut forever. 0 = never
		/// waive (the gate binds indefinitely while a forward base could cure it).
		int attackRangeGraceTicks = 2400;
		/// When 1, the attack-range gate is waived IMMEDIATELY (no grace wait) while
		/// AT MOST ONE enemy building is discovered: the gate first binds at first
		/// contact (flag targets ARE discovered buildings), and against a
		/// still-unscouted colony that lone out-of-envelope data point is no basis
		/// for holding the first strike through the grace window. Once the enemy
		/// base is mapped (>= 2 buildings discovered) the normal bind-then-grace
		/// behavior applies. 0 disables (always wait out the grace).
		int attackRangeUnscoutedWaiver = 1;

		// --- amphibious offense (water-crossing wave pipeline) ----------------
		/// Landing-zone standoff: an amphibious campaign's landing zone (where swimmers
		/// climb out and mass) must keep at least this many Chebyshev tiles from every
		/// discovered enemy building, so the fleet forms up out of shelling range before
		/// pushing inland. If no shore tile clears it, the best shore tile is used anyway.
		int landingStandoffTiles = 12;
		/// Ticks a wave may hold in the CROSS phase (massing swimmers at the landing zone)
		/// before it releases to the ASSAULT regardless of arrival count — so a slow or
		/// depleted crossing never stalls the amphibious offense forever.
		int crossTimeoutTicks = 3000;
		/// Fleet-release trigger: once the COMBINED arrived count of all waves currently
		/// CROSSing at the same landing zone reaches this, they release TOGETHER (a massed
		/// amphibious assault) rather than each waiting out its own crossReady fraction.
		int fleetReleaseArrived = 15;
		/// Swim-capable warriors (obs.swimWarriors) required before an amphibious campaign
		/// spawns its first musterer. Below it, no muster flag exists to bind fresh
		/// warriors, so they idle (ACT_RANDOM) and train SWIM at the pool — breaking the
		/// "flag-bound from birth so never learns to swim" loop. Default mirrors the
		/// ATTACK_MIN_WARRIORS commit bar (8) in CortexPolicyCombat.cpp.
		int amphibiousMinSwimWarriors = 8;
		/// Forward-rally trigger for LONG LAND marches: when a land campaign's true
		/// BFS path distance (rally -> primary target) exceeds this, the waves stage
		/// through the CROSS phase at a FORWARD RALLY corridor tile (picked at the
		/// landing standoff from every discovered enemy building) instead of marching
		/// straight onto the target — so the army masses forward and fights as a
		/// fleet rather than trickling in over a march the warp-distance envelope
		/// never saw (the Mazury seed-3 hunger-commute loss). 0 disables (straight
		/// MUSTER -> ASSAULT on every land campaign, the pre-forward-rally behavior).
		int forwardRallyPathDist = 30;

		// --- production-mix worker-target tiers (the expansion-tax side) ------
		/// Divisor D in mid = base + (needs - base)/D: how far past the hauler
		/// floor the worker base grows before production flips to pure warriors.
		/// Construction-site jobs inflate `needs`, so D also sets how hard an
		/// in-flight expansion delays the army ramp.
		int tierMidDiv = 2;
		/// Worker slice of the worker-dominant middle tier's production ratio.
		int workerRatioTier2 = CORTEX_MAX_RATIO / 2;
	};

	std::string tuningValues(const CortexTuning& tuning);
	bool applyTuning(CortexTuning& tuning, const std::string& values, std::string& error);
	std::string tuningSchemaJson();
	/// Scoped access for policy helpers. Each AI owns the immutable values; the
	/// scope restores the previous pointer, including on exceptions.
	class TuningScope
	{
		const CortexTuning* previous;
	public:
		explicit TuningScope(const CortexTuning& tuning);
		~TuningScope();
		TuningScope(const TuningScope&) = delete;
		TuningScope& operator=(const TuningScope&) = delete;
	};
	/// The active instance's values, or legacy environment defaults outside a scope.
	const CortexTuning& cortexTuning();
}
