// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 The Globulation 2 Authors

#pragma once
#include "CortexTuning.h"
#include "CortexSnapshotQueries.h"

#include "AIImplementation.h"
#include "CortexTypes.h"
#include "CortexPolicy.h"

#include <cstdio>
#include <map>
#include <memory>
#include <queue>
#include <sstream>

namespace GAGCore
{
	class InputStream;
	class OutputStream;
}
class Player;
class Order;
class Building;

// AICortex subclasses AIImplementation directly, owning the full
// observation -> policy -> action pipeline with no Runtime framework in between.
//
// The engine constraint is one Order per getOrder() call. The action layer
// therefore translates one CortexAction into a *sequence* of Orders pushed onto
// orderQueue; getOrder() pops one per tick and returns NullOrder when the queue
// is empty. The policy is consulted on a slow cadence (OBSERVE_INTERVAL ticks),
// not every tick — cheap now, and the right shape for paying NN inference cost
// only on decision cycles. See docs/ai/development.md.

class AICortex : public AIImplementation
{
public:
  void captureTelemetry() override;
  const std::vector<AITelemetry::Field> &telemetrySchema() const override
  {
	  return AITelemetry::schema(6);
  }
  Uint32 telemetrySchemaVersion() const override { return 2; }
	explicit AICortex(Player* player);
	AICortex(GAGCore::InputStream* stream, Player* player, Sint32 versionMinor);
	~AICortex();

	bool load(GAGCore::InputStream* stream, Player* player, Sint32 versionMinor);
	void save(GAGCore::OutputStream* stream);

	std::shared_ptr<Order> getOrder(void);
	bool supportsObservation() const override { return true; }
    std::optional<Uint64> retainedQueryVectorBytes() const override;
	std::shared_ptr<Order> getOrder(const AIEngine::DecisionContext&) override;

private:
	const AIEngine::AIWorldView* observedWorld = nullptr;
    const AIEngine::TeamView* observedTeam = nullptr;
    int observedPlayer = 0;
    Cortex::PlanningIntent intents;
	std::shared_ptr<Order> decide();
	std::shared_ptr<Order> runObservation(const AIEngine::DecisionContext&, bool worker);
	mutable std::ostringstream diagnosticStream;
    Cortex::QueryScratch queryScratch;
	void applyQueuedIntent(const AIEngine::AIWorldView&);
    struct PendingCommand {
        std::vector<Uint8> bytes;
        BuildingRef target;
        Uint32 observedTick=0,scheduledTick=0;
        Uint64 sequence=0;
        int upgradeType=-1,upgradeUntil=0,buildClass=-1,buildCooldown=0;
        int flagKind=0,flagSlot=-1,flagCooldown=0;
    };
    std::vector<PendingCommand> issuedCommands,queuedCommands;
    void applyReceipts(const AIEngine::DecisionContext&);
    void rememberIssued(Order&,const AIEngine::DecisionContext&,const AIEngine::AIWorldView&);
    void rememberFlagCreation(Order&,Sint32&);
    void rememberQueuedBuild(Order&,int);
    void enqueueOrder(std::shared_ptr<Order>);
    void rejectIntent(const PendingCommand&);
    void saveCommands(GAGCore::OutputStream*,const std::vector<PendingCommand>&,const char*) const;
    bool loadCommands(GAGCore::InputStream*,std::vector<PendingCommand>&,const char*,unsigned limit);

	Cortex::CortexTuning runtimeTuning;
	/// Ticks between policy invocations. The observation/policy run at this
	/// cadence; Order emission stays at tick rate via the queue. 30 ticks = 1
	/// second at normal speed.
	static const int OBSERVE_INTERVAL = 25;

	/// Worker count forced onto the pre-placed starting swarm on the first decision
	/// cycle. The map gives the initial swarm an arbitrary maxUnitWorking; jump it
	/// straight to a productive hauler count so the early worker economy ramps at
	/// once instead of crawling up one hauler per cycle through the ±1 worker-tuning
	/// loop. One-shot (see swarmKickstarted); tuning takes over from this baseline.
	static constexpr int SWARM_START_WORKERS = 4;

	/// Ticks to suppress a new build order OF THE SAME TYPE after issuing one, so
	/// the in-flight OrderCreate has time to execute and show up as a building site
	/// before the policy decides again (otherwise it re-issues duplicates the engine
	/// drops). Applied per-type via buildCooldownUntil[], so the cooldown bridges only
	/// the issue->visible-site window for that one type and never stalls placing a
	/// different building while units are free.
	static const int BUILD_COOLDOWN_TICKS = 250;

	/// Safety-net lifetime of the pendingUpgradeType guard (below). An issued
	/// upgrade is normally cleared the moment it becomes a visible construction
	/// site; this only bounds the rare case where the upgrade order is silently
	/// dropped or reverted (cancelConstruction) and never becomes a site, so the
	/// guard would otherwise block that type forever. Generously larger than the
	/// invisible issue->site window (a few hundred ticks at most).
	static const int UPGRADE_PENDING_TIMEOUT_TICKS = 2000;

	/// Offense-hold hysteresis (the thrash damper). Once we commit an offensive
	/// war flag we hold that posture for at least this many ticks; within the
	/// hold window a DEFENSE recall is IGNORED unless the base threat is "serious"
	/// (>= DEFENSE_SERIOUS_BUILDINGS buildings taking fire at once). This stops the
	/// single flag oscillating between the enemy base and home every decision cycle
	/// whenever a lone harasser pokes the colony — the measured failure mode where
	/// the army never advanced and melted short of the objective. Sized as several
	/// OBSERVE_INTERVAL cycles so the flag actually reaches and engages the enemy
	/// before any minor-harassment recall is even considered.
	///
	/// This constant is used ONLY here, to (re-)arm offenseHoldUntil when a war flag
	/// is placed — an execution side-effect the action layer owns. The hold-vs-recall
	/// DECISION that consults the resulting offenseHoldUntil now lives in the policy
	/// (CortexPolicy::scoreDefense), which reads it through the observation; the policy
	/// stays pure and never sees this constant.
	static const int OFFENSE_HOLD_TICKS = 600;
	/// Offense WAVE PIPELINE (the "keep the army moving as cohesive waves, no downtime"
	/// design). Cortex runs up to MAX_OFFENSE_FLAGS offense war flags at once. At any
	/// moment AT MOST ONE is MUSTERING — planted at the home rally point, at NORMAL
	/// priority so freshly-trained warriors flow into it and gather as a mass — while the
	/// others are MARCHING on the enemy at LOW priority (they keep their mustered cohort
	/// but never pull solo replacements: the engine never poaches a warrior already bound
	/// to a flag, so a marching wave stays intact and a new wave forms behind it). The
	/// moment a mustering wave is "near full" it marches and a fresh musterer is spawned,
	/// so pressure is continuous and never collapses to a single all-or-nothing push.
	/// One flag deploys at most CORTEX_MAX_FLAG_UNITS (engine cap); the pipeline is how
	/// Cortex fields a large army instead of leaving it idle behind a 20-unit cap.
	static const int MAX_OFFENSE_FLAGS = 3;
	/// A muster lasts at most this many ticks: once it elapses the wave marches with
	/// whatever has gathered, so a slow/scattered army never stalls the offense forever.
	static const int OFFENSE_MUSTER_TIMEOUT_TICKS = 500;
	/// A wave is "massed enough to march" once the warriors gathered at its rally flag
	/// reach this fraction (num/den) of the flag's requested summon count — "near full",
	/// not exactly full, since a unit is always dying or being born. Floored at 1.
	static const int OFFENSE_MUSTER_READY_NUM = 3;
	static const int OFFENSE_MUSTER_READY_DEN = 4;
	/// A MARCHING wave is retired (its slot freed for a fresh muster) once the warriors
	/// still present around its flag fall to or below this — the cohort is spent, so we
	/// recycle the slot rather than leave a near-empty flag dribbling at the enemy.
	static const int OFFENSE_WAVE_SPENT_WARRIORS = 2;
	/// How many of our buildings must be under attack AT ONCE for a defensive
	/// recall to override an in-progress offense hold. A single transient hit
	/// (1 building) is "harassment" and does not break the push; multiple
	/// buildings under fire is a real base assault that earns the recall.
	/// Single-sourced in CortexTypes.h (the hold-vs-recall decision now lives in
	/// the policy, which reads it from there); aliased here so the action layer's
	/// established name keeps working and the value can never drift.
	static const int DEFENSE_SERIOUS_BUILDINGS = Cortex::CORTEX_DEFENSE_SERIOUS_BUILDINGS;

	/// Flag posture the action layer last committed (RAM-only hysteresis state).
	/// Aliases Cortex::CortexFlagPosture (single source of truth) so the value
	/// stored in flagPosture / runtimeed into the observation is identical everywhere.
	enum FlagPosture {
		POSTURE_NONE    = Cortex::CORTEX_POSTURE_NONE,
		POSTURE_OFFENSE = Cortex::CORTEX_POSTURE_OFFENSE,
		POSTURE_DEFENSE = Cortex::CORTEX_POSTURE_DEFENSE
	};

	/// Explicit phase of an offense wave. A short land campaign runs MUSTER -> ASSAULT
	/// (exactly the historical muster-then-march); a STAGED campaign — amphibious, or a
	/// long land march past forwardRallyPathDist — inserts a CROSS phase (mass at the
	/// staging point: the landing zone or the forward rally) between the two. WAVE_NONE
	/// is the empty-slot sentinel (replaces the old "gid == NOGBID && musterUntil == 0"
	/// test).
	enum WavePhase {
		WAVE_NONE    = 0, ///< empty slot: no wave here.
		WAVE_MUSTER  = 1, ///< gathering at the home rally (NORMAL priority, recruits fresh warriors).
		WAVE_CROSS   = 2, ///< staged campaigns only: massing at the staging point — the amphibious landing zone or the long-march forward rally (LOW priority).
		WAVE_ASSAULT = 3  ///< marching/holding on the enemy target (LOW priority).
	};

	/// One offense wave in the pipeline. `gid` is its live WAR_FLAG (NOGBID when the
	/// flag has not registered yet or the slot is empty). `phase` is a WavePhase
	/// (WAVE_NONE == empty slot). `phaseDeadline` is the timeout tick of the current
	/// timed phase — the muster timeout in WAVE_MUSTER, the cross timeout in WAVE_CROSS
	/// — and 0 in WAVE_ASSAULT / WAVE_NONE (no deadline). `landingX/landingY` are the
	/// CROSS-phase staging tile (the amphibious landing zone or the long-march forward
	/// rally; -1 when none — the established field names predate the forward rally and
	/// are kept). `musterBestArrived` is the muster's arrival high-water mark: each net
	/// increase restarts the muster timeout, so a still-filling muster is never released
	/// at 2-of-20 (see manageOffenseWaves). `createCooldown` gates re-issuing this
	/// slot's OrderCreate until the flag registers (an OrderCreate takes several ticks
	/// to land). Iterated by array index — deterministic, never a set.
	struct OffenseWave {
		Uint16 gid;
		Sint32 phase;
		Sint32 phaseDeadline;
		Sint32 landingX, landingY;
		Sint32 musterBestArrived;
		Sint32 createCooldown;
	};

	/// One DEFENSE flag slot (multi-point defense). `gid` is its live WAR_FLAG (NOGBID ==
	/// empty slot); `createCooldown` gates re-issuing THIS slot's OrderCreate until the
	/// flag registers, so a pending create in one slot never stalls another slot's
	/// placement or a time-critical recall (the per-wave cooldown pattern). Iterated by
	/// array index — deterministic, never a set. Serialized for lockstep determinism.
	struct DefenseFlag {
		Uint16 gid;
		Sint32 createCooldown;
	};

	void init(Player* player);

	/// Action layer (direct binding): translate an action intent into zero or
	/// more engine Orders, appended to orderQueue. NoOp queues nothing. The
	/// observation is passed alongside because an ACTION_BUILD only carries a
	/// candidate-slot index — the (x, y) lives in obs.buildCandidates. Dispatches
	/// to one per-action-kind helper below; each helper owns that kind's cooldown
	/// gates, state mutations, dedup checks, and order-push sequence.
	void translateAction(const Cortex::CortexAction& action, const Cortex::CortexObservation& obs);

	// --- Per-action-kind translate helpers --------------------------------
	// One method per ACTION_* kind. Each appends zero or more Orders to
	// orderQueue and mutates only the state the original inline case mutated
	// (buildCooldownUntil[], pendingUpgradeType/Until, flagPosture,
	// offenseHoldUntil). The order in which orders are pushed is preserved
	// byte-for-byte from the pre-decomposition switch.
	void translateActionBuild(const Cortex::CortexAction& action, const Cortex::CortexObservation& obs);
	void translateActionBuildForward(const Cortex::CortexAction& action, const Cortex::CortexObservation& obs);
	void translateActionSetProduction(const Cortex::CortexAction& action, const Cortex::CortexObservation& obs);
	void translateActionPlaceWarFlag(const Cortex::CortexAction& action, const Cortex::CortexObservation& obs);
	void translateActionPlaceDefenseFlag(const Cortex::CortexAction& action, const Cortex::CortexObservation& obs);
	void translateActionClearFlags();
	void translateActionUpgradeBuilding(const Cortex::CortexAction& action, const Cortex::CortexObservation& obs);
	void translateActionTuneWorkers(const Cortex::CortexAction& action, const Cortex::CortexObservation& obs);
	void translateActionSetPriority(const Cortex::CortexAction& action, const Cortex::CortexObservation& obs);

	/// Shared build-order tail for translateActionBuild / translateActionBuildForward:
	/// resolve the level-0 building-site type id for `type`, push one OrderCreate at
	/// (x, y) with the engine's canonical default worker counts, and arm the per-type
	/// build cooldown until `tick` + BUILD_COOLDOWN_TICKS. Both callers have already gated
	/// on the cooldown and validated their candidate; this is only the shared
	/// resolve->emit->arm step (the candidate SOURCE is all that differs between them).
	/// Returns true when an OrderCreate was actually queued (false when the type has no
	/// buildable site), so translateActionBuildForward can record the ordered position.
	bool emitBuildOrder(int type, int x, int y, int tick, int placementType = -1);

	/// Shared "decode GID → verify building → dedup → push OrderModifyBuilding"
	/// loop used by translateActionTuneWorkers for all three building sets
	/// (swarms, inns, construction sites). `tracked`/`count` is the observed
	/// building array (TrackedBuilding or TrackedSite — both expose valid, gid,
	/// maxUnitWorking); `desiredArr[i]` is the requested maxUnitWorking for
	/// tracked[i] (-1 == leave unchanged). `maxClamp >= 0` clamps the request to
	/// that ceiling before the dedup check (the sites path; pass -1 for the
	/// swarm/inn paths, which do not clamp). `accept` is the per-set guard that
	/// confirms the decoded Building is still the kind we observed (finished swarm,
	/// finished inn, or live construction site) before issuing the order. On each
	/// accepted change it mirrors the engine executor locally (plannedWorkers(intents,*b) =
	/// desired; b->update()) and pushes one OrderModifyBuilding — identical to the
	/// original three inline loops, in the same index order.
	template <typename Tracked, typename Accept>
	void applyWorkerCounts(const Tracked* tracked, int count, const Sint32* desiredArr,
	                       int maxClamp, Accept accept);

	/// Sibling of applyWorkerCounts for Building::priority. `desiredArr[i]` is the
	/// requested priority for tracked[i] (CORTEX_PRIORITY_NONE, or any value outside
	/// -1/0/+1, == leave unchanged). Used by translateActionTuneWorkers to pin
	/// construction sites to LOW and restore finished inns to NORMAL. Dedups against
	/// the observed priority, mirrors the engine executor locally (plannedPriority(intents,*b) then
	/// b->updateCallLists(), per executeChangePriority) and pushes one
	/// OrderChangePriority per accepted change. `tracked` may be TrackedBuilding or
	/// TrackedSite — both expose valid, gid, priority.
	template <typename Tracked, typename Accept>
	void applyPriorities(const Tracked* tracked, int count, const Sint32* desiredArr,
	                     Accept accept);

	/// Wheat-forbidden executor, run EVERY decision cycle in parallel with
	/// translateAction (gated by CortexPolicy::wantFoodSourceProtection) — not as a
	/// competing action. Rebuilds the full ADD/DEL checkerboard tile masks over our
	/// food (a bounded colony-region scan, RNG-free) at the per-game open-margin
	/// wheatOpenMargin and appends one area-paint order per non-empty diff
	/// (DEL before ADD). A single order carries the whole diff, so all newly-revealed
	/// food is fenced in one cycle. Self-correcting: an already-painted diff is empty
	/// next cycle, so re-running each cycle is free when there is no new work.
	void enqueueFoodSourcesForbidden(const Cortex::CortexObservation& obs, bool liftAll = false);

	/// Resolve a tracked flag gid to its live ALIVE WAR_FLAG building, or NULL if the
	/// gid is unset (NOGBID) or the flag no longer exists (died / was deleted).
	/// Scans team->virtualBuildings (a list, deterministic insertion order — never a
	/// std::set).
	const AIEngine::BuildingView* findFlagByGid(Uint16 gid) const;

	/// True if `gid` is currently owned by ANY tracked flag (any defense flag or any
	/// offense wave). Used by rediscoverFlag so a newly-landed flag is never double-
	/// claimed by two slots.
	bool isOwnedGid(Uint16 gid) const;

	/// After an OrderCreate lands (it takes several ticks), claim the new WAR_FLAG into
	/// `gid`: the live WAR_FLAG nearest (tx, ty) whose gid is not already owned by
	/// another tracked flag. Returns the claimed building (and stores its gid in `gid`),
	/// or NULL if none has appeared yet. Position-matching disambiguates concurrently
	/// created flags (their targets are far apart).
	const AIEngine::BuildingView* rediscoverFlag(Uint16& gid, int tx, int ty);

	/// Ensure the flag tracked by `gid` sits at (tx, ty) with the given summon count,
	/// minLevel, and engine priority: create it if absent (respecting `cooldown` and the
	/// virtual-building room check), else move it when far and reconcile
	/// count/minLevel/priority. Operates on a gid/cooldown REFERENCE so any flag (defense
	/// or any offense wave) is managed independently. Appends Orders to orderQueue
	/// (mirroring each engine executor locally so the dedup won't re-fire).
	void ensureFlagAt(Uint16& gid, Sint32& cooldown, int tx, int ty, int radius, int count,
	                  int minLevel, int priority, const Cortex::CortexObservation& obs);

	/// Remove the flag tracked by `gid` (OrderDelete) if it exists, and reset `gid` to
	/// NOGBID. Deleting a flag releases its committed warriors back to the free pool.
	void clearOneFlag(Uint16& gid);

	/// Tear down every offense wave (delete each live flag, clear all slots). Used to
	/// recall the whole army (a serious defense) or to stand the offense down.
	void clearAllOffenseFlags();

	/// Drive the offense WAVE PIPELINE one decision cycle toward (targetX, targetY) (the
	/// enemy building to assault), each flag with stay-range `radius`: reconcile every
	/// live wave (advance phases, retire spent assaulters) and, if a slot is free and
	/// spare warriors exist, (keep) mustering the next wave at the home rally. `warriors`
	/// is the colony's current warrior count (whether there is anything left to muster).
	/// `staged` (with a valid staging point at stagingX/stagingY — the amphibious
	/// landing zone or the long-land-march forward rally) inserts the CROSS phase
	/// between MUSTER and ASSAULT so the army masses at the staging point before the
	/// final push; a short land campaign (staged false) runs MUSTER -> ASSAULT
	/// unchanged. `amphibious` additionally gates the swim-specific behavior (the
	/// swim-staging muster hold) — a forward-rally campaign is staged but NOT
	/// amphibious. See MAX_OFFENSE_FLAGS and the OffenseWave doc.
	void manageOffenseWaves(int targetX, int targetY, int radius, int warriors,
	                        bool staged, int stagingX, int stagingY, bool amphibious,
	                        const Cortex::CortexObservation& obs);

	/// Warriors of `flag`'s bound cohort (unitsWorking) currently ARRIVED — within the
	/// flag's unitStayRange (warp-safe Chebyshev). Reads deterministic simulation state
	/// (every client runs the same AI over the same state), so it is safe to drive phase
	/// transitions from it. Shared by manageOffenseWaves and the CORTEX_DUMP_OFFENSE
	/// diagnostic. 0 for a NULL flag.
	int countArrivedAtFlag(const AIEngine::BuildingView* flag) const;

	/// Home RALLY point for the muster-then-march offense: the colony's heart (its
	/// first/primary swarm, falling back to the first alive building). A single valid
	/// colony tile — no centroid/map-wrap math — where each offense wave gathers before
	/// marching out as one. Returns false (no buildings) so the caller can skip mustering.
	bool computeRallyPoint(int& rx, int& ry) const;

	/// Tear down the stale DEFENSE flag SET once the assault is over (no building under
	/// attack) — every defense slot's flag is cleared. Runs every decision cycle in
	/// getOrder() — in parallel with the action
	/// ladder, NOT gated on winning it — because scoreDefense DECLINES when there is no
	/// threat, so the ladder would never pick a teardown action. Cheap and idempotent
	/// (a no-op once the flag is already gone).
	void reconcileStaleDefenseFlag(const Cortex::CortexObservation& obs);

	/// OrderDelete any own ALIVE WAR_FLAG whose gid no tracker owns (isOwnedGid) and that
	/// has stayed unowned across two consecutive decision cycles. ensureFlagAt issues its
	/// OrderCreate fire-and-forget — the gid is latched only by rediscoverFlag on a LATER
	/// cycle — so a teardown in that window (retire / defense-deficit release / no-target
	/// stand-down / reconcileStaleDefenseFlag) can wipe the tracker slot while the flag
	/// lands UNTRACKED, summoning warriors forever with nothing to delete it. This runs
	/// LAST each decision cycle (after all flag management, so any slot that will claim its
	/// pending create already has); the two-cycle settle window (unownedFlagSeen) then
	/// guarantees no live slot is still waiting for a flag before it is swept. Idempotent.
	void sweepOrphanWarFlags(const Cortex::CortexObservation& obs);

	/// Find the single best finished instance of `buildingType` (an
	/// Cortex semantic role) to upgrade to its next level, or NULL if no
	/// instance currently passes the full engine Upgradable predicate. Scans
	/// game->buildingSlots(team->number) by ARRAY INDEX (never a std::set) and ranks eligible
	/// instances deterministically — improving on Nicowar's random pick. See the
	/// .cpp for the predicate and the bottleneck ranking.
	const AIEngine::BuildingView* findUpgradeTarget(int buildingType) const;

	Player* player;

	Cortex::CortexPolicy policy;
	int timer;

	/// Game tick before which translateAction refuses to issue another build
	/// (see BUILD_COOLDOWN_TICKS), indexed by building type. 0 = no build of that
	/// type pending. Per-type (not a single global gate) so issuing one building
	/// only suppresses re-issuing the SAME type while its OrderCreate is in flight
	/// — a different type can be placed on the very next decision cycle the moment
	/// spare labour exists, instead of waiting out a colony-wide build cooldown.
	/// The duplicate-build the cooldown prevents is inherently per-type (the policy
	/// only ever re-issues the same intent), so a per-type window loses no safety.
	int buildCooldownUntil[Cortex::CORTEX_BUILDING_TYPES];

	/// Guard against stacking two upgrades of the SAME building class while the
	/// first is still converting. An issued upgrade (OrderConstruction) does not
	/// appear in the observation as a site for a while — the building first evicts
	/// its trainees and waits for the larger footprint to clear
	/// (building/Construction.cpp:394-423) — so without this guard the policy,
	/// still seeing the pre-upgrade count finished and none upgrading, re-issues a
	/// SECOND upgrade and blacks out the whole class at once (measured: both
	/// barracks offline simultaneously). Holds the semantic role of an upgrade we
	/// issued that has not yet become a visible site; -1 == none pending. Cleared
	/// the cycle the upgrade becomes visible (the policy's own
	/// cortexBuildingsUpgrading / finished-count gates take over then) or after
	/// UPGRADE_PENDING_TIMEOUT_TICKS. Serialized for lockstep determinism (it
	/// gates order emission, like buildCooldownUntil).
	int pendingUpgradeType;
	/// Safety-net expiry tick for pendingUpgradeType. 0 when nothing is pending.
	int pendingUpgradeUntil;

	/// The offense WAVE PIPELINE: up to MAX_OFFENSE_FLAGS concurrent offense flags, each
	/// MUSTERING at the rally then MARCHING on the enemy (see OffenseWave / the pipeline
	/// constants). Tracked by gid (not a bare WAR_FLAG scan) because several WAR_FLAGs
	/// coexist and must be told apart. Serialized for lockstep determinism alongside
	/// flagPosture.
	OffenseWave offenseWaves[MAX_OFFENSE_FLAGS];

	/// The DEFENSE flag SET (multi-point defense): up to CORTEX_MAX_DEFENSE_FLAGS
	/// persistent defense flags, one per distinct building under fire (obs.defenseTargets[]),
	/// each recalling the home reserve to its own threatened point. Each slot carries its
	/// OWN createCooldown (in DefenseFlag), so a pending create in one slot never stalls
	/// another slot's placement or a time-critical recall. Tracked by gid (not a bare
	/// WAR_FLAG scan) because several WAR_FLAGs coexist and must be told apart. Serialized
	/// for lockstep determinism alongside flagPosture.
	DefenseFlag defenseFlags[Cortex::CORTEX_MAX_DEFENSE_FLAGS];

	/// Persisted monotone latch of the highest enemy-warrior ATTACK_STRENGTH level ever
	/// observed. FOW-gated intel from the observation (obs.enemyWarriorLevelVisible),
	/// latched so a visibility lull never resets the war-preparation gate; runtimeed into
	/// obs.enemyWarriorLevelLatched each cycle (the flagPosture runtime pattern) and
	/// serialized for lockstep determinism.
	Sint32 enemyWarriorLevelSeen;

	/// Position of the forward inn / hospital AICortex last ORDERED (-1 == none
	/// tracked). Set in translateActionBuildForward when the OrderCreate is actually
	/// emitted; reconciled each cycle in getOrder() against the live buildings to runtime
	/// obs.forwardInnUnderway/forwardHealUnderway (the double-order guard) and cleared
	/// once the site finishes (the finished inn opens the envelope via supportDist),
	/// is destroyed, or its build cooldown lapses with no site. This replaces the old
	/// proximity heuristic — a tracked position never false-positives on an unrelated
	/// economy food/heal site. Serialized for lockstep determinism.
	Sint32 forwardInnX, forwardInnY;
	Sint32 forwardHealX, forwardHealY;

	/// Tick the attack-range gate began BINDING (army wants to attack, every target
	/// out of the support envelope); 0 == not binding. Advanced/reset each cycle in
	/// getOrder() and runtimeed as obs.rangeGateWaived once the bind outlives
	/// attackRangeGraceTicks — the grace-timeout that stops a never-ordered "possible"
	/// forward base from holding the gate shut forever. Serialized for lockstep
	/// determinism.
	Sint32 rangeGateBindingSince;

	/// Offense-hold hysteresis state (RAM-only, persisted symmetrically). The posture
	/// the flags are currently committed to, and the tick until which an OFFENSE
	/// commitment is protected from a minor-harassment defensive recall. AICortex OWNS
	/// this state: it is MUTATED only here, as an execution side-effect when flags are
	/// (re)placed. The hold-vs-recall DECISION lives in the policy
	/// (CortexPolicy::scoreDefense), which READS these through the observation
	/// (obs.flagPosture / obs.offenseHoldUntil, runtimeed each cycle before decide()).
	/// flagPosture is one of FlagPosture; offenseHoldUntil == 0 means no hold is active.
	int flagPosture;
	int offenseHoldUntil;

	/// Per-game food open-margin N: the first N rows of food nearest the harvest
	/// source stay unpainted; the checkerboard starts at depth N+1. Drawn ONCE via
	/// the controller stream on the first decision cycle (sentinel -1 = not yet drawn) and then
	/// persisted (NOT redrawn on load) so same-seed replays stay byte-identical.
	/// The draw consumes one AI random value, advancing this controller's stream, so this
	/// is replay-relevant (validated against the deterministic harness).
	Sint32 wheatOpenMargin;

	/// Per-inn post-build settle clock: maps an inn's Building::gid to the game tick
	/// at which Cortex FIRST observed it finished. The decision cycle stamps
	/// obs.trackedInns[i].ticksSinceFinished = now - firstSeen so the policy's
	/// worker-tuning loop can hold a fresh inn at its as-built worker count for
	/// CORTEX_INN_TUNE_DELAY_TICKS (it starts at an empty 0/10 buffer and must not be
	/// worker-spiked before its first haulers fill it). Keyed by gid (deterministic);
	/// never iterated to PRODUCE an order, only for keyed lookup/insert/prune, so
	/// std::map order does not affect lockstep. Persisted in version 101 saves.
	std::map<Uint16, Sint32> innFinishedTick;

	/// Orphan-sweep settle window: maps each currently-UNOWNED own WAR_FLAG's gid to the
	/// game tick it was FIRST observed unowned. sweepOrphanWarFlags deletes a flag only
	/// once it has been unowned across two consecutive decision cycles (firstSeen tick is
	/// older than this cycle's), so a flag transiently untracked between its OrderCreate
	/// and rediscoverFlag's latch is spared — only a truly orphaned flag (its slot torn
	/// down mid-create) is swept. Keyed lookup only; the OrderDeletes are produced by
	/// iterating team->virtualBuildings (insertion order, deterministic), so std::map order
	/// never affects lockstep. Persisted so loading retains the settle window.
	std::map<Uint16, Sint32> unownedFlagSeen;

	/// One-shot guard for the start-of-game swarm worker kickstart
	/// (SWARM_START_WORKERS): set once the starting swarm has been jumped to its
	/// baseline hauler count. Persisted so loading does not repeat the kickstart.
	bool swarmKickstarted;

	/// Orders awaiting emission, one popped per getOrder() call.
	std::queue<std::shared_ptr<Order> > orderQueue;

	/// DIAGNOSTIC ONLY (not serialized, never read by the policy, emits no Order).
	/// One-shot guard so the under-attack state dump fires only the FIRST decision
	/// cycle on which the colony is taking fire. Gated behind the CORTEX_DUMP_ATTACK
	/// env var; pure read of the observation + snapshot team state for owner publication, so
	/// it cannot perturb the sync stream. RAM-only; never affects simulation state.
	bool attackDumped;
	/// Print the under-attack characterization (scouting / economy / timing / enemy)
	/// to stderr. Diagnostic; does not touch RNG, orders, or any persisted state.
	void dumpAttackState(const Cortex::CortexObservation& obs) const;

	/// Buffer training rows for owner publication to GLOB2_CORTEX_TRACE.team<N>.csv.
	/// Reads only the scoped observation and the computed action.
	void dumpWorkerTrace(const Cortex::CortexObservation& obs,
	                     const Cortex::CortexAction& tune);

	/// Buffer the decision feature/class trace for GLOB2_CORTEX_DECIDE_TRACE.
	void dumpDecideTrace(const Cortex::CortexObservation& obs,
	                     const Cortex::DecideTrace& trace);

	/// Buffer inn/restock/production-tier diagnostics for GLOB2_CORTEX_INN_TRACE.
	void dumpInnTrace(const Cortex::CortexObservation& obs,
	                  const Cortex::CortexAction& tune);
};
