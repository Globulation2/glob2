// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2006 Bradley Arsenault

#pragma once

#include "shared_runtime/Runtime.h"
#include "AINicowarTuning.h"
#include "ConfigFiles.h"

///This class represents the configurable strategy that Nicowar will take. It uses the same algorithms,
///but this can allow it to fine tune the variables in those algorithms
class NicowarStrategy : LoadableFromConfigFile
{
public:
	///Constructs a new NicowarStrategy with all values zeroed. Real values
	///come from loadFromConfigFile; every live strategy is copy-constructed
	///from the fully-loaded default entry (see ConfigVector::addBlock), so
	///the zeros are never read — they only guard against a future field
	///being added without a matching key in data/nicowar.default.txt.
	NicowarStrategy() = default;

	///Loads the strategy from the configuration block
	void loadFromConfigFile(const ConfigBlock *configBlock);
	
	///Returns the name of the strategy
	std::string getStrategyName();
	
	///Sets the name of the strategy
	void setStrategyName(const std::string& name);
	
	///Maximum number of units for the growth phase
	int growth_phase_unit_max = 0;
	///Minimum number of units for the skilled work phase
	int skilled_work_phase_unit_min = 0;
	///Minimum number of schools to activate the upgrading phase 1
	int upgrading_phase_1_school_min = 0;
	///Minimum number of units to activate the upgrading phase 1
	int upgrading_phase_1_unit_min = 0;
	///Minimum number of trained workers to activate the upgrading phase 1
	int upgrading_phase_1_trained_worker_min = 0;
	///Minimum number of level 2/3 schools to activate the upgrading phase 2
	int upgrading_phase_2_school_min = 0;
	///Minimum number of units to activate the upgrading phase 2
	int upgrading_phase_2_unit_min = 0;
	///Minimum number of trained workers to activate the upgrading phase 2
	int upgrading_phase_2_trained_worker_min = 0;
	///The minimum warrior level to be considered "trained" for the war preparation and war phases, starting at 0
	int minimum_warrior_level_for_trained = 0;
	///Minimum number of units to activate the war preparation phase
	int war_preparation_phase_unit_min = 0;
	///Maximum number of barracks to activate the war preparation phase
	int war_preparation_phase_barracks_max = 0;
	///Maximum number of trained warriors to activate the war preparation phase
	int war_preparation_phase_trained_warrior_max = 0;
	///Minimum number of trained warriors to activate the war phase
	int war_phase_trained_warrior_min = 0;
	///Minimum number of units to activate the fruit phase
	int fruit_phase_unit_min = 0;
	///Minimum percentage of starving units that can't find an Inn to eat at to trigger the starvation recovery phase
	int starvation_recovery_phase_starving_no_inn_min_percent = 0;
	///How many un-fed units to trigger placing a starving recovery Inn when in the starving recovery phase
	int starving_recovery_phase_unfed_per_new_inn = 0;
	///Minimum, percentage of workers free to trigger the no workers phase
	int no_workers_phase_free_worker_minimum_percent = 0;
	///How many units a level 1 Inn can feed, used to determine when more inns are needed
	int level_1_inn_units_can_feed = 0;
	///How many units a level 2 Inn can feed, used to determine when more inns are needed
	int level_2_inn_units_can_feed = 0;
	///How many units a level 3 Inn can feed, used to determine when more inns are needed
	int level_3_inn_units_can_feed = 0;
	///How many units it takes to constitute a new swarm when in the growth phase
	int growth_phase_units_per_swarm = 0;
	///How many units it takes to constitute a new swarm when not in the growth phase
	int non_growth_phase_units_per_swarm = 0;
	///The maximum number of swarms that can be made during the growth phase
	int growth_phase_maximum_swarms = 0;
	///The number of racetracks to be built during the skilled work phase
	int skilled_work_phase_number_of_racetracks = 0;
	///The number of swimming pools to be built during the skilled work phase
	int skilled_work_phase_number_of_swimmingpools = 0;
	///The number of schools to be built during the skilled work phase
	int skilled_work_phase_number_of_schools = 0;
	///The number of barracks to be built during the war preparation phase
	int war_preparation_phase_number_of_barracks = 0;
	///The base number of hospitals to build, these are only built when there is first demand
	int base_number_of_hospitals = 0;
	///The number of warriors required to trigger another hospital
	int war_preparation_phase_warriors_per_hospital = 0;
	///The base number of construction sites that can go at once
	int base_number_of_construction_sites = 0;
	///The number of extra construction sites when in starving recovery mode (to facilitate extra inns to be constructed0
	int starving_recovery_phase_number_of_extra_construction_sites = 0;
	///The amount of wheat that triggers a level 1 inn to increase the units working
	int level_1_inn_low_wheat_trigger_amount = 0;
	///The amount of wheat that triggers a level 2 inn to increase the units working
	int level_2_inn_low_wheat_trigger_amount = 0;
	///The amount of wheat that triggers a level 3 inn to increase the units working
	int level_3_inn_low_wheat_trigger_amount = 0;
	///The number of units to assign to an level 1 inn when its wheat is above the trigger
	int level_1_inn_units_assigned_normal_wheat = 0;
	///The number of units to assign to an level 2 inn when its wheat is above the trigger
	int level_2_inn_units_assigned_normal_wheat = 0;
	///The number of units to assign to an level 3 inn when its wheat is above the trigger
	int level_3_inn_units_assigned_normal_wheat = 0;
	///The number of units to assign to an level 1 inn when its wheat is below the trigger
	int level_1_inn_units_assigned_low_wheat = 0;
	///The number of units to assign to an level 2 inn when its wheat is below the trigger
	int level_2_inn_units_assigned_low_wheat = 0;
	///The number of units to assign to an level 3 inn when its wheat is below the trigger
	int level_3_inn_units_assigned_low_wheat = 0;
	///The base number of units to assign to a swarm, which is doubled/halved based on conditions
	int base_swarm_units_assigned = 0;
	///The amount of resources that caused a swarm to double its units assigned if it goes below this amount
	int base_swarm_low_wheat_trigger_amount = 0;
	///The percentage of units that are hungry/starving that will cause swarms to halve the number of units assigned, (more wheat to inns)
	int base_swarm_hungry_reduce_trigger_percent = 0;
	///The ratio of workers assigned to swarms during the growth phase
	int growth_phase_swarm_worker_ratio = 0;
	///The ratio of workers assigned to swarms when not in the growth phase
	int non_growth_phase_swarm_worker_ratio = 0;
	///The base number of explorers needed
	int base_number_of_explorers = 0;
	///The extra number of explorers needed during the fruit phase
	int fruit_phase_extra_number_of_explorers = 0;
	///The base ratio of explorers to use when explorers are needed
	int base_swarm_explorer_ratio = 0;
	///The warrior ratio during the war preparation phase
	int war_preparation_swarm_warrior_ratio = 0;
	///The percentage of total population that should be dedicated to defense explorers, when they are created
	int defense_explorer_population_percent = 0;
	///The number of explorers to produce for attacks
	int offense_explorer_number = 0;
	///The minimum number of trained explorers before it will start attacking with them
	int offense_explorer_minimum = 0;
	///The number of explorer attack flags to do at once
	int offense_explorer_flag_number = 0;
	///The number of explorers per explorer attack flag
	int offense_explorer_flag_assigned = 0;
	///The random chance that, when selecting the type of level 1 building to upgrade, it will choose an inn
	int upgrading_phase_1_inn_chance = 0;
	///The random chance that, when selecting the type of level 1 building to upgrade, it will choose an hospital
	int upgrading_phase_1_hospital_chance = 0;
	///The random chance that, when selecting the type of level 1 building to upgrade, it will choose a racetrack
	int upgrading_phase_1_racetrack_chance = 0;
	///The random chance that, when selecting the type of level 1 building to upgrade, it will choose an swimming pool
	int upgrading_phase_1_swimmingpool_chance = 0;
	///The random chance that, when selecting the type of level 1 building to upgrade, it will choose a barracks
	int upgrading_phase_1_barracks_chance = 0;
	///The random chance that, when selecting the type of level 1 building to upgrade, it will choose a school
	int upgrading_phase_1_school_chance = 0;
	///The random chance that, when selecting the type of level 1 building to upgrade, it will choose a tower
	int upgrading_phase_1_tower_chance = 0;
	///The random chance that, when selecting the type of level 2 building to upgrade, it will choose an inn
	int upgrading_phase_2_inn_chance = 0;
	///The random chance that, when selecting the type of level 2 building to upgrade, it will choose an hospital
	int upgrading_phase_2_hospital_chance = 0;
	///The random chance that, when selecting the type of level 2 building to upgrade, it will choose a racetrack
	int upgrading_phase_2_racetrack_chance = 0;
	///The random chance that, when selecting the type of level 2 building to upgrade, it will choose an swimming pool
	int upgrading_phase_2_swimmingpool_chance = 0;
	///The random chance that, when selecting the type of level 2 building to upgrade, it will choose a barracks
	int upgrading_phase_2_barracks_chance = 0;
	///The random chance that, when selecting the type of level 2 building to upgrade, it will choose a school
	int upgrading_phase_2_school_chance = 0;
	///The random chance that, when selecting the type of level 2 building to upgrade, it will choose a tower
	int upgrading_phase_2_tower_chance = 0;
	///The number of units to assign to an upgrade for upgrading phase level 1
	int upgrading_phase_1_units_assigned = 0;
	///The number of units to assign to an upgrade for upgrading phase level 2
	int upgrading_phase_2_units_assigned = 0;
	///The number of level 1 or higher units needed to count for upgrading one more building
	int upgrading_phase_1_num_units = 0;
	///The number of level 1 or higher units needed to count for upgrading one more building
	int upgrading_phase_2_num_units = 0;
	///The number of units to assign to a war flag attacking an enemy building
	int war_phase_war_flag_units_assigned = 0;
	///The number of flags to attack with at any one time
	unsigned war_phase_num_attack_flags = 0;
private:
	///The name of the strategy.
	std::string name;
};

///This class is meant to load a Nicowar Strategy
class NicowarStrategyLoader : ConfigVector<NicowarStrategy>
{
public:
	///Loads all strategies from the strategy files
	NicowarStrategyLoader();
	
	///This chooses a strategy at random
	NicowarStrategy chooseRandomStrategy(MersenneTwister& random);
	
	///This chooses a strategy with a particular name
	NicowarStrategy getParticularStrategy(const std::string& name);
};

/// Sentinel value for `NewNicowar::target` meaning "no enemy team
/// currently targeted." `target` is a Sint8/int that otherwise holds an
/// enemy team index. Used at init, when a chosen target dies/becomes
/// unreachable, and as a guard before launching attacks.
/// Distinct from AINames::AI_UNKNOWN_NAME and from the Runtime
/// enemy_building_iterator wildcard `-1` args (those are kept literal).
static const int AI_NICOWAR_NO_TARGET = -1;

///Nicowar is a new powerhouse AI for Globulation 2
class NewNicowar : public AISharedRuntime::RuntimeAI
{
public:
  Uint64 retainedQueryVectorBytes() const noexcept override
  {
      return Uint64(defenseScanScratch.counts.capacity() + defenseScanScratch.buildingGID.capacity()
          + defenseScanScratch.unitGID.capacity()) * sizeof(Uint16);
  }
  void captureTelemetry() override;
  const std::vector<AITelemetry::Field> &telemetrySchema() const override
  {
	  return AITelemetry::schema(5);
  }
	NewNicowar();
	bool load(GAGCore::InputStream *stream, Player *player, Sint32 versionMinor);
	void save(GAGCore::OutputStream *stream);
	void tick(AISharedRuntime::Runtime& runtime);
	void handle_message(AISharedRuntime::Runtime& runtime, const std::string& message);
private:
	// Every scan rebuilds these planes before reading them. Only capacities
	// persist between polls, owned by this controller rather than its worker.
	struct DefenseScanScratch
	{
		std::vector<Uint16> counts, buildingGID, unitGID;
	} defenseScanScratch;
	///This function loads up all available strategies, and selects one at random.
	///As such, Nicowar may be going war-rush style, or it may try a longer game.
	void selectStrategy(AISharedRuntime::Runtime& runtime);

	///This is the basic, variable strategy that Nicowar will be taking at all times
	NicowarStrategy strategy;
    std::shared_ptr<NicowarStrategyLoader> strategyDefinitions; // Loaded on owner, chosen on worker.

	///These are all of the various buildings that can be constructed. Note that,
	///while their may be more than one for a particular type of building, the
	///different orders have different properties for deciding where to place the
	///building
	enum BuildingPlacement
	{
		RegularInn,
		StarvingRecoveryInn,
		RegularSwarm,
		RegularRacetrack,
		RegularSwimmingpool,
		RegularSchool,
		RegularBarracks,
		RegularHospital,
		PlacementSize,
	};

	///This function is called at the very beginning of the game,
	///to initialize the existing buildings with the right amount of units
	void initialize(AISharedRuntime::Runtime& runtime);

	///This function is called periodically to choose the strategies
	///(called phases) that will be used at that time
	void check_phases(AISharedRuntime::Runtime& runtime);
	///During the growth phase, the object of the game is the fast growth of economy.
	///Swarms become a big priority, so does gaining territory and exploration.
	bool growth_phase;
	///During the skilled work phase, Nicowar tries to better the skills of its workers
	///by building 1 Racetrack, 1 Swimming pool and 2 Schools
	bool skilled_work_phase;
	///During the upgrading_phase_1 , Nicowar tries to upgrade its level 1 buildings in small numbers.
	bool upgrading_phase_1;
	///During the upgrading_phase_2 , Nicowar tries to upgrade its level 2 buildings in small numbers.
	bool upgrading_phase_2;
	///During the war preparation phase, warriors are made and barracks are prioritized
	bool war_preparation;
	///During the war phase, the enemies are attacked
	bool war;
	///During the fruit phase, explorers are stationed on fruit trees and Nicowar starts converting
	///enemy units
	bool fruit_phase;
	///During the starving recovery phase, swarms are turned off and extra inns may be created
	bool starving_recovery;
	///During the no worker phase, no workers are created, which occurs if there are too many free
	bool no_workers_phase;
	///During this phase, the colonies workers are "able to swim"
	bool can_swim;
	///During this phase, Nicowar tries to construct many explorers, in case its attacked by enemy explorers
	bool defend_explorers;
	///During this phase, Nicowar tries to construct many explorers so that it can launch an attack with them
	bool explorer_attack_preparation_phase;
	///During this phase, Nicowar will actively attack its opponents with explorers
	bool explorer_attack_phase;


	///This function decides how many buildings need to be constructed (and with what properties
	///their location must be picked with) and adds them to a queue. Most of the decisions are
	///made using statistics and depend on the phases that are activated
	void queue_buildings(AISharedRuntime::Runtime& runtime);
	///This function decides how many Inns and of what placements need construction and adds
	///them to the queue
	void queue_inns(AISharedRuntime::Runtime& runtime);
	///This function decides how many swarms are needed and queues them up
	void queue_swarms(AISharedRuntime::Runtime& runtime);
	///This function decides how many racetracks are needed and queues them up.
	void queue_racetracks(AISharedRuntime::Runtime& runtime);
	///This function decides how many swimming pools are needed and queues them up.
	void queue_swimmingpools(AISharedRuntime::Runtime& runtime);
	///This function decides how many schools are needed and queues them up.
	void queue_schools(AISharedRuntime::Runtime& runtime);
	///This function decides how many barracks are needed and queues them up.
	void queue_barracks(AISharedRuntime::Runtime& runtime);
	///This function decides how many hospitals are needed and queues them up.
	void queue_hospitals(AISharedRuntime::Runtime& runtime);
	///This counts how many StarvingRecoveryInn's there are under construction
	int starving_recovery_inns;

	///This function starts construction on buildings that are queued for construction. Its careful
	///not to construct too much or too little at once
	void order_buildings(AISharedRuntime::Runtime& runtime);
	///This function starts construction of a RegularInn, and returns the ID code
	int order_regular_inn(AISharedRuntime::Runtime& runtime);
	///This function starts construction of a RegularSwarm, and returns the ID code
	int order_regular_swarm(AISharedRuntime::Runtime& runtime);
	///This function starts construction of a RegularSwarm, and returns the ID code
	int order_regular_racetrack(AISharedRuntime::Runtime& runtime);
	///This function starts construction of a RegularSwarm, and returns the ID code
	int order_regular_swimmingpool(AISharedRuntime::Runtime& runtime);
	///This function starts construction of a RegularSwarm, and returns the ID code
	int order_regular_school(AISharedRuntime::Runtime& runtime);
	///This function starts construction of a RegularBarracks, and returns the ID code
	int order_regular_barracks(AISharedRuntime::Runtime& runtime);
	///This function starts construction of a RegularHospital, and returns the ID code
	int order_regular_hospital(AISharedRuntime::Runtime& runtime);
	///This integer stores the total number of buildings that are currently being constructed
	int buildings_under_construction;
	///This integer stores the number of buildings being constructed based on their placement id,
	///it counts buildings that are queued to be constructed but have not been started yet
	int buildings_under_construction_per_type[PlacementSize];
	///This is the queue for buildings that have yet to be processed for construction
	std::list<BuildingPlacement> placement_queue;
	///This is the queue for buildings that are going to be constructed
	std::list<BuildingPlacement> construction_queue;


	///This function updates all of the buildings that are not under construction.
	void manage_buildings(AISharedRuntime::Runtime& runtime);
	///This function updates the units assigned to a particular Inn.
	///Using the messaging system, it is called after the completion
	///of a new Inn and periodically thereafter
	void manage_inn(AISharedRuntime::Runtime& runtime, int id);
	///This function updated the units assigned and the creation
	///ratios of a particular Swarm. Its done after the completion
	///of a new swarm and periodically thereafter
	struct ProductionDemand { std::array<int,3> ratios{}; int workers=0; };
	ProductionDemand manage_swarm(AISharedRuntime::Runtime& runtime, int id);


	///This function chooses the type of level 1 building to be upgraded randomly
	///(but weighted in favor of certain building depending on the phase)
	int choose_building_upgrade_type_level1(AISharedRuntime::Runtime& runtime);
	///This function chooses the type of level 2 building to be upgraded randomly
	///(but weighted in favor of certain building depending on the phase)
	int choose_building_upgrade_type_level2(AISharedRuntime::Runtime& runtime);
	///This function is a generic version of the above functions
	int choose_building_upgrade_type(AISharedRuntime::Runtime& runtime, int level, int inn_ratio, int hospital_ratio, int racetrack_ratio, int swimmingpool_ratio, int barracks_ratio, int school_ratio, int tower_ratio);
	///This function chooses a building of the given type and level to be upgraded.
	int choose_building_for_upgrade(AISharedRuntime::Runtime& runtime, int type, int level);
	///This function starts upgrading buildings if the upgrading_phase is active.
	void upgrade_buildings(AISharedRuntime::Runtime& runtime);


	///This function chooses an enemy building to be destroyed. It returns -1 if there are no accessible buildings
	int choose_building_to_attack(AISharedRuntime::Runtime& runtime);
	///This function starts an attack on another enemy building
	void attack_building(AISharedRuntime::Runtime& runtime);
	///This function controls the attacking of enemies, such as how many flags are active at one time
	void control_attacks(AISharedRuntime::Runtime& runtime);
	///This function chooses the enemy team to target
	void choose_enemy_target(AISharedRuntime::Runtime& runtime);
	///This function digs out an enemy building that is surrounded by resources.
	///It will also cause Nicowar to dig itself out in certain situation
	///Returns true if there are buildings that it can dig out, false otherwise
	bool dig_out_enemy(AISharedRuntime::Runtime& runtime);

	///This integer stores the currently targetted enemy
	int target;
	///This integer stores whether a building is being dug out at the current moment
	bool is_digging_out;
	///This vector stores the ID's for all current war flags
	std::vector<int> attack_flags;
	
	
	///This function calculates the positions of defense flags
	void compute_defense_flag_positioning(AISharedRuntime::Runtime& runtime);
	///This function adds the specific value to the counts around the given pos, used in compute_defense_flag_positioning
	void modify_points(Uint16* counts, int w, int h, int x, int y, int dist, int value, std::list<int>& locations);
	///This vector stores the ID's for all current defense flags
	std::vector<int> defense_flags;

	///This function calculates the positions of explorer flags for explorer flag attacks
	void compute_explorer_flag_attack_positioning(AISharedRuntime::Runtime& runtime);
	///This vector stores the list of explorer attack flags
	std::vector<int> explorer_attack_flags;

	///This function updates the restricted areas for farming
	void update_farming(AISharedRuntime::Runtime& runtime);

	///This function puts exploration flags on fruit trees once the fruit phase
	///has been activated.
	void update_fruit_flags(AISharedRuntime::Runtime& runtime);
	///This function updates the alliances with opponents once the fruit phase
	///has been activated.
	void update_fruit_alliances(AISharedRuntime::Runtime& runtime);
	///This variable tells whether their are exploration flags on the fruit trees yet or not
	bool exploration_on_fruit;


	int timer;
};


