#include <functional>
// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#pragma once

#include "GAGSys.h"
#include "CursorManager.h"
#include "RenderFramePacer.h"
#include "RendererSelection.h"
#include "RenderResources.h"
#include "GameplayRecording.h"
#include "SkinAtlasCache.h"
#include "SpriteRenderAtlas.h"
#include <AssetLoader.h>
#include <array>
#include <map>
#include <utility>
#include <vector>
#include <string>
#include <iostream>
#include <valarray>
#include <memory>
#include <optional>
#include <cstdint>

#include <set>
#include <tuple>
#include <list>
#include <unordered_map>

#include <SDL3/SDL.h>


namespace GAGCore
{
    class RenderBatch;
    class SpriteLoad;
    struct SkinMesh;
    struct SkinMeshRequest;

    class RenderBackend;
    struct DrawPacket;
    struct DeviceSkinState;
    class RenderDevice;
    class RenderResources;
    class SoftwareFramePresenter;
    struct RenderOperations;
	//! Color is 4 bytes big but provides easy access to components
	struct Color
	{
		//! Typical useful alpha values pre-defined
		enum Alpha
		{
			ALPHA_TRANSPARENT = 0, //!< constant for transparent alpha
			ALPHA_OPAQUE = 255 //!< constant for opaque alpha
		};
		
		Uint8 r, g, b, a; //!< component of the color
		
		//! Constructor. Default color is opaque black
		Color() { r = g = b = 0; a = ALPHA_OPAQUE; }
		//! Constructor from components
		Color(Uint8 r, Uint8 g, Uint8 b, Uint8 a = ALPHA_OPAQUE) { this->r = r; this->g = g; this->b = b; this->a = a; }
		
		//! Return HSV values in pointers
		void getHSV(float *hue, float *sat, float *lum);
		//! Set color from HLS, alpha untouched
		void setHSV(float hue, float sat, float lum);
		
		//! pack components in a 32 bits int given SDL screen values
		Uint32 pack() const;
		//! unpack from a 32 bits int given SDL screen values
		void unpack(const Uint32 packedValue);
		
		//! comparaison for inequality
		bool operator<(const Color &o) const { return pack() < o.pack(); }
		//! comparaison for equality
		bool operator==(const Color &o) const { return pack() == o.pack(); }
		
		//! return a new color with a different alpha value
		Color applyAlpha(Uint8 _a) const { Color c = *this; c.a = _a; return c; }
		//! return a new color resulting of the multiplication by alpha
		Color applyMultiplyAlpha(Uint8 _a) const ;
		
		static Color black; //!< black color (0,0,0)
		static Color white; //!< black color (255,255,255)
	};
	
	//! Deprecated, for compatibility only. Eventually, all Color32 should be removed or changed to Color
	typedef Color Color32;
	
	class Sprite;
	
	//! Font with a given foundry, shape and color
	class Font
	{
	public:
		//! Shape of the font
		enum Shape
		{
			STYLE_NORMAL = 0x00, //!< normal fond
			STYLE_BOLD = 0x01, //!< bold font
			STYLE_ITALIC = 0x02, //!< italic font
			STYLE_UNDERLINE = 0x04, //!< underlined font
		};
		
		//! Style of the font, i.e. a shape and a color
		struct Style
		{
			Shape shape; //!< shape of this style
			Color color; //!< color of this style
			
			//! Constructor. Default is normal with white opaque color
			Style() { shape = STYLE_NORMAL; color = Color::white; }
			
			//! Constructor from shape and color
			Style(Shape _shape, Color _color) :
				shape(_shape),
				color(_color)
			{
			}
			
			//! Constructor from shape and color component
			Style(Shape _shape, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE) :
				shape(_shape),
				color(r, g, b, a)
			{
			}
			
			//! inequality comparaison
			bool operator<(const Style &o) const
			{
				if (color == o.color)
					return shape < o.shape;
				else
					return color < o.color;
			}
		};
	
	public:
		//! Destructor
		virtual ~Font() { }

		//! Whether every character of this UTF-8 string has a glyph in this font
		virtual bool hasGlyphsFor(const std::string &utf8Text) { return true; }

		// width and height
		virtual int getStringWidth(const std::string string) = 0;
		virtual int getStringWidth(const std::string string, int len);
		virtual int getStringWidth(const int i);
		virtual int getStringHeight(const std::string string) = 0;
		virtual int getStringHeight(const std::string string, int len);
		virtual int getStringHeight(const int i);
	
		// Style and color
		virtual void setStyle(Style style) = 0;
		virtual Style getStyle(void) const = 0;
		virtual void pushStyle(Style style) = 0;
		virtual void popStyle(void) = 0;
		
	protected:
		friend class DrawableSurface;
		virtual void drawString(DrawableSurface *Surface, int x, int y, int w, const std::string text, Uint8 alpha) = 0;
		virtual void drawString(DrawableSurface *Surface, float x, float y, float w, const std::string text, Uint8 alpha) = 0;
	};

	// Texture dimensions
	struct TextureInfo
	{
		//! which animation or texture atlas this surface is part of.
		Sprite* sprite = nullptr;
		//! sprite sheet coordinates
		int texX = 0;
		int texY = 0;
		//! width and height of this tile if using atlas
		int w = 0;
		int h = 0;
	};
	
	//! A surface on which we can draw
	class DrawableSurface
	{
	protected:
		friend struct Color;
		friend class GraphicContext;
		friend class Sprite;
        friend class SpriteLoad;
		//! the underlying software SDL surface
		SDL_Surface *sdlsurface;
		// Texture dimensions
		std::optional<TextureInfo> textureInfo;
        Sprite *spriteSource = nullptr;
        std::uint32_t spriteFrame = 0;
		//! The clipping rect, we do not draw outside it
		SDL_Rect clipRect;
		// Content revisions are never consumed by drawing. Each backend remembers
		// its own uploaded revision; raw pixel writes must call markPixelsChanged().
		std::vector<unsigned char> preparedUploadPixels;
        std::vector<AssetImage::Mip> preparedMips;
        std::uint64_t preparedUploadRevision = 0;
		std::uint64_t glUploadedRevision = 0; // Revision uploaded to this surface's legacy GL texture.
        std::uint64_t pixelRevision = 1, opacityRevision = 0;
        static std::uint64_t nextSurfaceIdentity();
        const std::uint64_t surfaceIdentity = nextSurfaceIdentity();
        bool opaquePixels = false;
		bool highResolutionSampling=false;
		//! texture index if GPU (GL) is used
		unsigned int texture=0;
		size_t gpuBytes=0;
		//! texture divisor
		float texMultX, texMultY;
		
	protected:
		//! draw a vertical line. This function is private because it is only a helper one
		void _drawVertLine(int x, int y, int l, const Color& color);
		//! draw a horizontal line. This function is private because it is only a helper one
		void _drawHorzLine(int x, int y, int l, const Color& color);
		
	protected:
		//! Protected constructor, only called by GraphicContext
		DrawableSurface() { sdlsurface = NULL; }
		//! allocate a GPU texture object, optionally initializing legacy padded storage
		void allocateTexture(bool initializeStorage = true);
		//! reset the texture size upon changes
		void initTextureSize(void);
		//! upload surface to GPU
		void uploadToTexture(void);
		//! free texture in GPU for this surface
		void freeGPUTexture(void);
		//! transform any SDL Surface to a GL uploadable one
		SDL_Surface *convertForUpload(SDL_Surface *source);
		
	public:
		// New API
		
		// constructors and destructor
		DrawableSurface(const std::string &imageFileName);
		DrawableSurface(int w, int h);
		DrawableSurface(const SDL_Surface *sourceSurface);
        //! Adopt CPU-prepared ARGB8888 pixels on the renderer thread.
        struct AdoptPixels {};
        DrawableSurface(SDL_Surface *prepared, AdoptPixels, bool allocateGPU = true);
        //! Create an owned renderer surface from prepared CPU data. Exclusive
        //! callers must own the image payload; other callers receive a pixel copy.
        static std::unique_ptr<DrawableSurface> fromAssetImage(const AssetImage& image,
            bool exclusive = false, bool allocateGPU = true);
        void adoptUploadPreparation(const AssetImage& image, bool exclusive = false);
        void prepareTexture();
		DrawableSurface *clone(void);
        DrawableSurface(const DrawableSurface&) = delete;
        DrawableSurface& operator=(const DrawableSurface&) = delete;
		virtual ~DrawableSurface(void);
		
		// modifiers
		virtual void setRes(int w, int h);
		virtual void getClipRect(int *x, int *y, int *w, int *h);
		virtual void setClipRect(int x, int y, int w, int h);
		virtual void setClipRect(void);
		virtual void nextFrame(void) { flushTextPictures(); }
		virtual bool loadImage(const std::string name);
		virtual void shiftHSV(float hue, float sat, float lum);
		
		// accessors
		virtual int getW(void) { if (textureInfo) return textureInfo->w; return sdlsurface->w; }
		virtual int getH(void) { if (textureInfo) return textureInfo->h; return sdlsurface->h; }
		//! The raw software surface, e.g. to hand off to an SDL API that wants one directly
		SDL_Surface *getSDLSurface(void) { return sdlsurface; }
        std::uint64_t lifetimeIdentity() const { return surfaceIdentity; }
        std::uint64_t contentRevision() const { return pixelRevision; }
        virtual void prepareDraw() {}
        void markPixelsChanged() { ++pixelRevision; }
        bool hasOpaquePixels();
		static size_t allocatedTextureBytes();

		virtual int getTexX(void) { if (textureInfo) { return textureInfo->texX; } return 0; }
		virtual int getTexY(void) { if (textureInfo) { return textureInfo->texY; } return 0; }
		
		// capability querying
		virtual bool canDrawStretchedSprite(void) { return false; }
		
		// drawing commands
		virtual void drawPixel(int x, int y, const Color& color);
		virtual void drawPixel(float x, float y, const Color& color);
		
		virtual void drawRect(int x, int y, int w, int h, const Color& color);
		virtual void drawRect(float x, float y, float w, float h, const Color& color);
		
		virtual void drawFilledRect(int x, int y, int w, int h, const Color& color);
		virtual void drawFilledRect(float x, float y, float w, float h, const Color& color);
		
		virtual void drawLine(int x1, int y1, int x2, int y2, const Color& color);
		virtual void drawLine(float x1, float y1, float x2, float y2, const Color& color);
		
		virtual void drawCircle(int x, int y, int radius, const Color& color);
		virtual void drawCircle(float x, float y, float radius, const Color& color);
		
		virtual void drawSurface(int x, int y, DrawableSurface *surface, Uint8 alpha = Color::ALPHA_OPAQUE);
		virtual void drawSurface(float x, float y, DrawableSurface *surface, Uint8 alpha = Color::ALPHA_OPAQUE);
		
		virtual void drawSurface(int x, int y, int w, int h, DrawableSurface *surface, Uint8 alpha = Color::ALPHA_OPAQUE);
		virtual void drawSurface(float x, float y, float w, float h, DrawableSurface *surface, Uint8 alpha = Color::ALPHA_OPAQUE);
		
		virtual void drawSurface(int x, int y, DrawableSurface *surface, int sx, int sy, int sw, int sh, Uint8 alpha = Color::ALPHA_OPAQUE);
		virtual void drawSurface(float x, float y, DrawableSurface *surface, int sx, int sy, int sw, int sh, Uint8 alpha = Color::ALPHA_OPAQUE);
		
		virtual void drawSurface(int x, int y, int w, int h, DrawableSurface *surface, int sx, int sy, int sw, int sh,  Uint8 alpha = Color::ALPHA_OPAQUE);
		virtual void drawSurface(float x, float y, float w, float h, DrawableSurface *surface, int sx, int sy, int sw, int sh, Uint8 alpha = Color::ALPHA_OPAQUE);
		
		void drawSprite(int x, int y, Sprite *sprite, unsigned index = 0, Uint8 alpha = Color::ALPHA_OPAQUE);
		void drawSprite(float x, float y, Sprite *sprite, unsigned index = 0, Uint8 alpha = Color::ALPHA_OPAQUE);
		
		void drawSprite(int x, int y, int w, int h, Sprite *sprite, unsigned index = 0, Uint8 alpha = Color::ALPHA_OPAQUE);
		void drawSprite(float x, float y, float w, float h, Sprite *sprite, unsigned index = 0, Uint8 alpha = Color::ALPHA_OPAQUE);
		
		void drawString(int x, int y, Font *font, const std::string &msg, int w = 0, Uint8 alpha = Color::ALPHA_OPAQUE);
		void drawString(float x, float y, Font *font, const std::string &msg, float w = 0, Uint8 alpha = Color::ALPHA_OPAQUE);
		

		//! Draw an alpha map of size mapW, mapH using a specific color at coordinates x, y using cells of size cellW, cellH
		virtual void drawAlphaMap(const std::valarray<float> &map, int mapW, int mapH, int x, int y, int cellW, int cellH, const Color &color);
		virtual void drawAlphaMap(const std::valarray<unsigned char> &map, int mapW, int mapH, int x, int y, int cellW, int cellH, const Color &color);
		
		// old API, deprecated, do not use. It is only there for compatibility with existing code
		virtual void drawPixel(int x, int y, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawRect(int x, int y, int w, int h, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawFilledRect(int x, int y, int w, int h, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawVertLine(int x, int y, int l, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawVertLine(int x, int y, int l, const Color& color);
		virtual void drawHorzLine(int x, int y, int l, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawHorzLine(int x, int y, int l, const Color& color);
		virtual void drawLine(int x1, int y1, int x2, int y2, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawCircle(int x, int y, int radius, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawString(int x, int y, Font *font, int i);
		
		// This is for translation text shot code, it works by trapping calls to the getString function in the translation StringTables,
		// then later in drawString, if we are drawing one of the found strings returned by StringTable, it will add it to the list of
		// rectangles that represent found texts. Just before the next frame begins to draw, all of the rectangle pictures are flushed
		// into bmp's. This is done because we want the translation pictures to be done when *all* of the screen is already drawn (when
		// we flushed into a bmp directly from drawString, sometimes the screen was only partially drawn, and the resulting pictures
		// would be hard to interpret)
		class SRectangle
		{
		public:
			SRectangle(int x, int y, int w, int h) : x(x), y(y), w(w), h(h) {}
			int x, y, w, h;
		};
		// This holds texts requested by the toolkit, but not yet drawn to the screen
		static std::map<std::string, std::string> texts;
		// This holds texts already drawn to the screen and detected, so that pictures aren't taken twice, which would lag the game badly
		static std::set<std::string> wroteTexts;
		// This holds detected texts that will be printed on the next flush
		static std::vector<std::tuple<SRectangle, std::string, GAGCore::DrawableSurface*> > drawSquares;
		// This holds the directory the pictures will be stored in. The system is disabled if this string is empty.
		static std::string translationPicturesDirectory;
		// This flushes all of the detected texts, making bmp pictures
		static void flushTextPictures();
		// This prints out information on all of the texts that where requested but not detected
		static void printFinishingText();
	};

	//! The description of a video mode
	typedef std::vector<SDL_DisplayMode> VideoModes;
	
	//! A GraphicContext is a DrawableSurface that represent the main screen of the application.
	class GraphicContext:public DrawableSurface
	{
        RendererSwitchStatus backendStatus;
        std::optional<RendererBackend> nextBackend;
        bool changingBackend = false, nextBackendPersists = true, switchPersists = true, recoveringBackend = false;
        RendererCapabilities retiringCapabilities;
        Uint64 switchStarted = 0;
        std::unique_ptr<SDL_Surface, decltype(&SDL_DestroySurface)> transitionPixels{nullptr, SDL_DestroySurface};
        std::function<void(RendererBackend)> backendPreferenceCallback;
        static std::optional<RendererBackend> initialBackend;
        RendererBackend automaticBackend = RendererBackend::Software;
        bool awaitingBrowserSurface = false;
        bool awaitingDevicePreparation = false, awaitingSwitchCapture = false;
        RendererBackend switchingFrom = RendererBackend::Software, switchingTo = RendererBackend::Software;
        int switchWindowX = SDL_WINDOWPOS_UNDEFINED, switchWindowY = SDL_WINDOWPOS_UNDEFINED;
        void retirePresentationSurface();
        void applyQueuedBackend();
        void captureBackendFrame();
        void completeBackendFrame();
        void recoverPresentationDevice();
        void handleDeviceFailure(const std::string &);
        void resetDeviceSkinState() { deviceSkinState.reset(); }
        void invalidateDeviceSkinTiles();
        void prepareDeviceSkinMeshes(const std::vector<SkinMeshRequest> &);
        bool drawDeviceSkinMesh(const SkinMeshRequest &, float, float, float, float, DrawableSurface *, Uint8);
        bool readDeviceSkinMesh(const SkinMeshRequest &, std::vector<std::uint8_t> &);
        void captureScreenshot();
        bool saveScreenshot(SDL_Surface &, const std::string &);
        static std::string rendererShaderDirectory();
    public:
        RenderDevice *renderDevice() const { return renderer == deviceRenderer.get() ? presentationDevice.get() : nullptr; }
        RenderResources *renderResources() const { return deviceResources.get(); }
        std::shared_ptr<RenderResources> renderResourceOwner() const { return deviceResources; }
        bool beginDeviceTarget(TextureSnapshot target, float logicalWidth, float logicalHeight);
        void endDeviceTarget();
        bool submitDevicePacket(DrawPacket packet);
        // Bounded offscreen producers publish only completed logical captures.
        bool flushDeviceFrame();
        bool deferDeviceFrame();
        bool setDeviceTargetScissor(const SDL_Rect *pixels);
    private:
        bool activateBackend(RendererBackend backend, SDL_Surface *previousFrame);
		RenderFramePacer renderPacer;
		static const bool verbose = false;
	public:
        static void setInitialRendererBackend(RendererBackend backend) { initialBackend = backend; }
        bool requestBackendSwitch(RendererBackend backend);
        const RendererSwitchStatus &backendSwitchStatus() const { return backendStatus; }
        RendererCapabilities rendererCapabilities() const;
        std::vector<RendererAvailability> rendererAvailability() const;
        void setBackendPreferenceCallback(std::function<void(RendererBackend)> callback) { backendPreferenceCallback = std::move(callback); }
		// Interactive hosts reserve drawing before painting; exports and benchmarks
		// leave the context's default uncapped. Zero means Unlimited.
		void setTargetRenderFps(int fps) { renderPacer.configure(fps); }
		void resetRenderPacing() { renderPacer.reset(); }
        bool beginRenderFrame();
		Uint32 renderFrameWait() const { return renderPacer.waitMilliseconds(SDL_GetTicksNS()); }

		//! The cursor manager, public to be able to set custom cursors
		CursorManager cursorManager;
		
		//! Flags that define the characteristic of the graphic context
		enum OptionFlags
		{
			DEFAULT = 0,
			USEGPU = 1,
			FULLSCREEN = 2,
			//! Allow windowed logical dimensions to follow the window size
			RESIZABLE = 8,
			CUSTOMCURSOR = 16,
			PORTABLEGPU = 32,
            NOAUDIO = 128, // Offline artwork export creates only the video context.
            //! Opt out of high-density backing pixels for fixed-pixel profiling.
            LOWPIXELDENSITY = 64,
		};
		
	protected:
		//! the minimum acceptable resolution
		int minW, minH;
		//! window size in window points, as SDL reports mouse coordinates; differs from the logical resolution when fullscreen scaling is active
		int windowW = 0, windowH = 0;
#if !defined(GLOB2_MOBILE) && !defined(__EMSCRIPTEN__)
		bool nativeDesktop = true;
#else
		bool nativeDesktop = false;
#endif
		bool nativeSoftware = false;
		int desktopLogicalW = 0, desktopLogicalH = 0;
		float preferredUiScale = 0, desktopSystemScale = 1;
		int desktopDisplay = -1;
		void refreshDesktopScale();
		bool refreshNativeWindow();
		std::function<void(int, int, bool)> displayPreferenceCallback;
        int fixedLogicalW=0, fixedLogicalH=0;
        bool responsiveViewport=false, compactWindowAllowed=false;
        bool uiTransformActive=false;
        SDL_Rect uiSavedClip{}, uiBounds{};
        float uiTransformScale=1, uiTransformX=0, uiTransformY=0;
        int responsiveMinW=0, responsiveMinH=0;
		//! Output drawable size in pixels; exceeds window points on HiDPI displays
		int drawableW = 0, drawableH = 0;
		//! resolution asked of setRes(), before the interface scale divides it
		int requestedW = 0, requestedH = 0;
		//! Window points per logical layout unit; native rasterization applies backing density separately
		float uiScale = 1.0f;
		//! the scale setRes() was asked for, before the window floor reduced it
		float wantedUiScale = 1.0f;
		//! interface scale for the next setRes(); 0 follows the desktop
		static float requestedUiScale;
		//! push minW/minH to SDL scaled by uiScale, so the floor applies to the
		//! logical surface rather than to the window it is stretched into
		void applyWindowMinimumSize(void);
		//! ratio of GL drawable pixels to logical pixels
		float drawableScale(void);
		//! target pixels per logical pixel for the rasteriser: the offscreen target while one is set, the window otherwise
		float rasterScale(void);
		//! target pixels per logical pixel while drawing into an offscreen target; 0 while drawing into the window
		float renderTargetScale = 0.0f;
		bool offscreenPass = false;
		bool mapTransformActive=false;
        bool periodicCopy=false;
		float mapScale=1, mapTranslateX=0, mapTranslateY=0;
		void drawMapSnappedRect(int x1, int y1, int x2, int y2, const Color& color, bool stroked, float maxStrokePoints);
		float overlayScale=1;
        float mapCopyTranslateX=0, mapCopyTranslateY=0;
		unsigned long drawCalls=0;
		int mapClipX=0,mapClipY=0,mapClipW=0,mapClipH=0;
		//! the GL viewport that fits the logical resolution into the drawable without distorting its aspect ratio, letterboxed/pillarboxed as needed
		void glLetterbox(float &scale, int &offX, int &offY);
		//! apply glLetterbox() as the current GL viewport
		void applyGLViewport(void);
		//! true when sdlsurface was allocated here rather than fetched from SDL
		bool ownsSurface = false;
		//! release sdlsurface when this context allocated it
		void freeOwnedSurface(void);
		//! refresh the window and drawable sizes after the window was resized
		void updateWindowSize(void);
		SDL_Window *window = nullptr;
		unsigned glContextGeneration = 0;
        std::uint64_t targetContentRevision = 0;
		SDL_GLContext context = nullptr;
		SDL_ThreadID eventThread = 0;
		bool pollingEvents = false;
		bool presenting = false;
		bool watchingEvents = false;
		// Owned here and released explicitly while the GL context is still current.
		struct FrameCache
		{
			SDL_Surface *surface = nullptr;
			unsigned texture = 0;
			int width = 0, height = 0;
			int textureWidth = 0, textureHeight = 0;
			int maximumTextureSize = 0;
			bool valid = false;
			bool failureReported = false;
		} frameCache;
		void reportFrameCacheFailure(const char *reason);
		void releaseFrameCache();
		void captureRecordingFrame();
		void cacheFrame();
        std::unique_ptr<SoftwareFramePresenter> softwarePresenter;
        void prepareDraw() override;
		void presentLastFrame();
		// GLSL 1.20 program that recolors a sprite's unrotated team layer on the
		// GPU (same HSV hue shift as DrawableSurface::shiftHSV) and combines it
		// with the base layer, so no team-coloured or composite texture is ever
		// created while it is active. Created after the context above exists and
		// destroyed before it is torn down. Plain unsigned/int fields, not GL
		// types, to keep GL headers out of this public header (see Sprite::vbo).
		std::unique_ptr<RenderBatch> renderBatch;
        bool renderBatchEnabled=true;
		// Experimental live mesh renderer, owned by the GL context.
		struct SkinResources
		{
			unsigned program = 0, rigProgram = 0, fragment = 0, framebuffer = 0, depth = 0;
			struct RigBuffers
			{
				unsigned vertices = 0, indices = 0, vao = 0;
			};
			struct Uniforms
			{
				int region = -1, bones = -1, view = -1, normalView = -1, shell = -1;
				void initialize(unsigned program);
			} uniforms, rigUniforms;
			void prepareRigShader();
			const RigBuffers &restBuffers(const SkinMesh &mesh);
			static void bindRigGeometry(const RigBuffers &buffers);
			static void finishRigGeometry();
			void uploadRigPalette(const SkinMesh &mesh, unsigned sample);
			void bindCpuGeometry(const SkinMesh &mesh, unsigned sample);
			// Geometry cache is bounded separately from the pose atlas. Rebuilt
			// from immutable models after context restoration.
			std::map<std::uint64_t, RigBuffers> rigs;
			std::vector<float> cpuPose, uploadScratch;
			std::vector<unsigned> colors;
			using Key = SkinAtlasCache::Key;
			SkinAtlasCache slots;
			unsigned poses = 0, uv = 0, indices = 0, vao = 0;
			std::uint64_t meshIdentity = 0;
			unsigned frame = ~0u;
			// Uniform values survive program switches and atlas batches.
			std::uint64_t paletteIdentity = 0;
			unsigned paletteFrame = ~0u;
			bool attempted = false, rigAttempted = false;
			// Fur support is cached by material-map identity and revision.
			std::map<std::pair<std::uint64_t, std::uint64_t>, std::array<bool, 4>> shellRegions;
		} skinResources;
		void destroySkinRenderer();
        static void releaseSurfaceTextures();
        static void restoreSurfaceTextures();
        unsigned unitShaderProgram = 0;
		int unitShaderLocBase = -1, unitShaderLocTeam = -1;
		int unitShaderLocHasBase = -1, unitShaderLocHasTeam = -1;
		bool unitShaderFailureLogged = false;
		void createUnitShader();
		void destroyUnitShader();
		// Central presentation boundary, also used by render-validation contexts.
		virtual void swapBuffers();
		static bool SDLCALL watchWindow(void *userdata, SDL_Event *event);
		std::unique_ptr<RenderBackend> portableRenderer;
        std::unique_ptr<RenderDevice> presentationDevice;
        std::shared_ptr<RenderResources> deviceResources;
        std::unique_ptr<RenderBackend> deviceRenderer;
        RendererBackend configuredBackend = RendererBackend::Software;
        std::shared_ptr<DeviceSkinState> deviceSkinState;
        struct DeviceTargetState { SDL_Rect clip; float scale; bool offscreen, map, ui; };
        std::vector<DeviceTargetState> deviceTargetStates;
        std::map<std::uint64_t, Recording::CaptureTicket> recordingCaptures;
        std::uint64_t captureFrameIdentity = 0;
        std::uint64_t screenshotIdentity = UINT64_MAX / 2;
        std::map<std::uint64_t, std::string> screenshotCaptures;
        void pollRecordingCaptures();
        void cancelRecordingCaptures();
        RenderBackend* renderer = nullptr; // Borrowed active backend; ownership stays in the two unique_ptrs.
        // Rasterizes transformed passes into the existing software framebuffer.
        std::unique_ptr<RenderBackend> softwareRasterizer;
        bool softwareTransform=false;
        void beginSoftwareTransform();
        void endSoftwareTransform();
		std::string pendingScreenshot;
		friend class DrawableSurface;
		//! option flags
		Uint32 optionFlags;
		std::string windowTitle;
		std::string appIcon;
		
	public:
		//! Constructor. Create a new window of size (w,h). If useGPU is true, use GPU for accelerated 2D (OpenGL or DX)
		GraphicContext(int w, int h, Uint32 flags, const std::string title = "", const std::string icon = "");
		//! Destructor
		virtual ~GraphicContext(void);
		
		//! Bounded software pass; borrows pixels and restores facade/backend state on failure.
		void drawToSurface(SDL_Surface* surface, float scale, const std::function<void()>& draw);
		unsigned getGLContextGeneration() const { return glContextGeneration; }
        // Failed bounded admission invalidates composed pixels, not logical leases.
        std::uint64_t renderTargetContentRevision() const { return targetContentRevision; }

		// modifiers
		virtual bool setRes(int w, int h, Uint32 flags);
        // Resize a software render target without replacing its window or assets.
        bool resizeViewport(int w, int h);
        bool setResponsiveViewport(bool enabled, int minimumWidth=0, int minimumHeight=0);
        bool refreshPresentation();
        void setCompactWindowAllowed(bool allowed) {
            if (compactWindowAllowed==allowed) return;
            compactWindowAllowed=allowed;applyWindowMinimumSize();
        }
        bool isResponsiveViewport() const { return responsiveViewport; }
        bool hasPortableRenderer() const { return bool(renderer) && !nativeSoftware && !offscreenPass; }
        double logicalUnitsPerPoint() const;
        //! Logical pixels per authored font pixel for text a touch painter sizes in
        //! points: logicalUnitsPerPoint() times the player's text-size preference.
        double textUnitsPerPoint() const;
        void setUITransform(float scale=1, float x=0, float y=0, const SDL_Rect* bounds=nullptr);
        Uint32 windowID() const { return SDL_GetWindowID(window); }
#ifdef GLOB2_WEBGL2
        static void restoreBrowserContext();
#endif
		virtual void setRes(int w, int h) { setRes(w, h, optionFlags); }
		//! the resolution asked of setRes(), which the interface scale then divides
		int getRequestedW(void) const { return requestedW; }
		int getRequestedH(void) const { return requestedH; }
		//! interface scale to apply on the next setRes(); 0 follows the desktop
		static void setRequestedUiScale(float scale) { requestedUiScale = scale; }
		//! the interface scale the player chose; 0 follows the desktop
		static float getRequestedUiScale(void) { return requestedUiScale; }
		//! the interface scale in use
		float getUiScale(void) const { return uiScale; }
		//! the scale the last setRes() was asked for, before the window floor reduced it
		float getWantedUiScale(void) const { return wantedUiScale; }
		//! drawable pixels per logical pixel for text drawn on this context, 1 when unscaled
		float textRenderScale(void);
		//! the interface scale the desktop asks for, or 0 when nothing reports one
		static float querySystemUiScale(void);
		//! the scale actually used for a preference; 0 follows the desktop, GLOB2_UI_SCALE wins
		static float effectiveUiScale(float preferred);
		//! true when the window pixel size differs from the logical resolution, so output is scaled
		bool isScalingActive(void);
		int getW() override { return nativeDesktop && desktopLogicalW ? desktopLogicalW : DrawableSurface::getW(); }
		int getH() override { return nativeDesktop && desktopLogicalH ? desktopLogicalH : DrawableSurface::getH(); }
		bool isNativeDesktop() const { return nativeDesktop; }
		int getDrawableW() const { return drawableW; }
		int getDrawableH() const { return drawableH; }
		bool setFullscreen(bool fullscreen);
		bool setUiScale(float scale);
		void setDisplayPreferenceCallback(std::function<void(int, int, bool)> callback)
		{ displayPreferenceCallback = std::move(callback); }
		bool toggleFullscreen();
		void beginMapTransform(float zoom,float x,float y,int clipX,int clipY,int clipW,int clipH);
		void endMapTransform();
        //! Axis-aligned world boundary, snapped to target pixels with a minimum one-pixel stroke.
        //! Unlike ordinary UI lines, this remains visible when the map is zoomed out.
        //! maxStrokePoints, when positive, stops the stroke thickening past that many screen points.
        void drawMapBoundary(int x1, int y1, int x2, int y2, const Color& color, float maxStrokePoints = 0);
        //! Axis-aligned world rectangle with edges snapped to target pixels, so
        //! translucent neighbours tile without seams or doubled edges at any zoom.
        void drawMapFill(int x1, int y1, int x2, int y2, const Color& color);
        //! A whole-tile fill that must meet neighbouring sprites exactly. Both
        //! software backends snap shared edges to target pixels; native software
        //! draws there directly to avoid DPI geometry rounding. Accelerated
        //! renderers retain exact fractions to match their neighbouring sprites.
        void drawMapTileFill(int x1, int y1, int x2, int y2, const Color& color);
        //! A sprite frame covering the `size`-pixel map square at (x, y), meeting
        //! its neighbours and drawMapTileFill exactly. Both software backends snap
        //! its edges in target pixels; elsewhere it is drawSprite.
        void drawMapTileSprite(int x, int y, int size, Sprite *sprite, unsigned index, Uint8 alpha = Color::ALPHA_OPAQUE);
        // Repeat a presentation-only pass. Its primary invocation advances visual
        // state once; subsequent invocations must only draw.
        void drawMapCopies(int periodW,int periodH,int viewW,int viewH,const std::function<void()> &draw, bool advance = true);
        bool isPeriodicCopy() const {return periodicCopy;}
		void beginScreenOverlay(int &x,int &y,int &sx,int &sy,int &sw,int &sh);
		//! Scale of the active map transform; 1 outside a map pass.
		float mapTransformScale() const { return mapTransformActive ? mapScale : 1.f; }
		//! Where a map pixel lands in the screen overlay's logical units,
		//! including the periodic copy being drawn.
		void mapToScreen(int x, int y, float &screenX, float &screenY) const;
		void endScreenOverlay();
		unsigned long getDrawCallCount() const {return drawCalls;}
		void resetDrawCallCount(){drawCalls=0;}
		//! convert window pixel coordinates (as delivered by SDL) to logical coordinates
		void windowToLogical(float &x, float &y);
		//! set a GL line width in logical pixels; GL rasterises lines in window pixels, which the viewport does not scale
		void setScaledLineWidth(float width);
		//! declare that drawing now goes to an offscreen target with this many of its pixels per logical pixel; 0 restores the window
		void setRenderTargetScale(float pixelsPerLogicalPixel) {renderTargetScale = pixelsPerLogicalPixel;}
		//! target pixels per logical pixel the rasteriser is drawing at right now
		float getRasterScale(void) {return rasterScale();}
		//! translate SDL_GetMouseState coordinates through the active context's scaling
		static void translateMouseCoordinates(int &x, int &y);
        static void translateMouseCoordinates(float &x, float &y);
		//! rewrite a polled event's mouse coordinates from window pixels to logical coordinates
		static void translateMouseEvent(SDL_Event *event);
		//! Counts render device/target resets seen by translateMouseEvent, so caches of
		//! composed surfaces (editor swatches) can drop themselves without an event hook.
		static std::uint64_t renderResetGeneration();
		//! Pump events at a frame boundary; modal expose callbacks only present a cached frame.
		static int pollEvent(SDL_Event *event);
		virtual void setClipRect(int x, int y, int w, int h);
		virtual void setClipRect(void);
		enum class FrameMode { FullRedraw, PreserveContent };
        void beginFrame(FrameMode mode = FrameMode::PreserveContent);
        RenderOperations backendOperations() const;
        SDL_Surface* completedFrame() const;
        virtual void nextFrame(void);
		//! This function does not work for GraphicContext
		virtual bool loadImage(const std::string name) { return false; }
		//! This function does not work for GraphicContext
		virtual bool loadImage(const std::string &name) { return false; }
		//! This function does not work for GraphicContext
		virtual void shiftHSV(float hue, float sat, float lum) { }
		
		// reimplemented drawing commands for HW (GPU / GL) accelerated version
		virtual bool canDrawStretchedSprite(void) { return hasPortableRenderer() || (optionFlags & USEGPU) != 0; }
		
		virtual void drawPixel(int x, int y, const Color& color);
		virtual void drawPixel(float x, float y, const Color& color);
		
		virtual void drawRect(int x, int y, int w, int h, const Color& color);
		virtual void drawRect(float x, float y, float w, float h, const Color& color);
		
		virtual void drawFilledRect(int x, int y, int w, int h, const Color& color);
		virtual void drawFilledRect(float x, float y, float w, float h, const Color& color);
		
		virtual void drawLine(int x1, int y1, int x2, int y2, const Color& color);
		virtual void drawLine(float x1, float y1, float x2, float y2, const Color& color);
		
		virtual void drawCircle(int x, int y, int radius, const Color& color);
		virtual void drawCircle(float x, float y, float radius, const Color& color);
		
		virtual void drawSurface(int x, int y, DrawableSurface *surface, Uint8 alpha = Color::ALPHA_OPAQUE);
		virtual void drawSurface(float x, float y, DrawableSurface *surface, Uint8 alpha = Color::ALPHA_OPAQUE);
		
		virtual void drawSurface(int x, int y, int w, int h, DrawableSurface *surface, Uint8 alpha = Color::ALPHA_OPAQUE);
		virtual void drawSurface(float x, float y, float w, float h, DrawableSurface *surface, Uint8 alpha = Color::ALPHA_OPAQUE);
		
		virtual void drawSurface(int x, int y, DrawableSurface *surface, int sx, int sy, int sw, int sh, Uint8 alpha = Color::ALPHA_OPAQUE);
		virtual void drawSurface(float x, float y, DrawableSurface *surface, int sx, int sy, int sw, int sh, Uint8 alpha = Color::ALPHA_OPAQUE);
		
		virtual void drawSurface(int x, int y, int w, int h, DrawableSurface *surface, int sx, int sy, int sw, int sh,  Uint8 alpha = Color::ALPHA_OPAQUE);
		virtual void drawSurface(float x, float y, float w, float h, DrawableSurface *surface, int sx, int sy, int sw, int sh, Uint8 alpha = Color::ALPHA_OPAQUE);

		void finishDrawingSprite(Sprite* sprite, Uint8 alpha);

		//! Draw a unit pose combining a base and team-colour layer with the
		//! unit shader, at logical position (x,y) and explicit destination size
		//! (independent of the sampled textures' own size, so an HD source
		//! layer still draws at the sprite's logical dimensions), alpha applied
		//! to the combined result. Returns false, drawing nothing, when the
		//! shader is unavailable so the caller can fall back to two ordinary
		//! drawSurface calls (base, then the CPU-recoloured team layer).
		bool drawTeamColoredQuad(DrawableSurface *base, DrawableSurface *team, float x, float y, float w, float h, Uint8 alpha, float hueShift);
		//! Maximum supported texture dimension, or zero when no limit is reported.
		int maximumTextureSize() const;
		RenderBatch* getRenderBatch() const { return renderBatchEnabled?renderBatch.get():nullptr; }
        void countRenderBatchDraw() { ++drawCalls; }
        // Diagnostic comparison switches use the same context and assets.
        void setRenderBatchEnabled(bool enabled);
        bool hasUnitShader() const { return unitShaderProgram != 0; }
        // Render distinct visible poses before painting the map; composites retain painter order.
        void drawSkinSprite(float x,float y,float w,float h,DrawableSurface *surface,int sx,int sy,int sw,int sh,Uint8 alpha);
        // Production FBO tile, top-down straight RGBA; no shadows or window readback.
        bool readSkinMesh(const SkinMeshRequest &request, std::vector<std::uint8_t> &rgba);
        void prepareSkinMeshes(const std::vector<SkinMeshRequest> &requests);
        // Returns false without drawing when the backend or assets are unavailable.
        // texture is the team's colour atlas and material its material-id map;
        // region (SkinRegion) selects the model's quadrant of both.
        bool drawSkinMesh(const SkinMesh &mesh, unsigned frame, DrawableSurface &texture,
                          DrawableSurface &material, std::uint8_t region,
                          float x, float y, float w, float h, DrawableSurface *underlay = nullptr, Uint8 alpha = Color::ALPHA_OPAQUE);
		
		virtual void drawAlphaMap(const std::valarray<float> &map, int mapW, int mapH, int x, int y, int cellW, int cellH, const Color &color);
		virtual void drawAlphaMap(const std::valarray<unsigned char> &map, int mapW, int mapH, int x, int y, int cellW, int cellH, const Color &color);
		
		// compat
		virtual void drawPixel(int x, int y, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawRect(int x, int y, int w, int h, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawFilledRect(int x, int y, int w, int h, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawVertLine(int x, int y, int l, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawVertLine(int x, int y, int l, const Color& color);
		virtual void drawHorzLine(int x, int y, int l, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawHorzLine(int x, int y, int l, const Color& color);
		virtual void drawLine(int x1, int y1, int x2, int y2, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		virtual void drawCircle(int x, int y, int radius, Uint8 r, Uint8 g, Uint8 b, Uint8 a = Color::ALPHA_OPAQUE);
		
		// GraphicContext specific methods
		//! Set the minimum acceptable resolution
		virtual void setMinRes(int w = 0, int h = 0);
		//! List all video modes
		VideoModes listVideoModes() const;

		//! Save a bmp of the screen to a file, bypass virtual filesystem
		virtual void printScreen(const std::string filename);
		
		//! Return the option flags
		Uint32 getOptionFlags(void) { return optionFlags; }
		// Report-only identity. GL strings are available only on this context's
		// presentation thread while the context is current; never switches it.
		struct RenderingIdentity {
			std::string backend;
			std::string glVendor, glRenderer;
			bool glIdentityAvailable = false;
		};
		RenderingIdentity renderingIdentity() const;
	};
	
    class HighResolutionInputs;
	//! A sprite is a collection of images (frames) that can be displayed one after another to make an animation
	class Sprite
	{
        friend class SpriteLoad;
        void registerLoaded();
        static HighResolutionInputs prefetchHighResolution(const std::string&, size_t frames);
        void adoptLoaded(Sprite& prepared);
	protected:
		struct RotatedImage
		{
			DrawableSurface *orig;
			typedef std::map<Color32, DrawableSurface *> RotationMap;
			RotationMap rotationMap;
	
			RotatedImage(DrawableSurface *s) { orig = s; }
			~RotatedImage();
		};

		friend class GraphicContext;
	
		std::string fileName;
//#define DEBUG_SPRITE_NOT_DRAWN
#ifdef DEBUG_SPRITE_NOT_DRAWN
		static std::vector <Sprite*> sprites;
#endif
		std::vector <DrawableSurface *> images;
		std::vector <RotatedImage *> rotated;
		std::unique_ptr<Sprite> highResolutionAtlas;
		void createHighResolutionAtlas(HighResolutionInputs& inputs);
		std::vector <DrawableSurface *> experimentImages;
		std::vector <RotatedImage *> experimentRotated;

		// Sprite sheet stuff to efficiently draw terrain/water/units.
#ifdef HAVE_OPENGL
		std::vector <float> vertices;
		std::vector <float> texCoords;
		unsigned int vbo = 0; // Vertex buffer object
		unsigned int texCoordBuffer = 0;
        unsigned bufferGeneration = 0;
#endif
        std::shared_ptr<const SpriteAtlasMemory> atlasMemory;
        std::unique_ptr<const DrawableSurface> atlas = nullptr;
        std::vector<SpriteAtlasStamp> atlasStamps;
        std::vector<SDL_Rect> atlasRegions;
        bool atlasVariableSizes = false;
		static void checkAllSpritesDrawn();
		Color actColor;

		// Team-colour recoloring for sprites marked dynamicTeamColor (currently
		// only the unit sprite, see load()). GPU rendering recolors in a shader
		// (GraphicContext::drawTeamColoredQuad) and never creates a CPU/GPU
		// recolor surface at all; this bounded cache backs the software renderer
		// and GL-without-a-working-shader fallback, shared by world units and
		// unit UI previews (portraits, editor previews, indicators, credits) since
		// they all route through the same DrawableSurface::drawSprite.
		bool dynamicTeamColor = false;
		//! Every dynamicTeamColor sprite's HD layer renders onto this fixed
		//! pixel canvas regardless of its own native/logical size (unlike other
		//! sprite categories' HD layers, which are always exactly 4x native).
		//! Matches UNIT_HD_PIXEL_SIZE in tools/unit-animation/render.py.
		static constexpr int highResolutionTextureSize = 128;
		struct TeamColorKey
		{
			int index; bool experiment; Uint8 r, g, b;
			bool operator==(const TeamColorKey &o) const
			{ return index == o.index && experiment == o.experiment && r == o.r && g == o.g && b == o.b; }
		};
		struct TeamColorKeyHash
		{
			size_t operator()(const TeamColorKey &k) const
			{
				size_t h = static_cast<size_t>(k.index) * 2 + (k.experiment ? 1 : 0);
				h = h * 257 + k.r; h = h * 257 + k.g; h = h * 257 + k.b;
				return h;
			}
		};
		struct TeamColorNode { TeamColorKey key; std::unique_ptr<DrawableSurface> surface; size_t bytes; };
		// Front = most recently used. Byte-accounted LRU: CPU pixels plus any GPU
		// texture allocation, evicted oldest-first before a new entry is admitted.
		std::list<TeamColorNode> teamColorList;
		std::unordered_map<TeamColorKey, std::list<TeamColorNode>::iterator, TeamColorKeyHash> teamColorIndex;
		size_t teamColorBytes = 0;
		static const size_t teamColorCacheCap = 64u * 1024u * 1024u;
		DrawableSurface *lookupTeamColor(const TeamColorKey &key);
		void insertTeamColor(const TeamColorKey &key, std::unique_ptr<DrawableSurface> surface, size_t bytes);
		void clearTeamColorCache();

		friend class DrawableSurface;
		// Support functions

		//! Check if index is within bound and return true, assert false and return false otherwise
		bool checkBound(int index);
		//! Return a rotated drawable surface for actColor, create it if necessary
    public:
        // The uncolored layer may be retained beneath replacement geometry
        // (unit sheets store their ground shadows here). The caller sizes it
        // to the native logical canvas, even when an HD surface is returned.
        DrawableSurface *baseFrame(unsigned index)
        {
            return checkBound(index) ? prepareDrawSurface(index, false, true) : nullptr;
        }

        // Immutable native image access for terrain cache preparation. Team layers
        // need separate composition and therefore are not cacheable here.
        DrawableSurface* nativeFrame(unsigned index) const
        {
            return index < images.size() && index < rotated.size() && !rotated[index] ? images[index] : nullptr;
        }

    protected:
		virtual DrawableSurface *getRotatedSurface(int index);
		//! One bit per 32-phase block, recomputed whenever the HD layer arrays
		//! change (load and atomic HD publication); backs blockHasCompleteHD.
		std::vector<bool> blockCompleteHD;
		void recomputeBlockCompleteHD();
		void applyTeamHueShift(DrawableSurface &surface);
		DrawableSurface *getColoredSurface(int index, bool experiment);
		DrawableSurface *prepareDrawSurface(unsigned index, bool teamColor, bool experiment);
        void appendHighResolutionFrame(size_t index, Sprite& target,
            HighResolutionInputs& inputs);

	public:
		//! Opt into batching variable-size frames; callers must finishDrawingSprite.
		bool createTextureAtlas(bool allowVariableSizes = false);
        bool resolveDeviceAtlas(DrawableSurface &, SDL_Rect &, const DrawableSurface *&);
        bool createDeviceTextureAtlas(int maximumTextureSize, bool variableSizes);
		struct HighResolutionStats {size_t cpuBytes=0, coloredFrames=0;};
		static HighResolutionStats highResolutionStats();
		static void setHighResolution(bool enabled);
        static void requestHighResolution(bool enabled);
        static void refreshHighResolutionForRenderer();
        static bool pollHighResolution(unsigned budgetMs = 2);
        static bool pollHighResolutionUntil(std::chrono::steady_clock::time_point deadline);
		static void flushBatches(GraphicContext *gc);
		//! Constructor
		Sprite() : fileName("not loaded yet") { }
		//! Destructor
		virtual ~Sprite();

		//! Load a sprite from the file, return true if any frame have been loaded
		bool load(const std::string filename);

		//! Set the (r,g,b) color to a sprite's base color
		virtual void setBaseColor(Uint8 r, Uint8 g, Uint8 b) { actColor = Color(r, g, b); }
		//! Set the color to a sprite's base color
		virtual void setBaseColor(const Color& color) { actColor = color; }

		bool isDynamicTeamColor() const { return dynamicTeamColor; }
		size_t getTeamColorCacheBytes() const { return teamColorBytes; }
		size_t getTeamColorCacheEntries() const { return teamColorList.size(); }
		//! True when every frame in index's 32-phase action/direction block has a
		//! matching HD layer wherever the native one exists. An incomplete block
		//! falls back to native throughout the action rather than switching
		//! resolutions from pose to pose. DrawSprite calls this per pose, so it is cached
		//! (recomputeBlockCompleteHD) rather than rescanned every time.
		bool blockHasCompleteHD(int index) const;
		//! Hue shift, in degrees, from this sprite's base team colour to actColor;
		//! shared by the CPU recolor path and the uHueShift uniform of the shader.
		//! Not const: Color::getHSV isn't const-qualified.
		float teamHueShiftDegrees();
		//! Return the width of index frame of the sprite
		virtual int getW(int index);
		//! Return the height of index frame of the sprite
		virtual int getH(int index);
		//! Return the number of frame in this sprite
		virtual int getFrameCount(void);
	};
}
