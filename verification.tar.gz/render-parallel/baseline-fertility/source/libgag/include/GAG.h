// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#pragma once

#include "GAGSys.h"
#include "FileManager.h"
#include "StringTable.h"
#include "GraphicContext.h"
#include "SupportFunctions.h"
#include "Toolkit.h"
#include "GUIBase.h"

