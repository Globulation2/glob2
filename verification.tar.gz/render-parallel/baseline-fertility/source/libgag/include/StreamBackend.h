// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#pragma once

#include <fstream>
#include <iostream>
#include <Types.h>
#include <string>
#include <stdio.h>
#include <assert.h>
#ifdef putc
#undef putc
#endif

namespace GAGCore
{
	class MemoryStreamBackend;

	//! A stream backend is a low-level serialization structure, that can be a file, a memory area, a network socket, ...
	class StreamBackend
	{
	public:
		virtual ~StreamBackend() { }
		
		virtual void write(const void *data, const size_t size) = 0;
		virtual void flush(void) = 0;
		virtual void read(void *data, size_t size) = 0;
		virtual bool readExact(void *data, size_t size)
		{
			const size_t before = getPosition();
			read(data, size);
			return getPosition() - before == size;
		}
		virtual void putc(int c) = 0;
		virtual int getChar(void) = 0;
		virtual void seekFromStart(int displacement) = 0;
		virtual void seekFromEnd(int displacement) = 0;
		virtual void seekRelative(int displacement) = 0;
		virtual size_t getPosition(void) = 0;
		virtual bool isEndOfStream(void) = 0;
		virtual bool isValid(void) = 0;
	};
	
	//! The FILE* implementation of stream backend
	class FileStreamBackend : public StreamBackend
	{
	protected:
		FILE *fp;
		
	public:
		//! Constructor. If fp is NULL, isEndOfStream returns true and all other functions excepted destructor are invalid and will assert false if called
		FileStreamBackend(FILE *fp) { this->fp = fp; }
		virtual ~FileStreamBackend() { if (fp) fclose(fp); }
		
		virtual void write(const void *data, const size_t size) { assert(fp); fwrite(data, size, 1 ,fp); }
		virtual void flush(void) { assert(fp); fflush(fp); }
		virtual void read(void *data, size_t size) { assert(fp); fread(data, size, 1, fp); }
		virtual bool readExact(void *data, size_t size) { return fp && fread(data, 1, size, fp) == size; }
		virtual void putc(int c) { assert(fp); fputc(c, fp); }
		virtual int getChar(void) { assert(fp); return fgetc(fp); }
		virtual void seekFromStart(int displacement) { assert(fp); fseek(fp, displacement, SEEK_SET); }
		virtual void seekFromEnd(int displacement) { assert(fp); fseek(fp, displacement, SEEK_END); }
		virtual void seekRelative(int displacement) { assert(fp); fseek(fp, displacement, SEEK_CUR); }
		virtual size_t getPosition(void) { assert(fp); return ftell(fp); }
		virtual bool isEndOfStream(void) { return (fp == NULL) || (feof(fp) != 0); }
		virtual bool isValid(void) { return (fp != NULL); }
	};
	
	//! A stream backend that lies in memory
	class MemoryStreamBackend : public StreamBackend
	{
	private:
		std::string buffer;
		size_t index;
		
	public:
		//! Constructor. If NULL is passed to data, internal buffer is empty, otherwise size bytes are copied from data.
		MemoryStreamBackend(const void *data = NULL, const size_t size = 0);
		//! Takes ownership of an input buffer and starts at its beginning.
		explicit MemoryStreamBackend(std::string&& contents);
		virtual ~MemoryStreamBackend() { }
		
		virtual void write(const void *data, const size_t size);
		virtual void flush(void) { }
		virtual void read(void *data, size_t size);
		virtual void putc(int c);
		virtual int getChar(void);
		virtual void seekFromStart(int displacement);
		virtual void seekFromEnd(int displacement);
		virtual void seekRelative(int displacement);
		virtual size_t getPosition(void);
		virtual bool isEndOfStream(void);
		virtual bool isValid(void) { return true; }
		virtual const char* getBuffer() { return buffer.c_str(); }
		//! Preallocates room for size bytes; the contents are unchanged.
		void reserve(size_t size) { buffer.reserve(size); }
		//! Moves the contents out and leaves the stream empty.
		std::string takeContents() { std::string contents; contents.swap(buffer); index = 0; return contents; }
	};
}
