// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#pragma once

#include <Stream.h>
#include <StreamBackend.h>
#include <ostream>
#include <sstream>
#include <map>
#include <vector>
#include <set>

namespace GAGCore
{
	//! Write data in a human readable form
	class TextOutputStream : public OutputStream
	{
	protected:
		StreamBackend *backend;
		
		unsigned level;
		
		//! print levels of tabs
		void printLevel(void);
		//! print string to backend
		void printString(const std::string &string);
		//! print a given type using ostringstream
		template <class T>
		void print(T v)
		{
			std::ostringstream oss;
			oss << v;
			printString(oss.str().c_str());
		}
		
	public:
		TextOutputStream(StreamBackend *backend) { this->backend = backend; level=0; };
		virtual ~TextOutputStream() { delete backend; }
	
		virtual void write(const void *data, const size_t size, const std::string name);
	
		virtual void writeSint8(const Sint8 v, const std::string name) { printLevel(); printString(name); printString(" = "); print<signed>(v); print(";\n"); }
		virtual void writeUint8(const Uint8 v, const std::string name) { printLevel(); printString(name); printString(" = "); print<unsigned>(v); print(";\n"); }
		virtual void writeSint16(const Sint16 v, const std::string name) { printLevel(); printString(name); printString(" = "); print<signed>(v); print(";\n"); }
		virtual void writeUint16(const Uint16 v, const std::string name) { printLevel(); printString(name); printString(" = "); print<unsigned>(v); print(";\n"); }
		virtual void writeSint32(const Sint32 v, const std::string name) { printLevel(); printString(name); printString(" = "); print(v); print(";\n"); }
		virtual void writeUint32(const Uint32 v, const std::string name) { printLevel(); printString(name); printString(" = "); print(v); print(";\n"); }
		virtual void writeFloat(const float v, const std::string name) { printLevel(); printString(name); printString(" = "); print(v); print(";\n"); }
		virtual void writeDouble(const double v, const std::string name) { printLevel(); printString(name); printString(" = "); print(v); print(";\n"); }
		virtual void writeText(const std::string &v, const std::string name);
		virtual void flush(void) { backend->flush(); }
		
		virtual void writeEnterSection(const std::string name);
		virtual void writeEnterSection(unsigned id);
		virtual void writeLeaveSection(size_t count = 1);
		
		virtual bool canSeek(void) { return false; }
		virtual void seekFromStart(int displacement) { }
		virtual void seekFromEnd(int displacement) { }
		virtual void seekRelative(int displacement) { }
		virtual size_t getPosition(void) { return backend->getPosition(); }
		virtual bool isEndOfStream(void) { return backend->isEndOfStream(); }
		virtual bool isValid(void) { return backend->isValid(); }
	};
	
	//! Read data from a human readable form, C-like, supporting C and C++ comments
	class TextInputStream : public InputStream
	{
	protected:
		//! table of parsed value
		std::map<std::string, std::string> table;
		//! recursive keys
		std::vector<std::string> levels;
		//! actual complete key
		std::string key;
		
		//! Read from table using keys key and name and put result to result
		void readFromTableToString(const std::string name, std::string *result);
		
		//! read from table and convert to type T using std::istringstream
		template <class T>
		T readFromTable(const std::string name)
		{
			std::string s;
			readFromTableToString(name, &s);
			std::istringstream iss(s);
			T v;
			iss >> v;
			return v;
		}
		
	public:
		//! Constructor. Uses backend, but does not delete it
		TextInputStream(StreamBackend *backend);
		//! Return all subsections of root
		void getSubSections(const std::string &root, std::set<std::string> *sections);
		//! Test a field relative to the current section without changing parser state.
		bool hasField(const std::string &name) const
		{
			return table.contains(key.empty() ? name : key + "." + name);
		}
		
		virtual void read(void *data, size_t size, const std::string name);
		virtual Sint8 readSint8(const std::string name) { return static_cast<Sint8>(readFromTable<signed>(name)); }
		virtual Uint8 readUint8(const std::string name) { return static_cast<Uint8>(readFromTable<unsigned>(name)); }
		virtual Sint16 readSint16(const std::string name) { return static_cast<Sint16>(readFromTable<signed>(name)); }
		virtual Uint16 readUint16(const std::string name) { return static_cast<Uint16>(readFromTable<unsigned>(name)); }
		virtual Sint32 readSint32(const std::string name) { return readFromTable<Sint32>(name); }
		virtual Uint32 readUint32(const std::string name) { return readFromTable<Uint32>(name); }
		virtual float readFloat(const std::string name) { return readFromTable<float>(name); }
		virtual double readDouble(const std::string name) { return readFromTable<double>(name); }
		virtual std::string readText(const std::string name) { std::string s; readFromTableToString(name, &s); return s; }
		
		virtual void readEnterSection(const std::string name);
		virtual void readEnterSection(unsigned id);
		virtual void readLeaveSection(size_t count = 1);
		
		virtual bool canSeek(void) { return false; }
		virtual void seekFromStart(int displacement) { }
		virtual void seekFromEnd(int displacement) { }
		virtual void seekRelative(int displacement) { }
		virtual size_t getPosition(void) { return 0; }
		virtual bool isEndOfStream(void) { return false; }
		virtual bool isValid(void) { return true; }
	};
}
