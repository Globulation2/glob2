/*

    Declaration of POSIX directory browsing functions and types for Win32.

    Kevlin Henney (mailto:kevlin@acm.org), March 1997.

    Copyright Kevlin Henney, 1997. All rights reserved.

    Permission to use, copy, modify, and distribute this software and its
    documentation for any purpose is hereby granted without fee, provided
    that this copyright and permissions notice appear in all copies and
    derivatives, and that no charge may be made for the software and its
    documentation except to cover cost of distribution.
    
*/

#pragma once

#ifdef WIN32

#ifdef __cplusplus
extern "C" {
#endif

typedef struct DIR DIR;

struct dirent
{
    char *d_name;
	int d_type;	// HACK:Non-standard! This is a hack! Get rid of it!
};


DIR           *opendir(const char *);
int           closedir(DIR *);
struct dirent *readdir(DIR *);
void          rewinddir(DIR *);

#define DT_DIR	1

#ifdef __cplusplus
}
#endif

#endif
