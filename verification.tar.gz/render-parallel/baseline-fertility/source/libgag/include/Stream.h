// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#pragma once

// For U/SintNN
#include "Types.h"
#include <string>
#include <stdexcept>

namespace GAGCore
{
	//! A stream is a high-level serialization structure, used to read/write structured data
	class Stream
	{
	public:
		virtual ~Stream() { }
		virtual bool canSeek(void) = 0;
		virtual void seekFromStart(int displacement) = 0;
		virtual void seekFromEnd(int displacement) = 0;
		virtual void seekRelative(int displacement) = 0;
		virtual size_t getPosition(void) = 0;
		virtual bool isEndOfStream(void) = 0;
		virtual bool isValid(void) = 0;
	};
	
	//! The stream that can be written to
	class OutputStream : public Stream
	{
	public:
		virtual ~OutputStream() { }
		
		virtual void write(const void *data, const size_t size, const std::string name) = 0;
		virtual void writeSint8(const Sint8 v, const std::string name) = 0;
		virtual void writeUint8(const Uint8 v, const std::string name) = 0;
		virtual void writeSint16(const Sint16 v, const std::string name) = 0;
		virtual void writeUint16(const Uint16 v, const std::string name) = 0;
		virtual void writeSint32(const Sint32 v, const std::string name) = 0;
		virtual void writeUint32(const Uint32 v, const std::string name) = 0;
		//! A byte offset into this stream. Deferred encoders relocate the target
		//! after expanding placeholders; ordinary binary/text streams write it
		//! exactly as a uint32. Field names never determine relocation behavior.
		virtual void writeOffset32(const Uint32 value, const std::string name)
		{
			writeUint32(value, name);
		}
		virtual void writeFloat(const float v, const std::string name) = 0;
		virtual void writeDouble(const double v, const std::string name) = 0;
		virtual void writeText(const std::string &v, const std::string name) = 0;
		
		virtual void flush(void) = 0;
		
		virtual void writeEnterSection(const std::string name) = 0;
		virtual void writeEnterSection(unsigned id) = 0;
		virtual void writeLeaveSection(size_t count = 1) = 0;

		//! Writes count values, each in its own numbered section, as
		//! writeUint16 would. Streams that store no sections may batch them.
		virtual void writeUint16Sections(const Uint16 *values, size_t count, const std::string name)
		{
			for (size_t i = 0; i < count; ++i)
			{
				writeEnterSection(static_cast<unsigned>(i));
				writeUint16(values[i], name);
				writeLeaveSection();
			}
		}
	};
	
	//! The stream that can be read from
	class InputStream : public Stream
	{
		unsigned nestingDepth = 0;
	public:
		virtual ~InputStream() { }

		// Bound file-controlled counts BEFORE allocating or resizing. The default
		// is a backstop: pass the smallest domain limit available at each call.
		Uint32 readCount(const std::string& name, Uint32 maximum = 1048576)
		{
			const Uint32 count = readUint32(name);
			if (count > maximum) throw std::runtime_error("Oversized collection: " + name);
			return count;
		}
		// Per-stream recursion budget for nested factory graphs; this does not
		// bound aggregate memory or total parsing/execution time.
		class NestedRead
		{
			InputStream& stream;
		public:
			explicit NestedRead(InputStream& input) : stream(input)
			{
				if (stream.nestingDepth >= 64) throw std::runtime_error("Saved object nesting limit exceeded");
				++stream.nestingDepth;
			}
			~NestedRead() { --stream.nestingDepth; }
			NestedRead(const NestedRead&) = delete;
			NestedRead& operator=(const NestedRead&) = delete;
		};

	
		virtual void read(void *data, size_t size, const std::string name) = 0;
		virtual Sint8 readSint8(const std::string name) = 0;
		virtual Uint8 readUint8(const std::string name) = 0;
		virtual Sint16 readSint16(const std::string name) = 0;
		virtual Uint16 readUint16(const std::string name) = 0;
		virtual Sint32 readSint32(const std::string name) = 0;
		virtual Uint32 readUint32(const std::string name) = 0;
		virtual float readFloat(const std::string name) = 0;
		virtual double readDouble(const std::string name) = 0;
		virtual std::string readText(const std::string name) = 0;
		
		virtual void readEnterSection(const std::string name) = 0;
		virtual void readEnterSection(unsigned id) = 0;
		//! Pops `count` nesting levels from the section stack. NOTE the
		//! asymmetry with readEnterSection(unsigned id): the parameter is a
		//! level count, NOT a section id — after readEnterSection(i), the
		//! matching call is readLeaveSection() (pop one), never
		//! readLeaveSection(i). Multi-level pops (e.g. count=3 on an error
		//! path unwinding nested sections) are the only reason to pass an
		//! argument. BinaryInputStream implements this as a no-op;
		//! TextInputStream asserts count <= current depth.
		virtual void readLeaveSection(size_t count = 1) = 0;
	};
	
	class StreamBackend;
	
	//! Stream used to write line by line
	class OutputLineStream
	{
	private:
		StreamBackend *backend;
	
	public:
		OutputLineStream(StreamBackend *backend);
		virtual ~OutputLineStream();
		void writeLine(const std::string &s);
		void writeLine(const char *s);
		bool isEndOfStream(void);
	};
	
	//! Stream used to read line by line
	class InputLineStream
	{
	private:
		StreamBackend *backend;
	
	public:
		InputLineStream(StreamBackend *backend);
		virtual ~InputLineStream();
		std::string readLine(void);
		bool isEndOfStream(void);
	};
}
