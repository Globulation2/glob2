// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#pragma once

#include "GAGSys.h"
#include <CooperativeTask.h>
#include <vector>
#include <fstream>
#include <string>
#include <functional>

//! this is the host filesystem directory separator
#ifndef DIR_SEPARATOR
#define DIR_SEPARATOR '/'
#endif
#ifndef DIR_SEPARATOR_S
#define DIR_SEPARATOR_S "/"
#endif

namespace GAGCore
{
	class ChunkedBuffer;
	class StreamBackend;
	class OutputStream;
	
	//! File Manager (filesystem abstraction)
	class FileManager
	{
	private:
		//! List of directory where to search for requested file
		std::vector<std::string> dirList;
		//! List of file relative to virtual base address after call to initDirectoryListing
		std::vector<std::string> fileList;
		//! Index in the dirFileList vector
		int fileListIndex;
	
	private:
		static bool isAbsolutePath(const std::string& path);
		//! clear the list of file for directory listing
		void clearFileList(void);
		//! internal function that does the real listing job
		bool addListingForDir(const std::string realDir, const std::string extension="", const bool dirs=false);
		//! open a file, if it is in writing, do a backup
		SDL_IOStream *openWithbackup(const std::string filename, const std::string mode);
		//! open a file, if it is in writing, do a backup, fopen version
		FILE *openWithbackupFP(const std::string filename, const std::string mode);

	public:
		//! FileManager constructor
		FileManager(const std::string gameName);
		//! FileManager destructor
		virtual ~FileManager();
	
		//! Add a directory to the search list
		void addDir(const std::string dir);
		//! Return the number of directory in the search list
		unsigned getDirCount(void) const { return dirList.size(); }
		//! Return a direction in the search list from its index
		std::string getDir(unsigned index) const { if (index < getDirCount()) return dirList[index]; else return std::string(); }
		//! Add a new subdir (create it if needed) which will be used to open file in write mode in it
		void addWriteSubdir(const std::string subdir);
	
		//! Remove a file or a directory in the virtual filesystem, std::string version
		void remove(const std::string filename);
		//! Returns true if filename is a directory
		bool isDir(const std::string filename);
		//! Returns true if filename resolves through the virtual filesystem
		bool exists(const std::string filename);
		
		//! Compress source to dest using gzip, returns true on success
		bool gzip(const std::string &source, const std::string &dest);
		//! Uncompress source to dest using gzip, returns true on success
		bool gunzip(const std::string &source, const std::string &dest);
	
		//! Open an output stream backend, use it to construct specific output streams
		StreamBackend *openOutputStreamBackend(const std::string filename);
		//! Checked replacement; failure leaves the original intact.
		bool writeFileAtomic(const std::string& filename, const std::string& contents);

		//! Replace a file only after the writer, flush, and close all succeed.
		bool writeAtomically(const std::string& filename, const std::function<void(OutputStream&)>& writer);

		//! Gzip-compresses contents at the given level and replaces filename with it
		//! only after compression and the write both succeed (see writeAtomically).
		//! The gzip header carries no timestamp or OS byte, so the same contents and
		//! level always produce identical bytes on every platform.
		bool writeGzipAtomic(const std::string& filename, const std::string& contents, int level = 6);
		bool writeGzipAtomic(const std::string& filename, const ChunkedBuffer& contents, int level = 6);
        // Cooperative normal-save encoder: level 6, byte-identical to writeGzipAtomic
        // at that level. Bounded steps never flatten the owned input buffer.
        CooperativeTask writeGzipTask(std::string filename, const ChunkedBuffer& contents);
		//! Serializes through writer into chunked memory first (so seek-based backpatching
		//! works exactly as it does for uncompressed output), then gzip-compresses
		//! and atomically replaces filename with the result.
		bool writeGzipAtomically(const std::string& filename, const std::function<void(OutputStream&)>& writer, int level = 6);

		//! Open an input stream backend, use it to construct specific input streams
		StreamBackend *openInputStreamBackend(const std::string filename);
		//! Like openInputStreamBackend, but when filename ends in ".gz" the whole
		//! file is inflated into a seekable chunked in-memory backend first, so callers see
		//! the original uncompressed bytes. Corrupt or truncated gzip data is
		//! reported like a missing file (an invalid backend), never a crash.
		StreamBackend *openInflatingInputStreamBackend(const std::string& filename);

		//! Open a file in the SDL_IOStream format, COMPAT for GraphicContext PNG loader, can be removed on others backends
		SDL_IOStream *open(const std::string filename, const std::string mode="rb");
		//! Open an exact image filename, preserving user-directory precedence.
		//! Runtime artwork uses WebP; imports/previews may use other formats.
		SDL_IOStream *openImage(const std::string &filename);
		//! Open a file in the FILE* format
		FILE *openFP(const std::string filename, const std::string mode="rb");
		//! Open a file in the c++ stream format for reading
		std::ifstream *openIFStream(const std::string &fileName);
		//! Return the checksum of a file
		Uint32 checksum(const std::string filename);
		//! Return the modification date of a file
		time_t mtime(const std::string filename);
	
		// FIXME : the following functions are not thread-safe :
		//! must be call before directory listening, return true if success
		bool initDirectoryListing(const std::string virtualDir, const std::string extension="", const bool dirs=false);
		//! get the next name, return NULL if none
		const std::string getNextDirectoryEntry(void);
	};
}
