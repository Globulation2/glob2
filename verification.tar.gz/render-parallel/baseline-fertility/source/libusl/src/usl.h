#pragma once

#include "debug.h"
#include "types.h"

#include <istream>
#include <memory>

struct Thread;
struct Scope;

struct Usl
{
	// Standalone interpreters may load files; embedded map scripts must opt out.
	explicit Usl(bool allowFileLoading = true);
	virtual ~Usl();
	
	void markGarbage() const;
	void collectGarbage();
	void includeScript(const std::string& name, std::istream& source);
	void createThread(const std::string& name, std::istream& source);
	void setConstant(const std::string& name, Value* value);
	Value* getConstant(const std::string& name) const;
	
	virtual std::ifstream* openFile(const std::string& name);
	
	typedef std::vector<Thread> Threads;
	
	DebugInfo debug;
	Heap heap;
	std::unique_ptr<Scope> root;
	std::unique_ptr<Prototype> prototype;
	Threads threads;
	
	/// Run one thread (round-robin over all threads) for a maximum of steps bytecodes executions
	size_t run(size_t steps);
	
private:
	Scope* compile(const std::string& name, std::istream& source);
	Thread* createThread(Scope* scope);
	friend struct Load;
};

