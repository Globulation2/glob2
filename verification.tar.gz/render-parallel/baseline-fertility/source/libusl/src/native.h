#include <limits>
#include <cstdint>
#pragma once

#include "usl.h"
#include "interpreter.h"
#include "code.h"
#include "types.h"
#include "position.h"

#include <functional>
#include <mutex>
#include <sstream>
#include <type_traits>

/// Parameter count and first parameter type of a function signature such as R(A, B)
template<typename Function>
struct FunctionSignature;

template<typename Result>
struct FunctionSignature<Result()>
{
	static constexpr size_t arity = 0;
};

template<typename Result, typename Argument1, typename... Arguments>
struct FunctionSignature<Result(Argument1, Arguments...)>
{
	static constexpr size_t arity = 1 + sizeof...(Arguments);
	typedef Argument1 FirstArgument;
};

template<typename Function>
struct NativeFunction: NativeCode
{
	typedef std::function<Function> Callable;
	Callable function;

	NativeFunction(const std::string& name, const Callable& function, bool receiver = false);
	
	void prologue(ThunkPrototype* thunk);
	void execute(Thread* thread);
	
	bool receiver;
};

template<typename This>
struct NativeValuePrototype: Prototype
{
	NativeValuePrototype(Heap* heap):
		Prototype(heap)
	{
	}
	
private:
	template<typename Thiss> friend struct NativeValue;
	/// specialize this method to add members to a native value prototype
	void initialize()
	{}
	
	template<typename Function>
	void addMethod(const std::string& name, const std::function<Function>& function)
	{
		static_assert(std::is_same<This, typename FunctionSignature<Function>::FirstArgument>::value, "method receiver must be the first argument");
		NativeCode* native = new NativeFunction<Function>(name, function, true);
		Prototype::addMethod(native);
	}
};

/// Every heap shares one static prototype per native type, and each NativeValue points it at
/// its own heap and re-adds its methods there. Two games constructed on different threads
/// would allocate those methods into each other's heaps, so that update is serialized.
/// Recursive, since a prototype's methods may themselves construct native values.
inline std::recursive_mutex& nativePrototypeMutex()
{
	static std::recursive_mutex mutex;
	return mutex;
}

template<typename This>
struct NativeValue: Value
{
	static NativeValuePrototype<This>* prototypeFor(Heap* heap) {
		assert(heap);
		const auto key = std::type_index(typeid(This));
		auto found = heap->nativePrototypes.find(key);
		if (found != heap->nativePrototypes.end()) return static_cast<NativeValuePrototype<This>*>(found->second);
		auto* prototype = new NativeValuePrototype<This>(heap);
		heap->nativePrototypes.emplace(key, prototype);
		prototype->initialize();
		return prototype;
	}
	
	NativeValue(Heap* heap, const This& value):
		Value(heap, prototypeFor(heap)),
		value(value)
	{
	}
	
	const This value;
	
	operator const This&() { return value; }
	
	void dumpSpecific(std::ostream &stream) const
	{
		stream << "= " << value;
	}
};


template<typename T>
inline const T& unbox(Thread* thread, Value*& value)
{
	NativeValue<T>* native = dynamic_cast<NativeValue<T>*>(value);
	if (native == 0)
		throw Exception(thread->usl->debug.find(thread->frames.back().thunk->thunkPrototype(),
			thread->frames.back().nextInstr), "Invalid native argument type");
	if constexpr (std::is_pointer_v<T>)
		if (!native->value) throw Exception(Position(), "Unavailable native receiver");
	return native->value;
}

template<>
inline Value*const& unbox<Value*>(Thread* thread, Value*& value) // ugly reference to constant pointer
{
	return value;
}

template<typename T>
inline T pop(Thread* thread)
{
	Thread::Frame::Stack& stack = thread->frames.back().stack;
	Value* value = stack.back();
	stack.pop_back();
	return unbox<T>(thread, value);
}


template<typename T>
inline Value* box(Thread* thread, const T& t)
{
	return new NativeValue<T>(&thread->usl->heap, t);
}

template<>
inline Value* box<Value*>(Thread* thread, Value*const& value) // ugly reference to constant pointer
{
	return value;
}

template<>
inline Value* box<bool>(Thread* thread, const bool& value)
{
	std::string name = value ? "true" : "false";
	return thread->usl->getConstant(name);
}

template<typename T>
inline void push(Thread* thread, const T& t)
{
	Thread::Frame::Stack& stack = thread->frames.back().stack;
	Value* value = box(thread, t);
	stack.push_back(value);
}


template<typename Result>
void execute(const std::function<Result(void)>& function, Thread* thread)
{
	const Result& result = function();
	push(thread, result);
}

inline void execute(const std::function<void(void)>& function, Thread* thread)
{
	function();
	push(thread, &nil);
}


template<typename Result, typename Argument>
void execute(const std::function<Result(Argument)>& function, Thread* thread)
{
	const Argument& argument = pop<Argument>(thread);
	const Result& result = function(argument);
	push(thread, result);
}

template<typename Argument>
void execute(const std::function<void(Argument)>& function, Thread* thread)
{
	const Argument& argument = pop<Argument>(thread);
	function(argument);
	push(thread, &nil);
}


template<typename Result, typename Argument1, typename Argument2>
void execute(const std::function<Result(Argument1, Argument2)>& function, Thread* thread)
{
	const Argument1& argument1 = pop<Argument1>(thread);
	const Argument2& argument2 = pop<Argument2>(thread);
	const Result& result = function(argument1, argument2);
	push(thread, result);
}

template<typename Argument1, typename Argument2>
void execute(const std::function<void(Argument1, Argument2)>& function, Thread* thread)
{
	const Argument1& argument1 = pop<Argument1>(thread);
	const Argument2& argument2 = pop<Argument2>(thread);
	function(argument1, argument2);
	push(thread, &nil);
}


template<typename Result, typename Argument1, typename Argument2, typename Argument3>
void execute(const std::function<Result(Argument1, Argument2, Argument3)>& function, Thread* thread)
{
	const Argument1& argument1 = pop<Argument1>(thread);
	const Argument2& argument2 = pop<Argument2>(thread);
	const Argument3& argument3 = pop<Argument3>(thread);
	const Result& result = function(argument1, argument2, argument3);
	push(thread, result);
}

template<typename Argument1, typename Argument2, typename Argument3>
void execute(const std::function<void(Argument1, Argument2, Argument3)>& function, Thread* thread)
{
	const Argument1& argument1 = pop<Argument1>(thread);
	const Argument2& argument2 = pop<Argument2>(thread);
	const Argument3& argument3 = pop<Argument3>(thread);
	function(argument1, argument2, argument3);
	push(thread, &nil);
}


template<typename Result, typename Argument1, typename Argument2, typename Argument3, typename Argument4>
void execute(const std::function<Result(Argument1, Argument2, Argument3, Argument4)>& function, Thread* thread)
{
	const Argument1& argument1 = pop<Argument1>(thread);
	const Argument2& argument2 = pop<Argument2>(thread);
	const Argument3& argument3 = pop<Argument3>(thread);
	const Argument4& argument4 = pop<Argument4>(thread);
	const Result& result = function(argument1, argument2, argument3, argument4);
	push(thread, result);
}

template<typename Argument1, typename Argument2, typename Argument3, typename Argument4>
void execute(const std::function<void(Argument1, Argument2, Argument3, Argument4)>& function, Thread* thread)
{
	const Argument1& argument1 = pop<Argument1>(thread);
	const Argument2& argument2 = pop<Argument2>(thread);
	const Argument3& argument3 = pop<Argument3>(thread);
	const Argument4& argument4 = pop<Argument4>(thread);
	function(argument1, argument2, argument3, argument4);
	push(thread, &nil);
}


template<typename Result, typename Argument1, typename Argument2, typename Argument3, typename Argument4, typename Argument5>
void execute(const std::function<Result(Argument1, Argument2, Argument3, Argument4, Argument5)>& function, Thread* thread)
{
	const Argument1& argument1 = pop<Argument1>(thread);
	const Argument2& argument2 = pop<Argument2>(thread);
	const Argument3& argument3 = pop<Argument3>(thread);
	const Argument4& argument4 = pop<Argument4>(thread);
	const Argument5& argument5 = pop<Argument5>(thread);
	const Result& result = function(argument1, argument2, argument3, argument4, argument5);
	push(thread, result);
}

template<typename Argument1, typename Argument2, typename Argument3, typename Argument4, typename Argument5>
void execute(const std::function<void(Argument1, Argument2, Argument3, Argument4, Argument5)>& function, Thread* thread)
{
	const Argument1& argument1 = pop<Argument1>(thread);
	const Argument2& argument2 = pop<Argument2>(thread);
	const Argument3& argument3 = pop<Argument3>(thread);
	const Argument4& argument4 = pop<Argument4>(thread);
	const Argument5& argument5 = pop<Argument5>(thread);
	function(argument1, argument2, argument3, argument4, argument5);
	push(thread, &nil);
}



template<typename Function>
NativeFunction<Function>::NativeFunction(const std::string& name, const Callable& function, bool receiver):
	NativeCode(name),
	function(function),
	receiver(receiver)
{}

template<typename Function>
void NativeFunction<Function>::prologue(ThunkPrototype* thunk)
{
	size_t arguments = FunctionSignature<Function>::arity;
	if (receiver)
		--arguments;
	
	if (arguments > 0)
	{
		thunk->body.push_back(new EvalCode()); // evaluate the argument
		if (arguments > 1)
		{
			for (int i = arguments - 1; i >= 0; --i)
			{
				std::ostringstream str;
				str << i;

				thunk->body.push_back(new DupCode(arguments - i - 1));
				thunk->body.push_back(new SelectCode(str.str()));
				thunk->body.push_back(new EvalCode());
			}
		}
	}
	else
	{
		thunk->body.push_back(new PopCode()); // dump the argument
	}
	
	if (receiver)
	{
		thunk->body.push_back(new ThunkCode()); // get the current thunk
		thunk->body.push_back(new ParentCode()); // get the parent value
	}
}

template<typename Function>
void NativeFunction<Function>::execute(Thread* thread)
{
	::execute(function, thread);
}


typedef NativeValue<int> Integer;
typedef NativeValue<std::string> String;


inline int checkedScriptInteger(std::int64_t value)
{
	if (value < std::numeric_limits<int>::min() || value > std::numeric_limits<int>::max())
		throw Exception(Position(), "Script integer overflow");
	return static_cast<int>(value);
}

template<>
inline void NativeValuePrototype<int>::initialize()
{
	addMethod<int (int     )>("_-", [](int a) { return checkedScriptInteger(-std::int64_t(a)); });
	addMethod<int (int, int)>("+", [](int a, int b) { return checkedScriptInteger(std::int64_t(a) + b); });
	addMethod<int (int, int)>("-", [](int a, int b) { return checkedScriptInteger(std::int64_t(a) - b); });
	addMethod<int (int, int)>("*", [](int a, int b) { return checkedScriptInteger(std::int64_t(a) * b); });
	addMethod<bool(int, int)>("<", std::less<int>());
	addMethod<bool(int, int)>(">", std::greater<int>());
	addMethod<bool(int, int)>("<=", std::less_equal<int>());
	addMethod<bool(int, int)>(">=", std::greater_equal<int>());
	addMethod<bool(int, int)>("=", std::equal_to<int>());
	addMethod<bool(int, int)>("!=", std::not_equal_to<int>());
}
