#include <PresentationWork.h>
#include <cassert>
#include <iostream>
#include <string>
struct Dispatcher : GAGCore::PresentationWork {
    unsigned calls = 0;
    void executePresentationJobs(std::size_t count, const std::function<void(std::size_t)> &job) override {
        ++calls;
        for (std::size_t i = 0; i < count; ++i) job(i);
    }
};
int main(int argc, char **argv) {
    assert(argc == 2);
    try {
        const auto mode = GAGCore::renderExecution();
        assert(std::string(argv[1]) != "invalid");
        assert(static_cast<int>(mode) == std::stoi(argv[1]));
        Dispatcher dispatcher;
        unsigned executed = 0;
        {
            GAGCore::PresentationWorkScope scope(dispatcher);
            GAGCore::executePresentationJobs(3, [&](std::size_t) { ++executed; });
        }
        assert(executed == 3);
        assert(dispatcher.calls == (mode == GAGCore::RenderExecution::Parallel ? 1u : 0u));
        assert(GAGCore::PresentationWork::current == nullptr);
    } catch (const std::invalid_argument &error) {
        assert(std::string(argv[1]) == "invalid");
        assert(std::string(error.what()) == "GLOB2_RENDER_EXECUTION must be immediate, serial or parallel");
    }
    std::cout << "passed\n";
}
