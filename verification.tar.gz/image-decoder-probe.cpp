#include <SDL3/SDL.h>
#include <SDL3_image/SDL_image.h>
#include "LossyAlphaFixture.h"
#include <cstdio>
#include <initializer_list>
#include <cstring>
int main(){int failures=0; for(auto decoder:{IMG_Load_IO,SDL_LoadPNG_IO}) {auto s=decoder(SDL_IOFromConstMem(rgba16Fixture::png,sizeof(rgba16Fixture::png)),true); if(!s)return 2;auto r=SDL_ConvertSurface(s,SDL_PIXELFORMAT_RGBA32);if(!r)return 3;for(int y=0;y<2;y++){auto p=(unsigned char*)r->pixels+y*r->pitch;for(int x=0;x<8;x++)printf("%u/%u ",p[x],rgba16Fixture::rgba[y*8+x]);puts("");failures+=memcmp(p,rgba16Fixture::rgba+y*8,8)!=0;}SDL_DestroySurface(r);SDL_DestroySurface(s);}return failures?1:0;}
