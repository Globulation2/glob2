#define VK_NO_PROTOTYPES
#include "third_party/vulkan/vulkan_core.h"
#include <dlfcn.h>
#include <cstdio>
#include <vector>
int main(){
 auto library=dlopen("libvulkan.so.1",RTLD_NOW);
 auto proc=(PFN_vkGetInstanceProcAddr)dlsym(library,"vkGetInstanceProcAddr");
 auto create=(PFN_vkCreateInstance)proc(nullptr,"vkCreateInstance");
 VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};app.apiVersion=VK_API_VERSION_1_0;
 VkInstanceCreateInfo info{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};info.pApplicationInfo=&app;
 VkInstance instance{};if(create(&info,nullptr,&instance))return 1;
 auto list=(PFN_vkEnumeratePhysicalDevices)proc(instance,"vkEnumeratePhysicalDevices");
 auto properties=(PFN_vkGetPhysicalDeviceProperties)proc(instance,"vkGetPhysicalDeviceProperties");
 auto memory=(PFN_vkGetPhysicalDeviceMemoryProperties)proc(instance,"vkGetPhysicalDeviceMemoryProperties");
 unsigned count=0;list(instance,&count,nullptr);std::vector<VkPhysicalDevice> devices(count);list(instance,&count,devices.data());
 for(auto device:devices){VkPhysicalDeviceProperties p{};properties(device,&p);VkPhysicalDeviceMemoryProperties m{};memory(device,&m);std::printf("%s driver=%u\n",p.deviceName,p.driverVersion);for(unsigned i=0;i<m.memoryTypeCount;++i)std::printf("type %u flags=0x%x heap=%u\n",i,m.memoryTypes[i].propertyFlags,m.memoryTypes[i].heapIndex);}
 ((PFN_vkDestroyInstance)proc(instance,"vkDestroyInstance"))(instance,nullptr);
 dlclose(library);
}
