import json,re,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'artifacts/cumulative'
NAMES={'static-warm':'Warm static terrain','animated-warm':'Animated terrain,1280x800','cold-first-frame':'Cold terrain first frame','streamed-pages':'Uncached terrain stress','gui-native-pan':'GUI pan,1x','gui-half-pan':'GUI pan,half-scale','gui-fractional':'GUI fractional,half-scale','animated-1080':'Animated terrain,1854x1011','gui-half-pan-1080':'GUI half-scale pan,1854x1011'}
fixed=json.loads((OUT/'measurements/results.json').read_text());tables=[]
for case in NAMES:
 rows={r['variant']:r['metrics'] for r in fixed['summary'] if r['case']==case};row={'case':case,'label':NAMES[case],'variants':{}}
 for variant,m in rows.items():
  row['variants'][variant]={'frame_ms':m['frame_median_ms']['median'],'cpu_ms':m['cpu_ms']['median'],'frame_change_percent':(m['frame_median_ms']['median_paired_ratio']-1)*100,'cpu_change_percent':(m['cpu_ms']['median_paired_ratio']-1)*100,'frame_p99_ms':m['frame_p99_ms']['median'] if case!='cold-first-frame' else None,'rss_mib':m['peak_rss_kib']['median']/1024,'frame_paired_range':[(min(m['frame_median_ms']['paired_ratios'])-1)*100,(max(m['frame_median_ms']['paired_ratios'])-1)*100]}
 tables.append(row)
summary={'fixed':tables,'fixed_run_count':len(fixed['runs']),'fixed_compiler_contended_runs':sum(bool(r['before']['compilers'] or r['after']['compilers']) for r in fixed['runs']),'interactive':[],'accelerated':[],'captures':None}
p=OUT/'interactive/results.json'
if p.exists():
 interactive=json.loads(p.read_text());summary['interactive_run_count']=len(interactive['runs']);summary['interactive_analysis_excludes_repeat']=0;summary['interactive_exclusion_reason']='Separate CPU/GPU simulation campaign began during the first rotated group; exclude the entire first group uniformly because host load was ramping. Remaining data still represents uncontrolled background contention, not isolated renderer causality.'
 for case in ['stationary','panning','panning-constrained']:
  for variant in ['original','current-auto','current-parallel']:
   rows=[r for r in interactive['runs'] if r['case']==case and r['variant']==variant and r['repeat']!=0]
   if not rows:continue
   summary['interactive'].append({'case':case,'variant':variant,'trials':len(rows),'cpu_ms':statistics.median(r['cpu_ms_per_frame'] for r in rows),'displayed_fps':statistics.median(r['displayed_fps'] for r in rows),'draw_p99_ms':statistics.median(r['draw_and_present']['p99'] for r in rows),'scene_age_p99_ms':statistics.median(r['displayed_scene_age']['p99'] for r in rows),'latest_lateness_p99_ms':statistics.median(r['last_simulation_deadline_lateness']['p99'] for r in rows),'missed_fraction':statistics.median(r['missed_fraction'] for r in rows),'rss_mib':statistics.median(r['peak_rss_kib'] for r in rows)/1024})
p=OUT/'accelerated/results.json'
if p.exists():
 accelerated=json.loads(p.read_text());summary['accelerated_run_count']=len(accelerated['runs'])
 for backend in ['legacy-gl','programmable-gl','sdl-gpu']:
  selected=[r for r in accelerated['runs'] if r['backend']==backend];original={r['repeat']:r for r in selected if r['variant']=='original'}
  for variant in ['original','current']:
   rows=[r for r in selected if r['variant']==variant and r['repeat'] in original]
   if not rows:continue
   summary['accelerated'].append({'backend':backend,'variant':variant,'trials':len(rows),'frame_ms':statistics.median(r['complete_frame']['median'] for r in rows),'cpu_ms':statistics.median(r['cpu_ms'] for r in rows),'frame_change_percent':(statistics.median(r['complete_frame']['median']/original[r['repeat']]['complete_frame']['median'] for r in rows)-1)*100,'cpu_change_percent':(statistics.median(r['cpu_ms']/original[r['repeat']]['cpu_ms'] for r in rows)-1)*100,'rss_mib':statistics.median(r['peak_rss_kib'] for r in rows)/1024})
p=OUT/'captures/results.json'
if p.exists():summary['captures']=json.loads(p.read_text())['comparisons']
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['fixed','captures']},indent=2))
