import hashlib,json,os,re,statistics,subprocess,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'artifacts/cumulative/interactive';OUT.mkdir(parents=True,exist_ok=True)
BINS={'original':Path(os.getenv('GLOB2_BENCH_ORIGINAL',str(ROOT/'build/linux/client/release/test/SoftwareRenderBenchmark'))),'current-auto':Path(os.getenv('GLOB2_BENCH_CURRENT','/home/bradley/.codex/worktrees/render-refinement/glob2/build/linux/client/release/test/SoftwareRenderBenchmark')),'current-parallel':Path(os.getenv('GLOB2_BENCH_CURRENT','/home/bradley/.codex/worktrees/render-refinement/glob2/build/linux/client/release/test/SoftwareRenderBenchmark'))}
from measure import state,distribution,ASSETS,FIXTURE
result={'original_revision':'9b853c4a3dcb2647b8828b77bb48faf5251a3de5','current_revision':'2d5cf67e8ea20ad8ebb983c9b207e24234e0356c','binary_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in BINS.items()},'fixture_sha256':hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),'scope':'Native X11 software, real simulation and scene workers, 60 FPS external schedule (internal pacer disabled), 12 seconds/run, default clouds/1x GUI, seven rotated triples/workload. Process CPU includes simulation and scene work. Per-run p99 summarized without pooling; latest simulation lateness sampled at display, not per-tick distribution.','runs':[]}
start_repeat=int(os.getenv('GLOB2_BENCH_REPEAT_START','0'));end_repeat=int(os.getenv('GLOB2_BENCH_REPEAT_END','7'))
if start_repeat and (OUT/'results.json').exists():result=json.loads((OUT/'results.json').read_text())
for repeat in range(start_repeat,end_repeat):
 for case,pan,threads,workers in [('stationary',False,4,2),('panning',True,4,2),('panning-constrained',True,2,1)]:
  order=list(BINS);order=order[repeat%3:]+order[:repeat%3]
  if repeat%2:order.reverse()
  for variant in order:
   name=f'{case}-{repeat}-{variant}';configured={'PROFILE_SAVE':str(FIXTURE),'PROFILE_MODE':'interactive','PROFILE_SECONDS':'12','PROFILE_FPS':'60','GLOB2_RENDER_EXECUTION':'parallel' if variant=='current-parallel' else 'auto','GLOB2_RENDER_WORKERS':str(workers),'GLOB2_UI_SCALE':'1','DISPLAY':os.environ.get('DISPLAY',':1'),'SDL_VIDEODRIVER':'x11','GLOB2_ASSET_DIR':str(ASSETS)}
   if pan:configured['PROFILE_PAN']='1'
   before=state()
   with tempfile.TemporaryDirectory(prefix='glob2-cumulative-interactive-') as profile:
    configured['GLOB2_USER_DATA_DIR']=profile;env={k:v for k,v in os.environ.items() if not k.startswith('PROFILE_') and not k.startswith('GLOB2_RENDER_')};env.update(configured)
    memory=Path(profile)/'memory.txt';command=[str(BINS[variant]),'--compute-threads',str(threads),'--renderer','software','--window-size','1280x800','--mute','--no-fullscreen'];r=subprocess.run(['/usr/bin/time','-f','%M','-o',str(memory),*command],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180);rss=int(memory.read_text().strip()) if r.returncode==0 else None
   (OUT/f'{name}.log').write_text(r.stdout)
   if r.returncode:raise RuntimeError(name)
   m=re.search(r'interactive frames=(\d+) opportunities=(\d+) undrawn_opportunities=(\d+) missed_render_deadlines=(\d+) period_ns=(\d+)',r.stdout)
   counts=dict(zip(['frames','opportunities','undrawn','missed','period_ns'],map(int,m.groups())))
   cpu=float(re.search(r'interactive_cpu_ms_per_frame=([\d.]+)',r.stdout)[1]);elapsed=float(re.search(r'interactive_elapsed_seconds=([\d.]+)',r.stdout)[1])
   row={'name':name,'case':case,'repeat':repeat,'variant':variant,'command':command,'environment':configured,'counts':counts,'cpu_ms_per_frame':cpu,'displayed_fps':counts['frames']/elapsed,'missed_fraction':counts['missed']/counts['frames'],'peak_rss_kib':rss,'draw_and_present':distribution(r.stdout,'draw_and_present'),'displayed_scene_age':distribution(r.stdout,'displayed_scene_age'),'last_simulation_deadline_lateness':distribution(r.stdout,'last_simulation_deadline_lateness'),'before':before,'after':state()}
   result['runs'].append(row);(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(name,cpu,counts,row['draw_and_present'],flush=True)
print('COMPLETE',len(result['runs']),flush=True)
