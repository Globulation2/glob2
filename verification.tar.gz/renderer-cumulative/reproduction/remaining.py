from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parents[3]
for name in ['interactive','accelerated','captures']:
 with (r/f'artifacts/cumulative/{name}.log').open('w') as log:
  result=subprocess.run([sys.executable,str(r/f'artifacts/cumulative/reproduction/{name}.py')],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:raise SystemExit(result.returncode)
 print('COMPLETED',name,flush=True)
