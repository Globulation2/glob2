import json,time,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'artifacts/cumulative'
with (OUT/'host-load.jsonl').open('w') as out:
 while not (OUT/'stop-host-load').exists():
  workers=[]
  for p in Path('/proc').glob('[0-9]*/comm'):
   try:
    name=p.read_text().strip()
    if name not in {'glob2-engine','cc1plus','cc1','SoftwareRenderB'}:continue
    stat=(p.parent/'stat').read_text().rsplit(')',1)[1].split()
    workers.append({'pid':int(p.parent.name),'name':name,'cpu_ticks':int(stat[11])+int(stat[12])})
   except (OSError,ValueError):pass
  row={'utc_epoch_seconds':time.time(),'load_average':os.getloadavg(),'cpu_stat':Path('/proc/stat').read_text().splitlines()[0],'processes':workers};out.write(json.dumps(row)+'\n');out.flush();time.sleep(2)
