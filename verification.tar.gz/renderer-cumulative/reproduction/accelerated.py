import hashlib,json,os,re,subprocess,tempfile
from pathlib import Path
from measure import ROOT,COMMON,state,distribution
OUT=ROOT/'artifacts/cumulative/accelerated';OUT.mkdir(parents=True,exist_ok=True)
BINS={'original':Path(os.getenv('GLOB2_BENCH_ORIGINAL',str(ROOT/'build/linux/client/release/test/SoftwareRenderBenchmark'))),'current':Path(os.getenv('GLOB2_BENCH_CURRENT','/home/bradley/.codex/worktrees/render-refinement/glob2/build/linux/client/release/test/SoftwareRenderBenchmark'))}
result={'scope':'Native AMD Radeon680M, X11, paused half-scale GUI pan,1280x800,240+30 frames, seven alternating pairs/backend; present included. GPU dispatch/present CPU wall timings are not GPU execution timestamps.','runs':[],'binary_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in BINS.items()}}
for repeat in range(7):
 for backend in ['legacy-gl','programmable-gl','sdl-gpu']:
  for variant in (list(BINS) if repeat%2==0 else list(BINS)[::-1]):
   name=f'{backend}-{repeat}-{variant}';configured={**COMMON,'PROFILE_MODE':'gui','PROFILE_ZOOM':'0.5','PROFILE_PAN':'1','PROFILE_PAUSED':'1','PROFILE_RECORD':'off','GLOB2_RENDER_EXECUTION':'auto'};before=state()
   with tempfile.TemporaryDirectory(prefix='glob2-cumulative-device-') as profile:
    configured['GLOB2_USER_DATA_DIR']=profile;env={k:v for k,v in os.environ.items() if not k.startswith('PROFILE_') and not k.startswith('GLOB2_RENDER_')};env.update(configured)
    memory=Path(profile)/'memory.txt';command=[str(BINS[variant]),'--compute-threads','4','--renderer',backend,'--window-size','1280x800','--mute','--no-fullscreen'];r=subprocess.run(['/usr/bin/time','-f','%M','-o',str(memory),*command],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180);rss=int(memory.read_text().strip()) if r.returncode==0 else None
   (OUT/f'{name}.log').write_text(r.stdout)
   if r.returncode:raise RuntimeError(name)
   checksum=int(re.search(r'simulation_checksum=(\d+)',r.stdout)[1])
   if checksum!=2231453127:raise RuntimeError('checksum')
   identity=re.search(r'RENDER_IDENTITY.*',r.stdout)[0]
   expected='opengl' if backend=='legacy-gl' else backend
   if f'backend={expected} ' not in identity:raise RuntimeError(f'Unexpected renderer: {identity}')
   row={'name':name,'backend':backend,'variant':variant,'repeat':repeat,'command':command,'environment':configured,'before':before,'after':state(),'cpu_ms':float(re.search(r'process_cpu_ms_per_frame=([\d.]+)',r.stdout)[1]),'complete_frame':distribution(r.stdout,'complete_frame'),'peak_rss_kib':rss,'identity':re.search(r'RENDER_IDENTITY.*',r.stdout)[0]}
   result['runs'].append(row);(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(name,row['cpu_ms'],row['complete_frame'],flush=True)
