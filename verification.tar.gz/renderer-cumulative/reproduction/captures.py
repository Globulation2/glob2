import hashlib,json,os,subprocess,tempfile
from pathlib import Path
from PIL import Image,ImageChops
from measure import ROOT,COMMON,BINS
OUT=ROOT/'artifacts/cumulative/captures';OUT.mkdir(parents=True,exist_ok=True)
result={'scope':'Fixed scene; same frame-driven terrain phases; paused GUI300+30 frames stabilizes HUD clock. Compare RGBA pixels, not image metadata.','runs':[],'comparisons':[]}
for case,extra in {'animated-map':{'PROFILE_MODE':'map','PROFILE_WHOLE_MAP':'1','PROFILE_FRAMES':'240'},'static-map':{'PROFILE_MODE':'map','PROFILE_WHOLE_MAP':'1','PROFILE_PAUSED':'1','PROFILE_FRAMES':'240'},'gui-native-pan':{'PROFILE_MODE':'gui','PROFILE_PAN':'1','PROFILE_PAUSED':'1'},'gui-half-pan':{'PROFILE_MODE':'gui','PROFILE_PAN':'1','PROFILE_ZOOM':'0.5','PROFILE_PAUSED':'1'},'gui-half-fractional':{'PROFILE_MODE':'gui','PROFILE_FRACTION':'1','PROFILE_ZOOM':'0.5','PROFILE_PAUSED':'1'}}.items():
 images={}
 for variant in ['original','current-auto','current-parallel']:
  name=f'{case}-{variant}';bmp=OUT/f'{name}.bmp';configured={**COMMON,'PROFILE_FRAMES':'300',**extra,'PROFILE_CAPTURE':str(bmp),'GLOB2_RENDER_EXECUTION':'parallel' if variant=='current-parallel' else 'auto'}
  with tempfile.TemporaryDirectory(prefix='glob2-cumulative-capture-') as profile:
   configured['GLOB2_USER_DATA_DIR']=profile;env={k:v for k,v in os.environ.items() if not k.startswith('PROFILE_') and not k.startswith('GLOB2_RENDER_')};env.update(configured);command=[str(BINS[variant]),'--compute-threads','4','--renderer','software','--window-size','1280x800','--mute','--no-fullscreen'];r=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
  (OUT/f'{name}.log').write_text(r.stdout)
  if r.returncode:raise RuntimeError(name)
  im=Image.open(bmp).convert('RGBA');images[variant]=im;png=OUT/f'{name}.png';im.save(png);bmp.unlink()
  result['runs'].append({'name':name,'command':command,'environment':configured,'rgba_sha256':hashlib.sha256(im.tobytes()).hexdigest()})
 for variant in ['current-auto','current-parallel']:
  a=images['original'];b=images[variant];count=sum(p!=q for p,q in zip(a.getdata(),b.getdata()));box=ImageChops.difference(a.convert('RGB'),b.convert('RGB')).getbbox();row={'case':case,'variant':variant,'differing_pixels':count,'bbox':box};result['comparisons'].append(row);print(row,flush=True)
 (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
