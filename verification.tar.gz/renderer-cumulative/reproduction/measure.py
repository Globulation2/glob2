import hashlib,json,os,re,statistics,subprocess,tempfile,time,platform
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'artifacts/cumulative/measurements';OUT.mkdir(parents=True,exist_ok=True)
ASSETS=Path(os.getenv('GLOB2_BENCH_ASSETS','/home/bradley/glob2/artifacts/pr-1151-render-refinement/runtime-assets'))
FIXTURE=Path(os.getenv('GLOB2_BENCH_FIXTURE',str(ASSETS.parent/'fixture.game')))
BINS={'original':Path(os.getenv('GLOB2_BENCH_ORIGINAL',str(ROOT/'build/linux/client/release/test/SoftwareRenderBenchmark'))),'current-auto':Path(os.getenv('GLOB2_BENCH_CURRENT','/home/bradley/.codex/worktrees/render-refinement/glob2/build/linux/client/release/test/SoftwareRenderBenchmark')),'current-parallel':Path(os.getenv('GLOB2_BENCH_CURRENT','/home/bradley/.codex/worktrees/render-refinement/glob2/build/linux/client/release/test/SoftwareRenderBenchmark'))}
COMMON={'PROFILE_SAVE':str(FIXTURE),'PROFILE_FRAMES':'240','PROFILE_WARMUP':'30','PROFILE_CLOUDS':'0','GLOB2_RENDER_WORKERS':'2','GLOB2_UI_SCALE':'1','GLOB2_ASSET_DIR':str(ASSETS),'DISPLAY':os.environ.get('DISPLAY',':1'),'SDL_VIDEODRIVER':'x11','GLOB2_RENDERER_SHADER_DIR':os.getenv('GLOB2_BENCH_SHADERS','/home/bradley/glob2/artifacts/pr-1148-parallel-rendering/native-shaders')}
CASES={
 'static-warm':{'PROFILE_MODE':'map','PROFILE_WHOLE_MAP':'1','PROFILE_PAUSED':'1'},
 'animated-warm':{'PROFILE_MODE':'map','PROFILE_WHOLE_MAP':'1'},
 'cold-first-frame':{'PROFILE_MODE':'map','PROFILE_WHOLE_MAP':'1','PROFILE_PAUSED':'1','PROFILE_FRAMES':'1','PROFILE_WARMUP':'0'},
 'streamed-pages':{'PROFILE_MODE':'map','PROFILE_WHOLE_MAP':'1','PROFILE_PAUSED':'1','PROFILE_TERRAIN_CACHE':'0','PROFILE_FRAMES':'60'},
 'gui-native-pan':{'PROFILE_MODE':'gui','PROFILE_PAN':'1','PROFILE_PAUSED':'1'},
 'gui-half-pan':{'PROFILE_MODE':'gui','PROFILE_ZOOM':'0.5','PROFILE_PAN':'1','PROFILE_PAUSED':'1'},
 'gui-fractional':{'PROFILE_MODE':'gui','PROFILE_ZOOM':'0.5','PROFILE_FRACTION':'1','PROFILE_PAUSED':'1'},
 'animated-1080':{'PROFILE_MODE':'map','PROFILE_WHOLE_MAP':'1','SIZE':'1920x1080'},
 'gui-half-pan-1080':{'PROFILE_MODE':'gui','PROFILE_ZOOM':'0.5','PROFILE_PAN':'1','PROFILE_PAUSED':'1','SIZE':'1920x1080'},
}
BINS['current-serial']=BINS['current-auto']

def compilers():
 n=0
 for p in Path('/proc').glob('[0-9]*/comm'):
  try:n+=p.read_text().strip() in {'cc1plus','cc1'}
  except OSError:pass
 return n

def state():
 thermal={}
 for p in [*Path('/sys/class/thermal').glob('thermal_zone*/temp'),*Path('/sys/class/hwmon').glob('hwmon*/temp*_input')]:
  try:thermal[str(p)]=int(p.read_text())
  except (OSError,ValueError):pass
 return {'load':os.getloadavg(),'compilers':compilers(),'thermal_millidegrees':thermal}

def distribution(log,label):
 m=re.search(rf'^{label} mean_ms=([\d.]+) median_ms=([\d.]+) p95_ms=([\d.]+) p99_ms=([\d.]+)',log,re.M)
 return dict(zip(['mean','median','p95','p99'],map(float,m.groups()))) if m else None

def summarize(result):
 result['summary']=[]
 for case in CASES:
  rows=[r for r in result['runs'] if r['case']==case]
  original={r['repeat']:r for r in rows if r['variant']=='original'}
  for variant in BINS:
   selected=[r for r in rows if r['variant']==variant]
   if not selected:continue
   metrics={}
   for metric in ['cpu_ms','wall_ms','frame_median_ms','frame_p95_ms','frame_p99_ms','peak_rss_kib']:
    vals=[r[metric] for r in selected];ratios=[r[metric]/original[r['repeat']][metric] for r in selected if r['repeat'] in original and original[r['repeat']][metric]]
    metrics[metric]={'median':statistics.median(vals),'min':min(vals),'max':max(vals),'paired_ratios':ratios,'median_paired_ratio':statistics.median(ratios) if ratios else None}
   result['summary'].append({'case':case,'variant':variant,'trials':len(selected),'metrics':metrics})
 (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__ == '__main__':
 result={'original_revision':'9b853c4a3dcb2647b8828b77bb48faf5251a3de5','current_revision':'2d5cf67e8ea20ad8ebb983c9b207e24234e0356c','scope':'Native X11 hidden windows; complete rendering including present; no PROFILE_CPU_SCOPES substitution; seven alternating pairs within rotated groups; per-run distributions, not pooled percentiles. Process CPU includes all workers. Simulation fixture frozen.','platform':platform.platform(),'cpu':subprocess.check_output(['lscpu'],text=True),'compiler':subprocess.check_output(['g++','--version'],text=True),'binary_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in BINS.items()},'fixture_sha256':hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),'runs':[]}
 for repeat in range(7):
  for case,extra in CASES.items():
   variants=[v for v in BINS if v!='current-serial' or case in ['animated-warm','streamed-pages','gui-half-pan']];offset=repeat%len(variants);variants=variants[offset:]+variants[:offset]
   if repeat%2:variants.reverse()
   for variant in variants:
    name=f'{case}-{repeat}-{variant}'
    configured={**COMMON,**{k:v for k,v in extra.items() if k!='SIZE'},'GLOB2_RENDER_EXECUTION':'parallel' if variant=='current-parallel' else 'serial' if variant=='current-serial' else 'auto'}
    before=state()
    if before['compilers']:print('CONTENTION',name,before,flush=True)
    with tempfile.TemporaryDirectory(prefix='glob2-cumulative-') as profile:
     configured['GLOB2_USER_DATA_DIR']=profile
     env={k:v for k,v in os.environ.items() if not k.startswith('PROFILE_') and not k.startswith('GLOB2_RENDER_')};env.update(configured)
     memory=Path(profile)/'memory.txt'
     command=[str(BINS[variant]),'--compute-threads','4','--renderer','software','--window-size',extra.get('SIZE','1280x800'),'--mute','--no-fullscreen']
     start=time.time();r=subprocess.run(['/usr/bin/time','-f','%M','-o',str(memory),*command],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
     rss=int(memory.read_text().strip()) if r.returncode==0 else None
    (OUT/f'{name}.log').write_text(r.stdout)
    if r.returncode:raise RuntimeError(f'{name} returned {r.returncode}')
    d=distribution(r.stdout,'complete_frame');cpu=float(re.search(r'process_cpu_ms_per_frame=([\d.]+)',r.stdout)[1]);frames=int(re.search(r'render_fps=[\d.]+ elapsed_seconds=[\d.]+ frames=(\d+)',r.stdout)[1]);elapsed=float(re.search(r'elapsed_seconds=([\d.]+)',r.stdout)[1]);checksum=int(re.search(r'simulation_checksum=(\d+)',r.stdout)[1])
    if checksum!=2231453127:raise RuntimeError('simulation checksum changed')
    cache=re.search(r'terrain_cache bytes=(\d+) mask_bytes=(\d+) hits=(\d+) rebuilds=(\d+)',r.stdout)
    row={'name':name,'case':case,'variant':variant,'repeat':repeat,'command':command,'environment':configured,'cpu_ms':cpu,'wall_ms':elapsed*1000/frames,'frame_median_ms':d['median'],'frame_p95_ms':d['p95'],'frame_p99_ms':d['p99'],'draw':distribution(r.stdout,'draw'),'present':distribution(r.stdout,'present'),'peak_rss_kib':rss,'simulation_checksum':checksum,'cache':dict(zip(['bytes','mask_bytes','hits','rebuilds'],map(int,cache.groups()))) if cache else None,'before':before,'after':state(),'elapsed_process_wall_seconds':time.time()-start}
    result['runs'].append(row);summarize(result);print(name,'cpu',cpu,'frame',d['median'],'rss',rss,flush=True)
 print('COMPLETE',len(result['runs']),flush=True)
