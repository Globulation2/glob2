from pathlib import Path
import json
p=Path('artifacts/air-complete-fast-path');s=json.loads((p/'summary75.json').read_text());pub=json.loads((p/'publication75.json').read_text());source=s['source'];n=s['native_suites']['native']['tests'];url=pub['url']
rows=['| Scenario | Master CPU ms | PR CPU ms | Change |','| --- | ---: | ---: | ---: |']
for r in s['performance']:
 a=r['versions']['master']['cpu_ms']['median'];b=r['versions']['direct']['cpu_ms']['median'];rows.append(f"| {r['case']} | {a:.2f} | {b:.2f} | {r['direct_vs_master_cpu_percent']:+.2f}% |")
table='\n'.join(rows)
body=f'''Flyers keep direct angular steering and local traffic avoidance on maps without air terrain modifiers or air-blocking resources. Food, healing, upgrades, inn rebooking, general building admission and explorer/warrior recruitment retain their historical geometric checks; these ordinary building-travel queries allocate no air fields. Forbidden paint remains ground-only, preserving the existing flying rule.

Maps that need air routing use shared movement-class fields, lazy cold queries and fixed-deadline refreshes. Resource/clearing goals and guard balancing retain shared routing. Ground material, clearing and guard seed loops, including the complete material-cache kernel, have separately compiled implementations. Unused air templates add neither per-cell air checks nor ground-only cache budget. Active air templates stay coherent, and changing worlds resets the cache.

Current master `{source['base']}` is integrated. Simulation revision is **75**, with its golden match regenerated. Save format **172** combines the air layout with master's tagged checksum metadata while preserving loading of master-format-168 and earlier PR-format-171 saves and order envelopes. The save floor remains 58; unreleased formats 169–170 stay rejected. Replay acceptance starts at 172 and the network protocol is 72.

Verified clean revision `{source['source']}` on Ubuntu 24.04.5 x86_64 / GCC 13.3: **{n} native tests and 340 Python tests passed, zero failures or skips**. Native tests include fullscreen graphics; the standard inventory excludes 38 opt-in benchmarks. Additional checks cover real 168/171 save continuations, complete per-tick records across 1/2/4/8 compute participants, eight save phases on ordinary/constrained air scenarios, Maxima serial/parallel continuation, the golden match and native replay/browser-reference corpora. [Raw evidence, commands, inventories, saves and traces]({url}).

Optimized CPU comparison against that master, identical dependencies/flags, four fixed physical cores, 128 warmup + 256 measured ticks, ten trials per scenario/revision:

{table}

The two ordinary-map profiles have identical field work to master: islands schedules 206 building fields and makes 8 synchronous queries; midgame schedules 355 and makes 37. Total instructions are +0.70% and +0.34%, concentrated in the shared material-cache, building-seed and propagation kernels. No extra scheduled or synchronous building fields remain in those captures.

Numbers are median process CPU time for the measured window. The archive retains all samples, ranges, input hashes, process/load snapshots and raw instruction profiles; timing ran after builds/tests finished. Small differences should be assessed against that variability, rather than treated as proof of exact parity. Earlier comments and measurements describe superseded revisions.

Gameplay effect: ordinary-map service/recruitment choices return to geometric ranking. Constrained-map choices may differ from the original private air solver. Automated scenarios do not replace maintainer play review. Actual browser/Windows/macOS/mobile execution, cross-platform checksum equivalence, sanitizers, hosted CI and release/store packaging are not newly qualified here. This PR remains draft.
'''
(p/'pr-body75.md').write_text(body)
comment=f'''Local verification and remaining-overhead changes are complete for `{source['source']}` against integrated master `{source['base']}`.

- Environment: Ubuntu 24.04.5, Linux x86_64, GCC 13.3. Optimized release, `dev_fast=0 release=1 retain_symbols=1 CXXFLAGS=-g1` (`-O3`, no PCH/unity). PR/master linked-library hashes match; dependency identity and original pinned prefixes are retained in the evidence.
- Results: **{n} native cases passed** ({s['native_suites']['engine-headless']['tests']} headless engine + {s['native_suites']['engine-display']['tests']} fullscreen/display engine + {s['native_suites']['unit']['tests']} unit), zero failures/errors/skips; **340 Python tests passed**. The two engine inventories are disjoint and cover the standard inventory; 38 explicit opt-in benchmarks are excluded.
- Compatibility: thread counts 1/2/4/8 compare 128 complete per-tick aggregate/entity records for both ordinary and constrained air maps; eight save phases each continue identically. Real 168/171 saves load and resume, Maxima serial and parallel continuations pass, and native replay/reference corpora plus the regenerated SIM75 match record verify. Save/replay/network acceptance checks are included in the native suites.
- Performance: ten trials per revision/scenario, sequential release runs after builds/tests completed, fixed four-core affinity and compute participants, 128 warmup + 256 measured ticks. All endpoints are stable within each revision. The archive includes raw reconciled Callgrind thread profiles and native endpoint verification.

{table}

Build command: `python3 tools/dev_build.py dev_fast=0 release=1 retain_symbols=1 CXXFLAGS=-g1 --build=/dev/shm/glob2-direct-air-release -j8 /dev/shm/glob2-direct-air-release/src/glob2 engine-tests unit-tests`, with `CCACHE_DIR=/dev/shm/glob2-air-ccache`, `GLOB2_SDL3_PREFIX=/home/bradley/glob2/build/sdl3/prefix`, `TMPDIR=/dev/shm/glob2-air-tmp`, and `GLOB2_GLSLANG=/dev/shm/glob2-air-glslang/StandAlone/glslang`.

Exact test/measurement commands, environments and input hashes are in `final75-native-commands.json`, `compat75-results.json`, `native-final75/commands.json`, and each profile's `command.json` in the archive. `run_final75_suite.py`, `run_compat75.py`, `native_bench75.py` `run_perf75_retry.py` and `run_native75_idle.py` retain the orchestration. Clean compiled-test provenance and app SHA are included. Older partial/stopped runs are explicitly superseded; the old explorer eligibility test now uses constrained terrain while retaining every accessibility/hunger assertion, and new ordinary-map tests check absence of air fields.

Coverage addresses routing/cache correctness, real inn swaps and arrivals, service selection, determinism, save/load and replay/network boundaries. Other operating systems/architectures and actual browsers were not executed, so cross-platform checksum equivalence remains unverified. Sanitizer, hosted CI and release/store matrices were not run. Human play feel and maintainer acceptance remain for review.

[Accessible evidence and SHA-256 archive digest]({url}). The PR remains draft. This replaces earlier revision-specific suite and timing claims.
'''
(p/'pr-comment75.md').write_text(comment)
