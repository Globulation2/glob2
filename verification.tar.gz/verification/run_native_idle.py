from pathlib import Path
import subprocess,time,json
out=Path('artifacts/air-merge-master');start=time.time();ledger=[];attempt=0
# Wait for final integrated functional verification, then obtain a quiet host.
import xml.etree.ElementTree as ET
while True:
 suite=out/'native-integrated.xml';checks=out/'integration-results.json'
 if suite.exists() and checks.exists() and json.loads(checks.read_text())[-1]['name']=='python' and all(int(ET.parse(suite).getroot().get(k,0))==0 for k in ('failures','errors','skipped')) and all(r['exit_code']==0 for r in json.loads(checks.read_text())):
  assert all(int(ET.parse(suite).getroot().get(k,0))==0 for k in ('failures','errors','skipped'))
  assert all(r['exit_code']==0 for r in json.loads(checks.read_text()))
  break
 if time.time()-start>5400:raise TimeoutError('Integration checks did not finish')
 time.sleep(5)
while True:
 candidate=out/'native';log=out/'native.log'
 if candidate.exists():candidate.rename(out/f'native-discarded-{attempt}')
 if log.exists():log.rename(out/f'native-discarded-{attempt}.log')
 quiet_start=None
 while True:
  lines=subprocess.check_output(['ps','-eo','comm='],text=True).splitlines();active=[n.strip() for n in lines if n.strip() in ('cc1plus','cc1','clang','clang++','rustc','g++','scons','ninja','ffmpeg') or n.strip().startswith(('glob2','callgrind'))]
  ledger.append({'time':time.time(),'active':active,'attempt':attempt+1});(out/'native75-final-idle-ledger.json').write_text(json.dumps(ledger,indent=2))
  if active:quiet_start=None
  elif quiet_start is None:quiet_start=time.time()
  elif time.time()-quiet_start>=120:break
  if time.time()-start>5400:raise TimeoutError('Unable to obtain an uncontended timing window')
  time.sleep(5)
 attempt+=1;print('120 seconds idle; starting native attempt',attempt,flush=True)
 with log.open('w') as f:r=subprocess.run(['python3',str(out/'native_bench.py')],stdout=f,stderr=subprocess.STDOUT)
 if r.returncode==0:print('All 120 native measurements completed without detected contention',flush=True);break
 if 'External computation contaminated timing' not in log.read_text():raise RuntimeError('Native sampler failed for a reason other than host contention')
 print('Detected external work; discarding entire attempt',attempt,flush=True)
