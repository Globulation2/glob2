from pathlib import Path
import subprocess,json
r=Path('artifacts/air-merge-master');results=[]
for name in ['fullhd','laptop']:
 d=r/('display-retry-'+name)
 cmd=['env','-u','DISPLAY','python3','test/run_tests.py','--build-dir','/dev/shm/glob2-direct-air-release','--binary','engine','--filter','UIPresentation/*at '+name+' across*','--fullscreen','--timeout','1200','--junit',str(d)+'.xml','--artifacts',str(d),'-j1']
 with Path(str(d)+'.log').open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 results.append({'command':cmd,'exit_code':p.returncode});print(name,p.returncode,flush=True)
 # Generated screenshots are disposable. Preserve logs and result XML.
 count=0
 for file in d.rglob('*'):
  if file.is_file() and file.suffix.lower() in ('.bmp','.png'):count+=file.stat().st_size;file.unlink()
 results[-1]['discarded_screenshot_bytes']=count;(r/'display-retry-results.json').write_text(json.dumps(results,indent=2))
 if p.returncode:raise SystemExit(p.returncode)
