from pathlib import Path
import shlex,subprocess,json,sys,hashlib,os
ROOT=Path('/home/bradley/.codex/worktrees/pr1196-direct-flight/glob2');OUT=ROOT/'artifacts/air-complete-fast-path/profile'
variant=sys.argv[1];source=ROOT if variant=='hybrid' else Path('/home/bradley/.codex/worktrees/pr1196-performance-master/glob2')
log=ROOT/'artifacts/air-complete-fast-path'/('final-release-build.log' if variant=='hybrid' else 'master-release-build.log');lines=log.read_text().splitlines();compile=next(shlex.split(l) for l in lines if ' -c ' in l and l.endswith('src/app/cli/Headless.cpp'));link=next(shlex.split(l) for l in reversed(lines) if l.startswith('g++ -o ') and '/src/glob2 ' in l)
# SCons logs escape quotes for a shell; shlex yields the actual argv expected by the compiler.
p=OUT/variant;p.mkdir(exist_ok=True);text=(source/'src/app/cli/Headless.cpp').read_text();original=text
text=text.replace('#include "Headless.h"','#include "Headless.h"\n#include <valgrind/callgrind.h>')
old='if(benchmarkWarmup==0) measureStart=processCpuNs();';new='const auto beginProfile=[&] { std::cerr << "PROFILE_BEGIN tick=" << engine.gui.game.stepCounter << "\\n"; CALLGRIND_START_INSTRUMENTATION; CALLGRIND_ZERO_STATS; };\n            if(benchmarkWarmup==0) { measureStart=processCpuNs(); beginProfile(); }'
assert old in text;text=text.replace(old,new)
old='if(!measureStart && engine.gui.game.stepCounter>=start) measureStart=processCpuNs();';new='if(!measureStart && engine.gui.game.stepCounter>=start) { measureStart=processCpuNs(); beginProfile(); }';assert old in text;text=text.replace(old,new)
old='runCpu=processCpuNs()-measureStart;';assert old in text;text=text.replace(old,'CALLGRIND_STOP_INSTRUMENTATION; std::cerr << "PROFILE_END tick=" << engine.gui.game.stepCounter << "\\n";\n            '+old)
cpp=p/'Headless.cpp';cpp.write_text(text);obj=p/'Headless.o';binary=p/'glob2-profile'
oldObj=compile[compile.index('-o')+1];compile[compile.index('-o')+1]=str(obj);compile[-1]=str(cpp);compile[1:1]=[]
link[link.index('-o')+1]=str(binary);assert oldObj in link;link=[str(obj) if a==oldObj else a for a in link]
# The executable retains its own source release runtime assets instead of triggering asset work.
base='/dev/shm/glob2-direct-air-release' if variant=='hybrid' else '/dev/shm/glob2-direct-air-master-release'
(p/'runtime-assets').symlink_to(Path(base)/'runtime-assets',target_is_directory=True) if not (p/'runtime-assets').exists() else None
(p/'runtime-assets.json').symlink_to(Path(base)/'runtime-assets.json') if not (p/'runtime-assets.json').exists() else None
(p/'commands.json').write_text(json.dumps({'compile':compile,'link':link,'source':str(source),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()},indent=2))
(p/'instrumentation.diff').write_text(subprocess.run(['diff','-u','--label','a/src/app/cli/Headless.cpp','--label','b/src/app/cli/Headless.cpp','-',str(cpp)],input=original,text=True,capture_output=True).stdout)
with (p/'build.log').open('w') as f:
 for args in [compile,link]:subprocess.run(args,cwd=source,stdout=f,stderr=subprocess.STDOUT,check=True,env=dict(os.environ,CCACHE_DIR='/dev/shm/glob2-air-ccache',TMPDIR='/dev/shm/glob2-air-tmp'))
(p/'binary-sha256.txt').write_text(hashlib.sha256(binary.read_bytes()).hexdigest()+'\n');print(variant,'built',flush=True)
