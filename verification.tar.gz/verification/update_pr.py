from pathlib import Path
import json,subprocess
r=Path('artifacts/air-merge-master');pub=json.loads((r/'publication.json').read_text());s=json.loads((r/'summary.json').read_text());head=s['source'];url=pub['url'];perf=s['performance']
rows='\n'.join('| '+x['case']+' | %.2f | %.2f | %+.2f%% |'%(x['versions']['master']['cpu_ms']['median'],x['versions']['direct']['cpu_ms']['median'],x['direct_vs_master_cpu_percent']) for x in perf)
body=f'''Flyers retain direct angular steering and local traffic avoidance on maps without air terrain modifiers or air-blocking resources. Food, healing, upgrades, inn rebooking, building admission and explorer/warrior recruitment use historical geometric checks and allocate no building-travel Air fields. Forbidden paint remains ground-only, preserving existing flying behavior.

Maps requiring air routing use shared movement-class fields. Resource/clearing goals and guard balancing retain shared routing. Ground seed and material-cache kernels have separate compiled implementations, removing per-cell Air branches; unused Air templates consume no ground-only cache budget. Active Air caches remain coherent.

Integrated master `13d99a181e3225738411f394e7c29edbabe11b47`, including delayed ground guidance and recruitment bookkeeping. Ground cold queries retain master's delayed behavior. Air cold queries materialize on the simulation owner; periodic refreshes use the shared FIFO. Simulation revision **76**, save format **173**, replay floor **173**, network protocol **72**, save floor **58**. Loading preserves independent released layouts168/169 and earlier Air171/172, including delayed-ground-state gates and order envelopes. Format170 remains rejected. Golden match and current checksum references are regenerated.

Verified final head `{head}` on Ubuntu24.04.5 x86_64/GCC13.3, optimized release builds: **3042 standard native cases and 340 Python tests passed, zero failures/errors/skips**. Full native inventory ran at143937cc5; later commits only update three expected checksum fixtures and Python save-header boundary expectations. Both affected JavaScript cases (clean0d68d4916; later a7c944a2f changes only the Python test) and the two display cases interrupted by disk exhaustion passed targeted reruns; initial failures and exact provenance remain in the evidence. Standard inventory excludes38 opt-in benchmarks.

Additional verification covers real168/169/171/172 save migration, complete per-tick Air records across1/2/4/8participants, eight save phases on ordinary/constrained scenarios, Maxima512-tick serial/parallel and256-tick midpoint reload, native replay/browser-reference corpora, golden match, docs and gradient contracts. [Commands, logs, inventories, saves, replays, checksum comparisons and all performance samples]({url}).

The updated JavaScript references preserve every team/entity record over512ticks; the96-tick ablation comparison preserves all unit vectors and RNG and changes only map routing metadata. The previous Maxima reference also fails on current master; current master and PR preserve all team/entity records over512ticks. Worker, reload and replay assertions remain intact.

Fresh CPU medians against integrated master13d99a181, matching optimized flags/dependencies, four physical cores/four participants,128warmup+256measured ticks and ten trials per scenario/revision:

| Scenario | Master CPU ms | PR CPU ms | Change |
| --- | ---: | ---: | ---: |
{rows}

All120 samples ran after functional checks and an idle window, with before/after contention checks. Raw ranges and host snapshots are retained. Small differences must be assessed against variability. This table supersedes earlier933/c7 measurements; those instruction profiles describe the older revisions.

Gameplay effect: ordinary-map service and recruitment choices retain geometric ranking; constrained-map choices may differ from the original private Air solver. Automated scenarios do not replace maintainer play review. Actual Windows/macOS/mobile/browser execution, cross-platform checksum equivalence, sanitizers, hosted full CI and release/store packaging are not newly qualified. Generated UI screenshots were discarded to recover disk capacity; assertion and completion logs are retained.
'''
(r/'pr-body.md').write_text(body)
comment=f'''Final integration verification for `{head}`, base `13d99a181e3225738411f394e7c29edbabe11b47`: **3042 native cases and340 Python tests passed**, zero final failures/errors/skips. Ubuntu24.04.5 x86_64/GCC13.3; release -O3, dev_fast=0, retain_symbols=1 CXXFLAGS=-g1, no PCH/unity, pinned dependencies and exact commands in [evidence]({url}).

Full native source143937cc5 plus reference/test-only final commits and four explicitly mapped passing reruns; original failures retained. Generated display captures exhausted disk; two interrupted cases passed after freeing space. All512 JavaScript team/entity records and96 ablation unit/RNG records matched before aggregate checksum updates. Current master independently reproduces the obsolete Maxima-reference mismatch, and its512 team/entity records match this PR; complete PR serial/parallel/midpoint reload checks pass.

Evidence includes actual saved formats168/169/171/172 and continuations, Air128-tick full records across1/2/4/8participants and eight reload phases, Maxima serial/parallel512+256 continuation, native browser/replay corpus, golden match, sim revision76, docs/gradient checks, full inventories, logs and120 fresh optimized timing samples against integrated master. Coverage rationale: full local native/Python suite for combined ground/Air simulation integration, focused compatibility gates and determinism checks, matching release performance builds. Excluded38 opt-in benchmarks. Windows/macOS/mobile/actual browser, cross-platform equality, sanitizers, hosted full CI, packaging and human play review are not newly qualified. Prior evidence is superseded for integrated performance. Archive SHA256 `{pub['archive_sha256']}`.
'''
(r/'pr-evidence-comment.md').write_text(comment)
subprocess.run(['gh','pr','edit','1196','--body-file',str(r/'pr-body.md')],check=True)
subprocess.run(['gh','pr','comment','1196','--body-file',str(r/'pr-evidence-comment.md')],check=True)
