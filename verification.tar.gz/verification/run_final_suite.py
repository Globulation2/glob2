from pathlib import Path
import subprocess,json,time,concurrent.futures
out=Path('artifacts/air-complete-fast-path');log=out/'kernel-final-clean-build.log';start=time.time()
while not log.read_text().rstrip().endswith('scons: done building targets.'):
 if 'scons: building terminated because of errors.' in log.read_text():raise RuntimeError('build failed')
 if time.time()-start>600:raise TimeoutError('build timeout')
 time.sleep(2)
commands={}
for kind,jobs in [('engine',4),('unit',1)]:
 commands[kind]=['env','-u','DISPLAY','python3','test/run_tests.py','--build-dir','/dev/shm/glob2-direct-air-release','--binary',kind,'--fullscreen','--display-jobs','1','-j',str(jobs),'--timeout','1200','--junit',str(out/(kind+'-final.xml')),'--artifacts',str(out/('native-final-'+kind)),'--write-inventory',str(out/(kind+'-final-inventory.json')),'--write-timings',str(out/(kind+'-final-timings.json'))]
(out/'final-native-commands.json').write_text(json.dumps(commands,indent=2))
def run(item):
 kind,cmd=item
 with (out/(kind+'-final.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print(kind,r.returncode,flush=True);return r.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:codes=list(pool.map(run,commands.items()))
raise SystemExit(any(codes))
