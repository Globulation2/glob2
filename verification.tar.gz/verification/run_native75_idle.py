from pathlib import Path
import subprocess,time,json
out=Path('artifacts/air-complete-fast-path');start=time.time();ledger=[];attempt=2
# Previous attempts were discarded when unrelated compilation started.
while True:
 candidate=out/'native-final75';log=out/'native-final75.log'
 if candidate.exists():candidate.rename(out/f'native-final75-discarded-{attempt}')
 if log.exists():log.rename(out/f'native-final75-discarded-{attempt}.log')
 quiet_start=None
 while True:
  lines=subprocess.check_output(['ps','-eo','comm='],text=True).splitlines();active=[n.strip() for n in lines if n.strip() in ('cc1plus','cc1','clang','clang++','rustc','g++','scons','ninja','ffmpeg') or n.strip().startswith(('glob2','callgrind'))]
  ledger.append({'time':time.time(),'active':active,'attempt':attempt+1});(out/'native75-final-idle-ledger.json').write_text(json.dumps(ledger,indent=2))
  if active:quiet_start=None
  elif quiet_start is None:quiet_start=time.time()
  elif time.time()-quiet_start>=120:break
  if time.time()-start>5400:raise TimeoutError('Unable to obtain an uncontended timing window')
  time.sleep(5)
 attempt+=1;print('120 seconds idle; starting native attempt',attempt,flush=True)
 with log.open('w') as f:r=subprocess.run(['python3',str(out/'native_bench75.py')],stdout=f,stderr=subprocess.STDOUT)
 if r.returncode==0:print('All 120 native measurements completed without detected contention',flush=True);break
 if 'External computation contaminated timing' not in log.read_text():raise RuntimeError('Native sampler failed for a reason other than host contention')
 print('Detected external work; discarding entire attempt',attempt,flush=True)
