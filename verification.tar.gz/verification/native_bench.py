from pathlib import Path
import os,json,hashlib,subprocess,random,statistics,time,shutil
ROOT=Path.cwd();OUT=ROOT/'artifacts/air-complete-fast-path/native';OUT.mkdir(exist_ok=True)
versions={'master':{'binary':'/dev/shm/glob2-direct-air-master-release/src/glob2','source':'64c792a61c4b5a7cdbfc49f33e7c846127645056'},'direct':{'binary':'/dev/shm/glob2-direct-air-release/src/glob2','source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}}
identities=[json.loads(Path('/dev/shm/glob2-direct-air-master-release/identity.json').read_text()),json.loads(Path('/dev/shm/glob2-direct-air-release/identity.json').read_text())]
assert identities[0]==identities[1],identities
for v in versions.values():v['binary_sha256']=hashlib.sha256(Path(v['binary']).read_bytes()).hexdigest()
previous=json.load(open(ROOT/'artifacts/direct-flight-performance/native/provenance.json'))
cases=[(x['case'],Path(x['path']),x['start']) for x in previous['inputs']]
original_inputs={n:str(p) for n,p,_ in cases}
(OUT/'inputs').mkdir(exist_ok=True)
new_cases=[]
for n,p,start in cases:
 target=OUT/'inputs'/(n+''.join(p.suffixes));shutil.copy2(p,target);new_cases.append((n,target,start))
cases=new_cases
# Four separate physical cores; all threads inherit this same affinity mask.
cores=[];seen=set()
for cpu in sorted(os.sched_getaffinity(0)):
 p=Path(f'/sys/devices/system/cpu/cpu{cpu}/topology');key=((p/'physical_package_id').read_text().strip(),(p/'core_id').read_text().strip())
 if key not in seen:cores.append(cpu);seen.add(key)
 if len(cores)==4:break
assert len(cores)==4
cpu_list=','.join(map(str,cores)); measured=256;warmup=128;trials=10
metadata={'versions':versions,'identity':identities[0],'compiler':subprocess.check_output(['g++','--version'],text=True),'uname':subprocess.check_output(['uname','-a'],text=True),'cpuinfo':Path('/proc/cpuinfo').read_text(),'affinity':cores,'warmup_ticks':warmup,'measured_ticks':measured,'trials':trials,'flags':'dev_fast=0 release=1 retain_symbols=1 CXXFLAGS=-g1; -O3; no PCH/unity; CPU only; 4 compute participants','inputs':[{'case':n,'path':str(p),'original_path':original_inputs[n],'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'start':s} for n,p,s in cases],'note':'Sequential native runs with task builds complete and the display runner held idle after its current child exited. Every run retains host process states and load. Each case/version has one unreported cache-priming run and ten measured runs. Variant order rotates per case/trial. CPU time covers the measured window plus final worker drains. Tick percentiles are headless wall time. Whole-run elapsed includes warmup; maximum RSS includes setup. No cross-version checksum equality is expected because routing behavior changes.'}
(OUT/'provenance.json').write_text(json.dumps(metadata,indent=2))
commands=[];records=[];expected={}
def run(case,variant,trial):
 name,save,start=case;directory=OUT/f'{name}-{variant}-{trial}';directory.mkdir(exist_ok=True)
 (directory/'host-processes.txt').write_text(subprocess.check_output(['ps','-eo','pid,ppid,stat,etimes,pcpu,comm','--sort=-pcpu'],text=True))
 (directory/'host-load.txt').write_text(Path('/proc/loadavg').read_text())
 args=[versions[variant]['binary'],'game','run','--load-game',str(save),'--ticks',str(start+warmup+measured),'--benchmark-warmup',str(warmup),'--compute-threads','4','--compute-telemetry','off','--gpu','off','--output-dir',str(directory/'game')]
 command=['/usr/bin/time','-f','%e %U %S %M','-o',str(directory/'process-time.txt'),'taskset','-c',cpu_list,*args]
 env=dict(os.environ,GLOB2_USER_DATA_DIR=str(directory/'profile'),GLOB2_USER_DIR=str(directory/'profile'),SDL_AUDIODRIVER='dummy',DEBUGINFOD_URLS='');env.pop('GLOB2_AIR_CALLGRIND',None)
 commands.append({'case':name,'version':variant,'trial':trial,'command':command,'cwd':str(ROOT)})
 (OUT/'commands.json').write_text(json.dumps(commands,indent=2))
 with (directory/'run.log').open('w') as log:subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
 j=json.loads((directory/'game/result.json').read_text());assert j['ticks']==start+warmup+measured and j['benchmark_measured_ticks']==measured,(name,variant,j)
 key=(name,variant);checks=(j['initialChecksum'],j['finalChecksum'])
 if key in expected:assert checks==expected[key],(key,expected[key],checks)
 else:expected[key]=checks
 timing=(directory/'process-time.txt').read_text().split()
 if trial>=0:
  record={'case':name,'version':variant,'trial':trial,'cpu_ms':j['benchmark_run_cpu_ns']/1e6,'cpu_us_per_tick':j['benchmark_run_cpu_ns']/measured/1e3,'p50_tick_ms':j['tick_p50_ns']/1e6,'p95_tick_ms':j['tick_p95_ns']/1e6,'p99_tick_ms':j['tick_p99_ns']/1e6,'full_run_wall_ms':j['run_ns']/1e6,'peak_rss_kib':int(timing[3]),'initialChecksum':checks[0],'finalChecksum':checks[1]};records.append(record)
  (OUT/'samples.json').write_text(json.dumps(records,indent=2));print(name,variant,trial,round(record['cpu_ms'],3),flush=True)
for case in cases:
 for version in versions:run(case,version,-1)
for trial in range(trials):
 for ci in range(len(cases)):
  case=cases[(ci+trial)%len(cases)];order=list(versions);shift=(ci+trial)%2;order=order[shift:]+order[:shift]
  for variant in order:run(case,variant,trial)
summary=[]
for name,_,_ in cases:
 row={'case':name,'versions':{}}
 for variant in versions:
  sample=[r for r in records if r['case']==name and r['version']==variant];assert len(sample)==trials
  result={}
  for metric in ['cpu_ms','cpu_us_per_tick','p50_tick_ms','p95_tick_ms','p99_tick_ms','peak_rss_kib']:
   values=[r[metric] for r in sample];q=statistics.quantiles(values,n=4);result[metric]={'median':statistics.median(values),'min':min(values),'max':max(values),'q1':q[0],'q3':q[2]}
  row['versions'][variant]=result
 for baseline in ['master']:
  row['direct_vs_'+baseline+'_cpu_percent']=100*(row['versions']['direct']['cpu_ms']['median']/row['versions'][baseline]['cpu_ms']['median']-1)
 summary.append(row)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2));print('all 120 measured runs passed',flush=True)
