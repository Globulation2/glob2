from pathlib import Path
import json,struct,subprocess,os,concurrent.futures
out=Path('artifacts/air-merge-master');save=next((out/'ablation-diagnostic').rglob('initial-v169.game')).resolve();commands=[]
def run(variant):
 binary='/dev/shm/glob2-direct-air-'+('master-release' if variant=='master' else 'release')+'/src/glob2';d=(out/('ablation-'+variant)).resolve()
 cmd=[binary,'game','run','--load-game',str(save),'--ticks','96','--telemetry','checksums','--compute-threads','4','--gpu','off','--output-dir',str(d)];commands.append(cmd)
 env=dict(os.environ,SDL_AUDIODRIVER='dummy',GLOB2_USER_DIR=str(d/'profile'),GLOB2_USER_DATA_DIR=str(d/'profile'))
 with (out/('ablation-'+variant+'.log')).open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 return d
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:dirs=list(pool.map(run,['master','pr']))
(out/'ablation-commands.json').write_text(json.dumps(commands,indent=2))
def parse(p):
 data=(p/'game.replay.checksums').read_bytes();teams,_,count,_=struct.unpack_from('<4I',data,4);i=20;records={}
 for _ in range(count):
  tick,aggregate=struct.unpack_from('<II',data,i);i+=8;units={};hashes=[]
  for team in range(teams):
   team_cs=struct.unpack_from('<I',data,i)[0];i+=4;hashes.append(team_cs)
   for typ in ['unit','building']:
    n=struct.unpack_from('<I',data,i)[0];i+=4
    for _ in range(n):
     gid,cs,fields=struct.unpack_from('<HII',data,i);i+=10;values=struct.unpack_from('<'+'I'*fields,data,i);i+=4*fields
     units[(typ,gid)]=(cs,values)
  records[tick]={'aggregate':aggregate,'teams':hashes,'entities':units}
 assert i==len(data)
 return records
a,b=map(parse,dirs);differences=[]
for tick in a:
 changes=[]
 for key in a[tick]['entities']:
  x=a[tick]['entities'][key];y=b[tick]['entities'].get(key)
  if x!=y:changes.append({'entity':key,'master_checksum':x[0],'pr_checksum':y[0] if y else None,'fields':[{'index':i,'master':v,'pr':w} for i,(v,w) in enumerate(zip(x[1],y[1])) if v!=w] if y else []})
 if changes:differences.append({'tick':tick,'changes':changes})
(out/'ablation-differences.json').write_text(json.dumps(differences,indent=2));print(json.dumps(differences[:2],indent=2))
