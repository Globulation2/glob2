from pathlib import Path
import json,subprocess,os,tarfile,hashlib,shutil,xml.etree.ElementTree as E
r=Path.cwd();out=r/'artifacts/air-merge-master';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
root=E.parse(out/'native-integrated.xml').getroot();assert root.get('tests')=='3042' and all(root.get(k)=='0' for k in ['failures','errors','skipped'])
assert all(x['exit_code']==0 for x in json.loads((out/'integration-results.json').read_text()))
assert 'Ran 340 tests' in (out/'python.log').read_text() and '\nOK\n' in (out/'python.log').read_text()
perf=json.loads((out/'native/summary.json').read_text());assert len(json.loads((out/'native/samples.json').read_text()))==120
summary={'source':head,'base':'13d99a181e3225738411f394e7c29edbabe11b47','native_totals':root.attrib,'native_provenance':json.loads((out/'native-result-provenance.json').read_text()),'python_tests':340,'performance':perf,'save_migration':json.loads((out/'saves-final-verification.json').read_text()),'air_determinism':json.loads((out/'determinism-final76/summary.json').read_text()),'limitations':['Linux x86_64 GCC13 only; actual Windows/macOS/mobile/browser and cross-platform checksums not rerun','No new sanitizer, hosted CI, store packaging or human gameplay qualification','Native full inventory source143937cc5 plus final reference/test-only commits and four targeted replacements; initial failures and provenance retained','Generated UI screenshots discarded after disk exhaustion; two interrupted cases rerun with capacity; logs retained','38 opt-in native benchmarks excluded from standard suite']}
(out/'summary.json').write_text(json.dumps(summary,indent=2))
rows='\n'.join('| '+x['case']+' | %.2f | %.2f | %+.2f%% |'%(x['versions']['master']['cpu_ms']['median'],x['versions']['direct']['cpu_ms']['median'],x['direct_vs_master_cpu_percent']) for x in perf)
readme=f'''# PR 1196 integrated verification

Tested final source `{head}`, integrated master `13d99a181e3225738411f394e7c29edbabe11b47`.
Ubuntu 24.04.5 x86_64, GCC13.3, pinned dependencies recorded in build logs and native provenance. Release -O3, dev_fast=0, retain_symbols=1 CXXFLAGS=-g1, no PCH/unity; same dependencies and flags for both timing binaries.

3042 standard native cases passed, zero failures/errors/skips; 340 Python tests passed. Full native inventory ran at143937cc5; final0d68d4916 changes only three checksum reference fixtures, followed by a7c944a2f updating Python format-boundary expectations. The two affected JavaScript cases ran on clean0d68d4916 source and two display cases interrupted by disk exhaustion passed reruns with available capacity. All original failures, replacement mapping, inventories, commands and logs are retained. The 38 opt-in native benchmarks are excluded. Generated UI screenshots were discarded to recover disk capacity; UI pass claims refer to assertions and completion logs.

The JavaScript references changed only aggregate map/routing metadata; all team/entity records match over512ticks. The ablation runner reproduces all96 master golden checksums; all unit vectors and RNG match the PR and only the map vector changes. The Maxima old reference fails on current master too; master and PR team/entity payloads match for512ticks, and PR serial/parallel plus midpoint reload all match complete records. References were updated only after these comparisons; assertions remain intact.

Real saved formats168,169,171,172 load into173 and continue with matching aggregate/entity records except explicit header-version checksum delta. Ordinary/constrained Air cases compare128 full per-tick records across1/2/4/8participants plus eight reload phases. Native browser-reference corpus, native replay/save continuations, golden match, sim revision76, docs and gradient contract checks pass. Saves retain floor58; replay floor173, network72. Released169 delayed-ground and171/172 Air layouts are decoded independently.

Fresh optimized CPU medians, four physical cores/four participants,128warmup+256measured ticks, ten trials per scenario/version (120 measured runs); raw ranges, process states, input hashes, commands and samples retained. Timing waits for120seconds without competing compilers/game/profile processes and checks before/after every sample.

| Scenario | Master CPU ms | PR CPU ms | Change |
| --- | ---: | ---: | ---: |
{rows}

Small timing differences must be assessed against sample variability. This refresh supersedes prior source933/c7 timings. Linux-only; actual Windows/macOS/mobile/browser execution, cross-platform checksum equivalence, sanitizers, hosted CI, release/store packaging and human play review are not newly qualified. Archive contains source diff, exact commands/results, actual saves/replays/checksums, diagnostic comparison proof and all timing samples. Binary files and compiler objects are excluded. Earlier failure logs are diagnostic history, not final failures.
'''
(out/'README.md').write_text(readme)
pub=Path('/dev/shm/glob2-pr1196-integrated-publication');pub.mkdir(exist_ok=True)
for name in ['README.md','summary.json','native-integrated.xml']:shutil.copy2(out/name,pub/name)
subprocess.run(['git','diff','--binary',summary['base'],head],stdout=(out/'reviewed-change.patch').open('w'),check=True)
paths=[p for p in out.iterdir() if p.is_file() and p.suffix in ('.log','.xml','.json','.py','.md','.patch','.txt','.gz') and not p.name.startswith('publication')]
folders=['compatibility-inputs','determinism-final76','final-master169','final-pr169','final-pr168','final-pr171','final-pr172','maxima-final-serial','maxima-final-parallel','maxima-master','native-browser','browser-fixtures-sim76','native','js-final','ablation-runner-master','ablation-runner-pr']
# Include all legacy save directories actually produced by verifier.
folders.extend(p.name for p in out.iterdir() if p.is_dir() and p.name.startswith('final-'))
for folder in set(folders):
 for p in (out/folder).rglob('*'):
  if p.is_file() and not p.is_symlink() and not any(x in ('profile','profiles','__pycache__','runtime-assets') for x in p.relative_to(out/folder).parts) and p.stat().st_size<100_000_000 and p.suffix not in ('.o','.a','.bmp','.png'):paths.append(p)
for folder in ['integrated-engine-headless','integrated-engine-display','integrated-unit','display-retry-fullhd','display-retry-laptop']:
 paths.extend(p for p in (out/folder).rglob('*') if p.is_file() and (p.suffix in ('.log','.xml') or p.name=='build-provenance.json'))
archive=pub/'verification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in sorted(set(paths)):
  if p.suffix in ('.key','.pem','.o','.a') or p.stat().st_size>150_000_000:continue
  tar.add(p,arcname=str(Path('verification')/p.relative_to(out)),recursive=False)
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(pub/'archive-sha256.txt').write_text(sha+'  '+archive.name+'\n')
if archive.stat().st_size>=95_000_000:
 with archive.open('rb') as f:
  i=1
  while data:=f.read(48_000_000):(pub/(archive.name+f'.part{i:03}')).write_bytes(data);i+=1
 archive.unlink()
env=dict(os.environ,GIT_INDEX_FILE=str(pub/'index'))
def git(args,**kw):return subprocess.check_output(['git',*args],env=env,**kw).decode().strip()
git(['read-tree','--empty'])
for p in sorted(pub.iterdir()):
 if not p.is_file() or p.name in ('index','index.lock'):continue
 oid=git(['hash-object','-w','--stdin'],input=p.read_bytes());git(['update-index','--add','--cacheinfo','100644',oid,p.name])
commit=git(['commit-tree',git(['write-tree']),'-m','Retain PR1196 integrated verification against delayed ground master'])
ref='refs/heads/evidence/pr1196-integrated-'+head[:9];git(['update-ref',ref,commit]);subprocess.run(['git','push','origin',ref],check=True)
result={'commit':commit,'url':'https://github.com/Globulation2/glob2/tree/'+commit,'archive_sha256':sha};(out/'publication.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
