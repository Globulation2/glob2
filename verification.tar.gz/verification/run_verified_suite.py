from pathlib import Path
import subprocess,json,time,concurrent.futures,xml.etree.ElementTree as ET
out=Path('artifacts/air-complete-fast-path');log=out/'sim74-clean-build.log';start=time.time()
while not log.read_text().rstrip().endswith('scons: done building targets.'):
 if 'scons: building terminated because of errors.' in log.read_text():raise RuntimeError('build failed')
 if time.time()-start>600:raise TimeoutError('build timeout')
 time.sleep(2)
specs=[('engine-headless','engine',4,['--exclude-tag','display']),('engine-display','engine',1,['--tag','display']),('unit','unit',1,[])]
commands={name:['env','-u','DISPLAY','python3','test/run_tests.py','--build-dir','/dev/shm/glob2-direct-air-release','--binary',kind,'--fullscreen','--display-jobs','1','-j',str(jobs),'--timeout','1200',*extra,'--junit',str(out/(name+'-verified.xml')),'--artifacts',str(out/('verified-'+name)),'--write-inventory',str(out/(name+'-verified-inventory.json')),'--write-timings',str(out/(name+'-verified-timings.json'))] for name,kind,jobs,extra in specs}
(out/'verified-native-commands.json').write_text(json.dumps(commands,indent=2))
def run(item):
 name,cmd=item
 with (out/(name+'-verified.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True);return r.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:codes=list(pool.map(run,commands.items()))
root=ET.Element('testsuites');totals={k:0 for k in ('tests','failures','errors','skipped')}
for name in commands:
 part=ET.parse(out/(name+'-verified.xml')).getroot()
 for k in totals:totals[k]+=int(part.get(k,0))
 for child in part:root.append(child)
for k,v in totals.items():root.set(k,str(v))
ET.ElementTree(root).write(out/'native-verified.xml',encoding='utf-8',xml_declaration=True)
heads=set(json.loads((out/'engine-headless-verified-inventory.json').read_text())['assigned']);displays=set(json.loads((out/'engine-display-verified-inventory.json').read_text())['assigned'])
assert not heads&displays
print('Native totals',totals,flush=True)
raise SystemExit(any(codes))
