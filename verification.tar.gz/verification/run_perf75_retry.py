from pathlib import Path
import subprocess,time,json,xml.etree.ElementTree as ET
out=Path('artifacts/air-complete-fast-path');start=time.time()
while True:
 suite=out/'native-final75.xml';compat=out/'compat75-results.json'
 ready=suite.exists() and compat.exists() and json.loads(compat.read_text())[-1]['name']=='python' and (out/'master-c7-build.log').read_text().rstrip().endswith('scons: done building targets.')
 if ready:break
 if time.time()-start>7200:raise TimeoutError('verification did not complete')
 time.sleep(5)
assert all(int(ET.parse(suite).getroot().get(k,0))==0 for k in ('failures','errors','skipped'))
assert all(r['exit_code']==0 for r in json.loads(compat.read_text()))
p=out/'profile'
for name in ['master','hybrid','islands-master','islands-hybrid','midgame24k-master','midgame24k-hybrid','islands-comparison.json','midgame24k-comparison.json','summary.json']:
 src=p/name
 if src.exists():src.rename(p/(name+'-explorer-only'))
s=(out/'build_profiles.py').read_text().replace('final-release-build.log','final75-build.log').replace('master-release-build.log','master-c7-build.log')
(out/'build_profiles75.py').write_text(s)
for variant in ['master','hybrid']:subprocess.run(['python3',str(out/'build_profiles75.py'),variant],check=True)
for case in ['islands','midgame24k']:
 for variant in ['master','hybrid']:subprocess.run(['python3',str(p/'profile.py'),case,variant],check=True)
with (p/'final75-analysis.log').open('w') as f:subprocess.run(['python3',str(p/'analyze.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
print('profiles complete',flush=True)

quiet_start=None;ledger=[]
while True:
 names=subprocess.check_output(['ps','-eo','comm='],text=True).splitlines();active=[n.strip() for n in names if n.strip() in ('cc1plus','cc1','clang','clang++','rustc','g++','scons','ninja')]
 ledger.append({'time':time.time(),'active_compilers':active});(out/'native75-idle-wait.json').write_text(json.dumps(ledger,indent=2))
 if active:quiet_start=None
 elif quiet_start is None:quiet_start=time.time()
 elif time.time()-quiet_start>=20:break
 if time.time()-start>7200:raise TimeoutError('Host did not become idle')
 time.sleep(5)
print('Host idle; native timing starting',flush=True)
with (out/'native-final75.log').open('w') as f:subprocess.run(['python3',str(out/'native_bench75.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
print('timing complete',flush=True)
