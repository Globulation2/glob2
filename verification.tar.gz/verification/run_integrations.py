from pathlib import Path
import subprocess,json,time,os,hashlib
out=Path('artifacts/air-merge-master');start=time.time();log=out/'final-build.log'
while not log.read_text().rstrip().endswith('scons: done building targets.'):
 if 'scons: building terminated because of errors.' in log.read_text():raise RuntimeError('build failed')
 if time.time()-start>1800:raise TimeoutError('build timeout')
 time.sleep(2)
source={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'base':'13d99a181e3225738411f394e7c29edbabe11b47','clean':not subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'app_sha256':hashlib.sha256(Path('/dev/shm/glob2-direct-air-release/src/glob2').read_bytes()).hexdigest()};assert source['clean'];(out/'integrated-source.json').write_text(json.dumps(source,indent=2))
s=(out/'verify_saves.py').read_text().replace("d=out/name;env=", "d=out/('final-'+name);env=").replace("out/(name+'.log')).open", "out/('final-'+name+'.log')).open").replace("['master169-build','incremental-build']","['master169-build','final-build']").replace("saves-commands.json","saves-final-commands.json").replace("saves-verification.json","saves-final-verification.json");(out/'verify_saves_final.py').write_text(s)
commands=[('saves',['python3',str(out/'verify_saves_final.py')]),('air',['python3',str(out/'verify_air76.py')]),('maxima-serial',['python3','test/maxima/check_save_continuation_fixture.py','/dev/shm/glob2-direct-air-release/src/glob2','--output',str(out/'maxima-serial')]),('maxima-parallel',['python3','test/maxima/check_save_continuation_fixture.py','/dev/shm/glob2-direct-air-release/src/glob2','--parallel-ai','--output',str(out/'maxima-parallel')]),('native-browser',['python3','test/run-browser-determinism.py','/dev/shm/glob2-direct-air-release/src/glob2',str(out/'native-browser'),'--engine-binary','/dev/shm/glob2-direct-air-release/test/glob2-engine-tests']),('sim-version',['python3','test/check_sim_revision.py','--base','origin/master']),('docs',['python3','tools/check_docs.py']),('gradient-contract',['python3','tools/shaders/gradient_preparation_rules.py'])]
results=[]
for name,cmd in commands:
 with (out/('integration-'+name+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'exit_code':r.returncode});(out/'integration-results.json').write_text(json.dumps(results,indent=2));print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
spec=json.loads(Path('artifacts/air-complete-fast-path/python-complete-command.json').read_text());env=dict(os.environ,**spec['env'])
with (out/'python.log').open('w') as f:r=subprocess.run(spec['command'],env=env,stdout=f,stderr=subprocess.STDOUT)
results.append({'name':'python','command':spec['command'],'env':spec['env'],'exit_code':r.returncode});(out/'integration-results.json').write_text(json.dumps(results,indent=2));print('python',r.returncode,flush=True);raise SystemExit(r.returncode)
