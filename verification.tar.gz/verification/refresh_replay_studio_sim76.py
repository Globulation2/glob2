from pathlib import Path
import subprocess,json,hashlib,os,shutil
root=Path.cwd();out=root/'artifacts/air-merge-master/browser-fixtures-sim76';out.mkdir(exist_ok=True);binary='/dev/shm/glob2-direct-air-release/src/glob2';commands=[]
def run(name,args,extra={}):
 d=out/name;env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_USER_DIR=str(out/(name+'-profile')),GLOB2_USER_DATA_DIR=str(out/(name+'-profile')),**extra);cmd=[binary,*args]
 commands.append({'name':name,'command':cmd,'env':{k:v for k,v in env.items() if k.startswith('GLOB2_') or k.startswith('SDL_')}})
 (out/'commands.json').write_text(json.dumps(commands,indent=2))
 with (out/(name+'.log')).open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
fixture=root/'browser/tests/fixtures/cross-replay.replay';shutil.copy2(fixture,out/'prior-format172.replay')
run('replay',['game','repeat',str(root/'games/cross-replay.game.gz'),'--ticks','1500','--runs','1'],{'GLOB2_REPLAY_PATH':str(out/'current.replay'),'GLOB2_TEST_SEED':'42'})
shutil.copy2(out/'current.replay',fixture)
p=root/'browser/tests/fixtures/README.md';p.write_text(p.read_text().replace('file format 172','file format 173').replace('accepted format is 172','accepted format is 173'))
run('studio',['game','run','--map-file',str(root/'platform/apps/engine-agent/fixtures/ais/two.map.gz'),'--game-seed','19','--player','javascript','--ai-script','0:'+str(root/'examples/javascript/studio-starter.js'),'--player','numbi','--ticks','1024','--write-replay','--telemetry','checksums','--save','initial','--save','final','--output-dir',str(out/'studio')])
p=root/'browser/tests/fixtures/studio-trace.json';shutil.copy2(p,out/'prior-studio-trace.json');j=json.loads(p.read_text());trace=(out/'studio/game.replay.checksums').read_bytes();j['traceBytes']=len(trace);j['traceSha256']=hashlib.sha256(trace).hexdigest();p.write_text(json.dumps(j,indent=2)+'\n');print('Refreshed format-173 replay and native Studio reference',flush=True)
