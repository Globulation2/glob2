from pathlib import Path
import subprocess,json,os,time
root=Path.cwd();out=root/'artifacts/air-complete-fast-path';build=out/'final-release-build.log'
start=time.time()
while not build.read_text().rstrip().endswith('scons: done building targets.'):
    if 'scons: building terminated because of errors.' in build.read_text():raise RuntimeError('release build failed')
    if time.time()-start>3600:raise TimeoutError('release build did not finish')
    time.sleep(3)
print('Release build ready; validating fixtures and navigation',flush=True)
b='/dev/shm/glob2-direct-air-release';g=b+'/src/glob2'
checks=[
 ('golden-match',['python3','test/run_tests.py','--build-dir',b,'--binary','engine','--update-fixtures','--filter','TurnEngineHarness/the committed*','--junit',str(out/'golden-match.xml'),'--artifacts',str(out/'golden-match')]),
 ('navigation',['python3','test/run_tests.py','--build-dir',b,'--filter','GradientPreparation/*','--filter','NetSendOrderDecode/*','--timeout','600','-j4','--junit',str(out/'navigation.xml')]),
 ('maxima-update',['python3','test/maxima/check_save_continuation_fixture.py',g,'--update-fixtures','--output',str(out/'maxima-serial')]),
 ('maxima-parallel',['python3','test/maxima/check_save_continuation_fixture.py',g,'--parallel-ai','--output',str(out/'maxima-parallel')]),
 ('air-determinism',['python3',str(out/'verify_air.py')]),
]
results=[];env=dict(os.environ,SDL_AUDIODRIVER='dummy',GLOB2_SDL3_PREFIX='/home/bradley/glob2/build/sdl3/prefix')
for name,cmd in checks:
    t=time.time()
    with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=1800)
    results.append({'name':name,'command':cmd,'exit':r.returncode,'seconds':time.time()-t})
    (out/'post-build-results.json').write_text(json.dumps(results,indent=2))
    print(name,r.returncode,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
