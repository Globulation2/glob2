from pathlib import Path
import json,subprocess,os,tarfile,hashlib,shutil
root=Path.cwd();out=root/'artifacts/air-complete-fast-path';summary=json.loads((out/'summary75.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert summary['source']['source']==head and not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
pub=Path('/dev/shm/glob2-pr1196-fast-path-publication');pub.mkdir(exist_ok=True)
for name in ['README75.md','summary75.json','native-final75.xml']:
 shutil.copy2(out/name,pub/('README.md' if name=='README75.md' else name))
subprocess.run(['git','diff','--binary',summary['source']['base'],head],stdout=(out/'reviewed-change.patch').open('w'),check=True)
folders=['determinism-final75','legacy168','legacy171','maxima-final75-serial','maxima-final75-parallel','maxima-master-current','native-browser-final75','browser-fixtures-sim75','native-final75']
paths=[p for p in out.iterdir() if p.is_file() and p.suffix in ('.log','.xml','.json','.py','.md','.patch','.txt') and not p.name.startswith(('pr-','publication'))]
for folder in folders:
 directory=out/folder
 paths.extend(p for p in directory.rglob('*') if p.is_file() and not p.is_symlink() and not any(x in ('__pycache__','profile','profiles','runtime-assets') or x.endswith('-profile') for x in p.relative_to(directory).parts))
for folder in ['final75-engine-headless','final75-engine-display','final75-unit']:
 paths.extend(p for p in (out/folder).rglob('*') if p.is_file() and (p.suffix in ('.log','.xml') or p.name=='build-provenance.json'))
profile=out/'profile'
for name in ['master','hybrid','islands-master','islands-hybrid','midgame24k-master','midgame24k-hybrid']:
 paths.extend(p for p in (profile/name).rglob('*') if p.is_file() and not p.is_symlink() and p.name not in ('glob2-profile','Headless.o') and 'runtime-assets' not in p.parts)
paths.extend(p for p in profile.iterdir() if p.is_file() and p.suffix in ('.py','.json','.log'))
archive=pub/'verification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in sorted(set(paths)):
  if p.suffix in ('.key','.pem','.o','.a') or p.stat().st_size>150_000_000:continue
  tar.add(p,arcname=str(Path('verification')/p.relative_to(out)),recursive=False)
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(pub/'archive-sha256.txt').write_text(sha+'  '+archive.name+'\n')
if archive.stat().st_size>=95_000_000:
 with archive.open('rb') as f:
  i=1
  while data:=f.read(48_000_000):(pub/(archive.name+f'.part{i:03}')).write_bytes(data);i+=1
 archive.unlink()
env=dict(os.environ,GIT_INDEX_FILE=str(pub/'index'))
def git(args,**kw):return subprocess.check_output(['git',*args],env=env,**kw).decode().strip()
git(['read-tree','--empty'])
for p in sorted(pub.iterdir()):
 if not p.is_file() or p.name in ('index','index.lock'):continue
 oid=git(['hash-object','-w','--stdin'],input=p.read_bytes());git(['update-index','--add','--cacheinfo','100644',oid,p.name])
commit=git(['commit-tree',git(['write-tree']),'-m','Retain PR 1196 final geometric flight verification and measurements'])
ref='refs/heads/evidence/pr1196-complete-fast-path-'+head[:9];git(['update-ref',ref,commit]);subprocess.run(['git','push','origin',ref],check=True)
result={'commit':commit,'url':'https://github.com/Globulation2/glob2/tree/'+commit,'archive_sha256':sha,'files':[{'name':p.name,'bytes':p.stat().st_size} for p in pub.iterdir() if p.is_file() and p.name not in ('index','index.lock')]};(out/'publication75.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
