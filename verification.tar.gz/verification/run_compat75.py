from pathlib import Path
import subprocess,time,os,json,hashlib,shutil
out=Path('artifacts/air-complete-fast-path');log=out/'final75-build.log';start=time.time()
while not log.read_text().rstrip().endswith('scons: done building targets.'):
 if 'scons: building terminated because of errors.' in log.read_text():raise RuntimeError('build failed')
 if time.time()-start>1800:raise TimeoutError('build timeout')
 time.sleep(2)
shutil.copy2(out/'final-source.json',out/'explorer-only-source.json')
source={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'base':subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'app_sha256':hashlib.sha256(Path('/dev/shm/glob2-direct-air-release/src/glob2').read_bytes()).hexdigest()}
assert source['clean'];(out/'final75-source.json').write_text(json.dumps(source,indent=2))
commands=[('air', ['python3',str(out/'verify_air_final75.py')]),('legacy168',['python3',str(out/'check_legacy75.py'),'legacy168']),('legacy171',['python3',str(out/'check_legacy75.py'),'legacy171']),('maxima-serial',['python3','test/maxima/check_save_continuation_fixture.py','/dev/shm/glob2-direct-air-release/src/glob2','--output',str(out/'maxima-final75-serial')]),('maxima-parallel',['python3','test/maxima/check_save_continuation_fixture.py','/dev/shm/glob2-direct-air-release/src/glob2','--parallel-ai','--output',str(out/'maxima-final75-parallel')]),('native-browser',['python3','test/run-browser-determinism.py','/dev/shm/glob2-direct-air-release/src/glob2',str(out/'native-browser-final75'),'--engine-binary','/dev/shm/glob2-direct-air-release/test/glob2-engine-tests']),('sim-revision',['python3','test/check_sim_revision.py','--base','origin/master']),('docs',['python3','tools/check_docs.py']),('gradients',['python3','tools/shaders/gradient_preparation_rules.py'])]
results=[]
for name,cmd in commands:
 with (out/('final75-'+name+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'exit_code':r.returncode});(out/'compat75-results.json').write_text(json.dumps(results,indent=2));print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
spec=json.loads((out/'python-complete-command.json').read_text());env=dict(os.environ,**spec['env'])
with (out/'python-final75.log').open('w') as f:r=subprocess.run(spec['command'],env=env,stdout=f,stderr=subprocess.STDOUT)
results.append({'name':'python','command':spec['command'],'env':spec['env'],'exit_code':r.returncode});(out/'compat75-results.json').write_text(json.dumps(results,indent=2));print('python',r.returncode,flush=True);raise SystemExit(r.returncode)
