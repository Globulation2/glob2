from pathlib import Path
import subprocess,time,json,xml.etree.ElementTree as ET
out=Path('artifacts/air-complete-fast-path');start=time.time()
while True:
 suite=out/'native-final75.xml';compat=out/'compat75-results.json'
 ready=suite.exists() and compat.exists() and json.loads(compat.read_text())[-1]['name']=='python' and (out/'master-c7-build.log').read_text().rstrip().endswith('scons: done building targets.')
 if ready:break
 if time.time()-start>7200:raise TimeoutError('verification did not complete')
 time.sleep(5)
assert all(int(ET.parse(suite).getroot().get(k,0))==0 for k in ('failures','errors','skipped'))
assert all(r['exit_code']==0 for r in json.loads(compat.read_text()))
cmd=['python3',str(out/'native_bench75.py')]
with (out/'native-final75.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
print('timing complete',flush=True)
p=out/'profile'
for name in ['master','hybrid','islands-master','islands-hybrid','midgame24k-master','midgame24k-hybrid','islands-comparison.json','midgame24k-comparison.json','summary.json']:
 src=p/name
 if src.exists():src.rename(p/(name+'-explorer-only'))
s=(out/'build_profiles.py').read_text().replace('final-release-build.log','final75-build.log').replace('master-release-build.log','master-c7-build.log')
(out/'build_profiles75.py').write_text(s)
for variant in ['master','hybrid']:subprocess.run(['python3',str(out/'build_profiles75.py'),variant],check=True)
for case in ['islands','midgame24k']:
 for variant in ['master','hybrid']:subprocess.run(['python3',str(p/'profile.py'),case,variant],check=True)
with (p/'final75-analysis.log').open('w') as f:subprocess.run(['python3',str(p/'analyze.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
print('profiles complete',flush=True)
