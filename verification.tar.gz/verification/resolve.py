from pathlib import Path
import re,subprocess
pat=re.compile(r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> origin/master',re.S)
def resolve(path, choices):
 p=Path(path);s=p.read_text();i=0
 def repl(m):
  nonlocal i
  c=choices[i] if isinstance(choices,list) else choices;i+=1
  return m[1] if c=='ours' else m[2] if c=='theirs' else m[1]+m[2] if c=='both' else c(m)
 p.write_text(pat.sub(repl,s))
for f in ['docs/architecture/simulation.md','src/app/Version.h','src/building/Step.cpp','src/game/SimRevision.h','src/replay/ReplayReader.h','src/scripting/javascript/ScriptCompatibilityTest.cpp','src/team/stats/TeamStatsSaveHarness.cpp']:
 resolve(f,'ours')
resolve('src/app/FileFormatVersions.h','both')
resolve('src/map/gradient/GradientRuntime.h','both')
resolve('src/map/MapResourceState.cpp','theirs')
resolve('src/map/MapStep.cpp','theirs')
resolve('src/map/gradient/MapGradientMaterial.cpp','theirs')
resolve('src/map/io/MapIO.cpp','theirs')
resolve('src/map/gradient/GradientPreparationTest.cpp','both')
resolve('src/unit/UnitCustomizationTest.cpp','both')
resolve('src/unit/Unit.cpp',lambda m:m[1]+'''\n}\n\nRouteResult Unit::queryMaterialDestination(int material,Sint32* x,Sint32* y,int* distance,bool withMarkets,const Building* consumer)
{
    Map& map=*owner->map;
    if (performance[FLY]) return findMaterialDestination(material,x,y,distance,withMarkets,consumer) ? RouteResult::Reachable : RouteResult::Unreachable;
    const auto result=map.queryMaterialDistance(owner->teamNumber,material,movementClass(),posX,posY,distance,withMarkets,consumer);
    if (result!=RouteResult::Reachable || !x || !y) return result;
    return map.materialAvailableUpdateSlot(owner->teamNumber,material,movementClass(),posX,posY,x,y,distance,withMarkets,consumer) ? RouteResult::Reachable : RouteResult::Unreachable;
''')
resolve('src/unit/Unit.h',lambda m:'\tRouteResult queryMaterialDestination(int material, Sint32* x, Sint32* y, int* distance,\n\t\tbool withMarkets=false, const Building* consumer=nullptr);\n')
resolve('src/unit/UnitDisplacement.cpp','theirs')
resolve('src/unit/UnitMovement.cpp',['ours','theirs',lambda m:m[2][m[2].index('\telse if (map->getForbidden'):].replace('else if (map->getForbidden','else if (!performance[FLY] && map->getForbidden'),lambda m:m[1]+'\t\tif (!clearAreasGradient) { waitForGradient(); return; }\n','ours','theirs','ours'])
resolve('test/support/LegacyPopulationOutput.h',['theirs','ours',lambda m:m[1]+'    void writeSint32(Sint32 value, std::string_view name) override\n    { if (!suppressed()) BinaryOutputStream::writeSint32(value,name); }\n'])
for f in ['test/fixtures/multiplayer/FourSquares1.g2mr','test/fixtures/resources/seeded-compositions-units.trace']:
 Path(f).write_bytes(subprocess.check_output(['git','show','origin/master:'+f]))
# The integrated format preserves both independently published layouts.
p=Path('src/app/Version.h');s=p.read_text().replace('VERSION_MINOR 172','VERSION_MINOR 173').replace('// version 172 combines','// version 173 integrates delayed ground guidance with the air routing layout.\n// version 172 combines').replace('// Draft formats 169-170 were never released and are not accepted.','// Version 169 is released delayed ground guidance; draft format 170 is rejected.');p.write_text(s)
p=Path('src/game/SimRevision.h');p.write_text(p.read_text().replace('SIM_REVISION 75','SIM_REVISION 76'))
p=Path('src/app/FileFormatVersions.h');s=p.read_text().replace('version == FILE_FORMAT_VERSION_SNAPSHOT_CHECKSUM || version >= 172','version == FILE_FORMAT_VERSION_SNAPSHOT_CHECKSUM || version == 169 || version >= 172');s+='\n// Air-only drafts 171/172 predate the released delayed-ground state.\ninline constexpr bool hasDelayedGradientState(unsigned version)\n{ return version == FILE_FORMAT_VERSION_DELAYED_GRADIENTS || version >= 173; }\n';p.write_text(s)
for f in ['src/replay/ReplayReader.h','src/scripting/javascript/ScriptCompatibilityTest.cpp','src/team/stats/TeamStatsSaveHarness.cpp']:
 p=Path(f);p.write_text(p.read_text().replace('== 172','== 173').replace('= 172','= 173'))
for f in ['src/map/MapStep.cpp','src/map/MapResourceState.cpp','src/map/gradient/MapGradientMaterial.cpp']:
 p=Path(f);s=p.read_text().replace('SWIM_CLASS_COUNT','MOVEMENT_CLASS_COUNT').replace('LEGACY_MOVEMENT_CLASS_COUNT','LEGACY_SWIM_CLASS_COUNT');p.write_text(s)
# Escape scheduling remains ground-only; flying never observes forbidden paint.
p=Path('src/map/MapStep.cpp');s=p.read_text().replace('game->hasWaterOnlyUnits()?MOVEMENT_CLASS_COUNT:LEGACY_SWIM_CLASS_COUNT','game->hasWaterOnlyUnits()?SWIM_CLASS_COUNT:LEGACY_SWIM_CLASS_COUNT');p.write_text(s)
# Retain pending-ground handling and the previously reviewed air steering.
p=Path('src/unit/UnitMovement.cpp');s=p.read_text().replace('return owner->map->getGuardAreasGradient(owner->teamNumber, movementClass())[owner->map->coordToIndex(x, y)]','return guardGradient[owner->map->coordToIndex(x, y)]')
s=s.replace('else if (performance[FLY])\n\t{\n\t\tmovement=MOV_FLYING_TARGET;', 'else if (performance[FLY] && !map->hasAirRoutingConstraints())\n\t{\n\t\tmovement=MOV_FLYING_TARGET;')
s=s.replace('movement=MOV_RANDOM_GROUND; }','movement=performance[FLY]?MOV_RANDOM_FLY:MOV_RANDOM_GROUND; }')
s=s.replace('swimClass(), posX, posY','movementClass(), posX, posY')
s=s.replace('if (!direct)\n                    findDisplacement([&](int* pathDx, int* pathDy) { return owner->map->pathfindArea(entityRandom, Map::AreaKind::Clear, owner->teamNumber, movementClass(), posX, posY, pathDx, pathDy); });','if (!direct)\n                    findDisplacement([&](int* pathDx, int* pathDy) { return owner->map->queryAreaStep(entityRandom, Map::AreaKind::Clear, owner->teamNumber, movementClass(), posX, posY, pathDx, pathDy)==StepResult::Step; });')
p.write_text(s)
# Admission must distinguish cold ground guidance from an unreachable route.
p=Path('src/building/Step.cpp');s=p.read_text();s=s.replace('if(!owner->map->materialAvailableSlot(owner->teamNumber,wantedMaterial,unit->movementClass(),unit->posX,unit->posY,&distMaterial,fetchesFromMarkets(),this))','const auto materialRoute=unit->queryMaterialDestination(wantedMaterial,nullptr,nullptr,&distMaterial,fetchesFromMarkets(),this);\n\tif (materialRoute==RouteResult::Pending) return false;\n\tif (materialRoute!=RouteResult::Reachable)');p.write_text(s)
# Format-gated delayed state, including genuine format-169 namespace strides.
p=Path('src/map/io/MapIO.cpp');s=p.read_text();s=s.replace('versionMinor>=FILE_FORMAT_VERSION_DELAYED_GRADIENTS','hasDelayedGradientState(versionMinor)').replace('versionMinor<FILE_FORMAT_VERSION_DELAYED_GRADIENTS','!hasDelayedGradientState(versionMinor)')
s=s.replace('gradientDestination(stream->readUint32("destination"))','gradientDestination(stream->readUint32("destination"),savedSwimClasses)')
s=s.replace('(2*MaterialSlotCount+3)*SWIM_CLASS_COUNT','(2*MaterialSlotCount+3)*MOVEMENT_CLASS_COUNT').replace('request.swim>=SWIM_CLASS_COUNT','request.swim>=savedSwimClasses')
p.write_text(s)
p=Path('src/map/Map.h');s=p.read_text().replace('Uint16** gradientDestination(unsigned);','Uint16** gradientDestination(unsigned, unsigned savedClasses=MOVEMENT_CLASS_COUNT);');p.write_text(s)
p=Path('src/map/MapStep.cpp');s=p.read_text().replace('Uint16** Map::gradientDestination(unsigned id)','Uint16** Map::gradientDestination(unsigned id, unsigned savedClasses)');a=s.index('Uint16** Map::gradientDestination(unsigned id');s=s[:a]+s[a:].replace('MOVEMENT_CLASS_COUNT','savedClasses');p.write_text(s)
# Historical adapters need both independent layout conversions.
p=Path('test/support/LegacyPopulationOutput.h');s=p.read_text().replace('formatVersion<FILE_FORMAT_VERSION_DELAYED_GRADIENTS','!hasDelayedGradientState(formatVersion)')
s=s.replace('return legacy || !hasDelayedGradientState(formatVersion);','return legacy || formatVersion<FILE_FORMAT_VERSION_UNIFIED_MOVEMENT || !hasDelayedGradientState(formatVersion);')
s=s.replace('if(injecting) return;','if(injecting || !tracking()) return;').replace('if (injecting) return;','if (injecting || !tracking()) return;')
s=s.replace('const auto legacyEnd=Team::MAX_COUNT*(2*MaterialSlotCount+2)*SWIM_CLASS_COUNT;','const auto legacyEnd=Team::MAX_COUNT*(2*MaterialSlotCount+2)*MOVEMENT_CLASS_COUNT;')
# Convert the current destination stride before emitting the older 16/32-bit word.
s=s.replace('if (suppressed()) return;\n        if (preservePending', '''if (suppressed()) return;
        if (name=="destination" && formatVersion<FILE_FORMAT_VERSION_UNIFIED_MOVEMENT) {
            const unsigned classes=formatVersion>=FILE_FORMAT_VERSION_UNIT_CATALOG?SWIM_CLASS_COUNT:LEGACY_SWIM_CLASS_COUNT;
            if (value<5000) { if (value%MOVEMENT_CLASS_COUNT>=classes) throw std::logic_error("Historical air destination"); value=(value/MOVEMENT_CLASS_COUNT)*classes+value%MOVEMENT_CLASS_COUNT; }
            else if (value<10000) { const unsigned key=value-5000; if (key%MOVEMENT_CLASS_COUNT>=classes) throw std::logic_error("Historical air escape destination"); value=5000+(key/MOVEMENT_CLASS_COUNT)*classes+key%MOVEMENT_CLASS_COUNT; }
        }
        if (preservePending''')
p.write_text(s)
# Released master saves at 169 supersede an old air-draft rejection.
for f in ['src/map/io/MapHeader.cpp','test/check_javascript.py']:
 p=Path(f)
 if not p.exists():continue
 s=p.read_text().replace('versionMinor==169 || versionMinor==170','versionMinor==170').replace('minor not in (169, 170)','minor != 170').replace('73..172','73..173').replace('minor <= 172','minor <= 173');p.write_text(s)
