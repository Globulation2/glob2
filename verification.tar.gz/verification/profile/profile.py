from pathlib import Path
import json,subprocess,os,sys,time
ROOT=Path.cwd();OUT=ROOT/'artifacts/air-complete-fast-path/profile';INPUT=ROOT/'artifacts/direct-flight-performance/native/inputs';case=sys.argv[1];variant=sys.argv[2];directory=OUT/f'{case}-{variant}';directory.mkdir(exist_ok=True)
start={'islands':8192,'midgame24k':24000,'swamp':8192,'ordinary32':0}[case];save=next(INPUT.glob(case+'.game*'));binary=OUT/variant/'glob2-profile';native='/dev/shm/glob2-direct-air-release/src/glob2' if variant=='hybrid' else '/dev/shm/glob2-direct-air-master-release/src/glob2'
common=['game','run','--load-game',str(save),'--ticks',str(start+384),'--benchmark-warmup','128','--compute-threads','4','--compute-telemetry','off','--gpu','off']
env=dict(os.environ,DEBUGINFOD_URLS='',SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(directory/'profile'),GLOB2_USER_DIR=str(directory/'profile'))
command=['valgrind','--tool=callgrind','--instr-atstart=no','--separate-threads=yes','--read-inline-info=yes','--callgrind-out-file='+str(directory/'callgrind.out.%p'),'--log-file='+str(directory/'valgrind.log'),str(binary),*common,'--output-dir',str(directory/'game')]
(directory/'command.json').write_text(json.dumps({'command':command,'cwd':str(ROOT),'env':{k:v for k,v in env.items() if k in ('DEBUGINFOD_URLS','SDL_AUDIODRIVER','GLOB2_USER_DATA_DIR','GLOB2_USER_DIR')},'start':time.time()},indent=2))
with (directory/'run.log').open('w') as f:subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=600)
native_command=[native,*common,'--output-dir',str(directory/'native')]
with (directory/'native.log').open('w') as f:subprocess.run(native_command,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=600)
a=json.load(open(directory/'game/result.json'));b=json.load(open(directory/'native/result.json'))
checks={k:{'profiled':a[k],'native':b[k],'match':a[k]==b[k]} for k in ['ticks','benchmark_measured_ticks','initialChecksum','finalChecksum']};assert all(x['match'] for x in checks.values()),checks
(directory/'verification.json').write_text(json.dumps(checks,indent=2));print(case,variant,'done',flush=True)
