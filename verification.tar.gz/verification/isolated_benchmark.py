from pathlib import Path
import os,signal,subprocess,json,time
out=Path('artifacts/air-complete-fast-path');rows=subprocess.check_output(['ps','-eo','pid=,comm=,args='],text=True).splitlines();targets=[]
for line in rows:
 p,comm,args=line.strip().split(None,2)
 if comm.startswith('python') and 'test/run_tests.py ' in args and '--junit artifacts/air-complete-fast-path/engine-display-verified.xml' in args:targets.append(int(p))
assert len(targets)==1,targets
pid=targets[0];ledger={'runner_pid':pid,'paused_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'reason':'Keep the display runner idle while its current child finishes, then run isolated optimized native timing','note':'Only the owned Python test runner is paused. Its current test is allowed to exit normally. No test case is paused and no unrelated process is changed. Outer runner duration for that case includes the hold.'}
(out/'benchmark-pause.json').write_text(json.dumps(ledger,indent=2));os.kill(pid,signal.SIGSTOP)
def active_children():
 data=[]
 for line in subprocess.check_output(['ps','-eo','pid=,ppid=,stat=,comm='],text=True).splitlines():
  p,parent,stat,comm=line.strip().split(None,3);data.append((int(p),int(parent),stat,comm))
 descendants={pid}
 while True:
  n=len(descendants);descendants.update(p for p,parent,_,_ in data if parent in descendants)
  if len(descendants)==n:break
 return [(p,stat,comm) for p,_,stat,comm in data if p in descendants and p!=pid and not stat.startswith('Z')]
try:
 start=time.time()
 while children:=active_children():
  if time.time()-start>600:raise TimeoutError(f'current display child did not finish: {children}')
  time.sleep(2)
 ledger['idle_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());ledger['wait_for_child_seconds']=time.time()-start
 (out/'benchmark-pause.json').write_text(json.dumps(ledger,indent=2));print('Display child finished; benchmark running',flush=True)
 # CPU snapshots retain state so paused/zombie test processes cannot be mistaken for active work.
 subprocess.run(['python3',str(out/'native_bench.py')],check=True,timeout=1800)
 ledger['benchmark_passed']=True
finally:
 os.kill(pid,signal.SIGCONT);ledger['resumed_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(out/'benchmark-pause.json').write_text(json.dumps(ledger,indent=2));print('Display runner resumed',flush=True)
