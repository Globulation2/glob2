from pathlib import Path
import shlex,subprocess,os,json,sys,hashlib
root=Path.cwd();out=root/'artifacts/air-merge-master';variant=sys.argv[1]
source=root if variant=='pr' else Path('/home/bradley/.codex/worktrees/pr1196-performance-master/glob2')
log=out/('build.log' if variant=='pr' else 'master169-build.log');lines=log.read_text().splitlines()
# The resumed PR log may not recompile Headless; its original full-build log did.
compile_lines=lines if any(' -c ' in l and l.endswith('src/app/cli/Headless.cpp') for l in lines) else (out/'build-failed-helpers.log').read_text().splitlines()
compile=next(shlex.split(l) for l in compile_lines if ' -c ' in l and l.endswith('src/app/cli/Headless.cpp'))
link=next(shlex.split(l) for l in reversed(lines) if l.startswith('g++ -o ') and '/src/glob2 ' in l)
d=out/('ablation-runner-'+variant);d.mkdir(exist_ok=True);commands=[];objects=[]
for i,file in enumerate([out/'ablation-runner.cpp',source/'test/support/EngineFixtures.cpp',source/'test/support/Glob2Test.cpp']):
 cmd=list(compile);obj=d/(str(i)+'.o');cmd[cmd.index('-o')+1]=str(obj);cmd[-1]=str(file);cmd[2:2]=['-fno-access-control','-Itest','-Itest/support'];commands.append(cmd);objects.append(str(obj))
entry=next(x for x in link if x.endswith('/src/app/Glob2.o'));renamed=d/'Glob2.o';commands.append(['objcopy','--redefine-sym','main=glob2UnusedOriginalMain',entry,str(renamed)])
link=[str(renamed) if x==entry else x for x in link];link[link.index('-o')+1]=str(d/'runner');link[3:3]=objects;commands.append(link)
(d/'commands.json').write_text(json.dumps({'source':str(source),'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'commands':commands,'entrypoint_only':'Original app main renamed to leave all production objects unchanged while running one diagnostic doctest.'},indent=2))
with (d/'build.log').open('w') as f:
 for cmd in commands:subprocess.run(cmd,cwd=source,stdout=f,stderr=subprocess.STDOUT,check=True,env=dict(os.environ,CCACHE_DIR='/dev/shm/glob2-air-ccache'))
base=Path('/dev/shm/glob2-direct-air-'+('release' if variant=='pr' else 'master-release'))
for name in ['runtime-assets','runtime-assets.json']:
 if not (d/name).exists():(d/name).symlink_to(base/name,target_is_directory=name=='runtime-assets')
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_TEST_SOURCE_ROOT=str(source),GLOB2_USER_DIR=str(d/'profile'),GLOB2_USER_DATA_DIR=str(d/'profile'))
with (d/'run.log').open('w') as f:subprocess.run([str(d/'runner')],cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=120)
print(variant,'done',flush=True)
