from pathlib import Path
import xml.etree.ElementTree as E,json,time,copy
r=Path('artifacts/air-merge-master')
files=['js-final.xml','display-retry-fullhd.xml','display-retry-laptop.xml']
while not all((r/f).exists() for f in files):time.sleep(5)
replacements={}
for f in files:
 root=E.parse(r/f).getroot()
 for c in root.iter('testcase'):
  assert c.find('error') is None and c.find('failure') is None and c.find('skipped') is None,(f,c.attrib)
  key=(c.get('classname'),c.get('name'));replacements[key]=(c,f)
initial=r/'native-integrated.xml';(r/'native-initial.xml').write_bytes(initial.read_bytes());root=E.parse(initial).getroot();ledger=[]
for suite in root:
 for old in list(suite):
  if old.tag!='testcase':continue
  key=(old.get('classname'),old.get('name'))
  if key in replacements:
   new,f=replacements.pop(key);suite.remove(old);suite.append(copy.deepcopy(new));ledger.append({'case':key,'replacement':f})
 for k in ['tests','failures','errors','skipped']:
  suite.set(k,str(sum(1 if k=='tests' else c.find({'failures':'failure','errors':'error','skipped':'skipped'}[k]) is not None for c in suite.findall('testcase'))))
assert not replacements,replacements
for k in ['tests','failures','errors','skipped']:root.set(k,str(sum(int(s.get(k,0)) for s in root)))
assert root.get('tests')=='3042' and all(root.get(k)=='0' for k in ['failures','errors','skipped']),root.attrib
E.ElementTree(root).write(initial,encoding='utf-8',xml_declaration=True)
(r/'native-result-provenance.json').write_text(json.dumps({'note':'Complete inventory initially ran at 143937cc5. Commit 0d68d4916 changes only three expected checksum fixture files and final a7c944a2f changes only Python header-boundary expectations; two JavaScript cases rerun on final clean source. Two display cases interrupted by disk exhaustion rerun with capacity. Initial failure ledger retained; no failures hidden. Production C++ is identical between these revisions.','replaced_cases':ledger,'totals':root.attrib},indent=2));print(root.attrib)
