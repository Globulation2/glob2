from pathlib import Path
import subprocess,os,json,sys,struct
sys.path.insert(0,'test')
from check_javascript import complete_ticks,save_header,header_checksum_delta
from compare_save_continuation import compare
root=Path.cwd();out=root/'artifacts/air-complete-fast-path';binary='/dev/shm/glob2-direct-air-release/src/glob2'
kind=sys.argv[1];base=out/kind
if kind=='legacy171':old=next((base/'run').glob('checkpoint-8.game*'))
else:old=next((base/'run').glob('checkpoint-8.game*'))
commands=[]
def run(save,name):
 d=base/name
 cmd=[binary,'game','run','--load-game',str(save),'--ticks','40','--save','every:8','--telemetry','checksums','--compute-threads','4','--gpu','off','--output-dir',str(d)]
 commands.append(cmd);env=dict(os.environ,SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(base/(name+'-profile')),GLOB2_USER_DIR=str(base/(name+'-profile')))
 with (base/(name+'.log')).open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
 return d
whole=run(old,'final75-current');fresh=next(whole.glob('checkpoint-16.game*'));resumed=run(fresh,'final75-resumed')
a=complete_ticks((whole/'game.replay.checksums').read_bytes());b=complete_ticks((resumed/'game.replay.checksums').read_bytes())
delta=header_checksum_delta(save_header(old),save_header(fresh))
for tick,record in b.items():
 ref=a[tick];assert record[:4]==ref[:4] and record[8:]==ref[8:],tick
 assert struct.unpack_from('<I',record,4)[0]==struct.unpack_from('<I',ref,4)[0]^delta,tick
report={'commands':commands,'old_header':save_header(old),'new_header':save_header(fresh),'matched_records':compare(whole/'game.replay.checksums',resumed/'game.replay.checksums'),'all_aggregate_bits_match_except_saved_header_version':True}
(base/'verification75.json').write_text(json.dumps(report,indent=2));print(kind,report['matched_records'],'records match',flush=True)
