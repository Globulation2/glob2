from pathlib import Path
import json,subprocess,os,time,hashlib
r=Path('artifacts/air-merge-master')
while not (r/'reference-final-build.log').read_text().rstrip().endswith('scons: done building targets.'):
 if 'terminated because of errors' in (r/'reference-final-build.log').read_text():raise RuntimeError('build failed')
 time.sleep(2)
(r/'initial-integration-results.json').write_bytes((r/'integration-results.json').read_bytes())
results=json.loads((r/'integration-results.json').read_text())[:2]
app='/dev/shm/glob2-direct-air-release/src/glob2'
(r/'reference-final-source.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'app_sha256':hashlib.sha256(Path(app).read_bytes()).hexdigest()},indent=2))
commands=[('maxima-serial',['python3','test/maxima/check_save_continuation_fixture.py',app,'--output',str(r/'maxima-final-serial')]),('maxima-parallel',['python3','test/maxima/check_save_continuation_fixture.py',app,'--parallel-ai','--output',str(r/'maxima-final-parallel')]),('javascript-final',['python3','test/run_tests.py','--build-dir','/dev/shm/glob2-direct-air-release','--binary','engine','--filter','JavaScriptSimulation/JavaScript original*','--filter','JavaScriptSimulation/JavaScript economic*','--junit',str(r/'js-final.xml'),'--artifacts',str(r/'js-final'),'-j2']),('native-browser',['python3','test/run-browser-determinism.py',app,str(r/'native-browser'),'--engine-binary','/dev/shm/glob2-direct-air-release/test/glob2-engine-tests']),('sim-version',['python3','test/check_sim_revision.py','--base','origin/master']),('docs',['python3','tools/check_docs.py']),('gradient-contract',['python3','tools/shaders/gradient_preparation_rules.py'])]
for name,cmd in commands:
 with (r/('final-'+name+'.log')).open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'exit_code':p.returncode});(r/'integration-results.json').write_text(json.dumps(results,indent=2));print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
spec=json.loads(Path('artifacts/air-complete-fast-path/python-complete-command.json').read_text())
with (r/'python.log').open('w') as f:p=subprocess.run(spec['command'],env=dict(os.environ,**spec['env']),stdout=f,stderr=subprocess.STDOUT)
results.append({'name':'python',**spec,'exit_code':p.returncode});(r/'integration-results.json').write_text(json.dumps(results,indent=2));print('python',p.returncode,flush=True)
