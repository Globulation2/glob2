from pathlib import Path
import subprocess,time,os,json
out=Path('artifacts/air-merge-master');log=out/'build.log';start=time.time()
while not log.read_text().rstrip().endswith('scons: done building targets.'):
 if 'scons: building terminated because of errors.' in log.read_text():raise RuntimeError('build failed')
 if time.time()-start>1800:raise TimeoutError('build timeout')
 time.sleep(2)
env=dict(os.environ,CCACHE_DIR='/dev/shm/glob2-air-ccache',GLOB2_SDL3_PREFIX='/home/bradley/glob2/build/sdl3/prefix',TMPDIR='/dev/shm/glob2-air-tmp',GLOB2_GLSLANG='/dev/shm/glob2-air-glslang/StandAlone/glslang')
cmd=['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1','CXXFLAGS=-g1','--build=/dev/shm/glob2-direct-air-release','-j8','/dev/shm/glob2-direct-air-release/src/glob2','engine-tests','unit-tests']
with (out/'incremental-build.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
cmd=['python3','test/run_tests.py','--build-dir','/dev/shm/glob2-direct-air-release','--binary','engine','-j4','--timeout','1200','--artifacts',str(out/'focused'),'--junit',str(out/'focused.xml')]
for suite in ['GradientPreparation','DelayedGradientPublication','GradientPipeline','MapGradientInvalidation','InnSwap','TerrainProperties','HiringPlanner','HiringPipeline','UnitCustomization']:
 cmd+=['--filter',suite+'/*']
(out/'focused-command.json').write_text(json.dumps(cmd,indent=2))
with (out/'focused.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
print('focus exit',r.returncode,flush=True);raise SystemExit(r.returncode)
