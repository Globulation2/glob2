from pathlib import Path
p=Path('src/map/gradient/GradientPreparationTest.cpp');s=p.read_text().replace('TEST_CASE("pending escape guidance preserves','        }\n    }\n}\n\nTEST_CASE("pending escape guidance preserves',1).replace('TEST_CASE("absent natural sources return','    }\n}\n\nTEST_CASE("absent natural sources return',1);p.write_text(s)
p=Path('src/map/io/MapHeader.cpp');p.write_text(p.read_text().replace('(versionMinor>=169 && versionMinor<171)','versionMinor==170'))
# Keep air cold material/area reads immediate; only ground demand is newly delayed.
p=Path('src/map/gradient/MapGradientMaterial.cpp');s=p.read_text().replace('if (!gradient && !game)', 'if (!gradient && (!game || swimClass==AIR_MOVEMENT_CLASS))').replace('if (game) {\n        auto& field=', 'if (game && swimClass!=AIR_MOVEMENT_CLASS) {\n        auto& field=')
old='if (!compute.insideJob()) requestGradientField(&entry.published, int(gradient_preparation::Kind::Markets),team,resource,swim,excluded,modes);'
new='''if (swim==AIR_MOVEMENT_CLASS) {
            if (!entry.cells) entry.cells=std::make_unique<Uint16[]>(size);
            seedMaterialGradient(team,resource,swim,entry.cells.get(),true,privateField ? consumer : nullptr,modes);
            propagateGradient(entry.cells.get(),swim,GRADIENT_COST_LIMIT,gradient_kernel::Family::Markets);
            entry.published=entry.cells.get();
        } else if (!compute.insideJob()) requestGradientField(&entry.published, int(gradient_preparation::Kind::Markets),team,resource,swim,excluded,modes);'''
assert old in s;s=s.replace(old,new);p.write_text(s)
p=Path('src/map/gradient/MapGradientArea.cpp');s=p.read_text().replace('if (!field && !game)','if (!field && (!game || swimClass==AIR_MOVEMENT_CLASS))').replace('if (game) { requestGradientField','if (game && swimClass!=AIR_MOVEMENT_CLASS) { requestGradientField');p.write_text(s)
# Compact material cache records also admit the appended air class.
p=Path('src/map/io/MapIO.cpp');s=p.read_text().replace('entry.swim>=SWIM_CLASS_COUNT','entry.swim>=MOVEMENT_CLASS_COUNT');p.write_text(s)
p=Path('src/game/SimRevision.h');p.write_text(p.read_text().rstrip()+'\n')
# Leave named helpers in historical test conversion instead of overloaded gates.
p=Path('test/support/LegacyPopulationOutput.h');s=p.read_text();s=s.replace('if (name=="slot" && formatVersion<FILE_FORMAT_VERSION_UNIFIED_MOVEMENT','if (name=="slot" && formatVersion<FILE_FORMAT_VERSION_UNIFIED_MOVEMENT')
p.write_text(s)
