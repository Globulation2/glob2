from pathlib import Path
import os,subprocess,json,time,sys,struct,hashlib
sys.path.insert(0,'test')
from check_javascript import save_header,complete_ticks,header_checksum_delta
from compare_save_continuation import compare
root=Path.cwd();out=root/'artifacts/air-merge-master';current='/dev/shm/glob2-direct-air-release/src/glob2';master='/dev/shm/glob2-direct-air-master-release/src/glob2';commands=[]
def run(binary,save,name,stop=40):
 d=out/('final-'+name);env=dict(os.environ,SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(d/'profile'),GLOB2_USER_DIR=str(d/'profile'))
 cmd=[binary,'game','run','--load-game',str(save),'--ticks',str(stop),'--save','every:8','--telemetry','checksums','--compute-threads','4','--gpu','off','--output-dir',str(d)]
 commands.append({'name':name,'command':cmd,'input_sha256':hashlib.sha256(save.read_bytes()).hexdigest()});(out/'saves-final-commands.json').write_text(json.dumps(commands,indent=2))
 with (out/('final-'+name+'.log')).open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=180)
 return d
for name in ['master169-build','final-build']:
 start=time.time();p=out/(name+'.log')
 while not p.exists() or not p.read_text().rstrip().endswith('scons: done building targets.'):
  if p.exists() and 'scons: building terminated because of errors.' in p.read_text():raise RuntimeError(name+' failed')
  if time.time()-start>2400:raise TimeoutError(name)
  time.sleep(2)
master_run=run(master,root/'games/cross-replay.game.gz','master169')
cases=[('168',root/'artifacts/air-complete-fast-path/legacy168/run/checkpoint-8.game.gz'),('169',master_run/'checkpoint-8.game.gz'),('171',root/'artifacts/air-complete-fast-path/legacy171/run/checkpoint-8.game.gz'),('172',root/'artifacts/air-complete-fast-path/legacy168/final75-current/checkpoint-16.game.gz')]
reports=[]
for version,old in cases:
 assert save_header(old)[1]==int(version)
 whole=run(current,old,'load'+version)
 fresh=min(whole.glob('checkpoint-*.game.gz'),key=lambda p:int(p.name.split('-')[1].split('.')[0]))
 resumed=run(current,fresh,'resume'+version)
 a=complete_ticks((whole/'game.replay.checksums').read_bytes());b=complete_ticks((resumed/'game.replay.checksums').read_bytes());delta=header_checksum_delta(save_header(old),save_header(fresh))
 for tick,record in b.items():
  ref=a[tick];assert record[:4]==ref[:4] and record[8:]==ref[8:],(version,tick,'entity mismatch')
  assert struct.unpack_from('<I',record,4)[0]==struct.unpack_from('<I',ref,4)[0]^delta,(version,tick,'aggregate mismatch')
 report={'version':version,'old_header':save_header(old),'new_header':save_header(fresh),'matched_records':compare(whole/'game.replay.checksums',resumed/'game.replay.checksums'),'aggregate_and_all_entities_match_except_saved_header_version':True};reports.append(report);print(version,report,flush=True)
(out/'saves-final-verification.json').write_text(json.dumps({'current_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'master':'13d99a181e3225738411f394e7c29edbabe11b47','results':reports},indent=2))
