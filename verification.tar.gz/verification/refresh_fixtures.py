from pathlib import Path
import subprocess,time,json,xml.etree.ElementTree as ET
out=Path('artifacts/air-merge-master');start=time.time()
while not (out/'focused.xml').exists():
 if (out/'focus-orchestrator.log').exists() and 'Traceback' in (out/'focus-orchestrator.log').read_text():raise RuntimeError('Focused run stopped')
 if time.time()-start>2400:raise TimeoutError('Focused run not complete')
 time.sleep(2)
r=ET.parse(out/'focused.xml').getroot();assert int(r.get('failures',0))+int(r.get('errors',0))==0,r.attrib
commands=[['python3','test/run_tests.py','--build-dir','/dev/shm/glob2-direct-air-release','--binary','engine','--filter','TurnEngineHarness/the committed*','--update-fixtures','--junit',str(out/'golden.xml'),'--artifacts',str(out/'golden')],['python3',str(out/'refresh_replay_studio_sim76.py')],['python3',str(out/'refresh_generator_sim76.py')]]
(out/'refresh-commands.json').write_text(json.dumps(commands,indent=2))
for i,cmd in enumerate(commands):
 with (out/f'refresh-{i}.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('refreshed',i,flush=True)
