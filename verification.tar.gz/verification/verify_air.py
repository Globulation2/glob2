import hashlib,json,os,struct,subprocess
from pathlib import Path
SOURCE=Path.cwd()
BINARY=Path('/dev/shm/glob2-direct-air-release/src/glob2')
OUT=SOURCE/'artifacts/air-complete-fast-path/determinism'
OUT.mkdir(parents=True,exist_ok=True)
commands=[]
def run(name,save,stop,threads=4,extra=()):
    directory=OUT/name; directory.mkdir(exist_ok=True)
    command=[str(BINARY),'game','run','--load-game',str(save),'--ticks',str(stop),'--compute-threads',str(threads),'--gpu','off','--compute-telemetry','off','--output-dir',str(directory),*extra]
    env=dict(os.environ,GLOB2_USER_DIR=str(directory/'profile'),GLOB2_USER_DATA_DIR=str(directory/'profile'))
    commands.append({'name':name,'command':command,'input_sha256':hashlib.sha256(save.read_bytes()).hexdigest()})
    (OUT/'commands.json').write_text(json.dumps(commands,indent=2))
    with (directory/'run.log').open('w') as log:
        subprocess.run(command,cwd=SOURCE,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
    result=json.loads((directory/'result.json').read_text())
    assert result['ticks']==stop,(name,result['ticks'],stop)
    print(name,result['finalChecksum'],flush=True)
    return directory

def hashes(path):
    with path.open('rb') as f:
        head=f.read(20); assert head[:4]==b'GCS1'
        teams,players,count,flags=struct.unpack('<4I',head[4:]); result={}
        def read(n):
            data=f.read(n); assert len(data)==n; return data
        for _ in range(count):
            prefix=read(8); tick,aggregate=struct.unpack('<2I',prefix); h=hashlib.sha256(prefix[4:])
            for _ in range(teams):
                h.update(read(4))
                for _ in range(2):
                    data=read(4);h.update(data); entities=struct.unpack('<I',data)[0]
                    for _ in range(entities):
                        data=read(10);h.update(data);fields=struct.unpack_from('<I',data,6)[0];h.update(read(4*fields))
            result[tick]=h.hexdigest()
        assert not f.read(1)
        return result

def saved(directory):
    return directory/'final.game.gz' if (directory/'final.game.gz').exists() else directory/'final.game'

fixtures=SOURCE/'artifacts/air-ignore-forbidden/inputs'
cases=[('direct',next(fixtures.rglob('direct-flight-couriers.game'))),('constrained',next(fixtures.rglob('air-routing-stress.game')))]
report=[]
for name,save in cases:
    # One common post-load snapshot fixes current save metadata and observation phase.
    save=saved(run(name+'-promoted',save,1,extra=('--save','final')))
    expected=None
    for participants in (1,2,4,8):
        directory=run(f'{name}-p{participants}',save,129,participants,('--telemetry','checksums'))
        actual=hashes(directory/'game.replay.checksums'); assert len(actual)==128
        if expected is None: expected=actual
        else: assert actual==expected,(name,participants,'thread divergence')
    for phase in range(8):
        checkpoint=saved(run(f'{name}-checkpoint-{phase}',save,33+phase,extra=('--save','final')))
        directory=run(f'{name}-resume-{phase}',checkpoint,129,(1,2,4,8)[phase%4],('--telemetry','checksums'))
        actual=hashes(directory/'game.replay.checksums')
        assert actual and all(expected[tick]==value for tick,value in actual.items()),(name,phase,'save divergence')
    report.append({'case':name,'participants':[1,2,4,8],'ticks_compared':128,'aggregate_and_all_team_entity_fields_match':True,'save_phases':list(range(8))})
(OUT/'summary.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'binary_sha256':hashlib.sha256(BINARY.read_bytes()).hexdigest(),'results':report,'platforms':['Linux x86_64 GCC 13'],'omitted_platforms':['Windows','macOS','Android','iOS','browser'],'build':'dev_fast=0 release=1, -O3 -g1, no PCH/unity, GPU off'},indent=2))
