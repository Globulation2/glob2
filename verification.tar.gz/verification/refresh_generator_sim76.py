from pathlib import Path
import subprocess,os,json,hashlib,shutil,time
root=Path.cwd();out=root/'artifacts/air-merge-master/browser-fixtures-sim76';b='/dev/shm/glob2-direct-air-release';commands=[]
cmd=['python3','test/run_tests.py','--build-dir',b,'--binary','engine','--filter','MapPreview/generator Studio*','--artifacts',str(out/'preview'),'--junit',str(out/'preview.xml'),'--timeout','600']
commands.append(cmd)
with (out/'preview.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=660)
reports=list((out/'preview').rglob('native-report.json'));assert len(reports)==1,reports
report=json.loads(reports[0].read_text());package=reports[0].parent/'frozen-package.json'
common=['--ticks','64','--write-replay','--telemetry','checksums','--save','initial','--save','final']
for name,args in [('generated',['--generator-package',str(package),'--generator','examples:swamp','--map-seed','19','--set','width=7','--set','height=7','--set','teams=4','--set','workers=4','--candidates','1','--game-seed','19',*sum([['--player','nicowar'] for _ in range(4)],[])]),('loaded',['--load-game',str(out/'generated/initial.game.gz')])]:
 cmd=[b+'/src/glob2','game','run',*args,*common,'--output-dir',str(out/name)];commands.append(cmd)
 env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(out/(name+'-profile')),GLOB2_USER_DIR=str(out/(name+'-profile')))
 with (out/(name+'.log')).open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
a=(out/'generated/game.replay.checksums').read_bytes();b=(out/'loaded/game.replay.checksums').read_bytes();assert a==b,'generated and loaded native traces differ'
p=root/'browser/tests/fixtures/generator-studio-trace.json';shutil.copy2(p,out/'prior-generator-studio-trace.json');j=json.loads(p.read_text())
for key in ('worldFingerprint','checksum','versionMinor','simRevision','simVersion'):j[key]=report[key]
j['traceBytes']=len(a);j['traceSha256']=hashlib.sha256(a).hexdigest();p.write_text(json.dumps(j,indent=2)+'\n')
(out/'generator-commands.json').write_text(json.dumps(commands,indent=2));print('Refreshed generator native reference; generated and loaded traces identical',flush=True)
