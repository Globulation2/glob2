import os,json,subprocess
from pathlib import Path
r=Path.cwd();o=r/'artifacts/render-execution-names';build='build/linux/client/debug/dev-dev_fast-true-linker-auto'
env=os.environ.copy();env.update(GLOB2_TEST_SHADER_DIRECTORY='/home/bradley/glob2/artifacts/pr-1148-parallel-rendering/native-shaders',GLOB2_RENDERER_SHADER_DIR='/home/bradley/glob2/artifacts/pr-1148-parallel-rendering/native-shaders',GLOB2_RENDER_EXECUTION='immediate')
commands=[('unit',['SurfaceCoverage/*','SurfaceRaster/*','ComputeExecutor/*']),('engine',['SoftwareRenderer/*','TerrainMaterials/*','TerrainPresentation/*','RendererSwitchIntegration/*','MapRenderResize/*'])]
records=[]
for binary,filters in commands:
 cmd=['python3','test/run_tests.py','--build-dir',build,'--binary',binary,'-j2','--display-jobs','1','--timeout','600','--write-inventory',str(o/f'{binary}-inventory.json'),'--junit',str(o/f'{binary}.xml'),'--artifacts',str(o/binary)]
 for f in filters:cmd+=['--filter',f]
 records.append({'command':cmd,'environment':{k:v for k,v in env.items() if k.startswith('GLOB2_') and k!='GLOB2_OFFICIAL_INSTANCE_TOKEN'}})
 (o/'test-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (o/f'{binary}.log').open('w') as log:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(binary,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
