import json,subprocess,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
analysis=json.loads((OUT/'analysis.json').read_text())
if not analysis['slow_ticks_50ms']: raise SystemExit('No ticks over 50 ms to sample.')
worst=analysis['slow_ticks_50ms'][0]
source=OUT/worst['game']/'initial.game.gz'
dest=OUT/'sampled-repeat'
cmd=[str(OUT/'baseline-glob2'),'game','run','--load-game',str(source),'--ticks',str(worst['tick']+512),'--compute-threads','auto','--compute-telemetry','off','--gradient-backend','cpu','--gradient-algorithm','buckets','--benchmark-warmup','0','--output-dir',str(dest)]
record={'target':worst,'command':cmd,'purpose':'Separate stack-sampling repeat near a slow tick; not included in measured latency statistics.'}
with (OUT/'sampled-repeat.stdout.log').open('w') as stdout,(OUT/'sampled-repeat.stderr.log').open('w') as stderr:
    proc=subprocess.Popen(cmd,cwd=ROOT,stdout=stdout,stderr=stderr)
    try:
        while proc.poll() is None:
            path=dest/'progress.jsonl'
            if path.exists():
                with path.open('rb') as file:
                    file.seek(max(0,path.stat().st_size-512)); data=file.read().decode().splitlines()
                tick=json.loads(data[-1])['tick'] if data else 0
                if tick>=max(256,worst['tick']-512): break
            time.sleep(.05)
        if proc.poll() is None:
            print('Sampling process',proc.pid,'near tick',tick,'target',worst['tick'],flush=True)
            samplecmd=['/usr/bin/sample',str(proc.pid),'3','1','-mayDie','-fullPaths','-file',str(OUT/'tail-stacks.txt')]
            record['sample_command']=samplecmd
            sample=subprocess.run(samplecmd,cwd=ROOT,capture_output=True,text=True)
            record.update(sample_returncode=sample.returncode,sample_stdout=sample.stdout,sample_stderr=sample.stderr)
        record['returncode']=proc.wait()
    finally:
        if proc.poll() is None: proc.terminate();proc.wait()
(OUT/'sampled-repeat.json').write_text(json.dumps(record,indent=2))
print('Sample repeat finished',record.get('sample_returncode'),flush=True)
