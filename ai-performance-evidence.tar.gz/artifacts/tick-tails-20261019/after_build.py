import os,time,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
while True:
    try: os.kill(71808,0)
    except ProcessLookupError: break
    time.sleep(2)
log=Path('/tmp/glob2-tail-build.log').read_text()
if 'scons: done building targets.' not in log: raise SystemExit('Release build failed; no games launched.')
# Run only the new integration contract; all calls use the real release executable.
code="""import sys,unittest
from pathlib import Path
sys.path.insert(0,'test')
import test_cli_smoke as cli
cli.BINARY=str(Path('build/darwin/client/release/dev-linker-auto/src/glob2').resolve())
cli.ARTIFACTS=Path('artifacts/tick-tails-20261019/cli-contract').resolve()
suite=unittest.TestSuite([cli.CliSmoke('test_benchmark_tick_profile_preserves_execution_and_tick_identity')])
raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
"""
out=Path(__file__).resolve().parent
with (out/'cli-contract.log').open('w') as f:
 result=subprocess.run([sys.executable,'-c',code],cwd=root,stdout=f,stderr=f)
if result.returncode: raise SystemExit('CLI profiling/checksum contract failed; see cli-contract.log')
print('CLI tick-profile/checksum contract passed.',flush=True)
subprocess.run(['git','diff','--output='+str(out/'diagnostic.patch')],cwd=root,check=True)
raise SystemExit(subprocess.call([sys.executable,str(out/'run_games.py')],cwd=root))
