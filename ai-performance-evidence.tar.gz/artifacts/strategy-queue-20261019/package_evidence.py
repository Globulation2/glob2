from pathlib import Path
import tarfile,json
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
folders=['tick-tails-20261019','ai-hotspots-20261019','maintenance-reuse-20261019','upgrade-colony-20261019','full-game-retest-20261019','fresh-spikes-20261019','strategy-queue-20261019']
files=set()
for name in folders:
 d=ROOT/'artifacts'/name
 for f in d.iterdir():
  if f.is_file() and f.suffix in ['.json','.csv','.png','.py','.log','.txt','.xml','.patch'] and f.stat().st_size<10_000_000:files.add(f)
 for g in d.glob('game-*'):
  if g.is_dir():
   for n in ['initial.game.gz','final.game.gz','game.replay','tick-timings.csv','slow-ticks.json','ai-decisions.jsonl','owner-ticks.jsonl']:
    f=g/n
    if f.exists():files.add(f)
for name in ['scoped-game-1','scoped-game-4','deep-game-1']:
 for f in (ROOT/'artifacts/fresh-spikes-20261019'/name).iterdir():
  if f.name in ['ai-decisions.jsonl','game.replay']:files.add(f)
for f in (OUT/'integration-compat').rglob('*'):
 if f.is_file() and (f.suffix in ['.json','.py','.log','.checksums'] or f.name.endswith('.game.gz')):files.add(f)
files={f for f in files if f.name!='evidence-manifest.json' and f.suffix!='.replay' and (not f.name.endswith('.game.gz') or f.name=='initial.game.gz')}
for f in (OUT/'continuation').glob('*.game'):files.add(f)
for sub in ['baseline','profiled']:
 f=OUT/'integration-cli/test_ai_decision_profile_gate_preserves_execution'/sub/'game.replay'
 if f.exists():files.add(f)
with tarfile.open(OUT/'review-evidence.tar.gz','w:gz',compresslevel=3) as tar:
 for f in sorted(files):tar.add(f,arcname=str(f.relative_to(ROOT)),recursive=False)
manifest=dict(files=[str(f.relative_to(ROOT)) for f in sorted(files)],archive_bytes=(OUT/'review-evidence.tar.gz').stat().st_size)
(OUT/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2));print('Evidence',len(files),'files',manifest['archive_bytes'],'bytes',flush=True)
