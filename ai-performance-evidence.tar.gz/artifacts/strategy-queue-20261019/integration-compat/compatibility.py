import hashlib,json,os,subprocess,sys,gzip,struct
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];BINARY=OUT.parent/'integration-glob2';sys.path.insert(0,str(ROOT/'test'))
from check_javascript import complete_ticks
previous={r["name"]:r for r in json.loads((OUT/"compatibility-commands.json").read_text()) if "command" in r} if (OUT/"compatibility-commands.json").exists() else {}
records=[]
def run(name,args,expected=0):
 cmd=[str(BINARY),*map(str,args)];dest=OUT/name
 if name in previous and previous[name]['command']==cmd:
  r=type('Completed',(),{'returncode':previous[name]['returncode']})()
 else:
  with (OUT/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=f)
 records.append(dict(name=name,command=cmd,returncode=r.returncode));(OUT/'compatibility-commands.json').write_text(json.dumps(records,indent=2));assert r.returncode==expected,(name,r.returncode)
 return dest
for label,source,end in [('retained-save',ROOT/'artifacts/fresh-spikes-20261019/game-1/final.game.gz',90128),('queue-save',OUT/'retained-save-workers-1/final.game.gz',90256)]:
 traces=[]
 for workers in (1,8):
  name=f'{label}-workers-{workers}';dest=OUT/name
  run(name,['game','run','--load-game',source,'--ticks',end,'--compute-threads',workers,'--gradient-backend','cpu','--gradient-algorithm','buckets','--compute-telemetry','off','--benchmark-warmup','0','--telemetry','checksums','--write-replay','--save','final','--save','every:64','--output-dir',dest])
  traces.append(complete_ticks((dest/'game.replay.checksums').read_bytes()))
 assert len(traces[0])==128 and traces[0]==traces[1]
 checkpoint=((end-64)//64)*64;name=f'{label}-reload';dest=OUT/name
 run(name,['game','run','--load-game',OUT/f'{label}-workers-1/checkpoint-{checkpoint}.game.gz','--ticks',end,'--compute-threads','8','--gradient-backend','cpu','--gradient-algorithm','buckets','--telemetry','checksums','--write-replay','--output-dir',dest])
 resumed=complete_ticks((dest/'game.replay.checksums').read_bytes());assert len(resumed)==end-checkpoint
 def minor(path):
  data=gzip.decompress(path.read_bytes());length=struct.unpack_from('>I',data)[0];return struct.unpack_from('>I',data,8+length)[0]
 old_minor=minor(source);new_minor=minor(OUT/f'{label}-workers-1/checkpoint-{checkpoint}.game.gz')
 # These standard maps have no required resource experiment keys. MapHeader's
 # version XOR is rotated once there and another teams+players+6 times by
 # Game::checkSum. Retain all map/script/team/entity coverage after normalizing
 # only that known format metadata contribution.
 result=json.loads((OUT/f'{label}-workers-1/result.json').read_text());rotation=(len(result['teams'])+len(result['players'])+7)%32
 raw=old_minor^new_minor;delta=((raw>>rotation)|(raw<<(32-rotation)))&0xffffffff if rotation else raw
 assert all(traces[0][t][8:]==v[8:] and (struct.unpack_from('<I',traces[0][t],4)[0]^delta)==struct.unpack_from('<I',v,4)[0] for t,v in resumed.items())
 records.append(dict(name=label,per_tick_worker_parity=True,ticks=128,reload_parity_ticks=end-checkpoint,loaded_format=old_minor,reloaded_format=new_minor,aggregate_save_version_xor=delta,full_checksum_parity_after_save_version_normalization=True));(OUT/'compatibility-commands.json').write_text(json.dumps(records,indent=2))
# A different sim revision must not enter match verification.
old=OUT/'previous-revision.g2mr';old.write_bytes(subprocess.check_output(['git','show','origin/master:test/fixtures/multiplayer/FourSquares1.g2mr'],cwd=ROOT))
run('old-sim-rejection',['match','verify',old,'--map-file',ROOT/'maps/FourSquares1.map.gz','--output-dir',OUT/'old-sim-rejection'],expected=0)
verdict=json.loads((OUT/'old-sim-rejection/verdict.json').read_text());assert verdict['verdict']=='unverifiable' and 'sim version' in verdict['reason']
records.append(dict(name='old-sim-boundary',verdict=verdict));(OUT/'compatibility-commands.json').write_text(json.dumps(records,indent=2))
print('Complete tick records match for one/eight workers and reloads; old and new saves load; old sim rejected.',flush=True)
