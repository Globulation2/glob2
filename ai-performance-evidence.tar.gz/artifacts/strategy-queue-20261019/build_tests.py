import concurrent.futures,json,shlex,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
commands=json.loads((ROOT/'artifacts/maintenance-reuse-20261019/test-build-commands.json').read_text());base=commands[0][:commands[0].index('-c')]+['-Ilibgag/src','-fno-access-control']
sources=['test/support/Glob2Test.cpp','test/support/EngineFixtures.cpp','test/support/LegacyResourceTypes.cpp','test/support/GlobalContainerSlot.cpp','src/ai/maxima/MaximaImplementationIntegrationTest.cpp','src/net/turn/TurnEngineHarness.cpp','src/ai/AIStateContinuationTest.cpp']
compiles=[base+['-c',s,'-o',str(OUT/(Path(s).stem+'.o'))] for s in sources]
(OUT/'test-compile-commands.json').write_text(json.dumps(compiles,indent=2))
def run(cmd):
 with (OUT/(Path(cmd[-1]).stem+'.compile.log')).open('w') as f:
  r=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=f)
 if r.returncode:raise RuntimeError(cmd[-1])
 print('Compiled',cmd[-1],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(run,compiles))
if '--compile-only' in sys.argv:raise SystemExit(0)
# Reuse exactly the release client's production objects and library arguments.
line=next(s for s in (ROOT/'artifacts/fresh-spikes-20261019/integration-build.log').read_text().splitlines() if ' -o build/darwin/client/release/dev-linker-auto/src/glob2 ' in s)
link=shlex.split(line);link[link.index('-o')+1]=str(OUT/'focused-engine-tests');link=[a for a in link if a!='-s' and not a.endswith('/src/app/Glob2.o')]
link+= [str(OUT/(Path(s).stem+'.o')) for s in sources]+['artifacts/maintenance-reuse-20261019/main.o']
(OUT/'test-link-command.json').write_text(json.dumps(link,indent=2))
with (OUT/'test-link.log').open('w') as f:r=subprocess.run(link,cwd=ROOT,stdout=f,stderr=f)
raise SystemExit(r.returncode)
