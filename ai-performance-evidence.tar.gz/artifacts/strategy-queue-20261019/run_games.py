import hashlib,json,subprocess,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];SOURCE=ROOT/'artifacts/fresh-spikes-20261019'
metadata=json.loads((SOURCE/'metadata.json').read_text());records=[]
for game in (1,4):
 dest=OUT/f'game-{game}';cmd=metadata['runs'][game-1]['command'].copy();cmd[0]=str(OUT/'queue-glob2');cmd[cmd.index('--output-dir')+1]=str(dest);cmd+=['--save','every:50000']
 record=dict(game=game,command=cmd,started_at=time.time());records.append(record);(OUT/'runs.json').write_text(json.dumps(records,indent=2))
 print('Measuring strategy queue, game',game,flush=True)
 with (OUT/f'game-{game}.stdout.log').open('w') as stdout,(OUT/f'game-{game}.stderr.log').open('w') as stderr:r=subprocess.run(cmd,cwd=ROOT,stdout=stdout,stderr=stderr)
 record.update(returncode=r.returncode,finished_at=time.time());assert r.returncode==0
 rows=[json.loads(s) for s in (dest/'ai-decisions.jsonl').read_text().splitlines()]
 count=sum(r['thread_cpu_ns']>=20e6 for r in rows);collisions=[]
 heavy=['Maxima::manage_land_clearing','Maxima::update_maintenance_clearing_areas','Maxima::update_preemptive_defense','Maxima::compute_defense_flag_positioning','Maxima::update_farming','Maxima::development_cycle']
 for r in rows:
  if r['phases'].get('Maxima::evaluate_strategy',{}).get('calls',0) and any(r['phases'].get(h,{}).get('calls',0) for h in heavy):collisions.append(r)
 assert not collisions
 record.update(ai_callbacks_cpu_ge20ms=count,max_ai_cpu_ms=max(r['thread_cpu_ns'] for r in rows)/1e6,strategy_other_heavy_job_collisions=len(collisions),top_cpu_decisions=sorted(rows,key=lambda r:r['thread_cpu_ns'],reverse=True)[:20])
 (OUT/'runs.json').write_text(json.dumps(records,indent=2))
 print('Finished',game,'callbacks >=20ms CPU',count,'max CPU ms',record['max_ai_cpu_ms'],'strategy collisions',len(collisions),flush=True)
