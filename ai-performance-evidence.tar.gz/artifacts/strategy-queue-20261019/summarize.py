import csv,json,platform,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[1];comparison=json.loads((p/'comparison.json').read_text())
for r in comparison:
 g=p/f"game-{r['game']}"
 with (g/'tick-timings.csv').open() as f:rows=list(csv.DictReader(f))
 r['after']['max_tick_excluding_periodic_save_ms']=max(int(t['elapsed_ns']) for t in rows if int(t['tick_before_step'])!=49999)/1e6
 r['after']['periodic_checkpoint_serialization_tick']=49999
 r['notes']=['Post-change command additionally saves a checkpoint at tick 50000; tick 49999 includes serialization in owner output. Raw maximum tick therefore includes that save.','AI callback timings exclude checkpoint serialization.','Normal desktop background contention; one run per setup. AI timing changes can alter subsequent world state; this is descriptive rather than an isolated same-workload speedup.']
(p/'comparison.json').write_text(json.dumps(comparison,indent=2))
findings=dict(base_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),platform=platform.platform(),sim_revision=96,changes=['Strategy reviews consume the existing deterministic map-scale job slot, ahead of other pending maintenance/planning.','Initialization and invalidation publish fresh budgets before executors run; pending work is retained.','No serialized state or save format changed. AI timing and potentially subsequent game evolution change.'],validation=dict(release_build=True,maxima_integration_cases=30,maxima_integration_assertions=2103,continuation_cases=2,continuation_assertions=35756,cli_contract_cases=3,golden_fixture_assertions=6038,worker_parity_complete_tick_records=256,reload_parity_complete_tick_records=160,retained_save_load=True,previous_sim_version_unverifiable=True),performance=comparison,limits=['macOS arm64 only; cross-platform checksum equivalence was not verified.','Full native test inventory not built; focused tests linked against the actual release production objects.','Gameplay feel requires play review.','No origin update performed.'])
(p/'findings.json').write_text(json.dumps(findings,indent=2))
patch=subprocess.check_output(['git','diff','--binary'],cwd=root)
for h in ['src/ai/AIProfile.h','src/engine/OwnerTickProfile.h']:patch+=subprocess.run(['git','diff','--no-index','/dev/null',h],cwd=root,stdout=subprocess.PIPE).stdout
(p/'source.patch').write_bytes(patch)
