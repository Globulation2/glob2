import json,hashlib,subprocess,shutil,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];BINARY=OUT/'scoped-glob2'
shutil.copy2(ROOT/'build/darwin/client/release/dev-linker-auto/src/glob2',BINARY)
metadata=json.loads((OUT/'metadata.json').read_text());records=[]
for game in (1,4):
 dest=OUT/f'scoped-game-{game}';cmd=metadata['runs'][game-1]['command'].copy();cmd[0]=str(BINARY);cmd[cmd.index('--output-dir')+1]=str(dest)
 record=dict(game=game,command=cmd,binary_sha256=hashlib.sha256(BINARY.read_bytes()).hexdigest(),started_at=time.time());records.append(record);(OUT/'scoped-repeats.json').write_text(json.dumps(records,indent=2))
 print('Repeating with detailed scopes',game,flush=True)
 with (OUT/f'scoped-game-{game}.stdout.log').open('w') as stdout,(OUT/f'scoped-game-{game}.stderr.log').open('w') as stderr:
  result=subprocess.run(cmd,cwd=ROOT,stdout=stdout,stderr=stderr)
 record.update(returncode=result.returncode,finished_at=time.time());assert result.returncode==0
 original=next((OUT/f'game-{game}').glob('*.replay'));repeated=dest/original.name
 record['replay_bytes_identical']=original.read_bytes()==repeated.read_bytes();assert record['replay_bytes_identical']
 rows=[json.loads(s) for s in (dest/'ai-decisions.jsonl').read_text().splitlines()];rows.sort(key=lambda r:r['thread_cpu_ns'] or 0,reverse=True)
 record['top_cpu_decisions']=rows[:30]
 (OUT/'scoped-repeats.json').write_text(json.dumps(records,indent=2))
 for r in rows[:8]:print(r['ai'],r['observed_tick'],'CPU',round(r['thread_cpu_ns']/1e6,2),'phases',[(k,round(v['self_ns']/1e6,2)) for k,v in sorted(r['phases'].items(),key=lambda kv:-kv[1]['self_ns'])[:3]],flush=True)
