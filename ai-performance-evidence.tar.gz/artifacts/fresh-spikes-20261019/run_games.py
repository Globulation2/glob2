import hashlib,json,platform,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
BINARY=ROOT/'artifacts/owner-spike-20261019/owner-profiled-clock-glob2'
players=['numbi','castor','warrush','econo','nicowar','cortex','maxima','cabino']
metadata={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'platform':platform.platform(),'binary':str(BINARY),'binary_sha256':hashlib.sha256(BINARY.read_bytes()).hexdigest(),'build_command':'PYTHONPATH='+str(ROOT)+' python3 tools/dev_build.py dev_fast=0 release=1','telemetry':'trace','notes':['Games executed sequentially; normal desktop background load present.','Headless simulation: presentation/rendering work absent.','Fresh seeds, AI callback wall/thread CPU profiles and owner tick wall/thread CPU attribution; timings include diagnostic overhead.','Optimizations: reuse maintenance candidates and baseline food claims; upgrade checks evaluate only their actual colony.','Local diagnostic additions split hiring/statistics and collect full-session deferred callback histograms.'],'runs':[], 'patch_sha256':hashlib.sha256(subprocess.check_output(['git','diff'],cwd=ROOT)).hexdigest()}
(OUT/'metadata.json').write_text(json.dumps(metadata,indent=2))
for i,(generator,seed) in enumerate([('honeycomb-isle',2026),('continents',2026),('honeycomb-isle',777),('continents',777)],1):
    dest=OUT/f'game-{i}'
    order=players if i==1 else players[4:]+players[:4]
    command=[str(BINARY),'game','run','--generator',generator,'--map-seed',str(seed),'--game-seed',str(seed+10000),'--set','width=8','--set','height=8','--set','teams=8','--compute-threads','auto','--compute-telemetry','trace','--gradient-backend','cpu','--gradient-algorithm','buckets','--benchmark-tick-profile','--ai-decision-profile','--ai-profile-min-ms','10','--owner-tick-profile','--owner-profile-min-ms','10','--ticks','90000','--benchmark-warmup','0','--save','initial','--save','final','--write-replay','--output-dir',str(dest)]
    if generator=='continents': command+=['--set','continent=4']
    for ai in order: command+=['--player',ai]
    record={'generator':generator,'command':command,'map_seed':seed,'game_seed':seed+10000,'players':order,'started_at':time.time()}
    metadata['runs'].append(record)
    (OUT/'metadata.json').write_text(json.dumps(metadata,indent=2))
    print('Starting game',i,'seed',seed,flush=True)
    with (OUT/f'game-{i}.stdout.log').open('w') as stdout,(OUT/f'game-{i}.stderr.log').open('w') as stderr:
        result=subprocess.run(command,cwd=ROOT,stdout=stdout,stderr=stderr)
    record.update(returncode=result.returncode,finished_at=time.time())
    (OUT/'metadata.json').write_text(json.dumps(metadata,indent=2))
    print('Finished game',i,'return code',result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.returncode)
