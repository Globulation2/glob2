import json,collections
from pathlib import Path
OUT=Path(__file__).resolve().parent
ai=[];owner=[];runs=[]
for game in sorted(OUT.glob('game-*')):
 if not game.is_dir():continue
 for name,rows in [('ai-decisions.jsonl',ai),('owner-ticks.jsonl',owner)]:
  if (game/name).exists():
   for line in (game/name).read_text().splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    r['game']=game.name;rows.append(r)
 if (game/'result.json').exists():
  r=json.loads((game/'result.json').read_text());s=json.loads((game/'slow-ticks.json').read_text())
  runs.append(dict(game=game.name,generation=r['generation'],ticks=r['ticks'],worst_ticks=s['ticks'][:10]))
ai.sort(key=lambda r:r['thread_cpu_ns'] or 0,reverse=True);owner.sort(key=lambda r:r['thread_cpu_ns'] or 0,reverse=True)
summary=dict(ai_cpu_rank=ai[:100],owner_cpu_rank=owner[:50],runs=runs,ai_by_type={a:dict(profiled_calls=len(rr),max_cpu_ms=max(r['thread_cpu_ns'] for r in rr)/1e6,max_wall_ms=max(r['wall_ns'] for r in rr)/1e6,calls_cpu_ge_20ms=sum(r['thread_cpu_ns']>=20e6 for r in rr)) for a in sorted({r['ai'] for r in ai}) if (rr:=[r for r in ai if r['ai']==a])})
(OUT/'ranked-spikes.json').write_text(json.dumps(summary,indent=2))
print('Completed games',len(runs),'AI types',summary['ai_by_type'])
for r in ai[:12]:print(r['game'],r['ai'],r['observed_tick'],'CPU',round(r['thread_cpu_ns']/1e6,3),'wall',round(r['wall_ns']/1e6,3),'phases',[(k,round(v['self_ns']/1e6,2)) for k,v in sorted(r['phases'].items(),key=lambda kv:-kv[1]['self_ns'])[:4]])
for r in owner[:5]:print('OWNER',r['game'],r['tick_before_step'],r['thread_cpu_ns']/1e6,r['wall_ns']/1e6)
