import csv,json,math,collections
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=Path(__file__).resolve().parent
names={'ai':'AI decisions','periodic_gradient':'Periodic gradients','building_gradient':'Building gradients','resource_growth':'Resource growth','hiring':'Hiring','team_statistics':'Team statistics','checksum':'Checksums','other':'Turret targeting (other)'}
all_callbacks={}
ai_callbacks={}
by_map={}
rows=[]
slow_rows=[]
def merge(target,value):
    target['samples']+=value['samples']; target['total_ns']+=value['total_ns']; target['maximum_ns']=max(target['maximum_ns'],value['maximum_ns'])
    target['histogram']=[a+b for a,b in zip(target['histogram'],value['histogram'])]
def empty(): return dict(samples=0,total_ns=0,maximum_ns=0,histogram=[0]*65)
def quantile_bin(value,q):
    if not value['samples']: return None
    target=math.ceil(value['samples']*q);count=0
    for i,n in enumerate(value['histogram']):
        count+=n
        if count>=target: return [0,0] if i==0 else [2**(i-1),2**i-1]
for path in sorted(OUT.glob('game-*/result.json')):
    result=json.loads(path.read_text());c=result['compute_telemetry'];profile=json.loads((path.parent/'slow-ticks.json').read_text())
    assert c['mode']=='trace' and c['threads']==8
    callbacks=c['deferred_callback_execution']
    family=by_map.setdefault(result['generation']['generator'],{})
    for name,value in callbacks.items():
        assert sum(value['histogram'])==value['samples']
        merge(all_callbacks.setdefault(name,empty()),value)
        merge(family.setdefault(name,empty()),value)
    for i,value in enumerate(c['ai_lane_callback_execution'][:len(result['players'])]):
        merge(ai_callbacks.setdefault(result['players'][i]['ai'],empty()),value)
    with (path.parent/'tick-timings.csv').open() as f:
        durations=np.array([int(row['elapsed_ns']) for row in csv.DictReader(f)],dtype=np.int64)
    milliseconds=durations/1e6
    assert len(durations)==result['benchmark_measured_ticks']
    assert max(durations)==profile['ticks'][0]['elapsed_ns']
    row={'game':path.parent.name,'generator':result['generation']['generator'],'seed':result['generation']['map_seed'],'ticks':result['ticks'],'seconds':result['run_ns']/1e9,'mean_ms':float(np.mean(milliseconds)),'p99_ms':float(np.sort(milliseconds)[(len(milliseconds)-1)*99//100]),'p999_ms':float(np.sort(milliseconds)[(len(milliseconds)-1)*999//1000]),'max_ms':float(np.max(milliseconds)),'ticks_ge_50ms':int(np.sum(milliseconds>=50)),'ticks_ge_100ms':int(np.sum(milliseconds>=100)),'wait_tick_pct':100*c['background_wait_ticks']/c['advancing_ticks'],'profile_collection_seconds':profile['collection_ns']/1e9,'trace_lost_events':c['trace_lost_events']}
    rows.append(row)
    for tick in profile['ticks']:
        if tick['elapsed_ns']<50e6: continue
        waits={k:v['elapsed_ns']/1e6 for k,v in tick['waits'].items()}
        phases={k:v['observed_ns']/1e6 for k,v in tick['phases'].items() if v['stride']==1 and k not in ('simulation.deadline_lateness','render.displayed_scene_age','pacing.presentation_interval','pacing.interval_change')}
        slow_rows.append(dict(game=row['game'],generator=row['generator'],seed=row['seed'],tick=tick['tick'],elapsed_ms=tick['elapsed_ns']/1e6,waits_ms=waits,phases_ms=phases))
    plt.figure(figsize=(9,3)); plt.plot(np.arange(len(milliseconds)),milliseconds,lw=.5,color='#297b9d');plt.yscale('log');plt.axhline(100,color='#b83b3b',lw=1,ls='--',label='100 ms');plt.xlabel('Tick index');plt.ylabel('Tick elapsed time (ms)');plt.title(f"{row['generator']}, seed {row['seed']} — CPU gradients");plt.legend();plt.tight_layout();plt.savefig(OUT/(row['game']+'-tick-latency.png'),dpi=160);plt.close()
for values in (all_callbacks,ai_callbacks):
    for name,value in values.items():
        value['mean_ns']=value['total_ns']/value['samples'] if value['samples'] else None
        for q,label in [(0.5,'p50_bin_ns'),(.99,'p99_bin_ns'),(.999,'p999_bin_ns')]: value[label]=quantile_bin(value,q)
summary={'by_map':by_map,'runs':rows,'callbacks':all_callbacks,'ai_callbacks':ai_callbacks,'slow_ticks_50ms':sorted(slow_rows,key=lambda x:-x['elapsed_ms'])}
(OUT/'analysis.json').write_text(json.dumps(summary,indent=2))
with (OUT/'execution-histograms.csv').open('w') as f:
    writer=csv.writer(f);writer.writerow(['population','job_or_ai','lower_ns','upper_ns_inclusive','callbacks','percent'])
    for population,values in [('producer',all_callbacks),('AI',ai_callbacks)]:
        for name,value in values.items():
            for i,count in enumerate(value['histogram']):
                writer.writerow([population,name,0 if i==0 else 2**(i-1),0 if i==0 else 2**i-1,count,100*count/value['samples'] if value['samples'] else ''])

with (OUT/'runs.csv').open('w') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
for label,values in [('job-execution-histograms',all_callbacks),('ai-execution-histograms',ai_callbacks)]:
    active=[(k,v) for k,v in values.items() if v['samples']]
    fig,axes=plt.subplots(len(active),1,figsize=(11,2.05*len(active)),sharex=True)
    for ax,(name,value) in zip(np.atleast_1d(axes),active):
        counts=np.array(value['histogram'][1:]);centres=np.array([2**(i-.5)/1e6 for i in range(1,65)])
        ax.bar(centres,100*counts/value['samples'],width=centres*.6,color='#297b9d');ax.set_xscale('log')
        ax.set_yscale('log');ax.set_ylabel('% of calls (log)');ax.set_title(f"{names.get(name,name)} — {value['samples']:,} callbacks; max {value['maximum_ns']/1e6:,.2f} ms",loc='left',fontsize=10);ax.grid(axis='y',alpha=.2)
        ax.set_xlim(.00001,4096)
    np.atleast_1d(axes)[-1].set_xlabel('Elapsed callback execution time (ms), powers-of-two bins')
    fig.suptitle('Deferred callback durations — four 256×256 / 8-AI games (CPU gradients)',fontsize=12);fig.tight_layout(rect=(0,0,1,.98));fig.savefig(OUT/(label+'.png'),dpi=150);plt.close(fig)
print(json.dumps(rows,indent=2))
print('AI max/mean ms', {k:(v['maximum_ns']/1e6,v['mean_ns']/1e6 if v['mean_ns'] else None) for k,v in ai_callbacks.items()})
print('largest slow ticks',json.dumps(summary['slow_ticks_50ms'][:12],indent=2))

active=[k for k,v in all_callbacks.items() if v['samples']]
fig,axes=plt.subplots(len(active),1,figsize=(11,2.0*len(active)),sharex=True)
for ax,name in zip(np.atleast_1d(axes),active):
    for (family,values),color in zip(by_map.items(),['#287b9d','#d17b20']):
        value=values[name]
        if not value['samples']:continue
        counts=np.array(value['histogram'][1:]);centres=np.array([2**(i-.5)/1e6 for i in range(1,65)])
        fraction=100*counts/value['samples']; fraction=np.where(fraction>0,fraction,np.nan)
        ax.plot(centres,fraction,marker='.',lw=1.1,color=color,label='Europe' if family=='continents' else 'Honeycomb Isle')
    ax.set_xscale('log');ax.set_yscale('log');ax.set_ylabel('% of calls (log)');ax.set_title(names.get(name,name),loc='left',fontsize=10);ax.set_xlim(.00001,4096);ax.grid(axis='y',alpha=.2)
np.atleast_1d(axes)[0].legend();np.atleast_1d(axes)[-1].set_xlabel('Elapsed callback execution time (ms), powers-of-two bins')
fig.suptitle('Execution-time distributions by map — two seeds each, 256×256, eight mixed AIs',fontsize=12);fig.tight_layout(rect=(0,0,1,.98));fig.savefig(OUT/'map-comparison-histograms.png',dpi=150);plt.close(fig)
