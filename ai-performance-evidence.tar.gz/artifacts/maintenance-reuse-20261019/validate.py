import hashlib,json,shutil,subprocess,sys
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'artifacts/maintenance-reuse-20261019';OLD=ROOT/'artifacts/ai-hotspots-20261019'
sys.path.insert(0,str(ROOT/'test'));from check_javascript import complete_ticks
NEW=OUT/'food-reuse-glob2';shutil.copy2(ROOT/'build/darwin/client/release/dev-linker-auto/src/glob2',NEW)
BEFORE=OLD/'profiled-base-glob2';records=[]
def run(binary,source,dest,end,first=None):
 cmd=[str(binary),'game','run','--load-game',str(source),'--ticks',str(end),'--gradient-backend','cpu','--gradient-algorithm','buckets','--compute-threads','auto','--compute-telemetry','off','--telemetry','checksums','--save','final','--output-dir',str(dest)]
 if first is not None:cmd+=['--ai-decision-profile','--ai-profile-min-ms','0','--ai-profile-from-tick',str(first)]
 with dest.with_suffix('.log').open('w') as log:r=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=log)
 records.append(dict(command=cmd,returncode=r.returncode));(OUT/'validation-commands.json').write_text(json.dumps(records,indent=2))
 assert r.returncode==0, str(dest)
 return complete_ticks((dest/'game.replay.checksums').read_bytes())
results=[]
for game,start,end in [(2,50000,57000),(1,44000,48000),(4,46000,50000),(3,22000,26000)]:
 print('Checking food reuse: game',game,flush=True)
 dest=OUT/f'food-game-{game}';new=run(NEW,OLD/f'checkpoint-game-{game}/checkpoint-{start}.game.gz',dest,end)
 old=complete_ticks((OLD/f'natural-game-{game}/game.replay.checksums').read_bytes())
 mismatch=[t for t,v in new.items() if old.get(t)!=v]
 results.append(dict(game=game,ticks=len(new),mismatches=mismatch));(OUT/'checksum-validation.json').write_text(json.dumps(results,indent=2))
 assert new and not mismatch, mismatch[:5]
 print('Matched',len(new),'ticks',flush=True)
print('Checking saved continuation',flush=True)
a=run(BEFORE,OLD/'natural-game-2/final.game.gz',OUT/'reload-before',57128)
b=run(NEW,OUT/'food-game-2/final.game.gz',OUT/'reload-after',57128)
assert a==b and a
results.append(dict(saved_continuation_ticks=len(a),mismatches=[]));(OUT/'checksum-validation.json').write_text(json.dumps(results,indent=2))
print('Matched',len(a),'saved continuation ticks',flush=True)
bench=[]
for repeat in range(3):
 for label,binary in [('before',BEFORE),('after',NEW)]:
  dest=OUT/f'bench-{repeat}-{label}';ticks=run(binary,OLD/'checkpoint-game-2/checkpoint-50000.game.gz',dest,54512,54480)
  natural=complete_ticks((OLD/'natural-game-2/game.replay.checksums').read_bytes());assert ticks and all(natural[t]==v for t,v in ticks.items())
  rows=[json.loads(s) for s in (dest/'ai-decisions.jsonl').read_text().splitlines()]
  row=next(r for r in rows if r['player']==2 and r['observed_tick']==54480)
  bench.append(dict(repeat=repeat,label=label,decision=row,checksum_ticks=len(ticks)))
  (OUT/'benchmark.json').write_text(json.dumps(bench,indent=2))
  print(label,repeat,'CPU ms',round(row['thread_cpu_ns']/1e6,3),'wall ms',round(row['wall_ns']/1e6,3),'ledger evaluations',row['phases'].get('Ledger::evaluate',{}).get('calls',0),'residual queries',row['phases'].get('Ledger::residualUpperBound',{}).get('calls',0),flush=True)
(OUT/'binaries.json').write_text(json.dumps({k:dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for k,p in [('before',BEFORE),('after',NEW)]},indent=2))
print('All four map continuations, saved continuation and six timing runs passed.',flush=True)
