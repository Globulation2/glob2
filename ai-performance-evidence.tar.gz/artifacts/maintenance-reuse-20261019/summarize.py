import hashlib,json,platform,statistics,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
rows=json.loads((OUT/'benchmark.json').read_text());assert len(rows)==6
summary={}
for label in ('before','after'):
 subset=[r['decision'] for r in rows if r['label']==label]
 assert len(subset)==3
 entry={}
 for field in ('thread_cpu_ns','wall_ns'):
  samples=[r[field]/1e6 for r in subset];entry[field.replace('_ns','_ms')]=dict(samples=samples,median=statistics.median(samples),minimum=min(samples),maximum=max(samples))
 entry['phase_calls']={k:v['calls'] for k,v in subset[0]['phases'].items()}
 entry['work']=subset[0]['work']
 assert all(r['work']==entry['work'] for r in subset)
 summary[label]=entry
summary['cpu_reduction_percent']=100*(1-summary['after']['thread_cpu_ms']['median']/summary['before']['thread_cpu_ms']['median'])
summary['checksum_validation']=json.loads((OUT/'checksum-validation.json').read_text())
summary['base_revision']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
summary['environment']=platform.platform()
summary['tests']=dict(cases=35,assertions=42773,failed=0,cli_contracts=2)
summary['limits']=['Native macOS release diagnostic builds; no cross-platform run was performed.','Three paired repeats of one captured decision; this does not establish a whole-game throughput or p99 improvement.','Baseline reuse lasts one synchronous maintenance scan, keyed by captured world identity and excluded action; it introduces no saved scheduling state.']
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
with (OUT/'final-working-tree.patch').open('wb') as sink:
 subprocess.run(['git','diff','--binary'],cwd=ROOT,stdout=sink,check=True)
 result=subprocess.run(['git','diff','--no-index','--','/dev/null','src/ai/AIProfile.h'],cwd=ROOT,stdout=sink)
 assert result.returncode==1
print(json.dumps({k:summary[k] for k in ['cpu_reduction_percent','before','after']},indent=2))
try:
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(figsize=(7.5,3.8),layout='constrained')
 vals=[summary[k]['thread_cpu_ms']['median'] for k in ('before','after')]
 bars=ax.barh(['Before','Reuse candidates + food baseline'],vals,color=['#8199ae','#318c83']);ax.invert_yaxis()
 ax.bar_label(bars,fmt='%.1f ms',padding=6);ax.set_xlim(0,max(vals)*1.25)
 ax.set_xlabel('Decision thread CPU time (ms), median of 3 paired runs')
 ax.set_title('Maxima: Continents (Europe), map seed 42\nCaptured decision 54,480 → publication tick 54,488',loc='left')
 ax.spines[['top','right']].set_visible(False);fig.savefig(OUT/'cpu-before-after.png',dpi=150)
except ImportError:pass
