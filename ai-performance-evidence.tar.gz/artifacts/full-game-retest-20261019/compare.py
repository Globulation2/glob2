import csv,hashlib,json,math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=Path(__file__).resolve().parent;BASE=OUT.parent/'tick-tails-20261019'
old=json.loads((BASE/'analysis.json').read_text());new=json.loads((OUT/'analysis.json').read_text())
def waits(result):
 return {k:v['joins']['tick_deadline']['background_wait']['total_ns']/1e9 for k,v in result['compute_telemetry']['producers'].items()}
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
comparisons=[];old_wait={};new_wait={};quality=[]
for i,(a,b) in enumerate(zip(old['runs'],new['runs']),1):
 assert a['game']==b['game'] and a['seed']==b['seed'] and a['ticks']==b['ticks']==90000
 ar=json.loads((BASE/a['game']/'result.json').read_text());br=json.loads((OUT/b['game']/'result.json').read_text())
 aw,bw=waits(ar),waits(br)
 for k,v in aw.items():old_wait[k]=old_wait.get(k,0)+v
 for k,v in bw.items():new_wait[k]=new_wait.get(k,0)+v
 c=br['compute_telemetry'];samples=sum(v['samples'] for v in c['deferred_callback_execution'].values())
 assert samples==br['compute_deferred_jobs']
 assert all(sum(v['histogram'])==v['samples'] for v in c['deferred_callback_execution'].values())
 quality.append(dict(game=b['game'],callback_samples=samples,histograms_complete=True,raw_trace_lost_events=c['trace_lost_events']))
 row=dict(game=b['game'],map='Continents (Europe)' if b['generator']=='continents' else 'Honeycomb Isle',seed=b['seed'],before=a,after=b,
  initial_checksum_matches=ar['initialChecksum']==br['initialChecksum'],final_checksum_matches=ar['finalChecksum']==br['finalChecksum'],
  before_final_checksum=ar['finalChecksum'],after_final_checksum=br['finalChecksum'],
  replay_bytes_identical=digest(BASE/a['game']/'game.replay')==digest(OUT/b['game']/'game.replay'),
  before_deadline_wait_seconds=aw,after_deadline_wait_seconds=bw,
  before_total_background_wait_seconds=ar['compute_telemetry']['tick_background_wait']['total_ns']/1e9,
  after_total_background_wait_seconds=c['tick_background_wait']['total_ns']/1e9,
  before_ticks_per_second=a['ticks']/a['seconds'],after_ticks_per_second=b['ticks']/b['seconds'])
 comparisons.append(row)
 assert row['initial_checksum_matches'] and row['final_checksum_matches'], f'Final simulation state differs in {b["game"]}'
def aggregate(data):
 rows=data['runs'];result=dict(ticks=sum(r['ticks'] for r in rows),seconds=sum(r['seconds'] for r in rows),ticks_ge_50ms=sum(r['ticks_ge_50ms'] for r in rows),ticks_ge_100ms=sum(r['ticks_ge_100ms'] for r in rows))
 result['ticks_per_second']=result['ticks']/result['seconds'];result['slow_ticks_100ms_with_majority_ai_wait']=sum(r['elapsed_ms']>=100 and r['waits_ms'].get('ai',0)>r['elapsed_ms']/2 for r in data['slow_ticks_50ms'])
 return result
summary=dict(base_revision=json.loads((OUT/'metadata.json').read_text())['revision'],before=aggregate(old),after=aggregate(new),runs=comparisons,
 deadline_wait_seconds=dict(before=old_wait,after=new_wait),ai_callbacks=dict(before=old['ai_callbacks'],after=new['ai_callbacks']),
 quality=quality,worst_after_ticks=new['slow_ticks_50ms'][:15],notes=[
 'Four sequential full 90k-tick games per version; same generators, map/game seeds, player order, CPU bucket gradients, eight participants and trace telemetry.',
 'AI function profiling is disabled. Normal desktop contention remains; one before/after run per map/seed is descriptive, not an isolated or repeated throughput benchmark.',
 'Tick quantiles come from complete 90000-row timing CSVs. Full-session callback histograms survive bounded raw trace overflow.',
 'Producer wait totals include simulation tick-deadline background waits only, excluding setup, save, verification, teardown and owner execution.',
 'Final simulation checksums are compared for all four games. Per-tick agreement was verified in earlier captured continuation tests.'
 ])
(OUT/'comparison.json').write_text(json.dumps(summary,indent=2))
with (OUT/'comparison.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['map','seed','p99_before_ms','p99_after_ms','p999_before_ms','p999_after_ms','max_before_ms','max_after_ms','ticks_ge_100ms_before','ticks_ge_100ms_after','ai_wait_before_seconds','ai_wait_after_seconds','final_checksum_matches','replay_bytes_identical'])
 for r in comparisons:
  a,b=r['before'],r['after'];w.writerow([r['map'],r['seed'],a['p99_ms'],b['p99_ms'],a['p999_ms'],b['p999_ms'],a['max_ms'],b['max_ms'],a['ticks_ge_100ms'],b['ticks_ge_100ms'],r['before_deadline_wait_seconds']['ai'],r['after_deadline_wait_seconds']['ai'],r['final_checksum_matches'],r['replay_bytes_identical']])
labels=[r['map']+'\nseed '+str(r['seed']) for r in comparisons];x=np.arange(4)
fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
for ax,field,title in [(axes[0],'p999_ms','99.9th-percentile tick duration'),(axes[1],'ticks_ge_100ms','Ticks taking at least 100 ms')]:
 ax.bar(x-.18,[r['before'][field] for r in comparisons],width=.36,label='Before',color='#879bae');ax.bar(x+.18,[r['after'][field] for r in comparisons],width=.36,label='Optimized',color='#25877b')
 ax.set_xticks(x,labels,fontsize=9);ax.set_title(title);ax.set_ylabel('Milliseconds' if field=='p999_ms' else 'Ticks / 90,000');ax.spines[['top','right']].set_visible(False);ax.legend()
fig.suptitle('Full 256×256 / eight-AI games — matched map and game seeds');fig.savefig(OUT/'tick-tails-before-after.png',dpi=150);plt.close(fig)
active=[k for k in old_wait if old_wait[k]+new_wait.get(k,0)>.005];x=np.arange(len(active))
fig,ax=plt.subplots(figsize=(9,4.5),layout='constrained');ax.barh(x-.18,[old_wait[k] for k in active],height=.36,label='Before',color='#879bae');ax.barh(x+.18,[new_wait[k] for k in active],height=.36,label='Optimized',color='#25877b');ax.set_yticks(x,[k.replace('_',' ').title() for k in active]);ax.invert_yaxis();ax.set_xlabel('Simulation deadline background wait (seconds, 360,000 ticks)');ax.set_title('Executor waits by job producer');ax.legend();ax.spines[['top','right']].set_visible(False);fig.savefig(OUT/'pipeline-waits-before-after.png',dpi=150);plt.close(fig)
fig,axes=plt.subplots(2,1,figsize=(10,6),sharex=True,layout='constrained')
for ax,ai in zip(axes,['maxima','cortex']):
 for data,label,color in [(old,'Before','#879bae'),(new,'Optimized','#25877b')]:
  v=data['ai_callbacks'][ai];counts=np.array(v['histogram'][1:]);centres=np.array([2**(i-.5)/1e6 for i in range(1,65)]);fractions=np.where(counts>0,100*counts/v['samples'],np.nan)
  ax.plot(centres,fractions,marker='.',color=color,label=label)
 ax.set_xscale('log');ax.set_yscale('log');ax.set_xlim(.001,2048);ax.set_ylabel('% of callbacks');ax.set_title(ai.title(),loc='left');ax.legend();ax.grid(alpha=.15)
axes[-1].set_xlabel('Elapsed callback duration (ms), powers-of-two bins');fig.suptitle('AI execution tails across the four complete games');fig.savefig(OUT/'ai-tails-before-after.png',dpi=150);plt.close(fig)
print(json.dumps({k:summary[k] for k in ['before','after','deadline_wait_seconds']},indent=2))
for r in comparisons:print(r['map'],r['seed'],'p999',r['before']['p999_ms'],'->',r['after']['p999_ms'],'max',r['before']['max_ms'],'->',r['after']['max_ms'],'100ms ticks',r['before']['ticks_ge_100ms'],'->',r['after']['ticks_ge_100ms'],'replay identical',r['replay_bytes_identical'])
