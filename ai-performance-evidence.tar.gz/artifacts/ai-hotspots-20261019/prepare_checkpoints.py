import subprocess,json,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
BINARY=ROOT/'artifacts/tick-tails-20261019/baseline-glob2'
records=[]
for game,tick in [(2,50000),(1,44000),(4,46000),(3,22000)]:
 dest=OUT/f'checkpoint-game-{game}'
 if (dest/'result.json').exists():continue
 command=[str(BINARY),'game','run','--load-game',str(ROOT/f'artifacts/tick-tails-20261019/game-{game}/initial.game.gz'),'--ticks',str(tick+1),'--save',f'every:{tick}','--gradient-backend','cpu','--gradient-algorithm','buckets','--compute-threads','auto','--compute-telemetry','off','--output-dir',str(dest)]
 print('Preparing',game,'tick',tick,flush=True)
 with (OUT/f'checkpoint-game-{game}.log').open('w') as log: p=subprocess.run(command,cwd=ROOT,stdout=log,stderr=log)
 records.append(dict(game=game,tick=tick,command=command,returncode=p.returncode));(OUT/'checkpoint-commands.json').write_text(json.dumps(records,indent=2))
 if p.returncode:raise SystemExit(p.returncode)
 print('Ready',game,flush=True)
