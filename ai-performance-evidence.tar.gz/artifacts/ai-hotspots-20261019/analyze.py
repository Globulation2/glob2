import collections,csv,hashlib,json,re,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
original='71a3a23ae82ea1a97c3c63f54e1d486c35419542'
records=[]
for p in sorted(OUT.glob('*-game-*/ai-decisions.jsonl')):
    if not p.parent.name.startswith(('natural-','latest-')):continue
    rows=[json.loads(s) for s in p.read_text().splitlines()]
    for ai in sorted({r['ai'] for r in rows}):
        subset=[r for r in rows if r['ai']==ai]
        records.append(dict(run=p.parent.name,base_revision=original if p.parent.name.startswith('natural-') else subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),ai=ai,exported_callbacks=len(subset),max_cpu=max(subset,key=lambda r:r['thread_cpu_ns'] or 0),max_wall=max(subset,key=lambda r:r['wall_ns'])))
exact=json.loads((OUT/'exact-profiles.json').read_text())
for item in exact:
    source=Path(item['sample_command'][-1])
    lines=source.read_text().splitlines()
    start=next(i for i,s in enumerate(lines) if 'Thread_' in s and item['worker_name'] in s)
    end=next((i for i in range(start+1,len(lines)) if re.match(r'^    \d+ Thread_',lines[i]) or lines[i].startswith('Total number')),len(lines))
    (OUT/(source.stem+'-target-worker.txt')).write_text('\n'.join(lines[start:end])+'\n')
analysis=dict(original_base_revision=original,current_base_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),notes=[
    'Only callbacks with elapsed >=10ms exported. This dataset cannot estimate all-callback percentiles or population frequencies.',
    'Natural timings contain instrumentation overhead. Exclusive phase wall times are additive; recursive inclusive phase times overlap.',
    'Exact gated runs identify the callback and match natural per-tick checksums and workload counters. Sampling substantially perturbed Maxima wall time; gated timings are not latency measurements.',
    'Exact stack captures include only 2 Maxima body samples and 9 Cortex body samples. Use function counters/timers for quantitative attribution; no sampled percentage claims.',
    'Latest-master validation was cancelled at user request and the checkout restored to the original tested base. No games ran on the newer master.'
],runs=records,exact_profiles=exact)
(OUT/'analysis.json').write_text(json.dumps(analysis,indent=2))
with (OUT/'slow-callback-summary.csv').open('w') as f:
    writer=csv.writer(f);writer.writerow(['run','base','ai','exported_callbacks_ge_10ms','max_cpu_observed_tick','max_cpu_ms','wall_at_max_cpu_ms','max_wall_observed_tick','max_wall_ms','cpu_at_max_wall_ms'])
    for r in records:
        c,w=r['max_cpu'],r['max_wall']
        writer.writerow([r['run'],r['base_revision'],r['ai'],r['exported_callbacks'],c['observed_tick'],c['thread_cpu_ns']/1e6,c['wall_ns']/1e6,w['observed_tick'],w['wall_ns']/1e6,w['thread_cpu_ns']/1e6])
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    row=exact[0]['target'];phase=row['phases']
    values=[phase['Ledger::evaluate']['self_ns']/1e6,phase['Ledger::walk']['self_ns']/1e6,phase['Planner::prepareFoodLedger']['self_ns']/1e6,phase['Maxima::collect_development_world']['self_ns']/1e6]
    values.append(row['wall_ns']/1e6-sum(values))
    labels=['Food-ledger evaluation\n(excluding walks)','Food reachability walks','Food-ledger preparation\n(excluding nested evaluation)','Collect development world','Other decision work']
    fig,ax=plt.subplots(figsize=(10,4.7),layout='constrained')
    bars=ax.barh(labels,values,color=['#246b9c','#318c83','#c88d32','#8199ae','#aeb9c2'])
    ax.invert_yaxis();ax.set_xlim(0,275);ax.set_xlabel('Exclusive elapsed time (ms), ungated instrumented run')
    ax.bar_label(bars,fmt='%.1f ms',padding=5);ax.spines[['top','right']].set_visible(False)
    ax.set_title('Maxima on Continents (Europe), seed 42\nDecision 54,480 → publication tick 54,488: 569 ms wall / 528 ms thread CPU',loc='left',pad=15)
    fig.savefig(OUT/'maxima-hotspot.png',dpi=150)
except ImportError:pass
print('Wrote analysis for',len(records),'run/AI groups')
