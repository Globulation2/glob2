import json,subprocess,hashlib,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
BINARY=ROOT/'build/darwin/client/release/dev-linker-auto/src/glob2'
cases=[(2,50000,57000),(1,44000,48000),(4,46000,50000),(3,22000,26000)]
records=[]
for game,start,end in cases:
 checkpoint=OUT/f'checkpoint-game-{game}/checkpoint-{start}.game.gz'
 if not checkpoint.exists():raise SystemExit(f'Missing checkpoint {checkpoint}')
 dest=OUT/f'natural-game-{game}'
 if (dest/'result.json').exists():continue
 cmd=[str(BINARY),'game','run','--load-game',str(checkpoint),'--ticks',str(end),'--gradient-backend','cpu','--gradient-algorithm','buckets','--compute-threads','auto','--compute-telemetry','waits','--benchmark-warmup','0','--benchmark-tick-profile','--ai-decision-profile','--ai-profile-min-ms','10','--ai-profile-from-tick',str(start+512),'--telemetry','checksums','--save','final','--output-dir',str(dest)]
 print('Profiling natural game',game,'ticks',start,end,flush=True)
 with (OUT/f'natural-game-{game}.log').open('w') as log: result=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=log)
 records.append(dict(game=game,command=cmd,returncode=result.returncode));(OUT/'natural-commands.json').write_text(json.dumps(records,indent=2))
 if result.returncode:raise SystemExit(result.returncode)
 print('Completed',game,flush=True)
