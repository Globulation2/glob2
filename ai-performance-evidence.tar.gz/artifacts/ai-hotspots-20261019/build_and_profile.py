import os,sys,subprocess,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
env=dict(os.environ,PYTHONPATH=str(ROOT))
with (OUT/'build-final.log').open('w') as log:
 result=subprocess.run([sys.executable,'tools/dev_build.py','dev_fast=0','release=1'],cwd=ROOT,env=env,stdout=log,stderr=log)
if result.returncode:raise SystemExit('Diagnostic release build failed; see build-final.log')
code="""import sys,unittest
from pathlib import Path
sys.path.insert(0,'test')
import test_cli_smoke as cli
cli.BINARY=str(Path('build/darwin/client/release/dev-linker-auto/src/glob2').resolve())
cli.ARTIFACTS=Path('artifacts/ai-hotspots-20261019/cli-contracts').resolve()
suite=unittest.TestSuite(cli.CliSmoke(name) for name in ['test_ai_decision_profile_gate_preserves_execution','test_benchmark_tick_profile_preserves_execution_and_tick_identity'])
raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
"""
with (OUT/'cli-contracts.log').open('w') as log:
 result=subprocess.run([sys.executable,'-c',code],cwd=ROOT,stdout=log,stderr=log)
if result.returncode:raise SystemExit('AI profiling integration contract failed; see cli-contracts.log')
print('Fresh release build and both checksum/profile contracts passed.',flush=True)
for game,start in [(2,50000),(1,44000),(4,46000),(3,22000)]:
 path=OUT/f'checkpoint-game-{game}/checkpoint-{start}.game.gz'
 deadline=time.monotonic()+240
 while not path.exists():
  if time.monotonic()>deadline:raise SystemExit('Checkpoint did not become ready: '+str(path))
  time.sleep(1)
for script in ['profile_windows.py','profile_exact.py']:
 result=subprocess.call([sys.executable,str(OUT/script)],cwd=ROOT)
 if result:raise SystemExit(result)
