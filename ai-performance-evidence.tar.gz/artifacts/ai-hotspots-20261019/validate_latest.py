import hashlib,json,subprocess,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
BINARY=ROOT/'build/darwin/client/release/dev-linker-auto/src/glob2'
records=[]
for game,start,end in [(2,50000,57000),(1,44000,48000)]:
    dest=OUT/f'latest-game-{game}'
    cmd=[str(BINARY),'game','run','--load-game',str(OUT/f'checkpoint-game-{game}/checkpoint-{start}.game.gz'),'--ticks',str(end),'--gradient-backend','cpu','--gradient-algorithm','buckets','--compute-threads','auto','--compute-telemetry','waits','--benchmark-warmup','0','--benchmark-tick-profile','--ai-decision-profile','--ai-profile-min-ms','10','--ai-profile-from-tick',str(start+512),'--telemetry','checksums','--output-dir',str(dest)]
    print('Latest master continuation',game,flush=True)
    with (OUT/f'latest-game-{game}.log').open('w') as log:
        p=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=log)
    records.append(dict(game=game,command=cmd,returncode=p.returncode))
    (OUT/'latest-commands.json').write_text(json.dumps(records,indent=2))
    if p.returncode:raise SystemExit(p.returncode)
    rows=[json.loads(s) for s in (dest/'ai-decisions.jsonl').read_text().splitlines()]
    for ai in sorted({r['ai'] for r in rows}):
        r=max((r for r in rows if r['ai']==ai),key=lambda r:r['thread_cpu_ns'])
        print(ai,'tick',r['observed_tick'],'wall ms',r['wall_ns']/1e6,'CPU ms',r['thread_cpu_ns']/1e6,flush=True)
print('Latest master continuations completed.',flush=True)
