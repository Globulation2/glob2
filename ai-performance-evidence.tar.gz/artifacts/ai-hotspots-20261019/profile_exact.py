import json,subprocess,time,sys,hashlib
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
records=[]
# Select actual high-CPU callbacks in each diagnostic continuation, rather than
# assuming that the largest elapsed outlier was computational work.
choices=[]
for game,base in [(2,50000),(1,44000),(4,46000),(3,22000)]:
 rows=[json.loads(s) for s in (OUT/f'natural-game-{game}/ai-decisions.jsonl').read_text().splitlines()]
 for ai in (['maxima'] if game==2 else ['cortex'] if game in (1,4) else ['castor']):
  eligible=[r for r in rows if r['ai']==ai and r['thread_cpu_ns'] is not None and r['thread_cpu_ns']>=10000000]
  if eligible: choices.append((game,base,max(eligible,key=lambda r:r['thread_cpu_ns'])))
# Keep one sample per AI, preferring the case with the largest CPU cost.
by_ai={}
for choice in choices:
 if choice[2]['ai'] not in by_ai or choice[2]['thread_cpu_ns']>by_ai[choice[2]['ai']][2]['thread_cpu_ns']: by_ai[choice[2]['ai']]=choice
for game,base,target in by_ai.values():
 dest=OUT/f"exact-game-{game}-{target['ai']}-{target['observed_tick']}"
 if (dest/'result.json').exists():continue
 tick=target['observed_tick'];player=target['player']
 command=[str(ROOT/'build/darwin/client/release/dev-linker-auto/src/glob2'),'game','run','--load-game',str(OUT/f'checkpoint-game-{game}/checkpoint-{base}.game.gz'),'--ticks',str(tick+32),'--gradient-backend','cpu','--gradient-algorithm','buckets','--compute-threads','auto','--compute-telemetry','off','--benchmark-warmup','0','--ai-decision-profile','--ai-profile-min-ms','60000','--ai-profile-from-tick',str(tick),'--ai-profile-gate',f'{player}:{tick}','--telemetry','checksums','--output-dir',str(dest)]
 record=dict(game=game,target=target,command=command)
 print('Targeting',game,target['ai'],'player',player,'observed tick',tick,'natural CPU ms',target['thread_cpu_ns']/1e6,flush=True)
 with (OUT/(dest.name+'.log')).open('w') as log:
  proc=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=log)
  try:
   ready=dest/'ai-profile-ready.json';deadline=time.monotonic()+180
   while not ready.exists() and proc.poll() is None:
    if time.monotonic()>deadline:raise TimeoutError('No gate marker')
    time.sleep(.02)
   if proc.poll() is not None:raise RuntimeError('Game exited before gate')
   stack=OUT/(dest.name+'-stacks.txt')
   samplecmd=['/usr/bin/sample',str(proc.pid),'3','1','-fullPaths','-file',str(stack)]
   sampler=subprocess.Popen(samplecmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
   first=sampler.stderr.readline()
   time.sleep(.5)
   (dest/'ai-profile-release').write_text('begin profiled callback\n')
   stdout,stderr=sampler.communicate(timeout=90)
   record.update(sample_command=samplecmd,sample_returncode=sampler.returncode,sample_stderr=first+stderr)
   deadline=time.monotonic()+60
   while not (dest/'ai-profile-done.json').exists() and proc.poll() is None:
    if time.monotonic()>deadline:raise TimeoutError('No callback completion marker')
    time.sleep(.01)
   (dest/'ai-profile-finish').write_text('stack sampling complete\n')
   record['returncode']=proc.wait(timeout=120)
   body=[json.loads(s) for s in (dest/'ai-decisions.jsonl').read_text().splitlines()]
   assert len(body)==1 and body[0]['player']==player and body[0]['observed_tick']==tick
   record['workload_matches_natural']=body[0]['work']==target['work']
   record['function_counts_match_natural']={k:v['calls'] for k,v in body[0]['phases'].items()}=={k:v['calls'] for k,v in target['phases'].items()}
   sys.path.insert(0,str(ROOT/'test'))
   from check_javascript import complete_ticks
   natural=complete_ticks((OUT/f'natural-game-{game}/game.replay.checksums').read_bytes())
   gated=complete_ticks((dest/'game.replay.checksums').read_bytes())
   assert gated and all(natural[t]==value for t,value in gated.items()), 'Gated tick checksums differ'
   record['tick_checksums_match_natural_run']=True
   record['profiled_decision']=body[0]
   graph=stack.read_text();assert 'Call graph:\n    ' in graph
   record['worker_name']='aip'+str(player)+'t'+str(tick)
   assert record['worker_name'] in graph, 'Named target worker missing from profile'
   records.append(record);(OUT/'exact-profiles.json').write_text(json.dumps(records,indent=2))
   print('Profiled',game,target['ai'],'CPU ms',body[0]['thread_cpu_ns']/1e6,'wall ms',body[0]['wall_ns']/1e6,flush=True)
  finally:
   if proc.poll() is None:
    (dest/'ai-profile-release').touch();(dest/'ai-profile-finish').touch();proc.terminate();proc.wait()
