const {test}=require('../browser-recovery-70319/browser/node_modules/@playwright/test');
const fs=require('node:fs');
const path=require('node:path');
const safe=async(promise)=>{let t;try{return await Promise.race([promise,new Promise(r=>{t=setTimeout(()=>r({timeout:true}),2500);})]);}catch(e){return{error:String(e)};}finally{clearTimeout(t);}};
test.beforeEach(async({context},info)=>{
  const rows=[];let next=0;const ids=new Map(),busy=new Set();
  const capture=async(page,event)=>{
    if(busy.has(page)||page.isClosed())return;busy.add(page);
    if(!ids.has(page))ids.set(page,++next);
    try{rows.push({at:Date.now(),page:ids.get(page),event,state:await safe(page.evaluate(()=>{
      const m=globalThis.Module,s=globalThis.glob2Diagnostics?.snapshot(),p=m?.storage;
      return{url:location.href,hidden:document.hidden,focused:document.hasFocus(),visibility:document.visibilityState,
        screen:s?.screen,screenClass:s?.screenClass,loop:s?.loop,execution:s?.executionMode,import:s?.import,persistence:s?.persistence,persisting:s?.persisting,
        applicationThread:m?.glob2ApplicationThreadIdentity,renderer:m?.renderer,
        controls:s?Object.fromEntries(Object.entries(s.controls).filter(([k])=>['retry','exit','back','intro/menu','intro/continue','intro/start','graphics.renderer'].includes(k))):null,
        storage:p?{state:p.state,generation:p.generation,committed:p.committed,active:p.active,scheduled:p.scheduled,waiters:p.waiters?.length,error:p.error?String(p.error):null}:null};
    }))});}finally{busy.delete(page);}
  };
  const added=page=>{if(!ids.has(page))ids.set(page,++next);page.on('close',()=>{rows.push({at:Date.now(),page:ids.get(page),event:'closed'});for(const p of context.pages())void capture(p,'sibling-closed');});};
  context.pages().forEach(added);context.on('page',added);
  const interval=setInterval(()=>{for(const page of context.pages())void capture(page,'sample');},1000);
  info._recovery={rows,interval,capture};
});
test.afterEach(async({context},info)=>{
  const rec=info._recovery;clearInterval(rec.interval);
  for(const page of context.pages())await rec.capture(page,'test-end');
  const workers=[];
  if(info.status!==info.expectedStatus)for(const page of context.pages())for(const worker of page.workers())workers.push({url:worker.url(),state:await safe(worker.evaluate(()=>({
    pthread:typeof ENVIRONMENT_IS_PTHREAD==='undefined'?null:ENVIRONMENT_IS_PTHREAD,
    self:typeof _pthread_self==='function'?_pthread_self():null,
    moduleThread:globalThis.Module?.glob2ApplicationThreadIdentity,
    webgpu:typeof Glob2WebGPU==='undefined'?null:{type:typeof Glob2WebGPU,state:Glob2WebGPU.state,error:Glob2WebGPU.error,lost:Glob2WebGPU.lost}
  })))});
  const out=process.env.RECOVERY_OBSERVATION;fs.writeFileSync(out,JSON.stringify({title:info.title,status:info.status,expectedStatus:info.expectedStatus,rows:rec.rows,workers},null,2)+'\n');
});
