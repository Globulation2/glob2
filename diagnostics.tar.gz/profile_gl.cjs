const {test}=require('../browser-recovery-70319/browser/node_modules/@playwright/test');
test.beforeEach(async({page})=>{
  await page.addInitScript(()=>{
    if(typeof WebGL2RenderingContext==='undefined')return;
    const counters=globalThis.recoveryGLCosts={};let last=0;
    for(const name of ['getError','getFramebufferAttachmentParameter','getParameter','isEnabled','disable','enable','readPixels','drawElements','drawArrays','finish','flush','bufferData','texImage2D','texSubImage2D','linkProgram','compileShader']){
      const original=WebGL2RenderingContext.prototype[name];if(typeof original!=='function')continue;
      const item=counters[name]={calls:0,total:0,max:0};
      WebGL2RenderingContext.prototype[name]=function(...args){
        const start=performance.now();try{return original.apply(this,args);}finally{
          const dt=performance.now()-start;item.calls++;item.total+=dt;item.max=Math.max(item.max,dt);
          if(performance.now()-last>5000){last=performance.now();console.log('RECOVERY_GL_COST '+JSON.stringify(counters));}
        }
      };
    }
  });
});
