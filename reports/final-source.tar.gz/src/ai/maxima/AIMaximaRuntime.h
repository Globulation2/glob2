/*
  Maxima private runtime.

  Maxima owns its decision state and gradient scheduling per AI instance.
  Its read adapter shares immutable engine observations with the other controllers.
 */

#ifndef AI_MAXIMA_RUNTIME_H
#define AI_MAXIMA_RUNTIME_H

#include "field/Frontier.h"
#include "field/TerrainTravel.h"
#include "AIImplementation.h"
#include "Map.h"
#include "Order.h"
#include "ai/observation/OrderSelection.h"
#include "Player.h"
#include "TeamStat.h"
#include "Ressource.h"
#include "MaximaObservationBinding.h"
#include "ai/engine/AIDecision.h"

#include <memory>
#include <functional>
#include <limits>
#include <list>
#include <locale>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <type_traits>
#include <vector>

class Building;
struct BuildingType;

namespace AIMaximaRuntime
{

/// A value as telemetry text, formatted exactly as boost::lexical_cast<std::string>
/// did before it was replaced: stream output in the classic locale, with enough
/// significant digits for floating-point values to round-trip.
template<typename T>
std::string telemetryText(const T& value)
{
	std::ostringstream text;
	text.imbue(std::locale::classic());
	if constexpr (std::is_floating_point<T>::value)
		text.precision(std::numeric_limits<T>::max_digits10);
	text << value;
	return text.str();
}

/// Most units a building accepts. The engine keeps its own copy of this limit
/// (MAX_UNIT_WORKING in GameGUI.h, a macro, hence the distinct name).
constexpr int MAXIMA_MAX_UNIT_WORKING=20;

/// True when GLOB2_MAXIMA_TELEMETRY is set to anything but "0": Maxima then
/// writes its per-decision MAXIMA_TELEMETRY lines to stdout.
/// See StrategyResolver::telemetryEnabled.
bool telemetry_enabled();

struct position
{
	position() : x(0), y(0) {}
	position(int x, int y) : x(x), y(y) {}
	int x;
	int y;
};

struct PlacementResult
{
	PlacementResult() : found(false), value() {}
	explicit PlacementResult(const position& value) : found(true), value(value) {}
	bool found;
	position value;
};

class Context;

enum OptionalBool
{
	KeepValue=-1,
	ClearValue=0,
	SetValue=1
};

enum ConstructionFilter
{
	AnyConstruction=-1,
	CompletedBuildings=0,
	ConstructionSites=1
};

struct RuntimeEvent
{
	enum Type
	{
		BuildingResolved,
		UpdateClearing,
		UpdateSwarm,
		UpdateInn,
		BuildingUpdated,
		AttackFinished,
		GuardFlagDeleted,
		ExplorerAttackFlagDeleted,
		DigOutFinished,
		StarvationInnFinished,
		ReconFlagDeleted,
		// Version 89 placement-planner events.  Append only: saved Notify
		// management orders serialize these numeric values.
		DevelopmentParcelReserved,
		DevelopmentCreateIssued,
		DevelopmentSiteObserved,
		DevelopmentCompleted,
		DevelopmentInvalidatedBeforeIssue,
		DevelopmentCreateTimedOut,
		DevelopmentDestroyedDuringConstruction,
		DevelopmentUpgradeBlocked,
		DevelopmentRequiredSourceMissing,
		DevelopmentEngineRejected
	};

	RuntimeEvent(Type type, int first=-1, int second=-1)
		: type(type), first(first), second(second) {}
	Type type;
	int first;
	int second;
};

class RuntimeAI
{
public:
	virtual ~RuntimeAI() {}
	virtual void tick(Context& context)=0;
	virtual void handle_event(Context& context, const RuntimeEvent& event)=0;
};

namespace Gradients
{
enum DistanceState
{
	UnreachableCell=0,
	ObstacleCell=1,
	SourceCell=2
};
namespace Entities
{
	enum EntityType { EBuilding, EAnyTeamBuilding, EAnyResource, EMaterialSource,
		EWater, EPosition, ESand, EUnwalkable, EResourceGroundObstacle };

	class Entity
	{
	public:
		virtual ~Entity() {}
		virtual bool matches(const AIEngine::AIWorldView& world, unsigned observerTeam, int x, int y) const=0;
		virtual bool equals(const Entity& other) const=0;
		virtual bool can_change() const=0;
		virtual EntityType type() const=0;
		virtual void save(GAGCore::OutputStream*) const=0;
		static Entity* load(GAGCore::InputStream*);
	};

	class Building : public Entity
	{
	public:
		Building(int buildingType, int team, bool includeConstruction);
		bool matches(const AIEngine::AIWorldView&, unsigned observerTeam, int, int) const;
		bool equals(const Entity&) const;
		bool can_change() const { return true; }
		EntityType type() const { return EBuilding; }
		void save(GAGCore::OutputStream*) const;
	private:
		int buildingType;
		int team;
		bool includeConstruction;
	};

	class AnyTeamBuilding : public Entity
	{
	public:
		AnyTeamBuilding(int team, bool includeConstruction);
		bool matches(const AIEngine::AIWorldView&, unsigned observerTeam, int, int) const;
		bool equals(const Entity&) const;
		bool can_change() const { return true; }
		EntityType type() const { return EAnyTeamBuilding; }
		void save(GAGCore::OutputStream*) const;
	private:
		int team;
		bool includeConstruction;
	};

	class MaterialSource : public Entity
	{
	public:
		explicit MaterialSource(int material);
		bool matches(const AIEngine::AIWorldView&, unsigned observerTeam, int, int) const;
		bool equals(const Entity&) const;
		bool can_change() const;
		EntityType type() const { return EMaterialSource; }
		void save(GAGCore::OutputStream*) const;
	private:
		int material;
	};

	class AnyResource : public Entity
	{
	public:
		bool matches(const AIEngine::AIWorldView&, unsigned observerTeam, int, int) const;
		bool equals(const Entity&) const;
		bool can_change() const { return true; }
		EntityType type() const { return EAnyResource; }
		void save(GAGCore::OutputStream*) const;
	};

    class ResourceGroundObstacle : public Entity
    {
    public:
        bool matches(const AIEngine::AIWorldView&, unsigned observerTeam, int, int) const;
        bool equals(const Entity&) const;
        bool can_change() const { return true; }
        EntityType type() const { return EResourceGroundObstacle; }
        void save(GAGCore::OutputStream*) const;
    };

	class Water : public Entity
	{
	public:
		bool matches(const AIEngine::AIWorldView&, unsigned observerTeam, int, int) const;
		bool equals(const Entity&) const;
		bool can_change() const { return false; }
		EntityType type() const { return EWater; }
		void save(GAGCore::OutputStream*) const;
	};

	class Unwalkable : public Water
	{
	public:
		bool matches(const AIEngine::AIWorldView&, unsigned observerTeam,int,int) const override;
		bool equals(const Entity&) const override;
		EntityType type() const override { return EUnwalkable; }
		void save(GAGCore::OutputStream*) const override;
	};

	class Position : public Entity
	{
	public:
		Position(int x, int y);
		bool matches(const AIEngine::AIWorldView&, unsigned observerTeam, int, int) const;
		bool equals(const Entity&) const;
		bool can_change() const { return false; }
		EntityType type() const { return EPosition; }
		void save(GAGCore::OutputStream*) const;
	private:
		int x;
		int y;
	};

	class Sand : public Entity
	{
	public:
		bool matches(const AIEngine::AIWorldView&, unsigned observerTeam, int, int) const;
		bool equals(const Entity&) const;
		bool can_change() const { return false; }
		EntityType type() const { return ESand; }
		void save(GAGCore::OutputStream*) const;
	};
}

class GradientInfo
{
public:
    field::TerrainTravel terrainTravel=field::TerrainTravel::Geometric;
	void add_source(Entities::Entity* source);
	void add_obstacle(Entities::Entity* obstacle);
	bool matches_source(const AIEngine::AIWorldView&, unsigned observerTeam, int, int) const;
	bool matches_obstacle(const AIEngine::AIWorldView&, unsigned observerTeam, int, int) const;
	bool needs_updating() const;
	bool operator==(const GradientInfo&) const;
	void save(GAGCore::OutputStream*) const;
	bool load(GAGCore::InputStream*,Sint32 versionMinor);
private:
    friend class GradientManager;
    friend class Gradient;
	std::vector<std::shared_ptr<Entities::Entity> > sources;
	std::vector<std::shared_ptr<Entities::Entity> > obstacles;
};

class Gradient
{
public:
	explicit Gradient(const GradientInfo& info);
	int get_height(int x, int y) const;
	bool has_sources() const { return sourceCount!=0; }
private:
	friend class GradientManager;
	void recalculate(const AIEngine::AIWorldView& world, unsigned observerTeam, field::Frontier& frontier);
	GradientInfo info;
    std::uint64_t terrainGeneration=0;
	int width;
	int sourceCount;
	std::vector<Sint16> values;
};

class GradientManager
{
public:
	explicit GradientManager(Player* player);
    Uint64 retainedVectorBytes() const noexcept;
    void bind(const AIEngine::AIWorldView& world,unsigned player,unsigned team) {binding.borrow(world,player,team);lastTerrainRevision=world.terrainRevision;}
    void unbind() {binding.clear();}
	Gradient& get_gradient(const GradientInfo& info);
	void queue_gradient(const GradientInfo& info);
	bool is_updated(const GradientInfo& info) const;
	void update(Uint32 worldStep);
	void invalidate();
	void saveExecutionState(GAGCore::OutputStream*) const;
	void loadExecutionState(GAGCore::InputStream*, Sint32 versionMinor);
private:
	int find(const GradientInfo& info) const;
	ObservationBinding binding;
    const AIEngine::AIWorldView& observation() const {return binding.get();}
    unsigned teamNumber() const {return binding.teamNumber();}
    unsigned playerNumber() const {return binding.playerNumber();}
    const AIEngine::TeamView& observedTeam() const {return observation().teams[teamNumber()];}
    Uint64 lastTerrainRevision=0;
	std::vector<std::shared_ptr<Gradient> > gradients;
	std::vector<int> ages;
	field::Frontier frontier; // transient, shared by this manager's fields
	std::queue<int> queued;
	std::set<int> queuedIndexes;
	Uint32 lastWorldStep;
};
}

namespace Conditions
{
	enum Result { Impossible=-1, Waiting=0, Ready=1 };
	class Condition
	{
	public:
		virtual ~Condition() {}
		virtual Result passes(Context&) const=0;
		virtual int type() const=0;
		virtual void save(GAGCore::OutputStream*) const=0;
		static Condition* load(GAGCore::InputStream*);
	};
	class BuildingCondition
	{
	public:
		virtual ~BuildingCondition() {}
		virtual bool passes(Context&, int id) const=0;
		virtual int type() const=0;
		virtual void save(GAGCore::OutputStream*) const=0;
		static BuildingCondition* load(GAGCore::InputStream*);
	};
	class ParticularBuilding : public Condition
	{
	public:
		ParticularBuilding(BuildingCondition*, int id);
		Result passes(Context&) const;
		int type() const { return 0; }
		void save(GAGCore::OutputStream*) const;
	private:
		std::shared_ptr<BuildingCondition> condition;
		int id;
	};
	class BuildingDestroyed : public Condition
	{
	public:
		explicit BuildingDestroyed(int id) : id(id) {}
		Result passes(Context&) const;
		int type() const { return 1; }
		void save(GAGCore::OutputStream*) const;
	private: int id;
	};
    class AttractionRetiredOrDestroyed : public Condition
    {
    public:
        AttractionRetiredOrDestroyed(int id,unsigned unitMask):id(id),unitMask(unitMask) {}
        Result passes(Context&) const override;
        int type() const override {return 4;}
        void save(GAGCore::OutputStream*) const override;
    private:
        int id;unsigned unitMask;
    };

	class EnemyBuildingDestroyed : public Condition
	{
	public:
		EnemyBuildingDestroyed(Context&, int gid) : gid(gid) {}
		explicit EnemyBuildingDestroyed(int gid) : gid(gid) {}
		Result passes(Context&) const;
		int type() const { return 2; }
		void save(GAGCore::OutputStream*) const;
	private: int gid;
	};
	class EitherCondition : public Condition
	{
	public:
		EitherCondition(Condition*, Condition*);
		Result passes(Context&) const;
		int type() const { return 3; }
		void save(GAGCore::OutputStream*) const;
	private:
		std::shared_ptr<Condition> first;
		std::shared_ptr<Condition> second;
	};
	class NotUnderConstruction : public BuildingCondition
	{ public: bool passes(Context&, int) const; int type() const{return 0;} void save(GAGCore::OutputStream*) const; };
	class UnderConstruction : public BuildingCondition
	{ public: bool passes(Context&, int) const; int type() const{return 1;} void save(GAGCore::OutputStream*) const; };
	class BeingUpgraded : public BuildingCondition
	{ public: bool passes(Context&, int) const; int type() const{return 2;} void save(GAGCore::OutputStream*) const; };
	class BeingUpgradedTo : public BuildingCondition
	{ public: explicit BeingUpgradedTo(int level) : level(level) {} bool passes(Context&, int) const; int type() const{return 3;} void save(GAGCore::OutputStream*) const; private: int level; };
	class SpecificBuildingType : public BuildingCondition
	{ public: explicit SpecificBuildingType(int type) : buildingType(type) {} bool passes(Context&, int) const; int type() const{return 4;} void save(GAGCore::OutputStream*) const; private: int buildingType; };
	class BuildingLevel : public BuildingCondition
	{ public: explicit BuildingLevel(int level) : level(level) {} bool passes(Context&, int) const; int type() const{return 5;} void save(GAGCore::OutputStream*) const; private: int level; };
	class Upgradable : public BuildingCondition
	{ public: bool passes(Context&, int) const; int type() const{return 6;} void save(GAGCore::OutputStream*) const; };
	///A live construction site that can actually accept a worker request. While
	///a building is evacuating into its site it is under construction but not
	///ALIVE, and the engine silently drops worker orders in that window.
	class StaffableConstructionSite : public BuildingCondition
	{ public: bool passes(Context&, int) const; int type() const{return 7;} void save(GAGCore::OutputStream*) const; };
}

namespace Construction
{
	struct BuildingRecord
	{
		BuildingRecord();
		int x, y, type, gid, age;
		Uint64 runtimeIdentity; // Engine scriptIdentity; rebound on load, not saved.
		bool issued, upgrading, upgradeSeen, awaitingUpgradeExecution;
	};

	class BuildingRegister
	{
	public:
		explicit BuildingRegister(Player* player);
    void bind(const AIEngine::AIWorldView& world,unsigned player,unsigned team) {binding.borrow(world,player,team);}
    void unbind() {binding.clear();}
		void initiate();
		unsigned register_building();
		void issue_order(int id, int x, int y, int type);
		void remove_building(int id);
		void set_upgrading(int id, bool awaitingExecution=false);
		void order_execution_completed(int gid, bool accepted, std::optional<Uint32> generation={});
		void tick();
		bool is_building_pending(unsigned id) const;
		bool is_building_found(unsigned id) const;
		bool is_building_upgrading(unsigned id) const;
		int get_type(unsigned id) const;
		bool has_role(unsigned id,int role) const;
		int get_level(unsigned id) const;
		int get_assigned(unsigned id) const;
		int get_enrolled(unsigned id) const;
		int get_on_site(unsigned id) const;
		const AIEngine::BuildingView* get_building(unsigned id) const;
		const ::BuildingType* get_building_type(unsigned id) const;
		const std::map<int, BuildingRecord>& found() const { return foundBuildings; }
		const std::map<int, BuildingRecord>& pending() const { return pendingBuildings; }
		void save(GAGCore::OutputStream*) const;
		bool load(GAGCore::InputStream*,Sint32 versionMinor);
    private:
        friend class ::AIMaximaRuntime::Context;
        // Stable incarnation from the simulation, also captured by AIWorldView.
        Uint64 identity_of(const AIEngine::BuildingView* building) const;
		ObservationBinding binding;
    const AIEngine::AIWorldView& observation() const {return binding.get();}
    unsigned teamNumber() const {return binding.teamNumber();}
    unsigned playerNumber() const {return binding.playerNumber();}
    const AIEngine::TeamView& observedTeam() const {return observation().teams[teamNumber()];}
		std::map<int, BuildingRecord> pendingBuildings;
		std::map<int, BuildingRecord> foundBuildings;
		unsigned nextId;
	};

	class Constraint
	{
	public:
		virtual ~Constraint() {}
		virtual int score(Context&, int, int)=0;
		virtual bool passes(Context&, int, int)=0;
		///Return the only possible anchor for constraints that describe an exact
		///point.  BuildingOrder uses this to avoid scanning the entire map for a
		///SinglePosition or CenterOfBuilding order; the normal passes/score path
		///still validates every constraint at that anchor.
		virtual bool exact_position(Context&, int&, int&) { return false; }
		virtual Gradients::GradientInfo* gradient_info() { return NULL; }
		virtual int type() const=0;
		virtual void save(GAGCore::OutputStream*) const=0;
		static Constraint* load(GAGCore::InputStream*,Sint32 versionMinor);
	};
	class MinimumDistance : public Constraint
	{
	public: MinimumDistance(const Gradients::GradientInfo&, int); int score(Context&,int,int); bool passes(Context&,int,int); Gradients::GradientInfo* gradient_info() { return &info; } int type()const{return 0;} void save(GAGCore::OutputStream*)const;
	private: Gradients::GradientInfo info; int distance; Gradients::Gradient* cached;
	};
	class MaximumDistance : public Constraint
	{
	public: MaximumDistance(const Gradients::GradientInfo&, int); int score(Context&,int,int); bool passes(Context&,int,int); Gradients::GradientInfo* gradient_info() { return &info; } int type()const{return 1;} void save(GAGCore::OutputStream*)const;
	private: Gradients::GradientInfo info; int distance; Gradients::Gradient* cached;
	};
	class MinimizedDistance : public Constraint
	{
	public: MinimizedDistance(const Gradients::GradientInfo&, int); int score(Context&,int,int); bool passes(Context&,int,int); Gradients::GradientInfo* gradient_info() { return &info; } int type()const{return 2;} void save(GAGCore::OutputStream*)const;
	private: Gradients::GradientInfo info; int weight; Gradients::Gradient* cached;
	};
	class MaximizedDistance : public Constraint
	{
	public: MaximizedDistance(const Gradients::GradientInfo&, int); int score(Context&,int,int); bool passes(Context&,int,int); Gradients::GradientInfo* gradient_info() { return &info; } int type()const{return 3;} void save(GAGCore::OutputStream*)const;
	private: Gradients::GradientInfo info; int weight; Gradients::Gradient* cached;
	};
	class CenterOfBuilding : public Constraint
	{
	public: explicit CenterOfBuilding(int gid) : gid(gid) {} int score(Context&,int,int); bool passes(Context&,int,int); bool exact_position(Context&,int&,int&); int type()const{return 4;} void save(GAGCore::OutputStream*)const;
	private: int gid;
	};
	class SinglePosition : public Constraint
	{
	public: SinglePosition(int x, int y) : x(x), y(y) {} int score(Context&,int,int); bool passes(Context&,int,int); bool exact_position(Context&,int&,int&); int type()const{return 5;} void save(GAGCore::OutputStream*)const;
	private: int x,y;
	};

	class BuildingOrder
	{
	public:
		BuildingOrder(int type, int workers);
		void add_constraint(Constraint*);
		void add_condition(Conditions::Condition*);
		void save(GAGCore::OutputStream*) const;
		static BuildingOrder* load(GAGCore::InputStream*,Sint32 versionMinor);
	private:
		friend class ::AIMaximaRuntime::Context;
		PlacementResult find_location(Context&, int cellBudget, bool& complete);
		bool score_location(Context&, const ::BuildingType*, bool flag, int x, int y,
			int& score);
		void reset_search();
		Conditions::Result conditions_pass(Context&) const;
		void queue_gradients(Gradients::GradientManager&);
		int type, workers, id;
		int concreteType; // Chosen once; saved across incremental placement searches.
		// Full-map searches resume in x-major order using saved execution state.
		int searchCursor, searchWidth, searchHeight, searchBestScore;
		position searchBest;
		bool searchActive;
		std::vector<std::shared_ptr<Constraint> > constraints;
		std::vector<std::shared_ptr<Conditions::Condition> > conditions;
	};
}

namespace Management
{
	class MaterialTracker
	{
	public:
		static constexpr int RecurringInputStock = MaterialCount;
		MaterialTracker(Context&, int id, int length, int material);
		int get_total_level() const;
		int get_age() const { return timer; }
		void tick();
		void save(GAGCore::OutputStream*) const;
		static MaterialTracker* load(Context&, GAGCore::InputStream*);
	private:
		Context& context;
		std::vector<int> record;
		unsigned position;
		int timer, buildingId, material;
	};

	class ManagementOrder
	{
	public:
		virtual ~ManagementOrder() {}
		void add_condition(Conditions::Condition*);
		Conditions::Result ready(Context&) const;
		virtual Conditions::Result wait(Context&) const=0;
		virtual void modify(Context&)=0;
		virtual int type() const=0;
		virtual void save_payload(GAGCore::OutputStream*) const=0;
		void save(GAGCore::OutputStream*) const;
		static ManagementOrder* load(GAGCore::InputStream*,Sint32 versionMinor);
	private:
		std::vector<std::shared_ptr<Conditions::Condition> > conditions;
	};
	class AssignWorkers : public ManagementOrder
	{ public: AssignWorkers(int workers,int id); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 0;} void save_payload(GAGCore::OutputStream*)const; private:int workers,id; };
	class ChangeSwarm : public ManagementOrder
	{ public: ChangeSwarm(int worker,int explorer,int warrior,int id); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 1;} void save_payload(GAGCore::OutputStream*)const; private:int worker,explorer,warrior,id; };
	class DestroyBuilding : public ManagementOrder
	{ public: explicit DestroyBuilding(int id); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 2;} void save_payload(GAGCore::OutputStream*)const; private:int id; };
	// Tactical cleanup must not demolish a building providing another service.
	class RetireAttraction : public ManagementOrder
	{ public: RetireAttraction(int id,unsigned unitMask) : id(id),unitMask(unitMask) {} Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 13;} void save_payload(GAGCore::OutputStream*)const; private:int id; unsigned unitMask; };
	class AddMaterialTracker : public ManagementOrder
	{ public: AddMaterialTracker(int length,int material,int id); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 3;} void save_payload(GAGCore::OutputStream*)const; private:int length,material,id; };
	class ChangeFlagSize : public ManagementOrder
	{ public: ChangeFlagSize(int size,int id); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 4;} void save_payload(GAGCore::OutputStream*)const; private:int size,id; };
	class ChangeFlagMinimumLevel : public ManagementOrder
	{ public: ChangeFlagMinimumLevel(int level,int id,int targetRole=0); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 5;} void save_payload(GAGCore::OutputStream*)const; private:int level,id,targetRole; };
	class ChangeFlagPosition : public ManagementOrder
	{ public: ChangeFlagPosition(int x,int y,int id); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 6;} void save_payload(GAGCore::OutputStream*)const; private:int x,y,id; };
	class AddArea : public ManagementOrder
	{ public: explicit AddArea(AreaType); void add_location(int,int); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 7;} void save_payload(GAGCore::OutputStream*)const; private:AreaType areaType; std::vector<position> locations; };
	class RemoveArea : public ManagementOrder
	{ public: explicit RemoveArea(AreaType); void add_location(int,int); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 8;} void save_payload(GAGCore::OutputStream*)const; private:AreaType areaType; std::vector<position> locations; };
	class ChangeAlliances : public ManagementOrder
	{ public: ChangeAlliances(int team,OptionalBool,OptionalBool,OptionalBool,OptionalBool,OptionalBool); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 9;} void save_payload(GAGCore::OutputStream*)const; private:int team; OptionalBool allied,enemy,market,inn,other; };
	class UpgradeRepair : public ManagementOrder
	{ public: explicit UpgradeRepair(int id); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 10;} void save_payload(GAGCore::OutputStream*)const; private:int id; };
	class Notify : public ManagementOrder
	{ public: explicit Notify(const RuntimeEvent& event); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 11;} void save_payload(GAGCore::OutputStream*)const; private:RuntimeEvent event; };
	///Sets a building's worker priority: -1 low, 0 normal, +1 high. Teams sort
	///buildings needing work by this value first, so a raised building is served
	///before its equals.
	class ChangePriority : public ManagementOrder
	{ public: ChangePriority(int priority,int id); Conditions::Result wait(Context&) const; void modify(Context&); int type()const{return 12;} void save_payload(GAGCore::OutputStream*)const; private:int priority;int id; };
}

namespace SearchTools
{
	class BuildingSearch;
	class building_search_iterator
	{
	public:
		building_search_iterator();
		unsigned operator*() const;
		building_search_iterator& operator++();
		bool operator!=(const building_search_iterator&) const;
	private:
		friend class BuildingSearch;
		building_search_iterator(BuildingSearch*, bool end);
		void advance();
		BuildingSearch* search;
		std::map<int, Construction::BuildingRecord>::const_iterator iterator;
		bool ended;
	};
	class BuildingSearch
	{
	public:
		explicit BuildingSearch(Context& context);
		void add_condition(Conditions::BuildingCondition*);
		int count_buildings();
		building_search_iterator begin();
		building_search_iterator end();
	private:
		friend class building_search_iterator;
		bool matches(int id) const;
		Context& context;
		std::vector<std::shared_ptr<Conditions::BuildingCondition> > conditions;
	};
	class enemy_team_iterator
	{
	public:
		explicit enemy_team_iterator(Context&);
		enemy_team_iterator();
		unsigned operator*() const;
		enemy_team_iterator& operator++();
		bool operator!=(const enemy_team_iterator&) const;
	private:
		void advance(); Context* context; int team; bool ended;
	};
	class enemy_building_iterator
	{
	public:
		enemy_building_iterator();
		enemy_building_iterator(Context&,int team,int type,int level,ConstructionFilter construction);
		unsigned operator*() const;
		enemy_building_iterator& operator++();
		bool operator!=(const enemy_building_iterator&) const;
	private:
		void advance(); Context* context; int team,type,level,index,gid; ConstructionFilter construction; bool ended;
	};
	class MapInfo
	{
	public:
		explicit MapInfo(Context&);
		int get_width() const; int get_height() const;
		bool is_forbidden_area(int,int) const; bool is_guard_area(int,int) const;
		bool is_clearing_area(int,int) const; bool is_discovered(int,int) const;
		bool is_resource(int,int,int) const; bool is_resource(int,int) const;
		bool is_walkable(int,int) const; bool is_crop_habitat(int,int) const;
		bool is_water(int,int) const; bool is_sand(int,int) const; bool is_grass(int,int) const;
		bool backs_onto_sand(int,int) const; int get_ammount_resource(int,int) const;
	private: Context& context;
	};
}

class Context
{
  public:
	AITelemetry::Sink telemetry;
    std::vector<AIEngine::DiagnosticRecord> bufferedDiagnostics;

  public:
	explicit Context(Player* player);
	std::shared_ptr<Order> getOrder(RuntimeAI& ai);
	unsigned add_building_order(Construction::BuildingOrder*);
	///Cancel an unissued request, or delete the building once its issued order resolves.
	void cancel_or_destroy_building(int id,unsigned retiringUnitMask);
    // Bind a new task after its predecessor completed; never call for routine staffing.
    bool begin_attraction(int id,unsigned unitMask);
    unsigned complete_attraction_retirement(int id,unsigned unitMask);
    bool attraction_retired_or_destroyed(int id,unsigned unitMask) const;
	///Find queued, issued, and observed exploration flags anchored on a resource.
	std::vector<int> material_source_flags(int material) const;
	///Issue an exact planner-selected construction after a final engine-space
	///check. Returns the Maxima building id, or -1 without queuing an order.
	int issue_building_at(int shortType, int workers, int x, int y);
	///Resolve a live building or an exact position reserved by a queued order.
	bool get_building_position(int id, int& x, int& y);
	///Issue an explicitly classified upgrade or repair after revalidation.
	bool issue_upgrade_repair(int id, bool repair);
	void add_management_order(Management::ManagementOrder*);
	void add_material_tracker(Management::MaterialTracker*, int id);
	std::shared_ptr<Management::MaterialTracker> get_material_tracker(int id);
	Construction::BuildingRegister& get_building_register() { return buildings; }
	const Construction::BuildingRegister& get_building_register() const { return buildings; }
	Gradients::GradientManager& get_gradient_manager() { return gradients; }
    const Gradients::GradientManager& get_gradient_manager() const { return gradients; }
	const TeamStat& get_team_stats();
	void push_order(std::shared_ptr<Order> order) {
        if(AIEngine::Command::targetGid(*order)) {
            auto ownerObservation=scopeOwnerObservation();
            AIEngine::selectTarget(*order,observation());
        }
        orders.push_back(order);
    }
    // Revoke stale queued commands before dispatch, preserving registry receipts.
    void reject_queued_orders(const std::function<bool(const Order&)>& reject);
    void push_urgent_order(std::shared_ptr<Order> order);
	bool is_fruit_on_map() const { return fruitOnMap; }
	void dispatch_event(const RuntimeEvent& event);
	void save(GAGCore::OutputStream*) const;
	bool load(GAGCore::InputStream*, Sint32 versionMinor);
	void saveExecutionState(GAGCore::OutputStream*) const;
	void loadExecutionState(GAGCore::InputStream*, Sint32 versionMinor);

	Player* player;
    mutable ObservationBinding binding;
    const AIEngine::AIWorldView& observation() const {return binding.get();}
    unsigned teamNumber() const {return binding.teamNumber();}
    unsigned playerNumber() const {return binding.playerNumber();}
    const AIEngine::TeamView& observedTeam() const {return observation().teams[teamNumber()];}
    void bindObservation(const AIEngine::DecisionContext& decision);
    void releaseObservation();
    class OwnerObservationScope {
        Context* context=nullptr;
      public:
        explicit OwnerObservationScope(Context&);
        ~OwnerObservationScope();
        OwnerObservationScope(const OwnerObservationScope&)=delete;
        OwnerObservationScope& operator=(const OwnerObservationScope&)=delete;
    };
    OwnerObservationScope scopeOwnerObservation() const {return OwnerObservationScope(const_cast<Context&>(*this));}
	Uint32 allies, enemies, inn_view, market_view, other_view;
private:
	friend class Management::MaterialTracker;
    bool observationBound=false;
	void initialize();
	void update_management_orders();
	void update_building_orders();
	void update_trackers();
	void detect_fruit();
	RuntimeAI* activeAI;
	Construction::BuildingRegister buildings;
	Gradients::GradientManager gradients;
	std::list<std::shared_ptr<Order> > orders;
	std::shared_ptr<Order> nullOrder;
	std::vector<std::shared_ptr<Construction::BuildingOrder> > buildingOrders;
	std::vector<std::shared_ptr<Management::ManagementOrder> > managementOrders;
	std::map<int, std::shared_ptr<Management::MaterialTracker> > trackers;
    std::map<int,unsigned> retiredAttractions;
	int timer;
	int previousBuildingId;
	bool initialized;
	bool fruitOnMap;
	std::vector<long long> profileTickMicros;
	long long profileAiMicros;
	long long profileHousekeepingMicros;
	long long profileBuildingSearchMicros;
	long long profileBuildingSearchMaxMicros;
	int profileBuildingSearchCalls;
	void record_profile(long long totalMicros, long long aiMicros,
		long long housekeepingMicros, long long buildingSearchMicros);
};

}

#endif
