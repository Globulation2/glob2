#include "MaximaObservationFixture.h"
// Link with the game objects (excluding Glob2.cpp) to exercise the real runtime.
#include "EngineFixtures.h"
#include "GradientFixture.h"
#include "ScopedEnvironment.h"
#include <algorithm>
#include <nlohmann/json.hpp>
#include <utility>
#include <functional>
#include "GlobalContainer.h"
#include "Version.h"
#include "Game.h"
#include "../../src/team/Team.h"
#include "../../src/ai/AIImplementation.h"
#include "../../src/map/Map.h"
#include "Order.h"
#include "../../src/ai/maxima/AIMaximaContinuation.h"
#include "Player.h"
#include "Utilities.h"
#include "TeamStat.h"
#include "AIMaximaBuildings.h"
#include "AIMaximaWorldHelpers.h"
#include <memory>
#include <limits>
#include <locale>
#include <tuple>
#include <type_traits>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
// Access the scheduler boundary without adding a production testing API.
#include "../../src/ai/maxima/AIMaximaRuntime.h"
#include "../../src/ai/maxima/AIMaxima.h"
#include "../../src/building/Building.h"
#include "BuildingType.h"
#include "../../src/unit/Unit.h"
#include <BinaryStream.h>
#include <StreamBackend.h>
#include <bit>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <memory>

using namespace AIMaximaRuntime;

// Combat policy must survive the handoff to real flag and engine behavior.
namespace combat_regressions
{
using namespace AIMaxima;
struct Fixture
{
    Game game;
    glob2test::BoundGameRandom random{game};
    Player player;
    std::unique_ptr<Maxima> ai;

    Fixture(const std::function<void(Game&)>& configure = {}) : game(NULL)
    {
        game.gameHeader.setRandomSeed(5489);
        // This fixture skips setGameHeader, which normally initializes the
        // player-wait state. syncStep must actually advance the simulation.
        game.setWaitingOnMask(0);
        game.map.setSize(6,6,GRASS);
        game.map.setGame(&game);
        for(int team=0; team<3; ++team) {
            game.addTeam();
            game.teams[team]->race.loadDefault();
            game.teams[team]->playersMask=1u<<team;
        }
        if (configure) configure(game);
        player.setTeam(game.teams[0]);
        ai.reset(new Maxima(&player));
        for(int y=0; y<64; ++y) for(int x=0; x<64; ++x) {
            game.map.setMapDiscovered(x,y,player.team->me);
            // Loading a playable map clears these; setSize alone does not.
            game.map.clearImmobileUnit(x,y);
        }
        ai->timer=100;
        ai->posture=Maxima::PostureCampaign;
        ai->snapshot.population=150;
        ai->snapshot.workers=100;
        ai->snapshot.trained_warriors=12;
        ai->budget.defense_reserve=0;
        ai->budget.food_emergency=false;
        ai->budget.colony_emergency=false;
        ai->strategy.tactics.enabled=true;
        ai->strategy.tactics.siege_enabled=true;
        ai->strategy.tactics.min_force=4;
        ai->strategy.raiding.enabled=false;
    }

    ::Building* building(int x, int y, int team, const char* type="inn", int level=0)
    {
        ::Building* result=game.addBuilding(game.map.normalizeX(x),game.map.normalizeY(y),
            game.buildingsTypes.getTypeNum(type,level,false),team);
        REQUIRE(result);
        return result;
    }

    int id(::Building* building)
    {
        for(auto record:ai->context.buildings.found())
            if(record.second.gid==building->gid) return record.first;
        REQUIRE(false);
        return -1;
    }

    Unit* warrior(int x, int y, int level=1)
    {
        Unit* unit=game.addUnit(x,y,0,WARRIOR,level,0,0,0);
        REQUIRE(unit);
        unit->medical=Unit::MED_FREE;
        unit->activity=Unit::ACT_RANDOM;
        return unit;
    }

    void attach(Unit* unit, ::Building* flag)
    {
        unit->attachedBuilding=flag;
        unit->activity=Unit::ACT_FLAG;
        flag->unitsWorking.push_back(unit);
    }

    void remember(::Building* building)
    {
        ai->reconnaissance.beginObservation(ai->timer,{building->owner->teamNumber});
        ai->reconnaissance.observeBuilding(Recon::BuildingSighting(building->gid,
            building->owner->teamNumber,building->typeNum,
            building->posX,building->posY,building->type->width,
            building->type->height,false,ai->timer));
        ai->reconnaissance.finishObservation();
    }

    void islands()
    {
        for(int y=0; y<64; ++y) for(int x=0; x<64; ++x) {
            const bool land=y>=5 && y<=55 && ((x>=5 && x<=19) || (x>=26 && x<=45));
            game.map.paintCell(x, y, land ? GRASS : WATER);
        }
        ai->context.gradients.invalidate();
    }
};

static bool assigned(Context& context, int id, int workers)
{
    for(auto order:context.managementOrders) {
        auto assignment=dynamic_cast<Management::AssignWorkers*>(order.get());
        if(assignment && assignment->id==id && assignment->workers==workers) return true;
    }
    return false;
}

static void defenseWrapsBuildingOrigins()
{
    // A building whose origin has crossed the toroidal seam used to index the
    // threat arrays out of bounds before any wrapping was applied.
    for(auto origin:{position(-1,7),position(7,-1),position(64,7),position(7,64)}) {
        Fixture f;
        auto* building=f.building(origin.x,origin.y,0);
        auto& a=*f.ai;
        a.context.initialize();
        const int x=building->posX,y=building->posY;
        building->posX=origin.x;
        building->posY=origin.y;
        building->underAttackTimer=100;
        a.budget.reactive_defense_enabled=true;
        a.budget.reactive_defense_flag_radius=5;
        a.budget.reactive_defense_unit_cap=10;
        a.budget.reactive_defense_advantage_min=3;
        a.budget.defense_reserve=10;
        a.compute_defense_flag_positioning(a.context);
        REQUIRE(!a.context.buildingOrders.empty());
        building->posX=x;
        building->posY=y;
    }
}

static void defenseCoverage()
{
    // Exercise both threat inputs and wrapping at the map edge. The fourth
    // target used to disappear from the potential field outside flag coverage.
    for(bool invaders:{false,true}) for(int shift:{0,40}) {
        Fixture f;
        f.building(20+shift,24+shift,0);
        auto& a=*f.ai;
        auto& c=a.context;
        c.initialize();
        const int points[][2]={{28,29},{28,30},{20,20},{28,21}};
        for(auto& point:points) {
            Unit* unit=f.game.addUnit((point[0]+shift)%64,(point[1]+shift)%64,
                invaders ? 1 : 0,invaders ? WARRIOR : WORKER,1,0,0,0);
            REQUIRE(unit);
            if(!invaders) unit->underAttackTimer=100;
        }
        a.budget.reactive_defense_enabled=true;
        a.budget.reactive_defense_flag_radius=5;
        a.budget.reactive_defense_unit_cap=10;
        a.budget.reactive_defense_advantage_min=3;
        a.budget.defense_reserve=30;
        a.compute_defense_flag_positioning(c);
        std::vector<position> flags;
        int allocation=0;
        for(auto order:c.buildingOrders) {
            bool complete=false;
            auto observation=c.scopeOwnerObservation();
            auto location=order->find_location(c,1,complete);
            REQUIRE((complete && location.found));
            flags.push_back(location.value);
            allocation+=order->workers;
        }
        REQUIRE(allocation<=a.budget.defense_reserve);
        for(auto& point:points) {
            bool covered=false;
            for(auto flag:flags)
                covered|=f.game.map.warpDistSquare((point[0]+shift)%64,
                    (point[1]+shift)%64,flag.x,flag.y)<=25;
            REQUIRE(covered);
        }
    }
}

static void economicRecoveryPreservesMilitaryBudget()
{
    Fixture f; auto& a=*f.ai;
    a.snapshot.population=100;
    a.snapshot.workers=1;
    a.snapshot.warriors=a.snapshot.trained_warriors=60;
    a.snapshot.alive_enemies=1;
    a.opponents[1].alive=true;
    a.opponents[1].score=10;
    a.opponents[1].estimated_warriors=10;
    a.strategy.emergencies.colony_enabled=false;
    glob2test::withMaximaObservation(a.context,[&]() -> decltype(auto) {return a.allocate_resources(a.context);});
    const int reserve=a.budget.defense_reserve;
    const int attack=a.budget.attack_units;
    REQUIRE((a.budget.attack_flags==1 && attack>0));
    a.snapshot.unserved_food=50;
    a.snapshot.critical_food=50;
    a.posture=Maxima::PostureRecover;
    glob2test::withMaximaObservation(a.context,[&]() -> decltype(auto) {return a.allocate_resources(a.context);});
    REQUIRE(a.severe_food_emergency());
    REQUIRE((a.budget.attack_flags==1 && a.budget.attack_units==attack));
    REQUIRE(a.budget.defense_reserve==reserve);
    a.posture=Maxima::PostureCampaign;
    a.posture_since=0;
    a.campaign.cooldown_until=0;
    a.select_posture();
    REQUIRE(a.posture==Maxima::PostureRecover);
    REQUIRE(a.campaign.cooldown_until==0); // Recovery cannot inject a military cooldown.
}

static void forbiddenDefenseZones()
{
    for(bool amphibious:{false,true}) {
        Fixture f;
        for(int y=0;y<64;++y) for(int x=0;x<64;++x)
            f.game.map.paintCell(x,y,(x>=5&&x<=50&&y>=20&&y<=27)?GRASS:WATER);
        f.building(10,22,0);
        f.building(42,22,1)->seenByMask|=f.player.team->me;
        auto& a=*f.ai; auto& c=a.context; c.initialize();
        a.budget.preemptive_defense_active=true;
        a.budget.preemptive_amphibious_active=amphibious;
        a.budget.preemptive_effective_zone_max=1;
        a.budget.preemptive_inner_distance=4;
        a.budget.preemptive_band_width=8;
        a.budget.preemptive_path_slack=2;
        a.budget.preemptive_probe_radius=8;
        a.budget.preemptive_cross_section_max=10;
        a.budget.preemptive_zone_radius=2;
        // Include the surrounding sea so swimming cannot bypass the barrier.
        for(int y=0;y<64;++y) for(int x=0;x<64;++x)
            if(x<5||x>50||y<20||y>27||(x>=16&&x<=38))
                f.game.map.addForbidden(x,y,f.player.team->teamNumber);
        a.update_preemptive_defense(c);
        REQUIRE(a.preemptive_guard_tiles.empty());
        for(int y=20;y<=27;++y) for(int x=16;x<=38;++x)
            f.game.map.removeForbidden(x,y,f.player.team->teamNumber);
        a.timer+=a.budget.preemptive_recompute_ticks;
        a.update_preemptive_defense(c);
        REQUIRE(!a.preemptive_guard_tiles.empty());
        for(int i:a.preemptive_guard_tiles) {
            REQUIRE(!f.game.map.isForbidden(i%64,i/64,f.player.team->me));
            f.game.map.addGuardArea(i%64,i/64,0);
        }
        glob2test::awaitGradient(f.game,[&] { return f.game.map.getGuardAreasGradient(0,amphibious); });
        f.game.map.updateGuardAreasGradient(0,amphibious);
        REQUIRE(f.game.map.getGuardAreasGradient(0,amphibious)[22*64+8]>1);
    }
}

static void defenseDeadbandPreservesCoverage()
{
    // Check all three coverage inputs, including wrapping and a harmless
    // shift that should still be suppressed by the existing deadband.
    for(int threatKind:{0,1,2}) for(int shift:{0,44}) for(bool covered:{false,true}) {
        Fixture f;
        const auto wrap=[&](int value) { return (value+shift)%64; };
        f.building(wrap(20),wrap(24),0);
        int x=wrap(22),y=wrap(20);
        if(threatKind==2) {
            auto building=f.building(wrap(24),wrap(20),0);
            building->underAttackTimer=100;
            x=f.game.map.normalizeX(building->posX-building->type->decLeft);
            y=f.game.map.normalizeY(building->posY-building->type->decTop);
        } else {
            auto unit=f.game.addUnit(x,y,threatKind==0?1:0,
                threatKind==0?WARRIOR:WORKER,1,0,0,0);
            REQUIRE(unit);
            if(threatKind==1) unit->underAttackTimer=100;
        }
        auto flag=f.building(x-(covered?4:6),y,0,"warflag");
        flag->unitStayRange=5;
        auto& a=*f.ai; auto& c=a.context; c.initialize();
        a.defense_flags.push_back(f.id(flag));
        a.budget.reactive_defense_flag_radius=5;
        a.budget.reactive_defense_move_deadband=2;
        a.budget.reactive_defense_move_radius=10;
        a.budget.reactive_defense_unit_cap=10;
        a.budget.reactive_defense_advantage_min=3;
        a.budget.defense_reserve=10;
        a.compute_defense_flag_positioning(c);
        bool moved=false;
        int finalX=flag->posX,finalY=flag->posY;
        for(auto order:c.managementOrders) {
            auto move=dynamic_cast<Management::ChangeFlagPosition*>(order.get());
            if(move) { moved=true; finalX=move->x; finalY=move->y; }
        }
        REQUIRE(moved==!covered);
        REQUIRE(c.buildingOrders.empty());
        REQUIRE(f.game.map.warpDistSquare(finalX,finalY,x,y)<=25);
    }
}

// Issue the pending flag order and materialize the engine building so later
// reviews see a found flag with real recruitment behavior.
static ::Building* materializeFlag(Fixture& f)
{
    auto& c=f.ai->context;
    c.update_building_orders();
    std::shared_ptr<OrderCreate> create;
    for(auto order:c.orders)
        if(auto candidate=std::dynamic_pointer_cast<OrderCreate>(order)) create=candidate;
    REQUIRE(create);
    auto flag=f.game.addBuilding(create->posX,create->posY,create->typeNum,0);
    REQUIRE(flag);
    {auto observation=c.scopeOwnerObservation();c.buildings.tick();}
    c.orders.clear();
    c.update_management_orders();
    for(auto order:c.orders) {
        if(auto minimum=std::dynamic_pointer_cast<OrderModifyMinLevelToFlag>(order)) {
            if(minimum->targetRole==1) flag->explorersRequireBombing=minimum->minLevelToFlag!=0;
            else flag->minLevelToFlag=minimum->minLevelToFlag;
        }
        if(auto size=std::dynamic_pointer_cast<OrderModifyFlag>(order))
            flag->unitStayRange=size->range;
        if(auto staffing=std::dynamic_pointer_cast<OrderModifyBuilding>(order))
            flag->maxUnitWorking=staffing->numberRequested;
    }
    c.orders.clear();
    return flag;
}

// Place synthetic policy-test arrivals on distinct legal cells and keep map
// occupancy consistent. Real movement to the rally is tested separately below.
static void placeAtRally(Fixture& f, ::Building* flag, const std::vector<Unit*>& units, int count)
{
    for(int i=0;i<count;++i) {
        auto* unit=units[i];
        f.game.map.setGroundUnit(unit->posX,unit->posY,NOGUID);
        bool placed=false;
        for(int dy=-flag->unitStayRange;dy<=flag->unitStayRange && !placed;++dy)
            for(int dx=-flag->unitStayRange;dx<=flag->unitStayRange && !placed;++dx) {
                if(dx*dx+dy*dy>flag->unitStayRange*flag->unitStayRange)continue;
                const int x=f.game.map.normalizeX(flag->posX+dx),y=f.game.map.normalizeY(flag->posY+dy);
                if(!f.game.map.isFreeForGroundUnit(x,y,false,f.player.team->me))continue;
                unit->posX=x;unit->posY=y;
                f.game.map.setGroundUnit(x,y,unit->gid);placed=true;
            }
        REQUIRE(placed);
    }
}

static void nearbyWarriorsCountAsRallied()
{
    for(bool withinTolerance:{false,true}) {
        Fixture f;
        f.building(10,10,0);
        auto target=f.building(35,30,1);
        std::vector<Unit*> warriors;
        for(int i=0;i<20;++i)warriors.push_back(f.warrior(i%5,i/5,3));
        auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);
        a.plan_offense(c);a.control_offense(c);
        auto* flag=materializeFlag(f);
        for(auto* warrior:warriors)f.attach(warrior,flag);
        const int inner=flag->unitStayRange+(withinTolerance?0:2),outer=inner+2;
        int placed=0;
        for(int dy=-outer;dy<=outer && placed<15;++dy)
            for(int dx=-outer;dx<=outer && placed<15;++dx) {
                if(dx*dx+dy*dy<=inner*inner || dx*dx+dy*dy>outer*outer)continue;
                const int x=f.game.map.normalizeX(flag->posX+dx),y=f.game.map.normalizeY(flag->posY+dy);
                if(!f.game.map.isFreeForGroundUnit(x,y,false,f.player.team->me))continue;
                auto* unit=warriors[placed++];
                f.game.map.setGroundUnit(unit->posX,unit->posY,NOGUID);
                unit->posX=x;unit->posY=y;f.game.map.setGroundUnit(x,y,unit->gid);
            }
        REQUIRE(placed==15);
        a.timer+=100;
        a.plan_offense(c);a.control_offense(c);
        REQUIRE((a.offense_waves[0].phase==Tactics::WaveAdvance)==withinTolerance);
    }
}

static void rallyRejectsBlockedGround()
{
    Fixture f;
    f.building(10,10,0);
    auto target=f.building(35,30,1);
    for(int i=0;i<20;++i)f.warrior(i%5,i/5,3);
    auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);
    for(int y=4;y<22;++y)for(int x=4;x<22;++x)f.game.map.addForbidden(x,y,0);
    // A reachable nine-tile pocket is still too small for the wave.
    for(int y=7;y<10;++y)for(int x=7;x<10;++x)f.game.map.removeForbidden(x,y,0);
    a.plan_offense(c);a.control_offense(c);
    REQUIRE(a.offense_waves.empty());
    // No room to muster must not fall through to an ungathered attack flag.
    REQUIRE(c.buildingOrders.empty());
    f.building(40,40,0);
    {auto observation=c.scopeOwnerObservation();c.buildings.tick();}
    a.plan_offense(c);a.control_offense(c);
    REQUIRE(a.offense_waves.size()==1);
    auto* flag=materializeFlag(f);
    REQUIRE(f.game.map.warpDistMax(flag->posX,flag->posY,40,40)<=10);
    REQUIRE(f.game.map.getBuilding(flag->posX,flag->posY)==NOGBID);
    const int oldX=flag->posX,oldY=flag->posY;
    f.building(oldX,oldY,0);
    a.timer+=100;
    a.plan_offense(c);a.control_offense(c);
    bool moved=false;
    for(auto order:c.managementOrders)
        if(auto move=dynamic_cast<Management::ChangeFlagPosition*>(order.get())) {
            REQUIRE(f.game.map.getBuilding(move->x,move->y)==NOGBID);
            REQUIRE(!f.game.map.isForbidden(move->x,move->y,f.player.team->me));
            moved=true;
        }
    REQUIRE((moved && a.offense_waves[0].phase==Tactics::WaveMuster));
}

static void rallyAssemblesByMovement()
{
    const std::string traceFile=(glob2test::sourceRoot() / "test/maxima/fixtures/rally-movement-checksums.txt").string();
    const char* tracePath=traceFile.c_str();
    const bool record=std::getenv("GLOB2_RECORD_RALLY_CHECKSUMS")!=nullptr;
    std::ifstream expected;
    std::ofstream output;
    if(record)output.open(tracePath);
    else expected.open(tracePath);
    REQUIRE((record ? output.good() : expected.good()));
    for(int shift:{0,52}) {
        setSyncRandSeed(5489);
        Fixture f;
        f.game.map.configureGradientPipeline(0,8);
        const auto wrap=[&](int v){return (v+shift)%64;};
        f.game.gameHeader.setHungerDisabled(true);
        f.building(wrap(10),wrap(10),0);
        auto target=f.building(wrap(35),wrap(30),1);
        std::vector<Unit*> warriors;
        for(int i=0;i<20;++i)warriors.push_back(f.warrior(wrap(2+i%5),wrap(2+i/5),3));
        auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);
        a.plan_offense(c);a.control_offense(c);
        REQUIRE(a.offense_waves.size()==1);
        auto* flag=materializeFlag(f);
        REQUIRE(f.game.map.getBuilding(flag->posX,flag->posY)==NOGBID);
        REQUIRE(flag->unitStayRange==4);
        for(auto* warrior:warriors) {
            warrior->subscriptionSuccess(flag,false,true);
            flag->unitsWorking.push_back(warrior);
        }
        // Readiness includes the two-tile margin: crowding at the flag edge
        // must not make this movement test demand more than the launch policy.
        const int arrivalRadius=flag->unitStayRange+2;
        int arrived=0;
        for(int tick=0;tick<2000 && arrived<15;++tick) {
            const auto previousStep=f.game.stepCounter;
            f.game.step(0);
            REQUIRE(f.game.stepCounter==previousStep+1);
            // Keep the format-115 baseline: this fixture's header version is
            // rotated eight times by MapHeader/Game checksums (three teams,
            // no players). A save-format bump must not change movement evidence.
            const Uint32 checksum=f.game.checkSum(nullptr,nullptr,nullptr,true,true)
                ^ std::rotr(Uint32(f.game.mapHeader.getVersionMinor()^115),8);
            if(record)output << shift << ' ' << f.game.stepCounter << ' ' << checksum << '\n';
            else {
                int expectedShift;
                Uint32 expectedStep,expectedChecksum;
                REQUIRE((expected >> expectedShift >> expectedStep >> expectedChecksum));
                if(expectedShift!=shift || expectedStep!=f.game.stepCounter || expectedChecksum!=checksum)
                    std::cerr << "Rally checksum mismatch: shift=" << shift
                        << " step=" << f.game.stepCounter << " actual=" << checksum
                        << " expected=" << expectedChecksum << '\n';
                REQUIRE((expectedShift==shift && expectedStep==f.game.stepCounter && expectedChecksum==checksum));
            }
            arrived=0;
            for(auto* warrior:warriors)
                arrived+=f.game.map.warpDistSquare(warrior->posX,warrior->posY,flag->posX,flag->posY)
                    <=arrivalRadius*arrivalRadius;
        }
        if(arrived<15)
            std::cerr << "Rally movement: shift=" << shift << " arrived=" << arrived
                << " radius=" << arrivalRadius << '\n';
        REQUIRE(arrived>=15);
        std::set<std::pair<int,int>> occupied;
        for(auto* warrior:warriors) {
            REQUIRE(f.game.map.getBuilding(warrior->posX,warrior->posY)==NOGBID);
            REQUIRE(occupied.insert({warrior->posX,warrior->posY}).second);
        }
        a.timer+=100;
        a.plan_offense(c);a.control_offense(c);
        REQUIRE(a.offense_waves[0].phase==Tactics::WaveAdvance);
    }
    if(!record) {
        expected >> std::ws;
        REQUIRE(expected.eof());
    }
}

static void waveAssemblyAndPipeline()
{
    Fixture f;
    f.building(10,10,0);
    auto target=f.building(35,30,1);
    std::vector<Unit*> warriors;
    for(int i=0;i<40;++i)warriors.push_back(f.warrior(i%10,i/10,3));
    auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);
    a.director.dirty=false;
    a.budget.tactical_kind=Tactics::MissionNone;
    a.control_offense(c);
    REQUIRE(!a.director.dirty); // Idle wave reviews must not reschedule the economy.
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_requested_force==40);
    a.control_offense(c);
    REQUIRE(a.offense_waves.size()==1);
    REQUIRE(a.offense_waves[0].requestedForce==20);
    const int first=a.offense_waves[0].flagId;
    auto flag=materializeFlag(f);
    REQUIRE(f.game.map.getBuilding(flag->posX,flag->posY)==NOGBID);
    REQUIRE(f.game.map.warpDistMax(flag->posX,flag->posY,10,10)<=10);
    for(int i=0;i<20;++i)f.attach(warriors[i],flag);
    a.timer+=100;
    a.plan_offense(c);a.control_offense(c);
    // Enrollment alone must not release the cohort; nobody has arrived.
    REQUIRE(a.offense_waves.size()==1);
    REQUIRE(a.offense_waves[0].phase==Tactics::WaveMuster);
    placeAtRally(f,flag,warriors,15);
    a.timer+=100;
    a.plan_offense(c);a.control_offense(c);
    REQUIRE(a.offense_waves.size()==2);
    REQUIRE(a.offense_waves[0].phase==Tactics::WaveAdvance);
    REQUIRE(a.offense_waves[1].phase==Tactics::WaveMuster);
    bool moved=false,lowPriority=false;
    for(auto order:c.managementOrders) {
        if(auto move=dynamic_cast<Management::ChangeFlagPosition*>(order.get()))
            moved=moved || (move->id==first && move->x==a.budget.tactical_target_x);
        if(auto priority=dynamic_cast<Management::ChangePriority*>(order.get()))
            lowPriority=lowPriority || (priority->id==first && priority->priority==-1);
    }
    REQUIRE((moved && lowPriority));
    // Save with one advancing and one pending muster flag. Restore the real
    // Maxima execution queue and verify all wave fields, including clocks.
    auto* saved=new GAGCore::MemoryStreamBackend;
    GAGCore::BinaryOutputStream output(saved);
    a.save(&output);
    const std::string bytes(saved->getBuffer(),saved->getPosition());
    GAGCore::BinaryInputStream input(new GAGCore::MemoryStreamBackend(bytes.data(),bytes.size()));
    input.seekFromStart(0);
    Maxima restored(&input,&f.player,VERSION_MINOR);
    const auto waveBytes=[](const std::vector<Tactics::Wave>& waves) {
        auto* storage=new GAGCore::MemoryStreamBackend;
        GAGCore::BinaryOutputStream stream(storage);
        AIMaximaContinuation::Writer archive(&stream);
        archive("waves",waves);
        return std::string(storage->getBuffer(),storage->getPosition());
    };
    REQUIRE(waveBytes(restored.offense_waves)==waveBytes(a.offense_waves));
    REQUIRE(restored.context.get_building_register().is_building_pending(a.offense_waves[1].flagId));
    a.timer+=100;restored.timer+=100;
    a.control_offense(c);restored.control_offense(restored.context);
    REQUIRE(waveBytes(restored.offense_waves)==waveBytes(a.offense_waves));
    REQUIRE(restored.context.managementOrders.size()==c.managementOrders.size());
    // A flag lifecycle notification cannot discard another live cohort.
    a.handle_event(c,RuntimeEvent(RuntimeEvent::AttackFinished,first));
    REQUIRE(a.offense_waves.size()==1);
    REQUIRE(a.tactical_mission.flagId==a.offense_waves[0].flagId);
    a.end_offense(c,"test");
    REQUIRE((a.offense_waves.empty() && a.attack_flags.empty()));
}

static void waveDeliveryFallback()
{
    Fixture f;
    f.building(10,10,0);
    auto target=f.building(35,30,1);
    auto flag=f.building(12,12,0,"warflag");
    std::vector<Unit*> warriors;
    for(int i=0;i<20;++i)warriors.push_back(f.warrior(i,2,3));
    auto& a=*f.ai;auto& c=a.context;c.initialize();
    const int id=f.id(flag);
    a.budget.tactical_siege_radius=6;
    const auto launch=[&](int arrived) {
        flag->unitsWorking.clear();
        for(int i=0;i<20;++i) {
            f.attach(warriors[i],flag);
            warriors[i]->posX=i<arrived ? 35 : i;
            warriors[i]->posY=i<arrived ? 30 : 2;
        }
        Tactics::Wave wave;wave.flagId=id;wave.phase=Tactics::WaveAdvance;
        wave.targetX=35;wave.targetY=30;a.offense_waves.push_back(wave);
        a.observe_wave_delivery();
        REQUIRE(a.wave_delivery.at(id).launched==20);
    };
    const auto spent=[&](bool retired=false) {
        const int before=a.failed_waves;
        for(auto* warrior:warriors){warrior->posY=2;warrior->attachedBuilding=nullptr;}
        // More than a quarter left: do not assess it yet.
        flag->unitsWorking.resize(6);a.observe_wave_delivery();
        REQUIRE(a.failed_waves==before);
        flag->unitsWorking.resize(5);
        if(retired)a.offense_waves.clear();
        a.observe_wave_delivery();
        const int after=a.failed_waves;
        a.offense_waves.clear();a.observe_wave_delivery();
        REQUIRE(a.failed_waves==after); // Retirement must not count it twice.
    };
    launch(6);spent();REQUIRE(a.failed_waves==1); // 30% is below 33%.
    launch(0);spent();REQUIRE(a.failed_waves==2);
    launch(7);spent();REQUIRE(a.failed_waves==0); // Peak delivery survives departures.
    launch(0);spent(true);REQUIRE(a.failed_waves==1);
    launch(0);spent();REQUIRE(a.failed_waves==2);
    launch(0);spent();REQUIRE(a.failed_waves==3);
    launch(0);
    // Save with three failures and an unassessed fourth wave.
    auto* saved=new GAGCore::MemoryStreamBackend;
    GAGCore::BinaryOutputStream output(saved);a.save(&output);
    const std::string bytes(saved->getBuffer(),saved->getPosition());
    GAGCore::BinaryInputStream input(new GAGCore::MemoryStreamBackend(bytes.data(),bytes.size()));
    input.seekFromStart(0);
    Maxima restored(&input,&f.player,VERSION_MINOR);
    REQUIRE((restored.failed_waves==3 && restored.wave_delivery.at(id).launched==20));
    spent();restored.observe_wave_delivery();
    REQUIRE((a.failed_waves==4 && restored.failed_waves==4));
    REQUIRE((a.offense_waves.empty() && restored.offense_waves.empty()));
    REQUIRE((a.wave_delivery.empty() && restored.wave_delivery.empty()));
    // The latch survives ordinary mission cleanup and uses the real old executor.
    a.end_offense(c,"test");
    a.budget.tactics_enabled=true;
    a.budget.tactical_kind=Tactics::MissionSiege;
    a.budget.tactical_target_team=1;a.budget.tactical_target_gid=target->gid;
    a.budget.tactical_target_x=35;a.budget.tactical_target_y=30;
    a.budget.tactical_requested_force=10;
    a.control_offense(c);
    REQUIRE((a.failed_waves==4 && a.offense_waves.empty()));
    REQUIRE((a.tactical_mission.flagId>=0 && !c.buildingOrders.empty()));
    auto* latched=new GAGCore::MemoryStreamBackend;
    GAGCore::BinaryOutputStream latchOutput(latched);a.save(&latchOutput);
    const std::string latchBytes(latched->getBuffer(),latched->getPosition());
    GAGCore::BinaryInputStream latchInput(new GAGCore::MemoryStreamBackend(latchBytes.data(),latchBytes.size()));
    latchInput.seekFromStart(0);
    Maxima resumed(&latchInput,&f.player,VERSION_MINOR);
    REQUIRE((resumed.failed_waves==4 && !resumed.control_offense_waves(resumed.context)));
    std::cout << "wave delivery: threshold, reset, retirement, one-way handoff and saved latch PASS\n";
}

static void waveAssemblyFallback()
{
    Fixture f;
    f.building(10,10,0);
    auto target=f.building(35,30,1);
    for(int i=0;i<20;++i)f.warrior(i,0,3);
    auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);
    a.plan_offense(c);a.control_offense(c);
    auto flag=materializeFlag(f);
    const auto rally=a.offense_waves.front();
    // A slow rally must get its full existing assembly allowance.
    a.timer=rally.startedTick+a.strategy.assault.muster_max_ticks-1;
    a.control_offense(c);
    REQUIRE((a.failed_waves==0 && a.offense_waves.front().phase==Tactics::WaveMuster));
    for(int failures=1;failures<=4;++failures) {
        a.timer=a.offense_waves.front().startedTick+a.strategy.assault.muster_max_ticks;
        a.control_offense(c);
        REQUIRE((a.failed_waves==failures && a.offense_waves.empty()));
        a.observe_wave_delivery();
        REQUIRE(a.failed_waves==failures); // No double counting after retirement.
        if(failures<4) {
            // Reuse the real flag for another synthetic timed-out attempt.
            auto next=rally;next.startedTick=next.progressTick=++a.timer;
            a.offense_waves.push_back(next);
        }
    }
    REQUIRE((flag && a.tactical_mission.flagId>=0 && !c.buildingOrders.empty()));
    REQUIRE(!a.control_offense_waves(c)); // Streaming remains latched.
    std::cout << "wave assembly: full timeout, four failures and streaming handoff PASS\n";
}

static void streamingScalesWithArmy()
{
    Fixture f;f.building(10,10,0);
    auto target=f.building(35,30,1);
    std::vector<Unit*> army;
    for(int i=0;i<45;++i)army.push_back(f.warrior(i,0,3));
    f.game.gameHeader.setNumberOfPlayers(1);
    f.game.players[0]=new Player;
    f.game.players[0]->setTeam(f.player.team);
    auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);
    a.failed_waves=4;
    const auto apply=[&] {
        // Exercise real creation, registration and management orders, including
        // the bounded search used to place additional flags near the objective.
        const auto drain=[&] {
            while(!c.orders.empty()) {
                auto order=c.orders.front();c.orders.pop_front();
                order->sender=0;f.game.executeOrder(order,0);
            }
        };
        for(int pass=0;pass<128;++pass) {
            {auto observation=c.scopeOwnerObservation();c.gradients.update(++f.game.stepCounter);}
            c.update_building_orders();drain();{auto observation=c.scopeOwnerObservation();c.buildings.tick();}
            c.update_management_orders();drain();
        }
        REQUIRE(c.buildingOrders.empty());
    };
    const auto allocation=[&](int total) {
        auto observation=c.scopeOwnerObservation();
        int assigned=0;std::set<int> gids;
        for(int id:a.attack_flags) {
            auto* flag=c.buildings.get_building(id);REQUIRE(flag);
            REQUIRE(flag->maxUnitWorking<=a.strategy.military.attack_unit_cap);
            assigned+=flag->maxUnitWorking;gids.insert(flag->gid);
            REQUIRE(f.game.map.warpDistMax(flag->posX,flag->posY,
                a.budget.tactical_target_x,a.budget.tactical_target_y)<=flag->unitStayRange);
        }
        REQUIRE((assigned==total && gids.size()==a.attack_flags.size()));
    };
    a.plan_offense(c);REQUIRE(a.budget.tactical_requested_force==45);
    a.control_offense(c);apply();REQUIRE(a.attack_flags.size()==3);allocation(45);
    const auto first=a.attack_flags;
    for(int i=0;i<45;++i)f.attach(army[i],f.game.teams[0]->myBuildings[Building::GIDtoID(c.buildings.found().at(first[i/20]).gid)]);
    a.plan_offense(c);
    REQUIRE((a.offense_diagnostics.eligibleWarriors==45 && a.budget.tactical_requested_force==45));
    a.control_offense(c);REQUIRE((a.attack_flags==first && c.buildingOrders.empty()));
    for(int i=0;i<20;++i)army.push_back(f.warrior(i,2,3));
    a.plan_offense(c);REQUIRE(a.budget.tactical_requested_force==65);
    a.control_offense(c);apply();REQUIRE(a.attack_flags.size()==4);allocation(65);
    REQUIRE(std::equal(first.begin(),first.end(),a.attack_flags.begin()));
    for(int i=25;i<65;++i)army[i]->medical=Unit::MED_DAMAGED;
    a.plan_offense(c);REQUIRE(a.budget.tactical_requested_force==25);
    a.control_offense(c);apply();REQUIRE(a.attack_flags.size()==2);allocation(25);
    REQUIRE((a.attack_flags[0]==first[0] && a.attack_flags[1]==first[1]));
    // A lost primary must promote a survivor without cancelling the mission.
    f.game.teams[0]->myBuildings[Building::GIDtoID(c.buildings.found().at(first[0]).gid)]->kill();{auto observation=c.scopeOwnerObservation();c.buildings.tick();}
    a.handle_event(c,RuntimeEvent(RuntimeEvent::AttackFinished,first[0]));
    REQUIRE((a.tactical_mission.flagId==first[1] && a.campaign.state==Maxima::CampaignActive));
    a.control_offense(c);apply();REQUIRE(a.attack_flags.size()==2);allocation(25);
    REQUIRE(a.attack_flags.front()==first[1]);
    a.budget.tactical_target_x=40;a.budget.tactical_target_y=40;
    a.control_offense(c);apply();allocation(25);
    for(int id:a.attack_flags) {
        auto observation=c.scopeOwnerObservation();
        auto* flag=c.buildings.get_building(id);
        REQUIRE((flag->posX==40 && flag->posY==40));
    }
    auto* saved=new GAGCore::MemoryStreamBackend;
    GAGCore::BinaryOutputStream output(saved);a.save(&output);
    const std::string bytes(saved->getBuffer(),saved->getPosition());
    GAGCore::BinaryInputStream input(new GAGCore::MemoryStreamBackend(bytes.data(),bytes.size()));
    input.seekFromStart(0);Maxima restored(&input,&f.player,VERSION_MINOR);
    REQUIRE((restored.attack_flags==a.attack_flags && restored.failed_waves==4));
    restored.control_offense(restored.context);
    REQUIRE((restored.attack_flags==a.attack_flags && restored.context.buildingOrders.empty()));
    const auto active=a.attack_flags;a.end_offense(c,"test");
    REQUIRE(a.attack_flags.empty());
    for(int id:active) {
        bool cancelled=false;
        for(auto order:c.managementOrders)
            if(auto* destroy=dynamic_cast<Management::RetireAttraction*>(order.get()))cancelled|=destroy->id==id;
        REQUIRE(cancelled);
    }
    std::cout << "streaming: real flags, full army, growth, shrink, loss, retarget and reload PASS\n";
}

static void smallWaveKeepsRecruiting()
{
    Fixture f;
    f.building(10,10,0);
    auto target=f.building(35,30,1);
    std::vector<Unit*> warriors;
    for(int i=0;i<4;++i)warriors.push_back(f.warrior(i,0,3));
    auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);
    a.plan_offense(c);a.control_offense(c);
    REQUIRE((a.offense_waves.size()==1 && a.offense_waves[0].requestedForce==4));
    auto flag=materializeFlag(f);
    for(auto warrior:warriors)f.attach(warrior,flag);
    placeAtRally(f,flag,warriors,4);
    a.timer+=100;
    a.plan_offense(c);a.control_offense(c);
    // Four of four present is not a full wave: allow time for the army to grow.
    REQUIRE(a.offense_waves[0].phase==Tactics::WaveMuster);
    for(int i=4;i<20;++i)warriors.push_back(f.warrior(20+i%10,20+i/10,3));
    a.timer+=100;
    a.plan_offense(c);a.control_offense(c);
    REQUIRE(a.offense_waves[0].requestedForce==20);
    REQUIRE(assigned(c,a.offense_waves[0].flagId,20));
    for(int i=4;i<20;++i)f.attach(warriors[i],flag);
    a.timer+=a.strategy.assault.muster_stall_ticks;
    a.plan_offense(c);a.control_offense(c);
    // A timeout cannot launch four arrived warriors with sixteen stragglers.
    REQUIRE(a.offense_waves[0].phase==Tactics::WaveMuster);
    placeAtRally(f,flag,warriors,15);
    a.timer+=100;
    a.plan_offense(c);a.control_offense(c);
    REQUIRE(a.offense_waves[0].phase==Tactics::WaveAdvance);
}

static void warriorEligibility()
{
    Fixture f;
    f.building(10,10,0);
    auto target=f.building(35,30,1);
    f.islands();
    for(int i=0; i<12; ++i) {
        auto unit=f.warrior(6+i,6);
        unit->setPerformance(SWIM,0);
        unit->level[SWIM]=0;
    }
    std::vector<Unit*> swimmers;
    for(int i=0; i<4; ++i) {
        auto unit=f.warrior(6+i,7,0);
        unit->setPerformance(SWIM,1);
        unit->level[SWIM]=1;
        swimmers.push_back(unit);
    }
    auto& a=*f.ai;
    auto& c=a.context;
    c.initialize();
    f.remember(target);
    a.snapshot.swimming_warriors=4;
    for(int ability:{ATTACK_SPEED,ATTACK_STRENGTH}) {
        // Neither single upgrade is sufficient for a level-2 tactical flag.
        for(auto unit:swimmers) {
            unit->level[ATTACK_SPEED]=0;
            unit->level[ATTACK_STRENGTH]=0;
            unit->level[ability]=1;
        }
        a.plan_offense(c);
        REQUIRE(a.budget.tactical_kind==Tactics::MissionNone);
    }
    for(auto unit:swimmers) {
        unit->level[ATTACK_SPEED]=unit->level[ATTACK_STRENGTH]=1;
        for(int ability:{ATTACK_SPEED,ATTACK_STRENGTH})
            unit->setPerformance(ability,unit->race->getUnitType(WARRIOR,1)->performance[ability]);
    }
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_kind==Tactics::MissionSiege);
    REQUIRE(a.budget.tactical_requested_force==a.offense_diagnostics.eligibleWarriors);
    a.control_offense(c);
    REQUIRE((a.tactical_mission.flagId>=0 && a.tactical_mission.kind==Tactics::MissionSiege));
    auto flag=materializeFlag(f);
    REQUIRE((flag->maxUnitWorking==a.offense_diagnostics.eligibleWarriors && flag->minLevelToFlag==1));
    flag->updateCallLists();
    for(int step=0; step<33; ++step) (glob2test::publishCurrentHiringSuggestions(*flag->owner->game), flag->subscribeForFlagingStep());
    REQUIRE(flag->unitsWorking.size()==4);
    for(auto unit:flag->unitsWorking) REQUIRE(unit->performance[SWIM]>0);
}

static void untrainedWarriorsFightAtLevelOne()
{
    for(int level:{1,2}) {
        Fixture f;
        f.building(10,10,0);
        auto target=f.building(35,30,1);
        for(int i=0;i<4;++i) f.warrior(15+i,15,0);
        auto& a=*f.ai; auto& c=a.context; c.initialize(); f.remember(target);
        a.strategy.tactics.flag_minimum_level=level;
        a.plan_offense(c);
        REQUIRE((a.budget.tactical_kind==Tactics::MissionSiege)==(level==1));
        REQUIRE((level==1 || a.offense_diagnostics.eligibleWarriors==0));
    }
}

static void loweredFlagLevelSurvivesReview()
{
    Fixture f;
    f.building(10,10,0);
    auto target=f.building(35,30,1);
    for(int i=0;i<8;++i) f.warrior(15+i,15,0);
    auto& a=*f.ai; auto& c=a.context; c.initialize(); f.remember(target);
    a.strategy.tactics.flag_minimum_level=2;
    a.opponents[1].alive=true;
    a.opponents[1].estimated_warriors=1;
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_kind==Tactics::MissionSiege);
    REQUIRE(a.budget.tactical_flag_level==1);
    a.control_offense(c);
    const int flagId=a.tactical_mission.flagId;
    REQUIRE(flagId>=0);
    // A director refresh must not reset the level while creation is pending.
    a.finalize_director_plan(c);
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_flag_level==1);
    REQUIRE(a.budget.tactical_target_gid==target->gid);
    auto flag=materializeFlag(f);
    REQUIRE(flag->minLevelToFlag==0);
    flag->updateCallLists();
    for(int step=0;step<33;++step) (glob2test::publishCurrentHiringSuggestions(*flag->owner->game), flag->subscribeForFlagingStep());
    REQUIRE(!flag->unitsWorking.empty());
    // Even a stale budget must defer to the actual flag after creation.
    a.budget.tactical_flag_level=2;
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_flag_level==1);
    REQUIRE(a.budget.tactical_target_gid==target->gid);
    a.control_offense(c);
    REQUIRE(a.tactical_mission.flagId==flagId);
}

static void minimumForceGate()
{
    for(int warriors:{3,4}) {
        Fixture f;
        f.building(10,10,0);
        auto target=f.building(35,30,1);
        for(int i=0;i<warriors;++i) f.warrior(15+i,15);
        auto& a=*f.ai; auto& c=a.context; c.initialize(); f.remember(target);
        a.plan_offense(c);
        REQUIRE(a.offense_diagnostics.eligibleWarriors==warriors);
        REQUIRE((a.budget.tactical_kind==Tactics::MissionSiege)==(warriors>=4));
        a.control_offense(c);
        REQUIRE((a.tactical_mission.flagId>=0)==(warriors>=4));
        REQUIRE(c.buildingOrders.empty()==(warriors<4));
    }
}

static void barracksAreFilledBeforeAttacking()
{
    for(int warriors:{6,8}) {
        Fixture f;
        f.building(10,10,0);
        auto barracks=f.building(14,10,0,"barracks",1);
        barracks->maxUnitInside=4;
        auto target=f.building(35,30,1);
        std::vector<Unit*> army;
        for(int i=0;i<warriors;++i) army.push_back(f.warrior(15+i,15));
        auto& a=*f.ai; auto& c=a.context; c.initialize(); f.remember(target);
        a.plan_offense(c);
        REQUIRE(a.offense_diagnostics.openTrainingSlots==4);
        // Six warriors leave only two beyond the barracks; eight leave four.
        REQUIRE((a.budget.tactical_kind==Tactics::MissionSiege)==(warriors==8));
        if(warriors==8) {
            REQUIRE(a.budget.tactical_requested_force==4);
            a.control_offense(c);
            REQUIRE(a.tactical_mission.requestedForce==4);
            // Two warriors enter training: the flag gives up two seats to them.
            barracks->unitsInside.push_back(army[0]); barracks->unitsInside.push_back(army[1]);
            a.plan_offense(c);
            REQUIRE(a.budget.tactical_requested_force==6); // 8 eligible - 2 open slots
            c.managementOrders.clear();
            a.control_offense(c);
            REQUIRE((a.tactical_mission.requestedForce==6 && assigned(c,a.tactical_mission.flagId,6)));
        }
    }
}

static void unusableTrainingDoesNotBlockAttacks()
{
    for(int untrained:{0,2,4}) {
        Fixture f;f.building(10,10,0);
        auto target=f.building(35,30,1);
        auto low=f.building(14,10,0,"barracks");low->maxUnitInside=4;
        auto high=f.building(14,30,0,"barracks",1);high->maxUnitInside=2;
        for(int i=0;i<4;++i)f.warrior(20+i,20,3);
        for(int i=0;i<untrained;++i)f.warrior(20+i,22,1);
        auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);
        a.plan_offense(c);
        REQUIRE(a.offense_diagnostics.openTrainingSlots==std::min(2,untrained));
        REQUIRE(a.budget.tactical_kind==Tactics::MissionSiege);
        REQUIRE(a.budget.tactical_requested_force==4+untrained-std::min(2,untrained));
    }
}

static void trainingReservationsMatchDifferentLevels()
{
    Fixture f;f.building(10,10,0);
    auto target=f.building(35,30,1);
    // The first trainee fits either school of combat; the second only fits
    // the higher level. Reassigning the first must preserve both reservations.
    auto high=f.building(14,10,0,"barracks",1);high->maxUnitInside=1;
    auto low=f.building(14,30,0,"barracks");low->maxUnitInside=1;
    f.warrior(20,20,0);f.warrior(21,20,1);
    for(int i=0;i<4;++i)f.warrior(22+i,20,3);
    auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);
    a.strategy.tactics.flag_minimum_level=1;
    a.plan_offense(c);
    REQUIRE(a.offense_diagnostics.openTrainingSlots==2);
    REQUIRE(a.budget.tactical_requested_force==4);
}

static void foodPostureDoesNotVetoCombat()
{
    Fixture f;
    f.building(10,10,0);
    auto target=f.building(35,30,1);
    for(int i=0;i<4;++i) f.warrior(15+i,15);
    auto& a=*f.ai; auto& c=a.context; c.initialize(); f.remember(target);
    a.snapshot.population=100;
    a.snapshot.workers=1;
    a.snapshot.critical_food=20;
    a.trends.population=-100;
    a.trends.food_pressure=100;
    a.strategy.emergencies.food_enabled=true;
    a.strategy.emergencies.food_critical_percent=20;
    REQUIRE(a.severe_food_emergency());
    a.budget.food_emergency=true;
    for(auto posture:{Maxima::PostureExpand,Maxima::PostureDevelop,
            Maxima::PostureRecover,Maxima::PostureDefend,Maxima::PostureCampaign}) {
        a.posture=posture;
        a.plan_offense(c);
        REQUIRE(a.budget.tactical_kind==Tactics::MissionSiege);
    }
    a.control_offense(c);
    REQUIRE(a.tactical_mission.flagId>=0);
    // A colony emergency is the one thing that recalls the army.
    a.strategy.emergencies.colony_enabled=true;
    a.snapshot.visible_colony_threat=a.strategy.emergencies.colony_threat_threshold;
    REQUIRE(a.severe_colony_emergency());
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_kind==Tactics::MissionNone);
    a.control_offense(c);
    REQUIRE((a.tactical_mission.flagId<0 && a.attack_flags.empty()));
}

static void sealedTargetOpensRoute()
{
    for(bool sealed:{false,true}) for(bool labor:{false,true}) {
        Fixture f; f.building(10,10,0);
        auto survivor=f.building(35,30,2);
        for(int i=0;i<12;++i) f.warrior(6+i,6)->setPerformance(SWIM,0);
        // A ring of wood seals the target: neither walkers nor swimmers can pass.
        if(sealed) for(int y=27;y<=37;++y) for(int x=32;x<=42;++x)
            if(x==32||x==42||y==27||y==37) f.game.map.setResourceByIndex(x,y,WOOD,1);
        auto& a=*f.ai; auto& c=a.context;
        c.initialize(); f.remember(survivor);
        a.strategy.tactics.dig_out_enabled=true;
        a.budget.attack_clearing_workers=labor ? 10 : 0;
        a.opponents[2].alive=true; a.opponents[2].known_buildings=1;
        a.opponents[2].score=100;
        a.plan_offense(c);
        if(sealed) {
            REQUIRE(a.budget.tactical_kind==Tactics::MissionNone);
            REQUIRE(a.budget.tactical_dig_out_team==(labor ? 2 : -1));
            REQUIRE(a.offense_diagnostics.rejections["no_route"]==1);
        } else {
            REQUIRE(a.budget.tactical_kind==Tactics::MissionSiege);
            REQUIRE(a.budget.tactical_target_team==2);
        }
    }
}

static void offenseFollowsDestroyedTargets()
{
    Fixture f;
    f.building(10,10,0);
    f.islands();
    for(int i=0;i<4;++i) {
        auto unit=f.warrior(6+i,6);
        unit->level[SWIM]=1;
        unit->setPerformance(SWIM,1);
    }
    auto first=f.building(30,30,1);
    auto next=f.building(40,40,1);
    auto& a=*f.ai; auto& c=a.context; c.initialize();
    a.snapshot.swimming_warriors=4;
    f.remember(first); f.remember(next);
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_kind==Tactics::MissionSiege);
    REQUIRE(a.budget.tactical_target_gid==first->gid); // Nearer, same value.
    a.control_offense(c);
    const int flagId=a.tactical_mission.flagId;
    REQUIRE((flagId>=0 && a.campaign.state==Maxima::CampaignActive));
    REQUIRE(a.attack_flag_targets[flagId]==first->gid);
    // A better target within the margin does not move the flag.
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_target_gid==first->gid);
    c.managementOrders.clear();
    a.control_offense(c);
    for(auto order:c.managementOrders)
        REQUIRE(!dynamic_cast<Management::ChangeFlagPosition*>(order.get()));
    // Once the dwell has passed, a quarantined target hands the flag to the
    // next building without tearing the flag down.
    a.attack_target_quarantine_until[first->gid]=a.timer+1000;
    a.timer+=a.strategy.tactics.dwell_ticks;
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_target_gid==next->gid);
    c.managementOrders.clear();
    a.control_offense(c);
    REQUIRE((a.tactical_mission.flagId==flagId && a.tactical_mission.targetGid==next->gid));
    REQUIRE(a.campaign.buildings_destroyed==0); // The first building still stands.
    bool moved=false;
    for(auto order:c.managementOrders)
        if(auto move=dynamic_cast<Management::ChangeFlagPosition*>(order.get()))
            moved|=move->x==a.budget.tactical_target_x && move->y==a.budget.tactical_target_y;
    REQUIRE(moved);
    // Destruction is credited when recon no longer remembers the flag's target.
    const int nextGid=next->gid;
    next->kill();
    f.game.teams[1]->syncStep();
    a.reconnaissance.beginObservation(a.timer,{1});
    a.reconnaissance.confirmBuildingAbsent(1,nextGid);
    a.reconnaissance.finishObservation();
    REQUIRE(!a.reconnaissance.opponent(1)->buildings.count(nextGid));
    a.budget.tactical_kind=Tactics::MissionSiege;
    a.budget.tactical_target_team=1;
    a.budget.tactical_target_gid=first->gid;
    a.budget.tactical_target_x=31; a.budget.tactical_target_y=31;
    a.budget.tactical_requested_force=a.strategy.military.attack_unit_cap;
    c.managementOrders.clear();
    a.control_offense(c);
    REQUIRE((a.campaign.buildings_destroyed==1 && a.tactical_mission.targetGid==first->gid));
    // Without any remembered target the flag comes down.
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_kind==Tactics::MissionNone);
    a.control_offense(c);
    REQUIRE((a.tactical_mission.flagId<0 && a.campaign.state==Maxima::CampaignIdle));
}

static void stalledTargetIsQuarantined()
{
    Fixture f;
    f.building(10,10,0);
    auto target=f.building(35,30,1);
    auto flag=f.building(36,31,0,"warflag");
    std::vector<Unit*> army;
    for(int i=0;i<4;++i) { army.push_back(f.warrior(35+i%2,32+i/2)); f.attach(army.back(),flag); }
    auto& a=*f.ai; auto& c=a.context; c.initialize(); f.remember(target);
    auto& mission=a.tactical_mission;
    mission.kind=Tactics::MissionSiege; mission.phase=Tactics::PhaseEngage;
    mission.flagId=f.id(flag); mission.targetTeam=1; mission.targetGid=target->gid;
    mission.targetX=c.player->map->normalizeX(target->posX+target->type->width/2);
    mission.targetY=c.player->map->normalizeY(target->posY+target->type->height/2);
    Tactics::Wave wave;
    wave.flagId=mission.flagId; wave.phase=Tactics::WaveAdvance;
    wave.requestedForce=4; wave.targetX=mission.targetX; wave.targetY=mission.targetY;
    wave.progressTick=a.timer;
    a.offense_waves.push_back(wave);
    mission.lastTargetHp=target->hp;
    mission.lastProgressTick=a.timer-a.strategy.tactics.stall_ticks;
    target->seenByMask|=f.player.team->me;
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_target_gid==target->gid); // Same target keeps the flag.
    a.control_offense(c);
    REQUIRE(a.attack_target_quarantine_until.count(target->gid));
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_kind==Tactics::MissionNone);
    REQUIRE(a.offense_diagnostics.rejections["quarantined"]==1);
    a.control_offense(c);
    REQUIRE(a.tactical_mission.flagId<0);
    // The fixture flag never actually disappears; release its warriors by hand.
    for(auto unit:army) { unit->attachedBuilding=NULL; unit->activity=Unit::ACT_RANDOM; }
    flag->unitsWorking.clear();
    a.timer=a.attack_target_quarantine_until[target->gid];
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_target_gid==target->gid);
}

static void raidsOutscoreDistantBuildings()
{
    Fixture f;
    f.building(10,10,0);
    auto target=f.building(50,50,1);
    for(int i=0;i<4;++i) f.warrior(15+i,15);
    auto& a=*f.ai; auto& c=a.context; c.initialize(); f.remember(target);
    a.strategy.raiding.enabled=true;
    a.tactics.beginObservation(a.timer);
    for(int i=0;i<4;++i)
        a.tactics.observeWorker(Tactics::WorkerSighting(100+i,1,20+i,20,a.timer,true,true,4));
    Tactics::RaidRules rules; rules.width=rules.height=64; rules.tick=a.timer;
    rules.workerWeight=a.strategy.raiding.worker_weight;
    a.tactics.finishObservation(rules);
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_kind==Tactics::MissionRaid);
    REQUIRE((a.budget.tactical_target_gid==-1 && a.budget.tactical_target_team==1));
    a.control_offense(c);
    REQUIRE((a.tactical_mission.kind==Tactics::MissionRaid && a.campaign.state==Maxima::CampaignActive));
    REQUIRE(a.offense_waves.size()==1);
    // Once the workers vanish the flag moves on to the building.
    a.tactics.beginObservation(a.timer);
    a.tactics.finishObservation(rules);
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_kind==Tactics::MissionSiege);
}

static void offensiveControlSwitches()
{
    // Identical combat-ready worlds: only the requested switch changes.
    for(bool parent:{false,true}) for(bool siege:{false,true}) for(bool eligible:{false,true})
    {
        Fixture f;
        f.building(10,10,0);
        auto target=f.building(35,30,1);
        if(eligible) for(int i=0;i<4;++i) f.warrior(15+i,15);
        auto& a=*f.ai; auto& c=a.context;
        c.initialize(); f.remember(target);
        a.strategy.tactics.enabled=parent;
        a.strategy.tactics.siege_enabled=siege;
        a.finalize_director_plan(c);
        a.plan_offense(c);
        REQUIRE((a.budget.tactical_kind==Tactics::MissionSiege)==(parent && siege && eligible));
        a.control_offense(c);
        REQUIRE((a.tactical_mission.kind==Tactics::MissionSiege)==(parent && siege && eligible));
        if(parent && siege && eligible) REQUIRE(!c.buildingOrders.empty());
        else REQUIRE(c.buildingOrders.empty());
    }
    for(bool enabled:{false,true}) for(bool eligible:{false,true})
    {
        Fixture f;
        f.building(10,10,0); f.building(35,30,1);
        auto& a=*f.ai; auto& c=a.context;
        c.initialize();
        // Explorer campaigns require prestige, trained explorers and a hostile target.
        a.snapshot.prestige=eligible ? 1 : 0;
        a.snapshot.trained_explorers=30;
        a.snapshot.alive_enemies=1;
        a.strategy.explorer_campaign.enabled=enabled;
        a.strategy.emergencies.colony_enabled=false;
        a.target=1;
        auto enemy=f.game.addUnit(35,35,1,WARRIOR,0,0,0,0);
        REQUIRE(enemy);
        glob2test::withMaximaObservation(a.context,[&]() -> decltype(auto) {return a.allocate_resources(a.context);});
        a.finalize_director_plan(c);
        REQUIRE(a.budget.explorer_campaign_active==(enabled && eligible));
        c.buildingOrders.clear(); c.managementOrders.clear();
        a.compute_explorer_flag_attack_positioning(c);
        REQUIRE(c.buildingOrders.empty()!= (enabled && eligible));
    }
    {
        Fixture f;
        auto flag=f.building(20,20,0,"warflag");
        auto& a=*f.ai; auto& c=a.context; c.initialize();
        a.attack_flags.push_back(f.id(flag));
        a.tactical_mission.flagId=f.id(flag);
        a.strategy.tactics.enabled=false;
        a.strategy.explorer_campaign.enabled=false;
        glob2test::withMaximaObservation(a.context,[&]() -> decltype(auto) {return a.allocate_resources(a.context);});
        a.finalize_director_plan(c);
        a.control_offense(c);
        REQUIRE(a.attack_flags.empty());
        bool removed=false;
        for(auto order:c.managementOrders)
            removed|=dynamic_cast<Management::RetireAttraction*>(order.get())!=nullptr;
        REQUIRE(removed);
        REQUIRE(!a.budget.explorer_campaign_active);
    }
    std::cout << "offensive controls: tactics/siege eligible, ineligible, parent-disabled; explorer eligible/ineligible; inherited flag removal PASS\n";
}

static void fittedForceUsesOnlyVisibleUnits()
{
    Fixture f;
    f.building(10,10,0);f.building(35,30,1);
    auto& a=*f.ai;auto& c=a.context;c.initialize();
    f.game.map.unsetMapDiscovered();
    std::fill(f.game.map.fogOfWarA.begin(),f.game.map.fogOfWarA.end(),0);
    std::fill(f.game.map.fogOfWarB.begin(),f.game.map.fogOfWarB.end(),0);
    Unit* seen=f.game.addUnit(30,30,1,WARRIOR,1,0,0,0);
    REQUIRE(seen);f.game.map.setMapDiscovered(30,30,f.player.team->me);
    a.update_reconnaissance(c);
    REQUIRE(a.force_beliefs.count(1));
    const auto baseline=a.force_beliefs.at(1);
    REQUIRE(baseline.features[ForceModel::VisibleWarriors]==1);
    // Adding hidden forces cannot affect any input or prediction.
    REQUIRE(f.game.addUnit(50,50,1,WARRIOR,3,0,0,0));
    REQUIRE(f.game.addUnit(51,50,1,WORKER,0,0,0,0));
    a.force_beliefs.clear();a.update_reconnaissance(c);
    const auto& hidden=a.force_beliefs.at(1);
    for(int i=0;i<ForceModel::FeatureCount;++i) REQUIRE(hidden.features[i]==baseline.features[i]);
    for(int t=0;t<ForceModel::TargetCount;++t)
        for(int q=0;q<ForceModel::QuantileCount;++q)
            REQUIRE(hidden.prediction.values[t][q]==baseline.prediction.values[t][q]);
    REQUIRE(a.reconnaissance.opponent(1)->estimatedWarriors==hidden.prediction.rounded(ForceModel::Warriors));
    a.sample_reconnaissance_forces(c);
    REQUIRE(a.reconnaissance.opponent(1)->estimatedWarriors==hidden.prediction.rounded(ForceModel::Warriors));
    a.update_opponent_models(c);
    REQUIRE(a.opponents[1].estimated_warriors==a.reconnaissance.opponent(1)->estimatedWarriors);
    a.strategy.reconnaissance.force_memory_enabled=false;
    a.reconnaissance.configure(10000,2500,2500,false);
    a.sample_reconnaissance_forces(c);
    REQUIRE(a.reconnaissance.opponent(1)->estimatedWarriors==1);
}

static void retirementPreservesIndependentTraining()
{
    for(int service:{0,1,2}) {
        Fixture f;
        const int typeId=f.game.buildingsTypes.getTypeNum("warflag",0,false);
        CAPTURE(service);
        auto snapshot=nlohmann::json::parse(f.game.buildingsTypes.snapshotJson());
        auto& variant=snapshot["variants"][typeId];
        if(service==1) {
            variant["properties"]["maxUnitInside"]=1;
            variant["semantics"]["admittedUnitMask"]=1u<<WARRIOR;
            variant["semantics"]["training"]["armor"]={{"enabled",true},{"unitMask",1u<<WARRIOR},{"targetLevel",1},{"duration",32},{"cost",nlohmann::json::object()}};
        }
        if(service==2) {
            variant["semantics"]["market"]["suppliesDirectStock"]=true;
            variant["semantics"]["market"]["suppliesDirectStockMaterials"]={"wood"};
            variant["properties"]["maxMaterial"][WOOD]=8;
        }
        f.game.buildingsTypes.loadSnapshotJson(snapshot.dump());
        f.game.configureBuildingCatalog();
        auto* building=f.building(20,20,0,"warflag");
        auto& context=f.ai->context;context.initialize();
        ([&]{auto observation=context.scopeOwnerObservation();return context.cancel_or_destroy_building(f.id(building),1u<<WARRIOR);}());
        REQUIRE(context.managementOrders.size()==1);
        auto* retirement=dynamic_cast<Management::RetireAttraction*>(context.managementOrders.front().get());
        REQUIRE(retirement);
        glob2test::withMaximaObservation(context,[&]{retirement->modify(context);});
        if(service!=0) {
            REQUIRE(context.orders.empty());
            REQUIRE(f.player.team->myBuildings[::Building::GIDtoID(building->gid)]==building);
        } else {
            REQUIRE(context.orders.size()==1);
            REQUIRE(dynamic_cast<OrderDelete*>(context.orders.front().get()));
        }
    }
}

static void retainedAttractionCompletesSavedMissions()
{
    for(int kind:{0,1,2}) {
        CAPTURE(kind);Fixture f;
        const int type=f.game.buildingsTypes.getTypeNum("warflag",0,false);
        auto snapshot=nlohmann::json::parse(f.game.buildingsTypes.snapshotJson());auto& variant=snapshot["variants"][type];
        if(kind==0) {
            variant["properties"]["maxUnitInside"]=1;
            variant["semantics"]["healing"]={{"enabled",true},{"unitMask",7},{"duration",32},{"cost",nlohmann::json::object()}};
        }
        if(kind==1) {
            variant["semantics"]["occupiesGround"]=true;
            variant["properties"]["hpMax"]=100;variant["properties"]["hpInit"]=100;
        }
        if(kind==2) variant["properties"]["zonable"][EXPLORER]=1;
        f.game.buildingsTypes.loadSnapshotJson(snapshot.dump());f.game.configureBuildingCatalog();
        f.building(10,10,0);auto* target=f.building(35,30,1);auto* flag=f.building(20,20,0,"warflag");
        for(int i=0;i<20;++i)f.warrior(2+i%5,2+i/5,3);
        auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);const int id=f.id(flag);
        a.attack_flags.push_back(id);a.defense_flags.push_back(id);a.explorer_attack_flags.push_back(id);
        Management::RetireAttraction retire(id,1u<<WARRIOR);{auto observation=c.scopeOwnerObservation();retire.modify(c);}
        CHECK(([&]{auto observation=c.scopeOwnerObservation();return c.attraction_retired_or_destroyed(id,1u<<WARRIOR);}()));
        CHECK_FALSE(([&]{auto observation=c.scopeOwnerObservation();return c.attraction_retired_or_destroyed(id,1u<<EXPLORER);}()));
        if(kind==1) {REQUIRE(c.orders.size()==1);CHECK(c.orders.front()->getOrderType()==ORDER_MODIFY_BUILDING);}
        else CHECK(c.orders.empty());
        for(auto event:{RuntimeEvent::AttackFinished,RuntimeEvent::GuardFlagDeleted}) {
            auto* notify=new Management::Notify(RuntimeEvent(event,id));
            notify->add_condition(new Conditions::AttractionRetiredOrDestroyed(id,1u<<WARRIOR));c.add_management_order(notify);
        }
        auto* explorer=new Management::Notify(RuntimeEvent(RuntimeEvent::ExplorerAttackFlagDeleted,id));
        explorer->add_condition(new Conditions::AttractionRetiredOrDestroyed(id,1u<<EXPLORER));c.add_management_order(explorer);
        auto* memory=new GAGCore::MemoryStreamBackend;GAGCore::BinaryOutputStream output(memory);a.save(&output);output.flush();const auto bytes=memory->takeContents();
        GAGCore::BinaryInputStream input(new GAGCore::MemoryStreamBackend(bytes.data(),bytes.size()));input.seekFromStart(0);
        Maxima restored(&f.player);REQUIRE(restored.load(&input,&f.player,VERSION_MINOR));
        struct EventForwarder : RuntimeAI {
            Maxima& ai;explicit EventForwarder(Maxima& ai):ai(ai) {}
            void tick(Context&) override {}
            void handle_event(Context& context,const RuntimeEvent& event) override {ai.handle_event(context,event);}
        } events(restored);
        auto& resumed=restored.context;resumed.activeAI=&events;
        CHECK(([&]{auto observation=resumed.scopeOwnerObservation();return resumed.attraction_retired_or_destroyed(id,1u<<WARRIOR);}()));resumed.update_management_orders();
        CHECK(restored.attack_flags.empty());CHECK(restored.defense_flags.empty());CHECK(restored.explorer_attack_flags.size()==1);
        REQUIRE(flag->buildingState==::Building::ALIVE);
        restored.plan_offense(resumed);restored.control_offense(resumed);
        REQUIRE_FALSE(resumed.buildingOrders.empty());
        CHECK(resumed.buildingOrders.front()->id!=id);
        CHECK(resumed.begin_attraction(id,1u<<WARRIOR));
        CHECK_FALSE(([&]{auto observation=resumed.scopeOwnerObservation();return resumed.attraction_retired_or_destroyed(id,1u<<WARRIOR);}()));
        {
            auto* again=new GAGCore::MemoryStreamBackend;GAGCore::BinaryOutputStream savedAgain(again);resumed.save(&savedAgain);savedAgain.flush();const auto state=again->takeContents();
            GAGCore::BinaryInputStream reloaded(new GAGCore::MemoryStreamBackend(state.data(),state.size()));reloaded.seekFromStart(0);REQUIRE(resumed.load(&reloaded,VERSION_MINOR));
            CHECK_FALSE(([&]{auto observation=resumed.scopeOwnerObservation();return resumed.attraction_retired_or_destroyed(id,1u<<WARRIOR);}()));
        }
        Management::RetireAttraction secondRetirement(id,1u<<WARRIOR);glob2test::withMaximaObservation(resumed,[&]{secondRetirement.modify(resumed);});
        CHECK(([&]{auto observation=resumed.scopeOwnerObservation();return resumed.attraction_retired_or_destroyed(id,1u<<WARRIOR);}()));
        if(kind==2) {
            Management::RetireAttraction explorerRetirement(id,1u<<EXPLORER);glob2test::withMaximaObservation(resumed,[&]{explorerRetirement.modify(resumed);});resumed.update_management_orders();
            CHECK(restored.explorer_attack_flags.empty());
        }
    }
}

static void unavailableAttractionHasNoPlacement()
{
    Fixture f;
    auto snapshot=nlohmann::json::parse(f.game.buildingsTypes.snapshotJson());
    for(auto& variant:snapshot["variants"]) variant["properties"]["zonable"][WARRIOR]=0;
    f.game.buildingsTypes.loadSnapshotJson(snapshot.dump());
    f.game.configureBuildingCatalog();
    Construction::BuildingOrder order(AIMaximaBuildings::WarriorAttraction,4);
    bool complete=false;
    const auto result=glob2test::withMaximaObservation(f.ai->context,[&]{return order.find_location(f.ai->context,1,complete);});
    REQUIRE(complete);
    REQUIRE_FALSE(result.found);
    REQUIRE(glob2test::withMaximaObservation(f.ai->context,[&]{return f.ai->context.issue_building_at(-1,4,20,20);})==-1);
    REQUIRE(f.ai->context.orders.empty());
}

static void fittedHistorySurvivesSave()
{
    Fixture f;f.building(10,10,0);f.building(35,30,1);
    auto& a=*f.ai;a.context.initialize();
    int64_t observation[ForceModel::ObservationFeatures]={12,20,0,0,0,2,40,800,9,3,70,40,1000};
    auto& before=a.force_beliefs[1];before.observe(observation);
    observation[ForceModel::Tick]=2200;observation[ForceModel::VisibleWarriors]=9;
    before.observe(observation);before.forecast(2400);a.timer=2400;
    auto* storage=new GAGCore::MemoryStreamBackend;
    GAGCore::BinaryOutputStream output(storage);a.save(&output);
    const std::string bytes(storage->getBuffer(),storage->getPosition());
    GAGCore::BinaryInputStream input(new GAGCore::MemoryStreamBackend(bytes.data(),bytes.size()));
    input.seekFromStart(0);
    Maxima restored(&f.player);REQUIRE(restored.load(&input,&f.player,VERSION_MINOR));
    auto& after=restored.force_beliefs.at(1);
    REQUIRE(after.initialized);
    for(int i=0;i<ForceModel::FeatureCount;++i) REQUIRE(after.features[i]==before.features[i]);
    for(int t=0;t<ForceModel::TargetCount;++t)
        for(int q=0;q<ForceModel::QuantileCount;++q) REQUIRE(after.prediction.values[t][q]==before.prediction.values[t][q]);
    observation[ForceModel::Tick]=2600;after.observe(observation);before.observe(observation);
    REQUIRE(after.features[ForceModel::Tick]==2200); // Cadence also survives loading.
    observation[ForceModel::Tick]=3400;after.observe(observation);before.observe(observation);
    after.forecast(3600);before.forecast(3600);
    for(int i=0;i<ForceModel::FeatureCount;++i) REQUIRE(after.features[i]==before.features[i]);
    for(int t=0;t<ForceModel::TargetCount;++t)
        for(int q=0;q<ForceModel::QuantileCount;++q) REQUIRE(after.prediction.values[t][q]==before.prediction.values[t][q]);
}

static void fittedPowerControlsAttackGate()
{
    Fixture f;
    f.building(10,10,0);auto target=f.building(35,30,1);
    for(int i=0;i<8;++i) f.warrior(15+i,15);
    auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);
    a.opponents[1].alive=true;a.opponents[1].estimated_warriors=1;
    auto& belief=a.force_beliefs[1];belief.initialized=true;
    belief.prediction.values[ForceModel::Power][ForceModel::Median]=1000000*ForceModel::Scale;
    a.plan_offense(c);
    REQUIRE(a.offense_diagnostics.gate.find("not strong enough")!=std::string::npos);
    belief.prediction.values[ForceModel::Power][ForceModel::Median]=ForceModel::Scale;
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_kind==Tactics::MissionSiege);
    // Without force memory, only observed defenders constrain the attack.
    a.strategy.reconnaissance.force_memory_enabled=false;
    belief.prediction.values[ForceModel::Power][ForceModel::Median]=1000000*ForceModel::Scale;
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_kind==Tactics::MissionSiege);
}

}

TEST_SUITE("Maxima.Combat")
{
	TEST_CASE("retained attraction completes saved missions") { glob2test::HeadlessGlobals globals; combat_regressions::retainedAttractionCompletesSavedMissions(); }
	TEST_CASE("retirement preserves independent training") { glob2test::HeadlessGlobals globals; combat_regressions::retirementPreservesIndependentTraining(); }
	TEST_CASE("unavailable attraction has no placement") { glob2test::HeadlessGlobals globals; combat_regressions::unavailableAttractionHasNoPlacement(); }
	TEST_CASE("fitted force uses only visible units") { glob2test::HeadlessGlobals globals; combat_regressions::fittedForceUsesOnlyVisibleUnits(); }
	TEST_CASE("fitted power controls attack gate") { glob2test::HeadlessGlobals globals; combat_regressions::fittedPowerControlsAttackGate(); }
	TEST_CASE("fitted history survives save") { glob2test::HeadlessGlobals globals; combat_regressions::fittedHistorySurvivesSave(); }
	TEST_CASE("nearby warriors count as rallied") { glob2test::HeadlessGlobals globals; combat_regressions::nearbyWarriorsCountAsRallied(); }
	TEST_CASE("rally rejects blocked ground") { glob2test::HeadlessGlobals globals; combat_regressions::rallyRejectsBlockedGround(); }
	TEST_CASE("rally assembles by movement") { glob2test::HeadlessGlobals globals; combat_regressions::rallyAssemblesByMovement(); }
	TEST_CASE("wave assembly and pipeline") { glob2test::HeadlessGlobals globals; combat_regressions::waveAssemblyAndPipeline(); }
	TEST_CASE("wave delivery fallback") { glob2test::HeadlessGlobals globals; combat_regressions::waveDeliveryFallback(); }
	TEST_CASE("wave assembly fallback") { glob2test::HeadlessGlobals globals; combat_regressions::waveAssemblyFallback(); }
	TEST_CASE("streaming scales with army") { glob2test::HeadlessGlobals globals; combat_regressions::streamingScalesWithArmy(); }
	TEST_CASE("small wave keeps recruiting") { glob2test::HeadlessGlobals globals; combat_regressions::smallWaveKeepsRecruiting(); }
	TEST_CASE("defense wraps building origins") { glob2test::HeadlessGlobals globals; combat_regressions::defenseWrapsBuildingOrigins(); }
	TEST_CASE("defense coverage") { glob2test::HeadlessGlobals globals; combat_regressions::defenseCoverage(); }
	TEST_CASE("warrior eligibility") { glob2test::HeadlessGlobals globals; combat_regressions::warriorEligibility(); }
	TEST_CASE("untrained warriors fight at level one") { glob2test::HeadlessGlobals globals; combat_regressions::untrainedWarriorsFightAtLevelOne(); }
	TEST_CASE("minimum force gate") { glob2test::HeadlessGlobals globals; combat_regressions::minimumForceGate(); }
	TEST_CASE("lowered flag level survives review") { glob2test::HeadlessGlobals globals; combat_regressions::loweredFlagLevelSurvivesReview(); }
	TEST_CASE("barracks are filled before attacking") { glob2test::HeadlessGlobals globals; combat_regressions::barracksAreFilledBeforeAttacking(); }
	TEST_CASE("unusable training does not block attacks") { glob2test::HeadlessGlobals globals; combat_regressions::unusableTrainingDoesNotBlockAttacks(); }
	TEST_CASE("training reservations match different levels") { glob2test::HeadlessGlobals globals; combat_regressions::trainingReservationsMatchDifferentLevels(); }
	TEST_CASE("food posture does not veto combat") { glob2test::HeadlessGlobals globals; combat_regressions::foodPostureDoesNotVetoCombat(); }
	TEST_CASE("sealed target opens route") { glob2test::HeadlessGlobals globals; combat_regressions::sealedTargetOpensRoute(); }
	TEST_CASE("offense follows destroyed targets") { glob2test::HeadlessGlobals globals; combat_regressions::offenseFollowsDestroyedTargets(); }
	TEST_CASE("stalled target is quarantined") { glob2test::HeadlessGlobals globals; combat_regressions::stalledTargetIsQuarantined(); }
	TEST_CASE("raids outscore distant buildings") { glob2test::HeadlessGlobals globals; combat_regressions::raidsOutscoreDistantBuildings(); }
	TEST_CASE("economic recovery preserves military budget") { glob2test::HeadlessGlobals globals; combat_regressions::economicRecoveryPreservesMilitaryBudget(); }
	TEST_CASE("forbidden defense zones") { glob2test::HeadlessGlobals globals; combat_regressions::forbiddenDefenseZones(); }
	TEST_CASE("defense deadband preserves coverage") { glob2test::HeadlessGlobals globals; combat_regressions::defenseDeadbandPreservesCoverage(); }
	TEST_CASE("offensive control switches") { glob2test::HeadlessGlobals globals; combat_regressions::offensiveControlSwitches(); }
}

TEST_SUITE("Maxima.Combat")
{
    TEST_CASE("unlearned combat estimates use configured tables at the shared strategy level")
    {
        glob2test::HeadlessGlobals globals;
        constexpr int stockRates[]={36,64,110,168};
        for (int variant=0;variant<3;++variant) {
            glob2test::HeadlessGame world({.clearImmobile=true,.loadDefaultRace=true,.header=true});
            auto snapshot=nlohmann::json::parse(UnitCatalog::builtins()->serialize());
            if (variant==1)
                for (auto& level:snapshot["units"][WARRIOR]["levels"]) {
                    level["performance"][ATTACK_SPEED]=level["performance"][ATTACK_SPEED].get<int>()*2;
                    level["performance"][ATTACK_STRENGTH]=level["performance"][ATTACK_STRENGTH].get<int>()+4;
                    level["performance"][ARMOR]=5;
                }
            if (variant==2) snapshot["units"][WARRIOR]["behaviors"]["melee"]=false;
            world.game.gameHeader.setUnitCatalog(UnitCatalog::deserialize(snapshot.dump()));
            world.game.configureBuildingCatalog();
            auto* live=world.addUnit(WARRIOR,10,10); REQUIRE(live);
            const auto view=AIEngine::AIWorldView::capture(world.game,AIEngine::AIWorldView::captureCatalog(world.game));
            auto unit=*view->unitAtSlot(Unit::GIDfrom(Unit::GIDtoID(live->gid), 0));
            const auto& levels=view->unitCatalog().levels(WARRIOR);
            const int armour=AIMaxima::WorldHelpers::unlearned_reference_armour(*view);
            CHECK(armour==(variant==2?0:variant==1?5:10));
            for (int speedLevel=0;speedLevel<4;++speedLevel)
                for (int strengthLevel=0;strengthLevel<4;++strengthLevel) {
                    unit.level[ATTACK_SPEED]=speedLevel;unit.level[ATTACK_STRENGTH]=strengthLevel;
                    unit.setPerformance(ATTACK_SPEED,variant==2?0:levels[speedLevel].performance[ATTACK_SPEED]);
                    unit.setPerformance(ATTACK_STRENGTH,variant==2?0:levels[strengthLevel].performance[ATTACK_STRENGTH]);
                    const int common=std::min(speedLevel,strengthLevel);
                    const int expected=variant==0?stockRates[common]:variant==2?0:
                        levels[common].performance[ATTACK_SPEED]*(levels[common].performance[ATTACK_STRENGTH]-armour);
                    CHECK(AIMaxima::WorldHelpers::unlearned_warrior_damage_rate(*view,unit,armour)==expected);
                    if(variant!=2)
                        CHECK(AIMaxima::WorldHelpers::detail::unlearned_eligible_damage_rate(*view,unit,armour)==expected);
                }
            const int first=variant==2?0:levels[1].performance[ATTACK_SPEED]*(levels[1].performance[ATTACK_STRENGTH]-armour);
            const int second=variant==2?0:levels[2].performance[ATTACK_SPEED]*(levels[2].performance[ATTACK_STRENGTH]-armour);
            const int reference=(first+second)/2;
            CHECK(AIMaxima::WorldHelpers::unlearned_reference_damage_rate(*view,armour)==reference);
            CHECK(AIMaxima::Labour::attackStrengthSufficient(4LL*reference,4,reference));
            if (reference>0) CHECK_FALSE(AIMaxima::Labour::attackStrengthSufficient(4LL*reference-1,4,reference));
            unit.setPerformance(ATTACK_SPEED,0);
            CHECK(AIMaxima::WorldHelpers::unlearned_warrior_damage_rate(*view,unit,armour)==0);
        }
    }

    TEST_CASE("custom melee remains a reference when built-in combat is disabled")
    {
        glob2test::HeadlessGlobals globals;
        for (bool experimentEnabled:{false,true}) {
            glob2test::HeadlessGame world({.clearImmobile=true,.loadDefaultRace=true,.header=true});
            auto units=nlohmann::json::parse(UnitCatalog::builtins()->serialize());
            auto fighter=units["units"][WARRIOR];fighter["key"]="fixture:reference-fighter";
            fighter["requiredExperiment"]="fixture-reference";
            for(auto& level:fighter["levels"]) {
                level["performance"][ARMOR]=20;
                level["performance"][ATTACK_SPEED]=3;
                level["performance"][ATTACK_STRENGTH]=10;
            }
            units["units"][WARRIOR]["behaviors"]["melee"]=false;
            units["experiments"].push_back({{"key","fixture-reference"},{"label","Fixture reference"},{"help","Test only"}});
            units["units"].push_back(fighter);
            auto catalog=UnitCatalog::deserialize(units.dump());
            world.game.gameHeader.setUnitCatalog(catalog);
            if(experimentEnabled)world.game.gameHeader.getExperiments().set("fixture-reference",true,world.game.gameHeader.catalogExperimentKeys());
            world.game.configureBuildingCatalog();
            const auto view=AIEngine::AIWorldView::capture(world.game,AIEngine::AIWorldView::captureCatalog(world.game));
            const int armour=AIMaxima::WorldHelpers::unlearned_reference_armour(*view);
            CHECK(armour==(experimentEnabled?20:0));
            CHECK(AIMaxima::WorldHelpers::unlearned_reference_damage_rate(*view,armour)==(experimentEnabled?3:0));
        }
    }

    TEST_CASE("offense uses effective mobile recruits and preserves already assigned custom fighters")
    {
        glob2test::HeadlessGlobals globals;
        combat_regressions::Fixture f([](Game& game) {
            auto units=nlohmann::json::parse(UnitCatalog::builtins()->serialize());
            auto denied=units["units"][WARRIOR];denied["key"]="fixture:refuses-recruitment";
            denied["behaviors"]["recruitDefend"]=false;units["units"].push_back(denied);
            auto excluded=units["units"][WARRIOR];excluded["key"]="fixture:excluded-fighter";units["units"].push_back(excluded);
            game.gameHeader.setUnitCatalog(UnitCatalog::deserialize(units.dump()));
            auto buildings=nlohmann::json::parse(game.buildingsTypes.snapshotJson());
            for(std::size_t type=0;type<game.buildingsTypes.size();++type)
                if(game.buildingsTypes.get(type)->runtimeAttractionRoles&4)
                    buildings["variants"][type]["semantics"]["attractionUnits"]["defend"]={"warrior","fixture:refuses-recruitment"};
            game.buildingsTypes.loadSnapshotJson(buildings.dump());game.configureBuildingCatalog();
        });
        f.building(10,10,0);auto* target=f.building(35,30,1);
        auto* flag=f.building(12,10,0,"warflag");
        for(int i=0;i<6;++i)f.warrior(i,0,3);
        auto* inactive=f.warrior(7,0,3);inactive->setPerformance(ATTACK_SPEED,0);
        auto* stationary=f.warrior(8,0,3);stationary->setPerformance(WALK,0); stationary->setPerformance(SWIM,0); stationary->setPerformance(FLY,0);
        auto* denied=f.game.addUnit(9,0,0,3,3,0,0,0);REQUIRE(denied);
        auto* excluded=f.game.addUnit(10,0,0,4,3,0,0,0);REQUIRE(excluded);
        auto& ai=*f.ai;auto& context=ai.context;context.initialize();f.remember(target);
        ai.plan_offense(context);
        CHECK(ai.offense_diagnostics.eligibleWarriors==6);
        f.attach(denied,flag);f.attach(excluded,flag);
        ai.attack_flags.push_back(f.id(flag));
        ai.tactical_mission.flagId=f.id(flag);
        ai.plan_offense(context);
        CHECK(ai.offense_diagnostics.eligibleWarriors==8);
        inactive->setPerformance(ATTACK_SPEED,28);
        ai.plan_offense(context);
        CHECK(ai.offense_diagnostics.eligibleWarriors==9);
    }

    TEST_CASE("active offense credits only returning recipients or continuing members")
    {
        glob2test::HeadlessGlobals globals;
        for(int scenario=0;scenario<7;++scenario) {
            combat_regressions::Fixture f([](Game& game) {
                auto units=nlohmann::json::parse(UnitCatalog::builtins()->serialize());
                auto denied=units["units"][WARRIOR];denied["key"]="fixture:denied-recovery";
                denied["behaviors"]["recruitDefend"]=false;units["units"].push_back(denied);
                auto excluded=units["units"][WARRIOR];excluded["key"]="fixture:excluded-recovery";
                units["units"].push_back(excluded);
                auto stationary=units["units"][WARRIOR];stationary["key"]="fixture:stationary-recovery";
                units["units"].push_back(stationary);
                game.gameHeader.setUnitCatalog(UnitCatalog::deserialize(units.dump()));
                auto buildings=nlohmann::json::parse(game.buildingsTypes.snapshotJson());
                for(std::size_t type=0;type<game.buildingsTypes.size();++type)
                    if(game.buildingsTypes.get(type)->runtimeAttractionRoles&4)
                        buildings["variants"][type]["semantics"]["attractionUnits"]["defend"]=
                            {"warrior","fixture:denied-recovery","fixture:stationary-recovery"};
                game.buildingsTypes.loadSnapshotJson(buildings.dump());game.configureBuildingCatalog();
            });
            f.building(20,20,0);auto* target=f.building(35,30,1);
            auto* flag=f.building(12,10,0,"warflag");
            auto* otherFlag=f.building(16,10,0,"warflag");
            auto* denied=f.game.addUnit(9,0,0,3,3,0,0,0);REQUIRE(denied);
            auto* excluded=f.game.addUnit(10,0,0,4,3,0,0,0);REQUIRE(excluded);
            auto* stationary=f.game.addUnit(scenario==4?12:11,scenario==4?10:0,0,5,3,0,0,0);REQUIRE(stationary);
            stationary->setPerformance(WALK,0); stationary->setPerformance(SWIM,0); stationary->setPerformance(FLY,0);
            for(auto* unit:{denied,excluded,stationary})unit->medical=Unit::MED_DAMAGED;
            auto& ai=*f.ai;auto& context=ai.context;context.initialize();f.remember(target);
            ai.tactical_mission.flagId=f.id(flag);
            if(scenario==1)f.attach(denied,flag); // Current member bypasses changed recruitment policy.
            if(scenario==2) {
                f.attach(excluded,otherFlag);ai.attack_flags.push_back(f.id(otherFlag));
            }
            if(scenario==3 || scenario==4)f.attach(stationary,flag);
            if(scenario==5) {
                auto* stock=f.warrior(15,0,3);stock->medical=Unit::MED_DAMAGED;
                f.attach(stock,otherFlag); // Service transition may retain a different flag.
            }
            if(scenario==6) {
                f.attach(denied,flag);denied->setPerformance(ATTACK_SPEED,0);
            }
            ai.plan_offense(context);
            CHECK(ai.offense_diagnostics.eligibleWarriors==0);
            const bool returns=scenario==1 || scenario==2 || scenario==4 || scenario==5;
            if(returns)CHECK(ai.offense_diagnostics.gate=="open");
            else CHECK(ai.offense_diagnostics.gate==
                "blocked: 0 eligible warriors, 0 training reservations; 0 deployable is below 1");
        }
    }

    TEST_CASE("stationary effective melee triggers local defense while inactive attacks do not")
    {
        glob2test::HeadlessGlobals globals;
        for(bool active:{false,true}) {
            combat_regressions::Fixture f;
            f.building(20,24,0);
            auto* enemy=f.game.addUnit(22,20,1,WARRIOR,1,0,0,0);REQUIRE(enemy);
            enemy->setPerformance(WALK,0); enemy->setPerformance(SWIM,0); enemy->setPerformance(FLY,0);
            if(!active)enemy->setPerformance(ATTACK_SPEED,0);
            f.game.map.setMapExploredByUnit(22,20,1,1,0);
            auto& ai=*f.ai;auto& context=ai.context;context.initialize();
            ai.budget.reactive_defense_enabled=true;ai.budget.reactive_defense_flag_radius=5;
            ai.budget.reactive_defense_unit_cap=10;ai.budget.reactive_defense_advantage_min=3;ai.budget.defense_reserve=30;
            ai.compute_defense_flag_positioning(context);
            CHECK(context.buildingOrders.empty()==!active);
        }
    }

    TEST_CASE("historical combat calibration remains private to imported race tables")
    {
        glob2test::HeadlessGlobals globals;
        glob2test::HeadlessGame world({.clearImmobile=true,.loadDefaultRace=true,.header=true});
        const auto defaults=UnitCatalog::builtins();
        std::vector<std::array<UnitType,NB_UNIT_LEVELS>> levels;
        for (unsigned type=0;type<defaults->size();++type) levels.push_back(defaults->levels(type));
        for (auto& level:levels[WARRIOR]) {
            level.performance[ATTACK_SPEED]*=2;level.performance[ATTACK_STRENGTH]+=4;
        }
        world.game.gameHeader.setUnitCatalog(defaults->withLegacyLevels(levels,425));
        world.game.configureBuildingCatalog();
        auto* live=world.addUnit(WARRIOR,10,10); REQUIRE(live);
        const auto view=AIEngine::AIWorldView::capture(world.game,AIEngine::AIWorldView::captureCatalog(world.game));
        auto unit=*view->unitAtSlot(Unit::GIDfrom(Unit::GIDtoID(live->gid), 0));
        REQUIRE((unit.capabilityFlags&UnitRuntimeTraits::LegacyPerformancePolicies)!=0);
        constexpr int oldRates[]={36,64,110,168};
        for (int level=0;level<4;++level) {
            unit.level[ATTACK_SPEED]=3;unit.level[ATTACK_STRENGTH]=level;
            CHECK(AIMaxima::WorldHelpers::unlearned_warrior_damage_rate(*view,unit,10)==oldRates[level]);
        }
        CHECK(AIMaxima::WorldHelpers::unlearned_reference_damage_rate(*view,10)==87);
    }
}

TEST_SUITE("Maxima.Combat")
{
TEST_CASE("replacement objectives favor the existing flag with wrapping and bounded preference")
{
    glob2test::HeadlessGlobals globals;
    for(bool wrapped:{false,true}) for(bool continuing:{false,true}) for(int weight:{0,4})
    {
        CAPTURE(wrapped);CAPTURE(continuing);CAPTURE(weight);
        combat_regressions::Fixture f;
        f.building(wrapped?20:10,10,0);
        auto* previous=f.building(9,28,1);
        // Insertion order deliberately favors the home-side alternative on ties.
        auto* homeSide=f.building(wrapped?20:14,wrapped?30:18,1);
        auto* nearby=f.building(wrapped?61:32,30,1);
        auto* superior=f.building(29,0,2);
        auto* flag=f.building(wrapped?0:29,wrapped?34:29,0,"warflag");
        for(int i=0;i<4;++i)
        {
            auto* unit=f.warrior((wrapped?0:26)+i,wrapped?35:29);
            if(continuing)f.attach(unit,flag);
        }
        auto& a=*f.ai;auto& c=a.context;c.initialize();
        a.strategy.tactics.flag_minimum_level=1;
        a.strategy.tactics.route_distance_weight=0;
        a.strategy.tactics.flag_proximity_weight=weight;
        a.reconnaissance.beginObservation(a.timer,{1,2});
        for(auto* building:{previous,homeSide,nearby,superior})
            a.reconnaissance.observeBuilding(AIMaxima::Recon::BuildingSighting(building->gid,
                building->owner->teamNumber,building->typeNum,building->posX,building->posY,
                building->type->width,building->type->height,false,a.timer));
        a.reconnaissance.finishObservation();
        a.opponents[1].alive=a.opponents[2].alive=true;
        a.opponents[1].estimated_warriors=a.opponents[2].estimated_warriors=0;
        a.opponents[1].score=100;a.opponents[2].score=0;
        if(continuing)
        {
            a.tactical_mission.flagId=f.id(flag);
            a.tactical_mission.kind=AIMaxima::Tactics::MissionSiege;
            a.tactical_mission.targetTeam=1;a.tactical_mission.targetGid=previous->gid;
            a.tactical_mission.targetX=previous->posX+previous->type->width/2;
            a.tactical_mission.targetY=previous->posY+previous->type->height/2;
            a.tactical_mission.phaseSinceTick=a.timer-5000;
        }
        a.attack_target_quarantine_until[previous->gid]=a.timer+1000;
        a.plan_offense(c);
        REQUIRE(a.budget.tactical_kind==AIMaxima::Tactics::MissionSiege);
        CHECK(a.budget.tactical_target_gid==((continuing && weight)?nearby:homeSide)->gid);
        CHECK(a.offense_diagnostics.flagProximityPenalty==
            ((continuing && weight)?weight*(wrapped?3:4):0));
        if(!continuing)CHECK(a.offense_diagnostics.flagProximityDistance==-1);
        a.attack_target_quarantine_until[nearby->gid]=a.timer+1000;
        a.plan_offense(c);CHECK(a.budget.tactical_target_gid==homeSide->gid);
        a.opponents[2].score=1000;
        a.plan_offense(c);CHECK(a.budget.tactical_target_gid==superior->gid);
    }
}

TEST_CASE("new flag proximity cannot make an unreachable nearby building viable")
{
    glob2test::HeadlessGlobals globals;combat_regressions::Fixture f;f.islands();
    f.building(10,10,0);
    auto* nearby=f.building(26,20,1);auto* reachable=f.building(5,43,1);
    auto* flag=f.building(18,20,0,"warflag");
    for(int i=0;i<4;++i)
    {
        auto* unit=f.warrior(14+i,20);unit->setPerformance(SWIM,0);unit->setPerformance(FLY,0);
        f.attach(unit,flag);
    }
    auto& a=*f.ai;auto& c=a.context;c.initialize();
    a.strategy.tactics.flag_proximity_weight=4;
    a.reconnaissance.beginObservation(a.timer,{1});
    for(auto* building:{nearby,reachable})
        a.reconnaissance.observeBuilding(AIMaxima::Recon::BuildingSighting(building->gid,1,
            building->typeNum,building->posX,building->posY,building->type->width,
            building->type->height,false,a.timer));
    a.reconnaissance.finishObservation();a.opponents[1].alive=true;
    a.tactical_mission.flagId=f.id(flag);a.tactical_mission.kind=AIMaxima::Tactics::MissionSiege;
    a.tactical_mission.targetTeam=1;a.tactical_mission.phaseSinceTick=a.timer-5000;
    a.plan_offense(c);
    REQUIRE(a.budget.tactical_kind==AIMaxima::Tactics::MissionSiege);
    CHECK(a.budget.tactical_target_gid==reachable->gid);
    CHECK(a.offense_diagnostics.rejections["too_few_reachable"]+
        a.offense_diagnostics.rejections["no_route"]>0);
}

TEST_CASE("raid locations use the same preference for the current offensive flag")
{
    glob2test::HeadlessGlobals globals;
    for(int weight:{0,4})
    {
        CAPTURE(weight);combat_regressions::Fixture f;f.building(10,10,0);
        auto* flag=f.building(29,29,0,"warflag");
        for(int i=0;i<4;++i)f.attach(f.warrior(26+i,29),flag);
        auto& a=*f.ai;auto& c=a.context;c.initialize();
        a.strategy.tactics.siege_enabled=false;a.strategy.raiding.enabled=true;
        a.strategy.raiding.route_distance_weight=0;a.strategy.tactics.flag_proximity_weight=weight;
        a.tactical_mission.flagId=f.id(flag);a.tactical_mission.kind=AIMaxima::Tactics::MissionSiege;
        a.tactical_mission.targetTeam=1;a.tactical_mission.phaseSinceTick=a.timer-5000;
        a.tactics.beginObservation(a.timer);
        for(int i=0;i<4;++i)
        {
            a.tactics.observeWorker(AIMaxima::Tactics::WorkerSighting(100+i,1,14+i,20,a.timer,true,true,4));
            a.tactics.observeWorker(AIMaxima::Tactics::WorkerSighting(200+i,1,32+i,30,a.timer,true,true,4));
        }
        AIMaxima::Tactics::RaidRules rules;rules.width=rules.height=64;rules.tick=a.timer;
        rules.workerWeight=a.strategy.raiding.worker_weight;a.tactics.finishObservation(rules);
        REQUIRE(a.tactics.raidCandidates().size()==2);
        a.plan_offense(c);REQUIRE(a.budget.tactical_kind==AIMaxima::Tactics::MissionRaid);
        if(weight)CHECK(a.budget.tactical_target_x>=30);
        else CHECK(a.budget.tactical_target_x<20);
    }
}

TEST_CASE("format188 AI execution keeps ring40 without enabling the new proximity preference")
{
    glob2test::HeadlessGlobals globals;combat_regressions::Fixture f;
    struct PreviousStrategyOutput : GAGCore::BinaryOutputStream
    {
        using BinaryOutputStream::BinaryOutputStream;
        void writeText(const std::string& value,std::string_view name) override
        {
            if(name!="strategy"){BinaryOutputStream::writeText(value,name);return;}
            std::istringstream input(value);std::string item,legacy;
            while(std::getline(input,item,','))if(item.rfind("tactics.flag_proximity_weight=",0))
            {if(!legacy.empty())legacy+=',';legacy+=item;}
            BinaryOutputStream::writeText(legacy,name);
        }
    };
    auto* memory=new GAGCore::MemoryStreamBackend;PreviousStrategyOutput output(memory);
    f.ai->save(&output);output.flush();
    const std::string bytes(memory->getBuffer(),memory->getPosition());
    GAGCore::BinaryInputStream input(new GAGCore::MemoryStreamBackend(bytes.data(),bytes.size()));
    input.seekFromStart(0);
    AIMaxima::Maxima restored(&input,&f.player,188);
    CHECK(restored.strategy.tactics.flag_proximity_weight==0);
    CHECK(restored.strategy.tactics.enemy_commitment==1);
    CHECK(restored.strategy.tactics.arrival_grace_ticks==4000);
    CHECK(restored.strategy.forward_support.inns_enabled);
    CHECK(restored.strategy.forward_support.hospitals_enabled);
    CHECK(restored.strategy.forward_support.distance_tiles==40);
    auto* upgraded=new GAGCore::MemoryStreamBackend;GAGCore::BinaryOutputStream saved(upgraded);
    restored.save(&saved);saved.flush();
    const std::string current(upgraded->getBuffer(),upgraded->getPosition());
    GAGCore::BinaryInputStream reload(new GAGCore::MemoryStreamBackend(current.data(),current.size()));
    reload.seekFromStart(0);
    AIMaxima::Maxima continued(&reload,&f.player,VERSION_MINOR);
    CHECK(AIMaxima::StrategyResolver::canonicalValues(continued.strategy)==
        AIMaxima::StrategyResolver::canonicalValues(restored.strategy));
}

TEST_CASE("enemy commitment follows successive viable objectives and releases exhausted enemies")
{
    glob2test::HeadlessGlobals globals;
    for(int mode:{0,1})
    {
        CAPTURE(mode);combat_regressions::Fixture f;
        f.building(10,10,0);auto* first=f.building(30,30,1);
        auto* successor=f.building(42,30,1);auto* alternative=f.building(35,40,2);
        auto* flag=f.building(24,24,0,"warflag");
        for(int i=0;i<4;++i) f.attach(f.warrior(20+i,20),flag);
        auto& a=*f.ai;auto& c=a.context;c.initialize();
        a.reconnaissance.beginObservation(a.timer,{1,2});
        for(auto* building:{first,successor,alternative})
            a.reconnaissance.observeBuilding(AIMaxima::Recon::BuildingSighting(building->gid,
                building->owner->teamNumber,building->typeNum,building->posX,building->posY,
                building->type->width,building->type->height,false,a.timer));
        a.reconnaissance.finishObservation();
        a.opponents[1].alive=a.opponents[2].alive=true;
        a.opponents[1].score=100;a.opponents[2].score=180;
        a.tactical_mission.flagId=f.id(flag);a.tactical_mission.kind=AIMaxima::Tactics::MissionSiege;
        a.tactical_mission.targetTeam=1;a.tactical_mission.targetGid=first->gid;
        a.tactical_mission.phaseSinceTick=a.timer-a.strategy.tactics.dwell_ticks;
        a.strategy.tactics.enemy_commitment=mode;
        a.attack_target_quarantine_until[first->gid]=a.timer+1000;
        a.plan_offense(c);
        REQUIRE(a.budget.tactical_kind==AIMaxima::Tactics::MissionSiege);
        CHECK(a.budget.tactical_target_team==(mode?1:2));
        if(mode) CHECK(a.budget.tactical_target_gid==successor->gid);
        a.attack_target_quarantine_until[successor->gid]=a.timer+1000;
        a.plan_offense(c);CHECK(a.budget.tactical_target_team==2);
    }
}
TEST_CASE("arrival grace protects a partial delivery and still expires for waves and streaming")
{
    glob2test::HeadlessGlobals globals;
    for(bool streaming:{false,true}) for(int grace:{0,12000})
    {
        CAPTURE(streaming);CAPTURE(grace);combat_regressions::Fixture f;
        f.building(10,10,0);auto* target=f.building(35,30,1);
        auto* flag=f.building(36,31,0,"warflag");
        f.attach(f.warrior(36,32),flag);
        for(int i=0;i<3;++i) f.attach(f.warrior(12+i,12),flag);
        auto& a=*f.ai;auto& c=a.context;c.initialize();f.remember(target);
        a.timer=5000;a.strategy.tactics.arrival_grace_ticks=grace;
        auto& mission=a.tactical_mission;
        mission.kind=AIMaxima::Tactics::MissionSiege;mission.phase=AIMaxima::Tactics::PhaseEngage;
        mission.flagId=f.id(flag);mission.targetTeam=1;mission.targetGid=target->gid;
        mission.targetX=target->posX+target->type->width/2;
        mission.targetY=target->posY+target->type->height/2;
        mission.phaseSinceTick=1000;mission.lastProgressTick=1000;mission.lastTargetHp=target->hp;
        target->seenByMask|=f.player.team->me;
        a.attack_flags={mission.flagId};
        if(streaming) a.failed_waves=4;
        else
        {
            AIMaxima::Tactics::Wave wave;wave.flagId=mission.flagId;
            wave.phase=AIMaxima::Tactics::WaveAdvance;wave.requestedForce=4;
            wave.targetX=mission.targetX;wave.targetY=mission.targetY;wave.progressTick=a.timer;
            a.offense_waves={wave};
        }
        a.plan_offense(c);a.control_offense(c);
        CHECK(bool(a.attack_target_quarantine_until.count(target->gid))==(grace==0));
        if(grace)
        {
            a.timer=mission.phaseSinceTick+grace+a.strategy.tactics.stall_ticks;
            mission.lastProgressTick=a.timer-a.strategy.tactics.stall_ticks;
            a.plan_offense(c);a.control_offense(c);
            CHECK(a.attack_target_quarantine_until.count(target->gid)==1);
        }
    }
}
TEST_CASE("recall telemetry emits numeric byte enums on one complete line")
{
    glob2test::ScopedEnvironment telemetry("GLOB2_MAXIMA_TELEMETRY","1");
    glob2test::HeadlessGlobals globals;combat_regressions::Fixture f;
    f.building(0,0,0);auto* flag=f.building(24,24,0,"warflag");
    auto* warrior=f.warrior(23,24);f.attach(warrior,flag);
    warrior->medical=Unit::MED_FREE;warrior->displacement=Unit::DIS_ATTACKING_AROUND;
    warrior->destinationPurpose=FEED;warrior->underAttackTimer=9;
    auto& a=*f.ai;auto& context=a.context;context.initialize();
    a.tactical_mission.flagId=f.id(flag);a.tactical_mission.kind=AIMaxima::Tactics::MissionSiege;
    glob2test::withMaximaObservation(context,[&]{a.end_offense(context,"test_emergency");});
    int records=0;
    for(const auto& diagnostic:context.bufferedDiagnostics)
        if(diagnostic.text.find("\trecall_local_unit\t")!=std::string::npos)
        {
            ++records;
            CHECK(diagnostic.text.find("\tmedical=0\tdisplacement=10\tactivity=2\tservice=18\t")!=std::string::npos);
            CHECK(diagnostic.text.find("\tunder_attack=9\tgame_tick=")!=std::string::npos);
            CHECK(std::count(diagnostic.text.begin(),diagnostic.text.end(),'\n')==1);
        }
    CHECK(records==1);
}
TEST_CASE("forward support adds independent demands and honors hunger upgrades and peaceful rules")
{
    glob2test::HeadlessGlobals globals;combat_regressions::Fixture f;
    f.building(0,0,0);auto* flag=f.building(24,24,0,"warflag");
    auto& a=*f.ai;auto& c=a.context;c.initialize();glob2test::withMaximaObservation(c,[&]{a.configure_development_planner();});
    a.timer=5000;a.tactical_mission.flagId=f.id(flag);
    a.tactical_mission.kind=AIMaxima::Tactics::MissionSiege;
    a.tactical_mission.targetX=a.tactical_mission.targetY=32;
    a.tactical_mission.phaseSinceTick=0;a.snapshot.warriors=20;a.snapshot.workers=100;
    a.strategy.forward_support.distance_tiles=12;
    a.strategy.forward_support.coverage_distance_tiles=20;
    const auto ordinary=[](const auto& intents) {
        std::vector<std::tuple<int,int,int,int,int>> result;
        for(const auto& i:intents) if(i.purpose!=AIMaximaPlacement::ForwardSupport)
            result.emplace_back(i.buildingType,int(i.purpose),i.unmetCount,i.priority,i.workers);
        return result;
    };
    auto world=a.collect_development_world(c);
    a.strategy.forward_support.inns_enabled=a.strategy.forward_support.hospitals_enabled=false;
    const auto baseline=ordinary(glob2test::withMaximaObservation(c,[&]{return a.collect_development_intents(world);}));
    a.strategy.forward_support.inns_enabled=a.strategy.forward_support.hospitals_enabled=true;
    glob2test::withMaximaObservation(c,[&]{a.configure_development_planner();});
    auto offered=glob2test::withMaximaObservation(c,[&]{return a.collect_development_intents(world);});
    CHECK(ordinary(offered)==baseline);
    CHECK(std::count_if(offered.begin(),offered.end(),[](const auto& i){return i.purpose==AIMaximaPlacement::ForwardSupport;})==2);
    f.game.gameHeader.setHungerDisabled(true);f.game.gameHeader.setUnitUpgradesDisabled(true);
    glob2test::withMaximaObservation(c,[&]{a.configure_development_planner();});
    world=a.collect_development_world(c);offered=glob2test::withMaximaObservation(c,[&]{return a.collect_development_intents(world);});
    CHECK(std::count_if(offered.begin(),offered.end(),[](const auto& i){return i.purpose==AIMaximaPlacement::ForwardSupport;})==1);
    f.game.gameHeader.setPeacefulModeEnabled(true);
    world=a.collect_development_world(c);offered=glob2test::withMaximaObservation(c,[&]{return a.collect_development_intents(world);});
    CHECK(std::none_of(offered.begin(),offered.end(),[](const auto& i){return i.purpose==AIMaximaPlacement::ForwardSupport;}));
}
}
