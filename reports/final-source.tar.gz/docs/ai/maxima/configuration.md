# Configuration

Maxima resolves a complete strategy when first asked for an order or a save.
Sources apply in this order, with later assignments taking precedence:

1. `data/maxima/base.strategy`, or the complete file named by `GLOB2_MAXIMA_BASE`.
2. The match-format layer: `duel`, `ffa3`, `ffa4`, `ffa5plus`, or allied `2v2`.
   `GLOB2_MAXIMA_FORMAT` overrides automatic selection.
3. Files in `GLOB2_MAXIMA_LAYERS`, separated by semicolons.
4. Team overrides, then player overrides.
5. `GLOB2_MAXIMA_OVERRIDES`.

Files contain `section.key = value` assignments with integer or boolean values
and `#` comments. Layers may be sparse. Unknown keys, duplicate assignments
within one source, malformed values, out-of-range values and inconsistent bounds
are errors with source locations. The resolver does not silently clamp values.

Team and player overrides use scoped lists, for example:

```sh
GLOB2_MAXIMA_TEAM_OVERRIDES="0:farming.enabled=false|2:tactics.min_force=6"
GLOB2_MAXIMA_PLAYER_OVERRIDES="0:tactics.min_force=8"
```

The historical `model.inn_capacity_level1`, `model.inn_capacity_level2` and
`model.inn_capacity_level3` keys remain accepted so existing strategy files and
saved configurations load. They no longer affect decisions: feeding estimates
come from building capabilities, the planned shared staffing budget and saved
recipient hunger/action clocks. `food.ticks_per_meal` is likewise retained for
loading historical configurations and diagnostic comparisons; it no longer
sets live recipient demand or headcount capacity. The historical
`economy.sustainable_inn_floor`, `economy.sustainable_inn_corn_divisor` and
`economy.sustainable_inn_offset` keys are also accepted but unused: a fixed crop
allowance per feeder double-counts shared recipient demand and cannot describe
free or non-wheat feeding. The ordinary inn target cap still bounds construction.

The base file and schema are the reference for available keys and defaults.
The schema exposes types, units, descriptions, hard bounds and recommended tuning
bounds. `MaximaStrategyDump` also reports resolved values and source provenance:

```sh
MaximaStrategyDump --dump-maxima-schema
MaximaStrategyDump --dump-maxima-strategy --maxima-format 2v2 \
    --maxima-layer custom.strategy --maxima-overrides 'tactics.min_force=8'
```

The executable is built from `src/ai/maxima/MaximaStrategyDump.cpp` by the
[Maxima test runner](../../../test/maxima/README.md).

| Parameter groups | Decisions |
| --- | --- |
| `model`, `environment`, `trends`, `demands` | Capacity estimates, observations and demand |
| `economy`, `staffing`, `upgrades`, `construction`, `prestige` | Production, worker requests and development |
| `food`, `farming` | Renewable supply, capacity claims and clearing |
| `military`, `postures`, `emergencies` | Army demand, service capacity and strategic priorities |
| `placement`, `scoring` | Sites, routes, candidate utility and switching margins |
| `defense`, `tactics`, `assault`, `raiding`, `forward_support` | Defensive response, attack execution and optional forward services |
| `recon`, `explorer_campaign`, `fruit` | Observation, explorer missions and fruit supply |
| `scheduling` | Review intervals, phases and cooldowns |

All clients simulating a new multiplayer match must use identical resolved
settings. Resuming a saved game uses its stored strategy rather than the local
files. `GLOB2_MAXIMA_TELEMETRY=1` emits `MAXIMA_TELEMETRY` decision records;
[AI telemetry](../telemetry.md) describes the common telemetry interface.

`prestige.enabled` enables economic prestige racing and completion guards only
when normal prestige victory is active. New matches default to `true`, with the
adaptive allowance enabled; opt out with `prestige.enabled=false`. The investment
floor defaults
to 45, the urgency weight to 35 and the winning-finish priority to 100. Preparation
uses ordinary technology priority; investment takes the greater of that priority
and the floor plus urgency scaled by global threshold progress.
`prestige.max_pipelines` defaults to 4 (range 1–4). It bounds adaptive preparation
from spare qualified builders after ordinary work and the training reserve; it
does not order that many schools unconditionally. A value of 1 keeps the
conservative control. Winning finishes and the number of remaining prestige
increments further restrict it. Only one prestige-producing completion is
committed at a time. Saves older than format 193 missing this setting receive 1.
All scores are bounded to 0–100. Food and colony emergencies suspend additional
investment.
Supported older saves without these controls explicitly receive `enabled=true`
and the same weights on load, preserving the requested older-save activation.
See [prestige economics](economy.md#prestige-race) for outcome and cancellation rules.

Related: [AI documentation](../README.md).

New games enable a dedicated forward-service pathway with a preferred 40-tile
geometric standoff, a 40-tile existing-service coverage threshold, a same-enemy
score preference and 4,000 ticks of bounded arrival grace. The ordinary colony
placement criteria are unchanged. These controls can be disabled independently;
older supported saves keep their stored policy. See [combat](combat.md#forward-support).

`tactics.flag_proximity_weight` defaults to 4 score points per geometric tile
from the existing offensive flag, capped at 32 tiles. It independently favors
nearby follow-up objectives; zero disables it. Strategies saved before format 189
restore zero when this key is absent, including format 188 ring40 saves.
