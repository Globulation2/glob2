import json,os,subprocess,time,importlib.util,urllib.request,hashlib
from pathlib import Path
from unittest import mock
R=Path.cwd();D=R/'artifacts/ci-recovery/recording-download-validation';W=R/'artifacts/ci-recovery/recording-download-repair';B=R/'artifacts/ci-recovery'
env=dict(os.environ,PATH=str(B/'nsis/prefix/usr/bin')+':'+str(B/'node/node_modules/.bin')+':'+os.environ['PATH'],NSISDIR=str(B/'nsis/prefix/usr/share/nsis'),PYTHONDONTWRITEBYTECODE='1')
state=dict(pid=os.getpid(),revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),base='9e903ff54a26b8bb26d67f5359fc4a9b43b8a02e',phase='full build contracts',results=[])
def save():(D/'status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 cmd=[str(B/'venv/bin/python'),'-m','unittest','discover','-s','test/build_system','-p','test_*.py','-v'];start=time.monotonic()
 with(D/'contracts.log').open('w')as log:code=subprocess.call(cmd,cwd=W,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 state['results'].append(dict(name='all build contracts',command=cmd,exit_code=code,seconds=round(time.monotonic()-start,1)));save();assert code==0,'contracts failed'
 spec=importlib.util.spec_from_file_location('mirror_download',W/'scons/sdl3_dependencies.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);lock=json.loads((W/'scons/recording-versions.json').read_text());ffmpeg=lock['ffmpeg'];calls=[];opener=urllib.request.urlopen
 def unavailable_primary(url,**options):
  calls.append(url)
  if url==ffmpeg['url']:raise TimeoutError('Intentional primary outage for actual mirror verification')
  return opener(url,**options)
 state['phase']='actual pinned mirror download with primary outage';save();start=time.monotonic()
 with mock.patch.object(module.urllib.request,'urlopen',side_effect=unavailable_primary):module.download(D/'download',{'ffmpeg':ffmpeg})
 p=D/'download'/ffmpeg['archive'];state['results'].append(dict(name='actual mirror under injected primary outage',exit_code=0,calls=calls,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=round(time.monotonic()-start,1)));state['phase']='finished; inspect all contract results and omission reasons';save()
except BaseException as error:state.update(phase='stopped; inspect error',error=repr(error));save();raise
