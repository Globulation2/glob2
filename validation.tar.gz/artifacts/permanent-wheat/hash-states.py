from pathlib import Path
import sys,json,mmap,hashlib
sys.path.insert(0,'test');from compare_save_continuation import records
V=Path('artifacts/permanent-wheat');host=sys.argv[1];rows={}
for name in ['v115','v116','v117','arena','rice','rice-terraces']:
 with (V/'validation'/host/name/'game.replay.checksums').open('rb') as f:
  with mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:rows[name]={str(t):hashlib.sha256(state).hexdigest() for t,state in records(data)}
(V/f'{host}-states.json').write_text(json.dumps(rows))
