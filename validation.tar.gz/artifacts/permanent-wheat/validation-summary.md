# Validation

- Native release builds on macOS and Linux.
- MaximaFarmingIntegrationTest, MaximaFarmingStandaloneTest, MaximaDirectorRegressionTest, MaximaEconomyRegressionTest, MaximaLifecycleTest: PASS.
- 17 Python farming policy tests: PASS.
- Permanent-layout integration test covers quantities 1–5, zero area-order changes across quantity transitions, forced resource loss/regrowth, wrapped farms and both team masks.
- Existing expansion support, wood-pincer reserve, access and discovery regressions remain enabled and pass.
- ReplayStepCounterTest: PASS including old/current/future replay boundaries.
- TournamentCompatibilityTest: PASS including old/current/future network protocol boundaries.
- macOS/Linux SHA-256 comparison of every team/entity state record: v115 512 ticks, crowded v116 4096 ticks, experimental v117 2048 ticks, arena 8192 ticks, generator 1 8192 ticks (legacy artifact label `rice`), Rice Terraces 8192 ticks. All 31232 match.
- Each legacy save resaved as118 and resumed: 256/2048/1024 matching continuation records on each platform.
- Retained v115 fixture baseline refreshed only after cross-platform equality. Fixture and midpoint-resume check pass.
- Windows not verified. AI behavior intentionally changes; human gameplay review remains outstanding. Engine orders, replay acceptance floor and network protocol are unchanged.
