from pathlib import Path
import sys,subprocess
R=Path.cwd();V=R/'artifacts/permanent-wheat';out=V/'validation'/sys.argv[2]/'rice-terraces';out.mkdir(parents=True,exist_ok=True)
cmd=[str(Path(sys.argv[1]).resolve()),'--run-game','--map-file',str(R/'artifacts/continuous-maturity/maps/g52-r0.map'),'--ticks','8192','--game-seed','53101','--player','maxima','--player','nicowar','--telemetry','checksums','--output-dir',str(out)]
with (out/'stdout.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=log,check=True)
