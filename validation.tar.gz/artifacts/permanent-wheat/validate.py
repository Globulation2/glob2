from pathlib import Path
import subprocess,json,sys,gzip
R=Path.cwd();V=R/'artifacts/permanent-wheat';host=sys.argv[2];binary=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(R/'test'));from compare_save_continuation import compare
old=V/'old-v115.game';old.write_bytes(gzip.decompress((R/'test/maxima/fixtures/save-continuation/checkpoint-30000-v115.game.gz').read_bytes()))
cases=[('v115',old,30512,30256),('v116',R/'artifacts/continuous-maturity/farm-crowding.game',579424,577376),('v117',R/'artifacts/continuous-maturity/continuation/from-v116/checkpoint-6144.game',8192,7168)]
rows=[]
for name,source,end,mid in cases:
 out=V/'validation'/host/name;out.mkdir(parents=True,exist_ok=True)
 def run(save,dest,extra):
  dest.mkdir(parents=True,exist_ok=True)
  cmd=[str(binary),'--run-game','--load-game',str(save),'--ticks',str(end),'--telemetry','checksums','--output-dir',str(dest),*extra]
  with (dest/'stdout.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=log,check=True)
 run(source,out,['--save',f'every:{mid}']);run(out/f'checkpoint-{mid}.game',out/'resumed',[])
 rows.append({'case':name,'continuation_records':compare(out/'game.replay.checksums',out/'resumed/game.replay.checksums')})
for name,mapfile,opponent in [('arena','g15-r0.map','maxima'),('rice','g1-r0.map','nicowar')]:
 out=V/'validation'/host/name;out.mkdir(parents=True,exist_ok=True)
 cmd=[str(binary),'--run-game','--map-file',str(R/'artifacts/continuous-maturity/maps'/mapfile),'--ticks','8192','--game-seed','53101','--player','maxima','--player',opponent,'--telemetry','checksums','--output-dir',str(out)]
 with (out/'stdout.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=log,check=True)
(V/f'{host}-validation.json').write_text(json.dumps(rows,indent=2));print(rows)
