#include <FormatableString.h>
#include <cassert>
#include <cstdint>
#include <iostream>
using GAGCore::FormattableString;
int main(){ unsigned checks=0;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{0ULL}).arg("0.00") == "Tick 0: 0.00 ms wall");++checks;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{4294967296ULL}).arg("0.00") == "Tick 4294967296: 0.00 ms wall");++checks;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{18446744073709551615ULL}).arg("0.00") == "Tick 18446744073709551615: 0.00 ms wall");++checks;
assert(FormattableString("Wall time: %0 ms").arg("0.00")=="Wall time: 0.00 ms");++checks;
assert(FormattableString("Required waits: %0 ms; owner joins: %1 ms; locks: %2 ms").arg("0.00").arg("2.00").arg("3.00")=="Required waits: 0.00 ms; owner joins: 2.00 ms; locks: 3.00 ms");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Orders").arg("0.00")=="Orders: 0.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Units").arg("0.00")=="Units: 0.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Buildings").arg("0.00")=="Buildings: 0.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Map").arg("0.00")=="Map: 0.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Statistics").arg("0.00")=="Statistics: 0.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("AI").arg("0.00")=="AI: 0.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("World capture").arg("0.00")=="World capture: 0.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Checksums").arg("0.00")=="Checksums: 0.00 ms wall");++checks;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{0ULL}).arg("0.01") == "Tick 0: 0.01 ms wall");++checks;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{4294967296ULL}).arg("0.01") == "Tick 4294967296: 0.01 ms wall");++checks;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{18446744073709551615ULL}).arg("0.01") == "Tick 18446744073709551615: 0.01 ms wall");++checks;
assert(FormattableString("Wall time: %0 ms").arg("0.01")=="Wall time: 0.01 ms");++checks;
assert(FormattableString("Required waits: %0 ms; owner joins: %1 ms; locks: %2 ms").arg("0.01").arg("2.00").arg("3.00")=="Required waits: 0.01 ms; owner joins: 2.00 ms; locks: 3.00 ms");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Orders").arg("0.01")=="Orders: 0.01 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Units").arg("0.01")=="Units: 0.01 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Buildings").arg("0.01")=="Buildings: 0.01 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Map").arg("0.01")=="Map: 0.01 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Statistics").arg("0.01")=="Statistics: 0.01 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("AI").arg("0.01")=="AI: 0.01 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("World capture").arg("0.01")=="World capture: 0.01 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Checksums").arg("0.01")=="Checksums: 0.01 ms wall");++checks;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{0ULL}).arg("1.23") == "Tick 0: 1.23 ms wall");++checks;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{4294967296ULL}).arg("1.23") == "Tick 4294967296: 1.23 ms wall");++checks;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{18446744073709551615ULL}).arg("1.23") == "Tick 18446744073709551615: 1.23 ms wall");++checks;
assert(FormattableString("Wall time: %0 ms").arg("1.23")=="Wall time: 1.23 ms");++checks;
assert(FormattableString("Required waits: %0 ms; owner joins: %1 ms; locks: %2 ms").arg("1.23").arg("2.00").arg("3.00")=="Required waits: 1.23 ms; owner joins: 2.00 ms; locks: 3.00 ms");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Orders").arg("1.23")=="Orders: 1.23 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Units").arg("1.23")=="Units: 1.23 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Buildings").arg("1.23")=="Buildings: 1.23 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Map").arg("1.23")=="Map: 1.23 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Statistics").arg("1.23")=="Statistics: 1.23 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("AI").arg("1.23")=="AI: 1.23 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("World capture").arg("1.23")=="World capture: 1.23 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Checksums").arg("1.23")=="Checksums: 1.23 ms wall");++checks;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{0ULL}).arg("1000000.00") == "Tick 0: 1000000.00 ms wall");++checks;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{4294967296ULL}).arg("1000000.00") == "Tick 4294967296: 1000000.00 ms wall");++checks;
assert(FormattableString("Tick %0: %1 ms wall").arg(std::uint64_t{18446744073709551615ULL}).arg("1000000.00") == "Tick 18446744073709551615: 1000000.00 ms wall");++checks;
assert(FormattableString("Wall time: %0 ms").arg("1000000.00")=="Wall time: 1000000.00 ms");++checks;
assert(FormattableString("Required waits: %0 ms; owner joins: %1 ms; locks: %2 ms").arg("1000000.00").arg("2.00").arg("3.00")=="Required waits: 1000000.00 ms; owner joins: 2.00 ms; locks: 3.00 ms");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Orders").arg("1000000.00")=="Orders: 1000000.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Units").arg("1000000.00")=="Units: 1000000.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Buildings").arg("1000000.00")=="Buildings: 1000000.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Map").arg("1000000.00")=="Map: 1000000.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Statistics").arg("1000000.00")=="Statistics: 1000000.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("AI").arg("1000000.00")=="AI: 1000000.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("World capture").arg("1000000.00")=="World capture: 1000000.00 ms wall");++checks;
assert(FormattableString("%0: %1 ms wall").arg("Checksums").arg("1000000.00")=="Checksums: 1000000.00 ms wall");++checks;
std::cout<<checks<<" original English formatted readouts match\n";}
