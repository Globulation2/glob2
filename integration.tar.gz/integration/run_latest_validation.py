import subprocess,os,json
from pathlib import Path
root=Path('/home/bradley/glob2/artifacts')
env=os.environ.copy();env.update(GLOB2_ASSET_DIR='/home/bradley/glob2/artifacts/pr-1151-render-refinement/runtime-assets',GLOB2_TEST_SHADER_DIRECTORY='/home/bradley/glob2/artifacts/pr-1148-parallel-rendering/native-shaders',GLOB2_RENDERER_SHADER_DIR='/home/bradley/glob2/artifacts/pr-1148-parallel-rendering/native-shaders',GLOB2_RENDER_EXECUTION='parallel')
common=['python3','test/run_tests.py','--build-dir','build/linux/client/debug/dev-dev_fast-true-linker-auto','-j4','--display-jobs','1','--timeout','600']
groups=[('unit','unit',['SurfaceRaster/*','SurfaceCoverage/*','ComputeExecutor/*'],[]),('engine','engine',['SoftwareRenderer/*','SceneExtract/*','WorldSnapshot/*','SharedWorkerLifecycle/*','AIPipeline/*','RuntimeContinuation/*','TeamStatsPipeline/*','TeamStatsSave/*'],['--exclude-tag','display']),('display','engine',['SoftwareRenderer/*','TerrainPresentation/*','HighResolutionIntegration/*','RendererSwitchIntegration/*','SettingsGraphics/*'],['--tag','display'])]
commands=[]
for label,binary,filters,extra in groups:
 base=root/('software-raster-depth-latest-'+label)
 cmd=common+['--binary',binary]
 for f in filters:cmd+=['--filter',f]
 cmd+=extra+['--junit',str(base)+'.xml','--artifacts',str(base)]
 commands.append({'command':cmd,'environment_overrides':{k:env[k] for k in ('GLOB2_ASSET_DIR','GLOB2_TEST_SHADER_DIRECTORY','GLOB2_RENDERER_SHADER_DIR','GLOB2_RENDER_EXECUTION')}})
 with open(str(base)+'.log','w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 commands[-1]['exit_code']=r.returncode
 (root/'software-raster-depth-latest-commands.json').write_text(json.dumps(commands,indent=2))
 print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
