# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: multiplayer.spec.js >> browser and native players complete matching simulation checkpoints (WSS)
- Location: tests/multiplayer.spec.js:281:1

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 125
Received:   0

Call Log:
- Timeout 30000ms exceeded while waiting on the predicate
```

# Test source

```ts
  207 |           if (checksum !== 0xffffffff) checksums.push(checksum);
  208 |         }
  209 |         bytes = bytes.subarray(size + 2);
  210 |       }
  211 |     });
  212 |   });
  213 |   return checksums;
  214 | }
  215 | 
  216 | const multiplayerAIs = ['no AI', 'Numbi', 'Castor', 'Warrush', 'ReachToInfinity', 'Nicowar', 'Cortex']
  217 |   .map((name, id) => ({name, id}))
  218 |   .filter(ai => process.env.GLOB2_ALL_AIS === '1' || ai.id === 0 || ai.id === 6);
  219 | for (const ai of multiplayerAIs)
  220 | test(`two browser players create, join and start a YOG match (${ai.name})`, async ({page, browser, baseURL}, testInfo) => {
  221 |   // Two WebGL clients share the headless browser's software GPU. This is a
  222 |   // correctness fixture; controlled performance gates use a reference GPU.
  223 |   test.setTimeout(180000);
  224 |   const other = await browser.newContext({baseURL, ignoreHTTPSErrors: true, viewport: {width: 1200, height: 900}});
  225 |   const guest = await other.newPage();
  226 |   try {
  227 |     const hostTypes = receivedTypes(page), guestTypes = receivedTypes(guest);
  228 |     const guestSent = receivedTypes(guest, 'framesent'), hostSent = receivedTypes(page, 'framesent');
  229 |     const hostChecksums = sentChecksums(page), guestChecksums = sentChecksums(guest);
  230 |     const errors = [];
  231 |     for (const target of [page, guest]) target.on('pageerror', error => errors.push(String(error)));
  232 |     await loginPlayer(page, 'transportplayer');
  233 |     await loginPlayer(guest, 'transportguest');
  234 |     const lists = guestTypes().filter(type => type === 50).length;
  235 |     await clickControl(page, 'lobby/host');
  236 |     await expect.poll(async () => (await page.evaluate(() => glob2Diagnostics.snapshot())).screen).toContain('ChooseMapScreen');
  237 |     await clickListRow(page, 'files', 0); await clickControl(page, 'ok');
  238 |     await expect.poll(hostTypes).toContain(16); // NetCreateGameAccepted
  239 |     await expect.poll(() => guestTypes().filter(type => type === 50).length).toBeGreaterThan(lists);
  240 |     await clickListRow(guest, 'lobby/games', 0); await clickControl(guest, 'lobby/join');
  241 |     await expect.poll(guestTypes).toContain(18); // NetGameJoinAccepted
  242 |     await expect.poll(guestSent).toContain(47); // NetSetGameInRouter
  243 |     await expect.poll(async () => (await guest.evaluate(() => glob2Diagnostics.snapshot())).screen).toContain('YOGSessionScreen');
  244 |     await guest.screenshot({path: testInfo.outputPath('joined-room.png')});
  245 |     if (ai.id) {
  246 |       await clickControl(page, 'ai/' + ai.id);
  247 |       await expect.poll(hostSent).toContain(12); // NetAddAI
  248 |     }
  249 |     const ready = hostTypes().filter(type => type === 26).length;
  250 |     await clickControl(guest, 'ready');
  251 |     await expect.poll(guestSent).toContain(26);
  252 |     await expect.poll(() => hostTypes().filter(type => type === 26).length).toBeGreaterThan(ready);
  253 |     await clickControl(page, 'start');
  254 |     for (const target of [page, guest])
  255 |       await expect.poll(async () => (await target.evaluate(() => glob2Diagnostics.snapshot())).tick, {timeout:60000}).toBeGreaterThan(100);
  256 |     for (const target of [page, guest])
  257 |       expect((await target.evaluate(() => glob2Diagnostics.snapshot())).screenClass).toContain('GameSessionScreen');
  258 |     await expect.poll(() => Math.min(hostChecksums.length, guestChecksums.length)).toBeGreaterThanOrEqual(25);
  259 |     const count = Math.min(hostChecksums.length, guestChecksums.length);
  260 |     expect(count).toBeGreaterThanOrEqual(25);
  261 |     expect(hostChecksums.slice(0, count)).toEqual(guestChecksums.slice(0, count));
  262 |     expect(errors).toEqual([]);
  263 |     await testInfo.attach('matching-order-checksums', {body: JSON.stringify({count, checksums: hostChecksums.slice(0, count)}), contentType: 'application/json'});
  264 |     await page.screenshot({path: testInfo.outputPath('multiplayer-match.png')});
  265 |     // Complete both clients' normal end-game flow instead of ending the fixture
  266 |     // by closing browser contexts while the match is still running.
  267 |     for (const target of [page, guest]) {
  268 |       await target.locator('#canvas').press('Escape',{delay:80});
  269 |       await expect.poll(async () => require('./pixels').hasClassicButton(target, await controlBox(target,'quit'))).toBe(true);
  270 |       await clickControl(target, 'quit');
  271 |       await expect.poll(async () => (await target.evaluate(() => glob2Diagnostics.snapshot())).screen).toContain('EndGameScreen');
  272 |       await target.locator('#canvas').press('Enter');
  273 |       await expect.poll(async () => (await target.evaluate(() => glob2Diagnostics.snapshot())).screen).toContain('YOGSessionScreen');
  274 |     }
  275 |     expect(errors).toEqual([]);
  276 |   } finally { await other.close(); }
  277 | });
  278 | 
  279 | 
  280 | for (const transport of ['WSS'])
  281 | test(`browser and native players complete matching simulation checkpoints (${transport})`, async ({page}, testInfo) => {
  282 |   const nativeProfile = 'glob2-native-peer-' + randomUUID();
  283 |   let peer;
  284 |   const peerLog = [];
  285 |   try {
  286 |     const hostTypes = receivedTypes(page), checksums = sentChecksums(page);
  287 |     const readyPlayers = receivedTypes(page, 'framereceived', body => body[0] === 26 ? body.readUInt16BE(1) : null);
  288 |     await loginPlayer(page, 'transportplayer');
  289 |     await clickControl(page, 'lobby/host');
  290 |     await expect.poll(async () => (await page.evaluate(() => glob2Diagnostics.snapshot())).screen).toContain('ChooseMapScreen');
  291 |     await clickListRow(page,'files',0); await clickControl(page,'ok');
  292 |     await expect.poll(hostTypes).toContain(16);
  293 |     const started = await start(path.join(root, `build/${platform}/client/release/src/native-multiplayer-peer`),
  294 |       [nativeProfile, endpoint, path.join(work, 'tls/ca.pem')],
  295 |       line => line.startsWith('native peer joined order-rate='));
  296 |     peer = started.child;
  297 |     peer.stdout.on('data', chunk => peerLog.push(String(chunk)));
  298 |     peer.stderr.on('data', chunk => peerLog.push(String(chunk)));
  299 |     const nativePlayerID = Number(/player-id=(\d+)/.exec(started.line)?.[1]);
  300 |     expect(nativePlayerID).toBeGreaterThan(0);
  301 |     // A single native Ready message is sufficient; repeated host readiness
  302 |     // transitions depend on timing and are not part of the admission contract.
  303 |     await expect.poll(readyPlayers).toContain(nativePlayerID);
  304 |     // Wire observation precedes the next SDL frame; wait for the actual control.
  305 |     await expect.poll(async () => (await page.evaluate(() => glob2Diagnostics.snapshot())).roomCanStart).toBe(true);
  306 |     await clickControl(page, 'start');
> 307 |     await expect.poll(async () => (await page.evaluate(() => glob2Diagnostics.snapshot())).tick).toBeGreaterThan(125);
      |                                                                                                  ^ Error: expect(received).toBeGreaterThan(expected)
  308 |     expect((await page.evaluate(() => glob2Diagnostics.snapshot())).screenClass).toContain('GameSessionScreen');
  309 |     await page.screenshot({path: testInfo.outputPath('native-cross-play.png')});
  310 |     await expect.poll(async () => (await page.evaluate(() => glob2Diagnostics.snapshot())).tick).toBeGreaterThan(250);
  311 |     await page.locator('#canvas').press('Escape',{delay:80});
  312 |     await expect.poll(async () => require('./pixels').hasClassicButton(page, await controlBox(page,'quit'))).toBe(true);
  313 |     await clickControl(page, 'quit');
  314 |     await expect.poll(async () => (await page.evaluate(() => glob2Diagnostics.snapshot())).screen).toContain('EndGameScreen');
  315 |     await expect.poll(() => peer.exitCode !== null || peer.signalCode !== null, {timeout:45000}).toBe(true);
  316 |     expect(peer.signalCode).toBeNull();
  317 |     expect(peer.exitCode).toBe(0);
  318 |     const bytes = await readFile(path.join(os.homedir(), '.' + nativeProfile, 'replays/last_game.replay.checksums'));
  319 |     const teams = bytes.readUInt32LE(4), count = bytes.readUInt32LE(12);
  320 |     expect(count).toBeGreaterThanOrEqual(250);
  321 |     expect(count).toBeLessThan(1000); // Victory, not the native safety timeout.
  322 |     const native = new Map();
  323 |     let offset = 20;
  324 |     const u32 = () => { const value = bytes.readUInt32LE(offset); offset += 4; return value; };
  325 |     for (let i = 0; i < count; ++i) {
  326 |       const tick = u32(), checksum = u32(); native.set(tick, checksum);
  327 |       for (let team = 0; team < teams; ++team) {
  328 |         u32(); // Team checksum.
  329 |         for (let group = 0; group < 2; ++group) {
  330 |           const objects = u32();
  331 |           for (let object = 0; object < objects; ++object) {
  332 |             offset += 6; // Object ID and checksum.
  333 |             const fields = u32(); offset += fields * 4;
  334 |           }
  335 |         }
  336 |       }
  337 |     }
  338 |     expect(offset).toBe(bytes.length);
  339 |     expect(checksums.length).toBeGreaterThanOrEqual(25);
  340 |     await testInfo.attach('native-checkpoints', {body: bytes, contentType: 'application/octet-stream'});
  341 |     await testInfo.attach('browser-order-checksums', {body: JSON.stringify(checksums), contentType: 'application/json'});
  342 |     await testInfo.attach('checksum-alignment', {body: JSON.stringify({native: [...native].slice(0, 30), browser: checksums.slice(0, 8)}), contentType: 'application/json'});
  343 |     // YOG finalizes the order rate at match start, after room readiness.
  344 |     const orderRate = Number(/native match order-rate=(\d+)/.exec(peerLog.join(''))?.[1]);
  345 |     expect(orderRate).toBeGreaterThan(0);
  346 |     // Align command-boundary checksums using the negotiated order rate.
  347 |     const compared = Math.min(checksums.length, Math.ceil(count / orderRate));
  348 |     for (let i = 0; i < compared; ++i) expect(checksums[i]).toBe(native.get(i * orderRate));
  349 |     await page.locator('#canvas').press('Enter');
  350 |     await expect.poll(async () => (await page.evaluate(() => glob2Diagnostics.snapshot())).screen).toContain('YOGSessionScreen');
  351 | 
  352 |   } finally {
  353 |     await stop(peer);
  354 |     await testInfo.attach('native-peer-log', {body: peerLog.join(''), contentType: 'text/plain'});
  355 |     await rm(path.join(os.homedir(), '.' + nativeProfile), {recursive: true, force: true});
  356 |   }
  357 | });
  358 | 
  359 | test('YOG admission enforces greeting, exact version, authentication and retry order', async ({page}) => {
  360 |   const version = Number((await readFile(path.join(root,'src/Version.h'),'utf8')).match(/^#define NET_PROTOCOL_VERSION (\d+)/m)[1]);
  361 |   await page.goto('/');
  362 |   for (const scenario of ['old version','future version','login before greeting','registration before greeting',
  363 |       'room before greeting','oversized map catalogue','room before login','repeated greeting','repeated login','greeting after login','retry login']) {
  364 |     const result = await page.evaluate(({endpoint,version,scenario}) => new Promise((resolve,reject) => {
  365 |       const socket = new WebSocket(endpoint); socket.binaryType='arraybuffer';
  366 |       let pending = new Uint8Array(), done=false, opened=false;
  367 |       const received=[];
  368 |       const timer=setTimeout(()=>finish(new Error('Admission did not finish: '+scenario)),5000);
  369 |       function finish(error) {
  370 |         if(done)return;done=true;clearTimeout(timer);socket.close();
  371 |         if(error)reject(error);else resolve(received);
  372 |       }
  373 |       const text = value => {const bytes=new TextEncoder().encode(value);return [bytes.length>>>24,(bytes.length>>>16)&255,(bytes.length>>>8)&255,bytes.length&255,...bytes];};
  374 |       const send = body => socket.send(Uint8Array.from([body.length>>>8,body.length&255,...body]));
  375 |       const hello = offset => send([9,(version+offset)>>>8,(version+offset)&255]);
  376 |       const login = password => send([1,...text('transportplayer'),...text(password)]);
  377 |       const room = () => send([15,...text('Must not create')]);
  378 |       socket.onopen=()=>{
  379 |         opened=true;
  380 |         if(scenario==='old version')hello(-1);
  381 |         else if(scenario==='future version')hello(1);
  382 |         else if(scenario==='login before greeting')login('fixture-only');
  383 |         else if(scenario==='registration before greeting')send([2,...text('mustnotregister'),...text('fixture-only')]);
  384 |         else if(scenario==='room before greeting')room();
  385 |         else if(scenario==='oversized map catalogue')send([52,255,255,255,255]);
  386 |         else hello(0);
  387 |       };
  388 |       socket.onmessage=event=>{
  389 |         const incoming=new Uint8Array(event.data),combined=new Uint8Array(pending.length+incoming.length);
  390 |         combined.set(pending);combined.set(incoming,pending.length);pending=combined;
  391 |         while(pending.length>=2){
  392 |           const size=pending[0]*256+pending[1];if(pending.length<size+2)break;
  393 |           const body=Array.from(pending.slice(2,size+2));pending=pending.slice(size+2);received.push(body);
  394 |           if(body[0]===10){
  395 |             if(scenario==='room before login')room();
  396 |             else if(scenario==='repeated greeting')hello(0);
  397 |             else login(scenario==='retry login'?'wrong-password':'fixture-only');
  398 |           }else if(body[0]===7){
  399 |             if(scenario==='old version'||scenario==='future version')finish();
  400 |             else if(scenario==='retry login')login('fixture-only');
  401 |             else finish(new Error('Unexpected login refusal: '+scenario));
  402 |           }else if(body[0]===4){
  403 |             if(scenario==='repeated login')login('fixture-only');
  404 |             else if(scenario==='greeting after login')hello(0);
  405 |             else if(scenario==='retry login')finish();
  406 |             else finish(new Error('Unauthorized login accepted: '+scenario));
  407 |           }
```