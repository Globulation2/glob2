from pathlib import Path
import importlib.util,json,subprocess
b=Path('artifacts/ci-recovery');first=b/'macos-generator-first';second=b/'macos-generator-second'
spec=importlib.util.spec_from_file_location('generator_evidence','test/collect_generator_evidence.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
count=module.compare(first,second)
a=json.loads((first/'manifest.json').read_text());c=json.loads((second/'manifest.json').read_text())
assert not a['source']['dirty'] and not c['source']['dirty']
assert a['source']['revision']=='8ac5bc598914f69b00ff269bfc7cf46d392d358f'
for key in ['host','host_compiler']:assert a[key]==c[key],key
assert a['github_run_id']!=c['github_run_id']
provenance=[]
for name in ['macos-native-first','macos-native-second']:
 p=json.loads((b/name/'tests/build-provenance.json').read_text());assert not p['dirty'];assert p['revision']==a['source']['revision'];assert p['sourceTreeSha256']==a['source']['sourceTreeSha256'];provenance.append(p)
assert provenance[0]['flags']==provenance[1]['flags']
production_diff=subprocess.check_output(['git','diff','8ac5bc598','HEAD','--','src',':(exclude)*Test.cpp',':(exclude)*Harness.cpp'],text=True)
assert not production_diff,'Generator acceptance source differs in production code'
path=Path('test/map-generator-golden.txt');before=path.read_text();expected=module.rows(before,'macos-arm64');observed=module.rows((first/'rows.txt').read_text(),'macos-arm64')
non=[k for k in expected if k[0]!=30];assert len(non)==556
assert all(expected[k]==observed.get(k) for k in non)
lookup={tuple(line.split()[3:7]):line for line in (first/'rows.txt').read_text().splitlines() if line.startswith('macos-arm64 30 ')};assert len(lookup)==8
changed=[];lines=[]
for line in before.splitlines():
 if line.startswith('macos-arm64 30 '):
  replacement=lookup[tuple(line.split()[3:7])];assert replacement.split()[2]=='7';changed.append({'before':line,'after':replacement});line=replacement
 if line.startswith('# Polder revision 7 follows'):line='# Polder revision 7 follows expanded-ground defaults; Linux GCC 13 and independent native macOS jobs supplied its rows.'
 lines.append(line)
assert len(changed)==8
receipt={'independentRuns':[a['github_run_id'],c['github_run_id']],'source':a['source'],'platform':a['platform'],'compiler':a['host_compiler'],'flags':provenance[0]['flags'],'binarySha256':[a['binary_sha256'],c['binary_sha256']],'matchingRows':count,'unchangedAcceptedNonPolderRows':len(non),'acceptedRows':changed,'historicalLinuxComparison':'polder-history/comparison.json','productionDifferenceFromMeasuredSource':production_diff}
(b/'macos-generator-comparison.json').write_text(json.dumps(receipt,indent=2)+'\n')
path.write_text('\n'.join(lines)+'\n');print('Accepted exactly 8 Polder rows; all',count,'independent observations agree')
