from pathlib import Path
import shlex,subprocess
p=Path('artifacts/ci-recovery')
(p/'polder-study-main.cpp').write_text('extern int runMapStudy(int,char**);\nint main(int argc,char**argv){return runMapStudy(argc,argv);}\n')
subprocess.run(['g++','-c',str(p/'polder-study-main.cpp'),'-o',str(p/'polder-study-main.o')],check=True)
subprocess.run(['objcopy','--redefine-sym','main=glob2_original_main','build/ci-recovery-release/src/app/Glob2.o',str(p/'polder-Glob2.o')],check=True)
lines=(p/'release-engine-build.log').read_text().splitlines()
a=shlex.split(next(l for l in lines if l.startswith('g++ -o build/ci-recovery-release/src/glob2 ')))
a[2]=str(p/'polder-study-diagnostic')
a=[str(p/'polder-Glob2.o') if x=='build/ci-recovery-release/src/app/Glob2.o' else x for x in a]
a.insert(3,str(p/'polder-study-main.o'))
subprocess.run(a,check=True)
