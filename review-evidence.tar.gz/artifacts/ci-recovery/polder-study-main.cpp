extern int runMapStudy(int,char**);
int main(int argc,char**argv){return runMapStudy(argc,argv);}
