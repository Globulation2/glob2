#include "src/field/OpenCLLaneRegistry.h"
#include <cstdio>
#include <memory>
int main(){
 using gradient_kernel::OpenCLLaneRegistry;
 int bytes=0;struct Credit{int& bytes;explicit Credit(int& b):bytes(b){bytes+=256;}~Credit(){bytes-=256;}};
 struct Payload{};
 OpenCLLaneRegistry<Payload,1> registry;
 auto firstCredit=std::make_shared<Credit>(bytes);
 auto first=std::shared_ptr<Payload>(new Payload,[firstCredit](Payload* p){delete p;});
 std::weak_ptr<Payload> escaped=first;registry.insert(first,firstCredit);firstCredit.reset();first.reset();
 if(bytes!=256)return 1;
 auto secondCredit=std::make_shared<Credit>(bytes);
 auto second=std::shared_ptr<Payload>(new Payload,[secondCredit](Payload* p){delete p;});
 if(!registry.insert(second,secondCredit))return 2;
 std::printf("credit after expired-slot replacement: %d\n",bytes);
 escaped.reset();if(bytes!=256)return 3;
 second.reset();secondCredit.reset();if(bytes!=256)return 4;
 registry.clear();if(bytes!=0)return 5;
 std::puts("explicit registry ownership and final release: passed");
}
