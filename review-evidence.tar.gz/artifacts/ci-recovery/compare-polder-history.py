from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
import subprocess,os,re,json,hashlib
root=Path.cwd(); base=root/'artifacts/ci-recovery'; out=base/'polder-history';out.mkdir(exist_ok=True)
old=subprocess.check_output(['git','show','origin/master:test/map-generator-golden.txt'],text=True)
rows=[line.split() for line in old.splitlines() if line.startswith('linux-x86_64 30 ')]
current={tuple(l.split()[3:7]):int(l.split()[8]) for l in Path('test/map-generator-golden.txt').read_text().splitlines() if l.startswith('linux-x86_64 30 ')}
def generate(task):
 row,ground=task;w,h,teams,seed=map(int,row[3:7]);name=f'{w}-{h}-{teams}-{seed}-ground{ground}';prefix=out/name
 cmd=[str(base/'polder-study-diagnostic'),'30',str(seed),'ci-polder-'+name,f'width={w}',f'height={h}',f'teams={teams}',f'ground={ground}',f'save={prefix}', 'rotations=1']
 if not Path(str(prefix)+'-generated.txt').exists():
  with (out/(name+'.log')).open('w') as log:subprocess.run(cmd,env=dict(os.environ,GLOB2_STUDY_EXPLAIN=str(prefix)),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
 p=Path(str(prefix)+'-generated.txt');s=p.read_text()
 def values(k):return list(map(int,re.findall(r'\b'+k+r' = (\d+);',s)))
 fields={k:values(k) for k in ['vertexTerrain','resourceType','resourceStock','startPosX','startPosY']};assert len(fields['vertexTerrain'])==(1<<w)*(1<<h)
 def fingerprint(stock):
  hv=14695981039346656037
  def add(v):
   nonlocal hv;hv=((hv^v)*1099511628211)&((1<<64)-1)
  add(1<<w);add(1<<h)
  for t,r,a in zip(fields['vertexTerrain'],fields['resourceType'],fields['resourceStock']):
   add(t);add(255 if r==65535 else r)
   if stock:add(a)
  add(teams)
  for x,y in zip(fields['startPosX'],fields['startPosY']):add(x);add(y)
  return hv
 result={'request':list(map(int,row[3:7])),'ground':ground,'fingerprint':fingerprint(True),'topologyFingerprint':fingerprint(False),'expectedFingerprint':int(row[8]) if ground==0 else current[tuple(row[3:7])],'textSha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 result['matchesExpected']=result['fingerprint']==result['expectedFingerprint'];return result,fields
with ThreadPoolExecutor(2) as pool:results=list(pool.map(generate,[(r,g) for r in rows for g in (0,1)]))
comparisons=[]
for i in range(0,len(results),2):
 classic,a=results[i];expanded,b=results[i+1]
 changes=Counter(f'{x}->{y}' for x,y in zip(a['vertexTerrain'],b['vertexTerrain']) if x!=y)
 comparisons.append({'request':classic['request'],'classic':classic,'expanded':expanded,'terrainSubstitutions':dict(changes),'resourceIdentityChanges':sum(x!=y for x,y in zip(a['resourceType'],b['resourceType'])),'resourceStockChanges':sum(x!=y for x,y in zip(a['resourceStock'],b['resourceStock'])),'classicStockTotal':sum(a['resourceStock']),'expandedStockTotal':sum(b['resourceStock']),'stockMultisetsEqual':Counter(a['resourceStock'])==Counter(b['resourceStock']),'changedStockResourceTypes':sorted({a['resourceType'][n] for n,(x,y) in enumerate(zip(a['resourceStock'],b['resourceStock'])) if x!=y}),'startPositionChanges':sum(x!=y or yy!=zz for x,y,yy,zz in zip(a['startPosX'],b['startPosX'],a['startPosY'],b['startPosY']))})
receipt={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'diagnostic':'Existing release objects linked to a separate main calling runMapStudy directly; game binary and production sources unchanged','comparisons':comparisons,'allFingerprintsMatch':all(r[0]['matchesExpected'] for r in results)}
(out/'comparison.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));assert receipt['allFingerprintsMatch']
