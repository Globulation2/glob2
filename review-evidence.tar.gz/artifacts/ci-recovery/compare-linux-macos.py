from pathlib import Path
import json,hashlib,subprocess
b=Path('artifacts/ci-recovery');comparisons=[]
def compare(a,c,label):
 left=a.read_bytes();right=c.read_bytes();comparisons.append({'label':label,'linux':str(a),'macos':str(c),'identical':left==right,'bytes':len(left),'sha256':hashlib.sha256(left).hexdigest()});assert left==right,label
for f in ['native.replay.checksums','verify-match.checksums.txt']:
 compare(b/'qualified-determinism'/f,b/'macos-determinism-first'/f,f)
for kind in ['resources','units']:
 a=json.loads((b/'qualified-determinism'/kind/'native/manifest.json').read_text());c=json.loads((b/'macos-determinism-first'/kind/'native/manifest.json').read_text());assert a['trace_sha256']==c['trace_sha256'];left=list((b/'qualified-determinism'/kind/'native').rglob('*.trace'));right=list((b/'macos-determinism-first'/kind/'native').rglob('*.trace'));assert len(left)==len(right)==1;compare(left[0],right[0],kind);assert comparisons[-1]['sha256']==a['trace_sha256']
for p in sorted((b/'qualified-javascript').rglob('*.checksums')):
 rel=p.relative_to(b/'qualified-javascript');compare(p,b/'macos-javascript-first/javascript-profile'/rel,'javascript/'+str(rel))
receipt={'linuxSource':'ec074e88f89cc8767bd69bd2040d9b641dba8003','macosSource':'8ac5bc598914f69b00ff269bfc7cf46d392d358f','productionSourceDifference':subprocess.check_output(['git','diff','--stat','8ac5bc598','ec074e88f','--','src',':(exclude)*Test.cpp',':(exclude)*Harness.cpp'],text=True),'linuxPlatform':'Ubuntu 24.04 x86_64 GCC13.3.0','macosPlatform':'macOS26.6.2 arm64 AppleClang21','comparisons':comparisons,'allIdentical':all(c['identical'] for c in comparisons)}
(b/'linux-macos-comparison.json').write_text(json.dumps(receipt,indent=2)+'\n');print(len(comparisons),'trace comparisons identical')
