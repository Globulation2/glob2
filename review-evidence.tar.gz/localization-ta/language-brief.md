# Tamil language brief

Variety: broad contemporary written Tamil. Script: Tamil (Taml), LTR. Region: general Tamil-reading audience, including India and Sri Lanka. Locale: ta; do not claim Tamil written in Latin script. Agent-reviewed, not native-human-certified.

Use clear standard written forms, respectful instructions (e.g. தேர்ந்தெடுக்கவும்), short labels, and explicit consequences in errors. Avoid literary archaisms and localized spoken dialect. Keep keyboard names, brands, protocol identifiers, URLs and placeholders intact. Do not use an English noun merely because it was left untranslated by the machine draft. Keep a deliberate distinction between players (ஆட்டக்காரர்கள்), warrior units (போர்வீரர்கள்), and all units (அலகுகள்).

## Consulted sources and limits

1. Microsoft, [Tamil Localization Style Guide](https://download.microsoft.com/download/5/0/7/5076DAEA-8D54-4294-A1DE-B274230CEEC1/tam-tam-StyleGuide.pdf), downloaded from the official aka.ms/tamil-styleguide link; local PDF and extracted text retained under reference/. Consulted sections 1.1, 4.1.1, 4.1.13, 4.1.15–18, 5.4.2, 5.5.2. The guide favors clear, concise language, consistent grammar, natural sentence order and respectful address; it discourages unnecessary abbreviation. It recommends modern Tamil reference works; those books are bibliographic leads, not claimed as directly consulted. PDF text extraction corrupts many Tamil examples: do not copy those examples into catalogs.
2. Unicode, [17.0 Core Specification, §12.6 Tamil](https://www.unicode.org/versions/Unicode17.0.0/core-spec/chapter-12/#G12322). Consulted the Tamil rendering discussion: normal puḷḷi is U+0BCD, dependent vowels can visually reorder or flank a consonant, and shaping is required. Preserve logical Unicode text and test vowel combinations rather than moving codepoints into visual order. Do not use U+0B82 to imitate puḷḷi.
3. Google, [Tamil account creation help](https://support.google.com/accounts/answer/27441?hl=ta), consulted the actual Tamil title, sign-in navigation and steps 1–8. Attests கணக்கு, உள்நுழைக, பயனர்பெயர், கடவுச்சொல், and மின்னஞ்சல். We adapt respectful verb endings to the game’s consistent UI register; this is contemporary usage evidence, not normative grammar authority.
4. [Tamil Dictionary worker lookup](https://dt.madurai.io/worker), read actual entry: தொழிலாளி and the specialized social-insect worker sense support தொழிலாளர் for the autonomous gathering/building class.
5. [Tamil Dictionary scout lookup](https://dt.madurai.io/scout), read actual scout senses: சாரணர் is offered alongside intelligence-gathering senses. Use சாரணர் for the game’s explorer/scout class; it is not a scientist or research-worker role.
6. [Tamil Dictionary hive lookup](https://dt.madurai.io/hive), read actual entry: தேன்கூடு/கூடு and social-bee habitat senses. This supports the short building name கூடு, interpreted in gameplay as the unit-producing hive. French Ruche and Hindi छत्ता corroborate the building metaphor in existing game catalogs.
7. [Tamil Dictionary inn lookup](https://dt.madurai.io/inn), read actual entry: lodging/traveller shelter senses. We intentionally prefer functional உணவகம் because the game’s inn feeds units; this is a gameplay interpretation, not a claim that உணவகம் is a literal dictionary equivalent of inn.
8. [Tamil Dictionary colony lookup](https://dt.madurai.io/colony), read actual entry and biological/social senses. Prefer குடியிருப்பு for the settlement where buildings and units grow; avoid an unexplained political-colonial reading.
9. [Tamil Dictionary resource lookup](https://dt.madurai.io/resource), read actual entry: includes supply/means/wealth senses. Prefer வளம்/வளங்கள் for map resources and கட்டுமானப் பொருட்கள் where the source specifically means needed building materials.
10. [Tamil Virtual Academy commentary](https://www.tamilvu.org/slet/l1280/l1280spg.jsp?file=l1280e09.htm&no=342), consulted the actual gloss பொருநர் → போர்வீரர், supporting the unambiguous martial noun. Academy dictionary landing pages were inspected but did not expose usable entries in the text interface, so they are not claimed as individual dictionary lookups.

## Reference catalogs and gameplay interpretation

Read English, French and Hindi entries for workers, warriors, explorers, Swarm, Inn, and all three flags. French ouvrières / guerrières / exploratrices and Hindi श्रमिक / योद्धा / खोजी confirm three different functional roles. French Ruche and Hindi छत्ता show that the English label Swarm names a hive building. Flag help says attracts explorers/warriors, not direct individual-unit commands. Clearing removes map resources; it is neither cleaning an interface nor harvesting resources for delivery.

## Terminology defaults

| Concept | Tamil | Reason |
|---|---|---|
| worker | தொழிலாளர் | gathering/building role; respectful generic noun |
| warrior | போர்வீரர் | martial role, separate from player |
| explorer | சாரணர் | scouting role, not scientific research |
| unit | அலகு | collective game entity term |
| player | ஆட்டக்காரர் | separates the person from warrior units |
| colony | குடியிருப்பு | settlement/community sense |
| Swarm building | கூடு | hive/nest building that creates units |
| Inn building | உணவகம் | feeds units; gameplay function |
| clearing flag | வள அகற்றும் கொடி | removes resources |
| exploration flag | தேடல் கொடி | attracts scouting units |
| war flag | போர்க் கொடி | attracts warrior units |
| resource | வளம் | terrain/economy resource |
| map | வரைபடம் | map/editor object |
| room | அறை | multiplayer lobby |
| match | ஆட்டம் | one played game; distinguish matchmaking/pairing |
| account | கணக்கு | established online usage |
| sign in | உள்நுழைக | established online usage |
| password | கடவுச்சொல் | established online usage |
| save | சேமி / சேமிக்கவும் | short button / respectful instruction |

Inflect these roots naturally; consistency does not require blindly replacing substrings. Plural count branches need grammatically valid Tamil, including one and other, with tokens preserved. Any deviation from these defaults needs an entry-specific reason and review.

Unresolved uncertainty: no glossary-level blocker. Final wording still requires the planned full per-key semantic, idiomatic, adversarial and in-context reviews. This brief does not certify the unseen machine draft or unavailable platforms.
