from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess
out=Path('artifacts/glacis-waterfront-crops/sweep');out.mkdir(exist_ok=True)
binary=str(Path('artifacts/glacis-waterfront-crops/after-glob2').resolve())
cases=[]
for w,h,teams in [(128,128,1),(128,128,2),(256,256,4),(256,256,6),(512,256,4),(256,512,8),(512,512,12)]:
 for bastions in [1,2,3]:
  for seed in [7,29]:
   cases.append(dict(width=w,height=h,teams=teams,seed=seed,workers=8 if seed==29 else 4,options={'bastions':bastions}))
for amount in [0,100,300]:
 for gates in [1,2,4]:
  cases.append(dict(width=256,height=256,teams=4,seed=401,workers=8,options={'wheat-amount':amount,'wood-amount':amount,'gates':gates,'fort-size':32,'starting-towers':1 if gates==2 else 0}))
for key in ['wheat-amount','wood-amount']:
 cases.append(dict(width=256,height=256,teams=4,seed=7,workers=4,options={key:0}))
(out/'requests.json').write_text(json.dumps(cases,indent=2))
def run(item):
 k,c=item;cmd=[binary,'map','generate','glacis','--width',str(c['width']),'--height',str(c['height']),'--teams',str(c['teams']),'--seed',str(c['seed']),'--workers',str(c['workers']),'--report-file',str(out/f'{k:03d}.json')]
 for key,value in c['options'].items():cmd+=['--set',f'{key}={value}']
 with (out/f'{k:03d}.log').open('w') as log:
  try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 return {'case':k,'returncode':code}
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,enumerate(cases)))
(out/'results.json').write_text(json.dumps(results,indent=2));print('Cases',len(results),'failures',[r for r in results if r['returncode']],flush=True)
