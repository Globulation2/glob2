from pathlib import Path
import json,hashlib,subprocess
p=Path(__file__).resolve().parent
assert (p/'preflight.json').exists()
assert (p/'runtime-calibration.json').exists()
assert not (p/'manifest.json').exists(), 'Already frozen'
c=json.loads((p/'protocol.json').read_text());c['tools_sha256']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.glob('*.py') if f.name!='freeze.py'}
c['preflight_sha256']=hashlib.sha256((p/'preflight.json').read_bytes()).hexdigest();c['analysis_packages']={'numpy':'2.4.6','scipy':'1.17.1'}
(p/'protocol.json').write_text(json.dumps(c,indent=2)+'\n')
print('PROTOCOL',hashlib.sha256((p/'protocol.json').read_bytes()).hexdigest(),flush=True)
