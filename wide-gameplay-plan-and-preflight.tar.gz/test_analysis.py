from pathlib import Path
import json,hashlib,shutil,subprocess,tempfile,itertools
p=Path(__file__).resolve().parent;c=json.loads((p/'protocol.json').read_text())
with tempfile.TemporaryDirectory(prefix='hiring-analysis-sanity-') as td:
 d=Path(td);(d/'protocol.json').write_text(json.dumps(c));(d/'analyze.py').write_text((p/'analyze.py').read_text().replace('B=10000;','B=100;'))
 jobs=[]
 for gen,size,fmt,mix in itertools.product(c['generators'],c['sizes'],c['formats'],c['mixes']):
  if fmt not in c['formats_by_generator'][gen]:continue
  for arm in c['arms']:
   for i in range(3):
    name=f'{gen}-{size}-{fmt}-{mix}-{arm}-{i}';j=dict(id=name,stratum=f'{gen}/{size}/{fmt}/{mix}',arm=arm,reps_per_arm=3);jobs.append(j);r=d/'runs'/name;r.mkdir(parents=True)
    row=dict(id=name,arm=arm,stratum=j['stratum'],ticks=65536,colonies=8,lost_colonies=i%3,worker_ticks=1000000,sampled_unit_ticks=2000000,sampled_critical_ticks=1000,starvation_deaths=100+i,new_buildings=80+i,food_worker_ticks=100000+i,idle_worker_ticks=10000,filling_worker_ticks=800000,combat_deaths=2,other_deaths=0,upgrades=10,births=200,delivered=2000,harvested=2000,meals=100,termination='tick_cap',winners=[],trajectory={})
    (r/'summary.json').write_text(json.dumps(row));(r/'attempt.json').write_text(json.dumps(dict(completed=True,id=name,arm=arm,summary_sha256=hashlib.sha256((r/'summary.json').read_bytes()).hexdigest())))
 c['total_games']=len(jobs);(d/'protocol.json').write_text(json.dumps(c))
 (d/'manifest.json').write_text(json.dumps(dict(protocol_sha256=hashlib.sha256((d/'protocol.json').read_bytes()).hexdigest(),games=jobs)));(d/'finished.json').write_text(json.dumps(dict(attempted=len(jobs))))
 subprocess.run([str(p/'analysis-venv/bin/python'),str(d/'analyze.py')],check=True,stdout=subprocess.DEVNULL)
 findings=json.loads((d/'findings.json').read_text())
 assert all(v['difference']==0 and v['randomization_p']==1 and v['holm_p']==1 for v in findings['primary'].values())
 assert len(findings['descriptive_subgroups'])==len(c['generators'])+len(c['sizes'])+len(c['formats'])+len(c['mixes'])
 for j in jobs:
  if j['arm']!='cached':continue
  r=d/'runs'/j['id'];row=json.loads((r/'summary.json').read_text());row['starvation_deaths']*=2;(r/'summary.json').write_text(json.dumps(row));a=json.loads((r/'attempt.json').read_text());a['summary_sha256']=hashlib.sha256((r/'summary.json').read_bytes()).hexdigest();(r/'attempt.json').write_text(json.dumps(a))
 subprocess.run([str(p/'analysis-venv/bin/python'),str(d/'analyze.py')],check=True,stdout=subprocess.DEVNULL)
 v=json.loads((d/'findings.json').read_text())['primary']['starvation_rate'];assert v['cached_over_original']==2 and v['holm_p']<.05 and not v['practical_noninferiority_supported']
print('PASS: identical arms, clear harmful treatment effect, subgroup inventory, allocations, hashes; synthetic B100 smoke check only')
