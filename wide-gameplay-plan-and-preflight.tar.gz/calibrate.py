from pathlib import Path
import json,subprocess,concurrent.futures,time,hashlib,statistics
p=Path(__file__).resolve().parent;c=json.loads((p/'protocol.json').read_text());jobs=[]
for i,gen in enumerate(c['generators']):
 valid=c['formats_by_generator'][gen];fmt=valid[i%len(valid)];n=c['formats'][fmt];mix=list(c['mixes'])[(i//4+i)%4];cycle=c['mixes'][mix];players=[cycle[k%len(cycle)] for k in range(n)]
 stem=p/'runtime-pilot-v2'/gen;stem.parent.mkdir(exist_ok=True)
 cmd=[str(p/'glob2-original'),'map','generate',gen,'--seed',str(789+i),'--width','128','--height','128','--teams',str(n),'--workers','4','--output',str(stem)+'.map','--report-file',str(stem)+'.json']
 with Path(str(stem)+'-generation.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(gen,'runtime input generation')
 for arm in c['arms']:jobs.append(dict(generator=gen,format=fmt,players=players,arm=arm,map=str(stem)+'.map.gz',game_seed=321+i))
def run(j):
 d=p/'runtime-pilot-v2'/(j['generator']+'-'+j['arm']);cmd=[str(p/('glob2-'+j['arm'])),'game','run','--map-file',j['map'],'--game-seed',str(j['game_seed']),'--ticks','65536','--compute-threads','2','--gpu','off','--output-dir',str(d)]
 for ai in j['players']:cmd+=['--player',ai]
 n=len(j['players']);alliances=[1]*(n//2)+[2]*(n//2) if j['format']=='teams4v4' else list(range(1,n+1))
 for a in alliances:cmd+=['--alliance',str(a)]
 cmd+=['--win-condition','allies' if j['format']=='teams4v4' else 'death'];start=time.time()
 with Path(str(d)+'.log').open('w') as f:r=subprocess.run(cmd,cwd='/home/bradley/glob2-hiring-profile-20261013',stdout=f,stderr=subprocess.STDOUT,timeout=1800)
 # Deliberately no telemetry/outcome values read; timing/technical completion only.
 return dict(generator=j['generator'],format=j['format'],arm=j['arm'],seconds=time.time()-start,returncode=r.returncode,command=cmd)
start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:results=list(ex.map(run,jobs))
wall=time.time()-start;report=dict(games=len(results),elapsed_seconds=wall,attempts_per_hour=len(results)*3600/wall,mean_game_seconds=statistics.mean(r['seconds'] for r in results),results=results,time=time.time())
(p/'runtime-calibration.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2),flush=True)
