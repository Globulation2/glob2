from pathlib import Path
import time,json,math,hashlib
p=Path(__file__).resolve().parent;c=json.loads((p/'protocol.json').read_text());pilot=json.loads((p/'runtime-calibration.json').read_text())
assert all(r['returncode']==0 for r in pilot['results']), 'Runtime pilot technical failure; investigate before choosing N'
# Four-hour target from request/administrative stop. Leave 25 minutes for generation and analysis.
deadline=1791984192.1178265+4*3600;available_hours=max(0,(deadline-time.time()-25*60)/3600)
# Lower forecast combines cohort batch rate and a longer-game-sensitive service estimate.
rate=min(pilot['attempts_per_hour'],c['concurrent']*3600/pilot['mean_game_seconds'])*.85
unit=sum(len(v) for v in c['formats_by_generator'].values())*len(c['mixes']) # one extra match per arm in half of fine cells
blocks=max(2,int(rate*available_hours//unit))
c['base_reps']=blocks//2;c['extra_half_cells']=bool(blocks%2);c['total_games']=blocks*unit
c['per_arm_per_stratum']='base_reps plus one in checkerboard-selected half cells when extra_half_cells is true; each policy has identical cell counts'
c['finish_target']=dict(deadline_unix=deadline,selected_at=time.time(),pilot_rate_per_hour=pilot['attempts_per_hour'],budgeted_rate_per_hour=rate,remaining_game_budget_hours=available_hours,estimated_game_hours=c['total_games']/rate,setup_and_analysis_reserve_minutes=25,fixed_attempts=c['total_games'],note='Forecast, not a guarantee. Once frozen, all fixed attempts finish; no wall-time stopping or outcome-driven resizing.')
c['runtime_calibration_sha256']=hashlib.sha256((p/'runtime-calibration.json').read_bytes()).hexdigest()
(p/'protocol.json').write_text(json.dumps(c,indent=2)+'\n');print(json.dumps(c['finish_target'],indent=2),flush=True)
