from pathlib import Path
import json,subprocess,random,hashlib,concurrent.futures
p=Path(__file__).resolve().parent;cfg=json.loads((p/'protocol.json').read_text());out=p/'inputs';out.mkdir(exist_ok=True)
if (p/'manifest.json').exists():raise SystemExit('Manifest exists; refusing regeneration')
rng=random.Random(cfg['input_seed']);jobs=[]
for gi,gen in enumerate(cfg['generators']):
 for size in cfg['sizes']:
  for fi,(fmt,n) in enumerate(cfg['formats'].items()):
   if fmt not in cfg['formats_by_generator'][gen]:continue
   for mi,(mix,cycle) in enumerate(cfg['mixes'].items()):
    reps=cfg['base_reps']+int(cfg['extra_half_cells'] and (gi+fi+mi)%2==0)
    for i in range(reps*2):
     players=[cycle[j%len(cycle)] for j in range(n)];rng.shuffle(players)
     alliances=[1]*(n//2)+[2]*(n//2) if fmt=='teams4v4' else list(range(1,n+1));rng.shuffle(alliances)
     jobs.append(dict(id=f'{gen}-{size}-{fmt}-{mix}-{i:03}',stratum=f'{gen}/{size}/{fmt}/{mix}',generator=gen,size=size,format=fmt,mix=mix,players=players,alliances=alliances,reps_per_arm=reps,map_seed=rng.randrange(1,2**32),game_seed=rng.randrange(1,2**32)))
assert len(jobs)==cfg['total_games'];(p/'input-plan.json').write_text(json.dumps(jobs,indent=2))
def generate(j):
 attempts=[]
 for a in range(100):
  seed=j['map_seed'] if a==0 else int.from_bytes(hashlib.sha256(f"replacement:{j['id']}:{a}:{cfg['input_seed']}".encode()).digest()[:4],'little')
  stem=out/j['id'];mf=Path(str(stem)+'.map.gz');report=Path(str(stem)+f'-a{a}.json')
  cmd=[str(p/'glob2-original'),'map','generate',j['generator'],'--seed',str(seed),'--width',str(j['size']),'--height',str(j['size']),'--teams',str(len(j['players'])),'--workers','4','--output',str(stem)+'.map','--report-file',str(report)]
  with Path(str(stem)+f'-a{a}.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  attempts.append(dict(seed=seed,returncode=r.returncode,command=cmd))
  if r.returncode==0 and mf.exists():return j|dict(map_seed=seed,map=str(mf.relative_to(p)),map_sha256=hashlib.sha256(mf.read_bytes()).hexdigest(),generation_attempts=attempts)
 raise RuntimeError('Input rejected 100 times: '+j['id'])
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for i,j in enumerate(ex.map(generate,jobs)):
  results.append(j)
  if (i+1)%100==0:print('generated',i+1,'/',len(jobs),flush=True)
rng=random.Random(cfg['assignment_seed'])
for s in sorted({j['stratum'] for j in results}):
 group=[j for j in results if j['stratum']==s];labels=cfg['arms']*group[0]['reps_per_arm'];rng.shuffle(labels)
 for j,a in zip(group,labels):j['arm']=a
rng.shuffle(results)
manifest=dict(protocol_sha256=hashlib.sha256((p/'protocol.json').read_bytes()).hexdigest(),games=results)
(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('MANIFEST',hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest(),flush=True)
