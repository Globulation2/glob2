from pathlib import Path
import time,subprocess,json,fcntl
p=Path(__file__).resolve().parent;lock=(p/'pipeline.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
while not (p/'preflight.json').exists():time.sleep(10)
for stage in ['freeze.py','generate.py','launch.py']:
 print('STAGE',stage,flush=True)
 r=subprocess.run(['python3',str(p/stage)],cwd='/home/bradley/glob2-hiring-profile-20261013')
 if r.returncode:
  (p/'pipeline-error.json').write_text(json.dumps(dict(stage=stage,returncode=r.returncode,time=time.time()),indent=2)+'\n');raise SystemExit(r.returncode)
print('COHORT AND ANALYSIS FINISHED',flush=True)
