from pathlib import Path
import json,collections,hashlib,sys
import numpy as np
p=Path(__file__).resolve().parent;c=json.loads((p/'protocol.json').read_text());m=json.loads((p/'manifest.json').read_text())
finished=json.loads((p/'finished.json').read_text());assert finished['attempted']==c['total_games']==len(m['games'])
assert hashlib.sha256((p/'protocol.json').read_bytes()).hexdigest()==m['protocol_sha256']
keys=[('starvation_deaths','sampled_unit_ticks'),('new_buildings','worker_ticks'),('food_worker_ticks','worker_ticks'),('lost_colonies','colonies')];names=list(c['primary'])
rows=[];attempts=[];groups=collections.defaultdict(lambda:collections.defaultdict(list));allocation=collections.Counter()
for j in m['games']:
 a=json.loads((p/'runs'/j['id']/'attempt.json').read_text());attempts.append(a);allocation[j['stratum'],j['arm']]+=1
 if a['completed']:
  sf=p/'runs'/j['id']/'summary.json';assert hashlib.sha256(sf.read_bytes()).hexdigest()==a['summary_sha256'];r=json.loads(sf.read_text());r={k:v for k,v in r.items() if k not in {'team_final_measurements','team_economy'}};rows.append(r);groups[j['stratum']][j['arm']].append(r)
expected=collections.Counter((j['stratum'],j['arm']) for j in m['games']);assert allocation==expected
for j in m['games']:assert allocation[j['stratum'],j['arm']]==j['reps_per_arm']
assert set(groups)=={j['stratum'] for j in m['games']}, 'A stratum has no successful games'
sub_boot={};sub_observed={};pool=collections.defaultdict(lambda:collections.defaultdict(list))
B=10000;rng=np.random.default_rng(c['analysis_seed']);boot=np.zeros((B,2,4,2));perm=np.zeros_like(boot);observed=np.zeros((2,4,2));empty=[]
for s,g in sorted(groups.items()):
 arrays=[]
 factors=s.split('/')
 for field,value in zip(['generator','size','format','mix'],factors):
  key=field+'/'+value
  sub_boot.setdefault(key,np.zeros((B,2,4,2)));sub_observed.setdefault(key,np.zeros((2,4,2)))
 for ai,arm in enumerate(c['arms']):
  rs=g[arm]
  if not rs:empty.append([s,arm]);continue
  a=np.array([[[r[num],r[den]] for num,den in keys] for r in rs],dtype=np.float64);arrays.append(a);observed[ai]+=a.mean(axis=0)
  pool[factors[0]][ai].extend([(v/len(a),factors) for v in a])
  for field,value in zip(['generator','size','format','mix'],factors):
   key=field+'/'+value;sub_observed[key][ai]+=a.mean(axis=0)
 if len(arrays)!=2:continue
 both=np.concatenate(arrays);order=np.argsort(rng.random((B,len(both))),axis=1);n=len(arrays[0]);perm[:,0]+=both[order[:,:n]].mean(axis=1);perm[:,1]+=both[order[:,n:]].mean(axis=1)
assert not empty,('empty analysis cells',empty)
# Pool only for bootstrap: fine-cell policy permutations above retain the randomized blocks.
# Resampling weighted match tuples within generators avoids zero estimated variance in tiny cells.
# Composition varies in the resamples; intervals intentionally include that additional uncertainty.
for generator,g in sorted(pool.items()):
 for ai,entries in g.items():
  a=np.array([v for v,factors in entries]);idx=rng.integers(0,len(a),size=(B,len(a)));draws=a[idx].sum(axis=1);boot[:,ai]+=draws
  for field in ['generator','size','format','mix']:
   fi=['generator','size','format','mix'].index(field)
   for value in {factors[fi] for v,factors in entries}:
    mask=np.array([factors[fi]==value for v,factors in entries]);sub_boot[field+'/'+value][:,ai]+=(a[idx]*mask[idx][...,None,None]).sum(axis=1)
rates=observed[:,:,0]/observed[:,:,1];br=boot[:,:,:,0]/boot[:,:,:,1];pr=perm[:,:,:,0]/perm[:,:,:,1]
difference=rates[1]-rates[0];pvalues=(1+np.sum(np.abs(pr[:,1]-pr[:,0])>=np.abs(difference),axis=0))/(B+1)
order=np.argsort(pvalues);adj=np.empty(4);maximum=0
for i,k in enumerate(order):maximum=max(maximum,min(1,float(pvalues[k])*(4-i)));adj[k]=maximum
primary={}
subgroups={}
for key,v in sub_boot.items():
 sr=sub_observed[key][:,:,0]/sub_observed[key][:,:,1];dr=v[:,:,:,0]/v[:,:,:,1]
 subgroups[key]={name:dict(original_rate=float(sr[0,k]),cached_rate=float(sr[1,k]),difference_ci95=np.quantile(dr[:,1,k]-dr[:,0,k],[.025,.975]).tolist() if np.all(np.isfinite(dr[:,:,k])) else None) for k,name in enumerate(names)}
for k,name in enumerate(names):
 diffci=np.quantile(br[:,1,k]-br[:,0,k],[.025,.975]).tolist();ratio=float(rates[1,k]/rates[0,k]) if rates[0,k]>0 else None
 ratio_ci=np.quantile(br[:,1,k]/br[:,0,k],[.025,.975]).tolist() if np.all(br[:,0,k]>0) else None
 noninferior=(ratio_ci is not None and ratio_ci[1]<=1.05) if k==0 else (ratio_ci is not None and ratio_ci[0]>=.95) if k==1 else diffci[1]<=([.005,.02][k-2])
 primary[name]=dict(original_rate=float(rates[0,k]),cached_rate=float(rates[1,k]),difference=float(difference[k]),difference_ci95=diffci,cached_over_original=ratio,ratio_ci95=ratio_ci,randomization_p=float(pvalues[k]),holm_p=float(adj[k]),practical_noninferiority_supported=bool(noninferior),warning='Rare/zero events may leave risk unresolved; bootstrap is not proof of absence' if k==0 else None)
def describe(rs):
 totals={key:sum(r[key] for r in rs) for key in ['ticks','colonies','lost_colonies','worker_ticks','sampled_unit_ticks','sampled_critical_ticks','starvation_deaths','combat_deaths','other_deaths','new_buildings','upgrades','births','delivered','harvested','meals','food_worker_ticks','idle_worker_ticks','filling_worker_ticks']}
 return dict(games=len(rs),totals=totals,terminations=dict(collections.Counter(r['termination'] for r in rs)),winners_by_ai=dict(collections.Counter(ai for r in rs for ai in r['winners'])),delivered_per_worker_tick=totals['delivered']/totals['worker_ticks'] if totals['worker_ticks'] else None,harvested_per_worker_tick=totals['harvested']/totals['worker_ticks'] if totals['worker_ticks'] else None)
failure=[a for a in attempts if not a['completed']]
findings=dict(source=c['source'],baseline=c['baseline'],attempted=len(attempts),completed=len(rows),failures=failure,allocation_balanced=True,primary=primary,descriptive_subgroups=subgroups,overall={a:describe([r for r in rows if r['arm']==a]) for a in c['arms']},strata={s:{a:describe(g[a]) for a in c['arms']} for s,g in sorted(groups.items())},acceptance='Unresolved technical failures block clean acceptance' if failure else 'All primary practical noninferiority gates passed' if all(v['practical_noninferiority_supported'] for v in primary.values()) else 'One or more practical bounds remain unresolved or exceeded',limitations=c['limits'],analysis_dependencies=dict(numpy=np.__version__),note='Only complete matches enter gameplay estimates. No equivalence claim from nonsignificance; subgroup effects are descriptive.')
(p/'findings.json').write_text(json.dumps(findings,indent=2,allow_nan=False)+'\n')
(p/'match-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
report=['# Frozen production hiring gameplay cohort',f"{len(attempts)} attempts; {len(rows)} completed; {len(failure)} failures.",'',findings['acceptance'],'','| Endpoint | Cached/original | 95% ratio interval | Holm p | Difference (95% interval) |','|---|---:|---|---:|---|']
for name,v in primary.items():report.append(f"| {name} | {v['cached_over_original']} | {v['ratio_ci95']} | {v['holm_p']:.4g} | {v['difference']} ({v['difference_ci95']}) |")
report+=['',findings['note'],'',c['limits']];(p/'report.md').write_text('\n'.join(report)+'\n');print(findings['acceptance'],flush=True)
