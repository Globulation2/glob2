#include <Game.h>
#include <PerformanceTelemetry.h>
#include <cstdio>
int main() {
  std::printf("Game=%zu Map=%zu ComputeExecutor=%zu Collector=%zu\n", sizeof(Game), sizeof(Map), sizeof(ComputeExecutor), sizeof(PerformanceTelemetry::Collector));
}
