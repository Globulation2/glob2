const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=process.env.GLOB2_PIXEL_WORKTREE,{PNG}=require(path.join(root,'browser/node_modules/pngjs'));
const engines=require(path.join(root,'browser/node_modules/@playwright/test'));
const sha=data=>crypto.createHash('sha256').update(data).digest('hex');
(async()=>{const results=[];
for(const name of ['chromium','firefox','webkit']){
 const browser=await engines[name].launch({headless:true});
 try{const page=await browser.newPage();
 for(const file of fs.readdirSync(path.join(__dirname,'corpus')).filter(n=>n.endsWith('.png'))){
  const bytes=fs.readFileSync(path.join(__dirname,'corpus',file)),decoded=PNG.sync.read(bytes);
  for(let at=3;at<decoded.data.length;at+=4)assert.equal(decoded.data[at],255,'normal screenshot must be opaque');
  const prior=await page.evaluate(async base64=>{
   const bitmap=await createImageBitmap(await(await fetch('data:image/png;base64,'+base64)).blob());
   const canvas=document.createElement('canvas');canvas.width=bitmap.width;canvas.height=bitmap.height;
   const ctx=canvas.getContext('2d');ctx.drawImage(bitmap,0,0);bitmap.close();
   const data=ctx.getImageData(0,0,canvas.width,canvas.height).data,parts=[];
   for(let at=0;at<data.length;at+=32768)parts.push(String.fromCharCode(...data.subarray(at,at+32768)));
   return btoa(parts.join(''));
  },bytes.toString('base64'));
  const original=Buffer.from(prior,'base64');assert.equal(sha(original),sha(decoded.data),name+' '+file+' RGBA mismatch');
  results.push({browser:name,file,width:decoded.width,height:decoded.height,rgba_sha256:sha(original),equal:true});
 }
 }finally{await browser.close();}
}
fs.writeFileSync(path.join(__dirname,'parity.json'),JSON.stringify({scope:'Idle browser comparison of original canvas decoder versus runner PNG decoder, captured opaque Software and WebGL screenshots; not an application performance claim',results},null,2));console.log(results.length+' byte-identical RGBA comparisons');
})().catch(error=>{console.error(error);process.exitCode=1;});
