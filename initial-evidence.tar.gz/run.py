import os,json,subprocess,time
from pathlib import Path
r=Path.cwd();b=r/'artifacts/ci-recovery';d=b/'pixel-decoding';w=b/'pixel-repair';runtime=b/'menu-latest-integration/build/emscripten/client/release'
env=dict(os.environ,CI='1',GLOB2_TEST_URL='http://127.0.0.1:8835',GLOB2_TEST_BUILD_DIR=str(runtime),GLOB2_PIXEL_WORKTREE=str(w),GLOB2_TEST_RENDERER='software',PLAYWRIGHT_JUNIT_OUTPUT_FILE=str(d/'renderer-junit.xml'));env['PATH']=str(b/'node/node_modules/.bin')+':'+env['PATH']
state={'pid':os.getpid(),'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'base':'a69886a8f9c7495e5c70449d01bdb18ce8174de9','runtime_revision':'1d09ddbff80f3cf916f1163a99a9899149ab31c4','scope':'Test-only PNG decoding outside application page; all6 helper thresholds/counts/RGBdiff rules unchanged. Exact pinned pngjs7.0.0 development-only; no runtime/bundle/native/SDK/dependency prefix changes. AllNodecontracts+RGBAparity3browsers+full747inventory+oneoriginal720srenderer case with originallocator inputs.','results':[]}
def save(phase):state['phase']=phase;(d/'status.json').write_text(json.dumps(state,indent=2)+'\n')
config=d/'renderer.config.cjs';config.write_text('const base=require('+json.dumps(str(w/'browser/playwright.config.js'))+');module.exports={...base,testDir:'+json.dumps(str(w/'browser/tests'))+',testMatch:["renderer-switching.spec.js"],projects:base.projects.filter(p=>p.name==="chromium"),workers:1,reporter:[["list"],["junit"]]};')
steps=[('node',['node','--test',*map(str,sorted((w/'browser/unit').glob('*.test.js')))]),('parity',['node',str(d/'parity.js')]),('inventory',['node',str(w/'browser/node_modules/@playwright/test/cli.js'),'test','--config='+str(w/'browser/playwright.config.js'),'--list','--reporter=json']),('renderer',['xvfb-run','-a','node',str(w/'browser/node_modules/@playwright/test/cli.js'),'test','--config='+str(config),'--grep','serial: repeated menu switches preserve Wasm lifetime and input','--output='+str(d/'renderer-results'),'--trace=retain-on-failure'])]
for name,cmd in steps:
 save(name);start=time.monotonic();server=None
 with(d/('inventory.json'if name=='inventory'else name+'.log')).open('w')as log:
  try:
   if name=='renderer':
    sl=(d/'server.log').open('w');server=subprocess.Popen(['python3',str(b/'serve_ci_layout.py'),'8835','--directory',str(runtime)],stdout=sl,stderr=subprocess.STDOUT)
   code=subprocess.call(cmd,cwd=w,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  finally:
   if server:server.terminate();server.wait();sl.close()
 state['results'].append({'name':name,'command':cmd,'exit_code':code,'seconds':round(time.monotonic()-start,1)});save(name+' finished')
 if code:save('failed; inspect log before any rerun');raise SystemExit(code)
 if name=='inventory':
  def rows(document):
   out=[]
   def walk(s,path):
    for spec in s.get('specs',[]):
     for test in spec['tests']:out.append([test['projectName'],spec['file'],path,spec['title'],sorted(spec.get('tags',[]))])
    for child in s.get('suites',[]):walk(child,path+[child['title']])
   for s in document['suites']:walk(s,[])
   return sorted(out)
  before=rows(json.loads((b/'fixtures-194/final-inventory.json').read_text()));after=rows(json.loads((d/'inventory.json').read_text()));assert len(before)==len(after)==747
  (d/'inventory-comparison.json').write_text(json.dumps({'baseline_count':len(before),'current_count':len(after),'identical':before==after},indent=2)+'\n');assert before==after,'case inventory changed'
save('finished; inspect all assertions and evidence before readiness')
