#include "LiveHiringTrial.h"
#include "Team.h"
#include "Unit.h"
#include "Building.h"
#include <span>
// SPDX-License-Identifier: GPL-3.0-or-later
#include "Game.h"
#include "HiringStudy.h"
#include "GameDiagnostics.h"
#include "ai/engine/AIPipeline.h"
#include "AIJavaScript.h"
#include "Player.h"
SimulationSnapshot::Handle Game::captureReadBoundary(SimulationSnapshot::CaptureOptions options) const
{
 LiveHiringTrial::Scope scope(LiveHiringTrial::Capture);
 {LiveHiringTrial::Scope setup(LiveHiringTrial::RouteBootstrap);
 if(LiveHiringTrial::active && HiringStudy::refreshDue(*this,false)) {
  for(int t=0;t<teamsCount();++t) {
   if(stepCounter%4!=unsigned(t)%4)continue; // Fixed K4/R4 trial admission.
   unsigned classes=0;for(const auto* u:teams[t]->liveUnits.entries())if(!u->performance[FLY])classes|=1u<<u->swimClass();
   for(auto* b:std::span(teams[t]->myBuildings,Building::MAX_COUNT))if(b && b->buildingState==Building::ALIVE &&
      !b->type->runtimeFlyingCarriers && b->desiredMaxUnitWorking>0 && b->unitsWorking.size()<unsigned(b->desiredMaxUnitWorking)) {
    bool demand=false;for(unsigned m=0;m<MaterialCount;++m)demand|=b->materialDeliveryNeed(m)>0;
    if(!demand)continue;
    for(int c=0;c<SWIM_CLASS_COUNT;++c)if(classes&(1u<<c)) {
     int ignoredDistance=0;
     const_cast<Game*>(this)->map.buildingAvailable(b,c,b->posX,b->posY,&ignoredDistance,BuildingRoute::Footprint);
     for(unsigned m=0;m<MaterialCount;++m)if(b->materialDeliveryNeed(m)>0)
      const_cast<Game*>(this)->map.getMaterialGradientSlot(t,m,c,b->fetchesFromMarkets(),b);
    }
   }
  }
 }
 }
 SimulationSnapshot::Handle world;
 {LiveHiringTrial::Scope extraction(LiveHiringTrial::Snapshot);world=worldSnapshots.captureBoundary(*this,options);}
 return world;
}
std::vector<std::pair<unsigned,std::shared_ptr<Order>>> Game::prepareAIOrders(std::span<const unsigned> players,
 bool paused,const std::shared_ptr<GameDiagnostics::Session>& diagnostics,const SimulationSnapshot::Handle* captured)
{
 if(!aiPipeline) aiPipeline=std::make_unique<AIEngine::Pipeline>();
 // Standalone simulation callers use the same boundary service; engine callers
 // supply the standard snapshot already published at this boundary.
 if (captured) {HiringStudy::observe(*this,*captured,paused);return aiPipeline->prepare(*this,players,paused,diagnostics,*captured); }
 const auto world=captureReadBoundary(diagnostics ? diagnostics->captureOptions(stepCounter) : SimulationSnapshot::CaptureOptions{});
 HiringStudy::observe(*this,world,paused);
 return aiPipeline->prepare(*this,players,paused,diagnostics,world);
}
std::shared_ptr<Order> Game::validateAIOrder(std::shared_ptr<Order> order,unsigned player) {return aiPipeline?aiPipeline->validate(*this,std::move(order),player):order;}
void Game::settleAIOrder(const std::shared_ptr<Order>& order,bool accepted) {if(aiPipeline)aiPipeline->settle(*this,order,accepted);}
void Game::cancelAI(unsigned player) {if(aiPipeline)aiPipeline->cancel(player);}
void Game::drainAI() {if(aiPipeline)aiPipeline->drain();}
void Game::clearAI() { HiringStudy::clear(*this); map.finishGradientPipeline({JoinReason::Teardown, ComputeTelemetry::NoTick}); map.finishResourceGrowth({JoinReason::Teardown, ComputeTelemetry::NoTick}); aiPipeline.reset(); worldSnapshots.reset(); }
void Game::saveAI(GAGCore::OutputStream* stream) {if(!aiPipeline){aiPipeline=std::make_unique<AIEngine::Pipeline>();aiPipeline->prepare(*this,{},true,nullptr,captureReadBoundary());}aiPipeline->save(stream);}
bool Game::loadAI(GAGCore::InputStream* stream) {auto pipeline=std::make_unique<AIEngine::Pipeline>();if(!pipeline->load(*this,stream))return false;aiPipeline=std::move(pipeline);return true;}
std::vector<std::pair<std::string,Uint64>> Game::aiMetrics() const {
 if(!aiPipeline)return {};
 const auto compute=map.computeExecutor().telemetrySnapshot();
 const auto& waits=compute.summary.joins[unsigned(ComputeProducer::AI)][unsigned(JoinReason::TickDeadline)];
 const auto& capture=worldSnapshots.metrics;const auto& scheduling=aiPipeline->schedulingMetrics();const auto memory=worldSnapshots.memoryMetrics();const auto queryMemory=aiPipeline->queryVectorMemory();
 return {{"captures",capture.captures},{"extraction_ns",capture.captureNs},{"preparation_ns",capture.preparationNs},
  {"map_bytes_copied",capture.mapBytesCopied},{"detailed_captures",capture.detailedCaptures},{"bytes_copied",capture.bytesCopied},{"component_reuses",capture.reusedComponents},{"allocations",capture.allocations},
  {"computation_ns",aiPipeline->computationNs()},{"controller_query_vector_bytes",queryMemory.first},
  {"controller_query_vector_peak_bytes",aiPipeline->peakQueryVectorMemory()},
  {"controller_query_vector_samples",queryMemory.second},{"submitted",scheduling.submitted},{"delivered",scheduling.delivered},
  {"snapshot_allocated_buffers",memory.allocatedBuffers},{"snapshot_reusable_buffers",memory.reusableBuffers},
  {"snapshot_leased_buffers",memory.leasedBuffers},{"snapshot_retained_bytes",memory.retainedBytes},
  {"snapshot_capacity_bytes",memory.capacityBytes},{"snapshot_leased_bytes",memory.leasedBytes},
  {"snapshot_peak_allocated_buffers",memory.peakAllocatedBuffers},{"snapshot_peak_reusable_buffers",memory.peakReusableBuffers},{"snapshot_peak_leased_buffers",memory.peakLeasedBuffers},
  {"snapshot_peak_retained_bytes",memory.peakRetainedBytes},{"snapshot_peak_capacity_bytes",memory.peakCapacityBytes},
  {"snapshot_peak_leased_bytes",memory.peakLeasedBytes},
  {"deadline_misses",waits.incomplete},{"deadline_wait_ns",waits.background.totalNs},{"maximum_pending",scheduling.maximumPending},
  {"shared_batches",scheduling.sharedBatches}};
}
void Game::observeUnpolledAI() {
 std::vector<AIJavaScript*> idle;
 for(unsigned p=0;p<unsigned(gameHeader.getNumberOfPlayers());++p)
  if(players[p]&&players[p]->ai&&players[p]->ai->implementationID==AI::JAVASCRIPT
    &&(!aiPipeline||!aiPipeline->wasPolled(p,stepCounter)))
   idle.push_back(static_cast<AIJavaScript*>(players[p]->ai->aiImplementation));
 if(idle.empty())return;
 // Replay/inactive replicas still update their historical visibility at the
 // legacy phase. Serialize this exceptional observation against private jobs.
 drainAI();
 // Replica-only observations historically capture fresh inputs at this mid-tick phase.
 if(!aiPipeline) worldSnapshots.invalidateBoundary();
 const AIEngine::AIWorldView world(worldSnapshots.captureBoundary(*this).simulationView());
 for(auto* controller:idle)controller->observe(world);
}
