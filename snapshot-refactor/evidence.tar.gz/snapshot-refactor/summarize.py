from pathlib import Path
import json,statistics,math,random,collections
p=Path(__file__).resolve().parent;rows=[json.loads(l) for l in (p/'timing/samples.jsonl').read_text().splitlines()];groups=collections.defaultdict(dict)
for r in rows:
 if r['repetition']>=0 and not r['excluded_pair']:groups[r['case'],r['repetition']][r['arm']]=r
assert len(groups)==120 and all(set(v)=={'before','after'} for v in groups.values())
metrics={'elapsed':lambda r:r['trial']['measured_elapsed_ns'],'process_cpu':lambda r:r['result']['benchmark_run_cpu_ns'],'tick_p95':lambda r:r['result']['tick_p95_ns']};rng=random.Random(713105);report={'scope':'Fixed twelve256x256 eight-Nicowar maps; ten paired repeated timings per map, not independent gameplay observations. Paired bootstrap uncertainty describes timing for these fixed cases, not a general map population. Baseline6b95/SIM48 frozen; latest statistics integration separate.','pairs':120,'warmup_pairs':sum(r['repetition']==-1 for r in rows)//2,'excluded_pairs':sum(r['excluded_pair'] for r in rows)//2,'metrics':{}}
for name,read in metrics.items():
 samples=collections.defaultdict(list)
 for (case,rep),arms in groups.items():samples[case].append(math.log(read(arms['after'])/read(arms['before'])))
 medians={case:statistics.median(v) for case,v in samples.items()};effect=math.expm1(statistics.mean(medians.values()));draws=[]
 for _ in range(10000):draws.append(math.expm1(statistics.mean(statistics.median(rng.choices(v,k=len(v))) for v in samples.values())))
 draws.sort();report['metrics'][name]={'geometric_mean_paired_median_delta':effect,'paired_bootstrap_95_interval':[draws[249],draws[9749]],'per_map':{case:{'paired_median_delta':math.expm1(median),'pairs':len(samples[case])} for case,median in medians.items()}}
(p/'timing-findings.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
