from pathlib import Path
import json,tarfile,hashlib,subprocess
p=Path(__file__).resolve().parent
assert (p/'timing/finished.json').exists()
files=[]
for name in ['protocol.json','validation-summary.json','timing-findings.json','phase-findings.json','report.md','run_pairs.py','write_report.py','package_evidence.py','summarize.py','diagnose.py','verify.py','build_trial.py','build_focused.py','layouts.txt','compile-commands.json','link-command.json','layout-command.json','golden-verification.json','focused-final-tests.xml','focused-final-tests.log','focused-final-build.log','release-final-build.log','release-membership-build.log','private-after-build-final.log','private-before-build-final.log','verify-final.log','measure.log','diagnose.log','EngineRun.cpp','GameAI.cpp','Headless.cpp','HiringStudy.cpp','LiveHiringTrial.h','Step.cpp','TeamStep.cpp']:
 f=p/name
 if f.exists():files.append(f)
for folder in ['verification','diagnostics','timing','golden-cli','before','inputs']:
 for f in (p/folder).rglob('*'):
  if f.is_file() and f.suffix not in ['.o'] and f.name!='glob2-trial':files.append(f)
files=sorted(set(files))
manifest={str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files}
(p/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2));files.append(p/'evidence-manifest.json')
with tarfile.open(p/'evidence.tar.gz','w:gz') as tar:
 for f in files:tar.add(f,arcname='snapshot-refactor/'+str(f.relative_to(p)),recursive=False)
f=p/'evidence.tar.gz';print(json.dumps({'files':len(files),'archive_bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}))
