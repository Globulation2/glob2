from pathlib import Path
import json,subprocess
p=Path(__file__).resolve().parent
for c in json.load(open(p/'compile-commands.json')):subprocess.run(c,check=True)
subprocess.run(json.load(open(p/'link-command.json')),check=True)
