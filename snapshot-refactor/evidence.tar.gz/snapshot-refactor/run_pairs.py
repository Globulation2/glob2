from pathlib import Path
import os,json,subprocess,time,hashlib,platform
p=Path(__file__).resolve().parent;out=p/'timing';out.mkdir(exist_ok=False);cases=json.load(open(p.parent/'ai-matches/maps.json'))
binaries={'before':p/'before/glob2-trial','after':p/'glob2-trial'}
def activity():
 lines=subprocess.check_output(['ps','-axo','pid,pcpu,command'],text=True).splitlines()[1:]
 busy=[];observations=[]
 for l in lines:
  cols=l.strip().split(None,2)
  if len(cols)<3:continue
  pid,cpu,cmd=cols
  if (' -c ' in cmd and ('clang' in cmd or 'g++' in cmd)) or ('glob2-engine-tests' in cmd) or ('glob2-unit-tests' in cmd) or ('test/run_tests.py' in cmd):busy.append(l)
  if float(cpu)>10 and int(pid)!=os.getpid():observations.append({'pid':int(pid),'cpu':float(cpu),'command':cmd})
 return busy,observations
meta={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'base':subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip(),'host':platform.platform(),'binaries':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},'protocol':'12 retained256maps8Nicowar; one process warmup per case/arm, ten before/after pairs in rotated case order and alternating arm order.16384ticks including4096warmup,n4. Diagnostics, trace exports, saves off. Exact same K4/R4/vacancies+2/available-only/round-coordinated material policy. All outliers retained. Detected compiler/test-overlapped pairs retained and excluded. ProcessCPU/user+system and elapsed include final drains. HostOS/background activity remains possible; recorded observations accompany every sample.'};(out/'metadata.json').write_text(json.dumps(meta,indent=2))
with (out/'samples.jsonl').open('w') as log:
 for rep in range(-1,10):
  ordered=cases[rep%12:]+cases[:rep%12]
  if rep%2:ordered=list(reversed(ordered))
  for case in ordered:
   attempt=0
   while True:
    while activity()[0]:print('Waiting for host build/test activity',flush=True);time.sleep(5)
    rows=[]
    for arm in (['before','after'] if (rep+cases.index(case))%2 else ['after','before']):
     dest=out/f"{case['name']}-{arm}-r{rep}-a{attempt}";cmd=[str(binaries[arm]),'game','run','--map-file',case['map'],'--game-seed',str(case['game_seed']),'--ticks','16384','--benchmark-warmup','4096','--compute-threads','4','--gpu','off','--output-dir',str(dest)]
     for _ in range(8):cmd+=['--player','nicowar']
     cmd+=['--hiring-schedule','4:4:128:combined','--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds','--hiring-execution','pool']
     env=os.environ.copy();env['GLOB2_ISOLATED_LIVE_HIRING']='1';env.pop('GLOB2_ISOLATED_TRACE',None)
     active,seen=activity();overlap=bool(active);observations=[{'seconds':0,'processes':seen}];start=time.monotonic();last=0
     with dest.with_suffix('.log').open('w') as f:
      proc=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
      while proc.poll() is None:
       active,seen=activity();overlap|=bool(active);elapsed=time.monotonic()-start
       if elapsed-last>=2:observations.append({'seconds':elapsed,'processes':seen});last=elapsed
       time.sleep(.25)
       if elapsed>600:proc.terminate();proc.wait();break
     row={'case':case['name'],'repetition':rep,'attempt':attempt,'arm':arm,'command':cmd,'returncode':proc.returncode,'host_build_overlap':overlap,'host_activity':observations,'result':json.load(open(dest/'result.json')) if (dest/'result.json').exists() else None,'trial':json.load(open(dest/'isolated-live.json')) if (dest/'isolated-live.json').exists() else None};rows.append(row)
    rejected=any(r['host_build_overlap'] for r in rows)
    for r in rows:r['excluded_pair']=rejected;log.write(json.dumps(r)+'\n');log.flush()
    assert all(r['returncode']==0 for r in rows),(case['name'],rep,rows)
    if rejected:attempt+=1;print('Retained/excluded overlapped pair',case['name'],rep,flush=True);continue
    assert rows[0]['result']['finalChecksum']==rows[1]['result']['finalChecksum'],(case['name'],'final checksum differs')
    print('PAIR',rep,case['name'],[(r['arm'],r['trial']['measured_elapsed_ns']/1e9,r['result']['benchmark_run_cpu_ns']/1e9) for r in rows],flush=True);break
(out/'finished.json').write_text(json.dumps({'status':'complete','pairs':120,'warmup_pairs':12,'finished':time.time()}))
