from pathlib import Path
import os,json,subprocess
p=Path(__file__).resolve().parent;out=p/'diagnostics';out.mkdir(exist_ok=False);rows=[]
for case in json.load(open(p.parent/'ai-matches/maps.json'))[::4]:
 for arm,live in [('before',False),('after',False),('before',True),('after',True)]:
  dest=out/f"{case['name']}-{arm}-{'cached' if live else 'original'}";binary=p/'before/glob2-trial' if arm=='before' else p/'glob2-trial'
  cmd=[str(binary),'game','run','--map-file',case['map'],'--game-seed',str(case['game_seed']),'--ticks','16384','--benchmark-warmup','4096','--compute-threads','4','--gpu','off','--output-dir',str(dest),'--telemetry','hiring-stats','--compute-telemetry','waits']
  for _ in range(8):cmd+=['--player','nicowar']
  env=os.environ.copy();env.pop('GLOB2_ISOLATED_LIVE_HIRING',None);env.pop('GLOB2_ISOLATED_TRACE',None)
  if live:env['GLOB2_ISOLATED_LIVE_HIRING']='1';cmd+=['--hiring-schedule','4:4:128:combined','--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds','--hiring-execution','pool']
  with dest.with_suffix('.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
  row={'case':case['name'],'arm':arm,'cached':live,'command':cmd,'result':json.load(open(dest/'result.json')),'trial':json.load(open(dest/'isolated-live.json')),'facts':json.load(open(dest/'snapshot-hiring-facts.json')),'hiring':json.load(open(dest/'hiring-compute.json')) if live else None};rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2));print(case['name'],arm,live,row['trial'],row['facts'],flush=True)
(out/'finished.json').write_text(json.dumps({'status':'complete','runs':len(rows)}))
