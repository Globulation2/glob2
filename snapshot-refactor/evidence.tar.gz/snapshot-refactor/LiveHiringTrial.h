#pragma once
#include "HiringPlanner.h"
#include <array>
#include <chrono>
#include <cstdint>
#include <string>
class Building;
namespace LiveHiringTrial {
inline bool active=false, collect=false;
inline std::string tracePath;
enum Phase { Tasks,Capture,Publication,Snapshot,RouteBootstrap,PhaseCount };
inline std::array<std::uint64_t,PhaseCount> ns{};
inline std::uint64_t examined=0,missing=0,rejected=0,destinationFailures=0,hires=0;
struct Scope {
 Phase phase;bool on;std::chrono::steady_clock::time_point start;
 explicit Scope(Phase p):phase(p),on(collect){if(on)start=std::chrono::steady_clock::now();}
 ~Scope(){if(on)ns[phase]+=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();}
};
const HiringPlanner::BuildingLists* suggestions(const Building&);
}
