import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
def main():
    import sys,os
    sys.path.insert(0,'test');import tests
    tests.ENGINE_TESTS=[e for e in tests.ENGINE_TESTS if any(name in str(e) for name in ['HiringPlannerTest.cpp','HiringRankingTest.cpp','WorldSnapshotTest.cpp','AIObservationTest.cpp','AIOrderSchedulerTest.cpp','FetchApportionmentHarness.cpp','FetchHiringScoreHarness.cpp','HiringBucketHarness.cpp','BuildingProductionCombatTest.cpp','ComputeExecutorHarness.cpp','AIContinuationTest.cpp','GoldenMatchTest.cpp','AreaEffectsTest.cpp','UnitCustomizationTest.cpp'])]
    tests.UNIT_TESTS=[e for e in tests.UNIT_TESTS if any(name in str(e) for name in ['ReplayStepCounterTest.cpp','TurnProtocolTest.cpp','PlatformProtocolTest.cpp','MobileCertificateHarness.cpp','MobileDocumentsHarness.cpp'])]
    os.environ.setdefault('CCACHE','1');os.environ.setdefault('CCACHE_MAXSIZE','12G')
    sys.argv=['scons','dev_fast=1','linker=auto','engine-tests','-j6']
    import SCons.Script
    SCons.Script.main()

if __name__=="__main__":main()
