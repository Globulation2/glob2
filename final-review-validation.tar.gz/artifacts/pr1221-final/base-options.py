linker = 'auto'
release = True
client_profile = 'full'
