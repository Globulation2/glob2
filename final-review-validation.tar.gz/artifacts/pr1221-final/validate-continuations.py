#!/usr/bin/env python3
import argparse,json,os,subprocess,sys,gzip,struct
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--root',type=Path,required=True);p.add_argument('--validation',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=a.root.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(root/'test'))
from check_javascript import compare_payloads,save_header,header_checksum_delta
cases={'small':'games/gd-small-2ai.game.gz','large':'games/gd-large-4ai.game.gz','arena':'games/gd-bigarena-long.game.gz','scripted':'test/fixtures/javascript/realistic-profile1-initial159.game.gz'}
env=os.environ.copy();env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy');results=[]
for name,source in cases.items():
 initial=root/source;checkpoint=a.validation.resolve()/f'{name}-candidate-w1/final.game.gz'
 runs={}
 for kind,saved,workers in [('full',initial,1),('resumed',checkpoint,4)]:
  directory=out/f'{name}-{kind}';command=[str(a.candidate.resolve()),'game','run','--load-game',str(saved),'--ticks','384','--compute-threads',str(workers),'--telemetry','checksums','--save','final','--output-dir',str(directory)]
  if (directory/'result.json').exists():
   assert json.loads((directory/'command.json').read_text())==command
  else:
   directory.mkdir()
   (directory/'command.json').write_text(json.dumps(command,indent=2)+'\n')
   with (directory/'run.log').open('w') as log:subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  runs[kind]=directory
 def payload_differences(first,second):
  x,y=gzip.decompress(first.read_bytes()),gzip.decompress(second.read_bytes())
  assert len(x)==len(y),name+': payload sizes differ'
  n=struct.unpack_from('>I',x)[0];assert n==struct.unpack_from('>I',y)[0];sha=4+n+4*4+1
  return [{'offset':i,'full':u,'resumed':v} for i,(u,v) in enumerate(zip(x,y)) if u!=v and not sha<=i<sha+20]
 differences=payload_differences(runs['full']/'final.game.gz',runs['resumed']/'final.game.gz')
 base_differences=[]
 if differences:
  for kind,saved,workers in [('full',initial,1),('resumed',a.validation.resolve()/f'{name}-base-w1/final.game.gz',4)]:
   directory=out/f'{name}-base-{kind}';directory.mkdir()
   command=[str(a.base.resolve()),'game','run','--load-game',str(saved),'--ticks','384','--compute-threads',str(workers),'--save','final','--output-dir',str(directory)]
   (directory/'command.json').write_text(json.dumps(command,indent=2)+'\n')
   with (directory/'run.log').open('w') as log:subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  base_differences=payload_differences(out/f'{name}-base-full/final.game.gz',out/f'{name}-base-resumed/final.game.gz')
  assert [(x['full'],x['resumed']) for x in differences]==[(x['full'],x['resumed']) for x in base_differences],name+': continuation introduces payload differences beyond base'

 full={int(t):int(v) for t,v in (r.split() for r in (runs['full']/'world.checksums').read_text().splitlines())}
 resumed={int(t):int(v) for t,v in (r.split() for r in (runs['resumed']/'world.checksums').read_text().splitlines())}
 delta=header_checksum_delta(save_header(initial),save_header(checkpoint),168)
 assert set(resumed)==set(range(256,384)),name+': continuation tick coverage'
 assert all(full[t]^delta==v for t,v in resumed.items()),name+': deep continuation differs'
 results.append({'scenario':name,'resume_tick':256,'end_tick':384,'workers':[1,4],'final_payload_identical_excluding_MapHeader_SHA1':not differences,'candidate_payload_differences':differences,'base_payload_differences':base_differences,'deep_traces_match_with_header_version_delta':delta})
 (out/'verified.json').write_text(json.dumps(results,indent=2)+'\n');print(results[-1],flush=True)
