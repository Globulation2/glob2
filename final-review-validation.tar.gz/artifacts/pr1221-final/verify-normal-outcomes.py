#!/usr/bin/env python3
import json
from pathlib import Path
root=Path(__file__).resolve().parent;rows=json.loads((root/'native/measurements.json').read_text());grouped={}
for row in rows:
 path=root/'native'/f"{row['scenario']}-w{row['participants']}-p{row['pair']}-{row['version']}/result.json"
 grouped.setdefault(row['scenario'],[]).append((row,json.loads(path.read_text())))
verified=[]
for name,items in grouped.items():
 first=items[0][1];fields=('ticks','players','teams','winning_teams','unresolved')
 for row,result in items:
  assert all(result.get(key)==first.get(key) for key in fields),(name,row)
 hashes={}
 for version in ('base','candidate'):
  hashes[version]={key:sorted({r[key] for row,r in items if row['version']==version}) for key in ('initialChecksum','finalChecksum')}
  assert all(len(values)==1 for values in hashes[version].values()),(name,version)
 verified.append({'scenario':name,'runs':len(items),'matching_fields':fields,'endpoint_hashes_by_algorithm':hashes})
(root/'normal-outcomes-verified.json').write_text(json.dumps(verified,indent=2)+'\n');print('All 160 uninstrumented runs agree on outcome fields; each checksum algorithm is stable across worker counts and repeats.')
