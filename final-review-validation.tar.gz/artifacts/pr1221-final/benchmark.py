#!/usr/bin/env python3
"""Sequential, alternating release comparisons; retains every command and result."""
import argparse, hashlib, json, math, os, platform, statistics, subprocess, time
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--base',type=Path,required=True)
parser.add_argument('--candidate',type=Path,required=True)
parser.add_argument('--root',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--pairs',type=int,default=10)
args=parser.parse_args()
root=args.root.resolve(); out=args.output.resolve(); out.mkdir(parents=True,exist_ok=True)
bins={key:getattr(args,key).resolve() for key in ('base','candidate')}
scenarios={
 'small':(['--load-game',str(root/'games/gd-small-2ai.game.gz')],4096,512),
 'large':(['--load-game',str(root/'games/gd-large-4ai.game.gz')],4096,512),
 'arena':(['--load-game',str(root/'games/gd-bigarena-long.game.gz')],2048,256),
 'scripted':(['--load-game',str(root/'test/fixtures/javascript/realistic-profile1-initial159.game.gz')],512,64),
}
env=os.environ.copy(); env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
metadata={'platform':platform.platform(),'affinity':sorted(os.sched_getaffinity(0)),
 'binaries':{k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in bins.items()},
 'scenarios':scenarios,'pairs':args.pairs,'policy':'sequential alternating order; telemetry off; identical input saves; no concurrent build/test work'}
(out/'environment.json').write_text(json.dumps(metadata,indent=2)+'\n')
rows=[]
for pair in range(args.pairs):
 for name,(setup,ticks,warmup) in scenarios.items():
  for participants in (1,4):
   for version in (('base','candidate') if pair%2==0 else ('candidate','base')):
    directory=out/f'{name}-w{participants}-p{pair}-{version}'
    command=[str(bins[version]),'game','run',*setup,'--ticks',str(ticks),
      '--compute-threads',str(participants),'--benchmark-warmup',str(warmup),'--output-dir',str(directory)]
    directory.mkdir()
    (directory/'command.json').write_text(json.dumps({'argv':command,'cwd':str(root),
      'env_overrides':{'SDL_VIDEODRIVER':'dummy','SDL_AUDIODRIVER':'dummy'}},indent=2)+'\n')
    started=time.monotonic_ns()
    with (directory/'run.log').open('w') as log:
     process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
     _,status,usage=os.wait4(process.pid,0)
     process.returncode=os.waitstatus_to_exitcode(status)
     if process.returncode: raise subprocess.CalledProcessError(process.returncode,command)
    elapsed=time.monotonic_ns()-started
    result=json.loads((directory/'result.json').read_text())
    measured=result['benchmark_measured_ticks']; assert measured==ticks-warmup,(name,measured)
    row={'scenario':name,'participants':participants,'pair':pair,'version':version,
      'cpu_ns_per_tick':result['benchmark_run_cpu_ns']/measured,
      'run_ns_per_tick':result['run_ns']/ticks,'process_elapsed_ns':elapsed,'peak_rss_kib':usage.ru_maxrss,
      **{key:result[key] for key in ('tick_p50_ns','tick_p95_ns','tick_p99_ns')},
      **{key:result['ai_pipeline'][key] for key in ('allocations','snapshot_peak_allocated_buffers','snapshot_peak_capacity_bytes','snapshot_peak_leased_bytes')}}
    rows.append(row); (out/'measurements.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(f"{name} w{participants} pair {pair+1}/{args.pairs} {version}: CPU {row['cpu_ns_per_tick']/1000:.2f} us/tick, p95 {row['tick_p95_ns']/1000:.2f} us",flush=True)
summary=[]
for name in scenarios:
 for participants in (1,4):
  subset=[r for r in rows if r['scenario']==name and r['participants']==participants]
  entry={'scenario':name,'participants':participants,'pairs':args.pairs,'metrics':{}}
  for metric in ('cpu_ns_per_tick','run_ns_per_tick','tick_p50_ns','tick_p95_ns','tick_p99_ns','peak_rss_kib','allocations','snapshot_peak_allocated_buffers','snapshot_peak_capacity_bytes','snapshot_peak_leased_bytes'):
   ratios=[]
   for pair in range(args.pairs):
    values={r['version']:r[metric] for r in subset if r['pair']==pair}
    ratios.append(math.log(values['candidate']/values['base']))
   mean=statistics.mean(ratios); se=statistics.stdev(ratios)/math.sqrt(len(ratios)) if len(ratios)>1 else 0
   # Two-sided Student-t 95% critical value for 10 pairs (9 degrees of freedom).
   critical=2.262 if len(ratios)==10 else 3.182 if len(ratios)==4 else 2.776 if len(ratios)==5 else 1.96
   entry['metrics'][metric]={'base_median':statistics.median(r[metric] for r in subset if r['version']=='base'),
    'candidate_median':statistics.median(r[metric] for r in subset if r['version']=='candidate'),
    'paired_geomean_percent':100*math.expm1(mean),
    'approx_95_percent_interval':[100*math.expm1(mean-critical*se),100*math.expm1(mean+critical*se)]}
  summary.append(entry)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
