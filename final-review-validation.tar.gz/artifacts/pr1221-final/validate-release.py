#!/usr/bin/env python3
import argparse,hashlib,json,os,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=a.root.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
cases={'small':'games/gd-small-2ai.game.gz','large':'games/gd-large-4ai.game.gz','arena':'games/gd-bigarena-long.game.gz','scripted':'test/fixtures/javascript/realistic-profile1-initial159.game.gz'}
env=os.environ.copy();env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
results=[]
for name,source in cases.items():
 runs={}
 for version,workers in [('base',1),('candidate',1),('candidate',4)]:
  directory=out/f'{name}-{version}-w{workers}';directory.mkdir()
  binary=getattr(a,version).resolve()
  command=[str(binary),'game','run','--load-game',str(root/source),'--ticks','256','--compute-threads',str(workers),'--telemetry','checksums','--write-replay','--save','final','--output-dir',str(directory)]
  (directory/'command.json').write_text(json.dumps(command,indent=2)+'\n')
  with (directory/'run.log').open('w') as log:subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  runs[(version,workers)]=directory
 # Same initial header and deep schema: compare every diagnostic sample, not routine hashes.
 deep=[(directory/'world.checksums').read_bytes() for directory in runs.values()]
 assert deep[0]==deep[1]==deep[2],name+': deep traces differ'
 for file in ('game.replay','final.game.gz','snapshot.checksums'):
  first=(runs[('candidate',1)]/file).read_bytes();second=(runs[('candidate',4)]/file).read_bytes()
  assert first==second,name+': worker output differs: '+file
 result={'scenario':name,'deep_ticks':len(deep[0].splitlines()),'deep_sha256':hashlib.sha256(deep[0]).hexdigest(),'candidate_worker_outputs_identical':['game.replay','final.game.gz','snapshot.checksums']}
 results.append(result);(out/'verified.json').write_text(json.dumps(results,indent=2)+'\n');print(result,flush=True)
