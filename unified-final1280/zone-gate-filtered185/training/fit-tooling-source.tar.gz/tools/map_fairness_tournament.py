#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Map fairness tournament for Globulation 2's random map generators.

Asks whether generated maps are fair in real games, not only by the generator's own
start-quality score. For every generator and map seed the tournament:

1. generates one playable map the way the custom-game lobby does (the best-scoring of five
   rolls derived from the map seed) and writes one copy per cyclic rotation, in which the
   generator's colony t plays as team (t + r) mod N (production map study --rotations);
2. plays free-for-all games with the same AI in every slot on every rotation, differing only in
   the explicit game seed, through glob2 game run and shared durable workers;
3. tallies wins by start position and, separately, by team index. Every team index plays every
   start equally often, so a start that keeps winning is the map's doing and a team index that
   keeps winning is the engine's own processing-order bias.

See docs/map-generators/fairness-tournament.md for the metrics and how to read the report.

  python3 tools/map_fairness_tournament.py run smoke
  python3 tools/map_fairness_tournament.py run standard --jobs 3
  python3 tools/map_fairness_tournament.py summarize artifacts/map-fairness/smoke
"""
import argparse
import csv
import datetime
import json
import math
import os
import random
import re
import shutil
import statistics
import subprocess
import sys
import threading
import time
from pathlib import Path
from build_paths import native_binary
from tournaments.local import run_job as shared_job, export_artifacts, parallel_map
from tournaments.fairness_statistics import (
    MIN_MAPS_FOR_INTERVAL, benjamini_hochberg, bias_interval, bootstrap, chi_square_uniform,
    exact_uniform_p, fair_map_floor, gamma_q, holm, pearson, ranks, rms_points, seed_for,
    share_table, spearman, squared_bias, t975, wilson,
)

ROOT = Path(__file__).resolve().parents[1]
PRESET_DIR = ROOT / 'tools' / 'map-fairness'
BASELINE_METHOD = 15  # Symmetric arena: exactly symmetric starts, the fairness baseline.
# What MapGeneratorStudy's COLONY line actually carries, in order. It used to end with each
# fairness factor's contribution and a total; it now ends with the model's fitness for that colony
# and the win probability it implies. The names here must match that line exactly: zip() below
# truncates silently, so a stale list does not raise - it quietly misnames every column and drops
# the last ones, which is how 'fitness' came to be read as 'wheat' and 'total' ceased to exist.
FACTORS = ['win_probability']
COLONY_FIELDS = ['wheat_distance', 'wood_distance', 'catchment_tiles', 'build_sites',
                 'resource_amount', 'rival_distance', 'rivals_within_threat', 'mean_fertility',
                 'fitness', *FACTORS]
RUN_FILES = ['config.json', 'summary.json', 'summary.md', 'games.csv', 'colonies.csv', 'maps.csv',
             'verification.json']
RUN_DIRECTORIES = ['maps', 'games', 'profiles', 'verify']

DEFAULTS = {
    'name': 'custom',
    'description': '',
    'generators': [BASELINE_METHOD],
    'map_seeds': [1001],
    'games_per_rotation': 1,
    'engine_seed_base': 1,
    'rotations': 'all',
    'size': 128,
    'colonies': 4,
    'workers': None,
    'controls': {},
    'candidates': 5,
    'ai': 'nicowar',
    'tick_cap': 90000,
    'jobs': 3,
    'game_timeout_seconds': 3600,
    'keep_replays': False,
    'timeline': False,
    'verify_games': 0,
    'bootstrap_draws': 4000,
}


def remove_tree(path, inside):
    """Delete a directory, but only one strictly inside `inside` (the run directory)."""
    target, root = Path(path).resolve(), Path(inside).resolve()
    if target == root or not target.is_relative_to(root):
        raise RuntimeError(f'refusing to delete {target}: not inside {root}')
    shutil.rmtree(target, ignore_errors=True)


# ---------------------------------------------------------------------------- configuration

def parse_int_list(spec):
    """'1001-1004', '1001,1005', a JSON list or {"start", "count"} as a list of ints."""
    if isinstance(spec, dict):
        start = int(spec['start'])
        return list(range(start, start + int(spec['count'])))
    if isinstance(spec, (list, tuple)):
        return [int(s) for s in spec]
    values = []
    for part in str(spec).split(','):
        part = part.strip()
        if not part:
            continue
        if '-' in part:
            first, last = part.split('-', 1)
            values.extend(range(int(first), int(last) + 1))
        else:
            values.append(int(part))
    return values


def load_config(preset, overrides):
    path = Path(preset)
    if path.suffix != '.json':
        path = PRESET_DIR / f'{preset}.json'
    if not path.exists():
        raise SystemExit(f'error: preset not found: {path}')
    config = dict(DEFAULTS)
    config.update(json.loads(path.read_text()))
    for key, value in overrides.items():
        if value is not None:
            config[key] = value
    resolved = path.resolve()
    config['preset_file'] = str(resolved.relative_to(ROOT)) if resolved.is_relative_to(ROOT) else str(resolved)
    config['map_seeds'] = parse_int_list(config['map_seeds'])
    generators = config['generators']
    if isinstance(generators, str):
        generators = parse_int_list(generators)
    config['generators'] = [g if isinstance(g, dict) else {'method': int(g)} for g in generators]
    size = config['size']
    width, height = (size, size) if isinstance(size, int) else (int(size[0]), int(size[1]))
    for side in (width, height):
        if side < 16 or side & (side - 1):
            raise SystemExit(f'error: map sides must be powers of two >= 16 (got {width}x{height})')
    config['width'], config['height'] = width, height
    colonies = int(config['colonies'])
    rotations = colonies if config['rotations'] == 'all' else int(config['rotations'])
    if not 1 <= rotations <= colonies:
        raise SystemExit(f'error: rotations must be "all" or 1..{colonies}')
    config['rotation_count'] = rotations
    return config


def generator_controls(config, generator):
    controls = dict(config.get('controls', {}).get(str(generator['method']), {}))
    controls.update(generator.get('controls', {}))
    return controls


def git_revision():
    def git(*args):
        return subprocess.run(['git', *args], cwd=ROOT, capture_output=True, text=True).stdout.strip()
    revision = git('rev-parse', 'HEAD')
    dirty = bool(git('status', '--porcelain', '--untracked-files=no'))
    return revision + ('-dirty' if dirty else '')


# ---------------------------------------------------------------------------- map production

def map_key(method, seed):
    return f'g{method}-s{seed}'


def parse_study(stdout):
    record = {'colony_quality': [], 'starts': [], 'files': [], 'options': {}}
    for line in stdout.splitlines():
        parts = line.strip().split(',')
        tag = parts[0]
        if tag == 'STUDY':
            record['generated'] = parts[3] == '1'
            record['generation_seconds'] = float(parts[14])
        elif tag == 'SAMPLED':
            record['root_seed'], record['chosen_seed'], record['candidates'] = map(int, parts[1:4])
        elif tag == 'QUALITY':
            record['quality'] = {'measured': parts[1] == '1', 'score': float(parts[2]),
                                 'fairness': float(parts[3]), 'worst': float(parts[4]),
                                 'best': float(parts[5])}
        elif tag == 'COLONY':
            if len(parts) != len(COLONY_FIELDS) + 2:
                raise ValueError(f'Unexpected COLONY field count: {len(parts) - 2}; '
                                 f'expected {len(COLONY_FIELDS)}')
            record['colony_quality'].append(dict(zip(COLONY_FIELDS, (float(v) for v in parts[2:]))))
        elif tag == 'REQUEST':
            record['request'] = {'generator_id': parts[1], 'revision': int(parts[2]),
                                 'seed': int(parts[3]), 'wDec': int(parts[4]), 'hDec': int(parts[5]),
                                 'teams': int(parts[6]), 'workers': int(parts[7])}
        elif tag == 'OPTION':
            record['options'][parts[1]] = int(parts[2])
        elif tag == 'START':
            record['starts'].append([int(parts[2]), int(parts[3])])
        elif tag == 'MAPFILE':
            record['files'].append({'rotation': int(parts[1]), 'path': ','.join(parts[2:-2]),
                                    'bytes': int(parts[-2]), 'fnv1a64': parts[-1]})
        elif tag == 'ROTATIONS':
            record['rotation_checks'] = dict(zip(
                ['teams', 'rotations', 'save_load_stable', 'references_consistent',
                 'colonies_placed', 'round_trip', 'reload_idempotent'], map(int, parts[1:8])))
    return record


def produce_map(config, paths, generator, seed):
    method = generator['method']
    key = map_key(method, seed)
    directory = paths['maps'] / key
    manifest = directory / 'map.json'
    if manifest.exists():
        record = json.loads(manifest.read_text())
        if record.get('ok') or record.get('failure') == 'generation':
            return record
    remove_tree(directory, paths['out'])
    directory.mkdir(parents=True)
    profile = paths['profiles'] / f'study-{key}'
    remove_tree(profile, paths['out'])
    profile.mkdir(parents=True)
    colonies = int(config['colonies'])
    command = [str(paths['study']), str(method), str(seed), 'glob2-fairness',
               f'w={int(math.log2(config["width"]))}', f'h={int(math.log2(config["height"]))}',
               f'teams={colonies}', 'quality', f'candidates={int(config["candidates"])}',
               f'save={directory / "map"}', f'rotations={config["rotation_count"]}',
               f'name=fairness-{key}']
    if config.get('workers'):
        command.append(f'workers={int(config["workers"])}')
    controls = generator_controls(config, generator)
    command += [f'{k}={v}' for k, v in controls.items()]
    begun = time.monotonic()
    params = {'width': int(math.log2(config['width'])), 'height': int(math.log2(config['height'])),
              'teams': colonies, **controls}
    if config.get('workers'): params['workers'] = config['workers']
    attempt, source = shared_job(paths['glob2'], ROOT, directory / 'execution', 'generate_map',
        config={'generator': method, 'params': params, 'candidates': config['candidates'],
                'rotations': config['rotation_count']}, seeds={'map': seed}, outputs={'map': True}, timeout=1800)
    command = attempt.get('command', command)
    export_artifacts(source, attempt, directory / 'native')
    with source.open_artifact(attempt, 'stdout.log') as stream: stdout = stream.read()
    with source.open_artifact(attempt, 'stderr.log') as stream: stderr = stream.read()
    # Legacy reports retain their column names and statistical inputs.
    (directory / 'study.log').write_text(stdout + stderr)
    exit_code = 0 if attempt['category'] == 'success' else 4 if attempt['category'] == 'generation_failed' else attempt.get('exit_code', 1)
    remove_tree(profile, paths['out'])
    record = parse_study(stdout)
    for entry in record.get('files', []):
        entry['path'] = str(directory / 'native' / f'map-r{entry["rotation"]}.map.gz')
    record.update({
        'key': key, 'method': method, 'map_seed': seed, 'colonies': colonies,
        'width': config['width'], 'height': config['height'], 'controls': controls,
        'study_command': [str(Path(c).relative_to(ROOT)) if c.startswith(str(ROOT)) else c
                          for c in command],
        'exit_code': exit_code, 'wall_seconds': round(time.monotonic() - begun, 3),
        'git_revision': paths['git_revision'],
    })
    record.setdefault('chosen_seed', seed)
    checks = record.get('rotation_checks', {})
    if exit_code == 4 or (exit_code == 0 and not record.get('generated', False)):
        record.update(ok=False, failure='generation')
    elif exit_code != 0 or not checks or not all(
            checks.get(k) for k in ('references_consistent', 'colonies_placed', 'round_trip',
                                    'reload_idempotent')):
        record.update(ok=False, failure=f'study exit {exit_code}')
    elif len(record['starts']) != colonies or len(record['files']) != config['rotation_count']:
        record.update(ok=False, failure='incomplete study output')
    else:
        record['ok'] = True
    manifest.write_text(json.dumps(record, indent=2))
    return record


# ---------------------------------------------------------------------------- matches

END_RE = re.compile(r'^GLOB2_GAME_END ticks=(\d+) winner_team=(-?\d+) seed=(\d+) '
                    r'map="([^"]*)" orders=(\d+)')


def parse_game_log(text):
    parsed = {'end': None, 'teams': {}, 'reason': None, 'cap_checksum': None}
    for line in text.splitlines():
        if line.startswith('GLOB2_GAME_END'):
            match = END_RE.match(line)
            if match:
                parsed['end'] = {'ticks': int(match[1]), 'winner_team': int(match[2]),
                                 'seed': int(match[3]), 'map': match[4], 'orders': int(match[5])}
        elif line.startswith('GLOB2_TEAM_RESULT '):
            fields = dict(item.split('=', 1) for item in line.split()[1:])
            team = int(fields.pop('team'))
            start = [int(v) for v in fields.pop('start').split(',')]
            entry = {k: (v if k == 'result' else int(v)) for k, v in fields.items()}
            entry['start'] = start
            parsed['teams'][team] = entry
        elif line.startswith('nox::gui.game.totalPrestigeReached'):
            parsed['reason'] = parsed['reason'] or 'prestige'
        elif line.startswith('nox::gui.game.isGameEnded'):
            parsed['reason'] = parsed['reason'] or 'elimination'
        elif line.startswith('nox::gui.game.checkSum() = '):
            parsed['cap_checksum'] = line.split('=', 1)[1].strip()
    return parsed


def adjudicate(game, record, config):
    """Winner, placement and elimination order by start position, from a parsed game."""
    n = record['colonies']
    rotation = game['rotation']
    teams = {int(t): e for t, e in game['parsed']['teams'].items()}
    end = game['parsed']['end']
    slot_of = lambda team: (team - rotation) % n
    outcome = {'status': game['status'], 'end_reason': None, 'ticks': None, 'winner_team': None,
               'winner_slot': None, 'adjudication': 'none', 'start_mismatch': False,
               'elimination_order': [], 'placement': {}}
    if game['status'] != 'ok' or end is None or len(teams) != n:
        outcome['status'] = game['status'] if game['status'] != 'ok' else 'incomplete'
        return outcome
    outcome['ticks'] = end['ticks']
    for team, entry in teams.items():
        if entry['start'] != record['starts'][slot_of(team)]:
            outcome['start_mismatch'] = True
    cap = int(config['tick_cap'])
    winners = [t for t, e in teams.items() if e['result'] == 'won']
    alive = [t for t, e in teams.items() if e['alive']]
    # At the cap: prestige (the engine's own victory measure), then population, then finished
    # buildings. Stalled colonies often have no prestige at all, so population usually decides.
    criteria = ('prestige', 'units', 'buildings')
    strength = lambda t: tuple(teams[t][c] for c in criteria)
    if end['winner_team'] >= 0:
        outcome['end_reason'] = game['parsed']['reason'] or 'elimination'
        winner = end['winner_team']
        outcome['adjudication'] = 'decisive' if len(winners) == 1 else 'decisive-shared'
    elif end['ticks'] >= cap:
        outcome['end_reason'] = 'cap'
        ranked = sorted(alive, key=strength, reverse=True)
        if len(ranked) == 1:
            winner = ranked[0]
            outcome['adjudication'] = 'cap-sole-survivor'
        elif ranked and strength(ranked[0]) != strength(ranked[1]):
            winner = ranked[0]
            decided_by = next(c for c, a, b in zip(criteria, strength(ranked[0]), strength(ranked[1])) if a != b)
            outcome['adjudication'] = f'cap-{decided_by}'
        else:
            winner = None
            outcome['adjudication'] = 'cap-tie' if ranked else 'cap-none-alive'
    else:
        outcome['end_reason'] = game['parsed']['reason'] or 'no-winner'
        winner = None
        outcome['adjudication'] = 'no-winner'
    if winner is not None:
        outcome['winner_team'] = winner
        outcome['winner_slot'] = slot_of(winner)
    eliminated = sorted((e['eliminated_tick'], t) for t, e in teams.items() if e['eliminated_tick'] >= 0)
    outcome['elimination_order'] = [[slot_of(t), tick] for tick, t in eliminated]
    # Placement 1 is the winner; other survivors by strength, then eliminated colonies, the
    # later-eliminated ahead. Ties break towards the lower start index, only to stay deterministic.
    survivors = sorted((t for t in teams if t != winner and teams[t]['eliminated_tick'] < 0),
                       key=lambda t: (tuple(-v for v in strength(t)), slot_of(t)))
    fallen = [t for _, t in sorted(((-e['eliminated_tick'], slot_of(t)), t)
                                   for t, e in teams.items() if t != winner and e['eliminated_tick'] >= 0)]
    order = ([winner] if winner is not None else []) + survivors + fallen
    outcome['placement'] = {slot_of(t): place + 1 for place, t in enumerate(order)}
    return outcome


def game_jobs(config, records):
    jobs = []
    per_rotation = int(config['games_per_rotation'])
    for k in range(per_rotation):
        for rotation in range(config['rotation_count']):
            for record in records:
                if record.get('ok'):
                    seed = int(config['engine_seed_base']) + rotation * per_rotation + k
                    jobs.append({'map': record['key'], 'rotation': rotation, 'game': k, 'seed': seed})
    return jobs


def run_game(config, paths, record, job, directory=None, force=False):
    directory = directory or paths['games'] / record['key'] / f'r{job["rotation"]}-k{job["game"]}'
    result_file = directory / 'result.json'
    if result_file.exists() and not force:
        return json.loads(result_file.read_text())
    remove_tree(directory, paths['out'])
    profile = directory / 'profile'
    (profile / 'maps').mkdir(parents=True)
    map_file = next(f for f in record['files'] if f['rotation'] == job['rotation'])
    map_name = f'fairness-{record["key"]}-r{job["rotation"]}'
    # map_file's content is always gzip-compressed (map generation always produces
    # a ".gz" file); name the symlink to match so the engine inflates it.
    os.symlink(Path(map_file['path']).resolve(), profile / 'maps' / f'{map_name}.map.gz')
    env = dict(os.environ)
    env.update(GLOB2_USER_DIR=str(profile), GLOB2_TEST_SEED=str(job['seed']),
               GLOB2_TEAM_RESULTS='1', GLOB2_TEST_MAX_TICKS=str(int(config['tick_cap'])),
               GLOB2_REPLAY_PATH=str(directory / 'game.replay'))
    if config.get('timeline'):
        env['GLOB2_TEAM_TIMELINE'] = '1'
    command = [str(paths['glob2']), 'dev', 'random-games', '--runs', '1', '--map', map_name,
               '--matchup', ','.join([config['ai']] * record['colonies'])]
    log = directory / 'game.log'
    begun = time.monotonic()
    attempt, source = shared_job(paths['glob2'], ROOT, directory / 'execution', 'game',
        config={'players': [config['ai']] * record['colonies'], 'ticks': int(config['tick_cap'])},
        seeds={'game': job['seed']}, inputs={'map': map_file['path']},
        outputs={'replay': bool(config.get('keep_replays')), 'telemetry': ['team-timeline'] if config.get('timeline') else []},
        timeout=float(config['game_timeout_seconds']))
    with source.open_artifact(attempt, 'stdout.log') as stream: text = stream.read()
    log.write_text(text)
    command = attempt.get('command', command)
    status = 'ok' if attempt['category'] == 'success' else attempt['category']
    wall = time.monotonic() - begun
    text = log.read_text(errors='replace')
    parsed = parse_game_log(text)
    native = attempt.get('result') or {}
    if native.get('teams'):
        parsed['teams'] = {str(t['team']): dict(t, result={'won':'won','lost':'lost','unresolved':'undecided'}[t['outcome']], alive=int(t['alive'])) for t in native['teams']}
    remove_tree(profile, paths['out'])
    replay = directory / 'game.replay'
    if not config.get('keep_replays') and replay.exists():
        replay.unlink()
    game = {**job, 'status': status, 'wall_seconds': round(wall, 3), 'parsed': parsed,
            'command': command[1:], 'env': {k: env[k] for k in (
                'GLOB2_TEST_SEED', 'GLOB2_TEAM_RESULTS', 'GLOB2_TEST_MAX_TICKS')}}
    game['outcome'] = adjudicate(game, record, config)
    # Keep only what the analysis reads; the full engine output can be large.
    if game['outcome']['status'] == 'ok':
        keep = [l for l in text.splitlines() if l.startswith(('GLOB2_', 'nox::', 'Random Seed'))]
        log.write_text('\n'.join(keep) + '\n')
    # Round-trip through JSON now so a fresh result and one read back from disk compare equal.
    game = json.loads(json.dumps(game))
    result_file.write_text(json.dumps(game, indent=1))
    return game


def run_pool(tasks, jobs, work, describe):
    results = [None] * len(tasks)
    lock = threading.Lock()
    done = 0
    begun = time.monotonic()
    for i, result in enumerate(parallel_map(work, tasks, jobs)):
        results[i] = result
        done += 1
        elapsed = time.monotonic() - begun
        print(f'[{done}/{len(tasks)} {elapsed:.0f}s] {describe(tasks[i], result)}', flush=True)
    return results


# ---------------------------------------------------------------------------- statistics

def load_results(out):
    records = {}
    for manifest in sorted((out / 'maps').glob('*/map.json')):
        record = json.loads(manifest.read_text())
        records[record['key']] = record
    games = [json.loads(result.read_text()) for result in sorted((out / 'games').glob('*/*/result.json'))]
    return records, games


def analyse_map(record, games, config):
    n = record['colonies']
    played = [g for g in games if g['outcome']['status'] == 'ok']
    wins = [0] * n
    decisive = [0] * n
    team_wins = [0] * n
    placement_points = [0.0] * n
    for game in played:
        outcome = game['outcome']
        if outcome['winner_slot'] is not None:
            wins[outcome['winner_slot']] += 1
            team_wins[outcome['winner_team']] += 1
            if outcome['adjudication'].startswith('decisive'):
                decisive[outcome['winner_slot']] += 1
        for slot, place in outcome['placement'].items():
            placement_points[int(slot)] += (n - place) / (n - 1) if n > 1 else 1.0
    rows = record.get('colony_quality', [])
    quality = ([c['fitness'] for c in rows]
               if len(rows) == n and all('fitness' in c for c in rows) else None)
    analysis = {
        'key': record['key'], 'method': record['method'], 'map_seed': record['map_seed'],
        'chosen_seed': record.get('chosen_seed'), 'games': len(games), 'played': len(played),
        'errors': len(games) - len(played),
        'cap_games': sum(g['outcome']['end_reason'] == 'cap' for g in played),
        'prestige_games': sum(g['outcome']['end_reason'] == 'prestige' for g in played),
        'unresolved': sum(g['outcome']['winner_slot'] is None for g in played),
        'start_mismatches': sum(g['outcome']['start_mismatch'] for g in played),
        'ticks_median': statistics.median([g['outcome']['ticks'] for g in played]) if played else None,
        'wall_seconds_mean': statistics.mean([g['wall_seconds'] for g in played]) if played else None,
        'slot': share_table(wins, seed_for(record['key'], 'slot')),
        'decisive_slot': share_table(decisive, seed_for(record['key'], 'decisive')),
        'team': share_table(team_wins, seed_for(record['key'], 'team')),
        'placement_score': [p / len(played) if played else None for p in placement_points],
        'quality': quality, 'quality_score': record.get('quality', {}).get('score'),
        'starts': record['starts'],
        'record_colonies': rows if len(rows) == n else [],
    }
    analysis['quality_spearman'] = spearman(quality, wins) if quality and sum(wins) and n >= 3 else None
    return analysis


def scorer_points(maps, factor):
    """(map, within-map centred factor, centred win share, centred placement score) per colony."""
    points = []
    for m in maps:
        wins = m['slot']['counts']
        n_wins = sum(wins)
        if not m['record_colonies'] or n_wins == 0:
            continue
        # A run recorded before a COLONY_FIELDS change can be missing a factor entirely. Skip it
        # rather than abandoning the whole summary: the games are the expensive part and they are
        # still perfectly good.
        if any(factor not in c for c in m['record_colonies']):
            continue
        values = [c[factor] for c in m['record_colonies']]
        if max(values) - min(values) < 1e-9:
            continue
        k = len(values)
        mean_value = sum(values) / k
        mean_place = sum(m['placement_score']) / k
        for slot in range(k):
            points.append((m['key'], values[slot] - mean_value, wins[slot] / n_wins - 1 / k,
                           m['placement_score'][slot] - mean_place))
    return points


def scorer_permutation_p(points, observed, column, draws, seed):
    """Two-sided p for a pooled rank correlation: shuffle quality among each map's own colonies."""
    if observed is None:
        return None
    by_map = {}
    for point in points:
        by_map.setdefault(point[0], []).append(point)
    rng = random.Random(seed)
    hits = 0
    for _ in range(draws):
        xs, ys = [], []
        for rows in by_map.values():
            qualities = [p[1] for p in rows]
            rng.shuffle(qualities)
            xs += qualities
            ys += [p[column] for p in rows]
        value = spearman(xs, ys)
        hits += value is not None and abs(value) >= abs(observed) - 1e-12
    return (hits + 1) / (draws + 1)


def scorer_check(maps, draws, seed):
    check = {}
    permutation_draws = min(draws, 2000)
    for factor in ['fitness', *FACTORS]:
        points = scorer_points(maps, factor)
        keys = sorted({p[0] for p in points})
        if len(points) < 3:
            check[factor] = None
            continue

        def rho(sample_keys, column):
            chosen = [p for key in sample_keys for p in points if p[0] == key]
            return spearman([p[1] for p in chosen], [p[column] for p in chosen])
        enough = len(keys) >= MIN_MAPS_FOR_INTERVAL
        entry = {'maps': len(keys), 'colonies': len(points), 'wins_rho': rho(keys, 2),
                 'placement_rho': rho(keys, 3),
                 'wins_rho_ci': bootstrap(keys, lambda s: rho(s, 2), draws, seed) if enough else None,
                 'placement_rho_ci': bootstrap(keys, lambda s: rho(s, 3), draws, seed + 1) if enough else None}
        if factor == 'fitness':
            entry['wins_rho_p'] = scorer_permutation_p(points, entry['wins_rho'], 2, permutation_draws, seed + 2)
            entry['placement_rho_p'] = scorer_permutation_p(points, entry['placement_rho'], 3,
                                                            permutation_draws, seed + 3)
        check[factor] = entry
    # Does the start the scorer rates best win more than a start picked at random on the same map?
    top_wins = top_n = 0
    alternatives = []
    for m in maps:
        if any('fitness' not in c for c in m['record_colonies']):
            continue
        values = [c['fitness'] for c in m['record_colonies']]
        if not values or max(values) - min(values) < 1e-9 or not m['slot']['n']:
            continue
        top = max(range(len(values)), key=lambda i: values[i])
        top_wins += m['slot']['counts'][top]
        top_n += m['slot']['n']
        alternatives.append(m['slot']['counts'])
    p_value = None
    if alternatives:
        rng = random.Random(seed + 4)
        hits = sum(sum(rng.choice(counts) for counts in alternatives) >= top_wins
                   for _ in range(permutation_draws))
        p_value = (hits + 1) / (permutation_draws + 1)
    check['top_rated_start'] = {'wins': top_wins, 'n': top_n, 'maps': len(alternatives),
                                'share': top_wins / top_n if top_n else None, 'p_one_sided': p_value}
    return check


def decisive_headline(maps, n):
    """Position bias from games won outright (elimination or prestige), leaving out capped games."""
    usable = [m for m in maps if m['decisive_slot']['n'] >= 2]
    biases = [m['decisive_slot']['squared_bias'] for m in usable]
    return {
        'decisive_maps': len(usable),
        'decisive_games': sum(m['decisive_slot']['n'] for m in maps),
        'decisive_rms_points': rms_points(statistics.mean(biases), n) if biases else None,
        'decisive_rms_points_ci': bias_interval(biases, n),
        'decisive_fair_floor': fair_map_floor([m['decisive_slot']['n'] for m in usable], n),
        'decisive_maps_p05': sum(m['decisive_slot']['p'] < 0.05 for m in usable),
    }


def analyse_generator(method, maps, config, catalog):
    n = int(config['colonies'])
    draws = int(config['bootstrap_draws'])
    usable = [m for m in maps if m['slot']['n'] >= 2]
    p_values = [m['slot']['p'] for m in usable]
    bh = benjamini_hochberg(p_values) if p_values else []
    hl = holm(p_values) if p_values else []
    for m, q, h in zip(usable, bh, hl):
        m['slot']['q_bh'] = q
        m['slot']['p_holm'] = h
    biases = [m['slot']['squared_bias'] for m in usable]
    mean_bias = statistics.mean(biases) if biases else None
    seed = seed_for('generator', method)
    pooled_slot = [sum(m['slot']['counts'][s] for m in maps) for s in range(n)]
    pooled_team = [sum(m['team']['counts'][t] for m in maps) for t in range(n)]
    # Is any of this generator's maps biased? Sum of per-map chi-square statistics, calibrated
    # by simulating every map's winners under a fair map (seeded, so the report reproduces).
    observed = sum(m['slot']['chi2'] for m in usable) if usable else None
    pooled_p = None
    if usable:
        rng = random.Random(seed + 7)
        simulations = 4000
        hits = 0
        for _ in range(simulations):
            total = 0.0
            for m in usable:
                xs = [0] * n
                for _ in range(m['slot']['n']):
                    xs[rng.randrange(n)] += 1
                total += chi_square_uniform(xs)[0]
            hits += total >= observed - 1e-9
        pooled_p = (hits + 1) / (simulations + 1)
    info = catalog.get(method, {})
    played = sum(m['played'] for m in maps)
    return {
        'method': method, 'name': info.get('nameKey', str(method)), 'id': info.get('id'),
        'revision': info.get('revision'), 'maps': len(maps), 'maps_with_winners': len(usable),
        'games': sum(m['games'] for m in maps), 'played': played,
        'errors': sum(m['errors'] for m in maps),
        'cap_share': sum(m['cap_games'] for m in maps) / played if played else None,
        'prestige_share': sum(m['prestige_games'] for m in maps) / played if played else None,
        'unresolved': sum(m['unresolved'] for m in maps),
        'start_mismatches': sum(m['start_mismatches'] for m in maps),
        'headline_rms_points': rms_points(mean_bias, n), 'headline_rms_points_ci': bias_interval(biases, n),
        'headline_fair_floor': fair_map_floor([m['slot']['n'] for m in usable], n),
        'mean_squared_bias': mean_bias,
        # The same headline counting only games won outright, so cap adjudication cannot drive it.
        **decisive_headline(maps, n),
        'maps_p05': sum(p < 0.05 for p in p_values), 'maps_bh05': sum(q < 0.05 for q in bh),
        'maps_holm05': sum(h < 0.05 for h in hl),
        'expected_p05_by_chance': 0.05 * len(p_values),
        'dominance': {'min': min(m['slot']['dominance'] for m in usable),
                      'median': statistics.median(m['slot']['dominance'] for m in usable),
                      'max': max(m['slot']['dominance'] for m in usable)} if usable else None,
        'pooled_chi2': observed, 'pooled_p': pooled_p,
        'slot_index': share_table(pooled_slot, seed + 11),
        'team_index': share_table(pooled_team, seed + 13),
        # Symmetric arena's colonies are identical by construction, so there is nothing to predict.
        'scorer': scorer_check(maps, draws, seed + 17) if method != BASELINE_METHOD else None,
        'ticks_median': statistics.median([m['ticks_median'] for m in maps if m['ticks_median']])
        if played else None,
        'wall_seconds_mean': statistics.mean([m['wall_seconds_mean'] for m in maps if m['wall_seconds_mean']])
        if played else None,
        'map_keys': [m['key'] for m in maps],
    }


def load_catalog(study):
    try:
        entries = json.loads(subprocess.run([str(study), 'info', 'catalog', '--format', 'json'], cwd=ROOT, capture_output=True,
                                            text=True, timeout=60).stdout)
        return {e['method']: e for e in entries['generators']}
    except Exception:
        return {}


def summarize(out, config, paths):
    records, games = load_results(out)
    # Outcomes are recomputed from each game's stored engine output, so a change to the
    # adjudication rule applies to earlier games without replaying them.
    for game in games:
        if game['map'] in records:
            game['outcome'] = adjudicate(game, records[game['map']], config)
    catalog = load_catalog(paths['study'])
    by_map = {}
    for game in games:
        by_map.setdefault(game['map'], []).append(game)
    maps = [analyse_map(record, by_map.get(key, []), config)
            for key, record in records.items() if record.get('ok')]
    generators = []
    for method in [g['method'] for g in config['generators']]:
        chosen = [m for m in maps if m['method'] == method]
        failed = [r for r in records.values() if r['method'] == method and not r.get('ok')]
        summary = analyse_generator(method, chosen, config, catalog)
        summary['failed_maps'] = [{'map_seed': r['map_seed'], 'failure': r.get('failure')} for r in failed]
        generators.append(summary)
    n = int(config['colonies'])
    all_team = [sum(m['team']['counts'][t] for m in maps) for t in range(n)]
    baseline_team = [sum(m['team']['counts'][t] for m in maps if m['method'] == BASELINE_METHOD)
                     for t in range(n)]
    played = [g for g in games if g['outcome']['status'] == 'ok']
    walls = [g['wall_seconds'] for g in played]
    ticks = [g['outcome']['ticks'] for g in played]
    summary = {
        'config': config, 'git_revision': paths['git_revision'],
        'generated_at': datetime.datetime.now().isoformat(timespec='seconds'),
        'balanced': config['rotation_count'] == n,
        'games': len(games), 'played': len(played),
        'wall_seconds': {'mean': statistics.mean(walls) if walls else None,
                         'median': statistics.median(walls) if walls else None,
                         'max': max(walls) if walls else None,
                         'total': sum(walls),
                         'per_1000_ticks': sum(walls) / sum(ticks) * 1000 if ticks and sum(ticks) else None},
        'ticks': {'median': statistics.median(ticks) if ticks else None, 'max': max(ticks) if ticks else None},
        'end_reasons': {reason: sum(g['outcome']['end_reason'] == reason for g in played)
                        for reason in sorted({g['outcome']['end_reason'] for g in played}, key=str)},
        'engine_team_index': {'all_generators': share_table(all_team, 101),
                              'baseline': share_table(baseline_team, 103)},
        'scorer_all_generators': scorer_check([m for m in maps if m['method'] != BASELINE_METHOD],
                                              int(config['bootstrap_draws']), 107),
        'generators': generators,
        'maps': [{k: v for k, v in m.items() if k != 'record_colonies'} for m in maps],
        'verification': json.loads((out / 'verification.json').read_text())
        if (out / 'verification.json').exists() else None,
    }
    (out / 'summary.json').write_text(json.dumps(summary, indent=2))
    write_csvs(out, records, games)
    (out / 'summary.md').write_text(markdown(summary, config))
    return summary


def write_csvs(out, records, games):
    ordered = sorted(games, key=lambda g: (g['map'], g['rotation'], g['game']))
    with open(out / 'games.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['generator', 'map_seed', 'map_roll_seed', 'rotation', 'engine_seed', 'status',
                         'end_reason', 'adjudication', 'ticks', 'wall_seconds', 'winner_start',
                         'winner_team', 'winner_x', 'winner_y', 'elimination_order', 'placement_by_start',
                         'start_mismatch', 'orders', 'cap_checksum'])
        for g in ordered:
            record = records[g['map']]
            o = g['outcome']
            end = g['parsed']['end'] or {}
            start = record['starts'][o['winner_slot']] if o['winner_slot'] is not None else [None, None]
            writer.writerow([record['method'], record['map_seed'], record.get('chosen_seed'), g['rotation'],
                             g['seed'], o['status'], o['end_reason'], o['adjudication'], o['ticks'],
                             g['wall_seconds'], o['winner_slot'], o['winner_team'], start[0], start[1],
                             ';'.join(f'{s}@{t}' for s, t in o['elimination_order']),
                             ';'.join(f'{s}:{p}' for s, p in sorted(o['placement'].items(), key=lambda i: int(i[0]))),
                             int(o['start_mismatch']), end.get('orders'), g['parsed']['cap_checksum']])
    team_fields = ['result', 'alive', 'eliminated_tick', 'prestige', 'units', 'workers', 'explorers',
                   'warriors', 'buildings', 'sites']
    with open(out / 'colonies.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['generator', 'map_seed', 'rotation', 'engine_seed', 'start', 'team', 'start_x',
                         'start_y', 'placement', 'won', *team_fields, 'quality_fitness',
                         *[f'quality_{f}' for f in FACTORS]])
        for g in ordered:
            record = records[g['map']]
            n = record['colonies']
            placement = {int(k): v for k, v in g['outcome']['placement'].items()}
            for team, entry in sorted(g['parsed']['teams'].items(), key=lambda i: int(i[0])):
                slot = (int(team) - g['rotation']) % n
                rows = record.get('colony_quality', [])
                quality = rows[slot] if len(rows) == n else {}
                writer.writerow([record['method'], record['map_seed'], g['rotation'], g['seed'], slot, team,
                                 *record['starts'][slot], placement.get(slot),
                                 int(g['outcome']['winner_slot'] == slot),
                                 *[entry.get(k) for k in team_fields], quality.get('fitness'),
                                 *[quality.get(f) for f in FACTORS]])
    with open(out / 'maps.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['generator', 'map_seed', 'roll_seed', 'ok', 'failure', 'quality_score',
                         'quality_fairness', 'starts', 'quality_by_start', 'map_fnv1a64_r0',
                         'generation_seconds'])
        for record in records.values():
            writer.writerow([record['method'], record['map_seed'], record.get('chosen_seed'),
                             int(bool(record.get('ok'))), record.get('failure'),
                             record.get('quality', {}).get('score'), record.get('quality', {}).get('fairness'),
                             ';'.join(f'{x}:{y}' for x, y in record.get('starts', [])),
                             ';'.join(f'{c["fitness"]:.3f}' if 'fitness' in c else ''
                                      for c in record.get('colony_quality', [])),
                             next((f['fnv1a64'] for f in record.get('files', []) if f['rotation'] == 0), None),
                             record.get('generation_seconds')])


# ---------------------------------------------------------------------------- report

def pct(value, digits=1):
    return '-' if value is None else f'{100 * value:.{digits}f}%'


def num(value, digits=2):
    return '-' if value is None else f'{value:.{digits}f}'


def pval(value):
    if value is None:
        return '-'
    return '<0.001' if value < 0.001 else f'{value:.3f}'


def interval(ci, fmt=lambda v: f'{v:.1f}'):
    return '' if not ci or ci[0] is None else f' [{fmt(ci[0])}, {fmt(ci[1])}]'


def rho_text(entry, which):
    """'0.21 (p 0.398) [-0.15, 0.57]' for a scorer correlation, with whatever is available."""
    value = entry.get(f'{which}_rho')
    text = num(value)
    if entry.get(f'{which}_rho_p') is not None:
        text += f' (p {pval(entry[f"{which}_rho_p"])})'
    return text + interval(entry.get(f'{which}_rho_ci'), lambda v: f'{v:.2f}')


def top_rated_text(top, n):
    if not top['n']:
        return 'no map had a top-rated start'
    return (f'the start the scorer rated best won {top["wins"]} of {top["n"]} games on {top["maps"]} maps '
            f'({pct(top["share"])}, fair {pct(1 / n)}; one-sided permutation p {pval(top["p_one_sided"])})')


def markdown(summary, config):
    n = int(config['colonies'])
    lines = [f'# Map fairness tournament: {config["name"]}', '']
    if config.get('description'):
        lines += [config['description'], '']
    wall = summary['wall_seconds']
    ends = ', '.join(f'{count} {reason}' for reason, count in summary['end_reasons'].items())
    lines += [
        f'- Revision `{summary["git_revision"]}`, generated {summary["generated_at"]}, preset `{config["preset_file"]}`.',
        f'- {config["width"]}x{config["height"]} maps, {n} colonies, `{config["ai"]}` in every slot, free for all '
        f'(prestige victory on, as in the lobby), tick cap {config["tick_cap"]}.',
        f'- Each map is the best of {config["candidates"]} lobby rolls of its seed; {config["rotation_count"]} '
        f'rotation(s) x {config["games_per_rotation"]} engine seed(s) = '
        f'{config["rotation_count"] * int(config["games_per_rotation"])} games per map.'
        + ('' if summary['balanced'] else ' **Not rotation-balanced: start position and team index are confounded.**'),
        f'- {summary["played"]} of {summary["games"]} games completed ({ends}); wall time per game mean '
        f'{num(wall["mean"], 1)} s, median {num(wall["median"], 1)} s, max {num(wall["max"], 1)} s '
        f'({num(wall["per_1000_ticks"], 2)} s per 1000 ticks); median game length '
        f'{num(summary["ticks"]["median"], 0)} ticks.',
        '- A game that reaches the tick cap goes to the surviving colony with the most prestige, then '
        'units, then finished buildings; an exact tie stays unresolved and is left out of win counts.',
    ]
    verification = summary.get('verification')
    if verification:
        lines.append(f'- Reproducibility: {verification["identical"]} of {verification["checked"]} re-run games '
                     f'matched their first run exactly (ticks, winner, order count, every team result).')
    lines += ['', '## Headline by generator', '',
              'Position bias is the root-mean-square gap between each start\'s true win rate and the fair '
              f'1/{n}, corrected for the scatter raw win shares show even on a fair map and averaged over maps; '
              'the bracket is a 95% t interval over maps. Fair-map floor is the 95th percentile that headline '
              'reaches when every map is perfectly fair, with the same decided games per map: a headline below '
              'it cannot be told apart from a fair generator. Decisive only repeats the position bias counting '
              'just games won outright, so tick-cap adjudication cannot drive it. Biased maps counts maps whose '
              'wins by start reject a uniform split, raw p < 0.05 and after Benjamini-Hochberg across that '
              'generator\'s maps. Any bias p tests whether any of its maps is biased. Scorer rho is the '
              'within-map rank correlation between a colony\'s start-quality score and its win share, with a '
              'permutation p-value.', '',
              '| Generator | Maps | Games | Cap | Position bias (pp) [95%] | Fair-map floor (pp) | Decisive only (pp, games) | Biased maps p<.05 / BH | Best start / fair (median) | Any bias p | Scorer rho (wins) |',
              '| --- | ---: | ---: | ---: | --- | ---: | --- | --- | ---: | ---: | --- |']
    for g in summary['generators']:
        scorer = (g['scorer'] or {}).get('fitness')
        scorer_cell = rho_text(scorer, 'wins') if scorer else ('n/a' if g['method'] == BASELINE_METHOD else '-')
        lines.append(
            f'| {g["name"]} ({g["method"]}) | {g["maps_with_winners"]}/{g["maps"]} | {g["played"]} | {pct(g["cap_share"], 0)} '
            f'| {num(g["headline_rms_points"], 1)}{interval(g["headline_rms_points_ci"])} '
            f'| {num(g["headline_fair_floor"], 1)} '
            f'| {num(g["decisive_rms_points"], 1)}{interval(g["decisive_rms_points_ci"])} ({g["decisive_games"]}) '
            f'| {g["maps_p05"]} / {g["maps_bh05"]} (chance {g["expected_p05_by_chance"]:.1f}) '
            f'| {num((g["dominance"] or {}).get("median"))} | {pval(g["pooled_p"])} '
            f'| {scorer_cell} |')
    lines += ['', '## Engine team-index bias', '',
              'Wins by team index, pooled over rotations, so every index played every start equally often. '
              'A skew here is the engine\'s processing order (team 0 also carries the passive local player of '
              '`dev random-games` and its AI polls last), not the map.', '',
              '| Scope | Decided games | Wins by team ' + ' / '.join(str(t) for t in range(n))
              + ' | p (uniform) | Top team share [95%] | Bias (pp) |',
              '| --- | ---: | --- | ---: | --- | ---: |']
    for label, table in (('Symmetric arena (baseline)', summary['engine_team_index']['baseline']),
                         ('All generators', summary['engine_team_index']['all_generators'])):
        if table['n']:
            lines.append(f'| {label} | {table["n"]} | {" / ".join(map(str, table["counts"]))} | {pval(table["p"])} '
                         f'| team {table["best"]}: {pct(table["best_share"])}{interval(table["best_share_wilson"], pct)} '
                         f'| {num(table["rms_points"], 1)} |')
    for g in summary['generators']:
        lines += ['', f'## {g["name"]} (generator {g["method"]}, id `{g["id"]}`, revision {g["revision"]})', '']
        if g['failed_maps']:
            lines += ['Maps that failed to generate: ' + ', '.join(
                f'{f["map_seed"]} ({f["failure"]})' for f in g['failed_maps']) + '.', '']
        lines += ['| Map seed (roll) | Games (cap) | Wins by start ' + ' / '.join(str(s) for s in range(n))
                  + ' | p | BH q | Best start share [95%] | Best / fair | Bias (pp) | Quality by start | Quality rho |',
                  '| --- | --- | --- | ---: | ---: | --- | ---: | ---: | --- | ---: |']
        for m in summary['maps']:
            if m['method'] != g['method']:
                continue
            s = m['slot']
            best = f'start {s["best"]}: {pct(s["best_share"])}{interval(s["best_share_wilson"], pct)}' \
                if s['n'] else '-'
            lines.append(
                f'| {m["map_seed"]} ({m["chosen_seed"]}) | {m["played"]} ({m["cap_games"]}) | {" / ".join(map(str, s["counts"]))} '
                f'| {pval(s["p"])} | {pval(s.get("q_bh"))} | {best} | {num(s["dominance"])} | {num(s["rms_points"], 1)} '
                f'| {" / ".join(f"{q:.2f}" for q in (m["quality"] or []))} | {num(m["quality_spearman"])} |')
        slot, team = g['slot_index'], g['team_index']
        dominance = ' / '.join(num(g['dominance'][k]) for k in ('min', 'median', 'max')) if g['dominance'] else '-'
        lines += ['',
                  f'- Wins by generator colony index, pooled over maps: {" / ".join(map(str, slot["counts"]))} '
                  f'(p {pval(slot["p"])}); a skew means the generator favours a colony it places early or late.',
                  f'- Wins by team index, pooled: {" / ".join(map(str, team["counts"]))} (p {pval(team["p"])}).',
                  f'- Maps significant after Holm: {g["maps_holm05"]}; best-start dominance min / median / max: {dominance}.']
        scorer = g['scorer'] or {}
        if scorer.get('fitness'):
            total = scorer['fitness']
            lines.append(f'- Scorer check: rho with win share {rho_text(total, "wins")}, with placement '
                         f'{rho_text(total, "placement")}; {top_rated_text(scorer["top_rated_start"], n)}. '
                         'By factor (wins rho): '
                         + ', '.join(f'{f} {num((scorer.get(f) or {}).get("wins_rho"))}' for f in FACTORS) + '.')
        elif g['method'] == BASELINE_METHOD:
            lines.append('- Scorer check: left out. Symmetric arena colonies are identical by construction; the small '
                         'score differences between them come from the build-site count, which is not symmetric '
                         'under rotation.')
    overall = summary['scorer_all_generators'] or {}
    if overall.get('fitness'):
        total = overall['fitness']
        lines += ['', '## Scorer check across generators', '',
                  f'Within-map rank correlation between start-quality score and win share over {total["colonies"]} '
                  f'colonies on {total["maps"]} maps, Symmetric arena left out: rho {rho_text(total, "wins")}; with '
                  f'placement {rho_text(total, "placement")}. Across the same maps, '
                  f'{top_rated_text(overall["top_rated_start"], n)}.']
    lines.append('')
    return '\n'.join(lines)


# ---------------------------------------------------------------------------- driver

def resolve_paths(args, out):
    return {'out': out, 'maps': out / 'maps', 'games': out / 'games', 'profiles': out / 'profiles',
            'glob2': Path(args.bin).resolve(), 'study': Path(args.bin).resolve(),
            'git_revision': git_revision()}


def verification_games(records, games, count):
    """Deterministic round robin across generators, then maps, then rotations."""
    groups = {}
    for game in games:
        if game['outcome']['status'] == 'ok':
            groups.setdefault(records[game['map']]['method'], []).append(game)
    for group in groups.values():
        group.sort(key=lambda g: (g['rotation'], g['game'], g['map']))
    selected = []
    for index in range(max((len(g) for g in groups.values()), default=0)):
        for generator in sorted(groups):
            if index < len(groups[generator]):
                selected.append(groups[generator][index])
    return selected[:max(0, count)]


def verify(config, paths, records, games):
    """Re-run a few finished games from scratch and require identical outcomes."""
    count = int(config.get('verify_games') or 0)
    finished = verification_games(records, games, count)
    checks = []
    for game in finished:
        job = {k: game[k] for k in ('map', 'rotation', 'game', 'seed')}
        directory = paths['out'] / 'verify' / game['map'] / f'r{game["rotation"]}-k{game["game"]}'
        again = run_game(config, paths, records[game['map']], job, directory=directory, force=True)
        same = (again['parsed']['end'] == game['parsed']['end'] and
                again['parsed']['teams'] == game['parsed']['teams'])
        checks.append({'map': game['map'], 'rotation': game['rotation'], 'seed': game['seed'],
                       'identical': same, 'first': game['parsed']['end'], 'again': again['parsed']['end']})
        print(f'verify {game["map"]} r{game["rotation"]} seed {game["seed"]}: {"identical" if same else "DIFFERENT"}',
              flush=True)
    result = {'checked': len(checks), 'identical': sum(c['identical'] for c in checks), 'games': checks}
    (paths['out'] / 'verification.json').write_text(json.dumps(result, indent=2))
    return result


def command_run(args):
    overrides = {'generators': args.generators, 'map_seeds': args.map_seeds, 'jobs': args.jobs,
                 'games_per_rotation': args.games_per_rotation, 'tick_cap': args.tick_cap,
                 'size': args.size, 'colonies': args.colonies, 'verify_games': args.verify,
                 'name': args.name}
    config = load_config(args.preset, overrides)
    out = Path(args.out).resolve() if args.out else ROOT / 'artifacts' / 'map-fairness' / config['name']
    out.mkdir(parents=True, exist_ok=True)
    if args.fresh:
        # Only this tool's own outputs, and never the run directory itself.
        for name in RUN_DIRECTORIES:
            remove_tree(out / name, out)
        for name in RUN_FILES:
            (out / name).unlink(missing_ok=True)
    paths = resolve_paths(args, out)
    for binary in (paths['glob2'], paths['study']):
        if not binary.exists():
            raise SystemExit(f'error: {binary} not found; build with scons release=1 and '
                             f'scons release=1 map-generator-study')
    # Provenance and pure throughput settings, not things that change the games played.
    ignored = ('jobs', 'verify_games', 'description', 'git_revision', 'preset_file')
    comparable = {k: v for k, v in config.items() if k not in ignored}
    previous = out / 'config.json'
    if previous.exists():
        old = {k: v for k, v in json.loads(previous.read_text()).items() if k not in ignored}
        if old != json.loads(json.dumps(comparable)):
            raise SystemExit(f'error: {out} holds a run with a different configuration; use --fresh or --out')
    previous.write_text(json.dumps(config | {'git_revision': paths['git_revision']}, indent=2))
    jobs = int(config['jobs'])
    print(f'map fairness tournament "{config["name"]}" -> {out}', flush=True)

    tasks = [(g, s) for g in config['generators'] for s in config['map_seeds']]
    records = run_pool(tasks, jobs, lambda t: produce_map(config, paths, t[0], t[1]),
                       lambda t, r: f'map {r["key"]}: ' + ('ok' if r.get('ok') else r.get('failure', '?')))
    by_key = {r['key']: r for r in records}

    def describe(job, game):
        o = game['outcome']
        who = f'start {o["winner_slot"]} (team {o["winner_team"]})' if o['winner_slot'] is not None else 'no winner'
        return (f'{job["map"]} r{job["rotation"]} seed {job["seed"]}: {o["status"]}, {o["end_reason"]}, {who}, '
                f'{o["ticks"]} ticks, {game["wall_seconds"]:.0f}s')
    games = run_pool(game_jobs(config, records), jobs,
                     lambda j: run_game(config, paths, by_key[j['map']], j), describe)
    if config.get('verify_games'):
        verify(config, paths, by_key, games)
    remove_tree(paths['profiles'], out)
    summary = summarize(out, config, paths)
    print(f'\nwrote {out / "summary.md"}, summary.json, games.csv, colonies.csv, maps.csv')
    for g in summary['generators']:
        print(f'  {g["name"]} ({g["method"]}): position bias {num(g["headline_rms_points"], 1)} pp'
              f'{interval(g["headline_rms_points_ci"])} (fair-map floor {num(g["headline_fair_floor"], 1)}), '
              f'biased maps {g["maps_p05"]}/{g["maps_with_winners"]} (BH {g["maps_bh05"]}), cap {pct(g["cap_share"], 0)}')
    return 0


def command_summarize(args):
    out = Path(args.out).resolve()
    config = json.loads((out / 'config.json').read_text())
    paths = resolve_paths(args, out)
    summarize(out, config, paths)
    print(f'wrote {out / "summary.md"}')
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest='command', required=True)
    run = sub.add_parser('run', help='produce maps, play games and summarize')
    run.add_argument('preset', help='preset name in tools/map-fairness/ or a path to a JSON preset')
    run.add_argument('--out', help='output directory (default: artifacts/map-fairness/<name>)')
    run.add_argument('--name', help='run name, overriding the preset (also names the default output directory)')
    run.add_argument('--fresh', action='store_true', help='discard earlier results in the output directory')
    run.add_argument('--generators', help='comma-separated generator ids, overriding the preset')
    run.add_argument('--map-seeds', help='e.g. 1001-1008 or 1001,1005')
    run.add_argument('--games-per-rotation', type=int, help='engine seeds per map rotation')
    run.add_argument('--size', type=int, help='map side in tiles (power of two)')
    run.add_argument('--colonies', type=int)
    run.add_argument('--tick-cap', type=int)
    run.add_argument('--jobs', type=int, help='concurrent processes')
    run.add_argument('--verify', type=int, help='re-run this many games to check reproducibility')
    summarize_parser = sub.add_parser('summarize', help='recompute the summary of an existing run')
    summarize_parser.add_argument('out', help='run directory')
    for p in (run, summarize_parser):
        p.add_argument('--bin', default=str(native_binary()))
        p.add_argument('--study', default=str(native_binary('MapGeneratorStudy')), help='deprecated compatibility argument; generation uses --bin')
    args = parser.parse_args()
    return command_run(args) if args.command == 'run' else command_summarize(args)


if __name__ == '__main__':
    sys.exit(main())
