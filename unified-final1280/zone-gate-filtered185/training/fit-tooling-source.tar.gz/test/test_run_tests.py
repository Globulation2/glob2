#!/usr/bin/env python3
"""Unit tests for test/run_tests.py: listing, selection, sharding and JUnit merging."""
import argparse
import io
from types import SimpleNamespace
import os
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import xml.etree.ElementTree as ET
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import run_tests  # noqa: E402
import xvfb_session  # noqa: E402
import windows_crash_diagnostics  # noqa: E402


class WindowsCrashDiagnosticsTests(unittest.TestCase):
    def test_non_utf8_console_preserves_unencodable_diagnostics(self):
        output = io.BytesIO()
        console = io.TextIOWrapper(output, encoding='cp1252')
        windows_crash_diagnostics.print_diagnostic('stack: \ufffd \u754c', console)
        console.flush()
        self.assertEqual(output.getvalue(), b'stack: \\ufffd \\u754c\n')


    def test_only_native_crashes_are_replayed(self):
        report = ET.fromstring('''<testsuites><testcase classname="LAN" name="crashed">
            <error>[run_tests] exit status 3221225477</error></testcase>
            <testcase classname="LAN" name="assertion"><failure>failed</failure></testcase>
            <testcase classname="LAN" name="ordinary"><error>exit status 2</error></testcase>
            <testcase classname="LAN" name="timeout"><error>killed after 600s</error></testcase>
            </testsuites>''')
        self.assertEqual(list(windows_crash_diagnostics.crashed_cases(report)), [('LAN', 'crashed')])

    def test_windows_crt_abort_is_replayed(self):
        report = ET.fromstring('<testcase classname="ScriptGenerator" name="aborted">'
                              '<error>exit status 3</error></testcase>')
        self.assertEqual(list(windows_crash_diagnostics.crashed_cases(report)),
                         [('ScriptGenerator', 'aborted')])

    def test_signed_windows_status_is_also_a_crash(self):
        report = ET.fromstring('''<testcase classname="LAN" name="crashed">
            <error>exit status -1073741819</error></testcase>''')
        self.assertEqual(list(windows_crash_diagnostics.crashed_cases(report)), [('LAN', 'crashed')])

    def test_debugger_uses_the_runner_filter_and_no_shell(self):
        name = 'LAN WSS drop, restart [network]'
        command = windows_crash_diagnostics.debugger_command('gdb', Path('engine.exe'), 'LAN', name)
        self.assertIn('-tc=' + run_tests.doctest_pattern(name), command)
        self.assertEqual(command[command.index('--args') + 1], 'engine.exe')
        self.assertIn('--nx', command)
        self.assertIn('break _assert', command)
        self.assertIn('break _wassert', command)
        self.assertIn('break abort', command)
        self.assertLess(command.index('break _assert'), command.index('run'))
        script = windows_crash_diagnostics.debugger_script()
        self.assertIn('break *JS_FreeRuntime', script)
        self.assertIn('JS_GetDumpFlags', script)
        self.assertIn('JS_SetDumpFlags', script)
        self.assertIn('$rcx', script)
        self.assertIn('0x4000', script)
        self.assertLess(script.index('commands'), script.index('\nrun\n'))
        replay = windows_crash_diagnostics.debugger_command('gdb', Path('engine.exe'),
                                                           'LAN', name, Path('replay.gdb'))
        self.assertEqual(replay[replay.index('-x') + 1], 'replay.gdb')

LISTING = """<?xml version="1.0" encoding="UTF-8"?>
<doctest binary="x" version="2.4.11">
  <Options order_by="file"/>
  <TestCase name="feeds the last worker" testsuite="HungryDefeat" filename="src/unit/HungryDefeatHarness.cpp" line="12" skipped="false"/>
  <TestCase name="renders the bar [display:1024x768][artifacts]" testsuite="PointBar" filename="src/render/PointBarRenderTest.cpp" line="40" skipped="false"/>
  <TestCase name="sweeps every landscape [slow]" testsuite="MapGeneratorDefaults" filename="src/map/generator/MapGeneratorDefaultsTest.cpp" line="7" skipped="false"/>
  <TestCase name="binds a port [network]" testsuite="NetConnection" filename="src/net/NetConnectionHarness.cpp" line="9" skipped="false"/>
  <OverallResultsTestCases unskipped="4"/>
</doctest>
"""

FAKE_CLASSNAME_SHELL = (
    'case "$name" in\n'
    '"feeds the last worker") class="src/unit/HungryDefeatHarness.cpp";;\n'
    '"sweeps every landscape [slow]") class="src/map/generator/MapGeneratorDefaultsTest.cpp";;\n'
    '"binds a port [network]") class="src/net/NetConnectionHarness.cpp";;\n'
    '*) class="src/render/PointBarRenderTest.cpp";; esac\n'
)


def junit_for(cases, skipped=False):
    report = ET.Element('testsuites')
    suite = ET.SubElement(report, 'testsuite', tests='999')
    for case in cases:
        child = ET.SubElement(suite, 'testcase', classname=case.file, name=case.name)
        if skipped:
            ET.SubElement(child, 'skipped')
    return ET.tostring(report, encoding='unicode')


def args(**overrides):
    namespace = argparse.Namespace(filter=[], tag=[], exclude_tag=[], quick=False, no_display=False,
                                   in_process=False)
    for key, value in overrides.items():
        setattr(namespace, key, value)
    return namespace


class ListingTest(unittest.TestCase):
    def test_parses_names_suites_and_tags(self):
        cases = run_tests.parse_listing(LISTING, 'engine')
        self.assertEqual([case.label for case in cases][:2],
                         ['HungryDefeat/feeds the last worker', 'PointBar/renders the bar [display:1024x768][artifacts]'])
        self.assertEqual(cases[1].tags, ['display:1024x768', 'artifacts'])
        self.assertTrue(cases[1].display)
        self.assertEqual(cases[1].screen, '1024x768')
        self.assertEqual(cases[0].screen, run_tests.DEFAULT_SCREEN)
        self.assertEqual(cases[0].line, 12)


class SelectionTest(unittest.TestCase):
    def setUp(self):
        self.cases = run_tests.parse_listing(LISTING, 'engine')

    def test_filter_and_tags(self):
        kept, skipped = run_tests.select(self.cases, args(filter=['hungrydefeat/*']))
        self.assertEqual([case.suite for case in kept], ['HungryDefeat'])
        kept, _ = run_tests.select(self.cases, args(tag=['artifacts']))
        self.assertEqual([case.suite for case in kept], ['PointBar'] if os.name != 'nt' else [])
        kept, _ = run_tests.select(self.cases, args(exclude_tag=['display', 'slow', 'network']))
        self.assertEqual([case.suite for case in kept], ['HungryDefeat'])

    def test_quick_and_no_display(self):
        kept, skipped = run_tests.select(self.cases, args(quick=True, no_display=True))
        self.assertEqual(sorted(case.suite for case in kept), ['HungryDefeat', 'NetConnection'])
        self.assertEqual([case.suite for case in skipped], ['PointBar'])


class ShardTest(unittest.TestCase):
    def test_shards_are_deterministic_and_complete(self):
        cases = run_tests.parse_listing(LISTING, 'engine')
        jobs = run_tests.make_jobs(cases, args())
        parts = [run_tests.shard(jobs, f'{k}/3') for k in (1, 2, 3)]
        labels = sorted(job.label for part in parts for job in part)
        self.assertEqual(labels, sorted(job.label for job in jobs))
        self.assertEqual(parts, [run_tests.shard(jobs, f'{k}/3') for k in (1, 2, 3)])
        with self.assertRaises(SystemExit):
            run_tests.shard(jobs, '4/3')

    def test_unit_display_cases_are_isolated_from_headless_driver_changes(self):
        cases = run_tests.parse_listing(LISTING, 'unit')
        for in_process in (False, True):
            jobs = run_tests.make_jobs(cases, args(in_process=in_process), cases)
            self.assertEqual(len(jobs), 2)
            self.assertEqual(jobs[0].cases, [cases[1]])
            self.assertTrue(jobs[0].display)
            self.assertFalse(jobs[0].whole)
            self.assertTrue(jobs[1].whole)
            self.assertFalse(jobs[1].display)
            self.assertEqual(run_tests.doctest_filter(jobs[1]), ['-tce=*[display*'])
        subset = run_tests.make_jobs(cases[:2], args(), cases)
        self.assertEqual([job.subset for job in subset], [False, True])
        self.assertEqual(run_tests.doctest_filter(subset[1]),
                         ['-tce=*[display*', '-tc=feeds the last worker', '-ts=HungryDefeat'])
        benchmark = run_tests.Case('unit', '', 'timing [benchmark]', tags=['benchmark'])
        jobs = run_tests.make_jobs(cases, args(), cases + [benchmark])
        self.assertEqual(run_tests.doctest_filter(jobs[1]),
                         ['-tce=*[display*,*[benchmark]*'])
        headless = [case for case in cases if not case.display]
        jobs = run_tests.make_jobs(headless, args(no_display=True), cases)
        self.assertEqual(len(jobs), 1)
        self.assertEqual(run_tests.doctest_filter(jobs[0]), ['-tce=*[display*'])

    def test_unit_display_cases_are_isolated_from_headless_batch(self):
        cases = run_tests.parse_listing(LISTING, 'unit')
        jobs = run_tests.make_jobs(cases, args())
        self.assertEqual(len(jobs), 2)
        display, headless = jobs
        self.assertEqual(display.cases, [cases[1]])
        self.assertFalse(display.whole)
        self.assertTrue(headless.whole)
        self.assertFalse(headless.display)
        self.assertEqual(headless.cases, [cases[0], cases[2], cases[3]])
        self.assertEqual(run_tests.doctest_filter(headless), ['-tce=*[display*'])
        subset = run_tests.make_jobs(cases[:2], args(), cases)
        self.assertEqual(run_tests.doctest_filter(subset[0]),
                         ['-tc=renders the bar [display:1024x768][artifacts]', '-ts=PointBar'])
        self.assertEqual(run_tests.doctest_filter(subset[1]),
                         ['-tce=*[display*', '-tc=feeds the last worker', '-ts=HungryDefeat'])
        self.assertEqual(run_tests.make_jobs([cases[1]], args(), cases)[0].cases, [cases[1]])
        benchmark = run_tests.parse_listing(LISTING.replace('sweeps every landscape [slow]', 'sweeps every landscape [benchmark]'), 'unit')
        kept, _ = run_tests.select(benchmark, args())
        self.assertEqual(len(kept), len(benchmark) - 1)
        display, headless = run_tests.make_jobs(kept, args(), benchmark)
        self.assertEqual(run_tests.doctest_filter(headless), ['-tce=*[display*,*[benchmark]*'])

    def test_same_name_in_two_suites_stays_in_its_suite(self):
        listing = LISTING.replace('<OverallResultsTestCases', '<TestCase name="feeds the last worker" testsuite="InnSwap" '
                                  'filename="src/building/InnSwapHarness.cpp" line="3" skipped="false"/>\n  <OverallResultsTestCases')
        cases = run_tests.parse_listing(listing, 'unit')
        kept, _ = run_tests.select(cases, args(filter=['InnSwap/*']))
        jobs = run_tests.make_jobs(kept, args(), cases)
        self.assertEqual(len(jobs), 1)
        self.assertEqual(run_tests.doctest_filter(jobs[0]), ['-tce=*[display*', '-tc=feeds the last worker', '-ts=InnSwap'])
        foreign = run_tests.Result(jobs[0], 'pass', 0.1, junit=(
            '<testsuites><testsuite name="x"><testcase classname="src/unit/HungryDefeatHarness.cpp" name="feeds the last worker"/>'
            '<testcase classname="src/building/InnSwapHarness.cpp" name="feeds the last worker"/></testsuite></testsuites>'))
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'junit.xml'
            run_tests.merge_junit([foreign], path)
            text = path.read_text()
        self.assertIn('classname="InnSwap"', text)
        self.assertNotIn('classname="InnSwap" name="feeds the last worker"/><testcase classname="InnSwap"', text)
        self.assertIn('classname="src/unit/HungryDefeatHarness.cpp"', text)
        engine = run_tests.make_jobs(run_tests.parse_listing(LISTING, 'engine'), args())
        self.assertEqual(len(engine), 4)
        self.assertEqual(run_tests.doctest_filter(engine[0]), ['-tc=feeds the last worker', '-ts=HungryDefeat'])
        self.assertEqual(engine[2].timeout, run_tests.SLOW_TIMEOUT)
        self.assertEqual(engine[1].timeout, run_tests.DISPLAY_TIMEOUT)

    def test_filter_quotes_comma_and_backslash_in_names_and_suites(self):
        case = run_tests.Case('engine', r'Suite,with\path', r'cancel, globals\saved')
        second = run_tests.Case('engine', case.suite, 'second, case')
        self.assertEqual(run_tests.doctest_filter(run_tests.Job('engine', [case])),
                         [r'-tc=cancel\, globals\\saved', r'-ts=Suite\,with\\path'])
        self.assertEqual(run_tests.doctest_filter(run_tests.Job('engine', [case, second], whole=True, subset=True)),
                         [r'-tc=cancel\, globals\\saved,second\, case', r'-ts=Suite\,with\\path'])


class JunitExecutionTest(unittest.TestCase):
    def setUp(self):
        self.cases = run_tests.parse_listing(LISTING, 'engine')[:2]
        self.job = run_tests.Job('engine', self.cases, whole=True, subset=True)

    def test_complete_actual_cases_pass_regardless_of_reported_test_count(self):
        self.assertEqual(run_tests.junit_execution_issue(self.job, junit_for(self.cases)), '')

    def test_empty_missing_malformed_and_only_skipped_reports_fail(self):
        for report in ('', '<testsuites tests="999"/>', '<broken', junit_for(self.cases, skipped=True)):
            with self.subTest(report=report):
                self.assertTrue(run_tests.junit_execution_issue(self.job, report))

    def test_incomplete_duplicate_and_foreign_cases_fail(self):
        for cases in (self.cases[:1], [self.cases[0]] * 2,
                      [*self.cases, run_tests.Case('engine', 'Other', self.cases[0].name, 'other.cpp')]):
            with self.subTest(cases=cases):
                issue = run_tests.junit_execution_issue(self.job, junit_for(cases))
                self.assertIn('does not match selection', issue)

    def test_same_name_from_wrong_file_does_not_satisfy_selection(self):
        wrong = run_tests.Case('engine', 'Other', self.cases[0].name, 'other.cpp')
        issue = run_tests.junit_execution_issue(self.job, junit_for([wrong, self.cases[1]]))
        self.assertIn('missing selected cases', issue)
        self.assertIn('unexpected executed cases', issue)

    def test_failure_in_successful_exit_report_is_rejected(self):
        report = ET.fromstring(junit_for(self.cases))
        ET.SubElement(report.find('.//testcase'), 'failure', message='actual failure')
        self.assertIn('failures', run_tests.junit_execution_issue(self.job, ET.tostring(report, encoding='unicode')))


class JunitTest(unittest.TestCase):
    def test_failed_process_with_empty_junit_records_selected_case_error(self):
        case = run_tests.Case('engine', 'Runner', 'failed before test', 'fixture.cpp')
        result = run_tests.Result(run_tests.Job('engine', [case]), 'fail', 0.1,
                                  output='failed before running tests', junit='<testsuites/>')
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'junit.xml'
            totals = run_tests.merge_junit([result], path)
            report = ET.parse(path)
        self.assertEqual(totals, {'tests': 1, 'failures': 0, 'errors': 1, 'skipped': 0})
        self.assertEqual(len(report.findall('.//testcase/error')), 1)

    def test_merges_doctest_reports_and_synthesises_errors(self):
        cases = run_tests.parse_listing(LISTING, 'engine')
        jobs = run_tests.make_jobs(cases, args())
        passed = run_tests.Result(jobs[0], 'pass', 0.5, junit=(
            '<testsuites><testsuite name="src/unit/HungryDefeatHarness.cpp"><testcase classname="src/unit/HungryDefeatHarness.cpp"'
            ' name="feeds the last worker" time="0.4"/></testsuite></testsuites>'))
        crashed = run_tests.Result(jobs[1], 'timeout', 300.0, output='tail of output')
        skipped = run_tests.Result(jobs[2], 'skip', 0.0)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'junit.xml'
            totals = run_tests.merge_junit([passed, crashed, skipped], path)
            text = path.read_text()
        self.assertEqual(totals, {'tests': 3, 'failures': 0, 'errors': 1, 'skipped': 1})
        self.assertIn('classname="HungryDefeat"', text)
        self.assertIn('<error message="timeout"', text)
        self.assertIn('tail of output', text)
        self.assertIn('<skipped', text)


@unittest.skipIf(os.name == 'nt', 'uses a shell script as the fake binary')
class EndToEndTest(unittest.TestCase):
    def test_generated_vulkan_bundle_reaches_test_process_and_explicit_override_wins(self):
        with tempfile.TemporaryDirectory() as directory:
            build = Path(directory) / 'build'
            (build / 'test').mkdir(parents=True)
            shaders = build / 'shaders'
            (shaders / 'vulkan').mkdir(parents=True)
            (shaders / 'vulkan/primitive.vert.spv').write_bytes(b'shader fixture')
            binary = build / 'test' / run_tests.BINARIES['engine']
            listing = LISTING.replace('\n', '\\n').replace('"', '\\"')
            binary.write_text('#!/bin/sh\n'
                              'for a in "$@"; do case "$a" in -ltc) printf "%b" "' + listing + '"; exit 0;; esac; done\n'
                              'test "$GLOB2_TEST_SHADER_DIRECTORY" = "$EXPECTED_SHADERS" || exit 9\n'
                              'for a in "$@"; do case "$a" in -o=*) echo "<testsuites><testsuite><testcase classname=\\"src/unit/HungryDefeatHarness.cpp\\" name=\\"feeds the last worker\\"/></testsuite></testsuites>" > "${a#-o=}";; esac; done\n')
            binary.chmod(binary.stat().st_mode | stat.S_IEXEC)
            for override in (None, str(Path(directory) / 'explicit-shaders')):
                with self.subTest(override=override):
                    environment = dict(os.environ)
                    environment.pop('GLOB2_TEST_SHADER_DIRECTORY', None)
                    environment['EXPECTED_SHADERS'] = override or str(shaders.resolve())
                    if override:
                        environment['GLOB2_TEST_SHADER_DIRECTORY'] = override
                    result = subprocess.run(
                        [sys.executable, str(HERE / 'run_tests.py'), '--binary', 'engine',
                         '--build-dir', str(build), '--filter', 'HungryDefeat/*',
                         '--junit', str(Path(directory) / 'junit.xml')],
                        capture_output=True, text=True, env=environment)
                    self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_fullscreen_requires_explicit_opt_in_even_in_process(self):
        with tempfile.TemporaryDirectory() as directory:
            build = Path(directory) / 'build'
            (build / 'test').mkdir(parents=True)
            binary = build / 'test' / run_tests.BINARIES['engine']
            listing = LISTING.replace('\n', '\\n').replace('"', '\\"')
            binary.write_text('#!/bin/sh\n'
                              'for a in "$@"; do case "$a" in -ltc) printf "%b" "' + listing + '"; exit 0;; esac; done\n'
                              'test "$GLOB2_TEST_FULLSCREEN" = "$EXPECTED_FULLSCREEN" || exit 9\n'
                              'for a in "$@"; do case "$a" in -o=*) echo "<testsuites><testsuite><testcase classname=\\"src/unit/HungryDefeatHarness.cpp\\" name=\\"feeds the last worker\\"/></testsuite></testsuites>" > "${a#-o=}";; esac; done\n')
            binary.chmod(binary.stat().st_mode | stat.S_IEXEC)
            for in_process in (False, True):
                for fullscreen in (False, True):
                    with self.subTest(in_process=in_process, fullscreen=fullscreen):
                        command = [sys.executable, str(HERE / 'run_tests.py'), '--binary', 'engine',
                                   '--build-dir', str(build), '--filter', 'HungryDefeat/*',
                                   '--junit', str(Path(directory) / 'junit.xml')]
                        if in_process:
                            command.append('--in-process')
                        if fullscreen:
                            command.append('--fullscreen')
                        result = subprocess.run(command, capture_output=True, text=True,
                                                env=dict(os.environ, GLOB2_TEST_FULLSCREEN='1',
                                                         EXPECTED_FULLSCREEN='1' if fullscreen else '0'))
                        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def run_python_fake(self, cases, report, extra=(), required_filters=(), process_output='', exit_code=0):
        listing = ET.Element('doctest')
        for case in cases:
            ET.SubElement(listing, 'TestCase', name=case.name, testsuite=case.suite,
                          filename=case.file, line='1', skipped='false')
        with tempfile.TemporaryDirectory() as directory:
            build = Path(directory) / 'build'
            (build / 'test').mkdir(parents=True)
            binary = build / 'test' / run_tests.BINARIES['engine']
            binary.write_text(
                f'#!{sys.executable}\n'
                'import sys\nfrom pathlib import Path\n'
                f'listing = {ET.tostring(listing, encoding="unicode")!r}\n'
                'if "-ltc" in sys.argv:\n print(listing); raise SystemExit(0)\n'
                f'report = {report!r}\n'
                f'if not all(value in sys.argv for value in {tuple(required_filters)!r}): report = "<testsuites/>"\n'
                'output = next(value[3:] for value in sys.argv if value.startswith("-o="))\n'
                'Path(output).write_text(report)\n'
                f'print({process_output!r})\n'
                f'raise SystemExit({exit_code})\n')
            binary.chmod(binary.stat().st_mode | stat.S_IEXEC)
            junit = Path(directory) / 'junit.xml'
            completed = subprocess.run([sys.executable, str(HERE / 'run_tests.py'), '--binary', 'engine',
                                        '--build-dir', str(build), '--no-display', '--junit', str(junit),
                                        '--artifacts', str(Path(directory) / 'artifacts'), *extra],
                                       capture_output=True, text=True)
            return completed, junit.read_text()

    def test_separator_names_run_instead_of_silently_selecting_nothing(self):
        case = run_tests.Case('engine', r'Suite,with\path', r'cancel, globals\saved', 'fixture.cpp')
        completed, report = self.run_python_fake(
            [case], junit_for([case]),
            required_filters=(r'-tc=cancel\, globals\\saved', r'-ts=Suite\,with\\path'))
        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
        self.assertIn('PASS', completed.stdout)
        self.assertEqual(len(ET.fromstring(report).findall('.//testcase')), 1)

    def test_post_report_exit_and_recoverable_sanitizers_cannot_publish_passing_junit(self):
        case = run_tests.Case('engine', 'Runner', 'sanitizer case', 'fixture.cpp')
        diagnostics = [
            (1, 'SUMMARY: AddressSanitizer: 48 byte(s) leaked in 1 allocation(s).'),
            (0, 'fixture.cpp:10:4: runtime error: load of value 32515, which is not a valid enum'),
            (0, 'SUMMARY: ThreadSanitizer: data race fixture.cpp:10'),
            (1, ''),
        ]
        for exit_code, output in diagnostics:
            with self.subTest(exit_code=exit_code, output=output):
                completed, report = self.run_python_fake([case], junit_for([case]),
                                                        process_output=output, exit_code=exit_code)
                self.assertEqual(completed.returncode, 1, completed.stdout + completed.stderr)
                self.assertIn('FAIL Runner/sanitizer case', completed.stdout)
                document = ET.fromstring(report)
                self.assertEqual(document.get('failures'), '1')
                self.assertEqual(len(document.findall('.//testcase/failure')), 1)
                self.assertIn(output or 'exited with status 1', report)

    def test_successful_process_with_empty_or_partial_junit_is_an_error(self):
        cases = [run_tests.Case('engine', 'Runner', 'first', 'first.cpp'),
                 run_tests.Case('engine', 'Runner', 'second', 'second.cpp')]
        for report, diagnostic in (('<testsuites tests="999"/>', 'no executed test cases'),
                                   (junit_for(cases[:1]), 'missing selected cases')):
            with self.subTest(report=report):
                completed, merged = self.run_python_fake(cases, report, extra=('--in-process',))
                self.assertEqual(completed.returncode, 1, completed.stdout + completed.stderr)
                self.assertIn(diagnostic, completed.stdout)
                self.assertEqual(len(ET.fromstring(merged).findall('.//testcase/error')), 2)

    def test_runs_a_fake_binary_per_case(self):
        with tempfile.TemporaryDirectory() as directory:
            build = Path(directory) / 'build'
            (build / 'test').mkdir(parents=True)
            binary = build / 'test' / run_tests.BINARIES['engine']
            listing = LISTING.replace('\n', '\\n').replace('"', '\\"')
            binary.write_text('#!/bin/sh\n'
                              'for a in "$@"; do case "$a" in -ltc) printf "%b" "' + listing + '"; exit 0;; esac; done\n'
                              'out=""; name=""\n'
                              'for a in "$@"; do case "$a" in -o=*) out="${a#-o=}";; -tc=*) name="${a#-tc=}";; esac; done\n'
                              'echo "running $name"\n'
                              'test -n "$GLOB2_USER_DATA_DIR" || exit 9\n'
                              'if [ "$name" = "binds a port [network]" ]; then echo "<testsuites/>" > "$out"; echo boom; exit 1; fi\n'
                              + FAKE_CLASSNAME_SHELL +
                              'echo "<testsuites><testsuite name=\\"x\\"><testcase classname=\\"$class\\" name=\\"$name\\"/></testsuite></testsuites>" > "$out"\n'
                              'exit 0\n')
            binary.chmod(binary.stat().st_mode | stat.S_IEXEC)
            junit = Path(directory) / 'junit.xml'
            result = subprocess.run([sys.executable, str(HERE / 'run_tests.py'), '--binary', 'engine',
                                     '--build-dir', str(build), '--no-display', '--junit', str(junit),
                                     '--artifacts', str(Path(directory) / 'artifacts'), '-j', '2'],
                                    capture_output=True, text=True, env=dict(os.environ, GITHUB_ACTIONS='1'))
            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertIn('FAIL NetConnection/binds a port [network]', result.stdout)
            self.assertIn('PASS HungryDefeat/feeds the last worker', result.stdout)
            self.assertIn('boom', result.stdout)
            self.assertIn('::error file=src/net/NetConnectionHarness.cpp,line=9', result.stdout)
            self.assertIn('2 passed, 1 failed, 1 skipped', result.stdout)
            self.assertTrue(junit.exists())

    def test_reports_preference_writes_and_timeouts(self):
        with tempfile.TemporaryDirectory() as directory:
            build = Path(directory) / 'build'
            (build / 'test').mkdir(parents=True)
            binary = build / 'test' / run_tests.BINARIES['engine']
            listing = LISTING.replace('\n', '\\n').replace('"', '\\"')
            binary.write_text('#!/bin/sh\n'
                              'for a in "$@"; do case "$a" in -ltc) printf "%b" "' + listing + '"; exit 0;; esac; done\n'
                              'out=""; name=""\n'
                              'for a in "$@"; do case "$a" in -o=*) out="${a#-o=}";; -tc=*) name="${a#-tc=}";; esac; done\n'
                              'if [ "$name" = "sweeps every landscape [slow]" ]; then sleep 30; fi\n'
                              'if [ "$name" = "feeds the last worker" ]; then echo "musicVolume=3" > "$GLOB2_USER_DATA_DIR/preferences.txt"; fi\n'
                              + FAKE_CLASSNAME_SHELL +
                              'echo "<testsuites><testsuite name=\\"x\\"><testcase classname=\\"$class\\" name=\\"$name\\"/></testsuite></testsuites>" > "$out"\n'
                              'exit 0\n')
            binary.chmod(binary.stat().st_mode | stat.S_IEXEC)
            junit = Path(directory) / 'junit.xml'
            result = subprocess.run([sys.executable, str(HERE / 'run_tests.py'), '--binary', 'engine',
                                     '--build-dir', str(build), '--no-display', '--junit', str(junit),
                                     '--artifacts', str(Path(directory) / 'artifacts'), '-j', '2', '--timeout', '2'],
                                    capture_output=True, text=True)
            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertIn('FAIL HungryDefeat/feeds the last worker', result.stdout)
            self.assertIn('changed the profile preferences', result.stdout)
            self.assertIn('TIMEOUT MapGeneratorDefaults/sweeps every landscape [slow]', result.stdout)
            self.assertIn('killed after 2s', result.stdout)
            self.assertIn('PASS NetConnection/binds a port [network]', result.stdout)
            text = junit.read_text()
            self.assertIn('<failure message="run_tests: the test changed the profile preferences', text)
            self.assertIn('<error message="timeout"', text)


class TimeoutDiagnosticsTest(unittest.TestCase):
    def test_display_diagnostics_cannot_inspect_an_unowned_display(self):
        proc = mock.MagicMock()
        proc.__truediv__.return_value = proc
        proc.read_bytes.return_value = b'DISPLAY=:7\0XAUTHORITY=/tmp/auth\0'
        with mock.patch.object(run_tests, 'Path', return_value=proc), \
             mock.patch.object(run_tests.subprocess, 'run') as inspect:
            self.assertEqual(run_tests.timeout_display_state(123, {':99'}), '')
        inspect.assert_not_called()

    def test_display_diagnostics_capture_real_mapping_on_owned_server(self):
        proc = mock.MagicMock()
        proc.__truediv__.return_value = proc
        proc.read_bytes.return_value = b'DISPLAY=:99\0XAUTHORITY=/tmp/auth\0'
        states = [subprocess.CompletedProcess([], 0, 'root state', ''),
                  subprocess.CompletedProcess([], 0, '  0x400001 "test window"', ''),
                  subprocess.CompletedProcess([], 0, 'Map State: IsViewable', '')]
        with mock.patch.object(run_tests, 'Path', return_value=proc), \
             mock.patch.object(run_tests.shutil, 'which', side_effect=lambda name: name), \
             mock.patch.object(run_tests.subprocess, 'run', side_effect=states) as inspect:
            output = run_tests.timeout_display_state(123, {':99'})
        self.assertIn('Map State: IsViewable', output)
        self.assertEqual(inspect.call_args_list[-1].args[0],
                         ['xwininfo', '-id', '0x400001', '-all'])
        self.assertTrue(all(call.kwargs['timeout'] <= 2 for call in inspect.call_args_list))

    def test_ignores_processes_outside_owned_group(self):
        snapshot = subprocess.CompletedProcess([], 0, '42 1 99 S unrelated-process\n')
        with mock.patch.object(run_tests.platform, 'system', return_value='Linux'), \
             mock.patch.object(run_tests.subprocess, 'run', return_value=snapshot) as inspect, \
             mock.patch.object(run_tests.shutil, 'which', return_value=None):
            output = run_tests.timeout_diagnostics(123, Path('/test-binary'))
        self.assertNotIn('unrelated-process', output)
        inspect.assert_called_once()
        self.assertEqual(inspect.call_args.kwargs['timeout'], 2)

    def test_diagnostic_timeout_does_not_interrupt_cleanup(self):
        with mock.patch.object(run_tests.platform, 'system', return_value='Linux'), \
             mock.patch.object(run_tests.subprocess, 'run', side_effect=subprocess.TimeoutExpired('ps', 2)):
            output = run_tests.timeout_diagnostics(123, Path('/test-binary'))
        self.assertIn('timeout diagnostics unavailable', output)

    def test_skips_linux_diagnostics_on_other_platforms(self):
        with mock.patch.object(run_tests.platform, 'system', return_value='Darwin'), \
             mock.patch.object(run_tests.subprocess, 'run') as inspect:
            self.assertEqual(run_tests.timeout_diagnostics(123, Path('/test-binary')), '')
        inspect.assert_not_called()


class XvfbSessionTest(unittest.TestCase):
    def test_waits_for_window_manager_and_preserves_test_exit_status(self):
        wm = mock.MagicMock()
        wm.poll.return_value = None
        state = subprocess.CompletedProcess([], 0, '_NET_SUPPORTING_WM_CHECK(WINDOW): window id # 0x400002\n_GLOB2_TEST_WM_READY(CARDINAL) = 1')
        with mock.patch.object(xvfb_session.shutil, 'which', side_effect=lambda name: name), \
             mock.patch.object(xvfb_session.subprocess, 'Popen', return_value=wm) as launch, \
             mock.patch.object(xvfb_session.subprocess, 'run', return_value=state), \
             mock.patch.object(xvfb_session.subprocess, 'call', return_value=7) as test:
            self.assertEqual(xvfb_session.run(['test-binary']), 7)
            test.assert_called_once_with(['test-binary'])
        wm.terminate.assert_called_once()
        wm.wait.assert_called_once_with(timeout=5)
        self.assertIsNone(launch.call_args.kwargs['stderr'])
        self.assertEqual(launch.call_args.args[0], [
            'openbox', '--sm-disable', '--startup',
            'xprop -root -f _GLOB2_TEST_WM_READY 32c -set _GLOB2_TEST_WM_READY 1'])

    def test_ewmh_identity_alone_does_not_launch_the_test(self):
        wm = mock.MagicMock()
        wm.poll.return_value = None
        identity = '_NET_SUPPORTING_WM_CHECK(WINDOW): window id # 0x400002'
        states = [subprocess.CompletedProcess([], 0, identity),
                  subprocess.CompletedProcess([], 0, identity + '\n_GLOB2_TEST_WM_READY(CARDINAL) = 1')]
        with mock.patch.object(xvfb_session.shutil, 'which', side_effect=lambda name: name), \
             mock.patch.object(xvfb_session.subprocess, 'Popen', return_value=wm), \
             mock.patch.object(xvfb_session.subprocess, 'call', return_value=0) as test, \
             mock.patch.object(xvfb_session.time, 'sleep') as sleep:
            def inspect(*args, **kwargs):
                test.assert_not_called()
                return states.pop(0)
            with mock.patch.object(xvfb_session.subprocess, 'run', side_effect=inspect) as state:
                self.assertEqual(xvfb_session.run(['test-binary']), 0)
            self.assertEqual(state.call_count, 2)
            sleep.assert_called_once_with(0.05)
            test.assert_called_once_with(['test-binary'])
        wm.terminate.assert_called_once()
        wm.wait.assert_called_once_with(timeout=5)

    def test_missing_window_manager_readiness_fails_and_cleans_up(self):
        wm = mock.MagicMock()
        wm.poll.return_value = None
        state = subprocess.CompletedProcess([], 0, 'no such atom')
        with mock.patch.object(xvfb_session.shutil, 'which', side_effect=lambda name: name), \
             mock.patch.object(xvfb_session.subprocess, 'Popen', return_value=wm) as launch, \
             mock.patch.object(xvfb_session.subprocess, 'run', return_value=state), \
             mock.patch.object(xvfb_session.subprocess, 'call') as test, \
             mock.patch.object(xvfb_session.time, 'monotonic', side_effect=[0, 10]):
            with self.assertRaisesRegex(RuntimeError, 'did not establish'):
                xvfb_session.run(['test-binary'])
            test.assert_not_called()
        wm.terminate.assert_called_once()
        wm.wait.assert_called_once_with(timeout=5)


if __name__ == '__main__':
    unittest.main()

class WeightedShardTest(unittest.TestCase):
    def test_heavy_jobs_separate_and_all_jobs_execute_once(self):
        jobs=[SimpleNamespace(label=label) for label in ['a','b','c','new']]
        weights={'a':100.0,'b':90.0,'c':1.0}
        parts=[run_tests.shard(jobs,f'{k}/2',weights,['aux:unit']) for k in [1,2]]
        self.assertEqual(sorted(j.label for part in parts for j in part),['a','b','c','new'])
        self.assertNotEqual(next(i for i,p in enumerate(parts) if jobs[0] in p),next(i for i,p in enumerate(parts) if jobs[1] in p))
        self.assertEqual(parts,[run_tests.shard(list(reversed(jobs)),f'{k}/2',weights,['aux:unit']) for k in [1,2]])
    def test_new_jobs_use_median_and_ties_use_shard_number(self):
        self.assertEqual(run_tests.assignments(['new','known'],2,{'known':3}),{'known':1,'new':2})
        self.assertEqual(run_tests.assignments(['b','a'],2,{'a':1,'b':1}),{'a':1,'b':2})
    def test_profile_rejects_bad_weights_and_empty_preserves_original(self):
        import tempfile,json
        from pathlib import Path
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'profile.json'
            for value in [-1,float('nan'),True,'3']:
                path.write_text(json.dumps({'schema':1,'seconds':{'a':value}}))
                with self.assertRaises(SystemExit):run_tests.load_timings(path)
            path.write_text(json.dumps({'schema':1,'seconds':{}}))
            self.assertIsNone(run_tests.load_timings(path))

class AuxiliaryShardTest(unittest.TestCase):
    def test_auxiliary_assignment_agrees_with_native_partition(self):
        import ci_native_shard_plan as planner
        jobs=[SimpleNamespace(label=x) for x in ['native-a','native-b']]
        aux={'aux:unit': {'id':'unit','default_shard':4}}
        weights={'native-a':100,'native-b':80,'aux:unit':90}
        mapped=planner.plan(jobs,aux,2,weights)
        expected=run_tests.assignments(['native-a','native-b','aux:unit'],2,weights)
        self.assertEqual(mapped['unit'],expected['aux:unit'])
        self.assertEqual(planner.plan(jobs,aux,4,None),{'unit':4})
    def test_profiles_need_ten_samples_and_same_platform(self):
        import build_ci_timing_profile as builder
        sample={'family':'ubuntu-24.04','seconds':{'native-a':3}}
        self.assertEqual(builder.build([sample]*9,'ubuntu-24.04',{})['seconds'],{})
        self.assertEqual(builder.build([sample]*10,'ubuntu-22.04',{})['seconds'],{})
        self.assertEqual(builder.build([sample]*10,'ubuntu-24.04',{})['seconds'],{'native-a':3})
