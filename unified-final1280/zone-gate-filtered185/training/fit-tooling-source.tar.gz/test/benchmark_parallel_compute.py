"""Retained paired wall/CPU benchmarks for the shared compute executor.

A manifest contains scenarios with id, args (headless arguments without output),
optional group, and fixture_sha256 (absolute paths to input hashes). Run one
process at a time; process CPU includes all threads. Correctness runs are separate
from timing. No performance thresholds belong in CI.
"""
import argparse
import hashlib
import json
import math
import platform
import os
import statistics
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    path = Path(path)
    if not path.exists() and Path(str(path)+".gz").exists():
        path = Path(str(path)+".gz")
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def execute(binary, args, output, *, cwd=ROOT):
    output.mkdir(parents=True, exist_ok=False)
    command = [str(binary), 'game', 'run', *args, '--output-dir', str(output)]
    runner_peak_rss = None
    if platform.system() == 'Linux':
        import resource
        runner_peak_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    started = time.perf_counter()
    with (output / 'engine.log').open('w') as log:
        process = subprocess.Popen(command, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
        try:
            _, status, usage = os.wait4(process.pid, 0)
            process.returncode = os.waitstatus_to_exitcode(status)
        except BaseException:
            # An interrupted campaign must not leave a timing workload behind.
            # Reap the child before propagating the error and auditing inputs.
            process.kill()
            process.wait()
            raise
    wall = time.perf_counter() - started
    if process.returncode:
        raise RuntimeError(f"exit {process.returncode}: {output / 'engine.log'}")
    result = json.loads((output / 'result.json').read_text())
    peak_rss = usage.ru_maxrss * (1 if platform.system() == "Darwin" else 1024)
    # Linux carries the pre-exec runner's high-water mark into the child.
    # A higher engine peak is measurable; a result at that floor is censored.
    if runner_peak_rss is not None and peak_rss <= runner_peak_rss:
        report = dict(status='censored', runner_peak_rss_bytes=runner_peak_rss,
                      reported_child_peak_rss_bytes=peak_rss)
        (output / 'rss-censored.json').write_text(json.dumps(report, indent=2) + '\n')
        raise RuntimeError('Child peak RSS is censored by inherited runner memory: ' + str(output))
    return dict(command=command, wall_s=wall, cpu_s=usage.ru_utime + usage.ru_stime,
                user_s=usage.ru_utime, system_s=usage.ru_stime,
                peak_rss_bytes=peak_rss, runner_peak_rss_bytes=runner_peak_rss, result=result)


def summarize(rows):
    summaries = {}
    for scenario in sorted({row['scenario'] for row in rows}):
        selected = [row for row in rows if row['scenario'] == scenario and row['repeat'] >= 0]
        variants = {}
        for variant in sorted({row['variant'] for row in selected}):
            samples = [row for row in selected if row['variant'] == variant]
            variants[variant] = {key: statistics.median(row[key] for row in samples) for key in ('wall_s', 'cpu_s', 'peak_rss_bytes')}
            if all('run_ns' in row['result'] for row in samples):
                variants[variant]['run_s'] = statistics.median(row['result']['run_ns'] / 1e9 for row in samples)
            # The engine's process CPU clock separates startup and save I/O
            # from the measured tick window, including all worker threads.
            if all(row['result'].get('benchmark_measured_ticks', 0) > 0 for row in samples):
                for phase in ('setup', 'run', 'save'):
                    key = f'benchmark_{phase}_cpu_ns'
                    variants[variant][f'{phase}_cpu_s'] = statistics.median(row['result'][key] / 1e9 for row in samples)
                variants[variant]['cpu_ns_per_tick'] = statistics.median(
                    row['result']['benchmark_run_cpu_ns'] / row['result']['benchmark_measured_ticks'] for row in samples)
            variants[variant]['ticks'] = sorted({row['result']['ticks'] for row in samples})
            variants[variant]['termination'] = sorted({row['result']['termination'] for row in samples})
        baseline = variants.get('baseline')
        if baseline:
            for value in variants.values():
                value['wall_speedup'] = baseline['wall_s'] / value['wall_s']
                value['cpu_ratio'] = value['cpu_s'] / baseline['cpu_s']
        for name, value in variants.items():
            if name.startswith('compute-'):
                count = name.removeprefix('compute-')
                paired = variants.get('baseline' if count == '1' else f'baseline-{count}')
                if paired:
                    value['wall_speedup_over_base_same_threads'] = paired['wall_s'] / value['wall_s']
                    value['cpu_ratio_over_base_same_threads'] = value['cpu_s'] / paired['cpu_s']
                    if 'cpu_ns_per_tick' in value and 'cpu_ns_per_tick' in paired:
                        value['cpu_per_tick_ratio_over_base_same_threads'] = value['cpu_ns_per_tick'] / paired['cpu_ns_per_tick']
            if name != 'baseline':
                serial = variants.get(name.rsplit('-', 1)[0] + '-1')
                if serial:
                    value['speedup_over_serial'] = serial['wall_s'] / value['wall_s']
                    if 'run_s' in serial and 'run_s' in value:
                        value['runtime_speedup_over_serial'] = serial['run_s'] / value['run_s']
        summaries[scenario] = variants
    return summaries


def aggregate_summary(summary, scenarios):
    groups = {s['id']: s.get('group', s['id']) for s in scenarios}
    controls = {s['id'] for s in scenarios if s.get('control', False)}
    aggregate = {}
    variants = set.intersection(*(set(values) for values in summary.values())) if summary else set()
    for variant in sorted(variants):
        heavy = [values[variant] for name, values in summary.items() if name not in controls]
        small = [values[variant] for name, values in summary.items() if name in controls]
        if not heavy:
            continue
        result = {}
        for key in ('wall_speedup', 'cpu_ratio'):
            by_group = {}
            for scenario, values in summary.items():
                if scenario not in controls:
                    by_group.setdefault(groups[scenario], []).append(math.log(values[variant][key]))
            result[key] = math.exp(statistics.mean(statistics.mean(v) for v in by_group.values()))
        result['worst_cpu_ratio'] = max(v['cpu_ratio'] for v in heavy)
        result['worst_control_speedup'] = min((v['wall_speedup'] for v in small), default=None)
        aggregate[variant] = result
    return aggregate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('before', type=Path)
    parser.add_argument('after', type=Path)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repeats', type=int, default=5)
    parser.add_argument('--threads', nargs='+', default=['1', '2', '4', '8', 'auto'])
    parser.add_argument('--verify', action='store_true', help='Compare per-tick traces, replay orders and final saves, without timing repeats')
    args = parser.parse_args()
    before, after, output = args.before.resolve(), args.after.resolve(), args.output.resolve()
    if args.repeats < 1 or any(n != 'auto' and (not n.isascii() or not n.isdecimal() or int(n) < 1 or int(n) > 2**32 - 1) for n in args.threads):
        parser.error('positive repeats and auto or positive unsigned thread counts required')
    manifest = json.loads(args.manifest.read_text())
    for scenario in manifest['scenarios']:
        for path, expected in scenario.get('fixture_sha256', {}).items():
            if digest(path) != expected:
                raise ValueError(f'fixture changed: {path}')
    output.mkdir(parents=True, exist_ok=False)
    metadata = dict(platform=platform.platform(), binaries={str(p): digest(p) for p in (before, after)}, manifest=manifest,
                    arguments=vars(args) | {'before': str(before), 'after': str(after), 'output': str(output), 'manifest': str(args.manifest.resolve())},
                    memory_note='wait4 peak resident bytes, measured separately for each child')
    (output / 'metadata.json').write_text(json.dumps(metadata, indent=2))
    variants = [('baseline', before, ['--compute-threads', '1'])]
    for threads in args.threads:
        if threads not in ('1', 'auto'):
            variants.append((f'baseline-{threads}', before, ['--compute-threads', threads]))
        variants.append((f'compute-{threads}', after, ['--compute-threads', threads]))
    rows = []
    with (output / 'measurements.jsonl').open('w') as stream:
        for scenario in manifest['scenarios']:
            reference = None
            for repeat in ([0] if args.verify else range(-1, args.repeats)):
                # Rotate then reverse on alternate rounds to distribute thermal drift.
                shift = (repeat + 1) % len(variants)
                order = variants[shift:] + variants[:shift]
                if repeat % 2: order = list(reversed(order))
                for variant, binary, extra in order:
                    run_args = list(scenario['args']) + extra
                    if args.verify:
                        run_args += ['--telemetry', 'checksums', '--write-replay', '--save', 'final']
                    directory = output / scenario['id'] / str(repeat) / variant
                    row = dict(scenario=scenario['id'], variant=variant, repeat=repeat,
                               **execute(binary, run_args, directory))
                    rows.append(row)
                    stream.write(json.dumps(row) + '\n'); stream.flush()
                    if args.verify:
                        hashes = {name: digest(directory / name) for name in ('game.replay.checksums', 'game.replay', 'final.game')}
                        if reference is None: reference = hashes
                        if hashes != reference:
                            raise RuntimeError(f"correctness mismatch: {scenario['id']} {variant}: {hashes} != {reference}")
                    print(f"{scenario['id']} {repeat} {variant}: wall={row['wall_s']:.3f}s cpu={row['cpu_s']:.3f}s ticks={row['result']['ticks']}", flush=True)
    summary = summarize(rows)
    aggregate = aggregate_summary(summary, manifest['scenarios'])
    (output / 'summary.json').write_text(json.dumps(dict(scenarios=summary, aggregate=aggregate), indent=2))


if __name__ == '__main__':
    main()
