#!/usr/bin/env python3
"""Exercise map CLI modes in a disposable profile; PNG checks use the shared software renderer without a display."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from build_paths import native_binary
import hashlib
import json
import os
import struct
import subprocess
import sys
import tempfile
import zlib

ROOT = Path(__file__).resolve().parents[1]
GENERATION_ONLY = '--generation-only' in sys.argv
arguments = [arg for arg in sys.argv[1:] if arg != '--generation-only']
BINARY = Path(arguments[0] if arguments else native_binary()).resolve()
OUT = ROOT / 'artifacts/map-cli'
if GENERATION_ONLY:
    OUT = OUT / 'generation-only'
OUT.mkdir(parents=True, exist_ok=True)


def png(path):
    data = path.read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n'
    offset, compressed = 8, bytearray()
    while offset < len(data):
        size, kind = struct.unpack_from('>I4s', data, offset)
        payload = data[offset+8:offset+8+size]
        assert zlib.crc32(kind + payload) & 0xffffffff == struct.unpack_from('>I', data, offset+8+size)[0]
        if kind == b'IHDR':
            width, height, depth, color, compression, filtering, interlace = struct.unpack('>IIBBBBB', payload)
            assert depth == 8 and color in (2, 6) and compression == filtering == interlace == 0
        if kind == b'IDAT':
            compressed.extend(payload)
        offset += size + 12
    bpp = 3 if color == 2 else 4
    raw = zlib.decompress(compressed)
    stride = width * bpp
    assert len(raw) == height * (stride + 1)
    previous = bytearray(stride)
    pixels = bytearray()
    for y in range(height):
        filter_type = raw[y*(stride+1)]
        row = bytearray(raw[y*(stride+1)+1:(y+1)*(stride+1)])
        for x in range(stride):
            a, b, c = row[x-bpp] if x >= bpp else 0, previous[x], previous[x-bpp] if x >= bpp else 0
            p = a+b-c
            distances = (abs(p-a), abs(p-b), abs(p-c))
            paeth = (a, b, c)[distances.index(min(distances))]
            assert 0 <= filter_type <= 4
            row[x] = (row[x] + (0, a, b, (a+b)//2, paeth)[filter_type]) & 255
        pixels.extend(v for i, v in enumerate(row) if bpp == 3 or i % 4 != 3)
        previous = row
    return width, height, bytes(pixels)


def main():
    log = []
    with tempfile.TemporaryDirectory(prefix='glob2-map-cli-') as temp:
        profile = Path(temp)
        preferences = profile / 'preferences.txt'
        preferences.write_text('rememberUnit=1\n')
        before = preferences.read_bytes(), preferences.stat().st_mtime_ns
        env = dict(os.environ, GLOB2_USER_DATA_DIR=str(profile), SDL_AUDIODRIVER='invalid', SDL_VIDEODRIVER='invalid')

        def run(*args, ok=True):
            args = list(map(str,args))
            if args[:2] in (['map', 'generate'], ['map', 'preview'], ['map', 'render'], ['map', 'generators']) and '--help' not in args:
                args[2:2] = ['--data-dir', str(ROOT)]
            try:
                result = subprocess.run([str(BINARY), *args], cwd=profile, env=env,
                                        capture_output=True, text=True, timeout=90)
            except subprocess.TimeoutExpired as error:
                # TimeoutExpired carries bytes even when text=True. Preserve the
                # failing command and output alongside preceding successful calls.
                log.append({'args': args, 'exit': None, 'timeout_seconds': error.timeout,
                            'stdout': (error.stdout or b'').decode('utf-8', errors='replace'),
                            'stderr': (error.stderr or b'').decode('utf-8', errors='replace')})
                (OUT/'commands.json').write_text(json.dumps(log,indent=2)+'\n')
                raise
            log.append({'args': list(map(str,args)), 'exit': result.returncode,
                        'stdout': result.stdout, 'stderr': result.stderr})
            (OUT/'commands.json').write_text(json.dumps(log,indent=2)+'\n')
            assert result.returncode == 0 if ok else result.returncode in (2, 3), log[-1]
            return result.stdout

        assert 'coral' in run('map', 'generators')
        catalog = run('map', 'generators', 'maze')
        assert 'cell-shape=2' in catalog and 'width=256' in catalog and '  search:' in catalog
        assert 'Generate a map at one exact seed' in run('map', 'generate', '--help')
        assert 'map preview' in run('--help')
        config = OUT / 'maze.cfg'
        config.write_text('# Test CLI precedence even before --config\nseed=99\nwidth=256\nheight=128\nteams=4\nworkers=4\ncell-shape=1\n')
        # --output writes maze.map.gz (an explicit ".map" destination gets a ".gz"
        # suffix); naming the variable with the suffix already applied means the
        # CLI's actual output path and this variable are exactly the same string.
        first, second, saved, loaded = (OUT / name for name in ('cli.png','config.png','maze.map.gz','loaded.png'))
        if GENERATION_ONLY:
            env['SDL_VIDEODRIVER'] = 'invalid'
            run('map', 'generate','maze','--seed','7','--width','128','--height','128',
                '--teams','4','--set','cell-shape=0','--output',saved)
            original = saved.read_bytes()
            run('map', 'generate','maze','--seed','7','--width','128','--set','cell-shape=0',
                '--config',config,'--output',saved)
            assert original == saved.read_bytes(), 'Config/CLI changed serialized map'
            run('map', 'generate','maze','--set','unknown=1','--output',saved,ok=False)
            assert original == saved.read_bytes(), 'Invalid settings overwrote map'
            assert (preferences.read_bytes(), preferences.stat().st_mtime_ns) == before
            print('PASS headless map generation, serialized config/CLI equivalence, invalid settings, preferences')
            return
        run('map', 'generate','maze','--seed','7','--width','128','--height','128',
            '--teams','4','--set','cell-shape=0','--preview',first,'--output',saved,'--report-file',OUT/'maze.json')
        assert json.loads((OUT/'maze.json').read_text())['map']['width'] == 128
        run('map', 'generate','maze','--seed','7','--width','128','--set','cell-shape=0',
            '--config',config,'--preview',second)
        width, height, pixels = png(first)
        assert sum(any(pixels[i:i+3]) for i in range(0,len(pixels),3)) > width*height*0.9, 'Terrain was not drawn'
        assert png(first) == png(second), 'Config/CLI precedence changed generation'
        saved_before = saved.read_bytes()
        run('map', 'preview',saved,'--output',loaded)
        assert png(first) == png(loaded), 'Generated map preview differs after loading'
        run('map', 'preview',saved,'--preview',loaded)
        assert png(first) == png(loaded), '--preview differs from --output'
        run('map', 'preview',saved,'--output',loaded,'--preview',first,ok=False)
        terrain = OUT / 'import-controls.png'
        run('map', 'export-image',saved,'--output',terrain)
        imported = OUT / 'imported.map.gz'
        run('map', 'import-image',terrain,'--width','128','--height','128','--teams','4',
            '--data-dir',ROOT,'--output',imported)
        imported_bytes = imported.read_bytes()
        run('map', 'import-image',terrain,'--set','width=128','--set','height=128','--set','teams=4',
            '--data-dir',ROOT,'--output',imported)
        assert imported.read_bytes() == imported_bytes, '--set changed image import controls'
        asset_directory = profile / 'assets-only'
        asset_directory.mkdir()
        (asset_directory / 'script-input.map.gz').write_bytes(saved.read_bytes())
        scripted = profile / 'scripted.map.gz'
        run('script', 'attach','script-input.map.gz',ROOT/'examples/javascript/scenario.js',scripted,
            '--data-dir',asset_directory,'--data-dir',ROOT)
        assert scripted.is_file(), 'Script attachment ignored --data-dir input search paths'
        assert png(first)[:2] == (256,256)
        for scale in (2, 4, 8):
            scaled = OUT / f'scale-{scale}.png'
            run('map', 'preview',saved,'--output',scaled,'--preview-scale',scale)
            assert png(scaled)[:2] == (128*scale,128*scale)
            if scale == 2:
                assert png(scaled) == png(first), 'Default differs from explicit 2x'
            explicit = OUT / f'size-{128*scale}.png'
            run('map', 'preview',saved,'--output',explicit,'--preview-size',128*scale)
            assert png(scaled) == png(explicit), 'Scale differs from equivalent explicit size'
        run('map', 'preview',saved,'--output',loaded,'--preview-size','128')
        assert png(loaded)[:2] == (128,128)
        run('map', 'preview',saved,'--output','relative.png')
        assert png(profile/'relative.png')[:2] == (256,256), 'CLI changed working directory'
        assert saved.read_bytes() == saved_before, 'Preview modified input map'
        for fixture in ('team-stats/version88.game.gz','wrapped-building/reproducer.game.gz','entering-explorer/reproducer.game.gz'):
            source = ROOT / 'test/fixtures' / fixture
            old = source.read_bytes()
            run('map', 'preview',source,'--output',OUT / (source.parent.name+'.png'))
            assert source.read_bytes() == old, 'Preview modified save'
            png(OUT / (source.parent.name+'.png'))
        rectangular = OUT / 'rectangular.png'
        run('map', 'generate','maze','--seed','7','--width','256','--height','128','--preview',rectangular)
        assert png(rectangular)[:2] == (512,256), 'Preview lost map aspect ratio'
        for scale in (4, 8):
            run('map', 'generate','maze','--seed','7','--width','256','--height','128',
                '--preview',OUT/f'rectangular-{scale}.png','--preview-scale',scale)
            assert png(OUT/f'rectangular-{scale}.png')[:2] == (256*scale,128*scale)
        premade = next(iter(sorted((ROOT / 'maps').glob('*.map.gz'))))
        run('map', 'preview',premade,'--output',OUT / 'premade.png')
        png(OUT / 'premade.png')
        invalid = [
            ['map', 'preview',saved,'--output',first,'--preview-scale','3'],
            ['map', 'preview',saved,'--output',first,'--preview-scale','0'],
            ['map', 'preview',saved,'--output',first,'--preview-scale','16'],
            ['map', 'preview',saved,'--output',first,'--preview-scale','4','--preview-size','512'],
            ['map', 'generate','maze','--report-file',OUT/'unused.json','--preview-scale','2'],
            ['map', 'preview',saved,'--output',first,'--preview-scale'],
            ['map', 'generate'], ['map', 'generate','unknown','--preview',first],
            ['map', 'generate','maze'], ['map', 'generate','maze','--seed'],
            ['map', 'generate','maze','--seed','4294967296','--preview',first],
            ['map', 'generate','maze','--seed','-1','--preview',first],
            ['map', 'generate','maze','--width','127','--preview',first],
            ['map', 'generate','maze','--set','unknown=1','--preview',first],
            ['map', 'generate','maze','--set','cell-shape=99','--preview',first],
            ['map', 'generate','maze','--set','cell-shape=1junk','--preview',first],
            ['map', 'generate','maze','--set','broken','--preview',first],
            ['map', 'generate','maze','--output',first,'--preview',first],
            ['map', 'generate','maze','--output',saved,'--preview-size','256'],
            ['map', 'generate','maze','--config',OUT/'missing.cfg','--preview',first],
            ['map', 'preview',OUT/'missing.game','--output',first],
            ['map', 'preview',saved,'--output',saved],
            ['map', 'preview',saved,'--output',first,'--overlay','unknown'],
            ['map', 'preview',saved,'--output',first,'--preview-size','0'],
            ['map', 'preview',saved,'--output',first,'--preview-size','4294967295'],
            ['map', 'preview',saved,'--output',first,'--seed','7'],
            ['map', 'preview',saved,'--output',OUT],
        ]
        for args in invalid:
            run(*args,ok=False)
        config = OUT / 'invalid.cfg'
        config.write_text('not key=value\ninvalid line\n')
        run('map', 'generate','maze','--config',config,'--preview',first,ok=False)
        assert (preferences.read_bytes(), preferences.stat().st_mtime_ns) == before
        assert not list(profile.rglob('*.replay'))
    (OUT/'commands.json').write_text(json.dumps(log,indent=2)+'\n')
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob('*.png')}
    (OUT/'sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(f'PASS {len(log)} map CLI commands: config precedence, map round trip, preview sizes, '
          'premade map, three saves, invalid inputs and unchanged preferences.')
    print(f'Artifacts: {OUT}')


if __name__ == '__main__':
    main()
    if not GENERATION_ONLY:
        from test_game_diagnostics import main as diagnostics_main
        diagnostics_main(BINARY)
