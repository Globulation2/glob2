"""Mobile configuration isolation, independent of installed SDKs."""
import itertools
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scons'))
from build_layout import build_identity, default_directory, prepare_directory
from mobile_toolchain import discover


class EmulatorSmokeTests(unittest.TestCase):
    def test_smoke_completes_hand_preference_and_waits_for_current_menu(self):
        sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'mobile'))
        import smoke
        for first_run in (False, True):
            with self.subTest(first_run=first_run):
                history = ['Glob2 screen ready: MainMenuScreen']
                if first_run:
                    history.append('Glob2 screen ready: HandPreferenceScreen')
                commands = []

                def run(*command):
                    commands.append(command)
                    if command[-1] == 'KEYCODE_ENTER':
                        history.append('Glob2 screen ready: MainMenuScreen')

                def wait_for(predicate, description):
                    self.assertTrue(predicate(), description)

                smoke.wait_for_main_menu(run, lambda: '\n'.join(history), wait_for)
                self.assertEqual([command[-1] for command in commands],
                                 ['KEYCODE_TAB', 'KEYCODE_ENTER'] if first_run else [])

    def test_pinned_java_home_is_host_specific_and_preserves_override(self):
        import json
        sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'mobile'))
        import developer_apk
        root = Path(__file__).resolve().parents[2]
        lock = json.loads((root/'mobile/android-tools.json').read_text())
        scratch = root/'build/test-profiles'
        scratch.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as temporary:
            task = Path(temporary)
            (task/'mobile').mkdir()
            (task/'mobile/android-tools.json').write_text(json.dumps(lock))
            for system, machine in [('Darwin', 'arm64'), ('Linux', 'x86_64')]:
                artifact = lock['jdk-' + system + '-' + machine]
                home = task/'build/mobile-tools'/artifact['directory']/artifact['java_home']
                (home/'bin').mkdir(parents=True, exist_ok=True)
                (home/'bin/java').touch()
                with self.subTest(system=system), patch('developer_apk.platform.system', return_value=system), patch('developer_apk.platform.machine', return_value=machine):
                    with patch.dict('developer_apk.os.environ', {'GLOB2_DEV_MODE':'isolated'}, clear=True):
                        self.assertEqual(developer_apk.java_environment(task)['JAVA_HOME'], str(home))
                    with patch.dict('developer_apk.os.environ', {'JAVA_HOME': '/explicit/jdk', 'GLOB2_DEV_MODE':'isolated'}, clear=True):
                        self.assertEqual(developer_apk.java_environment(task)['JAVA_HOME'], '/explicit/jdk')

    def test_smoke_rejects_physical_devices_and_shared_servers(self):
        sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'mobile'))
        import smoke
        for serial, port, avd in [('USB-device', 15037, 'glob2-api35-arm64'),
                                   ('emulator-5580', 5037, 'glob2-api35-arm64'),
                                   ('emulator-5580', 15037, 'personal-avd')]:
            with self.subTest(serial=serial, port=port, avd=avd), self.assertRaises(ValueError):
                smoke.validate_target(serial, port, avd)
        smoke.validate_target('emulator-5580', 15037, 'glob2-api35-x64')

    def test_extracted_emulator_is_registered_without_changing_licenses(self):
        import json
        import xml.etree.ElementTree as ET
        sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'mobile'))
        import setup_tools
        root = Path(__file__).resolve().parents[2]
        lock = json.loads((root / 'mobile/emulator.json').read_text())
        scratch = root / 'build/test-profiles'
        scratch.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as temporary:
            destination = Path(temporary)
            properties = destination / 'source.properties'
            properties.write_text('Pkg.Revision=' + lock['emulator_revision'] + '\n')
            artifact = lock['archives']['Linux-x86_64']
            setup_tools.ensure_sdk_metadata(destination, artifact)
            package = ET.parse(destination / 'package.xml').getroot().find('localPackage')
            self.assertEqual(package.get('path'), 'emulator')
            self.assertFalse((destination / 'licenses').exists())
            setup_tools.ensure_sdk_metadata(destination, artifact)
            properties.write_text('Pkg.Revision=0.0.0\n')
            with self.assertRaisesRegex(ValueError, 'revision differs'):
                setup_tools.ensure_sdk_metadata(destination, artifact)

    def test_emulator_archives_match_configured_package_versions(self):
        import json
        root = Path(__file__).resolve().parents[2]
        lock = json.loads((root / 'mobile/emulator.json').read_text())
        for arch in ('arm64-v8a', 'x86_64'):
            artifact = lock['archives'][arch]
            self.assertEqual(artifact['directory'], f"android-sdk/system-images/android-{lock['api']}/{lock['tag']}/{arch}")
            self.assertIn(f"-{lock['api']}_r{int(lock['image_revision']):02}.zip", artifact['url'])
            self.assertEqual(len(artifact['sha1']), 40)


class DeveloperSigningTests(unittest.TestCase):
    def test_install_rejects_stale_or_modified_signed_apk(self):
        import hashlib
        import json
        sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'mobile'))
        import developer_apk
        scratch=Path(__file__).resolve().parents[2]/'build/test-profiles'
        scratch.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as temporary:
            root=Path(temporary)
            directory=root/'app/build/outputs/apk/release';directory.mkdir(parents=True)
            unsigned=directory/'app-release-unsigned.apk'
            signed=directory/'app-release-development.apk'
            unsigned.write_bytes(b'original');signed.write_bytes(b'signed')
            signed.with_suffix('.json').write_text(json.dumps({
                'unsigned_sha256':hashlib.sha256(b'original').hexdigest(),
                'signed_sha256':hashlib.sha256(b'signed').hexdigest()}))
            with patch('developer_apk.subprocess.run') as run:
                for path in (unsigned,signed):
                    original=path.read_bytes();path.write_bytes(b'changed')
                    with self.assertRaisesRegex(ValueError,'stale or changed'):
                        developer_apk.verified(root,root,root)
                    path.write_bytes(original)
                run.assert_not_called()


class PlayBundleAssetTests(unittest.TestCase):
    def test_signing_rejects_changed_bundle_before_using_key(self):
        import json
        sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'mobile'))
        import android
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            bundle=root/'build/android/device/arm64-v8a/24/client/release/android-project/app/build/outputs/bundle/release/app-release.aab'
            bundle.parent.mkdir(parents=True)
            bundle.write_bytes(b'changed')
            bundle.with_suffix('.json').write_text(json.dumps({'sha256':'0'*64}))
            argv=['android.py','sign-bundle','--release','--keystore',str(root/'key.jks'),'--key-alias','upload']
            passwords={'GLOB2_PLAY_STORE_PASSWORD':'test','GLOB2_PLAY_KEY_PASSWORD':'test','GLOB2_DEV_MODE':'isolated'}
            with patch.object(android,'ROOT',root), patch.object(sys,'argv',argv), patch.dict('os.environ',passwords), patch('android.subprocess.run') as run:
                with self.assertRaisesRegex(ValueError,'changed since verification'):
                    android.main()
                run.assert_not_called()

    def test_bundle_restores_gzip_assets_and_checks_original_bytes(self):
        import gzip
        import hashlib
        import zipfile
        sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'mobile'))
        from asset_bundle import restore_gzip_assets, verify_apk_assets
        prefix='base/assets/glob2-bundle/'
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            assets=root/'assets'
            source=assets/'maps/example.map.gz'
            source.parent.mkdir(parents=True)
            source.write_bytes(gzip.compress(b'map contents'))
            digest=hashlib.sha256()
            digest.update(b'maps/example.map.gz\0'+hashlib.sha256(source.read_bytes()).digest())
            bundle=root/'app.aab'
            with zipfile.ZipFile(bundle,'w') as archive:
                archive.writestr(prefix+'index.list',digest.hexdigest()+'\nmaps/example.map.gz\n')
                archive.writestr(prefix+'maps/example.map',b'map contents')
            self.assertTrue(restore_gzip_assets(bundle,assets,prefix))
            verify_apk_assets(bundle,prefix)
            self.assertFalse(restore_gzip_assets(bundle,assets,prefix))
            with zipfile.ZipFile(bundle,'w') as archive:
                archive.writestr(prefix+'index.list',digest.hexdigest()+'\nmaps/example.map.gz\n')
                archive.writestr(prefix+'maps/example.map.gz',b'changed')
            with self.assertRaises(ValueError): verify_apk_assets(bundle,prefix)


class IOSCommandTests(unittest.TestCase):
    def test_incomplete_device_requests_fail_before_sdk_or_build(self):
        sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'mobile'))
        import ios
        cases = [
            (['build','--environment','device'], 'Device packaging needs'),
            (['configure','--environment','device'], 'Device packaging needs'),
            (['install'], '--device is required'),
            (['launch','--environment','device'], '--device is required'),
            (['install','--environment','device','--unsigned','--device','example'], 'cannot be installed'),
        ]
        with patch('ios.discover') as discover_sdk, patch('ios.subprocess.run') as run:
            for arguments,message in cases:
                with self.subTest(arguments=arguments), patch.object(sys,'argv',['ios.py']+arguments):
                    with self.assertRaisesRegex(ValueError,message):
                        ios.main()
            discover_sdk.assert_not_called()
            run.assert_not_called()

    def test_simulator_install_uses_task_device_set(self):
        sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'mobile'))
        import ios
        arguments=['ios.py','install','--device','test-udid','--simulator-set','build/test-simulators']
        with patch.object(sys,'argv',arguments), patch('ios.discover'), patch('ios.subprocess.run') as run:
            ios.main()
        command=run.call_args.args[0]
        self.assertEqual(command[:6],['xcrun','simctl','--set',str(Path('build/test-simulators').resolve()),'install','test-udid'])


class MobileBuildTests(unittest.TestCase):
    def test_android_seven_is_the_default_minimum(self):
        import json
        root = Path(__file__).resolve().parents[2]
        minimum = json.loads((root/'mobile/toolchain.json').read_text())['android']['min_api']
        self.assertEqual(minimum, 24)
        self.assertEqual(build_identity({'target':'android'})['api'], str(minimum))
        self.assertEqual(build_identity({'target':'android', 'api':'24'})['api'], '24')

    def test_each_mobile_configuration_has_its_own_directory(self):
        options = [dict(target='android', arch=arch, api=api, release=release)
            for arch, api, release in itertools.product(('arm64-v8a', 'armeabi-v7a', 'x86_64'), ('24','26','35'), ('0','1'))]
        options += [dict(target='ios', environment=env, deployment=api, release=release)
            for env, api, release in itertools.product(('device','simulator'), ('15.0','16.0'), ('0','1'))]
        paths = [default_directory(build_identity(args)) for args in options]
        self.assertEqual(len(paths), len(set(paths)))

    def test_amazon_release_isolated_from_standard_android_but_reuses_toolchain(self):
        standard = build_identity({'target':'android','release':'1'})
        amazon = build_identity({'target':'android','release':'1','amazon':'1'})
        self.assertNotEqual(default_directory(standard), default_directory(amazon))
        self.assertEqual(default_directory(amazon), default_directory(standard)/'amazon')
        self.assertEqual({key:value for key,value in amazon.items() if key!='amazon'}, standard)

    def test_wrong_architecture_cannot_reuse_output(self):
        with tempfile.TemporaryDirectory() as directory:
            prepare_directory(directory, build_identity({'target':'android'}))
            with self.assertRaises(ValueError):
                prepare_directory(directory, build_identity({'target':'android', 'arch':'armeabi-v7a'}))

    def test_invalid_targets_fail_without_probing_host(self):
        invalid = [dict(target='android', role='server'), dict(target='ios', mingw='1'),
            dict(target='android', arch='arm64'), dict(target='ios', arch='x86_64'),
            dict(target='android', api='23'), dict(target='android', api='../26'),
            dict(target='ios', deployment='14.0'), dict(target='ios', deployment='../15.0'),
            dict(target='android', environment='simulator'), dict(target='ios', profile='1'),
            dict(target='android', amazon='1'), dict(target='ios', release='1', amazon='1'),
            dict(target='android', release='1', china='1', amazon='1')]
        for options in invalid:
            with self.subTest(options=options), self.assertRaises(ValueError):
                build_identity(options)

    def test_missing_android_sdk_does_not_fall_back_to_host(self):
        with tempfile.TemporaryDirectory() as directory, patch('mobile_toolchain.run') as run:
            with self.assertRaisesRegex(ValueError, 'Android NDK .* missing'):
                discover(build_identity({'target':'android'}), {'android_sdk':directory})
            run.assert_not_called()

    def test_ios_on_non_apple_host_has_actionable_error(self):
        with patch('mobile_toolchain.platform.system', return_value='Linux'):
            with self.assertRaisesRegex(ValueError, 'full Xcode'):
                discover(build_identity({'target':'ios'}), {})

class MobileArtifactTests(unittest.TestCase):
    def test_packaged_shared_libraries_require_aligned_load_segments(self):
        import struct
        from mobile_artifacts import verify_android_shared_library
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'libmain.so'
            for architecture,machine,bits in (('arm64-v8a',183,2),('x86_64',62,2),('armeabi-v7a',40,1)):
                data=bytearray(self.elf(machine,bits))
                struct.pack_into('<H',data,16,3)
                if bits==2:
                    struct.pack_into('<Q',data,32,64)
                    struct.pack_into('<HH',data,54,56,1)
                    data.extend(struct.pack('<II6Q',1,5,0,0,0,120,120,16384))
                    alignment_offset=112
                else:
                    struct.pack_into('<I',data,28,64)
                    struct.pack_into('<HH',data,42,32,1)
                    data.extend(struct.pack('<8I',1,0,0,0,96,96,5,4096))
                    alignment_offset=92
                path.write_bytes(data)
                verify_android_shared_library(path,architecture)
                path.write_bytes(data[:-1])
                with self.assertRaisesRegex(ValueError,'program header'):
                    verify_android_shared_library(path,architecture)
                struct.pack_into('<Q' if bits==2 else '<I',data,alignment_offset,4096 if bits==2 else 1024)
                path.write_bytes(data)
                with self.assertRaisesRegex(ValueError,'page aligned'):
                    verify_android_shared_library(path,architecture)

    @staticmethod
    def elf(machine, bits):
        import struct
        data=bytearray(64);data[:4]=b'\x7fELF';data[4]=bits;data[5]=1
        struct.pack_into('<H',data,18,machine)
        return bytes(data)

    def test_reject_mislabeled_dependency_before_linking(self):
        from mobile_artifacts import verify_android_library
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'libSDL3.so';path.write_bytes(self.elf(40,1))
            verify_android_library(path,'armeabi-v7a')
            with self.assertRaisesRegex(ValueError,'wrong architecture'):
                verify_android_library(path,'arm64-v8a')

    def test_checks_every_archive_member(self):
        from mobile_artifacts import verify_android_library
        def member(name,data):
            header=f'{name:<16}{0:<12}{0:<6}{0:<6}{644:<8}{len(data):<10}`\n'.encode()
            return header+data+(b'\n' if len(data)%2 else b'')
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'libmixed.a'
            path.write_bytes(b'!<arch>\n'+member('good.o/',self.elf(183,2))+member('bad.o/',self.elf(40,1)))
            with self.assertRaisesRegex(ValueError,'bad.o'):
                verify_android_library(path,'arm64-v8a')

    def test_rejects_host_archive_and_empty_archive(self):
        from mobile_artifacts import verify_android_library
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'libhost.a'
            for data in (b'!<arch>\n',b'not an archive'):
                path.write_bytes(data)
                with self.assertRaises(ValueError): verify_android_library(path,'arm64-v8a')


class ArchiveSymbolTests(unittest.TestCase):
    def test_archive_member_names_distinguish_same_basename_sources(self):
        from mobile_artifacts import archive_object_name
        from sources import CLIENT_SOURCES, GAG_SOURCES, USL_SOURCES
        sources = ['src/' + name for name in CLIENT_SOURCES] + ['libgag/src/' + name for name in GAG_SOURCES] + ['libusl/src/' + name for name in USL_SOURCES]
        names = [archive_object_name(source).name for source in sources]
        self.assertEqual(len(names), len(set(names)))
        self.assertEqual(archive_object_name('src/ai/castor/Lifecycle.cpp'), archive_object_name('src/ai/castor/Lifecycle.cpp'))
        self.assertNotEqual(archive_object_name('src/ai/castor/Lifecycle.cpp').name, archive_object_name('src/ai/nicowar/Lifecycle.cpp').name)
        with self.assertRaises(ValueError): archive_object_name('../outside.cpp')


class EmulatorEnvironmentTests(unittest.TestCase):
    def test_runner_sdk_cannot_override_the_isolated_emulator_sdk(self):
        import json
        import os
        import shutil
        sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'mobile'))
        import emulator
        root = Path(__file__).resolve().parents[2]
        scratch = root / 'build/test-profiles'
        scratch.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as temporary:
            task = Path(temporary)
            (task/'mobile').mkdir()
            shutil.copyfile(root/'mobile/emulator.json', task/'mobile/emulator.json')
            shutil.copyfile(root/'mobile/android-tools.json', task/'mobile/android-tools.json')
            lock = json.loads((task/'mobile/emulator.json').read_text())
            sdk = task/'build/mobile-tools/android-sdk'
            for path, version in [('emulator', lock['emulator_revision']), ('system-images/android-35/default/x86_64', lock['image_revision'])]:
                directory = sdk/path
                directory.mkdir(parents=True)
                (directory/'source.properties').write_text('Pkg.Revision='+version+'\n')
            config = task/'build/mobile-tools/avd/glob2-api35-x64.avd/config.ini'
            def create(*args, **kwargs):
                self.assertEqual(kwargs['env']['ANDROID_HOME'], str(sdk))
                self.assertEqual(kwargs['env']['ANDROID_SDK_ROOT'], str(sdk))
                config.parent.mkdir(parents=True)
                config.write_text('image.sysdir.1=system-images/android-35/default/x86_64/\n')
            with patch.object(emulator, 'ROOT', task), patch.dict(os.environ, {'ANDROID_HOME': '/runner/shared/sdk', 'GLOB2_DEV_MODE':'isolated'}), patch.object(sys, 'argv', ['emulator.py','configure','--arch','x86_64']), patch.object(emulator.subprocess, 'run', side_effect=create):
                emulator.main()
            self.assertIn('hw.lcd.width=320', config.read_text())


class IOSSmokeFailureTests(unittest.TestCase):
    def test_unified_log_readiness_is_scoped_to_each_launched_process(self):
        import json
        sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'mobile'))
        import ios_smoke
        root = Path(__file__).resolve().parents[2]
        scratch = root/'build/test-profiles'
        scratch.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as temporary:
            output = Path(temporary)/'diagnostics'
            launch_count = 0
            predicates = []
            def command(argv, **kwargs):
                nonlocal launch_count
                arguments = argv[4:]
                if arguments[:2] == ['list', 'devices']:
                    return json.dumps({'devices': {'runtime': [{'udid': 'owned-test', 'name': 'Glob2-Mobile', 'state': 'Booted'}]}})
                if arguments[0] == 'launch' and arguments[-1] == ios_smoke.PACKAGE:
                    launch_count += 1
                    return ios_smoke.PACKAGE + ': ' + ('123' if launch_count < 3 else '456')
                if arguments[:4] == ['spawn', 'owned-test', 'log', 'show']:
                    self.assertIn('--start', arguments)
                    predicates.append(arguments[-1])
                    return 'Glob2 screen ready: 14MainMenuScreen\n'
                return ''
            with patch.object(sys, 'argv', ['ios_smoke.py', '--device', 'owned-test', '--output', str(output)]), patch.object(ios_smoke.subprocess, 'check_output', side_effect=command), patch.object(ios_smoke.time, 'sleep'):
                ios_smoke.main()
            self.assertEqual(predicates, [
                'processIdentifier == 123 AND eventMessage CONTAINS "Glob2 screen ready:"',
                'processIdentifier == 456 AND eventMessage CONTAINS "Glob2 screen ready:"'])
            result = json.loads((output/'result.json').read_text())
            self.assertTrue(result['passed'])
            self.assertEqual(len(result['checks']), 3)
            self.assertTrue((output/'startup-readiness-system.log').exists())

    def test_main_menu_readiness_requires_one_complete_message(self):
        sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'mobile'))
        import ios_smoke
        self.assertFalse(ios_smoke.main_menu_ready('Glob2 screen ready: SettingsScreen\nOld MainMenuScreen'))
        self.assertTrue(ios_smoke.main_menu_ready('Glob2 screen ready: 14MainMenuScreen'))

    def test_launch_timeout_survives_failed_diagnostics_without_stopping_unstarted_apps(self):
        import json
        import subprocess
        sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'mobile'))
        import ios_smoke
        root = Path(__file__).resolve().parents[2]
        scratch = root/'build/test-profiles'
        scratch.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as temporary:
            output = Path(temporary)/'diagnostics'
            calls = []
            def command(argv, **kwargs):
                arguments = argv[4:]
                calls.append((arguments, kwargs['timeout']))
                if arguments[:2] == ['list', 'devices']:
                    return json.dumps({'devices': {'runtime': [{'udid': 'owned-test', 'name': 'Glob2-Mobile', 'state': 'Booted'}]}})
                if len(calls) == 2: return ''  # No app is running before launch.
                if arguments[0] == 'launch': raise subprocess.TimeoutExpired(argv, 180)
                raise subprocess.CalledProcessError(1, argv, output='Simulator diagnostic unavailable')
            with patch.object(sys, 'argv', ['ios_smoke.py', '--device', 'owned-test', '--output', str(output)]), patch.object(ios_smoke.subprocess, 'check_output', side_effect=command):
                with self.assertRaises(subprocess.TimeoutExpired) as failure:
                    ios_smoke.main()
            self.assertIn('launch', failure.exception.cmd)
            self.assertFalse(any(arguments[0] == 'terminate' for arguments, unused in calls))
            self.assertTrue(all(timeout == 30 for unused, timeout in calls[3:]))
            result = json.loads((output/'result.json').read_text())
            self.assertFalse(result['passed'])
            self.assertEqual(result['checks'], [])
            self.assertEqual(len(result['diagnostic_errors']), 2)
            history = json.loads((output/'commands.json').read_text())
            self.assertEqual(history[2]['arguments'][0], 'launch')
            self.assertFalse(history[2]['success'])


class AndroidSymbolTests(unittest.TestCase):
    def test_packaged_symbols_require_matching_unambiguous_build_ids(self):
        import zipfile
        from mobile_artifacts import verify_android_symbols
        with tempfile.TemporaryDirectory() as directory:
            apk=Path(directory)/'app.apk'
            with zipfile.ZipFile(apk,'w') as archive:
                archive.writestr('lib/arm64-v8a/libmain.so',b'packaged library')
            library=Path(directory)/'libmain.so'
            library.write_bytes(b'debug library')
            valid='Build ID: '+('a'*40)+'\n'
            with patch('subprocess.check_output',side_effect=[valid,valid]):
                self.assertEqual(verify_android_symbols(apk,library,'arm64-v8a','readelf'),'a'*40)
            for notes in ('',valid+valid,'Build ID: '+('b'*40)+'\n'):
                with patch('subprocess.check_output',side_effect=[valid,notes]):
                    with self.assertRaises(ValueError):
                        verify_android_symbols(apk,library,'arm64-v8a','readelf')

    def test_bundle_uses_base_module_native_library(self):
        import zipfile
        from mobile_artifacts import verify_android_archive_symbols
        with tempfile.TemporaryDirectory() as directory:
            bundle=Path(directory)/'app.aab'
            member='base/lib/arm64-v8a/libmain.so'
            with zipfile.ZipFile(bundle,'w') as archive:
                archive.writestr(member,b'packaged library')
            library=Path(directory)/'libmain.so'
            library.write_bytes(b'debug library')
            notes='Build ID: '+('a'*40)+'\n'
            with patch('subprocess.check_output',side_effect=[notes,notes]):
                self.assertEqual(verify_android_archive_symbols(bundle,library,member,'readelf'),'a'*40)


class IOSNumericGuardTests(unittest.TestCase):
    def test_ios_guard_uses_its_own_compiled_objects_without_android_mapping(self):
        import ast
        from unittest.mock import Mock
        root = Path(__file__).resolve().parents[2]
        tree = ast.parse((root / 'scons/mobile_build.py').read_text())
        branch = next(node for node in ast.walk(tree) if isinstance(node, ast.If)
                      and ast.unparse(node.test) == "identity['target'] == 'android'"
                      and any(isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'by_source' for t in n.targets) for n in node.body))
        guard = next(node for node in branch.orelse if isinstance(node, ast.Expr)
                     and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name)
                     and node.value.func.id == 'numeric_guard')
        predicate = next(node for node in ast.parse((root / 'scons/javascript.py').read_text()).body
                         if isinstance(node, ast.FunctionDef) and node.name == 'guarded_numeric_source')
        namespace = {}
        exec(compile(ast.Module(body=[predicate], type_ignores=[]), '<numeric-selection>', 'exec'), namespace)
        files = ['src/app/Main.cpp', 'src/scripting/javascript/Runtime.cpp',
                 'mobile/ios/Documents.mm', 'src/ai/javascript/AIJavaScript.cpp',
                 'src/map/generator/javascript/ToolkitBinding.cpp']
        objects = [object() for _ in files]
        script = object()
        callback = Mock()
        strict = object()
        namespace.update(files=files, objects=objects + [script], strict=strict, numeric_guard=callback)
        # No Android-only by_source map is available in an iOS graph.
        exec(compile(ast.Module(body=[guard], type_ignores=[]), '<ios-guard>', 'exec'), namespace)
        callback.assert_called_once_with(strict, [objects[1], objects[3], objects[4]])
