#include "AdaptiveGradientModel.h"
#include <iostream>
int main(){AdaptiveGradientModel::BaseFeatures b;AdaptiveGradientModel::MovementCounts c;unsigned f;while(std::cin>>f>>b[0]>>b[1]>>b[2]>>b[3]>>b[4]>>b[5]>>b[6]>>c[0]>>c[1]>>c[2])std::cout<<AdaptiveGradientModel::predict(b,c,f)<<"\n";}