#!/bin/sh
set -eu
build_dir=$1
label=$2
out="artifacts/resource-core/$label"
mkdir -p "$out"
python3 tools/cli_reference.py --binary "$build_dir/src/glob2" --check > "$out/cli-reference.log" 2>&1
python3 test/run_tests.py --build-dir "$build_dir" --binary engine -j4 --no-display \
 --filter 'ApplicationResourcePlan/*' --filter 'ReplayTelemetry/*' --filter 'ComputeExecutor/*' \
 --filter 'GradientPreparation/seed cells match scalar predicates across policies and changing overlays*' \
 --filter 'TurnEngineHarness/a client that executes a tampered order is repaired by an in-place reload and named by the verifier*' \
 --filter 'CommandLine/*' --junit "$out/engine.xml" --artifacts "$out/engine" > "$out/engine.log" 2>&1
python3 test/run_tests.py --build-dir "$build_dir" --binary unit -j4 --no-display \
 --filter 'OpenCLGradient/*' --filter 'ComputeExecutor/*' --junit "$out/unit.xml" --artifacts "$out/unit" > "$out/unit.log" 2>&1
