from pathlib import Path
import json,os,subprocess,sys
root=Path('/home/bradley/glob2-resource-core-20261013-441870ef1')
base=root/'baseline'; candidate=root/'candidate'
out=root/'integration-policy-final';out.mkdir(exist_ok=True)
commands=[]
expected=None
for label,source in [('baseline',base),('candidate',candidate)]:
 binary=source/'build/linux/client/release/src/glob2'
 for count in [1,3,6]:
  dest=out/f'{label}-match-{count}'
  command=[str(binary),'match','verify','test/fixtures/multiplayer/FourSquares1.g2mr','--map-file','maps/FourSquares1.map.gz','--compute-threads',str(count),'--output-dir',str(dest)]
  commands.append(command)
  with dest.with_suffix('.log').open('w') as f:subprocess.run(command,cwd=source,stdout=f,stderr=subprocess.STDOUT,check=True)
  trace=(dest/'checksums.txt').read_bytes()
  if expected is None:expected=trace
  assert trace==expected,(label,count)
 for mask in ['12','12-14','12-14,28-30'] if label=='candidate' else []:
  eligible=1 if mask=='12' else 3 if mask=='12-14' else 6
  for count in ['auto','1','3','6']:
   dest=out/f'affinity-{eligible}-{count}'
   command=['taskset','-c',mask,str(binary),'game','run','--map-file','maps/FourSquares1.map.gz','--game-seed','713','--player','nicowar','--player','nicowar','--player','nicowar','--player','nicowar','--ticks','64','--gradient-backend','cpu','--compute-threads',count,'--output-dir',str(dest)]
   commands.append(command)
   with dest.with_suffix('.log').open('w') as f:subprocess.run(command,cwd=source,stdout=f,stderr=subprocess.STDOUT,check=True)
   result=json.loads((dest/'result.json').read_text());plan=result['resource_plan']
   n=plan['hardware_threads'] if count=='auto' else int(count)
   assert result['compute_threads']==result['compute_resolved_threads']==plan['compute_participants']==n,result
   assert result['compute_workers']==n-1 and plan['eligible_threads']==eligible,result
   assert plan['exceeds_cpu_allocation']==(n>eligible),result
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(out/'summary.json').write_text(json.dumps({'baseline_candidate_counts':[1,3,6],'equal_trace_lines':len(expected.splitlines()),'affinity_cases':12},indent=2)+'\n')
print('Linux per-tick match equality and twelve affinity admission cases passed')
