from pathlib import Path
import json,os,sys
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root))
from tools.tournaments.local import supplied_binary,execute_jobs
from tools.tournaments.model import job
out=root/'artifacts/resource-core/tournament-engine-smoke'
out.mkdir(parents=True,exist_ok=True)
binary=root/'build/linux/client/release/src/glob2'
bundle=supplied_binary(binary,root,out/'bundles')
initial=os.sched_getaffinity(0)
cpus=sorted(initial)[:4]
assert len(cpus)==4
report=[]
for label,mask,slots,count,jobs_count in [('parallel',cpus,2,2,3),('serial',cpus[:1],1,1,1)]:
 jobs=[job('game',bundle.name,config={'generator':15,'params':{'teams':2,'width':6,'height':6},'players':['nicowar','nicowar'],'ticks':64},seeds={'map':713,'game':714+i},limits={'timeout_seconds':120}) for i in range(jobs_count)]
 results=execute_jobs(out/label,jobs,bundle,slots=slots,cpu_ids=mask,participants_per_game=count)
 records=list(results)
 assert len(records)==jobs_count, list(results.attempts())
 for row in records:
  allocation=row['execution_allocation']['allocation']
  assert row['category']=='success',row
  assert row['cpu_affinity_proof']['actual_cpu_ids']==allocation['cpu_ids'],row
  assert row['result']['compute_threads']==row['result']['compute_resolved_threads']==count,row
  plan=row['result']['resource_plan']
  assert plan['eligible_threads']==len(allocation['cpu_ids']),row
  assert plan['participant_source']=='explicit-override',row
  report.append({'case':label,'attempt':row['id'],'allocation':row['execution_allocation'],'affinity':row['cpu_affinity_proof'],'resource_plan':plan})
 assert os.sched_getaffinity(0)==initial
(out/'proof.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'validated_games':len(report),'parent_affinity_unchanged':True}))
