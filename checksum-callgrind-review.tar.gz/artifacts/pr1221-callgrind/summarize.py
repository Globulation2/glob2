import json,re,collections
from pathlib import Path
out=Path(__file__).resolve().parent

def parse(path):
 names={};selfcost=collections.Counter();edges=collections.Counter();calls=collections.Counter();fn=None;cfn=None;pending=False
 for line in path.read_text().splitlines():
  m=re.match(r'(c?fn)=\((\d+)\)(?: (.*))?$',line)
  if m:
   key,num,name=m.groups()
   if name:names[num]=name
   if key=='fn':fn=num
   else:cfn=num
  elif line.startswith('calls='):
   pending=True;count=int(line[6:].split()[0]);calls[(fn,cfn)]+=count
  elif re.match(r'^[+*\-\d]',line):
   p=line.split()
   if len(p)==2:
    cost=int(p[1]);
    if pending:edges[(fn,cfn)]+=cost;pending=False
    else:selfcost[fn]+=cost
 inc=selfcost.copy()
 for (f,c),cost in edges.items():inc[f]+=cost
 byname={}
 for n,name in names.items():
  if n in selfcost or n in inc:
   v=byname.setdefault(name,{'self':0,'inclusive':0});v['self']+=selfcost[n];v['inclusive']+=inc[n]
 edgenames=[{'caller':names.get(f,f),'callee':names.get(c,c),'ir':cost,'calls':calls[f,c]} for (f,c),cost in edges.items()]
 return {'total':sum(selfcost.values()),'functions':byname,'edges':sorted(edgenames,key=lambda r:-r['ir'])}
if __name__=='__main__':
 all={}
 for d in out.iterdir():
  if (d/'complete').exists():
   r=parse(d/'callgrind.out');all[d.name]=r
   print(d.name,r['total'])
   for n,v in r['functions'].items():
    if any(x in n for x in ('Game::checkSum','::hashState','Pipeline::submit(SimulationSnapshot','Pipeline::collect(unsigned','routineMapChecksums')) and 'lambda' not in n:print(' ',v,n[:120])
 (out/'callgraph-summary.json').write_text(json.dumps(all,indent=2))
