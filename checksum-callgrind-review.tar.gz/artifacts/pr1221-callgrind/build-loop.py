import json,subprocess,concurrent.futures
from pathlib import Path
out=Path(__file__).resolve().parent

def build(v):
 old=out/v;d=out/(v+'-split');d.mkdir(exist_ok=True);x=json.loads((old/'commands.json').read_text())
 source=(old/'Headless.cpp').read_text().replace('engine.finishSession();','CALLGRIND_DUMP_STATS_AT("tick loop"); engine.finishSession();')
 (d/'Headless.cpp').write_text(source)
 a=x['compile'][0].copy();a[a.index('-o')+1]=str(d/'Headless.o');a[a.index(str(old/'Headless.cpp'))]=str(d/'Headless.cpp')
 with (d/'build.log').open('w') as f:subprocess.run(a,cwd=x['source'],stdout=f,stderr=subprocess.STDOUT,check=True)
 a=x['link'].copy();a[a.index('-o')+1]=str(d/'glob2');a[a.index(str(old/'Headless.o'))]=str(d/'Headless.o')
 with (d/'link.log').open('w') as f:subprocess.run(a,cwd=x['source'],stdout=f,stderr=subprocess.STDOUT,check=True)
 print(v,'split ready',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:list(p.map(build,['master','before','current']))
