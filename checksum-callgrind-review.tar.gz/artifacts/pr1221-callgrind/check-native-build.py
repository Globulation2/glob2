import json,subprocess,concurrent.futures
from pathlib import Path
out=Path(__file__).resolve().parent;d=out/'before';x=json.loads((d/'commands.json').read_text());replace={}
def build(a):
 a=a.copy();old=a[a.index('-o')+1];new=old.replace('.o','-native.o');a[a.index('-o')+1]=new;a=[v for v in a if v!='-g1'];a.append('-s')
 with Path(new+'.log').open('w') as f:subprocess.run(a,cwd=x['source'],stdout=f,stderr=subprocess.STDOUT,check=True)
 return old,new
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:replace.update(p.map(build,x['compile'][1:]))
a=x['link'].copy();a[a.index('-o')+1]=str(d/'glob2-native-plain');a.append('-s');a=[replace.get(v,v) for v in a]
for i,v in enumerate(a):
 if v.endswith('/before/Headless.o'):a[i]='/home/bradley/.codex/worktrees/10767f6f-cc33-44ac-bfe3-1afdc8bca482/glob2/build/linux/client/release/dev-linker-auto/client-full-direct-1111/src/app/cli/Headless.o'
with (d/'native-plain-link.log').open('w') as f:subprocess.run(a,cwd=x['source'],stdout=f,stderr=subprocess.STDOUT,check=True)
(d/'native-plain-link.json').write_text(json.dumps(a,indent=2))
import hashlib
checks={}
for old,new in replace.items():
 vals=[]
 for src in (old,new):
  tmp=Path(src+'.text');subprocess.run(['objcopy','--dump-section','.text='+str(tmp),src],check=True);vals.append(hashlib.sha256(tmp.read_bytes()).hexdigest());tmp.unlink()
 checks[Path(old).name]={'with_g1_text_sha256':vals[0],'plain_text_sha256':vals[1],'same':vals[0]==vals[1]}
(d/'native-text-comparison.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2),flush=True)
