import os,json,subprocess,time,math,statistics,hashlib
from pathlib import Path
root=Path.cwd();out=root/'artifacts/pr1221-callgrind';dest=out/'native-three';dest.mkdir(exist_ok=True)
bins={'master':Path('/tmp/glob2-pr1221-base/build/linux/client/release/dev-linker-auto/client-full-direct-1111/src/glob2'),'before':out/'before/glob2-native','current':Path('/home/bradley/.codex/worktrees/10767f6f-cc33-44ac-bfe3-1afdc8bca482/glob2/build/linux/client/release/dev-linker-auto/client-full-direct-1111/src/glob2')}
env=os.environ.copy();env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
versions=list(bins);rows=[]
(dest/'binaries.json').write_text(json.dumps({k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in bins.items()},indent=2))
for repeat in range(12):
 order=versions[repeat%3:]+versions[:repeat%3]
 if repeat%2:order=order[::-1]
 for participants in (1,4):
  for version in order:
   d=dest/f'p{repeat}-w{participants}-{version}';d.mkdir(exist_ok=True)
   args=['taskset','-c','9-15,25-31',str(bins[version]),'game','run','--load-game',str(root/'games/gd-small-2ai.game.gz'),'--ticks','4096','--benchmark-warmup','512','--compute-threads',str(participants),'--output-dir',str(d)]
   (d/'command.json').write_text(json.dumps(args,indent=2))
   with (d/'run.log').open('w') as f:subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
   r=json.loads((d/'result.json').read_text());rows.append({'repeat':repeat,'participants':participants,'version':version,'cpu':r['benchmark_run_cpu_ns']/r['benchmark_measured_ticks'],'wall':r['run_ns']/4096,'p95':r['tick_p95_ns'],'p99':r['tick_p99_ns']})
   print(repeat,participants,version,round(rows[-1]['cpu']/1000,2),flush=True)
   (dest/'measurements.json').write_text(json.dumps(rows,indent=2))
summary=[]
for n in (1,4):
 for av,bv in [('master','before'),('master','current'),('before','current')]:
  d={'participants':n,'baseline':av,'candidate':bv,'metrics':{}}
  for m in ('cpu','wall','p95','p99'):
   ratios=[]
   for p in range(12):
    v={r['version']:r[m] for r in rows if r['participants']==n and r['repeat']==p};ratios.append(math.log(v[bv]/v[av]))
   mu=statistics.mean(ratios);ci=2.201*statistics.stdev(ratios)/math.sqrt(12)
   d['metrics'][m]={'paired_percent':100*math.expm1(mu),'t95_percent':[100*math.expm1(mu-ci),100*math.expm1(mu+ci)]}
  summary.append(d)
(dest/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2),flush=True)
