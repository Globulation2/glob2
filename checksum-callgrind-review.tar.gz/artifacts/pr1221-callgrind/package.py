import tarfile,hashlib,json,platform
from pathlib import Path
root=Path.cwd();source=root/'artifacts/pr1221-callgrind';dest=Path('/tmp/glob2-pr1221-review-evidence')
archive=dest/'checksum-callgrind-review.tar.gz'
files=[]
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in sorted(source.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  if p.name.startswith('glob2') or p.suffix=='.o' or p.name.endswith('.o.log'):continue
  tar.add(p,arcname=str(p.relative_to(root)));files.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 for rel in ['games/gd-small-2ai.game.gz','games/gd-large-4ai.game.gz']:
  p=root/rel;tar.add(p,arcname=rel);files.append({'path':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(dest/'checksum-callgrind-report.txt').write_text((source/'REPORT.txt').read_text())
(dest/'checksum-callgrind-inventory.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files,'tested_sources':json.loads((source/'inventory.json').read_text())},indent=2)+'\n')
p=dest/'README.md';s=p.read_text();s=s.replace('**Decision: keep the PR in draft. The measured results do not justify accepting reduced routine checksum coverage for production.**','**Updated assessment:** hashing remains cheaper than master and the review fixes do not increase its instruction count. The earlier CPU table did not establish a regression caused by those fixes. Keep the PR in draft while the separate coverage decision remains unresolved.')
s=s.replace('- [Final assessment and complete performance table](final-review-report.txt)', '- [Three-version Callgrind investigation and correction](checksum-callgrind-report.txt)\n- [Download raw profiles, commands, copied drivers, 72 fresh native runs and controls](checksum-callgrind-review.tar.gz)\n- [Profile evidence inventory and hashes](checksum-callgrind-inventory.json)\n- [Earlier final assessment and complete performance table](final-review-report.txt)')
s=s.split('\nThe follow-up compares master')[0]
s+='''\nThe follow-up compares master `486a2230`, pre-fix `9449c5a`, and current `f47d5eb`. Strict interior serial windows show 30–49% fewer hashing instructions than master, with identical before/current hash counts. Whole-engine instructions decrease 0.19–0.58% versus master and differ by less than 0.03% before/current. Snapshot/executor/result handoff and terminal observations account for additional work outside the hash body; these predate the review fixes. Worker Callgrind counts are not native cycles.\n\nA separate fresh 12-triplet small-workload timing cohort (72 processes) did not reproduce the earlier +8.19% current/master four-participant CPU result: it measured −0.88% [−8.13%, +6.95%]. Current/pre-fix was −11.79% [−18.06%, −5.03%] in this cohort; this does not isolate the cached getter as the cause of that timing difference. The older runs remain above as historical evidence, not proof that hashing or the fixes regressed. No universal throughput improvement is established. See the new report for reconstruction details, symbol-build controls, intervals and limits. No production source changed during this investigation.\n'''
p.write_text(s)
paths=sorted(p for p in dest.iterdir() if p.is_file() and p.name not in ('SHA256SUMS','.git'))
(dest/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in paths))
print(archive,archive.stat().st_size,'bytes;',len(files),'files')
