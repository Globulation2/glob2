import json,importlib.util,re
from pathlib import Path
out=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cg',out/'summarize.py');cg=importlib.util.module_from_spec(spec);spec.loader.exec_module(cg)
all={};table=[]
for d in out.iterdir():
 if (d/'complete').exists():
  for f in d.glob('callgrind.out*'):
   r=cg.parse(f);assert sum(v['self'] for v in r['functions'].values())==r['total'],str(f)
   all[str(f.relative_to(out))]=r
for scenario in ('small-early','small-late','large-late'):
 for phase in ('','steady-'):
  d={'window':scenario,'phase':'interior' if phase else 'warmup through shutdown','versions':{}}
  for version in ('master','before','current'):
   path=f'{phase}{scenario}-w1-{version}/callgrind.out'
   if path not in all:break
   r=all[path];needle='Game::checkSum(' if version=='master' else '::hashState('
   v=[v['inclusive'] for n,v in r['functions'].items() if needle in n];assert len(v)==1,(path,v)
   d['versions'][version]={'engine_ir':r['total'],'hash_ir':v[0]}
  if len(d['versions'])==3:
   a=d['versions']['master'];b=d['versions']['before'];c=d['versions']['current']
   d['hash_percent_current_vs_master']=100*(c['hash_ir']/a['hash_ir']-1)
   d['hash_same_before_current']=b['hash_ir']==c['hash_ir']
   d['engine_percent_current_vs_master']=100*(c['engine_ir']/a['engine_ir']-1)
   d['engine_percent_current_vs_before']=100*(c['engine_ir']/b['engine_ir']-1)
   table.append(d)
(out/'profiles-parsed.json').write_text(json.dumps(all,indent=2))
(out/'profile-comparison.json').write_text(json.dumps(table,indent=2))
for r in table:print(r['window'],r['phase'],r['versions'],'hash',round(r['hash_percent_current_vs_master'],2),'engine',round(r['engine_percent_current_vs_master'],3),'fix',round(r['engine_percent_current_vs_before'],3))
