import json, shlex, subprocess, re, concurrent.futures
from pathlib import Path
ROOT=Path.cwd(); OUT=ROOT/'artifacts/pr1221-callgrind'
CAND=Path('/home/bradley/.codex/worktrees/10767f6f-cc33-44ac-bfe3-1afdc8bca482/glob2')
BASE=Path('/tmp/glob2-pr1221-base'); BEFORE=Path('/tmp/glob2-pr1221-review')
for name,tree,buildtree,dbfile,logfile in [('master',BASE,BASE,'base-compile_commands.json','build-base-release.log'),('before',BEFORE,CAND,'candidate-compile_commands.json','build-release-final.log'),('current',CAND,CAND,'candidate-compile_commands.json','build-release-final.log')]:
 out=OUT/name;out.mkdir(exist_ok=True)
 db=json.loads((ROOT/'artifacts/pr1221-final'/dbfile).read_text())
 entries={e['file']:e for e in db}
 files=['src/app/cli/Headless.cpp']
 if name=='before': files+=['src/engine/EngineInit.cpp','src/engine/EngineRun.cpp','src/online/SimVersion.cpp']
 # Retain optimized line information for attribution without altering the production tree.
 files+=['src/engine/sim/snapshot/SnapshotChecksum.cpp'] if name!='master' else []
 replacements={}
 jobs=[]
 for src in files:
  entry=entries[src]; args=shlex.split(entry['command'])[1:]
  # compile_commands stores escaped quote characters intended for a shell.
  args=[a.replace('\\"','"') for a in args]
  original_output=entry['output']; output=out/(Path(src).stem+'.o')
  args[args.index('-o')+1]=str(output)
  args=[a for a in args if a!='-s'];args+=['-g1']
  # Resolve generated build includes against the original build tree.
  args=[('-I'+str(buildtree/a[2:])) if a.startswith('-Ibuild/') else a for a in args]
  if src.endswith('Headless.cpp'):
   text=(tree/src).read_text();text='#include <valgrind/callgrind.h>\n'+text
   text=text.replace('if(benchmarkWarmup==0) measureStart=processCpuNs();','if(benchmarkWarmup==0) { measureStart=processCpuNs(); CALLGRIND_START_INSTRUMENTATION; }')
   text=text.replace('if(!measureStart && engine.gui.game.stepCounter>=start) measureStart=processCpuNs();','if(!measureStart && engine.gui.game.stepCounter>=start) { measureStart=processCpuNs(); CALLGRIND_START_INSTRUMENTATION; }')
   text=text.replace('runCpu=processCpuNs()-measureStart;','runCpu=processCpuNs()-measureStart; CALLGRIND_STOP_INSTRUMENTATION;')
   source=out/'Headless.cpp';source.write_text(text);args[args.index(src)]=str(source)
  jobs.append((args,tree,out/(Path(src).stem+'.build.log')))
  replacements[original_output]=str(output)
 def compile(job):
  args,cwd,log=job
  with log.open('w') as f: subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,check=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(compile,jobs))
 lines=(ROOT/'artifacts/pr1221-final'/logfile).read_text().splitlines()
 link=next(line for line in reversed(lines) if line.startswith('g++ -o ') and '/src/glob2 ' in line)
 args=shlex.split(link);args[args.index('-o')+1]=str(out/'glob2');args=[a for a in args if a!='-s']
 args=[replacements.get(a,str(buildtree/a) if a.startswith('build/') else a) for a in args]
 (out/'commands.json').write_text(json.dumps({'compile':[j[0] for j in jobs],'link':args,'source':str(tree),'build_inputs':str(buildtree)},indent=2))
 with (out/'link.log').open('w') as f:subprocess.run(args,cwd=tree,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(name,'ready',flush=True)
