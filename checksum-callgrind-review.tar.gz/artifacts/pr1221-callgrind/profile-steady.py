import json,os,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'artifacts/pr1221-callgrind'
env=os.environ.copy();env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
# Equal world-state windows; serial isolates algorithm cost from scheduling.
scenarios=[('small-early','games/gd-small-2ai.game.gz',512,128),('small-late','games/gd-small-2ai.game.gz',3072,128),('large-late','games/gd-large-4ai.game.gz',3072,64)]
for scenario,save,warmup,measured in scenarios:
 for participants in (1,):
  for version in ('master','before','current'):
   d=out/f'steady-{scenario}-w{participants}-{version}';d.mkdir(exist_ok=True)
   if (d/'complete').exists():continue
   args=['taskset','-c','9-15,25-31','valgrind','--tool=callgrind','--instr-atstart=no','--fair-sched=yes','--callgrind-out-file='+str(d/'callgrind.out'),'--log-file='+str(d/'valgrind.log'),str(out/(version+'-steady')/'glob2'),'game','run','--load-game',str(root/save),'--ticks',str(warmup+192),'--benchmark-warmup',str(warmup),'--compute-threads',str(participants),'--output-dir',str(d)]
   (d/'command.json').write_text(json.dumps({'argv':args,'cwd':str(root),'window':[warmup,warmup+128], 'normal_run_end':warmup+192},indent=2))
   print('START',scenario,participants,version,flush=True);started=time.monotonic()
   with (d/'run.log').open('w') as f:subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
   for inclusive in ('no','yes'):
    with (d/f'annotate-{inclusive}.txt').open('w') as f:subprocess.run(['callgrind_annotate','--inclusive='+inclusive,'--threshold=99.9','--auto=no',str(d/'callgrind.out')],stdout=f,check=True)
   (d/'complete').write_text(str(time.monotonic()-started))
   print('DONE',round(time.monotonic()-started,1),flush=True)
