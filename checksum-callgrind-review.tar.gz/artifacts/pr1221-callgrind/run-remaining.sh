#!/bin/bash
set -e
while pgrep -f '^python3 artifacts/pr1221-callgrind/profile.py$' >/dev/null; do sleep 1; done
python3 artifacts/pr1221-callgrind/profile-split.py > artifacts/pr1221-callgrind/profile-split.log 2>&1
python3 artifacts/pr1221-callgrind/native-three.py > artifacts/pr1221-callgrind/native-three.log 2>&1
