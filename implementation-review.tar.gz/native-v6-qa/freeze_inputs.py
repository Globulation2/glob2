"""Execute only after root clean final commit, review proof, and authorization. No binary execution."""
from pathlib import Path
import json,subprocess,sys,hashlib,importlib.util
from run_phase import R,B,write,sha
assert len(sys.argv)==4 and sys.argv[1]=='--freeze','--freeze REVISION REVIEW_PROOF_PATH'
rev=sys.argv[2];proof=Path(sys.argv[3]).resolve();assert proof.is_file()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==rev
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
subprocess.run([sys.executable,str(Path(__file__).with_name('prepare.py'))],check=True,cwd=R)
plan=json.loads((B/'native-captures/v6-final/candidate-font-delta-plan.json').read_text());kit=B/'kit-v5'
for candidate,live in [('texts.bg.txt','data/texts.bg.txt'),('bg.json','platform/packages/i18n/locales/bg.json')]:assert (kit/'drafts/bg'/candidate).read_bytes()==(R/live).read_bytes()
s=importlib.util.spec_from_file_location('p',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
native,errors=p.CHECKER.read_table(kit/'drafts/bg/texts.bg.txt');assert not errors;online=json.loads((kit/'drafts/bg/bg.json').read_text());delta={'native':{},'online':{}}
for e in plan['changed']:
 cat=delta[e['surface']]
 if e['branch']:cat.setdefault(e['key'],{})[e['branch']]=e['target']
 else:cat[e['key']]=e['target']
meta=dict(json.loads((B/'kit-v4/render-input/bg/metadata.json').read_text()),source_revision=rev,candidate_revision=rev,compiled_runtime_revision=rev,source_sha256=plan['candidate_source_sha256'],original_catalog_sha256=plan['candidate_catalog_raw_sha256'],review_proof_sha256=sha(proof),runtime_identity_note='Final candidate inputs; actual executable SHA and compiled identity required separately. Earlier producer evidence remains explicitly attributed.')
meta['rendering_code_sha256']={path:sha(R/path)for path in meta.get('rendering_code_sha256',{})if (R/path).is_file()}
for base,cats,scope in [(kit,{'native':native,'online':online},'Full final catalogs'),(B/'v6-font-supplement-input',delta,'Source or target values changed since8db; historical exact unchanged values have separate producer proof'),(B/'v6-probe-input',{'native':{'[settings]':'ѝ Ѝ ѝ Ѝ — „Български език“; «цитат», … ! ?'},'online':{}},'Synthetic font diagnostic, not translated catalog')]:
 out=base/'render-input/bg';out.mkdir(parents=True,exist_ok=True)
 for surf,cat in cats.items():write(out/(surf+'.json'),cat)
 write(out/'metadata.json',dict(meta,scope=scope))
write(B/'v6-frozen-inputs.json',{'revision':rev,'source_sha256':meta['source_sha256'],'catalog_sha256':meta['original_catalog_sha256'],'review_proof_path':str(proof),'review_proof_sha256':sha(proof),'delta_render_values':len(plan['changed']),'unchanged_render_values':len(plan['unchanged']),'final_render_values':plan['render_values'],'scope':'Input freeze only; technical validation and explicit binary handoff pending'})
