from pathlib import Path
import json,importlib.util,hashlib
B=Path('artifacts/bulgarian');K=B/'kit-v6';L=B/'linguistics';s=importlib.util.spec_from_file_location('t','tools/localization/translation_program.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);manifest=json.loads((K/'manifest.json').read_text());snap=K/'before-semantic-edits';snap.mkdir();changes=[]
for locale,reportfile,inputfile,outfile in [('bg','v6-semantic-bg228-initial.json','bg-full-affected-batches-review-input.json','bg228-after-semantic-input.json'),('ms','v6-semantic-ms19-initial.json','ms-delta-review-input.json','ms19-after-semantic-input.json')]:
 paths=m.catalog_paths(K,locale);native,err=m.CHECKER.read_table(paths['native']);assert not err;online=json.loads(paths['online'].read_text());oldnative=dict(native);oldonline=dict(online);(snap/locale).mkdir();(snap/locale/paths['native'].name).write_bytes(paths['native'].read_bytes());(snap/locale/paths['online'].name).write_bytes(paths['online'].read_bytes());report=json.loads((L/reportfile).read_text());edits=[]
 for e in report['entries']:
  if not e.get('proposed_target'):continue
  surface,key=e['id'].split(':',1);d=native if surface=='native'else online;assert d[key]==e['target'];d[key]=e['proposed_target'];edits.append({'id':e['id'],'before':e['target'],'after':e['proposed_target']})
 if native!=oldnative:keys=(K/'source/native-keys.txt').read_text().splitlines();paths['native'].write_text(''.join(k+'\n'+native[k]+'\n'for k in keys))
 if online!=oldonline:paths['online'].write_text(json.dumps(online,ensure_ascii=False,indent=2)+'\n')
 prior=json.loads((K/inputfile).read_text());entries=[]
 for e in prior['entries']:
  surf,key=e['id'].split(':',1);entries.append({'id':e['id'],'key':key,'source':e['source'],'target':(native if surf=='native'else online)[key],'surface':surf,'locale':locale,**({'batch_id':e['batch_id']}if' batch_id'in e else{})})
 # Preserve explicit batch membership from the manifest, not stale provider hashes.
 for e in entries:
  e['batch_id']=next(b['id']for b in manifest['batches']if e['id']in b['keys'])
 hashes={kind:hashlib.sha256(p.read_bytes()).hexdigest()for kind,p in paths.items()};(K/outfile).write_text(json.dumps({'status':'Semanticproposalsintegrated; independenteditor/fullsemanticrecheck/adversarialpending','locale':locale,'source_sha256':manifest['source_sha256'],'catalog_sha256':hashes,'entries':entries,'edits':edits,'author':'/root','batch_ids':sorted(set(e['batch_id']for e in entries))},ensure_ascii=False,indent=2)+'\n');changes.append({'locale':locale,'count':len(edits),'catalog_sha256':hashes,'packet':outfile})
(K/'semantic-integration.json').write_text(json.dumps({'changes':changes,'source_sha256':manifest['source_sha256']},ensure_ascii=False,indent=2)+'\n');print(json.dumps(changes,ensure_ascii=False))
