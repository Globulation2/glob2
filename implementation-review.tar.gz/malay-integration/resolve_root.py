from pathlib import Path
import subprocess,re,json,hashlib
R=Path.cwd();B=R/'artifacts/bulgarian/malay-integration';master='ffabe1b9ef4e2a9986b1d6321c356124480b8a2d';base='bc8fb2c2bda69af14a7a6c5ed5ca1dfed7575ddb'
def raw(rev,p):return subprocess.check_output(['git','show',rev+':'+p])
def get(rev,p):return json.loads(raw(rev,p))
def hunks(s,fn):return re.sub(r'^<<<<<<< [^\n]*\n(.*?)^=======\n(.*?)^>>>>>>> [^\n]*\n',lambda m:fn(m[1],m[2]),s,flags=re.M|re.S)
def merge(h,m,b=None):
 if isinstance(h,dict)and isinstance(m,dict):
  d=dict(h)
  for k,v in m.items():d[k]=merge(d[k],v,(b or{}).get(k))if k in d else v
  return d
 if isinstance(h,list)and isinstance(m,list):return h+[v for v in m if v not in h]
 return m if h==b else h
paths=[]
for p in ['platform/packages/i18n/shared-values.json','test/translation_shared_values.json']:
 d=merge(get('HEAD',p),get(master,p),get(base,p));Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');paths.append(p)
for code in ['hi','ur','sw','nb']:
 p='data/texts.'+code+'.txt';Path(p).write_bytes(raw('HEAD',p));paths.append(p)
for p in ['data/texts.list.txt','data/texts.incomplete.txt']:
 s=hunks(Path(p).read_text(),lambda a,b:a+b);lines=s.splitlines();assert len(lines)==len(set(lines));Path(p).write_text(s);paths.append(p)
p='libgag/src/TrueTypeFont.cpp';s=hunks(Path(p).read_text(),lambda a,b:a.replace('Swahili, Bokmål and Bulgarian','Swahili, Bokmål, Bulgarian and Malay').replace('language == "bg" || language == "nb"','language == "bg" || language == "nb" || language == "ms"'));Path(p).write_text(s);paths.append(p)
p='tools/TranslationPreviewHarness.cpp';s=hunks(Path(p).read_text(),lambda a,b:a);Path(p).write_text(s);paths.append(p)
p='docs/development/ui-framework.md';s=hunks(Path(p).read_text(),lambda a,b:a);s=s.replace('The gameplay preview also captures the win-probability statistics screen and its\nmetric explanation, checking that drawing leaves the simulation checksum intact.','Each gameplay capture checks that drawing leaves the simulation checksum intact.');Path(p).write_text(s);paths.append(p)
p='platform/packages/i18n/src/index.ts';s=hunks(Path(p).read_text(),lambda a,b:a+b if "bg: ()"in a else a.replace("language === 'sw'","language === 'sw' || language === 'ms'"));Path(p).write_text(s);paths.append(p)
p='platform/packages/i18n/src/locales.ts';s=raw(master,p).decode();old=raw('HEAD',p).decode();entry=re.search(r"  \{\n    code: 'bg',.*?\n  \},",old,re.S)[0];assert "code: 'bg'"not in s;s=s.replace('] as const;',entry+'\n] as const;');Path(p).write_text(s);paths.append(p)
p='platform/packages/i18n/test/runtime.test.ts';s=hunks(Path(p).read_text(),lambda a,b:b.replace("  it('contains unique game catalog mappings including Malay'","  it('contains unique game catalog mappings including Bulgarian, Bokmål and Malay'")+"    expect(locales).toContainEqual({code: 'bg', gameCode: 'bg', name: 'Български', dir: 'ltr'});\n");Path(p).write_text(s);paths.append(p)
for p in paths:assert not re.search(r'^(<<<<<<<|=======|>>>>>>>)',Path(p).read_text(),re.M),p
catalogs=[p for p in Path('artifacts/bulgarian/merge-malay-conflicts.txt').read_text().splitlines()if p.startswith('platform/packages/i18n/locales/')];subprocess.run(['git','add','--',*paths,*catalogs],check=True);(B/'root-resolution-inputs.json').write_text(json.dumps({'head':'5f63be074ebf13afa995dda702657ae882bd817c','master':master,'resolved':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in paths+catalogs},'notes':['Catalog3waypreservesoursoldreviewedtargets;appendmasternew105','Sharedexceptionarraysunionboth;nativeHI/UR/SW/NBpreserveours24finalreviewedfills','Nativebg/ms/nb/swfontauthoredunion;harnessretainsoursstrongersettingsAPIcontexts;docsretainsalllessonmodes','LocaleScriptmatchingbgcyrl+mslatn+lazyloadboth, registryall39, dynamicuniqueness+explicitbg/nb/ms tests']},ensure_ascii=False,indent=2)+'\n');print('Rootresolved',len(paths)+len(catalogs),'files;frontend3/tooling1 remainagentowned')
