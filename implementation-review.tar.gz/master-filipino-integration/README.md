Incoming Filipino font/source evidence only.

core-font-glyph-identity.json compares actual incomingstarterTTF to b148 via existing pinnedfontTools4.66.1. BinarySHA changed57d78→466fb (+84bytes), cmapadds ONLY U+FF0B; all5174old cmapcharacter mappings retain exact compiledglyphbytes,decomposedoutlines and horizontaladvance/lsbmetrics.173Bulgarian valuecharacters are covered. Fullnative sans.ttf5701 is byteequal. This proves glyph identity, NOT renderer/kerning/raster/platform equivalence or wholecorefontbinary equality.

    /home/bradley/.local/share/glob2/development/caches/asset-encoder-runtime-assets-v1-py3.14/venv/bin/python artifacts/bulgarian/master-filipino-integration/compare_core_glyphs.py

bg-font-code-branch-identity.json proves TrueTypeFont.cpp differs only in comment and addition of language==fil to authoredDrawWidth; BGpredicate remains identical for scripts=false/true. Incoming shared UI/frontend/scale/phone/HUD changes still require justified fresh targeted runtime/producer checks. Old b148,3810,EA0 receipts retain actual identities; no cache/producer relabeling. Rootconfig remainsPENDING and desktop/phone are conditional again until incoming-source refresh.
