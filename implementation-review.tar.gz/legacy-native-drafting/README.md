# Opt-in legacy native NMT drafting extension

`legacy-native-drafting.patch` changes only `tools/localization/translation_program.py` and its focused test. The exact reviewed executable is under `stage/tools/localization/translation_program.py`; the copied checker and tutorials make `__file__`/ROOT imports truthful for tests and are excluded from the patch. Root supplies the frozen source-stage-v3 native/online source files before preparing a real kit. This task made no paid call or live/catalog edit.

The original `LOCALES` tuple and default prepare scope are unchanged. `LEGACY_NATIVE_LOCALES` explicitly adds 35 registered native language scopes. Their canonical Intl/manifest tags are preserved in folders, review records and online draft names; native filenames use the explicit alias table. In particular cs→cz, da→dk, el→gr, sl→si, sr-Cyrl→sr, zh-Hans→zh-cn, zh-Hant→zh-tw and pt-PT→pt. Native filename aliases are not accepted as substitute canonical manifest tags.

Machine drafting accepts only `NMT_TARGETS`: those 35 legacy canonical scopes plus bg. API targets sr, zh-CN, zh-TW and pt-PT are explicit. Root verified the official NMT table at <https://docs.cloud.google.com/translate/docs/languages#nmt> and selected European Portuguese from the current native corpus. Unreviewed scripts such as pa-Arab fail before authentication or HTTP. No prefix fallback guesses a script. Other draft-only locales remain supported for ordinary prepare/check/review commands.

The original bg payload and cache identities are unchanged. All locales in one kit share its durable conservative spend ledger and cap; reservations still precede every request/retry and ambiguous failures remain charged. Protection, raw evidence, source/target/model request caching and blank-only reviewed-work resumability are unchanged. Existing prepared kits retain their immutable locale scope, so prepare a new explicitly scoped kit when adding languages and preserve root's shared cumulative budget evidence.

From a truthful frozen source shadow, root can prepare with the canonical tags in `legacy-locales.json` and run the existing CLI for each chosen locale:

```
python3 tools/localization/translation_program.py prepare --output KIT --locales cs pt-PT sr-Cyrl
python3 tools/localization/translation_program.py machine-draft --output KIT --locale cs --project bradley-personal-20261027 --only-keys NEW_KEYS.json --max-cost-usd 10
```

`new-native-entry-ids.json` contains the 18 approved native IDs only. Do not omit that selection when drafting compatibility additions to an otherwise blank kit. Paid execution, cumulative-ledger continuity, review and final catalog integration belong to root.

Validation: 44 mocked tests pass, including all previous authentication/protection/order/cache/resume/malformed/budget tests and new alias/target/unsupported-script/shared-ledger cases. An actual Intl.PluralRules support check covers all 36 canonical mapped locales; no provider was contacted. Exact file/patch/log hashes and full target map are in `patch-manifest.json`.
