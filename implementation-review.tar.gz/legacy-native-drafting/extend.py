from pathlib import Path
B=Path('artifacts/bulgarian/legacy-native-drafting');S=B/'stage';p=S/'tools/localization/translation_program.py';t=p.read_text();needle="SOURCE_PATHS = ("
block='''# Existing registered native languages are opt-in compatibility drafting scopes.
# LOCALES and prepare()'s default retain the original translation-program scope.
LEGACY_NATIVE_LOCALES = (
    'ar', 'br', 'ca', 'cs', 'da', 'de', 'eo', 'es', 'eu', 'fa', 'fi', 'fr',
    'el', 'hi', 'hu', 'id', 'it', 'ja', 'ko', 'nl', 'pl', 'pt-PT', 'ro', 'ru',
    'sl', 'sk', 'sr-Cyrl', 'sv', 'sw', 'tr', 'uk', 'ur', 'vi', 'zh-Hans', 'zh-Hant',
)
SUPPORTED_DRAFT_LOCALES = tuple(dict.fromkeys(LOCALES + LEGACY_NATIVE_LOCALES))
NATIVE_GAME_CODES = {
    'fuc-Latn': 'fuc', 'cs': 'cz', 'da': 'dk', 'el': 'gr', 'sl': 'si',
    'sr-Cyrl': 'sr', 'zh-Hans': 'zh-cn', 'zh-Hant': 'zh-tw', 'pt-PT': 'pt',
}
# Explicitly reviewed Google general/nmt targets only. Do not derive these from
# BCP-47 prefixes: a valid draft locale can still have an unsupported script.
# https://docs.cloud.google.com/translate/docs/languages#nmt
# Serbian sr is the NMT target for native Cyrillic; Chinese uses API region codes.
# Native Portuguese is European Portuguese, deliberately not the default pt.
NMT_TARGETS = {
    'bg': 'bg', 'ar': 'ar', 'br': 'br', 'ca': 'ca', 'cs': 'cs', 'da': 'da',
    'de': 'de', 'eo': 'eo', 'es': 'es', 'eu': 'eu', 'fa': 'fa', 'fi': 'fi',
    'fr': 'fr', 'el': 'el', 'hi': 'hi', 'hu': 'hu', 'id': 'id', 'it': 'it',
    'ja': 'ja', 'ko': 'ko', 'nl': 'nl', 'pl': 'pl', 'pt-PT': 'pt-PT',
    'ro': 'ro', 'ru': 'ru', 'sl': 'sl', 'sk': 'sk', 'sr-Cyrl': 'sr',
    'sv': 'sv', 'sw': 'sw', 'tr': 'tr', 'uk': 'uk', 'ur': 'ur', 'vi': 'vi',
    'zh-Hans': 'zh-CN', 'zh-Hant': 'zh-TW',
}
'''
assert needle in t;t=t.replace(needle,block+needle,1).replace("return 'fuc' if locale == 'fuc-Latn' else locale.lower()", "return NATIVE_GAME_CODES.get(locale, locale.lower())")
t=t.replace("set(locales) - set(LOCALES)","set(locales) - set(SUPPORTED_DRAFT_LOCALES)")
t=t.replace("if locale != 'bg':\n        raise ValueError('machine-draft currently supports only bg')", "if locale not in NMT_TARGETS:\n        raise ValueError('No reviewed Google NMT target for locale: ' + str(locale))")
t=t.replace("'targetLanguageCode': locale,", "'targetLanguageCode': NMT_TARGETS[locale],")
t=t.replace("parser.add_argument('--locale', choices=LOCALES)","parser.add_argument('--locale', choices=SUPPORTED_DRAFT_LOCALES)")
t=t.replace("parser.add_argument('--locales', nargs='+', choices=LOCALES,", "parser.add_argument('--locales', nargs='+', choices=SUPPORTED_DRAFT_LOCALES,")
p.write_text(t)
