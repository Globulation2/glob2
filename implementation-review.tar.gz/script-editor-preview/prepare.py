from pathlib import Path
import difflib,hashlib,json
root=Path.cwd();out=root/'artifacts/bulgarian/script-editor-preview';src=root/'tools/TranslationPreviewHarness.cpp';original=src.read_text();s=original
s=s.replace('    static void showEditorTerrain(MapEdit &editor)', '''    static ScriptEditorScreen &openScriptEditor(MapEdit &editor) {
        editor.performAction("open scenario editor");
        return *editor.scriptEditor;
    }
    static void closeScriptEditor(MapEdit &editor) { editor.performAction("close scenario editor"); }
    static void showEditorTerrain(MapEdit &editor)''')
s=s.replace('void editorPreview(const fs::path &root, const fs::path &pilot, const fs::path &output,\n                   int width, int height)', 'void editorPreview(const fs::path &root, const fs::path &pilot, const fs::path &output,\n                   int width, int height, bool scriptEditorMode = false)')
s=s.replace('{{"kind", "production-editor-draft-overlay"}, {"pilot", pilot.string()},','{{"kind", scriptEditorMode ? "production-script-editor-draft-overlay" : "production-editor-draft-overlay"}, {"pilot", pilot.string()},')
start=s.index('        capture("editor");',s.index('void editorPreview('));end=s.index('\n    globalContainer = nullptr;',start)
s=s[:start]+'''        if (scriptEditorMode) {
            const auto beforeEditing = editor.game.checkSum();
            auto &script = TranslationPreviewAccess::openScriptEditor(editor);
            require(editor.activeDialog() == &script, "Production scenario editor is the active dialog");
            script.selectLanguage(ScriptEditorScreen::Language::JavaScript);
            const std::string valid = "// Translation preview: local validation only.\\nfunction step(ctx) {\\n  return [];\\n}\\n";
            script.setScriptText(valid);
            capture("script-editor-cursor");
            auto recordStatus = [&](const std::string &name, bool expectedResult) {
                const auto *cursor = script.host().find("script/cursor");
                require(cursor != nullptr, "Production localized script cursor exists");
                const auto r = cursor->bounds;
                result["script_states"].push_back({{"name", name}, {"compile_result", expectedResult},
                    {"compilation_text", script.compilationText()}, {"cursor_text", cursor->accessibleText()},
                    {"cursor_bounds", {{"x", r.x}, {"y", r.y}, {"width", r.w}, {"height", r.h}}},
                    {"source_sha256", Online::Sha256::toHex(Online::Sha256::digest(script.scriptText()))}});
            };
            result["script_states"] = Json::array();
            const bool success = script.compile();
            require(success, "Production JavaScript validation accepts the controlled valid script");
            require(!script.compilationText().empty(), "Production compile success has a visible status");
            capture("script-editor-success");
            recordStatus("success", success);
            script.setScriptText("function step( {\\n");
            const bool failure = script.compile();
            require(!failure, "Production JavaScript validation rejects the controlled syntax error");
            require(!script.compilationText().empty(), "Production compile failure has a visible status");
            capture("script-editor-failure");
            recordStatus("failure", failure);
            TranslationPreviewAccess::closeScriptEditor(editor);
            require(beforeEditing == editor.game.checkSum(), "Validation and closing without confirmation preserve map state");
            result["limits"].push_back("Script source is controlled harness input; compile validates through the production compiler, never confirms or saves the scenario.");
        } else {
            capture("editor");
            const auto beforeNavigation = editor.game.checkSum();
            TranslationPreviewAccess::showEditorTerrain(editor);
            capture("editor-terrain");
            TranslationPreviewAccess::openEditorMenu(editor);
            require(editor.hasDialog(), "Production editor menu opened");
            capture("editor-dialog");
            TranslationPreviewAccess::closeEditorMenu(editor);
            require(beforeNavigation == editor.game.checkSum(), "Editor UI navigation must preserve simulation checksum");
        }
    }
    writeJson(output / (scriptEditorMode ? "script-editor.json" : "editor.json"), result);'''+s[end:]
# Use the already-established streaming SHA API, rather than assuming a digest overload.
s=s.replace('Online::Sha256::toHex(Online::Sha256::digest(script.scriptText()))','[&] { Online::Sha256 hash; hash.update(script.scriptText().data(), script.scriptText().size()); return Online::Sha256::toHex(hash.finish()); }()')
s=s.replace(' | editor ROOT DRAFT OUTPUT W H | game', ' | editor|script-editor ROOT DRAFT OUTPUT W H | game')
s=s.replace('else if (mode == "editor") {\n            require(argc == 7, "Editor mode takes ROOT DRAFT OUTPUT W H");\n            editorPreview(root, pilot, output, width, height);','else if (mode == "editor" || mode == "script-editor") {\n            require(argc == 7, "Editor modes take ROOT DRAFT OUTPUT W H");\n            editorPreview(root, pilot, output, width, height, mode == "script-editor");')
(out/'TranslationPreviewHarness.cpp').write_text(s);patch=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/tools/TranslationPreviewHarness.cpp',tofile='b/tools/TranslationPreviewHarness.cpp'));(out/'script-editor-preview.patch').write_text(patch)
(out/'identity.json').write_text(json.dumps({'source_file':str(src.relative_to(root)),'base_sha256':hashlib.sha256(original.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'status':'Staged harness-only source, not compiled or captured yet.','owner':'/root/compat_editor'},indent=2)+'\n')
