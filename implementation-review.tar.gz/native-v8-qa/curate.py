from pathlib import Path
import json,hashlib,gzip,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';O=B/'native-captures/v8-final';Q=B/'native-v8-qa';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
index=json.loads((O/'all-completed-ui-image-index.json').read_text());assert index['counts']=={'jobs':35,'images':79}
receipts=[*sorted(O.glob('surfaces-wrapper-corrected-shard-*/execution.json')),O/'schools/execution.json',O/'api/execution.json'];checks=[];identities=[];paths=set()
for receipt in receipts:
 d=json.loads(receipt.read_text());paths.add(receipt)
 for job in d['jobs']:
  assert job['returncode']==0;folder=receipt.parent/job['tag']
  for p in folder.glob('*.json'):
   paths.add(p);data=json.loads(p.read_text())
   identity=data.get('evidence_identity')
   if identity:
    assert identity['executable_sha256']=='3bac3d4cd4f45d2af331721f3586745571d8eea885ee51d1dcbb675c8e0f62b6';assert identity['producer']['revision']=='bd2ca9ca28173f0155754656e0da36eacf7ffac3';identities.append({'path':str(p.relative_to(R)),'sdl':identity.get('sdl_version'),'ttf':identity.get('sdl_ttf_version'),'harfbuzz':identity.get('harfbuzz_version'),'sdl_path':identity.get('sdl_library_path'),'ttf_path':identity.get('sdl_ttf_library_path')})
   for capture in data.get('captures',[]):
    if 'checksum_before_draw'in capture:
     assert capture['checksum_before_draw']==capture['checksum_after_draw'];checks.append({'path':str(p.relative_to(R)),'capture':capture['name'],'checksum':capture['checksum_before_draw']})
  for p in folder.glob('capture.log'):paths.add(p)
for e in index['images']:
 p=R/e['repository_relative_path'];assert sha(p)==e['sha256'];paths.add(p)
for receipt in [O/'fonts/execution.json',O/'probes/execution.json']:
 paths.add(receipt);d=json.loads(receipt.read_text());assert all(j['returncode']==0 for j in d['jobs'])
 for job in d['jobs']:
  folder=receipt.parent/job.get('tag',job.get('presentation',''));paths.add(folder/'capture.log')
  if receipt.parent.name=='fonts':
   paths.add(folder/'font-matrix.json.gz');pages=sorted(folder.glob('*.png'));assert pages;paths.add(pages[0])
  else:
   paths.add(folder/'font-matrix.json');paths.update(folder.glob('*.png'))
plan=O/'candidate-font-delta-plan.json';packed=O/'candidate-font-delta-plan.json.gz';packed.write_bytes(gzip.compress(plan.read_bytes(),compresslevel=9,mtime=0));paths.add(packed)
for p in O.glob('*.json'):
 if p.name not in ['candidate-font-delta-plan.json','publish-selection.json']:paths.add(p)
paths.update(O.glob('*.patch'));paths.add(O/'fonts/measurement-summary.json');paths.add(O/'probes/synthetic-equivalence.json')
for folder in ['review-receipts-001','review-receipts-002','review-receipts-003','preparation-before-surface-expansion']:
 paths.update(p for p in (O/folder).glob('*')if p.is_file())
for p in Q.glob('*'):
 if p.is_file()and p.suffix in ['.json','.txt','.log','.py','.sha256']:paths.add(p)
paths.add(Q/'building-failure-gdb/run.log')
for folder in ['native-tests-v8-engine','native-tests-v8-unit']:
 for name in ['command.json','inventory.json','timings.json','junit.xml','run.log']:
  p=B/folder/name
  if p.exists():paths.add(p)
for p in sorted(O.glob('surfaces-shard-*/execution.json')):
 paths.add(p);d=json.loads(p.read_text());assert all(j['returncode']!=0 for j in d['jobs'])
 for job in d['jobs']:paths.add(p.parent/job['tag']/'capture.log')
for base in [B/'v8-full-render-input',B/'v8-font-supplement-input',B/'v8-probe-input']:
 paths.update(base.rglob('*.json'))
paths.add(B/'v8-frozen-inputs.json')
summary={'status':'Actual bd2 native capture execution complete; independent image review and engine-failure resolution are separate','revision':'bd2ca9ca28173f0155754656e0da36eacf7ffac3','source_sha256':'67ce07e9975d2737b6de64e547453a8ed3a3222acfdb99b7d5dc49646eb7f38b','catalog_sha256':index['catalog_sha256'],'preview_capture_sha256':'3bac3d4cd4f45d2af331721f3586745571d8eea885ee51d1dcbb675c8e0f62b6','captures':{'surfaces':29,'api':4,'school_briefings':2,'UI_PNGs':79,'all_returncodes_zero':True,'draw_checksum_pairs_equal':len(checks)},'font_delta':json.loads((O/'fonts/measurement-summary.json').read_text()),'synthetic_probe_pngs':{'count':12,'all_byte_equal_8db':True},'tests':{'unit':{'cases':91,'passed':91,'failed':0},'engine':{'cases':87,'passed':85,'failed':2,'failures':['GUIInteractionCoverage/Bulgarian building failure rows wrap: SIGSEGV in newly required HudControlPaint topbar because fixture teamStats pointer uninitialized; gdb reproduced','Settings/software rendering name-edit persistence: expected New player, actual bradley; parent investigating']}},'SDL_runtime_receipts':identities,'draw_checksum_receipts':checks,'attempt_history':{'initial_null_manifest_capture_jobs':3,'initial_jobs_passed':False,'preserved_original_kit_manifest':True,'wrapper_fix':'native-v8-qa/wrapper-correction-proof.json','corrected_attempts_in_separate_paths':True},'limits':['Linux SDL/Xvfb; phone presentation is a desktop emulator, not physical mobile rendering','2x font diagnostic is not certification of hardware native-window high-DPI behavior','Initial /proc runtime maps observe original failed/null-manifest capture processes and successful matrix process; successful corrected jobs separately record actual SDL/ttf paths/API versions','All6249 carried source/target values preserve historical producer identities; export-only TextLayout normalization, unchanged Bulgarian authoredDrawWidth path and12 exact synthetic pages support limited rendering-component equivalence','Only the10 PNGs in technical-visual-sample-review.json were personally opened by native_final; independent editor image review is separately recorded','Engine failures remain failures in this immutable producer report, even if later scoped test fixes pass']};(O/'native-runtime-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');paths.add(O/'native-runtime-summary.json')
for p in paths:assert p.is_file()and not any(x in ['profiles','profile','binaries','__pycache__']for x in p.parts),p
selection={'status':'Explicit completed bd2 native review evidence; independent UI review/engine failures are separate, no inferred final acceptance','producer_revision':'bd2ca9ca28173f0155754656e0da36eacf7ffac3','paths':sorted(str(p.relative_to(R))for p in paths),'file_count':len(paths),'bytes':sum(p.stat().st_size for p in paths),'coverage':{'UI_PNGs':79,'font_delta_first_pages':12,'synthetic_probe_PNGs':12,'profiles_or_ELFs_included':False},'note':'Complete compressed font diagnostics included; selected first pages are bounded examples, not a claim that every page was visually read. All failed attempts/tests and their actual identities remain explicit.'};(O/'publish-selection.json').write_text(json.dumps(selection,indent=2)+'\n');print('Curated',len(paths),'files',round(selection['bytes']/1024/1024,2),'MiB; equal draw checksum pairs',len(checks),'success identities',len(identities))
