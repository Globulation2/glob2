"""Preparation only: candidate hashes are not a freeze or execution approval."""
from pathlib import Path
import json,hashlib,subprocess,importlib.util
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';Q=B/'native-v8-qa';O=B/'native-captures/v8-final';O.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
s=importlib.util.spec_from_file_location('p',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
kit=B/'kit-v7';old=B/'native-captures/producers/8db545/frozen-inputs/full'
new={'native':p.CHECKER.read_table(kit/'drafts/bg/texts.bg.txt')[0],'online':json.loads((kit/'drafts/bg/bg.json').read_text())};before={a:json.loads((old/(a+'.json')).read_text())for a in new}
# Preserve original source inputs, rather than treating equal targets as equal meaning.
oldsrc={};newsrc={}
for surf,file in [('native','data/texts.en.txt'),('online','platform/packages/i18n/locales/en.json')]:
 raw=subprocess.check_output(['git','show','8db545e53d664af3bd4abcdec7cc29f5dc2dadf3:'+file],cwd=R)
 if surf=='native':
  f=Q/'8db-English-native.txt';f.write_bytes(raw);oldsrc[surf]=p.CHECKER.read_table(f)[0]
 else:oldsrc[surf]=json.loads(raw)
 newsrc[surf]=json.loads((kit/'source'/(surf+'.json')).read_text())
def flat(values):
 for surf,cat in values.items():
  for key,v in cat.items():
   for branch,text in (v.items()if isinstance(v,dict)else[('',v)]):yield (surf,key,branch),text
oldflat=dict(flat(before));oldsource=dict(flat(oldsrc));newsource=dict(flat(newsrc));changed=[];same=[]
for identity,target in flat(new):
 source=newsource[identity];record=dict(zip(['surface','key','branch'],identity),source=source,target=target,source_sha256=sha(source.encode()),target_sha256=sha(target.encode()))
 if oldflat.get(identity)==target and oldsource.get(identity)==source:same.append(record)
 else:record.update(before=oldflat.get(identity),before_source=oldsource.get(identity));changed.append(record)
plan={'status':'PREPARATION ONLY; uncommitted candidate, no frozen acceptance, binary handoff or actual new runs','head_at_preparation':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'candidate_source_sha256':json.loads((kit/'manifest.json').read_text())['source_sha256'],'candidate_catalog_raw_sha256':{a:sha((kit/'drafts/bg'/f).read_bytes())for a,f in [('native','texts.bg.txt'),('online','bg.json')]},'keys':{a:len(c)for a,c in new.items()},'render_values':len(same)+len(changed),'unchanged_source_target_values':len(same),'changed_source_or_target_values':len(changed),'combinations':12,'expected_combined_samples':12*(len(same)+len(changed)),'fresh_samples_required':12*len(changed),'changed':changed,'unchanged':same,'serialization':'Hash decoded string UTF8 bytes without JSON quotes/newline; catalog hashes exact raw file bytes. Source AND target equality required for carry.'}
write(O/'candidate-font-delta-plan.json',plan)
previous=json.loads((B/'native-captures/v5-final/three-producer-font-plan.json').read_text());files=[]
for e in previous['font_wrapper_files']:
 f=R/e['path'];now=sha(f.read_bytes());files.append({'path':e['path'],'old_8db_sha256':e['original3881_and_final8db_sha256'],'candidate_sha256':now,'byte_identical':now==e['original3881_and_final8db_sha256']})
def block(s):return s[s.index('struct ProductionMeasurer'):s.index('template<class T> class Preview')]
a=block(subprocess.check_output(['git','show','8db545:tools/TranslationPreviewHarness.cpp'],cwd=R,text=True));b=block((R/'tools/TranslationPreviewHarness.cpp').read_text())
diff=subprocess.check_output(['git','diff','8db545','--','libgag/src/TrueTypeFont.cpp'],cwd=R,text=True);(O/'TrueTypeFont-before-candidate.patch').write_text(diff)
write(O/'candidate-component-proof.json',{'status':'Candidate source comparison only, not final producer/runtime validation','files':files,'font_matrix_block_identical':a==b,'before_matrix_block_sha256':sha(a.encode()),'candidate_matrix_block_sha256':sha(b.encode()),'TrueTypeFont_exception':'Exact retained diff adds only nb/ms to authoredDrawWidth and updates its comment; Bulgarian predicate remains true. Exact TrueTypeFont file equality NOT claimed. TextLayout.cpp/.h public export/rename is separately proven mechanically equivalent in text-layout-export-equivalence.json; runtime probes remain pending.','runtime_pending':['Actual final executable and runtime library file hashes/API versions','All28SHF_ALLOC/program headers proof if stripping immutable copy','Fresh12 synthetic probe PNG comparisons to8db/f02/3881, no broad visual equivalence inferred','Fresh changed source/target supplement12 combinations','Fresh relevant unit/engine tests and actual UI/API captures'],'historical_library_limit':'3881 library file bytes were not hashed then; versions/paths/timestamps and synthetic sample equivalence remain limited historical evidence.'})
print({k:plan[k]for k in ['render_values','unchanged_source_target_values','changed_source_or_target_values','expected_combined_samples','fresh_samples_required']})
