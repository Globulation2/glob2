# Corrected legacy native drafting tool (v2)

This separate ignored staging copy corrects a review-found mapping bug that was never integrated: `data/texts.br.txt` declares `[language] = Português do Brasil` and `[language-code] = br`. The historical native code is Brazilian Portuguese, not ISO br/Breton. `native-br-metadata-evidence.json` binds that exact source file and metadata.

V2 uses canonical `pt-BR`, native filename `texts.br.txt`, and Google target `pt-BR`. Canonical `br` is excluded from supported prepare scope and the reviewed machine-target map and fails before authentication/HTTP. All other mappings, default LOCALES, default prepare scope and original BG request/cache behavior remain unchanged.

The original `../legacy-native-drafting` executable remains byte-for-byte immutable (SHA2567c0036ca79969accc0224004089b7e76ed1c7f7832949bde9f25448d660b1a7d); its wrong mapping and failed Breton drafts/review evidence are preserved. No failed drafts were copied into V2. Root owns creating the fresh explicitly scoped compatibility kit, carrying completed correct locale drafts exactly, maintaining the cumulative ledger and paying for the single replacement pt-BR request.

Use the reviewed executable `stage/tools/localization/translation_program.py` from this V2 directory after root supplies the truthful frozen source-stage-v3 files. Copied checker/tutorial dependencies and the actual Brazilian catalog test input remain ignored and are excluded from the two-file patch. `legacy-locales.json` lists the35 corrected canonical scopes; `new-native-entry-ids.json` contains the same18 approved IDs.

45 mocked tests pass, including actual catalog metadata, canonical pt-BR→nativebr/APIpt-BR payload/path binding, explicit br rejection before auth/HTTP, all prior shared-ledger/cap/cache/resume/protection/review checks. Actual Intl.PluralRules supports all36 mapped canonical locales. This task made no paid call and changed no live source or catalog. Exact file/patch/log hashes are in patch-manifest.json.
