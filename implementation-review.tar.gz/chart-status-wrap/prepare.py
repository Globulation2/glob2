from pathlib import Path
import difflib,json,hashlib
R=Path.cwd();O=R/'artifacts/bulgarian/chart-status-wrap';path=R/'src/team/stats/TeamStatChart.cpp';old=path.read_text();new=old.replace('#include <Toolkit.h>','#include <Toolkit.h>\n#include <ui/TextLayout.h>',1)
anchor='\t//! `text` cut to fit `available` pixels.'
method='''    // Empty-state notices share the chart's real font and shaping boundaries.
    // Keep the complete notice readable inside compact statistics charts.
    void drawNotice(int x, int y, int availableWidth, int availableHeight,
                    const std::string &notice, const Color &color) const
    {
        struct Measurer : GAGGUI::ui::TextMeasurer {
            Font &font;
            explicit Measurer(Font &value) : font(value) {}
            int width(GAGGUI::ui::FontRole, const std::string &value) const override { return font.getStringWidth(value); }
            int lineHeight(GAGGUI::ui::FontRole) const override { return font.getStringHeight("0"); }
            std::vector<std::size_t> clusterEnds(GAGGUI::ui::FontRole, const std::string &value) const override { return font.getStringClusterEnds(value); }
        } measurer(*font);
        int offset = 0;
        for (const auto &line : GAGGUI::ui::wrapText(measurer, GAGGUI::ui::FontRole::Support,
                                                   notice, std::max(1, availableWidth))) {
            if (offset + height > availableHeight) break;
            draw(x, y + offset, line, color);
            offset += height;
        }
    }
'''
assert anchor in new;new=new.replace(anchor,method+anchor,1)
for expression in ['tr(recorded ? "[stat not recorded for this match]" : "[Not enough recorded history yet.]")','tr("[stat nothing to show]")']:
 a='text.draw(left + pad, top + pad, '+expression+', TeamStatChart::ink);';b='text.drawNotice(left + pad, top + pad, width - 2 * pad, height - 2 * pad, '+expression+', TeamStatChart::ink);';assert a in new;new=new.replace(a,b,1)
(O/'TeamStatChart.cpp').write_text(new);patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/src/team/stats/TeamStatChart.cpp',tofile='b/src/team/stats/TeamStatChart.cpp'));(O/'chart-status-wrap.patch').write_text(patch)
sha=lambda b:hashlib.sha256(b).hexdigest();(O/'proposal.json').write_text(json.dumps({'scope':'Presentation-only chart empty-state notice wrapping; no catalog/simulation changes. Staged ignored patch, not applied.','before_source_sha256':sha(old.encode()),'proposed_source_sha256':sha(new.encode()),'patch_sha256':sha(patch.encode()),'observed_before':['artifacts/bulgarian/native-captures/v4-final/surfaces/desktop-100-statistics/statistics-economy.png','artifacts/bulgarian/native-captures/v4-final/surfaces/desktop-100-statistics/statistics-world.png'],'cause':'TeamStatChart paints long no-history status as one unwrapped line within an inline chart about176px wide. Existing clip hides its ending.','change':'Use existing shared cluster-aware wrapText with the exact production chart font. Fit lines remain same text/position; long notices wrap within chart content bounds. Height remains bounded by chart; short normal empty notices fit without wrapping.','verification_plan':'Syntax-only staged source, then actual same statistics views at desktop1280 and phone390 normal/150 with corrected producer. Compare ink geometry/readable ending; preserve before producer/evidence and catalog hashes.'},indent=2)+'\n');print('Staged chart notice wrapping patch; no live changes')
