from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parents[3];b=r/'artifacts/bulgarian/native-captures/v4-final';out=[]
for phase in ['surfaces','api','fonts','probes']:
 p=b/phase/'execution.json'
 if not p.exists():continue
 try:d=json.loads(p.read_text())
 except json.JSONDecodeError:continue
 for job in d['jobs']:
  if job['returncode']!=0:continue
  name=job.get('tag',job.get('presentation'));folder=b/phase/name
  images=[{'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in sorted(folder.glob('*.png'))]
  out.append({'phase':phase,'job':name,'returncode':0,'execution':str(p),'images':images})
tmp=b/'peer-ready-index.json.tmp';tmp.write_text(json.dumps({'scope':'Completed returncode0 jobs only; exact image hashes, no conclusions.','jobs':out},indent=2)+'\n');tmp.replace(b/'peer-ready-index.json');print([(x['phase'],x['job'],len(x['images']))for x in out])
