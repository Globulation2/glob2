from pathlib import Path
import json,gzip,hashlib
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';O=B/'native-captures/v4-final';proof=json.load(open(O/'font-carryforward.json'));carry={(e['surface'],e['key'],e['branch'])for e in proof['unchanged_entries']};delta={(e['surface'],e['key'],e['branch'])for e in proof['delta_entries']};assert len(carry)==6244 and len(delta)==51 and not carry&delta
producer=json.load(open(B/'native-captures/producers/f02b75/strip-debug-proof.json'))['capture_copy_sha256'];rows=[];selection=[];allseen=set();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for view,w,h in [('desktop',1280,1024),('phone',480,960)]:
 for size in [10,13,20]:
  for scale in [1,2]:
   path=O/'fonts'/f'{view}-{size}x{scale}'/'font-matrix.json';d=json.load(open(path));assert d['evidence_identity']['producer']['revision']=='f02b75ccab66d3073f33ae865d2c8a731e546545' and d['evidence_identity']['executable_sha256']==producer
   values=d['samples'];tokens={(s['surface'],s['key'],s['branch'])for s in values};assert tokens==delta and len(values)==51
   before=B/'native-captures/font-corrected'/f'{view}-matrix-{size}-scale-{scale}'/'font-matrix.json.gz'
   with gzip.open(before,'rt')as f:old=json.load(f)
   retained=[s for s in old['samples']if(s['surface'],s['key'],s['branch'])in carry];assert len(retained)==6244
   combined=retained+values;assert len(combined)==6295
   assert all(s['size']==size and s['scale']==scale for s in combined)
   identity={(view,size,scale,s['surface'],s['key'],s['branch'])for s in combined};assert not identity&allseen;allseen|=identity
   def metrics(samples,manifest):
    return {'samples':len(samples),'missing_glyph_samples':sum(not s['has_glyphs']for s in samples),'draw_width_failures':sum(not l['drawn_fits_width']for s in samples for l in s['lines']),'draw_height_failures':sum(not l['drawn_fits_height']for s in samples for l in s['lines']),'actual_canvas_width_failures':sum(l['x']+l['drawn_width']/s['scale']>manifest['logical_width']for s in samples for l in s['lines']),'actual_canvas_height_failures':sum(l['y']+l['drawn_height']/s['scale']>manifest['logical_height']for s in samples for l in s['lines']),'raw_width_diagnostics':sum(not l['fits_width']for s in samples for l in s['lines'])}
   pages=sorted(path.parent.glob('font-*.png'));assert pages
   selection.extend(str(p.relative_to(R)) for p in pages);selection.extend([str(path.with_suffix('.json.gz').relative_to(R))])
   rows.append({'view':view,'size':size,'scale':scale,'new_delta':metrics(values,d),'retained_old_exact_inputs':metrics(retained,old),'complete_delta_diagnostics_sha256':sha(path),'complete_old_diagnostics_gzip_sha256':sha(before),'pages':len(pages),'producer':d['evidence_identity']})
assert len(allseen)==75540
summary={'scope':'Final6295 unique render values at12viewport/font combinations =75540 measurements, consisting of6244 unchanged exact source/target inputs from original3881producer plus51 freshly rendered changed/native values fromf02b producer per combination. Earlier captures are not relabeled.','new_measurements':612,'combined_measurements':len(allseen),'combinations':rows,'delta_images':len([s for s in selection if s.endswith('.png')]),'missing_glyph_samples':sum(v[k]['missing_glyph_samples']for v in rows for k in ['new_delta','retained_old_exact_inputs']),'draw_or_canvas_failures':sum(v[k][name]for v in rows for k in ['new_delta','retained_old_exact_inputs']for name in ['draw_width_failures','draw_height_failures','actual_canvas_width_failures','actual_canvas_height_failures']),'limits':'Geometry/glyph checks are complete measured diagnostics; only images explicitly listed in visual-inspection.json were visually inspected. Literal placeholders stay literal. Raw hinted-raster width diagnostics are not authored draw destination clipping.'}
(O/'font-supplement-validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(O/'font-publish-selection.json').write_text(json.dumps({'paths':selection},indent=2)+'\n')
# Contact sheets for actual visual inspection; page-level checks remain explicit.
for view in ['desktop','phone']:
 pages=[R/p for p in selection if p.endswith('.png')and f'/fonts/{view}-'in p];thumbs=[]
 for p in pages:
  im=Image.open(p).convert('RGB');im.thumbnail((390,330));tile=Image.new('RGB',(410,365),'#eee');tile.paste(im,((410-im.width)//2,8));ImageDraw.Draw(tile).text((4,342),p.parent.name+'/'+p.name,fill='black');thumbs.append(tile)
 cols=4;sheet=Image.new('RGB',(cols*410,365*((len(thumbs)+cols-1)//cols)),'white')
 for i,t in enumerate(thumbs):sheet.paste(t,((i%cols)*410,(i//cols)*365))
 sheet.save(O/(view+'-supplement-contact.png'))
print(json.dumps({k:v for k,v in summary.items() if k!='combinations'},ensure_ascii=False))
