from pathlib import Path
import json,hashlib,gzip,subprocess
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';O=B/'native-captures/v4-final';O.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def fsha(p):return sha(p.read_bytes())
def tsh(t):return sha(t.encode())
def load(p):return json.loads(p.read_text())
frozen=load(B/'v4-frozen-inputs.json');assert frozen['revision']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
oldpilot=B/'native-matrix-input-font-corrected/render-input/bg';newpilot=B/'kit-v4/render-input/bg'
values={};sources={}
for version,pilot,kit in [('old',oldpilot,B/'kit-v2'),('new',newpilot,B/'kit-v4')]:
 values[version]={};sources[version]={}
 for surface in ['native','online']:
  cat=load(pilot/(surface+'.json'));src=load(kit/'source'/(surface+'.json'))
  for key,v in cat.items():
   for branch,text in (v.items()if isinstance(v,dict)else [('',v)]):
    token=(surface,key,branch);values[version][token]=text
    rawsrc=src[key];sources[version][token]=rawsrc[branch] if isinstance(rawsrc,dict) else rawsrc
old=values['old'];new=values['new'];assert len(old)==6263 and len(new)==6295
carry=[];delta=[]
for token,t in new.items():
 surface,key,branch=token;s=sources['new'][token]
 record={'surface':surface,'key':key,'branch':branch,'key_sha256':tsh(key),'source_sha256':tsh(s),'target_sha256':tsh(t)}
 if token in old and old[token]==t and sources['old'][token]==s:carry.append(record)
 else:delta.append(record)
assert len(carry)==6244 and len(delta)==51
oldroot=B/'native-matrix-source-font-corrected';files=[]
prior=load(B/'native-captures/font-producer-carryforward-proof.json')
for e in prior['files']:
 name=e['path']
 if name=='tools/TranslationPreviewHarness.cpp' or name.startswith('data/texts.') or name.startswith('platform/'):continue
 a=oldroot/name;b=R/name
 assert a.exists()and b.exists()and a.read_bytes()==b.read_bytes(),name
 files.append({'path':name,'old_and_final_sha256':fsha(a),'comparison':'byte identical'})
def block(t):return t[t.index('struct ProductionMeasurer'):t.index('template<class T> class Preview')]
a=block((oldroot/'tools/TranslationPreviewHarness.cpp').read_text());b=block((R/'tools/TranslationPreviewHarness.cpp').read_text());assert a==b
proof={'scope':'Exact render-value and production font/wrapper carryforward from completed3881corrected matrices to finalv4; no relabeling of old executable or claim of fresh rendering unchanged entries.','old_producer_revision':'3881c64e0d2b43b460a122422d2727c0cbd4d3ca','final_candidate_revision':frozen['revision'],'unchanged_render_values':len(carry),'new_or_changed_values':len(delta),'final_render_values':6295,'old_full_samples_per_combination':6263,'retained_old_samples_per_combination':6244,'supplemental_samples_per_combination':51,'final_samples_all12combinations':75540,'replaced_old_targets':19,'source_and_target_hash_serialization':'SHA256 of raw UTF-8 decoded source/target strings; branch and surface identify plural sample.','font_and_wrapper_files':files,'harness_matrix_and_measurer_block':{'boundaries':'struct ProductionMeasurer through before template<class T> class Preview','old_and_final_sha256':tsh(a),'comparison':'byte identical; unrelated screen/editor/API modes changed elsewhere in whole harness'},'complete_old_diagnostics':[{'path':str(p.relative_to(R)),'sha256':fsha(p)}for p in sorted((B/'native-captures/font-corrected').glob('*/font-matrix.json.gz'))],'unchanged_entries':carry,'delta_entries':delta}
assert len(proof['complete_old_diagnostics'])==12
raw=(json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode();(O/'font-carryforward.json').write_bytes(raw)
with gzip.open(O/'font-carryforward.json.gz','wb',compresslevel=9)as f:f.write(raw)
print('Proof prepared:6244exact carryforward +51delta; font/measurer blocks unchanged;',len(files),'unchanged font/wrapper files')
