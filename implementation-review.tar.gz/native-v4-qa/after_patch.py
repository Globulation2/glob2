"""Run only affected actual UI + single Generated-font delta after a fresh handoff.
Usage: after_patch.py ui|generated-font BINARY --handoff REVISION
No execution until parent freezes new clean source and updates full v4 metadata.
"""
from pathlib import Path
import json,sys,subprocess,time,gzip,hashlib
from run_phase import R,B,guard,environment,write,sha
assert len(sys.argv)==5 and sys.argv[3]=='--handoff'
phase=sys.argv[1];binary=Path(sys.argv[2]).resolve();revision=sys.argv[4];guard(binary,revision)
base=B/'native-captures/v4-corrected-ui'/phase;base.mkdir(parents=True,exist_ok=True);pilot=B/'kit-v4/render-input/bg';jobs=[]
if phase=='ui':
 for view,w,h in [('desktop',1280,1024),('phone',390,844)]:
  for growth in [100,150]:
   jobs.append((f'{view}-{growth}-script-editor',view,w,h,growth,'script-editor',[]))
   jobs.append((f'{view}-{growth}-statistics',view,w,h,growth,'game',['statistics']))
  jobs.append((view+'-new-map',view,w,h,100,'screen',['new-map']))
elif phase=='generated-font':
 full=json.loads((pilot/'native.json').read_text());assert full['[Generated]']=='Генерирана'
 out=B/'v4-visual-delta-input/render-input/bg';out.mkdir(parents=True,exist_ok=True)
 write(out/'native.json',{'[Generated]':full['[Generated]']});write(out/'online.json',{})
 meta=json.loads((pilot/'metadata.json').read_text());meta['scope']='Single revised [Generated] label after actual visual review; other51delta values retained fromf02 and6243unchanged from3881.';write(out/'metadata.json',meta);pilot=out
 for view,w,h in [('desktop',1280,1024),('phone',480,960)]:
  for size in [10,13,20]:
   for scale in [1,2]:jobs.append((f'{view}-{size}x{scale}',view,w,h,100,'matrix',[str(size),str(scale)]))
else:raise SystemExit('Unknown phase')
records=[];identity={'revision':revision,'binary':str(binary),'binary_sha256':sha(binary),'scope':'Actual after-patch UI'if phase=='ui'else'Single changed label font diagnostic','jobs':records}
for tag,view,w,h,growth,mode,args in jobs:
 out=base/tag;assert not out.exists(),f'Never overwrite{out}';out.mkdir();env=environment(out/'profile',view=='phone',growth)
 cmd=[str(binary),mode,str(R),str(pilot),str(out),str(w),str(h)]+args
 if phase=='ui':cmd=['xvfb-run','-a','-s','-screen 0 1600x1400x24']+cmd
 print('START',tag,flush=True);start=time.monotonic()
 with (out/'capture.log').open('w')as log:
  try:rc=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900).returncode
  except subprocess.TimeoutExpired:rc='timeout'
 records.append({'tag':tag,'command':cmd,'returncode':rc,'seconds':round(time.monotonic()-start,2),'text_size_percent':growth});write(base/'execution.json',identity);print('END',tag,rc,flush=True)
 if rc!=0:raise SystemExit(f'Failed{tag}; evidence retained')
 if phase=='generated-font':
  p=out/'font-matrix.json';d=json.loads(p.read_text());assert len(d['samples'])==1 and d['samples'][0]['key']=='[Generated]'
  with gzip.open(out/'font-matrix.json.gz','wb',compresslevel=9)as f:f.write(p.read_bytes())
print('COMPLETE',len(records),'/',len(jobs),flush=True)
