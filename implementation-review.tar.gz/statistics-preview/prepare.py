from pathlib import Path
import difflib,json,hashlib
R=Path.cwd();O=R/'artifacts/bulgarian/statistics-preview';path=R/'tools/TranslationPreviewHarness.cpp';original=path.read_text();s=original
s=s.replace('#include "Engine.h"','#include "Engine.h"\n#include "InGameStatistics.h"\n#include "touch/GameGUITouch.h"',1)
anchor='    static void openMenu(GameGUI &gui) { gui.openMainMenu(); }'
s=s.replace(anchor,'''    static InGameStatisticsPanel &openStatistics(GameGUI &gui) {
        gui.clearSelection();
        gui.displayMode = GameGUI::STAT_TEXT_VIEW;
        if (gui.touch && gui.touch->usesHUD()) gui.touch->menuAction(3);
        return gui.statistics();
    }
    static bool openStatisticsDetails(GameGUI &gui) {
        auto *dialog = gui.activeDialog();
        if (!dialog) return false;
        auto *button = dialog->host().find("stats/history/details");
        if (!button) return false;
        dialog->host().tapAt(button->bounds.center());
        return true;
    }
'''+anchor,1)
s=s.replace('require(kind == "gameplay" || tutorial, "Unknown game preview kind");','const bool statistics = kind == "statistics";\n    require(kind == "gameplay" || statistics || tutorial, "Unknown game preview kind");',1)
anchor='        capture(captureKind);\n        if (kind == "gameplay"'
replacement='''        if (statistics) {
            const auto beforeNavigation = gui.game.checkSum();
            auto &panel = TranslationPreviewAccess::openStatistics(gui);
            result["statistics_views"] = Json::array();
            auto statisticsCapture = [&](const std::string &name) {
                capture(name);
                Json controls = Json::array();
                for (auto *node : panel.host().interactiveNodes())
                    controls.push_back({{"key", node->key}, {"text", node->accessibleText()}});
                result["statistics_views"].push_back({{"name", name},
                    {"topic", int(panel.topic())}, {"selected_metric", panel.selectedMetric()},
                    {"history_available", panel.history() != nullptr}, {"statistics_tick", panel.tick()},
                    {"win_probability_metric_available", panel.metric("win probability") != nullptr},
                    {"controls", std::move(controls)}});
            };
            panel.selectTopic(InGameStatisticsPanel::Topic::Overview);
            statisticsCapture("statistics-overview");
            panel.selectTopic(InGameStatisticsPanel::Topic::Economy);
            statisticsCapture("statistics-economy");
            panel.selectTopic(InGameStatisticsPanel::Topic::World);
            statisticsCapture("statistics-world");
            // Only open metrics present in the production catalog. Live-player
            // win probabilities are normally hidden; never fabricate access,
            // history, readings or a showChances flag for a translation image.
            for (const auto *id : {"population", "win probability"}) {
                if (!panel.metric(id)) continue;
                panel.openMetric(id);
                const std::string name = id == std::string("population") ? "statistics-population-history" : "statistics-win-probability-history";
                statisticsCapture(name);
                if (TranslationPreviewAccess::openStatisticsDetails(gui)) statisticsCapture(name + "-details");
                TranslationPreviewAccess::closeMenu(gui);
            }
            require(beforeNavigation == gui.game.checkSum(), "Statistics navigation must preserve simulation state");
            result["limits"].push_back("Statistics use only real published local-game readings. A short session can show waiting/empty history; no history is synthesized. Win probability remains unavailable wherever production live-player policy hides it; no hidden help/detail coverage is claimed.");
        } else capture(captureKind);
        if (kind == "gameplay"'''
assert anchor in s;s=s.replace(anchor,replacement,1)
s=s.replace('gameplay|tutorial[:LESSON-ID]','gameplay|statistics|tutorial[:LESSON-ID]').replace('Game mode needs gameplay or tutorial','Game mode needs gameplay, statistics or tutorial')
s=s.replace('             \"src/hud/draw/GameGUIDraw.cpp\",', '             \"src/hud/InGameStatistics.cpp\", \"src/hud/InGameStatistics.h\",\n             \"src/team/stats/MetricCatalog.cpp\", \"src/team/stats/MetricCatalog.h\",\n             \"src/hud/draw/GameGUIDraw.cpp\",')
(O/'TranslationPreviewHarness.cpp').write_text(s)
patch=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/tools/TranslationPreviewHarness.cpp',tofile='b/tools/TranslationPreviewHarness.cpp'))
header=R/'src/hud/touch/GameGUITouch.h';oldheader=header.read_text();newheader=oldheader.replace('\tfriend class GameGUITouchHarness;', '\tfriend class GameGUITouchHarness;\n\tfriend struct TranslationPreviewAccess;',1)
staged=O/'include/touch/GameGUITouch.h';staged.parent.mkdir(parents=True,exist_ok=True);staged.write_text(newheader)
patch+=''.join(difflib.unified_diff(oldheader.splitlines(True),newheader.splitlines(True),fromfile='a/src/hud/touch/GameGUITouch.h',tofile='b/src/hud/touch/GameGUITouch.h'))
(O/'statistics-preview.patch').write_text(patch)
p=R/'docs/development/ui-framework.md';original_doc=p.read_text();doc=original_doc.replace('`gameplay`, `tutorial` (the introduction), or `tutorial:LESSON-ID` and captures','`gameplay`, `statistics`, `tutorial` (the introduction), or `tutorial:LESSON-ID` and captures',1)
needle='the real engine and menu dialog.';assert needle in doc;doc=doc.replace(needle,needle+' Statistics captures navigate the real Overview, Economy and World topics and available metric history/details. They retain live-player visibility rules and never synthesize history or expose hidden win probabilities.',1)
(O/'statistics-preview-docs.patch').write_text(''.join(difflib.unified_diff(original_doc.splitlines(True),doc.splitlines(True),fromfile='a/docs/development/ui-framework.md',tofile='b/docs/development/ui-framework.md')))
sha=lambda b:hashlib.sha256(b).hexdigest();(O/'identity.json').write_text(json.dumps({'base_revision':'3100417199fd8889866fbfcb5c48aaf3c5d224b6','base_harness_sha256':sha(original.encode()),'proposed_harness_sha256':sha(s.encode()),'patch_sha256':sha(patch.encode()),'scope':'Harness-only statistics mode via existing UI navigation; simulation/font/catalog unchanged; staged ignored patch only.','planned_viewports':[[1280,1024],[390,844]],'text_size_percent':[100,150],'availability_limits':'Production live-player statistics explicitly remove win-probability metric. Normal20-tick local session may have waiting/empty charts; no fake history, role or chance visibility.'},indent=2)+'\n')
print('Staged harness + docs patches; no live changes.')
