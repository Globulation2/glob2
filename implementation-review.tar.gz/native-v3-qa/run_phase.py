"""Final-v3 QA runner. Preparation only until final clean source and binary handoff.
Usage: python3 .../run_phase.py fonts|surfaces|engine|unit BINARY --handoff REVISION
API503 runner is separate api_notices.py with the same explicit handoff guard.
"""
from pathlib import Path
import sys,json,subprocess,os,time,hashlib,fnmatch,gzip
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';OUT=B/'native-captures/v3-final'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def guard(binary,revision):
 assert revision==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'Handoff revision mismatch'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip(),'Final source must be clean'
 frozen=json.loads((B/'v3-frozen-inputs.json').read_text());assert frozen['revision']==revision
 assert binary.is_file();return frozen

def environment(profile,phone=False,growth=100):
 user=profile/'user';user.mkdir(parents=True,exist_ok=True);(user/'preferences.txt').write_text(f'textSizePercent={growth}\nlanguage=bg\n')
 env=dict(os.environ,LD_LIBRARY_PATH=str(B/'sdl3/prefix/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''),GLOB2_USER_DATA_DIR=str(user),XDG_DATA_HOME=str(profile/'data'),XDG_CONFIG_HOME=str(profile/'config'),XDG_CACHE_HOME=str(profile/'cache'),SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='x11',GLOB2_RENDERER='software')
 if phone:env['GLOB2_MOBILE_UI']='1'
 else:env.pop('GLOB2_MOBILE_UI',None)
 return env

def run_capture(binary,phase,revision):
 frozen=guard(binary,revision);base=OUT/phase;base.mkdir(parents=True,exist_ok=True);execution=base/'execution.json';records=[];jobs=[]
 if phase=='fonts':
  pilot=B/'v3-font-supplement-input/render-input/bg';delta=json.loads((pilot/'native.json').read_text());assert len(delta)==22 and not json.loads((pilot/'online.json').read_text())
  for view,w,h in [('desktop',1280,1024),('phone',480,960)]:
   for size in [10,13,20]:
    for scale in [1,2]:jobs.append((f'{view}-{size}x{scale}',view,w,h,100,'matrix',[str(size),str(scale)]))
 else:
  pilot=B/'kit-v3/render-input/bg'
  # Four jobs, three actual production cursor/success/failure states per job.
  for view,w,h in [('desktop',1280,1024),('phone',390,844)]:
   for growth in [100,150]:jobs.append((f'{view}-{growth}-script-editor',view,w,h,growth,'script-editor',[]))
  for view,w,h in [('desktop',1280,1024),('phone',390,844)]:
   for name in ['settings','settings-ais','settings-online','new-map']:jobs.append((f'{view}-{name}',view,w,h,100,'screen',[name]))
   jobs.append((f'{view}-editor',view,w,h,100,'editor',[]))
  # Actual compact west-access instruction remains contextual game text; briefing/state may differ.
  jobs.append(('phone-fortifications','phone',390,844,100,'game',['tutorial:fortifications']))
 identity={'binary':str(binary),'binary_sha256':sha(binary),'revision':revision,'phase':phase,'scope':'22 changed native values only; unchanged6259 render-values carried by separate exact-input/source proof.'if phase=='fonts'else'Actual production UI with final full catalog; only explicitly visible states are claimed.','jobs':records}
 for tag,view,w,h,growth,mode,args in jobs:
  out=base/tag;assert not out.exists(),f'Use a fresh output; never overwrite completed evidence: {out}';out.mkdir()
  cmd=[str(binary),mode,str(R),str(pilot),str(out),str(w),str(h)]+args
  if phase!='fonts':cmd=['xvfb-run','-a','-s','-screen 0 1600x1400x24']+cmd
  env=environment(out/'profile',view=='phone',growth);start=time.monotonic();print('START',tag,flush=True)
  with (out/'capture.log').open('w')as log:
   try:rc=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900).returncode
   except subprocess.TimeoutExpired:rc='timeout'
  record={'tag':tag,'command':cmd,'returncode':rc,'seconds':round(time.monotonic()-start,2),'text_size_percent':growth};records.append(record);write(execution,identity)
  if rc==0 and phase=='fonts':
   manifest=json.loads((out/'font-matrix.json').read_text());assert len(manifest['samples'])==22
   assert {(s['key'],s['surface'],s['branch'])for s in manifest['samples']}=={(k,'native','')for k in delta}
   raw=(out/'font-matrix.json').read_bytes()
   with gzip.open(out/'font-matrix.json.gz','wb',compresslevel=9)as target:target.write(raw)
   record['diagnostics_sha256']=hashlib.sha256(raw).hexdigest();write(execution,identity)
  print('END',tag,rc,flush=True)
  if rc!=0:raise SystemExit(f'Failed {tag}; evidence retained, later jobs not counted.')

def run_tests(binary,kind,revision):
 guard(binary,revision);out=B/('native-tests-v3-'+kind);assert not out.exists(),'Do not overwrite earlier test evidence';out.mkdir()
 filters=['ApiErrorText/*','PlatformProtocol/*','PlatformClient/*']if kind=='unit'else['ScriptEditor/*','HiveMindIntegration/*','HiveMindScheduler/*','HiveMindReliability/*','HiveMindPresentation/*','OnlineScreenLifetime/*','FontKerning/*','SystemLanguage/*','SettingsAILibrary/*','GUIInteractionCoverage/Bulgarian*','CommunityMusicUI/API failures clear queued installs*','GameGUITouch/phone navigation*','Settings/*all categories with enlarged text*','Settings/*software rendering*']
 build=R/'build/linux/client/debug/dev-dev_fast-true-linker-auto'
 assert binary.resolve()==(build/'test'/('glob2-'+kind+'-tests')).resolve(),'Use actual final linked test binary'
 cmd=['xvfb-run','-a','-s','-screen 0 1600x1400x24','python3','test/run_tests.py','--build-dir',str(build),'--binary',kind,'-j','2','--display-jobs','1','--timeout','600','--junit',str(out/'junit.xml'),'--artifacts',str(out),'--write-inventory',str(out/'inventory.json'),'--write-timings',str(out/'timings.json')]
 for f in filters:cmd+=['--filter',f]
 env=dict(os.environ,XDG_SESSION_TYPE='x11',LD_LIBRARY_PATH=str(B/'sdl3/prefix/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''))
 for k in ['WAYLAND_DISPLAY','WAYLAND_SOCKET','SDL_VIDEODRIVER','SDL_VIDEO_DRIVER']:env.pop(k,None)
 record={'revision':revision,'binary':str(binary),'binary_sha256':sha(binary),'command':cmd,'filters':filters};write(out/'command.json',record);start=time.monotonic()
 with (out/'run.log').open('w')as log:rc=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 names=json.loads((out/'inventory.json').read_text())['assigned'];record.update(returncode=rc,seconds=round(time.monotonic()-start,2),matched_filters={f:sum(fnmatch.fnmatchcase(n,f)for n in names)for f in filters});write(out/'command.json',record);assert all(record['matched_filters'].values()),record['matched_filters'];raise SystemExit(rc)
if __name__=='__main__':
 assert len(sys.argv)==5 and sys.argv[3]=='--handoff','phase BINARY --handoff REVISION required'
 phase=sys.argv[1];binary=Path(sys.argv[2]).resolve();revision=sys.argv[4]
 if phase in ['fonts','surfaces']:run_capture(binary,phase,revision)
 elif phase in ['unit','engine']:run_tests(binary,phase,revision)
 else:raise SystemExit('Unknown phase')
