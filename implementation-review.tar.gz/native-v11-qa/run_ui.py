from pathlib import Path
import json,os,subprocess,sys,hashlib,time,shutil
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'native-v10-qa'))
from run_phase import R,B,write,sha,environment
OUT=B/'native-captures/v11-integration';OUT.mkdir(exist_ok=True)
binary=Path(sys.argv[1]).resolve();revision,expected=sys.argv[2:]
assert sha(binary)==expected and revision.encode()in binary.read_bytes();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==revision
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
base=OUT/'surfaces-fil-master';assert not base.exists(),'Never overwrite actual attempt';base.mkdir()
old=B/'v10-full-render-input';new=B/'v11-full-render-input';assert not new.exists();shutil.copytree(old,new);pilot=new/'render-input/bg';m=json.loads((new/'manifest.json').read_text());m['revision']=revision;write(new/'manifest.json',m);meta=json.loads((pilot/'metadata.json').read_text());meta.update(source_revision=revision,candidate_revision=revision,compiled_runtime_revision=revision);write(pilot/'metadata.json',meta)
paths=[new/'manifest.json',*pilot.glob('*.json')];frozen={str(p):sha(p)for p in paths}
jobs=[
 ('desktop-main','desktop',1280,1024,100,'screen',['main']),
 ('phone-main','phone',390,844,100,'screen',['main']),
 ('desktop-settings','desktop',1280,1024,100,'screen',['settings']),
 ('phone-settings','phone',390,844,100,'screen',['settings']),
 ('phone-settings-enlarged','phone',390,844,150,'screen',['settings']),
 ('phone-settings-player','phone',390,844,100,'screen',['settings-player']),
 ('phone-results','phone',390,844,100,'game',['statistics']),
 ('phone-editor-enlarged','phone',390,844,150,'editor',[]),
 ('phone-gameplay-enlarged','phone',390,844,150,'game',['gameplay'])]
identity={'actual_revision':revision,'actual_binary_sha256':expected,'input_files_sha256':frozen,'jobs':[],'scope':'Fresh nine affected production UI jobs after Filipino master integration; historical3810/b148/EA0 identities remain unchanged.'}
for tag,view,w,h,growth,mode,args in jobs:
 assert sha(binary)==expected;assert all(sha(Path(p))==h for p,h in frozen.items())
 out=base/tag;out.mkdir();cmd=['xvfb-run','-a','-s','-screen 0 1600x1400x24',str(binary),mode,str(R),str(pilot),str(out),str(w),str(h),*args];start=time.monotonic();print('START',tag,flush=True)
 with (out/'capture.log').open('w')as log:rc=subprocess.run(cmd,cwd=R,env=environment(out/'profile',view=='phone',growth),stdout=log,stderr=subprocess.STDOUT,timeout=900).returncode
 identity['jobs'].append({'tag':tag,'text_size_percent':growth,'command':cmd,'returncode':rc,'seconds':round(time.monotonic()-start,2)});write(base/'execution.json',identity);print('END',tag,rc,flush=True)
 if rc:raise SystemExit(rc)
