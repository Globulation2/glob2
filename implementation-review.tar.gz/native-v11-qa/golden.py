from pathlib import Path
import os,json,subprocess,hashlib,time
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';O=B/'sgsl-bg-compatibility-v11';O.mkdir(exist_ok=True)
build=R/'build/linux/client/debug/dev-dev_fast-true-linker-auto';binary=build/'test/glob2-engine-tests'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert 'scons: done building targets.' in (B/'native-post-fil-precommit-build.log').read_text(),'Root build not complete'
assert not (O/'command.json').exists(),'Never overwrite golden evidence'
base=['python3','test/run_tests.py','--build-dir',str(build),'--binary','engine','--filter','TurnEngineHarness/the committed match record verifies to the committed checksum trace*']
env=dict(os.environ,LD_LIBRARY_PATH=str(B/'sdl3/prefix/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''))
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'actual_dirty_git_status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'engine_binary_sha256':sha(binary),'embedded_provenance_header_sha256':sha(build/'include/glob2/TestBuildProvenance.h'),'source_sim_revision':(R/'src/game/SimRevision.h').read_text(),'commands':[],'claim':'Actual post-master compiled process; dirty producer, not final commit certification'}
(O/'producer-header.txt').write_bytes((build/'include/glob2/TestBuildProvenance.h').read_bytes())
for action in ['update','verify']:
 cmd=base+(['--update-fixtures']if action=='update'else[])+['--junit',str(O/('golden-'+action+'.xml'))]
 with (O/('golden-'+action+'.log')).open('w')as log:rc=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 record['commands'].append({'command':cmd,'returncode':rc});(O/'command.json').write_text(json.dumps(record,indent=2)+'\n');print(action,rc,flush=True)
 assert rc==0
