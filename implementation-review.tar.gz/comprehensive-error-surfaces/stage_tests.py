from pathlib import Path
import json,hashlib
R=Path.cwd();B=R/'artifacts/bulgarian/comprehensive-error-surfaces';S=B/'stage';d=json.loads((B/'baseline.json').read_text())
def cp(rel):
 p=S/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/rel).read_bytes());d['files'][rel]=hashlib.sha256((R/rel).read_bytes()).hexdigest()
 return p
p=cp('src/online/OnlineScreenLifetimeTest.cpp');t=p.read_text().replace('#include "ui/ApiErrorText.h"','#include "ui/ApiErrorText.h"\n#include "ui/DiagnosticText.h"\n#include "ui/HiveReportText.h"');t+='''
TEST_CASE("Diagnostic UI preserves reviewed native summaries, raw values and explicit report provenance" *
		  doctest::test_suite("OnlineScreenLifetime"))
{
	glob2test::GlobalsOptions options{.loadStrings = true};
	options.beforeLoad = [](GlobalContainer &g) { g.settings.language = "bg"; };
	glob2test::HeadlessGlobals globals(options);
	Glob2UI::DiagnosticText diagnostic;
	const std::string raw = "Unknown option preserved-id";
	CHECK_EQ(diagnostic(raw), Glob2UI::onlineProblemText(""));
	CHECK_EQ(diagnostic(raw), Glob2UI::onlineProblemText(""));
	CHECK_EQ(raw, "Unknown option preserved-id");
	CHECK_EQ(diagnostic("Give at least one terrain type a nonzero weight."),
		Glob2UI::nativeSurfaceText("[Give at least one terrain type a nonzero weight.]", ""));
	const Glob2UI::PresentedError deliberate("already presented detail", "raw transport");
	CHECK_EQ(diagnostic.exception(deliberate), "already presented detail");
	CHECK_EQ(Glob2UI::literalSurfaceFormat("%1 / %0 / %1", {"literal %1", "user {p0}"}),
		"user {p0} / literal %1 / user {p0}");
	const std::string text = "Order received: literal %0 {p0}";
	CHECK_EQ(Glob2UI::hiveReportText(Hive::Report(text)), text);
	const Hive::Report local("Order received: literal %0 {p0}", Hive::ReportSource::OrderReceived,
		"literal %0 {p0}");
	CHECK_EQ(Glob2UI::hiveReportText(local), Glob2UI::literalSurfaceFormat(
		Glob2UI::nativeSurfaceText("[hive order received %0]", "Order received: %0"), {local.parameter}));
	CHECK_EQ(local.text, text);
	// The old status words in a remote report remain user/commander text.
	CHECK_EQ(Glob2UI::hiveReportText(Hive::Report("Stopped")), "Stopped");
	CHECK_EQ(Glob2UI::hiveReportText(Hive::Report("Stopped", Hive::ReportSource::Stopped)),
		Glob2UI::nativeSurfaceText("[hive stopped]", "Stopped"));
}
''';p.write_text(t)
p=cp('src/scripting/map/ScriptEditorTest.cpp');t=p.read_text().replace('#include "ScriptEditorScreen.h"','#include "ScriptEditorScreen.h"\n#include "ui/DiagnosticText.h"\n#include "UIRecordingCanvas.h"\n#include "FrontendTheme.h"\n#include "ScopedEnvironment.h"');t+='''
TEST_CASE("Bulgarian script status distinguishes compilation success and failure without changing source" *
		  doctest::test_suite("ScriptEditor"))
{
	glob2test::GlobalsOptions options{.loadStrings = true};
	options.beforeLoad = [](GlobalContainer &g) { g.settings.language = "bg"; };
	glob2test::HeadlessGlobals globals(options);
	glob2test::HeadlessGame world;
	ScriptEditorScreen editor(&world.game);
	editor.selectLanguage(Language::JavaScript);
	const auto previous = world.game.mapscript.getMapScript();
	const std::string source = "function step(ctx) { return []; }";
	editor.setScriptText(source);
	REQUIRE(editor.compile());
	CHECK_EQ(editor.compilationText(), Glob2UI::nativeSurfaceText("[script compilation success]", "Compilation success"));
	CHECK_EQ(editor.scriptText(), source);
	CHECK_EQ(world.game.mapscript.getMapScript(), previous);
	editor.setScriptText("function step( {");
	CHECK_FALSE(editor.compile());
	CHECK_EQ(editor.compilationText(), Glob2UI::literalSurfaceFormat(
		Glob2UI::nativeSurfaceText("[script compilation failed %0]", "Compilation failed: %0"),
		{Glob2UI::onlineProblemText("")}));
	CHECK_EQ(world.game.mapscript.getMapScript(), previous);
}

TEST_CASE("Bulgarian script cursor caption reserves measured localized coordinates [display][artifacts]" *
		  doctest::test_suite("ScriptEditor"))
{
	glob2test::ScopedEnvironment mobile("GLOB2_MOBILE_UI", "0");
	glob2test::GlobalsOptions options{.display = true, .loadStrings = true, .width = 800, .height = 600,
		.screenFlags = GAGCore::GraphicContext::RESIZABLE};
	options.beforeLoad = [](GlobalContainer &g) { g.settings.language = "bg"; };
	glob2test::HeadlessGlobals globals(options);
	glob2test::HeadlessGame world;
	for (const auto &[width, height, touch] : {std::tuple{800, 600, false}, {390, 844, true}})
	for (const double growth : {1.0, 1.5})
	{
		GAGCore::setProcessEnvironment("GLOB2_MOBILE_UI", touch ? "1" : "0", 1);
		SDL_SetWindowSize(SDL_GetWindowFromID(globals->gfx->windowID()), width, height);
		SDL_Event resized{}; resized.type = SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED;
		GAGCore::GraphicContext::translateMouseEvent(&resized);
		ScriptEditorScreen editor(&world.game);
		editor.attach(*globals->gfx);
		editor.selectLanguage(Language::JavaScript);
		const std::string source = std::string(12344, '\\n') + std::string(12344, ' ');
		editor.setScriptText(source);
		editor.host().state("script").cursor = source.size();
		auto presentation = editor.host().presentation();
		presentation.textGrowth = growth; presentation.textUnit *= growth;
		editor.host().setPresentation(presentation);
		editor.draw(0);
		const auto *caption = editor.host().find("script/cursor");
		REQUIRE(caption);
		CHECK_EQ(caption->accessibleText(), Glob2UI::literalSurfaceFormat(
			Glob2UI::nativeSurfaceText("[script line %0 column %1]", "Line: %0 Col: %1"), {"12345", "12345"}));
		CHECK(editor.host().presentation().dialog.contains(caption->bounds));
		GAGGUI::ui::ToolkitTextMeasurer measure(editor.theme(), touch, editor.host().presentation().textUnit);
		glob2test::RecordingCanvas canvas({width, height}, measure);
		editor.host().paint(canvas, 0);
		for (const auto &[at, text] : canvas.texts)
			if (caption->bounds.contains(at))
				CHECK(at.x + measure.width(GAGGUI::ui::FontRole::Caption, text) <= caption->bounds.right());
	}
}
''';p.write_text(t)
(B/'baseline.json').write_text(json.dumps(d,indent=2)+'\n')
