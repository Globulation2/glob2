from pathlib import Path
import shutil,json
R=Path.cwd();B=R/'artifacts/bulgarian/comprehensive-error-surfaces';S=B/'stage';O=B/'check-tree'
def overlay(base,stage,out):
 out.mkdir(parents=True,exist_ok=True)
 for child in base.iterdir():
  target=out/child.name;replacement=stage/child.name
  if replacement.exists():
   if child.is_dir():overlay(child,replacement,target)
   else:shutil.copy2(replacement,target)
  elif not target.exists():target.symlink_to(child, target_is_directory=child.is_dir())
 for child in stage.iterdir():
  if not (base/child.name).exists():
   target=out/child.name
   if child.is_dir():shutil.copytree(child,target,dirs_exist_ok=True)
   else:shutil.copy2(child,target)
overlay(R/'platform',S/'platform',O/'platform')
(B/'vitest.config.mts').write_text('''import base from "'''+str(R/'platform/vitest.config.ts')+'''";
export default {...base, root: "'''+str(O/'platform')+'''", cacheDir: "'''+str(B/'vite-cache')+'''", test: {...base.test, include: ["apps/web/test/generatorStudio.test.tsx"]}};
''')
print(O/'platform')
