from pathlib import Path
B=Path('artifacts/bulgarian/comprehensive-error-surfaces');S=B/'stage'
p=S/'src/hive/HiveIntegrationTest.cpp';t=p.read_text().replace('#include "hive/HiveClient.h"','#include "hive/HiveClient.h"\n#include <type_traits>',1);t+='''
static_assert(std::is_same_v<decltype(Hive::Client::reports), std::vector<std::string>>);
TEST_CASE("Hive report presentation metadata preserves raw API, bounded history and remote provenance" *
		  doctest::test_suite("HiveMindIntegration"))
{
	std::vector<std::string> raw;
	Hive::ReportHistory history;
	const std::string same = "A standing order needs attention and has been paused.";
	history.append(raw, same, Hive::ReportSource::StandingOrderPaused);
	history.append(raw, same); // Remote content is never identified by its bytes.
	CHECK_EQ(history.at(raw, 0).source, Hive::ReportSource::StandingOrderPaused);
	CHECK_EQ(history.at(raw, 1).source, Hive::ReportSource::Remote);
	CHECK_EQ(raw[0], raw[1]);
	for (int i = 0; i < 125; ++i)
		history.append(raw, std::to_string(i), i % 2 ? Hive::ReportSource::Stopped : Hive::ReportSource::Remote);
	REQUIRE_EQ(raw.size(), Hive::ReportHistory::Limit);
	CHECK_EQ(raw.front(), "25");
	for (std::size_t i = 0; i < raw.size(); ++i)
	{
		const auto report = history.at(raw, i);
		CHECK_EQ(report.text, raw[i]);
		CHECK_EQ(report.source, std::stoi(raw[i]) % 2 ? Hive::ReportSource::Stopped : Hive::ReportSource::Remote);
	}
	raw[0] = "Externally supplied report";
	CHECK_EQ(history.at(raw, 0).source, Hive::ReportSource::Remote);
	raw.push_back(same); // Public raw API writes carry no presentation metadata.
	CHECK_EQ(history.at(raw, raw.size() - 1).source, Hive::ReportSource::Remote);
	history.append(raw, "new local", Hive::ReportSource::ConnectionChanged);
	CHECK_EQ(raw.size(), Hive::ReportHistory::Limit);
	CHECK_EQ(history.at(raw, raw.size() - 2).source, Hive::ReportSource::Remote);
	CHECK_EQ(history.at(raw, raw.size() - 1).source, Hive::ReportSource::ConnectionChanged);
}
''';p.write_text(t)
# Additional already-fixed render catch: cache the diagnostic instead of re-logging per paint.
import json,hashlib
d=json.loads((B/'baseline.json').read_text())
for rel in ['src/online/screens/BuildingLibraryScreen.h','src/online/screens/BuildingLibraryScreen.cpp']:
 p=S/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(Path(rel).read_bytes());d['files'][rel]=hashlib.sha256(Path(rel).read_bytes()).hexdigest()
p=S/'src/online/screens/BuildingLibraryScreen.h';t=p.read_text().replace('#pragma once','#pragma once\n#include "ui/DiagnosticText.h"').replace('\tstd::string status, cursor, familyInput;','\tGlob2UI::DiagnosticText listingError;\n\tstd::string status, cursor, familyInput;');p.write_text(t)
p=S/'src/online/screens/BuildingLibraryScreen.cpp';t=p.read_text().replace('Glob2UI::exceptionText(e, Glob2UI::libraryText("Invalid building library response"))','listingError.exception(e, Glob2UI::libraryText("Invalid building library response"))');p.write_text(t)
(B/'baseline.json').write_text(json.dumps(d,indent=2)+'\n')
