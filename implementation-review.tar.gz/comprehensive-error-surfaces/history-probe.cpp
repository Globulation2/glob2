#include "hive/HiveReport.h"
#include <cassert>
#include <iostream>
int main(){
 std::vector<std::string> raw;Hive::ReportHistory history;
 const std::string fixed="A standing order needs attention and has been paused.";
 history.append(raw,fixed,Hive::ReportSource::StandingOrderPaused);history.append(raw,fixed);
 assert(raw[0]==raw[1]);assert(history.at(raw,0).source==Hive::ReportSource::StandingOrderPaused);assert(history.at(raw,1).source==Hive::ReportSource::Remote);
 for(int i=0;i<125;++i)history.append(raw,std::to_string(i),i%2?Hive::ReportSource::Stopped:Hive::ReportSource::Remote);
 assert(raw.size()==100&&raw.front()=="25");
 for(std::size_t i=0;i<raw.size();++i){auto r=history.at(raw,i);assert(r.text==raw[i]);assert(r.source==(std::stoi(raw[i])%2?Hive::ReportSource::Stopped:Hive::ReportSource::Remote));}
 raw[0]="external";assert(history.at(raw,0).source==Hive::ReportSource::Remote);
 raw.push_back(fixed);assert(history.at(raw,raw.size()-1).source==Hive::ReportSource::Remote);
 history.append(raw,"new local",Hive::ReportSource::ConnectionChanged);assert(raw.size()==100);assert(history.at(raw,98).source==Hive::ReportSource::Remote);assert(history.at(raw,99).source==Hive::ReportSource::ConnectionChanged);
 std::cout<<"raw API companion metadata: identical remote/local text, 100-entry trim alignment and external mismatch fallback passed\n";
}
