from pathlib import Path
import json,hashlib,difflib,subprocess
R=Path.cwd();B=R/'artifacts/bulgarian/comprehensive-error-surfaces';S=B/'stage'; baseline=json.loads((B/'baseline.json').read_text());rows=[];out=[]
for p in sorted(S.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(S).as_posix(); live=R/rel; old=live.read_text() if live.exists() else ''
 if rel in baseline['files']:assert hashlib.sha256(live.read_bytes()).hexdigest()==baseline['files'][rel],rel
 elif live.exists(): raise Exception('missing baseline '+rel)
 new=p.read_text()
 if new==old:continue
 out.append('diff --git a/'+rel+' b/'+rel+'\n')
 if not live.exists():out.append('new file mode 100644\n')
 out.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel if live.exists() else '/dev/null',tofile='b/'+rel))
 rows.append({'path':rel,'baseline_sha256':hashlib.sha256(live.read_bytes()).hexdigest() if live.exists() else None,'staged_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
patch=B/'comprehensive-error-surfaces.patch';patch.write_text(''.join(out));subprocess.run(['git','apply','--check',str(patch)],check=True)
(B/'patch-manifest.json').write_text(json.dumps({'base_revision':baseline['revision'],'scope':'IGNORED STAGING ONLY. No live source/build outputs changed.','patch':patch.name,'patch_bytes':patch.stat().st_size,'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'files':rows},indent=2)+'\n')
print(len(rows),patch.stat().st_size)
