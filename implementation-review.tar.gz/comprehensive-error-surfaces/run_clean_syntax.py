from pathlib import Path
import json,subprocess,time,shlex,hashlib,shutil,concurrent.futures
R=Path.cwd();B=R/'artifacts/bulgarian/comprehensive-error-surfaces';S=B/'stage';C=B/'syntax-shadow';C.mkdir(exist_ok=True)
for p in (R/'src').rglob('*'):
 if p.is_file() and p.suffix in ['.h','.hpp']:
  q=C/p.relative_to(R/'src');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for p in (S/'src').rglob('*'):
 if p.is_file():q=C/p.relative_to(S/'src');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
line=next(l for l in (R/'artifacts/bulgarian/native-build-027a.log').read_text().splitlines() if 'g++ -o ' in l and l.endswith('src/ui/settings/SettingsScreenCustomAIs.cpp'))
a=shlex.split(line);a=a[a.index('g++')+1:];i=a.index('-o');del a[i:i+2];a.remove('-c');a=a[:-1];a=[x for x in a if not x.startswith('-fdebug-prefix-map=')]
shadowflags=[]
for x in a:
 if x=='-Isrc':shadowflags.append('-I'+str(C))
 elif x.startswith('-Isrc/'):shadowflags.append('-I'+str(C/x[len('-Isrc/'):]))
 # original fallback includes remain after the consistent shadow roots.
sourceparents={p.parent for p in C.rglob('*.h')};paths=sorted(p for p in (S/'src').rglob('*.cpp'));checks=[]
def run(p):
 rel=p.relative_to(S/'src');command=['g++','-fsyntax-only','-fmax-errors=3',*shadowflags,*['-I'+str(q) for q in sorted(sourceparents)],'-I'+str(R/'test/support'),'-I'+str(R/'test'),*a]
 if p.name.endswith('Test.cpp'):command+=['-fno-access-control']
 command+=[str(C/rel)];start=time.monotonic();log='syntax-'+p.stem+'.log'
 with (B/log).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 return {'path':'src/'+rel.as_posix(),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'command':command,'exit_code':r.returncode,'seconds':round(time.monotonic()-start,2),'log':log}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for check in pool.map(run,paths):
  checks.append(check);(B/'syntax-results.json').write_text(json.dumps({'scope':'Independent consistent header shadow; no active sources/output mutation','checks':checks,'staged_header_sha256':{str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in S.rglob('*.h')}},indent=2)+'\n');print(check['path'],check['exit_code'],flush=True)
print('complete',len(checks),'failures',sum(c['exit_code']!=0 for c in checks))
