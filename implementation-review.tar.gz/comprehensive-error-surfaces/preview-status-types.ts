type GeneratorSettings = { seed: number };
declare function t(source: string, params?: Record<string, string | number>): string;
declare function sourceMessage(source: string): string;
type PreviewStatus =
  | { kind: 'loading' | 'timeout' }
  | { kind: 'generated'; revision: number; seed: GeneratorSettings['seed']; seconds: string }
  | { kind: 'progress'; revision: number; tick: number }
  | { kind: 'failure' | 'error' | 'complete'; raw: string };

function primaryStatus(status: PreviewStatus, locale: string): string {
  switch (status.kind) {
    case 'loading':
      return t('Loading engine…');
    case 'timeout':
      return sourceMessage('Engine launch timed out. Stop and retry the preview.');
    case 'generated':
      return t('Revision {value0} · seed {value1} · {value2} seconds', {
        value0: status.revision,
        value1: status.seed,
        value2: status.seconds,
      });
    case 'progress':
      return t('Revision {value0} · tick {value1} · live', {
        value0: status.revision,
        value1: status.tick,
      });
    case 'failure':
    case 'error':
      return locale === 'bg' ? t('Something went wrong. Please try again.') : status.raw;
    case 'complete':
      return locale === 'bg' ? t('Finished') : status.raw;
  }
}


declare const status: PreviewStatus;
declare const locale: string;
declare const logs: string[];
const terminal = status.kind === 'error' || status.kind === 'complete';
const displayLogs: string[] = locale === 'bg' && terminal ? [...logs, status.raw] : logs;
export {};
