from pathlib import Path
S=Path('artifacts/bulgarian/comprehensive-error-surfaces/stage')
p=S/'src/hive/HiveReport.h';t=p.read_text().replace('#include <utility>','#include <utility>\n#include <vector>\n#include <cstddef>');t=t.replace('} // namespace Hive','''// Companion presentation metadata. The public raw vector remains unchanged.
// Only explicitly tagged internal appends acquire local provenance. Any mismatch
// in container identity, length or the retained per-entry snapshot is untagged.
class ReportHistory
{
	std::vector<Report> metadata;
	const std::string *boundData = nullptr;
  public:
	static constexpr std::size_t Limit = 100;
	void append(std::vector<std::string> &raw, std::string text,
		ReportSource source = ReportSource::Remote, std::string parameter = {})
	{
		if (boundData != raw.data() || metadata.size() != raw.size())
		{
			metadata.clear();
			for (const auto &value : raw) metadata.emplace_back(value);
		}
		for (std::size_t i = 0; i < raw.size(); ++i)
			if (metadata[i].text != raw[i]) metadata[i] = Report(raw[i]);
		raw.push_back(text);
		metadata.emplace_back(std::move(text), source, std::move(parameter));
		if (raw.size() > Limit)
		{
			const auto count = raw.size() - Limit;
			raw.erase(raw.begin(), raw.begin() + count);
			metadata.erase(metadata.begin(), metadata.begin() + count);
		}
		boundData = raw.data();
	}
	Report at(const std::vector<std::string> &raw, std::size_t index) const
	{
		if (index >= raw.size()) return Report("");
		if (boundData != raw.data() || metadata.size() != raw.size() || metadata[index].text != raw[index])
			return Report(raw[index]);
		return metadata[index];
	}
};
} // namespace Hive''');p.write_text(t)
p=S/'src/hive/HiveClient.h';t=p.read_text().replace('std::vector<Report> reports;', 'std::vector<std::string> reports;').replace('\tvoid deliverResult();','''	void deliverResult();
	ReportHistory reportHistory;
	void appendReport(std::string text, ReportSource source = ReportSource::Remote, std::string parameter = {})
	{
		reportHistory.append(reports, std::move(text), source, std::move(parameter));
	}''').replace('\tJson standingOrders() const;', '''	Json standingOrders() const;
	Report reportPresentation(std::size_t index) const { return reportHistory.at(reports, index); }''');p.write_text(t)
p=S/'src/hive/HiveClient.cpp';t=p.read_text().replace('reports.emplace_back(', 'appendReport(');t=t.replace('''				 while (reports.size() > 100)
					 reports.erase(reports.begin());
''','');p.write_text(t)
p=S/'src/hive/HiveDialog.cpp';t=p.read_text().replace('Glob2UI::hiveReportText(client->reports[client->reports.size() - 1 - i])','Glob2UI::hiveReportText(client->reportPresentation(client->reports.size() - 1 - i))').replace('Glob2UI::hiveReportText(client->reports.back())','Glob2UI::hiveReportText(client->reportPresentation(client->reports.size() - 1))');p.write_text(t)
p=S/'src/hive/HiveIntegrationTest.cpp';t=p.read_text().replace('client->reports.back().text.find("still sending")','client->reports.back().find("still sending")');p.write_text(t)
