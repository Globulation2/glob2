// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "HiveWorker.h"
#include "HiveReport.h"
#include <nlohmann/json.hpp>
#include "online/PlatformClient.h"
#include "scripting/javascript/ScriptObservations.h"
#include <future>
#include <memory>
#include <map>
class GameGUI;
namespace Online
{
class OnlineStorage;
}
namespace Hive
{
void setExecutable(const char *path);
struct ClientEnvironment
{
	std::function<void(HttpFetch::Method, const std::string &, const Json &,
					   Online::PlatformClient::ResponseHandler)>
		request;
	std::function<Json(const Json &)> worker;
	std::function<std::uint64_t()> now;
	Online::OnlineStorage *storage = nullptr;
};
class Client
{
	GameGUI &gui;
	Online::PlatformClient &platform;
	Script::Observations observations;
	ClientEnvironment environment;
	void rest(HttpFetch::Method method, const std::string &path, const Json &body,
			  Online::PlatformClient::ResponseHandler callback);
	std::uint64_t now() const;
	Online::OnlineStorage &storage();
	std::string match, base, clientId, lease, cursor = "0";
	std::shared_ptr<bool> alive = std::make_shared<bool>(true);
	std::uint64_t lastPoll = 0, lastEvents = 0, lastLeaseAck = 0, lastAccount = 0, lastResult = 0;
	bool polling = false, enabled = false, working = false, ready = false,
		 uncertainDispatch = false, resultSending = false;
	Json pendingResult = Json::object(), pendingWakes = Json::array();
	struct Program
	{
		Json definition, state = nullptr, recent = nullptr;
		bool initialized = false, paused = false, missingCheckpoint = false;
		unsigned nextTick = 0, random = 1;
	};
	std::map<std::string, Program> programs;
	std::future<Json> pending;
	Json current;
	std::string currentProgram, invocationLease, cancelledOperation;
	Json snapshot();
	void execute(const Json &operation);
	void start(const Json &request);
	void finish(const Json &result);
	bool save();
	void restore();
	void deliverResult();
	ReportHistory reportHistory;
	void appendReport(std::string text, ReportSource source = ReportSource::Remote, std::string parameter = {})
	{
		reportHistory.append(reports, std::move(text), source, std::move(parameter));
	}

  public:
	std::vector<std::string> reports;
	std::string commandDraft, retryCommandId, retryCommandText;
	bool commandSending = false, retryCommandOngoing = false;
	std::map<std::string, std::string> controlStatus;
	std::map<std::string, std::uint64_t> controlGeneration;
	std::string progress;
	Json account = Json::object();
	Client(GameGUI &gui, Online::PlatformClient &platform, std::string match, int seat,
		   ClientEnvironment environment = {});
	~Client();
	void update(bool caughtUp);
	void command(const std::string &text, bool ongoing);
	void stop();
	void change(const std::string &id, const std::string &action);
	void buyCredits();
	bool available() const { return enabled; }
	Json standingOrders() const;
	Report reportPresentation(std::size_t index) const { return reportHistory.at(reports, index); }
};
} // namespace Hive
