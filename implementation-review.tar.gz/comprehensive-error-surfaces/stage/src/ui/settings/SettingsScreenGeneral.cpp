#include "MusicLibraryScreen.h"
#include <ScreenStack.h>
// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2007 Bradley Arsenault
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière
#include "SettingsScreen.h"
#include "ExperimentalFeatures.h"
#include "GlobalContainer.h"
#include "field/GradientAccelerators.h"
#include "SoundMixer.h"
#include "ui/ThemeCatalog.h"
#include <InterfacePresentation.h>
#include <Toolkit.h>
#include <StringTable.h>
#include <FormatableString.h>
#include <algorithm>
#include <cmath>
#include <iterator>

using namespace GAGCore;

void SettingsScreen::buildGeneral()
{
	auto &s = globalContainer->settings;
	// Localize generic display labels; protocol/backend names stay canonical.
	const auto rendererLabel = [](RendererBackend backend) -> std::string
	{
		if (backend == RendererBackend::Software) return tr("Software");
		if (backend == RendererBackend::Auto) return tr("Automatic");
		return std::string(rendererBackendLabel(backend));
	};
	if (current == Category::Display)
	{
		info(tr("Choose how the game looks on your screen."));
#ifndef GLOB2_MOBILE
		if (!touchLayout || globalContainer->gfx->isNativeDesktop())
		{
			// Mobile uses the OS-managed viewport and portable renderer.
			section("Display");
			choice("display.mode", "Window mode", "Choose a window or fill the screen.",
				   bool(s.screenFlags & GraphicContext::FULLSCREEN),
				   {tr("Windowed"), tr("Fullscreen")},
				   [this](int v)
				   {
					   changeDisplay(
						   [v](Settings &s)
						   {
							   if (v)
							   {
								   s.screenFlags |= GraphicContext::FULLSCREEN;
							   }
							   else
							   {
								   s.screenFlags &= ~GraphicContext::FULLSCREEN;
							   }
						   });
				   });

			{
				// 0 follows the desktop; the rest are the scales desktops actually offer.
				static const int percents[] = {0, 100, 125, 150, 175, 200, 250, 300};
				const float desktop = GraphicContext::querySystemUiScale();
				const int desktopPercent =
					int(std::lround(std::max(1.0f, desktop > 0.0f ? desktop : 1.0f) * 100));
				std::vector<std::string> labels;
				for (int p : percents)
					labels.push_back(p ? std::to_string(p) + " %"
									   : FormattableString(tr("Match the desktop %0"))
											 .arg(std::to_string(desktopPercent) + " %"));
				int selected = std::find(std::begin(percents), std::end(percents), s.uiScale) -
							   std::begin(percents);
				if (selected >= int(std::size(percents)))
					selected = 0;
				choice("display.uiscale", "Interface scale",
					   "Multiply the operating system display scale for menus, text and the sidebar.", selected,
					   labels,
					   [this](int v)
					   {
						   if (v >= 0 && v < int(std::size(percents)))
							   changeUiScale(percents[v]);
					   });
			}
			info(FormattableString(tr("Current display %0 %1 %2 %3"))
					 .arg(globalContainer->gfx->getDrawableW())
					 .arg(globalContainer->gfx->getDrawableH())
                     .arg(rendererLabel(globalContainer->gfx->backendSwitchStatus().active))
					 .arg(tr(globalContainer->gfx->getOptionFlags() & GraphicContext::FULLSCREEN
								 ? "Fullscreen"
								 : "Windowed")));
			if (restartRequired())
				info(tr("Saved — restart required"));
			if (displayError)
				info(tr("Could not change display mode. The previous mode was restored."));
		}
#endif
		section("Artwork & effects");
		auto effect = [this, &s](const char *id, const char *label, const char *help,
								 bool Settings::*field)
		{
			toggle(id, label, help, s.*field, [this, field](int v)
			{
				globalContainer->settings.*field = v != 0;
				commit();
			});
		};
		auto appearance = [this, &s](const char *id, const char *label, const char *help,
									 bool Settings::*field, const char *off, const char *on)
		{
			choice(id, label, help, s.*field, {tr(off), tr(on)}, [this, field](int v)
			{
				globalContainer->settings.*field = v != 0;
				commit();
			});
		};
		effect("graphics.skins", "Show colony skins", "Turn off to use classic units, swarms and building colors on this device.", &Settings::showColonySkins);
		effect("graphics.clouds", "Clouds", "Show cloud cover above the map.", &Settings::clouds);
		effect("graphics.shadows", "Cloud shadows", "Show cloud shadows on the ground independently of cloud cover.", &Settings::cloudShadows);
		effect("graphics.particles", "Building particles", "Show smoke and other building particles.", &Settings::buildingParticles);
		appearance("graphics.magic", "Magic effects", "Choose animated magic effects or a simple visible effect.", &Settings::fullMagicEffects, "Simple", "Full");
#ifndef GLOB2_MOBILE
		if (!touchLayout || globalContainer->gfx->isNativeDesktop())
		{
			choice("graphics.artwork", "Artwork",
				   "Apply artwork on the next game or editor load.",
				   s.highResolutionArtwork, {tr("Original"), tr("High resolution")},
				   [this](int v)
				   {
					   globalContainer->settings.highResolutionArtwork = v;
					   commit();
				   });
			const bool gpu = globalContainer->gfx->rendererCapabilities().textureFiltering;
			form.back().enabled = gpu;
            if (!gpu) form.back().help = tr("Requires a renderer with texture filtering. Your saved choice is retained.");
			toggle("graphics.torus", "Automatic torus view",
                   "Automatically show the torus overview while moving around the map.",
				   s.automaticTorus,
				   [this](int v)
				   {
					   globalContainer->settings.automaticTorus = v;
					   commit();
				   });
			form.back().enabled = globalContainer->gfx->rendererCapabilities().torus;
			if (!form.back().enabled) form.back().help = tr("Requires a renderer with torus support. Your saved choice is retained.");
		}
#endif
		section("Interface appearance");
		{
			// Menus and matches each wear their own theme; both apply at once.
			const auto &themes = Glob2UI::ThemeCatalog::shared().themes();
			std::vector<std::string> names;
			// Shipped themes have translated names; a player's theme shows its own.
			const auto *strings = Toolkit::getStringTable();
			for (const auto &theme : themes)
			{
				const std::string key = "[theme " + theme.id + "]";
				names.push_back(strings->doesStringExist(key) ? strings->getString(key) : theme.name);
			}
			auto themeChoice = [&](const char *id, const char *label, const char *help,
								   std::string Settings::*field, const char *fallback)
			{
				const std::string &shown = Glob2UI::ThemeCatalog::shared().resolve(s.*field, fallback).id;
				const auto current = std::find_if(themes.begin(), themes.end(),
												  [&](const auto &theme) { return theme.id == shown; });
				choice(id, label, help, int(current - themes.begin()), names, [this, field](int v)
				{
					const auto &list = Glob2UI::ThemeCatalog::shared().themes();
					auto &settings = globalContainer->settings;
					settings.*field = list.at(std::clamp(v, 0, int(list.size()) - 1)).id;
					Glob2UI::applyThemes(settings.menuTheme, settings.gameTheme);
					commit();
				});
			};
			themeChoice("display.menutheme", "Menu theme", "Colours and backdrop of menus, lobbies and results.", &Settings::menuTheme, Glob2UI::ThemeCatalog::menuDefault);
			themeChoice("display.gametheme", "In-game theme", "Colours of dialogs and the touch interface during a game and in the editor.", &Settings::gameTheme, Glob2UI::ThemeCatalog::gameDefault);
		}
		appearance("graphics.panels", "Panels", "Choose translucent or opaque interface panels.", &Settings::translucentPanels, "Opaque", "Translucent");
		choice("display.textsize", "Text size", "Enlarge interface text without changing the map scale.",
			   s.textSizePercent >= 150 ? 2 : s.textSizePercent >= 125 ? 1 : 0,
			   {"100 %", "125 %", "150 %"}, [this](int v)
			   {
				   // Menus, dialogs and the touch HUD all follow it on their next frame.
				   globalContainer->settings.setTextSizePercent(100 + v * 25);
				   commit();
			   });
		choice("display.presentation", "Interface layout",
			   "Spacious uses a side panel when there is room. Compact uses a toolbar and drawers.",
			   int(parsePresentationPreference(s.interfacePresentation)),
			   {tr("Automatic"), tr("Compact"), tr("Spacious")},
			   [this](int v)
			   {
				   presentationPreference =
					   static_cast<PresentationPreference>(std::clamp(v, 0, 2));
				   globalContainer->settings.interfacePresentation =
					   presentationPreferenceName(presentationPreference);
				   commit();
			   });
		section("Advanced graphics");
        {
            const auto &presets = Settings::RENDER_FPS_PRESETS;
            std::vector<std::string> labels;
            for (int fps : presets) labels.push_back(fps ? std::to_string(fps) + " FPS" : tr("Unlimited"));
            const auto selected = std::find(std::begin(presets), std::end(presets), s.targetRenderFps);
            choice("graphics.fps", "Target render FPS",
                   "Limit drawing across the application. Lower values reduce rendering work. Game speed is unchanged.",
                   selected == std::end(presets) ? 2 : int(selected - std::begin(presets)), labels,
                   [this](int v) {
                       if (v < 0 || v >= int(std::size(Settings::RENDER_FPS_PRESETS))) return;
                       auto &settings = globalContainer->settings;
                       settings.targetRenderFps = Settings::RENDER_FPS_PRESETS[v];
                       globalContainer->gfx->setTargetRenderFps(settings.targetRenderFps);
                       commit();
                   });
        }
		appearance("graphics.paths", "Path lines", "Choose translucent or opaque unit path lines.", &Settings::translucentPathLines, "Opaque", "Translucent");
		effect("graphics.indicators", "Smooth progress indicators", "Smooth the moving edges of progress indicators.", &Settings::smoothProgressIndicators);
		effect("graphics.animation", "Decorative interface animation", "Animate victory artwork. Reduced motion also disables this animation.", &Settings::decorativeAnimations);
		effect("graphics.zoomdetail", "Adaptive zoom detail", "Simplify bars, zones, terrain and units as the map zooms out, and keep them small zoomed in.", &Settings::adaptiveZoomDetail);
		effect("graphics.unitmotion", "Smooth unit motion", "Move and animate units between game ticks.", &Settings::unitInterpolation);
		effect("graphics.smoothfog", "Smooth fog of war", "Fade the map into and out of the fog of war gradually.", &Settings::smoothFog);
        {
            auto *gfx = globalContainer->gfx;
            const auto availability = gfx->rendererAvailability();
            std::vector<RendererBackend> backends;
            std::vector<std::string> labels;
            for (const auto &entry : availability) {
                backends.push_back(entry.backend);
                auto label = rendererLabel(entry.backend);
                if (!entry.available) label += " (" + tr("Renderer unavailable") + ")";
                labels.push_back(std::move(label));
            }
            const auto &status = gfx->backendSwitchStatus();
            const auto selected = std::find(backends.begin(), backends.end(), status.requested);
            choice("graphics.renderer", "Renderer", "Apply at the next completed frame. Your game stays running.",
                int(selected - backends.begin()), labels, [this, backends](int v) {
                    if (v >= 0 && v < int(backends.size()))
                        globalContainer->gfx->requestBackendSwitch(backends[v]);
                    invalidate();
                });
            info(std::string(GAGCore::FormattableString(tr("Active renderer: %0")).arg(rendererLabel(status.active))));
            if (status.phase == RendererSwitchPhase::Queued || status.phase == RendererSwitchPhase::Preparing ||
                status.phase == RendererSwitchPhase::Presenting) info(tr("Changing renderer…"));
            // Backend diagnostics may contain untranslated driver messages. Keep
            // the detailed reason in backend status and show a catalog notice.
            if (!status.reason.empty()) info(tr("Renderer unavailable"));
        }
		if (touchLayout)
			choice("display.zoomdrag", "One-finger zoom", "Double-tap the map, hold, then drag to zoom.",
				   s.oneFingerZoomDirection,
				   {tr("Platform default"), tr("Drag up zooms in"), tr("Drag down zooms in")},
				   [this](int v)
				   {
					   globalContainer->settings.oneFingerZoomDirection =
						   std::clamp(v, int(Settings::ONE_FINGER_ZOOM_PLATFORM),
									  int(Settings::ONE_FINGER_ZOOM_DOWN_IN));
					   commit();
				   });
		if (touchLayout)
			choice("display.thumb", "Thumb side", "Phone controls gather in this bottom corner.",
				   s.thumbSide, {tr("Right"), tr("Left")},
				   [this](int v)
				   {
					   globalContainer->settings.thumbSide =
						   std::clamp(v, int(Settings::THUMB_RIGHT), int(Settings::THUMB_LEFT));
					   globalContainer->settings.thumbSideChosen = true;
					   commit();
				   });
	}
	else if (current == Category::Audio)
	{
		info(tr("Adjust music and voice volume."));
        if(screens) button("audio.library", tr("Music library · Browse, install and import"), [this] {
            screens->push(std::make_unique<MusicLibraryScreen>(*screens), [this](GAGGUI::Screen&,int){ invalidate(); });
        });
		toggle("audio.mute", "Mute audio", "Keep your volume levels while silencing audio.", s.mute,
			   [this](int v)
			   {
				   auto &s = globalContainer->settings;
				   s.mute = v;
				   s.audioPreferenceChosen = true;
				   globalContainer->mix->setVolume(s.musicVolume, s.voiceVolume, s.mute);
				   commit();
			   });
		{
			auto sets = SoundMixer::getMusicSets();
			sets.insert(sets.begin(), "");
			std::vector<std::string> labels{Toolkit::getStringTable()->getString("[random music set]")};
			for (size_t i = 1; i < sets.size(); ++i) labels.push_back(SoundMixer::musicSetLabel(sets[i]));
			const auto selected = std::find(sets.begin(), sets.end(), s.musicSet);
			choice("audio.set", "Music set", "Random each match",
				selected == sets.end() ? 0 : int(selected - sets.begin()), labels,
				[this, sets](int index) {
					if (index >= 0 && index < int(sets.size()) && globalContainer->mix->selectMusicSet(sets[index]))
					{
						globalContainer->settings.musicSet = sets[index];
						commit();
					}
				});
		}
		for (int voice = 0; voice < 2; ++voice)
		{
			auto &r = add(voice ? "audio.voice" : "audio.music", Kind::Slider,
						  tr(voice ? "Voice volume" : "Music volume"));
			r.number = voice ? s.voiceVolume : s.musicVolume;
			r.maximum = 256;
			r.enabled = !s.mute;
			r.value = std::to_string((r.number * 100 + 128) / 256) + "%";
			r.change = [this, voice](int v)
			{
				auto &s = globalContainer->settings;
				(voice ? s.voiceVolume : s.musicVolume) = std::clamp(v, 0, 256);
				globalContainer->mix->setVolume(s.musicVolume, s.voiceVolume, s.mute);
				commit(true);
			};
		}
	}
	else if (current == Category::Gameplay)
	{
		info(tr("Adjust the pace of play."));
        using namespace gradient_kernel;
        const auto selected=globalContainer->runNoX?s.gradientConfiguration():globalContainer->gradientConfiguration();
        std::vector<Backend> backends;std::vector<std::string> names;std::vector<bool> enabled;
        int selectedIndex=0;
        for(const auto& descriptor:gradientBackends()){
            if(!descriptor.compiled && descriptor.id!=selected.backend)continue;
            if(descriptor.id==selected.backend)selectedIndex=int(backends.size());
            backends.push_back(descriptor.id);
            const char* label=descriptor.id==Backend::CPU?"CPU automatic":descriptor.id==Backend::Scalar?"Scalar":descriptor.id==Backend::SSE2?"SSE2":descriptor.id==Backend::NEON?"NEON":descriptor.id==Backend::OpenCL?"OpenCL":descriptor.id==Backend::Vulkan?"Vulkan":"WebGPU";
            names.push_back(descriptor.id==Backend::CPU || descriptor.id==Backend::Scalar?tr(label):label);
            const bool initializing=descriptor.status.availability==Availability::Initializing;
            enabled.push_back(descriptor.selectable());
            if(initializing)names.back()+=" ("+tr("Initializing")+")";
            else if(!descriptor.available)names.back()+=" ("+tr("Unavailable")+")";
        }
        choice("gameplay.gradientBackend","Gradient backend","Applies at the next simulation boundary. Unsupported work uses CPU automatic; rendering is independent.",selectedIndex,names,
            [this,backends](int v){if(v<0 || v>=int(backends.size()))return;
                auto& settings=globalContainer->settings;settings.gradientBackend=backends[v];
                if(!supportsAlgorithm(*settings.gradientBackend,settings.gradientAlgorithm))settings.gradientAlgorithm=isGPU(*settings.gradientBackend)?Algorithm::Frozen8:Algorithm::Buckets;
                // A later explicit menu choice supersedes the launch choice for this run.
                globalContainer->gradientBackendOverride=*settings.gradientBackend;
                globalContainer->gradientAlgorithmOverride=settings.gradientAlgorithm;
                requestBackendConfiguration(globalContainer->gradientConfiguration());commit();});
        form.back().enabledChoices=enabled;
        const std::vector<Algorithm> algorithms=!isGPU(selected.backend)?std::vector{Algorithm::Buckets}:selected.backend==Backend::OpenCL?std::vector{Algorithm::Frozen8}:std::vector{Algorithm::Frozen8,Algorithm::Jacobi};
        std::vector<std::string> algorithmLabels;int algorithmIndex=0;
        for(std::size_t i=0;i<algorithms.size();++i){algorithmLabels.push_back(algorithms[i]==Algorithm::Buckets?tr("Bucket propagation"):algorithms[i]==Algorithm::Frozen8?"Frozen8":"Jacobi");if(algorithms[i]==selected.algorithm)algorithmIndex=int(i);}
        choice("gameplay.gradientAlgorithm","Gradient algorithm","All choices compute the same exact field.",algorithmIndex,algorithmLabels,
            [this,algorithms](int v){if(v<0 || v>=int(algorithms.size()))return;globalContainer->settings.gradientAlgorithm=algorithms[v];globalContainer->gradientAlgorithmOverride=algorithms[v];requestBackendConfiguration(globalContainer->gradientConfiguration());commit();});
        const auto active=configuration();const auto status=acceleratorStatus(active.backend);
        const std::string actual=isGPU(active.backend)?status.availability==Availability::Ready?status.device:std::string(backendName(automaticCPU()))+" ("+tr("CPU fallback")+")":backendName(cpuBackend());
        info(std::string(tr("Gradient computation"))+": "+backendName(active.backend)+" / "+algorithmName(active.algorithm)+"; "+actual+"; "+std::to_string(status.fields)+" "+tr("GPU fields")+"; "+std::to_string(status.fallbacks)+" "+tr("CPU fallbacks")+(status.error.empty()?"":"; "+gradientError(status.error)));
		std::vector<std::string> labels;
		Settings copy = s;
		for (int i = Settings::GAME_SPEED_MINIMUM; i <= Settings::GAME_SPEED_MAXIMUM; ++i)
		{
			copy.gameSpeed = i;
			labels.push_back(copy.getGameSpeedText());
		}
		choice("gameplay.speed", "Game speed",
			   "Single-player and replays only. Multiplayer runs at 1x.",
			   s.gameSpeed - Settings::GAME_SPEED_MINIMUM, labels,
			   [this](int v)
			   {
				   globalContainer->settings.gameSpeed =
					   std::clamp(v + int(Settings::GAME_SPEED_MINIMUM),
						int(Settings::GAME_SPEED_MINIMUM), int(Settings::GAME_SPEED_MAXIMUM));
				   commit();
			   });
		toggle("gameplay.autosave", "Autosave", "Save the game automatically about every minute.",
			   s.autosaveGames,
			   [this](int v)
			   {
				   globalContainer->settings.autosaveGames = v;
				   commit();
			   });
	}
	else if (current == Category::Player)
	{
		info(tr("Set your language and player name."));
		auto *strings = Toolkit::getStringTable();
		std::vector<std::string> labels;
		for (int i = 0; i < strings->getNumberOfLanguage(); ++i)
		{
			auto label = strings->getStringInLang(
				strings->isLangComplete(i) ? "[language]" : "[language incomplete]", i);
			if (!Toolkit::getFont("standard")->hasGlyphsFor(label))
				label = strings->getStringInLang("[language-code]", i) + " — " + tr("Missing font");
			labels.push_back(label);
		}
		choice("player.language", "Language", "Language used throughout the interface.",
			   strings->getLang(), labels,
			   [this](int v)
			   {
				   auto *strings = Toolkit::getStringTable();
				   strings->setLang(v);
				   globalContainer->settings.language =
					   strings->getStringInLang("[language-code]", v);
				   commit();
			   });
		auto &r =
			add("player.name", Kind::Text, tr("Player name"), tr("Name shown to other players."));
		r.value = s.getUsername();
	}
	else if (current == Category::Experiments)
	{
		info(tr("Try features we are still testing. They can change balance and pacing."));
		info(tr("Experiments apply to new games you start or host, never to campaign missions. A saved game keeps the ones it started with."));
		const auto definitions = registeredExperimentDefinitions();
		if (definitions.empty())
			info(tr("No experiments in this build."));
		for (const auto &definition : definitions)
		{
			// Labels come from the experiment's own keys rather than the
			// "[settings ...]" prefix, so the lobby and this page share them.
			const std::string key = definition.key;
			auto &r = add("experiments." + key, Kind::Toggle, experimentLabel(definition), experimentHelp(definition));
			r.number = s.experiments.has(key);
			r.change = [this, key](int v)
			{
				globalContainer->settings.experiments.set(key, v != 0);
				commit();
			};
		}
	}
}
