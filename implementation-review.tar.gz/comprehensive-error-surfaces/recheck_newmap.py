from pathlib import Path
import subprocess,json,time,hashlib
B=Path('artifacts/bulgarian/comprehensive-error-surfaces');p=B/'syntax-results.json';d=json.loads(p.read_text());r=next(r for r in d['checks'] if r['path']=='src/map/editor/screens/NewMapScreen.cpp');t=time.monotonic()
with (B/r['log']).open('w') as out:result=subprocess.run(r['command'],stdout=out,stderr=subprocess.STDOUT)
r['exit_code']=result.returncode;r['seconds']=round(time.monotonic()-t,2);r['final_recheck_reason']='Actual compiler dependency inventory identified final BuildingLibraryScreen header consumer';p.write_text(json.dumps(d,indent=2)+'\n');print('NewMap final header-consumer syntax',result.returncode)
raise SystemExit(result.returncode)
