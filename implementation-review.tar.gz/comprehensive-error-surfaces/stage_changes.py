from pathlib import Path
import json,hashlib,re
R=Path.cwd();B=R/'artifacts/bulgarian/comprehensive-error-surfaces';S=B/'stage';base={}
def copy(rel):
 p=S/rel
 if not p.exists():
  p.parent.mkdir(parents=True,exist_ok=True)
  if (R/rel).exists():p.write_bytes((R/rel).read_bytes());base[rel]=hashlib.sha256((R/rel).read_bytes()).hexdigest()
 return p
def edit(rel,fn):
 p=copy(rel);old=p.read_text();new=fn(old);assert old!=new,rel;p.write_text(new)
def include(t):return '#include "ui/DiagnosticText.h"\n'+t
def field(rel,needle,text):edit(rel,lambda t:include(t).replace(needle,text+needle))
p=copy('src/ui/DiagnosticText.h');p.write_text('''// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "ui/ApiErrorText.h"
#include <initializer_list>
#include <string_view>

namespace Glob2UI
{
inline bool bulgarianErrorLocale()
{
	const auto locale = onlineErrorLocale();
	return locale == "bg" || locale == "bg-BG";
}
// Exact native source binding, with an explicit English fallback while new keys
// are staged. Data parameters are substituted literally in one pass below.
inline std::string nativeSurfaceText(const std::string &key, const std::string &english)
{
	auto *strings = GAGCore::Toolkit::getStringTable();
	return strings && strings->doesStringExist(key) ? strings->getString(key) : english;
}
inline std::string literalSurfaceFormat(std::string_view text,
	std::initializer_list<std::string_view> values)
{
	std::string out;
	for (std::size_t i = 0; i < text.size();)
	{
		if (text[i] == '%' && i + 1 < text.size() && text[i + 1] >= '0' && text[i + 1] <= '9')
		{
			const auto slot = std::size_t(text[i + 1] - '0');
			if (slot < values.size()) { out += *(values.begin() + slot); i += 2; continue; }
		}
		out += text[i++];
	}
	return out;
}
// One bounded cache per UI diagnostic context. Repaints of the same failure do
// not repeat logs. Underlying model/report bytes and readiness remain untouched.
class DiagnosticText
{
	std::string lastIdentity, lastLocale, lastSummary, display;
	bool hasValue = false;
  public:
	std::string exception(const std::exception &error, const std::string &summary = {})
	{
		const auto *marked = dynamic_cast<const PresentedError *>(&error);
		std::string identity = marked ? marked->diagnostic : std::string();
		identity += '\\0'; identity += error.what();
		const auto locale = onlineErrorLocale();
		if (!hasValue || identity != lastIdentity || locale != lastLocale || summary != lastSummary)
		{
			display = exceptionText(error, summary);
			lastIdentity = std::move(identity); lastLocale = locale; lastSummary = summary; hasValue = true;
		}
		return display;
	}
	std::string operator()(const std::string &raw)
	{
		if (raw.empty()) { hasValue = false; return {}; }
		std::string summary;
		if (bulgarianErrorLocale())
		{
			auto *strings = GAGCore::Toolkit::getStringTable();
			const auto key = "[" + raw + "]";
			summary = strings && strings->doesStringExist(key)
				? strings->getString(key) : onlineProblemText(raw);
		}
		return exception(std::runtime_error(raw), summary);
	}
};
} // namespace Glob2UI
''')
# Event-driven catches. Keep surrounding cleanup and state transitions verbatim.
for rel in ['src/ui/settings/SettingsScreenCustomGenerators.cpp','src/game/screens/CustomGameScreen.cpp','src/map/editor/MapEditFlows.cpp','src/map/editor/MapEditDelegate.cpp','src/map/editor/SetLibraryDialog.cpp','src/net/lan/screens/LANFindScreen.cpp','src/net/lan/screens/LANMenuScreen.cpp']:
 def change(t,rel=rel):
  t=include(t)
  t=re.sub(r'\b(error|e)\.what\(\)',r'Glob2UI::exceptionText(\1)',t)
  if 'CustomGenerators' in rel:
   t=t.replace('throw std::runtime_error("Generator storage persistence is unavailable")','throw Glob2UI::PresentedError(Glob2UI::nativeSurfaceText("[library Storage persistence unavailable]", "Storage persistence unavailable"), "Generator storage persistence is unavailable")')
   # A constructor failure can be retried by every paint.
   t=t.replace('info(Glob2UI::exceptionText(error));','info(generatorConstructionError.exception(error));')
  if 'SetLibraryDialog' in rel:
   t=t.replace('throw std::runtime_error(fe::tr(', 'throw Glob2UI::PresentedError(fe::tr(')
   # Broad map import failures need generic; malformed listing/package context remains precise.
   old='status = Glob2UI::exceptionText(error); package = nullptr; bytes.clear();'
   t=t.replace(old,'status = Glob2UI::exceptionText(error, fe::tr(downloading ? "[set library package error]" : "[set library listing error]")); package = nullptr; bytes.clear();')
  if 'LANFindScreen' in rel:t=t.replace('throw std::invalid_argument(tr("[lan lobby endpoint required]"))','throw Glob2UI::PresentedError(tr("[lan lobby endpoint required]"))')
  return t
 edit(rel,change)
# Settings diagnostics are per screen. Also prevent repeated logs for preexisting AI constructor failure.
field('src/ui/settings/SettingsScreen.h','\tstd::vector<Row> form;', '\tGlob2UI::DiagnosticText gradientError, mcpError, generatorConstructionError, aiConstructionError;\n')
edit('src/ui/settings/SettingsScreenCustomAIs.cpp',lambda t:t.replace('info(Glob2UI::exceptionText(e));','info(aiConstructionError.exception(e));'))
edit('src/ui/settings/SettingsScreenGeneral.cpp',lambda t:t.replace('"; "+status.error','"; "+gradientError(status.error)'))
edit('src/ui/settings/SettingsScreenMCP.cpp',lambda t:t.replace('.arg(service->failureReason())','.arg(mcpError(service->failureReason()))'))
# Raw/visible state split in repeated render paths.
field('src/game/screens/CustomGameScreen.h','\tstd::string message;', '\tGlob2UI::DiagnosticText validationError, mapDownloadError;\n')
def custom(t):
 t=t.replace('message="Missing map generator: "+preferences.missingGeneratorId+". A native landscape was selected."','message=Glob2UI::bulgarianErrorLocale() ? Glob2UI::literalSurfaceFormat(Glob2UI::nativeSurfaceText("[missing map generator %0]", "Missing map generator: %0. A native landscape was selected."), {preferences.missingGeneratorId}) : "Missing map generator: "+preferences.missingGeneratorId+". A native landscape was selected."')
 t=t.replace('message = tr(setup.validation());','message = Glob2UI::bulgarianErrorLocale() ? validationError(setup.validation()) : tr(setup.validation());\n\t\tif (setup.validation() == "Shared control needs a free controller slot (maximum %0).")\n\t\t\tmessage = FormattableString(message).arg(Team::MAX_COUNT);')
 t=t.replace('onlineMapCache->error()', 'mapDownloadError(onlineMapCache->error())') if 'onlineMapCache->error()' in t else t
 # exact actual MapCache spelling handled below if needed
 t=t.replace(': tr(error);', ': (Glob2UI::bulgarianErrorLocale() ? validationError(error) : tr(error));')
 # Formatting this known numeric template is already done by tr() for non-BG.
 t=t.replace('const std::string note =', 'const std::string note =')
 return t
edit('src/game/screens/CustomGameScreen.cpp',custom)
field('src/map/editor/screens/NewMapScreen.h','\tstd::string error;', '\tGlob2UI::DiagnosticText validationError;\n')
edit('src/map/editor/screens/NewMapScreen.cpp',lambda t:t.replace('fe::paragraph(error,','fe::paragraph(validationError(error),'))
# Precompute translations at the recomputation event, preserving raw incompatibility for enablement.
field('src/game/screens/LandscapePickerScreen.h','\tstd::vector<std::string> incompatible;', '\tstd::vector<std::string> incompatibleText;\n')
edit('src/game/screens/LandscapePickerScreen.cpp',lambda t:include(t).replace('incompatible.assign(entries.size(), {});','incompatible.assign(entries.size(), {});\n\tincompatibleText.assign(entries.size(), {});').replace('incompatible[i] = validateGenerationRequest(entry.request, entry.request.definition());','incompatible[i] = validateGenerationRequest(entry.request, entry.request.definition());\n\t\tGlob2UI::DiagnosticText presenter;\n\t\tincompatibleText[i] = presenter(incompatible[i]);').replace('fe::paragraph(incompatible[std::size_t(i)],','fe::paragraph(incompatibleText[std::size_t(i)],'))
# Game loading raw diagnostic remains available; neutral summary avoids a false damage diagnosis.
field('src/game/screens/GameLoadScreen.h','\tstd::string failureDiagnostic;', '\tmutable Glob2UI::DiagnosticText loadFailure;\n')
edit('src/game/screens/GameLoadScreen.cpp',lambda t:t.replace('auto message = Glob2UI::tr("[ERROR_CANT_LOAD_MAP]");','if (Glob2UI::bulgarianErrorLocale())\n\t{\n\t\tloadFailure(failureDiagnostic);\n\t\treturn Glob2UI::nativeSurfaceText("[Could not load this map. Choose another map or retry.]", "Could not load this map. Choose another map or retry.");\n\t}\n\tauto message = Glob2UI::tr("[ERROR_CANT_LOAD_MAP]");'))
# Recorder process singleton has one shared control/status context; last-value cache is bounded.
edit('src/ui/RecordingControls.h',lambda t:include(t).replace('parts.push_back(paragraph(status.error,','static DiagnosticText recordingError;\n\t\tparts.push_back(paragraph(recordingError(status.error),').replace('if (!status.error.empty())\n\t\tstatic', 'if (!status.error.empty())\n\t{\n\t\tstatic').replace('\n\treturn column', '\n\t}\n\treturn column'))
field('src/ui/screens/RecordingFilesScreen.h','\tstd::string deleting, error;', '\tGlob2UI::DiagnosticText filesError;\n')
edit('src/ui/screens/RecordingFilesScreen.cpp',lambda t:t.replace('paragraph(files.error)','paragraph(filesError(files.error))'))
field('src/game/screens/MatchStartScreen.h','\tbool failed', '\tGlob2UI::DiagnosticText failureText;\n')
edit('src/game/screens/MatchStartScreen.cpp',lambda t:t.replace('"\\n" + flow->failure()', '"\\n" + failureText(flow->failure())'))
# LanRoom describeClose is already a UI presenter, not raw transport state.
field('src/net/lan/LanRoom.h','\t\tstd::string ending;', '\t\tmutable Glob2UI::DiagnosticText closeDiagnostic;\n')
edit('src/net/lan/LanRoom.cpp',lambda t:t.replace('.arg(detail));','.arg(closeDiagnostic(detail)));').replace('.arg(detail.empty() ? reason : detail);','.arg(closeDiagnostic(detail.empty() ? reason : detail));'))
# Notice comparison and raw room JSON untouched; only emitted system-chat text is presented.
edit('src/online/PlatformRoom.cpp',lambda t:include(t).replace('notice(startNotice(next));','{ Glob2UI::DiagnosticText presenter; notice(presenter(startNotice(next))); }'))
# Web cross-surface primary summary; structured report/details stay exact.
edit('platform/apps/web/src/pages/generatorStudio/Preview.tsx',lambda t:t.replace('  useLocale();','  const locale = useLocale();').replace(": String(m.diagnostic || 'Generation failed').slice(0, 2000),",": locale === 'bg'\n              ? t('Something went wrong. Please try again.')\n              : String(m.diagnostic || 'Generation failed').slice(0, 2000),"))
(B/'baseline.json').write_text(json.dumps({'revision':'d3f7ad00c8d4276967b8807e052d46a74d63be34','files':base},indent=2)+'\n')
