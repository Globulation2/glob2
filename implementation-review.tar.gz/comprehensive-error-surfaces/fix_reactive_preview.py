from pathlib import Path
S=Path('artifacts/bulgarian/comprehensive-error-surfaces/stage');p=S/'platform/apps/web/src/pages/generatorStudio/Preview.tsx';s=p.read_text().replace('t, useLocale, RichMessage, getLocale','t, useLocale, RichMessage');s=s.replace('export default function Preview({','''type PreviewStatus =
  | { kind: 'loading' | 'timeout' }
  | { kind: 'generated'; revision: number; seed: GeneratorSettings['seed']; seconds: string }
  | { kind: 'progress'; revision: number; tick: number }
  | { kind: 'failure' | 'error' | 'complete'; raw: string };

function primaryStatus(status: PreviewStatus, locale: string): string {
  switch (status.kind) {
    case 'loading': return t('Loading engine…');
    case 'timeout': return sourceMessage('Engine launch timed out. Stop and retry the preview.');
    case 'generated': return t('Revision {value0} · seed {value1} · {value2} seconds', {
      value0: status.revision, value1: status.seed, value2: status.seconds,
    });
    case 'progress': return t('Revision {value0} · tick {value1} · live', {
      value0: status.revision, value1: status.tick,
    });
    case 'failure':
    case 'error': return locale === 'bg' ? t('Something went wrong. Please try again.') : status.raw;
    case 'complete': return locale === 'bg' ? t('Finished') : status.raw;
  }
}

export default function Preview({''');s=s.replace('  useLocale();', '  const locale = useLocale();',1).replace("const [status, setStatus] = useState(t('Loading engine…'))", "const [status, setStatus] = useState<PreviewStatus>({ kind: 'loading' })");s=s.replace("setStatus(sourceMessage('Engine launch timed out. Stop and retry the preview.'));", "setStatus({ kind: 'timeout' });")
a=s.index('        setStatus(\n          m.success');b=s.index('        callback.current(',a)
s=s[:a]+'''        setStatus(m.success
          ? { kind: 'generated', revision: run.revision, seed: run.settings.seed,
              seconds: Number(m.seconds).toFixed(2) }
          : { kind: 'failure', raw: String(m.diagnostic || 'Generation failed').slice(0, 2000) });
'''+s[b:]
a=s.index('        setStatus(\n          t(\'Revision {value0} · tick');b=s.index('\n      }',a)
s=s[:a]+"        setStatus({ kind: 'progress', revision: run.revision, tick: Number(m.tick) || 0 });"+s[b:]
a=s.index("        if (getLocale() === 'bg')");b=s.index('        callback.current(',a)
s=s[:a]+"        setStatus({ kind: m.type, raw });\n"+s[b:]
s=s.replace('  return (\n    <div className="as-playtest">', '''  // Derive display from retained event data so locale changes never restart the
  // engine and never leave a previous locale's primary diagnostic on screen.
  const terminal = status.kind === 'error' || status.kind === 'complete';
  const displayLogs = locale === 'bg' && terminal ? [...logs, status.raw] : logs;
  return (
    <div className="as-playtest">''').replace('<p role="status">{status}</p>','<p role="status">{primaryStatus(status, locale)}</p>').replace('slots={{ slot0: logs.length }}','slots={{ slot0: displayLogs.length }}').replace("<pre>{logs.join('\\n')}</pre>","<pre>{displayLogs.join('\\n')}</pre>");p.write_text(s)
p=S/'src/ui/DiagnosticText.h';s=p.read_text().replace('// Exact native source binding, with an explicit English fallback while new keys\n// are staged. Data parameters are substituted literally in one pass below.','// Exact native source binding with an explicit English fallback when a key is\n// unavailable. Data parameters are substituted literally in one pass below.');p.write_text(s)
# Replace the previous event-only test with bidirectional switches after each status.
p=S/'platform/apps/web/test/generatorStudio.test.tsx';s=p.read_text();a=s.index("it('uses a reviewed Bulgarian primary failure");s=s[:a]+'''it('relocalizes retained failure and completion status without engine lifecycle or report changes', async () => {
  registerCatalog('bg', bg);
  await setLocale('en');
  try {
    const result = vi.fn();
    const run = { runId: '11111111-1111-4111-8111-111111111111', revision: 3,
      source: 'package', draftHash: 'a'.repeat(64), settings: defaultSettings };
    const view = render(<LocaleProvider><Preview run={run} onResult={result} /></LocaleProvider>);
    const frame = view.container.querySelector('iframe')!;
    const post = vi.spyOn(frame.contentWindow!, 'postMessage');
    const send = (data: Record<string, unknown>) => act(() => window.dispatchEvent(
      new MessageEvent('message', { origin: location.origin, source: frame.contentWindow,
        data: { channel: 'glob2-generator-studio', version: 1, runId: run.runId, revision: 3, ...data } })));
    const switchLocale = async (locale: string, expected: string) => {
      const callbacks = result.mock.calls.length;
      await act(() => setLocale(locale));
      expect(screen.getByRole('status').textContent).toBe(expected);
      expect(post).not.toHaveBeenCalled(); // No stop or relaunch without a new engine event.
      expect(result.mock.calls.length).toBe(callbacks);
    };
    const generic = bg['Something went wrong. Please try again.'];
    send({ type: 'generated', success: false, playable: false, seconds: 1,
      diagnostic: 'Fixed generator failure: exact-custom-id' });
    expect(screen.getByRole('status').textContent).toBe('Fixed generator failure: exact-custom-id');
    await switchLocale('bg', generic);
    await switchLocale('en', 'Fixed generator failure: exact-custom-id');
    expect(view.container.querySelector('pre')?.textContent).toContain('Fixed generator failure: exact-custom-id');
    expect(JSON.parse(result.mock.calls.at(-1)![0]).diagnostic).toBe('Fixed generator failure: exact-custom-id');
    send({ type: 'diagnostic', text: 'Exact original runtime diagnostic array entry' });
    send({ type: 'error', text: 'Exact runtime report {p0} %1' });
    expect(screen.getByRole('status').textContent).toBe('Exact runtime report {p0} %1');
    await switchLocale('bg', generic);
    expect(view.container.textContent).toContain('Exact runtime report {p0} %1');
    await switchLocale('en', 'Exact runtime report {p0} %1');
    await switchLocale('bg', generic);
    const errorReport = JSON.parse(result.mock.calls.at(-1)![0]);
    expect(errorReport.text).toBe('Exact runtime report {p0} %1');
    expect(errorReport.logs).toEqual(['Exact original runtime diagnostic array entry']);
    send({ type: 'complete', result: 'Exact completion result' });
    expect(screen.getByRole('status').textContent).toBe(bg.Finished);
    await switchLocale('en', 'Exact completion result');
    await switchLocale('bg', bg.Finished);
    const completed = JSON.parse(result.mock.calls.at(-1)![0]);
    expect(completed.result).toBe('Exact completion result');
    expect(completed.logs).toEqual(['Exact original runtime diagnostic array entry']);
    expect(errorReport.logs).toEqual(['Exact original runtime diagnostic array entry']);
  } finally { cleanup(); await setLocale('en'); }
});
''';p.write_text(s)
