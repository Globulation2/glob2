from pathlib import Path
import json,hashlib
R=Path.cwd();B=R/'artifacts/bulgarian/comprehensive-error-surfaces';S=B/'stage';d=json.loads((B/'baseline.json').read_text())
p=S/'platform/apps/web/src/pages/generatorStudio/Preview.tsx';t=p.read_text();t=t.replace("setStatus(String(m.text ?? m.result ?? 'Finished').slice(0, 2000));",'''const raw = String(m.text ?? m.result ?? 'Finished').slice(0, 2000);
        if (locale === 'bg' && diagnostics.length < 40) {
          diagnostics.push(raw);
          setLogs([...diagnostics]);
        }
        setStatus(locale === 'bg'
          ? m.type === 'error' ? t('Something went wrong. Please try again.') : t('Finished')
          : raw);''');p.write_text(t)
rel='platform/apps/web/test/generatorStudio.test.tsx';p=S/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/rel).read_bytes());d['files'][rel]=hashlib.sha256((R/rel).read_bytes()).hexdigest();t=p.read_text().replace("import Preview from '../src/pages/generatorStudio/Preview.tsx';","import Preview from '../src/pages/generatorStudio/Preview.tsx';\nimport { LocaleProvider } from '../src/i18n.tsx';\nimport { registerCatalog, setLocale } from '../../../packages/i18n/src/index.ts';\nimport bg from '../../../packages/i18n/locales/bg.json';")
t+='''
it('uses a reviewed Bulgarian primary failure while preserving generation and runtime reports', async () => {
  registerCatalog('bg', bg);
  await setLocale('bg');
  try {
    const result = vi.fn();
    const run = { runId: '11111111-1111-4111-8111-111111111111', revision: 3,
      source: 'package', draftHash: 'a'.repeat(64), settings: defaultSettings };
    const view = render(<LocaleProvider><Preview run={run} onResult={result} /></LocaleProvider>);
    const frame = view.container.querySelector('iframe')!;
    const send = (data: Record<string, unknown>) => act(() => window.dispatchEvent(
      new MessageEvent('message', { origin: location.origin, source: frame.contentWindow,
        data: { channel: 'glob2-generator-studio', version: 1, runId: run.runId, revision: 3, ...data } })));
    send({ type: 'generated', success: false, playable: false, seconds: 1,
      diagnostic: 'Fixed generator failure: exact-custom-id' });
    expect(screen.getByRole('status').textContent).toBe(bg['Something went wrong. Please try again.']);
    expect(view.container.querySelector('pre')?.textContent).toContain('Fixed generator failure: exact-custom-id');
    expect(JSON.parse(result.mock.calls.at(-1)![0]).diagnostic).toBe('Fixed generator failure: exact-custom-id');
    send({ type: 'error', text: 'Exact runtime report {p0} %1' });
    expect(screen.getByRole('status').textContent).toBe(bg['Something went wrong. Please try again.']);
    expect(view.container.textContent).toContain('Exact runtime report {p0} %1');
    expect(JSON.parse(result.mock.calls.at(-1)![0]).text).toBe('Exact runtime report {p0} %1');
    send({ type: 'complete', result: 'Exact completion result' });
    expect(screen.getByRole('status').textContent).toBe(bg.Finished);
    expect(JSON.parse(result.mock.calls.at(-1)![0]).result).toBe('Exact completion result');
  } finally { cleanup(); await setLocale('en'); }
});
''';p.write_text(t)
(B/'baseline.json').write_text(json.dumps(d,indent=2)+'\n')
# Fix includes/test state while no compiler reads this new test source yet.
p=S/'src/scripting/map/ScriptEditorTest.cpp';t=p.read_text().replace('for (const auto &[width, height, touch] : {std::tuple{800, 600, false}, {390, 844, true}})','struct RestoreText { double old = GAGCore::userTextScale; ~RestoreText() { GAGCore::userTextScale = old; } } restoreText;\n\tfor (const auto &[width, height, touch] : {std::tuple{800, 600, false}, {390, 844, true}})').replace('auto presentation = editor.host().presentation();\n\t\tpresentation.textGrowth = growth; presentation.textUnit *= growth;\n\t\teditor.host().setPresentation(presentation);','GAGCore::userTextScale = growth;');p.write_text(t)
