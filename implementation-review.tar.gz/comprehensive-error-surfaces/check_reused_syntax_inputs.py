from pathlib import Path
import subprocess,json,concurrent.futures,hashlib
B=Path('artifacts/bulgarian/comprehensive-error-surfaces').resolve();S=B/'stage';C=B/'syntax-shadow';old=json.loads((B/'syntax-results-before-final.json').read_text());cur=json.loads((B/'syntax-results.json').read_text());oldmap={r['path']:r for r in old['checks']}
changed=[k for k,v in cur['staged_header_sha256'].items() if old['staged_header_sha256'].get(k)!=v];rows=[]
def check(row):
 command=list(row['command']);command[command.index('-fsyntax-only')]='-MM';r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,check=True)
 deps=[k for k in changed if str(C/Path(k).relative_to('src')) in r.stdout]
 # Reused command records point into the same shadow; these are final header dependency inventories.
 was_rechecked=row['path'] in ['src/game/screens/CustomGameScreen.cpp','src/hive/HiveClient.cpp','src/hive/HiveDialog.cpp','src/hive/HiveIntegrationTest.cpp','src/online/OnlineScreenLifetimeTest.cpp','src/online/screens/BuildingLibraryScreen.cpp']
 if deps and not was_rechecked: print('needs recheck',row['path'],deps,flush=True)
 return {'source':row['path'],'changed_header_dependencies':deps,'final_recheck':was_rechecked,'result':'rechecked' if was_rechecked else 'source and consumed staged headers unchanged from completed immutable sweep'}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(check,cur['checks']))
(B/'syntax-reuse-proof.json').write_text(json.dumps({'result':'passed','changed_staged_headers_since_initial_sweep':changed,'method':'Actual compiler -MM inventories on final consistent header shadow; changed-header consumers must have final recheck, reused consumers retain identical source and consumed staged headers','sources':rows},indent=2)+'\n');print('syntax reuse proof passed',len(rows))
