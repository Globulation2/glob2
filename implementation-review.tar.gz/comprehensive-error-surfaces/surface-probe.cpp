#include "ui/DiagnosticText.h"
#include "ui/HiveReportText.h"
#include <ui/Element.h>
#include "ui/UIRecordingCanvas.h"
#include <cassert>
#include <iostream>
namespace fe=GAGGUI::ui;
class ScriptCursorCaption : public fe::Node
{
	std::function<std::string()> current;
	std::string format;
	std::size_t digits;
  public:
	ScriptCursorCaption(std::function<std::string()> current, std::string format, std::size_t digits)
		: current(std::move(current)), format(std::move(format)), digits(digits) { key = "script/cursor"; }
	std::string accessibleText() const override { return current(); }
	fe::Size measure(const fe::LayoutContext &ctx, fe::Constraints constraints) override
	{
		int width = ctx.text.width(fe::FontRole::Caption, current());
		std::string reserve = current();
		for (char digit = '0'; digit <= '9'; ++digit)
		{
			const std::string bound(digits, digit);
			const auto text = Glob2UI::literalSurfaceFormat(format, {bound, bound});
			if (ctx.text.width(fe::FontRole::Caption, text) > width) { width = ctx.text.width(fe::FontRole::Caption, text); reserve = text; }
		}
		const auto block = fe::layoutText(ctx.text, fe::FontRole::Caption, reserve, std::min(width, constraints.maxW), 0);
		return constraints.clamp({block.width, block.height});
	}
	void paint(fe::Frame &frame) override
	{
		int y = bounds.y;
		for (const auto &line : fe::wrapText(frame.layout.text, fe::FontRole::Caption, current(), bounds.w))
		{
			frame.canvas.text({bounds.x, y}, fe::FontRole::Caption, line, frame.layout.theme.palette.muted);
			y += frame.layout.text.lineHeight(fe::FontRole::Caption);
		}
	}
};

int main(){
 auto *table=GAGCore::Toolkit::getStringTable();
 table->values["[script compilation success]"]="FIXTURE Compilation success";
table->values["[script error at %0:%1: %2]"]="FIXTURE Error at %0:%1: %2";
table->values["[script compilation failure %0:%1:(%2):%3]"]="FIXTURE Compilation failure : %0:%1:(%2):%3";
table->values["[script compilation failed %0]"]="FIXTURE Compilation failed: %0";
table->values["[script loading failed %0]"]="FIXTURE Loading script from %0 failed";
table->values["[script saving failed %0]"]="FIXTURE Saving script to %0 failed";
table->values["[script line %0 column %1]"]="FIXTURE Line: %0 Col: %1";
table->values["[game stopped %0]"]="FIXTURE Game stopped: %0";
table->values["[game stopped script help]"]="FIXTURE Review the embedded JavaScript and its resource use before restarting this game.";
table->values["[missing map generator %0]"]="FIXTURE Missing map generator: %0. A native landscape was selected.";
table->values["[hive standing order paused]"]="FIXTURE A standing order needs attention and has been paused.";
table->values["[hive connection changed orders paused]"]="FIXTURE The connection changed. Review your paused standing orders before resuming.";
table->values["[hive standing order fresh instruction]"]="FIXTURE A standing order needs a fresh instruction after reconnecting. You can cancel it or ask the commander to replace it.";
table->values["[hive order confirmation failed]"]="FIXTURE An order could not be confirmed. Review your standing orders before resuming.";
table->values["[hive previous order sending]"]="FIXTURE Your previous order is still sending. This message has been kept; open the commander to send it again.";
table->values["[hive order received %0]"]="FIXTURE Order received: %0";
table->values["[hive order not confirmed]"]="FIXTURE Order not confirmed. Open the commander to retry; your message has been kept.";
table->values["[hive standing order update failed]"]="FIXTURE Standing order update failed. Your order is paused locally; retry the control.";
table->values["[Give at least one terrain type a nonzero weight.]"]="Задайте ненулево тегло на поне един вид терен.";
 const std::string generic=Glob2UI::onlineProblemText("");
 Glob2UI::DiagnosticText state;
 for(int i=0;i<20;++i) assert(state("RAW_REPEAT_DIAGNOSTIC")==generic);
 assert(state("RAW_CHANGED_DIAGNOSTIC")==generic);
 assert(state("").empty()); assert(state("RAW_REPEAT_DIAGNOSTIC")==generic);
 assert(state("Give at least one terrain type a nonzero weight.")==table->values.at("[Give at least one terrain type a nonzero weight.]"));
 const Glob2UI::PresentedError marked("presented specific", "RAW_MARKED_DIAGNOSTIC");
 for(int i=0;i<20;++i) assert(state.exception(marked)=="presented specific");
 assert(Glob2UI::literalSurfaceFormat("%1 / %0 / %1",{"user %1 {p0}","literal %0"})=="literal %0 / user %1 {p0} / literal %0");
 for(const auto &key: {"[hive standing order paused]","[hive connection changed orders paused]","[hive standing order fresh instruction]","[hive order confirmation failed]","[hive previous order sending]","[hive order not confirmed]","[hive standing order update failed]"}) assert(table->values.contains(key));
 const std::string localText="Order received: user %0 {p0} <tag>";
 Hive::Report remote(localText); assert(Glob2UI::hiveReportText(remote)==localText);
 Hive::Report local(localText,Hive::ReportSource::OrderReceived,"user %0 {p0} <tag>");
 assert(Glob2UI::hiveReportText(local)=="FIXTURE Order received: user %0 {p0} <tag>"); assert(local.text==localText);
 assert(Glob2UI::hiveReportText(Hive::Report("Stopped"))=="Stopped");
 for(const auto &locale:{"en","fr","bg-XX"}) {table->locale=locale;assert(state("RAW_NON_BG")=="RAW_NON_BG");assert(Glob2UI::hiveReportText(local)==localText);}
 table->locale="bg";
 // Exercise the actual measured caption node through production wrap/measure APIs.
 int cases=0;
 for(const int width:{800,390,240}) for(const int growth:{1,2}) {
  fe::FixedTextMeasurer measurer(8*growth,16*growth);fe::Theme theme;fe::Metrics metrics;
  auto p=fe::Presentation::forSurface(width,900);fe::LayoutContext ctx{p,theme,metrics,measurer};
  std::string caption="FIXTURE localized line 123456 column 987654";
  ScriptCursorCaption node([&](){return caption;},"FIXTURE localized line %0 column %1",6);
  const auto size=node.measure(ctx,{0,0,width,900});assert(size.w<=width);assert(size.h>=measurer.lineHeight(fe::FontRole::Caption));
  node.arrange(ctx,{0,0,size.w,size.h});glob2test::RecordingCanvas canvas({width,900},measurer);fe::Frame frame{canvas,ctx};node.paint(frame);
  assert(!canvas.texts.empty());for(const auto &[at,text]:canvas.texts){assert(at.x+measurer.width(fe::FontRole::Caption,text)<=size.w);assert(at.y+measurer.lineHeight(fe::FontRole::Caption)<=size.h);}
  ++cases;
 }
 std::cout<<"diagnostic cache, exact native lookup, marked API/native text, non-BG, provenance/UGC and "<<cases<<" measured cursor layout cases passed\n";
}
