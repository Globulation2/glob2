from pathlib import Path
import json,subprocess,time,hashlib,shlex
R=Path.cwd();B=R/'artifacts/bulgarian/comprehensive-error-surfaces';S=B/'stage';T=B/'probe-includes';T.mkdir(exist_ok=True)
(T/'StringTable.h').write_text('''#pragma once
#include <map>
#include <string>
namespace GAGCore { struct StringTable { std::string locale="bg"; std::map<std::string,std::string> values; bool doesStringExist(const std::string &key) {return key=="[language-code]"||values.contains(key);} std::string getString(const std::string &key) {return key=="[language-code]"?locale:values.at(key);} }; }
''')
(T/'Toolkit.h').write_text('''#pragma once
#include "StringTable.h"
namespace GAGCore { struct Toolkit { static StringTable *getStringTable(){static StringTable value; return &value;} }; }
''')
script=S/'src/scripting/map/ScriptEditorScreen.cpp';s=script.read_text();cursor=s[s.index('class ScriptCursorCaption'):s.index('bool loadText(')]
entries=json.loads((B/'proposed-native-sources.json').read_text())['entries'];bindings=[]
for entry in entries:
 # Synthetic English-only fixtures test key binding without inventing translations.
 bindings.append('table->values['+json.dumps(entry['key'])+']='+json.dumps('FIXTURE '+entry['value'])+';')
lines=(R/'data/texts.bg.txt').read_text().splitlines();native=dict(zip(lines[::2],lines[1::2]));known='Give at least one terrain type a nonzero weight.'
bindings.append('table->values['+json.dumps('['+known+']')+']='+json.dumps(native['['+known+']'],ensure_ascii=False)+';')
cpp='''#include "ui/DiagnosticText.h"
#include "ui/HiveReportText.h"
#include <ui/Element.h>
#include "ui/UIRecordingCanvas.h"
#include <cassert>
#include <iostream>
namespace fe=GAGGUI::ui;
CURSOR
int main(){
 auto *table=GAGCore::Toolkit::getStringTable();
 BINDINGS
 const std::string generic=Glob2UI::onlineProblemText("");
 Glob2UI::DiagnosticText state;
 for(int i=0;i<20;++i) assert(state("RAW_REPEAT_DIAGNOSTIC")==generic);
 assert(state("RAW_CHANGED_DIAGNOSTIC")==generic);
 assert(state("").empty()); assert(state("RAW_REPEAT_DIAGNOSTIC")==generic);
 assert(state("Give at least one terrain type a nonzero weight.")==table->values.at("[Give at least one terrain type a nonzero weight.]"));
 const Glob2UI::PresentedError marked("presented specific", "RAW_MARKED_DIAGNOSTIC");
 for(int i=0;i<20;++i) assert(state.exception(marked)=="presented specific");
 assert(Glob2UI::literalSurfaceFormat("%1 / %0 / %1",{"user %1 {p0}","literal %0"})=="literal %0 / user %1 {p0} / literal %0");
 for(const auto &key: {"[hive standing order paused]","[hive connection changed orders paused]","[hive standing order fresh instruction]","[hive order confirmation failed]","[hive previous order sending]","[hive order not confirmed]","[hive standing order update failed]"}) assert(table->values.contains(key));
 const std::string localText="Order received: user %0 {p0} <tag>";
 Hive::Report remote(localText); assert(Glob2UI::hiveReportText(remote)==localText);
 Hive::Report local(localText,Hive::ReportSource::OrderReceived,"user %0 {p0} <tag>");
 assert(Glob2UI::hiveReportText(local)=="FIXTURE Order received: user %0 {p0} <tag>"); assert(local.text==localText);
 assert(Glob2UI::hiveReportText(Hive::Report("Stopped"))=="Stopped");
 for(const auto &locale:{"en","fr","bg-XX"}) {table->locale=locale;assert(state("RAW_NON_BG")=="RAW_NON_BG");assert(Glob2UI::hiveReportText(local)==localText);}
 table->locale="bg";
 // Exercise the actual measured caption node through production wrap/measure APIs.
 int cases=0;
 for(const int width:{800,390,240}) for(const int growth:{1,2}) {
  fe::FixedTextMeasurer measurer(8*growth,16*growth);fe::Theme theme;fe::Metrics metrics;
  auto p=fe::Presentation::forSurface(width,900);fe::LayoutContext ctx{p,theme,metrics,measurer};
  std::string caption="FIXTURE localized line 123456 column 987654";
  ScriptCursorCaption node([&](){return caption;},"FIXTURE localized line %0 column %1",6);
  const auto size=node.measure(ctx,{0,0,width,900});assert(size.w<=width);assert(size.h>=measurer.lineHeight(fe::FontRole::Caption));
  node.arrange(ctx,{0,0,size.w,size.h});glob2test::RecordingCanvas canvas({width,900},measurer);fe::Frame frame{canvas,ctx};node.paint(frame);
  assert(!canvas.texts.empty());for(const auto &[at,text]:canvas.texts){assert(at.x+measurer.width(fe::FontRole::Caption,text)<=size.w);assert(at.y+measurer.lineHeight(fe::FontRole::Caption)<=size.h);}
  ++cases;
 }
 std::cout<<"diagnostic cache, exact native lookup, marked API/native text, non-BG, provenance/UGC and "<<cases<<" measured cursor layout cases passed\\n";
}
'''.replace('CURSOR',cursor).replace('BINDINGS','\n'.join(bindings))
(B/'surface-probe.cpp').write_text(cpp)
cmd=['g++','-std=c++20','-O0','-g0','-fmax-errors=3','-I'+str(T),'-I'+str(S/'src'),'-I'+str(R/'src'),'-I'+str(R/'src/online'),'-I'+str(R/'src/app'),'-I'+str(R/'src/game'),'-I'+str(R/'third_party/nlohmann-json/include'),'-I'+str(R/'libgag/include'),'-I'+str(R/'artifacts/bulgarian/sdl3/prefix/include'),'-I'+str(R/'build/linux/client/debug/dev-dev_fast-true-linker-auto/include'),'-I'+str(R/'artifacts/bulgarian/native-error-bridge/stage/include'),str(B/'surface-probe.cpp'),str(R/'src/online/ApiErrorText.cpp'),str(R/'src/online/PlatformProtocol.cpp'),str(R/'libgag/src/ui/Element.cpp'),str(R/'libgag/src/ui/TextLayout.cpp'),'-o',str(B/'surface-probe')]
with (B/'probe-compile.log').open('w') as log: subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
with (B/'probe.log').open('w') as log: subprocess.run([str(B/'surface-probe')],stdout=log,stderr=subprocess.STDOUT,check=True)
log=(B/'probe.log').read_text();assert log.count('RAW_REPEAT_DIAGNOSTIC')==2;assert log.count('RAW_CHANGED_DIAGNOSTIC')==1;assert log.count('RAW_MARKED_DIAGNOSTIC')==1
(B/'probe-results.json').write_text(json.dumps({'result':'passed','command':cmd,'scope':'Actual staged diagnostic/Hive helpers and extracted actual cursor node; fake Toolkit/StringTable and screen state, real protocol/catalog/presenter and production text layout/element code. No full UI harness execution.','new_key_values':'Synthetic English fixture values only; no translations authored','source_sha256':{str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [script,S/'src/ui/DiagnosticText.h',S/'src/ui/HiveReportText.h',S/'src/hive/HiveReport.h']}},indent=2)+'\n')
print('surface probe passed')
