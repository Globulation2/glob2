from pathlib import Path
import json,subprocess,time,shlex,hashlib
R=Path.cwd();B=R/'artifacts/bulgarian/comprehensive-error-surfaces';S=B/'stage'
line=next(l for l in (R/'artifacts/bulgarian/native-build-027a.log').read_text().splitlines() if 'g++ -o ' in l and l.endswith('src/ui/settings/SettingsScreenCustomAIs.cpp'))
a=shlex.split(line);a=a[a.index('g++')+1:];i=a.index('-o');del a[i:i+2];a.remove('-c');a=a[:-1];a=[x for x in a if not x.startswith('-fdebug-prefix-map=')]
paths=sorted(p for p in S.rglob('*.cpp'));dirs=sorted({p.parent for p in S.rglob('*.h')});checks=json.loads((B/'syntax-results-initial.json').read_text())['checks']
checks=[c for c in checks if c['exit_code']==0]
for p in paths:
 name=p.relative_to(S).as_posix()
 if any(c['path']==name and c['source_sha256']==hashlib.sha256(p.read_bytes()).hexdigest() for c in checks):continue
 command=['g++','-fsyntax-only','-fmax-errors=3','-I'+str(S/'src'),*['-I'+str(d) for d in dirs],*['-I'+str(R/d.relative_to(S)) for d in dirs],'-I'+str(R/'test/support'),'-I'+str(R/'test'),*a]
 if p.name.endswith('Test.cpp'):command+=['-fno-access-control']
 command+=[str(p)];t=time.monotonic();log='syntax-'+p.stem+'.log';before=hashlib.sha256(p.read_bytes()).hexdigest()
 with (B/log).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 checks.append({'path':name,'source_sha256':before,'command':command,'exit_code':r.returncode,'seconds':round(time.monotonic()-t,2),'log':log});(B/'syntax-results.json').write_text(json.dumps({'checks':checks},indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:break
