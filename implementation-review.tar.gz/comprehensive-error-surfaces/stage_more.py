from pathlib import Path
import json,hashlib,re
R=Path.cwd();B=R/'artifacts/bulgarian/comprehensive-error-surfaces';S=B/'stage';data=json.loads((B/'baseline.json').read_text());base=data['files']
def copy(rel):
 p=S/rel
 if not p.exists():
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/rel).read_bytes());base[rel]=hashlib.sha256((R/rel).read_bytes()).hexdigest()
 return p
def edit(rel,fn):
 p=copy(rel);old=p.read_text();new=fn(old);assert new!=old,rel;p.write_text(new)
# Fix aggregate declarations where the original fields share a declaration.
edit('src/game/screens/CustomGameScreen.h',lambda t:t.replace('\tstd::string username, source, message;', '\tGlob2UI::DiagnosticText validationError, mapDownloadError;\n\tstd::string username, source, message;').replace('message = "Could not launch this map. Your setup is retained; try again.";','message = Glob2UI::bulgarianErrorLocale() ? Glob2UI::nativeSurfaceText("[Could not launch this map. Your setup is retained; try again.]", "Could not launch this map. Your setup is retained; try again.") : "Could not launch this map. Your setup is retained; try again.";'))
edit('src/game/screens/MatchStartScreen.h',lambda t:t.replace('\tint lastStep = -1;', '\tGlob2UI::DiagnosticText failureText;\n\tint lastStep = -1;'))
edit('src/map/editor/screens/NewMapScreen.h',lambda t:t.replace('\tstd::string error;', '\tGlob2UI::DiagnosticText validationError;\n\tstd::string error;'))
edit('src/game/screens/CustomGameScreen.cpp',lambda t:t.replace(': catalogDownload->error();', ': mapDownloadError(catalogDownload->error());').replace('const std::string note =','std::string note =',1).replace('\n\tbool ready = error.empty();','\n\tif (Glob2UI::bulgarianErrorLocale() && error == "Shared control needs a free controller slot (maximum %0).")\n\t\tnote = FormattableString(note).arg(Team::MAX_COUNT);\n\tbool ready = error.empty();'))
# Session failure fixed wrapper/remedy, preserving the original machine diagnostic bridge.
def session(t):
 t='#include "ui/DiagnosticText.h"\n'+t
 start=t.index('\t\tstack.push(std::make_unique<MessageScreen>(std::string("Game stopped: ")');end=t.index('\n\t}\n}',start)
 old=t[start:end]
 new='''		const std::string raw = failure.what();
		Glob2UI::DiagnosticText presenter;
		const auto message = Glob2UI::bulgarianErrorLocale()
			? Glob2UI::literalSurfaceFormat(Glob2UI::nativeSurfaceText("[game stopped %0]", "Game stopped: %0"), {presenter(raw)}) + "\\n" +
				Glob2UI::nativeSurfaceText("[game stopped script help]", "Review the embedded JavaScript and its resource use before restarting this game.")
			: "Game stopped: " + raw + "\\nReview the embedded JavaScript and its resource use before restarting this game.";
		stack.push(std::make_unique<MessageScreen>(message,
			std::vector<std::string>{Glob2UI::bulgarianErrorLocale() ? Glob2UI::nativeSurfaceText("[ok]", "Ok") : "OK"}),
			[this](GAGGUI::Screen &, int) { endExecute(0); });'''
 return t[:start]+new+t[end:]
edit('src/game/screens/GameSessionScreen.cpp',session)
# Script editor primary status remains specific; raw diagnostics logged at compile/commit event.
edit('src/scripting/map/ScriptEditorScreen.h',lambda t:'#include "ui/DiagnosticText.h"\n'+t.replace('\tstd::string script, compilation;', '\tGlob2UI::DiagnosticText compilationDiagnostic;\n\tstd::string script, compilation;'))
def script(t):
 t=t.replace('compilation = "Compilation success";', 'compilation = Glob2UI::bulgarianErrorLocale() ? Glob2UI::nativeSurfaceText("[script compilation success]", "Compilation success") : "Compilation success";')
 t=t.replace('FormattableString("Error at %0:%1: %2")','FormattableString(Glob2UI::bulgarianErrorLocale() ? Glob2UI::nativeSurfaceText("[script error at %0:%1: %2]", "Error at %0:%1: %2") : "Error at %0:%1: %2")').replace('.arg(error.getMessage());','.arg(compilationDiagnostic(error.getMessage()));')
 t=t.replace('FormattableString("Compilation failure : %0:%1:(%2):%3")','FormattableString(Glob2UI::bulgarianErrorLocale() ? Glob2UI::nativeSurfaceText("[script compilation failure %0:%1:(%2):%3]", "Compilation failure : %0:%1:(%2):%3") : "Compilation failure : %0:%1:(%2):%3")').replace('.arg(er.getErrorString());','.arg(compilationDiagnostic(er.getErrorString()));')
 # Uncoordinated diagnostic paths use precise compilation-failed wrapper, not Done.
 for raw in ['error.what()', 'error.getMessage()', 'error.getErrorString()']:
  t=t.replace('compilation = '+raw+';', 'compilation = Glob2UI::bulgarianErrorLocale() ? Glob2UI::literalSurfaceFormat(Glob2UI::nativeSurfaceText("[script compilation failed %0]", "Compilation failed: %0"), {compilationDiagnostic('+raw+')}) : '+raw+';')
 for action,key in [('Loading script from','loading'),('Saving script to','saving')]:
  old=f'FormattableString("{action} %0 failed")';new=f'FormattableString(Glob2UI::bulgarianErrorLocale() ? Glob2UI::nativeSurfaceText("[script {key} failed %0]", "{action} %0 failed") : "{action} %0 failed")';t=t.replace(old,new)
 # Source-data placeholders must never be recursively interpreted (filenames too).
 t=t.replace('''auto position =
		fe::canvas("script/cursor", {p.pt(120), p.pt(16)},
				   [this](fe::Canvas &c, fe::Rect r, const fe::Frame &frame)
				   {''','''const auto cursorTemplate = Glob2UI::bulgarianErrorLocale()
		? Glob2UI::nativeSurfaceText("[script line %0 column %1]", "Line: %0 Col: %1") : "Line: %0 Col: %1";
	auto cursorText = [this, cursorTemplate]()
	{''')
 old='''					   c.text({r.x, r.y}, fe::FontRole::Caption,
							  FormattableString("Line: %0 Col: %1").arg(line).arg(column),
							  frame.layout.theme.palette.muted);
				   });'''
 new='''		return Glob2UI::literalSurfaceFormat(cursorTemplate, {std::to_string(line), std::to_string(column)});
	};
	// Reserve measured localized text for the largest possible coordinates, and
	// wrap in compact/enlarged layouts instead of clipping a fixed 120px canvas.
	auto position = std::make_shared<ScriptCursorCaption>(cursorText, cursorTemplate,
		std::to_string(script.size() + 1).size());'''
 assert old in t;t=t.replace(old,new)
 t=t.replace('''auto status = fe::row({fe::expanded(fe::label(compilation, resultStyle)), position},
						  {p.pt(8), fe::CrossAlign::Center});''','''auto status = p.compact() || p.textGrowth > 1.2
		? fe::column({fe::label(compilation, resultStyle), position}, {p.pt(4)})
		: fe::row({fe::expanded(fe::label(compilation, resultStyle)), position}, {p.pt(8), fe::CrossAlign::Center});''')
 # A measured node preserves the original live cursor calculation at every paint.
 pos=t.index('bool loadText(')
 node='''class ScriptCursorCaption : public fe::Node
{
	std::function<std::string()> current;
	std::string format;
	std::size_t digits;
  public:
	ScriptCursorCaption(std::function<std::string()> current, std::string format, std::size_t digits)
		: current(std::move(current)), format(std::move(format)), digits(digits) { key = "script/cursor"; }
	std::string accessibleText() const override { return current(); }
	fe::Size measure(const fe::LayoutContext &ctx, fe::Constraints constraints) override
	{
		int width = ctx.text.width(fe::FontRole::Caption, current());
		std::string reserve = current();
		for (char digit = '0'; digit <= '9'; ++digit)
		{
			const std::string bound(digits, digit);
			const auto text = Glob2UI::literalSurfaceFormat(format, {bound, bound});
			if (ctx.text.width(fe::FontRole::Caption, text) > width) { width = ctx.text.width(fe::FontRole::Caption, text); reserve = text; }
		}
		const auto block = fe::layoutText(ctx.text, fe::FontRole::Caption, reserve, std::min(width, constraints.maxW), 0);
		return constraints.clamp({block.width, block.height});
	}
	void paint(fe::Frame &frame) override
	{
		int y = bounds.y;
		for (const auto &line : fe::wrapText(frame.layout.text, fe::FontRole::Caption, current(), bounds.w))
		{
			frame.canvas.text({bounds.x, y}, fe::FontRole::Caption, line, frame.layout.theme.palette.muted);
			y += frame.layout.text.lineHeight(fe::FontRole::Caption);
		}
	}
};
'''
 return t[:pos]+node+t[pos:]
edit('src/scripting/map/ScriptEditorScreen.cpp',script)
(B/'baseline.json').write_text(json.dumps(data,indent=2)+'\n')
