from pathlib import Path
import json,hashlib,re
R=Path.cwd();B=R/'artifacts/bulgarian/comprehensive-error-surfaces';S=B/'stage';data=json.loads((B/'baseline.json').read_text());base=data['files']
def cp(rel):
 p=S/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/rel).read_bytes());base[rel]=hashlib.sha256((R/rel).read_bytes()).hexdigest()
 return p
def edit(rel,f):
 p=cp(rel);t=p.read_text();u=f(t);assert t!=u,rel;p.write_text(u)
# UI-only provenance record; text remains the exact old diagnostic/user report.
# All producers explicitly choose a local tag or Remote; there is no text inference.
p=S/'src/hive/HiveReport.h';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('''// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <string>
#include <utility>
namespace Hive
{
enum class ReportSource
{
	Remote, StandingOrderPaused, ConnectionChanged, FreshInstruction,
	ConfirmationFailed, PreviousSending, OrderReceived, OrderNotConfirmed,
	UpdateFailed, Stopped, StopFailed
};
struct Report
{
	std::string text;
	ReportSource source = ReportSource::Remote;
	std::string parameter;
	Report(std::string text, ReportSource source = ReportSource::Remote, std::string parameter = {})
		: text(std::move(text)), source(source), parameter(std::move(parameter)) {}
	Report(const char *text) : text(text) {}
};
} // namespace Hive
''')
edit('src/hive/HiveClient.h',lambda t:t.replace('#include "HiveWorker.h"','#include "HiveWorker.h"\n#include "HiveReport.h"').replace('std::vector<std::string> reports;','std::vector<Report> reports;'))
# Bind tags by exact source literal *at each producer*, never at runtime display.
entries=json.loads((B/'proposed-native-sources.json').read_text())['entries'][10:]
tags=['StandingOrderPaused','ConnectionChanged','FreshInstruction','ConfirmationFailed','PreviousSending','OrderReceived','OrderNotConfirmed','UpdateFailed']
def hive(t):
 pattern=re.compile(r'reports\.push_back\((.*?)\);',re.S)
 def repl(m):
  expr=m[1]
  if expr=='b.at("text")':return 'reports.emplace_back(b.at("text").template get<std::string>());'
  if expr=='controlStatus["commander"]':return 'reports.emplace_back(controlStatus["commander"], r.ok ? ReportSource::Stopped : ReportSource::StopFailed);'
  if expr=='"Order received: " + text':return 'reports.emplace_back("Order received: " + text, ReportSource::OrderReceived, text);'
  literals=re.findall(r'"((?:[^"\\]|\\.)*)"',expr);joined=''.join(literals)
  for entry,tag in zip(entries,tags):
   if joined==entry['value']:return 'reports.emplace_back('+expr+', ReportSource::'+tag+');'
  raise ValueError('unclassified '+expr)
 return pattern.sub(repl,t)
edit('src/hive/HiveClient.cpp',hive)
# A reusable UI presentation helper with explicit source selection is independently testable.
p=S/'src/ui/HiveReportText.h';p.parent.mkdir(parents=True,exist_ok=True)
values=[]
for entry,tag in zip(entries,tags):values.append((tag,entry['key'],entry['value']))
values += [('Stopped','[hive stopped]','Stopped'),('StopFailed','[hive stop failed]','Stop failed; retry the stop shortcut')]
text='''// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "ui/DiagnosticText.h"
#include "hive/HiveReport.h"
namespace Glob2UI
{
inline std::string hiveReportText(const Hive::Report &report)
{
	// Remote/commander/user content is data, even when identical to a local report.
	if (!bulgarianErrorLocale() || report.source == Hive::ReportSource::Remote) return report.text;
	switch (report.source)
	{
'''
for tag,key,english in values:
 expr='nativeSurfaceText('+json.dumps(key)+', '+json.dumps(english)+')'
 if tag=='OrderReceived':expr='literalSurfaceFormat('+expr+', {report.parameter})'
 text+='\tcase Hive::ReportSource::'+tag+': return '+expr+';\n'
text+='''	case Hive::ReportSource::Remote: return report.text;
	}
	return report.text;
}
} // namespace Glob2UI
''';p.write_text(text)
edit('src/hive/HiveDialog.cpp',lambda t:'#include "ui/HiveReportText.h"\n'+t.replace('controlStatusText(client->reports[client->reports.size() - 1 - i])','Glob2UI::hiveReportText(client->reports[client->reports.size() - 1 - i])').replace('controlStatusText(client->reports.back())','Glob2UI::hiveReportText(client->reports.back())'))
edit('src/hive/HiveIntegrationTest.cpp',lambda t:t.replace('client->reports.back().find("still sending")','client->reports.back().text.find("still sending")'))
# Local transport diagnostics remain raw; UI cache objects are already staged.
p=S/'src/map/editor/screens/NewMapScreen.h';t=p.read_text().replace('\tGlob2UI::DiagnosticText validationError;\n\tGlob2UI::DiagnosticText validationError;','\tGlob2UI::DiagnosticText validationError;');p.write_text(t)
p=S/'platform/apps/web/src/pages/generatorStudio/Preview.tsx';t=p.read_text().replace('}, [run]);','}, [run, locale]);');p.write_text(t)
(B/'baseline.json').write_text(json.dumps(data,indent=2)+'\n')
