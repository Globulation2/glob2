from pathlib import Path
import os,json,sys,subprocess,time,threading,concurrent.futures,shutil
from run_phase import R,B,guard,environment,write,sha
binary=Path(sys.argv[1]).resolve();rev=sys.argv[2];pid=int(sys.argv[3]);guard(binary,rev);base=B/'native-captures/v5-final/ui';original=base/'execution.json'
assert Path(f'/proc/{pid}/cwd').resolve()==R
cmdline=Path(f'/proc/{pid}/cmdline').read_bytes();assert b'after_patch.py\x00ui\x00'in cmdline
jobs=[]
for view,w,h in [('desktop',1280,1024),('phone',390,844)]:
 for growth in [100,150]:
  jobs.extend([(f'{view}-{growth}-script-editor',view,w,h,growth,'script-editor',[]),(f'{view}-{growth}-statistics',view,w,h,growth,'game',['statistics'])])
 jobs.append((view+'-new-map',view,w,h,100,'screen',['new-map']))
prior=json.loads(original.read_text());done={j['tag']for j in prior['jobs']};active=[j for j in jobs if j[0]not in done and (base/j[0]).exists()];assert len(active)==1,active
pending=[j for j in jobs if j[0]not in done and j not in active];assert pending
# Reserve earliest unstarted output atomically. The old launcher must stop
# before launching it, without signaling or interrupting its current child.
first=base/pending[0][0];first.mkdir();(first/'.parallel-reservation').write_text('Controlled orchestration reservation; no prior capture attempt.\n')
for job in pending[1:]:
 p=base/job[0];p.mkdir();(p/'.parallel-reservation').write_text('Controlled orchestration reservation; no prior capture attempt.\n')
record={'scope':'Bounded3 UI captures; current sequential child untouched; reserved next fresh output causes intentional launcher guard exit, not a product/storage failure.','original_pid':pid,'completed_before_transition':list(done),'current_capture_untouched':active[0][0],'reserved_pending':[j[0]for j in pending],'producer_revision':rev,'binary_sha256':sha(binary),'jobs':[]};lock=threading.Lock();write(base/'parallel-transition.json',record)
def alive():
 try:
  state=Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1][0]
  return state!='Z'
 except FileNotFoundError:return False
def task(job,wait_for_original=False):
 if wait_for_original:
  deadline=time.monotonic()+1000
  while alive():
   assert time.monotonic()<deadline,'Sequential original did not finish current child'
   time.sleep(1)
 tag,view,w,h,growth,mode,args=job;out=base/tag;assert set(p.name for p in out.iterdir())=={'.parallel-reservation'}
 (out/'.parallel-reservation').unlink();env=environment(out/'profile',view=='phone',growth);cmd=['xvfb-run','-a','-s','-screen 0 1600x1400x24',str(binary),mode,str(R),str(B/'kit-v4/render-input/bg'),str(out),str(w),str(h)]+args;print('START parallel',tag,flush=True);start=time.monotonic()
 with (out/'capture.log').open('w')as log:
  try:rc=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900).returncode
  except subprocess.TimeoutExpired:rc='timeout'
 row={'tag':tag,'command':cmd,'returncode':rc,'seconds':round(time.monotonic()-start,2),'text_size_percent':growth}
 with lock:record['jobs'].append(row);write(base/'parallel-transition.json',record)
 print('END parallel',tag,rc,flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
 futures=[]
 # Reserve the third worker until old current child/launcher has exited.
 for i,j in enumerate(pending):futures.append(pool.submit(task,j,i==2))
 rows=[f.result()for f in futures]
while alive():time.sleep(1)
old=json.loads(original.read_text());assert all(j['returncode']==0 for j in old['jobs']);assert len(old['jobs'])==len(done)+1;assert old['jobs'][-1]['tag']==active[0][0]
shutil.copyfile(original,base/'execution-sequential-prefix.json');combined=old['jobs']+rows;assert len(combined)==10 and len({j['tag']for j in combined})==10
order={j[0]:i for i,j in enumerate(jobs)};combined.sort(key=lambda j:order[j['tag']]);result=dict(old,jobs=combined,orchestration='Sequential completed prefix plus bounded3 parallel remaining; see parallel-transition.json. Original next-output guard exit is expected and retained separately.');write(original,result)
record['final_capture_jobs']=10;record['successful_capture_jobs']=sum(j['returncode']==0 for j in combined);write(base/'parallel-transition.json',record);print('COMPLETE',record['successful_capture_jobs'],'/10',flush=True)
raise SystemExit(0 if all(j['returncode']==0 for j in combined)else 1)
