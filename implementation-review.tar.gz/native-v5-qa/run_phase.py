"""Final-v5 QA runner. Preparation only until final clean source and binary handoff.
Usage: python3 .../run_phase.py engine|unit BINARY --handoff REVISION
API503 runner is separate api_notices.py with the same explicit handoff guard.
"""
from pathlib import Path
import sys,json,subprocess,os,time,hashlib,fnmatch,gzip
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';OUT=B/'native-captures/v5-final'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def guard(binary,revision):
 assert revision==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'Handoff revision mismatch'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip(),'Final source must be clean'
 frozen=json.loads((B/'v5-frozen-inputs.json').read_text());assert frozen['revision']==revision
 assert binary.is_file();assert revision.encode() in binary.read_bytes(),'Binary lacks this fresh compiled revision; no old producer execution';return frozen

def environment(profile,phone=False,growth=100):
 user=profile/'user';user.mkdir(parents=True,exist_ok=True);(user/'preferences.txt').write_text(f'textSizePercent={growth}\nlanguage=bg\n')
 env=dict(os.environ,LD_LIBRARY_PATH=str(B/'sdl3/prefix/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''),GLOB2_USER_DATA_DIR=str(user),XDG_DATA_HOME=str(profile/'data'),XDG_CONFIG_HOME=str(profile/'config'),XDG_CACHE_HOME=str(profile/'cache'),SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='x11',GLOB2_RENDERER='software')
 if phone:env['GLOB2_MOBILE_UI']='1'
 else:env.pop('GLOB2_MOBILE_UI',None)
 return env

def run_tests(binary,kind,revision):
 guard(binary,revision);out=B/('native-tests-v5-'+kind);assert not out.exists(),'Do not overwrite earlier test evidence';out.mkdir()
 filters=['ApiErrorText/*','PlatformProtocol/*','PlatformClient/*']if kind=='unit'else['ScriptEditor/*','HiveMindIntegration/*','HiveMindScheduler/*','HiveMindReliability/*','HiveMindPresentation/*','OnlineScreenLifetime/*','FontKerning/*','SystemLanguage/*','SettingsAILibrary/*','GUIInteractionCoverage/Bulgarian*','CommunityMusicUI/API failures clear queued installs*','GameGUITouch/phone navigation*','GameGUITouch/live statistics hide post-game probability*','GUIInteractionCoverage/statistics topics history and overlays*','Settings/*all categories with enlarged text*','Settings/*software rendering*']
 build=R/'build/linux/client/debug/dev-dev_fast-true-linker-auto'
 assert binary.resolve()==(build/'test'/('glob2-'+kind+'-tests')).resolve(),'Use actual final linked test binary'
 cmd=['xvfb-run','-a','-s','-screen 0 1600x1400x24','python3','test/run_tests.py','--build-dir',str(build),'--binary',kind,'-j','2','--display-jobs','1','--timeout','600','--junit',str(out/'junit.xml'),'--artifacts',str(out),'--write-inventory',str(out/'inventory.json'),'--write-timings',str(out/'timings.json')]
 for f in filters:cmd+=['--filter',f]
 env=dict(os.environ,XDG_SESSION_TYPE='x11',LD_LIBRARY_PATH=str(B/'sdl3/prefix/lib')+':'+os.environ.get('LD_LIBRARY_PATH',''))
 for k in ['WAYLAND_DISPLAY','WAYLAND_SOCKET','SDL_VIDEODRIVER','SDL_VIDEO_DRIVER']:env.pop(k,None)
 record={'revision':revision,'binary':str(binary),'binary_sha256':sha(binary),'command':cmd,'filters':filters};write(out/'command.json',record);start=time.monotonic()
 with (out/'run.log').open('w')as log:rc=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 names=json.loads((out/'inventory.json').read_text())['assigned'];record.update(returncode=rc,seconds=round(time.monotonic()-start,2),matched_filters={f:sum(fnmatch.fnmatchcase(n,f)for n in names)for f in filters});write(out/'command.json',record);assert all(record['matched_filters'].values()),record['matched_filters'];raise SystemExit(rc)
if __name__=='__main__':
 assert len(sys.argv)==5 and sys.argv[3]=='--handoff','phase BINARY --handoff REVISION required'
 phase=sys.argv[1];binary=Path(sys.argv[2]).resolve();revision=sys.argv[4]
 if phase in ['unit','engine']:run_tests(binary,phase,revision)
 else:raise SystemExit('Unknown phase')
