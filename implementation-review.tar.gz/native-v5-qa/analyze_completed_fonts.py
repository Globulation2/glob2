from pathlib import Path
import json,hashlib,gzip,re
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';O=B/'native-captures/v5-final';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rev='8db545e53d664af3bd4abcdec7cc29f5dc2dadf3';expected='f3a86fb2950f31fa2129360f5c338b9bc9971977d068046c42e070b48c004df3';rows=[]
for view in ['desktop','phone']:
 for size in [10,13,20]:
  for scale in [1,2]:
   p=O/'generated-font'/f'{view}-{size}x{scale}'/'font-matrix.json';d=load(p);assert d['evidence_identity']['producer']['revision']==rev and d['evidence_identity']['executable_sha256']==expected
   assert d['native_keys_overridden']==1 and len(d['samples'])==1;s=d['samples'][0];assert s['key']=='[Generated]' and s['size']==size and s['scale']==scale and s['has_glyphs'];assert ''.join(l['text']for l in s['lines'])=='Генерирана'
   assert all(l['drawn_fits_width']and l['drawn_fits_height']and l['x']+l['drawn_width']/scale<=d['logical_width']and l['y']+l['drawn_height']/scale<=d['logical_height']for l in s['lines'])
   rows.append({'view':view,'size':size,'scale':scale,'manifest':str(p.relative_to(R)),'manifest_sha256':sha(p),'glyph_and_draw_canvas_pass':True,'native_catalog_sha256':d['evidence_identity']['input_metadata']['original_catalog_sha256']['native']})
assert len(rows)==12
probes=[]
for view in ['desktop','phone']:
 p=O/'probes'/view/'font-matrix.json';d=load(p);assert len(d['samples'])==6 and d['evidence_identity']['producer']['revision']==rev and d['evidence_identity']['executable_sha256']==expected
 for s in d['samples']:assert s['has_glyphs']and all(l['drawn_fits_width']and l['drawn_fits_height']for l in s['lines'])
 for png in sorted(p.parent.glob('font-*.png')):
  old=B/'native-captures/v4-final/probes'/view/png.name;assert png.read_bytes()==old.read_bytes();probes.append({'view':view,'old':str(old.relative_to(R)),'new':str(png.relative_to(R)),'byte_identical':True,'sha256':sha(png)})
assert len(probes)==12
old_runtime=load(B/'native-captures/v4-final/runtime-font-scope-audit.json');e=load(O/'generated-font/desktop-10x1/font-matrix.json')['evidence_identity'];old=load(B/'native-captures/v4-final/fonts/desktop-10x1/font-matrix.json')['evidence_identity']
for key in ['sdl_library_path','sdl_ttf_library_path','sdl_version','sdl_ttf_version','harfbuzz_version']:assert e[key]==old[key]
assert e['producer']['flags']==old['producer']['flags']and e['producer']['compiler']==old['producer']['compiler']
libproof=[];ldd=(B/'native-captures/producers/8db545/ldd.txt').read_text();resolved=dict(re.findall(r'^\s*(\S+) => (\S+)',ldd,re.M))
for item in old_runtime['libraries']:
 p=Path(resolved[item['soname']]);assert str(p.resolve())==item['resolved_path']and sha(p)==item['sha256_current_file'];libproof.append({'soname':item['soname'],'path':str(p.resolve()),'actual_hash_matches_recorded_f02':True,'sha256':sha(p)})
plan=load(O/'three-producer-font-plan.json');report={'status':'Font/render-input verification complete for8dbcandidate; actual UI and fresh engine/unit validation tracked separately.','revision':rev,'native_catalog_sha256':'dfc3638b84e9d90272a093c7fe0f6e9112b3af0c8a6b3cca7d45ff26c69ca10c','source_sha256':plan['source_sha256'],'render_values':6295,'combined_measurements':75540,'retained3881_values':6243,'retained_f02_values':51,'fresh8db_values':1,'fresh8db_measurements':12,'glyph_or_draw_canvas_failures':0,'fresh_generated_batches':rows,'synthetic_probes':probes,'runtime_libraries':libproof,'SDL_TTF_HarfBuzz_versions_match':True,'compiler_and_flags_match':True,'source_proof':str((O/'three-producer-font-plan.json.gz').relative_to(R)),'limits':'Old producer identities preserved;6243old+51f02values carried by exact input and font/wrapper proof, not freshly rendered or manually read. Probe is synthetic, not translated catalog. Historical3881library hashes were not recorded; see originalruntimeaudit timestamp/version limitation.'}
(O/'font-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('Generated12/12glyph/draw/canvas pass; probes12/12byte-identical; runtime8libraries exactf02SHA/paths; combined6295/75540.')
