from pathlib import Path
import json,hashlib,gzip,subprocess
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';O=B/'native-captures/v5-final';O.mkdir(parents=True,exist_ok=True)
load=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();tsha=lambda s:sha(s.encode());frozen=load(B/'v5-frozen-inputs.json');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==frozen['revision']=='8db545e53d664af3bd4abcdec7cc29f5dc2dadf3'
full=B/'kit-v4/render-input/bg';f02=B/'native-captures/producers/f02b75/frozen-inputs/full';new_native=load(full/'native.json');old_native=load(f02/'native.json');online=load(full/'online.json');assert online==load(f02/'online.json')
assert len(new_native)==3425 and len(online)==2843
changed={k:(old_native.get(k),v)for k,v in new_native.items()if old_native.get(k)!=v};assert changed=={'[Generated]':('Генерирано','Генерирана')}
oldproof=load(B/'native-captures/v4-final/font-carryforward.json');retained=[e for e in oldproof['unchanged_entries']if e['key']!='[Generated]'];assert len(retained)==6243
f02delta=oldproof['delta_entries'];assert len(f02delta)==51
for e in f02delta:
 assert e['surface']=='native' and tsha(new_native[e['key']])==e['target_sha256']
for e in retained:
 v=(new_native if e['surface']=='native'else online)[e['key']]
 if isinstance(v,dict):v=v[e['branch']]
 assert tsha(v)==e['target_sha256']
oldroot=B/'native-matrix-source-font-corrected';files=[]
for e in oldproof['font_and_wrapper_files']:
 p=R/e['path'];assert sha(p.read_bytes())==e['old_and_final_sha256'];files.append({'path':e['path'],'original3881_and_final8db_sha256':sha(p.read_bytes())})
def block(s):return s[s.index('struct ProductionMeasurer'):s.index('template<class T> class Preview')]
a=block((oldroot/'tools/TranslationPreviewHarness.cpp').read_text());b=block((R/'tools/TranslationPreviewHarness.cpp').read_text());assert a==b
source=load(B/'kit-v4/source/native.json')['[Generated]'];assert source=='Generated'
record={'status':'Exact input/source carryforward prepared; new8db executable/runtime/test/after-image verification still pending. No technical approval implied.','final_revision':frozen['revision'],'source_sha256':frozen['source_sha256'],'final_catalog_sha256':frozen['catalog_sha256'],'render_values':6295,'combinations':12,'combined_measurements_expected':75540,'three_producer_correspondence':{'3881c64e0d2b43b460a122422d2727c0cbd4d3ca':{'unchanged_values':6243,'retained_measurements':74916},'f02b75ccab66d3073f33ae865d2c8a731e546545':{'unchanged_delta_values':51,'retained_measurements':612},'8db545e53d664af3bd4abcdec7cc29f5dc2dadf3':{'fresh_changed_values':1,'new_measurements_required':12,'status':'Await actual fresh binary handoff and successful captures'}},'changed_entry':{'surface':'native','key':'[Generated]','source':source,'before':'Генерирано','target':'Генерирана','source_value_sha256':tsha(source),'target_sha256':tsha('Генерирана')},'unchanged3881_entries':retained,'unchanged_f02_entries':f02delta,'font_wrapper_files':files,'measurer_and_font_matrix_block_sha256':tsha(a),'measurer_and_font_matrix_block_comparison':'byte identical from3881 to8db; only unrelated UI sources changed','previous_measured_diagnostics':'artifacts/bulgarian/native-captures/v4-final/font-supplement-validation.json','previous_f02_strip_proof':'artifacts/bulgarian/native-captures/producers/f02b75/strip-debug-proof.json','runtime_font_scope_pending':'Verify new actual executable resolution/API versions and cheap synthetic sample equivalence after fresh handoff; do not relabel old producer metadata.','serialization':'source/target hashes are raw decoded UTF8 string bytes, no JSON quotes/newline; code file hashes exact file bytes.'}
assert 74916+612+12==75540
raw=(json.dumps(record,ensure_ascii=False,indent=2)+'\n').encode();(O/'three-producer-font-plan.json').write_bytes(raw)
with gzip.open(O/'three-producer-font-plan.json.gz','wb',compresslevel=9)as f:f.write(raw)
print('Prepared6243old +51f02 +1new =6295values; actual8dbfont/UI/tests pending.')
