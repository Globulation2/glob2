# Bulgarian SGSL compatibility assessment

Prepared from the actual tree; no engine builds or test executions were run by this subtask. The root task owns fresh-binary validation and fixture generation. git diff --check passed for the two assigned files.

## Scope and policy

Assigned production edit: src/game/SimRevision.h, revision 111 -> 112. No save-format bump and no SGSL execution/parser/lexer changes. Assigned tests: src/scripting/sgsl/LegacyScriptCoverageTest.cpp only.

AGENTS.md requires a revision for changed map loading or scripting computation/acceptance, including changes outside saved bytes. This is a language-inventory acceptance boundary: Lexer.cpp identifies bare identifiers by scanning every StringTable catalog language (lines 305-313); Parser.cpp requires LANG for show's optional locale (lines 185-191). Adding bg makes bare bg LANG rather than NIL and accepts show("...",bg), which older catalog inventories reject. SGSL programs also execute simulation actions such as win and resetAI. This is an actual accepted-map/script input change, without a change to existing rule/tick behavior. Predecessor master ffabe1b9ef4e2a9986b1d6321c356124480b8a2d explicitly assigned revision 111 to Malay registration for the same reason.

SGSL.cpp::load preserves sourceCode from the saved byte stream and recompiles it before loading suspended story program counters/internal timers; pre-private-RNG versions intentionally omit private random state. No production save-layout changes are needed. The existing historical writer remains independent of the current writer.

## Tests prepared

Generalized the existing Malay-specific tests to cover Malay and Bulgarian. The inventory helper omits a named catalog to reproduce the absence/presence acceptance boundary. Tests cover NIL -> LANG including numeric catalog index and locale string; show acceptance; locale-specific text and authored fallback; MINIMUM_VERSION_MINOR (58) and VERSION_MINOR (191) saved source bytes, suspended PC and timer, all compiled token types/indices/messages, exact re-encoded bytes, continued checksums and a scripted victory. The Bulgarian legacy source includes an existing Malay locale token, so appending Bulgarian must preserve Malay's released index. A scope guard restores Toolkit's process-wide complete catalog and original selected/settings language even if a REQUIRE exits early. Each engine case also receives process isolation in the registry runner.

## Pending commands after the root builds the fresh revision-112 binary

Replace FRESH_NATIVE_BUILD_DIR with the build directory containing the newly compiled src/glob2-engine-tests; do not use the existing revision-110 binary. No command below was executed by this subtask.

```sh
python3 test/run_tests.py --build-dir FRESH_NATIVE_BUILD_DIR --binary engine --filter 'LegacyScriptCoverage/*' --artifacts artifacts/bulgarian/sgsl-bg-compatibility/legacy --junit artifacts/bulgarian/sgsl-bg-compatibility/legacy.xml
python3 test/run_tests.py --build-dir FRESH_NATIVE_BUILD_DIR --binary engine --update-fixtures --filter 'TurnEngineHarness/the committed*' --artifacts artifacts/bulgarian/sgsl-bg-compatibility/golden-update --junit artifacts/bulgarian/sgsl-bg-compatibility/golden-update.xml
python3 test/run_tests.py --build-dir FRESH_NATIVE_BUILD_DIR --binary engine --filter 'TurnEngineHarness/the committed*' --artifacts artifacts/bulgarian/sgsl-bg-compatibility/golden-verify --junit artifacts/bulgarian/sgsl-bg-compatibility/golden-verify.xml
```

The golden test creates a fresh seed-2026, two-human/Nicowar/Warrush FourSquares1 match record, verifies it through MatchVerifier, and writes both test/fixtures/multiplayer/FourSquares1.g2mr and FourSquares1.verify-trace.txt through the sanctioned fixture-update path. Both regenerated files belong in the same PR as revision 112. Do not patch trace/version metadata by hand. Relevant simulation-version acceptance checks and cross-platform traces remain root-task validation responsibilities; none are claimed here.
