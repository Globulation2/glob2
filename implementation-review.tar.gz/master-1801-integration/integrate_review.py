from pathlib import Path
import json,hashlib,sys,importlib.util
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'kit-v7';L=B/'linguistics';phase=sys.argv[1];reports=sys.argv[2:];spec=importlib.util.spec_from_file_location('p',R/'tools/localization/translation_program.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);changes=[]
for report in reports:
 d=json.loads((L/report).read_text());locale=d.get('locale')or d['entries'][0]['locale'];paths=m.catalog_paths(K,locale)
 for e in d['entries']:
  if not e.get('proposed_target'):continue
  p=paths[e['surface']];cat,err=m.CHECKER.read_table(p)if e['surface']=='native'else(json.loads(p.read_text()),[]);assert not err;assert cat[e['key']]==e['target'],(e['id'],'candidate changed');cat[e['key']]=e['proposed_target'];p.write_text(''.join(k+'\n'+v+'\n'for k,v in cat.items())if e['surface']=='native'else json.dumps(cat,ensure_ascii=False,indent=2)+'\n');changes.append({'locale':locale,'id':e['id'],'old':e['target'],'new':e['proposed_target'],'report':report})
for locale,inputfile in [('bg','bg-full-affected-batches-review-input.json'),('bn','bn-delta-review-input.json')]:
 packet=json.loads((K/inputfile).read_text());paths=m.catalog_paths(K,locale);cats={s:(m.CHECKER.read_table(p)[0]if s=='native'else json.loads(p.read_text()))for s,p in paths.items()};packet['catalog_sha256']={s:hashlib.sha256(p.read_bytes()).hexdigest()for s,p in paths.items()};packet['phase']=phase
 for e in packet['entries']:
  e['target']=cats[e['surface']][e['key']];e['target_sha256']=hashlib.sha256(e['target'].encode()).hexdigest();e['identity_sha256']=hashlib.sha256(json.dumps([e['id'],e['source'],e['target']],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();e['approval']=None
 (K/(locale+'-'+phase+'-review-input.json')).write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
(K/(phase+'-integration.json')).write_text(json.dumps({'phase':phase,'changes':changes,'live_catalogs_modified':False},ensure_ascii=False,indent=2)+'\n');print(phase,len(changes),'corrections integrated only in ignored candidate; new BG/BN packets emitted')
