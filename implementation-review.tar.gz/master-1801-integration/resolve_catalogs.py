from pathlib import Path
import subprocess,json,hashlib
out=Path('artifacts/bulgarian/master-1801-integration');base=subprocess.check_output(['git','merge-base','HEAD','origin/master'],text=True).strip();files=subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True).splitlines();proof=[]
for p in files:
 if not ((p.startswith('data/texts.') and p.endswith('.txt'))or p.startswith('platform/packages/i18n/locales/')or p=='platform/packages/i18n/shared-values.json'):continue
 def read(ref):return subprocess.check_output(['git','show',ref+':'+p]).decode()
 a=read(':2') if False else subprocess.check_output(['git','show',':2:'+p]).decode();b=subprocess.check_output(['git','show',':3:'+p]).decode();old=read(base)
 def native(t):
  lines=t.splitlines();assert len(lines)%2==0;return dict(zip(lines[::2],lines[1::2]))
 parse=native if p.startswith('data/')else json.loads;x,y,z=map(parse,(a,b,old));r=dict(x);added=[];changed=[];both=[]
 for k,v in y.items():
  if k not in x:r[k]=v;added.append(k)
  elif x[k]==v:continue
  elif p.endswith('shared-values.json'):
   r[k]=list(dict.fromkeys([*x[k],*v]));changed.append(k)
  elif x[k]==z.get(k):r[k]=v;changed.append(k)
  elif v!=z.get(k):both.append(k)
 Path(p).write_text(''.join(k+'\n'+v+'\n' for k,v in r.items())if p.startswith('data/')else json.dumps(r,ensure_ascii=False,indent=2)+'\n');subprocess.run(['git','add',p],check=True);proof.append({'path':p,'added':added,'master_only_changes':changed,'both_changed_keep_reviewed_ours':both,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()})
(out/'catalog-conflict-union.json').write_text(json.dumps({'base':base,'records':proof},ensure_ascii=False,indent=2)+'\n');print(len(proof),'catalog conflicts resolved')
