from pathlib import Path
import json,hashlib,importlib.util,shutil
R=Path.cwd();B=R/'artifacts/bulgarian';K=B/'kit-v7';L=B/'linguistics';spec=importlib.util.spec_from_file_location('p',R/'tools/localization/translation_program.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);before=K/'registered-before-final-apply';before.mkdir(exist_ok=True);proof=[]
for locale,count,tag in [('bg',72,'bg72'),('bn',19,'bn19')]:
 packetpath=K/(locale+'-after-editor-review-input.json');packet=json.loads(packetpath.read_text());expected={e['id']:(e['source'],e['target'])for e in packet['entries']};assert len(expected)==count;reports=[]
 for role,agent in [('semantic','/root/v7_meaning'),('editor','/root/v7_editor'),('adversarial','/root/v7_adversary')]:
  p=L/('v7-'+role+'-'+tag+'-final'+('-normalized'if role=='adversarial'else'')+'.json');d=json.loads(p.read_text());identity=d.get('reviewer_identity',d.get('reviewer',d.get('reviewer_agent')));assert (identity.get('agent')if isinstance(identity,dict)else identity)==agent;assert d['source_sha256']==packet['source_sha256'];assert d['catalog_sha256']==packet['catalog_sha256'];assert len(d['entries'])==count;assert {e['id']:(e['source'],e['target'])for e in d['entries']}==expected
  for e in d['entries']:assert e.get('status',e.get('verdict',e.get('decision')))in ['approved','approve','accepted','accept'],(role,e['id'],e.get('status'));assert not e.get('findings')
  reports.append({'role':role,'actual_agent':agent,'path':str(p.relative_to(B)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 results=[]
 for surface,src in m.catalog_paths(K,locale).items():
  dest=R/('data/texts.'+locale+'.txt')if surface=='native'else R/('platform/packages/i18n/locales/'+locale+'.json');assert hashlib.sha256(src.read_bytes()).hexdigest()==packet['catalog_sha256'][surface];old,err=m.CHECKER.read_table(dest)if surface=='native'else(json.loads(dest.read_text()),[]);new,err2=m.CHECKER.read_table(src)if surface=='native'else(json.loads(src.read_text()),[]);assert not err and not err2;changed=[surface+':'+k for k,v in old.items()if new[k]!=v];added=[surface+':'+k for k in new if k not in old];assert set(changed+added)<=set(expected);assert locale!='bn'or not changed
  (before/locale).mkdir(exist_ok=True);shutil.copyfile(dest,before/locale/dest.name)
  if src.read_bytes()!=dest.read_bytes():shutil.copyfile(src,dest)
  assert dest.read_bytes()==src.read_bytes();results.append({'surface':surface,'path':str(dest.relative_to(R)),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'changed_old_keys':changed,'added_keys':added,'new_count':len(new)})
 proof.append({'locale':locale,'fresh_reviewed_pairs':count,'reports':reports,'applied':results,'packet_sha256':hashlib.sha256(packetpath.read_bytes()).hexdigest()})
(K/'registered-application-validation.json').write_text(json.dumps({'status':'Actual final three-role-approved BG72 and BN19 exact catalogs applied','source_sha256':packet['source_sha256'],'catalogs':proof,'runtime_gates_pending':True},ensure_ascii=False,indent=2)+'\n');print('Applied final reviewed BG6378 and BN6378. No unreviewed pair changes.')
