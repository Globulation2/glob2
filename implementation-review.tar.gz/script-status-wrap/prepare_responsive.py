from pathlib import Path
import difflib,json,hashlib
R=Path.cwd();O=R/'artifacts/bulgarian/script-status-wrap';path=R/'src/scripting/map/ScriptEditorScreen.cpp';old=path.read_text();new=old.replace('#include <algorithm>','#include <algorithm>\n#include <sstream>',1)
anchor='class ScriptCursorCaption : public fe::Node'
helper='''Element scriptTouchButtons(std::vector<Element> buttons, std::vector<std::string> labels,
                           const Presentation &p, fe::FontRole role, int maxColumns)
{
    return fe::adaptive([buttons=std::move(buttons), labels=std::move(labels), role,
                         gap=p.pt(6), minimum=p.pt(150), maxColumns](const fe::LayoutContext &ctx, fe::Size) {
        int width=minimum;
        for (const auto &label : labels) {
            std::istringstream words(label);
            for (std::string word; words >> word;)
                width=std::max(width,ctx.text.width(role,word)+2*ctx.metrics.padding);
        }
        return fe::wrap(buttons,{gap,width,maxColumns});
    });
}
'''
assert anchor in new;new=new.replace(anchor,helper+anchor,1)
new=new.replace('? fe::column({fe::label(compilation, resultStyle), position}, {p.pt(4)})','? fe::column({fe::paragraph(compilation, resultStyle), position}, {p.pt(4)})',1)
anchor='\treturn fe::column(\n\t\t{language, editor, status, fe::actions(std::move(tools), p)},'
replace='''    Element toolActions;
    if (!p.touch) toolActions=fe::actions(std::move(tools),p);
    else {
        std::vector<Element> buttons;
        std::vector<std::string> labels;
        for (const auto &item : tools) {
            fe::ButtonOptions options;
            options.primary=item.primary; options.shortcut=item.shortcut;
            options.enabled=item.enabled; options.icon=item.icon;
            options.minHeight=48; options.role=fe::FontRole::Heading;
            buttons.push_back(fe::button(item.key,item.label,item.action,options));
            labels.push_back(item.label);
        }
        toolActions=scriptTouchButtons(std::move(buttons),std::move(labels),p,fe::FontRole::Heading,0);
    }
\treturn fe::column(
\t\t{language, editor, status, toolActions},'''
assert anchor in new;new=new.replace(anchor,replace,1)
anchor='\tauto header =\n\t\tfe::segments("tab", tabs, selected, [this, ids](int index) { showTab(ids[index]); });'
replace=anchor+'''
    if (p.touch) {
        std::vector<Element> buttons;
        for (int i=0;i<4;++i) {
            fe::ButtonOptions options;
            options.selected=i==selected; options.minHeight=44;
            buttons.push_back(fe::button("tab/"+std::to_string(i),tabs[i],
                [this,id=ids[i]] { showTab(id); },options));
        }
        header=scriptTouchButtons(std::move(buttons),tabs,p,fe::FontRole::Body,2);
    }'''
assert anchor in new;new=new.replace(anchor,replace,1)
(O/'ScriptEditorScreen-responsive.cpp').write_text(new);patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/src/scripting/map/ScriptEditorScreen.cpp',tofile='b/src/scripting/map/ScriptEditorScreen.cpp'));(O/'script-responsive-layout.patch').write_text(patch)
sha=lambda t:hashlib.sha256(t.encode()).hexdigest();(O/'responsive-proposal.json').write_text(json.dumps({'scope':'Phone-only scenario-editor tabs/tools responsive grid plus compact/enlarged status paragraph. Desktop tabs/tool layout, IDs, callbacks, font roles, wording unchanged.','before_source_sha256':sha(old),'proposed_source_sha256':sha(new),'patch_sha256':sha(patch),'patch_includes_status_one_line_fix':True,'layout':'Use existing adaptive+wrap containers. At most2tab columns, but production font-measured longest-word width plus existing button padding can require1column. Compile/load/save actions retain48ptminimum and Heading font; tabs44ptminimum and Body. No font fitting/abbreviation. Footer unchanged.','height_tradeoff':'Column fallback adds rows but removes midword stacking; existing expanded code editor remains flexible/scrollable. Actual390x844100/150 after-captures required to establish available editor height and final fit.','status':'Ignored staged patch; not applied; no pixel-fit claim before actual after-captures.'},indent=2)+'\n');print('Staged responsive tabs/tools+status; no live edits')
