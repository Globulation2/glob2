"""Pinned, minimal recording libraries; never discover host FFmpeg libraries."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import shutil
import subprocess
import tarfile
import tempfile

from sdl3_dependencies import download

LOCK = Path(__file__).with_name('recording-versions.json')
LIBRARIES = ('avformat', 'avcodec', 'swscale', 'swresample', 'avutil')

def codec_libraries(video_codec):
    return LIBRARIES + {'h264': ('x264',), 'vp9': ('vpx',), 'av1': ('aom',)}[video_codec]

def codec_sources(video_codec):
    return ('ffmpeg',) + {'h264': ('x264', 'nv-codec-headers'), 'vp9': ('vpx',), 'av1': ('aom',)}[video_codec]


def native_opus_configuration(environment):
    """The Linux client owns Opus; record the API and link inputs FFmpeg uses."""
    def query(*arguments):
        return subprocess.check_output(['pkg-config', *arguments, 'opus'],
                                       env=environment, text=True).strip()
    return dict(version=query('--modversion'), cflags=query('--cflags'),
                libs=query('--libs'), static_libs=query('--static', '--libs'))


def configure_bash(environment):
    if platform.system() != 'Windows':
        return 'bash'
    # System32 also contains bash.exe (a WSL launcher). Use the Bash beside
    # the POSIX shell already selected for the MSYS build tools instead.
    shell = shutil.which('sh', path=environment.get('PATH'))
    bash = Path(shell).with_name('bash.exe') if shell else None
    if not bash or not bash.is_file():
        raise RuntimeError('Embedded recording requires MSYS Bash; install the MSYS build tools and add their bin directory to PATH.')
    return str(bash)


def build(prefix, work, *, cc='cc', cxx='c++', ar='ar', ranlib='ranlib',
          target=None, arch=None, cflags=(), ldflags=(), environment=None, jobs=2, sdk_identity=None, video_codec='h264', opus_configuration=None):
    prefix, work = Path(prefix).resolve(), Path(work).resolve()
    env = dict(environment if environment is not None else os.environ)
    if video_codec not in ('h264', 'vp9', 'av1'):
        raise ValueError('recording_codec must be h264, vp9, or av1')
    versions = {name: spec for name, spec in json.loads(LOCK.read_text()).items() if name in codec_sources(video_codec)}
    target = target or {'Darwin': 'darwin', 'Windows': 'mingw32'}.get(platform.system(), 'linux')
    if video_codec != 'h264' and target != 'linux':
        raise ValueError('WebM recording builds currently support native Linux only')
    if video_codec != 'h264':
        installed_opus = native_opus_configuration(env)
        if opus_configuration is not None and opus_configuration != installed_opus:
            raise ValueError('Native Opus configuration changed while preparing recording dependencies')
        opus_configuration = installed_opus
    arch = arch or platform.machine()
    arch = {'AMD64':'x86_64','ARM64':'aarch64'}.get(arch,arch)
    if sdk_identity is None and target == 'darwin':
        sdk_identity = {key: subprocess.check_output(['xcrun', '--show-sdk-'+key],env=env,text=True).strip() for key in ('path','version')}
    cflags, ldflags = list(cflags), list(ldflags)
    vaapi = None
    if target == 'linux' and video_codec == 'h264':
        probe_env = dict(env)
        probe_env.pop('PKG_CONFIG_LIBDIR', None)
        try:
            probe = subprocess.run(['pkg-config', '--modversion', 'libva', 'libva-drm'],
                                   env=probe_env, capture_output=True, text=True)
            if probe.returncode == 0: vaapi = probe.stdout.strip()
        except FileNotFoundError:
            pass
    assembler = None
    if target != 'wasm' and arch in ('x86_64', 'amd64', 'i686', 'i386'):
        if not shutil.which('nasm', path=env.get('PATH')):
            raise RuntimeError('Embedded recording requires NASM 2.13 or newer on x86 targets; install nasm and retry.')
        assembler = subprocess.check_output(['nasm', '--version'], env=env, text=True).strip()
    compiler = subprocess.check_output(shlex.split(str(cc)) + ['--version'], env=env, text=True)
    identity = dict(configuration=3, video_codec=video_codec, opus=opus_configuration, versions=versions, target=target, arch=arch,
                    compiler=compiler, cc=str(cc), ar=str(ar), flags=[cflags, ldflags],
                    vaapi_api=vaapi, assembler=assembler, sdk=sdk_identity, environment={name:env.get(name,'') for name in ('CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','SDKROOT','MACOSX_DEPLOYMENT_TARGET','DEVELOPER_DIR')}, recipe=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    manifest = prefix / 'recording-manifest.json'
    archives = [prefix / 'lib' / ('lib' + name + '.a') for name in codec_libraries(video_codec)]
    if video_codec != 'h264' and any((prefix / name).exists() for name in ('lib/libopus.a', 'lib/pkgconfig/opus.pc')):
        raise ValueError('Recording prefix contains bundled Opus; choose a clean recording prefix')
    if manifest.exists():
        installed = json.loads(manifest.read_text())
        if installed.get('identity', {}).get('video_codec', 'h264') != video_codec:
            raise ValueError('Choose a separate recording prefix for each codec profile')
        if installed.get('identity') == identity and all(p.is_file() and
                hashlib.sha256(p.read_bytes()).hexdigest() == installed.get('archives', {}).get(p.name)
                for p in archives):
            return prefix
    work.mkdir(parents=True, exist_ok=True)
    prefix.mkdir(parents=True, exist_ok=True)
    vendored = Path(env.get('GLOB2_RECORDING_ARCHIVES', str(LOCK.parent.parent / 'third_party/recording-sources')))
    for spec in versions.values():
        if not (work / spec['archive']).exists() and (vendored / spec['archive']).exists():
            shutil.copy2(vendored / spec['archive'], work / spec['archive'])
    download(work, versions)
    sources = {}
    for name, spec in versions.items():
        source = work / spec['directory']
        if not source.exists():
            with tarfile.open(work / spec['archive']) as package:
                package.extractall(work, filter='data')
        sources[name] = source
    # x264 expands $CC without eval, so a quoted SDK path is still split. Use
    # private executable wrappers with space-free names for both upstream builds.
    commands = tempfile.TemporaryDirectory(prefix='glob2-recording-tools-',dir='/tmp' if platform.system()!='Windows' else None)
    def wrapper(name, command):
        path = Path(commands.name) / name
        path.write_bytes(('#!/bin/sh\nexec ' + shlex.join(shlex.split(str(command))) + ' "$@"\n').encode())
        path.chmod(0o700)
        return path.as_posix()
    original_ar = ar
    cc, cxx, ar, ranlib = (wrapper(name, command) for name, command in
                           [('cc',cc),('cxx',cxx),('ar',ar),('ranlib',ranlib)])
    env.update(CC=cc, CXX=cxx, AR=ar, RANLIB=ranlib)
    if video_codec != 'h264':
        env['LDFLAGS'] = shlex.join(ldflags)
    native_pkg_path = env.get('PKG_CONFIG_PATH', '') if video_codec != 'h264' else ''
    env['PKG_CONFIG_PATH'] = (prefix / 'lib/pkgconfig').as_posix() + (os.pathsep + native_pkg_path if native_pkg_path else '')
    if target != 'linux': env['PKG_CONFIG_LIBDIR'] = env['PKG_CONFIG_PATH']
    elif video_codec == 'h264': env.pop('PKG_CONFIG_LIBDIR', None)
    extra_c = shlex.join(['-O3', '-fPIC'] + cflags)
    extra_ld = shlex.join(ldflags)
    if video_codec == 'h264':
        # x264's configure uses brace expansion to create architecture output
        # directories. /bin/sh is dash on Linux and silently creates wrong paths.
        x264 = [configure_bash(env), (sources['x264'] / 'configure').as_posix(), '--prefix=' + prefix.as_posix(),
                '--enable-static', '--enable-pic', '--disable-cli', '--disable-opencl',
                '--disable-avs', '--disable-lavf', '--disable-swscale', '--disable-ffms',
                '--bit-depth=8', '--chroma-format=420', '--extra-cflags=' + extra_c,
                '--extra-ldflags=' + extra_ld]
        if arch in ('arm64','arm64-v8a','armeabi-v7a','aarch64'):
            x264 += ['--extra-asflags=' + shlex.join(cflags)]
        encoders = ['libx264', 'aac']
        hardware = []
        if target == 'wasm':
            x264 += ['--host=wasm32-unknown-linux', '--disable-asm', '--disable-thread']
        elif target == 'android':
            x264 += ['--host=' + {'arm64-v8a': 'aarch64-linux-android', 'armeabi-v7a': 'arm-linux-androideabi', 'x86_64': 'x86_64-linux-android'}[arch]]
            encoders += ['h264_mediacodec']; hardware = ['--enable-mediacodec','--enable-jni']
        elif target in ('darwin', 'ios'):
            if target == 'ios': x264 += ['--host=aarch64-apple-darwin']
            encoders += ['h264_videotoolbox']; hardware = ['--enable-videotoolbox']
        elif target == 'mingw32':
            x264 += ['--host=x86_64-w64-mingw32']
            # MF's encoder references its D3D11 device context even for CPU input.
            # Enable the context API; unrelated hardware decoders remain disabled.
            encoders += ['h264_mf', 'h264_nvenc']; hardware = ['--enable-mediafoundation','--enable-d3d11va','--enable-ffnvcodec','--enable-nvenc']
        elif target == 'linux':
            # VAAPI is linked only to its runtime API, never to codec implementations.
            encoders += ['h264_nvenc']; hardware = ['--enable-ffnvcodec','--enable-nvenc']
            if vaapi: encoders += ['h264_vaapi']; hardware += ['--enable-vaapi']
        if target in ('linux', 'mingw32'):
            subprocess.run(['make', 'install', 'PREFIX=' + prefix.as_posix()], cwd=sources['nv-codec-headers'], env=env, check=True)
    else:
        encoders = ['libvpx-vp9' if video_codec == 'vp9' else 'libaom-av1', 'libopus']
        hardware = []
    ffmpeg = ['sh', (sources['ffmpeg'] / 'configure').as_posix(), '--prefix=' + prefix.as_posix(),
              '--disable-autodetect', '--disable-everything', '--disable-programs',
              '--disable-doc', '--disable-debug', '--disable-network', '--disable-avdevice',
              '--disable-avfilter', '--enable-static', '--disable-shared', '--enable-pic',
              '--enable-encoder=' + ','.join(name.replace('-', '_') for name in encoders),
              '--enable-muxer=mp4,webm', '--enable-demuxer=mov,matroska', '--enable-swscale',
              '--enable-swresample', '--cc=' + str(cc), '--cxx=' + str(cxx),
              '--ar=' + str(ar), '--ranlib=' + str(ranlib),
              '--extra-cflags=' + shlex.join(['-O3', '-fPIC', '-I' + (prefix / 'include').as_posix()] + cflags),
              '--extra-ldflags=' + shlex.join(['-L' + (prefix / 'lib').as_posix()] + ldflags)] + hardware
    ffmpeg += ['--enable-gpl', '--enable-libx264'] if video_codec == 'h264' else ['--pkg-config-flags=--static', '--enable-libopus', '--enable-libvpx' if video_codec == 'vp9' else '--enable-libaom']
    if target in ('wasm', 'android', 'ios', 'mingw32'):
        mapped = {'arm64-v8a': 'aarch64', 'armeabi-v7a': 'arm', 'arm64': 'aarch64'}.get(arch, arch)
        ffmpeg += ['--enable-cross-compile', '--target-os=' + {'wasm': 'none', 'ios': 'darwin'}.get(target,target),
                   '--arch=' + ('wasm32' if target == 'wasm' else mapped)]
    if target == 'wasm':
        # A dedicated worker needs no pthreads; preserve wasm32 SIMD detection.
        ffmpeg += ['--disable-pthreads', '--disable-w32threads', '--disable-os2threads',
                   '--nm=' + wrapper('nm', shlex.quote(str(Path(shlex.split(str(original_ar))[0]).parent.parent / 'bin/llvm-nm')))]
    else:
        ffmpeg += ['--enable-pthreads' if target != 'mingw32' else '--enable-w32threads']
    builds = [('x264', x264)] if video_codec == 'h264' else webm_build_commands(sources, prefix, cc, cxx, ar, ranlib, cflags, ldflags, video_codec)
    for name, command in builds + [('ffmpeg', ffmpeg)]:
        directory = work / (name + '-build')
        if directory.exists(): shutil.rmtree(directory)
        directory.mkdir()
        with (directory / 'build.log').open('w') as log:
            steps = (command, ['cmake', '--build', '.', '--parallel', str(jobs)], ['cmake', '--install', '.']) if name == 'aom' else (command, ['make', '-j' + str(jobs)], ['make', 'install'])
            for index,step in enumerate(steps):
                result = subprocess.run(step, cwd=directory, env=env, stdout=log, stderr=subprocess.STDOUT)
                if result.returncode:
                    log.flush()
                    print('\n'.join((directory/'build.log').read_text(errors='replace').splitlines()[-60:]),flush=True)
                    raise RuntimeError('Recording dependency failed: ' + name + '; see ' + str(directory / 'build.log'))
                if index == 0 and name == 'x264' and target == 'wasm':
                    # Upstream disables C vectorization when native assembler is
                    # present. wasm32 has no x264 assembler; retain LLVM SIMD.
                    configuration=directory/'config.mak'
                    with configuration.open('a') as flags:
                        flags.write('\nCFLAGS += -fvectorize -fslp-vectorize\n')
    notices = prefix / 'share/licenses/recording'
    notices.mkdir(parents=True, exist_ok=True)
    licenses=[('ffmpeg',p.name) for p in sources['ffmpeg'].glob('COPYING.*')]
    licenses += [('x264','COPYING')] if video_codec == 'h264' else ([('vpx','LICENSE'), ('vpx','PATENTS')] if video_codec == 'vp9' else [('aom','LICENSE'), ('aom','PATENTS')])
    for name, filename in licenses:
        shutil.copy2(sources[name] / filename, notices / (name + '-' + filename))
    if video_codec == 'h264': shutil.copy2(sources['nv-codec-headers']/'include/ffnvcodec/nvEncodeAPI.h',notices/'nvEncodeAPI.h')
    (notices/'configuration.json').write_text(json.dumps(dict(target=target,arch=arch,video_codec=video_codec,opus=opus_configuration,encoders=encoders,hardware=hardware,ffmpeg=[flag for flag in ffmpeg if flag.startswith(('--disable-','--enable-','--arch=','--target-os='))],x264=[flag for flag in x264 if flag.startswith(('--disable-','--enable-','--bit-depth=','--chroma-format='))] if video_codec == 'h264' else [],wasm_vectorization=target=='wasm',compiler=compiler.splitlines()[0],flags=[cflags,ldflags]),indent=2)+'\n')
    (notices / 'sources.json').write_text(json.dumps(versions, indent=2) + '\n')
    manifest.write_text(json.dumps(dict(identity=identity, archives={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in archives}), indent=2) + '\n')
    commands.cleanup()
    return prefix


def webm_build_commands(sources, prefix, cc, cxx, ar, ranlib, cflags, ldflags, video_codec):
    """Native Linux only; upstream optimizations stay outside simulation flags."""
    if video_codec == 'vp9':
        vpx = ['bash', str(sources['vpx'] / 'configure'), '--prefix=' + str(prefix),
               '--libdir=' + str(prefix / 'lib'), '--enable-pic', '--enable-static',
               '--disable-shared', '--disable-examples', '--disable-tools',
               '--disable-docs', '--disable-unit-tests', '--disable-vp8',
               '--disable-vp9-decoder', '--enable-vp9-encoder', '--as=nasm',
               '--extra-cflags=' + shlex.join(['-O3'] + cflags)]
        return [('vpx', vpx)]
    aom = ['cmake', str(sources['aom']), '-DCMAKE_INSTALL_PREFIX=' + str(prefix),
           '-DCMAKE_INSTALL_LIBDIR=lib', '-DCMAKE_BUILD_TYPE=Release',
           '-DCMAKE_C_COMPILER=' + cc, '-DCMAKE_CXX_COMPILER=' + cxx,
           '-DCMAKE_AR=' + ar, '-DCMAKE_RANLIB=' + ranlib,
           '-DCMAKE_C_FLAGS=' + shlex.join(cflags), '-DCMAKE_CXX_FLAGS=' + shlex.join(cflags),
           '-DCMAKE_POSITION_INDEPENDENT_CODE=ON', '-DBUILD_SHARED_LIBS=OFF',
           '-DENABLE_DOCS=OFF', '-DENABLE_APPS=OFF', '-DENABLE_EXAMPLES=OFF', '-DENABLE_TESTS=OFF',
           '-DENABLE_TOOLS=OFF', '-DCONFIG_AV1_DECODER=0', '-DCONFIG_AV1_ENCODER=1']
    return [('aom', aom)]


def attach(env, prefix, target, video_codec='h264'):
    prefix = Path(prefix)
    manifest = prefix / 'recording-manifest.json'
    if manifest.exists() and json.loads(manifest.read_text())['identity'].get('video_codec', 'h264') != video_codec:
        raise ValueError('Recording prefix codec does not match recording_codec')
    if video_codec != 'h264':
        env.Append(CPPDEFINES=['GLOB2_RECORDING_' + video_codec.upper()])
    env.Prepend(CPPPATH=[str(prefix / 'include')])
    env.Append(LIBS=[env.File(str(prefix / 'lib' / ('lib' + name + '.a'))) for name in codec_libraries(video_codec)])
    if video_codec != 'h264':
        # Keep Opus under the native client's existing dependency ownership.
        # Append after FFmpeg so --as-needed links also resolve its Opus calls.
        env.ParseConfig('pkg-config opus --cflags --libs')
    if target in ('darwin', 'ios'):
        env.Append(FRAMEWORKS=['VideoToolbox', 'CoreMedia', 'CoreVideo', 'Foundation', 'AudioToolbox'])
    elif target == 'android':
        env.Append(LIBS=['mediandk'])
        # Static FFmpeg assembly references private tables directly. Bind only
        # codec archive symbols locally inside the JNI shared library; SDL's
        # Java entry points must remain exported.
        env.Append(LINKFLAGS=['-Wl,--exclude-libs=' + ':'.join('lib'+name+'.a' for name in codec_libraries(video_codec))])
    elif target == 'mingw32': env.Append(LIBS=['mfplat', 'mfuuid', 'ole32', 'strmiids', 'bcrypt'])
    elif target == 'linux':
        manifest = prefix / 'recording-manifest.json'
        if manifest.exists() and json.loads(manifest.read_text())['identity'].get('vaapi_api'):
            env.Append(LIBS=['va', 'va-drm'])
        env.Append(LIBS=['dl', 'm'])


if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix',type=Path,required=True)
    parser.add_argument('--work',type=Path,required=True)
    parser.add_argument('--cc',default=os.environ.get('CC','cc'))
    parser.add_argument('--cxx',default=os.environ.get('CXX','c++'))
    parser.add_argument('--codec', choices=('h264', 'vp9', 'av1'), default='h264')
    parser.add_argument('--jobs',type=int,default=2)
    args=parser.parse_args()
    build(args.prefix,args.work,cc=args.cc,cxx=args.cxx,jobs=args.jobs,video_codec=args.codec)
