require('./guard.cjs').guard();
const path=require('node:path'),fs=require('node:fs');
const root=path.resolve(__dirname,'../../..');
const {chromium,expect}=require(path.join(root,'browser/node_modules/@playwright/test'));
const {clickMainMenu,clickControl,clickSettingsDone,tapControl,control}=require(path.join(root,'browser/tests/main-menu'));
const {clickCreateMap}=require(path.join(root,'browser/tests/editor-controls'));
const report=[];
async function snapshot(page){return page.evaluate(()=>({diagnostics:glob2Diagnostics.snapshot(),dpr:devicePixelRatio,css:{width:innerWidth,height:innerHeight},canvas:[...document.querySelectorAll('canvas')].map(c=>({width:c.width,height:c.height,rect:{x:c.getBoundingClientRect().x,y:c.getBoundingClientRect().y,width:c.getBoundingClientRect().width,height:c.getBoundingClientRect().height}}))}));}
async function capture(page,name){await page.screenshot({path:path.join(__dirname,name+'.png')});report.push({name,state:await snapshot(page)});fs.writeFileSync(path.join(__dirname,'scenes-report.json'),JSON.stringify(report,null,2));}
async function boot(page){await page.goto('http://127.0.0.1:42771/?renderer=software&threads=serial');await expect.poll(async()=>{const s=await page.evaluate(()=>glob2Diagnostics.snapshot()),n=s.screen+' '+s.screenClass;for(const key of ['audio.silence','hand.right','intro/menu'])if(s.controls[key]?.enabled){await clickControl(page,key);return false;}return n.includes('MainMenuScreen');},{timeout:180000}).toBe(true);}
async function screen(page,name){await expect.poll(()=>page.evaluate(()=>{const s=glob2Diagnostics.snapshot();return s.screen+' '+s.screenClass}),{timeout:180000}).toContain(name);}
async function captureStatistics(page,name,touch,viewport){
 await clickControl(page,'intro/help'); // Close the help card opened by the preceding capture.
 const hasStats=()=>page.evaluate(()=>Boolean(glob2Diagnostics.snapshot().controls['stats/topic/0']));
 if(!await hasStats()){
  if(touch){
   // This is the real Tools action; hand-painted lens targets need actual-image inspection.
   await page.touchscreen.tap(viewport.width*2.5/6,viewport.height-35);
   await capture(page,name+'-stats-tools');
  }else{
   // Normal right-click cycles views and clears selection; no state injection or hidden flags.
   for(let attempt=0;attempt<6 && !await hasStats();++attempt){await page.mouse.click(viewport.width*.48,viewport.height*.65,{button:'right'});await page.waitForTimeout(250);}
  }
 }
 if(!await hasStats()){report.push({name:name+'-statistics',status:'pending actual-image navigation or unavailable through normal tutorial UI; no visibility flags changed',touch});fs.writeFileSync(path.join(__dirname,'scenes-report.json'),JSON.stringify(report,null,2));return;}
 await clickControl(page,'stats/topic/0');await capture(page,name+'-stats-overview');
 let keys=await page.evaluate(()=>Object.keys(glob2Diagnostics.snapshot().controls));expect(keys.some(k=>k.startsWith('stats/metric/') && /win.probability/i.test(k))).toBe(false);
 if(keys.includes('stats/full-history/population')){await clickControl(page,'stats/full-history/population');await control(page,'stats/history/close');await capture(page,name+'-stats-population-history');await clickControl(page,'stats/history/close');}
 await clickControl(page,'stats/topic/4');await capture(page,name+'-stats-world');
 keys=await page.evaluate(()=>Object.keys(glob2Diagnostics.snapshot().controls));expect(keys.some(k=>k.startsWith('stats/metric/') && /win.probability/i.test(k))).toBe(false);
 report.push({name:name+'-statistics-policy',status:'actual live player UI only; hidden win-probability metric absent; no observer/profile flags modified'});fs.writeFileSync(path.join(__dirname,'scenes-report.json'),JSON.stringify(report,null,2));
}
(async()=>{const browser=await chromium.launch();try{for(const [name,viewport,dpr,touch,textSize]of[['desktop-dpr2',{width:1200,height:900},2,false,100],['phone',{width:390,height:844},1,true,100],['phone150',{width:390,height:844},1,true,150]]){
 const context=await browser.newContext({locale:'bg-BG',viewport,deviceScaleFactor:dpr,hasTouch:touch});
 let page=await context.newPage();await boot(page);if(textSize===150){await clickMainMenu(page,'settings');await clickControl(page,'nav.0');await clickControl(page,'display.textsize');await clickControl(page,'popup/2');await capture(page,name+'-settings-text150');await clickSettingsDone(page);}await clickMainMenu(page,'tutorial');await screen(page,'LessonCatalogScreen');await capture(page,name+'-tutorial-catalog');await clickControl(page,'tutorial/lesson/0');await screen(page,'match');await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().tick),{timeout:120000}).toBeGreaterThan(15);
 let s=await page.evaluate(()=>glob2Diagnostics.snapshot());
 if(!s.controls['objectives/tab/0']){
  if(touch)await page.touchscreen.tap(viewport.width*3.5/6,viewport.height-35);
  else await page.mouse.click((s.width-160)*viewport.width/s.width,80*viewport.height/s.height);
 }
 await control(page,'objectives/tab/0',{timeout:30000});await clickControl(page,'objectives/tab/0');await capture(page,name+'-tutorial-briefing');await clickControl(page,'ok');
 await control(page,'intro/help',{timeout:60000});await capture(page,name+'-gameplay-hud');await clickControl(page,'intro/help');await control(page,'intro/help-text',{enabled:false});await capture(page,name+'-tutorial-help');await captureStatistics(page,name,touch,viewport);
 await page.close();page=await context.newPage();await boot(page);await clickMainMenu(page,'editor');await screen(page,'EditorMainMenu');await clickControl(page,'new-map');await screen(page,'NewMapScreen');await capture(page,name+'-editor-new-map');await clickCreateMap(page);await screen(page,'MapEditorScreen');await capture(page,name+'-editor-map');
 // Drive the actual map scenario dialog and language dropdown, retaining edits as a draft.
 await page.locator('#canvas').press('Escape',{delay:80});await clickControl(page,'script');await control(page,'script/language');await clickControl(page,'script/language');await clickControl(page,'popup/2');await control(page,'script');
 const validSource=await page.evaluate(()=>glob2Diagnostics.snapshot().controls.script?.label);
 expect(validSource).toContain('function step(ctx)');
 await clickControl(page,'compile');await capture(page,name+'-script-compile-success');
 // Read-only cursor/status nodes are not exported by the interactive-control observer.
 // Preserve their actual pixels for visual review rather than asserting a fabricated diagnostic value.
 const cursorVerification='Actual caption pixels captured; noninteractive ScriptCursorCaption is not exported in glob2Diagnostics.controls';
 await clickControl(page,'script');await page.keyboard.press('Home');await page.keyboard.type('}',{delay:80});
 await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls.script?.label)).not.toBe(validSource);
 const invalidSource=await page.evaluate(()=>glob2Diagnostics.snapshot().controls.script?.label);
 expect((invalidSource.match(/}/g)||[]).length).toBe((validSource.match(/}/g)||[]).length+1);
 await clickControl(page,'compile');await capture(page,name+'-script-compile-error');
 report.push({name:name+'-script-draft-evidence',validSource,invalidSource,cursorVerification,sourceChanges:'One unmatched closing brace inserted through keyboard; compile only, never confirmed into map',verification:'Success/error status pixels must be visually inspected; status label is not keyed in diagnostic controls'});fs.writeFileSync(path.join(__dirname,'scenes-report.json'),JSON.stringify(report,null,2));
 await context.close();
 }}finally{await browser.close();}})().catch(e=>{fs.writeFileSync(path.join(__dirname,'scenes-error.txt'),e.stack||String(e));console.error(e);process.exitCode=1});
