# Actual Bulgarian browser evidence: bd2 producer

These are historical actual results from clean source `bd2ca9ca28173f0155754656e0da36eacf7ffac3` and package `99e56b3a6f62ed96`, before the later Tamil/Marathi source integration. They must not be relabeled as final new-master execution.

The actual package passed `package-static.py --verify`. All four tracked Bulgarian cases have actual passing executions: startup and serial from the first fixed-server suite, threaded from an isolated rerun, explicit English-browser → Bulgarian selection/reload from the helper-corrected rerun. The first full fixed-server suite's two failures remain preserved; this is composed case coverage, not a pristine combined full-run pass. The tracked popup helper fix wheels inside the actual popup instead of over the window center.

Three startup contexts proved actual custom-font glyph selection through Chromium CDP, with decoded font/network/MIME/gzip identity checks. There are 22 normal scene screenshots across desktop DPR2 and phone100: gameplay, briefing/help, editor, compiler success/error/cursor and desktop statistics. `completed-image-index.json` binds the bounded 30-image selection. `run-summary.json` records exact results and limits.

Phone150 was prepared but refused by source guards when the later master merge changed production files. The phone main/settings matrix also did not complete, and phone Statistics was only reached as far as its normal Tools menu. These are explicitly unverified here. Decorative startup branding had missing platform-owned URLs on this old standalone package; Bulgarian text/font controls remained readable. Physical devices were not tested.

The guarded package/server remained immutable. Exact parent-authorized changes to three test-only files were recorded separately; every other source/package byte was checked. The later master merge correctly blocked any new launch. Own server and browser runners were stopped; port42771 is free. No source files, catalogs or binary outputs were changed by this worker except the explicitly authorized tracked popup test-helper fix.

Future corrected runbooks are prepared only: phone150 uses compact `nav.current` rather than a missing desktop `nav.0`; matrix uses normal onboarding and compact Language/player selection; HUD coordinates use the actual logical control surface rather than physical DPR canvas dimensions; readonly tutorial/compiler captions require actual image review rather than invented diagnostic controls. New source/bundles require a new explicit root handoff and fresh paths.
