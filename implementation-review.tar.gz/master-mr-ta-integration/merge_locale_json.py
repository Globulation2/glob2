from pathlib import Path
import json,subprocess,hashlib
root=Path.cwd();base=subprocess.check_output(['git','merge-base','HEAD','origin/master'],text=True).strip();records=[]
def get(ref,p):
 r=subprocess.run(['git','show',ref+':'+str(p)],capture_output=True)
 return json.loads(r.stdout)if r.returncode==0 else None
for p in sorted(Path('platform/packages/i18n/locales').glob('*.json')):
 ours=get('HEAD',p);theirs=get('origin/master',p);before=get(base,p)
 if ours is None:new=theirs
 elif theirs is None:new=ours
 else:
  new=dict(ours)
  for k,v in theirs.items():
   if k not in ours or (ours[k]==(before or{}).get(k)and v!=ours[k]):new[k]=v
 assert new is not None
 p.write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n');records.append({'path':str(p),'keys':len(new),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'old_BG_values_preserved':all(new[k]==v for k,v in(ours or{}).items())if p.stem=='bg'else None})
# Array-valued exact English exceptions are additive; retain both branches.
p=Path('platform/packages/i18n/shared-values.json');ours=get('HEAD',p);theirs=get('origin/master',p);merged=dict(ours)
for k,v in theirs.items():merged[k]=list(dict.fromkeys([*ours.get(k,[]),*v]))
p.write_text(json.dumps(merged,ensure_ascii=False,indent=2)+'\n')
Path('artifacts/bulgarian/master-mr-ta-integration/catalog-union.json').write_text(json.dumps({'base':base,'records':records},indent=2)+'\n');print('Canonicalized',len(records),'locale JSON catalogs; existing BG2948 untouched, newEN',len(get('origin/master',Path('platform/packages/i18n/locales/en.json'))))
