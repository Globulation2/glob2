# CI selector environment fix

The selector now creates a dedicated child venv using the exact asset encoder Python and installs the focused build-contract requirements into that child. The shared encoder environment and asset recipe remain unchanged. Requirements reuse Pillow 12.2.0 and the existing SCons 4.11.1 development pin. CI inventory and selection policy are unchanged.

Fresh child environment: Python 3.14.4, Pillow 12.2.0, SCons 4.11.1, WebP enabled. Full build-system discovery passed: **695 tests, five skips, 263.983 seconds, exit 0**. This includes all six previously unimportable native/browser/mobile SCons graph contracts. Focused selector tests passed: **33 tests**. The added executable regression checks that only venv creation uses the encoder interpreter; pip and unittest use the child interpreter, including an encoder path containing spaces. It also checks the focused requirements include and single SCons pin.

`inputs.json` binds the five owned uncommitted files to the tested HEAD and SHA256 hashes. `inputs/` preserves exact contents; `ci-selector-fix.patch` is reviewable. `result.json` lists commands, skips and environment; install.log/build-system.log/focused.log retain output. Inputs were unchanged throughout the full suite.

The hosted failure used Python 3.12; this local validation used the available exact encoder Python 3.14.4. No hosted rerun, commit, push, shared encoder mutation, asset recipe change or native/browser build was performed. Unrelated frontend work is excluded from the patch and input manifest.
