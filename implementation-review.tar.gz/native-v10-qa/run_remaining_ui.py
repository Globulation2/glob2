from pathlib import Path
import json,os,subprocess,sys,hashlib,time,shutil
from run_phase import R,B,OUT,write,sha,environment
binary=Path(sys.argv[1]).resolve();revision,expected=sys.argv[2:]
assert sha(binary)==expected and revision.encode()in binary.read_bytes();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==revision
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
base=OUT/'surfaces-harness-corrected';assert not base.exists(),'Never overwrite actual attempt';base.mkdir()
old=B/'v10-full-render-input';new=B/'v10-corrected-full-render-input';assert not new.exists();shutil.copytree(old,new);pilot=new/'render-input/bg';m=json.loads((new/'manifest.json').read_text());m['revision']=revision;write(new/'manifest.json',m);meta=json.loads((pilot/'metadata.json').read_text());meta.update(source_revision=revision,candidate_revision=revision,compiled_runtime_revision=revision);write(pilot/'metadata.json',meta)
paths=[new/'manifest.json',*pilot.glob('*.json')];frozen={str(p):sha(p)for p in paths}
jobs=[]
for view,w,h in [('desktop',1280,1024),('phone',390,844)]:
 if view=='phone':
  for name in ['lobby','lobby-players']:jobs.append((f'{view}-{name}',view,w,h,'screen',[name]))
 for tag,mode,args in [('results','game',['statistics']),('navigation','game',['statistics-navigation']),('script-editor','script-editor',[]),('fortifications','game',['tutorial:fortifications'])]:jobs.append((view+'-'+tag,view,w,h,mode,args))
identity={'actual_revision':revision,'actual_binary_sha256':expected,'input_files_sha256':frozen,'jobs':[],'scope':'Fresh remaining actual native production scenarios; initial two desktop lobby captures retain actual3810 producer and closure.'}
for tag,view,w,h,mode,args in jobs:
 assert sha(binary)==expected;assert all(sha(Path(p))==h for p,h in frozen.items())
 out=base/tag;out.mkdir();cmd=['xvfb-run','-a','-s','-screen 0 1600x1400x24',str(binary),mode,str(R),str(pilot),str(out),str(w),str(h),*args];start=time.monotonic();print('START',tag,flush=True)
 with (out/'capture.log').open('w')as log:rc=subprocess.run(cmd,cwd=R,env=environment(out/'profile',view=='phone'),stdout=log,stderr=subprocess.STDOUT,timeout=900).returncode
 identity['jobs'].append({'tag':tag,'command':cmd,'returncode':rc,'seconds':round(time.monotonic()-start,2)});write(base/'execution.json',identity);print('END',tag,rc,flush=True)
 if rc:raise SystemExit(rc)
