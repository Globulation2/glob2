from pathlib import Path
import json,sys,subprocess,hashlib,importlib.util
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';O=B/'native-captures/v10-integration'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
revision,proofpath,proofsha=sys.argv[1:];proof=Path(proofpath).resolve();assert sha(proof)==proofsha
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==revision
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
assert not (B/'v10-frozen-inputs.json').exists(),'Preserve actual prior input freeze'
subprocess.run([sys.executable,str(Path(__file__).with_name('prepare.py'))],cwd=R,check=True)
spec=importlib.util.spec_from_file_location('tp',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p);native,errors=p.CHECKER.read_table(R/'data/texts.bg.txt');assert not errors
online=json.loads((R/'platform/packages/i18n/locales/bg.json').read_text());plan=json.loads((O/'font-delta-plan.json').read_text())
meta={'locale':'bg','source_revision':revision,'candidate_revision':revision,'compiled_runtime_revision':revision,'review_proof_path':str(proof),'review_proof_sha256':proofsha,'original_catalog_sha256':plan['catalog_sha256'],'scope':'Post-master integration, native exact e9fd and33 reviewed online corrections; all original V9 actual producer records preserved'}
paths=[R/'data/texts.bg.txt',R/'platform/packages/i18n/locales/bg.json',proof]
for name,cats in [('full',{'native':native,'online':online}),('delta',{surf:json.loads((O/('delta-'+surf+'.json')).read_text())for surf in ['native','online']})]:
 base=B/('v10-'+name+'-render-input');out=base/'render-input/bg'
 write(base/'manifest.json',{'revision':revision,'review_proof_sha256':proofsha})
 write(out/'metadata.json',dict(meta,scope=name+' render corpus'))
 for surf,cat in cats.items():write(out/(surf+'.json'),cat)
 paths.extend([base/'manifest.json',*sorted(out.glob('*.json'))])
write(B/'v10-frozen-inputs.json',{'revision':revision,'final_render_values':plan['total_final_literal_variants'],'fresh_render_values':plan['changed_literal_variants'],'carry_render_values':plan['unchanged_exact_literal_variants'],'input_files_sha256':{str(f.relative_to(R)):sha(f)for f in paths},'review_proof_sha256':proofsha})
