from pathlib import Path
import json,hashlib,importlib.util,subprocess
R=Path(__file__).resolve().parents[3];B=R/'artifacts/bulgarian';O=B/'native-captures/v10-integration'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('tp',R/'tools/localization/translation_program.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
native,errs=p.CHECKER.read_table(R/'data/texts.bg.txt');assert not errs
current={'native':native,'online':json.loads((R/'platform/packages/i18n/locales/bg.json').read_text())}
old=json.loads((B/'native-captures/v9-final/full-font-plan.json').read_text());oldv={(x['surface'],x['key'],x['branch']):x['target'] for x in old['values']}
newv={(surf,k,br):v for surf,cat in current.items() for k,val in cat.items() for br,v in (val.items()if isinstance(val,dict)else[('',val)])}
changes={k:v for k,v in newv.items()if oldv.get(k)!=v};carry={k:v for k,v in newv.items()if oldv.get(k)==v};assert len(newv)==len(carry)+len(changes)
delta={surf:{} for surf in current}
for (surf,k,branch),v in changes.items():
 if branch:delta[surf].setdefault(k,{})[branch]=v
 else:delta[surf][k]=v
write(O/'font-delta-plan.json',{'status':'Preparation only; actual binary and final input freeze pending','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'catalog_sha256':{surf:sha(R/path)for surf,path in [('native','data/texts.bg.txt'),('online','platform/packages/i18n/locales/bg.json')]},'previous_plan_sha256':sha(B/'native-captures/v9-final/full-font-plan.json'),'total_final_literal_variants':len(newv),'unchanged_exact_literal_variants':len(carry),'changed_literal_variants':len(changes),'fresh_combinations':12,'planned_fresh_samples':12*len(changes),'old_measurement_identity':'EA0 actual V9 producer; carry is exact literal/font input proof only, not fresh final process measurements','changed_values':[{'surface':s,'key':k,'branch':b,'target':v}for (s,k,b),v in changes.items()]})
for surf,cat in delta.items():write(O/('delta-'+surf+'.json'),cat)
print(len(newv),len(carry),len(changes),12*len(changes))
