from pathlib import Path
import difflib,hashlib,json,subprocess
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2];STAGE=BASE/'stage'
manifest=json.loads((BASE/'baseline.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
new=['scons/online_error_catalog.py','test/build_system/test_online_error_catalog_build.py','tools/localization/build_online_error_catalog.py','test/test_online_error_catalog.py','src/online/ApiErrorText.h','src/online/ApiErrorText.cpp','src/online/ApiErrorTextTest.cpp','src/ui/ApiErrorText.h']
patch=[];changed=[]
for name in sorted(list(manifest['files'])+new):
 path=ROOT/name;staged=STAGE/name
 if name in manifest['files']:
  assert sha(path)==manifest['files'][name],('Live source changed; recheck before exporting',name)
  original=path.read_text().splitlines(keepends=True);old='a/'+name
 else:
  assert not path.exists(),('New live path appeared',name)
  original=[];old='/dev/null'
 revised=staged.read_text().splitlines(keepends=True)
 if original==revised:continue
 patch.extend(difflib.unified_diff(original,revised,fromfile=old,tofile='b/'+name))
 changed.append({'path':name,'new':name in new,'staged_sha256':sha(staged),'staged_bytes':staged.stat().st_size})
output=BASE/'native-error-bridge.patch';output.write_text(''.join(patch));subprocess.run(['git','apply','--check',str(output)],cwd=ROOT,check=True)
subprocess.run(['git','apply','--check',str(BASE/'renderer-labels-separate.patch')],cwd=ROOT,check=True)
report={'base_revision':manifest['base_revision'],'patch':output.name,'patch_bytes':output.stat().st_size,'patch_sha256':sha(output),'files':changed,'generated_resource':json.loads((BASE/'generation.json').read_text()),'generated_resource_committed':False,'optional_renderer_patch':{'path':'renderer-labels-separate.patch','bytes':(BASE/'renderer-labels-separate.patch').stat().st_size,'apply_check':'passed separately; not included in main patch'},'live_status':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).splitlines(),'limits':'Staging only; UI object builds/native/browser integration are deferred until root applies after active builds finish.'};(BASE/'patch-manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'patch_bytes':report['patch_bytes'],'files':len(changed),'apply_check':'passed','live_status':report['live_status']},indent=2))
