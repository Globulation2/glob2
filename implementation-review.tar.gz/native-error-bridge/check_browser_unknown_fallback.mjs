import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
const root=process.cwd(),base=root+'/artifacts/bulgarian/native-error-bridge';
const localization=await import(pathToFileURL(root+'/platform/packages/i18n/src/index.ts'));
const messages=await import(pathToFileURL(root+'/platform/apps/web/src/messages.ts'));
const bg=JSON.parse(fs.readFileSync(root+'/platform/packages/i18n/locales/bg.json'));
const census=JSON.parse(fs.readFileSync(base+'/plural-source-census.json'));
localization.registerCatalog('bg',bg);await localization.setLocale('bg');
const literals=[...new Set(census.apiErrorLiteralArguments.filter(row=>row.catalogShape==='uncatalogued').map(row=>row.key))];
const generic=bg['Something went wrong. Please try again.'];const results=[];
for(const source of literals){const body={code:'bad_request',message:source,messageKey:source};const before=JSON.stringify(body);const displayed=messages.translateError({body});if(displayed!==generic)throw Error('Unexpected raw/other fallback: '+source);if(JSON.stringify(body)!==before)throw Error('Raw body mutated');results.push({source,displayed,result:'reviewed Bulgarian generic',rawBodyUnchanged:true});}
const report={method:'Actual platform/apps/web/src/messages.ts -> platform/packages/i18n/src/index.ts translateError executed under Node with the actual registered Bulgarian catalog; matches ApiError.message getter path. No network/browser/provider calls.',locale:localization.getLocale(),generic,results,limits:'This checks the common API error display bridge, not per-route browser interaction, image onError handling or caller-specific replacement notices.'};
fs.writeFileSync(base+'/browser-unknown-fallback.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({cases:results.length,allGeneric:true,rawBodiesUnchanged:true}));
