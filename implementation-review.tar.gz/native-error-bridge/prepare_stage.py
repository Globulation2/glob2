from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'artifacts/bulgarian/native-error-bridge';STAGE=BASE/'stage';STAGE.mkdir(exist_ok=True)
files=['src/online/PlatformProtocol.h','src/online/PlatformProtocol.cpp','src/online/PlatformProtocolTest.cpp','src/SConscript','scons/sources.py','test/tests.py','src/ui/settings/SettingsScreenOnline.cpp','src/ui/settings/SettingsScreenCustomAIs.cpp','src/online/screens/QuickMatchScreen.cpp','src/online/screens/OnlineProfileScreen.cpp','src/online/screens/OnlineMapsScreen.cpp','src/online/screens/BuildingLibraryScreen.cpp','src/online/screens/OnlineGeneratorsScreen.cpp','src/online/PlatformRoom.cpp']
manifest={'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'files':{}}
for name in files:
 p=STAGE/name;p.parent.mkdir(parents=True,exist_ok=True);data=(ROOT/name).read_bytes();p.write_bytes(data);manifest['files'][name]=hashlib.sha256(data).hexdigest()
for name in ['platform/packages/i18n/locales/en.json','platform/packages/i18n/locales/bg.json']:
 p=STAGE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
(BASE/'baseline.json').write_text(json.dumps(manifest,indent=2)+'\n')
