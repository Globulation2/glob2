from pathlib import Path
B=Path(__file__).resolve().parent/'stage'
p=B/'src/online/PlatformProtocol.h';s=p.read_text().replace('\tJson details;\n};','\tJson details;\n\t// Optional presentation metadata; never replaces raw diagnostic fields.\n\tstd::optional<std::string> messageKey = std::nullopt;\n\tJson messageParams = Json::object();\n\tbool invalidLocalization = false;\n};',1);p.write_text(s)
p=B/'src/online/PlatformProtocol.cpp';s=p.read_text();needle='\t\tif (auto details = body.find("details"); details != body.end())\n\t\t\terror.details = *details;';addition='''
        if (auto key = body.find("messageKey"); key != body.end())
        {
            if (key->is_string() && !key->get_ref<const std::string &>().empty())
                error.messageKey = key->get<std::string>();
            else
                error.invalidLocalization = true;
        }
        if (auto params = body.find("messageParams"); params != body.end())
        {
            bool valid = params->is_object();
            if (valid)
                for (const auto &value : *params)
                    if (!(value.is_string() || value.is_number() || value.is_boolean() || value.is_null()))
                        valid = false;
            if (valid) error.messageParams = *params;
            else error.invalidLocalization = true;
        }''';assert needle in s;s=s.replace(needle,needle+addition,1);p.write_text(s)
p=B/'src/online/PlatformProtocolTest.cpp';s=p.read_text().replace('CHECK_EQ(localized.error.details, failed.error.details);','CHECK_EQ(localized.error.details, failed.error.details);\n\t\tCHECK_EQ(localized.error.messageKey.value(), "Room {id} not found.");\n\t\tCHECK_EQ(localized.error.messageParams["id"], "ABCDEF");\n\t\tCHECK_FALSE(localized.error.invalidLocalization);');p.write_text(s)
# UI presentation boundaries only; no PlatformClient/model error rewriting.
ui=['src/ui/settings/SettingsScreenOnline.cpp','src/ui/settings/SettingsScreenCustomAIs.cpp','src/online/screens/QuickMatchScreen.cpp','src/online/screens/OnlineProfileScreen.cpp','src/online/screens/OnlineMapsScreen.cpp','src/online/screens/BuildingLibraryScreen.cpp','src/online/screens/OnlineGeneratorsScreen.cpp']
for name in ui:
 p=B/name;s=p.read_text();s='#include "ui/ApiErrorText.h"\n'+s
 for expression in ['response.error','r.error','artwork.error','error']:
  # Keep explicit empty-message specialized fallbacks, replace only the value.
  import re
  s=re.sub(r'\b'+re.escape(expression)+r'\.message(?!\.)', 'apiErrorText('+expression+')',s)
 s=s.replace('share->error().message :', 'apiErrorText(share->error()) :')
 s=s.replace(': download->error();', ': onlineProblemText(download->error());')
 p.write_text(s)
# Room diagnostics remain raw; only rendered event text uses presentation.
p=B/'src/online/PlatformRoom.cpp';s=p.read_text();s='#include "ui/ApiErrorText.h"\n'+s;s=s.replace(': problem;\n\t\t\t\t\t\t\t   push', ': Glob2UI::apiErrorText(response.error);\n\t\t\t\t\t\t\t   push',1)
s=s.replace('event.text = formatted("[room map upload failed %0]", problem);','event.text = formatted("[room map upload failed %0]", !response.ok ? Glob2UI::apiErrorText(response.error) : Glob2UI::onlineProblemText(problem));');p.write_text(s)
p=B/'scons/sources.py';s=p.read_text().replace("    'online/PlatformProtocol.cpp',", "    'online/PlatformProtocol.cpp',\n    'online/ApiErrorText.cpp',",1);p.write_text(s)
p=B/'test/tests.py';s=p.read_text().replace("    '#src/online/PlatformProtocolTest.cpp',", "    '#src/online/PlatformProtocolTest.cpp',\n    '#src/online/ApiErrorTextTest.cpp',",1);p.write_text(s)
p=B/'src/SConscript';s=p.read_text();needle='local = env.Clone()';insert='''
# Same generated resource for native and serial/threaded browser client builds.
# Only reviewed en/bg inputs are embedded. Each variant tracks both catalogs and
# the generator explicitly, so changed translations rebuild the one consumer.
import subprocess
import sys
from SCons.Action import Action
online_error_catalog = local.File('generated/OnlineErrorCatalog.h')
def build_online_error_catalog(target, source, env):
    subprocess.check_call([sys.executable, source[0].abspath,
        '--english', source[1].abspath, '--bulgarian', source[2].abspath,
        '--output', target[0].abspath])
    return 0
online_error_catalog = local.Command(online_error_catalog, [
    '#tools/localization/build_online_error_catalog.py',
    '#platform/packages/i18n/locales/en.json',
    '#platform/packages/i18n/locales/bg.json'],
    Action(build_online_error_catalog, 'Embedding reviewed Bulgarian API error text'))
local.Append(CPPPATH=[Dir('.').abspath])
''';s=s.replace(needle,needle+insert,1);needle='strict_objects.update({source: ordinary_mapping[source] for source in ordinary_sources})';s=s.replace(needle,needle+"\nlocal.Depends(ordinary_mapping['online/ApiErrorText.cpp'], online_error_catalog)",1);p.write_text(s)
