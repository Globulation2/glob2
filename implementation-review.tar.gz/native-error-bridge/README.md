# Staged native API-error presentation bridge

This folder contains an unapplied patch. Live native/browser sources remain unchanged.

- `native-error-bridge.patch`: 27 files, 60,154 bytes; `git apply --check --whitespace=error` passes.
- `renderer-labels-separate.patch`: the previously supplied semantic renderer-label/diagnostic fix, copied unchanged and independently apply-checked. It is intentionally separate.
- `patch-manifest.json`: baseline revision, original/live and staged file SHA-256 identities, changed paths and resource size.
- `test-results.json`, `generator-tests.log`, `compile-tests.log`, `presenter-tests.log`: actual standalone checks. Eight Python generator tests and six real-SCons build-contract tests pass. Seven doctest codec/presenter cases pass with 137 assertions. Only doctest main, staged protocol codec, presenter and presenter tests were compiled; no SCons or full engine/browser build was run.

## Behavior

`ApiError` keeps code/message/details unchanged and appends optional presentation metadata. Scalar parameter values remain JSON scalars; malformed keys/parameter containers set an internal invalid-metadata flag. The wire protocol and PlatformClient's raw errors are unchanged.

The pure presenter handles Bulgarian/bg-BG only. Known source keys use the reviewed Bulgarian online string and a single forward interpolation pass. Inserted values containing `{slot1}`, `%0` or markup-like characters remain literal. Missing parameters, unknown strings or malformed metadata use the existing reviewed generic summary. Legacy fallback is an exact English source-literal lookup, including sparse source aliases; there is no fuzzy matching or reconstruction of interpolated text. Non-Bulgarian presentation returns the original raw message.

The generated resource consumes only the existing authoritative en/bg JSON files (current English 7ef5053b…, Bulgarian 69de8f4c…). It contains 2,816 strings, excludes 27 plural objects because ErrorBody has no plural selector, and records exact input SHA-256 values. Output is 591,295 ASCII bytes, with raw C++ string chunks <=8,192 bytes to avoid MSVC literal limits. It is generated into each variant's build directory and is not part of the patch. Native, serial/threaded browser, Android and iOS builders independently call the shared `scons/online_error_catalog.py` rule. Each writes under its established `include/generated` directory; there is no global CPPPATH addition or compile-signature change. Presenter and test consumer objects explicitly depend on that target, including native/Android unit-production reuse or fallback. Contract tests execute actual builder wiring with real SCons DAG nodes while the header is absent. No new runtime dependency or translation source/value is added. The 72 chunks concatenate to 588,400 JSON bytes on the first Bulgarian error only; that synchronous first call parses into a process-static nlohmann lookup, releases the temporary joined string, and reuses the map thereafter. Non-Bulgarian calls return before joining/parsing. Target-device first-error latency, process memory and production binary cost have not been measured.

`Glob2UI::apiErrorText` reads the current StringTable language code. Ordinary typed API errors are presented at UI boundaries in settings/custom AIs, profile, maps, buildings, generators, QuickMatch, room events and the Bulgarian music REST path. Library errors are presented before conversion into `runtime_error`. Existing cooldown, version, conflict, account-needed and not-found branches stay authoritative. The music path preserves existing non-Bulgarian behavior. JSON/script/`e.what()` diagnostics are not blanket-translated.

## Plain transport diagnostic trace

- `PlatformClient::lastError()` remains raw. Its only ordinary screen reference is OnlineHubScreen's offline-state condition; the banner is already localized and does not display the raw text. Probes/tests/harnesses continue reading raw diagnostics.
- MapCache download errors do enter map UI as plain strings. That display now uses the safe generic/exact-literal presenter; the download object's raw `error()` remains unchanged.
- PlatformRoom keeps its diagnostic `problem` string raw; only player-facing error event text is presented.
- The music decoder logs the raw API message before setting its Bulgarian notice.

## Deferred integration

After active builds finish, root can apply the main patch and optionally the separate renderer patch. Re-run the ordinary protocol/presenter registry, PlatformClient/test doubles and affected UI harnesses, then native and both browser variants. The staged helper suite does not establish complete UI object compilation, actual server-error rendering, Windows/MSVC or browser execution. New generator tests also run as `python3 test/test_online_error_catalog.py` after application. Frozen source/catalog identity and current error-field behavior must remain preserved.

The first exploratory standalone compile exposed a test-only `std::string`/Json comparison mismatch; it is retained in `compile-tests-initial.log`. The corrected final test run is source-hash-bound in `test-results.json` and passes. The plural source census proves all 27 excluded keys have web UI references and no API-production literal references. Current API literals include 606 catalog string alternatives and 13 uncatalogued occurrences (10 distinct messages); 27 nonliteral diagnostic arguments are listed explicitly. Unknowns use a safe generic summary but retain a specific-meaning coverage gap. `uncatalogued-api-source-audit.json` records every source/callsite, verified browser generic fallback and careful equivalence/proposal limits. `browser-unknown-fallback.json` comes from the actual browser translation modules: all 10 distinct uncatalogued sources use the reviewed Bulgarian generic and retain raw bodies. No route or catalog remediation was applied. There were no paid calls, live-file edits, commits or deployment/publication actions.
