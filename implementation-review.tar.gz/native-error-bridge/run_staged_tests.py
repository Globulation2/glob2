"""Standalone staged checks only; never invokes SCons or modifies live sources."""
import hashlib,json,subprocess,time
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2];STAGE=BASE/'stage'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=[STAGE / row['path'] for row in json.loads((BASE/'patch-manifest.json').read_text())['files']]
inputs.append(STAGE/'include/generated/OnlineErrorCatalog.h')
before={str(p.relative_to(BASE)):sha(p) for p in inputs};checks=[]
def run(name,command):
 start=time.monotonic()
 with (BASE/(name+'.log')).open('w') as log: result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 checks.append({'name':name,'command':command,'exit_code':result.returncode,'seconds':round(time.monotonic()-start,2),'log':name+'.log'})
 if result.returncode: raise SystemExit(result.returncode)
run('generator-tests',['python3',str(STAGE/'test/test_online_error_catalog.py'),'-v'])
run('build-contract-tests',['python3',str(STAGE/'test/build_system/test_online_error_catalog_build.py'),'-v'])
command=['g++','-std=c++20','-O0','-g0','-fmax-errors=3',
 '-I'+str(STAGE/'include'),'-I'+str(STAGE/'src/online'),'-I'+str(ROOT/'src/online'),'-I'+str(ROOT/'src/app'),'-I'+str(ROOT/'src/game'),'-I'+str(ROOT/'third_party/nlohmann-json/include'),'-I'+str(ROOT/'test/support'),
 str(BASE/'doctest-main.cpp'),str(STAGE/'src/online/PlatformProtocol.cpp'),str(STAGE/'src/online/ApiErrorText.cpp'),str(STAGE/'src/online/ApiErrorTextTest.cpp'),'-o',str(BASE/'presenter-tests')]
run('compile-tests',command)
run('presenter-tests',[str(BASE/'presenter-tests'),'--no-colors'])
assert before=={str(p.relative_to(BASE)):sha(p) for p in inputs},'Staged inputs changed while checking'
(BASE/'test-results.json').write_text(json.dumps({'scope':'Standalone staged generator + codec + presenter only; no live source changes or full builds','checks':checks,'staged_inputs_sha256':before},indent=2)+'\n')
print(json.dumps(checks,indent=2))
