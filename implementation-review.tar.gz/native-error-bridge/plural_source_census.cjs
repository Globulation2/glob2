const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=process.cwd(),ts=require(root+'/platform/node_modules/typescript');
const base=path.join(root,'artifacts/bulgarian/native-error-bridge');
const en=JSON.parse(fs.readFileSync('platform/packages/i18n/locales/en.json'));
const excluded=Object.keys(en).filter(k=>typeof en[k]!=='string');
const byKey=Object.fromEntries(excluded.map(k=>[k,[]])); const errors=[],dynamic=[];
const files=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]);
const sources=[...files('platform/apps/api/src'),...files('platform/apps/web/src')].filter(f=>/\.tsx?$/.test(f));
const literal=n=>n&&(ts.isStringLiteral(n)||ts.isNoSubstitutionTemplateLiteral(n))?n.text:undefined;
const options=(n)=>{const v=literal(n);if(v!==undefined)return [v]; if(n&&ts.isConditionalExpression(n))return [...options(n.whenTrue),...options(n.whenFalse)];return [];};
for(const file of sources){const source=fs.readFileSync(file,'utf8'),tree=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true);
 const at=n=>({file,line:tree.getLineAndCharacterOfPosition(n.getStart(tree)).line+1});
 function visit(n){ const text=literal(n);if(text!==undefined&&Object.hasOwn(byKey,text)){ let p=n.parent;while(p&&!ts.isCallExpression(p)&&!ts.isJsxAttribute(p)&&!ts.isVariableDeclaration(p)&&!ts.isPropertyAssignment(p))p=p.parent;byKey[text].push({...at(n),context:p?p.getText(tree).slice(0,320):n.parent.getText(tree).slice(0,320)}); }
 if(file.startsWith('platform/apps/api/src')&&ts.isCallExpression(n)&&n.expression.getText(tree)==='apiError'){
  const argument=n.arguments[1],known=options(argument);for(const key of known)errors.push({...at(n),key,catalogShape:Object.hasOwn(en,key)?typeof en[key]==='string'?'string':'plural':'uncatalogued'});
  if(!known.length||ts.isConditionalExpression(argument)&&(!options(argument.whenTrue).length||!options(argument.whenFalse).length))dynamic.push({...at(n),expression:argument?.getText(tree)});
 }
 ts.forEachChild(n,visit);
 } visit(tree);
}
const apiPlural=errors.filter(x=>x.catalogShape==='plural');
const excludedReferences=excluded.map(key=>({key,apiErrorLiteralReferences:errors.filter(x=>x.key===key),sourceReferences:byKey[key]}));
const report={method:'TypeScript AST census of direct literal/conditional apiError message arguments and every excluded-key literal in API/web production source; no regex/fuzzy source reconstruction.',excludedPluralKeys:excludedReferences,apiErrorLiteralArguments:errors,unresolvedDynamicApiErrorArguments:dynamic,summary:{excludedPluralKeyCount:excluded.length,apiErrorLiteralArgumentCount:errors.length,knownCatalogStringArguments:errors.filter(x=>x.catalogShape==='string').length,uncataloguedStringArguments:errors.filter(x=>x.catalogShape==='uncatalogued').length,apiPluralArguments:apiPlural.length,dynamicArguments:dynamic.length,excludedKeysWithUISourceReference:excludedReferences.filter(x=>x.sourceReferences.some(r=>r.file.startsWith('platform/apps/web/src'))).length},signature:{file:'platform/apps/api/src/errors.ts',contract:'apiError(code: ErrorCode, message: string, details?: unknown, messageParams?: Record<string,string|number>): HttpError; ErrorBody.message/messageKey remain strings. No plural-selector field exists.'},sourceFilesSha256:Object.fromEntries(sources.map(file=>[file,crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')])),limits:'Nonliteral exception/diagnostic arguments remain explicitly listed, not inferred as catalog keys. They are strings by the API helper signature and get exact-literal lookup or generic native summary. This is current source inventory, not a claim about arbitrary future/dynamic messages.'};
fs.writeFileSync(path.join(base,'plural-source-census.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report.summary,null,2));
if(excluded.length!==27||apiPlural.length)process.exitCode=1;
