from pathlib import Path
b=Path('artifacts/colony-context-repair/client/threaded/index.wasm').read_bytes()
def u(buf,i):
 n=s=0
 while True:
  x=buf[i];i+=1;n|=(x&127)<<s
  if not x&128:return n,i
  s+=7
def enc(n):
 a=[]
 while True:
  x=n&127;n>>=7;a.append(x|(128 if n else 0))
  if not n:return bytes(a)
idx=8
while idx<len(b):
 sid=b[idx];sz,st=u(b,idx+1)
 if sid==10:break
 idx=st+sz
count,p=u(b,st);bodies=[]
for i in range(count):
 size,start=u(b,p);body=b[start:start+size]
 if i==15410:
  old=b'\x10'+enc(21357)
  assert body.count(old)==1 and body.count(b'\xfc\x0b\x00')==1
  body=body.replace(old,b'\x1a\x41\x00').replace(b'\xfc\x0b\x00',b'\x1a\x1a\x1a')
 bodies.append(enc(len(body))+body);p=start+size
section=enc(count)+b''.join(bodies)
Path('artifacts/colony-context-repair/no-zero-buffer.wasm').write_bytes(b[:idx]+bytes([10])+enc(len(section))+section+b[st+sz:])
