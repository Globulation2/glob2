from pathlib import Path
import argparse, hashlib, json, math, os, statistics, subprocess, time
from scipy.stats import t
parser=argparse.ArgumentParser()
parser.add_argument('--mode',choices=['gpu','cpu'],default='gpu')
parser.add_argument('--counts',default='8')
parser.add_argument('--pairs',type=int,default=8)
parser.add_argument('--output',required=True)
args=parser.parse_args()
root=Path.cwd(); manifest=json.loads((root/'artifacts/gpu-resources/frozen-manifest.json').read_text())
refs={'before':manifest['candidate'],'after':manifest['resource_candidate']}
out=root/args.output;out.mkdir(parents=True,exist_ok=False)
for ref in refs.values():
 assert hashlib.sha256((root/ref['binary']).read_bytes()).hexdigest()==ref['binary_sha256']
for fixture in manifest['fixtures']:
 assert hashlib.sha256((root/fixture['path']).read_bytes()).hexdigest()==fixture['sha256']
counts=[int(x) for x in args.counts.split(',')]; assert all(x in (1,2,4,8) for x in counts)
env={**os.environ,'VK_DRIVER_FILES':'/usr/share/vulkan/icd.d/nvidia_icd.json','GLOB2_GRADIENT_DIAGNOSTICS':'0','GLOB2_VULKAN_VERIFY_TRANSFERS':'0','GLOB2_GRADIENT_VERIFY':'0'}
protocol=dict(mode=args.mode,counts=counts,pairs=args.pairs,affinity=sorted(os.sched_getaffinity(0)),manifest=manifest,metrics=['whole_process_cpu_including_startup_and_exit','benchmark_window_cpu_including_required_job_drain'],unit='one complete cohort run per alternating pair',qualification=False,limitations=['Candidate workload coverage not audited','Publication-wait p95 unavailable with diagnostics disabled','Benchmark window excludes final device teardown; whole-process metric includes it'])
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');rows=[]
for pair in range(args.pairs):
 for fixture in manifest['fixtures']:
  for count in counts:
   order=('before','after') if pair%2==0 else ('after','before')
   pair_results=[]
   for revision in order:
    dest=out/f'{pair}-{fixture["name"]}-{count}-{revision}'
    backend='vulkan' if args.mode=='gpu' else 'cpu';algo='frozen8' if args.mode=='gpu' else 'buckets'
    command=[str(root/refs[revision]['binary']),'game','run','--load-game',str(root/fixture['path']),'--ticks',str(fixture['tick']+fixture['window_ticks']),'--benchmark-warmup',str(fixture['warmup_ticks']),'--compute-threads',str(count),'--gradient-backend',backend,'--gradient-algorithm',algo,'--gradient-verify','off','--output-dir',str(dest)]
    with dest.with_suffix('.log').open('w') as log:
     started=time.monotonic_ns(); process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
     _,status,usage=os.wait4(process.pid,0); process.returncode=os.waitstatus_to_exitcode(status)
     elapsed=time.monotonic_ns()-started
    if process.returncode: raise RuntimeError(f'{dest}: exit {process.returncode}')
    result=json.loads((dest/'result.json').read_text()); assert result['benchmark_measured_ticks']==fixture['window_ticks']-fixture['warmup_ticks']
    row=dict(pair=pair,fixture=fixture['name'],count=count,revision=revision,command=command,elapsed_ns=elapsed,whole_cpu_ns=round((usage.ru_utime+usage.ru_stime)*1e9),cpu_per_tick=round((usage.ru_utime+usage.ru_stime)*1e9)/fixture['window_ticks'],window_cpu_per_tick=result['benchmark_run_cpu_ns']/result['benchmark_measured_ticks'],setup_cpu_ns=result['benchmark_setup_cpu_ns'],gpu_fields=result['gradient_gpu_fields'],fallbacks=result['gradient_cpu_fallbacks'],checksum=result['finalChecksum'],max_rss_kib=usage.ru_maxrss)
    rows.append(row);pair_results.append(row);(out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n')
   assert pair_results[0]['checksum']==pair_results[1]['checksum'], 'simulation mismatch'
 print('pair',pair+1,'completed',flush=True)
summary={'pairs':args.pairs,'mode':args.mode,'fixtures':{},'qualification':False}
def compare(before,after):
 diffs=[x-y for x,y in zip(before,after)];mean=statistics.mean(diffs);base=statistics.mean(before)
 half=float(t.ppf(.975,len(diffs)-1))*statistics.stdev(diffs)/math.sqrt(len(diffs))
 return dict(before_mean=base,after_mean=statistics.mean(after),savings_pct=100*mean/base,paired_95_ci_pct=[100*(mean-half)/base,100*(mean+half)/base])
for metric in ('cpu_per_tick','window_cpu_per_tick'):
 cohorts={revision:[] for revision in refs}
 for pair in range(args.pairs):
  for revision in refs:
   cohorts[revision].append(sum(row[metric]*next(f['weight'] for f in manifest['fixtures'] if f['name']==row['fixture'])/len(counts) for row in rows if row['pair']==pair and row['revision']==revision))
 summary[metric]=compare(cohorts['before'],cohorts['after'])
for fixture in manifest['fixtures']:
 for count in counts:
  selected=[r for r in rows if r['fixture']==fixture['name'] and r['count']==count]
  before=sorted([r for r in selected if r['revision']=='before'],key=lambda r:r['pair']);after=sorted([r for r in selected if r['revision']=='after'],key=lambda r:r['pair'])
  summary['fixtures'][f'{fixture["name"]}-{count}']={**compare([r['cpu_per_tick'] for r in before],[r['cpu_per_tick'] for r in after]),'median_elapsed_change_pct':100*(statistics.median(r['elapsed_ns'] for r in after)/statistics.median(r['elapsed_ns'] for r in before)-1),'before_gpu_fields':sum(r['gpu_fields'] for r in before),'after_gpu_fields':sum(r['gpu_fields'] for r in after)}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='fixtures'},indent=2),flush=True)
