import json, os, subprocess, sys, time
from pathlib import Path
ROOT=Path.cwd()
OUT=ROOT/'artifacts/service-restoration'
BUILD='build/darwin/client/debug/dev-dev_fast-true-linker-auto'
mode=sys.argv[1] if len(sys.argv)>1 else "final"
results=[]
def run(name,command,env=None):
    print(f'START {name}',flush=True)
    start=time.time()
    with (OUT/(mode+'-'+name+'.log')).open('w') as log:
        p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
    results.append({'name':name,'command':command,'exit_code':p.returncode,'elapsed_seconds':round(time.time()-start,3)})
    (OUT/(mode+'-results.json')).write_text(json.dumps(results,indent=2)+'\n')
    print(f'END {name}: exit {p.returncode}',flush=True)
    if p.returncode:sys.exit(p.returncode)
if mode.isdigit():
    pid=int(mode)
    while True:
        try:os.kill(pid,0)
        except ProcessLookupError:break
        time.sleep(5)
env=os.environ.copy();env['PYTHONPATH']=str(ROOT)
run('build-current-source',['python3','tools/dev_build.py','tests',BUILD+'/src/glob2'],env)
filters=['BuildingStock/*','BuildingServices/*','BuildingExpel/*','EnteringUnitSave/*','UnitContinuation/*','UnitCustomization/*','BuildingAreaEffects/*','SharedWorkerLifecycle/*','SimulationReadPhase/*','JavaScriptCompatibility/*','TeamStatsSave/*','MatchSetup/the simulation data hash*','PlatformProtocol/the local sim version*','PlatformClient/an unsupported sim version*']
args=['python3','test/run_tests.py','--build-dir',BUILD,'--binary','all','--no-display','--junit',str(OUT/'focused.xml'),'--artifacts',str(OUT/'tests'),'--write-inventory',str(OUT/'inventory.json')]
for f in filters:args+=['--filter',f]
if mode=='final':
    run('relay-build',['python3','tools/dev_build.py','role=relay','relay-tests'],env)
    run('relay',['build/darwin/relay/debug/dev-dev_fast-true-linker-auto/src/glob2-relay-tests','--reporters=junit'])
    run('focused',args)
else:run('blocked-regressions',['python3','test/run_tests.py','--build-dir',BUILD,'--binary','engine','--filter','BuildingStock/canceled entering explorers wait*','--filter','BuildingStock/funded explorers rebound*','--junit',str(OUT/'blocked.xml'),'--artifacts',str(OUT/'blocked-artifacts')])
fixtures=['python3','test/run_tests.py','--build-dir',BUILD,'--binary','engine','--filter','TurnEngineHarness/the committed*','--filter','RuntimeResources/frozen seeded resource compositions preserve invariants and exact simulation continuation*']
if mode=='prepare':
    run('regenerate-fixtures',fixtures+['--update-fixtures','--junit',str(OUT/'regenerate.xml'),'--artifacts',str(OUT/'fixture-artifacts')])
    sys.exit(0)
run('check-fixtures',fixtures+['--junit',str(OUT/'fixtures.xml'),'--artifacts',str(OUT/'fixture-check')])
run('sim-revision',['python3','test/check_sim_revision.py','--base','441870ef12bcc96337e65f1fbfe036a13d5eefb1'])
for workers in (1,4):
    run('verify-'+str(workers),[BUILD+'/src/glob2','match','verify','test/fixtures/multiplayer/FourSquares1.g2mr','--map-file','maps/FourSquares1.map.gz','--output-dir',str(OUT/('verify-'+str(workers))),'--compute-threads',str(workers)])
print('VALIDATION COMMANDS COMPLETED',flush=True)
