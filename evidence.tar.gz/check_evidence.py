from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as E
root=Path(__file__).resolve().parent
a=root/'verify-1/checksums.txt';b=root/'verify-4/checksums.txt'
assert a.read_bytes()==b.read_bytes()==Path('test/fixtures/multiplayer/FourSquares1.verify-trace.txt').read_bytes()
print('One/four-worker traces equal the committed golden:',hashlib.sha256(a.read_bytes()).hexdigest())
for name in ['verify-1','verify-4']:
 verdict=json.loads((root/name/'verdict.json').read_text())
 assert verdict['verdict']=='verified' and not verdict['orderRejections']
 print(name,verdict['verdict'],'final tick',verdict['outcome']['finalTick'])
traces=list((root/'tests/SharedWorkerLifecycle').rglob('compute-*.trace'))
assert len(traces)==12 and len({p.read_bytes() for p in traces})==1
print('All twelve saved-continuation traces match across workers1/2/4/8 and diagnostics off/waits/trace.')
j=json.loads((root/'binary-sim-version.json').read_text())
expected=subprocess.check_output(['python3','deploy/sim_version.py','.'],text=True).strip()
assert expected==f"{j['versionMinor']}-{j['netProtocol']}-{j['dataHash']}"
print('Source and binary sim versions match:',expected)
for name in ['focused.xml','fixtures.xml','final-relay.log']:
 tree=E.parse(root/name).getroot()
 assert not list(tree.iter('failure')) and not list(tree.iter('error'))
 cases=list(tree.iter('testcase'));skips=sum(c.find('skipped') is not None for c in cases)
 print(name,'passed',len(cases)-skips,'skipped',skips)
