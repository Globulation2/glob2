import ast, errno, os, pathlib, subprocess, tempfile
from pathlib import Path
from unittest.mock import patch
source=subprocess.check_output(['git','show','f5d1bc51ef61795d4cc165e9ac530f5d2ad21a42:tools/tournaments/worker.py'],text=True)
function=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='usage')
namespace={'Path':Path}
exec(compile(ast.Module(body=[function],type_ignores=[]),'<original-usage>','exec'),namespace)
with tempfile.TemporaryDirectory() as temporary:
 root=Path(temporary);gone=root/'packing-removed';gone.mkdir();(gone/'old').write_bytes(b'old')
 remaining=root/'remaining';remaining.mkdir();(remaining/'live').write_bytes(b'live')
 original=os.scandir
 def scan(path):
  if Path(path)==gone:raise FileNotFoundError(errno.ENOENT,'concurrently removed directory',str(path))
  return original(path)
 with patch.object(pathlib._normal_accessor,'scandir',side_effect=scan):
  try:namespace['usage'](root)
  except FileNotFoundError as error:print('Original Python 3.10 traversal reproduces:',error)
  else:raise AssertionError('Original traversal did not reproduce the observed race')
