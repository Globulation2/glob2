# Old/new candidate calibration review

Eight paired ratios range 0.82322–1.28782; the reported ratio1.06103 has an interval crossing1, so the incremental AI-policy cost is not established. Candidate-first pairs average1.08841, baseline-first1.03434; this order effect reverses the prior approved-control block. First-half1.07187 versus second-half1.05031 is less dramatic than the pure-baseline block, but the final two opposing large ratios dominate uncertainty. Leave-one-pair-out ranges1.03207–1.10020. Preserve both; there is no justification to discard either. Terminal full teams are equal across arms.

This diagnostic motivates category profiling, not a causal claim that new propagation queries account for6%. Exact mutation verification passed as recorded by the measured runner. No new acceptance measurements were produced by this review.
