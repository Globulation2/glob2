# Verification evidence for 531808a85 (merge with master aee20ae52)

- `linux-merge/`: the merged head, Linux, after `origin/master` advanced to
  `aee20ae52`. It holds the full suite, focused gradient/executor/save suites plus every
  test changed by the 8 new master commits, `check_sim_revision`, the re-recorded browser
  replay fixture (recorded twice, byte-identical) and a determinism smoke (busy s19 t6000
  +1024, workers 0/1/4). See `exits.txt`; `exits-manual.txt` records the terrain-studio
  tests rerun directly, because `pytest` is not installed on the host.
- The directories below are from the pre-merge head `2c3370ba9`, whose engine code the
  merge did not change.

Logs, JUnit reports, result.json files, exit codes and hashes. No binaries, saves or
replays.

- `linux-final/`: Ubuntu 24.04 x86_64, GCC 13.3.0, `scons -j14 release=1` at `2c3370ba9`.
  - `exits.txt`: the exit code of every step.
  - `suite.*`: full suite.
  - `det/`: the determinism matrix (`det/summary.txt`, `det/exits.txt`).
  - `oldsaves/`: continuation of old saves (`summary.txt`).
  - `forkrepro/`: fork, save, then load.
  - `pipeline*`: `check_gradient_pipeline.py`.
  - `simrev.log`: `check_sim_revision.py`.
  - `depth*`: full, table and lazy depth.
  - `tsan/`: ThreadSanitizer runs.
- `linux-master/`: the same full suite at master `0507700f1`, same host and toolchain.
- `mac/`: macOS 26.6.2 arm64, Apple clang 21, `scons -j3 release=1 server=0 CXXFLAGS=""` at `2c3370ba9`.
  - The quick suite and the touched harnesses.
  - Cross-platform per-tick checksum digests (`xplat-mac.txt` against `xplat-linux.txt`).
  - The fork repro.

## Failures

| Platform | Test | Also fails without this change | Classification |
| --- | --- | --- | --- |
| Linux | FontKerning: bundled SDL3_ttf moves the pen for kerned pairs | yes (master suite) | environment |
| Linux | TextRaster: native software glyphs at fractional scale | yes (master suite) | environment |
| Linux | TextRaster: scaled and unscaled text rasterisation | yes (master suite) | environment |
| Linux | ImageAssets: 16-bit RGBA exporter reference | yes (master suite) | environment |
| Mac | ImageAssets: 16-bit RGBA exporter reference | yes (pre-branch Mac binary, master test sources) | pre-existing |
| Mac | SkinReadback: export readback matches live compositing | yes (pre-branch Mac binary) | pre-existing |
| Mac | GUIInteractionCoverage: mixed service progress HUD pixel | yes (pre-branch Mac binary) | pre-existing |
| Mac | GameSpeed: live engine speed and pause | passes when run alone | wall-clock bound under load |
