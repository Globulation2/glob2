#!/bin/bash
# Mac side of the cross-platform comparison: the same checkpoints and worker setting as the Linux det runs.
cd "$(dirname "$0")"; D=$(pwd)
B=$D/../../build/darwin/client/release/src/glob2
: > mac.txt
for spec in s19-d8-t6000:6000 s19-d8-t12000:12000 s19-d1-t6000:6000; do
  n=${spec%%:*}; t=${spec##*:}
  rm -rf run-$n
  $B --run-game --load-game $D/$n.game.gz --ticks $((t+1024)) --compute-threads 5 --gradient-workers 4 --telemetry checksums --output-dir $D/run-$n > run-$n.log 2>&1
  code=$?
  echo "$n exit=$code $(shasum -a 256 run-$n/game.replay.checksums | cut -c1-16)" >> mac.txt
done
echo DONE >> mac.txt
