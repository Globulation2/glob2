from pathlib import Path
import subprocess,os,time,json,hashlib,gzip,shutil
root=Path('/dev/shm/glob2-recruitment-profile');os.chdir(root)
out=root/'artifacts/recruitment-reuse';out.mkdir(exist_ok=True)
while True:
 s=(out/'build.log').read_text()
 if 'scons: done building targets.' in s:break
 if 'scons: building terminated' in s:raise RuntimeError('initial build failed')
 time.sleep(5)
time.sleep(1)
env=os.environ.copy();env.update(GLOB2_SDL3_PREFIX='/home/bradley/glob2/build/sdl3/prefix',PYTHONPATH=str(root))
commands=[]
def run(cmd,label):
 cmd=[str(x) for x in cmd];commands.append({'label':label,'argv':cmd});(out/'commands.json').write_text(json.dumps(commands,indent=2))
 print(time.strftime('%H:%M:%S'),label,flush=True)
 with (out/(label+'.log')).open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
run(['scons','release=1','retain_symbols=1','CXXFLAGS=-g1','--build=build/recruitment-profile','-j12','build/recruitment-profile/src/glob2','engine-tests'],'final-build')
run(['python3','test/run_tests.py','--build-dir','build/recruitment-profile','--binary','engine','--filter','BuildingMaterialDemand/*','--filter','Hiring*/*','--filter','FetchHiringScore/*','--filter','UnitContinuation/*','--filter','InnSwap/*','--no-display','-j3','--junit',out/'tests.xml','--artifacts',out/'tests'],'tests')
binaries={'before':root/'artifacts/recruitment-measurements/glob2-optimized','after':root/'build/recruitment-profile/src/glob2'}
comparison={}
for name,save,ticks,threads in [('12k','midgame12k.game.gz',13153,8),('24k','midgame24k.game.gz',25153,8),('24k-serial','midgame24k.game.gz',25153,1)]:
 for label,binary in binaries.items():
  run([binary,'game','run','--load-game',root/save,'--compute-threads',str(threads),'--gpu','off','--ticks',str(ticks),'--telemetry','checksums','--save','final','--output-dir',out/(label+'-'+name)],label+'-'+name)
 checks={}
 for file in ['world.checksums','snapshot.checksums']:
  a=(out/('before-'+name)/file).read_bytes();b=(out/('after-'+name)/file).read_bytes();checks[file]={'identical':a==b,'rows':len(a.splitlines()),'sha256':hashlib.sha256(a).hexdigest()}
 a=gzip.decompress((out/('before-'+name)/'final.game.gz').read_bytes());b=gzip.decompress((out/('after-'+name)/'final.game.gz').read_bytes());checks['save']={'identical':a==b,'sha256':hashlib.sha256(a).hexdigest()}
 assert all(v['identical'] for v in checks.values()),(name,checks)
 comparison[name]=checks
 (out/'behavior.json').write_text(json.dumps(comparison,indent=2))
run([binaries['after'],'match','verify','test/fixtures/multiplayer/FourSquares1.g2mr','--map-file','maps/FourSquares1.map.gz','--compute-threads','8','--output-dir',out/'golden'],'golden')
for label,binary in binaries.items():
 dest=out/(label+'-profile');dest.mkdir(exist_ok=True)
 run(['valgrind','--tool=callgrind','--instr-atstart=no','--separate-threads=yes','--callgrind-out-file='+str(dest/'callgrind.%p'),binary,'game','run','--load-game',root/'midgame24k.game.gz','--compute-threads','8','--gpu','off','--ticks','25153','--save','final','--output-dir',dest/'game'],label+'-callgrind')
 profiles=list(dest.glob('callgrind.*-01'));assert len(profiles)==1
 run(['python3',root/'parse_callgrind.py',profiles[0],out/(label+'-owner.json')],label+'-parse')
 native=gzip.decompress((out/(label+'-24k')/'final.game.gz').read_bytes());profiled=gzip.decompress((dest/'game/final.game.gz').read_bytes());assert native==profiled,label
 a=json.loads((out/(label+'-owner.json')).read_text());totals=[int(x.split()[1]) for x in profiles[0].read_text().splitlines() if x.startswith('totals:')];assert totals==[a['self_total']]
a=json.loads((out/'before-owner.json').read_text());b=json.loads((out/'after-owner.json').read_text())
af={x['function']:x['ir'] for x in a['functions']};bf={x['function']:x['ir'] for x in b['functions']}
summary={'base_commit':'0e36aee51be98cc297d3f6a72fe6438209d0eb9a','ticks':1024,'begin_tick':24128,'end_tick':25152,'before_ir':a['self_total'],'after_ir':b['self_total'],'reduction_percent':100*(1-b['self_total']/a['self_total']),'behavior':comparison,'binary_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['src/building/Step.cpp','src/building/MaterialDemandTest.cpp']}}
summary['function_comparison']=[{'function':n,'before_ir':af.get(n,0),'after_ir':bf.get(n,0),'saved_ir':af.get(n,0)-bf.get(n,0)} for n in sorted(set(af)|set(bf),key=lambda n:af.get(n,0)-bf.get(n,0),reverse=True)]
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print('EXPERIMENT COMPLETE',json.dumps({k:v for k,v in summary.items() if k not in ['function_comparison','behavior']}),flush=True)
