import json,subprocess
from pathlib import Path
r=Path('artifacts/pr1168-final')
base=['python3','test/run_tests.py','--build-dir','build/linux/client/release/dev-linker-auto','--binary','engine']
commands=[]
cmd=base+['--update-fixtures','--filter','TurnEngineHarness/the committed*','--junit',str(r/'golden.xml'),'--artifacts',str(r/'golden')];commands.append(cmd)
with (r/'golden.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
filters=['BuildingStock/*','BuildingProductionCombat/*','BuildingServices/*','WorldSnapshot/*','UnitCustomization/*','UnitCatalog/*','UnitContinuation/*','TeamStatsSave/*','TeamStatsPipeline/*','JavaScriptCompatibility/*','JavaScriptSimulation/*','JavaScriptIntegration/*','ReplayStepCounter/*','TurnEngineHarness/*','EditorActionCoverage/*','GameHeaderTextSaveLoad/*','BuildingCatalogFixtures/*','MarketsV2/*','MarketFetch/*','MatchSetup/*','TurretTargeting/*','EnteringUnitSave/*','LegacyRoundTripSave/*','RuntimeResources/*','BuildingGradientInvalidation/*','CombGenerator/*','OrderValidation/*','AIPipeline/*','AIStateContinuation/*']
cmd=base+['-j12','--timeout','300','--exclude-tag','benchmark','--junit',str(r/'tests.xml'),'--write-inventory',str(r/'inventory.json'),'--artifacts',str(r/'tests')]
for name in filters:cmd+=['--filter',name]
commands.append(cmd);(r/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
with (r/'tests.log').open('w') as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
print('focused tests exit',result.returncode,flush=True)
raise SystemExit(result.returncode)
