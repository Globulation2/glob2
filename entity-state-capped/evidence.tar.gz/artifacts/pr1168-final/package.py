import json,hashlib,tarfile,subprocess
from pathlib import Path
repo=Path.cwd();dest=repo/'artifacts/pr1168-final';cap=repo/'artifacts/state-performance/capped-layout'
files=[]
for p in cap.iterdir():
 if p.is_file() and p.suffix in {'.json','.py','.md','.txt','.log','.xml','.patch','.cpp'}: files.append(p)
for folder in ['whole-comparison','pipeline-equivalence','markets-audit']:
 for p in (cap/folder).rglob('*'):
  if not p.is_file():continue
  if folder=='whole-comparison':
   if p.suffix=='.json' or p.name=='run.log' or p.parts[-2].startswith('00-'):files.append(p)
  else:files.append(p)
for folder in ['colony-fixture','echo-fixture']:
 for p in (cap.parent/folder).rglob('*'):
  if p.is_file():files.append(p)
for p in dest.rglob('*'):
 if p.is_file() and p.name not in {'evidence.tar.gz','manifest.json'} and p.suffix in {'.json','.xml','.log','.py','.md','.txt','.gz','.checksums','.replay','.png','.bmp'}:files.append(p)
patch=dest/'final-source.patch';patch.write_bytes(subprocess.check_output(['git','diff','origin/master','HEAD']));files.append(patch)
manifest={'tested_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'integration_base':subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip(),'performance_commit':'6ee39c48b113c0280f26c560ca589967d36a610c','files':{}}
archive=dest/'evidence.tar.gz'
seen={}
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for p in sorted(set(files)):
  name=str(p.relative_to(repo));digest=hashlib.sha256(p.read_bytes()).hexdigest();manifest['files'][name]=digest
  if digest in seen:
   manifest.setdefault('duplicates',{})[name]=seen[digest];continue
  seen[digest]=name;t.add(p,arcname=name,recursive=False)
manifest['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();manifest['archive_bytes']=archive.stat().st_size
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('archive bytes',archive.stat().st_size,flush=True)
