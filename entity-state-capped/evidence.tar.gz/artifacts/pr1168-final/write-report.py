from pathlib import Path
import json,subprocess,xml.etree.ElementTree as E,hashlib
r=Path('artifacts/pr1168-final');cap=Path('artifacts/state-performance/capped-layout');sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base='f6f2127ab974dda82215a81782645680aa643380'
def counts(name):
 root=E.parse(r/name).getroot();ts=list(root.iter('testcase'));return f"{len(ts)} cases; {sum(t.find('failure') is not None or t.find('error') is not None for t in ts)} failures; {sum(t.find('skipped') is not None for t in ts)} skipped"
j=json.loads((cap/'whole-comparison/comparison.json').read_text());rows=[]
for v in j['summaries']:
 m=v['metrics']['cpu_seconds_per_tick'];w=v['metrics']['wall_seconds_per_tick'];rows.append(f"| {v['fixture']} | {v['workers']} | {m['baseline']*1e6:.3f} | {m['candidate']*1e6:.3f} | {m['change_percent']:+.2f}% [{m['lower_95_percent']:+.2f}, {m['upper_95_percent']:+.2f}] | {w['change_percent']:+.2f}% [{w['lower_95_percent']:+.2f}, {w['upper_95_percent']:+.2f}] |")
report=f'''# PR 1168 final local verification and recovered performance

Final tested source: `{sha}`. Integrated master: `{base}`.
Linux x86_64, GCC15.2, Threadripper2950X; native pinned SDL prefix and release
`dev_fast=0 release=1 linker=auto`, `-O3`, no PCH/unity. Original release build used
-j16; current-gradient integration and unit harness builds used-j28. Build logs,
exact commands, selected-case inventories and JUnit reports are in the archive.
Production files were unchanged between the final build and the tested commit;
embedded build revision strings are not the source authority. Binary hashes below
and the committed diff identify the actual inputs.

Selected changes: compact pointer-free unit/building records, naturally aligned
bulk capture, logical stock/performance accessors, named masks and bounded fields.
Unit performance caps at65535, private building stock at255; shared stock, demand,
health, hunger, speeds, timers and unrestricted continuation values remain wide.
No new runtime dependencies or exceptional stock representation. Stock caps can
limit private funding and cached-performance caps affect extreme custom content;
ordinary workload timing does not replace play review. The maintainer accepted
the selected layout and requested cleanup and merge.

Current compiled sizes (bytes):

| Record/object | Current master | Selected integrated source |
| --- | ---: | ---: |
| UnitState |360|208|
| Unit |440|288|
| UnitView |392|240|
| BuildingStateRecord |352|264|
| Building |1960|1872|
| BuildingView |408|312|

Incoming turret targeting uses existing padding differently in the compact
record, so historical256/1864-byte building measurements are not the final sizes.
The unit state saves152bytes (42.2%); building state saves88bytes (25%).

Final engine checks: **{counts('final-tests.xml')}**.
Gradient unit checks: **{counts('gradient-tests.xml')}**.
The initial pre-gradient integration selection had461passes and3golden mismatches;
all were corrected and reverified on the final revision. The seeded-resource
trace changes include the format checksum at tick zero. JavaScript trace updates
change only aggregate checksums: all team/entity records match the previous
master goldens at every one of256ticks for both fixtures. Tests retain full
one/four-worker, checkpoint continuation and replay comparisons. The initial
failure reports are retained alongside successful final reports.

Final CLI continuation: same format159 game state run512ticks with1/4workers;
canonical compressed saves, replay bytes and both checksum sidecars are identical.
The engine-only input fixture needed a36-byte empty GUI metadata suffix for the
CLI loader; the wrapped input, exact commands and hashes are retained. No game
simulation fields were altered. First diagnostic attempts failed fixture loading
and output-directory reuse; they are retained and excluded from passing claims.
Simulation revision56, format160, replay floor160 and network protocol71 mark
the cap policies plus incoming turret targeting. Saved-game floor159 is inherited
from master; map floor58 remains. Format159 save loading and current continuation,
version acceptance tests and regenerated FourSquares match verification pass.

Recovered capped-layout performance was tested on`6ee39c48b113c0280f26c560ca589967d36a610c`,
based on`35b84d4ffd774742ada41d33c39ab1a50551f113`, before incoming turret/GPU work.
**No final integrated-head performance rerun is claimed.** The120completed release
runs compare compact stock/performance arrays against32-bit arrays with identical
caps. Other narrowing, masks, accessors and layout grouping are common. This
isolates these arrays under the new policy, not total PR speedup against uncapped
master.10rotated pairs per fixture/worker count;1024warmup ticks; process CPU
includes every thread and drains pending work at both endpoints. Wall latency is
separate.1worker uses CPU6;4workers use CPUs4–7. Raw binary/input hashes, commands,
results and representative canonical/replay/checksum files accompany the archive.

| Workload | Workers | Wide-control CPU µs/tick | Compact CPU µs/tick | CPU change [95%] | Wall change [95%] |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

All six pointwise CPU upper bounds are below the predeclared2% practical
nonregression limit. This is workload-specific evidence; intervals are not
simultaneous coverage and selection has no independent confirmation. All60paired
canonical saves/final checksums match. Earlier component/layout experiments remain
historical and were not used to establish final capped performance.

Scope/omissions: final native Linux/x86_64 functional execution only. Actual
Windows/macOS/mobile/browser determinism is unavailable; CPU gradient continuation
and1/4worker execution are verified, not cross-platform equivalence. Rendering
performance was waived; editor and JavaScript display functionality are included
in the native suite. GPU hardware/performance and general gameplay feel are not
claimed. Historical saved matches below159 remain rejected by incoming master's
explicit turret-targeting policy. No full hosted or release/store packaging
verification is claimed. Final-head whole-process performance remains unmeasured.

Cleanup: removed the ad hoc entity-storage benchmark harness and test-guide section;
no unselected layouts, padding controls, benchmark binaries, generated reports or
logs are shipped. Retained copy accounting and logical snapshot verification are
maintained diagnostics with focused tests.
'''
(r/'verification.md').write_text(report)
bins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('build/linux/client/release/dev-linker-auto/src/glob2'),Path('build/linux/client/release/dev-linker-auto/test/glob2-engine-tests'),Path('build/linux/client/release/dev-linker-auto/test/glob2-unit-tests')]};(r/'binary-hashes.json').write_text(json.dumps(bins,indent=2)+'\n')
