from pathlib import Path
import subprocess,os,json,hashlib
r=Path('artifacts/pr1168-final');exe=Path('build/linux/client/release/dev-linker-auto/src/glob2').resolve();commands=[];hashes={}
for workers in [1,4]:
 out=(r/f'workers{workers}-integrated').resolve();out.mkdir(exist_ok=True)
 cmd=[str(exe),'game','run','--load-game',str(r/'current159-shared-gradient-gui.game.gz'),'--ticks','512','--compute-threads',str(workers),'--gradient-backend','cpu','--telemetry','checksums','--write-replay','--save','final','--output-dir',str(out)]
 commands.append(cmd)
 with (out/'run.log').open('w') as f:subprocess.run(cmd,env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy'),stdout=f,stderr=subprocess.STDOUT,check=True)
 hashes[str(workers)]={n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in ['final.game.gz','world.checksums','game.replay.checksums','game.replay']}
assert hashes['1']==hashes['4'],hashes
(r/'worker-equivalence.json').write_text(json.dumps({'commands':commands,'hashes':hashes,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},indent=2)+'\n');print('one/four worker equivalence passed')
