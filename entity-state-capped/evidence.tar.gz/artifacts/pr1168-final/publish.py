import subprocess,os,json
from pathlib import Path
r=Path('artifacts/pr1168-final');index=(r/'publication.index').resolve();index.unlink(missing_ok=True);env=dict(os.environ,GIT_INDEX_FILE=str(index));branch='codex/entity-state-compaction-evidence'
def git(*args):return subprocess.check_output(['git',*args],env=env,text=True).strip()
parent=git('rev-parse','origin/'+branch);git('read-tree',parent)
files={'entity-state-capped/evidence.tar.gz':r/'evidence.tar.gz','entity-state-capped/manifest.json':r/'manifest.json','entity-state-capped/results.md':r/'verification.md','entity-state-capped/performance.json':Path('artifacts/state-performance/capped-layout/whole-comparison/comparison.json')}
for name,p in files.items():
 blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo','100644,'+blob+','+name)
tree=git('write-tree');commit=git('commit-tree',tree,'-p',parent,'-m','Publish recovered capped-layout performance and final integration verification')
subprocess.run(['git','push','origin',commit+':refs/heads/'+branch],check=True)
(r/'evidence-commit.txt').write_text(commit+'\n');print(commit);index.unlink(missing_ok=True)
