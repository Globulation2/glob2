from pathlib import Path
import subprocess,os,time
r=Path('artifacts/state-performance/capped-layout')
while True:
 s=(r/'final-build.log').read_text()
 if 'building terminated because of errors' in s or 'scons: done building targets.' in s:break
 time.sleep(3)
cmd=['python3','tools/dev_build.py','dev_fast=0','release=1','-j28','build/linux/client/release/dev-linker-auto/src/glob2','engine-tests']
with (r/'final-build-3.log').open('w') as f:subprocess.run(cmd,env=dict(os.environ,GLOB2_SDL3_PREFIX=str(Path.cwd()/'artifacts/state-compaction/native-sdl')),stdout=f,stderr=subprocess.STDOUT,check=True)
subprocess.run(['python3',str(r/'validate.py')],check=True)
