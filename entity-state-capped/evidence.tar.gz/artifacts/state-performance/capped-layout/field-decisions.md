# Entity state decisions

The single pointer-free UnitState and BuildingStateRecord remain bulk-copied. No core/detail split, wide-material fallback or separate rendering representation is introduced. Empirical ranges informed the explicit unit performance policy; they are not a proof about all historical/custom content.

| Fields | Storage decision | Writers, arithmetic and compatibility |
|---|---|---|
| Unit medical/activity/displacement/movement/action/direction | Uint8 | Named init/action transitions; raw signed/unsigned loader temporaries checked before conversion, including enum gaps; global ability IDs unchanged. |
| Unit dx/dy | Sint8 | All movement/geometry/pathfinding outputs audited -1..1. Small output adapter initializes wide locals from existing values and commits both on success or failure; failed-search output tests. |
| Unit levels/construction qualification | Uint8 | 0..3 catalog/training/order/load bounds; historical migrations use validated values; editor byte bindings and mixed-type comparisons preserve promoted arithmetic. |
| Unit destination/material IDs | Sint8 | -1 preserved; ability destinations through18 and material namespace checked before narrowing. |
| Unit animation clocks | Uint8 | Init zero, fixed20/8 starts, guarded decrements; captured presentation and rendering integer arithmetic preserved. |
| Unit terrain health remainder | Sint16 | Loader -255..255, wide accumulation and signed division/remainder; saved continuation debt preserved. |
| Unit 17 learning flags + service reservation/wide cargo/medical recheck/valid target | Uint32 named mask | All writers use setters; other bits preserved, unused bits zero; logical boolean serialization and checksum order unchanged. |
| Unit cached performance[17] | Uint16, deliberate0..65535 cap | Runtime setter uses wide input; HP rule division before final cap at creation/rebind/training. Catalog tables stay Sint32. Load validates existing wide constraints first, then normalizes accepted cached values; existing serialized32-bit widths/order unchanged. Negative legacy or above-cap caches deliberately change continuation. |
| Unit isDead, positions, targets, speed/delta, HP/triggers/hunger, experience, unrestricted timers, RNG/generations | Wide | Unrestricted accepted values, arithmetic or continuation state; no inferred additional policy cap. Observed hunger reaches150000, HP can be negative, and several timers are signed. |
| Building lifecycle/result/recruitment levels | Uint8 | Existing wide loader/order validation before cast, transitions preserve enum values. |
| Building maxUnitInside | Uint16 | Accepted0..65535 retained; signed16-bit would be wrong. |
| Building stay range | Uint16 | Existing loader/orders0..32767, explicit editor word bindings; arithmetic promotes to int. |
| Building variant ID | Uint16 | Catalog dense variant namespace0..4095; separately validated before conversion. |
| Building family/origin/funding IDs | Sint16 | Each namespace independently validated -1..4095; signed absence sentinel preserved; historical migration preserved. |
| Building builtin and construction-origin ratios[3] | Uint16 | Catalog/order/load0..32767; value getter and explicit mutation replace Sint32 references. Origin array lives outside authoritative state and savings accounted separately. Extra production entries remain wide. |
| Building clearing preferences/9 locks | Named unsigned16-bit masks | Initunusedzero, setter preserves neighbors; legacy save boolean loops/checksum traversal unchanged. No bitfields/proxies. |
| Building private stock[15] | Uint8, deliberate0..255 cap | Wide updates clamp before store; headroom limits deliveries, actual accepted amount drives telemetry/residuals. Loader preserves old repair-credit arithmetic before cap and reconciles only funding affected by clamped private stock. Shared Team arrays stay wide and inactive private stock remains preserved. |
| Building demand[15] | Sint32 | Accepted full signed32-bit saved continuation values; legal target arithmetic can reach1333333. Sint16 needs another policy or exceptional representation; neither authorized nor justified here. |
| Building staffing/priority/percentUsed/failure counters/exchange masks/HP/timers/ammunition/RNG/generations | Wide | Staffing/priority load unrestricted signed values; failure counters accept fullUint32; percentUsed transient committed jobs/preferences do not prove16-bit bound; exchange high bits retained. |

Stock costs above255 remain wide and may be unfundable in a private pool. The cap does not rewrite costs, demand or team balances. Current save version159/minimum58, replay floor159, network protocol71 and SIM_REVISION55 explicitly mark the changed simulation policy. Save encodings remain compatible, while out-of-range continuation is deliberately normalized.

Release x86_64 compiled layout: UnitState360→208, Unit440→288, UnitView392→240; BuildingState352→256, Building1960→1864, BuildingView408→312. Record savings152 perunit and96 perbuilding. Views include query data beyond state. Compiled offsets/allocation sizes and raw manifests accompany this inventory; retained capacity and leases are separate metrics.

The matched performance control restores only stock and cached-performance arrays to signed32-bit while keeping the same caps, accessor logic, other proven narrowing and masks. It isolates these arrays' representation cost; it is not the original all-wide baseline. Earlier layout experiments remain historical evidence, not final-cap performance claims.
