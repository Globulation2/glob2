from pathlib import Path
import subprocess,time,json
r=Path('artifacts/state-performance/capped-layout')
while True:
 s=(r/'final-build-3.log').read_text()
 if 'scons: done building targets.' in s:break
 if 'building terminated because of errors' in s:raise RuntimeError('build failed')
 time.sleep(3)
base=['python3','test/run_tests.py','--build-dir','build/linux/client/release/dev-linker-auto','--binary','engine']
cmd=base+['--update-fixtures','--filter','TurnEngineHarness/the committed*','--junit',str(r/'golden-update.xml'),'--artifacts',str(r/'golden-update')]
with (r/'golden-update.log').open('w') as f:subprocess.run(cmd,check=True,stdout=f,stderr=subprocess.STDOUT)
filters=['BuildingStock/*','BuildingProductionCombat/*','BuildingServices/*','WorldSnapshot/*','UnitCustomization/*','UnitCatalog/*','UnitContinuation/*','TeamStatsSave/*','JavaScriptCompatibility/*','ReplayStepCounter/*','TurnEngineHarness/*','EditorActionCoverage/*','GameHeaderTextSaveLoad/*','BuildingCatalogFixture/*','MarketsV2/*','MarketFetch/*','MatchSetup/*']
cmd=base+['-j16','--junit',str(r/'tests.xml'),'--write-inventory',str(r/'test-inventory.json'),'--artifacts',str(r/'test-artifacts')]
for name in filters:cmd+=['--filter',name]
(r/'test-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (r/'tests.log').open('w') as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
print('Tests exit',result.returncode,flush=True)
