from pathlib import Path
import subprocess, shutil, os, json, hashlib, shlex
repo=Path.cwd(); out=repo/'artifacts/state-performance/capped-layout'; source=repo/'artifacts/state-performance/layout-screen/source'
env=dict(os.environ,GLOB2_SDL3_PREFIX=str(repo/'artifacts/state-compaction/native-sdl'))
names=subprocess.check_output(['git','ls-files'],text=True).splitlines()+['src/building/BuildingStock.h','src/building/BuildingStockTest.cpp']
for name in names:
 p=repo/name; q=source/name
 if not p.is_file():continue
 q.parent.mkdir(parents=True,exist_ok=True)
 if q.is_symlink():q.unlink()
 if not q.exists() or p.read_bytes()!=q.read_bytes():shutil.copyfile(p,q)
p=source/'src/app/cli/Headless.cpp'; s=p.read_text()
s=s.replace('uint64_t setupCpu=0,runCpu=0,measureStart=0;','uint64_t setupCpu=0,runCpu=0,measureStart=0,runWall=0;\n        std::chrono::steady_clock::time_point measureWall;')
drain='engine.gui.game.drainAI(); engine.gui.game.drainTeamStats(); engine.gui.game.map.finishGradientPipeline(); engine.gui.game.map.finishResourceGrowth();'
s=s.replace('if(benchmarkWarmup==0) measureStart=processCpuNs();',f'if(benchmarkWarmup==0) {{{drain} measureStart=processCpuNs();measureWall=std::chrono::steady_clock::now();}}')
s=s.replace('if(!measureStart && engine.gui.game.stepCounter>=start) measureStart=processCpuNs();',f'if(!measureStart && engine.gui.game.stepCounter>=start) {{{drain} measureStart=processCpuNs();measureWall=std::chrono::steady_clock::now();}}')
s=s.replace('runCpu=processCpuNs()-measureStart;',f'{drain}\n            runCpu=processCpuNs()-measureStart;\n            runWall=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-measureWall).count();')
s=s.replace('<< ",\\\"benchmark_save_cpu_ns\\\":" << saveCpu','<< ",\\\"benchmark_run_wall_ns\\\":" << runWall\n            << ",\\\"benchmark_save_cpu_ns\\\":" << saveCpu')
assert 'benchmark_run_wall_ns' in s;p.write_text(s)
(out/'measurement.patch').write_text(subprocess.run(['diff','-u',str(repo/'src/app/cli/Headless.cpp'),str(p)],text=True,stdout=subprocess.PIPE).stdout)
originals={name:(source/name).read_text() for name in ['src/building/BuildingStock.h','src/unit/UnitState.h']}
manifest={}
for label in ['wide-control','compact']:
 for name,s in originals.items():
  if label=='wide-control':s=s.replace('using PrivateBuildingStock = Uint8;','using PrivateBuildingStock = Sint32;').replace('using UnitPerformanceStorage = Uint16;','using UnitPerformanceStorage = Sint32;')
  (source/name).write_text(s)
 cmd=['python3','tools/dev_build.py','dev_fast=0','release=1','-j28','build/linux/client/release/dev-linker-auto/src/glob2']
 with (out/(label+'-build.log')).open('w') as f:subprocess.run(cmd,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 binary=out/(label+'-glob2');shutil.copy2(source/'build/linux/client/release/dev-linker-auto/src/glob2',binary)
 manifest[label]={'command':cmd,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sources':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'src').rglob('*') if p.suffix in {'.h','.cpp'}}}
 (out/'binaries.json').write_text(json.dumps(manifest,indent=2)+'\n')
 line=next(x for x in (out/(label+'-build.log')).read_text().splitlines() if 'g++ -o ' in x and ' -c ' in x)
 flags=[x for x in shlex.split(line) if x.startswith(('-I','-D','-std='))]
 subprocess.run(['g++','-O3',*flags,str(out/'offsets.cpp'),'-o',str(out/(label+'-offsets'))],cwd=source,check=True,stderr=(out/(label+'-offset-warnings.log')).open('w'))
 (out/(label+'-offsets.txt')).write_text(subprocess.check_output([str(out/(label+'-offsets'))],text=True))
 print('Frozen',label,flush=True)
