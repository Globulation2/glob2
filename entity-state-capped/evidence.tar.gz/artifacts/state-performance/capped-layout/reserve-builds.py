from pathlib import Path
import os,json,time
out=Path(__file__).resolve().parent;excluded={4,5,6,7,20,21,22,23};allowed=set(range(32))-excluded;original={}
while not (out/'stop-reservation').exists():
 roots=set();parents={};commands={}
 for p in Path('/proc').glob('[0-9]*'):
  try:
   pid=int(p.name);cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace');pp=int(next(x.split()[1] for x in (p/'status').read_text().splitlines() if x.startswith('PPid:')));parents[pid]=pp;commands[pid]=cmd
   if ('tools/dev_build.py' in cmd or '/usr/bin/scons ' in cmd or '/usr/local/bin/scons ' in cmd) and not cmd.startswith(('bash -c','/bin/bash -c')):roots.add(pid)
  except (OSError,ValueError,StopIteration):pass
 selected=set(roots)
 while True:
  children={pid for pid,pp in parents.items() if pp in selected};new=children-selected
  if not new:break
  selected|=new
 for pid in selected:
  for task in Path('/proc/'+str(pid)+'/task').glob('*'):
   try:
    tid=int(task.name);aff=os.sched_getaffinity(tid)
    if aff & excluded:
     original.setdefault(str(tid),{'pid':pid,'affinity':sorted(aff),'command':commands.get(pid,'')[:180]});os.sched_setaffinity(tid,allowed)
   except (OSError,ProcessLookupError):pass
 (out/'reservation-adjustments.json').write_text(json.dumps({'reserved':sorted(excluded),'original_threads':original,'updated_ns':time.time_ns()},indent=2)+'\n')
 time.sleep(1)
# Restore surviving threads by PID and command identity; avoid PID reuse.
for tid,row in original.items():
 try:
  cmd=Path('/proc/'+str(row['pid'])+'/cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')[:180]
  if cmd==row['command']:os.sched_setaffinity(int(tid),row['affinity'])
 except (OSError,ProcessLookupError):pass
