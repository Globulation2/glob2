# Capped-layout review evidence and reproduction

Run commands from the repository root. Keep these scripts/logs on the immutable
review evidence branch, not in the shipping implementation. Record the final tested
commit, integrated master revision, toolchain/dependency versions and omissions in
the PR validation comment when publication is complete.

## What this comparison establishes

`wide-control` and `compact` use **identical** private-stock0…255 and cached-unit-
performance0…65535 policies, historical normalization, accessors, other proven
narrowing, named masks and field grouping. The control changes only
`PrivateBuildingStock` and `UnitPerformanceStorage` aliases back to Sint32.
This comparison isolates the incremental storage representation and its total
process costs **under the same new policies**. It is not the pre-PR all-wide
baseline and cannot establish unchanged simulation against the old uncapped game.
Original-baseline offsets and earlier pre-cap measurements remain separate evidence;
do not transfer their timing conclusions to this semantic revision.

Observed historical/builtin workloads informed the deliberate performance cap;
observed maxima are not proof of a universal storage bound. Catalogs stay wide,
HP rule arithmetic precedes cache storage, and saved continuation values normalize
as documented. Old private-stock reservations reconcile only after that policy
change. Field decisions, policy limits and source review are in field-decisions.md
and review.md; the permanent architecture/persistence guides describe the shipped
behavior.

Compiled x86_64 layout (bytes, alignment8) currently records:

| Object | Original baseline | Matched wide control | Compact |
| --- | ---: | ---: | ---: |
| UnitState |360|240|208|
| UnitView |392|272|240|
| Unit |440|320|288|
| BuildingStateRecord |352|304|256|
| BuildingView |408|352|312|
| Building |1960|1912|1864|

Use the corresponding *-offsets.txt files as authority. Base-tail padding reuse
means view/object savings need not equal authoritative record savings. The probes
also record real member offsets and sampled allocator usable sizes/alignment.
Neither allocation residue nor these samples proves a cache-performance cause.

## Freeze source and build both representations

`build.py` copies the selected working source into an isolated source directory,
applies the shared measurement-only Headless.cpp patch, builds wide-control then
compact with the same pinned native SDL prefix and native release flags, and saves
per-file source hashes, exact commands and executable SHA-256 in binaries.json.
The measurement patch drains pending AI, statistics, gradients and resource growth
at both endpoints. CPU uses CLOCK_PROCESS_CPUTIME_ID and includes every process
thread; wall time spans the same drained interval. This instrumentation is shared
between the two timed binaries and does not publish future work early.

Reproduce the freeze/build stage only when it is safe to replace the source copy;
never rebuild or replace a frozen executable while a timing run is using it:

```bash
taskset -c 0-3,8-19,24-31 python3 artifacts/state-performance/capped-layout/build.py
```

Release command inside the copied source is recorded verbatim:
`python3 tools/dev_build.py dev_fast=0 release=1 -j28 build/linux/client/release/dev-linker-auto/src/glob2`.
No PCH/unity or fast development optimization is used. The native SDL/dependency
prefix, compiler command lines and link inputs are recorded in the build logs.
Record dependency versions/manifest with publication; source hashes alone do not
identify external libraries or generated configuration.

`finish-build.py` and validate.py sequence shipping-source builds, golden-record
regeneration and selected harness execution. Launch these orchestrators under the
same non-timing affinity above. Publish exact test-command.json, test-inventory.json,
XML/logs and relevant fixture/checksum files. An in-progress build log is not a
passing result. Existing unrelated baseline failures must remain distinguished
from candidate failures.

## Provenance caveat

An archived/copied source directory may inherit an embedded Git revision from its
parent checkout or generated/cache inputs. Embedded revision text is not sufficient
provenance. Compare actual executable SHA-256, build commands and per-file source
hashes in binaries.json with each run's binary/input hashes. The manifest hashes
listed src .h/.cpp files; it does not independently cover omitted .inc/assets,
third-party files or generated headers. Publish the source archive/commit and shared
dependency/build inputs alongside it. Both aliases and measurement.patch must be
included. Final evidence must identify the actual final tested revision separately
from inherited revision strings.

pipeline-probe.py constructs an **early pipeline/equivalence diagnostic** executable
with a measurement object and current shipping objects. Its pipeline-binary.json
states that purpose; it is not the final compact paired-timing executable. Preserve
that distinction even if its short equivalence runs pass.

## Native paired protocol and reserved cores

The user requested pipelining with reserved physical timing cores. CPUs4–7 and their
SMT siblings20–23 are reserved; compiler/tests/helper processes use
0–3,8–19,24–31. core-reservation.json records the process-affinity inventory.
The original protocol's isolation wording described the initial ideal condition;
current requested pipelining permits builds/tests on the other cores. Shared memory,
I/O and host load can still affect timing despite disjoint CPU/SMT affinity. Report
this limitation and retain host/environment observations.

**Always pass `--four-affinity 4-7`: whole.py defaults to6–9, which crosses the
reservation and is not the selected protocol.** A reproduction command, to run
only after both frozen binaries and inputs are complete, is:

```bash
taskset -c 0-3,8-19,24-31 python3 artifacts/state-performance/capped-layout/whole.py \
  --label wide-control --label compact --repeat 10 --four-affinity 4-7 \
  --output artifacts/state-performance/capped-layout/whole-paired
```

The driver stays off timing cores and explicitly pins native children to CPU6 for
one worker or CPUs4–7 for four workers. All three fixtures use CPU gradients and
identical orders/capture requirements. Warmup1024ticks precedes fixed measured
windows: ordinary32768ticks, normal-colonies8192, shared-runtime24576. Ten rotated,
alternating pairs retain individual result.json, exact command, executable/input
hashes, canonical save and final checksum. Comparisons assert equal canonical saves
and final checksums within each fixture/worker/pair.

Report whole-process CPU and wall separately, with absolute seconds/tick and paired
log-ratio two-sided95% bootstrap intervals (20,000resamples). The practical CPU
limit is2%: upper bound≤2% supports practical nonregression in that workload;
non-significance alone does not. These pointwise intervals are not simultaneous
coverage over all workloads. Microbenchmark components must not be summed into a
substitute whole-match result. Never describe pending/incomplete rows as completed
or claim general performance improvement from only a favorable subset.

## Required publication and omissions

Publish binaries.json, measurement.patch, protocol.json, core-reservation.json,
*-offsets.txt, build/test logs and inventories, whole-paired/comparison.json and
representative raw canonical/replay/checksum artifacts on an immutable accessible
evidence commit. Preserve unsuccessful/baseline results and metadata identifying
which source binary produced each file. Local-only paths are not reviewer access.

Rendering performance and new renderer screenshots are omitted at the user's
explicit direction. These headless process timings do not measure scene preparation,
GPU/software draw or frame presentation. Native Linux/x86_64 is the execution
coverage here; Windows/macOS/browser/mobile simulation and performance are not
established by GCC compilation/layout probes. Different worker configurations are
covered only when their recorded runs finish; affinity is not itself evidence of
successful equivalence. Historical-save normalization intentionally changes affected
continuation, and replay/network version boundaries and the regenerated golden
record must be documented separately in the PR's final functional validation.

## Reproduced MarketsV2 baseline continuation failures

The uncapped b4c463a439953059c9ac058902cff8a652e87f02 baseline was tested with
the two cases “disabled fruit deliveries have a stable per-tick trace and save
continuation” and “enabled supply networks repeat deterministically with save
continuation”. Both fail their existing current save/resume equality check at
MarketsV2Test.cpp:121. There are **three failed assertions across two cases**
(158assertions total,155passing), not a historical golden mismatch. The failure
reproduces without private-stock or unit-performance caps. Do not report these
current-continuation checks as passed, and do not attribute them to this PR.

The b4→35b84d4ff relevance audit confirms MarketsV2Test, unit/building loaders,
Game load/sync/diagnostics, team serialization and statistics implementation files
are unchanged. Incoming production differences concern Nicowar policy, executor
notifications/EngineRun and rendering; this fixture directly steps Game and does
not run Nicowar. This is a scoped reuse justification, not an exact35b84 execution
claim. The inherited baseline binary/source provenance remains as previously
documented; its exact executable SHA-256 is captured.

Reviewer evidence relative to this directory:

- [Exact baseline command](markets-audit/baseline-command.json).
- [Raw assertion log](markets-audit/baseline.log).
- [Result counts, binary hash and relevance commands](markets-audit/baseline-results.json).
- [b4→35 master change inventory](markets-audit/base-relevance-diff.txt).
- [Empty diff for the audited continuation paths](markets-audit/unchanged-continuation-paths.diff).

The existing failure is retained as an explicit verification limitation. No
production/test-source changes or new baseline builds were made to diagnose it;
repairing that preexisting continuation issue is outside this focused PR.
