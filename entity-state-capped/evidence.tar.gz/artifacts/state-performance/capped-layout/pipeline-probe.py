from pathlib import Path
import subprocess,shlex,json,hashlib,os
r=Path('artifacts/state-performance/capped-layout');source=Path('artifacts/state-performance/layout-screen/source');logs='\n'.join(Path(p).read_text() for p in ['artifacts/state-performance/layout-screen/capped-build-4.log',str(r/'final-build.log'),str(r/'final-build-3.log')])
line=next(x for x in logs.splitlines() if 'g++ -o ' in x and ' -c ' in x and x.endswith('src/app/cli/Headless.cpp'))
compile=shlex.split(line);compile[compile.index('-o')+1]=str(r/'Headless.pipeline.o');(r/'Headless.pipeline.cpp').write_bytes((source/'src/app/cli/Headless.cpp').read_bytes());compile[-1]=str(r/'Headless.pipeline.cpp');compile.insert(-1,'-Isrc/app/cli');subprocess.run(compile,check=True)
line=[x for x in logs.splitlines() if 'g++ -o build/linux/client/release/dev-linker-auto/src/glob2 ' in x and ' -c ' not in x][-1]
link=shlex.split(line);link[link.index('-o')+1]=str(r/'pipeline-compact-glob2');link=[str(r/'Headless.pipeline.o') if x=='build/linux/client/release/dev-linker-auto/src/app/cli/Headless.o' else x for x in link];subprocess.run(link,check=True)
(r/'pipeline-binary.json').write_text(json.dumps({'purpose':'early equivalence/pipeline diagnostic; not final paired timing binary','compile':compile,'link':link,'sha256':hashlib.sha256((r/'pipeline-compact-glob2').read_bytes()).hexdigest()},indent=2)+'\n')
fixtures=[('ordinary',0,Path('test/fixtures/ai-random-streams/numbi-castor-v121.game.gz')),('normal-colonies',4096,Path('artifacts/state-performance/colony-fixture/final.game.gz')),('shared-runtime',256,Path('artifacts/state-performance/echo-fixture/initial.game.gz'))]
for workers in [1,4]:
 for name,start,fixture in fixtures:
  rows=[]
  for label,binary in [('wide-control',r/'wide-control-glob2'),('compact',r/'pipeline-compact-glob2')]:
   out=r/'pipeline-equivalence'/f'{name}-{workers}-{label}';out.mkdir(parents=True,exist_ok=True)
   cmd=['taskset','-c','6' if workers==1 else '4-7',str(binary.resolve()),'game','run','--load-game',str(fixture.resolve()),'--ticks',str(start+2048),'--benchmark-warmup','1024','--compute-threads',str(workers),'--gradient-backend','cpu','--write-replay','--telemetry','checksums','--save','final','--output-dir',str(out.resolve())]
   (out/'command.json').write_text(json.dumps(cmd)+'\n')
   with (out/'run.log').open('w') as f:subprocess.run(cmd,env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy'),stdout=f,stderr=subprocess.STDOUT,check=True)
   rows.append(hashlib.sha256((out/'final.game.gz').read_bytes()).hexdigest())
  assert len(set(rows))==1,'canonical divergence'
  print('Pipelined equivalence passed',name,workers,flush=True)
