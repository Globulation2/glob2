# Independent source review

Two subagents reviewed the working implementation independently of their scoped changes. Both reported no unresolved introduced correctness blocker. Review is source inspection, not a substitute for the attached executed tests.

Design review covered stock saturation/delivery preflight, actual accepted telemetry and cargo residuals, guarded private-to-team transfers, preserved inactive private stock, immutable snapshot reads, canceled loaded service exits, centralized cached-performance writes and HP division order. Findings resolved: duplicate load-marker comment moved beside its field, redundant wide-cargo flag initialization removed, missing performance-cap documentation added. A duplicate script Uint16 conversion overload found during the release build was consolidated.

Compatibility review covered separate catalog ID namespaces and sentinels, validation before conversion, ratio assignments versus wide transient production counters, boolean mask initialization/save/checksum ordering, structural membership validation before cap-induced funding reconciliation, shared-stock validation, demand and progress continuation. It confirmed that signed demand cannot be narrowed under the accepted current contracts. Stale replay/network boundary assertions were updated to159/71 and immediate predecessor158 rejection was added.

The compatibility reviewer added runtime tests for all15 stock slots, wide saturation arithmetic, delivery at254/full255 with telemetry/discard/residual coherence, and shared balances above255 with preserved inactive private stock. Test execution results are recorded separately.

## Reproduced MarketsV2 baseline continuation failures

The uncapped b4c463a439953059c9ac058902cff8a652e87f02 baseline was tested with
the two cases “disabled fruit deliveries have a stable per-tick trace and save
continuation” and “enabled supply networks repeat deterministically with save
continuation”. Both fail their existing current save/resume equality check at
MarketsV2Test.cpp:121. There are **three failed assertions across two cases**
(158assertions total,155passing), not a historical golden mismatch. The failure
reproduces without private-stock or unit-performance caps. Do not report these
current-continuation checks as passed, and do not attribute them to this PR.

The b4→35b84d4ff relevance audit confirms MarketsV2Test, unit/building loaders,
Game load/sync/diagnostics, team serialization and statistics implementation files
are unchanged. Incoming production differences concern Nicowar policy, executor
notifications/EngineRun and rendering; this fixture directly steps Game and does
not run Nicowar. This is a scoped reuse justification, not an exact35b84 execution
claim. The inherited baseline binary/source provenance remains as previously
documented; its exact executable SHA-256 is captured.

Reviewer evidence relative to this directory:

- [Exact baseline command](markets-audit/baseline-command.json).
- [Raw assertion log](markets-audit/baseline.log).
- [Result counts, binary hash and relevance commands](markets-audit/baseline-results.json).
- [b4→35 master change inventory](markets-audit/base-relevance-diff.txt).
- [Empty diff for the audited continuation paths](markets-audit/unchanged-continuation-paths.diff).

The existing failure is retained as an explicit verification limitation. No
production/test-source changes or new baseline builds were made to diagnose it;
repairing that preexisting continuation issue is outside this focused PR.
