#include "Unit.h"
#include "Building.h"
#include "sim/snapshot/WorldRecords.h"
#include <cstddef>
#include <iostream>
#include <malloc.h>
#include <new>
#include <vector>
#define RECORD(T) std::cout<<#T<<" size="<<sizeof(T)<<" align="<<alignof(T)<<"\n"
#define FIELD(T,F) std::cout<<#T<<"."<<#F<<" offset="<<offsetof(T,F)<<" size="<<sizeof(T::F)<<"\n"
template<class T> void allocations(const char* name){std::vector<void*> blocks;for(int i=0;i<1000;++i)blocks.push_back(::operator new(sizeof(T)));size_t lo=~size_t(0),hi=0;unsigned residues=0;bool aligned=true;for(void* p:blocks){auto n=malloc_usable_size(p);lo=std::min(lo,n);hi=std::max(hi,n);aligned &= reinterpret_cast<uintptr_t>(p)%16==0;residues|=1u<<(reinterpret_cast<uintptr_t>(p)%64/16);}std::cout<<name<<" allocation_usable_min="<<lo<<" max="<<hi<<" alignment16="<<aligned<<" cacheline_quarter_mask="<<residues<<"\n";for(void* p:blocks)::operator delete(p);}
int main(){RECORD(UnitState);RECORD(Unit);RECORD(SimulationSnapshot::UnitView);RECORD(BuildingStateRecord);RECORD(Building);RECORD(SimulationSnapshot::BuildingView);
FIELD(UnitState,performance);FIELD(UnitState,stateFlags);FIELD(UnitState,terrainHealthRemainder);FIELD(UnitState,dx);FIELD(BuildingStateRecord,localMaterials);FIELD(BuildingStateRecord,wishedMaterials);FIELD(BuildingStateRecord,ratio);FIELD(Building,type);FIELD(Building,owner);FIELD(Building,sharedMaterials);FIELD(Building,reservedMaterials);allocations<Unit>("Unit");allocations<Building>("Building");}
