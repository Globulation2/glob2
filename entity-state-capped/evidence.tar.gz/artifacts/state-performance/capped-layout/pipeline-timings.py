from pathlib import Path
import subprocess,time,os,json
r=Path(__file__).resolve().parent
cmd=['python3',str(r/'whole.py'),'--label','wide-control','--label','compact','--four-affinity','4-7']
# Early screen may overlap reserved-core compilation. Keep it separate from the
# final clean paired interval: no inferential acceptance claims from this screen.
with (r/'screen-whole.log').open('w') as f:subprocess.run(cmd+['--repeat','2','--output',str(r/'screen-whole')],stdout=f,stderr=subprocess.STDOUT,check=True)
while True:
 busy=[]
 for p in Path('/proc').glob('[0-9]*'):
  try:
   comm=(p/'comm').read_text().strip()
   if comm=='cc1plus' or comm.startswith('glob2-engine-te'):busy.append(int(p.name))
  except OSError:pass
 (r/'timing-stage.json').write_text(json.dumps({'status':'waiting for clean final timing' if busy else 'final timing','busy_pids':busy,'time_ns':time.time_ns()})+'\n')
 if not busy:break
 time.sleep(3)
with (r/'whole.log').open('w') as f:subprocess.run(cmd+['--repeat','10','--output',str(r/'whole-comparison')],stdout=f,stderr=subprocess.STDOUT,check=True)
(r/'timing-stage.json').write_text(json.dumps({'status':'completed','time_ns':time.time_ns()})+'\n')
