import argparse,os,subprocess,json,hashlib,statistics,random,math
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--label',action='append',required=True);p.add_argument('--repeat',type=int,default=10);p.add_argument('--four-affinity',default='6-9');p.add_argument('--output',type=Path,required=True);a=p.parse_args()
r=Path(__file__).resolve().parent;repo=Path.cwd();a.output.mkdir(parents=True,exist_ok=True)
fixtures=[('ordinary',0,32768,repo/'test/fixtures/ai-random-streams/numbi-castor-v121.game.gz'),('normal-colonies',4096,8192,r.parent/'colony-fixture/final.game.gz'),('shared-runtime',256,24576,r.parent/'echo-fixture/initial.game.gz')]
report={'protocol':json.loads((r/'protocol.json').read_text()),'labels':a.label,'warmup':1024,'runs':[],'summaries':[]}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ci(v):
 logs=[math.log(x) for x in v];rng=random.Random(491);s=sorted(statistics.mean(rng.choices(logs,k=len(logs))) for _ in range(20000))
 return {'change_percent':100*math.expm1(statistics.mean(logs)),'lower_95_percent':100*math.expm1(s[500]),'upper_95_percent':100*math.expm1(s[19500])}
for rep in range(a.repeat):
 order=a.label[rep%len(a.label):]+a.label[:rep%len(a.label)]
 if rep%2:order.reverse()
 for workers,affinity in [(1,'6'),(4,a.four_affinity)]:
  for name,start,ticks,fixture in fixtures:
   for label in order:
    out=a.output/f'{rep:02d}-{name}-workers{workers}-{label}';out.mkdir(exist_ok=True)
    cmd=['taskset','-c',affinity,str(r/(label+'-glob2')),'game','run','--load-game',str(fixture),'--ticks',str(start+1024+ticks),'--benchmark-warmup','1024','--compute-threads',str(workers),'--gradient-backend','cpu','--save','final','--output-dir',str(out.resolve())]
    with (out/'run.log').open('w') as f:subprocess.run(cmd,env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy'),stdout=f,stderr=subprocess.STDOUT,check=True)
    data=json.loads((out/'result.json').read_text());assert data['benchmark_measured_ticks']==ticks,'ended early'
    report['runs'].append({'pair':rep,'fixture':name,'workers':workers,'variant':label,'command':cmd,'binary_sha256':sha(r/(label+'-glob2')),'fixture_sha256':sha(fixture),'result':data,'cpu_seconds_per_tick':data['benchmark_run_cpu_ns']/ticks/1e9,'wall_seconds_per_tick':data['benchmark_run_wall_ns']/ticks/1e9,'canonical_sha256':sha(out/'final.game.gz')})
    (a.output/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
   group=[x for x in report['runs'] if x['pair']==rep and x['fixture']==name and x['workers']==workers]
   assert len({x['canonical_sha256'] for x in group})==1,'canonical divergence'
   assert len({x['result']['finalChecksum'] for x in group})==1,'checksum divergence'
   print('Whole pair',rep+1,name,'workers',workers,{x['variant']:round(x['cpu_seconds_per_tick']*1e6,3) for x in group},flush=True)
for workers in [1,4]:
 for name,_,_,_ in fixtures:
  for label in a.label:
   if label=='wide-control':continue
   row={'fixture':name,'workers':workers,'variant':label,'metrics':{}}
   for metric in ['cpu_seconds_per_tick','wall_seconds_per_tick']:
    bs=[];cs=[]
    for rep in range(a.repeat):
     b=next(x for x in report['runs'] if x['pair']==rep and x['fixture']==name and x['workers']==workers and x['variant']=='wide-control');c=next(x for x in report['runs'] if x['pair']==rep and x['fixture']==name and x['workers']==workers and x['variant']==label);bs.append(b[metric]);cs.append(c[metric])
    row['metrics'][metric]={'baseline':statistics.mean(bs),'candidate':statistics.mean(cs),**ci([c/b for b,c in zip(bs,cs)])}
   report['summaries'].append(row)
(a.output/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
