#!/usr/bin/env python3
"""Fresh matched games, master vs final, per worker count; whole run and late window.

Each run: Oazis 11 Maxima --game-seed S --ai-order-delay 8 --ticks T --benchmark-warmup LATE
--telemetry team-timeline --gradient-workers W.  Whole run = wait4 CPU, run_ns, final perf
scopes; late window = perf samples from LATE, benchmark_run_cpu_ns, *_window AI counters.
Interleaved and rotated per (repeat, seed).  Run under run_with_benchmark_cpuset.py.
"""
import argparse, gzip, json, os, shutil, statistics as st, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import benchmark_building_gradients as bb

p = argparse.ArgumentParser()
p.add_argument('--arm', action='append', required=True, metavar='NAME=BIN')
p.add_argument('--workers', type=int, nargs='+', default=[1, 4, 8])
p.add_argument('--cpus-for-workers', action='append', default=[], metavar='W=LIST')
p.add_argument('--map', required=True)
p.add_argument('--seeds', type=int, nargs='+', default=[19, 23, 29])
p.add_argument('--repeats', type=int, default=2)
p.add_argument('--ticks', type=int, default=18048)
p.add_argument('--late', type=int, default=12000)
p.add_argument('--quiet', type=float, default=0.5)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
cpu_map = {int(s.split('=')[0]): {int(c) for c in s.split('=')[1].split(',')} for s in a.cpus_for_workers}
arms = [(s.split('=', 1)[0], s.split('=', 1)[1]) for s in a.arm]
combos = [(n, b, w) for w in a.workers for n, b in arms]
a.output.mkdir(parents=True, exist_ok=False)
env = dict(os.environ); env.pop('GLOB2_PERF_DISABLE', None)
rows_path = a.output / 'rows.jsonl'
k = 0
for rep in range(a.repeats):
    for seed in a.seeds:
        order = combos[k % len(combos):] + combos[:k % len(combos)]
        if k % 2: order.reverse()
        k += 1
        for name, spec, w in order:
            binary, _, extra = spec.partition(';'); binary = Path(binary).resolve()
            dest = a.output / f's{seed}' / f'r{rep}' / f'{name}-w{w}'
            args = ['--map-file', a.map] + ['--player', 'maxima'] * 11 + [
                '--game-seed', str(seed), '--ai-order-delay', '8', '--ticks', str(a.ticks),
                '--benchmark-warmup', str(a.late), '--telemetry', 'team-timeline', ] + (['--gradient-workers', str(w)] if w >= 0 else []) + extra.split()
            waited = bb.wait_quiet(a.quiet)
            try:
                row = bb.run_once(binary, args, dest, env, cpu_map.get(w))
            except RuntimeError as e:
                print('FAILED', e, flush=True); raise
            res = json.loads((dest / 'result.json').read_text())
            final, window, _ = bb.parse_perf(dest / 'engine.log', a.late)
            fs = lambda n: (final.get(n, {}).get('total_ns') or 0) / 1e9
            ws = lambda n: (window.get(n, {}).get('total_ns') or 0) / 1e9
            aip, aiw = res.get('ai_pipeline', {}), res.get('ai_pipeline_window', {})
            r = dict(seed=seed, rep=rep, arm=name, workers=w, gradient_workers=res.get('gradient_workers'), compute_threads=res.get('compute_threads'), exit_code=0, quiet_wait_s=waited,
                     loadavg=row['loadavg'][0] if row.get('loadavg') else None, background_cores=row['background_cores'],
                     ticks=res['ticks'], termination=res['termination'], final_checksum=res['finalChecksum'],
                     run_s=res['run_ns'] / 1e9, wall_s=row['wall_s'], cpu_s=row['cpu_s'],
                     loop_s=fs('loop.work'), owner_s=fs('simulation.tick'),
                     g_bld_s=fs('gradient.building') + fs('gradient.building_resume'),
                     join_wait_s=res.get('compute_join_wait_ns', 0) / 1e9, lane_wait_s=res.get('compute_lane_wait_ns', 0) / 1e9,
                     owner_jobs=res.get('compute_owner_jobs'), bwait_s=res.get('building_gradient_wait_ns', 0) / 1e9,
                     ai_wait_s=aip.get('deadline_wait_ns', 0) / 1e9, ai_miss=aip.get('deadline_misses'),
                     ai_cpu_s=(res.get('ai_decision_work') or {}).get('decision_cpu_ns', 0) / 1e9,
                     late_cpu_s=res['benchmark_run_cpu_ns'] / 1e9, late_ticks=res['benchmark_measured_ticks'],
                     late_loop_s=ws('loop.work'), late_owner_s=ws('simulation.tick'),
                     late_g_bld_s=ws('gradient.building') + ws('gradient.building_resume'),
                     late_ai_wait_s=aiw.get('deadline_wait_ns', 0) / 1e9, late_ai_miss=aiw.get('deadline_misses'),
                     late_ai_cpu_s=(res.get('ai_decision_work_window') or {}).get('decision_cpu_ns', 0) / 1e9)
            with rows_path.open('a') as f:
                f.write(json.dumps(r) + '\n')
            print(json.dumps(r), flush=True)
            log = dest / 'engine.log'
            with log.open('rb') as src, gzip.open(str(log) + '.gz', 'wb') as dst:
                shutil.copyfileobj(src, dst)
            log.unlink()
print('ALLRUNS')
