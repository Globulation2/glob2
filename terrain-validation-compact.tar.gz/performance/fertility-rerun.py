from pathlib import Path
import subprocess,csv,json,statistics
out=Path(__file__).resolve().parent
rows=[]
for repeat in range(2):
 for variant in (['baseline','candidate'] if repeat==0 else ['candidate','baseline']):
  result=subprocess.check_output(['taskset','-c','15',str(out/f'fertility-{variant}')],text=True)
  (out/f'fertility-repeat-{repeat}-{variant}.csv').write_text(result)
  rows += [dict(r,repeat=repeat,variant=variant) for r in csv.DictReader(result.splitlines())]
summary=[]
for width in [128,256,512]:
 for layout in [0,1,2]:
  matched=[r for r in rows if int(r['size'])==width and int(r['layout'])==layout and int(r['sample'])>=0]
  assert len({r['digest'] for r in matched})==1
  med={v:statistics.median(int(r['cpu_ns']) for r in matched if r['variant']==v) for v in ['baseline','candidate']}
  memory={v:max(int(r['retained_bytes']) for r in matched if r['variant']==v) for v in ['baseline','candidate']}
  summary.append(dict(size=width,layout=layout,median_ns=med,retained_bytes=memory,delta_percent=100*(med['candidate']/med['baseline']-1)))
(out/'fertility-repeated-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
