from pathlib import Path
import subprocess,json,hashlib,statistics,struct
root=Path.cwd();out=root/'artifacts/terrain-refactor/performance';rows=[]
for name,growth in [('allotments-1427','normal'),('river-1427','none')]:
 source=json.loads((out/f'{name}-{growth}-0-candidate/inputs.json').read_text())
 for repeat in range(2):
  for variant in (['pre','final'] if repeat==0 else ['final','pre']):
   binary=out/'glob2-pre-metadata-optimization' if variant=='pre' else root/'build/linux/client/release/src/glob2'
   command=source['command'][:];command[3]=str(binary);dest=out/f'post-{name}-{growth}-{repeat}-{variant}';dest.mkdir(exist_ok=True);command[command.index('--output-dir')+1]=str(dest);command+=['--telemetry','checksums']
   (dest/'inputs.json').write_text(json.dumps(dict(command=command,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()),indent=2))
   with (dest/'run.log').open('w') as log:subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
   trace=(dest/'game.replay.checksums').read_bytes();assert struct.unpack_from('<I',trace,12)[0]==16384;trace_sha256=hashlib.sha256(trace).hexdigest();r=json.loads((dest/'result.json').read_text());rows.append(dict(trace_sha256=trace_sha256,name=name,growth=growth,repeat=repeat,variant=variant,**{k:r[k] for k in ['initialChecksum','finalChecksum','ticks','benchmark_run_cpu_ns','benchmark_measured_ticks','teams']}))
 group=[r for r in rows if r['name']==name];assert len({r['initialChecksum'] for r in group})==1;assert len({r['finalChecksum'] for r in group})==1;assert len({r['trace_sha256'] for r in group})==1;assert all(r['teams']==group[0]['teams'] for r in group)
 print(name,'identical per-tick traces and final team state',flush=True)
(out/'post-control.json').write_text(json.dumps(rows,indent=2))
