#include "field/TerrainGradient.h"
#include <algorithm>
#include <array>
#include <ctime>
#include <iostream>
#include <random>
#include <vector>
std::uint64_t now(){timespec ts{};clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&ts);return std::uint64_t(ts.tv_sec)*1000000000+ts.tv_nsec;}
std::size_t retained(const GradientWorkspace&w){size_t n=sizeof(w)+w.deferredSeeds.capacity()*sizeof(std::pair<int,int>);for(auto&b:w.buckets)n+=b.cells.capacity()*sizeof(std::uint32_t);return n;}
std::uint64_t digest(const std::vector<std::uint16_t>&v){std::uint64_t h=1469598103934665603ull;for(auto x:v){h^=x;h*=1099511628211ull;}return h;}
int main(){
 std::cout<<"size,swim,mode,sample,cpu_ns,retained_bytes,cold_cpu_ns,digest,terrain_grid_bytes\n";
 for(int width:{128,256,512})for(int sw:{0,2,3,6}){
  const size_t n=size_t(width)*width;std::mt19937 rng(72941);
  std::vector<TerrainType>classic(n),mixed(n);std::vector<std::uint16_t>sprites(n),seeds(n);
  for(size_t i=0;i<n;++i){auto v=rng()%10;classic[i]=v<2?WATER:v<4?SAND:GRASS;sprites[i]=classic[i]==WATER?256:classic[i]==SAND?128:0; mixed[i]=classic[i];if(classic[i]==GRASS)mixed[i]=v<6?ICE:v<8?ROAD:GRASS;seeds[i]=(rng()%7==0||(!sw&&classic[i]==WATER))?0:1; if(i%(width*17+13)==0)seeds[i]=65535;}
  std::array<GradientWorkspace,4>scratch;std::array<std::vector<std::uint16_t>,4>fields;
  std::array<std::uint64_t,4>cold{},hashes{};
  auto kernel=[&](int mode){auto*g=fields[mode].data();auto&w=scratch[mode];const auto*types=mode==3?mixed.data():classic.data();if(mode==0)gradient_kernel::propagateField(g,sw,65491,{width,width},w,[&](size_t i){return sprites[i]>=256 && sprites[i]<272;});else gradient_kernel::propagateTerrainField(g,sw,65491,{width,width},w,[&](size_t i){return types[i];},mode>=2);};
  for(int mode=0;mode<4;++mode){fields[mode]=seeds;auto t=now();kernel(mode);cold[mode]=now()-t;hashes[mode]=digest(fields[mode]);}
  if(hashes[0]!=hashes[1]||hashes[0]!=hashes[2])return 1;
  for(int sample=0;sample<21;++sample)for(int seq=0;seq<4;++seq){int mode=(seq+sample)%4;std::uint64_t total=0;for(int batch=0;batch<3;++batch){fields[mode]=seeds;auto t=now();kernel(mode);total+=now()-t;}std::cout<<width<<','<<sw<<','<<mode<<','<<sample<<','<<total/3<<','<<retained(scratch[mode])<<','<<cold[mode]<<','<<hashes[mode]<<','<<sizeof(TerrainType)*n<<'\n';}
 }
}
