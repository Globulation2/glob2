from pathlib import Path
import json,subprocess
root=Path.cwd(); out=root/'artifacts/terrain-refactor/performance'
profiles=[]
for growth in ('normal','none'):
 for variant in ('baseline','candidate'):
  source=out/f'allotments-1427-{growth}-0-{variant}'
  inputs=json.loads((source/'inputs.json').read_text());command=inputs['command'];dest=out/f'profile-allotments-{growth}-{variant}';dest.mkdir(exist_ok=True)
  command[command.index('--output-dir')+1]=str(dest);command+=['--telemetry','team-timeline']
  (dest/'inputs.json').write_text(json.dumps(dict(command=command,**{k:v for k,v in inputs.items() if k!='command'}),indent=2))
  cwd=root if variant=='candidate' else Path('/tmp/glob2-terrain-baseline-934c3c588')
  with (dest/'run.log').open('w') as log:subprocess.run(['/usr/bin/time','-v','-o',str(dest/'process-resources.txt')]+command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,check=True)
  scopes=[]
  for line in (dest/'run.log').read_text().splitlines():
   if not line.startswith('GLOB2_PERF_FINAL '):continue
   scopes.append(dict(pair.split('=',1) for pair in line.split()[1:] if '=' in pair))
  profiles.append(dict(growth=growth,variant=variant,scopes=scopes));print(growth,variant,len(scopes),flush=True)
(out/'profiles.json').write_text(json.dumps(profiles,indent=2))
