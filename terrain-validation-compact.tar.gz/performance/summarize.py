import csv,json,statistics
from pathlib import Path
out=Path(__file__).parent
summary=json.loads((out/'summary.json').read_text())
for r in summary:print(r['map'],r['growth'],round(r['candidate_change_percent'],2))
print('Unweighted median six scenario changes',statistics.median(r['candidate_change_percent'] for r in summary))
print('Aggregate median duration ratio',100*(sum(r['median_cpu_ns_per_tick']['candidate'] for r in summary)/sum(r['median_cpu_ns_per_tick']['baseline'] for r in summary)-1))
for file in ['kernels-shared.csv','kernels-prepared.csv','kernels-final.csv']:
 if not (out/file).exists():continue
 rows=list(csv.DictReader((out/file).open()));print(file)
 report=[]
 for size in ['128','256','512']:
  for swim in ['0','2','3','6']:
   group=[r for r in rows if r['size']==size and r['swim']==swim]
   modes=sorted({r['mode'] for r in group},key=int)
   med={m:statistics.median(float(r['cpu_ns']) for r in group if r['mode']==m) for m in modes}
   if len(med)<4:continue
   changes={m:round(100*(med[m]/med['0']-1),1) for m in modes}
   if '4' in med:changes.update(prepared_classic=round(100*(med['4']/med['2']-1),1),prepared_mixed=round(100*(med['5']/med['3']-1),1))
   report.append(dict(size=int(size),swim=int(swim),median_ns=med,changes_percent=changes))
   print(size,swim,changes)
 (out/(file.removesuffix('.csv')+'-summary.json')).write_text(json.dumps(report,indent=2))
