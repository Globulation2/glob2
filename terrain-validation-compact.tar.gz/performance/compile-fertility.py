import json,shlex,subprocess
from pathlib import Path
root=Path.cwd();out=root/'artifacts/terrain-refactor/performance'
commands=json.load(open('/tmp/glob2-terrain-baseline-build/compile_commands.json'))
base=shlex.split(next(x['command'] for x in commands if x['file'].endswith('FertilityField.cpp')))
for variant,cwd in [('baseline',Path('/tmp/glob2-terrain-baseline-934c3c588')),('candidate',root)]:
 args=base[:];args[args.index('-o')+1]=str(out/f'fertility-{variant}.o');args+=['-ffunction-sections','-fdata-sections']
 subprocess.run(args,cwd=cwd,check=True)
 link=['g++','-std=gnu++20','-O3','-Wl,--gc-sections',f'-I{cwd}/src',str(out/'fertility.cpp'),str(out/f'fertility-{variant}.o'),'-o',str(out/f'fertility-{variant}')]
 if variant=='baseline':link+=['-DLEGACY_FIELD']
 subprocess.run(link,check=True)
