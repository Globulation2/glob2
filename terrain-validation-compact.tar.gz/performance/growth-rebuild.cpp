#include <cstdint>
#include <vector>
#define private public
#include "map/FertilityField.h"
#undef private
#include <ctime>
#include <random>
#include <iostream>
std::uint64_t now(){timespec ts{};clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&ts);return std::uint64_t(ts.tv_sec)*1000000000+ts.tv_nsec;}
std::uint64_t digest(const std::vector<std::uint32_t>&v){std::uint64_t h=1469598103934665603ull;for(auto x:v){h^=x;h*=1099511628211ull;}return h;}
int main(){std::cout<<"size,layout,sample,cpu_ns,retained_bytes,digest\n";for(int w:{128,256,512})for(int layout=0;layout<3;++layout){std::vector<std::uint8_t>water(w*w),sand(w*w);std::mt19937 rng(78311);for(int y=0;y<w;++y)for(int x=0;x<w;++x){auto i=y*w+x;auto r=rng()%100; if(layout==0){water[i]=r<2;sand[i]=r>=2&&r<5;}else if(layout==1){water[i]=x%32<3;sand[i]=x%32==3||x%32==31;}else{water[i]=r<25;sand[i]=r>=25&&r<50;}}
std::vector<std::int16_t>contribution(w*w);std::vector<std::uint16_t>inhibition(w*w),local(w*w,256),habitats(w*w,3);for(int i=0;i<w*w;++i){contribution[i]=water[i]?256:0;inhibition[i]=sand[i]?256:0;} std::vector<std::uint32_t>aquatic; Fertility::Field field;for(int sample=-1;sample<9;++sample){auto t=now();field.rebuildWeighted(w,w,contribution,inhibition);aquatic=Fertility::shoreGrowthField(w,w,contribution,inhibition);field.multiplyLocal(local);auto elapsed=now()-t;size_t bytes=sizeof(Fertility::GrowthCache)+field.fertility.capacity()*4+aquatic.capacity()*4+local.capacity()*2+habitats.capacity()*2;
#ifdef LEGACY_FIELD
bytes+=field.first.capacity()*2+field.second.capacity()*2+field.wrappedX.capacity()*4+field.wrappedY.capacity()*4;
#endif
std::cout<<w<<','<<layout<<','<<sample<<','<<elapsed<<','<<bytes<<','<<digest(field.values())<<'\n';}}}
