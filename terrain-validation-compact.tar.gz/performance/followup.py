import os,time,subprocess
from pathlib import Path
root=Path.cwd();out=root/'artifacts/terrain-refactor/performance'
while not (out/'summary.json').exists():time.sleep(2)
for name in ['kernels-shared','kernels-prepared']:
 with (out/(name+'.csv')).open('w') as result:subprocess.run(['taskset','-c','15',str(out/name)],stdout=result,check=True)
 print(name,'complete',flush=True)
subprocess.run(['python3',str(out/'profile.py')],check=True)
