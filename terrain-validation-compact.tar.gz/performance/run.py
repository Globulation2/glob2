from pathlib import Path
import subprocess,json,time,statistics,os,hashlib
root=Path.cwd();out=root/'artifacts/terrain-refactor/performance'
configs={'baseline':('/tmp/glob2-terrain-baseline-build/src/glob2','/tmp/glob2-terrain-baseline-934c3c588'),'candidate':(str(root/'build/linux/client/release/src/glob2'),str(root))}
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
provenance={name:{'binary':binary,'cwd':cwd,'binary_sha256':sha(binary)} for name,(binary,cwd) in configs.items()}
provenance.update(cpu=15,cpu_sibling=31,compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],platform=os.uname()._asdict() if hasattr(os.uname(),'_asdict') else list(os.uname()),revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),tracked_diff_sha256=hashlib.sha256(subprocess.check_output(['git','diff','--binary'])).hexdigest())
(out/'provenance.json').write_text(json.dumps(provenance,indent=2))
corpus=json.loads((root/'artifacts/terrain-refactor/ecology/corpus/generated.json').read_text())
selected=[x for x in corpus if Path(x['path']).parent.name in ('allotments-1427','last-treeline-1427-256','river-1427')]
assert len(selected)==3
rows=[]
for entry in selected:
 assert sha(entry['path'])==entry['sha256'], entry['path']
 name=Path(entry['path']).parent.name
 for growth in ('normal','none'):
  for repeat in range(7):
   for variant in (('baseline','candidate') if repeat%2==0 else ('candidate','baseline')):
    dest=out/f'{name}-{growth}-{repeat}-{variant}';dest.mkdir(exist_ok=True)
    binary,cwd=configs[variant]
    command=['taskset','-c','15',binary,'--run-game','--map-file',entry['path'],'--game-seed','12345','--player','maxima','--player','nicowar','--ticks','16384','--rule',f'noGrowth={int(growth == "none")}','--compute-threads','1','--gradient-workers','0','--benchmark-warmup','2048','--output-dir',str(dest)]
    sample_inputs={'binary_sha256':provenance[variant]['binary_sha256'],'map_sha256':entry['sha256'],'command':command}
    existing=dest/'inputs.json'
    if (dest/'result.json').exists():
     assert existing.exists() and json.loads(existing.read_text())==sample_inputs, f'Stale sample: {dest}'
    else:
     existing.write_text(json.dumps(sample_inputs,indent=2))
     with (dest/'run.log').open('w') as log:
      subprocess.run(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,check=True)
    result=json.loads((dest/'result.json').read_text())
    assert result['benchmark_measured_ticks']>0
    row=dict(map=name,growth=growth,repeat=repeat,variant=variant,**{k:v for k,v in result.items() if k.startswith('benchmark_') or k in ['termination','ticks','initialChecksum','finalChecksum','gradient_jobs','gradient_published','hiring_popped_entries','teams','players']})
    row['cpu_ns_per_tick']=result['benchmark_run_cpu_ns']/result['benchmark_measured_ticks']
    rows.append(row);(out/'samples.json').write_text(json.dumps(rows,indent=2));print({k:v for k,v in row.items() if k not in ['teams','players']},flush=True)
summary=[]
for entry in selected:
 name=Path(entry['path']).parent.name
 for growth in ('normal','none'):
  group=[r for r in rows if r['map']==name and r['growth']==growth]
  values={v:[r['cpu_ns_per_tick'] for r in group if r['variant']==v] for v in configs}
  med={v:statistics.median(x) for v,x in values.items()}
  summary.append(dict(map=name,growth=growth,median_cpu_ns_per_tick=med,candidate_change_percent=100*(med['candidate']/med['baseline']-1),samples=values))
(out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
