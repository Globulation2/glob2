from pathlib import Path
import os,subprocess,concurrent.futures,json,time
root=Path.cwd();out=root/'artifacts/terrain-refactor/ecology';binary=root/'build/linux/client/release/test/glob2-engine-tests'
def run(i):
 profile=out/f'pilot-profile-{i}';profile.mkdir(exist_ok=True)
 env=os.environ.copy();env.update(GLOB2_USER_DATA_DIR=str(profile),GLOB2_TERRAIN_CALIBRATION_CORPUS=str(out/f'corpus/pilot-{i}.txt'),GLOB2_TERRAIN_CALIBRATION_OUTPUT=str(out/f'pilot-{i}.jsonl'),GLOB2_TERRAIN_CALIBRATION_SEEDS='2',GLOB2_TERRAIN_CALIBRATION_TICKS='4096',SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
 command=[str(binary),'--test-suite=TerrainEcology','--no-skip=true','--no-colors=true']
 (out/f'pilot-{i}-command.json').write_text(json.dumps({'command':command,'environment':{k:v for k,v in env.items() if k.startswith('GLOB2_TERRAIN_') or k.startswith('SDL_')}},indent=2))
 with (out/f'pilot-{i}.log').open('w') as log:
  result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 return i,result.returncode
start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for result in pool.map(run,range(4)):print(result,flush=True)
print('elapsed',time.time()-start)
