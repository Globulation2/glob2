import json
from pathlib import Path
import analyze as a
root=Path(__file__).resolve().parent;p=root/'analysis'
cases=['canals-2857-seed-19','isles-2857-seed-19','isles-1427-seed-41','last-treeline-1427-256-seed-101','last-treeline-1427-256-seed-41']
out=[]
for case in cases:
 for variant in ('baseline','candidate'):
  path=root/variant/case;d=a.read_game(path,p/'cache');wanted={8192,16384,24576,32768,49152,65024}
  rows={}
  for line in (path/'run.log').open():
   if line.startswith('GLOB2_MEASURE_HISTORY ') or line.startswith('GLOB2_MEASURE '):
    f=a.fields(line)
    if f['tick'] in wanted:rows[f['team'],f['tick']]=f
  for team in range(2):
   ai=d['result']['players'][team]['ai'];samples=[];prev=None
   for (t,tick),r in sorted(rows.items()):
    if t!=team:continue
    val={'tick':tick,'units':a.at(d,'timeline',team,tick)['units'],
      'starved':sum(r[f'deaths_{u}_1'] for u in range(3)),
      'combat_deaths':sum(r[f'deaths_{u}_0'] for u in range(3)),
      'food_buildings':sum(v for k,v in r.items() if k.startswith('buildings_1_')),
      'food_destroyed':sum(v for k,v in r.items() if k.startswith('removed_0_1_')),
      'food_demolished':sum(v for k,v in r.items() if k.startswith('removed_1_1_')),
      'wheat_stock':r['stock_1'],'wheat_delivered':r['delivered_1'],
      'wheat_meals':r['consumed_0_1'],'wheat_spawning':r['consumed_1_1'],
      'hungry':r['hungry'],'critical':r['critical'],
      'no_inn_worker_ticks':r['labour_3'],
      'local16_wheat_net':r['growthAmount_1_1']-r['growthReduction_1_1']}
    samples.append(val)
   out.append({'case':case,'variant':variant,'team':team,'ai':ai,'samples':samples})
(p/'outlier-timelines.json').write_text(json.dumps(out,indent=2)+'\n')
for row in out:
 if row['ai']=='maxima' or row['case'].startswith('last-treeline'):
  print(row['case'],row['variant'],row['team'],row['ai'])
  for s in row['samples']:print(s)
