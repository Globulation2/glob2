"""Exploratory matched-cohort investigation of midgame food-pressure warning."""
import json,collections,random
from pathlib import Path
import analyze as a
root=Path(__file__).resolve().parent;p=root/'analysis'
r=json.loads((p/'report.json').read_text());h=json.loads((p/'paired-metrics.json').read_text())
cache=p/'cache'
cohorts={'both32768':{x['case'] for x in h['32768']},'both65536':{x['case'] for x in h['65536']}}
keys=('starvation','hungry_share','critical_share','worker_delivery.wheat','worker_no_inn_share','delivered.wheat','local16_net.wheat','population')
data={name:{variant:a.read_game(root/variant/name,cache) for variant in ('baseline','candidate')} for name in cohorts['both32768']}
def pairmetrics(names,start,end):
 out=[]
 for name in sorted(names):
  row={'case':name,'map':name.rsplit('-seed-',1)[0]}
  for variant in ('baseline','candidate'):
   allmetrics=a.game_metrics(data[name][variant],start,end)
   row[variant]={k:allmetrics[k] for k in keys}
  out.append(row)
 return out
out={'exploratory':True,'intervals':{},'team_ai':{},'standardized':{}}
for label,names in cohorts.items():
 out['intervals'][label]={}
 for start,end in [(512,8192),(8192,16384),(16384,32768)]+([(32768,65536)] if label=='both65536' else []):
  out['intervals'][label][f'{start}-{end}']={'pairs':len(names),'metrics':a.aggregate(pairmetrics(names,start,end),2000,431902)}
# Worker versus non-worker groups: exact worker exposure; total and residual
# non-worker exposure derive from sampled total units, so label residual approx.
rows=[];teams=collections.defaultdict(list)
for name,variants in data.items():
 row={'map':name.rsplit('-seed-',1)[0]}
 for variant,d in variants.items():
  trows=[]
  for t in sorted(map(int,d['measure'])):
   first=a.at(d,'measure',t,512);last=a.at(d,'measure',t,32768)
   delta=lambda k:last[k]-first[k]
   workers=sum(delta(f'labour_{i}') for i in range(11))+sum(delta(f'filling_{j}_{ph}') for j in range(4) for ph in range(4))
   units=a.sampled_integral(d,t,512,32768,'units','timeline')
   deaths=[delta(f'deaths_{u}_1') for u in range(3)]
   trows.append([deaths[0],workers,sum(deaths[1:]),units-workers])
   ai=d['result']['players'][t]['ai']
   teamrow=next((x for x in teams[ai] if x['case']==name and x['team']==t),None)
   if teamrow is None:
    teamrow={'case':name,'map':row['map'],'team':t};teams[ai].append(teamrow)
   teamrow[variant]={'starvation':[sum(deaths),units],
    'worker_starvation':[deaths[0],workers], 'nonworker_starvation':[sum(deaths[1:]),units-workers],
    'hungry_share':[a.sampled_integral(d,t,512,32768,'hungry'),units],
    'worker_no_inn_share':[delta('labour_3'),workers],
    'wheat_delivery':[delta('delivered_1'),32768-512]}
  row[variant]=list(map(sum,zip(*trows)))
 rows.append(row)
for k,scale in [('worker_starvation',1e6),('nonworker_starvation',1e6),('wheat_delivery',1000)]:a.META[k]={'scale':scale,'unit':'per exposure; see group definition'}
for ai,rs in teams.items():out['team_ai'][ai]={'teams':len(rs),'metrics':a.aggregate(rs,2000,431902)}
names=sorted({x['map'] for x in rows});groups={n:[x for x in rows if x['map']==n] for n in names}
def sums(rs,variant):return [sum(x[variant][i] for x in rs) for i in range(4)]
b=sums(rows,'baseline');c=sums(rows,'candidate');weight=b[1]/(b[1]+b[3])
def standardized(v):return (weight*v[0]/v[1]+(1-weight)*v[2]/v[3])*1e6
rng=random.Random(431902);deltas=[]
for _ in range(2000):
 sample=[row for _ in names for row in groups[rng.choice(names)]]
 deltas.append(standardized(sums(sample,'candidate'))-standardized(sums(sample,'baseline')))
out['standardized']={'baseline_worker_weight':weight,'baseline_group_counts':b,'candidate_group_counts':c,
 'baseline_rate':standardized(b),'candidate_rate':standardized(c),'delta_ci95':[a.quantile(deltas,q) for q in (.025,.975)],
 'caveat':'Nonworker exposure = trapezoidal total minus exact worker-ticks; baseline worker/nonworker mixture held fixed, not per warrior/explorer species.'}
(p/'investigate.json').write_text(json.dumps(out,indent=2)+'\n')
print('STANDARDIZED',out['standardized'])
for cohort,intervals in out['intervals'].items():
 print('COHORT',cohort)
 for interval,d in intervals.items():
  print(interval,d['pairs'])
  for key in ('starvation','hungry_share','worker_delivery.wheat'):
   m=d['metrics'][key];print(key,round(m['baseline'],4),round(m['candidate'],4),[round(x,4) for x in m['delta_ci95']])
for ai,d in out['team_ai'].items():
 print('AI',ai,d['teams'])
 for k,m in d['metrics'].items():print(k,round(m['baseline'],4),round(m['candidate'],4),[round(x,4) for x in m['delta_ci95']],m['baseline_numerator'],m['candidate_numerator'])
