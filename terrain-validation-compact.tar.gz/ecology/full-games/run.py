import concurrent.futures,json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[4]
variant=sys.argv[1]
binary=Path(sys.argv[2]).resolve();cwd=Path(sys.argv[3]).resolve()
corpus=json.loads((root/'artifacts/terrain-refactor/ecology/corpus/generated.json').read_text())
pairs=[('maxima','nicowar'),('cortex','cabino'),('nicowar','maxima'),('cabino','cortex')]
seeds=[19,41,73,101]
def run(job):
 item,case=job;name=Path(item['path']).parent.name;seed=seeds[case]
 out=root/f'artifacts/terrain-refactor/ecology/full-games/{variant}/{name}-seed-{seed}'
 out.mkdir(parents=True,exist_ok=True)
 if (out/'result.json').exists():return name,seed,'existing'
 cmd=[str(binary),'--run-game','--map-file',item['path'],'--game-seed',str(seed),'--player',pairs[case][0],'--player',pairs[case][1],'--ticks','65536','--compute-threads','1','--gradient-workers','0','--telemetry','team-timeline','--output-dir',str(out)]
 (out/'command.json').write_text(json.dumps(cmd,indent=2))
 with (out/'run.log').open('w') as log:
  p=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 return name,seed,p.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for result in pool.map(run,[(item,case) for item in corpus for case in range(4)]):print(*result,flush=True)
