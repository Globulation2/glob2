import concurrent.futures,json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[4]
case='last-treeline-1427-256-seed-101'
def run(variant):
 src=root/f'artifacts/terrain-refactor/ecology/full-games/{variant}/{case}'
 out=root/f'artifacts/terrain-refactor/ecology/full-games/cortex-investigation/{variant}'
 out.mkdir(parents=True,exist_ok=False)
 cmd=json.loads((src/'command.json').read_text())
 cmd[cmd.index('--ticks')+1]='32768';cmd[cmd.index('--output-dir')+1]=str(out)
 cmd+=['--replay','true','--save','every:8192']
 env=os.environ.copy()
 for key,file in [('GLOB2_CORTEX_INN_TRACE','inn'),('GLOB2_CORTEX_DECIDE_TRACE','decide'),('GLOB2_CORTEX_TRACE','worker')]:env[key]=str(out/file)
 (out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 cwd=root if variant=='candidate' else Path('/tmp/glob2-terrain-baseline-934c3c588')
 with (out/'run.log').open('w') as log:result=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(variant,result.returncode,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,['baseline','candidate']))
