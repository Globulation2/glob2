"""Exploratory follow-up of preselected horizon flags; not confirmatory testing."""
import json,collections
from pathlib import Path
import analyze as a
p=Path(__file__).resolve().parent/'analysis'
h=json.loads((p/'paired-metrics.json').read_text())
keys={'starvation':1e6,'hungry_share':100,'critical_share':100,'worker_delivery.wheat':1000,'worker_no_inn_share':100,'delivered.wheat':1000,'local16_net.wheat':1000,'population':1}
a.META={k:{'scale':s,'unit':'see main report'} for k,s in keys.items()}
def trim(rows):return [{**r,'baseline':{k:r['baseline'][k] for k in keys},'candidate':{k:r['candidate'][k] for k in keys}} for r in rows]
def agg(rows):return a.aggregate(trim(rows),2000,431902)
rows=h['32768'];names={r['case'] for r in rows}
out={'exploratory':True,'at32768':agg(rows),'ai_strata':{},'same_survivor_cohort':{},'map_contributions':[]}
for pair in {tuple(r['ai_pair']) for r in rows}:
 selected=[r for r in rows if tuple(r['ai_pair'])==pair]
 out['ai_strata'][' / '.join(pair)]={'pairs':len(selected),'metrics':agg(selected)}
for horizon in ('8192','16384','common'):
 out['same_survivor_cohort'][horizon]=agg([r for r in h[horizon] if r['case'] in names])
for name in sorted({r['map'] for r in rows}):
 selected=[r for r in rows if r['map']==name]
 bn=sum(r['baseline']['starvation'][0] for r in selected);cn=sum(r['candidate']['starvation'][0] for r in selected)
 bd=sum(r['baseline']['starvation'][1] for r in selected);cd=sum(r['candidate']['starvation'][1] for r in selected)
 others=[r for r in rows if r['map']!=name]
 bnum=sum(r['baseline']['starvation'][0] for r in others);cnum=sum(r['candidate']['starvation'][0] for r in others)
 bden=sum(r['baseline']['starvation'][1] for r in others);cden=sum(r['candidate']['starvation'][1] for r in others)
 out['map_contributions'].append({'map':name,'pairs':len(selected),'baseline_deaths':bn,'candidate_deaths':cn,'death_delta':cn-bn,'rate_delta':(cn/cd-bn/bd)*1e6,'excluding_map_rate_delta':(cnum/cden-bnum/bden)*1e6})
out['map_contributions'].sort(key=lambda r:r['death_delta'],reverse=True)
(p/'posthoc.json').write_text(json.dumps(out,indent=2)+'\n')
print('strata')
for name,s in out['ai_strata'].items():
 print(name,s['pairs'])
 for k in keys:
  m=s['metrics'][k];print(k,round(m['baseline'],4),round(m['candidate'],4),[round(v,4) for v in m['delta_ci95']])
print('same survivor cohort')
for name,metrics in out['same_survivor_cohort'].items():
 print(name)
 for k in ('starvation','hungry_share','worker_delivery.wheat'):
  m=metrics[k];print(k,m['relative_percent'],m['delta_ci95'])
print('map contributions');print(json.dumps(out['map_contributions'],indent=2))
