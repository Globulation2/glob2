#!/usr/bin/env python3
"""Paired full-game terrain ecology audit. Ignored, reproducible review evidence.

Usage: python3 analyze.py [--baseline DIR] [--candidate DIR] [--output DIR]
       python3 analyze.py --inventory-only
No winner/checksum equivalence gate. Fixed horizons report survivors explicitly.
"""
import argparse, collections, csv, hashlib, json, math, random, re, statistics
from pathlib import Path

HERE = Path(__file__).resolve().parent
RESOURCES = ('wood', 'wheat', 'papyrus', 'stone', 'algae', 'cherry', 'orange', 'prune')
KEEP = {'team','tick','final','coverage_start','extended_coverage_start','labour_coverage_start',
        'hungry','critical','meals','eatWalkDistance','eatWalkSamples'}
PREFIX = ('births_','deaths_','harvested_','delivered_','consumed_','stock_','carried_',
          'growthTiles_','growthAmount_','growthReduction_','growthGlobal_',
          'labour_','filling_','harvestDistance_','harvestSamples_')
CACHE_VERSION = 1
META = {}

def fields(line, limited=False):
    out={}
    for token in line.split()[1:]:
        key,sep,value=token.partition('=')
        if sep and (not limited or key in KEEP or key.startswith(PREFIX)):
            try: out[key]=int(value)
            except ValueError: pass
    return out

def final_timeline(data):
    # The periodic TL stops at65024 for capped games. Headless result.json
    # separately counts live slot units and completed nonvirtual buildings at
    # the final tick (Headless.cpp). Use that observed endpoint, never extrapolate.
    tick=str(data['result']['ticks'])
    for team in data['result'].get('teams',[]):
        data['timeline'].setdefault(str(team['team']),{}).setdefault(tick,
            {'tick':int(tick),'team':team['team'],'units':team['units'],'bld':team['buildings']})
    return data

def read_game(path, cache):
    result=json.loads((path/'result.json').read_text())
    log=path/'run.log';stat=log.stat()
    key=[CACHE_VERSION,str(log.resolve()),stat.st_size,stat.st_mtime_ns]
    cached=cache/(hashlib.sha256(str(log.resolve()).encode()).hexdigest()+'.json')
    if cached.exists():
        data=json.loads(cached.read_text())
        if data['key']==key:
            data['result']=result
            return final_timeline(data)
    measure=collections.defaultdict(dict); timeline=collections.defaultdict(dict)
    for line in log.open(errors='replace'):
        if line.startswith('GLOB2_MEASURE_HISTORY ') or line.startswith('GLOB2_MEASURE '):
            row=fields(line,True);measure[str(row['team'])][str(row['tick'])]=row
        elif line.startswith('GLOB2_TL '):
            row=fields(line);timeline[str(row['team'])][str(row['tick'])]=row
    data={'key':key,'result':result,'measure':dict(measure),'timeline':dict(timeline)}
    cached.write_text(json.dumps(data,separators=(',',':')))
    return final_timeline(data)

def inventory(directory):
    result={};errors=[]
    for path in sorted(directory.glob('*/result.json')):
        try:
            data=json.loads(path.read_text())
            if data.get('status')!='completed':errors.append(f'{path.parent.name}: status {data.get("status")}')
            else:result[path.parent.name]=path.parent
        except (OSError,ValueError) as e:errors.append(f'{path}: {e}')
    return result,errors

def pairing_errors(a,b):
    errors=[]
    for key in ('game_seed',):
        if a.get(key)!=b.get(key):errors.append(key)
    for key in ('map','tick_limit','rules','experiments','winning_conditions'):
        if a['resolved'].get(key)!=b['resolved'].get(key):errors.append('resolved.'+key)
    seats=lambda r:[(p['player'],p['team'],p['ai'],p.get('runtime_values','')) for p in r['players']]
    if seats(a)!=seats(b):errors.append('player seats/AI/runtime values')
    return errors

def at(data,kind,team,tick):return data[kind][str(team)][str(tick)]

def sampled_integral(data,team,start,end,column,kind='measure'):
    rows=data[kind][str(team)]
    times=sorted(int(t) for t in rows if start<=int(t)<=end)
    if not times or times[0]!=start or times[-1]!=end:raise ValueError('incomplete integration endpoints')
    # Trapezoidal snapshot exposure, not exact per-tick unit/hunger accounting.
    return sum((rows[str(a)][column]+rows[str(b)][column])*(b-a)/2 for a,b in zip(times,times[1:]))

def validation(data):
    errors=[];teams=sorted(map(int,data['measure']))
    if not teams:return ['missing measurement history']
    first=teams[0]
    required={'tick','hungry','critical','meals','coverage_start','extended_coverage_start','labour_coverage_start'}
    for resource in range(8):
        for stem in ('harvested','delivered','stock','carried'):
            required.add(f'{stem}_{resource}')
        for event in range(3):
            required.add(f'growthGlobal_{event}_{resource}')
            for stem in ('growthTiles','growthAmount','growthReduction'):
                required.add(f'{stem}_{event}_{resource}')
    required.update(f'deaths_{unit}_1' for unit in range(3))
    for team in teams:
        rows=data['measure'][str(team)]
        previous=None
        for tick in sorted(map(int,rows)):
            row=rows[str(tick)]
            missing=required-row.keys()
            if missing:errors.append(f'team {team}: missing telemetry {sorted(missing)}')
            if str(team) not in data['timeline']:
                errors.append(f'team {team}: missing timeline')
            elif str(tick) in data['timeline'][str(team)] and tick>0:
                units=at(data,'timeline',team,tick)['units']
                if not 0<=row.get('critical',0)<=row.get('hungry',0)<=units:
                    errors.append(f'team {team} tick {tick}: invalid hunger snapshot containment')
            for key in ('coverage_start' ,'extended_coverage_start','labour_coverage_start'):
                if row.get(key,0)>512:errors.append(f'team {team}: late {key}={row[key]}');break
            for r in range(8):
                for local,global_kind in (('growthTiles',0),('growthAmount',1),('growthReduction',2)):
                    values=[row.get(f'{local}_{band}_{r}',0) for band in range(3)]
                    if not (0<=values[0]<=values[1]<=values[2]<=row.get(f'growthGlobal_{global_kind}_{r}',0)):
                        errors.append(f'team {team} tick {tick}: growth coverage containment {local}/{r}')
                if team!=first and str(tick) in data['measure'][str(first)]:
                    other=at(data,'measure',first,tick)
                    for event in range(3):
                        key=f'growthGlobal_{event}_{r}'
                        if row.get(key)!=other.get(key):errors.append(f'tick {tick}: duplicated global growth disagrees')
            if previous:
                for key,value in row.items():
                    if key.startswith(('growth','harvested_','delivered_','births_','deaths_','labour_','filling_')) and key in previous and value<previous[key]:
                        errors.append(f'team {team} tick {tick}: decreasing cumulative {key}')
            previous=row
    return sorted(set(errors))

def metric(out,name,num,den=1.,scale=1.,unit='value'):
    out[name]=[float(num),float(den)]
    META.setdefault(name,{'scale':scale,'unit':unit})

def game_metrics(data,start,end):
    out={};teams=sorted(map(int,data['measure']));duration=end-start
    current=[at(data,'measure',t,end) for t in teams];initial=[at(data,'measure',t,start) for t in teams]
    delta=lambda key:sum(c.get(key,0)-i.get(key,0) for c,i in zip(current,initial))
    global_delta=lambda key:current[0].get(key,0)-initial[0].get(key,0)
    units=sum(sampled_integral(data,t,start,end,'units','timeline') for t in teams)
    workers=sum(delta(f'labour_{a}') for a in range(11))+sum(delta(f'filling_{j}_{p}') for j in range(4) for p in range(4))
    hungry=sum(sampled_integral(data,t,start,end,'hungry') for t in teams)
    critical=sum(sampled_integral(data,t,start,end,'critical') for t in teams)
    starved=sum(delta(f'deaths_{t}_1') for t in range(3))
    metric(out,'starvation',starved,units,1e6,'deaths / million sampled unit-ticks')
    metric(out,'starvation_per_time',starved,duration,1000,'deaths / 1000 ticks')
    metric(out,'hungry_share',hungry,units,100,'percent sampled unit exposure')
    metric(out,'critical_share',critical,units,100,'percent sampled unit exposure')
    metric(out,'meals',delta('meals'),units,1000,'meals / 1000 sampled unit-ticks')
    metric(out,'worker_food_travel_share',delta('labour_1'),workers,100,'percent worker-ticks')
    metric(out,'worker_no_inn_share',delta('labour_3'),workers,100,'percent worker-ticks')
    metric(out,'inn_walk_distance',delta('eatWalkDistance'),delta('eatWalkSamples'),1,'tiles / sampled inn trip')
    metric(out,'population',sum(at(data,'timeline',t,end)['units'] for t in teams),1,1,'units / game')
    metric(out,'buildings',sum(at(data,'timeline',t,end)['bld'] for t in teams),1,1,'buildings / game')
    metric(out,'mean_population',units,duration,1,'sampled units / game')
    metric(out,'births',sum(delta(f'births_{t}') for t in range(3)),duration,1000,'births / 1000 ticks')
    for r,name in enumerate(RESOURCES):
        metric(out,f'stock.{name}',sum(c.get(f'stock_{r}',0) for c in current),1,1,'stored amount / game at horizon')
        metric(out,f'carried.{name}',sum(c.get(f'carried_{r}',0) for c in current),1,1,'carried amount / game at horizon')
        for kind in ('harvested','delivered'):
            metric(out,f'{kind}.{name}',delta(f'{kind}_{r}'),duration,1000,'amount / 1000 ticks')
        metric(out,f'worker_delivery.{name}',delta(f'delivered_{r}'),workers,1000,'amount / 1000 worker-ticks')
        added=global_delta(f'growthGlobal_1_{r}');removed=global_delta(f'growthGlobal_2_{r}')
        metric(out,f'global_added.{name}',added,duration,1000,'amount / 1000 ticks')
        metric(out,f'global_removed.{name}',removed,duration,1000,'amount / 1000 ticks')
        metric(out,f'global_net.{name}',added-removed,duration,1000,'amount / 1000 ticks')
        metric(out,f'global_new_tiles.{name}',global_delta(f'growthGlobal_0_{r}'),duration,1000,'new tiles / 1000 ticks')
        for band,radius in enumerate((8,16,32)):
            local_add=delta(f'growthAmount_{band}_{r}');local_remove=delta(f'growthReduction_{band}_{r}')
            metric(out,f'local{radius}_net.{name}',local_add-local_remove,len(teams)*duration,1000,'amount / team / 1000 ticks')
            metric(out,f'local{radius}_added_share.{name}',local_add,len(teams)*added,100,'mean team percent of global additions')
    for job,name in ((0,'swarm'),(1,'inn'),(2,'site'),(3,'other')):
        metric(out,f'harvest_distance.{name}',delta(f'harvestDistance_{job}'),delta(f'harvestSamples_{job}'),1,'tiles / sampled harvesting trip')
    for threshold,column in ((20,'units'),(3,'bld')):
        hits=[];times=[]
        for team in teams:
            rows=data['timeline'][str(team)]
            reached=[int(t) for t,row in rows.items() if int(t)<=end and row[column]>=threshold]
            hits.append(bool(reached));times.append(min(reached) if reached else end)
        metric(out,f'milestone_{column}_{threshold}_attained',sum(hits),len(teams),100,'percent teams by horizon')
        metric(out,f'milestone_{column}_{threshold}_restricted_time',sum(times),len(teams),1,'ticks; unachieved assigned horizon')
    return out

def quantile(values,p):
    values=sorted(values)
    if not values:return None
    where=(len(values)-1)*p;lo=int(where);hi=math.ceil(where)
    return values[lo]+(values[hi]-values[lo])*(where-lo)

def aggregate(rows,samples,seed):
    if not rows:return {}
    groups=collections.defaultdict(list)
    for row in rows:groups[row['map']].append(row)
    names=list(groups);rng=random.Random(seed)
    weights=[collections.Counter(rng.randrange(len(names)) for _ in names) for _ in range(samples)]
    output={}
    for key in rows[0]['baseline']:
        totals=[]
        for name in names:
            sums=[0.,0.,0.,0.]
            for row in groups[name]:
                b=row['baseline'][key];c=row['candidate'][key]
                if b[1]>0 and c[1]>0:
                    for i,v in enumerate(b+c):sums[i]+=v
            totals.append(sums)
        bn,bd,cn,cd=map(sum,zip(*totals))
        if not bd or not cd:continue
        scale=META[key]['scale'];b=bn/bd*scale;c=cn/cd*scale
        differences=[];relatives=[]
        for weight in weights:
            a=[sum(totals[i][k]*n for i,n in weight.items()) for k in range(4)]
            if not a[1] or not a[3]:continue
            bb=a[0]/a[1]*scale;cc=a[2]/a[3]*scale
            differences.append(cc-bb)
            if bb>0:relatives.append((cc/bb-1)*100)
        ci=[quantile(differences,p) for p in (.025,.975)]
        rel=[quantile(relatives,p) for p in (.025,.975)] if relatives else None
        paired=[(r['baseline'][key],r['candidate'][key]) for r in rows if r['baseline'][key][1]>0 and r['candidate'][key][1]>0]
        output[key]={'baseline':b,'candidate':c,'delta':c-b,'delta_ci95':ci,
                     'relative_percent':(c/b-1)*100 if b>0 else None,'relative_ci95':rel,
                     'pairs':len(paired),'maps':len(names),'unit':META[key]['unit'],
                     'baseline_numerator':bn,'candidate_numerator':cn,
                     'direction_resolved':bool(ci[0] is not None and (ci[0]>0 or ci[1]<0))}
    return output

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',type=Path,default=HERE/'baseline')
    parser.add_argument('--candidate',type=Path,default=HERE/'candidate')
    parser.add_argument('--output',type=Path,default=HERE/'analysis')
    parser.add_argument('--start',type=int,default=512)
    parser.add_argument('--bootstrap',type=int,default=2000)
    parser.add_argument('--inventory-only',action='store_true')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    cache=args.output/'cache';cache.mkdir(exist_ok=True)
    baseline,errors=inventory(args.baseline);candidate,issues=inventory(args.candidate);errors+=issues
    summary={'baseline_complete':len(baseline),'candidate_complete':len(candidate),
             'baseline_dir':str(args.baseline.resolve()),'candidate_dir':str(args.candidate.resolve()),
             'self_comparison':args.baseline.resolve()==args.candidate.resolve(),
             'missing_candidate':sorted(set(baseline)-set(candidate)),
             'extra_candidate':sorted(set(candidate)-set(baseline)),'errors':errors,
             'window_start':args.start,'bootstrap_replicates':args.bootstrap,
             'method':'Paired pooled rates; fixed-map cluster bootstrap, seed 431902; exact shared ticks; global growth once/game.',
             'limitations':['Fixed late horizons contain only pairs still observed; survivor counts are explicit.',
                'Last-common horizons depend on earlier termination and are descriptive, not an uncensored end-game estimator.',
                'Unit/hunger exposure uses trapezoidal 512-tick snapshots plus actual final result counts; first512 ticks excluded because initial TL records contain startup zeros.',
                'Coverage radii8/16/32 are geometric neighborhoods of periodically snapshotted buildings, not actual harvest paths; teams and nested radii overlap.',
                'Containment validation here checks telemetry nesting/local<=global only. No cell-coordinate or habitat inventory exists in these logs, so spatial crop containment cannot be established.',
                'Tick-cap durations are right-censored. Paired capped durations and termination proportions are reported; winners and RNG/checksums are not acceptance gates.',
                'Critical hunger counts hungry units with HP below maximum, including combat wounds; it is a pressure proxy, not a separate cause-of-death measurement.',
                'No formal full-game tolerance was invented; statistically resolved shifts need gameplay review alongside the separate fixed growth-calibration gates.']}
    if args.inventory_only:
        rows=[]
        for name,path in baseline.items():
            data=read_game(path,cache);issues=validation(data)
            rows.append({'case':name,'ticks':data['result']['ticks'],'termination':data['result']['termination'],
                         'teams':len(data['measure']),'history_samples':{t:len(v) for t,v in data['measure'].items()},'issues':issues})
        summary['baseline_inventory']=rows
    else:
        horizons=collections.defaultdict(list);cases=[];validation_errors=[]
        for name in sorted(set(baseline)&set(candidate)):
            a=read_game(baseline[name],cache);b=read_game(candidate[name],cache)
            mismatch=pairing_errors(a['result'],b['result'])
            if mismatch:errors.append(f'{name}: setup mismatch {mismatch}');continue
            for variant,data in (('baseline',a),('candidate',b)):
                for issue in validation(data):validation_errors.append(f'{variant}/{name}: {issue}')
            common=None
            for data in (a,b):
                for kind in ('measure','timeline'):
                    for team,rows in data[kind].items():
                        ticks=set(map(int,rows));common=ticks if common is None else common&ticks
            if not common or args.start not in common:errors.append(f'{name}: no common starting sample');continue
            end=max(common);map_name=name.rsplit('-seed-',1)[0]
            case={'case':name,'map':map_name,'baseline_end':a['result']['ticks'],'candidate_end':b['result']['ticks'],
                  'baseline_termination':a['result']['termination'],'candidate_termination':b['result']['termination'],
                  'ai_pair':[p['ai'] for p in a['result']['players']],'last_common_tick':end}
            cases.append(case)
            for label,tick in [('common',end)]+[(str(h),h) for h in (4096,8192,16384,32768,65536) if h in common]:
                if tick<=args.start:continue
                horizons[label].append({'case':name,'map':map_name,'tick':tick,'ai_pair':case['ai_pair'],
                    'baseline':game_metrics(a,args.start,tick),'candidate':game_metrics(b,args.start,tick)})
        summary['paired_games']=len(cases);summary['validation_errors']=validation_errors
        summary['cases']=cases
        summary['horizons']={label:{'pairs':len(rows),'maps':len({r['map'] for r in rows}),
                            'metrics':aggregate(rows,args.bootstrap,431902)} for label,rows in horizons.items()}
        primary=horizons.get('8192',[])
        strata=collections.defaultdict(list)
        for row in primary:strata[' / '.join(row['ai_pair'])].append(row)
        summary['primary_ai_pair_strata']={name:{'pairs':len(rows),'metrics':aggregate(rows,args.bootstrap,431902)} for name,rows in strata.items()}
        outliers={}
        for key in ('delivered.wheat','worker_delivery.wheat','local16_net.wheat','starvation','hungry_share','population'):
            values=[]
            for row in primary:
                b,c=row['baseline'][key],row['candidate'][key]
                if b[1]<=0 or c[1]<=0:continue
                base=b[0]/b[1]*META[key]['scale'];test=c[0]/c[1]*META[key]['scale']
                values.append({'case':row['case'],'baseline':base,'candidate':test,'delta':test-base,
                    'baseline_numerator':b[0],'candidate_numerator':c[0],
                    'relative_percent':100*(test/base-1) if base>0 else None})
            outliers[key]={'largest_decreases':sorted(values,key=lambda x:x['delta'])[:8],
                           'largest_increases':sorted(values,key=lambda x:x['delta'],reverse=True)[:8]}
        summary['primary_outliers']=outliers

        # Capped duration is a valid restricted endpoint; it is not mean natural game length.
        length_rows=[]
        for c in cases:
            row={'map':c['map'],'baseline':{},'candidate':{}}
            for variant in ('baseline','candidate'):
                metric(row[variant],'capped_game_duration',c[variant+'_end'],1,1,'ticks, capped at65536')
                metric(row[variant],'natural_end_fraction',c[variant+'_termination']=='engine_end',1,100,'percent matches ending before cap')
            length_rows.append(row)
        summary['duration']=aggregate(length_rows,args.bootstrap,431902)
        (args.output/'paired-metrics.json').write_text(json.dumps(dict(horizons),separators=(',',':')))
        with (args.output/'metrics.csv').open('w',newline='') as f:
            columns=['horizon','metric','pairs','maps','baseline','candidate','delta','delta_ci95','relative_percent','relative_ci95','unit']
            writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
            for label,h in summary['horizons'].items():
                for key,value in h['metrics'].items():writer.writerow({'horizon':label,'metric':key,**{k:value[k] for k in columns[2:]}})
    (args.output/'report.json').write_text(json.dumps(summary,indent=2))
    lines=['# Paired full-game ecology comparison',f'Completed baseline: {len(baseline)}; candidate: {len(candidate)}.',
           f'Counter/exposure window starts at tick {args.start}. Paired map-cluster bootstrap: {args.bootstrap} draws;95% percentile intervals.',
           '']
    if summary['self_comparison']:lines += ['**Self-comparison validation only; this is not candidate evidence.**','']
    for label,h in summary.get('horizons',{}).items():
        lines += [f'## Horizon {label}: {h["pairs"]} pairs, {h["maps"]} maps','',
                  '| Metric | Baseline | Candidate | Change (95% CI) |','| --- | ---: | ---: | --- |']
        keys=['delivered.wheat','delivered.wood','global_net.wheat','global_net.wood','global_net.algae',
              'local16_net.wheat','worker_delivery.wheat','starvation','hungry_share','critical_share',
              'worker_no_inn_share','population','buildings','milestone_units_20_attained']
        for key in keys:
            if key not in h['metrics']:continue
            m=h['metrics'][key];ci=m['delta_ci95']
            change=f'{m["delta"]:+.4g} [{ci[0]:+.4g},{ci[1]:+.4g}]'
            if m['relative_percent'] is not None:change+=f' ({m["relative_percent"]:+.2f}%)'
            lines.append(f'| {key} | {m["baseline"]:.5g} | {m["candidate"]:.5g} | {change} |')
        lines.append('')
    lines += ['## Limits and interpretation','']+['- '+x for x in summary['limitations']]
    lines += ['',f'Setup errors: {len(errors)}; telemetry validation errors: {len(summary.get("validation_errors",[]))}.',
              'Full per-resource/local-band results: metrics.csv. Pairwise numerators and denominators: paired-metrics.json.']
    (args.output/'report.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:summary[k] for k in ('baseline_complete','candidate_complete','paired_games') if k in summary},indent=2))
    if errors:print('Setup/data errors:',len(errors))
    print(args.output/'report.md')

if __name__=='__main__':main()
