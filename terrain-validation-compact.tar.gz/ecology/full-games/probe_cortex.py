import concurrent.futures,gzip,json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[4];base=root/'artifacts/terrain-refactor/ecology/full-games/cortex-investigation'
def run(job):
 variant,tick=job;out=base/variant/f'probe-{tick}';out.mkdir(exist_ok=False)
 checkpoint=out/'checkpoint.game';checkpoint.write_bytes(gzip.decompress((base/variant/f'checkpoint-{tick}.game.gz').read_bytes()))
 binary=root/'build/linux/client/release/src/glob2' if variant=='candidate' else Path('/tmp/glob2-terrain-baseline-build/src/glob2')
 cmd=[str(binary),'-nox',str(checkpoint),str(tick+256),'1']
 env=os.environ.copy()
 for key,file in [('GLOB2_CORTEX_INN_TRACE','inn'),('GLOB2_CORTEX_DECIDE_TRACE','decide'),('GLOB2_CORTEX_TRACE','worker')]:env[key]=str(out/file)
 env['CORTEX_DUMP_PERIODIC']='1'
 cwd=root if variant=='candidate' else Path('/tmp/glob2-terrain-baseline-934c3c588')
 (out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (out/'run.log').open('w') as log:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(variant,tick,p.returncode,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,[(v,t) for v in ('baseline','candidate') for t in (8192,16384,24576,32768)]))
