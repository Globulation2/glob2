# Paired full-game ecology comparison
Completed baseline: 96; candidate: 96.
Counter/exposure window starts at tick 512. Paired map-cluster bootstrap: 2000 draws;95% percentile intervals.

## Horizon common: 96 pairs, 24 maps

| Metric | Baseline | Candidate | Change (95% CI) |
| --- | ---: | ---: | --- |
| delivered.wheat | 79.925 | 80.358 | +0.4335 [-2.437,+3.317] (+0.54%) |
| delivered.wood | 12.296 | 12.456 | +0.16 [-0.3512,+0.6611] (+1.30%) |
| global_net.wheat | 166.68 | 167.68 | +1.003 [-0.6655,+2.724] (+0.60%) |
| global_net.wood | 174.46 | 173.4 | -1.061 [-4.261,+1.637] (-0.61%) |
| global_net.algae | 61.189 | 61.271 | +0.08238 [-0.5401,+0.7796] (+0.13%) |
| local16_net.wheat | 34.324 | 34.488 | +0.1646 [-0.9242,+1.318] (+0.48%) |
| worker_delivery.wheat | 0.70382 | 0.69904 | -0.004781 [-0.02653,+0.02308] (-0.68%) |
| starvation | 7.0782 | 6.908 | -0.1702 [-2.177,+1.916] (-2.40%) |
| hungry_share | 17.855 | 18.213 | +0.3586 [-0.9712,+1.361] (+2.01%) |
| critical_share | 9.8655 | 9.9916 | +0.1261 [-1.232,+1.22] (+1.28%) |
| worker_no_inn_share | 5.7419 | 6.009 | +0.2671 [-0.9108,+1.174] (+4.65%) |
| population | 243.98 | 245.4 | +1.417 [-14.06,+17.23] (+0.58%) |
| buildings | 42.74 | 42.781 | +0.04167 [-2.99,+2.834] (+0.10%) |
| milestone_units_20_attained | 92.708 | 94.271 | +1.562 [+0,+3.138] (+1.69%) |

## Horizon 4096: 96 pairs, 24 maps

| Metric | Baseline | Candidate | Change (95% CI) |
| --- | ---: | ---: | --- |
| delivered.wheat | 39.045 | 39.036 | -0.008719 [-0.5553,+0.5059] (-0.02%) |
| delivered.wood | 4.8799 | 4.9526 | +0.07266 [-0.1192,+0.2675] (+1.49%) |
| global_net.wheat | 593.6 | 593.82 | +0.2151 [-1.622,+2.145] (+0.04%) |
| global_net.wood | 546.54 | 544.71 | -1.828 [-5.368,+2.009] (-0.33%) |
| global_net.algae | 98.272 | 99.368 | +1.096 [-0.2558,+2.671] (+1.11%) |
| local16_net.wheat | 43.922 | 43.748 | -0.1744 [-0.7414,+0.3953] (-0.40%) |
| worker_delivery.wheat | 2.5597 | 2.5534 | -0.006337 [-0.03415,+0.0179] (-0.25%) |
| starvation | 0 | 0 | +0 [+0,+0] |
| hungry_share | 1.1925 | 1.153 | -0.03943 [-0.1077,+0.0206] (-3.31%) |
| critical_share | 0.037736 | 0.022608 | -0.01513 [-0.0553,+0.01586] (-40.09%) |
| worker_no_inn_share | 0 | 0 | +0 [+0,+0] |
| population | 30.167 | 30.302 | +0.1354 [-0.1771,+0.4375] (+0.45%) |
| buildings | 6.8229 | 6.9375 | +0.1146 [-0.1044,+0.3333] (+1.68%) |
| milestone_units_20_attained | 23.958 | 27.604 | +3.646 [+0.5208,+7.292] (+15.22%) |

## Horizon 8192: 96 pairs, 24 maps

| Metric | Baseline | Candidate | Change (95% CI) |
| --- | ---: | ---: | --- |
| delivered.wheat | 43.205 | 42.529 | -0.6755 [-1.51,+0.114] (-1.56%) |
| delivered.wood | 6.5701 | 6.661 | +0.09087 [-0.1383,+0.3039] (+1.38%) |
| global_net.wheat | 408.97 | 409.67 | +0.6985 [-0.9565,+2.278] (+0.17%) |
| global_net.wood | 389.4 | 389.91 | +0.5086 [-2.127,+3.201] (+0.13%) |
| global_net.algae | 90.057 | 90.499 | +0.4422 [-0.51,+1.415] (+0.49%) |
| local16_net.wheat | 34.435 | 34.821 | +0.3859 [-0.1628,+0.9068] (+1.12%) |
| worker_delivery.wheat | 1.8749 | 1.8472 | -0.02762 [-0.0468,-0.006745] (-1.47%) |
| starvation | 0.77331 | 0.86121 | +0.0879 [-0.0002798,+0.2073] (+11.37%) |
| hungry_share | 8.219 | 8.0329 | -0.1861 [-0.391,+0.01601] (-2.26%) |
| critical_share | 2.1128 | 1.9446 | -0.1682 [-0.4024,+0.0396] (-7.96%) |
| worker_no_inn_share | 0.97404 | 0.88956 | -0.08449 [-0.218,+0.03607] (-8.67%) |
| population | 54.417 | 54.073 | -0.3438 [-1.385,+0.6672] (-0.63%) |
| buildings | 13.552 | 13.594 | +0.04167 [-0.3021,+0.3646] (+0.31%) |
| milestone_units_20_attained | 68.229 | 66.667 | -1.562 [-4.167,+1.042] (-2.29%) |

## Horizon 16384: 91 pairs, 24 maps

| Metric | Baseline | Candidate | Change (95% CI) |
| --- | ---: | ---: | --- |
| delivered.wheat | 53.177 | 53.393 | +0.216 [-1.176,+1.816] (+0.41%) |
| delivered.wood | 8.4058 | 8.4356 | +0.02977 [-0.1669,+0.2444] (+0.35%) |
| global_net.wheat | 285.88 | 286.05 | +0.1675 [-1.09,+1.251] (+0.06%) |
| global_net.wood | 281.54 | 281.08 | -0.4556 [-2.744,+1.459] (-0.16%) |
| global_net.algae | 74.622 | 74.69 | +0.06785 [-0.7405,+0.8184] (+0.09%) |
| local16_net.wheat | 30.647 | 30.714 | +0.06681 [-0.2937,+0.4085] (+0.22%) |
| worker_delivery.wheat | 1.3464 | 1.3432 | -0.003204 [-0.02275,+0.01237] (-0.24%) |
| starvation | 2.0024 | 2.1715 | +0.1691 [-0.3702,+0.749] (+8.45%) |
| hungry_share | 11.857 | 12.041 | +0.1838 [-0.09172,+0.4909] (+1.55%) |
| critical_share | 4.6703 | 4.8204 | +0.1501 [-0.1489,+0.4398] (+3.21%) |
| worker_no_inn_share | 1.9622 | 2.1755 | +0.2133 [-0.07474,+0.5299] (+10.87%) |
| population | 116.42 | 117.99 | +1.571 [-2.441,+6.215] (+1.35%) |
| buildings | 27.11 | 26.934 | -0.1758 [-1.161,+0.8043] (-0.65%) |
| milestone_units_20_attained | 91.758 | 91.758 | +0 [-1.63,+1.613] (+0.00%) |

## Horizon 32768: 63 pairs, 24 maps

| Metric | Baseline | Candidate | Change (95% CI) |
| --- | ---: | ---: | --- |
| delivered.wheat | 75.222 | 76.673 | +1.452 [-0.7568,+4.055] (+1.93%) |
| delivered.wood | 12.626 | 12.751 | +0.1255 [-0.3458,+0.5789] (+0.99%) |
| global_net.wheat | 217.38 | 218.26 | +0.8769 [-0.5064,+2.271] (+0.40%) |
| global_net.wood | 198.5 | 198.06 | -0.4365 [-3.494,+2.44] (-0.22%) |
| global_net.algae | 64.756 | 64.927 | +0.1712 [-0.3205,+0.6714] (+0.26%) |
| local16_net.wheat | 34.312 | 34.138 | -0.1732 [-1.537,+1.035] (-0.50%) |
| worker_delivery.wheat | 0.90887 | 0.91185 | +0.002981 [-0.01395,+0.02451] (+0.33%) |
| starvation | 2.825 | 4.1347 | +1.31 [+0.1096,+2.632] (+46.36%) |
| hungry_share | 14.847 | 15.858 | +1.011 [+0.1257,+1.754] (+6.81%) |
| critical_share | 7.1862 | 8.026 | +0.8398 [+0.0465,+1.532] (+11.69%) |
| worker_no_inn_share | 3.087 | 4.2945 | +1.208 [-0.07104,+2.458] (+39.12%) |
| population | 267.17 | 269.46 | +2.286 [-7.787,+13.22] (+0.86%) |
| buildings | 45.413 | 46.937 | +1.524 [-1.092,+4.458] (+3.36%) |
| milestone_units_20_attained | 99.206 | 100 | +0.7937 [+0,+2.83] (+0.80%) |

## Horizon 65536: 18 pairs, 9 maps

| Metric | Baseline | Candidate | Change (95% CI) |
| --- | ---: | ---: | --- |
| delivered.wheat | 100.24 | 101.64 | +1.399 [-7.497,+10.81] (+1.40%) |
| delivered.wood | 14.089 | 14.142 | +0.05297 [-1.523,+1.402] (+0.38%) |
| global_net.wheat | 189.08 | 190.61 | +1.522 [-1.673,+4.913] (+0.80%) |
| global_net.wood | 124.47 | 123.14 | -1.328 [-3.756,+0.9345] (-1.07%) |
| global_net.algae | 58.132 | 58.335 | +0.2025 [-0.6417,+1.195] (+0.35%) |
| local16_net.wheat | 38.901 | 39.702 | +0.8018 [-0.8779,+2.957] (+2.06%) |
| worker_delivery.wheat | 0.5751 | 0.55934 | -0.01576 [-0.05156,+0.03146] (-2.74%) |
| starvation | 7.2564 | 7.1393 | -0.1171 [-2.227,+1.863] (-1.61%) |
| hungry_share | 18.326 | 19.354 | +1.028 [-0.5275,+2.478] (+5.61%) |
| critical_share | 9.8083 | 10.375 | +0.5671 [-0.9553,+1.927] (+5.78%) |
| worker_no_inn_share | 6.8311 | 7.7035 | +0.8724 [-0.9,+1.944] (+12.77%) |
| population | 386.61 | 414.78 | +28.17 [-36.06,+108.4] (+7.29%) |
| buildings | 67.667 | 68.667 | +1 [-6.159,+9.5] (+1.48%) |
| milestone_units_20_attained | 100 | 100 | +0 [+0,+0] (+0.00%) |

## Limits and interpretation

- Fixed late horizons contain only pairs still observed; survivor counts are explicit.
- Last-common horizons depend on earlier termination and are descriptive, not an uncensored end-game estimator.
- Unit/hunger exposure uses trapezoidal 512-tick snapshots plus actual final result counts; first512 ticks excluded because initial TL records contain startup zeros.
- Coverage radii8/16/32 are geometric neighborhoods of periodically snapshotted buildings, not actual harvest paths; teams and nested radii overlap.
- Containment validation here checks telemetry nesting/local<=global only. No cell-coordinate or habitat inventory exists in these logs, so spatial crop containment cannot be established.
- Tick-cap durations are right-censored. Paired capped durations and termination proportions are reported; winners and RNG/checksums are not acceptance gates.
- Critical hunger counts hungry units with HP below maximum, including combat wounds; it is a pressure proxy, not a separate cause-of-death measurement.
- No formal full-game tolerance was invented; statistically resolved shifts need gameplay review alongside the separate fixed growth-calibration gates.

Setup errors: 0; telemetry validation errors: 0.
Full per-resource/local-band results: metrics.csv. Pairwise numerators and denominators: paired-metrics.json.
