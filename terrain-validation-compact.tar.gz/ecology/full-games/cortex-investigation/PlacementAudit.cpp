#include "EngineFixtures.h"
#include "Engine.h"
#include "CortexPlacement.h"
#include "CortexPlacementGeo.h"
#include "CortexConstants.h"
#include "IntBuildingType.h"
#include "BuildingType.h"
#include <iostream>
#include <array>
#include <map>

TEST_CASE("ignored Cortex placement audit" * doctest::test_suite("TerrainDiagnosis"))
{
 using namespace Cortex;
 for (const char* variant : {"baseline","candidate"}) for (int tick : {8192,16384,24576,32768})
 {
  glob2test::HeadlessGlobals globals;
  Engine engine;
  auto path=glob2test::sourceRoot()/"artifacts/terrain-refactor/ecology/full-games/cortex-investigation"/variant/("checkpoint-"+std::to_string(tick)+".game.gz");
  REQUIRE(engine.initCustom(path.string())==Engine::EE_NO_ERROR);
  auto& game=engine.gui.game;auto& map=game.map;auto* team=game.teams[1];
  const auto* bt=globalContainer->buildingsTypes.getByType("inn",0,true);
  int ox=0,oy=0,ew=bt->width,eh=bt->height;grownFootprintBox(bt,ox,oy,ew,eh);
  PlacementGeometry geo(team,map);
  std::array<unsigned,12> before{},only{}; std::map<unsigned,unsigned> masks;
  std::array<unsigned,TERRAIN_COUNT> ids{};unsigned semantics=0;
  for(int y=0;y<map.getH();++y) for(int x=0;x<map.getW();++x)
  {++ids[map.terrainTypeAt(x,y)];if(map.terrainPropertiesAt(x,y).buildable!=(map.getTerrain(x,y)<16)) ++semantics;}
  std::cout<<"AUDIT "<<variant<<" tick="<<tick<<" groundModifiers="<<map.hasTerrainMovementModifiers()<<" airConstraints="<<map.hasAirTerrainConstraints()<<" legacyBuildabilityMismatches="<<semantics<<" ids=";
  for(auto n:ids)std::cout<<n<<','; std::cout<<'\n';
  for(int i=0;i<Building::MAX_COUNT;++i)if(auto*b=team->myBuildings[i])if(b->buildingState!=Building::DEAD)
   std::cout<<"BUILDING type="<<b->type->shortTypeNum<<" level="<<b->type->level<<" site="<<b->type->isBuildingSite<<" at="<<b->posX<<','<<b->posY<<" dims="<<b->type->width<<','<<b->type->height<<'\n';
  for(int x=0;x<map.getW();++x)for(int y=0;y<map.getH();++y)
  {
   int gx=x+ox,gy=y+oy;std::array<bool,12> ok{};ok.fill(true);
   ok[0]=map.isMapDiscovered(map.normalizeX(gx),map.normalizeY(gy),team->allies)&&map.isMapDiscovered(map.normalizeX(gx+ew-1),map.normalizeY(gy+eh-1),team->allies);
   for(int dx=0;dx<ew;++dx)for(int dy=0;dy<eh;++dy)
   {ok[1]&=map.terrainPropertiesAt(gx+dx,gy+dy).buildable;ok[2]&=map.getBuilding(gx+dx,gy+dy)==NOGBID;ok[3]&=!map.isResource(gx+dx,gy+dy);}
   ok[4]=nearestWheatDist(map,x,y,CORTEX_WHEAT_MAX_DIST)>=0;
   ok[5]=countSurvivingWheatWithin(map,x,y,bt->width,bt->height,CORTEX_WHEAT_MIN_TILES_RADIUS)>=CORTEX_WHEAT_MIN_TILES;
   ok[6]=countSurvivingWheatWithin(map,gx,gy,ew,eh,CORTEX_INN_WHEAT_EDGE_DIST)>=1;
   int dist=geo.distanceToNearestBuildingType(x,y,IntBuildingType::FOOD_BUILDING);ok[7]=dist<0||dist>=CORTEX_INN_MIN_SPACING;
   ok[8]=innOccupiedSides(map,gx,gy,ew,eh,-1,-1,0,0)<=CORTEX_INN_MAX_TOUCH_SIDES;
   ok[9]=!geo.candidateCrowdsInn(gx,gy,ew,eh);
   ok[10]=!geo.candidateOverlapsReservedExpansion(gx,gy,ew,eh);
   unsigned mask=0;bool pass=true;
   for(unsigned i=0;i<ok.size();++i){if(pass)++before[i];if(!ok[i]){mask|=1u<<i;pass=false;}}
   ++masks[mask];for(unsigned i=0;i<11;++i)if(mask==(1u<<i)){++only[i];if(only[i]<5)std::cout<<"SINGLE_FAIL gate="<<i<<" at="<<x<<','<<y<<'\n';}
  }
  std::cout<<"GATES fog,terrain,building,resource,wheatDistance,wheatCluster,wheatEdge,innSpacing,ownSides,crowdsInn,reserved,pass\nBEFORE ";for(auto v:before)std::cout<<v<<',';std::cout<<"\nONLY_FAIL ";for(auto v:only)std::cout<<v<<',';std::cout<<'\n';
  std::cout<<"NEAR_WHEAT_FAIL_MASKS ";for(auto [mask,count]:masks)if(!(mask&((1u<<0)|(1u<<1)|(1u<<4)|(1u<<5)|(1u<<6))))std::cout<<mask<<':'<<count<<',';std::cout<<'\n';
  BuildCandidate candidates[CORTEX_BUILD_CANDIDATES];int actual=placeCandidates(&game,team,IntBuildingType::FOOD_BUILDING,0,candidates);
  std::cout<<"PRODUCTION_CANDIDATES "<<actual<<'\n';CHECK(actual==int(std::min<unsigned>(before[11],CORTEX_BUILD_CANDIDATES)));
 }
}
