from pathlib import Path
import shlex,subprocess,json
root=Path.cwd();out=root/'artifacts/terrain-refactor/ecology/full-games/cortex-investigation'
lines=(root/'artifacts/terrain-refactor/build.log').read_text().splitlines()
compile=shlex.split(next(l for l in lines if l.startswith('g++ ') and ' -c ' in l and 'CortexPlacementCandidates.cpp' in l))
compile[compile.index('-o')+1]=str(out/'PlacementAudit.o')
compile[-1]=str(out/'PlacementAudit.cpp')
compile+=['-fno-access-control','-Itest/support','-Itest/third_party','-Isrc/ai/cortex']
link=shlex.split(next(l for l in reversed(lines) if l.startswith('g++ -o build/linux/client/release/test/glob2-engine-tests ')))
link[link.index('-o')+1]=str(out/'placement-audit')
link.insert(3,str(out/'PlacementAudit.o'))
# The original relative rpath belongs to build/test; retain its actual library path.
link+=['-Wl,-rpath,'+str(root/'build/linux/client/release/lib/glob2')]
(out/'build-commands.json').write_text(json.dumps([compile,link],indent=2)+'\n')
subprocess.run(compile,check=True);subprocess.run(link,check=True)
