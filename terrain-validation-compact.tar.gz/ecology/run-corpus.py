from pathlib import Path
import os,subprocess,concurrent.futures,json,time,sys
root=Path.cwd();out=root/'artifacts/terrain-refactor/ecology';binary=root/'build/linux/client/release/test/glob2-engine-tests'
part=sys.argv[1];first=1 if part=='train' else 17
maps=(out/f'corpus/{part}.txt').read_text().splitlines()
def run(i):
 profile=out/f'{part}-profile-{i}';profile.mkdir(exist_ok=True)
 manifest=out/f'corpus/{part}-{i}.txt';manifest.write_text('\n'.join(maps[i::8])+'\n')
 target=out/f'{part}-{i}.jsonl'
 if target.exists():raise RuntimeError(f'Refusing to append duplicate observations: {target}')
 env=os.environ.copy();env.update(GLOB2_USER_DATA_DIR=str(profile),GLOB2_TERRAIN_CALIBRATION_CORPUS=str(manifest),GLOB2_TERRAIN_CALIBRATION_OUTPUT=str(target),GLOB2_TERRAIN_CALIBRATION_SEEDS='16',GLOB2_TERRAIN_CALIBRATION_FIRST_SEED=str(first),GLOB2_TERRAIN_CALIBRATION_TICKS='65536',SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
 command=[str(binary),'--test-suite=TerrainEcology','--no-skip=true','--no-colors=true']
 (out/f'{part}-{i}-command.json').write_text(json.dumps({'command':command,'environment':{k:v for k,v in env.items() if k.startswith('GLOB2_TERRAIN_') or k.startswith('SDL_')}},indent=2))
 with (out/f'{part}-{i}.log').open('w') as log:
  result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 return i,result.returncode
start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 for result in pool.map(run,range(8)):print(result,flush=True)
print('elapsed',time.time()-start)
