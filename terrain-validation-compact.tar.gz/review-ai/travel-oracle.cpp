#include "field/TerrainTravel.h"
#include <cassert>
#include <random>
#include <iostream>
int main() {
 std::mt19937 rng(682451);
 for(int test=0;test<600;++test) {
  const int w=2+rng()%7,h=2+rng()%7,n=w*h;
  std::vector<TerrainType> types(n);std::vector<unsigned char> influence(n);
  std::vector<short> distance(n);std::vector<unsigned> truth(n,1000000),power(n);
  for(int i=0;i<n;++i) {
   types[i]=TerrainType(GRASS+rng()%3);
   distance[i]=rng()%4==0?1:0;influence[i]=distance[i]?0:1;
   if(rng()%9==0){distance[i]=2;truth[i]=0;influence[i]=20+rng()%236;power[i]=influence[i]*GRADIENT_STEP;}
  }
  for(int it=0;it<n;++it)for(int i=0;i<n;++i)for(int dy=-1;dy<=1;++dy)for(int dx=-1;dx<=1;++dx) {
   if(!dx&&!dy)continue;int to=((i/w+dy+h)%h)*w+(i%w+dx+w)%w;
   const auto step=field::terrainTravelCost(terrainProperties(types[i]),field::TerrainTravel::Walk);
   if(distance[to]!=1)truth[to]=std::min(truth[to],truth[i]+step);
   const auto entry=field::terrainTravelCost(terrainProperties(types[to]),field::TerrainTravel::Walk);
   if(influence[to] && power[i]>entry+GRADIENT_STEP)power[to]=std::max(power[to],power[i]-entry);
  }
  field::expandTerrainTravel(distance,w,h,field::TerrainTravel::Walk,[&](size_t i){return types[i];});
  field::expandTerrainInfluence(influence.data(),w,h,[&](size_t i){return types[i];});
  for(int i=0;i<n;++i){if(truth[i]<1000000)assert(distance[i]==2+(truth[i]+9)/10);if(power[i])assert(influence[i]==power[i]/10);}
 }
 std::cout<<"600 random weighted strategic/influence fields match independent repeated-relaxation oracle\n";
}
