import gzip,struct,json,collections
from pathlib import Path
p=Path('artifacts/terrain-refactor/ecology/full-games/maxima-investigation')
def arrays(path):
 d=gzip.decompress(path.read_bytes());n=struct.unpack_from('>I',d)[0];minor=struct.unpack_from('>I',d,8+n)[0];o=struct.unpack_from('>I',d,16+n)[0];assert d[o:o+4]==b'MapB';w,h=struct.unpack_from('>II',d,o+4);w=1<<w;h=1<<h;o+=12
 def packed(size):
  nonlocal o
  out=[]
  for base in range(0,w*h,4096):
   mode,length=struct.unpack_from('>BI',d,o);o+=5;b=d[o:o+length];o+=length;z=0
   def word():
    nonlocal z
    v=int.from_bytes(b[z:z+size],'big');z+=size;return v
   def var():
    nonlocal z
    v=0;s=0
    while True:
     x=b[z];z+=1;v|=(x&127)<<s
     if x<128:return v
     s+=7
   count=min(4096,w*h-base);v=word();block=[v]
   while len(block)<count:
    if mode==0:v=word();block.append(v)
    elif mode==1:block.append(v)
    else:
     delta=var()
     if delta==0:block += [v]*var()
     else:v=(v+((delta>>1)^-(delta&1)))&((1<<(size*8))-1);block.append(v)
   assert z==len(b) and len(block)==count;out+=block
  return out
 a={}
 fields=[('undermap',1),('discovered',4),('terrain',2)]+([('identity',2)] if minor>=134 else [])+[('building',2),('resource',1),('variety',1),('amount',1),('animation',1),('ground',2),('air',2),('forbidden',4)]
 for name,size in fields:a[name]=packed(size)
 return w,h,a
out={}
for variant in ('baseline','candidate'):
 out[variant]={}
 for tick in (16384,24576,32768):
  path=p/variant/f'checkpoint-{tick}.game.gz';path=path if path.exists() else p/variant/'final.game.gz'
  w,h,a=arrays(path);d=json.loads((p/variant/f'snapshot-{tick}.json').read_text())
  inns=[b for b in d['buildings'] if b['typeNum'] in(3,5,7) and b['state']==1]
  hungry=[u for u in d['units'] if u['medical']==1 and u['targetBuilding']==65535 and u['displacement'] not in(20,22,24)]
  result={'hungryWithoutTarget':len(hungry),'inns':[{'gid':b['gid'],'x':b['posX'],'y':b['posY'],'wheat':b['resources'][1],'capacity':b['maxInside'],'reserved':len(b['inside']),'listState':b['inCanFeed'],'carriers':len(b['workers'])} for b in inns]}
  def neigh(i):
   x=i%w;y=i//w
   return [((y+dy)%h)*w+(x+dx)%w for dy in(-1,0,1) for dx in(-1,0,1) if dx or dy]
  for mode in ('terrainOnly','withResourcesAndForbidden'):
   labels=[-1]*(w*h);sizes=[]
   def allowed(i):return a['terrain'][i]<256 and (mode=='terrainOnly' or (a['resource'][i]==255 and a['building'][i]==65535 and not(a['forbidden'][i]&1)))
   for i in range(w*h):
    if labels[i]>=0 or not allowed(i):continue
    label=len(sizes);q=[i];labels[i]=label
    for j in q:
     for k in neigh(j):
      if labels[k]<0 and allowed(k):labels[k]=label;q.append(k)
    sizes.append(len(q))
   fed=set();allFed=set();componentBuildings=collections.defaultdict(list)
   if mode=='terrainOnly':
    for b in d['buildings']:
     i=b['posY']*w+b['posX'];componentBuildings[labels[i]].append({'gid':b['gid'],'type':b['typeNum'],'state':b['state'],'x':b['posX'],'y':b['posY']})
   for b in inns:
    footprint=[i for i,gid in enumerate(a['building']) if gid==b['gid']]
    for i in footprint:
     for j in [i]+neigh(i):
      if labels[j]>=0:
       allFed.add(labels[j])
       if b['inCanFeed']==1:fed.add(labels[j])
   counts=collections.Counter();examples=[]
   for u in hungry:
    i=u['posY']*w+u['posX'];ls={labels[j] for j in [i]+neigh(i) if labels[j]>=0}
    if u['abilities'][4][0] or u['abilities'][5][0]:counts['swimmerOrFlyer']+=1;continue
    key='connectedToListedInn' if ls&fed else 'disconnectedFromListedInn';counts[key]+=1
    if key=='disconnectedFromListedInn':examples.append({'gid':u['gid'],'x':u['posX'],'y':u['posY'],'components':sorted(ls),'componentSizes':[sizes[l] for l in sorted(ls)],'hasInnEvenIfUnavailable':bool(ls&allFed)})
   result[mode]={'counts':dict(counts),'examples':examples,'componentBuildings':dict(componentBuildings) if mode=='terrainOnly' else {}}
  out[variant][tick]=result
(p/'access-analysis.json').write_text(json.dumps(out,indent=2))
for v,ticks in out.items():
 for t,r in ticks.items():print(v,t,'inns',len(r['inns']),'wheat',sum(b['wheat'] for b in r['inns']),'reserved/cap',sum(b['reserved'] for b in r['inns']),sum(b['capacity'] for b in r['inns']),r['terrainOnly']['counts'],r['withResourcesAndForbidden']['counts'])
