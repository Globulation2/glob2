#include "src/field/AirPathfind.h"
#include <cassert>
#include <iostream>
#define CHECK_EQ(a,b) assert((a)==(b))
int main() {
    constexpr int width=8,height=4,cells=width*height;
    unsigned state=9137;
    const auto random=[&] { state=1664525u*state+1013904223u;return state; };
    for(int trial=0;trial<80;++trial)
    {
        std::array<bool,cells> passable{};
        std::array<unsigned,cells> costs{};
        for(int i=0;i<cells;++i) { passable[i]=(random()%5)!=0;costs[i]=1+random()%32; }
        const int tx=random()%width,ty=random()%height;
        const auto access=[&](int x,int y){return passable[x*height+y];};
        const auto entry=[&](int x,int y){return costs[x*height+y];};
        field::AirDistanceField reverse(width,height,tx,ty,access,entry,true,field::AirDistanceDirection::ToDestination);
        constexpr unsigned infinity=decltype(reverse)::unreachable;
        // Independent Bellman-Ford relaxation of forward edges: the distance
        // from u is min(entry(v)+distance(v)) over accessible neighbors v.
        std::array<unsigned,cells> oracle;
        oracle.fill(infinity);
        if(access(tx,ty)) oracle[tx*height+ty]=0;
        else for(int y=-1;y<=1;++y) for(int x=-1;x<=1;++x)
        {
            if(!x&&!y)continue;
            const int nx=(tx+x+width)%width,ny=(ty+y+height)%height;
            if(access(nx,ny))oracle[nx*height+ny]=0;
        }
        for(int iteration=0;iteration<cells;++iteration)
            for(int x=0;x<width;++x) for(int y=0;y<height;++y)
                if(access(x,y)) for(int dy=-1;dy<=1;++dy) for(int dx=-1;dx<=1;++dx)
                {
                    if(!dx&&!dy)continue;
                    const int nx=(x+dx+width)%width,ny=(y+dy+height)%height;
                    if(!access(nx,ny)||oracle[nx*height+ny]==infinity)continue;
                    const unsigned cost=entry(nx,ny)*(dx&&dy?GRADIENT_DIAGONAL_STEP:GRADIENT_STEP)/GRADIENT_STEP;
                    oracle[x*height+y]=std::min(oracle[x*height+y],cost+oracle[nx*height+ny]);
                }
        for(int x=0;x<width;++x) for(int y=0;y<height;++y)
            CHECK_EQ(reverse.costTo(x,y),oracle[x*height+y]);
    }
std::cout<<"2560 reverse-distance oracle cases passed\n";
}
