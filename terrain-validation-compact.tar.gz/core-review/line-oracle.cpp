#include "src/map/TerrainLine.h"
#include <random>
#include <cassert>
#include <iostream>
bool intersects(int x0,int y0,int x1,int y1,int cx,int cy) {
 double lo=0,hi=1;
 const auto clip=[&](int p,int d,int low,int high) {
  if(!d)return p>=low&&p<=high;
  double a=double(low-p)/d,b=double(high-p)/d;
  if(a>b)std::swap(a,b);
  lo=std::max(lo,a);hi=std::min(hi,b);return lo<=hi;
 };
 return clip(x0,x1-x0,cx*32,cx*32+32)&&clip(y0,y1-y0,cy*32,cy*32+32);
}
int main(){std::mt19937 r(765); for(int n=0;n<100000;++n){
 int x0=int(r()%193)-96,y0=int(r()%193)-96,x1=int(r()%193)-96,y1=int(r()%193)-96;
 int cx=int(r()%8)-4,cy=int(r()%8)-4;
 bool got=terrainSegmentClear(x0,y0,x1,y1,[&](auto x,auto y){return x==cx&&y==cy;});
 bool expected=!intersects(x0,y0,x1,y1,cx,cy);
 if(got!=expected){std::cerr<<x0<<','<<y0<<' '<<x1<<','<<y1<<' '<<cx<<','<<cy<<'\n';return 1;}
 } std::cout<<"100000 segment/closed-cell oracle cases passed\n";}
