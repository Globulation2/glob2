#include "field/TerrainMovementCosts.h"
#include <cassert>
#include <iostream>
int main(){
 for(unsigned sprite=0;sprite<272;++sprite){
  auto type=legacyTerrainType(sprite);const auto&p=terrainProperties(type);
  const bool oldWater=sprite>=256&&sprite<272,oldGrass=sprite<16,oldSand=sprite>=128&&sprite<144,oldShore=sprite>=16&&sprite<=255;
  assert(p.walkable==!oldWater&&p.swimmable==oldWater&&p.buildable==oldGrass);
  assert(terrainProvidesFertility(p)==oldWater&&(p.inhibitionQ8!=0)==oldSand&&p.shoreline==oldShore);
  assert(bool(p.allowedResources&(1u<<1))==oldGrass);
  assert(p.groundSpeedQ8==256&&p.airSpeedQ8==256&&p.flyable&&!p.groundHealthQ8&&!p.airHealthQ8);
  for(unsigned sw=0;sw<7;++sw){auto cost=gradient_kernel::TERRAIN_ENTRY_COSTS[sw][type];unsigned old=oldWater&&sw?gradient_kernel::WATER_STEP[sw]:GRADIENT_STEP;assert(cost.cardinal==old&&cost.diagonal==old*GRADIENT_DIAGONAL_STEP/GRADIENT_STEP);}
 }
 std::cout<<"PASS all 272 legacy sprites: food habitat, inn placement/passability, ecology masks, unchanged movement/health, all seven gradient profiles\n";
}
