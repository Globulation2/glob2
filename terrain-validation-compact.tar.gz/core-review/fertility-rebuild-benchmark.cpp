#include "src/map/FertilityField.h"
#include <algorithm>
#include <cassert>
#include <random>
#include <iostream>
namespace
{
int wrap(int value, int size) { const int r = value % size; return r < 0 ? r + size : r; }

// Four running-box passes produce the triangular kernel in O(width*height).
// Signed 64-bit intermediates cover the largest map and every allowed Q8 value.
// Each line starts with a short fixed-size sum; no per-cell division/modulo is
// needed in the inner loops, including maps smaller than the kernel radius.
template<class T>
std::vector<std::int64_t> triangular(const std::vector<T>& input, int width, int height, int radius)
{
	const int box = radius + 1;
	const std::size_t size = std::size_t(width) * height;
	std::vector<std::int64_t> a(input.begin(), input.end()), b(size);
	for (int axis = 0; axis < 2; ++axis)
		for (int pass = 0; pass < 2; ++pass)
		{
			const int length = axis ? height : width, lines = axis ? width : height;
			const int stride = axis ? width : 1;
			const int begin = pass ? -radius : 0;
			for (int line = 0; line < lines; ++line)
			{
				const std::size_t base = axis ? line : std::size_t(line) * width;
				std::int64_t sum = 0;
				for (int d = 0; d < box; ++d) sum += a[base + wrap(begin+d, length)*stride];
				int remove = wrap(begin, length), add = wrap(begin+box, length);
				for (int p = 0; p < length; ++p)
				{
					b[base + p*stride] = sum;
					sum += a[base + add*stride] - a[base + remove*stride];
					if (++add == length) add = 0;
					if (++remove == length) remove = 0;
				}
			}
			a.swap(b);
		}
	return a;
}
// Only rebuilds need wrapped indexes. Runtime growth reads the cached fields.
// Algae's rotated doubled offset reaches +/-45 relative to a donor/shore cell.
struct WrappedIndexes
{
    int width,height;
    std::vector<int> xs,ys;
    WrappedIndexes(int w,int h):width(w),height(h),xs(91*w),ys(91*h)
    {
        for(int d=-45;d<=45;++d)
        {
            const int bx=d%w,by=d%h;
            for(int x=0;x<w;++x) xs[(d+45)*w+x]=(x+bx+w)%w;
            for(int y=0;y<h;++y) ys[(d+45)*h+y]=(y+by+h)%h;
        }
    }
    int x(int position,int delta) const { return xs[(delta+45)*width+position]; }
    int y(int position,int delta) const { return ys[(delta+45)*height+position]; }
};
constexpr int offsetWeight(int offset) { return 16-(offset<0 ? -offset : offset); }

std::uint32_t q16(std::int64_t value)
{
	return static_cast<std::uint32_t>(std::clamp<std::int64_t>(value, 0, Fertility::kScale));
}
}


namespace Fertility {
void Field::rebuild(int w, int h, const std::vector<std::uint8_t>& water,
	const std::vector<std::uint8_t>& sand, Path path)
{
	std::vector<std::int16_t> contributions(water.size());
	std::vector<std::uint16_t> inhibition(sand.size());
	for (std::size_t i=0; i<water.size(); ++i) contributions[i] = water[i] ? 256 : 0;
	for (std::size_t i=0; i<sand.size(); ++i) inhibition[i] = sand[i] ? 256 : 0;
	rebuildWeighted(w, h, contributions, inhibition, path);
}

void Field::rebuildWeighted(int w, int h, const std::vector<std::int16_t>& contributionQ8,
    const std::vector<std::uint16_t>& inhibitionQ8,Path path)
{
    assert(w>0 && h>0 && contributionQ8.size()==std::size_t(w)*h && inhibitionQ8.size()==contributionQ8.size());
    width=w;height=h;
    waterTiles=std::count_if(contributionQ8.begin(),contributionQ8.end(),[](auto v){return v!=0;});
    sandTiles=std::count_if(inhibitionQ8.begin(),inhibitionQ8.end(),[](auto v){return v!=0;});
    const auto size=contributionQ8.size();
    usedPath=path==Path::Adaptive
        ? (4*std::uint64_t(size)+961*std::uint64_t(sandTiles)<=961*std::uint64_t(waterTiles)
            ? Path::SandCorrection : Path::WaterSplat) : path;
    std::vector<std::int64_t> totals(size,0);
    const WrappedIndexes wrapped(w,h);
    if(usedPath==Path::SandCorrection)
    {
        totals=triangular(contributionQ8,w,h,15);
        for(auto& value:totals)value*=256;
        // A donor and its opposite inhibitor act on the same weighted offset.
        // Iterate only inhibitors; no grid-sized 961-tap scan is needed.
        for(int sy=0;sy<h;++sy)for(int sx=0;sx<w;++sx)
        {
            const int inhibition=std::min<int>(inhibitionQ8[sy*w+sx],256);
            if(!inhibition)continue;
            int targetX[31],donorX[31];
            for(int dx=-15;dx<=15;++dx)
            {targetX[dx+15]=wrapped.x(sx,dx);donorX[dx+15]=wrapped.x(sx,2*dx);}
            for(int dy=-15;dy<=15;++dy)
            {
                auto* target=&totals[wrapped.y(sy,dy)*w];
                const auto* donor=&contributionQ8[wrapped.y(sy,2*dy)*w];
                const std::int64_t scale=inhibition*offsetWeight(dy);
                for(int dx=-15;dx<=15;++dx)
                    target[targetX[dx+15]]-=scale*offsetWeight(dx)*donor[donorX[dx+15]];
            }
        }
    }
    else
    {
        // Sparse donor alternative; signed contributions remain signed until
        // every pair is accumulated, so nearby deficits cancel bonuses exactly.
        for(int sy=0;sy<h;++sy)for(int sx=0;sx<w;++sx)
        {
            const int donor=contributionQ8[sy*w+sx];
            if(!donor)continue;
            int targetX[31],inhibitorX[31];
            for(int dx=-15;dx<=15;++dx)
            {targetX[dx+15]=wrapped.x(sx,-dx);inhibitorX[dx+15]=wrapped.x(sx,-2*dx);}
            for(int dy=-15;dy<=15;++dy)
            {
                auto* target=&totals[wrapped.y(sy,-dy)*w];
                const auto* inhibitors=&inhibitionQ8[wrapped.y(sy,-2*dy)*w];
                const std::int64_t scale=donor*offsetWeight(dy);
                for(int dx=-15;dx<=15;++dx)
                    target[targetX[dx+15]]+=scale*offsetWeight(dx)*(256-std::min<int>(inhibitors[inhibitorX[dx+15]],256));
            }
        }
    }
    fertility.resize(size);
    for(std::size_t i=0;i<size;++i)fertility[i]=q16(totals[i]/(256*256));
}

std::vector<std::uint32_t> shoreGrowthField(int w,int h,
    const std::vector<std::int16_t>& contributionQ8,const std::vector<std::uint16_t>& supportQ8)
{
    const auto size=contributionQ8.size();
    assert(w>0 && h>0 && size==std::size_t(w)*h && supportQ8.size()==size);
    const auto donors=std::count_if(contributionQ8.begin(),contributionQ8.end(),[](auto v){return v!=0;});
    const auto shores=std::count_if(supportQ8.begin(),supportQ8.end(),[](auto v){return v!=0;});
    std::vector<std::uint32_t> result(size,0);
    if(!donors || !shores)return result;
    std::vector<std::int64_t> totals(size,0);
    const WrappedIndexes wrapped(w,h);
    if(shores<=donors)
    {
        // Shore at (x+2dy,y+2dx), donor at (x+dx,y+dy). Invert the
        // former relation to stamp only from nonzero support cells.
        for(int sy=0;sy<h;++sy)for(int sx=0;sx<w;++sx)
        {
            const int support=supportQ8[sy*w+sx];
            if(!support)continue;
            int targetX[31];
            for(int dy=-15;dy<=15;++dy)targetX[dy+15]=wrapped.x(sx,-2*dy);
            for(int dx=-15;dx<=15;++dx)
            {
                auto* target=&totals[wrapped.y(sy,-2*dx)*w];
                const std::int64_t scale=support*offsetWeight(dx);
                for(int dy=-15;dy<=15;++dy)
                    target[targetX[dy+15]]+=scale*offsetWeight(dy)*
                        contributionQ8[wrapped.y(sy,dy-2*dx)*w+wrapped.x(sx,dx-2*dy)];
            }
        }
    }
    else
    {
        for(int sy=0;sy<h;++sy)for(int sx=0;sx<w;++sx)
        {
            const int donor=contributionQ8[sy*w+sx];
            if(!donor)continue;
            int targetX[31];
            for(int dx=-15;dx<=15;++dx)targetX[dx+15]=wrapped.x(sx,-dx);
            for(int dy=-15;dy<=15;++dy)
            {
                auto* target=&totals[wrapped.y(sy,-dy)*w];
                const std::int64_t scale=donor*offsetWeight(dy);
                for(int dx=-15;dx<=15;++dx)
                    target[targetX[dx+15]]+=scale*offsetWeight(dx)*
                        supportQ8[wrapped.y(sy,2*dx-dy)*w+wrapped.x(sx,2*dy-dx)];
            }
        }
    }
    for(std::size_t i=0;i<size;++i)result[i]=q16(totals[i]/(256*256));
    return result;
}

void Field::multiplyLocal(const std::vector<std::uint16_t>& growthQ8)
{
	assert(growthQ8.size()==fertility.size());
	for (std::size_t i=0; i<fertility.size(); ++i)
		fertility[i]=static_cast<std::uint32_t>(std::uint64_t(fertility[i])*growthQ8[i]/256);
}


}

#include <chrono>
int main(){using Clock=std::chrono::steady_clock;for(int side:{128,256,512})for(int overlap:{0,1}){std::vector<int16_t> donors(side*side);std::vector<uint16_t> blockers(side*side),shore(side*side);for(int i=0;i<side*side;++i){donors[i]=(overlap||i%2)?256:0;blockers[i]=shore[i]=(overlap||!(i%2))?256:0;}auto start=Clock::now();Fertility::Field field;field.rebuildWeighted(side,side,donors,blockers);auto middle=Clock::now();auto aquatic=Fertility::shoreGrowthField(side,side,donors,shore);auto end=Clock::now();std::cout<<side<<","<<overlap<<","<<std::chrono::duration<double,std::milli>(middle-start).count()<<","<<std::chrono::duration<double,std::milli>(end-middle).count()<<"\n";}}