import gzip,json,re,struct
from pathlib import Path
root=Path.cwd()
def inspect(path):
 data=gzip.decompress(path.read_bytes());n=struct.unpack_from('>I',data)[0];minor=struct.unpack_from('>I',data,8+n)[0]
 start=data.index(b'GaBe');tick=struct.unpack_from('>I',data,start+4)[0];assert data[start+8:start+12]==b'GaBt'
 pos=start+12+20
 def read(fmt):
  nonlocal pos
  v=struct.unpack_from('>'+fmt,data,pos);pos+=struct.calcsize('>'+fmt);return v[0] if len(v)==1 else v
 def fields(names,fmt='i'):return {name:read(fmt) for name in names.split()}
 units=[];buildings=[]
 for slot in range(1024):
  used=read('I');assert used in (0,1)
  if not used:continue
  u=fields('typeNum');u['gid']=read('H');assert u['gid']==slot
  u.update(fields('scriptIdentity isDead diagnosticDeathCause posX posY delta dx dy direction insideTimeout speed'))
  if minor>=134:u['healthRemainder']=read('i')
  u.update(fields('needToRecheckMedical medical activity displacement movement action targetX targetY validTarget magicActionTimeout'))
  u['underAttackTimer']=read('B');u.update(fields('hp trigHP hungry hungriness trigHungry fruitMask fruitCount'))
  u['abilities']=[read('III') for _ in range(17)]
  u.update(fields('experience experienceLevel destinationPurpose carriedResource jobTimer'))
  claim=read('B');assert claim in (0,1)
  if claim:read('II')
  read('I');units.append(u)
 for slot in range(1024):
  used=read('I');assert used in (0,1)
  if not used:continue
  b=fields('state constructionResult');b['gid']=read('H');assert b['gid']==slot
  b.update(fields('scriptIdentity posX posY'));b.update(fields('underAttackTimer canNotConvertTimer','B'))
  b.update(fields('priority priorityLocal unitStayRange'));b['clearing']=[read('i') for _ in range(5)];b['minLevel']=read('i');b['resources']=[read('i') for _ in range(15)]
  b.update(fields('hp productionTimeout totalRatio'));b['ratios']=[read('ii') for _ in range(3)]
  b.update(fields('receiveMask sendMask shootingStep shootingCooldown bullets typeNum seenByMask'));buildings.append(b)
 for u in units:u.update(fields('attachedBuilding targetBuilding ownExchangeBuilding','H'))
 for b in buildings:
  b['maxInside']=read('i');count=read('I');assert count<=1024;b['workers']=[read('H') for _ in range(count)]
  b.update(fields('subscriptionTimer maxWorking maxWorkingPreferred maxWorkingPrevious maxWorkingFuture'))
  b['workerFailures']=[read('I') for _ in range(8)]
  count=read('I');assert count<=1024;b['inside']=[read('H') for _ in range(count)]
  count=read('I');assert count<=1024;b['harvesting']=[read('H') for _ in range(count)]
  b.update(fields('desiredWorking oldPriority'));b.update(fields('callList inCanFeed inCanHeal','B'));b['inUpgrade']=[read('B') for _ in range(17)];b['wished']=[read('i') for _ in range(15)]
 for b in buildings:
  assert 0<=b['posX']<128 and 0<=b['posY']<128 and b['inCanFeed'] in (0,1,2)
  assert all(0<=n<=1024 for n in [b['maxInside'],b['desiredWorking']])
 return {'tick':tick,'minor':minor,'units':units,'buildings':buildings,'team0ConsumedOffset':pos}
if __name__=='__main__':
 p=root/'artifacts/terrain-refactor/ecology/full-games/maxima-investigation'
 for variant in ('baseline','candidate'):
  for t in (16384,24576,32768):
   file=p/variant/f'checkpoint-{t}.game.gz';file=file if file.exists() else p/variant/'final.game.gz'
   result=inspect(file);(p/variant/f'snapshot-{t}.json').write_text(json.dumps(result,indent=2));print(variant,t,'units',len(result['units']),'buildings',len(result['buildings']))
