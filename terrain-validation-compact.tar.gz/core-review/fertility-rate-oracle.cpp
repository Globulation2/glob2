#include "src/map/FertilityField.h"
#include <cassert>
#include <iostream>
int main(){unsigned checked=0;
 for(const uint32_t rate:{0u,1u,2u,Fertility::kScale,Fertility::kRateScale-1,Fertility::kRateScale+1,4*Fertility::kRateScale-1,4*Fertility::kRateScale}){
  uint64_t first=0,last=0;
  for(uint32_t residue=0;residue<Fertility::kRateScale;++residue){
   first+=Fertility::growthOpportunities(rate,[=]{return residue;});
   last+=Fertility::growthOpportunities(rate,[=]{return Fertility::kRateDrawLimit-Fertility::kRateScale+residue;});
   checked+=2;
  }
  assert(first==rate&&last==rate);
 }
 std::cout<<checked<<" rational-rate bucket samples preserve exact probability mass\n";
}
