import concurrent.futures,json,os,subprocess,time
from pathlib import Path
root=Path.cwd()
def run(variant):
 src=root/f'artifacts/terrain-refactor/ecology/full-games/{variant}/canals-2857-seed-19'
 out=root/f'artifacts/terrain-refactor/ecology/full-games/maxima-investigation/{variant}'
 out.mkdir(parents=True,exist_ok=False)
 cmd=json.loads((src/'command.json').read_text())
 cmd[cmd.index('--ticks')+1]='32768';cmd[cmd.index('--output-dir')+1]=str(out)
 cmd+=['--telemetry','maxima','--save','every:8192','--save','final']
 env=os.environ.copy();env['LD_LIBRARY_PATH']='/tmp/glob2-terrain-sdl-patched/prefix/lib'
 cmd=['taskset','-c','0-5' if variant=='baseline' else '6-11']+cmd
 (out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 cwd=root if variant=='candidate' else Path('/tmp/glob2-terrain-baseline-934c3c588')
 with (out/'run.log').open('w') as log:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=480)
 print(variant,r.returncode,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,['baseline','candidate']))
