"""Lightweight mocked orchestration checks: never launches a process/governor."""
import importlib.util
import json
from pathlib import Path
import signal
import sys
import tempfile
from unittest.mock import patch

path=Path(__file__).with_name('run_v3_timing.py')
spec=importlib.util.spec_from_file_location('timing',path)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
wrapper=m
m=wrapper.configure()

for campaign,mode in [(c,m) for c in ('v3-priority','v3-regressions') for m in ('success','child-failure','unrestored','launch-interrupt')]:
    with tempfile.TemporaryDirectory() as tmp:
        output=Path(tmp)/'fresh'
        class Child:
            signals=[]
            def poll(self): return None
            def send_signal(self,s): self.signals.append(s)
            def wait(self,**kwargs): return 1 if mode=='child-failure' else 0
        child=Child()
        def launch(command,**kwargs):
            if mode=='launch-interrupt': signal.getsignal(signal.SIGINT)(signal.SIGINT,None)
            (output/campaign).mkdir()
            (output/(campaign+'-governors.json')).write_text(json.dumps({'restored':mode!='unrestored'}))
            (output/campaign/'input-verification.json').write_text(json.dumps({'state':'verified','inputs_unchanged':True}))
            (output/campaign/'summary.json').write_text(json.dumps({'scenarios':{str(i):{} for i in range(2 if campaign=='v3-priority' else 3)}}))
            return child
        previous=signal.getsignal(signal.SIGINT)
        with patch.object(sys,'argv',[str(path),'--output',str(output),'--run','--campaign',campaign]),patch.object(m,'input_snapshot',return_value={}),patch.object(m.subprocess,'Popen',side_effect=launch):
            try: result=m.main()
            except RuntimeError:
                assert mode!='success'
            else:
                assert mode=='success' and result==0
        state=json.loads((output/'campaign-state.json').read_text())
        assert state['status']==('complete' if mode=='success' else 'failed')
        assert signal.getsignal(signal.SIGINT)==previous
        if mode=='launch-interrupt': assert child.signals==[signal.SIGINT]
        print('PASS',campaign,mode)
print('All mocked checks passed; no engine, governor or subprocess executed.')

# Integrity checks use real small frozen metadata but mock all large-file hashing,
# library discovery and fixture reads. No ldd or subprocess is run.
prior=json.loads((m.BASE/'priority-timing/paired-01/metadata.json').read_text())
catalogs={str(Path(k).relative_to('data')):v for k,v in prior['data_roots']['baseline']['files'].items()}
provenance=json.loads((m.ROOTS['reuse-v3']/'provenance.json').read_text())
libraries=provenance['runtime_libraries']['sha256']
real_digest=m.benchmark.digest
for problem in ('none','binary','catalog','library','patch','asset'):
    def digest(p):
        p=Path(p)
        if p in m.BINS.values():
            arm=next(k for k,v in m.BINS.items() if p==v)
            return 'changed' if problem=='binary' and arm=='reuse-v3' else m.HASHES[arm]
        if p==m.ROOTS['reuse-v3']/'source.patch' and problem=='patch':return 'changed'
        return real_digest(p)
    def data(root):
        rows=dict(catalogs)
        if root==m.ROOTS['reuse-v3']:
            if problem=='catalog':rows['new-definition.json']='changed'
            if problem=='asset':rows['gfx/new.png']='changed'
        return rows
    def runtime(binary):
        rows=dict(libraries)
        if problem=='library' and binary==m.BINS['reuse-v3']:rows['new-library']='changed'
        return {'sha256':rows}
    with patch.object(m.benchmark,'digest',side_effect=digest),patch.object(m,'data_hashes',side_effect=data),patch.object(m.benchmark,'runtime_libraries',side_effect=runtime),patch.object(m,'validate_manifest',return_value={'scenarios':[]}):
        try: m.input_snapshot({'v3-priority'})
        except RuntimeError: assert problem!='none'
        else: assert problem=='none'
    print('PASS integrity',problem)
assert m.DEFAULT_CAMPAIGNS==('v3-priority','v3-regressions')
plan=m.commands(Path('/nonexistent'),{'v3-priority','v3-legacy','v3-eight-team','v3-custom'})
assert [r['scenario_count'] for r in plan]==[2,98,3,6]
assert [r['measured_pairs'] for r in plan]==[16,8,8,8]
for row in plan:
    assert str(m.BINS['merged']) in row['command'] and str(m.BINS['reuse-v3']) in row['command']
    assert str(m.ROOTS['reuse-v3']) in row['command']
print('PASS optional candidate inventory/default preservation')

for mode in ('prelaunch-interrupt','between-campaign-integrity'):
    with tempfile.TemporaryDirectory() as tmp:
        output=Path(tmp)/'fresh'
        captures=0
        def snapshot(selected):
            global captures
            captures+=1
            if captures==2:
                if mode=='prelaunch-interrupt':signal.getsignal(signal.SIGINT)(signal.SIGINT,None)
                else:return {'changed':True}
            return {}
        previous=signal.getsignal(signal.SIGINT)
        with patch.object(sys,'argv',[str(path),'--output',str(output),'--run','--campaign','v3-priority']),patch.object(m,'input_snapshot',side_effect=snapshot),patch.object(m.subprocess,'Popen') as launch:
            try:m.main()
            except (RuntimeError,InterruptedError):pass
            else:raise AssertionError('Prelaunch failure must stop')
            launch.assert_not_called()
        assert signal.getsignal(signal.SIGINT)==previous
        assert json.loads((output/'campaign-state.json').read_text())['status']=='failed'
        print('PASS',mode,'no child launched')


for mode in ('missing','invalid','pending'):
    with tempfile.TemporaryDirectory() as temp:
        p=Path(temp)/'pins.json'
        if mode!='missing':p.write_text(json.dumps({'status':'pending'} if mode=='pending' else {'status':'frozen','binary_sha256':'bad','source_tree_sha256':'0'*64,'patch_sha256':'0'*64}))
        with patch.object(wrapper,'PINS_PATH',p):
            try:wrapper.configure()
            except (RuntimeError,FileNotFoundError):pass
            else:raise AssertionError('invalid pins accepted')
    print('PASS frozen pins',mode)

real_read=Path.read_text
for field in ('source','patch','binary'):
    def read_mutated(p,*args,**kwargs):
        text=real_read(p,*args,**kwargs)
        if p==m.ROOTS['reuse-v3']/'provenance.json':
            value=json.loads(text)
            if field=='source':value['source']['sourceTreeSha256']='0'*64
            elif field=='patch':value['patch_sha256']='0'*64
            else:value['binary_sha256']='0'*64
            return json.dumps(value)
        return text
    with patch.object(Path,'read_text',read_mutated),patch.object(m.benchmark,'digest',side_effect=lambda p: m.HASHES[next(k for k,v in m.BINS.items() if Path(p)==v)] if Path(p) in m.BINS.values() else real_digest(p)),patch.object(m,'data_hashes',return_value=dict(catalogs)),patch.object(m.benchmark,'runtime_libraries',return_value={'sha256':dict(libraries)}),patch.object(m,'validate_manifest',return_value={'scenarios':[]}):
        try:m.input_snapshot({'v3-priority'})
        except RuntimeError:pass
        else:raise AssertionError('provenance mismatch accepted')
    print('PASS provenance',field)
print('All v3 mocked checks passed; no engines/governors/subprocesses executed.')

with tempfile.TemporaryDirectory() as temp:
    output=Path(temp)/'fresh'
    class Finished:
        def wait(self,**kwargs):return 0
        def poll(self):return 0
    def launch_after_change(command,**kwargs):
        d=output/'v3-priority';d.mkdir()
        (output/'v3-priority-governors.json').write_text(json.dumps({'restored':True}))
        (d/'input-verification.json').write_text(json.dumps({'state':'verified','inputs_unchanged':True}))
        (d/'summary.json').write_text(json.dumps({'scenarios':{'a':{},'b':{}}}))
        return Finished()
    with patch.object(sys,'argv',[str(path),'--output',str(output),'--run','--campaign','v3-priority']),patch.object(m,'input_snapshot',side_effect=[{}, {}, {'changed':True}]),patch.object(m.subprocess,'Popen',side_effect=launch_after_change):
        try:m.main()
        except RuntimeError:pass
        else:raise AssertionError('Post-run mutation accepted')
    assert json.loads((output/'campaign-state.json').read_text())['status']=='failed'
    assert json.loads((output/'inputs-after.json').read_text())=={'changed':True}
print('PASS post-run input mutation retained and rejected')
