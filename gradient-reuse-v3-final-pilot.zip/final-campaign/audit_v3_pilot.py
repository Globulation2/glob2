#!/usr/bin/env python3
"""Post-reservation audit only: this performs bootstrap work and must not run during timing."""
import argparse
import json
import math
from pathlib import Path
import statistics
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[2] / 'test'))
import benchmark_resource_refactor as benchmark

METRICS = ('simulation_cpu_s', 'simulation_wall_s', 'cpu_s', 'wall_s', 'peak_rss_bytes')
RESERVED = set(range(8)) | set(range(16, 24))
OUTSIDE = set(range(32)) - RESERVED
BINARY_HASHES = {
    'merged': '77fb4b9d29432cdfea08734b4eb0b0d3eb7c354862fdc9820ba01c89a76333b6',
    'reuse-v3': '60e9eb2ea259abc6b869b97960c18aed3fa92f7c6be64161b6f50537344b4760',
}
CAMPAIGNS = {
    'v3-priority': ('../priority-recovery/priority-windows.json', 2, 16),
    'v3-regressions': ('v3-regression-pilot-windows.json', 3, 16),
}
PINNED_SOURCE = 'c48e156bc220359587121b7c6e74afe8d7e12b0cb4e159500dfa3cb78527ec14'
PINNED_PATCH = 'ef343f58277ab585033f2dbf52554ec1e80ff6171dd3254ce21dff320f89f041'



def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def read(path):
    return json.loads(path.read_text())


def activity(rows):
    evidence = []
    for row in rows:
        a = row['host_cpu_activity']
        require(a['status'] == 'available', 'Missing host CPU activity')
        sums = {name: sum(a['per_cpu_busy_s'][f'cpu{i}'] for i in cpus)
                for name, cpus in [('reserved', RESERVED), ('outside', OUTSIDE), ('siblings', set(range(16, 24)))]}
        evidence.append(dict(scenario=row['scenario'], repeat=row['repeat'], variant=row['variant'],
                             snapshot_elapsed_s=a['snapshot_elapsed_s'], child_cpu_s=row['cpu_s'],
                             reserved_residual_cpu_s=sums['reserved'] - row['cpu_s'],
                             **{name + '_cpu_s': value for name, value in sums.items()}))

    def stats(items):
        elapsed = sum(r['snapshot_elapsed_s'] for r in items)
        require(elapsed > 0, 'Empty CPU activity interval')
        return dict(rows=len(items), snapshot_elapsed_s=elapsed, **{
            key: dict(total_s=sum(r[key] for r in items),
                      weighted_average_cores=sum(r[key] for r in items) / elapsed,
                      min_average_cores=min(r[key] / r['snapshot_elapsed_s'] for r in items),
                      max_average_cores=max(r[key] / r['snapshot_elapsed_s'] for r in items))
            for key in ('reserved_cpu_s', 'reserved_residual_cpu_s', 'outside_cpu_s', 'siblings_cpu_s')})

    measured = [r for r in evidence if r['repeat'] >= 0]
    return dict(rows=evidence, all=stats(evidence), measured=stats(measured),
                by_variant={v: stats([r for r in measured if r['variant'] == v]) for v in ('baseline', 'candidate')})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', choices=CAMPAIGNS, required=True)
    parser.add_argument('--after-timing-release', action='store_true', required=True,
                        help='Coordinator has released timing; no benchmark workload may overlap this audit')
    parser.add_argument('--output', required=True, type=Path, help='Exact two-campaign pilot output; sibling -cpuset.json is required')
    args = parser.parse_args()
    manifest_name, count, repeats = CAMPAIGNS[args.campaign]
    base = args.output.resolve()
    manifest = read(HERE / manifest_name)
    scenarios = manifest['scenarios']
    require(len(scenarios) == count, 'Wrong manifest scenario count')
    rows = [json.loads(line) for line in (base / args.campaign / 'measurements.jsonl').read_text().splitlines()]
    require(len(rows) == count * (2 * (repeats + 1)), 'Incomplete/extra engine rows')
    require(len({(r['scenario'], r['repeat'], r['variant']) for r in rows}) == len(rows), 'Duplicate row identities')
    expected_order = [(s['id'], i, v) for s in scenarios for i in range(-1, repeats)
                      for v in (['baseline', 'candidate'] if i % 2 else ['candidate', 'baseline'])]
    require([(r['scenario'], r['repeat'], r['variant']) for r in rows] == expected_order,
            'Wrong scenario/repeat/alternating order')
    summary = read(base / args.campaign / 'summary.json')
    require(set(summary['scenarios']) == {s['id'] for s in scenarios}, 'Summary inventory differs')
    pairs, checksums, windows = {}, {}, {}
    for scenario in scenarios:
        name = scenario['id']
        target = int(scenario['args'][scenario['args'].index('--ticks') + 1])
        expected_ticks = target - scenario['start_tick']
        require(expected_ticks > 0, 'Empty manifest window')
        selected = [r for r in rows if r['scenario'] == name]
        require(len(selected) == 2 * (repeats + 1), f'Incomplete scenario {name}')
        for row in selected:
            result = row['result']
            binary_folder = 'merged-reference' if row['variant'] == 'baseline' else 'candidate-gradient-reuse-v3'
            expected_command = [str(HERE.parent / binary_folder / 'glob2'), '--run-game', *scenario['args'],
                                '--benchmark-warmup', '0', '--output-dir',
                                str(base / args.campaign / name / str(row['repeat']) / row['variant'])]
            require(row['command'] == expected_command, f'Executed arguments differ from manifest: {name}')
            require(result.get('status') == 'completed' and result.get('ticks') == target
                    and result.get('benchmark_measured_ticks') == expected_ticks,
                    f'Short/error window {name}/{row["repeat"]}/{row["variant"]}')
            require(all(math.isfinite(row[m]) and row[m] > 0 for m in METRICS), 'Invalid measurement')
        all_pairs = [{r['variant']: r for r in selected if r['repeat'] == i} for i in range(-1, repeats)]
        for pair in all_pairs:
            require(pair['baseline']['result']['initialChecksum'] == pair['candidate']['result']['initialChecksum'],
                    f'Initial checksum mismatch {name}')
            require(pair['baseline']['result']['finalChecksum'] == pair['candidate']['result']['finalChecksum'],
                    f'Final checksum mismatch {name}')
        for checksum in ('initialChecksum', 'finalChecksum'):
            require(all(type(r['result'][checksum]) is int and 0 <= r['result'][checksum] <= 0xffffffff
                        for r in selected), f'Missing/invalid checksum {name}/{checksum}')
            require(len({r['result'][checksum] for r in selected}) == 1, f'Repeat checksum differs {name}/{checksum}')
        checksums[name] = dict(initial=selected[0]['result']['initialChecksum'], final=selected[0]['result']['finalChecksum'])
        windows[name] = dict(start=scenario['start_tick'], end=target, measured_ticks=expected_ticks)
        pairs[name] = all_pairs[1:]
        for metric in METRICS:
            reported = summary['scenarios'][name][metric]
            logs = [math.log(pair['candidate'][metric] / pair['baseline'][metric]) for pair in pairs[name]]
            require(math.isclose(math.exp(statistics.mean(logs)), reported['ratio'], rel_tol=1e-14)
                    and benchmark.interval(logs) == reported['ci95'], f'Ratio/CI mismatch {name}/{metric}')
            for variant in ('baseline', 'candidate'):
                require(statistics.median(pair[variant][metric] for pair in pairs[name]) == reported[variant + '_median'],
                        f'Median mismatch {name}/{metric}/{variant}')
    aggregate = benchmark.aggregate_interval([
        [math.log(pair['candidate']['simulation_cpu_s'] / pair['baseline']['simulation_cpu_s']) for pair in samples]
        for samples in pairs.values()])
    require(aggregate == summary['aggregate_cpu'], 'Aggregate ratio/CI mismatch')
    before, after = read(base / 'inputs-before.json'), read(base / 'inputs-after.json')
    require(before == after, 'Frozen input snapshots differ')
    require(before['binaries'] == BINARY_HASHES, 'Wrong frozen merged/candidate identities')
    pins = before['v3_pins']
    require(pins['status'] == 'frozen' and pins['binary_sha256'] == BINARY_HASHES['reuse-v3']
            and pins['source_tree_sha256'] == PINNED_SOURCE and pins['patch_sha256'] == PINNED_PATCH,
            'Wrong frozen v3 source/patch/binary identity')
    expected_bindings = {str(HERE/'run_v3_timing.py'), str(HERE/'v3-frozen-pins.json')} | {
        str(HERE.parent/'candidate-gradient-reuse-v3'/name)
        for name in ('provenance.json','source.patch','data-freeze.json')}
    require(set(before['v3_binding']) == expected_bindings and all(isinstance(v,str) and len(v)==64
            and all(c in '0123456789abcdef' for c in v) for v in before['v3_binding'].values()),
            'Incomplete v3 input bindings')
    require(before['manifests'][args.campaign]['manifest'] == manifest, 'Audited manifest differs from timing manifest')
    verification = read(base / args.campaign / 'input-verification.json')
    require(verification['state'] == 'verified' and verification['inputs_unchanged']
            and verification['before'] == verification['after'] and not verification.get('changed_inputs')
            and not verification.get('campaign_error'), 'Runner input verification failed')
    metadata = read(base / args.campaign / 'metadata.json')
    require(metadata['manifest'] == manifest and metadata['repeats'] == repeats and metadata['affinity'] == list(range(8)),
            'Wrong metadata manifest/repeat/CPU protocol')
    for key, value in verification['before'].items():
        require(value == metadata['manifest_input' if key == 'manifest' else key], f'Metadata/input audit differs: {key}')
    for role, arm, argument, folder in [('baseline', 'merged', 'before', 'merged-reference'),
                                      ('candidate', 'reuse-v3', 'after', 'candidate-gradient-reuse-v3')]:
        expected = str(HERE.parent / folder / 'glob2')
        require(metadata['binaries'][role] == {'path': expected, 'sha256': BINARY_HASHES[arm]}
                and metadata['arguments'][argument] == expected, f'Wrong metadata binary role: {role}')
        require(all(r['command'][0] == expected for r in rows if r['variant'] == role),
                f'Wrong executed binary role: {role}')
    state = read(base / 'campaign-state.json')
    require(state['status'] == 'complete' and state['completed'] == ['v3-priority', 'v3-regressions'], 'Orchestrator incomplete')
    governor = read(base / (args.campaign + '-governors.json'))
    require(governor['state'] == 'completed' and governor['exit_code'] == 0 and governor['dry_run'] is False
            and governor['selected_cpus'] == list(range(8)) and governor['restored']
            and not governor.get('restoration_errors') and not governor.get('child_cleanup_error'),
            'Governor execution/cleanup failed')
    policies = {f'/sys/devices/system/cpu/cpufreq/policy{i}' for i in range(8)}
    require(set(governor['original_governors']) == policies, 'Wrong governor policy scope')
    for phase in ('before', 'stabilized', 'before_restore', 'after_restore'):
        require(set(governor[phase]) == policies, f'Incomplete governor snapshot: {phase}')
    for policy, original in governor['original_governors'].items():
        require(governor['before'][policy]['scaling_governor'] == original
                and governor['after_restore'][policy]['scaling_governor'] == original
                and governor['stabilized'][policy]['scaling_governor'] == 'performance'
                and governor['before_restore'][policy]['scaling_governor'] == 'performance',
                f'Governor stabilization/restoration mismatch: {policy}')
    cpuset = read(base.with_name(base.name + '-cpuset.json'))
    require(cpuset['state'] == 'completed' and cpuset['exit_code'] == 0 and cpuset['cgroup_restored']
            and cpuset['wrapper_affinity_restored'] and not cpuset['forced_cgroup_kill']
            and cpuset['dry_run'] is False and cpuset['validity_checks'] > 0
            and cpuset['original_affinity'] == cpuset['final_wrapper_affinity'], 'Cpuset cleanup failed')
    require(not Path(cpuset['cgroup_path']).exists(), 'Owned cgroup still exists')
    require(cpuset['child_identity']['affinity'] == list(range(8)), 'Wrong engine allocation')
    for label in ('partition_before_command', 'last_partition_check', 'partition_after_command'):
        require(cpuset[label]['cpuset.cpus.partition'] == 'root'
                and all(cpuset[label][key] == '0-7,16-23' for key in
                        ('cpuset.cpus', 'cpuset.cpus.effective', 'cpuset.cpus.exclusive', 'cpuset.cpus.exclusive.effective')),
                'Invalid partition allocation')
    # Rank every observed slowdown; no arbitrary old threshold decides acceptance.
    slowdowns = {}
    for metric in METRICS:
        slowdowns[metric] = sorted([
            dict(scenario=name, **values[metric], ci_excludes_no_change=values[metric]['ci95'][0] > 1,
                 explanation_status='Unexplained observational result; representative review required')
            for name, values in summary['scenarios'].items() if values[metric]['ratio'] > 1],
            key=lambda r: r['ratio'], reverse=True)
    report = dict(status='verified', campaign=args.campaign, scenarios=count, engine_runs=len(rows),
                  measured_runs=count * 2 * repeats, measured_pairs=count * repeats, warmup_runs=count * 2,
                  summary_recomputed_exactly=True, input_snapshots_equal=True, all_initial_final_checksums_equal=True,
                  windows=windows, checksums=checksums, summary=summary, slowdowns=slowdowns,
                  activity=activity(rows), partition_checks=cpuset['validity_checks'],
                  governors_restored=True, cpuset_restored=True,
                  limits='Final checksums are not full per-tick traces. Bootstrap intervals are per-window and unadjusted '
                         'for multiple comparisons; slowdown lists guide investigation, not automatic rejection. '
                         'Simulation CPU excludes setup/requested save but includes finishSession/drain; whole-child '
                         'CPU includes setup/exit. Reserved residual subtracts whole-child CPU, includes wrappers/kernel '
                         'and coarse-jiffy/boundary skew; outside activity is expected under exclusive allocation. '
                         'Parent complementary allocation is checked by the live wrapper on every validity pass but is not '
                         'retained in child snapshots, so it cannot be independently recomputed here. '
                         'Shared power/thermal/memory/IRQ effects remain possible. Old percentage gates are diagnostic only.')
    (base / args.campaign / 'independent-v3-audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status=report['status'], scenarios=count, runs=len(rows), aggregate_cpu=aggregate,
                         slowdown_counts={m: len(v) for m, v in slowdowns.items()},
                         activity_measured=report['activity']['measured']), indent=2))


if __name__ == '__main__':
    main()
