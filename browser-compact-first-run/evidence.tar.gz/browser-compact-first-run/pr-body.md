The compact FPS persistence test starts a fresh touch layout, which shows the hand-preference screen before the main menu. Complete that choice through the real control before checking FPS settings.

Validation: all 9 FPS persistence/text-dispatch cases pass across Chromium, Firefox and WebKit. The original compact case stalled at HandPreferenceScreen. No production changes.

[Commands, CI-artifact provenance and browser results](https://github.com/Globulation2/glob2/tree/evidence/master-ci-recovery-1198/browser-compact-first-run).
