A torus capture can finish its atlas and overlays, then defer the final world submission. Releasing the capture at that point starts another capture on retry and advances tool-preview opacity again. A deterministic one-time world-admission failure reproduces opacity 0.2 instead of 0.1 on OpenGL; concurrent SDL GPU probes also showed repeated advancement.

Retain the completed atlas and frozen capture state until the world submission is admitted. Deferred world work reuses that atlas and skips overlay composition. Explicitly flush the world submission before releasing the capture. Extend the existing GL/SDL retry regression to reject both the final overlay and final world submissions; all animation and checksum assertions remain.

The intended visible effect is stable preview opacity during admission pressure. Simulation, save formats and dependencies are unchanged. The explicit world flush adds a submission boundary before later HUD work; no performance improvement is claimed.

Validation: clean release GL and SDL GPU retry/fatal-fallback cases pass, including the deterministic regression that fails on prior production code. Large captures and concurrent retry stress are running; evidence will be linked before merge. Actual Metal/D3D/browser coverage remains the full master matrix.
