from pathlib import Path
import sys,types,json,concurrent.futures
sys.path.insert(0,str(Path('test').resolve()));import run_tests as registry
build=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
cases=[c for c in registry.list_cases(registry.binary_path(build,'engine'),'engine') if c.suite=='TorusRender' and c.name.startswith('SDL GPU retries a submitted final')];assert len(cases)==1
args=types.SimpleNamespace(keep_profiles=False,fullscreen=True,update_fixtures=False,artifacts=None,verbose=False)
def run(i):
 r=registry.run_job(registry.Job('engine',cases),args,build);(out/f'{i}.log').write_text(r.output);row={'index':i,'status':r.status,'seconds':r.seconds};print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,range(4)))
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
