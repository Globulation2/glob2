// SPDX-License-Identifier: GPL-3.0-or-later
// Real game rendering regression. Run with an isolated GLOB2_USER_DIR and
// either -g (OpenGL) or -G (software). No desktop input is generated.
#include <Environment.h>
#include "EngineFixtures.h"
#include "ScopedEnvironment.h"
#include <vector>
#include <algorithm>
#include <utility>
#include <cstdlib>
#include "GlobalContainer.h"
#include "TorusPicking.h"
#include "TorusGeometry.h"
#include "DynamicClouds.h"
#include <SDL3/SDL.h>
// Expose camera and settings widgets for deterministic integration checks.
#include "TorusView.h"
#include "SettingsScreen.h"
#include "GameGUI.h"
#include "GameGUIInternal.h"
#include "GameGUIViewport.h"
#include "Engine.h"
#include "Utilities.h"
#include "Team.h"
#include "TorusMapFixture.h"
#include "Unit.h"
#include "Player.h"
#include "GameGUIKeyActions.h"
#include "CloudField.h"
#include <RenderDevice.h>
#include <RenderBackend.h>
#include <RendererSelection.h>
#ifdef HAVE_OPENGL
#ifdef __APPLE__
#include <OpenGL/gl.h>
#else
#include <epoxy/gl.h>
#endif
#endif
#include <cmath>
#include <iostream>
#include <fstream>
#include <optional>
#include "render/terrain/TerrainCompositor.h"
#include "render/SoftwareTerrainCache.h"

class TorusRenderIntegrationTest
{
public:
static void tiledCapture(bool hd = false)
{
#ifdef HAVE_OPENGL
    std::optional<glob2test::ScopedEnvironment> hdPath;
    if (hd)
    {
        const auto directory = glob2test::artifactDir() / "synthetic-terrain-hd";
        std::filesystem::create_directories(directory);
        std::filesystem::copy_file(glob2test::sourceRoot() / "test/fixtures/image-assets/terrain-hd-solid.webp",
            directory / "grass.webp", std::filesystem::copy_options::overwrite_existing);
        std::ofstream frames(directory / "frames.txt");
        frames << "GLOB2_HIGHRES 1\n";
        for (int variant = 0; variant < 16; ++variant)
            frames << "terrain" << variant << " 32 32 4 grass.webp -\n";
        frames.close();
        hdPath.emplace("GLOB2_EXPERIMENT_TEXTURE_DIR", directory.string().c_str());
    }
    glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.display = true, .loadStrings = true,
        .width = 1120, .height = 720, .screenFlags = Uint32(GraphicContext::USEGPU)});
    if (hd) Sprite::setHighResolution(true);
    Game game(nullptr);
    makeTorusMapFixture(game, 64, 64);
    REQUIRE(game.addUnit(29, 29, 0, EXPLORER, 0, 128, 1, 1));
    REQUIRE(game.addUnit(63, 63, 0, EXPLORER, 0, 128, 1, 1));
    REQUIRE(game.addBuilding(29, 31, globalContainer->buildingsTypes.getFinishedTypeNum("swarm"), 0));
    game.map.setMapDiscovered();
    for (int y = 0; y < 64; ++y) for (int x = 0; x < 64; ++x)
    {
        const int index = game.map.coordToIndex(x, y);
        const bool unknown = y >= 10 && y < 16;
        const Uint32 visible = unknown || (x >= 30 && x < 32) || (x >= 60 && x < 62) ? 0 : 1;
        game.map.fogOfWarA[index] = game.map.fogOfWarB[index] = visible;
        game.map.mapDiscovered[index] = unknown ? 0 : 1;
    }
    TorusView view;
    view.textureLimit = 1024;
    view.toggle();
    int vx = 17, vy = 21; // Initial capture origin is (0,0), boundaries are at cells 30 and 60.
    const unsigned options = Game::DRAW_AREA;
    REQUIRE(view.draw(glob2test::sceneOf(game),game.gui, 0, options, vx, vy, 960, 720));
    if (hd) REQUIRE(globalContainer->terrainCompositor().scale() == 4);
    REQUIRE(view.tiles.size() == 9);
    REQUIRE(view.pixelsPerCell == 32);
    REQUIRE(view.standaloneRender.animationTime == 1);
    REQUIRE(view.standaloneRender.areaAnimationTick == 1);
    GLint oldViewport[4]; glGetIntegerv(GL_VIEWPORT, oldViewport);
    GLuint reference, framebuffer;
    glGenTextures(1, &reference);
    glBindTexture(GL_TEXTURE_2D, reference);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 2048, 2048, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glGenFramebuffers(1, &framebuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, reference, 0);
    REQUIRE(glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE);
    glViewport(0, 0, 2048, 2048);
    glMatrixMode(GL_PROJECTION); glPushMatrix(); glLoadIdentity(); glOrtho(0, 2048, 2048, 0, -1, 1);
    glMatrixMode(GL_MODELVIEW); glPushMatrix(); glLoadIdentity();
    glUseProgram(0); glDisable(GL_DEPTH_TEST); glDisable(GL_SCISSOR_TEST);
    globalContainer->gfx->setRenderTargetScale(1);
    Game::ViewState baseline;
    baseline.render.animationTime = view.standaloneRender.animationTime;
    baseline.render.areaAnimationTick = 0;
    glob2test::drawMap(game,0, 0, 2048, 2048, 0, 0, view.originX, view.originY, 0,
                 baseline, options | Game::DRAW_NO_CLOUD_LAYER, nullptr, nullptr, true, 128);
    Sprite::flushBatches(globalContainer->gfx);
    std::vector<unsigned char> pixels(2048 * 2048 * 4);
    glReadPixels(0, 0, 2048, 2048, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    int maximumDifference = 0;
    for (const auto &tile : view.tiles)
    {
        std::vector<unsigned char> actual(size_t(tile.textureW) * tile.textureH * 4);
        glBindTexture(GL_TEXTURE_2D, tile.texture);
        glGetTexImage(GL_TEXTURE_2D, 0, GL_RGBA, GL_UNSIGNED_BYTE, actual.data());
        // Compare interiors AND gutters against the full-world renderer. This
        // checks wrap seams and subregion rendering independently of the mesh.
        for (int y = 0; y < tile.textureH; ++y) for (int x = 0; x < tile.textureW; ++x)
        {
            int worldX = (tile.x + x - 32 + 2048) % 2048;
            int worldY = (tile.y + tile.textureH - 1 - y - 32 + 2048) % 2048;
            for (int c = 0; c < 3; ++c)
                maximumDifference = std::max(maximumDifference, std::abs(int(actual[(size_t(y)*tile.textureW+x)*4+c])
                    - int(pixels[(size_t(2047-worldY)*2048+worldX)*4+c])));
        }
    }
    std::cout << "Native tiled capture maximum RGB difference: " << maximumDifference << "/255\n";
    REQUIRE(maximumDifference <= 1);
    glDeleteTextures(1, &reference); glDeleteFramebuffers(1, &framebuffer);
    globalContainer->gfx->setRenderTargetScale(0);
    glMatrixMode(GL_MODELVIEW); glPopMatrix(); glMatrixMode(GL_PROJECTION); glPopMatrix(); glMatrixMode(GL_MODELVIEW);
    glViewport(oldViewport[0], oldViewport[1], oldViewport[2], oldViewport[3]);
    REQUIRE(glGetError() == GL_NO_ERROR);
    REQUIRE(view.draw(glob2test::sceneOf(game),game.gui, 0, options, vx, vy, 960, 720));
    REQUIRE(view.standaloneRender.animationTime == 2);
    REQUIRE(view.standaloneRender.areaAnimationTick == 2);
    view.reset();
    view.allocationPixelLimit = 1500000; // Some native tiles allocate before retrying.
    view.toggle();
    REQUIRE(view.draw(glob2test::sceneOf(game),game.gui, 0, options, vx, vy, 960, 720));
    REQUIRE(view.pixelsPerCell == 16);
    REQUIRE(view.tiles.size() == 4);
    std::vector<GLuint> oldTextures;
    for (const auto &tile : view.tiles) oldTextures.push_back(tile.texture);
    view.reset();
    for (GLuint texture : oldTextures) REQUIRE(glIsTexture(texture) == GL_FALSE);
    view.allocationPixelLimit = 5000;
    view.toggle();
    REQUIRE(view.draw(glob2test::sceneOf(game),game.gui, 0, options, vx, vy, 960, 720));
    REQUIRE(view.pixelsPerCell == 1);
    REQUIRE(view.draw(glob2test::sceneOf(game),game.gui, 0, options, vx, vy, 960, 720));
    REQUIRE(view.pixelsPerCell == 1); // Retain the successful level until reset.
    view.reset();
    view.allocationPixelLimit = 1;
    view.toggle();
    REQUIRE(!view.draw(glob2test::sceneOf(game),game.gui, 0, options, vx, vy, 960, 720));
    REQUIRE(view.tiles.empty());
    REQUIRE(view.framebuffer == 0);
    REQUIRE(!view.active());
    view.reset(); view.allocationPixelLimit = 0;
    view.toggle();
    REQUIRE(view.draw(glob2test::sceneOf(game),game.gui, 0, options, vx, vy, 960, 720));
    REQUIRE(view.pixelsPerCell == 32);
    REQUIRE(glGetError() == GL_NO_ERROR);
    // Preview opacity is frame state too: a region that cannot see the mouse
    // still participates in capture, but must not advance the preview again.
    GameGUI gui;
    gui.init();
    makeTorusMapFixture(gui.game, 64, 64);
    for (int y = 0; y < 64; ++y) for (int x = 0; x < 64; ++x)
        gui.game.map.paintVertexSquare(x, y, GRASS, 1);
    gui.localPlayer = gui.localTeamNo = 0;
    gui.adjustLocalTeam();
    gui.prepareLocalPresentation();
    gui.selectionMode = GameGUI::TOOL_SELECTION;
    gui.toolManager.activateBuildingTool("swarm");
    gui.mouseX = 480; gui.mouseY = 368;
    gui.torusView.textureLimit = 1024;
    gui.torusView.toggle();
    int gx = 17, gy = 21;
    REQUIRE(gui.torusView.draw(glob2test::sceneOf(gui.game),gui.game.gui, 0, Game::DRAW_WHOLE_MAP, gx, gy, 960, 720));
    REQUIRE(gui.torusView.draw(glob2test::sceneOf(gui.game),gui.game.gui, 0, Game::DRAW_WHOLE_MAP, gx, gy, 960, 720));
    REQUIRE(std::abs(gui.toolManager.highlightStrength - .1f) < .00001f);
    REQUIRE(gui.torusView.draw(glob2test::sceneOf(gui.game),gui.game.gui, 0, Game::DRAW_WHOLE_MAP, gx, gy, 960, 720));
    REQUIRE(std::abs(gui.toolManager.highlightStrength - .2f) < .00001f);
    REQUIRE(glGetError() == GL_NO_ERROR);
#endif
}

// Inject one admission failure after the final overlay work has really submitted.
// Region packets carry exact physical scissors; the final overlay does not.
class OverlayAdmissionDevice final : public GAGCore::RenderDevice
{
    std::unique_ptr<GAGCore::RenderDevice> device;
public:
    bool rejected=false;
    bool overlayFailure=true;
    bool completedWorld=false;
    unsigned submissions=0, worldSubmissions=0;
    unsigned admittedSubmissions=0, refusedSubmissions=0;
    std::string lastDeferral;
    mutable bool phaseRejected=false;
    std::function<bool()> phaseFault;
    explicit OverlayAdmissionDevice(std::unique_ptr<GAGCore::RenderDevice> value) : device(std::move(value)) {}
    GAGCore::RenderDeviceCapabilities capabilities() const override {
        if(!phaseRejected && phaseFault && phaseFault()) {
            phaseRejected=true;
            throw std::runtime_error("Injected torus exception after source phase advancement");
        }
        return device->capabilities();
    }
    bool canBeginFrame() override {return device->canBeginFrame();}
    GAGCore::RenderSubmission submit(GAGCore::RenderFrame frame) override {
        ++submissions;
        const bool world=std::any_of(frame.packets.begin(),frame.packets.end(),[](const auto &packet){
            return !packet.target && packet.kind==GAGCore::DrawPacket::Kind::MeshTriangles &&
                packet.material==GAGCore::DrawPacket::Material::WorldLit;
        });
        const bool overlay=overlayFailure && !rejected && std::any_of(frame.packets.begin(),frame.packets.end(),[](const auto &packet){
            return packet.target && packet.target->descriptor.budgetClass==GAGCore::TextureDescriptor::BudgetClass::TerrainPage &&
                !packet.targetScissor && (packet.kind==GAGCore::DrawPacket::Kind::Fill || packet.kind==GAGCore::DrawPacket::Kind::Blit);
        });
        GAGCore::RenderSubmission submitted;
        try { submitted=device->submit(std::move(frame)); }
        catch(const GAGCore::RenderAdmissionDeferred& error) { lastDeferral=error.what(); throw; }
        if(submitted) ++admittedSubmissions;
        else { ++refusedSubmissions; lastDeferral="device returned no submission"; }
        if(overlay && submitted){rejected=true;throw GAGCore::RenderAdmissionDeferred("Injected final torus overlay admission failure");}
        if(world && submitted) { completedWorld=true; ++worldSubmissions; }
        return submitted;
    }
    GAGCore::RenderCompletion completion(GAGCore::RenderSubmission value) override {return device->completion(value);}
    void present() override {device->present();}
    void discardFrame() override {device->discardFrame();}
    void reset() override {device->reset();}
    std::uint64_t generation() const override {return device->generation();}
    GAGCore::RenderTelemetry telemetry() const override {return device->telemetry();}
    void trimRetiredResources() override {device->trimRetiredResources();}
    bool capture(GAGCore::CaptureRequest request) override {return device->capture(std::move(request));}
    bool pollCapture(GAGCore::CaptureResult &result) override {return device->pollCapture(result);}
    SDL_Surface *captureSynchronously(GAGCore::CaptureRequest request) override {return device->captureSynchronously(std::move(request));}
    void cancelCaptures() override {device->cancelCaptures();}
    void outputSize(int &width,int &height) override {device->outputSize(width,height);}
};
static void deviceOverlayRetry(GAGCore::RendererBackend backend)
{
    using namespace GAGCore;
    glob2test::HeadlessGlobals globals({.display=true,.loadStrings=true,.width=960,.height=720,
        .beforeLoad=[backend](GlobalContainer &container){container.settings.rendererBackend=backend;}});
    auto *gfx=globals->gfx;
    if(gfx->backendSwitchStatus().active!=backend){MESSAGE("Backend unavailable: ",gfx->backendSwitchStatus().reason);return;}
    gfx->deviceRenderer.reset();
    auto injected=std::make_unique<OverlayAdmissionDevice>(std::move(gfx->presentationDevice));
    auto *probe=injected.get();gfx->presentationDevice=std::move(injected);
    gfx->deviceRenderer=makeDeviceRenderBackend(*gfx->presentationDevice,*gfx->renderResources(),gfx->getW(),gfx->getH());
    gfx->renderer=gfx->deviceRenderer.get();
    globals->settings.clouds=false;
    GameGUI gui;gui.init();makeTorusMapFixture(gui.game,64,64);
    // The render-only map helper declares a player but does not allocate one.
    // These fixtures verify game checksums, which require the real player.
    gui.game.players[0]=new Player(0,"Renderer fixture",gui.game.teams[0],BasePlayer::P_LOCAL);
    for(int y=0;y<64;++y)for(int x=0;x<64;++x)gui.game.map.paintVertexSquare(x,y,GRASS,1);
    gui.localPlayer=gui.localTeamNo=0;gui.adjustLocalTeam();gui.prepareLocalPresentation();
    gui.mouseX=480;gui.mouseY=368;gui.torusView.textureLimit=1024;gui.torusView.toggle();
    // Picking uses the last completed world mesh. Establish it before asking the
    // tool overlay to emit packets; the first capture cannot pick yet.
    probe->overlayFailure=false;
    gui.selectionMode=GameGUI::NO_SELECTION;
    bool initialized=false;
    for(unsigned attempt=0;attempt<128 && !initialized;++attempt){
        const auto priorWorlds=probe->worldSubmissions;
        int vx=17,vy=21;
        REQUIRE(gui.torusView.draw(gui.drawnScene(),&gui,0,Game::DRAW_WHOLE_MAP|Game::DRAW_AREA,vx,vy,960,720));
        initialized=gfx->flushDeviceFrame() && probe->completedWorld;
        if(initialized) std::cout << "Warm completed: prior worlds=" << priorWorlds << " current worlds=" << probe->worldSubmissions << " attempt=" << attempt << std::endl;
        gfx->nextFrame();SDL_Delay(1);
    }
    REQUIRE(initialized);
    int pickedX=0,pickedY=0;
    REQUIRE(gui.torusView.pick(gui.mouseX,gui.mouseY,pickedX,pickedY));
    probe->overlayFailure=true;
    probe->completedWorld=false;
    gui.selectionMode=GameGUI::TOOL_SELECTION;gui.toolManager.activateBuildingTool("swarm");
    bool complete=false;unsigned holds=0;
    const auto checksum=gui.game.checkSum();
    // Admission is asynchronous: fast polling must not exhaust an iteration
    // budget while the GPU queue drains its bounded capture regions.
    const auto retryDeadline=SDL_GetTicks()+60000;
    for(unsigned attempt=0;!complete && SDL_GetTicks()<retryDeadline;++attempt){
        // Pausing a running multi-turn capture freezes source animation clocks,
        // independently of the capture's immutable initial animation phase.
        gui.gamePaused=attempt==1 || attempt==2;
        const auto animationBefore=gui.view.render.animationTime;
        const auto areaBefore=gui.view.render.areaAnimationTick;
        int vx=17,vy=21;
        REQUIRE(gui.torusView.draw(gui.drawnScene(),&gui,0,Game::DRAW_WHOLE_MAP|Game::DRAW_AREA,vx,vy,960,720));
        REQUIRE(gui.view.render.animationTime==animationBefore+(gui.gamePaused?0:1));
        REQUIRE(gui.view.render.areaAnimationTick==areaBefore+(gui.gamePaused?0:1));
        complete=gfx->flushDeviceFrame() && probe->completedWorld;
        if(!complete)++holds;
        gfx->nextFrame();SDL_Delay(1);
        REQUIRE(gfx->presentationDevice.get()==probe);
        REQUIRE(gfx->backendSwitchStatus().active==backend);
    }
    INFO("submissions=",probe->submissions," admitted=",probe->admittedSubmissions," refused=",probe->refusedSubmissions,
        " worlds=",probe->worldSubmissions," holds=",holds," deferral=",probe->lastDeferral,
        " logical bytes=",gfx->renderResources()->retainedBytes()," device bytes=",probe->telemetry().resourceBytes);
    REQUIRE(probe->rejected);REQUIRE(complete);REQUIRE(holds>1);
    std::cout << "Torus overlay recovery: holds=" << holds << " admitted=" << probe->admittedSubmissions
        << " refused=" << probe->refusedSubmissions << " world submissions=" << probe->worldSubmissions << '\n';
    REQUIRE(gui.game.checkSum()==checksum);
    INFO("actual highlight strength=",gui.toolManager.highlightStrength);
    REQUIRE(std::abs(gui.toolManager.highlightStrength-.1f)<.00001f);
}

static void devicePhaseFallback(GAGCore::RendererBackend backend)
{
    using namespace GAGCore;
    glob2test::HeadlessGlobals globals({.display=true,.loadStrings=true,.width=640,.height=480,
        .beforeLoad=[backend](GlobalContainer &container){container.settings.rendererBackend=backend;}});
    auto *gfx=globals->gfx;
    if(gfx->backendSwitchStatus().active!=backend){MESSAGE("Backend unavailable: ",gfx->backendSwitchStatus().reason);return;}
    gfx->deviceRenderer.reset();
    auto injected=std::make_unique<OverlayAdmissionDevice>(std::move(gfx->presentationDevice));
    auto *probe=injected.get();probe->overlayFailure=false;
    gfx->presentationDevice=std::move(injected);
    gfx->deviceRenderer=makeDeviceRenderBackend(*gfx->presentationDevice,*gfx->renderResources(),gfx->getW(),gfx->getH());
    gfx->renderer=gfx->deviceRenderer.get();
    globals->settings.clouds=false;
    GameGUI gui;gui.init();makeTorusMapFixture(gui.game,64,64);
    // The render-only map helper declares a player but does not allocate one.
    // These fixtures verify game checksums, which require the real player.
    gui.game.players[0]=new Player(0,"Renderer fixture",gui.game.teams[0],BasePlayer::P_LOCAL);
    gui.localPlayer=gui.localTeamNo=0;gui.adjustLocalTeam();gui.prepareLocalPresentation();
    gui.torusView.textureLimit=1024;gui.torusView.toggle();
    const auto checksum=gui.game.checkSum();
    const int animationBefore=gui.view.render.animationTime;
    const int areaBefore=gui.view.render.areaAnimationTick;
    // pushDeviceTarget consults capabilities after the phase scope starts.
    // The injected fault therefore exercises the real draw() fallback catch.
    probe->phaseFault=[&]{return gui.view.render.animationTime!=animationBefore;};
    int vx=17,vy=21;
    REQUIRE_FALSE(gui.torusView.draw(gui.drawnScene(),&gui,0,Game::DRAW_WHOLE_MAP|Game::DRAW_AREA,vx,vy,640,480));
    REQUIRE(probe->phaseRejected);
    probe->phaseFault={};
    REQUIRE(gui.view.render.animationTime==animationBefore);
    REQUIRE(gui.view.render.areaAnimationTick==areaBefore);
    Game::drawSceneMap(gui.drawnScene(),0,0,640,480,0,0,vx,vy,0,gui.view,Game::DRAW_WHOLE_MAP|Game::DRAW_AREA);
    REQUIRE(gui.view.render.animationTime==animationBefore+1);
    REQUIRE(gui.view.render.areaAnimationTick==areaBefore+1);
    REQUIRE(gui.game.checkSum()==checksum);
    REQUIRE(gfx->presentationDevice.get()==probe);
    REQUIRE(gfx->backendSwitchStatus().active==backend);
}

static void deviceCapture(GAGCore::RendererBackend backend)
{
    glob2test::HeadlessGlobals globals({.display = true, .loadStrings = true, .width = 640, .height = 480,
        .beforeLoad = [backend](GlobalContainer &container) { container.settings.rendererBackend = backend; }});
    auto *gfx = globals->gfx;
    if (gfx->backendSwitchStatus().active != backend) {
        MESSAGE("Backend unavailable: ", gfx->backendSwitchStatus().reason);
        return;
    }
    REQUIRE(gfx->renderDevice());
    globals->settings.clouds = false;
    Game game(nullptr);
    makeTorusMapFixture(game, 256, 256);
    game.map.setMapDiscovered();
    // The logical capture is over 8,000 pixels high, independently of the
    // window and the bounded physical tile resolution. Its centre must receive
    // terrain rather than retain the black initial target contents.
    for (int limit : {4096, 2048, 1024}) {
        TorusView view;
        view.textureLimit = limit;
        view.toggle();
        bool recorded = false;
        // Full-density targets exceed one bounded upload admission. Preserve
        // the requested quality while allowing successive frames to restore them.
        for (unsigned retry = 0; retry < 128; ++retry) {
            int vx = 128, vy = 128;
            REQUIRE(view.draw(glob2test::sceneOf(game), nullptr, 0, Game::DRAW_WHOLE_MAP,
                vx, vy, gfx->getW(), gfx->getH()));
            REQUIRE(view.pixelsPerCell == SoftwareTerrainCache::capturePixelsPerCell(256, 256));
            gfx->renderer->flush();
            recorded = didRecordDeviceFrame(*gfx->renderer);
            if (recorded) break;
            gfx->nextFrame();
            SDL_Delay(1);
        }
        REQUIRE(recorded);
        std::unique_ptr<SDL_Surface, decltype(&SDL_DestroySurface)> capture(gfx->renderer->capture(), SDL_DestroySurface);
        REQUIRE(capture);
        unsigned samples = 0, coloured = 0;
        for (int y = capture->h / 3; y < 2 * capture->h / 3; y += 8)
            for (int x = capture->w / 3; x < 2 * capture->w / 3; x += 8) {
                Uint8 r, g, b, a;
                REQUIRE(SDL_ReadSurfacePixel(capture.get(), x, y, &r, &g, &b, &a));
                ++samples;
                coloured += unsigned(r) + g + b > 48;
            }
        CHECK(coloured * 100 >= samples * 90);
        const auto filename = std::string(GAGCore::rendererBackendName(backend)) + "-large-torus-" + std::to_string(limit);
        REQUIRE(SDL_SaveBMP(capture.get(), (glob2test::artifactDir() / (filename + ".bmp")).string().c_str()));
        std::ofstream report(glob2test::artifactDir() / (filename + ".txt"));
        report << "active=" << GAGCore::rendererBackendName(gfx->backendSwitchStatus().active)
            << " density=" << view.pixelsPerCell << " samples=" << samples << " coloured=" << coloured << '\n';
        gfx->nextFrame();
    }
}

static void liveTerrainPressure(GAGCore::RendererBackend backend)
{
    using namespace GAGCore;
    glob2test::HeadlessGlobals globals({.display=true,.loadStrings=true,.width=640,.height=480,
        .beforeLoad=[backend](GlobalContainer &container){container.settings.rendererBackend=backend;}});
    auto *gfx=globals->gfx;
    if(gfx->backendSwitchStatus().active!=backend){MESSAGE("Backend unavailable: ",gfx->backendSwitchStatus().reason);return;}
    auto &device=*gfx->renderDevice();auto &resources=*gfx->renderResources();
    REQUIRE(device.capabilities().maximumTextureSize>=2048);
    globals->settings.clouds=false;
    // Four live 2048-square pages consume 64 MiB of the shared TerrainPage
    // class. The 256-cell torus's requested density needs another >64 MiB.
    // These are completed GPU targets, not merely unuploaded logical handles.
    std::vector<TextureHandle> handles;std::vector<TextureSnapshot> pressure;
    for(unsigned i=0;i<4;++i){
        std::unique_ptr<SDL_Surface,decltype(&SDL_DestroySurface)> pixels(
            SDL_CreateSurface(2048,2048,SDL_PIXELFORMAT_RGBA32),SDL_DestroySurface);
        REQUIRE(pixels);REQUIRE(SDL_FillSurfaceRect(pixels.get(),nullptr,0));
        TextureDescriptor descriptor;descriptor.budgetClass=TextureDescriptor::BudgetClass::TerrainPage;
        descriptor.alpha=TextureDescriptor::Alpha::Opaque;
        auto handle=resources.create(pixels.get(),i+1,descriptor);REQUIRE(handle);
        handles.push_back(handle);pressure.push_back(resources.snapshot(handle));
        RenderSubmission submission;
        for(unsigned retry=0;retry<128 && !submission;++retry){
            RenderFrame frame;frame.identity=i+1;frame.logicalWidth=gfx->getW();frame.logicalHeight=gfx->getH();
            DrawPacket clear;clear.kind=DrawPacket::Kind::Clear;clear.target=pressure.back();
            clear.clearColor=true;clear.clearValue={.8f,.1f,.2f,1};frame.packets.push_back(clear);
            try{submission=device.submit(std::move(frame));}
            catch(const RenderAdmissionDeferred &){device.discardFrame();}
            if(!submission)SDL_Delay(1);
        }
        REQUIRE(submission);device.present();
        CaptureRequest request;request.target=pressure.back();request.pixelRegion=SDL_Rect{1024,1024,1,1};
        request.width=request.height=1;
        std::unique_ptr<SDL_Surface,decltype(&SDL_DestroySurface)> pixel(device.captureSynchronously(request),SDL_DestroySurface);
        REQUIRE(pixel);Uint8 r,g,b,a;REQUIRE(SDL_ReadSurfacePixel(pixel.get(),0,0,&r,&g,&b,&a));
        REQUIRE(r>=200);REQUIRE(a==255);
    }
    device.trimRetiredResources();
    REQUIRE(device.telemetry().resourceBytes>=64u*1024*1024);
    Game game(nullptr);makeTorusMapFixture(game,256,256);game.map.setMapDiscovered();
    const auto requested=SoftwareTerrainCache::capturePixelsPerCell(256,256);
    TorusView view;view.textureLimit=2048;view.toggle();
    auto render=[&]{
        for(unsigned retry=0;retry<128;++retry){
            if(!view.active())view.toggle();
            int vx=128,vy=128;
            REQUIRE(view.draw(glob2test::sceneOf(game),nullptr,0,Game::DRAW_WHOLE_MAP,
                vx,vy,gfx->getW(),gfx->getH()));
            gfx->renderer->flush();
            const bool recorded=didRecordDeviceFrame(*gfx->renderer);
            if(recorded){
                std::unique_ptr<SDL_Surface,decltype(&SDL_DestroySurface)> capture(gfx->renderer->capture(),SDL_DestroySurface);
                REQUIRE(capture);
                unsigned sampled=0,coloured=0;
                for(int y=capture->h/3;y<2*capture->h/3;y+=16)
                    for(int x=capture->w/3;x<2*capture->w/3;x+=16){
                        Uint8 r,g,b,a;REQUIRE(SDL_ReadSurfacePixel(capture.get(),x,y,&r,&g,&b,&a));
                        ++sampled;coloured+=unsigned(r)+g+b>48;
                    }
                REQUIRE(coloured*100>=sampled*90);
            }
            gfx->nextFrame();
            if(recorded)return;
            SDL_Delay(1);
        }
        FAIL("Torus never completed within bounded pressure retries");
    };
    render();REQUIRE(view.pixelsPerCell>0);REQUIRE(view.pixelsPerCell<requested);
    const auto reduced=view.pixelsPerCell;
    // Release both logical handles and external target leases, then explicitly
    // finish earlier work. Requested density must return without switching device.
    for(auto handle:handles)resources.erase(handle);
    pressure.clear();view.reset();
    RenderFrame barrier;
    barrier.identity=10000;barrier.logicalWidth=gfx->getW();barrier.logicalHeight=gfx->getH();
    DrawPacket fence;fence.kind=DrawPacket::Kind::Barrier;
    barrier.packets.push_back(std::move(fence));
    const auto retirement=device.submit(std::move(barrier));REQUIRE(retirement);
    device.present();
    const auto deadline=SDL_GetTicks()+5000;
    while(device.completion(retirement)==RenderCompletion::Pending && SDL_GetTicks()<deadline) SDL_Delay(1);
    REQUIRE(device.completion(retirement)==RenderCompletion::Complete);
    device.trimRetiredResources();view.toggle();render();
    REQUIRE(view.pixelsPerCell==requested);
    std::cout<<rendererBackendName(backend)<<" live TerrainPage pressure density "<<reduced
        <<" -> "<<view.pixelsPerCell<<" completed without backend fallback\n";
    REQUIRE(gfx->backendSwitchStatus().active==backend);
}

static void run(bool gpu, int width, int height)
{
    SDL_SetHint(SDL_HINT_MAC_BACKGROUND_APP, "1");
    // The old harness ran with -F (windowed) -m (mute) -s WxH and -g or -G.
    glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.display = true, .loadStrings = true, .width = width, .height = height,
                                                                 .screenFlags = gpu ? Uint32(GraphicContext::USEGPU) : 0u});
    if (SDL_GL_GetCurrentWindow())
        SDL_HideWindow(SDL_GL_GetCurrentWindow());
    {
        GameGUI gui;
        auto mapHeader = Engine::loadMapHeader("maps/Island_of_the_Renfur.map");
        GameHeader gameHeader;
        for (int i = 0; i < mapHeader.getNumberOfTeams(); ++i)
            gameHeader.getBasePlayer(i) =
                BasePlayer(i, "Test", i, i == 0 ? BasePlayer::P_LOCAL : BasePlayer::P_AI);
        gameHeader.setNumberOfPlayers(mapHeader.getNumberOfTeams());
        gui.localPlayer = gui.localTeamNo = 0;
        REQUIRE(gui.loadFromHeaders(mapHeader, gameHeader, true, true));
        gui.adjustLocalTeam();
        gui.adjustInitialViewport();
        gui.prepareLocalPresentation();
        gui.updateCamera();
        // A drag beginning on empty ground moves the map with the pointer.
        // Find an actual empty visible tile so the fixture can change freely.
        int dragX = -1, dragY = -1;
        for (int y = 64; y < globalContainer->gfx->getH() - 64 && dragX < 0; y += 24)
            for (int x = 64; x < globalContainer->gfx->getW() - GAME_GUI_RIGHT_MENU_WIDTH - 64; x += 24)
            {
                int tileX, tileY;
                gui.game.map.displayToMapCaseAligned(gui.mapMouseX(x), gui.mapMouseY(y),
                    &tileX, &tileY, gui.viewportX, gui.viewportY);
                bool flagHere = false;
                for (const auto *flag : gui.localTeam->virtualBuildings)
                    flagHere |= gui.displayedPosX(*flag) == tileX &&
                        gui.displayedPosY(*flag) == tileY;
                if (gui.game.map.getBuilding(tileX, tileY) == NOGBID &&
                    !flagHere &&
                    !gui.game.map.isResource(tileX, tileY) &&
                    gui.game.map.getGroundUnit(tileX, tileY) == NOGUID &&
                    gui.game.map.getAirUnit(tileX, tileY) == NOGUID)
                {
                    dragX = x;
                    dragY = y;
                    break;
                }
            }
        REQUIRE(dragX >= 0);
        gui.view.mouseUnit = UnitRef();
        SDL_MouseButtonEvent down{};
        down.button = SDL_BUTTON_LEFT;
        down.x = dragX;
        down.y = dragY;
        gui.handleMouseButtonDown(down);
        REQUIRE(gui.mapPanPushed);
        const double originX = gui.camera.originX;
        gui.handleMouseMotion(dragX + 12, dragY + 8, SDL_BUTTON_MASK(SDL_BUTTON_LEFT));
        REQUIRE(std::abs(gui.camera.originX -
            MapCamera::wrap(originX - 12 / gui.camera.zoom, gui.camera.mapWidth)) < 0.01);
        gui.handleMouseButtonUp(down);
        REQUIRE(!gui.mapPanPushed);
        const double releasedX = gui.camera.originX;
        gui.handleMouseMotion(dragX + 24, dragY + 8, 0);
        REQUIRE(gui.camera.originX == releasedX);
        // Building and resource tiles must accept the same pan and wheel
        // gestures as empty ground, without queuing building orders.
        std::pair<int, int> building{-1, -1}, resource{-1, -1};
        for (int y = 0; y < gui.game.map.getH(); ++y)
            for (int x = 0; x < gui.game.map.getW(); ++x)
            {
                if (building.first < 0 && gui.game.map.getBuilding(x, y) != NOGBID)
                    building = {x, y};
                if (resource.first < 0 && gui.game.map.getBuilding(x, y) == NOGBID &&
                    gui.game.map.isResource(x, y))
                    resource = {x, y};
            }
        REQUIRE((building.first >= 0 && resource.first >= 0));
        for (const auto tile : {building, resource})
        {
            gui.camera.originX = tile.first * 32 + 16 - gui.camera.visibleW() / 2;
            gui.camera.originY = tile.second * 32 + 16 - gui.camera.visibleH() / 2;
            gui.camera.normalize();
            gui.viewportX = gui.camera.tileX();
            gui.viewportY = gui.camera.tileY();
            gui.updateCamera();
            const int x = int(gui.camera.offsetX + gui.camera.width / 2);
            const int y = int(gui.camera.offsetY + gui.camera.height / 2);
            gui.view.mouseUnit = UnitRef();
            SDL_MouseButtonEvent press{};
            press.button = SDL_BUTTON_LEFT;
            press.x = x;
            press.y = y;
            const auto ordersBefore = gui.orderQueue.size();
            gui.handleMouseButtonDown(press);
            REQUIRE(gui.mapPanPushed);
            const double beforePan = gui.camera.originX;
            gui.handleMouseMotion(x + 12, y + 8, SDL_BUTTON_MASK(SDL_BUTTON_LEFT));
            REQUIRE(std::abs(gui.camera.originX -
                MapCamera::wrap(beforePan - 12 / gui.camera.zoom, gui.camera.mapWidth)) < 0.01);
            SDL_Event release{};
            release.type = SDL_EVENT_MOUSE_BUTTON_UP;
            release.button.button = SDL_BUTTON_LEFT;
            release.button.x = x;
            release.button.y = y;
            gui.processEvent(&release);
            REQUIRE(gui.orderQueue.size() == ordersBefore);
            gui.mouseX = x;
            gui.mouseY = y;
            SDL_Event wheel{};
            wheel.type = SDL_EVENT_MOUSE_WHEEL;
            wheel.wheel.y = 1;
            wheel.wheel.mouse_x = x;
            wheel.wheel.mouse_y = y;
            const double beforeZoom = gui.camera.zoom;
            gui.processEvent(&wheel);
            REQUIRE(gui.camera.zoom > beforeZoom);
            REQUIRE(gui.orderQueue.size() == ordersBefore);
        }
        // A direct flag grab keeps its existing move gesture.
        if (!gui.localTeam->virtualBuildings.empty())
        {
            auto *flag = gui.localTeam->virtualBuildings.front();
            gui.camera.originX = gui.displayedPosX(*flag) * 32 + 16 - gui.camera.visibleW() / 2;
            gui.camera.originY = gui.displayedPosY(*flag) * 32 + 16 - gui.camera.visibleH() / 2;
            gui.camera.normalize();
            gui.viewportX = gui.camera.tileX();
            gui.viewportY = gui.camera.tileY();
            gui.updateCamera();
            const int x = int(gui.camera.offsetX + gui.camera.width / 2);
            const int y = int(gui.camera.offsetY + gui.camera.height / 2);
            gui.view.mouseUnit = UnitRef();
            SDL_MouseButtonEvent press{};
            press.button = SDL_BUTTON_LEFT;
            press.x = x;
            press.y = y;
            gui.handleMouseButtonDown(press);
            REQUIRE(!gui.mapPanPushed);
            const double origin = gui.camera.originX;
            const int flagX = gui.displayedPosX(*flag);
            gui.handleMouseMotion(x + 96, y, SDL_BUTTON_MASK(SDL_BUTTON_LEFT));
            REQUIRE(gui.camera.originX == origin);
            REQUIRE(gui.displayedPosX(*flag) != flagX);
            gui.handleMouseButtonUp(press);
        }
        // Units in the last 15 tiles of a full-world capture must keep their
        // visible copy's position, including movement across either seam.
        Unit *explorer = gui.game.addUnit(0, 0, 0, EXPLORER, 0, 128, 1, 1);
        REQUIRE(explorer);
        for (int x : {-1, 0, gui.game.map.getW() - 8, gui.game.map.getW()})
            for (int y : {-1, 0, gui.game.map.getH() - 8, gui.game.map.getH()})
            {
                gui.view.mouseX = x * 32;
                gui.view.mouseY = y * 32;
                gui.view.mouseUnit = UnitRef();
                gui.game.drawUnit(x, y, explorer->gid, (-x) & gui.game.map.getMaskW(),
                    (-y) & gui.game.map.getMaskH(), gui.game.map.getW(), gui.game.map.getH(),
                    0, Game::DRAW_WHOLE_MAP, gui.view, glob2test::sceneOf(gui.game, gui.view));
                REQUIRE(gui.game.resolveUnit(gui.view.mouseUnit) == explorer);
            }
        gui.view.mouseX = gui.view.mouseY = -1;
        gui.view.mouseUnit = UnitRef();
        // Upgrading an old keyboard layout must neither shadow custom keys
        // nor lose the new default when its key is available.
        KeyboardManager keyboard(GameGUIShortcuts);
        KeyboardShortcut custom;
        custom.interpret("<g>=pause game", GameGUIShortcuts);
        keyboard.getKeyboardShortcuts().clear();
        keyboard.getKeyboardShortcuts().push_back(custom);
        keyboard.addMissingDefaults(GameGUIKeyActions::getDefaultConfigurationFile());
        for (const auto &shortcut : keyboard.getKeyboardShortcuts())
            REQUIRE(shortcut.format(GameGUIShortcuts) != "<g>=toggle torus view");
        keyboard.getKeyboardShortcuts().clear();
        keyboard.addMissingDefaults(GameGUIKeyActions::getDefaultConfigurationFile());
        bool hasToggle = false;
        for (const auto &shortcut : keyboard.getKeyboardShortcuts())
            hasToggle |= shortcut.format(GameGUIShortcuts) == "<g>=toggle torus view";
        REQUIRE(hasToggle);
        REQUIRE(!Settings().automaticTorus);
        globalContainer->settings.automaticTorus = false;
#ifndef GLOB2_MOBILE
        {
            SettingsScreen options;
            const int oldMute = globalContainer->settings.mute;
            const bool oldHighResolution = globalContainer->settings.highResolutionArtwork;
            if (gpu) { REQUIRE(options.changeSetting("graphics.torus",1)); }
            else
            {
                REQUIRE(!options.changeSetting("graphics.torus",1));
                REQUIRE(!globalContainer->settings.automaticTorus);
                // An unavailable control retains an existing saved preference.
                globalContainer->settings.automaticTorus=true;
                REQUIRE(globalContainer->settings.save());
            }
            REQUIRE(globalContainer->settings.automaticTorus);
            REQUIRE(globalContainer->settings.mute == oldMute);
            REQUIRE(globalContainer->settings.highResolutionArtwork == oldHighResolution);
            options.done();
        }
        Settings restored;
        restored.load();
        REQUIRE(restored.automaticTorus);
        {
            SettingsScreen options;
            // Discrete settings save immediately, including when the screen
            // closes without a separate Save action.
            if (gpu) { REQUIRE(options.changeSetting("graphics.torus",0)); }
            else
            {
                REQUIRE(!options.changeSetting("graphics.torus",0));
                REQUIRE(globalContainer->settings.automaticTorus);
                globalContainer->settings.automaticTorus=false;
                REQUIRE(globalContainer->settings.save());
            }
            REQUIRE(!globalContainer->settings.automaticTorus);
            restored.load();
            REQUIRE(!restored.automaticTorus);
            options.done();
            REQUIRE(!globalContainer->settings.automaticTorus);
        }
        restored.load();
        REQUIRE(!restored.automaticTorus);
#else
        {
            // Mobile deliberately omits the desktop OpenGL torus preference.
            SettingsScreen options;
            REQUIRE(!options.changeSetting("graphics.torus", 1));
            REQUIRE(!globalContainer->settings.automaticTorus);
            options.done();
            Settings restored;
            restored.load();
            REQUIRE(!restored.automaticTorus);
        }
#endif
        TorusView view;
        view.notifyMove();
        REQUIRE(!view.active());
        for (int i = 0; i < 100; ++i)
        {
            view.setViewport(i, i / 2);
            REQUIRE(!view.active());
        }
        const bool gpu = globalContainer->gfx->getOptionFlags() & GraphicContext::USEGPU;
        REQUIRE(view.available() == gpu);
        if (!gpu)
        {
            globalContainer->settings.automaticTorus = true;
            view.notifyMove();
            view.toggle();
            REQUIRE(!view.active());
            globalContainer->settings.automaticTorus = false;
            int x = 0, y = 0, px, py;
            REQUIRE(!view.draw(glob2test::sceneOf(gui.game),gui.game.gui, 0, 0, x, y, 960, 720));
            REQUIRE(!view.pick(480, 560, px, py));
            glob2test::drawGUI(gui,0);
            std::cout << "Software game rendering and inactive torus controls passed\n";
        }
        else
        {
#ifdef HAVE_OPENGL
            // Variable-size resource batching must preserve pixels, frame bounds,
            // transparency and ordering at native and overview scales.
            for (bool highResolution : {false, true})
            {
                Sprite::setHighResolution(highResolution);
                Sprite resources;
                REQUIRE(resources.load("data/gfx/ressource"));
                GLint viewport[4];
                glGetIntegerv(GL_VIEWPORT, viewport);
                auto captureResources = [&](float scale, Uint8 alpha, bool immediate)
                {
                    globalContainer->gfx->setClipRect();
                    glClearColor(.17f, .29f, .43f, 1);
                    glClear(GL_COLOR_BUFFER_BIT);
                    for (int i = 0; i < resources.getFrameCount(); ++i)
                    {
                        const int frame = i % 2 ? resources.getFrameCount() - 1 - i / 2 : i / 2;
                        const int x = 30 + (i % 8) * 52, y = 30 + (i / 8) * 52;
                        if (scale == 1.f)
                            globalContainer->gfx->drawSprite(x, y, &resources, frame, alpha);
                        else
                            globalContainer->gfx->drawSprite(float(x), float(y), resources.getW(frame) * scale,
                                resources.getH(frame) * scale, &resources, frame, alpha);
                        if (immediate)
                            globalContainer->gfx->finishDrawingSprite(&resources, alpha);
                    }
                    globalContainer->gfx->finishDrawingSprite(&resources, alpha);
                    std::vector<unsigned char> pixels(viewport[2] * viewport[3] * 4);
                    glReadPixels(0, 0, viewport[2], viewport[3], GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
                    return pixels;
                };
                std::vector<std::vector<unsigned char>> reference;
                for (float scale : {1.f, .5f, .75f, 2.f})
                    for (Uint8 alpha : {Uint8(255), Uint8(127)})
                        reference.push_back(captureResources(scale, alpha, true));
                std::vector<std::pair<int, int>> sizes;
                for (int i = 0; i < resources.getFrameCount(); ++i)
                    sizes.emplace_back(resources.getW(i), resources.getH(i));
                REQUIRE(resources.createTextureAtlas(true));
                int sample = 0, maximumDifference = 0;
                for (float scale : {1.f, .5f, .75f, 2.f})
                    for (Uint8 alpha : {Uint8(255), Uint8(127)})
                    {
                        auto actual = captureResources(scale, alpha, false);
                        for (size_t i = 0; i < actual.size(); ++i)
                            maximumDifference = std::max(maximumDifference,
                                std::abs(int(actual[i]) - reference[sample][i]));
                        ++sample;
                    }
                for (int i = 0; i < resources.getFrameCount(); ++i)
                    REQUIRE(sizes[i] == std::make_pair(resources.getW(i), resources.getH(i)));
                std::cout << (highResolution ? "HD" : "Original") << " resource atlas maximum pixel difference: " << maximumDifference << "/255\n";
                REQUIRE(maximumDifference <= 1);
            }
            Sprite::setHighResolution(globalContainer->settings.highResolutionArtwork);
            DynamicClouds clouds(&globalContainer->settings);
            std::valarray<unsigned char> pixels;
            int gridW, gridH;
            clouds.computeWorld(256, 256, 250, pixels, gridW, gridH, 128);
            REQUIRE((gridW == 128 && gridH == 128));
            const auto &settings = globalContainer->settings;
            CloudField field(8192, 8192, 250, settings.cloudSize, settings.cloudStability,
                settings.cloudMaxSpeed, settings.cloudWindStability, settings.cloudMaxAlpha);
            for (int row = 0; row < gridH; ++row)
                for (int col = 0; col < gridW; ++col)
                    REQUIRE(pixels[row * gridW + col] == field.opacity(col * 64, row * 64,
                        std::max(.01f, settings.cloudHeight / 100.f)));
            int x = 11, y = 13;
            auto draw = [&](float amount)
            {
                view.amount = amount;
                view.lastFrame = SDL_GetTicks();
                const auto randomState=syncRandEngine();
                const auto gameRandom=gui.game.syncRandom;
                REQUIRE(view.draw(glob2test::sceneOf(gui.game),gui.game.gui, 0, Game::DRAW_WHOLE_MAP | Game::DRAW_AREA, x, y, 960, 720));
                REQUIRE(glGetError() == GL_NO_ERROR);
                REQUIRE((syncRandEngine()==randomState && gui.game.syncRandom==gameRandom));
            };
            view.toggle();
            REQUIRE(view.active());
            draw(0);
            for (float phase : {.01f, .25f, .5f, .75f, 1.f})
                draw(phase);
            const auto saveFrame = [](const char *name)
            {
                GLint viewport[4]; glGetIntegerv(GL_VIEWPORT,viewport);
                const int w=viewport[2],h=viewport[3];
                std::vector<unsigned char> pixels(size_t(w)*h*4),upright(pixels.size());
                glReadPixels(0,0,w,h,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());
                for(int y=0;y<h;++y) std::copy_n(pixels.data()+size_t(y)*w*4,w*4,upright.data()+size_t(h-1-y)*w*4);
                auto *frame=SDL_CreateSurfaceFrom(w,h,SDL_PIXELFORMAT_RGBA32,upright.data(),w*4);
                REQUIRE(frame!=nullptr);
                REQUIRE(SDL_SaveBMP(frame,(glob2test::artifactDir()/name).string().c_str()));
                SDL_DestroySurface(frame);
            };
            saveFrame("torus-native.bmp");
            gui.gamePaused = true;
            const int pausedTime = gui.view.render.animationTime;
            const int pausedAreas = gui.view.render.areaAnimationTick;
            draw(1);
            const auto pausedClouds = view.cloudPixels;
            draw(1);
            REQUIRE(gui.view.render.animationTime == pausedTime);
            REQUIRE(gui.view.render.areaAnimationTick == pausedAreas);
            REQUIRE(pausedClouds.size() == view.cloudPixels.size());
            for (size_t i = 0; i < pausedClouds.size(); ++i)
                REQUIRE(pausedClouds[i] == view.cloudPixels[i]);
            gui.gamePaused = false;
            draw(1);
            REQUIRE(gui.view.render.animationTime == pausedTime + 1);
            REQUIRE(gui.view.render.areaAnimationTick == pausedAreas + 1);
            // Selection markers are painted into the atlas, which is measured in
            // world pixels. The factor the window stretches the interface by must
            // not reach their line width, and every marker the flat view paints
            // over the map has to be on the ring too.
            {
                const float windowScale = globalContainer->gfx->getRasterScale();
                Building *selected = gui.game.teams[0]->liveBuildings.front();
                REQUIRE(selected);
                gui.showUnitWorkingToBuilding = true;
                gui.setSelection(GameGUI::BUILDING_SELECTION, selected);
                REQUIRE(std::get<BuildingRef>(gui.selection) == Game::refOf(selected));
                REQUIRE(gui.view.selectedBuilding == nullptr);
                const int worldW = gui.game.map.getW() * 32, worldH = gui.game.map.getH() * 32;
                std::vector<std::vector<unsigned char>> atlas;
                // The atlas holds one upright copy of the world; GL hands rows back bottom-up.
                auto texel = [&](int worldX, int worldY)
                {
                    const int x = ((worldX % worldW) + worldW) % worldW;
                    const int y = ((worldY % worldH) + worldH) % worldH;
                    for (size_t i = 0; i < view.tiles.size(); ++i)
                    {
                        const auto &tile = view.tiles[i];
                        if (x < tile.x || x >= tile.x + tile.w || y < tile.y || y >= tile.y + tile.h) continue;
                        const int col = (x - tile.x + 32) * view.pixelsPerCell / 32;
                        const int row = tile.textureH - 1 - (y - tile.y + 32) * view.pixelsPerCell / 32;
                        return &atlas[i][(size_t(row) * tile.textureW + col) * 4];
                    }
                    return static_cast<unsigned char *>(nullptr);
                };
                // Drawing reads the GUI's PresentationFrame; drawAll would extract it first.
                PresentationFrame scene;
                auto capture = [&]()
                {
                    gui.game.snapshots().invalidateBoundary();
                    gui.prepareLocalPresentation(scene);
                    gui.setPublishedScene(&scene);
                    draw(1);
                    gui.setPublishedScene(nullptr);
                    // Software GL renders on worker threads, and the readback below has been
                    // seen to return the previous frame's atlas: wait for the frame first.
                    glFinish();
                    atlas.resize(view.tiles.size());
                    for (size_t i = 0; i < view.tiles.size(); ++i)
                    {
                        const auto &tile = view.tiles[i];
                        atlas[i].resize(size_t(tile.textureW) * tile.textureH * 4);
                        glBindTexture(GL_TEXTURE_2D, tile.texture);
                        glGetTexImage(GL_TEXTURE_2D, 0, GL_RGBA, GL_UNSIGNED_BYTE, atlas[i].data());
                    }
                    REQUIRE(glGetError() == GL_NO_ERROR);
                };
                // A worker circle is white over whatever it covers, so count the
                // bright pixels its own tile gains rather than trusting a threshold.
                int ux, uy;
                gui.game.map.mapCaseToDisplayable(explorer->posX, explorer->posY, &ux, &uy,
                    view.originX, view.originY);
                auto brightAroundWorker = [&]()
                {
                    int bright = 0;
                    for (int dy = -40; dy <= 72; ++dy)
                        for (int dx = -40; dx <= 72; ++dx)
                        {
                            const unsigned char *p = texel(ux + dx, uy + dy);
                            if (p[0] > 150 && p[1] > 150 && p[2] > 150)
                                ++bright;
                        }
                    return bright;
                };
                capture();
                const int withoutWorker = brightAroundWorker();
                selected->unitsWorking.push_back(explorer);
                capture();
                const int withWorker = brightAroundWorker();
                selected->unitsWorking.clear();
                std::cout << "Torus worker marker bright pixels: " << withoutWorker << " -> "
                          << withWorker << "\n";
                REQUIRE(withWorker > withoutWorker + 16);
                // Walk outwards from the ring's left edge: at one texel per world
                // pixel the selection circle is the two pixels drawCircle asks for.
                int cx, cy;
                gui.game.map.buildingPosToCursor(selected->posX, selected->posY, selected->type->width,
                    selected->type->height, &cx, &cy, view.originX, view.originY);
                int stroke = 0;
                for (int d = -8; d <= 8; ++d)
                {
                    const unsigned char *p = texel(cx - selected->type->width * 16 + d, cy);
                    if (p[2] > 110 && p[0] < 90 && p[1] < 90)
                        ++stroke;
                }
                std::cout << "Torus selection circle: " << stroke << " atlas texels wide at interface scale "
                          << windowScale << "\n";
                REQUIRE((stroke > 0 && stroke <= 3));
                // The window is the drawable again once the atlas pass is over.
                REQUIRE(globalContainer->gfx->getRasterScale() == windowScale);
                gui.clearSelection();
                std::cout << "Torus selection markers passed\n";
            }
            // Test navigation separately from the expensive cloud layer.
            globalContainer->settings.setGraphicsDetail(false);
            for (int i = 0; i < 20; ++i)
            {
                view.setViewport((x + 3) & gui.game.map.getMaskW(), (y + 5) & gui.game.map.getMaskH());
                draw(1);
                int px, py;
                REQUIRE(view.pick(480, 560, px, py));
            }
            view.reset();
            REQUIRE(!view.active());
            int px, py;
            REQUIRE(!view.pick(480, 560, px, py));
            for (int i = 0; i < 3; ++i)
            {
                view.toggle();
                draw(0);
                draw(1);
                view.reset();
            }
            view.toggle();
            draw(0);
            view.toggle();
            view.lastFrame = SDL_GetTicks() - 100;
            view.amount = .04f;
            REQUIRE(view.draw(glob2test::sceneOf(gui.game),gui.game.gui, 0, Game::DRAW_WHOLE_MAP | Game::DRAW_AREA, x, y, 960, 720));
            REQUIRE(!view.active());
            // Automatic motion opens slowly and returns quickly after inactivity.
            globalContainer->settings.automaticTorus = true;
            view.notifyMove();
            REQUIRE((view.active() && !view.enabled()));
            draw(0);
            view.amount = .25f;
            view.lastMove = SDL_GetTicks();
            view.lastFrame = SDL_GetTicks() - 100;
            REQUIRE(view.draw(glob2test::sceneOf(gui.game),gui.game.gui, 0, Game::DRAW_WHOLE_MAP | Game::DRAW_AREA, x, y, 960, 720));
            REQUIRE((view.amount > .25f && view.amount <= .28f));
            // Neither folding nor automatic return changes an active gesture's projection.
            view.setPointerHeld(true);
            float heldAmount = view.amount;
            view.lastMove = SDL_GetTicks() - 300;
            view.lastFrame = SDL_GetTicks() - 100;
            REQUIRE(view.draw(glob2test::sceneOf(gui.game),gui.game.gui, 0, Game::DRAW_WHOLE_MAP | Game::DRAW_AREA, x, y, 960, 720));
            REQUIRE(view.amount == heldAmount);
            view.setPointerHeld(false);
            view.lastFrame = SDL_GetTicks() - 100;
            REQUIRE(view.draw(glob2test::sceneOf(gui.game),gui.game.gui, 0, Game::DRAW_WHOLE_MAP | Game::DRAW_AREA, x, y, 960, 720));
            REQUIRE(view.amount < heldAmount - .2f);
            // G pins the overview even when no movement notifications arrive.
            view.toggle();
            view.lastMove = SDL_GetTicks() - 300;
            draw(1);
            REQUIRE((view.enabled() && view.amount == 1));
            view.toggle();
            view.amount = .1f;
            view.lastFrame = SDL_GetTicks() - 100;
            REQUIRE(view.draw(glob2test::sceneOf(gui.game),gui.game.gui, 0, Game::DRAW_WHOLE_MAP | Game::DRAW_AREA, x, y, 960, 720));
            REQUIRE(!view.active());
            // Disabling the preference clears an automatic reveal before its first frame.
            view.notifyMove();
            globalContainer->settings.automaticTorus = false;
            REQUIRE(!view.draw(glob2test::sceneOf(gui.game),gui.game.gui, 0, Game::DRAW_WHOLE_MAP, x, y, 960, 720));
            REQUIRE(!view.active());
            view.notifyMove();
            REQUIRE(!view.active());
            globalContainer->gfx->setClipRect();
            glob2test::drawGUI(gui,0);
            // Preserve the map focus when entering from shared 2D zoom.
            for (double flatZoom : {.5, 1.0, 2.0})
            {
                gui.camera.zoom = flatZoom;
                gui.camera.originX = gui.viewportX * 32.0 + 7;
                gui.camera.originY = gui.viewportY * 32.0 + 11;
                gui.updateCamera();
                const int cx = (globalContainer->gfx->getW()-RIGHT_MENU_WIDTH)/2;
                const int cy = (globalContainer->gfx->getH()+16)/2;
                const auto center = gui.camera.screenToWorld(cx, cy);
                gui.torusView.reset();
                gui.torusView.toggle();
                for (float phase : {0.f, .5f, 1.f})
                {
                    gui.torusView.amount = phase;
                    gui.torusView.lastFrame = SDL_GetTicks();
                    glob2test::drawGUI(gui,0);
                    int px, py;
                    REQUIRE(gui.torusView.pick(cx, cy, px, py));
                    REQUIRE(std::abs(TorusGeometry::wrappedDelta(px, int(center.first), gui.game.map.getW()*32)) <= 2);
                    REQUIRE(std::abs(TorusGeometry::wrappedDelta(py, int(center.second), gui.game.map.getH()*32)) <= 2);
                    REQUIRE(glGetError() == GL_NO_ERROR);
                }
                gui.torusView.reset();
                glob2test::drawGUI(gui,0);
            }
            // One zoom for both views: the wheel on the ring zooms the 2D
            // camera about the ring's focus, the ring draws the detail of that
            // zoom, and unfolding returns to the flat map at the zoom reached.
            {
                gui.camera.zoom = 1;
                gui.updateCamera();
                const int cx = (globalContainer->gfx->getW()-RIGHT_MENU_WIDTH)/2;
                const int cy = (globalContainer->gfx->getH()+16)/2;
                gui.torusView.reset();
                gui.torusView.toggle();
                for (float phase : {0.f, 1.f})
                {
                    gui.torusView.amount = phase;
                    gui.torusView.lastFrame = SDL_GetTicks();
                    glob2test::drawGUI(gui,0);
                }
                REQUIRE(gui.view.render.detail.strategic == 0);
                int beforeX, beforeY, afterX, afterY;
                REQUIRE(gui.torusView.pick(cx, cy, beforeX, beforeY));
                const float closeUp = gui.torusView.meshKey[2];
                gui.mouseX = cx + 150;
                gui.mouseY = cy - 90;
                SDL_Event wheel{};
                wheel.type = SDL_EVENT_MOUSE_WHEEL;
                wheel.wheel.y = -1;
                wheel.wheel.mouse_x = gui.mouseX;
                wheel.wheel.mouse_y = gui.mouseY;
                for (int notch = 0; notch < 60; notch++)
                    gui.processEvent(&wheel);
                REQUIRE(gui.camera.zoom == gui.camera.minimumZoom());
                gui.torusView.lastFrame = SDL_GetTicks();
                glob2test::drawGUI(gui,0);
                REQUIRE(gui.torusView.meshKey[2] < closeUp);
                REQUIRE(gui.view.render.detail.strategic == 1);
                REQUIRE(gui.torusView.pick(cx, cy, afterX, afterY));
                REQUIRE(std::abs(TorusGeometry::wrappedDelta(beforeX, afterX, gui.game.map.getW()*32)) <= 2);
                REQUIRE(std::abs(TorusGeometry::wrappedDelta(beforeY, afterY, gui.game.map.getH()*32)) <= 2);
                REQUIRE(glGetError() == GL_NO_ERROR);
                saveFrame("torus-overview.bmp");
                gui.torusView.reset();
                glob2test::drawGUI(gui,0);
                REQUIRE(gui.camera.zoom == gui.camera.minimumZoom());
                const auto center = gui.camera.screenToWorld(cx, cy);
                REQUIRE(std::abs(TorusGeometry::wrappedDelta(beforeX, int(center.first), gui.game.map.getW()*32)) <= 34);
                REQUIRE(std::abs(TorusGeometry::wrappedDelta(beforeY, int(center.second), gui.game.map.getH()*32)) <= 34);
                saveFrame("flat-overview.bmp");
                gui.camera.zoom = 1;
                gui.updateCamera();
                glob2test::drawGUI(gui,0);
            }
            std::cout << "Manual/automatic modes, saved option and pointer hold passed\n";
            std::cout << "Navigation, GL state, picking and reload lifecycle passed\n";
            // Reuse the renderer across changing map shapes at one window size.
            // This catches stale fitting/mesh caches as well as tall-map apertures.
            TorusView rectangularView;
            for (const auto &size : {std::make_pair(64, 128), std::make_pair(512, 64),
                                     std::make_pair(64, 512), std::make_pair(128, 128)})
            {
                GameGUI rectangular;
                rectangular.init();
                makeTorusMapFixture(rectangular.game, size.first, size.second);
                rectangular.localPlayer = rectangular.localTeamNo = 0;
                rectangular.adjustLocalTeam();
                rectangularView.reset();
                rectangularView.toggle();
                int vx = 0, vy = 0;
                // The ring shares the flat view's zoom; fully zoomed out it
                // fits the view, whatever the map's shape.
                const float farthest = std::min(1.f, std::max(960.f / (size.first * 32), 720.f / (size.second * 32)));
                for (float phase : {0.f, .1f, .5f, 1.f})
                {
                    rectangularView.amount = phase;
                    rectangularView.lastFrame = SDL_GetTicks();
                    REQUIRE(rectangularView.draw(glob2test::sceneOf(rectangular.game),rectangular.game.gui, 0, Game::DRAW_WHOLE_MAP, vx, vy, 960, 720, farthest));
                    REQUIRE(glGetError() == GL_NO_ERROR);
                    // Picking the original screen center must still reach the
                    // same map location after each step of the transition.
                    int px, py;
                    REQUIRE(rectangularView.pick(480, 368, px, py));
                    const int expectedX = TorusPicking::worldPixel(rectangularView.pickU, rectangularView.originX, size.first);
                    const int expectedY = TorusPicking::worldPixel(rectangularView.pickV, rectangularView.originY, size.second);
                    REQUIRE(std::abs(TorusGeometry::wrappedDelta(px, expectedX, size.first * 32)) <= 2);
                    REQUIRE(std::abs(TorusGeometry::wrappedDelta(py, expectedY, size.second * 32)) <= 2);
                }
                REQUIRE(rectangularView.ringMapAspect == float(size.first) / size.second);
                for (const auto &vertex : rectangularView.vertices)
                {
                    float x = vertex.position[0] / vertex.position[3];
                    float y = vertex.position[1] / vertex.position[3];
                    REQUIRE((std::isfinite(x) && std::isfinite(y)));
                    REQUIRE((x >= 0 && x <= 960)); // The distant rim may crop vertically.
                }
                rectangularView.setViewport(size.first - 1, size.second - 1);
                REQUIRE(rectangularView.draw(glob2test::sceneOf(rectangular.game),rectangular.game.gui, 0, Game::DRAW_WHOLE_MAP, vx, vy, 960, 720, farthest));
                int hits = 0;
                for (int y = 100; y < 700; y += 40)
                    for (int x = 100; x < 900; x += 40)
                    {
                        int px, py;
                        if (rectangularView.pick(x, y, px, py))
                        {
                            REQUIRE((px >= 0 && px < size.first * 32 && py >= 0 && py < size.second * 32));
                            ++hits;
                        }
                    }
                REQUIRE(hits > 10);
            }
            std::cout << "Rectangular-map rendering, fitting, picking and cache changes passed\n";

#endif
        }
    }
}
};

TEST_SUITE("TorusRender")
{
    TEST_CASE("programmable GL fatal torus fallback advances animation once [display][isolated]") {
        TorusRenderIntegrationTest::devicePhaseFallback(GAGCore::RendererBackend::ProgrammableGL);
    }
    TEST_CASE("SDL GPU fatal torus fallback advances animation once [display][isolated]") {
        TorusRenderIntegrationTest::devicePhaseFallback(GAGCore::RendererBackend::SDLGPU);
    }
    TEST_CASE("programmable GL retries a submitted final torus overlay coherently [display][isolated]") {
        TorusRenderIntegrationTest::deviceOverlayRetry(GAGCore::RendererBackend::ProgrammableGL);
    }
    TEST_CASE("SDL GPU retries a submitted final torus overlay coherently [display][isolated]") {
        TorusRenderIntegrationTest::deviceOverlayRetry(GAGCore::RendererBackend::SDLGPU);
    }
    TEST_CASE("programmable GL captures large logical maps beyond the window [display][isolated][artifacts]") {
        TorusRenderIntegrationTest::deviceCapture(GAGCore::RendererBackend::ProgrammableGL);
    }
    TEST_CASE("SDL GPU captures large logical maps beyond the window [display][isolated][artifacts]") {
        TorusRenderIntegrationTest::deviceCapture(GAGCore::RendererBackend::SDLGPU);
    }
    TEST_CASE("programmable GL torus progresses under live terrain page pressure [display][isolated][artifacts]") {
        TorusRenderIntegrationTest::liveTerrainPressure(GAGCore::RendererBackend::ProgrammableGL);
    }
    TEST_CASE("SDL GPU torus progresses under live terrain page pressure [display][isolated][artifacts]") {
        TorusRenderIntegrationTest::liveTerrainPressure(GAGCore::RendererBackend::SDLGPU);
    }
    TEST_CASE("native tiled capture pixels and allocation fallback [display]") { TorusRenderIntegrationTest::tiledCapture(); }
    TEST_CASE("HD tiled capture interiors and gutters match whole-map pixels [display]") { TorusRenderIntegrationTest::tiledCapture(true); }
	TEST_CASE("game rendering; picking and cache changes in software rendering [writes-preferences]") { TorusRenderIntegrationTest::run(false, 1120, 720); }
	TEST_CASE("game rendering; picking and cache changes in OpenGL [display][writes-preferences]") { TorusRenderIntegrationTest::run(true, 1120, 720); }
	TEST_CASE("game rendering at triple UI scale in OpenGL [display:1920x1440][writes-preferences]")
	{
		glob2test::ScopedEnvironment scale("GLOB2_UI_SCALE", "3");
		TorusRenderIntegrationTest::run(true, 1920, 1440);
	}
}
