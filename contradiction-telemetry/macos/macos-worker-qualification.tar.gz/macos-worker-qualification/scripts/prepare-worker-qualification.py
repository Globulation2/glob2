import pathlib,subprocess,json,sys,shutil,copy,hashlib,platform
B=pathlib.Path('/Users/bradley/glob2/artifacts/gradient-contradictions-20261018/macos-next-round');R=pathlib.Path('/Users/bradley/.codex/worktrees/adaptive-resource-gradients/glob2');sys.path.insert(0,str(R));Q=B/'worker-qualification';Q.mkdir(exist_ok=True)
from tools.tournaments.bundles import package_identity,register_bundle
from tools.tournaments.common import atomic_json,store_artifact,file_hash
from tools.tournaments.coordinator import Coordinator
from tools.resource_gradient_distributed import make_experiment,digest
assert package_identity()=='ba1ad34a55e7c54637d5579a93a64d356340f464060a6452e9f026ec051fd603'
prov=json.loads((B/'runtime-provenance.json').read_text());assert prov['native_qualification_passed'];assert file_hash(B/'bin/glob2')==prov['binary_sha256'];assert json.loads((B/'qualification/QUALIFIED.json').read_text())['status']=='native_fixture_qualified'
for p,info in prov['dependencies'].items():assert file_hash(p)==info['sha256'],p
deps={};system=set()
for line in (Q/'dyld-help.log').read_text().splitlines():
 if not line.startswith('dyld[') or '> ' not in line:continue
 name=line.split('> ',1)[1]
 if name.startswith('/opt/homebrew/'):
  n=pathlib.Path(name);assert n.is_file();deps[name]={'sha256':file_hash(n),'bytes':n.stat().st_size,'resolved_path':str(n.resolve())}
 elif name.startswith('/usr/lib/') or name.startswith('/System/'):system.add(name)
 else:assert name==str(B/'bin/glob2'),name
assert len(deps)>=len(prov['dependencies'])
source=Q/'bundle-source';source.mkdir(exist_ok=True)
assets=json.loads((B/'asset-sha256.json').read_text())
for name,sha in assets.items():
 assert file_hash(B/name)==sha;dest=source/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(B/name,dest)
(source/'bin').mkdir(exist_ok=True);shutil.copy2(B/'bin/glob2',source/'bin/glob2')
for n in ['runtime-provenance.json','asset-sha256.json','collection-contract.json']:shutil.copy2(B/n,source/n)
atomic_json(source/'external-dependency-lock.json',dict(platform=platform.platform(),dependencies=deps,system_dyld_dependencies=sorted(system),scope='Host-pinned existing dependencies, no library modifications. Recheck hashes before worker launch.'))
from tools.resource_gradient_dataset import CONTRADICTION_CONTRACT,canonical_hash
options=dict(contradiction_contract_sha256=canonical_hash(CONTRADICTION_CONTRACT),release=1,optimization='O3',model_sha256=prov['model_sha256'],header_sha256=prov['header_sha256'],contract_canonical_sha256=prov['contract_canonical_sha256'],asset_manifest_sha256=prov['assets']['asset_manifest_sha256'],runtime_provenance=prov,external_dependency_lock_sha256=file_hash(source/'external-dependency-lock.json'),resource_gradient_collection_threads=1,affinity='unavailable-on-macOS; job-explicit-single-participant')
bundle=register_bundle(source,Q/'bundles','bin/glob2',prov['source_revision'],options=options);atomic_json(Q/'registered-bundle.json',bundle)
job0=json.loads((B/'qualification/job.json').read_text());cohort=job0['labels']['resource_gradient']['cohort'];spec=job0['labels']['resource_gradient']['actual_spec'];mp=B/'qualification/map.map.gz';maps=[dict(group=digest(spec)[:16],spec=spec,path=str(mp),sha256=file_hash(mp))]
manifest=make_experiment([spec],maps,[bundle],cohort,ticks=2048);manifest['id']='contradiction-mac-transport-20261018'
job=manifest['jobs'][0];job['config']['resource_gradient_collection']['threads']=1;job['outputs'].update(telemetry=['checksums'],saves=['final']);job['outputs']['required']+=['world.checksums','snapshot.checksums','game.replay.checksums','final.game.gz']
experiment=Q/'experiment';store_artifact(mp,experiment/'artifacts',compress=False);c=Coordinator.submit(experiment,manifest,[Q/'bundles'/bundle['id']]);c.close()
host=dict(name='macbook-local',transport='local',directory=str(Q/'worker-root'),slots=1,collect_slots=1,cpu_ids=None,participants_per_game=None,builds=[bundle['id']],disk_reserve_bytes=2*1024**3,spool_budget_bytes=2*1024**3,cache_budget_bytes=1024**3)
atomic_json(Q/'hosts.json',[host]);proposed=dict(host,slots=6,collect_slots=2,directory=str(B.parent/'round-002-local-worker-root'),spool_budget_bytes=4*1024**3,cache_budget_bytes=2*1024**3)
atomic_json(Q/'proposed-host-round002.json',proposed);atomic_json(Q/'PREPARED.json',dict(bundle_id=bundle['id'],binary_sha256=file_hash(source/'bin/glob2'),package_id=package_identity(),dependency_count=len(deps),cohort=cohort,experiment=str(experiment),host=host,limitations=['No CPU affinity onmacOS; every eligible job must freeze resource_gradient_collection.threads=1.','Six slots proposed for both job pools: Linux worst observedRSS2.292GiB implies13.8GiB plusOS/Codex headroom on24GiB. Explicit memory limit not set.']))
print(json.dumps(dict(bundle_id=bundle['id'],external_dependencies=len(deps),experiment=str(experiment))))
