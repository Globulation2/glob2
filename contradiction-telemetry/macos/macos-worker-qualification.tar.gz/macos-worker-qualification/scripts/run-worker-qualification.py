import pathlib,json,sys,subprocess,datetime,os
B=pathlib.Path('/Users/bradley/glob2/artifacts/gradient-contradictions-20261018/macos-next-round');Q=B/'worker-qualification';R=pathlib.Path('/Users/bradley/.codex/worktrees/adaptive-resource-gradients/glob2');sys.path.insert(0,str(R))
from tools.tournaments.bundles import package_identity,inspect_bundle
from tools.tournaments.common import file_hash
assert package_identity()=='ba1ad34a55e7c54637d5579a93a64d356340f464060a6452e9f026ec051fd603'
bundle=json.loads((Q/'registered-bundle.json').read_text());directory=Q/'bundles'/bundle['id'];inspect_bundle(directory)
lock=json.loads((directory/'external-dependency-lock.json').read_text());assert all(file_hash(p)==d['sha256'] for p,d in lock['dependencies'].items())
command=[sys.executable,'-m','tools.tournaments','run',str(Q/'experiment'),'--hosts',str(Q/'hosts.json')]
(Q/'run-command.json').write_text(json.dumps(dict(command=command,cwd=str(R),package_id=package_identity(),external_dependencies_verified=len(lock['dependencies']),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),worker_config=json.loads((Q/'hosts.json').read_text()),source_or_helpers_modified=False),indent=2)+'\n')
p=subprocess.run(command,cwd=R);(Q/'run-status.json').write_text(json.dumps(dict(returncode=p.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n');raise SystemExit(p.returncode)
