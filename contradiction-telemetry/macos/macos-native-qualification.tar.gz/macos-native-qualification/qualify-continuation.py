import pathlib,json,hashlib,subprocess,datetime
B=pathlib.Path('/Users/bradley/glob2/artifacts/gradient-contradictions-20261018/macos-next-round');Q=B/'qualification';ref=Q/'linux-continuation';checkpoint=Q/'linux-checkpoint-2048.game.gz';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert h(checkpoint)=='6b1c0c032a33975f2816ae64728d7d8fcb65252a7b3d74c2b66aeb250587e3ef'
command=json.loads((ref/'command.json').read_text());required=['world.checksums','snapshot.checksums','game.replay.checksums','game.replay','final.game.gz','gradient-episodes.csv','gradient-quality.csv','gradient-planning-quality.csv','gradient-contradictions.csv']+[f'checkpoint-{t}.game.gz' for t in [2560,3072,3584,4096]];report=dict(status='running',checkpoint_sha256=h(checkpoint),linux_reference_command=command,runs=[])
for threads in [1,4]:
 out=Q/f'mac-continuation-t{threads}';out.mkdir(exist_ok=True)
 args=[str(B/'bin/glob2'),'game','run','--gpu','off','--compute-telemetry','off','--load-game',str(checkpoint),'--ticks','4096','--compute-threads',str(threads),'--telemetry','checksums','--write-replay','--save','final','--save','every:512','--resource-gradient-probe','--output-dir',str(out),'--profile',str(out/'profile')]
 (out/'command.json').write_text(json.dumps(args,indent=2)+'\n')
 with (out/'stdout.log').open('w') as log,(out/'stderr.log').open('w') as err:p=subprocess.run(args,cwd=B,stdout=log,stderr=err)
 assert p.returncode==0,p.returncode
 r=dict(threads=threads,returncode=p.returncode,hashes={},mismatches=[])
 for n in required:
  actual=h(out/n);expected=h(ref/n);r['hashes'][n]=dict(mac=actual,linux=expected,bytes=(out/n).stat().st_size)
  if actual!=expected:r['mismatches'].append(n)
 report['runs'].append(r);report['status']='mismatch' if r['mismatches'] else 'running';(Q/'continuation-status.json').write_text(json.dumps(report,indent=2)+'\n')
 if r['mismatches']:raise SystemExit('Continuation mismatch '+','.join(r['mismatches']))
report['status']='passed';report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(Q/'continuation-status.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
