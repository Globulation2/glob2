import pathlib,subprocess,json,os,time,datetime,hashlib,shutil,signal,platform
B=pathlib.Path('/Users/bradley/glob2/artifacts/gradient-contradictions-20261018/macos-next-round');R=pathlib.Path('/Users/bradley/.codex/worktrees/adaptive-resource-gradients/glob2')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert shutil.disk_usage(R).free>=6*1024**3
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='f65c8d1698f6deefc4820209e69ad704f91d5776',head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
files=[p for folder in ['src','libgag','libusl','scons'] for p in (R/folder).rglob('*') if p.is_file() and p.suffix in ['.h','.cpp','.c','.py','.in']]+[R/'SConstruct',R/'src/SConscript']
source={str(p.relative_to(R)):h(p) for p in files};(B/'native-source-sha256.json').write_text(json.dumps(source,indent=2)+'\n')
args=['scons','release=1','CXXFLAGS=','dev_fast=0','pch=0','unity=0','--build=build/gradient-throughput-release','-j4','build/gradient-throughput-release/src/glob2']
env=dict(os.environ,CCACHE='1',CCACHE_MAXSIZE='12G')
meta=dict(source_revision=head,source_manifest_sha256=h(B/'native-source-sha256.json'),model_sha256=h(R/'tools/models/resource-gradient.json'),header_sha256=h(R/'src/map/gradient/ResourceGradientModel.h'),argv=args,cwd=str(R),environment={k:env[k] for k in ['CCACHE','CCACHE_MAXSIZE']},platform=platform.platform(),compiler=subprocess.check_output(['clang++','--version'],text=True),disk_free_before=shutil.disk_usage(R).free,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),disk_guard_min_bytes=2*1024**3,previous_binary_sha256=h(R/'build/gradient-throughput-release/src/glob2'))
(B/'build-command.json').write_text(json.dumps(meta,indent=2)+'\n')
with (B/'build.log').open('w') as log:
 p=subprocess.Popen(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (B/'build-pid.json').write_text(json.dumps(dict(supervisor=os.getpid(),scons=p.pid))+'\n');guard=False
 while p.poll() is None:
  free=shutil.disk_usage(R).free
  if free<2*1024**3:
   guard=True;os.killpg(p.pid,signal.SIGTERM);break
  time.sleep(5)
 p.wait()
 status=dict(returncode=p.returncode,disk_guard_triggered=guard,disk_free_after=shutil.disk_usage(R).free,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(B/'build-status.json').write_text(json.dumps(status,indent=2)+'\n')
 if p.returncode:raise SystemExit(p.returncode)
 assert all(h(R/k)==v for k,v in source.items()),'Native source changed during build'
 binary=R/'build/gradient-throughput-release/src/glob2';frozen=B/'bin/glob2';frozen.parent.mkdir(exist_ok=True);shutil.copy2(binary,frozen)
 dylibs=subprocess.check_output(['otool','-L',str(frozen)],text=True);(B/'otool-L.txt').write_text(dylibs)
 deps={}
 for line in dylibs.splitlines()[1:]:
  path=pathlib.Path(line.strip().split(' (')[0])
  if path.is_file():deps[str(path)]={'sha256':h(path),'bytes':path.stat().st_size}
 meta.update(binary_sha256=h(frozen),binary_bytes=frozen.stat().st_size,dependencies=deps,qualified=False,note='Frozen ordinary-release Mac runtime; no game qualification or tournament started.')
 (B/'runtime-provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
