import pathlib,json,hashlib,gzip,subprocess,datetime,shutil
B=pathlib.Path('/Users/bradley/glob2/artifacts/gradient-contradictions-20261018/macos-next-round');Q=B/'qualification';Q.mkdir(exist_ok=True);D=B.parent/'qualification-distributed';binary=B/'bin/glob2';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(binary)=='29493368329536b6ad923ef38ba21a208926633e06217a8c09b0568d0f2ada7c'
receipts=[json.loads(p.read_text()) for p in (D/'results').glob('*.json')];reference=next(r for r in receipts if r['host']=='devlaptop.local');job=reference['job'];(Q/'linux-reference-receipt.json').write_text(json.dumps(reference,indent=2)+'\n');(Q/'job.json').write_text(json.dumps(job,indent=2)+'\n')
mp=Q/'map.map.gz';shutil.copy2(D/'artifacts'/job['inputs']['map']['sha256'],mp);assert h(mp)==job['inputs']['map']['raw_sha256']
required=['world.checksums','snapshot.checksums','game.replay.checksums','final.game.gz','gradient-episodes.csv','gradient-quality.csv','gradient-planning-quality.csv','gradient-contradictions.csv'];ref=Q/'linux-reference';ref.mkdir(exist_ok=True)
for r in receipts:
 assert r['accepted'] and r['exit_code']==0
 for n in required:
  a=next(a for a in r['artifacts'] if a['path']==n);data=(D/'artifacts'/a['sha256']).read_bytes();assert hashlib.sha256(data).hexdigest()==a['sha256'];data=gzip.decompress(data) if a['encoding']=='gzip' else data;assert hashlib.sha256(data).hexdigest()==a['raw_sha256'];assert a['raw_sha256']==next(a for a in reference['artifacts'] if a['path']==n)['raw_sha256']
  if r==reference:(ref/n).write_bytes(data)
report={'status':'running','fixture':dict(map_sha256=h(mp),game_seed=job['seeds']['game'],ticks=2048,players=job['config']['players'],external_orders=[],probe=True,policy='adaptive32'),'mac_binary_sha256':h(binary),'linux_hosts':[r['host'] for r in receipts],'runs':[],'limitations':['Small three-AI fixture; no new gameplay policy or performance claim.','Platform-specific metadata paths/profile settings exempt; all eight raw simulation/diagnostic artifacts compared unchanged.']}
(Q/'status.json').write_text(json.dumps(report,indent=2)+'\n')
for threads in [1,4]:
 out=Q/f'mac-t{threads}';out.mkdir(exist_ok=True)
 args=[str(binary),'game','run','--output-dir',str(out),'--profile',str(out/'profile'),'--map-file',str(mp),'--game-seed',str(job['seeds']['game']),'--ticks','2048']
 for player in job['config']['players']:args+=['--player',player]
 args+=['--save','final','--telemetry','checksums','--resource-gradient-probe','--gpu','off','--compute-telemetry','off','--compute-threads',str(threads)]
 (out/'command.json').write_text(json.dumps(args,indent=2)+'\n')
 with (out/'stdout.log').open('w') as log,(out/'stderr.log').open('w') as err:p=subprocess.run(args,cwd=B,stdout=log,stderr=err)
 run={'threads':threads,'returncode':p.returncode,'hashes':{},'mismatches':[]};assert p.returncode==0,(out,p.returncode)
 for n in required:
  actual=h(out/n);expected=h(ref/n);run['hashes'][n]={'mac':actual,'linux':expected,'bytes':(out/n).stat().st_size};
  if actual!=expected:run['mismatches'].append(n)
 report['runs'].append(run);report['status']='mismatch' if run['mismatches'] else 'running';(Q/'status.json').write_text(json.dumps(report,indent=2)+'\n')
 if run['mismatches']:raise SystemExit('Parity mismatch: '+','.join(run['mismatches']))
report['status']='passed';report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(Q/'status.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
