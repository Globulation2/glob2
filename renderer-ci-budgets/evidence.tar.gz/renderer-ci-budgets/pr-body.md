Serial renderer-switch tests repeatedly exhaust their six-minute total limit on hosted software GL while frames continue advancing and controls remain stable. Two-frame waits reach 4.55 seconds and screenshots 10.7 seconds. The long file also occupies most of one general Chromium job.

Give serial switches bounded 12-minute limits and recording/backend-pair cases 16 minutes. Run the same cases in three single-worker serial shards and one single-worker threaded job. Keep all assertions, threaded limits, the 60-minute job limit and browser concurrency. Update the verification guide.

Validation: exact before/after inventory matches all 202 moved/general cases; the other 19 matrix entries are unchanged. A clean candidate browser build passes all four new job commands (16 passed, five capability skips) and all 24 determinism/scripting cases, with verified source and binary manifests. All 567 build contracts pass (two optional skips); 309 documents pass link checks. Raw commands, logs, screenshots/media, traces and timings are linked in a comment.

This is functional timeout repair, with no performance-savings claim. A fresh full master pass under the new coverage-policy fingerprint is still required; no coverage tier is reduced.
