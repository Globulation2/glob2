from pathlib import Path
from collections import Counter
import subprocess,shlex,json,os,re
root=Path.cwd();out=root/'artifacts/ci-recovery/renderer-ci-budgets';node='/home/bradley/.local/share/glob2/development/toolchains/emscripten/Linux-x86_64-88a621bc131cd4954413aa39/node/24.19.0_64bit/bin/node';cli=str(root/'browser/node_modules/@playwright/test/cli.js')
def inventory(filename):
 matrix=json.loads((out/filename).read_text());counts=Counter();jobs=[]
 for row in matrix:
  if not re.fullmatch(r'chromium [1-5]/5|chromium serial renderer [1-3]/3|chromium threaded renderer',row['name']):continue
  args=shlex.split(row['command']);args=args[args.index('test')+1:];command=[node,cli,'test',*args,'--list','--reporter=json'];p=subprocess.run(command,cwd=root/'browser',env=dict(os.environ,CI='1',GLOB2_TEST_RENDERER=row.get('renderer','software')),capture_output=True,text=True,check=True);r=json.loads(p.stdout);cases=[]
  def collect(suite,parents=()):
   for spec in suite.get('specs',[]):
    for test in spec['tests']:cases.append((test['projectName'],spec['file'],*parents,spec['title']))
   for child in suite.get('suites',[]):collect(child,(*parents,child['title']))
  for suite in r['suites']:collect(suite)
  counts.update(cases);jobs.append({'name':row['name'],'command':command,'cases':cases});print(row['name'],len(cases),flush=True)
 (out/(filename.removesuffix('.json')+'-inventory.json')).write_text(json.dumps(jobs,indent=2)+'\n');return counts
before=inventory('matrix-before.json');after=inventory('matrix-after.json');result={'beforeCount':before.total(),'afterCount':after.total(),'missing':list((before-after).elements()),'added':list((after-before).elements()),'sameMultiset':before==after};(out/'inventory-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert before==after
