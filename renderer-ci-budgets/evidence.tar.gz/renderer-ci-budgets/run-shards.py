from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer
from concurrent.futures import ThreadPoolExecutor
import importlib.util,threading,subprocess,os,json,shlex,sys
root=Path.cwd();base=root/'artifacts/ci-recovery/renderer-ci-budgets';source=root/'build/ci-recovery-web'
spec=importlib.util.spec_from_file_location('serve',root/'browser/serve.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
node='/home/bradley/.local/share/glob2/development/toolchains/emscripten/Linux-x86_64-88a621bc131cd4954413aa39/node/24.19.0_64bit/bin/node'
rows=[r for r in json.loads((root/'.github/scripts/ci_browser_matrix.json').read_text()) if r['name'].startswith('chromium serial renderer') or r['name']=='chromium threaded renderer']
def run(row):
 out=base/row['name'].replace(' ','-').replace('/','-');out.mkdir(exist_ok=True);http_log=(out/'http.log').open('w')
 class Handler(module.Handler):
  def log_message(self,format,*args):http_log.write((format%args)+'\n');http_log.flush()
 server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(source)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 env=dict(os.environ,GLOB2_TEST_URL=f'http://127.0.0.1:{server.server_port}',GLOB2_TEST_RENDERER='software',CI='1',LIBGL_ALWAYS_SOFTWARE='1',GLOB2_TEST_BUILD_DIR=str(source));env.pop('DISPLAY',None)
 args=shlex.split(row['command']);args=args[args.index('test')+1:];cmd=[node,str(root/'browser/node_modules/@playwright/test/cli.js'),'test',*args,'--trace=off','--reporter=list','--output='+str(out/'results')]
 try:
  with (out/'playwright.log').open('w') as log:r=subprocess.run(cmd,cwd=root/'browser',env=env,stdout=log,stderr=subprocess.STDOUT)
  rec={'job':row['name'],'command':cmd,'exitCode':r.returncode,'testSource':'76f558837','runtimeSource':'562963996bc41fbfe01a26b062a81be6ca1772be','productionUnchanged':True};(out/'result.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True);return rec
 finally:server.shutdown();server.server_close();thread.join();http_log.close()
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,rows))
(base/'shard-results.json').write_text(json.dumps(results,indent=2)+'\n');sys.exit(any(r['exitCode'] for r in results))
