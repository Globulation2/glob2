import hashlib,json,subprocess
from pathlib import Path
p=Path('artifacts/hiring-study/quotas').resolve();out=p/'controlled-verification';out.mkdir(exist_ok=False)
binary=p/'glob2';save=p/'controlled-save/initial.game.gz';rows=[]
for n in [1,2,4,8]:
 for mode in ['disabled','owner','pool']:
  target=out/f'{mode}-n{n}';target.mkdir()
  command=[str(binary),'game','run','--load-game',str(save),'--ticks','64','--compute-threads',str(n),'--gpu','off','--output-dir',str(target),'--telemetry','checksums','--write-replay','--save','final']
  if mode!='disabled':command+=['--hiring-schedule','4:4:128:split','--hiring-execution',mode,'--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds','--telemetry','hiring-shadow']
  with (target/'engine.log').open('w') as f:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
  hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in target.rglob('*') if f.is_file() and (f.suffix in ['.checksums','.replay'] or f.name=='final.game.gz')}
  study=list(target.rglob('*hiring*json'))
  if study:
   report=json.loads(study[0].read_text());digest=report['output_digest'];metric=report['planner_metrics'];print(mode,n,digest,metric['rankedCandidates'],metric['coordinatedTeams'],flush=True)
  else: digest=None;metric={}
  rows.append({'participants':n,'mode':mode,'command':command,'hashes':hashes,'candidate_digest':digest,'metrics':metric})
assert all(r['hashes']==rows[0]['hashes'] for r in rows)
active=[r for r in rows if r['mode']!='disabled'];assert all(r['candidate_digest']==active[0]['candidate_digest'] for r in active)
assert all(r['metrics']['rankedCandidates']>0 and r['metrics']['coordinatedTeams']>0 for r in active)
(out/'verification.json').write_text(json.dumps({'identical':True,'nonempty_coordinated_outputs':True,'rows':rows},indent=2))
