import json,os,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parents[4];B=R/'artifacts/ci-recovery';D=Path(__file__).resolve().parent;W=B/'browser-recovery-70319'
env=dict(os.environ,GLOB2_TEST_URL='http://127.0.0.1:8845',GLOB2_TEST_BUILD_DIR=str(D.parent/'runtime'),GLOB2_BUILD_DIR=str(R/'build/local-release'),LD_LIBRARY_PATH=str(R/'build/sdl3-ci/prefix/lib'))
env['PATH']=str(B/'node/node_modules/.bin')+':'+env['PATH'];env.pop('GLOB2_CHROMIUM_ANGLE',None)
allowed=sorted(os.sched_getaffinity(0));cores={}
for cpu in allowed:
    p=Path('/sys/devices/system/cpu')/('cpu'+str(cpu))/'topology'
    cores.setdefault(((p/'physical_package_id').read_text().strip(),(p/'core_id').read_text().strip()),cpu)
selected=list(cores.values())[:2];affinity=','.join(map(str,selected));assert len(selected)==2
state=dict(runtime_limit='Compiled70319productionidenticalto9e903;diagnosticnotfreshbuildacceptance',pid=os.getpid(),revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),compiled_runtime_revision='70319a0da004a6473ef974ceb2415a9ccf072488',phase='running original focused cases',physical_core_cpus=selected,results=[],note='Unchanged original cases/assertions/timeouts; private current-source runtime. Two physical cores; default Chromium ANGLE matches actual hosted environment (no forced backend). Read-only page/worker observations; not timing acceptance evidence. Root/full-browser/helper/pinned dependencies untouched.')
def save():(D/'status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
cases=[(project+'-'+mode+'-fullscreen','renderer-switching.spec.js',mode+': canvas replacement preserves active fullscreen host','software',project)for project in ['firefox','chromium','webkit']for mode in ['serial','threaded']]+[(project+'-menu','viewport.spec.js','menus follow the viewport and keep their controls clickable','software',project)for project in ['chromium','firefox','webkit']]+[(project+'-hidpi','viewport.spec.js','uses the renderer-appropriate backing resolution','software',project)for project in ['chromium','firefox','webkit']]

with(D/'server.log').open('w')as sl:
    server=subprocess.Popen(['python3',str(B/'serve_ci_layout.py'),'8845','--directory',str(D.parent/'runtime')],stdout=sl,stderr=subprocess.STDOUT)
    try:
        for name,file,grep,renderer,mode in cases:
            probes=D/'probes';probes.mkdir(exist_ok=True)
            (probes/(name+'.spec.cjs')).write_text('require('+json.dumps(str(D.parent/'fullscreen-baseline-9e903/geometry.cjs'))+');require('+json.dumps(str(W/'browser/tests'/file))+');')
            config=D/(name+'.config.cjs');config.write_text('const base=require('+json.dumps(str(W/'browser/playwright.config.js'))+');module.exports={...base,testDir:'+json.dumps(str(probes))+',testMatch:['+json.dumps(name+'.spec.cjs')+'],workers:1,reporter:[["list"],["junit"]]};')
            e=dict(env,GLOB2_FIREFOX_HEADED='1',GLOB2_TEST_RENDERER=renderer,PLAYWRIGHT_JUNIT_OUTPUT_FILE=str(D/(name+'-junit.xml')),RECOVERY_OBSERVATION=str(D/(name+'-observation.json')))
            if False:e['GLOB2_SKIN_TEST_THREADS']=mode
            else:e.pop('GLOB2_SKIN_TEST_THREADS',None)
            command=['taskset','-c',affinity,'xvfb-run','-a','-s','-screen 0 2560x2048x24 -noreset','node',str(W/'browser/node_modules/@playwright/test/cli.js'),'test','--config='+str(config),'--project='+mode,'--grep',grep,'--output='+str(D/(name+'-results')),'--trace=off']
            state.update(phase=name,command=command);save();start=time.monotonic()
            with(D/(name+'.log')).open('w')as log:code=subprocess.call(command,cwd=W,env=e,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
            state['results'].append(dict(name=name,exit_code=code,seconds=round(time.monotonic()-start,1)));save()
    finally:server.terminate();server.wait()
state['phase']='finished; inspect actual case results and observations';save()
