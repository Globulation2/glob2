# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: chromium-hidpi.spec.cjs >> high density display >> uses the renderer-appropriate backing resolution
- Location: browser/tests/viewport.spec.js:97:3

# Error details

```
Error: expect(received).toMatch(expected)

Expected pattern: /MainMenuScreen|HandPreferenceScreen|AudioPreferenceScreen|IntroductionOfferScreen/
Received string:  "loading"

Call Log:
- Timeout 30000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [aria-hidden]:
    - status: Starting the game…
    - generic:
      - progressbar
      - generic: 41 of 41 MB
    - combobox
  - generic "Globulation 2" [active] [ref=e3]
```

# Test source

```ts
  1   | const {waitForMainMenu}=require('./main-menu');
  2   | const {clickCreateMap}=require('./editor-controls');
  3   | const {gameURL,clickMainMenu,clickSettingsDone,clickCustomGameStart,clickControl,control}=require('./main-menu');
  4   | const {test, expect} = require('@playwright/test');
  5   | const snapshot = page => page.evaluate(() => glob2Diagnostics.snapshot());
  6   | const screen = (page, name) => name==='MainMenuScreen' ? waitForMainMenu(page) : expect.poll(async () => (await snapshot(page)).screen).toContain(name);
  7   | async function resize(page,width,height,backingScale=1) {
  8   |   await page.setViewportSize({width,height});
  9   |   await expect.poll(async () => { const s=await snapshot(page); return [s.width,s.height]; }).toEqual([width*backingScale,height*backingScale]);
  10  |   expect(await page.locator('#canvas').boundingBox()).toMatchObject({x:0,y:0,width,height});
  11  |   // Input and dimensions can work even when an offscreen surface is never presented.
  12  |   await expect.poll(() => require('./pixels').hasRenderedPixels(page)).toBe(true);
  13  | }
  14  | test.beforeEach(async ({page}) => {
  15  |   await page.goto(gameURL());
> 16  |   await expect.poll(async () => (await snapshot(page)).screen).toMatch(/MainMenuScreen|HandPreferenceScreen|AudioPreferenceScreen|IntroductionOfferScreen/);
      |                                                                ^ Error: expect(received).toMatch(expected)
  17  |   if ((await snapshot(page)).screen.includes('AudioPreferenceScreen')) {
  18  |     await clickControl(page,'audio.silence');
  19  |     await screen(page,'HandPreferenceScreen');
  20  |   }
  21  |   if ((await snapshot(page)).screen.includes('HandPreferenceScreen')) await clickControl(page,'hand.right');
  22  |   await screen(page,'MainMenuScreen');
  23  | });
  24  | test('menus follow the viewport and keep their controls clickable', async ({page}) => {
  25  |   await resize(page,1280,720);
  26  |   await clickMainMenu(page,'settings'); await screen(page,'SettingsScreen');
  27  |   await resize(page,900,650);
  28  |   await clickSettingsDone(page); await screen(page,'MainMenuScreen');
  29  |   await resize(page,1440,900);
  30  |   await clickMainMenu(page,'credits'); await screen(page,'CreditScreen');
  31  |   await page.locator('#canvas').press('Escape'); await screen(page,'MainMenuScreen');
  32  | });
  33  | test('a running match survives resize and its open menu follows the new center', async ({page}, info) => {
  34  |   // Cold texture creation on a headless software GPU can dominate startup.
  35  |   test.setTimeout(120000);
  36  |   await clickMainMenu(page,'custom'); await screen(page,'CustomGameScreen');
  37  |   await clickCustomGameStart(page); // The lobby prepares its selected generated landscape.
  38  |   await expect.poll(async () => (await snapshot(page)).tick, {timeout:60000}).toBeGreaterThan(25);
  39  |   const before=(await snapshot(page)).tick;
  40  |   await resize(page,1400,800); await resize(page,900,650);
  41  |   await expect.poll(async () => (await snapshot(page)).tick).toBeGreaterThan(before);
  42  |   await resize(page,500,400);
  43  |   expect((await snapshot(page)).screenClass).toContain('GameSessionScreen');
  44  |   const small = (await snapshot(page)).tick;
  45  |   await expect.poll(async () => (await snapshot(page)).tick).toBeGreaterThan(small);
  46  |   await resize(page,900,650);
  47  |   const beforeMenu = (await snapshot(page)).frames;
  48  |   await page.locator('#canvas').press('Escape',{delay:80});
  49  |   await expect.poll(async () => (await snapshot(page)).frames).toBeGreaterThan(beforeMenu + 2);
  50  |   await resize(page,1280,720);
  51  |   await page.screenshot({path:info.outputPath('resized-game-menu.png')});
  52  |   await clickControl(page,'quit'); await screen(page,'EndGameScreen');
  53  |   await page.locator('#canvas').press('Enter'); await screen(page,'CustomGameScreen');
  54  | });
  55  | test('editor dialogs and discard controls follow viewport changes', async ({page}) => {
  56  |   await clickMainMenu(page,'editor'); await screen(page,'EditorMainMenu');
  57  |   await clickControl(page,'new-map'); await screen(page,'NewMapScreen');
  58  |   await clickCreateMap(page); await screen(page,'MapEditorScreen');
  59  |   await page.locator('#canvas').press('Escape',{delay:80});
  60  |   await resize(page,1280,720);
  61  |   // Unsaved work is decided on a card over the map, not on a separate page.
  62  |   await clickControl(page,'quit'); await control(page,'choice/1');
  63  |   expect((await snapshot(page)).screen).toContain('MapEditorScreen');
  64  |   await resize(page,1000,800);
  65  |   await clickControl(page,'choice/1'); await screen(page,'EditorMainMenu');
  66  | });
  67  | 
  68  | test('small viewports retain the active screen and continue rendering', async ({page}, info) => {
  69  |   await clickMainMenu(page,'settings'); await screen(page,'SettingsScreen');
  70  |   await resize(page,500,400); await screen(page,'SettingsScreen');
  71  |   await page.screenshot({path:info.outputPath('small-viewport.png')});
  72  |   await resize(page,1100,700); await screen(page,'SettingsScreen');
  73  |   await clickSettingsDone(page); await screen(page,'MainMenuScreen');
  74  | });
  75  | 
  76  | test.describe('initial small viewport', () => {
  77  |   test.use({viewport:{width:500,height:400}});
  78  |   test('starts at the actual browser dimensions', async ({page}) => {
  79  |     expect(await snapshot(page)).toMatchObject({width:500,height:400});
  80  |     await expect.poll(() => require('./pixels').hasRenderedPixels(page)).toBe(true);
  81  |     await clickMainMenu(page,'settings'); await screen(page,'SettingsScreen');
  82  |   });
  83  | });
  84  | 
  85  | test.describe('initial wide viewport', () => {
  86  |   // Not 4:3, so the 800x600 placeholder's CSS fit must not decide the window size.
  87  |   test.use({viewport:{width:1280,height:554}});
  88  |   test('fills the page before any resize', async ({page}) => {
  89  |     expect(await snapshot(page)).toMatchObject({width:1280,height:554});
  90  |     expect(await page.locator('#canvas').boundingBox()).toMatchObject({x:0,y:0,width:1280,height:554});
  91  |     await expect.poll(() => require('./pixels').hasRenderedPixels(page)).toBe(true);
  92  |   });
  93  | });
  94  | 
  95  | test.describe('high density display', () => {
  96  |   test.use({deviceScaleFactor:2});
  97  |   test('uses the renderer-appropriate backing resolution', async ({page}) => {
  98  |     // Firefox loses emulated density when COOP navigation replaces its process.
  99  |     // Reapply the real viewport so this still exercises a genuine 2x display.
  100 |     await page.setViewportSize(page.viewportSize());
  101 |     expect(await page.evaluate(() => devicePixelRatio)).toBe(2);
  102 |     // SDL3 high-density windows size the backing canvas for both software and
  103 |     // WebGL. Control bounds still map to CSS pixels once at the input boundary.
  104 |     const backingScale = 2;
  105 |     await resize(page,1100,750,backingScale);
  106 |     await clickMainMenu(page,'settings'); await screen(page,'SettingsScreen');
  107 |   });
  108 | });
  109 | 
  110 | test('interface scale survives resizing and keeps settings controls clickable', async ({page}, info) => {
  111 |   // Software applies scale immediately; WebGL follows master's restart requirement.
  112 |   test.skip((await snapshot(page)).renderer !== 'software');
  113 |   await clickMainMenu(page,'settings'); await screen(page,'SettingsScreen');
  114 |   await clickControl(page,'display.uiscale');
  115 |   await clickControl(page,'popup/1'); // Interface scale: 125%.
  116 |   await page.setViewportSize({width:1400,height:1000});
```