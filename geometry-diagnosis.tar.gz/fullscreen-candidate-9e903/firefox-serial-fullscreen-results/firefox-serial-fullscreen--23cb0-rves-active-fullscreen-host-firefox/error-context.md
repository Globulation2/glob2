# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: firefox-serial-fullscreen.spec.cjs >> serial: canvas replacement preserves active fullscreen host
- Location: browser/tests/renderer-switching.spec.js:526:3

# Error details

```
Error: control "graphics.renderer" is not available

control "graphics.renderer" is not available

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 30000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [aria-hidden]:
    - status: Starting the game…
    - generic:
      - progressbar
      - generic: 41 of 41 MB
    - combobox
  - generic "Globulation 2" [active] [ref=e3]
```

# Test source

```ts
  1   | // Screens and dialogs publish their interactive controls, keyed by the same
  2   | // stable keys the native harnesses use, with bounds in logical pixels (see
  3   | // ApplicationHost::controlsChanged and glob2Diagnostics.snapshot().controls).
  4   | // Tests drive those real controls rather than mirroring layout arithmetic.
  5   | const {expect} = require('@playwright/test');
  6   | // Layout runs inside the game's animation frame; two frames after a resize or
  7   | // rebuild the published bounds are current.
  8   | const settled = page => page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  9   | // The logical surface always fills the window at one uniform scale, so bounds
  10  | // published for a previous window size (their surface has another aspect
  11  | // ratio) are stale after a resize and must not be clicked.
  12  | // Fullscreen can resize the real window without changing Playwright's
  13  | // configured viewport. Input must follow the live CSS viewport.
  14  | const viewport = page => page.evaluate(() => ({width: innerWidth, height: innerHeight}));
  15  | async function current(page, bounds) {
  16  |   const {width, height} = await viewport(page);
  17  |   return Math.abs(width / bounds.surface.w - height / bounds.surface.h) < 0.02;
  18  | }
  19  | async function control(page, key, {timeout = 30000, enabled = true} = {}) {
  20  |   let found;
  21  |   await expect.poll(async () => {
  22  |     found = await page.evaluate(key => glob2Diagnostics.snapshot().controls[key] || null, key);
  23  |     return Boolean(found && (!enabled || found.enabled) && (await current(page, found)));
> 24  |   }, {timeout, message: `control "${key}" is not available`}).toBe(true);
      |                                                               ^ Error: control "graphics.renderer" is not available
  25  |   await settled(page);
  26  |   return (await page.evaluate(key => glob2Diagnostics.snapshot().controls[key] || null, key)) || found;
  27  | }
  28  | // The first control whose key matches and whose text is the label shown.
  29  | exports.clickByLabel = async (page, keyPattern, label, options = {}) => {
  30  |   const source = keyPattern.source;
  31  |   let key;
  32  |   await expect.poll(async () => {
  33  |     key = await page.evaluate(({source, label}) => {
  34  |       const pattern = new RegExp(source);
  35  |       for (const [key, value] of Object.entries(glob2Diagnostics.snapshot().controls))
  36  |         if (pattern.test(key) && value.label.toLowerCase() === label.toLowerCase()) return key;
  37  |       return null;
  38  |     }, {source, label});
  39  |     return Boolean(key);
  40  |   }, {timeout: options.timeout || 30000, message: `no control matching ${source} labelled "${label}"`}).toBe(true);
  41  |   return exports.clickControl(page, key, options);
  42  | };
  43  | // Logical → CSS pixels: the canvas fills the window at the logical surface size,
  44  | // scaled by any interface scale setting.
  45  | async function css(page, bounds, point) {
  46  |   const {width, height} = await viewport(page);
  47  |   const sx = width / bounds.surface.w, sy = height / bounds.surface.h;
  48  |   return {x: point.x * sx, y: point.y * sy};
  49  | }
  50  | async function center(page, bounds) {
  51  |   return css(page, bounds, {x: bounds.x + bounds.w / 2, y: bounds.y + bounds.h / 2});
  52  | }
  53  | exports.control = control;
  54  | // The control's bounds in CSS pixels, for pixel checks near a known control.
  55  | exports.controlBox = async (page, key, options) => {
  56  |   const requested = {enabled: false, ...options};
  57  |   const bounds = options?.fullyVisible
  58  |     ? await controlOnScreen(page, key, requested) : await control(page, key, requested);
  59  |   const origin = await css(page, bounds, {x: bounds.x, y: bounds.y});
  60  |   const corner = await css(page, bounds, {x: bounds.x + bounds.w, y: bounds.y + bounds.h});
  61  |   return {x: origin.x, y: origin.y, width: corner.x - origin.x, height: corner.y - origin.y};
  62  | };
  63  | // The panel of the host owning a control, in CSS pixels.
  64  | exports.rootBox = async (page, key) => {
  65  |   const bounds = await control(page, key, {enabled: false});
  66  |   const origin = await css(page, bounds, {x: bounds.root.x, y: bounds.root.y});
  67  |   const corner = await css(page, bounds, {x: bounds.root.x + bounds.root.w, y: bounds.root.y + bounds.root.h});
  68  |   return {x: origin.x, y: origin.y, width: corner.x - origin.x, height: corner.y - origin.y};
  69  | };
  70  | // Scroll regions publish every row and card, including ones scrolled out of
  71  | // the window; wheel over the owning panel until the control is on screen.
  72  | // A control's "visible" rect is what its scroll regions leave on screen.
  73  | // Game frames are scheduled by the host, not by requestAnimationFrame, so a
  74  | // scroll shows up in the published bounds only after the next game frame.
  75  | const same = (a, b) => a.x === b.x && a.y === b.y && a.w === b.w && a.h === b.h;
  76  | const shown = bounds => bounds.visible && bounds.visible.w >= Math.min(bounds.w, 8) && bounds.visible.h >= Math.min(bounds.h, 8);
  77  | async function controlOnScreen(page, key, options) {
  78  |   let bounds = await control(page, key, options);
  79  |   // Clicking needs only an exposed hit area; rendered-text checks need the
  80  |   // complete control, including glyphs below a scroll-region clipping edge.
  81  |   const exposed = options?.fullyVisible
  82  |     ? b => b.visible && b.visible.w >= b.w && b.visible.h >= b.h : shown;
  83  |   for (let attempt = 0; attempt < 60; ++attempt) {
  84  |     if (exposed(bounds)) {
  85  |       // Wait until the bounds hold still before clicking.
  86  |       await page.waitForTimeout(150);
  87  |       const again = await control(page, key, options);
  88  |       if (same(again, bounds) && same(again.visible, bounds.visible)) return bounds;
  89  |       bounds = again;
  90  |       continue;
  91  |     }
  92  |     let anchor = {x: bounds.root.x + bounds.root.w / 2, y: bounds.root.y + bounds.root.h / 2};
  93  |     // Popup controls report the host surface as their root, while their narrow
  94  |     // scroll panel can sit at an edge. Wheel over an exposed sibling row so
  95  |     // the actual popup receives the gesture, in either scroll direction.
  96  |     if (/^popup\/\d+$/.test(key)) {
  97  |       const rows = await page.evaluate(() => Object.entries(glob2Diagnostics.snapshot().controls)
  98  |         .filter(([key, row]) => /^popup\/\d+$/.test(key) && row.visible?.w > 0 && row.visible?.h > 0)
  99  |         .map(([, row]) => row.visible).sort((a, b) => a.y - b.y));
  100 |       if (rows.length) {
  101 |         const row = rows[Math.floor(rows.length / 2)];
  102 |         anchor = {x: row.x + row.w / 2, y: row.y + row.h / 2};
  103 |       }
  104 |     }
  105 |     const root = await css(page, bounds, anchor);
  106 |     await page.mouse.move(root.x, root.y);
  107 |     const distance = bounds.y + bounds.h / 2 - anchor.y;
  108 |     // SDL's browser wheel converts 100 CSS pixels into one scroll step. A
  109 |     // single notch moves only about one row, so use a bounded multi-notch
  110 |     // gesture for distant controls and re-read the real layout after each.
  111 |     const delta = Math.max(120, Math.min(600, bounds.root.h * 0.75, Math.abs(distance) * 3));
  112 |     await page.mouse.wheel(0, (Math.sign(distance) || 1) * delta);
  113 |     await page.waitForTimeout(150);
  114 |     bounds = await control(page, key, options);
  115 |   }
  116 |   throw new Error(`control "${key}" cannot be scrolled into view`);
  117 | }
  118 | // Click the on-screen part of the control.
  119 | async function visibleCenter(page, bounds) {
  120 |   const v = shown(bounds) ? bounds.visible : bounds;
  121 |   return css(page, bounds, {x: v.x + v.w / 2, y: v.y + v.h / 2});
  122 | }
  123 | // Input is consumed at the game's next host frame; give that frame a moment
  124 | // to run so a test's next step (a resize, say) cannot overtake the click. A
```