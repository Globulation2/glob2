# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: firefox-threaded-fullscreen.spec.cjs >> threaded: canvas replacement preserves active fullscreen host
- Location: browser/tests/renderer-switching.spec.js:526:3

# Error details

```
Error: main menu is not showing after declining the introduction

main menu is not showing after declining the introduction

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 60000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [aria-hidden]:
    - status: Starting the game…
    - generic:
      - progressbar
      - generic: 41 of 41 MB
    - combobox
    - paragraph: The first visit downloads the game once. Later visits start from this device's copy.
  - generic "Globulation 2" [active] [ref=e3]
```

# Test source

```ts
  173 | };
  174 | 
  175 | const mainMenuCodes = {campaign:0, tutorial:1, load:2, custom:3, yog:4, lan:5, settings:6, editor:7, credits:8, quit:9};
  176 | exports.clickMainMenu = async (page, action) => {
  177 |   await exports.waitForMainMenu(page);
  178 |   const code = mainMenuCodes[action];
  179 |   if (code === undefined) throw new Error('Unknown main menu action: ' + action);
  180 |   const keys = action === 'settings' ? ['menu/6', 'menu/settings'] : ['menu/' + code];
  181 |   const present = () => page.evaluate(keys => {
  182 |     const controls = glob2Diagnostics.snapshot().controls;
  183 |     return keys.find(key => controls[key]) || (controls['menu/more'] ? 'menu/more' : null);
  184 |   }, keys);
  185 |   await expect.poll(present, {timeout: 30000, message: 'main menu is not showing'}).not.toBeNull();
  186 |   let key = await present();
  187 |   // Phones keep the utilities one level away behind More.
  188 |   if (key === 'menu/more' && !keys.includes('menu/more')) {
  189 |     await exports.clickControl(page, 'menu/more');
  190 |     key = keys[0];
  191 |   }
  192 |   return exports.clickControl(page, key);
  193 | };
  194 | 
  195 | exports.clickSettingsDone = page => exports.clickControl(page, 'done');
  196 | // Leaves Settings without claiming a durable save. Changes save as they are made,
  197 | // so the footer has only Done; a failed save adds "continue" (SettingsScreen::
  198 | // abandon()), which closes at once. Done after a failed restore fails the same
  199 | // way and offers it.
  200 | exports.clickSettingsCancel = async page => {
  201 |   await control(page, 'done', {enabled: false});
  202 |   // A save that has just failed shows "continue" at the next layout.
  203 |   let offered = false;
  204 |   for (const end = Date.now() + 2000; !offered && Date.now() < end; await page.waitForTimeout(100))
  205 |     offered = await page.evaluate(() => Boolean(glob2Diagnostics.snapshot().controls.cancel));
  206 |   if (!offered) await exports.clickControl(page, 'done');
  207 |   return exports.clickControl(page, 'cancel');
  208 | };
  209 | 
  210 | // The lobby's Start ignores input while its preview is pending; wait for the
  211 | // same ready state the lobby publishes.
  212 | exports.clickCustomGameStart = async page => {
  213 |   await expect.poll(() => page.evaluate(() => glob2Diagnostics.snapshot().customGameReady),
  214 |     {timeout: 60000}).toBe(true);
  215 |   return exports.clickControl(page, 'start');
  216 | };
  217 | // The AI profile picker behind a colony's info button on the Players & Teams tab.
  218 | exports.clickCustomAIProfile = (page, colony) => exports.clickControl(page, `colony/${colony}/info`);
  219 | 
  220 | // Exercise the visible editing surface with actual mouse and keyboard events.
  221 | // Filling the DOM value directly would miss focus, deletion and key routing bugs.
  222 | // The browser input exists while a field is being edited, so start with the
  223 | // field's own control (by key) as a player would.
  224 | exports.editTextField = async (page, value, password = false, key = password ? 'password' : 'name') => {
  225 |   await exports.clickControl(page, key);
  226 |   const field = page.locator(password ? 'input[aria-label="Password"]' : 'input[aria-label="Game text field"]');
  227 |   await field.click();
  228 |   await expect(field).toBeFocused();
  229 |   // Use the platform's native Select All shortcut; Home/End caret behavior
  230 |   // differs between macOS Firefox and the other browser/platform pairs.
  231 |   await field.press('ControlOrMeta+A');
  232 |   await field.press('Delete');
  233 |   await expect(field).toHaveValue('');
  234 |   await field.pressSequentially(value);
  235 |   await expect(field).toHaveValue(value);
  236 |   if (password) await expect(field).toHaveAttribute('type', 'password');
  237 | };
  238 | 
  239 | exports.clickResultsSave = page => exports.clickControl(page, 'save-replay');
  240 | 
  241 | // Export binary evidence compactly: tracing a JS number per byte can consume
  242 | // minutes and hundreds of MB for a replay. This leaves the exact bytes intact.
  243 | exports.readBrowserFile = async (page,path) => Buffer.from(await page.evaluate(path=>{
  244 |   const data=FS.readFile(path),parts=[];
  245 |   for(let at=0;at<data.length;at+=32768)
  246 |     parts.push(String.fromCharCode(...data.subarray(at,at+32768)));
  247 |   return btoa(parts.join(''));
  248 | },path),'base64');
  249 | 
  250 | // Existing gameplay tests explicitly decline the first-run recommendation when
  251 | // they ask for the main menu. Tests of onboarding itself drive its controls.
  252 | exports.waitForMainMenu = async (page, {timeout = 60000} = {}) => {
  253 |   const sent = new Set();
  254 |   await expect.poll(async () => {
  255 |     // A retry can navigate before the new document installs its diagnostics.
  256 |     const state=await page.evaluate(()=>globalThis.glob2Diagnostics?.snapshot());
  257 |     if (!state) return false;
  258 |     if ((state.screen+' '+state.screenClass).includes('MainMenuScreen')) return true;
  259 |     if ((state.screen+' '+state.screenClass).includes('IntroductionOfferScreen')) {
  260 |       const key = ['intro/menu', 'intro/continue'].find(key =>
  261 |         !sent.has(key) && state.controls[key]?.enabled);
  262 |       const bounds = key && state.controls[key];
  263 |       if (bounds && shown(bounds) && (await current(page, bounds))) {
  264 |         // This snapshot already supplies the visible hit area. Re-entering a
  265 |         // control/layout wait can outlive an accepted screen transition on a
  266 |         // busy renderer. Send each choice once, then observe the destination.
  267 |         sent.add(key);
  268 |         await page.locator('#canvas').click({position: await visibleCenter(page, bounds), delay: 80});
  269 |         await consumed(page);
  270 |       }
  271 |     }
  272 |     return false;
> 273 |   }, {timeout,message:'main menu is not showing after declining the introduction'}).toBe(true);
      |                                                                                     ^ Error: main menu is not showing after declining the introduction
  274 | };
  275 | 
```