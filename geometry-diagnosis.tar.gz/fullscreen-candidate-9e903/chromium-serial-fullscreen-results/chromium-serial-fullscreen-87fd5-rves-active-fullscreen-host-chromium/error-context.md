# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: chromium-serial-fullscreen.spec.cjs >> serial: canvas replacement preserves active fullscreen host
- Location: browser/tests/renderer-switching.spec.js:526:3

# Error details

```
Error: Channel closed
```

```
Error: page.evaluate: Target page, context or browser has been closed
```

```
Error: browserContext.close: Target page, context or browser has been closed
```