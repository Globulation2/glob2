from pathlib import Path
import os,subprocess,json,secrets,time,sys
root=Path.cwd();out=root/'artifacts/ci-recovery/merged-43b/platform';out.mkdir(exist_ok=True);nodebin='/home/bradley/.local/share/glob2/development/toolchains/emscripten/Linux-x86_64-88a621bc131cd4954413aa39/node/24.19.0_64bit/bin';image='postgres@sha256:ca0bd484cb98bf4b24eb1010e73fb3fcbd6714d240fbc1a10eea5b7dbecb641d';name='glob2-ci-recovery-43b-'+secrets.token_hex(4);container=None;steps=[];record={'source':'43b153739838207983c922ab4cbeed7773459de9','postgresImage':image,'ownedContainerName':name,'steps':steps}
def save(): (out/'results.json').write_text(json.dumps(record,indent=2)+'\n')
def step(label,command,env):
 with (out/(label+'.log')).open('w') as log:r=subprocess.run(command,cwd=root/'platform',env=env,stdout=log,stderr=subprocess.STDOUT)
 steps.append({'name':label,'command':command,'exitCode':r.returncode});save();print(label,'exit',r.returncode,flush=True);return r.returncode
try:
 container=subprocess.check_output(['docker','run','--rm','-d','--name',name,'--label','glob2.task=ci-recovery-43b','-e','POSTGRES_USER=glob2','-e','POSTGRES_PASSWORD=glob2','-e','POSTGRES_DB=postgres','-p','127.0.0.1::5432','--tmpfs','/var/lib/postgresql/data:rw,size=2147483648',image],text=True).strip();record['ownedContainerId']=container;save()
 deadline=time.monotonic()+60
 while subprocess.run(['docker','exec',container,'pg_isready','-h','127.0.0.1','-U','glob2','-d','postgres'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
  if time.monotonic()>deadline:raise RuntimeError('Isolated Postgres did not become ready')
  time.sleep(.3)
 port=subprocess.check_output(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',container],text=True).strip();record['privateLoopbackPort']=port;record['postgresVersion']=subprocess.check_output(['docker','exec',container,'postgres','--version'],text=True).strip();url=f'postgres://glob2:glob2@127.0.0.1:{port}/postgres'
 env=dict(os.environ,PATH=nodebin+':'+os.environ['PATH'],CI='1',ASTRO_TELEMETRY_DISABLED='1',GLOB2_DESIGN_SYSTEM_SHA='acd277710acfebf528e1fc6f653d55fdf75de4b2',TEST_DATABASE_URL=url,DATABASE_URL=url,TERRAIN_PYTHON='/usr/bin/python3');record['nodeVersion']=subprocess.check_output([nodebin+'/node','--version'],text=True).strip();save()
 for label,command in [('design-sync',['npm','run','design:sync']),('lint',['npm','run','lint']),('typecheck',['npm','run','typecheck']),('i18n',['npm','run','i18n:check']),('web-build',['npm','run','build','-w','@glob2/web']),('tests',['npm','test','--','--maxWorkers=4'])]:step(label,command,env)
 subprocess.run(['docker','exec',container,'createdb','-U','glob2','glob2'],check=True);env['DATABASE_URL']=url.rsplit('/',1)[0]+'/glob2'
 for action in ['latest','status']:step('migrate-'+action,['npm','run','migrate','--',action],env)
 record['trackedStatusAfter']=subprocess.check_output(['git','status','--porcelain'],text=True);save()
finally:
 if container:
  with (out/'postgres.log').open('w') as log:subprocess.run(['docker','logs',container],stdout=log,stderr=subprocess.STDOUT)
  owner=subprocess.run(['docker','inspect','--format','{{index .Config.Labels "glob2.task"}}',container],capture_output=True,text=True)
  if owner.returncode==0 and owner.stdout.strip()=='ci-recovery-43b':record['ownedContainerRemoved']=subprocess.run(['docker','rm','-f',container],stdout=subprocess.DEVNULL).returncode==0
  save()
sys.exit(any(s['exitCode'] for s in steps))
