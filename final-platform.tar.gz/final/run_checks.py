import json,os,subprocess,time
from pathlib import Path
R=Path.cwd();B=R/'artifacts/ci-recovery';D=B/'music-transition-final';W=B/'music-integration-repair';env=dict(os.environ);env['PATH']=str(B/'node/node_modules/.bin')+':'+env['PATH'];state=dict(pid=os.getpid(),revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),phase='lint',results=[])
def save():(D/'checks-status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for name in ['lint','typecheck']:
  state['phase']=name;save();start=time.monotonic()
  with(D/(name+'.log')).open('w')as log:code=subprocess.call(['npm','run',name],cwd=W/'platform',env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  state['results'].append(dict(name=name,exit_code=code,seconds=round(time.monotonic()-start,1)));save();assert code==0,name+' failed'
 state['phase']='full platform suite';save()
 with(D/'launch.log').open('w')as log:code=subprocess.call(['python3',str(D/'run.py')],cwd=R,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 state.update(phase='finished; inspect final tests/JUnit and both prior actual palette artifacts',coordinator_exit_code=code);save()
except BaseException as error:state.update(phase='stopped; inspect error',error=repr(error));save();raise
