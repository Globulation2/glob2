from pathlib import Path
import hashlib, importlib.util, json, subprocess

ROOT = Path.cwd()
B = ROOT / 'artifacts/ci-recovery'
W = B / 'telemetry-translations'
D = B / 'telemetry-translations-validation'
SOURCE = B / 'menu-latest-integration/build/emscripten/client/release'
TARGET = D / 'runtime'
assert not TARGET.exists(), 'Inspect the existing private runtime before replacing it'
subprocess.run(['cp', '-a', '--reflink=auto', str(SOURCE), str(TARGET)], check=True)
spec = importlib.util.spec_from_file_location('translation_assets', W / 'scons/web_assets.py')
assets = importlib.util.module_from_spec(spec); spec.loader.exec_module(assets)
original = (SOURCE / 'asset-manifest.js').read_text()
manifest = json.loads(original.split('??= ', 1)[1].rstrip().removesuffix(';'))
changed = []
for package in manifest['packages']:
    for part in package['parts']:
        if not any(path.startswith('/data/texts.') for path, _, _ in part['files']):
            continue
        old = (SOURCE / part['url']).read_bytes()
        blob = bytearray(); files = []
        for path, start, end in part['files']:
            value = old[start:end]
            if path.startswith('/data/texts.'):
                value = (W / path.lstrip('/')).read_bytes()
                if package['name'] == 'core' and assets.translation(path.lstrip('/')):
                    value = assets.stub(value)
            at = len(blob); blob.extend(value); files.append([path, at, len(blob)])
        filename = Path(part['url']).name.rsplit('.', 2)[0] + '.' + hashlib.sha256(blob).hexdigest()[:16] + '.data'
        part.update(url='assets/' + filename, size=len(blob), files=files)
        (TARGET / part['url']).write_bytes(blob)
        changed.append(part['url'])
    package['size'] = sum(p['size'] for p in package['parts'])
(TARGET / 'asset-manifest.js').write_text(assets.manifest_script(manifest))
proof = []
for relative in ['index.js', 'threaded/index.js']:
    path = TARGET / relative
    text = path.read_text()
    token = 'Module["glob2AssetManifest"]??='
    assert text.count(token) == 1
    # Supply the freshly packed catalog manifest before the embedded default.
    # The rest of the compiled JS and every Wasm byte remain unchanged.
    insertion = 'Module["glob2AssetManifest"]=' + json.dumps(manifest, separators=(',', ':')) + ';'
    patched = text.replace(token, insertion + token, 1)
    assert patched.replace(insertion, '', 1) == text
    path.write_text(patched)
    for extension in ['.br', '.gz']:
        path.with_name(path.name + extension).unlink(missing_ok=True)
    wasm = path.with_suffix('.wasm')
    if wasm.exists():
        assert wasm.read_bytes() == (SOURCE / wasm.relative_to(TARGET)).read_bytes()
        proof.append(dict(file=str(wasm.relative_to(TARGET)), sha256=hashlib.sha256(wasm.read_bytes()).hexdigest()))
for package in manifest['packages']:
    for part in package['parts']:
        data = (TARGET / part['url']).read_bytes()
        assert len(data) == part['size']
        for path, start, end in part['files']:
            if path.startswith('/data/texts.'):
                expected = (W / path.lstrip('/')).read_bytes()
                if package['name'] == 'core' and assets.translation(path.lstrip('/')):
                    expected = assets.stub(expected)
                assert data[start:end] == expected
(D / 'runtime-provenance.json').write_text(json.dumps(dict(
    compiled_revision='1d09ddbff80f3cf916f1163a99a9899149ab31c4',
    catalog_source=str(W), private_runtime=str(TARGET), changed_packages=changed,
    wasm=proof, scope='Catalog-only fixture qualification with unchanged historical engine. '
    'Real files repacked using production core stubs/hash/offset schema; no fake controls or assertions. '
    'Does not establish current engine build or performance-panel execution. '
    'All original language-picker tests and deadlines stay intact.'), indent=2) + '\n')
print('Prepared private runtime with current catalogs:', changed)
