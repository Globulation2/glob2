#include "ai/engine/AIExecutor.h"
#include <cassert>
#include <array>
int main() {
 for(unsigned workers:{0u,1u,4u,8u}) {
  AIEngine::Executor executor; executor.configure(workers);
  std::array<unsigned,32> next{};
  for(unsigned batch=0;batch<100;++batch) {
   std::vector<std::future<unsigned>> work;
   for(unsigned poll=0;poll<9;++poll) for(unsigned actor=0;actor<32;++actor) {
    auto expected=batch*9+poll;
    work.push_back(executor.submit<unsigned>(actor,[&,actor,expected] {
      assert(next[actor]++==expected);
      if((expected+actor)%7==0) std::this_thread::yield();
      return expected;
    }));
   }
   for(auto& result:work) result.get();
   executor.drain();
  }
  for(auto count:next) assert(count==900);
  executor.configure(0);
 }
}
