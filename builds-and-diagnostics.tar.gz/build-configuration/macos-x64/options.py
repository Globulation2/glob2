CC = '/Users/bradley/.codex/worktrees/d912/glob2/build/macos-x86-tools/bin/cc'
CXX = '/Users/bradley/.codex/worktrees/d912/glob2/build/macos-x86-tools/bin/cxx'
release = True
