from pathlib import Path
import sys,types,json
sys.path.insert(0,str(Path('test').resolve()));import run_tests as registry
build=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True);repeats=int(sys.argv[3]);rows=[]
cases=[c for c in registry.list_cases(registry.binary_path(build,'engine'),'engine') if c.suite=='GameSpeed' and c.name.startswith('live engine speed')];assert len(cases)==1
for index in range(repeats):
 for n,case in enumerate(cases):
  args=types.SimpleNamespace(keep_profiles=False,fullscreen=True,update_fixtures=False,artifacts=out/f'{index}-{n}',verbose=False);r=registry.run_job(registry.Job('engine',[case]),args,build);(out/f'{index}-{n}.log').write_text(r.output);row={'iteration':index,'case':case.name,'status':r.status,'seconds':r.seconds};rows.append(row);print(json.dumps(row),flush=True);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
print('RESULT',sum(r['status']=='pass' for r in rows),'/',len(rows),flush=True)
