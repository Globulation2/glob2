The live speed fixture can finish its 50-tick Maximum-speed probe before the resume timer fires because its initial synthetic pause key arrives after a window-focus loss and is ignored.

Supply a focus-gained event for the fixture's window before each injected pause/resume shortcut, and carry the window ID with the timer's immutable input data. The existing timing bounds, normal/hard-pause checks, replay speed checks and seven checksum comparisons remain unchanged. Production input and simulation code are unchanged.

Validation: the clean baseline fails both in the full isolated-display suite and in an isolated follow-up (pause duration about 30 ms), while some repeated baseline probes pass. The corrected candidate passes all three speed tests and ten repeated full live probes constrained to two CPUs. Clean final-source validation and accessible evidence will be added before merge.
