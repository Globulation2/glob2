// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <vector>

// Opt-in, observation-only experiment. No values here feed back into routing,
// scheduling, saves or RNG. Each row covers one building/swim-class rebuild's
// lifetime, not just its first request. Loaded fields are unmeasured until rebuilt.
namespace GradientDemandProbe
{
enum Consumer { Movement, Availability, RoundTrip, ConsumerCount };
using Clock = std::chrono::steady_clock;
inline std::uint64_t elapsed(Clock::time_point start)
{
	return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count();
}
struct Demand
{
	int cost = -1;
	std::uint64_t reads = 0, unreachable = 0;
	void read(std::uint16_t value)
	{
		++reads;
		if (value == 1) ++unreachable; // proving no path requires exhaustion
		else if (value > 1) cost = std::max(cost, 65535 - int(value));
		// Obstacles (zero) are known from initialization without any expansion.
	}
};
struct Field
{
	unsigned gid = 0, swim = 0, tick = 0;
	bool flag = false;
	std::size_t cells = 0;
	std::uint64_t initNs = 0, seedNs = 0, propagationNs = 0, reachable = 0;
	std::array<Demand, ConsumerCount> demand;
	std::vector<std::uint32_t> cumulative;
	Clock::time_point started;
	void read(Consumer consumer, std::uint16_t value) { demand[consumer].read(value); }
	// Full cost layers include equal-distance sidesteps. This models settled
	// vertices, not queue duplicates, allocations or the eight boundary relaxations.
	std::uint64_t needed(unsigned mask, bool proveUnreachable = true) const
	{
		int cost = -1;
		for (unsigned c = 0; c < ConsumerCount; ++c)
			if (mask & (1u << c))
			{
				if (proveUnreachable && demand[c].unreachable) return reachable;
				cost = std::max(cost, demand[c].cost);
			}
		if (cost < 0 || cumulative.empty()) return 0;
		return cumulative[std::min<std::size_t>(cost, cumulative.size() - 1)];
	}
};
class Probe
{
	FILE *output = nullptr;
	std::map<const std::uint16_t *, Field> fields;
public:
	Probe()
	{
		const char *path = std::getenv("GLOB2_GRADIENT_DEMAND_CSV");
		if (path && *path)
		{
			output = std::fopen(path, "w");
			if (!output) { std::perror("GLOB2_GRADIENT_DEMAND_CSV"); return; }
			std::fprintf(output, "gid,swim,start_tick,flag,map_cells,reachable,init_ns,seed_ns,propagation_ns,movement_reads,availability_reads,roundtrip_reads,movement_unreachable,availability_unreachable,roundtrip_unreachable,movement_needed,availability_needed,local_needed,all_needed,roundtrip_full_needed,local_reachable_needed,end_reason\n");
		}
	}
	~Probe()
	{
		while (!fields.empty()) finish(fields.begin()->first, "process_end");
		if (output) std::fclose(output);
	}
	Field *find(const std::uint16_t *gradient)
	{
		if (!output || !gradient) return nullptr;
		auto it = fields.find(gradient);
		return it == fields.end() ? nullptr : &it->second;
	}
	void finish(const std::uint16_t *gradient, const char *reason)
	{
		Field *f = find(gradient);
		if (!f) return;
		const auto &d = f->demand;
		std::fprintf(output, "%u,%u,%u,%d,%zu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%s\n",
			f->gid, f->swim, f->tick, int(f->flag), f->cells,
			(unsigned long long)f->reachable, (unsigned long long)f->initNs,
			(unsigned long long)f->seedNs, (unsigned long long)f->propagationNs,
			(unsigned long long)d[0].reads, (unsigned long long)d[1].reads, (unsigned long long)d[2].reads,
			(unsigned long long)d[0].unreachable, (unsigned long long)d[1].unreachable, (unsigned long long)d[2].unreachable,
			(unsigned long long)f->needed(1), (unsigned long long)f->needed(2),
			(unsigned long long)f->needed(3), (unsigned long long)f->needed(7),
			(unsigned long long)(d[RoundTrip].reads ? f->reachable : f->needed(3)),
			(unsigned long long)f->needed(3, false), reason);
		fields.erase(gradient);
	}
	Field *begin(const std::uint16_t *gradient, std::size_t size, unsigned gid, unsigned swim, unsigned tick, bool flag)
	{
		if (!output) return nullptr;
		finish(gradient, "rebuild");
		Field &f = fields[gradient];
		f.gid = gid; f.swim = swim; f.tick = tick; f.flag = flag; f.cells = size;
		f.started = Clock::now();
		return &f;
	}
};
inline Probe &probe() { static Probe instance; return instance; }
inline Field *find(const std::uint16_t *gradient) { return probe().find(gradient); }
struct Build
{
	Field *field;
	Build(const std::uint16_t *gradient, std::size_t size, unsigned gid, unsigned swim, unsigned tick, bool flag)
		: field(probe().begin(gradient, size, gid, swim, tick, flag)) {}
	~Build() { if (field && field->propagationNs == 0) field->initNs = elapsed(field->started); }
};
struct Propagation
{
	Field *field;
	const std::uint16_t *gradient;
	Clock::time_point started;
	Propagation(const std::uint16_t *gradient) : field(find(gradient)), gradient(gradient)
	{
		if (field) { field->initNs = elapsed(field->started); started = Clock::now(); }
	}
	void beginSweep()
	{
		if (field) { field->seedNs = elapsed(started); started = Clock::now(); }
	}
	~Propagation()
	{
		if (!field) return;
		field->propagationNs = elapsed(started);
		// This extra census is deliberately outside the measured propagation time.
		// It is diagnostic overhead, not part of the proposed lazy algorithm.
		for (std::size_t i = 0; i < field->cells; ++i)
			if (gradient[i] > 1)
			{
				std::size_t cost = 65535 - gradient[i];
				if (field->cumulative.size() <= cost) field->cumulative.resize(cost + 1);
				++field->cumulative[cost];
				++field->reachable;
			}
		for (std::size_t i = 1; i < field->cumulative.size(); ++i)
			field->cumulative[i] += field->cumulative[i - 1];
	}
};
}
