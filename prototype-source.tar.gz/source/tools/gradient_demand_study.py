#!/usr/bin/env python3
"""Run reproducible building-gradient demand experiments; retain raw evidence.

The probe observes eager fields. Estimated time saved is propagation time times
the fraction of settled cells avoided, not a measured lazy implementation speedup.
"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def summarize(path):
    with path.open() as stream:
        rows = [{k: (v if k == "end_reason" else int(v)) for k, v in r.items()}
                for r in csv.DictReader(stream)]

    def group(rows):
        total = sum(r["reachable"] for r in rows)
        result = {"epochs": len(rows), "reachable": total,
                  "init_ns": sum(r["init_ns"] for r in rows),
                  "seed_ns": sum(r["seed_ns"] for r in rows),
                  "propagation_ns": sum(r["propagation_ns"] for r in rows),
                  "roundtrip_epochs": sum(r["roundtrip_reads"] > 0 for r in rows),
                  "local_unreachable_epochs": sum(r["movement_unreachable"] + r["availability_unreachable"] > 0 for r in rows)}
        for key in ("movement_needed", "availability_needed", "local_needed", "all_needed", "roundtrip_full_needed", "local_reachable_needed"):
            needed = sum(r[key] for r in rows)
            result[key] = {"cells": needed, "avoided_fraction": 1 - needed / total if total else 0,
                           "estimated_saved_ns": sum(r["propagation_ns"] * (1 - r[key] / r["reachable"])
                                                     for r in rows if r["reachable"])}
        return result
    return {"all": group(rows),
            "rebuild_or_idle": group([r for r in rows if r["end_reason"] in ("rebuild", "idle")]),
            "buildings": group([r for r in rows if not r["flag"]]),
            "flags": group([r for r in rows if r["flag"]]),
            "by_swim": {str(c): group([r for r in rows if r["swim"] == c]) for c in range(7)}}


def perf(log):
    result = {}
    for line in log.read_text().splitlines():
        if not line.startswith("GLOB2_PERF_FINAL "):
            continue
        values = dict(token.split("=", 1) for token in shlex.split(line)[1:] if "=" in token)
        if "scope" in values:
            result[values["scope"]] = values
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--variant", required=True)
    parser.add_argument("--probe", action="store_true")
    parser.add_argument("--lazy", action="store_true", help="test the resumable-building-gradient prototype")
    parser.add_argument("--no-checksums", action="store_true", help="timing-only runs after checksum validation")
    args = parser.parse_args()
    if args.probe and args.lazy:
        parser.error("--probe models eager fields; it cannot be combined with --lazy")
    root = Path(__file__).resolve().parents[1]
    binary, output = args.binary.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.pop("GLOB2_GRADIENT_DEMAND_CSV", None)
    env["SDL_VIDEODRIVER"] = "dummy"
    env["SDL_AUDIODRIVER"] = "dummy"
    results = []

    def run(command, log, run_env):
        start = time.monotonic()
        with log.open("w") as stream:
            subprocess.run(command, cwd=root, env=run_env, stdout=stream, stderr=subprocess.STDOUT, check=True)
        return time.monotonic() - start

    for case in json.loads(args.cases.read_text()):
        case_dir = output / case["name"]
        case_dir.mkdir(exist_ok=True)
        generated = case_dir / "generated"
        map_file = generated / "map-r0.map"
        if not map_file.exists():
            command = [str(binary), "--generate-map", "--generator", str(case["generator"]),
                       "--map-seed", str(case["map_seed"]), "--write-map", "true", "--output-dir", str(generated)]
            for key, value in case["params"].items():
                command += ["--param", f"{key}={value}"]
            (case_dir / "generate-command.json").write_text(json.dumps(command, indent=2) + "\n")
            run(command, case_dir / "generate.log", env)
        target = case_dir / args.variant
        if target.exists():
            raise RuntimeError(f"Refusing to overwrite {target}")
        log = case_dir / f"{args.variant}.log"
        csv_file = case_dir / f"{args.variant}.csv"
        command = [str(binary), "--run-game", "--map-file", str(map_file), "--game-seed", str(case["game_seed"]),
                   "--ticks", str(case["ticks"]), "--telemetry", "team-timeline",
                   "--save", "initial", "--save", "final", "--output-dir", str(target)]
        if not args.no_checksums:
            command += ["--telemetry", "checksums"]
        if args.lazy:
            command += ["--lazy-building-gradients", "true"]
        for ai in case["players"]:
            command += ["--player", ai]
        run_env = env.copy()
        if args.probe:
            run_env["GLOB2_GRADIENT_DEMAND_CSV"] = str(csv_file)
        record = {"case": case, "command": command, "binary_sha256": digest(binary),
                  "map_sha256": digest(map_file), "platform": platform.platform(),
                  "probe": args.probe, "lazy": args.lazy, "checksums": not args.no_checksums}
        print(f"Running {case['name']} / {args.variant}", flush=True)
        record["wall_s"] = run(command, log, run_env)
        record["performance"] = perf(log)
        if args.probe:
            record["demand"] = summarize(csv_file)
        results.append(record)
        (case_dir / f"{args.variant}-summary.json").write_text(json.dumps(record, indent=2) + "\n")
        print(f"Finished in {record['wall_s']:.2f}s", flush=True)
    (output / f"{args.variant}-summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
