// SPDX-License-Identifier: GPL-3.0-or-later
#include "../src/map/gradient/GradientDemandProbe.h"
#include <cassert>

int main()
{
	using namespace GradientDemandProbe;
	Field f;
	f.reachable = 7;
	f.cumulative = {1, 1, 3, 3, 5, 7};
	assert(f.needed(7) == 0);
	f.read(Movement, 65533); // distance 2: whole equal-cost layer
	assert(f.needed(1) == 3);
	f.read(Movement, 65535); // closer later query must not shrink the lifetime
	assert(f.needed(1) == 3);
	f.read(Availability, 0); // blocked cell is known without a search
	assert(f.needed(2) == 0);
	f.read(Availability, 65531);
	assert(f.needed(3) == 5);
	f.read(RoundTrip, 1); // unreachable must exhaust, but only its own scenario
	assert(f.needed(7) == 7);
	assert(f.needed(3) == 5);
	f.read(Movement, 1);
	assert(f.needed(3) == 7);
	assert(f.needed(3, false) == 5);
	Field locked;
	locked.read(Availability, 1);
	assert(locked.needed(7) == 0);
	if (std::getenv("GLOB2_GRADIENT_DEMAND_CSV"))
	{
		std::uint16_t gradient[] = {65535, 65525, 65525, 65521, 0, 1};
		const std::vector<std::uint16_t> original(std::begin(gradient), std::end(gradient));
		{
			Build build(gradient, 6, 17, 0, 10, false);
			Propagation propagation(gradient);
			propagation.beginSweep();
		}
		auto *field = find(gradient);
		assert(field && field->reachable == 4);
		field->read(Movement, gradient[1]);
		assert(field->needed(1) == 3); // both equal-distance vertices included
		field->read(RoundTrip, gradient[5]);
		assert(field->needed(7) == 4);
		assert(std::equal(original.begin(), original.end(), gradient));
		{
			Build rebuild(gradient, 6, 17, 0, 20, false);
			assert(find(gradient)->demand[Movement].reads == 0);
			assert(find(gradient)->reachable == 0);
		}
		probe().finish(gradient, "idle");
		assert(!find(gradient));
	}
	return 0;
}
