# Engine performance telemetry

Performance collection is automatic. `GLOB2_TEAM_TIMELINE=1` exports it alongside gameplay
and AI statistics. It is local to an execution session: loading starts fresh timing coverage,
and no performance data enters saves, orders, RNG, simulation checksums, or AI decisions.
No HUD values or pacing rules change. AI samples are written in fixed-size binary batches
with byte-for-byte equivalence to the previous scalar writes; the save format is unchanged.

## Meaning of the measurements

All durations are monotonic elapsed nanoseconds, not process CPU time. Descheduling and
blocking inside an instrumented operation remain in its duration. Rendering measures CPU-side
submission and the presentation call; it does not measure GPU execution or physical display
scanout. No GPU queries, synchronization, or additional world scans are introduced.

- `loop` measures complete main-loop iterations, including pacing.
- `loop.work` excludes intentional sleep, network sleep, and the presentation call.
- `simulation.tick` measures an executed simulation step; rendered frames and ticks need not
  have the same cadence.
- `pacing.presentation_interval` measures time between presentation returns. Its population
  standard deviation is frame jitter. `pacing.interval_change` measures absolute differences
  between consecutive intervals; its mean is mean absolute interval change.
- `budgets` records observations, overruns, accumulated/worst excess, and longest overrun
  streak. Work uses the current step budget; presentation uses the step budget multiplied by
  render cadence. Normal-speed steps have a 40 ms budget. Headless/uncapped runs have no
  budget classification. Mode/speed changes break interval chains and overrun streaks.
- Save queue, hash, and write measurements describe background work (or the existing
  synchronous fallback if thread creation fails). They must not be added to main-thread work.
  They are published under the writer's existing lock on the next submission or final wait.
  `saved_total`, `failed_total`, and `superseded_total` are session counters.

Scopes cover units/buildings/tasks, map updates, fog, scripts, construction projects,
statistics, orders/replay checksums, AI totals and observation/planning/gradient phases,
resource/building/round-trip/area gradients and propagation, pathfinding, rendering passes,
loading/generation/site assignment/site relaxation/validation, and save/output work.
Per-player AI totals identify player, team, implementation, and controller generation.
Replay timings describe replay execution, not reconstructed original AI decisions.
AI subphase scopes are aggregate timings across players; the complete per-player AI cost is
reported by `ai.player`. Audio callback and GPU execution times are not instrumented.
Startup timings include generation attempts performed while preparing the session.

## Cost and sampling

`PerformanceScopes.inc` defines stable scope names and sampling strides. Major phases and
expensive rebuilds are timed on every execution. Hot path-query/direction scopes count every
call and time one in 64 calls. The selected residue rotates between capture windows without
using gameplay RNG. This spreads sampling across periodic callers, but does not make the
estimate statistically unbiased for every workload.

Each scope retains fixed-size online moments: count, integer total/maximum, mean, and M2.
There is no event log, per-event allocation, string lookup, or sorting. Nesting is bounded at
64 timed scopes; player attribution retains at most 128 controller generations per session.
Overflow reports dropped records/samples and continues the game normally.

Inclusive durations overlap and must not be summed into a supposed engine total. `self_ns`
is available only when all instrumented child timing is exact. Uninstrumented work remains
in the parent's self time. Encountering a sampled descendant makes self time unavailable,
rather than subtracting an estimate from an exact duration.

`GLOB2_PERF_DISABLE=1` disables collection for benchmark comparisons. It is a diagnostic
control, not a gameplay option. `GLOB2_PERF_BUILD_LABEL` optionally supplies a build identifier
in exports; the benchmark artifacts should also retain the executable hash and build command.

## Export contract

Existing records remain unchanged. New records use key/value fields and nanosecond units:

- `GLOB2_PERF_SESSION`: process-local session identity, clock, save-format version, platform/compiler,
  pointer width, renderer, dimensions, player/team counts, optional build label.
- `GLOB2_PERF_SCHEMA`: stable scope name, sampling stride, population-variance convention.
- `GLOB2_PERF_SAMPLE`: interval tick and elapsed-time ranges, execution mode and separate work/presentation budgets, scope,
  thread attribution, call/sample counts, mean, standard deviation, maximum and totals.
- `GLOB2_PERF_FINAL`: session aggregates, following the final partial sample and the existing
  autosave drain. Cumulative mode is `all`; compare mode-specific sample records when speed
  changes matter.

A sample closes at the end of the iteration crossing a 512-tick boundary, or after five
seconds without a tick-based capture. Mode changes close the previous interval. Windows
continue during pause/stalls. No unbounded performance history is retained; explicit output
streams interval records, while collection without output retains only aggregates.

Exact scopes export `total_ns`. Sampled scopes export `observed_total_ns` and
`estimated_total_ns = sample_mean * call_count`. Their maxima and standard deviations describe
observed samples only. A scope with calls but no timed sample exports `na`; an unexecuted
scope has no sample record and remains identifiable through the schema. Absence is not zero.

Performance formatting runs only when output is enabled. Interval-output cost is charged to
the following interval; final output includes the final interval-formatting cost but cannot
include the time spent printing its own final records. Gameplay/AI export work is separately
timed. Parsing quoted metadata requires quote-aware key/value parsing (for example `shlex`).

## Extending and verifying

Add a descriptor and place `PERF_SCOPE_TIME(Name)` around an existing operation or batch.
Use a named `PerformanceTelemetry::Scope` and `stop()` where only part of a function belongs
to the scope. Keep timers outside entity/cell inner loops. Background threads must publish
explicit aggregates through existing synchronization; the implicit collector is thread-local.

Run `scons -j8 release=1 server=0 performance-telemetry-test team-stats-save-test savegame-safety-test`
and `build/libgag/src/PerformanceTelemetryHarness`. Run the save/statistics harnesses through
`test/run-savegame-safety-tests.py` as documented in the test README. The dedicated collector
harness uses an injected clock; the save harness checks background completion/failure counts.

Validate performance against the preceding AI-only executable using identical fixtures and
orders, separately for output off/on. Retain per-tick checksum sidecars, compiler/build
commands, executable hashes, and raw timing results. Cross-platform execution comparisons
remain required before claiming cross-platform verification.

Structured tournament runs include requested final-save serialization before the
performance final export. All records pass through verified worker log artifacts
and the [offline tournament readers](../tools/tournaments.md#gameplay-ai-and-performance-telemetry).

## Experimental building-gradient demand probe

Set `GLOB2_GRADIENT_DEMAND_CSV` to an output filename to observe the building
fields without changing their computation or consumers. This opt-in experiment
writes one CSV row per building/swim-class field lifetime, closing a row when the
field is rebuilt, freed or the process exits. The file is overwritten at startup.
Loaded fields are not measured until their next rebuild. No probe state is saved.

The probe counts reachable cells by final path cost and records the maximum cost
requested over the lifetime by movement, availability/distance checks (including
hiring), and round-trip resource construction. Whole equal-cost layers are included
so movement's equal-distance sidesteps remain available. Obstacles need no search;
an unreachable query requires exhaustion. The demand scenarios are:

- `movement_needed` and `availability_needed`: each consumer in isolation.
- `local_needed`: movement and availability together, excluding round-trip demand.
- `all_needed`: all actual reads, including round-trip resource seed dependencies.
- `roundtrip_full_needed`: a simpler implementation that completes a field whenever
  round-trip construction reads it.
- `local_reachable_needed`: optimistic local demand assuming unreachable answers
  were available for free from some other mechanism. No such mechanism is supplied.

These are settled-cell work estimates, not implemented lazy searches. They exclude
queue duplicates, retained-frontier memory, pause/resume overhead, and the work of
any replacement for round-trip selection. Full-map initialization and seed scanning
remain. Costs describe each existing field's frozen eager result; retaining stable
inputs across pauses would need separate design and validation. Destruction/process
end rows can be truncated by the run's tick cap; inspect rebuild/idle-only results
as well. Dropping consumers changes the workload, so those scenarios are hypotheses,
not claims of equivalent gameplay.

`tools/gradient_demand_study.py` runs JSON case lists using an explicit `--binary`,
`--variant`, `--cases` and `--output` directory; add `--probe` for collection. Each
case supplies `name`, `generator`, `map_seed`, `game_seed`, `params` (generator
controls), `players` (AI names) and `ticks`. The first variant generates retained
maps; subsequent variants reuse them. It retains commands, executable/map hashes,
initial/final saves, per-tick checksums, logs, CSV and summaries. Use an ignored
`artifacts/` output directory. Existing variant directories are never overwritten.
After verifying checksums, `--no-checksums` supports timing-only runs without the
additional full-state checksum cost on every tick.

The summary weights each lifetime's avoided-cell fraction by its measured
propagation sweep duration, excluding initialization and seed scanning (both timed
separately). This is a rough time estimate, not a measured speedup. The
additional histogram scans and read bookkeeping slow instrumented runs; obtain the
simulation/gradient timing shares from the uninstrumented baseline, and compare
its checksums with collection both disabled and enabled. The probe's own build
timers exclude its histogram scan, but ordinary performance scopes include it.
The standalone accounting check can be built with
`c++ -std=c++17 -O2 -Wall -Wextra test/GradientDemandProbeTest.cpp -o artifacts/gradient-demand-test`.
Run it with `GLOB2_GRADIENT_DEMAND_CSV=artifacts/gradient-demand-test.csv artifacts/gradient-demand-test`
to also exercise the histogram census, field rollover and CSV export.

### Experimental lazy propagation

`--run-game --lazy-building-gradients true` enables the propagation-only prototype;
the default is false. Legacy entry points and regression harnesses can instead set
`GLOB2_LAZY_BUILDING_GRADIENTS=1`. The structured headless command clears that ambient
variable and uses its explicit argument. `gradient_demand_study.py --lazy` passes
the argument and retains it in the run manifest. Do not combine lazy execution
with the eager demand probe (`--probe` / `GLOB2_GRADIENT_DEMAND_CSV`).

Initialization and seed scanning are unchanged. Building fields retain a bucket
queue, and weighted swimming classes copy the water mask at initialization.
Obstacles remain frozen in the initialized field. Point requests settle a whole
cost layer before reading, including the equal-cost neighbors used for sidesteps.
Unknown cells are never reported as unreachable until the search is exhausted.
Round-trip construction, forbidden-area escape and gradient debug rendering finish
the relevant cached fields. Reading an already-cached round-trip field does not
force completion. Existing refresh deadlines and use timestamps are preserved.

Saving finishes pending fields from their original snapshots without refreshing
them. It writes the existing complete-field representation, with no new saved bytes
or version change. Loaded fields start complete. Save-time completion can introduce
a pause and is additional work relative to unsaved lazy play; include save timing
when evaluating autosave workloads. Retained queues and water masks also add memory.

`gradient.building` measures initialization (and eager propagation when disabled).
`gradient.building_resume` measures actual lazy extensions and completion, including
those nested in round-trip construction or saving. Sum these two scopes to compare
building-field construction, but do not then add inclusive round-trip/save timings
to that total. The prototype is opt-in pending correctness and performance review;
local experiment results belong under `artifacts/`, not in this guide.
