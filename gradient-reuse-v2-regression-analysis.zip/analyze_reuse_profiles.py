from pathlib import Path
import re,json,collections
BASE=Path(__file__).resolve().parent;ROOT=BASE/'reuse-regression-profiles-01'
rx=re.compile(r'^\s*(\S+) (\d+)/(\d+) ([\d.]+):\s+(\d+) cycles:u:\s+([0-9a-f]+) (.*) \((.*)\)$')
header=re.compile(r'^\s*(\S+) (\d+)/(\d+) ([\d.]+):\s+(\d+) cycles:u:')
reports={}
for d in sorted(ROOT.iterdir()):
 if not d.is_dir():continue
 samples=[]
 for line in (d/'samples-flat.txt').read_text().splitlines():
  m=rx.match(line)
  if m:samples.append(dict(comm=m[1],pid=int(m[2]),tid=int(m[3]),time=float(m[4]),period=int(m[5]),ip=m[6],symbol=m[7],dso=m[8]))
 gradients={s['tid'] for s in samples if s['tid']!=s['pid'] and 'propagateField' in s['symbol'] and 'Map::configureGradientPipeline' in s['symbol']}
 total=sum(s['period'] for s in samples);engine=sum(s['period'] for s in samples if s['comm']=='glob2');threads=collections.defaultdict(collections.Counter)
 for s in samples:
  if s['comm']!='glob2':continue
  c=threads[s['tid']];c['samples']+=1;c['period']+=s['period']
  if 'propagateField' in s['symbol']:c['propagation']+=s['period']
  if 'memmove' in s['symbol'] or 'memcpy' in s['symbol']:c['copy']+=s['period']
  if 'memcmp' in s['symbol'] or 'bcmp' in s['symbol']:c['compare']+=s['period']
  if 'preparePendingGradient' in s['symbol']:c['prepare_self']+=s['period']
  if s['symbol']=='[unknown]':c['unknown_leaf']+=s['period']
 # Empty versus nonempty raw DWARF callchains, independent of flat sampled IP.
 unwind=collections.defaultdict(collections.Counter);current=None;frames=[]
 def flush():
  if current is None:return
  comm,pid,tid,period=current
  if comm!='glob2':return
  c=unwind['gradient' if tid in gradients else 'other_engine'];c['samples']+=1;c['period']+=period
  if not frames:c['empty_samples']+=1;c['empty_period']+=period
  elif all('[unknown]' in f for f in frames):c['all_unknown_samples']+=1;c['all_unknown_period']+=period
 for line in (d/'samples.txt').read_text().splitlines():
  m=header.match(line)
  if m:flush();current=(m[1],int(m[2]),int(m[3]),int(m[5]));frames=[]
  elif line.startswith('\t'):frames.append(line)
 flush()
 g=collections.Counter()
 for tid in gradients:g.update(threads[tid])
 record=json.loads((d/'run/result.json').read_text())
 reports[d.name]={'sample_count':len(samples),'total_weighted_cycles':total,'engine_weighted_cycles':engine,'gradient_tids':sorted(gradients),'gradient':dict(g),'gradient_copy_process_share':g['copy']/total,'gradient_compare_process_share':g['compare']/total,'per_tid':{str(t):dict(v) for t,v in threads.items()},'unwind':{k:dict(v) for k,v in unwind.items()},'instrumented_result_metrics':{k:record[k] for k in ['gradient_active_elapsed_ns','gradient_wait_ns','compute_active_elapsed_ns','compute_batch_ns','compute_wait_ns']}}
 print(d.name,'weightedB',round(total/1e9,3),'gradB',round(g['period']/1e9,3),'propB',round(g['propagation']/1e9,3),'copyB',round(g['copy']/1e9,3),'cmpB',round(g['compare']/1e9,3),'gradthreads',len(gradients),'unwind',dict(unwind['gradient']))
report={'scope':'Single instrumented diagnostic observation per arm/window; sample-period weights approximate cycles, not end-to-end CPU measurements. Worker classification uses actual propagation callback symbols and TIDs; no hit/miss count inferred. HEADER_EVENT_DESC warning and incomplete worker DWARF unwinds retained.','profiles':reports}
(BASE/'reuse-regression-profile-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
