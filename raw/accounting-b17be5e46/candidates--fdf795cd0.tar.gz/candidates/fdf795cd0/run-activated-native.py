import os,json,subprocess,hashlib,xml.etree.ElementTree as ET,datetime
from pathlib import Path
root=Path.cwd(); candidate=root/'artifacts/gpu-offload/candidates/fdf795cd0'
plan=json.loads((candidate/'activation-cases.json').read_text()); output=root/'artifacts/gpu-offload/native-fdf795cd0-activated';output.mkdir(exist_ok=False)
binary=candidate/'glob2-unit-tests'; receipt=json.loads((candidate/'build-receipt.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(binary)==receipt['test_binaries']['glob2-unit-tests']['sha256']
base={'GLOB2_OPENCL_DEVICE':'0','GLOB2_OPENCL_POLL_US':'0','GLOB2_OPENCL_PROFILE':'0','GLOB2_OPENCL_API_CPU':'0','GLOB2_OPENCL_ACTIVE_EPOCH':'0','GLOB2_OPENCL_PARITY_BOUND':'0','GLOB2_OPENCL_DIRECT_SEED_UPLOAD':'0','GLOB2_GRADIENT_BATCH':'1','GLOB2_OPENCL_CHECK_INTERVAL':'8','GLOB2_GRADIENT_PLAN':'frozen8','GLOB2_GRADIENT_TUNING':'0','GLOB2_OPENCL_UNIFORM_METADATA':'0','GLOB2_OPENCL_PROBE_COLD_COSTS':'0'}
rows=[]
for case in plan['cases']:
 directory=output/case['id'];directory.mkdir();env={k:v for k,v in os.environ.items() if not k.startswith(('GLOB2_TEST_OPENCL_','GLOB2_TEST_CAPTURE_','GLOB2_OPENCL_','GLOB2_GRADIENT_'))};env.update(base|case['environment']);env['GLOB2_TEST_ARTIFACTS_ROOT']=str(directory)
 command=[str(binary),'-r=xml','--no-breaks=true','--no-colors=true','-ts='+case.get('suite','OpenCLGradient'),'-tc='+case['case']]
 began=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (directory/'results.xml').open('w') as xml,(directory/'stderr.log').open('w') as error:
  try: result=subprocess.run(command,cwd=root,env=env,stdout=xml,stderr=error,timeout=case.get("timeout_seconds",600));code=result.returncode
  except subprocess.TimeoutExpired:code=None
 row=dict(case=case['id'],test_case=case['case'],command=command,environment=base|case['environment'],source_revision=plan['source_revision'],binary_sha256=sha(binary),source_requirements=case.get('source_requirements'),count_mode=case['count_mode'],expected_assertions=case['count'],exit_code=code,started_utc=began,qualifying_evidence=False,stage='native-correctness',ready_mask_observation='No literal mask export from this case; complete source REQUIREs/assertion count prove required ready plans. Separate ordinal/UUID preflight is retained.')
 try:
  doc=ET.parse(directory/'results.xml').getroot();active=[c for c in doc.findall('.//TestCase') if c.get('skipped')!='true'];totals=doc.find('OverallResultsAsserts');actual=int(totals.get('successes'));failed=int(totals.get('failures'));count_ok=actual==case['count'] if case['count_mode']=='exact' else actual>=case['count'];row.update(actual_successful_assertions=actual,failed_assertions=failed,active_cases=[c.get('name') for c in active],valid=code==0 and len(active)==1 and active[0].get('name')==case['case'] and count_ok and failed==0)
 except Exception as error:row.update(valid=False,parse_error=str(error))
 (directory/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);(output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(case['id'],row.get('actual_successful_assertions'),row['valid'],flush=True)
 if not row['valid']:raise SystemExit(1)
