import json,subprocess,hashlib,datetime,os,fnmatch
from pathlib import Path
root=Path.cwd();candidate=root/'artifacts/gpu-offload/candidates/fdf795cd0';entries=json.loads((candidate/'native-commands.json').read_text());declared=json.loads((candidate/'expected-native-inventory.json').read_text())['expected_names'];rows=[]
for entry in entries:
 family=entry['family'];command=entry['command'];out=root/f'artifacts/gpu-offload/native-fdf795cd0-{family}';out.mkdir(exist_ok=False)
 env=dict(os.environ);removed={k:env.pop(k,None) for k in ('DISPLAY','WAYLAND_DISPLAY','SDL_VIDEO_DRIVER')};runtime=out/'xdg-runtime';runtime.mkdir(mode=0o700);env['XDG_RUNTIME_DIR']=str(runtime)
 inventory_command=[*command,'--list'];listed=subprocess.run(inventory_command,cwd=root,env=env,capture_output=True,text=True,timeout=30);(out/'declared-inventory.log').write_text(listed.stdout+listed.stderr)
 names=listed.stdout.splitlines();assert listed.returncode==0 and names[-1]==f'{len(declared[family])} cases';assert sorted(names[:-1])==sorted(declared[family])
 expected=declared[family]
 if family=='engine':
  selected=['GradientPreparation/*','EngineSession/rendered CPU*','EngineSession/warm capture*'];command=[];i=0
  while i<len(entry['command']):
   if entry['command'][i]=='--filter':i+=2;continue
   command.append(entry['command'][i]);i+=1
  for pattern in selected:command.extend(['--filter',pattern])
  expected=[name for name in expected if any(fnmatch.fnmatchcase(name,pattern) for pattern in selected)]
 with (out/'runner.log').open('w') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 inv=json.loads((out/'inventory.json').read_text());row={'family':family,'command':command,'source_revision':'fdf795cd0bbd57858b87e648d668d7554c82e8cb','source_tree':'1d21ec0b8f6599860f7f67e50d185495afa62904','declared_full_count':len(declared[family]),'declared_full_names_match':True,'expected_executed_count':len(expected),'eligible_count':len(inv['eligible']),'assigned_count':len(inv['assigned']),'eligible_matches_expected':sorted(inv['eligible'])==sorted(expected),'assigned_matches_expected':sorted(inv['assigned'])==sorted(expected),'exit_code':r.returncode,'valid':r.returncode==0 and sorted(inv['eligible'])==sorted(expected) and sorted(inv['assigned'])==sorted(expected),'environment_removed':removed,'private_xdg_runtime_dir':str(runtime),'stage':'affected-correctness-refresh','qualifying_evidence':False,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'junit_sha256':hashlib.sha256((out/'junit.xml').read_bytes()).hexdigest()};(out/'official-receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);print(row,flush=True)
(candidate/'affected-native-summary.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(0 if all(r['valid'] for r in rows) else 1)
