from pathlib import Path
import os,json,subprocess,fcntl,time,hashlib
p=Path('artifacts/gpu-offload/candidates/fdf795cd0');head='fdf795cd0bbd57858b87e648d668d7554c82e8cb';git=lambda *x:subprocess.check_output(['git',*x],text=True).strip()
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
e=os.environ.copy();e.update({'GLOB2_SDL3_PREFIX':'/home/bradley/glob2-claude/build/sdl3/prefix','GLOB2_RECORDING_PREFIX':'/home/bradley/glob2-claude/build/linux/client/release/recording/prefix'})
cmd=['scons','-j8','release=1','server=0','--build=build/linux/client/release-final-f33','build/linux/client/release-final-f33/src/glob2','unit-tests','engine-tests']
with open('../gpu-offload-resource.lock','a+') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);start=time.time_ns()
 with (p/'build.log').open('w') as log:r=subprocess.run(cmd,env=e,stdout=log,stderr=subprocess.STDOUT)
 receipt={'source_revision':head,'source_tree':git('rev-parse','HEAD^{tree}'),'command':cmd,'prefix_environment':{k:e[k] for k in ['GLOB2_SDL3_PREFIX','GLOB2_RECORDING_PREFIX']},'exit_code':r.returncode,'start_unix_ns':start,'end_unix_ns':time.time_ns(),'head_unchanged':git('rev-parse','HEAD')==head,'source_clean':not git('status','--porcelain'),'build_log_sha256':hashlib.sha256((p/'build.log').read_bytes()).hexdigest()}
 (p/('build-execution.json' if not r.returncode else 'build-failure-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 raise SystemExit(r.returncode)
