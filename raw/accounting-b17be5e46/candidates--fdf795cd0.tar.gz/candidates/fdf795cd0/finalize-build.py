from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
root=Path.cwd();out=root/'artifacts/gpu-offload/candidates/fdf795cd0';base=root/'build/linux/client/release-final-f33'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='fdf795cd0bbd57858b87e648d668d7554c82e8cb';assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
log=(out/'build.log').read_text();assert 'scons: done building targets.' in log and 'error:' not in log
paths={'glob2':base/'src/glob2','glob2-unit-tests':base/'test/glob2-unit-tests','glob2-engine-tests':base/'test/glob2-engine-tests'}
for name,p in paths.items():assert p.is_file();shutil.copy2(p,out/name)
old=json.loads((root/'artifacts/gpu-offload/candidates/786feaa6a/build-receipt.json').read_text());dependencies={p:sha(p) for p in old['dependency_hashes'] if p.startswith('/home/bradley/')}
assert dependencies=={p:h for p,h in old['dependency_hashes'].items() if p.startswith('/home/bradley/')}
for name in ['identity.json','config.h']:
 p=base/name if name=='identity.json' else root/'config.h'
 if p.is_file():shutil.copy2(p,out/name)
receipt={'source_revision':head,'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'native_base_root':'b17be5e46dd7eae50c201ea89eedd61ec9ab2b48','reviewed_patches':[],'complete_base_tree_equivalence':True,'binary':str(out/'glob2'),'binary_sha256':sha(out/'glob2'),'game_binary_sha256':sha(out/'glob2'),'game_source_revision':head,'test_binaries':{name:{'binary':str(out/name),'sha256':sha(out/name),'source_revision':head} for name in paths if name!='glob2'},'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'build_command':['scons','-j8','release=1','server=0','--build=build/linux/client/release-final-f33','build/linux/client/release-final-f33/src/glob2','unit-tests','engine-tests'],'dependency_hashes':dependencies,'identity_sha256':sha(base/'identity.json'),'config_sha256':sha(root/'config.h'),'build_log_sha256':sha(out/'build.log'),'build_exit_code':0,'compile_commands':sum(x.startswith('g++ ') and ' -c ' in x for x in log.splitlines()),'compiler_errors':0,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'note':'Three linked binaries at immutable checkpoint with exact reviewed root d4c1057c tree including refreshed current master d20c23957, production Group/full-debt and minimal default. No extra runtime changes. Affected policy/Group and gameplay automatic feasibility remain pending; all failed precursor builds remain preserved separately. Reviewed controlled automatic attachment is present; native activation and overhead proof remain pending.'}
receipt['note']=json.loads((out/'freeze.json').read_text())['purpose']
(out/'build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ('source_revision','compile_commands','binary_sha256','test_binaries')},indent=2))
