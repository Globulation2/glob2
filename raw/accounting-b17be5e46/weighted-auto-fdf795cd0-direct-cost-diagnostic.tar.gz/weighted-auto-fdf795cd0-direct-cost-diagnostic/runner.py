"""One reviewed behavioral Auto diagnostic; sealed CPU reused only for exact traces."""
import argparse, datetime, fcntl, hashlib, json, os, re, struct, subprocess, time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--reuse-cpu-control',type=Path,required=True);p.add_argument('--reviewed-root',required=True);p.add_argument('--reviewed-tree',required=True);p.add_argument('--protocol',type=Path,required=True);a=p.parse_args()
root=Path.cwd();candidate=a.candidate.resolve();out=a.output.resolve();build=json.loads((candidate/'build-receipt.json').read_text());binary=Path(build['binary']);sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(binary)==build['binary_sha256']
assert re.fullmatch(r'[0-9a-f]{40}',a.reviewed_root) and re.fullmatch(r'[0-9a-f]{40}',a.reviewed_tree)
assert subprocess.check_output(['git','rev-parse',a.reviewed_root+'^{tree}'],text=True).strip()==a.reviewed_tree
assert build['source_tree']==a.reviewed_tree and build['native_base_root']==a.reviewed_root, 'Require the independently reviewed combined source tree'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==build['source_revision'] and not subprocess.check_output(['git','status','--porcelain'],text=True), 'Keep pilot source immutable and clean'
protocol=json.loads(a.protocol.resolve().read_text());assert protocol['frozen'] and protocol['reviewed_root']==a.reviewed_root and protocol['reviewed_tree']==a.reviewed_tree, 'Seal reviewed source/protocol before launch'
assert protocol['window']=={'initial_tick':0,'end_tick':768,'warmup_ticks':256,'measure_ticks':512}
assert protocol['configuration']['epoch']==1 and protocol['configuration']['batch']==1
assert protocol['variants']==[{'id':'auto-admission','backend':'auto','tuning':1,'promotion':0}]
control_path=a.reuse_cpu_control.resolve();control=json.loads((control_path/'receipt.json').read_text());assert control['source_revision']=='cfbc704b78c5f7ee489f84d3229148bd447a504f' and control['variant']['id']=='cpu' and control['trace']['ticks']==768 and control['trace']['closed_body']
assert sha(control_path/'game.replay.checksums')==control['trace']['sha256']
protocol=dict(protocol,source_freeze=f'Reviewed root {a.reviewed_root}, tree {a.reviewed_tree}; source behavior changes are declared in the frozen protocol.',stage='single-auto-direct-cost-cadence-diagnostic',reuse_cpu_control={'receipt_path':str(control_path/'receipt.json'),'receipt_sha256':sha(control_path/'receipt.json'),'source_revision':control['source_revision'],'source_tree':control['source_tree'],'binary_sha256':control['binary_sha256'],'trace':control['trace'],'use':'Exact trace comparator only; source behavior differs, no CPU/performance ratio inference.'})
native=json.loads((candidate/'affected-native-summary.json').read_text())
assert len(native)==2 and all(r['valid'] for r in native), 'Require native checks before game launch'
assert {r['family']:r['expected_executed_count'] for r in native}=={'unit':306,'engine':26}
assert all(r['source_revision']==build['source_revision'] and r['source_tree']==build['source_tree'] for r in native)
fixture=root/'artifacts/gpu-offload/native-15eb839ec-swimmer-writer/GpuOffloadFixture/write_1024_real-game_stress_fixtures_benchmark_artifacts/gpu-1024-corridors-bounded-ai-seed91006-swimmers.game'
if not fixture.exists():
 matches=list((root/'artifacts/gpu-offload/native-15eb839ec-swimmer-writer').rglob('*corridors*swimmers*.game'));assert len(matches)==1;fixture=matches[0]
assert sha(fixture)==protocol['fixture_sha256']
assert not Path('/sys/fs/cgroup/codex-gpu1045-benchmark').exists(), 'Do not reuse an unexplained reservation'
launcher=root.parent/'cpu_partition_ten.py';lock_path=root.parent/'gpu-offload-resource.lock'
keys=tuple(json.loads((root/'artifacts/gpu-offload/resumed-validation/rendered-regression-protocol-draft.json').read_text())['renderer_environment_keys'])
assert os.environ.get('DISPLAY'),'Normal desktop X11 is required for this diagnostic'
base={k:v for k,v in os.environ.items() if k.startswith('GLOB2_')}
assert not base, 'Remove ambient GLOB2 overrides; every launch setting is declared here'

def trace(path):
 data=path.read_bytes();assert data[:4]==b'GCS1';teams,players,count,flags=struct.unpack_from('<4I',data,4);assert 1<=teams<=32 and count==768;pos=20;ticks=[]
 def u32():
  nonlocal pos
  assert pos+4<=len(data);v=struct.unpack_from('<I',data,pos)[0];pos+=4;return v
 for _ in range(count):
  ticks.append(u32());u32()
  for _ in range(teams):
   u32()
   for _ in range(2):
    objects=u32();assert objects<=65536
    for _ in range(objects):
     assert pos+2<=len(data);pos+=2;u32();n=u32();assert n<=1048576;pos+=4*n;assert pos<=len(data)
 assert ticks==list(range(768)) and pos==len(data)
 return {'sha256':sha(path),'first_tick':0,'last_tick':767,'ticks':count,'closed_body':True}

def value(v):
 if re.fullmatch(r'[-+]?[0-9]+',v):return int(v)
 if re.fullmatch(r'[-+]?(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][-+]?[0-9]+)?',v):return float(v)
 return v

def partition(action):
 result=subprocess.run(['sudo','-n','/usr/bin/python3','-I',str(launcher),action],capture_output=True,text=True,timeout=15)
 (out/f'partition-{action}.json').write_text(json.dumps({'command':result.args,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'launcher_sha256':sha(launcher)},indent=2)+'\n');assert result.returncode==0

def inventory():
 result=subprocess.run(['nvidia-smi'],capture_output=True,text=True,timeout=10)
 return {'monotonic_ns':time.monotonic_ns(),'unix_ns':time.time_ns(),'command':['nvidia-smi'],'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}

out.mkdir(parents=True,exist_ok=False);rows=[]
with lock_path.open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 (out/'protocol.json').write_text(json.dumps(dict(protocol,build_receipt=build,launcher_sha256=sha(launcher),script_sha256=sha(__file__),ambient_renderer_environment={k:os.environ.get(k) for k in keys}),indent=2)+'\n')
 (out/'runner.py').write_bytes(Path(__file__).read_bytes())
 partition('setup')
 try:
  for variant in protocol['variants']:
   d=out/variant['id'];d.mkdir();profile=d/'profile';profile.mkdir();replay=d/'game.replay';report=d/'rendered-cpu.json'
   env={k:os.environ[k] for k in keys if k in os.environ};env.update({'SDL_VIDEO_DRIVER':'x11','GLOB2_USER_DATA_DIR':str(profile),'GLOB2_REPLAY_PATH':str(replay),'GLOB2_CHECKSUM_SIDECAR':'1','GLOB2_TEAM_TIMELINE':'1','GLOB2_PERF_DISTRIBUTIONS':'1','GLOB2_GRADIENT_BACKEND':variant['backend'],'GLOB2_GRADIENT_TUNING':str(variant['tuning']),'GLOB2_GRADIENT_TUNING_PROMOTION':str(variant.get('promotion',1)),'GLOB2_GRADIENT_PLAN':'frozen8','GLOB2_GRADIENT_BATCH':'1','GLOB2_OPENCL_DEVICE':'0','GLOB2_OPENCL_CHECK_INTERVAL':'8','GLOB2_OPENCL_POLL_US':'0','GLOB2_OPENCL_PROFILE':'0','GLOB2_OPENCL_ACTIVE_EPOCH':'1','GLOB2_OPENCL_PARITY_BOUND':'0','GLOB2_OPENCL_DIRECT_SEED_UPLOAD':'0','GLOB2_OPENCL_API_CPU':'0','GLOB2_OPENCL_UNIFORM_METADATA':'0','GLOB2_GRADIENT_WORKER_NOOP':'0','GLOB2_GRADIENT_SKIP_EMPTY_CLASSIC':'0','GLOB2_AI_SCHEDULER_DIAGNOSTICS':'1','GLOB2_GRADIENT_DIAGNOSTICS':'1','GLOB2_BENCHMARK_LARGE_MAPS':'1','GLOB2_BENCHMARK_DIAGNOSTICS':'1','GLOB2_RENDERED_CPU_DIAGNOSTICS_PATH':str(report),'GLOB2_RENDERED_CPU_WARMUP_TICKS':'256','GLOB2_RENDERED_CPU_MEASURE_TICKS':'512','GLOB2_RENDERED_WARM_DISTRIBUTIONS':'1'})
   envfile=d/'launch-environment.json';envfile.write_text(json.dumps(env,indent=2)+'\n')
   game=[str(binary),'game','repeat',str(fixture),'--ticks','768','--runs','1','--compute-threads','8','--renderer','gpu','--window-size','1280x720','--no-fullscreen','--no-custom-cursor','--mute','--display']
   command=['sudo','-n','/usr/bin/python3','-I',str(launcher),'--env-json',str(envfile),'run','--',*game]
   before=inventory();snapshots=[];started=datetime.datetime.now(datetime.timezone.utc).isoformat();began=time.monotonic_ns();process=None;code=None
   try:
    with (d/'engine.log').open('w') as log:
     process=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
     deadline=time.monotonic()+300;next_sample=0
     while process.poll() is None:
      if time.monotonic()>deadline:raise TimeoutError('bounded diagnostic300second timeout')
      if time.monotonic()>=next_sample:
       sample=inventory();sample['partition_procs']=[];procfile=Path('/sys/fs/cgroup/codex-gpu1045-benchmark/cgroup.procs')
       for rawpid in procfile.read_text().split():
        pid=int(rawpid);tasks=[]
        for task in (Path('/proc')/rawpid/'task').glob('*'):
         try:
          raw=(task/'stat').read_text();f=raw[raw.rindex(')')+2:].split();tasks.append({'tid':int(task.name),'comm':(task/'comm').read_text().strip(),'cpu_clock_ticks':int(f[11])+int(f[12]),'allowed':next(l for l in (task/'status').read_text().splitlines() if l.startswith('Cpus_allowed_list:'))})
         except OSError:pass
        sample['partition_procs'].append({'pid':pid,'tasks':tasks})
       snapshots.append(sample);next_sample=time.monotonic()+2
      time.sleep(.1)
     code=process.returncode
   except BaseException:
    if process and process.poll() is None:
     # Terminate only the owned child group, retaining any partial outputs.
     for pid in Path('/sys/fs/cgroup/codex-gpu1045-benchmark/cgroup.procs').read_text().split():
      subprocess.run(['sudo','-n','kill','-TERM',pid],check=False)
     try:process.wait(timeout=10)
     except subprocess.TimeoutExpired:process.kill();process.wait()
    raise
   finally:
    r={'variant':variant,'source_revision':build['source_revision'],'source_tree':build['source_tree'],'binary_sha256':sha(binary),'fixture_sha256':sha(fixture),'command':command,'effective_environment':env,'renderer_environment':{k:env.get(k) for k in keys},'started_utc':started,'whole_session_wall_ns':time.monotonic_ns()-began,'exit_code':code,'before':before,'after':inventory(),'snapshots':snapshots,'stage':'real-normal-loop-admission-diagnostic','qualifying_evidence':False,'observer_note':'Full checksum/stage diagnostics and2second external inventories are enabled; no performance acceptance inference'}
    (d/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
   assert code==0
   result=json.loads(report.read_text());assert all(result[k] for k in ('process_cpu_valid','owner_cpu_valid','wall_valid')) and not result['missed_boundary'];assert result['start']['tick']==256 and result['end']['tick']==768 and result['final_tick']==768
   r['rendered_report']=result;r['trace']=trace(Path(str(replay)+'.checksums'))
   terminals=[];policies=[];required_gpu=[]
   for line in (d/'engine.log').read_text(errors='replace').splitlines():
    for prefix,rows_out in [('gradient_probe ',terminals),('gradient_policy ',policies),('gradient_gpu ',required_gpu)]:
     if line.startswith(prefix):rows_out.append({k:value(v) for k,v in re.findall(r'(\w+)=([^\s]+)',line)})
   r['terminal_rows']=terminals;r['policy_rows']=policies;r['required_auto_gpu_rows']=required_gpu;r['sampling_limit']='No per-key opportunity histogram is inferred from retired rows; missing source counters are reported unavailable.'
   (d/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');rows.append(r);print(variant['id'],len(terminals),'terminal rows',flush=True)
  assert len(rows)==1 and rows[0]['trace']['sha256']==control['trace']['sha256']
  (out/'summary.json').write_text(json.dumps({'valid':True,'qualifying_evidence':False,'rows':rows,'reused_cpu_control':protocol['reuse_cpu_control'],'interpretation':'One Auto behavioral diagnostic versus previously sealed CPU exact trace. No CPU/performance ratio; readiness does not prove learning or promotion.'},indent=2)+'\n')
 finally:partition('cleanup')
