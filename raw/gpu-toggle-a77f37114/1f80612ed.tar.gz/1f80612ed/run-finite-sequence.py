import json,subprocess,time
from pathlib import Path
p=Path('artifacts/gpu-toggle-final/1f80612ed');events=[]
def emit(stage,status,**kwargs):
 row={'stage':stage,'status':status,'unix_ns':time.time_ns(),**kwargs};events.append(row);(p/'finite-sequence-events.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(row),flush=True)
emit('build','waiting for immutable build and CPU cleanup receipts')
while not (p/'build-cpu-cleanup.json').exists():time.sleep(2)
if (p/'build-failure-receipt.json').exists():emit('build','failed; no native launches');raise SystemExit(1)
assert json.loads((p/'build-execution.json').read_text())['exit_code']==0
for name in ['finalize-build.py','run-native.py','run-native-activated.py','run-game-exactness.py']:
 emit(name,'started')
 r=subprocess.run(['python3',str(p/name)])
 emit(name,'passed' if r.returncode==0 else 'failed',exit_code=r.returncode)
 if r.returncode:raise SystemExit(r.returncode)
emit('finite-controls','complete; replay/display guard and evidence summary remaining')
