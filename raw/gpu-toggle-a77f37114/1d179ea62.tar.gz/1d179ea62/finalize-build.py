from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path.cwd();p=root/'artifacts/gpu-toggle-final/1d179ea62';build=root/'build/linux/client/release-final-f33';receipt=json.loads((p/'build-execution.json').read_text());assert receipt['exit_code']==0 and receipt['head_unchanged'] and receipt['source_clean']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==receipt['source_revision'];assert not subprocess.check_output(['git','status','--porcelain'])
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();names={'glob2':build/'src/glob2','glob2-unit-tests':build/'test/glob2-unit-tests','glob2-engine-tests':build/'test/glob2-engine-tests'}
for name,path in names.items():assert path.is_file();shutil.copy2(path,p/name)
old=json.loads((root/'artifacts/gpu-offload/candidates/fdf795cd0/build-receipt.json').read_text());dependencies={path:sha(path) for path in old['dependency_hashes'] if path.startswith('/home/bradley/')};assert dependencies=={path:val for path,val in old['dependency_hashes'].items() if path.startswith('/home/bradley/')},'pinned dependency changed'
for name,path in [('identity.json',build/'identity.json'),('config.h',root/'config.h')]:shutil.copy2(path,p/name)
log=(p/'build.log').read_text();assert 'scons: done building targets.' in log;assert 'error:' not in log
result=receipt|{'binary':str((p/'glob2').resolve()),'binary_sha256':sha(p/'glob2'),'test_binaries':{name:{'path':str((p/name).resolve()),'sha256':sha(p/name)} for name in names if name!='glob2'},'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'dependency_hashes':dependencies,'identity_sha256':sha(p/'identity.json'),'config_sha256':sha(p/'config.h'),'compile_commands':sum(x.startswith('g++ ') and ' -c ' in x for x in log.splitlines()),'scope':'Final GPU on/off source; all automatic/probe/campaign code removed; finite native and exactness verification follows'}
(p/'build-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['source_revision','compile_commands','binary_sha256','test_binaries']},indent=2))
