import fcntl,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();p=root/'artifacts/gpu-toggle-final/1d179ea62'
launcher=root.parent/'cpu_partition_ten.py'
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
assert head=='1d179ea628e94b6d3623929de7fbce88f869853e' and not git('status','--porcelain')
cmd=['scons','-j8','release=1','server=0','--build=build/linux/client/release-final-f33','build/linux/client/release-final-f33/src/glob2','unit-tests','engine-tests']
env={'GLOB2_SDL3_PREFIX':'/home/bradley/glob2-claude/build/sdl3/prefix','GLOB2_RECORDING_PREFIX':'/home/bradley/glob2-claude/build/linux/client/release/recording/prefix'}
(p/'build-environment.json').write_text(json.dumps(env))
with (root.parent/'gpu-offload-resource.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 setup=subprocess.run(['sudo','-n','python3','-I',str(launcher),'setup'],capture_output=True,text=True)
 (p/'build-cpu-partition-setup.json').write_text(setup.stdout);assert setup.returncode==0,setup.stderr
 start=time.time_ns()
 try:
  with (p/'build.log').open('w') as log:
   run=subprocess.run(['sudo','-n','python3','-I',str(launcher),'run','--env-json',str(p/'build-environment.json'),'--',*cmd],stdout=log,stderr=subprocess.STDOUT)
  receipt={'source_revision':head,'source_tree':tree,'command':cmd,'prefix_environment':env,'exit_code':run.returncode,'start_unix_ns':start,'end_unix_ns':time.time_ns(),'head_unchanged':git('rev-parse','HEAD')==head,'source_clean':not git('status','--porcelain'),'build_log_sha256':hashlib.sha256((p/'build.log').read_bytes()).hexdigest()}
  (p/('build-execution.json' if not run.returncode else 'build-failure-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
  print(json.dumps(receipt),flush=True)
 finally:
  cleanup=subprocess.run(['sudo','-n','python3','-I',str(launcher),'cleanup'],capture_output=True,text=True);(p/'build-cpu-cleanup.json').write_text(json.dumps({'exit_code':cleanup.returncode,'stdout':cleanup.stdout,'stderr':cleanup.stderr},indent=2))
 raise SystemExit(run.returncode)
