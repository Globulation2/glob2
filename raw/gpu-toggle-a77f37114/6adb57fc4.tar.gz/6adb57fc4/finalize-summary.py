import hashlib,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
root=Path.cwd();p=root/'artifacts/gpu-toggle-final/6adb57fc4'
read=lambda f:json.loads((p/f).read_text())
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
b=read('build-receipt.json');native=read('native-summary.json');activated=read('native-activated/summary.json');games=read('game-exactness/summary.json');compat=read('compatibility-guards/summary.json')
assert b['exit_code']==0 and len(native)==2 and all(x['exit_code']==0 and x['eligible_names_match'] and x['assigned_names_match'] for x in native)
assert len(activated)==4 and all(x['valid'] for x in activated)
assert len(games)==18 and all(x['valid'] for x in games)
assert len(compat)==4 and all(x['valid'] for x in compat)
images=list(p.rglob('gpu-compute-*.png'));assert len(images)==4
assert not subprocess.check_output(['git','status','--porcelain'])
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==b['source_revision']
for f in ['build-cpu-cleanup.json','native-cpu-cleanup.json','native-activated/partition-cleanup.json','game-exactness/partition-cleanup.json','compatibility-guards/partition-cleanup.json']:assert read(f)['exit_code']==0
failures=[]
for prefix in ['1d179ea62','1676084ef']:
 q=p.parent/prefix/'build-failure-receipt.json';failures.append({'path':str(q.relative_to(root)),'sha256':sha(q),'receipt':json.loads(q.read_text())})
counts=[]
for x in native:
 d=p/('native-'+x['family']);doc=ET.parse(d/'junit.xml').getroot();full=(d/'full-compiled-inventory.log').read_text().splitlines()[-1]
 counts.append({'family':x['family'],'compiled_inventory':full,'selected_cases':x['expected_count'],'exit_code':x['exit_code'],'junit_sha256':x['junit_sha256'],'junit_root':doc.attrib})
result={'source_revision':b['source_revision'],'source_tree':b['source_tree'],'master_base':'c6a7eae787a0f945619a622ed99ac755c2632689','scope':'Finite GPU on/off settings, actual-device correctness and save/replay continuation; no performance inference or automatic qualification','build':b,'native_inventory_and_passes':counts,'native_activated':activated,'game_controls':games,'compatibility_guards':compat,'gui_visual_qa':{'images':[{'path':str(i.relative_to(root)),'sha256':sha(i)} for i in images],'review':'Both switch states at 640x480 and 1280x900 inspected; see visual-qa.json'},'preserved_failed_builds':failures,'historical_native_failure':{'source':'1f80612ed','path':'artifacts/gpu-toggle-final/1f80612ed/native-engine/receipt.json','failure':'Obsolete costIdentityHits assertion; exactness passed, replaced by actual committed GPU fields'},'local_preparation_failure':'1676084ef/local-preparation-failure.json records a launcher identity check failure before any build; preserved separately','resources':{'cpu_partition':'10 physical cores with SMT siblings, CPUs 6-15,22-31, memory node 0; equal budgets','gpu_ordinal':0,'nvidia_uuid':'GPU-289a3035-0b2c-d273-67db-ccc36b6ca73b','exclusive_gpu_claim':False,'cleanup':'All owned CPU partitions released; no native processes left'},'limitations':['Linux GCC release and NVIDIA RTX 2070 SUPER/OpenCL verified; Windows/macOS/web builds not executed','Graphical native and repeat-loop checks use an owned X11/Mesa software GL display; no hardware-renderer or performance qualification claim','Historic accepted 24-26 percent CPU savings are separate evidence; this final validation makes no timing claim','Automatic tuning, probes, campaigns and large-map import overrides have been removed; ordinary supported 512 map used'],'automatic_mode_present':False,'performance_inference':False}
(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
manifest={str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file() and f.name!='sha256-manifest.json'}
(p/'sha256-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'source_revision':b['source_revision'],'native':counts,'actual_gpu_gates':len(activated),'exact_initial_and_continuation_runs':len(games),'compatibility_controls':len(compat)},indent=2))
