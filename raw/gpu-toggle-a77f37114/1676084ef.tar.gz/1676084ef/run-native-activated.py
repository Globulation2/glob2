import fcntl,hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
from pathlib import Path
root=Path.cwd();p=root/'artifacts/gpu-toggle-final/1676084ef';launcher=root.parent/'cpu_partition_ten.py';out=p/'native-activated';out.mkdir(exist_ok=False)
cases=[('query-failure','unit','isolated required query failure retains cost graph through exact CPU recovery','GLOB2_TEST_OPENCL_REQUIRED_QUERY_FAILURE',19),('host-admission','unit','isolated required host admission pressure preserves seeds and device readiness','GLOB2_TEST_OPENCL_HOST_ADMISSION',26),('observed-rollback','unit','isolated completed kernels remain observed when transactional output is declined','GLOB2_TEST_OPENCL_EXECUTION_OBSERVATION_ROLLBACK',12),('minimal48','engine','GradientPreparation/minimal GPU views release source graphs and recover exact CPU fields','GLOB2_TEST_OPENCL_MINIMAL_COSTS',794)]
rows=[]
with (root.parent/'gpu-offload-resource.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 setup=subprocess.run(['sudo','-n','python3','-I',str(launcher),'setup'],capture_output=True,text=True);(out/'partition-setup.json').write_text(setup.stdout);assert setup.returncode==0,setup.stderr
 try:
  for name,family,case,flag,count in cases:
   d=out/name;d.mkdir();profile=d/'profile';profile.mkdir();xdg=d/'xdg';xdg.mkdir(mode=0o700)
   e={'GLOB2_OPENCL_DEVICE':'0',flag:'1','GLOB2_USER_DATA_DIR':str(profile.resolve()),'GLOB2_TEST_ARTIFACTS_ROOT':str(d.resolve()),'SDL_VIDEODRIVER':'dummy','SDL_VIDEO_DRIVER':'dummy','SDL_AUDIODRIVER':'dummy','XDG_RUNTIME_DIR':str(xdg.resolve())};(d/'environment.json').write_text(json.dumps(e))
   env={k:v for k,v in os.environ.items() if not k.startswith(('GLOB2_OPENCL_','GLOB2_GRADIENT_','GLOB2_TEST_'))};env.update(e)
   b=p/('glob2-'+family+'-tests');command=[str(b.resolve()),'-r=xml','--no-breaks=true','--no-colors=true','-tc='+case]
   with (d/'results.xml').open('w') as xml,(d/'stderr.log').open('w') as error:run=subprocess.run(['sudo','-n','python3','-I',str(launcher),'run','--env-json',str(d/'environment.json'),'--',*command],env=env,stdout=xml,stderr=error,timeout=600)
   row={'id':name,'case':case,'command':command,'environment':e,'source_revision':'1676084efac00a37801dcf36d4231d951a9a392a','binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'exit_code':run.returncode,'expected_assertions':count,'valid':False}
   try:
    doc=ET.parse(d/'results.xml').getroot();active=[c for c in doc.findall('.//TestCase') if c.get('skipped')!='true'];totals=doc.find('OverallResultsAsserts');actual=int(totals.get('successes'));fail=int(totals.get('failures'));row.update(actual_successful_assertions=actual,failed_assertions=fail,active_cases=[c.get('name') for c in active]);row['valid']=run.returncode==0 and len(active)==1 and active[0].get('name')==case and actual==count and fail==0
   except Exception as error:row['parse_error']=str(error)
   (d/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,row,flush=True)
   if not row['valid']:raise RuntimeError('activated native gate failed; preserve')
 finally:
  c=subprocess.run(['sudo','-n','python3','-I',str(launcher),'cleanup'],capture_output=True,text=True);(out/'partition-cleanup.json').write_text(json.dumps({'exit_code':c.returncode,'stdout':c.stdout,'stderr':c.stderr},indent=2))
