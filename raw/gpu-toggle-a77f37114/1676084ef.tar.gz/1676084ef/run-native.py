import fcntl,fnmatch,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();p=root/'artifacts/gpu-toggle-final/1676084ef';m=json.loads((p/'validation-matrix.json').read_text());launcher=root.parent/'cpu_partition_ten.py'
assert json.loads((p/'build-execution.json').read_text())['exit_code']==0
env=dict(os.environ)
for k in list(env):
 if k.startswith('GLOB2_OPENCL_') or k in ['GLOB2_GRADIENT_BACKEND','DISPLAY','WAYLAND_DISPLAY','SDL_VIDEO_DRIVER','SDL_VIDEODRIVER']:env.pop(k,None)
env['GLOB2_OPENCL_DEVICE']='0'
xdg=p/'native-xdg-runtime';xdg.mkdir(mode=0o700,exist_ok=True);env['XDG_RUNTIME_DIR']=str(xdg.resolve())
rows=[]
with (root.parent/'gpu-offload-resource.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 setup=subprocess.run(['sudo','-n','python3','-I',str(launcher),'setup'],capture_output=True,text=True);(p/'native-cpu-partition-setup.json').write_text(setup.stdout);assert setup.returncode==0,setup.stderr
 try:
  updates={k:v for k,v in env.items() if k in ['GLOB2_OPENCL_DEVICE','XDG_RUNTIME_DIR']};(p/'native-environment.json').write_text(json.dumps(updates))
  for family in ['unit','engine']:
   d=p/('native-'+family);d.mkdir(exist_ok=False)
   common=['python3','test/run_tests.py','--build-dir',m['build_dir'],'--binary',family]
   full=subprocess.run(common+['--list'],env=env,capture_output=True,text=True,timeout=60);(d/'full-compiled-inventory.log').write_text(full.stdout+full.stderr);assert full.returncode==0
   selected=common+['--exclude-tag','benchmark']
   for pattern in m['native'][family+'_filters']:selected+=['--filter',pattern]
   listed=subprocess.run(selected+['--list'],env=env,capture_output=True,text=True,timeout=60);(d/'selected-inventory.log').write_text(listed.stdout+listed.stderr);assert listed.returncode==0
   names=listed.stdout.splitlines();assert names[-1]==f'{len(names)-1} cases';expected=names[:-1]
   command=selected+['--jobs','1','--display-jobs','1','--write-inventory',str((d/'inventory.json').resolve()),'--junit',str((d/'junit.xml').resolve()),'--artifacts',str((d/'artifacts').resolve())]
   start=time.time_ns()
   with (d/'runner.log').open('w') as log:run=subprocess.run(['sudo','-n','python3','-I',str(launcher),'run','--env-json',str(p/'native-environment.json'),'--',*command],env=env,stdout=log,stderr=subprocess.STDOUT)
   actual=json.loads((d/'inventory.json').read_text());row={'family':family,'command':command,'source_revision':m['reviewed_final_source'],'source_tree':m['reviewed_final_tree'],'expected_count':len(expected),'expected_names':expected,'actual_eligible_count':len(actual['eligible']),'actual_assigned_count':len(actual['assigned']),'eligible_names_match':sorted(actual['eligible'])==sorted(expected),'assigned_names_match':sorted(actual['assigned'])==sorted(expected),'exit_code':run.returncode,'start_unix_ns':start,'end_unix_ns':time.time_ns(),'junit_sha256':hashlib.sha256((d/'junit.xml').read_bytes()).hexdigest(),'scope':'affected finite correctness; compiled full inventory retained separately'}
   (d/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);print(json.dumps(row),flush=True)
   if run.returncode:raise RuntimeError(f'{family} failed; preserved; stop before gameplay')
  (p/'native-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
 finally:
  c=subprocess.run(['sudo','-n','python3','-I',str(launcher),'cleanup'],capture_output=True,text=True);(p/'native-cpu-cleanup.json').write_text(json.dumps({'exit_code':c.returncode,'stdout':c.stdout,'stderr':c.stderr},indent=2))
