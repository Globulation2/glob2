import fcntl,hashlib,json,os,struct,subprocess,time
from pathlib import Path
root=Path.cwd();p=root/'artifacts/gpu-toggle-final/1676084ef';m=json.loads((p/'validation-matrix.json').read_text());launcher=root.parent/'cpu_partition_ten.py';binary=p/'glob2';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert json.loads((p/'native-summary.json').read_text());assert sha(binary)==json.loads((p/'build-receipt.json').read_text())['binary_sha256']
fixture=Path(m['fixture']['path']);assert sha(fixture)==m['fixture']['sha256'];output=p/'game-exactness';output.mkdir(exist_ok=False);rows=[];reference={}
def trace(d,end,start):
 world=d/'world.checksums';raw=world.read_bytes();values=[tuple(map(int,x.split())) for x in raw.splitlines()];assert [r[0] for r in values]==list(range(start,end)), 'incomplete heavy world trace'
 side=d/'game.replay.checksums';header=side.read_bytes()[:20];assert header[:4]==b'GCS1' and struct.unpack('<I',header[12:16])[0]==len(values), 'unclosed sidecar'
 return {'count':len(values),'first_tick':start,'end_tick_exclusive':end,'world_sha256':sha(world),'sidecar_sha256':sha(side)}
with (root.parent/'gpu-offload-resource.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 setup=subprocess.run(['sudo','-n','python3','-I',str(launcher),'setup'],capture_output=True,text=True);(output/'partition-setup.json').write_text(setup.stdout);assert setup.returncode==0,setup.stderr
 try:
  for v in m['headless_runs']:
   previous=None
   for stage in ['initial','continuation']:
    d=output/v['name']/stage;d.mkdir(parents=True,exist_ok=False);profile=d/'profile';profile.mkdir()
    if v['stored_preference'] is not None:(profile/'preferences.txt').write_text('gpuCompute='+str(int(v['stored_preference']))+'\n')
    f=fixture if stage=='initial' else previous/'final.game.gz';start=1024 if stage=='initial' else 1280;end=1280 if stage=='initial' else 1408
    command=[str(binary.resolve()),'game','run','--load-game',str(f),'--ticks',str(end),'--compute-threads',str(v['compute_threads']),'--save','final','--telemetry','checksums','--write-replay','--output-dir',str(d.resolve())]
    if v['gpu_cli'] is not None:command+=['--gpu',v['gpu_cli']]
    env={k:value for k,value in os.environ.items() if not k.startswith(('GLOB2_OPENCL_','GLOB2_GRADIENT_','GLOB2_TEST_'))};env['GLOB2_OPENCL_DEVICE']=str(v['device_ordinal']);(d/'environment.json').write_text(json.dumps({'GLOB2_OPENCL_DEVICE':env['GLOB2_OPENCL_DEVICE']}))
    began=time.time_ns()
    with (d/'engine.log').open('w') as log:run=subprocess.run(['sudo','-n','python3','-I',str(launcher),'run','--env-json',str(d/'environment.json'),'--',*command],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    row={'variant':v['name'],'stage':stage,'command':command,'environment':{'GLOB2_OPENCL_DEVICE':env['GLOB2_OPENCL_DEVICE']},'stored_preference':v['stored_preference'],'source_revision':m['reviewed_final_source'],'binary_sha256':sha(binary),'fixture_sha256':sha(f),'exit_code':run.returncode,'start_unix_ns':began,'end_unix_ns':time.time_ns(),'correctness_only':True,'valid':False}
    try:
     assert run.returncode==0,'game process failed';r=json.loads((d/'result.json').read_text());row['result']=r;assert r['ticks']==end;row['trace']=trace(d,end,start)
     if previous:assert r['initialChecksum']==json.loads((previous/'result.json').read_text())['finalChecksum'],'save reload mismatch'
     signature=[r['initialChecksum'],r['finalChecksum'],row['trace']]
     if stage not in reference:reference[stage]=signature
     assert signature==reference[stage],'CPU/GPU exact per-tick divergence'
     g=r['gradient_execution'];expected=v['expected_gpu_execution'];assert bool(r['gpu_requested'])==bool(v['gpu_cli']=='on' or (v['gpu_cli'] is None and v['stored_preference'] is not False)),'preference routing mismatch'
     if expected:assert g['gpu_complete_fields']>0 and g['device_dispatches']>0 and g['device_committed_fields']>0,'GPU requested but no actual nontrivial execution'
     else:
      assert g['device_dispatches']==0 and g['device_committed_fields']==0,'unexpected GPU work'
      if v['compute_threads']==1:assert g['cpu_reason_owner_excluded']>0
      elif v['device_ordinal']==999:assert g['cpu_reason_unavailable']>0 or g['fallback_reason_unavailable']>0
     assert r['compute_threads']==v['compute_threads'];row['valid']=True
    except Exception as error:row['error']=str(error)
    (d/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);(output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(v['name'],stage,row['valid'],row.get('error',''),flush=True)
    if not row['valid']:raise RuntimeError('finite correctness failed; preserve and stop')
    previous=d
 finally:
  c=subprocess.run(['sudo','-n','python3','-I',str(launcher),'cleanup'],capture_output=True,text=True);(output/'partition-cleanup.json').write_text(json.dumps({'exit_code':c.returncode,'stdout':c.stdout,'stderr':c.stderr},indent=2))
