import fcntl,hashlib,json,os,struct,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
root=Path.cwd();p=root/'artifacts/gpu-toggle-final/a77f37114';m=json.loads((p/'validation-matrix.json').read_text());launcher=root.parent/'cpu_partition_ten.py';binary=p/'glob2';out=p/'compatibility-canonical-replay';out.mkdir(exist_ok=True);rows=[]
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
base={k:v for k,v in os.environ.items() if not k.startswith(('GLOB2_OPENCL_','GLOB2_GRADIENT_','GLOB2_TEST_')) and k not in ['DISPLAY','WAYLAND_DISPLAY','SDL_VIDEO_DRIVER','SDL_VIDEODRIVER']};base.pop('GLOB2_REFERENCE_HEAVY',None);base['GLOB2_OPENCL_DEVICE']='0'
def invoke(d,command,e,xml=False):
 d.mkdir(parents=True,exist_ok=True);(d/'environment.json').write_text(json.dumps(e));env=base|e
 with (d/('results.xml' if xml else 'engine.log')).open('w') as log,(d/'stderr.log').open('w') as error:r=subprocess.run(['sudo','-n','python3','-I',str(launcher),'run','--env-json',str(d/'environment.json'),'--',*command],env=env,stdout=log,stderr=error,timeout=600)
 return r.returncode
with (root.parent/'gpu-offload-resource.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 setup=subprocess.run(['sudo','-n','python3','-I',str(launcher),'setup'],capture_output=True,text=True);(out/'partition-setup.json').write_text(setup.stdout);assert setup.returncode==0,setup.stderr
 try:
  d=out/'fresh-replay-recording';r=json.loads((d/'result.json').read_text());assert r['ticks']==96 and not r['gpu_requested']
  row={'id':'canonical-recording','exit_code':0,'result':r,'replay_sha256':sha(d/'game.replay'),'initial_save_sha256':sha(p/'compatibility-guards/fresh-replay-recording/initial.game.gz'),'loader_request_used_extension_resolution':True,'command_source':'run-canonical-replay.py original preserved command','valid':True};rows.append(row);(d/'receipt.json').write_text(json.dumps(row,indent=2)+'\n')
  d2=out/'replay-playback';d2.mkdir();profile=d2/'profile';profile.mkdir();runtime=d2/'xdg';runtime.mkdir(mode=0o700);e={'GLOB2_REFERENCE_REPLAY':str((d/'game.replay').resolve()),'GLOB2_GRADIENT_BACKEND':'cpu','GLOB2_USER_DATA_DIR':str(profile.resolve()),'GLOB2_TEST_ARTIFACTS_ROOT':str(d2.resolve()),'SDL_VIDEODRIVER':'dummy','SDL_AUDIODRIVER':'dummy','XDG_RUNTIME_DIR':str(runtime.resolve())};case='external replay retains recorded simulation checksums [benchmark][artifacts]';command=[str((p/'glob2-engine-tests').resolve()),'-r=xml','--no-breaks=true','--no-colors=true','-tc='+case];code=invoke(d2,command,e,True);doc=ET.parse(d2/'results.xml').getroot();totals=doc.find('OverallResultsAsserts');active=[c.get('name') for c in doc.findall('.//TestCase') if c.get('skipped')!='true'];traces=list(d2.rglob('external-replay.checksums.txt'));assert len(traces)==1;valid=code==0 and int(totals.get('failures'))==0 and active==[case] and len(traces[0].read_text().splitlines())==96;row={'id':'replay-playback','command':command,'environment':e,'exit_code':code,'successful_assertions':int(totals.get('successes')),'recorded_ticks':96,'playback_trace_rows':len(traces[0].read_text().splitlines()),'failed_assertions':int(totals.get('failures')),'trace_sha256':sha(traces[0]),'valid':valid};rows.append(row);(d2/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');print('Canonical replay valid:',valid,'trace rows:',len(traces[0].read_text().splitlines()),flush=True);assert valid
  (out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
 finally:
  c=subprocess.run(['sudo','-n','python3','-I',str(launcher),'cleanup'],capture_output=True,text=True);(out/'partition-cleanup.json').write_text(json.dumps({'exit_code':c.returncode,'stdout':c.stdout,'stderr':c.stderr},indent=2))
