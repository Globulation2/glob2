from pathlib import Path
import shlex,subprocess,json,concurrent.futures
root=Path('/Users/bradley/glob2/artifacts/building-recruitment');source=Path('/Users/bradley/.codex/worktrees/building-recruitment/glob2')
logs=[Path('/Users/bradley/glob2/artifacts/building-recruitment-macos-build.log')]+[root/f for f in ['macos-build-final.log','macos-build-retry.log','macos-build-complete.log','macos-build-verified.log']]
lines=[line for f in logs for line in f.read_bytes().decode(errors='replace').splitlines()]
def build(name,probe):
 command=next(l for l in reversed(lines) if l.endswith(name) and ' -c ' in l and ' -O3 ' in l)
 a=shlex.split(command);a[a.index('-o')+1]=str(root/(probe+'.canonical.o'));a[-1]=str(root/(probe+'.cpp'))
 assert any(str(source/'build') in x for x in a if 'GLOB2_RENDER_SHADER_DIR' in x)
 with (root/(probe+'.canonical-compile.log')).open('w') as f:subprocess.run(a,cwd=source,stdout=f,stderr=subprocess.STDOUT,check=True)
 return a
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 jobs=[pool.submit(build,'src/team/TeamStep.cpp','TeamStep.profile'),pool.submit(build,'src/building/Step.cpp','Step.profile')];records=[x.result() for x in jobs]
a=shlex.split(next(l for l in reversed(lines) if ' -o build/darwin/client/release/src/glob2 ' in l and ' -c ' not in l))
a[a.index('-o')+1]=str(root/'glob2-canonical-profile')
for i,x in enumerate(a):
 if x=='build/darwin/client/release/src/team/TeamStep.o':a[i]=str(root/'TeamStep.profile.canonical.o')
 if x=='build/darwin/client/release/src/building/Step.o':a[i]=str(root/'Step.profile.canonical.o')
with (root/'canonical-probe-link.log').open('w') as f:subprocess.run(a,cwd=source,stdout=f,stderr=subprocess.STDOUT,check=True)
records.append(a);(root/'canonical-probe-commands.json').write_text(json.dumps(records,indent=2)+'\n')
