from pathlib import Path
import subprocess,json,sys
root=Path('artifacts/entity-traversal');build='build/darwin/client/debug/dev-dev_fast-true-linker-auto'
common=[sys.executable,'test/run_tests.py','--build-dir',build,'--no-display','-j2','--timeout','300']
commands=[]
def run(label,args):
 cmd=common+args+['--junit',str(root/(label+'.xml'))];commands.append(cmd)
 (root/'integrated-test-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (root/(label+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print(label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
engine=['TeamLiveLists/*','IntrusivePopulationSave/*','Maxima.Director/tactical quarantine*','WorldSnapshot/*','JavaScriptIntegration/*','JavaScriptCompatibility/*','BuildingStock/*','UnitCustomization/conversion cancels pending transport*']
run('integrated-focused',['--binary','engine','--quick',*[a for g in engine for a in ['--filter',g]]])
unit=['WordChecksum','EntityRandom','BitArray','ReplayStepCounter','HiringRanking','Maxima.Defense','Maxima.FoodLedger','Maxima.ForceModel','Maxima.Labour','Maxima.Continuation','Maxima.Recon','Maxima.StaffingControl','Maxima.Tactics','TeamLayout','BaseTeamSaveLoad','AllyTeamWidgetIndex']
run('integrated-unit',['--binary','unit','--quick',*[a for g in unit for a in ['--filter',g+'/*']]])
run('integrated-golden',['--binary','engine','--quick','--tag','golden','--update-fixtures','--artifacts',str(root/'integrated-golden-artifacts')])
