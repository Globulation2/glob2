"""Check the changed building translation units with undefined-behavior guards."""
from concurrent.futures import ThreadPoolExecutor
import os
from pathlib import Path
import shlex
import subprocess

ROOT = Path(os.environ['GLOB2_REVIEW_ROOT']).resolve()
OUT = ROOT/'artifacts/material-demand/ubsan'
OUT.mkdir(exist_ok=False)
lines = (ROOT/'artifacts/material-demand/build.log').read_text().splitlines()
objects = {}


def compile_one(source):
    target = str(OUT/(Path(source).stem+'.o'))
    original = 'build/material-demand/'+('test/engine-src_building_MaterialDemandTest.o' if source.endswith('Test.cpp') else source[:-4]+'.o')
    command = shlex.split(next(line for line in lines if line.startswith('/usr/bin/ccache ') and '-o '+original+' -c ' in line))
    command[command.index('-o')+1] = target
    command += ['-fsanitize=undefined','-fno-sanitize-recover=all']
    with (OUT/(Path(source).stem+'-compile.log')).open('w') as log:
        log.write('$ '+shlex.join(command)+'\n'); log.flush()
        subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    return original,target


with ThreadPoolExecutor(max_workers=4) as pool:
    objects.update(pool.map(compile_one,['src/building/Construction.cpp','src/building/Step.cpp','src/building/Update.cpp','src/building/MaterialDemandTest.cpp']))
link = shlex.split(next(line for line in lines if line.startswith('g++-13 -o build/material-demand/src/glob2 ')))
link = [objects.get(value,value) for value in link if value!='build/material-demand/src/app/Glob2.o']
link[link.index('-o')+1] = str(OUT/'building-demand-ubsan')
support = ['support_TestMain','support_Glob2Test','support_GlobalContainerSlot','support_EngineFixtures','support_LegacyResourceTypes']
link = link[:3]+['build/material-demand/test/engine-'+name+'.o' for name in support]+[objects['build/material-demand/test/engine-src_building_MaterialDemandTest.o'],'-fsanitize=undefined']+link[3:]
with (OUT/'link.log').open('w') as log:
    log.write('$ '+shlex.join(link)+'\n'); log.flush()
    subprocess.run(link,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
command=[str(OUT/'building-demand-ubsan'),'-ts=BuildingMaterialDemand','-no-colors','-r=junit','-o='+str(OUT/'tests.xml')]
env=dict(os.environ,GLOB2_TEST_SOURCE_ROOT=str(ROOT),GLOB2_TEST_ARTIFACTS_ROOT=str(OUT/'cases'),UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
with (OUT/'run.log').open('w') as log:
    log.write('$ '+shlex.join(command)+'\n'); log.flush()
    subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Building material demand: eight cases passed with UBSan on Construction, Step, Update and the oracle.')
