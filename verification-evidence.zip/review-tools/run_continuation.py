import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import os
root = Path(os.environ['GLOB2_REVIEW_ROOT']).resolve()
spec = importlib.util.spec_from_file_location('demand_benchmark', Path(__file__).parent / 'tools/material_demand_benchmark.py')
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)
output = root / 'artifacts/material-demand/continuation'
output.mkdir(exist_ok=False)
args = SimpleNamespace(game_binary=root/'build/material-demand/src/glob2',
    baseline_game=root/'artifacts/material-demand/baseline-source/build/material-demand/src/glob2',
    save=None, start_tick=24000, ticks=25153, measure=False)
proof = bench.simulation_fixture(args, output)
assert proof['ticks'] == args.ticks, 'The saved fixture stopped before the requested endpoint'
trace = (output/'candidate/world.checksums').read_text().splitlines()
assert len(trace) == args.ticks-args.start_tick, 'Incomplete per-tick continuation evidence'
proof['compared_tick_checksums'] = len(trace)
proof['trace_first_tick'] = int(trace[0].split()[0])
proof['trace_last_tick'] = int(trace[-1].split()[0])
for name, expected in [('initial',args.start_tick),('continuous',args.ticks+128),('resumed',args.ticks+128)]:
    result = json.loads((output/name/'result.json').read_text())
    assert result['ticks'] == expected, f'{name} stopped before its requested endpoint'
(output/'fixture.json').write_text(json.dumps(proof, indent=2)+'\n')
print(json.dumps(proof, indent=2))
