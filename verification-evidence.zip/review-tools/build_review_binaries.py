"""Build one-off benchmark and baseline regression executables from release objects."""
import json
import os
from pathlib import Path
import shlex
import subprocess

ROOT = Path(os.environ['GLOB2_REVIEW_ROOT']).resolve()
OUT = ROOT/'artifacts/material-demand'
TOOLS = OUT/'review-tools'
BUILD = Path('build/material-demand')


def run(command, cwd, log):
    log.write('$ '+shlex.join(map(str, command))+'\n')
    log.flush()
    subprocess.run(list(map(str, command)), cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=True)


def compile_template(lines):
    return shlex.split(next(line for line in lines if line.startswith('/usr/bin/ccache ') and
                            'engine-src_building_MaterialDemandTest.o -c ' in line))


def compile_source(template, source, output, root, log):
    command = template.copy()
    command[command.index('-o')+1] = str(output)
    command[-1] = str(source)
    command += ['-I'+str(TOOLS/'src/building')]
    run(command, root, log)


def main():
    candidate_lines = (OUT/'build.log').read_text().splitlines()
    template = compile_template(candidate_lines)
    results = {}
    for name, root, logfile in [('candidate', ROOT, 'build.log'),
                                ('baseline', OUT/'baseline-source', 'baseline-build.log')]:
        lines = (OUT/logfile).read_text().splitlines()
        link = shlex.split(next(line for line in lines if line.startswith('g++-13 -o build/material-demand/src/glob2 ')))
        # Match the ordinary game link, replacing only its entry point with the
        # repository's five test-support objects and this measurement fixture.
        link = [value for value in link if value != 'build/material-demand/src/app/Glob2.o']
        support_names = ['support_TestMain', 'support_Glob2Test', 'support_GlobalContainerSlot',
                         'support_EngineFixtures', 'support_LegacyResourceTypes']
        support = [BUILD/'test'/('engine-'+value+'.o') for value in support_names]
        with (OUT/(name+'-review-build.log')).open('w') as log:
            environment = dict(os.environ, GLOB2_SDL3_PREFIX='/home/bradley/.codex/worktrees/repair-tls-rejection-fixture/glob2/build/sdl3-ci/prefix')
            command = ['python3','tools/dev_build.py','dev_fast=0','release=1','retain_symbols=1',
                       'CC=gcc-13','CXX=g++-13','--build=build/material-demand','-j8',*map(str,support)]
            log.write('$ '+shlex.join(command)+'\n'); log.flush()
            subprocess.run(command,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT,check=True)
            obj = OUT/(name+'-benchmark.o')
            compile_source(template, TOOLS/'src/building/MaterialDemandBenchmark.cpp', obj, root, log)
            executable = OUT/(name+'-benchmark')
            link[link.index('-o')+1] = str(executable)
            command = link[:3]+list(map(str,support))+[str(obj)]+link[3:]
            run(command,root,log)
            results[name] = str(executable)
    (OUT/'review-binaries.json').write_text(json.dumps(results,indent=2)+'\n')


if __name__ == '__main__':
    main()
