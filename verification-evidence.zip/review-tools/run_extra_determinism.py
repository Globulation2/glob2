"""Compare early construction and serial/eight-participant saved execution."""
from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
import os
from pathlib import Path
import subprocess

ROOT=Path(os.environ['GLOB2_REVIEW_ROOT']).resolve()
OUT=ROOT/'artifacts/material-demand/determinism'
OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('demand_benchmark',Path(__file__).parent/'tools/material_demand_benchmark.py')
bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
candidate=ROOT/'build/material-demand/src/glob2'
baseline=ROOT/'artifacts/material-demand/baseline-source/build/material-demand/src/glob2'


def run(binary,args,name,threads):
    folder=OUT/name;folder.mkdir()
    command=[str(binary),'game','run',*args,'--compute-threads',str(threads),'--gpu','off','--output-dir',str(folder)]
    (folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
    with (folder/'stdout.log').open('w') as out,(folder/'stderr.log').open('w') as err:
        subprocess.run(command,cwd=ROOT,stdout=out,stderr=err,check=True,timeout=900)
    return json.loads((folder/'result.json').read_text())


opening=['--map-file',str(ROOT/'maps/Playground.map.gz'),'--game-seed','713','--ticks','4096','--telemetry','checksums','--write-replay','--save','final']+['--player','nicowar']*8
with ThreadPoolExecutor(max_workers=2) as pool:
    a=pool.submit(run,baseline,opening,'opening-baseline',8)
    b=pool.submit(run,candidate,opening,'opening-candidate',8)
    results=[a.result(),b.result()]
assert all(r['ticks']==4096 for r in results)
bench.compare_traces(OUT/'opening-baseline',OUT/'opening-candidate')
assert bench.sha(OUT/'opening-baseline/game.replay')==bench.sha(OUT/'opening-candidate/game.replay')
checkpoint=ROOT/'artifacts/material-demand/continuation/normalized/initial.game.gz'
serial=run(candidate,['--load-game',str(checkpoint),'--ticks','25153','--save','final','--telemetry','checksums','--write-replay'],'saved-serial',1)
assert serial['ticks']==25153
parallel=ROOT/'artifacts/material-demand/continuation/candidate'
bench.compare_traces(parallel,OUT/'saved-serial')
assert bench.sha(parallel/'game.replay')==bench.sha(OUT/'saved-serial/game.replay')
proof={'opening_ticks_compared':4096,'saved_ticks_compared':1153,'baseline_candidate_equal':True,'serial_eight_equal':True,
       'opening_trace_sha256':bench.sha(OUT/'opening-candidate/world.checksums'),
       'saved_trace_sha256':bench.sha(OUT/'saved-serial/world.checksums')}
(OUT/'fixture.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
