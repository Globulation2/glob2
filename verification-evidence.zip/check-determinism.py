from pathlib import Path
import sys,subprocess,hashlib,json
binary=Path(sys.argv[1]).resolve()
root=Path(__file__).resolve().parent/'determinism'
root.mkdir(exist_ok=True)
commands=[]
def run(label,args):
 output=root/label;output.mkdir(exist_ok=False)
 command=[str(binary),'game','run',*map(str,args),'--output-dir',str(output)]
 commands.append(command)
 with (output/'engine.log').open('w') as log:
  subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 return output
def file(output,name):
 p=output/name
 return p if p.exists() else Path(str(p)+'.gz')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
players=['nicowar','castor','numbi','maxima']*2
setup=['--generator','15','--map-seed','4242','--set','width=7','--set','height=7','--set','teams=8','--game-seed','19']
for ai in players:setup+=['--player',ai]
initial=run('fixture',setup+['--ticks','1','--save','initial','--compute-threads','1'])
start=file(initial,'initial.game')
common=['--load-game',start,'--ticks','256','--telemetry','checksums','--write-replay','--save','final']
a=run('serial',common+['--compute-threads','1'])
b=run('parallel',common+['--compute-threads','8'])
hashes={}
for name in ['game.replay.checksums','game.replay','final.game']:
 hashes[name]=sha(file(a,name));assert hashes[name]==sha(file(b,name)),name
# Same saved checkpoint, two compute sizes: every continuation tick must match.
common=['--load-game',file(a,'final.game'),'--ticks','320','--telemetry','checksums','--write-replay','--save','final']
c=run('continued-serial',common+['--compute-threads','1'])
d=run('continued-parallel',common+['--compute-threads','8'])
for name in ['game.replay.checksums','game.replay','final.game']:
 hashes['continued/'+name]=sha(file(c,name));assert hashes['continued/'+name]==sha(file(d,name)),name
(root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(root/'hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
print('PASS: eight-player mixed-AI serial/8-thread traces, replay bytes, and saves match; loaded continuation also matches')
