from pathlib import Path
import subprocess

def git(*args,data=None):
 return subprocess.check_output(['git',*args],input=data).decode().strip()
archive=Path('artifacts/entity-traversal/verification-evidence.zip')
readme=Path('docs/.work/entity-traversal-evidence-draft.md')
blob=git('hash-object','-w',str(archive));doc=git('hash-object','-w',str(readme))
tree=git('mktree',data=f'100644 blob {blob}\tverification-evidence.zip\n100644 blob {doc}\tREADME.md\n'.encode())
ref='refs/heads/codex/entity-traversal-evidence'
prior=subprocess.run(['git','rev-parse','--verify',ref],capture_output=True,text=True)
args=['commit-tree',tree]
if prior.returncode==0:args+=['-p',prior.stdout.strip()]
commit=git(*args,data=b'Attach intrusive population verification evidence\n')
git('update-ref',ref,commit)
subprocess.run(['git','push','origin',ref],check=True)
print(commit)
