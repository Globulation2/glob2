from pathlib import Path
import sys,subprocess,json,hashlib
sys.path.insert(0,str(Path('test').resolve()))
from check_telemetry_simulation import detailed_ticks
root=Path('artifacts/entity-traversal/determinism-reviewed').resolve()
out=root/'uninterrupted';out.mkdir(exist_ok=False)
binary=Path('build/darwin/client/debug/dev-dev_fast-true-linker-auto/src/glob2').resolve()
command=[str(binary),'game','run','--load-game',str(root/'fixture/initial.game.gz'),'--ticks','320','--telemetry','checksums','--write-replay','--save','final','--compute-threads','1','--output-dir',str(out)]
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'engine.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
full=detailed_ticks((out/'game.replay.checksums').read_bytes())
resumed=detailed_ticks((root/'continued-serial/game.replay.checksums').read_bytes())
assert resumed and all(full[tick]==state for tick,state in resumed.items())
summary={'matched_ticks':len(resumed),'first':min(resumed),'last':max(resumed),'per_tick_team_entity_sha256':{str(t):hashlib.sha256(s).hexdigest() for t,s in resumed.items()}}
(out/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PASS: eight-player mixed-AI saved continuation matches uninterrupted per-tick team/entity state across',len(resumed),'ticks')
