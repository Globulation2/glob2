from pathlib import Path
import gzip, hashlib, json
root=Path(__file__).parent
pairs=[('base12k','canonical12k'),('base24k','canonical24k'),('base24k-serial','canonical24k-serial')]
rows=[]
for base,new in pairs:
    a=json.loads((root/base/'result.json').read_text()); b=json.loads((root/new/'result.json').read_text())
    row=dict(base=base,optimized=new,ticks=b['ticks'],routine_final_checksum=b['finalChecksum'])
    assert (a['ticks'],a['initialChecksum'],a['finalChecksum'])==(b['ticks'],b['initialChecksum'],b['finalChecksum'])
    for name in ['world.checksums','snapshot.checksums']:
        x=(root/base/name).read_bytes(); y=(root/new/name).read_bytes()
        assert x==y,(base,new,name)
        row[name]=dict(identical=True,rows=len(x.splitlines()),sha256=hashlib.sha256(x).hexdigest())
    x=gzip.decompress((root/base/'final.game.gz').read_bytes());y=gzip.decompress((root/new/'final.game.gz').read_bytes())
    row['final_save_identical']=x==y
    if x!=y:
        row['save_first_difference']=next((i for i,(u,v) in enumerate(zip(x,y)) if u!=v),min(len(x),len(y)))
    rows.append(row)
(root/'canonical-behavior-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
