"""Restore deduplicated artifact paths and verify every retained file."""
import hashlib
import json
from pathlib import Path
import shutil

root = Path(__file__).resolve().parent
aliases = json.loads((root / 'DUPLICATES.json').read_text())
for target, source in aliases.items():
    destination = root / target
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / source, destination)
manifest = json.loads((root / 'SHA256SUMS.json').read_text())
for relative, expected in manifest.items():
    content = (root / relative).read_bytes()
    assert len(content) == expected['bytes'], relative
    assert hashlib.sha256(content).hexdigest() == expected['sha256'], relative
print(f'Verified {len(manifest)} files; restored {len(aliases)} identical copies.')
