#include "src/team/IntrusiveEntityList.h"
#include <memory>
struct Node {
 Node* populationPrevious=nullptr;
 Node* populationNext=nullptr;
 const void* populationMembership=nullptr;
 int gid;
 static int GIDtoID(int id) { return id; }
};
int main() {
 IntrusiveEntityList<Node> source,destination;
 auto current=std::make_unique<Node>();
 auto pending=std::make_unique<Node>();
 auto survivor=std::make_unique<Node>();
 auto tail=std::make_unique<Node>();
 auto arrival=std::make_unique<Node>();
 auto resident=std::make_unique<Node>();
 source.append(*current);source.append(*pending);source.append(*survivor);source.append(*tail);
 destination.append(*resident);
 {
  auto destinationBefore=destination.mutableWalk();
  auto outer=source.mutableWalk();
  assert(outer.next()==current.get());
  auto nested=source.mutableWalk();
  assert(nested.next()==current.get());
  source.remove(*current);current.reset();
  source.remove(*pending);pending.reset();
  source.append(*arrival);
  source.remove(*tail);tail.reset(); // Both original fences now refer to survivor.
  source.remove(*survivor);destination.append(*survivor); // Repair both pending pointers.
  assert(!outer.next());assert(!nested.next()); // Arrival is excluded from both walks.
  assert(destinationBefore.next()==resident.get());assert(!destinationBefore.next());
  auto destinationAfter=destination.mutableWalk();
  assert(destinationAfter.next()==resident.get());
  destination.remove(*resident);resident.reset();
  assert(destinationAfter.next()==survivor.get());
  destination.remove(*survivor);survivor.reset();
  assert(!destinationAfter.next());
 }
 assert(source.front()==arrival.get());
 source.remove(*arrival);arrival.reset();
 assert(source.empty() && destination.empty());
}
