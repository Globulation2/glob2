import json, os, subprocess, time
from pathlib import Path
R=Path(__file__).resolve().parents[3]; B=R/'artifacts/ci-recovery'; D=Path(__file__).resolve().parent; W=B/'telemetry-translations'; runtime=D/'runtime'
config=D/'playwright.config.cjs'
config.write_text('const base=require('+json.dumps(str(W/'browser/playwright.config.js'))+');module.exports={...base,testDir:'+json.dumps(str(W/'browser/tests'))+',testMatch:["marathi.spec.js","bulgarian.spec.js","thai-localization.spec.js"],workers:1,reporter:[["list"],["junit"]]};')
env=dict(os.environ,GLOB2_TEST_URL='http://127.0.0.1:8841',GLOB2_TEST_BUILD_DIR=str(runtime),GLOB2_TEST_RENDERER='software',GLOB2_FIREFOX_HEADED='1',GLOB2_BUILD_DIR=str(B/'comb-stack-repair/build/stack-release'),LD_LIBRARY_PATH=str(B/'comb-stack-repair/build/ci-prefix/lib'),PLAYWRIGHT_JUNIT_OUTPUT_FILE=str(D/'browser-junit.xml'))
env['PATH']=str(B/'node/node_modules/.bin')+':'+env['PATH']
state=dict(pid=os.getpid(),phase='validating original language fixtures with updated real catalogs',catalog_source=str(W),compiled_runtime_revision='1d09ddbff80f3cf916f1163a99a9899149ab31c4',runtime_provenance=str(D/'runtime-provenance.json'),note='All original assertions/deadlines preserved. Catalog-only qualification with historical engine, private runtime and headed Firefox adapter; current full engine matrix remains separate.')
def save(): (D/'browser-status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
command=['xvfb-run','-a','-s','-screen 0 2560x2048x24 -noreset','node',str(W/'browser/node_modules/@playwright/test/cli.js'),'test','--config='+str(config),'--grep','native catalog, settings and tutorial render in Marathi|selecting Bulgarian in Settings survives a reload|Thai startup, composed input and refresh use the shipped catalog','--output='+str(D/'browser-results'),'--trace=retain-on-failure']
state['command']=command;save()
with (D/'browser-server.log').open('w')as sl:
    server=subprocess.Popen(['python3',str(B/'serve_ci_layout.py'),'8841','--directory',str(runtime)],stdout=sl,stderr=subprocess.STDOUT)
    try:
        with (D/'browser-validation.log').open('w')as log:code=subprocess.call(command,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT)
    finally: server.terminate();server.wait()
state.update(phase='finished; inspect actual JUnit/results',exit_code=code);save()
