from pathlib import Path
import subprocess,json,time,hashlib,gzip
root=Path('/Users/bradley/.codex/worktrees/building-recruitment/glob2');out=Path('/Users/bradley/glob2/artifacts/building-recruitment/integration');binary=root/'build/darwin/client/release/src/glob2';inputs=Path('/Users/bradley/glob2/artifacts/sim-callgrind-master-486a2230a/inputs');commands=[]
while True:
 s=(out/'macos-build.log').read_text()
 if 'scons: done building targets.' in s:break
 if 'scons: building terminated' in s:raise RuntimeError('build failed')
 time.sleep(5)
def run(args,label):
 args=[str(x) for x in args];commands.append({'label':label,'argv':args});(out/'macos-commands.json').write_text(json.dumps(commands,indent=2))
 print(label,flush=True)
 with (out/(label+'.log')).open('w') as f:subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
run(['python3','test/run_tests.py','--build-dir','build/darwin/client/release','--binary','engine','--filter','BuildingMaterialDemand/*','--filter','Hiring*/*','--filter','FetchHiringScore/*','--filter','UnitContinuation/*','--filter','InnSwap/*','--filter','GradientPreparation/*','--filter','GradientDemandQueue/*','--no-display','-j3','--junit',out/'macos-tests.xml','--artifacts',out/'macos-tests'],'macos-tests')
results={}
for name,save,ticks,threads in [('12k','midgame12k.game.gz',13153,8),('24k','midgame24k.game.gz',25153,8),('24k-serial','midgame24k.game.gz',25153,1)]:
 dest=out/('macos-'+name)
 run([binary,'game','run','--load-game',inputs/save,'--compute-threads',threads,'--gpu','off','--ticks',ticks,'--telemetry','checksums','--save','final','--output-dir',dest],'macos-'+name)
 checks={}
 for n in ['world.checksums','snapshot.checksums','final.game.gz']:
  b=(dest/n).read_bytes()
  if n.endswith('.gz'):b=gzip.decompress(b)
  checks[n]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'rows':len(b.splitlines()) if not n.endswith('.gz') else None}
 for sidecar in dest.glob('*.replay.checksums'):sidecar.unlink()
 results[name]=checks;(out/'macos-behavior.json').write_text(json.dumps(results,indent=2))
run([binary,'match','verify','test/fixtures/multiplayer/FourSquares1.g2mr','--map-file','maps/FourSquares1.map.gz','--compute-threads',8,'--output-dir',out/'macos-golden'],'macos-golden')
print('MACOS INTEGRATION COMPLETE',flush=True)
