import importlib.util,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('observe',Path(__file__).with_name('observe.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BASE='''Game
{
Map
{
wDec=0;
hDec=0;
undermap=02;
cases
{
0
{
terrain=14;
RESOURCE
}
}
}
teams
{
0
{
Team
{
startPosX=0;
startPosY=0;
}
}
}
}
'''
class Tests(unittest.TestCase):
 def parse(self,text):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'map.txt';p.write_text(text);return m.parse(p)
 def test_old_new_normalization(self):
  self.assertEqual(self.parse(BASE.replace('RESOURCE','ressource=ff000000;')),self.parse(BASE.replace('RESOURCE','resourceType=65535;\nresourceStock=0;')))
 def test_amount_changes_full_only(self):
  a=self.parse(BASE.replace('RESOURCE','ressource=03000400;'));b=self.parse(BASE.replace('RESOURCE','ressource=03000500;'))
  self.assertNotEqual(a['full'],b['full']);self.assertEqual(a['topology'],b['topology'])
 def test_truncation(self):
  with self.assertRaises(ValueError):self.parse(BASE.replace('RESOURCE','ressource=03000400;').rstrip()[:-1])
 def test_missing_cells(self):
  with self.assertRaises(ValueError):self.parse(BASE.replace('wDec=0','wDec=1').replace('RESOURCE','ressource=03000400;'))
 def test_duplicate_field(self):
  with self.assertRaises(ValueError):self.parse(BASE.replace('RESOURCE','ressource=03000400;\nterrain=14;'))
 def test_ambiguous_anchor(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'golden';p.write_text('linux-x86_64 65 4 9 8 4 1 ok 1\n'*2)
   with self.assertRaises(ValueError):m.expected(p,'linux-x86_64',9,8,1)
if __name__=='__main__':unittest.main()
