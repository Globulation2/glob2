import pathlib,json,shutil
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=pathlib.Path(__file__).resolve().parent;s=json.loads((root/'summary.json').read_text())
fig,axes=plt.subplots(1,2,figsize=(10,4))
for ax,a,b,t in [(axes[0],'agreement_direction_equal','agreement_compared','Conditional exact agreement'),(axes[1],'agreement_compared','agreement_opportunities','Usable comparison coverage')]:
 vals=[100*c[a]/c[b] for c in s];ax.plot(range(9),vals,'o-',color='#1565c0');ax.set(xlabel='Configured delay (ticks)',ylabel='Percent (magnified scale)',title=t,xticks=range(9));ax.grid(alpha=.2)
 for i in [0,8]:ax.annotate(f'{vals[i]:.2f}%',(i,vals[i]),xytext=(0,10 if i==0 else -20),textcoords='offset points',ha='center')
fig.suptitle('Small changes across delays — six games, descriptive counts\nDifferent comparison denominators; zero does not mean fresh-at-action planning',fontsize=11);fig.tight_layout();fig.savefig(root/'agreement-delay-detail.png',dpi=170)
shutil.copy2(root/'agreement-delay-detail.png',root.parent.parent/'docs/.work/compact-core-evidence-publish/agreement-delay-detail.png')
