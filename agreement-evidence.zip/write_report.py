import pathlib,json,collections
root=pathlib.Path(__file__).resolve().parent;out=root.parent.parent/'docs/.work/compact-core-evidence-publish'
s=json.loads((root/'summary.json').read_text());rows=json.loads((root/'observations.json').read_text());proto=json.loads((root/'protocol.json').read_text())
def pct(c,a,b):return 100*c.get(a,0)/c.get(b,1) if c.get(b,0) else float('nan')
def mode(d,m):
 c=collections.Counter()
 for r in rows:
  if r['delay']==d and r['mode']==m:c.update({k:v for k,v in r.items() if isinstance(v,int)})
 return c
text='''# Real-game movement direction agreement: diagnostic delays 0–8

Six active AI matches were replayed from identical initial saves at every diagnostic delay from 0 through 8, alongside an unconfigured reference run. All 54 reference/diagnostic pairs match per-tick world checksums, replay bytes, replay checksum files and decompressed final-save payloads. This is an unchanged reference trajectory with conditional counterfactual steps, **not gameplay with adopted movement**. Movement stays Stage A, and the PR stays draft.

The additional presentation split was cancelled after auditing actual AI reads. The existing authoritative core/detail split is unchanged. AI health/hunger, experience, construction, cargo, facing and under-attack dependencies remain in core; no presentation layer has been implemented. JavaScript observations also expose these gameplay fields. Only the two animation clocks were clearly presentation-only in the audited compact record, representing eight field bytes rather than a large headless saving.

## Agreement across delays

Each action is classified into eight directions or stay. The proposal is the suggestion's first currently legal direction, or stay for no route/goal reached/no legal direction. Exact agreement counts equal outcomes; moving-only agreement restricts the denominator to actions where both policies move. Coverage is compared actions divided by eligible reference travel completions. Missing/rejected/cancelled suggestions are coverage losses, not matches or invented fallback outcomes.

| Delay | Compared actions | Exact direction/stay | Moving-only direction | Move/stay agreement | Comparison coverage | Mean observation age |
|---:|---:|---:|---:|---:|---:|---:|
'''
for c in s:
 text+=f"| {c['delay']} | {c['agreement_compared']:,} | {pct(c,'agreement_direction_equal','agreement_compared'):.2f}% | {pct(c,'agreement_moving_direction_equal','agreement_both_move'):.2f}% | {pct(c,'agreement_move_stay_equal','agreement_compared'):.2f}% | {pct(c,'agreement_compared','agreement_opportunities'):.2f}% | {c['agreement_observation_age_ticks']/c['agreement_compared']:.2f} ticks |\n"
text+='''
![Pooled counts and individual games](agreement-delay.png)

The curves are nearly flat in this corpus. Zero means immediate serial computation/publication **at admission**, using the completed-world snapshot; it does not recompute at each action. Requests may be admitted after assignment or the preceding action and retained until completion. Thus zero already has substantial observation age, and this is not a fresh-at-decision zero-delay policy comparison. Nonzero delays use the existing executor with configured publication deadlines. The allowed live-trial delays remain unchanged.

Rates are descriptive census counts for these games. Actions are correlated within games, and the six games reuse three gameplay seeds across two terrain styles. No independent-action confidence interval or population-level significance is claimed. Per-game lines show heterogeneity; pooled rates are weighted by compared actions. Higher delay changes which actions have a usable suggestion, so rates at different delays have different denominators. In particular, an apparent rise in pursuit agreement must be read beside falling pursuit coverage.

![Travel-mode comparison and coverage](agreement-modes.png)

| Mode | Delay-0 compared / opportunities | Exact agreement: 0 → 8 | Coverage: 0 → 8 |
|---|---:|---:|---:|
'''
for m in ['idle','explore','resource','building','pursuit','clearing']:
 a=mode(0,m);b=mode(8,m)
 if not a['agreement_opportunities']:text+=f'| {m} | 0 / 0 | Not observed | Not observed |\n';continue
 text+=f"| {m} | {a['agreement_compared']:,} / {a['agreement_opportunities']:,} | {pct(a,'agreement_direction_equal','agreement_compared'):.2f}% → {pct(b,'agreement_direction_equal','agreement_compared'):.2f}% | {pct(a,'agreement_compared','agreement_opportunities'):.2f}% → {pct(b,'agreement_compared','agreement_opportunities'):.2f}% |\n"
text+='''
Resource steering agrees about three quarters of the time among compared suggestions. Wandering and exploration use private planning randomness, so low direction agreement alone does not imply poor gameplay. Building travel has very poor coverage; its agreement percentage describes a small selected subset. At delay zero there are 45,694 building destination rejections. Inspection finds the existing destination checker applies supplier/home restrictions to a building-tagged destination (including `supplier != home`) before the Resource-specific stock check. A normal destination can be the assigned home building. This is a validation-semantics issue requiring correction and fresh measurement before adoption; the curve does not justify building-policy equivalence. It was left visible in this measurement rather than silently changing the policy under test.

Clearing was not observed. Pursuit has low coverage and a small comparison population. These ordinary growing matches do not provide the sustainable 1,000-worker workload, comprehensive flying/congestion/clearing coverage, mirrored combat seeds or the 30-seed gameplay trial required by the original plan.

![Mean input age at actual comparison](agreement-age.png)

## What is compared

The observer runs after the reference medical/activity/displacement and movement preparation, before reference action execution. It validates identity, task, action generation, position, destination and the first locally legal step against current terrain/occupancy/forbidden/hazard checks. The reference action executes once, in existing unit order; the final committed wrapped cell supplies the actual move/stay outcome. Non-travel transitions or unexpected displacement cancel comparison.

Target acquisition, stock claims and service transitions have already followed the reference path. This measures conditional steering after those decisions; it does not measure agreement of an independent destination-selection/adoption policy or a simulated alternative future. The destination-coordinate counters compare stored coordinates only, not supplier/claim semantics. GoalReached/NoRoute proposals model stay; a missing/rejected suggestion has no modeled live fallback. Workers do not touch gameplay RNG and diagnostics do not write canonical state.

CSV traces contain the first 64 matches and first 64 differences per team/mode, with identity, sequence, input/publication/action ticks, origin, outcomes and destination coordinates. These are bounded examples, not random distribution samples. Aggregate counters and 9×9 confusion counts include every compared action. No trace-write errors occurred.

## Corpus and reproducibility

All games use existing generator settings: 128×128, two teams, eight initial workers, scalar gradient backend and four compute participants. Each initial game is generated/saved at tick one, then every mode loads that same save and runs to absolute tick 12,000 (11,999 further ticks). Controllers remain active and issue real orders. Initial saves, reference replays, checksum files and final saves are published, not only synthetic fixture outputs.

| Match | Map seed | Gameplay seed | Controllers | End units / buildings by team |
|---|---:|---:|---|---|
'''
for g in proto['games']:
 r=json.loads((root/g['name']/'reference/result.json').read_text());end='; '.join(f"T{t['team']}: {t['units']} / {t['buildings']}" for t in r['teams'])
 text+=f"| {g['name']} | {g['map_seed']} | {g['game_seed']} | {' vs '.join(g['players'])} | {end} |\n"
text+='''
The report does not claim FPS/TPS, concurrency or timing benefit from instrumented runs, and no exclusive CPU reservation is claimed here. Timing experiments remain in the separate live-measurement report.

Five additional controls use the first arena game: the pre-dense-sweep release binary without movement diagnostics; one participant at delays 0, 3 and 8; and four participants at delay 3 without trace output. All match the reference canonical payloads; all four agreement-enabled controls also match the aggregate agreement counters. Initial controls omitted the team-timeline telemetry selector and their saved payloads differed; those results are retained as `control-mismatched-telemetry.json`. With identical telemetry selectors the saves match. Do not compare canonical save bytes across differing collection configurations.

## Verification and source

Source: `e09f80733c8c99533925baede8f24abc3427e4d0`; measurement implementation commit `54c2ce8d0`; base `277510840054b1416f2defd7d86fe1431dd0ddc0`. Master was fetched again before final integration validation and remained at that base. Linux x86-64, GCC 15.2, pinned existing SDL 3.4.16 and existing dependencies. No runtime dependency, save/replay/network version or SIM_REVISION changes.

The corpus binary was built with ordinary `scons release=1 --build=build/movement-release -j12 build/movement-release/src/glob2`, `-O3`, from the working tree subsequently committed as the measurement implementation. Its build revision stamp predates that commit; the exact binary hash and commands are in the protocol. Subsequent game-source change was indentation only; the final commit adds the repaired CLI test fixture. Final source integration was rebuilt separately and checked against the frozen corpus.

Focused development validation: 60 cases / 161,576 assertions pass across MovementPlanning, CommandLine, WorldSnapshot, SharedWorkerLifecycle and SimulationReadPhase. The suites already belong to the native compatibility registry. Tests include all nine move/stay outcomes, dense diagnostic delay range, zero publication, canonical state across delay phases, snapshot lifetime and shared simulation/worker boundaries. The CLI test initially omitted required input arguments; the failed runs and corrected fixture are retained. Documentation: 309 Markdown documents, zero errors. This scope covers the new diagnostic path; it does not rerun or replace the earlier complete representation/refactor verification. macOS arm64, Windows x64 and browser serial/threaded execution are unavailable.

**Recommendation:** retain Stage A and the current two-layer layout. The measured sweep supplies steering agreement evidence, but does not qualify live adoption or infer win rates, economy, travel-time quality or congestion. Repair destination validation and cover missing workload/mode populations before any stronger gameplay conclusion. No original performance/gameplay gate was relaxed.

## Reviewer-accessible evidence

[Commands, traces, metrics, analysis/plot scripts, build/test logs and control results](agreement-evidence.zip) · [Protocol and binary hash](agreement-protocol.json) · [Source/platform metadata](agreement-provenance.json) · [All comparison results](agreement-comparisons.json) · [Control results](agreement-control-comparisons.json) · [Per-team/mode counts](agreement-observations.csv) · [Canonical payload SHA-256 manifest](agreement-canonical-payload-manifest.json).

Canonical payloads are deduplicated in the archives: every diagnostic output maps by SHA-256 to its reference payload, rather than publishing 54 identical replay/checksum sets. The manifest includes on-disk and decompressed save hashes. Each archive includes the initial generator output/save and actual reference replay, checksums and final save:

'''
for g in proto['games']:text+=f"- [{g['name']}](agreement-{g['name']}.zip)\n"
(out/'agreement-report.md').write_text(text)
