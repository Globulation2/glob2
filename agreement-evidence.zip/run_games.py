import os,sys,json,pathlib,subprocess,time,hashlib
root=pathlib.Path(__file__).resolve().parent
binary=pathlib.Path(sys.argv[1]).resolve()
games=[{'name':f'{g}-{s}', 'generator':g,'map_seed':1100+s,'game_seed':100+s,'players':p} for g in ['symmetric-arena','river'] for s,p in [(1,['cortex','warrush']),(2,['nicowar','warrush']),(3,['cortex','nicowar'])]]
(root/'protocol.json').write_text(json.dumps({'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'ticks':12000,'compute_threads':4,'games':games,'delays':list(range(9)),'reference':'no diagnostic','trace':'first 64 per outcome per team/mode; all aggregate counts retained'},indent=2))
commands=[]
def run(name,args,trace=False):
 out=root/name;out.mkdir(parents=True,exist_ok=True)
 env=os.environ.copy();env['GLOB2_USER_DATA_DIR']=str(out/'user-data')
 if trace:env['GLOB2_MOVEMENT_AGREEMENT_TRACE']=str(out/'agreement.csv')
 cmd=[str(binary),'game','run',*args,'--output-dir',str(out),'--compute-threads','4','--gradient-backend','scalar']
 commands.append({'name':name,'argv':cmd,'environment':{k:v for k,v in env.items() if k.startswith('GLOB2_')}})
 (root/'commands.json').write_text(json.dumps(commands,indent=2))
 start=time.monotonic()
 with open(out/'run.log','w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 print(name,round(time.monotonic()-start,2),flush=True)
for game in games:
 name=game['name']
 run(name+'/initial',['--generator',game['generator'],'--map-seed',str(game['map_seed']),'--game-seed',str(game['game_seed']),'--set','width=7','--set','height=7','--set','teams=2','--set','workers=8',*[v for p in game['players'] for v in ['--player',p]],'--ticks','1','--save','final'])
 initial=root/name/'initial/final.game.gz'
 args=['--load-game',str(initial),'--ticks','12000','--save','final','--write-replay','--telemetry','checksums','--telemetry','team-timeline']
 run(name+'/reference',args)
 for delay in range(9):run(name+f'/delay-{delay}',[*args,'--movement-agreement-delay',str(delay)],True)
