from pathlib import Path
p=Path('src/unit/planning/MovementShadow.h');s=p.read_text().replace('#include <string>','#include <string>\n#include <fstream>')
s=s.replace('Counters reference;', '''// Conditional steering agreement; unavailable/rejected suggestions are not matches.
        Uint64 agreementOpportunities=0, agreementDestinationRejected=0, agreementCancelled=0;
        Uint64 compared=0, directionAgree=0, moveStayAgree=0, bothMove=0, movingDirectionAgree=0, bothStay=0;
        Uint64 proposalMoveReferenceStay=0, proposalStayReferenceMove=0;
        Uint64 destinationCompared=0, destinationCoordinateAgree=0;
        Uint64 confusion[9][9]{}, traceSamples[2]{};
        Counters reference;''')
s=s.replace('struct Actor\n    {', '''struct Comparison
    {
        Request request;
        std::optional<Destination> destination;
        Uint8 proposedDirection=8;
    };
    struct Actor
    {''')
s=s.replace('std::optional<Suggestion> published;', 'std::optional<Suggestion> published;\n        std::optional<Comparison> comparison;')
s=s.replace('unsigned delay;', 'unsigned delay;\n    std::unique_ptr<std::ofstream> agreementTrace;')
s=s.replace('void completeAction(const Unit& unit);', '''void completeAction(const Unit& unit);
    // Pure aggregation helper, also exercises all nine move/stay outcomes in tests.
    static void recordAgreement(Metrics& metrics,unsigned proposed,unsigned reference);''')
p.write_text(s)
p=Path('src/unit/planning/MovementShadow.cpp');s=p.read_text().replace('#include <tuple>','#include <tuple>\n#include <cstdlib>')
s=s.replace('constexpr const char* Names[]', '''bool travelMovement(const Unit& unit)
{
    switch(unit.core.movement) {
    case UnitState::MOV_RANDOM_GROUND: case UnitState::MOV_RANDOM_FLY:
    case UnitState::MOV_GOING_TARGET: case UnitState::MOV_FLYING_TARGET:
    case UnitState::MOV_GOING_DX_DY: return true;
    default: return false;
    }
}
constexpr const char* Names[]''')
s=s.replace('if (!delay) return; // profiling-only reference control', '''if (!delay) return; // profiling-only reference control
    if(const char* path=std::getenv("GLOB2_MOVEMENT_AGREEMENT_TRACE");path && *path) {
        agreementTrace=std::make_unique<std::ofstream>(path);
        if(!*agreementTrace)throw std::runtime_error("Cannot open movement agreement trace");
        *agreementTrace<<"tick,team,mode,gid,incarnation,sequence,publication_tick,origin_x,origin_y,proposed_direction,reference_direction,disposition,destination_present,destination_x,destination_y,reference_target_valid,reference_target_x,reference_target_y\\n";
    }''')
a=s.index('void Shadow::completeAction');b=s.index('void Shadow::observe',a)
s=s[:a]+'''void Shadow::recordAgreement(Metrics& m,unsigned proposed,unsigned reference)
{
    if(proposed>8 || reference>8)throw std::invalid_argument("Invalid movement comparison direction");
    ++m.compared;++m.confusion[proposed][reference];
    m.directionAgree+=proposed==reference;
    m.moveStayAgree+=(proposed<8)==(reference<8);
    if(proposed<8 && reference<8){++m.bothMove;m.movingDirectionAgree+=proposed==reference;}
    else if(proposed==8 && reference==8)++m.bothStay;
    else if(proposed<8)++m.proposalMoveReferenceStay;
    else ++m.proposalStayReferenceMove;
}
void Shadow::completeAction(const Unit& unit)
{
    const auto found=actors.find(unit.core.gid);
    if(found==actors.end() || found->second.task.unit!=Game::refOf(&unit))return;
    auto& actor=found->second;
    if(actor.comparison) {
        auto comparison=std::move(*actor.comparison);actor.comparison.reset();
        const auto& r=comparison.request;
        auto& m=metrics[r.task.team][unsigned(r.mode)];
        // Compare the committed cell, including wrapped edges. Authoritative
        // non-travel transitions and unexpected displacement are exclusions.
        const auto& map=unit.owner->game->map;
        if(unit.core.isDead || !travelMovement(unit) ||
            unit.core.posX!=((r.task.x+unit.core.dx)&map.getMaskW()) ||
            unit.core.posY!=((r.task.y+unit.core.dy)&map.getMaskH()))++m.agreementCancelled;
        else {
            const unsigned actual=Unit::directionFromDxDy(unit.core.dx,unit.core.dy);
            recordAgreement(m,comparison.proposedDirection,actual);
            if(comparison.destination && unit.core.validTarget) {
                ++m.destinationCompared;
                m.destinationCoordinateAgree+=((comparison.destination->x&map.getMaskW())==unit.core.targetX
                    && (comparison.destination->y&map.getMaskH())==unit.core.targetY);
            }
            const unsigned equal=comparison.proposedDirection==actual;
            // Deterministic bounded examples, independently for each team/mode
            // and agreement outcome. Aggregate counters cover every comparison.
            if(agreementTrace && m.traceSamples[equal]<64) {
                ++m.traceSamples[equal];const auto d=comparison.destination;
                *agreementTrace<<unit.owner->game->stepCounter<<','<<r.task.team<<','<<Names[unsigned(r.mode)]<<','
                    <<r.task.unit.gid<<','<<r.task.unit.generation<<','<<r.sequence<<','<<r.publicationTick<<','
                    <<r.task.x<<','<<r.task.y<<','<<unsigned(comparison.proposedDirection)<<','<<actual<<','
                    <<unsigned(r.mode==Mode::Idle?Disposition::Travel:comparison.disposition)<<','<<bool(d)<<','
                    <<(d?d->x:0)<<','<<(d?d->y:0)<<','<<unit.core.validTarget<<','<<unit.core.targetX<<','<<unit.core.targetY<<'\\n';
                if(!*agreementTrace)throw std::runtime_error("Cannot write movement agreement trace");
            }
        }
    }
    ++actor.actionGeneration;
}
''' + s[b:]
# Preserve the original observer placement and its existing diagnostic counters.
s=s.replace('auto& m=metrics[unit.owner->teamNumber][unsigned(*mode)];++m.reference.opportunities;', '''auto& m=metrics[unit.owner->teamNumber][unsigned(*mode)];++m.reference.opportunities;
    const bool eligible=travelMovement(unit);
    if(delay && eligible)++m.agreementOpportunities;''')
s=s.replace('auto& actor=found->second;\n    const bool stable=', 'auto& actor=found->second;actor.comparison.reset();\n    const bool stable=')
s=s.replace('if(suggestion.destination) {', 'bool destinationValid=true;\n    if(suggestion.destination) {')
s=s.replace('if(!valid)++m.destinationRejected;', 'if(!valid) { ++m.destinationRejected;destinationValid=false; }')
s=s.replace('if(rank==8)++m.blocked;else if(rank<suggestion.preferred)++m.preferredSuccess;', '''if(rank==8)++m.blocked;else if(rank<suggestion.preferred)++m.preferredSuccess;
    if(eligible) {
        if(!destinationValid)++m.agreementDestinationRejected;
        else {
            // This models only the specified suggestion's first legal step.
            // Missing/rejected fallback policies and serial service decisions
            // are deliberately not invented by this observer.
            const Uint8 direction=suggestion.disposition==Disposition::Travel && rank<8?suggestion.directions[rank]:8;
            auto comparisonRequest=r;comparisonRequest.task.x=task.x;comparisonRequest.task.y=task.y;
            actor.comparison=Comparison{comparisonRequest,suggestion.destination,direction,suggestion.disposition};
        }
    }''')
s=s.replace('add("preferred_success",m.preferredSuccess);', '''add("agreement_opportunities",m.agreementOpportunities);add("agreement_destination_rejected",m.agreementDestinationRejected);add("agreement_cancelled",m.agreementCancelled);
        add("agreement_compared",m.compared);add("agreement_direction_equal",m.directionAgree);add("agreement_move_stay_equal",m.moveStayAgree);
        add("agreement_both_move",m.bothMove);add("agreement_moving_direction_equal",m.movingDirectionAgree);add("agreement_both_stay",m.bothStay);
        add("agreement_proposal_move_reference_stay",m.proposalMoveReferenceStay);add("agreement_proposal_stay_reference_move",m.proposalStayReferenceMove);
        add("agreement_destination_compared",m.destinationCompared);add("agreement_destination_coordinate_equal",m.destinationCoordinateAgree);
        for(unsigned proposed=0;proposed<9;++proposed)for(unsigned actual=0;actual<9;++actual)
            if(m.confusion[proposed][actual])add(("agreement_proposed_"+std::to_string(proposed)+"_reference_"+std::to_string(actual)).c_str(),m.confusion[proposed][actual]);
        add("preferred_success",m.preferredSuccess);''')
p.write_text(s)
p=Path('src/unit/planning/MovementShadow.h');s=p.read_text().replace('Uint8 proposedDirection=8;', 'Uint8 proposedDirection=8;\n        Disposition disposition=Disposition::NoRoute;');p.write_text(s)
p=Path('src/unit/planning/MovementShadow.cpp');s=p.read_text().replace('unsigned(r.mode==Mode::Idle?Disposition::Travel:comparison.disposition)','unsigned(comparison.disposition)');p.write_text(s)
p=Path('src/unit/planning/MovementPlanningTest.cpp');s=p.read_text();start=s.index('    TEST_CASE("completion prediction')
s=s[:start]+'''    TEST_CASE("agreement classifies all directions and stays without hiding exclusions")
    {
        Shadow::Metrics m;
        for(unsigned proposed=0;proposed<9;++proposed)for(unsigned actual=0;actual<9;++actual)
            Shadow::recordAgreement(m,proposed,actual);
        CHECK(m.compared==81);CHECK(m.directionAgree==9);CHECK(m.moveStayAgree==65);
        CHECK(m.bothMove==64);CHECK(m.movingDirectionAgree==8);CHECK(m.bothStay==1);
        CHECK(m.proposalMoveReferenceStay==8);CHECK(m.proposalStayReferenceMove==8);
        for(const auto& row:m.confusion)for(auto count:row)CHECK(count==1);
        CHECK_THROWS(Shadow::recordAgreement(m,9,0));CHECK(m.compared==81);
    }
''' + s[start:];p.write_text(s)
