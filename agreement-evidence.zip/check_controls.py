import pathlib,os,subprocess,json,gzip
root=pathlib.Path(__file__).resolve().parent
current=root.parent.parent/'build/movement-release/src/glob2';old=root/'glob2-pre-sweep'
initial=root/'symmetric-arena-1/initial/final.game.gz';ref=root/'symmetric-arena-1/reference'
controls=[]
for name,binary,delay,threads in [('old-reference',old,None,4),('serial-zero',current,0,1),('serial-three',current,3,1),('serial-eight',current,8,1),('no-trace-three',current,3,4)]:
 out=root/'controls-matched'/name;out.mkdir(parents=True,exist_ok=True)
 env=os.environ.copy();env['GLOB2_USER_DATA_DIR']=str(out/'user-data');env.pop('GLOB2_MOVEMENT_AGREEMENT_TRACE',None)
 cmd=[str(binary),'game','run','--load-game',str(initial),'--ticks','12000','--save','final','--write-replay','--telemetry','checksums','--telemetry','team-timeline','--output-dir',str(out),'--compute-threads',str(threads),'--gradient-backend','scalar']
 if delay is not None:cmd+=['--movement-agreement-delay',str(delay)]
 with open(out/'run.log','w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 r=json.loads((out/'result.json').read_text());row={'name':name,'argv':cmd,'ticks':r['ticks'],'files':{}}
 for f in ['world.checksums','game.replay','game.replay.checksums','final.game.gz']:
  a=(ref/f).read_bytes();b=(out/f).read_bytes();row['files'][f]=a==b if not f.endswith('.gz') else gzip.decompress(a)==gzip.decompress(b)
 if delay is not None:
  c=json.loads((root/'symmetric-arena-1'/f'delay-{delay}'/'result.json').read_text())['movement_shadow'];s=r['movement_shadow']
  keys=[k for k in c if '_agreement_' in k and k.startswith('team_')]
  row['agreement_counters_equal']=all(c[k]==s.get(k,0) for k in keys)
 controls.append(row);(root/'control-comparisons.json').write_text(json.dumps(controls,indent=2));print(name,row['files'],row.get('agreement_counters_equal'),flush=True)
