import pathlib,json,hashlib,gzip,zipfile,shutil,subprocess
root=pathlib.Path(__file__).resolve().parent
publish=root.parent.parent/'docs/.work/compact-core-evidence-publish'
protocol=json.loads((root/'protocol.json').read_text());manifest=[]
canonical=['world.checksums','game.replay','game.replay.checksums','final.game.gz']
def digest(path,unzip=False):
 with (gzip.open(path,'rb') if unzip else path.open('rb')) as f:return hashlib.file_digest(f,'sha256').hexdigest()
for game in protocol['games']:
 base=root/game['name'];reference=base/'reference'
 for mode in ['reference',*[f'delay-{d}' for d in range(9)]]:
  for name in canonical:
   file=base/mode/name
   manifest.append({'path':str(file.relative_to(root)),'bytes':file.stat().st_size,'sha256':digest(file),'canonical_sha256':digest(file,True) if name.endswith('.gz') else digest(file),'reviewer_payload':f"agreement-{game['name']}.zip:{game['name']}/reference/{name}"})
 archive=publish/f"agreement-{game['name']}.zip"
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for mode in ['initial','reference']:
   for f in (base/mode).rglob('*'):
    if f.is_file() and 'profile' not in f.parts and 'user-data' not in f.parts:z.write(f,str(f.relative_to(root)))
 print(archive.name,archive.stat().st_size,flush=True)
 if archive.stat().st_size>=99_000_000:raise RuntimeError('Evidence archive exceeds GitHub file limit')
(root/'canonical-payload-manifest.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(publish/'agreement-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in root.rglob('*'):
  if not f.is_file() or 'profile' in f.parts or 'user-data' in f.parts or f.name in canonical or f.name.startswith('glob2') or f.suffix=='.zip' or '/generated/' in str(f):continue
  z.write(f,str(f.relative_to(root)))
for name in ['agreement-delay.png','agreement-modes.png','agreement-age.png','summary.json','observations.csv','comparisons.json','control-comparisons.json','protocol.json','provenance.json','canonical-payload-manifest.json']:
 shutil.copy2(root/name,publish/(name if name.startswith('agreement-') else 'agreement-'+name))
print('metadata archive', (publish/'agreement-evidence.zip').stat().st_size,flush=True)
