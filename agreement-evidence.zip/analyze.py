import json,pathlib,collections,csv,gzip,hashlib
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=pathlib.Path(__file__).resolve().parent
protocol=json.loads((root/'protocol.json').read_text());rows=[];checks=[]
for game in protocol['games']:
 path=root/game['name'];ref=path/'reference'
 if not (ref/'result.json').exists():continue
 for delay in range(9):
  out=path/f'delay-{delay}'
  if not (out/'result.json').exists():continue
  result=json.loads((out/'result.json').read_text());m=result['movement_shadow']
  for team in range(2):
   for mode in ['idle','explore','resource','building','clearing','pursuit']:
    prefix=f'team_{team}_{mode}_';counts={k[len(prefix):]:v for k,v in m.items() if k.startswith(prefix)}
    row={'game':game['name'],'team':team,'ai':game['players'][team],'delay':delay,'mode':mode,**counts};rows.append(row)
  files={}
  for f in ['world.checksums','game.replay','game.replay.checksums','final.game.gz']:
   a=(ref/f).read_bytes();b=(out/f).read_bytes()
   files[f]=a==b if not f.endswith('.gz') else gzip.decompress(a)==gzip.decompress(b)
  checks.append({'game':game['name'],'delay':delay,'ticks':result['ticks'],'files':files,'trace_errors':m['agreement_trace_errors']})
(root/'comparisons.json').write_text(json.dumps(checks,indent=2));(root/'observations.json').write_text(json.dumps(rows,indent=2))
keys=sorted(set().union(*(r.keys() for r in rows)))
with open(root/'observations.csv','w') as f:
 w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def agg(delay,mode=None,game=None):
 c=collections.Counter()
 for r in rows:
  if r['delay']==delay and (mode is None or r['mode']==mode) and (game is None or r['game']==game):
   c.update({k:v for k,v in r.items() if isinstance(v,int) and k not in ['team','delay']})
 return c
def ratio(c,a,b):return 100*c[a]/c[b] if c[b] else np.nan
metrics=[('agreement_direction_equal','agreement_compared','Exact direction, including stay'),('agreement_moving_direction_equal','agreement_both_move','Direction when both move'),('agreement_compared','agreement_opportunities','Usable comparison coverage')]
fig,axes=plt.subplots(1,3,figsize=(14,4.5),sharex=True)
for ax,(a,b,title) in zip(axes,metrics):
 for g in protocol['games']:
  ax.plot(range(9),[ratio(agg(d,game=g['name']),a,b) for d in range(9)],alpha=.3,lw=1)
 ax.plot(range(9),[ratio(agg(d),a,b) for d in range(9)],'o-',color='#1565c0',lw=2.5,label='Pooled action counts')
 ax.set(title=title,xlabel='Configured delay (ticks)',ylabel='Percent',xticks=range(9),ylim=(0,100));ax.grid(alpha=.2)
axes[0].legend();fig.suptitle('Movement policy agreement along unchanged reference games\nThin lines: individual games. Coverage exclusions are not matches.',fontsize=12);fig.tight_layout();fig.savefig(root/'agreement-delay.png',dpi=170);plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(12,5),sharex=True)
for mode in ['resource','building','explore','idle','clearing','pursuit']:
 if not sum(agg(d,mode)['agreement_opportunities'] for d in range(9)):continue
 for ax,(a,b) in zip(axes,[('agreement_direction_equal','agreement_compared'),('agreement_compared','agreement_opportunities')]):ax.plot(range(9),[ratio(agg(d,mode),a,b) for d in range(9)],'o-',label=mode)
for ax,t in zip(axes,['Conditional exact direction agreement','Usable comparison coverage']):ax.set(title=t,xlabel='Configured delay (ticks)',ylabel='Percent',xticks=range(9),ylim=(0,100));ax.grid(alpha=.2);ax.legend()
fig.suptitle('Breakdown by travel mode; no independent-action confidence interval');fig.tight_layout();fig.savefig(root/'agreement-modes.png',dpi=170);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4.5))
for mode in ['resource','building','explore','idle','pursuit']:
 ax.plot(range(9),[agg(d,mode)['agreement_observation_age_ticks']/agg(d,mode)['agreement_compared'] if agg(d,mode)['agreement_compared'] else np.nan for d in range(9)],'o-',label=mode)
ax.set(xlabel='Configured delay (ticks)',ylabel='Mean snapshot age at comparison (ticks)',xticks=range(9),title='Configured delay is not the age of a retained suggestion');ax.grid(alpha=.2);ax.legend();fig.tight_layout();fig.savefig(root/'agreement-age.png',dpi=170);plt.close(fig)
summary=[{'delay':d,**dict(agg(d))} for d in range(9)];(root/'summary.json').write_text(json.dumps(summary,indent=2))
print('Completed paired runs:',len(checks),'canonical matches:',sum(all(c['files'].values()) for c in checks))
for c in summary:print(c['delay'],c.get('agreement_compared'),*[round(ratio(c,a,b),2) for a,b,_ in metrics])
