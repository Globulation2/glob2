from pathlib import Path
import subprocess,json,time,hashlib,shlex,sys
root=Path.cwd();out=root/'artifacts/resource-refactor';source=out/'android-source';sdk=Path('/home/bradley/.local/share/glob2/development/toolchains/mobile/Linux-x86_64-8dbf18a4a97410f6b6a92b4a/android-sdk');adb=[str(sdk/'platform-tools/adb'),'-P','15037','-s','emulator-5580'];stage=out/'android-final-de4-stage';audit=out/'android-final-de4-payload-audit';audit.mkdir(exist_ok=True)
while True:
 p=out/'android-final-de4-source-provenance.json'
 if p.exists():
  d=json.loads(p.read_text())
  if 'build_returncode' in d:assert d['build_returncode']==0;break
 time.sleep(2)
subprocess.run(adb+['wait-for-device'],check=True,timeout=180)
for _ in range(90):
 if subprocess.check_output(adb+['shell','getprop','sys.boot_completed'],text=True).strip()=='1':break
 time.sleep(2)
else:raise RuntimeError('emulator did not boot')
command=['python3','mobile/android_device_tests.py','--android-sdk',str(sdk),'--serial','emulator-5580','--adb-port','15037','--arch','x86_64','--suite','__staging_only_no_matching_cases__','--keep-remote','--mobile-deps','/home/bradley/.local/share/glob2/development/dependencies/Linux-x86_64-0db2318ca135e0c408e4c9d3','--output',str(stage)]
(audit/'stage-command.json').write_text(json.dumps({'command':command,'cwd':str(source),'counted_tests':0},indent=2))
with (out/'android-final-de4-stage.log').open('w') as log:subprocess.run(command,cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
summary=json.loads((stage/'result.json').read_text());remote=summary['remoteDirectory'];assert remote.startswith('/data/local/tmp/glob2-tests-')
dirs=['data','maps','games','test/fixtures','test/maxima/fixtures','examples/javascript','campaigns','scripts'];expected={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for name in dirs for p in (source/name).rglob('*') if p.is_file()}
def verify(label):
 command=adb+['shell','cd '+shlex.quote(remote)+' && find '+shlex.join(dirs)+' -type f -exec sha256sum {} +'];r=subprocess.run(command,check=True,capture_output=True,text=True);(audit/(label+'.sha256')).write_text(r.stdout)
 actual={name.removeprefix('./'):digest for line in r.stdout.splitlines() for digest,name in [line.split('  ',1)]};mismatches={p:{'expected':h,'actual':actual.get(p)} for p,h in expected.items() if actual.get(p)!=h};extras=sorted(set(actual)-set(expected));(audit/(label+'.json')).write_text(json.dumps({'command':command,'checked':len(expected),'mismatches':mismatches,'extras':extras},indent=2));assert not mismatches and not extras,(label,len(mismatches),len(extras))
verify('before-tests')
registry=out/'android-final-de4-registry';registry.mkdir();profile=remote+'/profiles/verified-registry';cmd=adb+['shell','cd '+shlex.quote(remote)+' && mkdir -p '+shlex.quote(profile)+' && '+shlex.join(['env','LD_LIBRARY_PATH='+remote,'SDL_VIDEODRIVER=dummy','SDL_RENDER_DRIVER=software','SDL_AUDIODRIVER=dummy','GLOB2_ASSET_DIR='+remote,'GLOB2_TEST_SOURCE_ROOT='+remote,'GLOB2_USER_DATA_DIR='+profile,'timeout','-k','5','180','./glob2-unit-tests','--test-suite=ResourceRegistry','-r=junit','-o='+remote+'/verified-registry.xml'])]
(registry/'command.json').write_text(json.dumps(cmd,indent=2))
with (registry/'engine.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(adb+['pull',remote+'/verified-registry.xml',str(registry/'result.xml')],check=True,stdout=subprocess.DEVNULL)
verify('after-registry')
for script,log in [('run_android_final_de4_cases.py','android-final-de4-cases.log'),('build_android_final_de4_cli.py','android-final-de4-cli-build.log'),('run_android_final_de4_trace.py','android-final-de4-cross-trace.log')]:
 with (out/log).open('w') as f:subprocess.run(['python3',str(out/script)],cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
verify('after-cases-and-traces')
print('Android de4 registry, engine cases and cross-platform traces passed; complete payload verified before and after.')
