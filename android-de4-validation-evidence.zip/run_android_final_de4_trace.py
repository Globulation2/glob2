"""Run the unchanged engine's portable CLI traces in the task-local Android shell."""
import pathlib,json,subprocess,shlex,hashlib
root=pathlib.Path(__file__).resolve().parent;checkout=root/'android-source';out=root/'android-final-de4-cross-trace';out.mkdir(exist_ok=True)
remote=json.loads((root/'android-final-de4-stage/result.json').read_text())['remoteDirectory'];assert remote.startswith('/data/local/tmp/glob2-tests-')
sdk=pathlib.Path('/home/bradley/.local/share/glob2/development/toolchains/mobile/Linux-x86_64-8dbf18a4a97410f6b6a92b4a/android-sdk');adb=[str(sdk/'platform-tools/adb'),'-P','15037','-s','emulator-5580'];binary=checkout/'artifacts/android-shell-cli-de4/glob2-android-shell';stripped=out/'glob2-android-shell'
strip=sdk/'ndk/28.2.13676358/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip'
subprocess.run([str(strip),'--strip-debug','-o',str(stripped),str(binary)],check=True);stripped.chmod(0o755)
subprocess.run(adb+['push',str(stripped),remote+'/glob2-android-shell'],check=True,stdout=subprocess.DEVNULL)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
meta={'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip(),'binary_sha256':sha(binary),'executed_binary_sha256':sha(stripped),'fixture_sha256':sha(checkout/'games/cross-replay.game.gz'),'bridge_provenance':str(checkout/'artifacts/android-shell-cli-de4/provenance.json'),'commands':[],'timing_valid':False}
base=['env','LD_LIBRARY_PATH='+remote,'SDL_VIDEODRIVER=dummy','SDL_RENDER_DRIVER=software','SDL_AUDIODRIVER=dummy','SDL_PREFERRED_LOCALES=en_US','GLOB2_ASSET_DIR='+remote,'GLOB2_USER_DATA_DIR='+remote+'/profiles/trace-cli']
def run(args,name,extra=[]):
 invocation=base+extra+['timeout','-k','5','300','./glob2-android-shell']+args
 cmd=adb+['shell','cd '+shlex.quote(remote)+' && mkdir -p '+shlex.quote(remote+'/profiles/trace-cli')+' && '+shlex.join(invocation)]
 meta['commands'].append(cmd);(out/'manifest.json').write_text(json.dumps(meta,indent=2))
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=315)
 assert r.returncode==0,(name,r.returncode)
run(['--nox',remote+'/games/cross-replay.game.gz','1500','1'],'replay',['GLOB2_REPLAY_PATH='+remote+'/android-trace.replay','GLOB2_CHECKSUM_SIDECAR=1'])
trace=out/'native.replay.checksums';subprocess.run(adb+['pull',remote+'/android-trace.replay.checksums',str(trace)],check=True,stdout=subprocess.DEVNULL)
reference=root/'native-9a54-determinism/native.replay.checksums';assert trace.read_bytes()==reference.read_bytes()
meta['replay']={'ticks':1500,'matches_native':True,'sha256':sha(trace),'reference':str(reference)}
run(['--verify-match',remote+'/test/fixtures/multiplayer/FourSquares1.g2mr','--map',remote+'/maps/FourSquares1.map.gz','--out',remote+'/android-verify-match'],'verify-match')
subprocess.run(adb+['pull',remote+'/android-verify-match',str(out/'verify-match')],check=True,stdout=subprocess.DEVNULL)
verified=out/'verify-match/checksums.txt';ref=root/'native-9a54-determinism/verify-match.checksums.txt';assert verified.read_bytes()==ref.read_bytes()
meta['verify_match']={'matches_native':True,'sha256':sha(verified),'reference':str(ref),'verdict':json.loads((out/'verify-match/verdict.json').read_text())['verdict']}
(out/'manifest.json').write_text(json.dumps(meta,indent=2));print(json.dumps({'status':'pass','replay':meta['replay'],'verify_match':meta['verify_match']}))
