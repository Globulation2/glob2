from pathlib import Path
import json,subprocess,time
root=Path.cwd();out=root/'artifacts/resource-refactor';source=out/'android-source';prior=out/'android-final-9a-source-provenance.json'
while True:
 d=json.loads(prior.read_text())
 if 'build_returncode' in d:
  assert d['build_returncode']==0,d
  break
 time.sleep(2)
revision=subprocess.check_output(['git','rev-parse','de4a315d8'],text=True).strip()
subprocess.run(['git','fetch','--quiet',str(root),revision],cwd=source,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
subprocess.run(['git','reset','--hard',revision],cwd=source,check=True)
manifest={'revision':revision,'source_status':subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True),'production_revision':d['revision'],'source':str(source),'delta':subprocess.check_output(['git','diff','--stat',d['revision'],revision],text=True),'build_command':d['build_command'],'timing_valid':False,'method':'Batch final golden and test-only fixes after9a production build completed'}
p=out/'android-final-de4-source-provenance.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
with (out/'android-final-de4-build.log').open('w') as log:r=subprocess.run(manifest['build_command'],cwd=source,stdout=log,stderr=subprocess.STDOUT)
manifest['build_returncode']=r.returncode;p.write_text(json.dumps(manifest,indent=2)+'\n');print('Android de4 build',r.returncode)
