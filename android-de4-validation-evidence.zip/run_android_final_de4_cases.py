"""Fresh-process Android resource fixtures on the existing task-owned adb payload."""
import json,pathlib,subprocess,shlex,xml.etree.ElementTree as ET,hashlib,sys
root=pathlib.Path(__file__).resolve().parent;checkout=root/'android-source';stage=root/'android-final-de4-stage'
sys.path.insert(0,str(checkout/'test'));from build_provenance import build_issues
summary=json.loads((stage/'result.json').read_text());remote=summary['remoteDirectory'];assert remote.startswith('/data/local/tmp/glob2-tests-')
sdk=pathlib.Path('/home/bradley/.local/share/glob2/development/toolchains/mobile/Linux-x86_64-8dbf18a4a97410f6b6a92b4a/android-sdk')
adb=[str(sdk/'platform-tools/adb'),'-P','15037','-s','emulator-5580']
out=root/'android-final-de4-cases';out.mkdir(exist_ok=True)
base=['env','LD_LIBRARY_PATH='+remote,'SDL_VIDEODRIVER=dummy','SDL_RENDER_DRIVER=software','SDL_AUDIODRIVER=dummy','GLOB2_ASSET_DIR='+remote,'GLOB2_TEST_SOURCE_ROOT='+remote]
listcmd=base+['GLOB2_USER_DATA_DIR='+remote+'/profiles/discovery','./glob2-engine-tests','-r=xml','-ltc','--test-suite=RuntimeResources,TerrainResources,FarmAreas,AIRules,TeamStatsSave,ClearingFlagGradient,RuntimeContinuation,SharedWorkerLifecycle,SimulationReadPhase,JavaScriptCompatibility','-tce=*[display*']
shell='cd '+shlex.quote(remote)+' && '+shlex.join(listcmd)
r=subprocess.run(adb+['shell',shell],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
(out/'inventory.xml').write_text(r.stdout);(out/'inventory.stderr').write_text(r.stderr)
cases=[c for c in ET.fromstring(r.stdout).iter('TestCase') if c.attrib.get('testsuite') not in ('AIRules','TeamStatsSave','RuntimeContinuation','JavaScriptCompatibility') or c.attrib['name'] in (
    'clearing telemetry counts operations once by configured primary material',
    'renewable material potential survives saturation and honors yield policies',
    'prospective material supply combines mixed branch numerators without overflow',
    'Maxima removes disabled reserves while retaining finite production supply',
    'static material fields invalidate on source edits and preserve continuation',
    'Resource catalog simulation change rejects released replays and enforces acceptance boundaries')];assert cases
selected_names={case.attrib['name'] for case in cases}
assert {'static material fields invalidate on source edits and preserve continuation',
        'Resource catalog simulation change rejects released replays and enforces acceptance boundaries'} <= selected_names
assert {'RuntimeResources','SharedWorkerLifecycle','SimulationReadPhase'} <= {case.attrib.get('testsuite') for case in cases}
rows=[]
for i,case in enumerate(cases):
 name=case.attrib['name'];suite=case.attrib.get('testsuite','');key=f'{i:03d}';profile=remote+'/profiles/resource-case-'+key;artifacts=remote+'/artifacts/resource-case-'+key
 pattern=name.replace('\\','\\\\').replace(',','\\,')
 command=base+['GLOB2_USER_DATA_DIR='+profile,'GLOB2_TEST_ARTIFACTS_ROOT='+artifacts,'timeout','-k','5','180','./glob2-engine-tests','-r=junit','-o='+remote+'/case-'+key+'.xml','-tc='+pattern,'-ts='+suite]
 shell='cd '+shlex.quote(remote)+' && mkdir -p '+shlex.quote(profile)+' && '+shlex.join(command)
 with (out/(key+'.log')).open('w') as log:r=subprocess.run(adb+['shell',shell],stdout=log,stderr=subprocess.STDOUT,timeout=195)
 subprocess.run(adb+['pull',remote+'/case-'+key+'.xml',str(out/(key+'.xml'))],stdout=subprocess.DEVNULL,check=True)
 xml=ET.parse(out/(key+'.xml'));executed=len(list(xml.iter('testcase')));assert executed==1,(name,executed)
 proofs=[json.loads(l.partition('GLOB2_TEST_PROVENANCE ')[2]) for l in (out/(key+'.log')).read_text().splitlines() if l.startswith('GLOB2_TEST_PROVENANCE ')]
 issues=build_issues(proofs[0] if len(proofs)==1 else {},summary)
 rows.append({'suite':suite,'name':name,'returncode':r.returncode,'provenanceIssues':issues,'command':adb+['shell',shell],'log':key+'.log','junit':key+'.xml'})
 (out/'results.json').write_text(json.dumps({'sourceRevision':summary.get('revision'), 'stagedRunnerManifest':str(stage/'result.json'),'cases':rows},indent=2));print(('PASS' if not r.returncode and not issues else 'FAIL')+' '+suite+'/'+name,flush=True)
subprocess.run(adb+['pull',remote+'/artifacts',str(out/'artifacts')],stdout=subprocess.DEVNULL,check=True)
traces=list((out/'artifacts').rglob('seeded-compositions.trace'));assert len(traces)==1,traces
reference=checkout/'test/fixtures/resources/seeded-compositions.trace';assert traces[0].read_bytes()==reference.read_bytes()
(out/'composition-comparison.json').write_text(json.dumps({'equal':True,'trace':str(traces[0]),'reference':str(reference),'sha256':hashlib.sha256(reference.read_bytes()).hexdigest(),'rows':len(reference.read_text().splitlines())},indent=2))
if any(r['returncode'] or r['provenanceIssues'] for r in rows):raise SystemExit(1)
