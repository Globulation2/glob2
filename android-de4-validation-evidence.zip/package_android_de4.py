from pathlib import Path
import json,hashlib,zipfile,collections,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cases=json.loads((root/'android-final-de4-cases/results.json').read_text());assert len(cases['cases'])==56 and all(not r['returncode'] and not r['provenanceIssues'] for r in cases['cases'])
unit=ET.parse(root/'android-final-de4-registry/result.xml');assert len(list(unit.iter('testcase')))==9 and not list(unit.iter('failure')) and not list(unit.iter('error'))
proof=json.loads((root/'android-final-de4-registry/provenance-verification.json').read_text());assert not proof['issues']
audits={name:json.loads((root/f'android-final-de4-payload-audit/{name}.json').read_text()) for name in ['before-tests','after-registry','after-cases-and-traces']};assert all(v['checked']==8137 and not v['mismatches'] and not v['extras'] for v in audits.values())
cleanup=json.loads((root/'android-final-de4-cleanup.json').read_text());assert all(cleanup['ports_closed'].values())
source=json.loads((root/'android-final-de4-source-provenance.json').read_text())
summary={'tested_source':source['revision'],'production_source':source['production_revision'],'source_delta':source['delta'],'source_clean':source['source_status']=='','results':{'registry_unit_cases':9,'fresh_engine_cases':56,'all_passed':True,'suite_counts':dict(collections.Counter(r['suite'] for r in cases['cases'])),'staging_zero_case_runs_counted':False},'composition':json.loads((root/'android-final-de4-cases/composition-comparison.json').read_text()),'cross_platform':json.loads((root/'android-final-de4-cross-trace/manifest.json').read_text()),'payload_integrity':{'inputs_verified':8137,'stages':list(audits),'all_match':True,'corruption_observed':False},'cleanup':cleanup,'limitations':['Android x86_64 API35 emulator with NDK28.2.13676358/API24 native target; native shell and dummy SDL, not APK/JVM/touch/UI/ARM validation.','CLI uses unmodified production objects with retained shell entry and existing test platform bridges; staged assets replace APK installation. SDL_PREFERRED_LOCALES=en_US avoids no-JVM locale probing.','No performance claims; build, emulator, and tournament overlapped.','Historical d556 staging corruption remains unexplained and retained in previous evidence. This fresh payload was completely verified before counted tests and afterward.'],'previous_evidence':'android-final-validation-evidence.zip preserves superseded source results and staging incident; not used as evidence for current source.'}
(root/'android-de4-validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=set()
for directory in ['android-final-de4-stage','android-final-de4-registry','android-final-de4-cases','android-final-de4-payload-audit']:
 files.update(p for p in (root/directory).rglob('*') if p.is_file())
for p in root.glob('android-final-de4-*'):
 if p.is_file() and p.suffix in ['.json','.log']:files.add(p)
for name in ['android-final-9a-build.log','android-final-9a-source-provenance.json','android-de4-validation-summary.json','refresh_android_de4.py','run_android_de4_validation.py','run_android_final_de4_cases.py','build_android_final_de4_cli.py','run_android_final_de4_trace.py','package_android_de4.py']:files.add(root/name)
for p in (root/'android-final-de4-cross-trace').rglob('*'):
 if p.is_file() and p.suffix in ['.json','.txt','.checksums','.log'] and 'profile' not in p.parts:files.add(p)
for name in ['ShellMain.cpp','provenance.json','Glob2.build.log','ShellMain.build.log','link.log']:files.add(root/'android-source/artifacts/android-shell-cli-de4'/name)
for name in ['manifest.json','native.replay.checksums','verify-match.checksums.txt']:files.add(root/'native-9a54-determinism'/name)
contents={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)}
path=root/'android-de4-validation-evidence.zip'
with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,str(p.relative_to(root)))
 z.writestr('CONTENTS.sha256.json',json.dumps(contents,indent=2)+'\n')
print(json.dumps({'path':str(path),'files':len(files),'bytes':path.stat().st_size,'sha256':sha(path)},indent=2))
