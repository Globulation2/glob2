"""Link an Android shell CLI using unmodified production objects and test platform bridges.
Only APK asset installation is replaced: the adb payload already supplies assets/profile.
No simulation, scheduling, resource, AI, or random-number implementation is replaced.
"""
import pathlib,subprocess,shlex,json,hashlib
root=pathlib.Path(__file__).resolve().parent/'android-source'
out=root/'artifacts/android-shell-cli-de4';out.mkdir(parents=True,exist_ok=True)
log=(root.parent/'android-final-de4-build.log').read_text().splitlines()
compilation_log=(root.parent/'android-final-9a-build.log').read_text().splitlines()
compiles=[shlex.split(line) for line in compilation_log if ' -c ' in line and ' -o ' in line and '-clang++' in line]
assert compiles
base=next(a for a in compiles if any('src/app/' in x for x in a))
wrapper=out/'ShellMain.cpp';wrapper.write_text('''// Task-local shell entry point. NativeTestMain supplies the existing SDL shell bridges.
extern "C" int SDL_main(int argc, char** argv);
// Assets are already staged by adb; shell execution has no APK AssetManager.
void initializeMobilePaths() {}
int main(int argc, char** argv) { return SDL_main(argc, argv); }
''')
def compile(source,obj):
 a=list(base);a[a.index('-o')+1]=str(obj)
 # SCons puts the C++ source last; assert rather than accidentally replace a flag.
 assert a[-1].endswith('.cpp'),a[-1]
 a[-1]=str(source)
 with (out/(obj.stem+'.build.log')).open('w') as logfile:
  subprocess.run(a,cwd=root,check=True,stdout=logfile,stderr=subprocess.STDOUT)
 return a
appobj=out/'Glob2.o';wrapperobj=out/'ShellMain.o'
commands=[compile(root/'src/app/Glob2.cpp',appobj),compile(wrapper,wrapperobj)]
links=[shlex.split(line) for line in log if ' -o ' in line and '/tests/glob2-engine-tests' in line and ' -c ' not in line and '-clang++' in line]
assert len(links)==1,len(links)
a=links[0];a[a.index('-o')+1]=str(out/'glob2-android-shell')
a=[arg for arg in a if not (arg.endswith('.o') and (('/tests/' in arg and not arg.endswith('/NativeTestMain.o')) or arg.endswith('/mobile/MobilePaths.cpp.o')))]
a += [str(appobj),str(wrapperobj)]
# Keep object inputs before archives to work with both linker's group modes.
objects=[arg for arg in a if arg.endswith('.o')];a=[arg for arg in a if not arg.endswith('.o')];a[1:1]=objects
with (out/'link.log').open('w') as logfile:
 subprocess.run(a,cwd=root,check=True,stdout=logfile,stderr=subprocess.STDOUT)
commands.append(a)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
(out/'provenance.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_status':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'wrapper_sha256':sha(wrapper),'binary_sha256':sha(out/'glob2-android-shell'),'commands':commands,'limitations':'Android shell dummy drivers with existing NativeTestMain platform bridges and direct staged assets; not installed APK/JVM/UI validation.'},indent=2))
print(out/'glob2-android-shell')
