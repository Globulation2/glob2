"""Strict Linux tournament provenance and content-verified reuse; never caches failures."""
import hashlib,json,os,pathlib,re,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
SETTINGS=['--compute-threads','4','--compute-experiments','ai','--gradient-workers','2','--gradient-delay','8','--telemetry','team-timeline']
def sha(path):
    digest=hashlib.sha256()
    with pathlib.Path(path).open('rb') as source:
        for block in iter(lambda:source.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()
def canonical_sha(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def tools_snapshot():
    paths=[pathlib.Path(__file__).with_name(name) for name in ['paired_behavior.py','paired_telemetry.py','paired_provenance.py']]
    paths.append(ROOT/'tools/tournaments/game_telemetry.py')
    return {str(p.relative_to(ROOT)):sha(p) for p in paths}
def environment_snapshot():
    # A digest avoids publishing credentials while rejecting changed inherited
    # engine/loader settings. Shell bookkeeping is not passed as a game setting.
    values={k:v for k,v in os.environ.items() if k not in {'_','SHLVL','PWD','OLDPWD'}}
    return canonical_sha(values)
def runtime_snapshot(binary,cwd):
    binary=pathlib.Path(binary).resolve();cwd=pathlib.Path(cwd).resolve()
    data={str(p.relative_to(cwd)):sha(p) for p in sorted((cwd/'data').rglob('*'))
          if p.is_file() and p.suffix.lower() in {'.json','.txt','.js'}}
    if not data:raise ValueError('No runtime data inventory in '+str(cwd))
    loaded=subprocess.run(['ldd',str(binary)],cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    libraries={}
    if 'not found' in loaded.stdout:raise ValueError('Unresolved shared library: '+loaded.stdout)
    for line in loaded.stdout.splitlines():
        match=re.search(r'(?:=>\s*)?(/\S+)\s+\(0x',line)
        if match:
            path=pathlib.Path(match[1]);libraries[str(path)]={'resolved':str(path.resolve()),'sha256':sha(path)}
    if not libraries and not any(s in loaded.stdout for s in ('not a dynamic executable','statically linked')):
        raise ValueError('Cannot establish resolved shared libraries: '+loaded.stdout)
    return {'binary':str(binary),'binary_sha256':sha(binary),'cwd':str(cwd),
            'data_inputs':data,'shared_libraries':libraries,'ldd_stdout':loaded.stdout}
def stable_runtime(value):
    # Loader addresses vary due to ASLR; resolved filenames/content must match.
    return {k:v for k,v in value.items() if k!='ldd_stdout'}
def normalized_command(command):
    value=list(command);index=value.index('--output-dir');del value[index:index+2];return value

def run_observed(command,cwd,log,timeout=3600):
    """Capture executable mappings, including libraries loaded after startup."""
    libraries={};errors=[];started=time.monotonic()
    process=subprocess.Popen(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
    def capture():
        try:lines=pathlib.Path(f'/proc/{process.pid}/maps').read_text().splitlines()
        except FileNotFoundError:return
        for line in lines:
            fields=line.split(maxsplit=5)
            if len(fields)<6 or 'x' not in fields[1] or not fields[5].startswith('/'):continue
            name=fields[5]
            if name.endswith(' (deleted)'):
                errors.append('deleted executable mapping: '+name);continue
            path=pathlib.Path(name)
            if path.resolve()==pathlib.Path(command[0]).resolve() or name in libraries:continue
            try:libraries[name]={'resolved':str(path.resolve()),'sha256':sha(path)}
            except OSError as error:errors.append('unreadable mapping '+name+': '+str(error))
    timed_out=False
    while True:
        capture()
        remaining=timeout-(time.monotonic()-started)
        if remaining<=0:
            process.kill();process.wait();timed_out=True;break
        try:process.wait(timeout=min(1,remaining));break
        except subprocess.TimeoutExpired:pass
    return {'returncode':process.returncode,'timeout':timed_out,
            'loaded_libraries':libraries,'loaded_library_errors':sorted(set(errors))}

def validate_run(row,expected_command=None,expected_cwd=None):
    if row.get('returncode')!=0 or row.get('timeout'):return 'unsuccessful run'
    try:
        if row.get('loaded_library_errors') or not row.get('loaded_libraries'):return 'missing or unverifiable actual loaded libraries'
        for name,identity in row['loaded_libraries'].items():
            path=pathlib.Path(name)
            if str(path.resolve())!=identity['resolved'] or sha(path)!=identity['sha256']:return 'actual loaded shared library changed'
        for name in ('result','engine_log','command_file'):
            if sha(row[name])!=row['artifact_sha256'][name]:return name+' content changed'
        command=json.loads(pathlib.Path(row['command_file']).read_text())
        if expected_command is not None and normalized_command(command['argv'])!=normalized_command(expected_command):return 'command settings changed'
        if expected_cwd is not None and command['cwd']!=str(expected_cwd):return 'working directory changed'
        result=json.loads(pathlib.Path(row['result']).read_text())
        if result.get('status')!='completed':return 'incomplete result'
        if type(result.get('ticks')) is not int or not row['initial_tick']<=result['ticks']<=row['horizon']:return 'result tick range invalid'
        if result.get('termination')=='tick_cap' and result['ticks']!=row['horizon']:return 'tick cap mismatch'
    except (OSError,ValueError,KeyError,TypeError) as error:return 'missing or invalid evidence: '+str(error)
    return None

def reuse_reason(old,current,row,command,cwd):
    for key in ('schema','manifest_sha256','ticks','concurrency','settings','tools_sha256','environment_sha256'):
        if key not in old or old[key]!=current[key]:return key+' mismatch'
    if old.get('runtime_stable') is not True:return 'prior inputs were not verified stable at completion'
    try:
        if stable_runtime(old['runtime']['baseline'])!=stable_runtime(current['runtime']['baseline']):return 'baseline runtime inputs mismatch'
    except KeyError:return 'missing baseline runtime provenance'
    return validate_run(row,command,cwd)
