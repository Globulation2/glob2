"""Run paired gameplay outcomes from frozen initial saves; explicitly not a timing benchmark."""
import argparse,concurrent.futures,json,pathlib,random,statistics,subprocess,sys
from paired_telemetry import extract
from paired_provenance import (sha,SETTINGS,tools_snapshot,environment_snapshot,runtime_snapshot,
    stable_runtime,reuse_reason,validate_run,run_observed)

def main():
 p=argparse.ArgumentParser(__doc__)
 for name in ('baseline','candidate','manifest'):p.add_argument(name,type=pathlib.Path)
 for name in ('baseline-cwd','candidate-cwd','output'):p.add_argument('--'+name,type=pathlib.Path,required=True)
 p.add_argument('--reuse-baseline',type=pathlib.Path)
 p.add_argument('--jobs',type=int,default=4);p.add_argument('--ticks',type=int,default=90000)
 a=p.parse_args();assert 1<=a.jobs<=4
 a.output=a.output.resolve()
 manifest=json.loads(a.manifest.read_text());a.output.mkdir(parents=True,exist_ok=False)
 variants={'baseline':(a.baseline.resolve(),a.baseline_cwd.resolve()),'candidate':(a.candidate.resolve(),a.candidate_cwd.resolve())}
 provenance={'schema':2,'timing_valid':False,'manifest_sha256':sha(a.manifest),'manifest':str(a.manifest.resolve()),
  'ticks':a.ticks,'concurrency':a.jobs,'settings':SETTINGS,'tools_sha256':tools_snapshot(),
  'environment_sha256':environment_snapshot(),'runtime':{v:runtime_snapshot(b,c) for v,(b,c) in variants.items()},
  'runtime_stable':False,'note':'Gameplay comparison only; cross-revision exact checksum identity is not expected.'}
 prior={};old={};prior_error=''
 if a.reuse_baseline:
  a.reuse_baseline=a.reuse_baseline.resolve()
  try:
   old=json.loads((a.reuse_baseline/'provenance.json').read_text())
   prior={r['scenario']:r for r in json.loads((a.reuse_baseline/'runs.json').read_text()) if r['variant']=='baseline'}
   provenance['reuse_source']={'directory':str(a.reuse_baseline),'provenance_sha256':sha(a.reuse_baseline/'provenance.json'),'runs_sha256':sha(a.reuse_baseline/'runs.json')}
  except (OSError,ValueError,KeyError,TypeError) as error:prior_error='prior evidence unavailable: '+str(error)
 (a.output/'provenance.json').write_text(json.dumps(provenance,indent=2))
 def execute(job):
  scenario,variant=job;binary,cwd=variants[variant]
  for file,expected in scenario['fixture_sha256'].items():assert sha(file)==expected
  output=a.output/scenario['id']/variant;output.mkdir(parents=True)
  args=scenario['args'].copy();args[args.index('--ticks')+1]=str(a.ticks)
  command=[str(binary),'--run-game',*args,'--output-dir',str(output),*SETTINGS]
  rejection=None
  if variant=='baseline' and a.reuse_baseline:
   previous=prior.get(scenario['id'])
   rejection=prior_error or ('missing scenario' if previous is None else reuse_reason(old,provenance,previous,command,cwd))
   if not rejection:
    record={**previous,'analysis_dir':str(output),'reused_from':{'tournament':str(a.reuse_baseline),'result':previous['result'],'engine_log':previous['engine_log'],'command_file':previous['command_file']}}
    (output/'reuse.json').write_text(json.dumps(record,indent=2))
    print(scenario['id'],variant,'reused verified baseline',flush=True);return record
  command_file=output/'command.json'
  command_file.write_text(json.dumps({'argv':command,'cwd':str(cwd)},indent=2))
  record={'scenario':scenario['id'],'variant':variant,'group':scenario['group'],'control':scenario.get('control',False),
   'initial_tick':scenario.get('start_tick',0),'horizon':a.ticks,'result':str(output/'result.json'),
   'engine_log':str(output/'engine.log'),'command_file':str(command_file),'analysis_dir':str(output),
   'fixture_sha256':scenario['fixture_sha256']}
  if rejection:record['reuse_rejected']=rejection
  with (output/'engine.log').open('w') as log:record.update(run_observed(command,cwd,log))
  record['artifact_sha256']={name:sha(record[name]) for name in ('result','engine_log','command_file') if pathlib.Path(record[name]).is_file()}
  (output/'run.json').write_text(json.dumps(record,indent=2))
  print(scenario['id'],variant,record.get('returncode','timeout'),flush=True);return record
 jobs=[(s,v) for s in manifest['scenarios'] for v in variants]
 with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as pool:rows=list(pool.map(execute,jobs))
 (a.output/'runs.json').write_text(json.dumps(rows,indent=2))
 final_runtime={v:runtime_snapshot(b,c) for v,(b,c) in variants.items()}
 provenance['runtime_stable']=all(stable_runtime(final_runtime[v])==stable_runtime(provenance['runtime'][v]) for v in variants) and tools_snapshot()==provenance['tools_sha256'] and environment_snapshot()==provenance['environment_sha256'] and sha(a.manifest)==provenance['manifest_sha256']
 provenance['runtime_stable']=provenance['runtime_stable'] and all(sha(path)==expected for scenario in manifest['scenarios'] for path,expected in scenario['fixture_sha256'].items())
 provenance['runtime_after']=final_runtime
 (a.output/'provenance.json').write_text(json.dumps(provenance,indent=2))
 if not provenance['runtime_stable']:raise RuntimeError('Inputs changed during tournament; evidence is not eligible for reuse or accepted analysis')
 analyze(a.output,rows)

def compare_candidates():
 p=argparse.ArgumentParser('Join the candidate arms of two compatible paired tournaments without launching engines')
 p.add_argument('earlier',type=pathlib.Path);p.add_argument('later',type=pathlib.Path);p.add_argument('--output',type=pathlib.Path,required=True)
 a=p.parse_args(sys.argv[2:]);out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
 dirs=[a.earlier.resolve(),a.later.resolve()];provs=[json.loads((d/'provenance.json').read_text()) for d in dirs]
 for key in ('schema','manifest_sha256','ticks','concurrency','settings','tools_sha256','environment_sha256'):
  if provs[0].get(key)!=provs[1].get(key):raise ValueError('Incompatible comparison '+key)
 if tools_snapshot()!=provs[0]['tools_sha256']:raise ValueError('Current analysis driver/extractor differs from recorded version')
 if not all(p.get('runtime_stable') is True for p in provs):raise ValueError('Unverified tournament inputs')
 if stable_runtime(provs[0]['runtime']['baseline'])!=stable_runtime(provs[1]['runtime']['baseline']):raise ValueError('Different baseline controls')
 rows=[]
 for directory,variant in zip(dirs,('baseline','candidate')):
  for row in json.loads((directory/'runs.json').read_text()):
   if row['variant']!='candidate':continue
   error=validate_run(row)
   if error:row={**row,'returncode':-1,'join_error':error}
   rows.append({**row,'variant':variant,'original_tournament':str(directory),'analysis_dir':str(out/row['scenario']/variant)})
 (out/'provenance.json').write_text(json.dumps({'kind':'joined-candidate-arms','timing_valid':False,'sources':[{'directory':str(d),'provenance_sha256':sha(d/'provenance.json'),'runs_sha256':sha(d/'runs.json')} for d in dirs]},indent=2))
 (out/'runs.json').write_text(json.dumps(rows,indent=2));analyze(out,rows)

def analyze(out,rows):
 by={};failures=[]
 for row in rows:
  if row.get('returncode')!=0:failures.append(row);continue
  error=validate_run(row)
  if error:failures.append({**row,'validation_error':error});continue
  try:d=json.loads(pathlib.Path(row['result']).read_text())
  except (OSError,ValueError) as error:failures.append({**row,'analysis_error':str(error)});continue
  if d.get('status')!='completed':failures.append(row);continue
  t=d['teams'];metrics={'ticks':d['ticks'],'tick_cap':int(d.get('termination')=='tick_cap'),'surviving_teams':sum(x.get('alive',False) for x in t)}
  for field in ['units','workers','warriors','buildings','sites']:metrics[field]=sum(x.get(field,0) for x in t)
  resolved=d.get('termination')=='engine_end' and d.get('unresolved') is False
  metrics['resolved_outcome']=int(resolved);metrics['unresolved_outcome']=int(not resolved)
  ai_teams={}
  for player in d.get('players',[]):
   if isinstance(player.get('ai'),str) and type(player.get('team')) is int:
    ai_teams.setdefault(player['ai'],set()).add(player['team'])
  winners=set(d.get('winning_teams',[]))
  for ai,teams in ai_teams.items():
   metrics['resolved_win_team_share_'+ai]=len(winners&teams)/len(teams) if resolved else None
   metrics['resolved_match_win_'+ai]=int(bool(winners&teams)) if resolved else None

  for field in ['needFood','needFoodCritical','needFoodNoInns']:metrics[field]=sum(x.get('standard_statistics',{}).get(field,0) for x in t)
  telemetry=extract(row.get('engine_log',pathlib.Path(row['result']).parent/'engine.log'),d,row.get('initial_tick',0),row.get('horizon',90000))
  metrics.update(telemetry['metrics'])
  analysis_dir=pathlib.Path(row.get('analysis_dir',out/row['scenario']/row['variant']));analysis_dir.mkdir(parents=True,exist_ok=True)
  (analysis_dir/'telemetry-summary.json').write_text(json.dumps(telemetry,indent=2))
  by.setdefault(row['scenario'],{'group':row['group'],'control':row['control'],'scenario':row['scenario']})[row['variant']]={'metrics':metrics,'winners':d.get('winning_teams',[]),'checksum':d.get('finalChecksum'),'telemetry_errors':telemetry['parse_errors'],'telemetry_team_coverage':{k:v['status'] for k,v in telemetry['teams'].items()}}
 pairs={k:v for k,v in by.items() if 'baseline'in v and 'candidate'in v};summary={}
 for pair in pairs.values():
  left,right=pair['baseline'],pair['candidate']
  both=left['metrics']['resolved_outcome'] and right['metrics']['resolved_outcome']
  left['metrics']['observed_winner_set_change']=0 if both else None
  right['metrics']['observed_winner_set_change']=int(set(left['winners'])!=set(right['winners'])) if both else None
  left['metrics']['resolution_status_change']=0
  right['metrics']['resolution_status_change']=int(left['metrics']['resolved_outcome']!=right['metrics']['resolved_outcome'])

 for group in ['all',*sorted(set(v['group'] for v in pairs.values())),'control']:
  selected=[v for v in pairs.values() if (v['control'] if group=='control' else not v['control'] and (group=='all' or v['group']==group))]
  if not selected:continue
  result={'games':len(selected),'observed_winner_set_changed':sum(v['candidate']['metrics']['observed_winner_set_change'] or 0 for v in selected),'both_resolved_pairs':sum(v['candidate']['metrics']['observed_winner_set_change'] is not None for v in selected),'metrics':{}}
  for metric in sorted(set().union(*(set(v[variant]['metrics']) for v in selected for variant in ('baseline','candidate')))):
   complete=[v for v in selected if all(v[variant]['metrics'].get(metric) is not None for variant in ('baseline','candidate'))]
   if not complete:
    result['metrics'][metric]={'available_pairs':0,'missing_pairs':len(selected)};continue
   diffs=[v['candidate']['metrics'][metric]-v['baseline']['metrics'][metric] for v in complete]
   clusters={}
   for v,diff in zip(complete,diffs):
    parts=v['scenario'].removeprefix('control-').split('-');cluster='-'.join(parts[:3]);clusters.setdefault(cluster,[]).append(diff)
   cluster_changes=[statistics.mean(values) for values in clusters.values()]
   if len(set(cluster_changes))==1:interval=[cluster_changes[0],cluster_changes[0]]
   else:
    rng=random.Random(4242);samples=sorted(statistics.mean(rng.choices(cluster_changes,k=len(cluster_changes))) for _ in range(10000));interval=[samples[249],samples[9749]]
   result['metrics'][metric]={'available_pairs':len(complete),'missing_pairs':len(selected)-len(complete),'baseline_mean':statistics.mean(v['baseline']['metrics'][metric] for v in complete),'candidate_mean':statistics.mean(v['candidate']['metrics'][metric] for v in complete),'paired_mean_change':statistics.mean(diffs),'geometry_balanced_mean_change':statistics.mean(cluster_changes),'geometry_clusters':len(clusters),'bootstrap95':interval,'individual_changes':diffs,'directional_interpretation':'descriptive; CI excludes within512tick interval and competing-event uncertainty' if 'waiting_' in metric else 'descriptive; unresolved games excluded, resolution-selection bias possible' if metric.startswith(('resolved_win_','resolved_match_','observed_winner_')) else 'descriptive'}
  summary[group]=result
 (out/'summary.json').write_text(json.dumps({'timing_valid':False,'caution':'Bootstrap clusters by terrain/teamcount/mapseed (AI mixes and swapped sides share each geometry). Only two seed values and eight geometry configurations; intervals are descriptive, not proof of equivalence. Tick-cap and otherwise unresolved outcomes are censored, never counted as losses. Win shares and winner-change intervals use only paired resolved outcomes; selection due to differential resolution remains a limitation.','failed_runs':failures,'groups':summary,'pairs':pairs},indent=2))
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='--compare-candidates':compare_candidates()
 else:main()
