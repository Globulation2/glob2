from pathlib import Path
import json,time
from paired_provenance import *
from paired_behavior import analyze
out=ROOT/'artifacts/resource-refactor/tournament-ee3-approved-fixes'
p=json.loads((out/'provenance.json').read_text());rows=json.loads((out/'runs.json').read_text())
audit={'kind':'analysis-only-recovery','prior_wrapper_exit':143,'prior_engine_results':len(rows),'timing_valid':False,'reason':'Original enclosing session terminated after all runs and stable-runtime finalization, before summary write. No engine rerun.'}
assert len(rows)==84 and p['runtime_stable'] is True
assert environment_snapshot()==p['environment_sha256']
assert tools_snapshot()==p['tools_sha256']
assert sha(p['manifest'])==p['manifest_sha256']
for v,old in p['runtime'].items():assert stable_runtime(runtime_snapshot(old['binary'],old['cwd']))==stable_runtime(old)
for r in rows:
 error=validate_run(r)
 assert error is None,(r['scenario'],r['variant'],error)
audit.update(environment_sha256=environment_snapshot(),tools_sha256=tools_snapshot(),provenance_sha256=sha(out/'provenance.json'),runs_sha256=sha(out/'runs.json'),verified_runs=len(rows))
(out/'analysis-recovery.json').write_text(json.dumps(audit,indent=2)+'\n')
print('All84 complete run records and runtime provenance verified; analyzing.',flush=True)
analyze(out,rows)
s=json.loads((out/'summary.json').read_text());assert len(s['pairs'])==42 and not s['failed_runs']
audit.update(complete=True,summary_sha256=sha(out/'summary.json'))
(out/'analysis-recovery.json').write_text(json.dumps(audit,indent=2)+'\n')
print('Analysis recovered:42pairs,0failures.',flush=True)
