from pathlib import Path
import json,tarfile,subprocess,hashlib,zipfile,csv,io
from paired_provenance import sha
ROOT=Path.cwd();A=ROOT/'artifacts/resource-refactor';R=A/'tournament-ee3-approved-fixes';D=A/'ee3-control-publication';D.mkdir(exist_ok=True)
rows=json.loads((R/'runs.json').read_text());summary=json.loads((R/'summary.json').read_text());prov=json.loads((R/'provenance.json').read_text());assert prov['runtime_stable'] and len(rows)==84 and not summary['failed_runs']
index={'timing_valid':False,'source':'pure ee3be8ecd versus same base plus approved three fixes; not refactor comparison','artifacts':[],'logs':[],'limitations':summary['caution'],'interruption':'Original wrapper exit143 after successful engines/final runtime hashes. Analysis-only recovery revalidated all original records; see analysis-recovery.json.'}
for group in ['land-2','land-4','water-2','water-4','control']:
 selected=[r for r in rows if ('control' if r['control'] else '-'.join(r['scenario'].split('-')[:2]))==group]
 dest=D/(group+'-logs.tar.zst');cmd=['zstd','-q','-6','-T1','-f','-o',str(dest)]
 process=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 with tarfile.open(fileobj=process.stdin,mode='w|') as tar:
  for row in selected:
   p=Path(row['engine_log']);name=str(p.relative_to(ROOT));tar.add(p,arcname=name,recursive=False)
   index['logs'].append({'archive':dest.name,'path':name,'sha256':row['artifact_sha256']['engine_log'],'bytes':p.stat().st_size})
 process.stdin.close();assert process.wait()==0
 # Verify all decompressed bytes independently against original retained hashes.
 expected={x['path']:x['sha256'] for x in index['logs'] if x['archive']==dest.name};seen=set()
 proc=subprocess.Popen(['zstd','-q','-d','-c',str(dest)],stdout=subprocess.PIPE)
 with tarfile.open(fileobj=proc.stdout,mode='r|') as tar:
  for member in tar:
   source=tar.extractfile(member);digest=hashlib.sha256()
   for block in iter(lambda:source.read(1024*1024),b''):digest.update(block)
   assert digest.hexdigest()==expected[member.name];seen.add(member.name)
 assert proc.wait()==0 and seen==set(expected)
 index['artifacts'].append({'path':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest),'logs':len(selected),'verification':'decompressed each member and matched original run content SHA256'})
 print(group,dest.stat().st_size,flush=True)
# All statistical fields, not selected only for direction/significance.
columns=['group','metric','games','available_pairs','missing_pairs','baseline_mean','candidate_mean','paired_mean_change','geometry_balanced_mean_change','geometry_clusters','bootstrap95','directional_interpretation'];csvpath=D/'all-metrics.csv'
with csvpath.open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
 for group,g in summary['groups'].items():
  for metric,v in g['metrics'].items():writer.writerow({**{k:v.get(k) for k in columns},'group':group,'metric':metric,'games':g['games']})
paths=set(p for p in R.rglob('*') if p.is_file() and p.name!='engine.log')
for name in ['paired_behavior.py','paired_telemetry.py','paired_provenance.py','recover_ee3_control_analysis.py','package_ee3_control.py','master-ee3-controls-summary.json','master-ee3-pure-provenance.json','master-ee3-approved-provenance.json','master-ee3-pure-actual.patch','master-ee3-approved-actual.patch','master-ee3-pure-build.log','master-ee3-approved-build.log','control-analysis-recovery.log','tournament-ee3-approved-fixes.log','full-baseline-corpus/completion.json']:
 paths.add(A/name)
paths.add(ROOT/'tools/tournaments/game_telemetry.py')
manifest=json.loads((A/'full-baseline-corpus/completion.json').read_text())
for scenario in manifest['scenarios']:
 for name,digest in scenario['fixture_sha256'].items():
  p=Path(name);assert sha(p)==digest;paths.add(p)
  # Generation provenance alongside each original frozen fixture.
  paths.update(p.parent.glob('*.json'))
for p in (A/'master-ee3-pure-source/data').rglob('*'):
 if p.is_file() and p.suffix.lower() in {'.json','.txt','.js'}:paths.add(p)
compact=D/'control-summary-inputs-provenance.zip'
with zipfile.ZipFile(compact,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths):
  if p.is_file():z.write(p,str(p.relative_to(ROOT)))
 z.write(csvpath,csvpath.name)
index['artifacts'].append({'path':compact.name,'bytes':compact.stat().st_size,'sha256':sha(compact),'contents':'All non-log run evidence and telemetry summaries; all metrics; exact driver/parser/recovery; source/build/runtime identities and patch; original42 fixtures and generation metadata; runtime JSON/TXT/JS input bytes. No binaries/dependencies/fullsource.'})
index['raw_log_bytes']=sum(x['bytes'] for x in index['logs']);index['compressed_log_bytes']=sum(x['bytes'] for x in index['artifacts'] if x['path'].endswith('.zst'))
(D/'inventory.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({k:index[k] for k in ('raw_log_bytes','compressed_log_bytes')}),flush=True)
