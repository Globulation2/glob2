"""Offline paired-game telemetry extraction. Missing observations are never zeros."""
import importlib.util
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parents[2]
_spec = importlib.util.spec_from_file_location('glob2_game_telemetry', ROOT / 'tools/tournaments/game_telemetry.py')
_parser = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_parser)
MATERIALS = ('wood', 'food', 'paper', 'stone', 'algae', 'cherries', 'oranges', 'prunes', 'gold', 'metal', 'glass', 'fabric')


def summed(row, pattern):
    values = [value for key, value in row.items() if re.fullmatch(pattern, key)]
    return sum(values) if values and all(type(v) is int for v in values) else None


def subtract(final, initial):
    return final - initial if final is not None and initial is not None else None


def series(log):
    """Deduplicate final history copies; preserve malformed/contradictory evidence."""
    measure, econ, errors = {}, {}, []
    with pathlib.Path(log).open(errors='replace') as log_file:
        for line_number, line in enumerate(log_file, 1):
            if not line.startswith(('GLOB2_MEASURE ', 'GLOB2_MEASURE_HISTORY ', 'GLOB2_ECON ')):
                continue
            try:
                prefix, values = _parser.parse(line)
                team, tick = values['team'], values['tick']
                if type(team) is not int or type(tick) is not int:
                    raise ValueError('invalid team/tick')
                target = econ if prefix == 'GLOB2_ECON' else measure
                existing = target.setdefault(team, {}).get(tick)
                if existing:
                    keys = (set(existing) & set(values)) - {'final'}
                    if any(existing[key] != values[key] for key in keys):
                        errors.append({'line': line_number, 'team': team, 'tick': tick, 'error': 'contradictory duplicate sample'})
                # Prefer exact final flags over the duplicated historical prefix.
                if not existing or values.get('final', 0) >= existing.get('final', 0):
                    target[team][tick] = values
            except (ValueError, KeyError, TypeError) as error:
                errors.append({'line': line_number, 'error': str(error)})
    return measure, econ, errors


def milestone(samples, field_pattern, threshold, coverage, horizon):
    """Event time lies in (previous sample, first threshold sample], or is censored."""
    previous = coverage
    for tick, row in sorted(samples.items()):
        total = summed(row, field_pattern)
        if total is None:
            return {'status': 'unavailable'}
        if total >= threshold:
            return {'status': 'observed', 'lower_tick_exclusive': previous,
                    'upper_tick_inclusive': tick, 'sample_interval': tick - previous}
        previous = tick
    return {'status': 'right_censored_at_observation_end', 'last_observed_tick': previous,
            'requested_horizon': horizon,
            'note': 'Game end/elimination can compete with construction; no independent-censoring assumption.'}


def extract(log, result, initial_tick, horizon):
    measures, economy, errors = series(log)
    per_team, metrics = {}, {}
    for team in result['teams']:
        number = team['team']
        samples = measures.get(number, {})
        if not samples:
            per_team[str(number)] = {'status': 'unavailable', 'reason': 'no gameplay measurements'}
            continue
        final_tick = max(samples)
        final = samples[final_tick]
        coverage = final.get('coverage_start')
        if type(coverage) is not int:
            per_team[str(number)] = {'status': 'unavailable', 'reason': 'missing coverage start'}
            continue
        # Baseline fixtures start at tick0. Coverage0 gives cumulative-from-start
        # counters even when the first emitted sample is tick512. For other
        # starts require an actual starting sample before computing run deltas.
        initial = samples.get(initial_tick)
        from_zero = initial_tick == 0 and coverage == 0
        counters = {}
        for material, name in enumerate(MATERIALS):
            for key in ('harvested', 'delivered', 'withdrawn', 'stock', 'carried'):
                wire = f'{key}_{material}'
                total = final.get(wire)
                base = 0 if from_zero else initial.get(wire) if initial else None
                counters[f'{key}_{name}'] = total if key in ('stock', 'carried') else subtract(total, base)
            for purpose, name_of_purpose in ((0, 'meals'), (1, 'births'), (2, 'ammunition'), (3, 'construction'), (4, 'upgrades'), (5, 'healing'), (6, 'training')):
                wire = f'consumed_{purpose}_{material}'
                base = 0 if from_zero else initial.get(wire) if initial else None
                counters[f'consumed_{name_of_purpose}_{name}'] = subtract(final.get(wire), base)
        for label, pattern in [('starvation_deaths', r'deaths_\d+_1'), ('births', r'births_\d+'),
                               ('new_buildings', r'completed_0_\d+_\d+'), ('upgrades', r'completed_1_\d+_\d+')]:
            base = 0 if from_zero else summed(initial, pattern) if initial else None
            counters[label] = subtract(summed(final, pattern), base)
        elapsed = final_tick - initial_tick
        rates = {key + '_per_1000_ticks': value * 1000 / elapsed if elapsed > 0 and value is not None else None
                 for key, value in counters.items() if key.startswith(('harvested_', 'delivered_'))}
        milestones = {f'new_buildings_{n}': milestone(samples, r'completed_0_\d+_\d+', n, coverage, horizon) for n in (1, 5, 10)}
        milestones['first_upgrade'] = milestone(samples, r'completed_1_\d+_\d+', 1, coverage, horizon)
        per_team[str(number)] = {'status': 'observed' if final.get('final') == 1 and final_tick == result['ticks'] else 'partial', 'coverage_start': coverage, 'last_tick': final_tick,
                                'exact_final': final.get('final') == 1, 'samples': len(samples),
                                'counters': counters, 'rates': rates, 'construction_milestones': milestones,
                                'economy_samples': list(economy.get(number, {}).values())}
    observed = [value for value in per_team.values() if value['status'] == 'observed']
    # Sum only complete team coverage; incomplete/missing fields remain unavailable.
    if len(observed) == len(result['teams']) and observed and not errors:
        for section in ('counters', 'rates'):
            for key in observed[0][section]:
                values = [team[section][key] for team in observed]
                metrics[key] = sum(values) if all(v is not None for v in values) else None
        for key in observed[0]['construction_milestones']:
            events = [team['construction_milestones'][key] for team in observed]
            if any(event['status'] == 'unavailable' for event in events):
                continue
            metrics[key + '_observed_fraction'] = sum(event['status'] == 'observed' for event in events) / len(events)
            metrics[key + '_waiting_lower_ticks'] = sum(event.get('lower_tick_exclusive', event.get('last_observed_tick')) for event in events) / len(events)
            metrics[key + '_waiting_upper_ticks'] = sum(event.get('upper_tick_inclusive', horizon) for event in events) / len(events)
    return {'teams': per_team, 'metrics': metrics, 'parse_errors': errors,
            'limitations': ['Harvested units are raw one-unit harvest packets; delivered/consumed are building stock units, not normalized across recipe multipliers.',
                           'Construction times are from game start to cumulative completion milestones, interval-observed at512tick cadence; no project-start events exist.',
                           'Missing telemetry is unavailable, not zero. Censored construction includes game-end/elimination competing events.',
                           'Final stocks/population and cumulative counters depend on game length; per1000tick throughput is reported separately.']}
