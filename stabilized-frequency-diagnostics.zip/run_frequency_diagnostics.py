import subprocess, sys, json, hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=root/'artifacts/resource-followup/stable-frequency'
out.mkdir(parents=True,exist_ok=False)
commands=[]
for arm, directory in [('merged','symbolized-merged'),('rejected-ring','symbolized-ring')]:
 for case in ['land-2-1002-maxima-late','land-2-1001-cortex-late']:
  commands.append([sys.executable,'artifacts/resource-followup/profile_merged.py','profile',f'artifacts/resource-followup/{directory}/glob2','artifacts/resource-followup/priority-recovery/priority-windows.json',case,str(out/f'{arm}-{case}'),'--counter-mode','stat'])
(out/'plan.json').write_text(json.dumps({'scope':'Separate post-campaign instrumented frequency diagnostics under the same governor and affinity; not frequency of earlier timing samples, not CPU acceptance evidence.','commands':commands,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
for command in commands:subprocess.run(command,cwd=root,check=True)
