"""Exact-workload diagnostic profiles; never performance acceptance timing."""
import argparse, hashlib, json, os, pathlib, pwd, shlex, shutil, struct, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'test'))
from benchmark_resource_refactor import runtime_libraries
from build_provenance import source_identity
ENV=os.environ.copy()
ENV['LD_LIBRARY_PATH']='/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib'
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def elf(p):
 b=p.read_bytes();assert b[:6]==b'\x7fELF\x02\x01'
 e=struct.unpack_from('<16sHHIQQQIHHHHHH',b);off,size,count,names_idx=e[6],e[11],e[12],e[13]
 ss=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*size) for i in range(count)]
 names=b[ss[names_idx][4]:ss[names_idx][4]+ss[names_idx][5]]
 return {names[s[0]:].split(b'\0')[0].decode():{'addr':s[3],'size':s[5],'sha256':hashlib.sha256(b[s[4]:s[4]+s[5]]).hexdigest()} for s in ss if s[2]&2 and s[1]!=8}
def symbolize(args):
 log=args.build_log.resolve(); frozen=args.binary.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
 lines=[shlex.split(line) for line in log.read_text().splitlines() if line.startswith('g++ -o build/linux/client/release/src/glob2 ')]
 if len(lines)!=1:raise RuntimeError('Expected exactly one completed native link command')
 cmd=[v for v in lines[0] if v!='-s'];cmd[cmd.index('-o')+1]=str(out/'glob2')
 inputs={str((ROOT/v).resolve()):sha(ROOT/v) for v in cmd if v.endswith(('.o','.a')) and (ROOT/v).is_file()}
 record={'source':source_identity(ROOT),'command':cmd,'cwd':str(ROOT),'build_log':str(log),'build_log_sha256':sha(log),'frozen_binary':str(frozen),'frozen_sha256':sha(frozen),'object_inputs':inputs,'timing_valid':False,'status':'linking'}
 write(out/'provenance.json',record)
 with (out/'link.log').open('w') as f:subprocess.run(cmd,cwd=ROOT,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
 if any(sha(p)!=h for p,h in inputs.items()):raise RuntimeError('Link inputs changed')
 a,b=elf(frozen),elf(out/'glob2');diff={k:[a.get(k),b.get(k)] for k in a.keys()|b.keys() if a.get(k)!=b.get(k)}
 record.update(status='linked',binary_sha256=sha(out/'glob2'),allocated_sections_frozen=a,allocated_sections_symbolized=b,allocated_differences=diff)
 write(out/'provenance.json',record)
 if set(diff)-{'.note.gnu.build-id'}:raise RuntimeError('Symbolized binary allocated sections differ')
 print('Verified symbolized twin',out/'glob2',flush=True)
def profile(args):
 out=args.output.resolve();out.mkdir(parents=True,exist_ok=False);binary=args.binary.resolve();manifest=args.manifest.resolve();symbol=json.loads((binary.parent/'provenance.json').read_text())
 if set(symbol['allocated_differences'])-{'.note.gnu.build-id'}:raise RuntimeError('Symbolization mismatch')
 scenario=next(s for s in json.loads(manifest.read_text())['scenarios'] if s['id']==args.scenario)
 inputs={str(binary):sha(binary),str(manifest):sha(manifest)}
 for p in (ROOT/'data').rglob('*'):
  if p.is_file() and p.suffix in {'.json','.txt','.js','.sgsl'}:inputs[str(p)]=sha(p)
 for p,h in scenario['fixture_sha256'].items():
  if sha(p)!=h:raise RuntimeError('Frozen fixture mismatch: '+p)
  inputs[p]=h
 old=os.environ.get('LD_LIBRARY_PATH');os.environ['LD_LIBRARY_PATH']=ENV['LD_LIBRARY_PATH']
 try:libs=runtime_libraries(binary)
 finally:
  if old is None:os.environ.pop('LD_LIBRARY_PATH',None)
  else:os.environ['LD_LIBRARY_PATH']=old
 inputs.update(libs['sha256'])
 command=[str(binary),'--run-game',*scenario['args'],'--benchmark-warmup','0','--output-dir',str(out/'run')]
 user=pwd.getpwuid(os.getuid()).pw_name
 inner=['sudo','-n','-u',user,'env','LD_LIBRARY_PATH='+ENV['LD_LIBRARY_PATH'],'GLOB2_USER_DIR='+str(out/'profile'),'GLOB2_USER_DATA_DIR='+str(out/'profile'),*command]
 perf_file=out/('perf-stat.csv' if args.counter_mode=='stat' else 'perf.data')
 perf_args=['stat','-x',';','-e','cycles,task-clock,instructions,context-switches,cpu-migrations'] if args.counter_mode=='stat' else ['record','-e','cycles:u','-F','499']
 argv=['taskset','-c','0-7','sudo','-n','perf',*perf_args,'-o',str(perf_file),'--',*inner]
 record={'source':source_identity(ROOT),'argv':argv,'cwd':str(ROOT),'inputs':inputs,'runtime_libraries':libs,'symbolization':symbol,'timing_valid':False,'mode':args.counter_mode,'scope':'Exact engine window, process-scoped perf diagnostic; startup included; concurrent workloads permitted for attribution only.','status':'running'}
 write(out/'provenance.json',record)
 try:
  with (out/'profile.log').open('w') as f:
   child=subprocess.Popen(argv,cwd=ROOT,env=ENV,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   record['owned_process_group']=child.pid;write(out/'provenance.json',record)
   try:code=child.wait(timeout=900)
   except BaseException:
    subprocess.run(['sudo','-n','kill','-KILL','--','-'+str(child.pid)],check=False,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    child.wait();raise
  record['returncode']=code
  if code:raise RuntimeError('perf failed')
  subprocess.run(['sudo','-n','chown',f'{os.getuid()}:{os.getgid()}',str(perf_file)],check=True)
  result=json.loads((out/'run/result.json').read_text());expected=int(scenario['args'][scenario['args'].index('--ticks')+1])-scenario['start_tick']
  if result['benchmark_measured_ticks']!=expected:raise RuntimeError('Incomplete diagnostic window')
  if args.counter_mode=='profile':
   with (out/'report.txt').open('w') as f:subprocess.run(['perf','report','--stdio','--no-children','--percent-limit','0','-i',str(perf_file)],stdout=f,stderr=subprocess.STDOUT,check=True)
  else:
   counters={}
   for line in perf_file.read_text().splitlines():
    fields=line.split(';')
    if len(fields)>=5 and fields[2] in ('cycles','task-clock','instructions','context-switches','cpu-migrations'):
     counters[fields[2]]={'value':float(fields[0]),'unit':fields[1],'running_percent':float(fields[4])}
   if not all(key in counters for key in ('cycles','task-clock')):raise RuntimeError('Missing interval frequency counters')
   if any(value['running_percent']<99.9 for value in counters.values()):raise RuntimeError('Multiplexed diagnostic counters')
   if counters['task-clock']['unit']!='msec':raise RuntimeError('Unexpected task-clock unit')
   record['frequency_diagnostic']={'counters':counters,'effective_GHz':counters['cycles']['value']/(counters['task-clock']['value']*1e6),'scope':'Process scheduled cycles divided by task-clock; all engine threads including startup, not weighted by simulation phase. Separate instrumented run, not paired CPU acceptance.'}
  record['status']='completed'
 except BaseException as e:record.update(status='failed',error=repr(e));raise
 finally:
  record['inputs_stable']=all(pathlib.Path(p).exists() and sha(p)==h for p,h in inputs.items());write(out/'provenance.json',record)
 if not record['inputs_stable']:raise RuntimeError('Diagnostic inputs changed')
 print('Profile complete',out,flush=True)
p=argparse.ArgumentParser();s=p.add_subparsers(dest='mode',required=True)
a=s.add_parser('symbolize');a.add_argument('binary',type=pathlib.Path);a.add_argument('build_log',type=pathlib.Path);a.add_argument('output',type=pathlib.Path)
a=s.add_parser('profile');a.add_argument('binary',type=pathlib.Path);a.add_argument('manifest',type=pathlib.Path);a.add_argument('scenario');a.add_argument('output',type=pathlib.Path);a.add_argument('--counter-mode',choices=['profile','stat'],default='profile')
a=p.parse_args();symbolize(a) if a.mode=='symbolize' else profile(a)
