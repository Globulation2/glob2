#!/usr/bin/env python3
import json,math,statistics,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'test'))
import benchmark_resource_refactor as b
base=Path(__file__).resolve().parent/'gradient-reuse-v2-isolated-01'
rows=[json.loads(line) for line in (base/'v2-priority/measurements.jsonl').read_text().splitlines()]
summary=json.loads((base/'v2-priority/summary.json').read_text())
assert len(rows)==68
scenarios=sorted({r['scenario'] for r in rows})
assert len(scenarios)==2
pairs={}
for s in scenarios:
 sr=[r for r in rows if r['scenario']==s]
 assert len(sr)==34
 for i in range(-1,16):
  pair=[r for r in sr if r['repeat']==i]
  assert [r['variant'] for r in pair]==(['baseline','candidate'] if i%2 else ['candidate','baseline'])
  assert all(r['result']['benchmark_measured_ticks']==8192 and r['result']['ticks']==32768 for r in pair)
  assert len({r['result']['finalChecksum'] for r in pair})==1
 pairs[s]=[{r['variant']:r for r in sr if r['repeat']==i} for i in range(16)]
 for metric,reported in summary['scenarios'][s].items():
  logs=[math.log(p['candidate'][metric]/p['baseline'][metric]) for p in pairs[s]]
  assert math.isclose(math.exp(statistics.mean(logs)),reported['ratio'],rel_tol=1e-14)
  assert b.interval(logs)==reported['ci95']
agg=b.aggregate_interval([[math.log(p['candidate']['simulation_cpu_s']/p['baseline']['simulation_cpu_s']) for p in pairs[s]] for s in scenarios])
assert agg==summary['aggregate_cpu']
cp=json.loads(base.with_name(base.name+'-cpuset.json').read_text()); gov=json.loads((base/'v2-priority-governors.json').read_text())
assert cp['state']=='completed' and cp['exit_code']==0 and cp['cgroup_restored'] and cp['wrapper_affinity_restored'] and not cp['forced_cgroup_kill']
assert gov['restored'] and not gov.get('child_cleanup_error')
assert json.loads((base/'inputs-before.json').read_text())==json.loads((base/'inputs-after.json').read_text())
assert json.loads((base/'campaign-state.json').read_text())['status']=='complete'
reserved=set(range(8))|set(range(16,24)); outside=set(range(32))-reserved
activity=[]
for r in rows:
 a=r['host_cpu_activity']; assert a['status']=='available'
 sums={name:sum(a['per_cpu_busy_s'][f'cpu{i}'] for i in cpus) for name,cpus in [('reserved',reserved),('outside',outside),('siblings',set(range(16,24)))]}
 activity.append({'scenario':r['scenario'],'repeat':r['repeat'],'variant':r['variant'],'snapshot_elapsed_s':a['snapshot_elapsed_s'],'child_cpu_s':r['cpu_s'],**{k+'_cpu_s':v for k,v in sums.items()},'reserved_residual_cpu_s':sums['reserved']-r['cpu_s']})
def stats(ar):
 total=sum(r['snapshot_elapsed_s'] for r in ar)
 return {'rows':len(ar),'snapshot_elapsed_s':total,**{key:{'total_s':sum(r[key] for r in ar),'weighted_average_cores':sum(r[key] for r in ar)/total,'min_average_cores':min(r[key]/r['snapshot_elapsed_s'] for r in ar),'max_average_cores':max(r[key]/r['snapshot_elapsed_s'] for r in ar)} for key in ['reserved_cpu_s','reserved_residual_cpu_s','outside_cpu_s','siblings_cpu_s']}}
audit={'status':'verified','runs':68,'measured_runs':64,'warmup_runs':4,'pairs_per_scenario':16,'summary_recomputed_exactly':True,'paired_final_checksums_equal':True,'input_snapshots_equal':True,'cpuset_restored':True,'governors_restored':True,'partition_checks':cp['validity_checks'],'summary':summary,'activity_all':stats(activity),'activity_measured':stats([r for r in activity if r['repeat']>=0]),'activity_by_scenario_variant':{s:{v:stats([r for r in activity if r['scenario']==s and r['variant']==v and r['repeat']>=0]) for v in ['baseline','candidate']} for s in scenarios},'rows':activity,'interpretation':'Provisional broader-test candidate, not final retention. Simulation CPU excludes setup and requested save, includes finishSession and final gradient drain; whole-child wait4 CPU includes setup and exit. Paired geometric ratios with seeded4000 bootstrap draws, equal scenario weighting aggregate. Residual subtracts whole-child CPU from reserved /proc/stat busy and includes kernel/wrapper activity plus coarse-jiffy/boundary skew; not process attribution. Outside CPU activity is expected under exclusivity, but shared memory/power/thermal/IRQ effects remain possible. Boundary frequency snapshots are not effective interval frequency.'}
(base/'independent-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
conditions_path=base.with_name(base.name+'-conditions.json'); conditions=json.loads(conditions_path.read_text());conditions.update(status='completed',finished_utc=cp['finished_utc'],exit_code=0,independent_audit='gradient-reuse-v2-isolated-01/independent-audit.json',inputs_unchanged=True,cpuset_restored=True,governors_restored=True,retention='Provisional broader-test candidate; final corpus and cross-platform candidate coverage pending.')
conditions_path.write_text(json.dumps(conditions,indent=2)+'\n')
print(json.dumps({k:v for k,v in audit.items() if k in ['status','summary_recomputed_exactly','activity_measured']},indent=2))
