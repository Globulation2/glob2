#include <ChecksumStream.h>
#include "src/team/stats/StatsChecksum.h"
#include <iostream>
int main() { Uint32 result=0; for(unsigned round=0;round<100;++round) {
#if LEGACY
 auto* backend=new StatsChecksumBackend; GAGCore::BinaryOutputStream out(backend);
#else
 GAGCore::ChecksumStream out;
#endif
 for(unsigned field=0;field<5000;++field) {
  const Uint32 value=field*16777619u+round;
#if LEGACY
 out.writeUint32(value,"value");
#else
 out.addUint32(value);
#endif
 }
#if LEGACY
 result^=backend->value;
#else
 result^=out.value;
#endif
 } std::cout<<result<<"\n"; }
