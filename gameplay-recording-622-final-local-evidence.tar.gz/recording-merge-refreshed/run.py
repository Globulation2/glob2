import os, subprocess, pathlib
root=pathlib.Path('/Users/bradley/glob2/artifacts/recording-merge-refreshed')
env=os.environ.copy();env['GLOB2_TEST_FFMPEG']='/Users/bradley/glob2/artifacts/recording-tools/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1'
def run(name,args,extra=None):
 e=env.copy();e.update(extra or {})
 with (root/(name+'.log')).open('w') as f:
  p=subprocess.run(args,env=e,stdout=f,stderr=subprocess.STDOUT)
 print(name,p.returncode,flush=True)
 if p.returncode: raise SystemExit(p.returncode)
run('unit',['python3','test/run_tests.py','--binary','unit','--junit',str(root/'unit.xml'),'--artifacts',str(root/'unit')])
for name,gpu in [('software','0'),('opengl','1')]:
 run(name,['python3','test/run_tests.py','--binary','engine','--filter','GameplayRecording.Integration/*','--artifacts',str(root/name),'--junit',str(root/(name+'.xml'))],{'GLOB2_TEST_RECORD_GPU':gpu})
run('touch',['python3','test/run_tests.py','--binary','engine','--filter','GameGUITouch/a touch on or near a flag*','--artifacts',str(root/'touch'),'--junit',str(root/'touch.xml')])
run('multiplayer',['python3','test/run_recording_multiplayer.py','build/darwin/client/release/test/recording-multiplayer-peer','--ffmpeg',env['GLOB2_TEST_FFMPEG'],'--output',str(root/'multiplayer')])
run('menu',['build/darwin/client/release/test/MenuColonyHarness','check','data/menu/colony.bin'],{'GLOB2_USER_DATA_DIR':str(root/'menu-profile'),'SDL_VIDEODRIVER':'cocoa','SDL_AUDIODRIVER':'dummy'})
fixtures=list((root/'unit').rglob('recording-sections-*.mp4'))
print('Media fixtures',fixtures,flush=True)
if not fixtures: raise SystemExit('No software recording fixture')
run('media',['python3','test/test_recording_tool.py'],{'GLOB2_RECORDING_FIXTURE':str(fixtures[0]),'GLOB2_TEST_FFPROBE':'/Users/bradley/glob2/artifacts/recording-tools/ffprobe/package/ffprobe'})
(root/'PASS').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
