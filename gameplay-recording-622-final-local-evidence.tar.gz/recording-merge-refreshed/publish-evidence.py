import os, subprocess, pathlib, tarfile, tempfile
root=pathlib.Path('/Users/bradley/glob2/artifacts')
proof=root/'recording-merge-refreshed'
def git(*args,env=None): return subprocess.check_output(['git',*args],env=env,text=True).strip()
head=git('rev-parse','HEAD')
assert (proof/'PASS').read_text().strip()==head
(proof/'provenance.txt').write_text('Source '+head+'\nBase '+git('rev-parse','origin/master')+'\nmacOS arm64; pinned SDL3; FFmpeg 7.1\nLocal relevant checks gate explicitly authorized by user. Hosted CI not claimed passing.\nBroader build-system suite: 276 passed, 1 skipped, 1 failure inherited unchanged from master (ScenePanels.h includes ai/AITelemetry.h).\nIdentical scene-header blobs: '+git('rev-parse','HEAD:src/scene/ScenePanels.h','origin/master:src/scene/ScenePanels.h')+'\nIdentical boundary test blobs: '+git('rev-parse','HEAD:tests/build_system/test_scene_boundary.py','origin/master:tests/build_system/test_scene_boundary.py')+'\n')
archive=root/'gameplay-recording-622-final-local-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 tar.add(proof,arcname='recording-merge-refreshed')
 for name in ('recording-final-refresh-build.log','recording-final-build-system-refreshed.log','recording-final-translations.log','recording-final-backup.log','recording-final-coverage-accounting.log'):
  tar.add(root/name,arcname=name)
subprocess.run(['git','fetch','origin','evidence/gameplay-recording-622'],check=True)
parent=git('rev-parse','origin/evidence/gameplay-recording-622')
with tempfile.TemporaryDirectory() as tmp:
 env=os.environ.copy();env['GIT_INDEX_FILE']=tmp+'/index'
 subprocess.run(['git','read-tree',parent],env=env,check=True)
 blob=git('hash-object','-w',str(archive))
 subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+archive.name],env=env,check=True)
 tree=git('write-tree',env=env)
 commit=subprocess.check_output(['git','commit-tree',tree,'-p',parent],input='Record final local recording validation for '+head+'\n',text=True).strip()
 subprocess.run(['git','push','origin',commit+':refs/heads/evidence/gameplay-recording-622'],check=True)
print('Published evidence',head,archive.stat().st_size,flush=True)
