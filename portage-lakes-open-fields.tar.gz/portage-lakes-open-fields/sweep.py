from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json
out=Path('artifacts/portage-lakes-open-fields/sweep');out.mkdir(exist_ok=True)
binary=str(Path('artifacts/portage-lakes-open-fields/after-glob2').resolve())
cases=[]
shapes=[(64,64,2,{}),(64,256,4,{}),(256,64,4,{}),(128,128,4,{}),(256,256,4,{}),(256,128,4,{}),(128,256,4,{}),(512,256,8,{}),(256,512,8,{}),(512,512,12,{})]
for width,height,teams,layout in shapes:
 for seed in [7,29]:
  for amount in [0,100,300]:
   cases.append(dict(width=width,height=height,teams=teams,seed=seed,workers=8 if seed==29 else 4,options={k:amount for k in ['wheat-amount','wood-amount','stone-amount','algae-amount','fruit-amount']}))
for elongation in [125,300]:
 for trails in [0,100]:
  for depth in [2,8]:
   cases.append(dict(width=256,height=256,teams=4,seed=401,workers=4,options={'lake-elongation':elongation,'extra-trails':trails,'portage-depth':depth}))
(out/'requests.json').write_text(json.dumps(cases,indent=2))
def run(item):
 k,c=item;cmd=[binary,'map','generate','portage-lakes','--width',str(c['width']),'--height',str(c['height']),'--teams',str(c['teams']),'--seed',str(c['seed']),'--workers',str(c['workers']),'--report-file',str(out/f'{k:03d}.json')]
 for key,value in c['options'].items():cmd+=['--set',f'{key}={value}']
 with (out/f'{k:03d}.log').open('w') as log:
  try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=600);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 return {'case':k,'returncode':code}
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,enumerate(cases)))
(out/'results.json').write_text(json.dumps(results,indent=2));print('Cases',len(results),'failures',[r for r in results if r['returncode']],flush=True)
