import json,math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=Path('artifacts/compact-unit-state');rng=np.random.default_rng(713)
def paired(rows,key,group):
 result={}
 groups=sorted({tuple(row[k] for k in group) for row in rows if row['repeat']>=0})
 for g in groups:
  selected=[r for r in rows if r['repeat']>=0 and tuple(r[k] for k in group)==g]
  before={r['repeat']:r[key] for r in selected if r['variant']=='reference'};after={r['repeat']:r[key] for r in selected if r['variant']=='compact'}
  repeats=sorted(before.keys()&after.keys());a=np.array([before[i] for i in repeats]);b=np.array([after[i] for i in repeats]);logs=np.log(b/a);samples=logs[rng.integers(0,len(logs),(20000,len(logs)))].mean(axis=1);ci=np.exp(np.quantile(samples,[.025,.975]));ratio=float(np.exp(logs.mean()))
  result['/'.join(map(str,g))]={'pairs':len(repeats),'before_mean':float(a.mean()),'after_mean':float(b.mean()),'geomean_ratio':ratio,'ratio_ci95':ci.tolist(),'reduction_percent':100*(1-ratio),'reduction_ci95':[100*(1-ci[1]),100*(1-ci[0])],'minimum':float(logs.min()),'maximum':float(logs.max())}
 return result
summary={};capture=json.loads((out/'capture-pairs/samples.json').read_text());summary['capture_elapsed']=paired(capture,'elapsed_ns',['units','scenario']);summary['capture_only']=paired(capture,'capture_ns',['units','scenario'])
for name,key,group in [('engine','run_ns',['fixture','mode']),('render','median_ms',['units'])]:
 p=out/f'{name}-pairs/samples.json'
 if p.exists():summary[name]=paired(json.loads(p.read_text()),key,group)
summary['callgrind']=json.loads((out/'callgrind-summary.json').read_text());summary['canonical']=json.loads((out/'correctness/comparison.json').read_text());(out/'paired-summary.json').write_text(json.dumps(summary,indent=2))
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(2,2,figsize=(13,9),layout='constrained')
ax=axes[0,0];labels=['Previous full record','Compact core','Core + details'];vals=[384,160,376];bars=ax.bar(labels,vals,color=['#667085','#167b83','#79ac91']);ax.axhline(192,color='#a64b3b',linestyle='--',label='Core size budget: 192 B');ax.set_ylabel('Bytes per unit');ax.set_title('Record layout: smaller core, no larger full payload');ax.legend(loc='upper right');ax.bar_label(bars,fmt='%d B')
scenarios=['movement','guard','market','render','render-panels','render-movement','render-ai','render-all'];names=['Movement','Guard','Market','Render','Panels','Render + move','Render + AI','All combined'];x=np.arange(len(scenarios));width=.38
ax=axes[0,1]
for i,variant in enumerate(('reference','compact')):
 vals=[next(r['bytes_copied']/2**20 for r in capture if r['repeat']==0 and r['units']==1024 and r['variant']==variant and r['scenario']==s) for s in scenarios];ax.bar(x+(i-.5)*width,vals,width,label=variant,color=['#667085','#167b83'][i])
ax.set_xticks(x,names,rotation=35,ha='right');ax.set_ylabel('Reported copy/payload work (MiB / 128 ticks)');ax.set_title('1,024 units: independent and shared requests');ax.legend()
ax=axes[1,0];metrics=[summary['capture_only'][f'1024/{s}'] for s in scenarios];r=np.array([v['reduction_percent'] for v in metrics]);lo=np.array([v['reduction_ci95'][0] for v in metrics]);hi=np.array([v['reduction_ci95'][1] for v in metrics]);ax.errorbar(x,r,yerr=np.stack([r-lo,hi-r]),fmt='o',capsize=4,color='#167b83');ax.axhline(0,color='#667085',linewidth=1);ax.set_xticks(x,names,rotation=35,ha='right');ax.set_ylabel('Capture time reduction (%)');ax.set_title('Ten paired release runs; bootstrap 95% intervals')
ax=axes[1,1];cg=summary['callgrind']['instructions'];bars=ax.bar(['Previous guard capture','Compact guard capture'],[cg['reference']/1e6,cg['compact']/1e6],color=['#667085','#167b83']);ax.bar_label(bars,fmt='%.2f M');ax.set_ylabel('Instructions (millions)');ax.set_title('Callgrind: 44.8% fewer capture instructions')
fig.suptitle('Shared compact unit cores — isolated refactor comparison',fontsize=16)
fig.savefig(out/'compact-core-evidence.png',dpi=180);fig.savefig(out/'compact-core-evidence.svg');fig.savefig(out/'compact-core-evidence.pdf');plt.close(fig)
print(json.dumps({k:v for k,v in summary.items() if k in ('capture_only','engine','render')},indent=2))
