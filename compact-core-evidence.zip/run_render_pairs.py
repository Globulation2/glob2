from pathlib import Path
import subprocess,os,json,re,hashlib
root=Path.cwd();out=root/'artifacts/compact-unit-state/render-pairs';out.mkdir(exist_ok=True)
binaries={'reference':root/'artifacts/compact-unit-state/torus-reference','compact':root/'artifacts/compact-unit-state/torus-compact-isolated'}
rows=[]
for repeat in range(-1,10):
 for count in (64,1024):
  order=('reference','compact') if (repeat+count)%2 else ('compact','reference')
  for variant in order:
   folder=out/f'units-{count}'/('warmup' if repeat<0 else f'rep-{repeat:02d}')/variant;folder.mkdir(parents=True,exist_ok=True)
   env=os.environ.copy();env.update(SDL_VIDEODRIVER='x11',SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(folder/'profile'),GLOB2_BENCH_FLAT='1',GLOB2_BENCH_SIZE='64x64',GLOB2_BENCH_UNITS=str(count),GLOB2_BENCH_FRAMES='64',GLOB2_BENCH_WARMUP_FRAMES='8',GLOB2_BENCH_MODE='2D no clouds',GLOB2_BENCH_BARS='1',GLOB2_BENCH_CAPTURE=str((folder/'frame.ppm').relative_to(root)))
   cmd=['xvfb-run','-a',str(binaries[variant]),'--renderer','software','--window-size','640x480','--mute','--no-fullscreen'];(folder/'command.json').write_text(json.dumps({'command':cmd,'env':{k:v for k,v in env.items() if k.startswith(('GLOB2_','SDL_'))}},indent=2))
   with (folder/'run.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
   s=(folder/'run.log').read_text();row={'repeat':repeat,'units':count,'variant':variant,'median_ms':float(re.search(r'2D no clouds median=([\d.]+)',s)[1]),'cpu_median_ms':float(re.search(r'2D no clouds process_cpu_median=([\d.]+)',s)[1]),'p95_ms':float(re.search(r'2D no clouds median=[\d.]+ ms p95=([\d.]+)',s)[1]),'image_sha256':hashlib.sha256((folder/'frame.ppm').read_bytes()).hexdigest(),'loadavg':os.getloadavg()};rows.append(row);print(json.dumps(row),flush=True)
 (out/'samples.json').write_text(json.dumps(rows,indent=2))
(out/'binaries.json').write_text(json.dumps({k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in binaries.items()},indent=2))
