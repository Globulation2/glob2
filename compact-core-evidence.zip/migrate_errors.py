import re,json,sys
from pathlib import Path
fields=json.loads(Path('artifacts/compact-unit-state/fields.json').read_text());fields.pop('abilities',None)
edits={}
for row in Path(sys.argv[1]).read_text().splitlines():
 m=re.match(r'((?:src|test)/[^:]+):(\d+):(\d+): error: (.*)',row)
 if not m:continue
 path,line,col,msg=m[1],int(m[2]),int(m[3]),m[4]
 f=re.search(r"has no member named ['‘](\w+)['’]",msg)
 if f and not any(t in msg for t in ['Unit', 'SnapshotUnit']):continue
 if not f:f=re.search(r"['‘](\w+)['’] was not declared in this scope",msg)
 if not f or f[1] not in fields:continue
 name=f[1];edits.setdefault(path,set()).add((line,col,name))
count=0
for path,positions in edits.items():
 p=Path(path); lines=p.read_text().splitlines(keepends=True)
 for line,col,name in sorted(positions,reverse=True):
  s=lines[line-1];visual=0;pos=0
  while pos<len(s) and visual<col-1:
   visual=(visual//8+1)*8 if s[pos]=='\t' else visual+1;pos+=1
  if s[pos:pos+len(name)]!=name:continue
  if s[max(0,pos-7):pos].endswith(('core.','detail.')):continue
  lines[line-1]=s[:pos]+fields[name]+'.'+s[pos:];count+=1
 p.write_text(''.join(lines))
print('Migrated',count,'field accesses in',len(edits),'files')
