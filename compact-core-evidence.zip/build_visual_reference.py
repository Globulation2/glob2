from pathlib import Path
import subprocess,json
p=Path('artifacts/compact-unit-state');src=(p/'reference-source/src/render/torus/TorusRenderBenchmark.cpp').read_text()
fixed=Path('src/render/torus/TorusRenderBenchmark.cpp').read_text();start=fixed.index('        if(gfx->backendSwitchStatus().active==');end=fixed.index('        if(auto *device=',start)
capture=src.index('    static void captureFramebuffer'); prefix=src[:capture];src=prefix+src[capture:].replace('        if(auto *device=',fixed[start:end]+'        if(auto *device=',1)
(p/'visual-reference-fixed.cpp').write_text(src)
compile=json.loads((p/'torus-reference-compile-command.json').read_text());compile[-3]=str(p/'visual-reference-fixed.cpp');compile[-1]=str(p/'visual-reference-fixed.o');subprocess.run(compile,check=True)
link=json.loads((p/'torus-reference-link-command.json').read_text());link[2]=str(p/'torus-reference-visual');link=[str(p/'visual-reference-fixed.o') if a.endswith('/torus-reference.o') else a.replace('build/movement-release/',str(p/'baseline-core-check')+'/') for a in link]
# JavaScript archive belongs to the baseline build's dependency cache, not its output directory.
for i,a in enumerate(link):
 if a.endswith('third_party/libGlob2JavaScript.a') and not Path(a).exists():link[i]='build/movement-release/third_party/libGlob2JavaScript.a'
(p/'visual-reference-link-command.json').write_text(json.dumps(link,indent=2));subprocess.run(link,check=True)
