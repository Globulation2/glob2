from pathlib import Path
import re,sys
positions={}
for line in Path(sys.argv[1]).read_text().splitlines():
 m=re.match(r'((?:src|test)/[^:]+):(\d+):(\d+): error: (.*)',line)
 if not m:continue
 msg=m[4]
 if ('unable to deduce' in msg and 'UnitObservation' in msg) or ('unable to deduce' in msg and 'unit(' in msg):kind='auto'
 elif ('no match for' in msg and ('optional<' in msg or 'UnitObservation' in msg)):kind='null'
 else:continue
 positions.setdefault(m[1],set()).add((int(m[2]),kind))
count=0
for path,rows in positions.items():
 p=Path(path);lines=p.read_text().splitlines(keepends=True)
 for n,kind in rows:
  s=lines[n-1]
  if kind=='auto':s=s.replace('const auto*','auto').replace('const auto *','auto ')
  else:s=re.sub(r'\b(?:NULL|nullptr)\b','std::nullopt',s)
  if s!=lines[n-1]:count+=1
  lines[n-1]=s
 p.write_text(''.join(lines))
print('Updated',count,'optional lookup uses')
