from pathlib import Path
import json,shlex,subprocess,sys
root=Path.cwd();out=root/'artifacts/compact-unit-state';variant=sys.argv[1]
line=next(x for x in Path('artifacts/movement-planning/fix-integrated-dev-build.log').read_text().splitlines() if x.startswith('/usr/bin/ccache g++'))
incs=[a for a in shlex.split(line) if a.startswith('-I')]
if variant=='reference':
 ref=out/'reference-source';incs=['-I'+str(ref),*[('-I'+str(ref/a[2:])) if a[2:].startswith(('src','test')) else a for a in incs]]
flags=['g++','-std=gnu++20','-O3','-g','-DHAVE_CONFIG_H','-DSDL_MAIN_HANDLED','-DGLOB2_OFFICIAL_INSTANCE_ORIGIN="https://app.glob2online.com"',*incs]
if variant!='reference':flags+=['-DGLOB2_COMPACT_CORE']
objects=[]
for name,source in [('main',out/'capture-benchmark.cpp'),('fixtures',(out/'reference-source' if variant=='reference' else root)/'test/support/EngineFixtures.cpp'),('support',(out/'reference-source' if variant=='reference' else root)/'test/support/Glob2Test.cpp')]:
 target=out/f'capture-{variant}-{name}.o';cmd=[*flags,'-c',str(source),'-o',str(target)];(out/f'capture-{variant}-{name}-command.json').write_text(json.dumps(cmd));subprocess.run(cmd,check=True);objects.append(str(target))
link=json.loads(Path('artifacts/movement-planning/fix-retest/symbol-link-command.json').read_text());link[2]=str(out/f'capture-{variant}');link=[a for a in link if not a.endswith('/app/Glob2.o')];link[3:3]=objects
(out/f'capture-{variant}-link-command.json').write_text(json.dumps(link,indent=2));subprocess.run(link,check=True)
