import os,sys
os.environ["SDL_VIDEODRIVER"]="x11"
os.execv(sys.argv[1],sys.argv[1:])
