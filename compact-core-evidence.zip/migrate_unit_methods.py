from pathlib import Path
import re,json
fields=json.loads(Path('artifacts/compact-unit-state/fields.json').read_text());fields.pop('abilities',None)
lex=re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|\b\w+\b|->|::|[^\s]')
count=0
for p in Path('src/unit').glob('*.cpp'):
 s=p.read_text();tokens=[m for m in lex.finditer(s) if not m[0].startswith(('//','/*','"',"'"))];ts=[m[0] for m in tokens];edits=[];i=0
 while i<len(ts)-3:
  if ts[i:i+2]!=['Unit','::'] or ts[i+3]!='(':i+=1;continue
  a=i+4;end=a;depth=1
  while end<len(ts) and depth:
   depth+=int(ts[end]=='(')-int(ts[end]==')');end+=1
  shadows={v for v in ts[a:end-1] if v in fields}
  while end<len(ts) and ts[end] not in ['{',';']:end+=1
  if end==len(ts) or ts[end]==';':i=end+1;continue
  start=end+1;end=start;depth=1
  while end<len(ts) and depth:
   depth+=int(ts[end]=='{')-int(ts[end]=='}');end+=1
  for j in range(start,end-1):
   if ts[j] in fields and ts[j-1] in ['int','bool','auto','Sint32','Uint32','Sint64','Uint64','Uint16','Uint8','float','double']:
    shadows.add(ts[j])
  for j in range(start,end-1):
   name=ts[j]
   if name not in fields:continue
   prev=ts[j-1]
   if prev in ['.','::']:continue
   if prev=='->':
    if j<2 or ts[j-2]!='this':continue
   elif name in shadows:continue
   edits.append((tokens[j].start(),fields[name]+'.'))
  i=end
 for pos,prefix in sorted(edits,reverse=True):s=s[:pos]+prefix+s[pos:];count+=1
 if edits:p.write_text(s)
print('Migrated',count,'remaining live member references')
