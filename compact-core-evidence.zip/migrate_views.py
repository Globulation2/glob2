from pathlib import Path
import re
# Optional borrowed full-unit views replace pointer lookups and stored pointers.
for p in Path('src/ai').rglob('*'):
 if p.suffix not in ('.h','.cpp'):continue
 s=p.read_text()
 s=re.sub(r'const\s+AIEngine::UnitView\s*\*', 'AIEngine::UnitObservation',s)
 s=re.sub(r'const\s+UnitView\s*\*', 'UnitObservation',s)
 s=re.sub(r'(UnitObservation\s+\w+\s*=\s*)(?:NULL|nullptr)',r'\1std::nullopt',s)
 s=s.replace('std::vector<AIEngine::UnitObservation> units(Unit::MAX_COUNT, nullptr)','std::vector<AIEngine::UnitObservation> units(Unit::MAX_COUNT)')
 s=s.replace('std::span<const UnitView> units;','SimulationSnapshot::UnitViews units;')
 s=s.replace('lease.entities->unitCargo','lease.unitDetails->unitCargo')
 s=s.replace('lease.entities->unitSlotIndices','lease.unitCores->unitSlotIndices')
 s=s.replace('units = lease.entities->units;','')
 s=s.replace('units = lease.unitCores->units;','')
 p.write_text(s)
p=Path('src/ai/observation/AIWorldView.h');s=p.read_text().replace('using SimulationSnapshot::UnitView;','using SimulationSnapshot::UnitView;\nusing UnitObservation=std::optional<UnitView>;');a=s.index('\tEntitySlots<UnitView> unitSlots');b=s.index('\tTileView tile(',a);s=s[:a]+'''    struct UnitSlots {
        SimulationSnapshot::UnitViews records;
        std::span<const Uint32> indices;
        std::size_t size() const { return indices.size(); }
        UnitObservation operator[](std::size_t slot) const {
            const auto index=indices[slot];
            return index==SimulationSnapshot::Entities::NoRecord ? std::nullopt : UnitObservation(records[index]);
        }
    };
    UnitSlots unitSlots(int team) const {
        if(!lease.unitCores || !lease.unitDetails || team<0 || std::size_t(team)>=lease.unitCores->unitSlotIndices.size()/UnitUtils::MAX_COUNT)return {};
        return {units,std::span<const Uint32>(lease.unitCores->unitSlotIndices).subspan(std::size_t(team)*UnitUtils::MAX_COUNT,UnitUtils::MAX_COUNT)};
    }
    std::span<const SimulationSnapshot::UnitCoreView> unitCores;
    EntitySlots<SimulationSnapshot::UnitCoreView> coreUnitSlots(int team) const {
        if(!lease.unitCores || team<0 || std::size_t(team)>=lease.unitCores->unitSlotIndices.size()/UnitUtils::MAX_COUNT)return {};
        return {unitCores,std::span<const Uint32>(lease.unitCores->unitSlotIndices).subspan(std::size_t(team)*UnitUtils::MAX_COUNT,UnitUtils::MAX_COUNT)};
    }
    const SimulationSnapshot::UnitCoreView* coreUnit(UnitRef identity) const {
        if(!lease.unitCores || identity.gid>=lease.unitCores->unitSlotIndices.size())return nullptr;
        const auto index=lease.unitCores->unitSlotIndices[identity.gid];
        if(index==SimulationSnapshot::Entities::NoRecord)return nullptr;
        const auto& value=unitCores[index];return value.identity==identity ? &value : nullptr;
    }
'''+s[b:];p.write_text(s)
p=Path('src/ai/observation/AIWorldCapture.cpp');s=p.read_text().replace('\tif (lease.entities) {\n\t\tconst auto buildingSlots', '\tif (lease.entities && lease.unitCores) {\n\t\tconst auto buildingSlots');s=s.replace('\tif (lease.entities) { buildings', '    if(lease.unitCores)unitCores=lease.unitCores->units;\n    units=lease.units();\n\tif (lease.entities) { buildings');p.write_text(s)
p=Path('src/ai/observation/AIQueries.cpp');s=p.read_text();a=s.index('UnitObservation AIWorldView::unitAtSlot');b=s.index('const BuildingView* AIWorldView::building(',a);s=s[:a]+'''UnitObservation AIWorldView::unitAtSlot(Uint16 gid) const
{
    if(!lease.unitCores || !lease.unitDetails || gid>=lease.unitCores->unitSlotIndices.size())return std::nullopt;
    const auto index=lease.unitCores->unitSlotIndices[gid];
    return index==SimulationSnapshot::Entities::NoRecord ? std::nullopt : UnitObservation(units[index]);
}
'''+s[b:];a=s.index('UnitObservation AIWorldView::unit(UnitRef');b=s.index('TileView AIWorldView::tile',a);s=s[:a]+'''UnitObservation AIWorldView::unit(UnitRef identity) const
{
    const auto value=unitAtSlot(identity.gid);
    return value && value->identity==identity ? value : std::nullopt;
}
'''+s[b:];p.write_text(s)
# Templates allow an owning simulation-state probe without mutable observation views.
p=Path('src/ai/observation/ObservationQueries.h');s=p.read_text();s=s.replace('inline int realAttackStrength(', 'template<class Unit> inline int realAttackStrength(').replace('inline bool matchesStrategyUnitRole(','template<class Unit> inline bool matchesStrategyUnitRole(').replace('inline bool matchesConstructionRole(','template<class Unit> inline bool matchesConstructionRole(').replace('const AIEngine::UnitView& unit','const Unit& unit',3);s=s.replace('AIEngine::UnitView probe;','UnitState probe{};').replace('    std::fill(std::begin(probe.performance),std::end(probe.performance),0);\n','');p.write_text(s)
# Selected panels own a borrowed view while retaining the scene snapshot lease.
p=Path('src/render/scene/ScenePanels.h');s=p.read_text().replace('    const SnapshotUnit* record = nullptr;\n    bool valid = false;\n    const SnapshotUnit& state() const { static const SnapshotUnit empty{}; return record ? *record : empty; }', '''    std::optional<SimulationSnapshot::UnitView> record;
    bool valid = false;
    const SimulationSnapshot::UnitView& state() const {
        static const SimulationSnapshot::UnitCoreView core{};
        static const UnitDetailState detail{};
        static const SimulationSnapshot::UnitView empty(core,detail);
        return record ? *record : empty;
    }''');p.write_text(s)
p=Path('src/render/scene/SceneExtract.cpp');s=p.read_text().replace('->const SimulationSnapshot::UnitView*','->const SimulationSnapshot::UnitCoreView*').replace('up.record=selectedUnit;', 'up.record=world.units().at(world.unitCores->unitSlotIndices.at(selectedUnit->core.gid));');s=s.replace('const auto& u = world.unitCores->units.at(index);','const auto u = world.units().at(index);');s=s.replace('|bit(Component::Entities)|bit(Component::Teams)', '|bit(Component::BuildingEntities)|bit(Component::UnitCores)|bit(Component::Teams)').replace('required|=bit(Component::Statistics);','required|=bit(Component::Statistics)|bit(Component::UnitDetails);');s=s.replace('    if (request.includeHistory)', '    if (request.view.overlay==OverlayArea::Starving) required|=bit(Component::UnitDetails);\n    if (request.includeHistory)');p.write_text(s)
p=Path('src/render/overlay/OverlayAreas.cpp');s=p.read_text().replace('const auto& units=world.unitCores->units;','const auto units=world.units();');p.write_text(s)
# Borrowed values must remain rebindable when stored in optional containers.
p=Path('src/engine/sim/snapshot/WorldRecords.h');s=p.read_text().replace('#include <type_traits>','#include <type_traits>\n#include <new>');s=s.replace('    const Sint32& performance(int ability) const {\n        if (ability<0', '''    UnitView(const UnitView&)=default;
    UnitView& operator=(const UnitView& other) {
        if(this!=&other) { this->~UnitView(); new(this) UnitView(other); }
        return *this;
    }
    bool operator==(const UnitView& other) const { return &core==&other.core && &detail==&other.detail; }
    const Sint32& performance(int ability) const {
        if (ability<0''');p.write_text(s)
