from pathlib import Path
import subprocess,json,os,hashlib
root=Path.cwd();out=root/'artifacts/compact-unit-state/engine-pairs';out.mkdir(exist_ok=True)
binaries={'reference':root/'artifacts/compact-unit-state/glob2-reference','compact':root/'artifacts/compact-unit-state/glob2-compact-isolated'}
rows=[]
for repeat in range(-1,10):
 for fixture in ('large-colony','ordinary-control'):
  path=root/f'artifacts/movement-planning/fixtures/{fixture}.game'
  if not path.exists():continue
  for mode in ('reference','shadow'):
   order=('reference','compact') if (repeat+(fixture=='large-colony')+(mode=='shadow'))%2 else ('compact','reference')
   for variant in order:
    folder=out/f'{fixture}-{mode}'/('warmup' if repeat<0 else f'rep-{repeat:02d}')/variant;folder.mkdir(parents=True,exist_ok=True)
    cmd=[str(binaries[variant]),'game','run','--load-game',str(path),'--ticks','128','--gradient-backend','cpu','--compute-threads','4','--output-dir',str(folder)]
    if mode=='shadow':cmd+=['--movement-shadow','1']
    env=os.environ.copy();env['GLOB2_USER_DATA_DIR']=str(folder/'profile')
    (folder/'command.json').write_text(json.dumps(cmd))
    with (folder/'run.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    d=json.loads((folder/'result.json').read_text());record={'repeat':repeat,'fixture':fixture,'mode':mode,'variant':variant,'run_ns':d['run_ns'],'checksum':d['finalChecksum'],'loadavg':os.getloadavg(),'pipeline':d.get('ai_pipeline'),'movement':d.get('movement_shadow')};rows.append(record);print(json.dumps({k:v for k,v in record.items() if k not in ('pipeline','movement')}),flush=True)
 (out/'samples.json').write_text(json.dumps(rows,indent=2))
(out/'binaries.json').write_text(json.dumps({k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in binaries.items()},indent=2))
