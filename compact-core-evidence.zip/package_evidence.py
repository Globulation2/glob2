from pathlib import Path
import zipfile,json,hashlib
p=Path('artifacts/compact-unit-state');files=set()
for pattern in ('*.log','*.xml','*.json','*.py','*.cpp','*.png','*.svg','*.pdf','callgrind-*.out','callgrind-*-annotated.txt','report.md'):
 files.update(p.glob(pattern))
# Remove superseded logo and local-only mechanical edit scripts.
files={x for x in files if x.name not in ('render-inspection.png','split_snapshots.py','syntax_pass.py')}
for folder in ('capture-pairs','engine-pairs','render-pairs','correctness','integration-correctness','final-correctness','corrected-visuals'):
 for x in (p/folder).rglob('*'):
  if x.is_file() and 'profile' not in x.parts and x.suffix in ('.json','.log','.gz','.replay','.checksums','.ppm','.png'):files.add(x)
# Retain representative actual renderer suite images, not all temporary test state.
images=sorted((p/'render-test-artifacts-x11').rglob('*.png'))+sorted((p/'render-test-artifacts-x11').rglob('*.bmp'))
files.update(images[:30])
manifest=[];stored={}
with zipfile.ZipFile(p/'compact-core-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for x in sorted(files):
  path=str(x.relative_to(p));digest=hashlib.sha256(x.read_bytes()).hexdigest();member=stored.get(digest,path)
  if digest not in stored:z.write(x,path);stored[digest]=path
  manifest.append({'path':path,'archive_member':member,'bytes':x.stat().st_size,'sha256':digest})
 for x in Path('artifacts/movement-planning/fixtures').glob('*.game'):
  z.write(x,'fixtures/'+x.name)
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
print(len(files),(p/'compact-core-evidence.zip').stat().st_size)
