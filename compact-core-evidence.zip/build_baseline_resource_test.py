from pathlib import Path
import shlex,json,subprocess
out=Path('artifacts/compact-unit-state');ref=Path.cwd()/out/'reference-source'
line=next(s for s in Path('artifacts/movement-planning/fix-integrated-dev-build.log').read_text().splitlines() if s.startswith('/usr/bin/ccache g++'))
incs=[a for a in shlex.split(line) if a.startswith('-I')];incs=['-I'+str(ref),*[('-I'+str(ref/a[2:])) if a[2:].startswith(('src','test')) else a for a in incs]]
flags=['g++','-std=gnu++20','-O0','-g1','-DHAVE_CONFIG_H','-DSDL_MAIN_HANDLED',*incs]
replacements={}
for src,old in [('src/resource/ResourceRegistry.cpp','build/movement-dev/src/resource/ResourceRegistry.o'),('src/resource/ResourceRegistryTest.cpp','build/movement-dev/test/unit-src_resource_ResourceRegistryTest.o')]:
 target=out/('baseline-'+Path(src).stem+'.o');cmd=[*flags,'-c',str(ref/src),'-o',str(target)];subprocess.run(cmd,check=True);replacements[old]=str(target)
link=json.loads((out/'unit-link-command.json').read_text());link[2]=str(out/'baseline-resource-unit-tests');link=[replacements.get(a,a) for a in link];(out/'baseline-resource-link-command.json').write_text(json.dumps(link));subprocess.run(link,check=True)
