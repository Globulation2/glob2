from pathlib import Path
import json,numpy as np,matplotlib.pyplot as plt
p=Path('artifacts/compact-unit-state');m=json.loads((p/'paired-summary.json').read_text());fig,axes=plt.subplots(1,2,figsize=(12,4),layout='constrained')
for ax,family in zip(axes,['engine','render']):
 data=m[family];x=np.arange(len(data));y=np.array([r['reduction_percent'] for r in data.values()]);lo=np.array([r['reduction_ci95'][0] for r in data.values()]);hi=np.array([r['reduction_ci95'][1] for r in data.values()]);ax.errorbar(x,y,yerr=np.stack([y-lo,hi-y]),fmt='o',capsize=5,color='#167b83');ax.axhline(0,color='grey');ax.set_xticks(x,[str(k).replace('/','\n') for k in data]);ax.set_ylabel('Time reduction (%)');ax.set_title(f'{family.capitalize()}: ten pairs, bootstrap 95% interval');ax.grid(axis='y',alpha=.2)
fig.suptitle('Capture savings do not yet establish broad runtime benefit')
for ext in ['png','svg','pdf']:fig.savefig(p/('compact-runtime-intervals.'+ext),dpi=180)
