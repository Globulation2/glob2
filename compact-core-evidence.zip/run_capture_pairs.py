from pathlib import Path
import subprocess,os,json,hashlib,time
root=Path.cwd();out=root/'artifacts/compact-unit-state/capture-pairs';out.mkdir(exist_ok=True)
binaries={name:root/f'artifacts/compact-unit-state/capture-{name}' for name in ('reference','compact')}
scenarios=['movement','guard','market','render','render-panels','render-movement','render-ai','render-all']
rows=[]
for repeat in range(-1,10):
 for count in (64,1024):
  for scenario in scenarios:
   order=('reference','compact') if (repeat+count+scenarios.index(scenario))%2==0 else ('compact','reference')
   for variant in order:
    folder=out/f'{scenario}-{count}'/('warmup' if repeat<0 else f'rep-{repeat:02d}')/variant;folder.mkdir(parents=True,exist_ok=True)
    cmd=[str(binaries[variant]),scenario,str(count),'128'];env=os.environ.copy();env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(folder/'profile'))
    (folder/'command.json').write_text(json.dumps(cmd));start=time.monotonic()
    with (folder/'run.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    line=next(s for s in (folder/'run.log').read_text().splitlines() if s.startswith('CAPTURE_BENCH '));record=json.loads(line.split(' ',1)[1]);record.update(repeat=repeat,variant=variant,process_elapsed_s=time.monotonic()-start,loadavg=os.getloadavg())
    rows.append(record);print(json.dumps(record),flush=True)
 (out/'samples.json').write_text(json.dumps(rows,indent=2))
(out/'binaries.json').write_text(json.dumps({k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in binaries.items()},indent=2))
