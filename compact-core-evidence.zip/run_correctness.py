from pathlib import Path
import subprocess,json,hashlib,os
root=Path.cwd();out=root/'artifacts/compact-unit-state/correctness';out.mkdir(exist_ok=True)
variants={'before-reference':('artifacts/compact-unit-state/glob2-reference',0),'compact-reference':('build/movement-release/src/glob2',0),**{f'compact-k{k}':('build/movement-release/src/glob2',k) for k in (1,2,4,8)}}
comparisons={}
for fixture in ('large-colony','ordinary-control','contention','team-imbalance'):
 for name,(binary,k) in variants.items():
  folder=out/fixture/name;folder.mkdir(parents=True,exist_ok=True)
  cmd=[str(root/binary),'game','run','--load-game',str(root/f'artifacts/movement-planning/fixtures/{fixture}.game'),'--ticks','64','--gradient-backend','cpu','--compute-threads','4','--output-dir',str(folder),'--write-replay','--telemetry','checksums','--save','final']
  cmd+=['--movement-profile'] if k==0 else ['--movement-shadow',str(k)]
  (folder/'command.json').write_text(json.dumps(cmd));env=os.environ.copy();env['GLOB2_USER_DATA_DIR']=str(folder/'profile')
  with (folder/'run.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  print(fixture,name,flush=True)
 comparisons[fixture]={}
 for path in ('game.replay','game.replay.checksums','world.checksums','final.game.gz'):
  hashes={name:hashlib.sha256((out/fixture/name/path).read_bytes()).hexdigest() for name in variants}
  comparisons[fixture][path]={'equal':len(set(hashes.values()))==1,'sha256':hashes}
 (out/'comparison.json').write_text(json.dumps(comparisons,indent=2))
assert all(result['equal'] for fixture in comparisons.values() for result in fixture.values())
