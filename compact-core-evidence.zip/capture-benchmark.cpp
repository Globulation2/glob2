#define DOCTEST_CONFIG_IMPLEMENT
#include "EngineFixtures.h"
#include "sim/snapshot/SnapshotStore.h"
#include "gradient/SnapshotGradient.h"
#include "render/scene/SceneExtract.h"
#include "unit/planning/MovementShadow.h"
#include <chrono>
#include <iostream>
#include <nlohmann/json.hpp>
GlobalContainer* globalContainer=nullptr;
int benchArgc;char** benchArgv;
int runCapture() {
    const int argc=benchArgc;char** argv=benchArgv;
    const std::string scenario=argc>1 ? argv[1] : "guard";
    const int count=argc>2 ? std::stoi(argv[2]) : 1024;
    const int ticks=argc>3 ? std::stoi(argv[3]) : 128;
    glob2test::HeadlessGlobals globals;
    glob2test::HeadlessGame fixture({.wDec=6,.hDec=6,.teams=1,.discovered=true,.clearImmobile=true,.loadDefaultRace=true,.header=true,.seed=713});
    for(int i=0;i<count;++i)fixture.addUnit(i%3,16+i%32,16+i/32);
    fixture.addBuilding("market",4,4);
    using namespace SimulationSnapshot;
    const auto guard=gradient_preparation::Request{.kind=gradient_preparation::Kind::Guard,.crowding=true}.requirements();
    const auto market=gradient_preparation::Request{.kind=gradient_preparation::Kind::Markets}.requirements();
    SceneRequest request;request.localTeam=0;request.includePanels=scenario=="render-panels";
    request.view.displayW=640;request.view.displayH=480;
    request.selectedUnit=Game::refOf(fixture.game.teams[0]->myUnits[0]);
    auto requirements=guard;
    const bool render=scenario.starts_with("render");
    if(scenario=="market") requirements=market;
    if(scenario=="movement")requirements=MovementPlanning::Shadow::requirements;
    if(render)requirements=SceneExtractor::requirements(request);
    if(scenario=="render-movement")requirements|=MovementPlanning::Shadow::requirements;
    if(scenario=="render-ai" || scenario=="render-all")requirements|=Simulation;
    if(scenario=="render-all")requirements|=guard|market;
    Store store;SceneExtractor extractor;
    // Warm the pools independently of the measured advancing captures.
    for(int i=0;i<4;++i){++fixture.game.stepCounter;store.captureBoundary(fixture.game,requirements);}
    store.metrics={};
    const auto start=std::chrono::steady_clock::now();
    Uint64 sceneNs=0;
    for(int i=0;i<ticks;++i) {
        ++fixture.game.stepCounter;
        auto world=store.captureBoundary(fixture.game,requirements);
        if(render) {
            const auto sceneStart=std::chrono::steady_clock::now();
            PresentationFrame frame;extractor.prepare(world,request,frame);
            sceneNs+=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-sceneStart).count();
        }
    }
    const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();
    const auto memory=store.memoryMetrics();
    nlohmann::json output={{"scenario",scenario},{"units",count},{"ticks",ticks},{"elapsed_ns",elapsed},{"capture_ns",store.metrics.captureNs},{"preparation_ns",store.metrics.preparationNs},{"scene_ns",sceneNs},{"bytes_copied",store.metrics.bytesCopied},{"allocations",store.metrics.allocations},{"retained_bytes",memory.retainedBytes},{"capacity_bytes",memory.capacityBytes},{"checksum",fixture.game.checkSum()}};
#ifdef GLOB2_COMPACT_CORE
    output["core_record_bytes"]=sizeof(UnitCoreView);output["detail_record_bytes"]=sizeof(UnitDetailState);
    output["unit_state_bytes_copied"]=store.metrics.unitStateBytesCopied;output["unit_record_payload_bytes"]=store.metrics.unitRecordPayloadBytes;
#else
    output["full_record_bytes"]=sizeof(UnitView);
#endif
    std::cout<<"CAPTURE_BENCH "<<output.dump()<<"\n";
    return 0;
}
TEST_CASE("capture benchmark") { CHECK(runCapture()==0); }
int main(int argc,char** argv) { benchArgc=argc;benchArgv=argv;doctest::Context context;return context.run(); }
