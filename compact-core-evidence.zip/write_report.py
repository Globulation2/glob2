import json,platform,subprocess
from pathlib import Path
p=Path('artifacts/compact-unit-state');m=json.loads((p/'paired-summary.json').read_text());rows=json.loads((p/'capture-pairs/samples.json').read_text())
s='''# Compact unit cores: review evidence

The refactor uses a 132-byte authoritative core and a 160-byte snapshot core (including relationship metadata), within the 192-byte budget on Linux x86-64 GCC 15.2. Full observation payload is 376 bytes (160 core + 216 details), versus the previous 384-byte record. Full observations borrow both arrays by value; there is no second materialized full-unit array. Save/checksum ordering remains explicit and unchanged.

Guard crowding requests cores only. Market gradients request buildings only: zero unit-state bytes are copied for a standalone market request. Rendering, movement and applicable AI scans share cores; details remain optional. The combined-request tests assert component reuse across requirement upgrades and compare scalar reference seeds and propagated values through supplier stock changes, depletion, inside status, dead units and foreign units. Snapshot lifetime, invalidation, generation and retained-lease tests cover the new arrays and shared index.

## Isolated release measurements

Before: `3a3917757752fe64a2af9c1dc964c074794ebf3e`. After: `5a40f7a9f281cd1aa71c6980573cee3f6f35a36f`. Linux x86-64, GCC 15.2, ordinary SCons release=1 (-O3); pinned existing SDL/dependency prefixes. No runtime dependency added. One warmup, ten paired repetitions with rotating order. Independent timing, correctness and Callgrind runs. Paired log-ratio bootstrap (20,000 resamples, seed 713) supplies 95% intervals. These are capture costs in small diagnostic fixtures, not qualified movement trial results.

Later master CPU-gradient and CPU-render changes are excluded from this comparison. Ordered admission and incremental/effective-goal route optimization candidates remain separate; they were not combined with this refactor's timings.

| 1,024 units / 128 advancing captures | Before logical copy/payload MiB | After MiB | Capture time reduction (95% CI) |
|---|---:|---:|---:|
'''
for scenario in ('movement','guard','market','render','render-panels','render-movement','render-ai','render-all'):
 values={v:next(x for x in rows if x['units']==1024 and x['repeat']==0 and x['variant']==v and x['scenario']==scenario) for v in ('reference','compact')}
 r=m['capture_only']['1024/'+scenario];lo,hi=r['reduction_ci95'];s+=f"| {scenario} | {values['reference']['bytes_copied']/2**20:.3f} | {values['compact']['bytes_copied']/2**20:.3f} | {r['reduction_percent']:.2f}% ({lo:.2f}–{hi:.2f}%) |\n"
s+='''
The `bytes_copied` counter includes populated record payload and indexes; it is not a claim about exact memcpy traffic. New `unit_state_bytes_copied` counts actual state memcpy bytes, `unit_record_payload_bytes` counts populated core/detail payload, and capacity/retained counters report retained buffers. For guard-only, these are 17,301,504 state bytes and 20,971,520 record payload bytes across 128 captures. For market-only both unit counters are zero. Rendering plus full AI requirements copies 45,613,056 state bytes and populates 49,283,072 record bytes; adding guard and market does not increase those totals. The render-AI case requests full AI observations but does not step an AI controller. Allocations are reported in raw samples: full shared captures increased tracked allocations (62 to 88); smaller copying does not imply fewer allocations.

Optimized Callgrind scoped to `Store::captureBoundary` reports 35,246,712 -> 19,461,876 instructions (44.78% fewer) for guard-only. Startup outside capture is excluded; warm captures are included. This establishes causal instruction savings, not runtime benefit for the whole engine.

## Engine and drawing outcomes

'''
for family in ('engine','render'):
 for name,r in m[family].items():
  lo,hi=r['reduction_ci95'];s+=f"- {family} {name}: {r['reduction_percent']:.2f}% reduction; 95% interval {lo:.2f}–{hi:.2f}%.\n"
s+='''
The preliminary large-colony shadow K=1 run has a small positive engine interval. Reference engine controls and drawing intervals include no change, so their runtime benefit/regression is inconclusive. Capture cost reduction is supported; broad runtime improvement is not established. Synthetic 64/1,024-unit capture fixtures supplement the existing ordinary and preliminary colony engine controls. They do not qualify a sustainable 1,000-active-worker gameplay corpus.

The original software Torus captures accidentally read the stale OpenGL startup logo. Those images are not visual parity evidence. A benchmark-only correction reads the completed software frame; corrected before/after images and their comparison are recorded separately. Existing actual GUI/scene/render suites are also retained. Performance runs remain valid timing observations; their image hashes must not be treated as gameplay screenshots.

## Correctness and known failures

Four engine fixtures, 64 ticks, four compute participants, reference and shadow delays 1/2/4/8: final saves, replay bytes, replay checksum files and per-tick checksum files match the original release baseline exactly (`correctness/comparison.json`). Focused movement tests additionally exercise the delay/participant matrix and save/lease/supersession boundaries. All ability indices are checked against full captures and save/load. Representation-only version constants and compatibility floor remain unchanged.

Development engine focused inventory: 262 pass / 1 failure / 1 skip initially. The Nicowar cold combat-role lookup error was fixed and a regression test added; correction runs passed including the long native-controller case. Final integration focused inventory before the latest renderer base update: 144 pass / 1 baseline LAN failure / 2 skip.

Broad unit inventory: 1,061 pass / 2 failures / 88 skips. Maxima's fixed CPU-time guard fails in the development build but passes in release. ResourceRegistry's maximum-size JSON fixture fails identically against original baseline source. Broad compatibility inventory: 876 pass / 6 failures / 68 skips. Three process timeouts pass when rerun with 600-second process deadlines and unchanged assertions. Two old golden failures and the LAN wake-time failure reproduce identically in a separately built pre-refactor checkout. Golden fixtures were not rewritten to hide failures.

Under Xvfb/Openbox with SDL X11 forced: 25 actual display cases pass. The touch/window-resize case fails its resize-settle assertion both before and after. Initial Wayland display failures are environment failures, not a passing visual test. Baseline reproductions, JUnit XML and logs are included. The 24 CI-policy tests and documentation checks pass; native compatibility registration and shared-header boundaries are updated.

This is Linux-only local evidence. macOS arm64, Windows x64, browser serial/threaded execution, complete screenshot scenario coverage, allocator-inclusive memory ceiling, 30-seed gameplay distributions and footage review remain unavailable/unqualified. No cross-platform equivalence claim is made.

## Recommendation

Retain this refactor in the draft: core size, canonical Linux comparisons and reduced copying/capture cost support it. Whole-engine/render runtime benefit is separate and mostly inconclusive. Investigate any statistically supported regressions before recommending integration. Movement stays Stage A, diagnostic only; earlier gates remain failed/inconclusive, and no delay is qualified for live adoption. No thresholds were changed.

The archive includes commands, helper sources, paired raw samples, binary/fixture hashes, Callgrind profiles/annotations, JUnit reports, baseline failure reproductions, saves, replays and checksums. Build outputs, executables, virtual environments and personal preference directories are excluded. Commands contain original local dependency paths as provenance, not as dependencies required by reviewers.
'''
(p/'report.md').write_text(s)
