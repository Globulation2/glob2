from pathlib import Path
import os,sys
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'test'))
import run_tests
# The host's default SDL probe chooses a display-less Wayland driver. Keep the
# test inventory and assertions unchanged, selecting X11 inside owned Xvfb.
original=run_tests.xvfb_prefix
wrapper=Path(__file__).resolve().parent/'force_x11.py'
wrapper.write_text('import os,sys\nos.environ["SDL_VIDEODRIVER"]="x11"\nos.execv(sys.argv[1],sys.argv[1:])\n')
def prefix(job):
 base=original(job)
 return base+[sys.executable,str(wrapper)] if job.display else base
run_tests.xvfb_prefix=prefix
raise SystemExit(run_tests.main())
