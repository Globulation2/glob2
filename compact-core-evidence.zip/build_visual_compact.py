from pathlib import Path
import subprocess,json
p=Path('artifacts/compact-unit-state')
c=json.loads((p/'torus-reference-compile-command.json').read_text());c=[a.replace(str(p.resolve()/'reference-source')+'/', '').replace('-I'+str(p.resolve()/'reference-source'),'-I.') for a in c];c[-3]='src/render/torus/TorusRenderBenchmark.cpp';c[-1]=str(p/'visual-compact-fixed.o');subprocess.run(c,check=True)
l=json.loads((p/'torus-reference-link-command.json').read_text());l[2]=str(p/'torus-compact-visual');l=[str(p/'visual-compact-fixed.o') if a.endswith('/torus-reference.o') else a.replace('build/movement-release/','build/movement-dev/') for a in l]
for i,a in enumerate(l):
 if a.endswith('third_party/libGlob2JavaScript.a') and not Path(a).exists():l[i]='build/movement-release/third_party/libGlob2JavaScript.a'
(p/'visual-compact-link-command.json').write_text(json.dumps(l,indent=2));subprocess.run(l,check=True)
