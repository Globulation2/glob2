from pathlib import Path
import re,sys
positions={}
for line in Path(sys.argv[1]).read_text().splitlines():
 m=re.match(r"((?:src|test)/[^:]+):(\d+):(\d+): error: invalid types .*overloaded function type",line)
 if m:positions.setdefault(m[1],set()).add((int(m[2]),int(m[3])))
for path,rows in positions.items():
 p=Path(path);lines=p.read_text().splitlines(keepends=True)
 for n,col in sorted(rows,reverse=True):
  s=lines[n-1];pos=0;visual=0
  while pos<len(s) and visual<col-1:
   visual=(visual//8+1)*8 if s[pos]=='\t' else visual+1;pos+=1
  candidates=[]
  for m in re.finditer(r"\bperformance\[",s):
   end=m.end();depth=1
   while depth and end<len(s):
    depth+=int(s[end]=='[')-int(s[end]==']');end+=1
   candidates.append((min(abs(pos-m.start()),abs(pos-end)),m,end))
  if not candidates:continue
  _,m,end=min(candidates,key=lambda x:x[0]);lines[n-1]=s[:m.end()-1]+'('+s[m.end():end-1]+')'+s[end:]
 p.write_text(''.join(lines))
