#include "sim/snapshot/WorldRecords.h"
#include <cstdio>
int main(){ std::printf("core=%zu view=%zu detail=%zu state=%zu\n",sizeof(UnitCoreState),sizeof(SimulationSnapshot::UnitCoreView),sizeof(UnitDetailState),sizeof(UnitState)); }
