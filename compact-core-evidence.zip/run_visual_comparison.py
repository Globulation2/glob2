from pathlib import Path
import subprocess,os,json,hashlib
p=Path('artifacts/compact-unit-state');rows=[]
for count in (64,1024):
 for variant,binary in [('reference',p/'torus-reference-visual'),('compact',Path('build/movement-release/test/torus-render-benchmark'))]:
  if not binary.exists():binary=Path('build/movement-release/src/torus-render-benchmark')
  folder=p/'corrected-visuals'/str(count)/variant;folder.mkdir(parents=True,exist_ok=True)
  env=os.environ.copy();env.update(SDL_VIDEODRIVER='x11',SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str((folder/'profile').resolve()),GLOB2_BENCH_FLAT='1',GLOB2_BENCH_SIZE='64x64',GLOB2_BENCH_UNITS=str(count),GLOB2_BENCH_FRAMES='8',GLOB2_BENCH_WARMUP_FRAMES='2',GLOB2_BENCH_MODE='2D no clouds',GLOB2_BENCH_BARS='1',GLOB2_BENCH_CAPTURE=str(folder/'frame.ppm'))
  cmd=['xvfb-run','-a',str(binary.resolve()),'--renderer','software','--window-size','640x480','--mute','--no-fullscreen'];(folder/'command.json').write_text(json.dumps({'command':cmd,'env':{k:v for k,v in env.items() if k.startswith(('GLOB2_','SDL_'))}},indent=2))
  with (folder/'run.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
  rows.append({'units':count,'variant':variant,'sha256':hashlib.sha256((folder/'frame.ppm').read_bytes()).hexdigest()});print(rows[-1],flush=True)
(p/'corrected-visuals/comparison.json').write_text(json.dumps(rows,indent=2))
assert all(rows[i]['sha256']==rows[i+1]['sha256'] for i in (0,2))
assert rows[0]['sha256']!=rows[2]['sha256']
