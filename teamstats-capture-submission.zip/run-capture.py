import subprocess,os,pathlib,random
p=pathlib.Path(__file__).parent
variants=['capture-probe','no-accounting','no-index-clear','no-attack-query','no-unit-state-copy','no-event-capture']
env=dict(os.environ,CAPTURE_PROBE='1',CAPTURE_PROBE_N='100000',GLOB2_PERF_DISABLE='1',SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_STATS_PROFILE='0',GLOB2_SNAPSHOT_PROFILE='0')
for trial in range(1,4):
 order=variants.copy();random.Random(trial).shuffle(order)
 for variant in order:
  with (p/f'{variant}-{trial}.log').open('w') as f:r=subprocess.run([str(p/variant),'--test-case=capture component microprobe'],env=env,stdout=f,stderr=subprocess.STDOUT)
  print(trial,variant,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
