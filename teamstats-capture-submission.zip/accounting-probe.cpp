#include "EngineFixtures.h"
#include "src/engine/sim/snapshot/SnapshotStore.h"
#include "SnapshotStoreNoAccounting.h"
#include <chrono>
#include <iostream>
using namespace SimulationSnapshot;
TEST_CASE("interleaved accounting probe") {
 glob2test::HeadlessGlobals globals;glob2test::HeadlessGame w(glob2test::GameOptions{.wDec=8,.hDec=8,.teams=2,.loadDefaultRace=true,.seed=1234567});
 for(int t=0;t<2;++t){w.game.teams[t]->stats.enableCollection();for(int i=0;i<128;++i)w.addUnit(i%3,16+t*128+i%64,16+3*(i/64),t);w.addBuilding("inn",4+t*128,100,0,t);}
 const auto required=bit(Component::Catalogs)|bit(Component::Rules)|bit(Component::Teams)|bit(Component::Entities)|bit(Component::StatisticsInputs);
 Store original;StoreNoAccounting removed;std::array<Handle,8> leases[2];unsigned tick=0;
 auto run=[&](auto& store,unsigned mode,unsigned trial){for(unsigned i=0;i<16;++i){w.game.stepCounter=++tick;leases[mode][i%8]=store.captureBoundary(w.game,required);}auto start=std::chrono::steady_clock::now();for(unsigned i=0;i<10000;++i){w.game.stepCounter=++tick;leases[mode][i%8]=store.captureBoundary(w.game,required);}std::cout<<"ACCOUNTING trial="<<trial<<" mode="<<mode<<" ns="<<double(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count())/10000<<"\n";};
 for(unsigned trial=0;trial<25;++trial)if(trial%2){run(removed,1,trial);run(original,0,trial);}else{run(original,0,trial);run(removed,1,trial);}
}
