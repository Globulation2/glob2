#include "EngineFixtures.h"
#include "src/engine/sim/snapshot/SnapshotStore.h"
#include <chrono>
#include <iostream>
#include <array>
using namespace SimulationSnapshot;
TEST_CASE("capture component microprobe" * doctest::skip(std::getenv("CAPTURE_PROBE")==nullptr)) {
 glob2test::HeadlessGlobals globals;
 const unsigned n=std::getenv("CAPTURE_PROBE_N")?std::atoi(std::getenv("CAPTURE_PROBE_N")):200000;
 const auto base=bit(Component::Catalogs)|bit(Component::Rules);
 const auto entity=bit(Component::Entities), teams=bit(Component::Teams), inputs=bit(Component::StatisticsInputs);
 for(int nt:{2,4}) for(int population:{0,128}) {
  glob2test::HeadlessGame w(glob2test::GameOptions{.wDec=8,.hDec=8,.teams=nt,.loadDefaultRace=true,.seed=1234567});
  for(int t=0;t<nt;++t){w.team=w.game.teams[t];w.team->stats.enableCollection();for(int i=0;i<population;++i)w.addUnit(i%3,16+(t%2)*128+i%64,16+(t/2)*128+3*(i/64),t);w.addBuilding("inn",4+(t%2)*128,100+(t/2)*128,0,t);}
  for(auto mask:{base,base|teams,base|entity,base|entity|teams,base|entity|teams|inputs,Simulation,Simulation|inputs}) {
   Store store; std::array<Handle,8> leases; unsigned counter=0;
   for(unsigned i=0;i<128;++i){w.game.stepCounter=++counter;leases[i%8]=store.captureBoundary(w.game,mask);}
   const auto allocations=store.metrics.allocations;
   auto start=std::chrono::steady_clock::now();
   for(unsigned i=0;i<n;++i){w.game.stepCounter=++counter;leases[i%8]=store.captureBoundary(w.game,mask);}
   auto ns=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();
   std::cout<<"CAPTURE teams="<<nt<<" units="<<nt*population<<" mask="<<mask<<" n="<<n<<" ns="<<double(ns)/n<<" allocations="<<store.metrics.allocations-allocations<<"\n";
  }
 }
}
