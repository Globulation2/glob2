import pathlib,json,subprocess
p=pathlib.Path(__file__).parent;s=pathlib.Path('src/engine/sim/snapshot/WorldCapture.cpp').read_text()
helper='''
#include <iostream>
struct CapturePhaseRows {
 struct Row { unsigned long long calls=0,total=0,part[7]{}; } rows[2][2][9][5]{};
 ~CapturePhaseRows(){for(int ai=0;ai<2;++ai)for(int team=0;team<2;++team)for(int delay=0;delay<9;++delay)for(int workers=0;workers<5;++workers){auto& r=rows[ai][team][delay][workers];if(r.calls){std::cout<<"CAPTURE_PHASE ai="<<ai<<" teams="<<(team?4:2)<<" delay="<<delay<<" workers="<<workers<<" calls="<<r.calls<<" total="<<r.total;for(int i=0;i<7;++i)std::cout<<" p"<<i<<"="<<r.part[i];std::cout<<"\\n";}}}
};
static CapturePhaseRows phaseRows;
'''
s=s.replace('namespace SimulationSnapshot\n{',helper+'\nnamespace SimulationSnapshot\n{',1)
a=s.index('Handle capture(');i=s.index('\n{',a)+2
s=s[:i]+'''
 const auto probeStart=std::chrono::steady_clock::now();
 const bool probeAi=game.players[0] && game.players[0]->ai;
 const unsigned probeWorkers=game.map.computeExecutor().threadCount()-1;
 auto& probeRow=phaseRows.rows[probeAi][game.teamsCount()==4][game.gameHeader.getTeamStatsDelay()][probeWorkers];
 const auto probeNow=[](){return std::chrono::steady_clock::now();};
 const auto probeElapsed=[&](auto mark){return std::chrono::duration_cast<std::chrono::nanoseconds>(probeNow()-mark).count();};
'''+s[i:]
s=s.replace('\tresult->tick = game.stepCounter;', '\tconst auto probeMap=probeNow();\n\tresult->tick = game.stepCounter;',1)
s=s.replace('\tstd::size_t buildingRecordCount = 0, unitRecordCount = 0;', '\tprobeRow.part[0]+=probeElapsed(probeMap);\n\tstd::size_t buildingRecordCount = 0, unitRecordCount = 0;',1)
s=s.replace('\t\tif (needs(requirements, Component::Teams)) {\n\t\tauto& target', '\t\tconst auto probeTeam=probeNow();\n\t\tif (needs(requirements, Component::Teams)) {\n\t\tauto& target',1)
s=s.replace('\t\tif (!needs(requirements, Component::Entities)) continue;', '\t\tprobeRow.part[1]+=probeElapsed(probeTeam);\n\t\tif (!needs(requirements, Component::Entities)) continue;\n\t\tconst auto probeIndex=probeNow();',1)
s=s.replace('\t\tfor (std::size_t n = 0; n < team->liveBuildings.size(); ++n)', '\t\tprobeRow.part[2]+=probeElapsed(probeIndex);\n\t\tconst auto probeBuildings=probeNow();\n\t\tfor (std::size_t n = 0; n < team->liveBuildings.size(); ++n)',1)
s=s.replace('\t\tfor (std::size_t n = 0; n < team->liveUnits.size(); ++n)', '\t\tprobeRow.part[3]+=probeElapsed(probeBuildings);\n\t\tconst auto probeUnits=probeNow();\n\t\tfor (std::size_t n = 0; n < team->liveUnits.size(); ++n)',1)
s=s.replace('\t}\n\tentities->buildings.resize(buildingRecordCount);','\t\tprobeRow.part[4]+=probeElapsed(probeUnits);\n\t}\n\tentities->buildings.resize(buildingRecordCount);',1)
s=s.replace('\tif (needs(requirements, Component::Growth)) {','\tconst auto probeFields=probeNow();\n\tif (needs(requirements, Component::Growth)) {',1)
s=s.replace('\tif (auto input = acquire(&Storage::statisticsInputs, Component::StatisticsInputs)) {','\tprobeRow.part[5]+=probeElapsed(probeFields);\n\tconst auto probeInputs=probeNow();\n\tif (auto input = acquire(&Storage::statisticsInputs, Component::StatisticsInputs)) {',1)
s=s.replace('    if (storage && storage->verify) verifyCapture(game, value);','    probeRow.part[6]+=probeElapsed(probeInputs);\n    ++probeRow.calls;probeRow.total+=probeElapsed(probeStart);\n    if (storage && storage->verify) verifyCapture(game, value);',1)
f=p/'capture-phases.cpp';f.write_text(s)
a=json.loads((p/'compile-native.json').read_text());a[a.index('-o')+1]=str(p/'capture-phases.o');a[next(i for i,x in enumerate(a) if x.endswith('/capture-probe.cpp'))]=str(f);a+=['-Isrc/engine/sim/snapshot'];r=subprocess.run(a,capture_output=True,text=True);(p/'capture-phases-build.log').write_text(r.stdout+r.stderr)
if r.returncode:raise RuntimeError(r.stderr[-1600:])
a=json.loads((p/'link-native.json').read_text());a[a.index('-o')+1]=str(p/'capture-phases');a.remove(next(x for x in a if x.endswith('/capture-probe.o')));a[a.index('build/darwin/client/release/src/engine/sim/snapshot/WorldCapture.o')]=str(p/'capture-phases.o');r=subprocess.run(a,capture_output=True,text=True);print('linked',r.returncode,r.stderr[-1000:])
