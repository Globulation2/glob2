// SPDX-License-Identifier: GPL-3.0-or-later
#include "SnapshotStore.h"
#include "Game.h"
#include <algorithm>
namespace SimulationSnapshot
{
Handle Store::captureBoundary(const Game& game, Requirements required)
{
	const auto requested = required;
	if (latest && latest->worldIdentity != game.map.identity()) reset();
	if (latest && latest->tick == game.stepCounter && latest->observationRevision == observationRevision
        && latest->configurationRevision == game.gameHeader.observationRevision()
        && latest->mapGenerations == game.map.snapshotGenerations()) {
		if ((required & latest->requirements) == required) return latest->project(requested);
		required |= latest->requirements;
	}
	const auto start = storage.profiling ? std::chrono::steady_clock::now() : std::chrono::steady_clock::time_point{};
	const auto preparedBefore = storage.preparationNs;
	if (needs(required, Component::Catalogs) && (!catalog || catalogConfigurationRevision != game.gameHeader.observationRevision())) {
		catalog = captureCatalog(game);
		catalogConfigurationRevision = game.gameHeader.observationRevision();
	}
	const auto copiedBefore = storage.bytesCopied;
	auto next = capture(game, catalog, required, latest ? &*latest : nullptr, &storage);
	next.observationRevision = observationRevision;
	latest = std::move(next);
	return latest->project(requested);
}

MemoryMetrics Store::memoryMetrics() const
{
	auto value = storage.memoryMetrics();
	memoryPeaks.peakAllocatedBuffers = std::max(memoryPeaks.peakAllocatedBuffers, value.allocatedBuffers);
	memoryPeaks.peakReusableBuffers = std::max(memoryPeaks.peakReusableBuffers, value.reusableBuffers);
	memoryPeaks.peakLeasedBuffers = std::max(memoryPeaks.peakLeasedBuffers, value.leasedBuffers);
	memoryPeaks.peakRetainedBytes = std::max(memoryPeaks.peakRetainedBytes, value.retainedBytes);
	memoryPeaks.peakCapacityBytes = std::max(memoryPeaks.peakCapacityBytes, value.capacityBytes);
	memoryPeaks.peakLeasedBytes = std::max(memoryPeaks.peakLeasedBytes, value.leasedBytes);
	value.peakAllocatedBuffers = memoryPeaks.peakAllocatedBuffers;
	value.peakReusableBuffers = memoryPeaks.peakReusableBuffers;
	value.peakLeasedBuffers = memoryPeaks.peakLeasedBuffers;
	value.peakRetainedBytes = memoryPeaks.peakRetainedBytes;
	value.peakCapacityBytes = memoryPeaks.peakCapacityBytes;
	value.peakLeasedBytes = memoryPeaks.peakLeasedBytes;
	return value;
}
} // namespace SimulationSnapshot
