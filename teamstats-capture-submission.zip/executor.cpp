#include EXHEADER
#include <iostream>
struct Work { std::atomic<unsigned> count{0}; unsigned iterations=0; };
void job(void* p,std::size_t) { auto& w=*static_cast<Work*>(p); unsigned x=1;for(unsigned i=0;i<w.iterations;++i){x=(x*1664525u)+1013904223u;asm volatile("" : "+r"(x));}w.count.fetch_add(x?1:1,std::memory_order_relaxed); }
int main(int argc,char**argv){
 unsigned threads=argc>1?std::atoi(argv[1]):1,loops=argc>2?std::atoi(argv[2]):0;
 ComputeExecutor e;e.configure(threads);Work w;w.iterations=loops;
 std::array<ComputeExecutor::Batch,8> batches{};
 ComputeExecutor::Group g{1,{job,&w},ComputeExecutor::StatisticsLaneBase};
 const unsigned n=argc>3?std::atoi(argv[3]):20000;
 unsigned check=0;auto start=std::chrono::steady_clock::now();
 for(unsigned i=0;i<n;++i){if(i>=8)e.join(batches[i%8]);batches[i%8]=e.submit(std::span(&g,1),i+8);if(argc>4)for(unsigned j=0;j<20000;++j){check=check*1664525u+1013904223u;asm volatile("" : "+r"(check));}}
 for(auto& b:batches)if(!b.empty())e.join(b);
 std::cout<<"workers="<<threads-1<<" jobs="<<n<<" ns="<<double(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count())/n<<" completed="<<w.count<<" check="<<check;
#ifdef TIMED
 std::cout<<" lock_ns="<<double(SubmitProbe::lockNs)/n<<" body_ns="<<double(SubmitProbe::bodyNs)/n<<" unlock_notify_ns="<<double(SubmitProbe::wakeNs)/n;
#endif
 std::cout<<"\n";return w.count==n?0:1;
}
