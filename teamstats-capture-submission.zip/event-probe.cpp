#include "TeamStat.h"
#include "UnitState.h"
#include "src/engine/sim/snapshot/WorldRecords.h"
#include <algorithm>
#include <cstring>
#include <iostream>
#include <valgrind/callgrind.h>
namespace {
template<class Visitor, class Destination, class Source>
void visitEventFields(Visitor&& visit, Destination& destination, Source& source)
{
    visit(destination.births, source.births);
    visit(destination.deaths, source.deaths);
    visit(destination.conversionsIn, source.conversionsIn);
    visit(destination.conversionsOut, source.conversionsOut);
    visit(destination.harvested, source.harvested);
    visit(destination.cleared, source.cleared);
    visit(destination.delivered, source.delivered);
    visit(destination.withdrawn, source.withdrawn);
    visit(destination.transferredIn, source.transferredIn);
    visit(destination.transferredOut, source.transferredOut);
    visit(destination.consumed, source.consumed);
    visit(destination.repairDelivered, source.repairDelivered);
    visit(destination.materialSpillageEvents, source.materialSpillageEvents);
    visit(destination.meals, source.meals);
    visit(destination.healingVisits, source.healingVisits);
    visit(destination.hpRestored, source.hpRestored);
    visit(destination.damageDealt, source.damageDealt);
    visit(destination.damageReceived, source.damageReceived);
    visit(destination.shots, source.shots);
    visit(destination.impacts, source.impacts);
    visit(destination.completed, source.completed);
    visit(destination.removed, source.removed);
    visit(destination.trainingVisits, source.trainingVisits);
    visit(destination.abilityGains, source.abilityGains);
    visit(destination.growthTiles, source.growthTiles);
    visit(destination.growthAmount, source.growthAmount);
    visit(destination.growthReduction, source.growthReduction);
    visit(destination.growthGlobal, source.growthGlobal);
    visit(destination.combatDeathPlace, source.combatDeathPlace);
    visit(destination.combatDeathAssignment, source.combatDeathAssignment);
}
template<class T> void copyEventField(T& destination, const T& source) { destination = source; }
template<class T, size_t N> void copyEventField(T (&destination)[N], const T (&source)[N])
{ for (size_t i=0;i<N;++i) copyEventField(destination[i],source[i]); }
}
void GameplayEventCounters::capture(const GameplayMeasurements& source)
{
    visitEventFields([](auto& to,const auto& from){copyEventField(to,from);},*this,source);
    variants.resize(source.variants.size());
    for(size_t i=0;i<variants.size();++i) {
        copyEventField(variants[i].completed,source.variants[i].completed);
        copyEventField(variants[i].removed,source.variants[i].removed);
    }
}
void GameplayEventCounters::applyTo(GameplayMeasurements& destination) const
{
    visitEventFields([](auto& to,const auto& from){copyEventField(to,from);},destination,*this);
    destination.variants.resize(variants.size());
    for(size_t i=0;i<variants.size();++i) {
        copyEventField(destination.variants[i].completed,variants[i].completed);
        copyEventField(destination.variants[i].removed,variants[i].removed);
    }
}
std::size_t GameplayEventCounters::capacityBytes() const
{
    size_t bytes=variants.capacity()*sizeof(Variant);
    visitEventFields([&](const auto& field,const auto&) {
        if constexpr (requires { field.extraCapacityBytes(); }) bytes+=field.extraCapacityBytes();
    },*this,*this);
    return bytes;
}

int main(int argc,char**argv){
 GameplayMeasurements source; GameplayEventCounters rows[9];source.variants.resize(32);for(auto& r:rows)r.capture(source);
 const unsigned n=20000;const int mode=argc>1?std::atoi(argv[1]):0;
 std::vector<UnitState> units(256);std::vector<SimulationSnapshot::UnitView> copy(256);std::vector<unsigned> slots(4096);size_t checksum=0;
 CALLGRIND_ZERO_STATS;CALLGRIND_START_INSTRUMENTATION;
 for(unsigned i=0;i<n;++i){if(mode==0)rows[i%9].capture(source);if(mode==1)checksum+=rows[i%9].capacityBytes();if(mode==2)std::fill_n(slots.begin(),4096,0xffffffffu);if(mode==3)for(size_t j=0;j<256;++j)std::memcpy(static_cast<UnitState*>(&copy[j]),&units[j],sizeof(UnitState));asm volatile("" ::: "memory");}
 CALLGRIND_DUMP_STATS;CALLGRIND_STOP_INSTRUMENTATION;
 std::cout<<"mode="<<mode<<" samples="<<n<<" event_bytes="<<sizeof(GameplayEventCounters)<<" unit_bytes="<<sizeof(UnitState)<<" checksum="<<checksum<<"\n";
}
