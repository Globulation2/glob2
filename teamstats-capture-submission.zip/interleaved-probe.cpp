#include "EngineFixtures.h"
#include "src/engine/sim/snapshot/SnapshotStorage.h"
#include <chrono>
#include <iostream>
using namespace SimulationSnapshot;
namespace SimulationSnapshot {
Handle captureNoIndexClear(const Game&,std::shared_ptr<const std::vector<BuildingKindView>>,Requirements,const Handle*,Storage*);
Handle captureNoAttackQuery(const Game&,std::shared_ptr<const std::vector<BuildingKindView>>,Requirements,const Handle*,Storage*);
Handle captureNoUnitStateCopy(const Game&,std::shared_ptr<const std::vector<BuildingKindView>>,Requirements,const Handle*,Storage*);
Handle captureNoEventCapture(const Game&,std::shared_ptr<const std::vector<BuildingKindView>>,Requirements,const Handle*,Storage*);
}
TEST_CASE("interleaved capture probe") {
 glob2test::HeadlessGlobals globals;
 glob2test::HeadlessGame w(glob2test::GameOptions{.wDec=8,.hDec=8,.teams=2,.loadDefaultRace=true,.seed=1234567});
 for(int t=0;t<2;++t){w.game.teams[t]->stats.enableCollection();for(int i=0;i<128;++i)w.addUnit(i%3,16+t*128+i%64,16+3*(i/64),t);w.addBuilding("inn",4+t*128,100,0,t);}
 const auto catalog=captureCatalog(w.game);
 const auto requirements=bit(Component::Catalogs)|bit(Component::Rules)|bit(Component::Teams)|bit(Component::Entities)|bit(Component::StatisticsInputs);
 using Fn=decltype(&capture);
 Fn functions[]{capture,captureNoIndexClear,captureNoAttackQuery,captureNoUnitStateCopy,captureNoEventCapture};
 Storage stores[5];Handle previous[5];std::array<std::array<Handle,8>,5> leases;unsigned tick=0;
 const unsigned count=10000;
 for(unsigned trial=0;trial<25;++trial)for(unsigned k=0;k<5;++k){const unsigned mode=(trial+k)%5;
  auto& storage=stores[mode];auto& prev=previous[mode];
  for(unsigned i=0;i<16;++i){w.game.stepCounter=++tick;prev=functions[mode](w.game,catalog,requirements,prev.tick?&prev:nullptr,&storage);leases[mode][i%8]=prev;}
  auto start=std::chrono::steady_clock::now();
  for(unsigned i=0;i<count;++i){w.game.stepCounter=++tick;prev=functions[mode](w.game,catalog,requirements,&prev,&storage);leases[mode][i%8]=prev;auto projected=prev.project(requirements);}
  auto ns=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();
  std::cout<<"INTERLEAVED trial="<<trial<<" mode="<<mode<<" ns="<<double(ns)/count<<"\n";
 }
}
