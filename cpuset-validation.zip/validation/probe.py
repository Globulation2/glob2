import json,os,uuid
from pathlib import Path
base=Path('/sys/fs/cgroup');group=base/('glob2-benchmark-probe-'+uuid.uuid4().hex)
watched=[base,base/'user.slice',base/'system.slice']
def snapshot():return {str(p.relative_to(base)):(p/'cpuset.cpus.effective').read_text().strip() for p in watched}
result={'before':snapshot(),'group':group.name,'reserved':'0-7,16-23'}
try:
 if os.geteuid()!=0:raise RuntimeError('Root helper required')
 group.mkdir()
 (group/'cpuset.mems').write_text((base/'cpuset.mems.effective').read_text())
 (group/'cpuset.cpus').write_text('0-7,16-23')
 (group/'cpuset.cpus.exclusive').write_text('0-7,16-23')
 (group/'cpuset.cpus.partition').write_text('root')
 result['partition']={n:(group/n).read_text().strip() for n in ['cpuset.cpus.partition','cpuset.cpus.effective','cpuset.cpus.exclusive.effective','cgroup.procs']}
 result['during']=snapshot()
 if result['partition']['cpuset.cpus.partition']!='root':raise RuntimeError('Partition invalid')
 if any(result['during'][k]!='8-15,24-31' for k in ('user.slice','system.slice')):raise RuntimeError('Outside masks not disjoint')
 result['passed']=True
finally:
 if group.exists():
  (group/'cpuset.cpus.partition').write_text('member')
  group.rmdir()
 result['after']=snapshot();result['removed']=not group.exists();result['restored']=result['after']==result['before']
 print(json.dumps(result,indent=2))
 if not result['restored'] or not result['removed']:raise RuntimeError('Restoration failed')
