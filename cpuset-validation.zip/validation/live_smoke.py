import hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd(); OUT=ROOT/'artifacts/resource-followup/cpuset-validation'
CP=ROOT/'test/run_with_benchmark_cpuset.py'; GOV=ROOT/'test/run_with_benchmark_governor.py'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
 return {'root':Path('/sys/fs/cgroup/cpuset.cpus.effective').read_text().strip(),
 'user':Path('/sys/fs/cgroup/user.slice/cpuset.cpus.effective').read_text().strip(),
 'system':Path('/sys/fs/cgroup/system.slice/cpuset.cpus.effective').read_text().strip(),
 'governors':{str(i):Path(f'/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_governor').read_text().strip() for i in range(8)}}
PROOF='''import json,os,sys,time
from pathlib import Path
result={'uid':os.getuid(),'gid':os.getgid(),'groups':os.getgroups(),'affinity':sorted(os.sched_getaffinity(0)),'cgroup':Path('/proc/self/cgroup').read_text().strip(),'outside':Path('/sys/fs/cgroup/cpuset.cpus.effective').read_text().strip(),'governors':{str(i):Path(f'/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_governor').read_text().strip() for i in range(8)}}
Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\\n')
time.sleep(float(sys.argv[2]))
'''
report={'before':snapshot(),'sources':{str(p):digest(p) for p in (CP,GOV)},'cases':[]}
for kind,seconds in [('success',2),('interrupt',60)]:
 audit=OUT/f'live-{kind}-cpuset.json';gaudit=OUT/f'live-{kind}-governors.json';proof=OUT/f'live-{kind}-child.json'
 for p in (audit,gaudit,proof):
  if p.exists():raise RuntimeError(f'Fresh output required: {p}')
 command=[sys.executable,str(CP),'--audit',str(audit),'--timeout-seconds','120','--',sys.executable,str(GOV),'--audit',str(gaudit),'--timeout-seconds','120','--',sys.executable,'-c',PROOF,str(proof),str(seconds)]
 with (OUT/f'live-{kind}.log').open('x') as log:
  p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
  try:
   deadline=time.monotonic()+30
   while not proof.exists():
    if p.poll() is not None:raise RuntimeError(f'{kind} exited before proof: {p.returncode}')
    if time.monotonic()>deadline:raise RuntimeError('Child proof timeout')
    time.sleep(.05)
   if kind=='interrupt':p.send_signal(signal.SIGINT)
   code=p.wait(timeout=90)
  finally:
   if p.poll() is None:
    p.send_signal(signal.SIGINT);p.wait(timeout=90)
 a=json.loads(audit.read_text());g=json.loads(gaudit.read_text());pr=json.loads(proof.read_text())
 checks={'expected_exit':code==(0 if kind=='success' else 1),'unprivileged_identity':pr['uid']==os.getuid() and pr['gid']==os.getgid() and sorted(pr['groups'])==sorted(os.getgroups()),'engine_affinity':pr['affinity']==list(range(8)),'outside_complement':pr['outside']=='8-15,24-31','stabilized_governors':set(pr['governors'].values())=={'performance'},'cpuset_restored':a.get('cgroup_restored') is True and a.get('wrapper_affinity_restored') is True and not a.get('forced_cgroup_kill') and not a.get('cleanup_error'),'governors_restored':g.get('restored') is True and not g.get('restoration_errors'),'reservation_removed':not Path(a['cgroup_path']).exists(),'host_restored':snapshot()==report['before'],'sources_unchanged':all(digest(Path(path))==sha for path,sha in report['sources'].items())}
 report['cases'].append({'kind':kind,'command':command,'exit_code':code,'checks':checks,'cpuset_audit':str(audit),'governor_audit':str(gaudit)})
 (OUT/'live-smoke-report.json').write_text(json.dumps(report,indent=2)+'\n')
 if not all(checks.values()):raise RuntimeError(f'Failed checks: {checks}')
report['passed']=True;report['after']=snapshot();(OUT/'live-smoke-report.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS: real nested governor success and SIGINT restore CPU partition, affinity and all governors; command remains unprivileged.')
