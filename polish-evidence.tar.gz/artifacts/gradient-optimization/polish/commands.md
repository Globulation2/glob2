# Review cleanup verification commands

All commands run from the repository root. Exact per-benchmark compiler and subprocess arguments are also retained in manifests and summary JSON. Native dependency/library provenance is unchanged from the original published evidence.

```sh
GLOB2_SDL3_PREFIX=/tmp/glob2-sdl3/prefix GLOB2_RECORDING_PREFIX=/tmp/glob2-terrain-baseline-build/recording/prefix taskset -c 0-11 scons -j12 release=1 tests build/linux/client/release/src/glob2

LD_LIBRARY_PATH=/tmp/glob2-terrain-sdl-patched/prefix/lib python3 test/run_tests.py --binary unit --no-display --exclude-tag benchmark --junit artifacts/gradient-optimization/polish/committed-unit-tests.xml --artifacts artifacts/gradient-optimization/polish/committed-unit-tests

LD_LIBRARY_PATH=/tmp/glob2-terrain-sdl-patched/prefix/lib python3 test/run_tests.py --binary engine --no-display --filter '*Gradient*' -j 4 --junit artifacts/gradient-optimization/polish/committed-engine-tests.xml --artifacts artifacts/gradient-optimization/polish/committed-engine-tests

python3 tools/test_gradient_benchmark.py
python3 -m py_compile tools/gradient_benchmark.py tools/test_gradient_benchmark.py

taskset -c 15 python3 tools/gradient_benchmark.py --baseline-dir artifacts/gradient-optimization/baseline/src --output artifacts/gradient-optimization/polish/benchmark-final --suite smoke --repeats 1

taskset -c 14 python3 tools/gradient_benchmark.py --baseline-dir artifacts/gradient-optimization/baseline/src --output artifacts/gradient-optimization/polish/benchmark-sanitized --suite smoke --repeats 1 --instrumented --flags='-O1 -g -DNDEBUG -std=c++20 -fsanitize=address,undefined -fno-omit-frame-pointer'

python3 artifacts/gradient-optimization/polish-core/verify-tokens.py
sha256sum build/linux/client/release/src/glob2 artifacts/gradient-optimization/final/glob2
git diff --check
```

The two standalone runs froze their compilation inputs before the final Python-only safeguards were completed; their C++ source matches final HEAD. The final Python runner's evidence-protection/error-reporting paths were tested by the eleven contract tests after the commit. These smoke runs establish correctness, not new timing claims. The full native unit/engine tests were repeated after the final commit and build. The invalid CLI commands, diagnostics and results are listed individually in `cli-invalid-cases.json`.
