# Independent review of benchmark validation and eager regression additions

Reviewed the strategic `referenceTravel` oracle, CLI parser/validation, eager
Map dispatch invocation in the uniform/source regression, and the new eager
specialization regression against revision `37d609766`.

- The strategic oracle is independent of the production and frozen baseline
  traversal: it uses a 64-bit heap, explicit Q8 cost arithmetic, direct wrapped
  coordinates, and publishes only after all wide costs are settled. Sharing the
  immutable property table is appropriate input sharing, not implementation reuse.
- Parser validation rejects trailing integer junk, invalid enums, non-positive
  dimensions/repeats, invalid profile/caps, and unsupported synthetic production
  dispatch/strategic combinations. Strategic-only seeds/caps are validated.
- The eager regression exercises goals with different costs, forbidden outliers,
  distant traversable outliers, deferred seeds, no goals, and all blockers, reusing
  one workspace across all variants and three shapes. The existing Map-level
  uniform/source test now covers eager dispatch as well as the resumable path.
- The original antipodal outlier was ineffective; the coordinating agent changed
  it to one third of each dimension. An independent Python heap confirms that the
  revised fixture improves 60, 16, and 5 cells on 32x32, 17x5, and 1x31 grids.
  See `distant-outlier-check.json`.
- The four product files still have identical C++ lexical tokens to the measured
  implementation. See `token-comparison.json`.

Remaining low-priority recommendation at review time: the CLI cell-count bound
allows an extremely wide/thin dimension greater than INT_MAX/2, while fixture
`2*width` and oracle `(x+dx+width)` use signed-int arithmetic. Also reject either
dimension above INT_MAX/2, or widen those coordinate expressions. Normal maintained
suite sizes are unaffected. No simulation/kernel correctness issue was found.
