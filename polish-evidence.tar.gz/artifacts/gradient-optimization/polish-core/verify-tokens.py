#!/usr/bin/env python3
"""Verify that core polish changes only comments and whitespace.

GCC strips comments without expanding directives/includes (-fpreprocessed).
A C++ lexical-token matcher then retains literals and punctuation boundaries,
so e.g. `+ +` cannot accidentally compare equal to `++`.
"""
import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path.cwd()
evidence = root / 'artifacts/gradient-optimization/polish-core'
paths = [
    'src/field/PreparedTerrainCosts.h',
    'src/field/TerrainGradient.h',
    'src/field/TerrainTravel.h',
    'src/map/gradient/BuildingGradientSearch.cpp',
]
# These files use ordinary literals only (no raw or user-defined literals).
token = re.compile(r'''(?:u8|u|U|L)?"(?:\\.|[^"\\])*"|(?:u8|u|U|L)?'(?:\\.|[^'\\])*'|[A-Za-z_]\w*|\d[\w.]*|%:%:|<=>|>>=|<<=|->\*|\.\.\.|::|->|\.\*|\+\+|--|<<|>>|<=|>=|==|!=|&&|\|\||\+=|-=|\*=|/=|%=|\^=|&=|\|=|##|<:|:>|<%|%>|%:|[^\s]''')

def tokens(path):
    result = subprocess.run(['g++', '-E', '-P', '-fpreprocessed', '-x', 'c++', str(path)], check=True, capture_output=True, text=True)
    return token.findall(result.stdout)

results = []
for name in paths:
    before = evidence / (Path(name).name + '.before')
    after = root / name
    old, new = tokens(before), tokens(after)
    assert old == new, f'Non-comment/whitespace token change: {name}'
    results.append({'path': name, 'tokens_identical': True, 'token_count': len(new),
        'token_sha256': hashlib.sha256(json.dumps(new).encode()).hexdigest(),
        'before_sha256': hashlib.sha256(before.read_bytes()).hexdigest(),
        'after_sha256': hashlib.sha256(after.read_bytes()).hexdigest()})
report = {'method': __doc__.strip(), 'files': results,
    'scope': 'C++ lexical tokens unchanged; source locations and diagnostic/debug line numbers may differ.'}
(evidence / 'token-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
