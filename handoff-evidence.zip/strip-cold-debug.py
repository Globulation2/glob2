import hashlib,json,shlex,struct,subprocess,time
from pathlib import Path
root=Path('/work/build/linux/client/release/retain-symbols/dev-linker-auto/src')
allowed=('render/','ui/','hud/','map/generator/','map/editor/','online/screens/','game/screens/')
targets=set()
for log in (Path('/tmp/inline-base-build-part1.log'),Path('/tmp/inline-base-build-oom.log'),Path('/tmp/inline-base-build.log'),Path('/inline-evidence/linux-candidate-build.log')):
 if not log.exists():continue
 for line in log.read_text(errors='replace').splitlines():
  if not line.startswith('g++ '):continue
  args=shlex.split(line)
  if '-o' in args:targets.add(Path(args[args.index('-o')+1]).resolve())
active=set()
for proc in Path('/proc').iterdir():
 if not proc.name.isdecimal():continue
 try:
  args=proc.joinpath('cmdline').read_bytes().decode().strip('\0').split('\0')
  if args and Path(args[0]).name in ('g++','gcc','as') and '-o' in args:active.add(Path(args[args.index('-o')+1]).resolve())
 except (OSError,ValueError):pass

def allocated(data):
 assert data[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<H',data,16)[0]==1
 offset=struct.unpack_from('<Q',data,40)[0]
 size,count,names=struct.unpack_from('<HHH',data,58)
 sections=[struct.unpack_from('<IIQQQQIIQQ',data,offset+i*size) for i in range(count)]
 table=sections[names];strings=data[table[4]:table[4]+table[5]];rows=[]
 for name,kind,flags,addr,pos,length,*rest in sections:
  if not flags&2:continue
  label=strings[name:].split(b'\0',1)[0].decode()
  payload=b'' if kind==8 else data[pos:pos+length]
  rows.append((label,kind,flags,length,hashlib.sha256(payload).hexdigest()))
 return sorted(rows)

rows=[]
for path in sorted(targets):
 try:relative=path.relative_to(root).as_posix();stat=path.stat()
 except (ValueError,FileNotFoundError):continue
 if not relative.startswith(allowed) or path in active or time.time()-stat.st_mtime<120:continue
 before=path.read_bytes();digest=allocated(before)
 if path.stat().st_mtime_ns!=stat.st_mtime_ns:continue
 subprocess.run(['strip','--strip-debug',str(path)],check=True,capture_output=True)
 after=path.read_bytes()
 if allocated(after)!=digest:
  path.write_bytes(before);raise RuntimeError(f'Allocated sections changed: {path}')
 rows.append({'path':relative,'before_bytes':len(before),'after_bytes':len(after),'allocated_sections_sha256':hashlib.sha256(json.dumps(digest).encode()).hexdigest()})
result={'runtime_sections_unchanged':True,'files':rows,'freed_bytes':sum(x['before_bytes']-x['after_bytes'] for x in rows)}
output=Path('/inline-evidence')/('cold-debug-stripping-'+str(int(time.time()))+'.json');output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'files':len(rows),'freed_bytes':result['freed_bytes'],'runtime_sections_unchanged':True}))
