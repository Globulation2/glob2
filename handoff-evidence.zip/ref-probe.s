	.build_version macos, 26, 0	sdk_version 27, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_buildingRef                    ; -- Begin function buildingRef
	.p2align	2
_buildingRef:                           ; @buildingRef
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_2
; %bb.1:
	ldrh	w8, [x0, #72]
	ldr	w9, [x0, #68]
	orr	x0, x8, x9, lsl #32
	ret
LBB0_2:
	mov	w0, #65535                      ; =0xffff
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_unitRef                        ; -- Begin function unitRef
	.p2align	2
_unitRef:                               ; @unitRef
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_2
; %bb.1:
	ldrh	w8, [x0, #10]
	ldr	w9, [x0, #132]
	orr	x0, x8, x9, lsl #32
	ret
LBB1_2:
	mov	w0, #65535                      ; =0xffff
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
	.cfi_startproc
; %bb.0:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
