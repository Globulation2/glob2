#!/bin/bash
set -euo pipefail
cd /work
while ! test -f /inline-evidence/candidate-profile-3/result.json || ! grep -q '^totals:' /inline-evidence/candidate-3.callgrind.*-01 2>/dev/null; do sleep 5; done
bin=build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2
strip --strip-debug /inline-evidence/linux-candidate.glob2
sha256sum /inline-evidence/linux-candidate.glob2 > /inline-evidence/linux-candidate-retained-post-strip-sha256.txt
cp /inline-evidence/EngineRun.original.cpp src/engine/EngineRun.cpp
PYTHONPATH=/work GLOB2_SDL3_PREFIX=/opt/glob2-sdl scons release=1 retain_symbols=1 linker=auto -j2 engine-tests unit-tests "$bin" > /inline-evidence/linux-candidate-pristine-build.log 2>&1
ln "$bin" /inline-evidence/linux-candidate-pristine.glob2
sha256sum /inline-evidence/linux-candidate-pristine.glob2 > /inline-evidence/linux-candidate-pristine-binary-sha256.txt
size -A "$bin" > /inline-evidence/linux-candidate-pristine-sections.txt
/inline-evidence/linux-candidate-pristine.glob2 game run --load-game /profile/midgame24k/final.game.gz --compute-threads 8 --gpu off --ticks 25153 --telemetry checksums --save final --output-dir /inline-evidence/linux-candidate-pristine-run > /inline-evidence/linux-candidate-pristine-run.log 2>&1
cmp /inline-evidence/linux-base-run/world.checksums /inline-evidence/linux-candidate-pristine-run/world.checksums
bash /tmp/run-focused-tests.sh build/linux/client/release/retain-symbols/dev-linker-auto /inline-evidence/focused-tests
for count in 1 8; do
 /inline-evidence/linux-candidate-pristine.glob2 match verify test/fixtures/multiplayer/FourSquares1.g2mr --map-file maps/FourSquares1.map.gz --output-dir /inline-evidence/golden-$count --compute-threads "$count" > /inline-evidence/golden-$count.log 2>&1
 cmp test/fixtures/multiplayer/FourSquares1.verify-trace.txt /inline-evidence/golden-$count/checksums.txt
done
python3 /tmp/analyze-results.py /inline-evidence > /inline-evidence/comparison.log
printf 'Focused tests, golden traces at 1/8 threads, and continuation comparison passed.\n' > /inline-evidence/validation-complete.txt
