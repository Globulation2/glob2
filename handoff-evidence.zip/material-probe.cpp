#include "Building.h"
extern "C" int demand(const Building* b,int r) {return b->materialDeliveryNeed(r);}
extern "C" int target(const Building* b,int r) {return b->materialDeliveryTarget(r);}
extern "C" int available(const Building* b,int r) {return b->availableMaterial(r);}
