from pathlib import Path
import json,re,resource,shlex,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
root=Path('artifacts/inline-hot-helpers')
flags=shlex.split((root/'ref-probe-command.txt').read_text())
flags=[x for x in flags if x!='-DNDEBUG']
commands=[]
def run(args,expect=0):
 commands.append(shlex.join(map(str,args)))
 p=subprocess.run(list(map(str,args)),capture_output=True,text=True)
 assert p.returncode==expect,(args,p.returncode,p.stderr[-2000:])
 return p
for mode,extra in [('debug',[]),('release',['-DNDEBUG'])]:
 binary=root/f'gid-probe-{mode}'
 run(flags+extra+[root/'gid-probe.cpp','-o',binary])
 run([binary])
 if mode=='debug':
  for case in range(1,13):run([binary,str(case)],-6 if case<=10 else 0)
run(flags+['-DNDEBUG',root/'gid-probe.cpp','-S','-o',root/'gid-probe-release.s'])
for order in ('game-first','building-first','unit-first'):
 run(flags+['-fsyntax-only',root/f'ref-order-{order}.cpp'])
run(flags+['-DNDEBUG',root/'ref-probe.cpp','-o',root/'ref-probe'])
run([root/'ref-probe'])
run(flags+['-DNDEBUG',root/'ref-probe.cpp','-S','-o',root/'ref-probe.s'])
for mode,extra in [('assertions',[]),('release',['-DNDEBUG'])]:
 path=root/f'material-probe-{mode}.s'
 run(flags+extra+[root/'material-probe.cpp','-S','-o',path])
for name in ('gid-probe-release.s','ref-probe.s','material-probe-assertions.s','material-probe-release.s'):
 text=(root/name).read_text()
 assert not re.search(r'^\s*(?:b|bl)\s+[^\n]*(?:materialDeliveryNeed|materialDeliveryTarget|availableMaterial|constructionMaterialNeed|refOf|GIDto|GIDfrom)',text,re.M),name
(root/'final-clang-probe-commands.txt').write_text('\n'.join(commands)+'\n')
result={'commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'compiler':subprocess.check_output(['clang++','--version']).decode().splitlines()[0],'result':'PASS','valid_round_trips_per_mode':32768,'assertion_abort_cases':10,'historical_negative_building_cases':2,'header_orders':3,'helper_calls_in_optimized_wrappers':0}
(root/'final-clang-probe-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
