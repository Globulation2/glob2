#include "Game.h"
extern "C" BuildingRef buildingRef(const Building *b) { return Game::refOf(b); }
extern "C" UnitRef unitRef(const Unit *u) { return Game::refOf(u); }
static_assert(std::is_same_v<decltype(static_cast<BuildingRef (*)(const Building *)>(&Game::refOf)), BuildingRef (*)(const Building *)>);
static_assert(std::is_same_v<decltype(static_cast<UnitRef (*)(const Unit *)>(&Game::refOf)), UnitRef (*)(const Unit *)>);
int main() { return !Game::refOf(static_cast<const Unit *>(nullptr)).empty() || !Game::refOf(static_cast<const Building *>(nullptr)).empty(); }
