#!/bin/bash
set -euo pipefail
cd /work
mkdir -p /inline-evidence
while ! grep -q 'scons: done building targets.' /tmp/inline-base-build.log; do
  if grep -q 'scons: building terminated' /tmp/inline-base-build.log; then exit 1; fi
  sleep 3
done
bin=build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2
cp /tmp/inline-base-build.log /inline-evidence/linux-base-build.log
size -A "$bin" > /inline-evidence/linux-base-sections.txt
objcopy --strip-debug "$bin" /inline-evidence/linux-base.glob2
/inline-evidence/linux-base.glob2 game run --load-game /profile/midgame24k/final.game.gz --compute-threads 8 --gpu off --ticks 25153 --telemetry checksums --save final --output-dir /inline-evidence/linux-base-run > /inline-evidence/linux-base-run.log 2>&1
cp src/engine/EngineRun.cpp /inline-evidence/EngineRun.original.cpp
python3 - <<'PY'
from pathlib import Path
p=Path('src/engine/EngineRun.cpp');s=p.read_text();s='#include <valgrind/callgrind.h>\n'+s
needle='bool Engine::advanceSession(Uint64 now, const std::function<void()>& clientWork, bool handleExit)\n{'
probe='''
    static const unsigned profileBegin = std::getenv("GLOB2_CG_BEGIN") ? std::strtoul(std::getenv("GLOB2_CG_BEGIN"), nullptr, 10) : 0;
    static const unsigned profileEnd = std::getenv("GLOB2_CG_END") ? std::strtoul(std::getenv("GLOB2_CG_END"), nullptr, 10) : 0;
    if (profileBegin && gui.game.stepCounter == profileBegin) { CALLGRIND_START_INSTRUMENTATION; CALLGRIND_ZERO_STATS; }
    if (profileEnd && gui.game.stepCounter == profileEnd) { CALLGRIND_STOP_INSTRUMENTATION; }
'''
assert s.count(needle)==1;p.write_text(s.replace(needle,needle+probe))
PY
PYTHONPATH=/work GLOB2_SDL3_PREFIX=/opt/glob2-sdl scons release=1 retain_symbols=1 linker=auto -j2 > /inline-evidence/linux-base-profile-build.log 2>&1
ln "$bin" /inline-evidence/linux-base-profile.glob2
sha256sum /inline-evidence/linux-base-profile.glob2 > /inline-evidence/linux-base-profile-executed-pre-strip-sha256.txt
for repeat in 1 2 3; do
 GLOB2_CG_BEGIN=24128 GLOB2_CG_END=25152 valgrind --tool=callgrind --instr-atstart=no --separate-threads=yes --read-inline-info=no --callgrind-out-file=/inline-evidence/base-$repeat.callgrind.%p --log-file=/inline-evidence/base-$repeat.valgrind.log /inline-evidence/linux-base-profile.glob2 game run --load-game /profile/midgame24k/final.game.gz --compute-threads 8 --gpu off --ticks 25153 --output-dir /inline-evidence/base-profile-$repeat > /inline-evidence/base-profile-$repeat.log 2>&1
done
strip --strip-debug /inline-evidence/linux-base-profile.glob2
sha256sum /inline-evidence/linux-base-profile.glob2 > /inline-evidence/linux-base-profile-retained-post-strip-sha256.txt
tar -xf /tmp/inline-candidate.tar -C /work
python3 -c "from pathlib import Path; Path('src/unit/UnitUtils.cpp').unlink()"
PYTHONPATH=/work GLOB2_SDL3_PREFIX=/opt/glob2-sdl scons release=1 retain_symbols=1 linker=auto -j2 engine-tests unit-tests "$bin" > /inline-evidence/linux-candidate-build.log 2>&1
size -A "$bin" > /inline-evidence/linux-candidate-sections.txt
ln "$bin" /inline-evidence/linux-candidate.glob2
sha256sum /inline-evidence/linux-candidate.glob2 > /inline-evidence/linux-candidate-executed-pre-strip-sha256.txt
/inline-evidence/linux-candidate.glob2 game run --load-game /profile/midgame24k/final.game.gz --compute-threads 8 --gpu off --ticks 25153 --telemetry checksums --save final --output-dir /inline-evidence/linux-candidate-run > /inline-evidence/linux-candidate-run.log 2>&1
cmp /inline-evidence/linux-base-run/world.checksums /inline-evidence/linux-candidate-run/world.checksums
printf 'Linux baseline/candidate per-tick world checksums match\n' > /inline-evidence/linux-continuation-result.txt
for repeat in 1 2 3; do
 GLOB2_CG_BEGIN=24128 GLOB2_CG_END=25152 valgrind --tool=callgrind --instr-atstart=no --separate-threads=yes --read-inline-info=no --callgrind-out-file=/inline-evidence/candidate-$repeat.callgrind.%p --log-file=/inline-evidence/candidate-$repeat.valgrind.log /inline-evidence/linux-candidate.glob2 game run --load-game /profile/midgame24k/final.game.gz --compute-threads 8 --gpu off --ticks 25153 --output-dir /inline-evidence/candidate-profile-$repeat > /inline-evidence/candidate-profile-$repeat.log 2>&1
done
