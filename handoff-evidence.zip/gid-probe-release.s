	.build_version macos, 26, 0	sdk_version 27, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_decodeUnit                     ; -- Begin function decodeUnit
	.p2align	2
_decodeUnit:                            ; @decodeUnit
	.cfi_startproc
; %bb.0:
	and	w0, w0, #0x3ff
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_encodeBuilding                 ; -- Begin function encodeBuilding
	.p2align	2
_encodeBuilding:                        ; @encodeBuilding
	.cfi_startproc
; %bb.0:
	add	w8, w0, w1, lsl #10
	and	w0, w8, #0xffff
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
	.cfi_startproc
; %bb.0:
	cmp	w0, #2
	b.lt	LBB2_3
; %bb.1:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x1, #8]
	bl	_atoi
	sub	w8, w0, #1
	cmp	w8, #11
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b.hi	LBB2_3
; %bb.2:
Lloh0:
	adrp	x9, l_switch.table.main@PAGE
Lloh1:
	add	x9, x9, l_switch.table.main@PAGEOFF
	ldr	w0, [x9, w8, uxtw #2]
	ret
LBB2_3:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @switch.table.main
l_switch.table.main:
	.long	65535                           ; 0xffff
	.long	1024                            ; 0x400
	.long	64512                           ; 0xfc00
	.long	16384                           ; 0x4000
	.long	0                               ; 0x0
	.long	63                              ; 0x3f
	.long	1024                            ; 0x400
	.long	16384                           ; 0x4000
	.long	0                               ; 0x0
	.long	63                              ; 0x3f
	.long	0                               ; 0x0
	.long	0                               ; 0x0

.subsections_via_symbols
