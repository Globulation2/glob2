#!/bin/bash
set -euo pipefail
build="$1"
out="$2"
mkdir -p "$out"
python3 test/run_tests.py --build-dir "$build" --binary unit --no-display -j2 --junit "$out/unit.xml" --artifacts "$out/unit-artifacts" --write-inventory "$out/unit-inventory.json" > "$out/unit.log" 2>&1
python3 test/run_tests.py --build-dir "$build" --binary engine --no-display -j2 --filter 'TeamLimit/*' --filter 'BuildingStock/*' --filter 'BuildingServices/*' --filter 'BuildingProductionCombat/*' --filter 'WorldSnapshot/*' --filter 'SavegameSafety/*' --filter 'HiringPlanner/*' --junit "$out/engine.xml" --artifacts "$out/engine-artifacts" --write-inventory "$out/engine-inventory.json" > "$out/engine.log" 2>&1
