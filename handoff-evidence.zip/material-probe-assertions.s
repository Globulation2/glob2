	.build_version macos, 26, 0	sdk_version 27, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_demand                         ; -- Begin function demand
	.p2align	2
_demand:                                ; @demand
	.cfi_startproc
; %bb.0:
                                        ; kill: def $w1 killed $w1 def $x1
	ldr	x9, [x0, #576]
	mov	w8, #2147483647                 ; =0x7fffffff
	mov	w10, #255                       ; =0xff
	cmp	x9, #0
	csel	x8, x10, x8, eq
	cbz	x9, LBB0_2
; %bb.1:
	ldr	w10, [x9, w1, sxtw #2]
	sub	x8, x8, w10, sxtw
	bic	x8, x8, x8, asr #63
	ldr	x12, [x0, #560]
	ldr	w10, [x12, #496]
	cbnz	w10, LBB0_3
	b	LBB0_7
LBB0_2:
	add	x10, x0, w1, sxtw
	ldrb	w10, [x10, #95]
	sub	x8, x8, w10, sxtw
	bic	x8, x8, x8, asr #63
	ldr	x12, [x0, #560]
	ldr	w10, [x12, #496]
	cbz	w10, LBB0_7
LBB0_3:
	add	x10, x0, w1, sxtw #2
	sxtw	x11, w1
	ldr	w10, [x10, #340]
	cbnz	w10, LBB0_5
; %bb.4:
	add	x13, x12, x11, lsl #2
	ldr	w13, [x13, #660]
	cbz	w13, LBB0_7
LBB0_5:
	ldrb	w13, [x0, #77]
	cmp	w13, #3
	b.ne	LBB0_10
; %bb.6:
	mov	w9, #0                          ; =0x0
	b	LBB0_18
LBB0_7:
	ldr	x10, [x0, #272]
	ldrh	w10, [x10, #54]
	lsr	w10, w10, w1
	tbz	w10, #0, LBB0_13
; %bb.8:
	add	x10, x12, w1, sxtw #2
                                        ; kill: def $w1 killed $w1 killed $x1 def $x1
	sxtw	x11, w1
	ldr	w10, [x10, #344]
	cbz	x9, LBB0_14
; %bb.9:
	ldr	w9, [x9, x11, lsl #2]
	sub	w9, w10, w9
	bic	w9, w9, w9, asr #31
	cmp	x8, x9
	csel	x0, x8, x9, lo
                                        ; kill: def $w0 killed $w0 killed $x0 def $x0
                                        ; kill: def $w0 killed $w0 killed $x0
	ret
LBB0_10:
	ldr	w12, [x12, #284]
	cbz	w12, LBB0_15
; %bb.11:
	ldr	x12, [x0, #568]
	add	x12, x12, #1012
	ldr	w12, [x12, x11, lsl #2]
	cbz	x9, LBB0_16
LBB0_12:
	ldr	w9, [x9, x11, lsl #2]
	b	LBB0_17
LBB0_13:
	mov	w0, #0                          ; =0x0
                                        ; kill: def $w0 killed $w0 killed $x0
	ret
LBB0_14:
	add	x9, x0, x11
	ldrb	w9, [x9, #95]
	sub	w9, w10, w9
	bic	w9, w9, w9, asr #31
	cmp	x8, x9
	csel	x0, x8, x9, lo
                                        ; kill: def $w0 killed $w0 killed $x0 def $x0
                                        ; kill: def $w0 killed $w0 killed $x0
	ret
LBB0_15:
	add	x12, x0, #280
	ldr	w12, [x12, x11, lsl #2]
	cbnz	x9, LBB0_12
LBB0_16:
	add	x9, x0, x11
	ldrb	w9, [x9, #95]
LBB0_17:
	sub	w9, w9, w12
	bic	w9, w9, w9, asr #31
LBB0_18:
	add	x11, x0, x11, lsl #2
	ldr	w11, [x11, #400]
	sub	w10, w10, w11
	bic	w10, w10, w10, asr #31
	sub	w9, w10, w9
	bic	w9, w9, w9, asr #31
	cmp	x8, x9
	csel	x0, x8, x9, lo
                                        ; kill: def $w0 killed $w0 killed $x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_target                         ; -- Begin function target
	.p2align	2
_target:                                ; @target
	.cfi_startproc
; %bb.0:
                                        ; kill: def $w1 killed $w1 def $x1
	ldr	x9, [x0, #560]
	ldr	w8, [x9, #496]
	cbz	w8, LBB1_4
; %bb.1:
	add	x8, x0, w1, sxtw #2
	ldr	w8, [x8, #340]
	cbz	w8, LBB1_3
; %bb.2:
	mov	x0, x8
	ret
LBB1_3:
	sxtw	x8, w1
	add	x8, x9, x8, lsl #2
	ldr	w8, [x8, #660]
	cbnz	w8, LBB1_6
LBB1_4:
	ldr	x8, [x0, #272]
	ldrh	w8, [x8, #54]
	lsr	w8, w8, w1
	tbz	w8, #0, LBB1_6
; %bb.5:
	add	x8, x9, w1, sxtw #2
	ldr	w8, [x8, #344]
	mov	x0, x8
	ret
LBB1_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_available                      ; -- Begin function available
	.p2align	2
_available:                             ; @available
	.cfi_startproc
; %bb.0:
                                        ; kill: def $w1 killed $w1 def $x1
	ldr	x8, [x0, #560]
	ldr	w8, [x8, #284]
	cbz	w8, LBB2_3
; %bb.1:
	ldr	x8, [x0, #568]
	add	x8, x8, #1012
	sxtw	x9, w1
	ldr	w8, [x8, w1, sxtw #2]
	ldr	x10, [x0, #576]
	cbz	x10, LBB2_4
LBB2_2:
	ldr	w9, [x10, x9, lsl #2]
	sub	w8, w9, w8
	bic	w0, w8, w8, asr #31
	ret
LBB2_3:
	add	x8, x0, #280
	sxtw	x9, w1
	ldr	w8, [x8, w1, sxtw #2]
	ldr	x10, [x0, #576]
	cbnz	x10, LBB2_2
LBB2_4:
	add	x9, x0, x9
	ldrb	w9, [x9, #95]
	sub	w8, w9, w8
	bic	w0, w8, w8, asr #31
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
