
# Local evidence-only focused harness selection; production objects are unchanged.
_inline_engine = ['BuildingProductionCombatTest.cpp', 'BuildingServicesTest.cpp', 'BuildingStockTest.cpp', 'HiringPlannerTest.cpp', 'SavegameSafetyHarness.cpp', 'TeamLimitTest.cpp', 'WorldSnapshotTest.cpp']
_inline_unit = ['BitArrayTest.cpp', 'FertilityFieldTest.cpp', 'FetchApportionmentTest.cpp', 'GlobalGradientHarness.cpp', 'GradientPipelineHarness.cpp', 'GradientTest.cpp', 'MapExploredAreaSaveLoadTest.cpp', 'MapQueryTest.cpp', 'PathGradientHarness.cpp']
_inline_name = lambda entry: (entry[0] if isinstance(entry, tuple) else entry).rsplit('/', 1)[-1]
registry.ENGINE_TESTS = [entry for entry in registry.ENGINE_TESTS if _inline_name(entry) in _inline_engine]
registry.UNIT_TESTS = [entry for entry in registry.UNIT_TESTS if _inline_name(entry) in _inline_unit]
