import collections,json,re,subprocess,sys
from pathlib import Path
result={}
for label,binary in [('base','linux-base.glob2'),('candidate','linux-candidate-pristine.glob2')]:
 process=subprocess.Popen(['objdump','-d','-C',str(Path(sys.argv[1])/binary)],stdout=subprocess.PIPE,text=True)
 caller='';rows=[];counts=collections.Counter()
 for line in process.stdout:
  function=re.match(r'^[0-9a-f]+ <(.*)>:$',line)
  if function:caller=function[1]
  call=re.search(r'\s(?:bl|b)\s+[0-9a-f]+\s+<((?:UnitUtils|BuildingUtils|Building|Game)::(?:GIDtoID|GIDtoTeam|GIDfrom|availableMaterial|constructionMaterialNeed|materialDeliveryNeed|materialDeliveryTarget|refOf)[^>]*)>',line)
  if call and '+0x' not in call[1] and caller!=call[1]:
   counts[call[1]]+=1;rows.append({'caller':caller,'callee':call[1],'instruction':line.strip()})
 assert process.wait()==0
 result[label]={'static_direct_calls':dict(sorted(counts.items())),'callsites':rows}
output=Path(sys.argv[1])/'static-helper-calls.json';output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({label:row['static_direct_calls'] for label,row in result.items()},indent=2))
