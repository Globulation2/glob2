#include "UnitUtils.h"
#include "BuildingUtils.h"
#include <cstdlib>

extern "C" Sint32 decodeUnit(Uint16 gid) { return UnitUtils::GIDtoID(gid); }
extern "C" Uint16 encodeBuilding(Sint32 id, Sint32 team) { return BuildingUtils::GIDfrom(id, team); }
int main(int argc, char **argv) {
 if (argc > 1) {
  switch(std::atoi(argv[1])) {
   case 1: return UnitUtils::GIDfrom(-1,0);
   case 2: return UnitUtils::GIDfrom(1024,0);
   case 3: return UnitUtils::GIDfrom(0,-1);
   case 4: return UnitUtils::GIDfrom(0,16);
   case 5: return UnitUtils::GIDtoID(16384);
   case 6: return UnitUtils::GIDtoTeam(65535);
   case 7: return BuildingUtils::GIDfrom(1024,0);
   case 8: return BuildingUtils::GIDfrom(0,16);
   case 9: return BuildingUtils::GIDtoID(16384);
   case 10: return BuildingUtils::GIDtoTeam(65535);
   case 11: return BuildingUtils::GIDfrom(-1,0) == Uint16(-1) ? 0 : 1;
   case 12: return BuildingUtils::GIDfrom(0,-1) == Uint16(-1024) ? 0 : 1;
  }
 }
 for(int team=0;team<TEAM_MAX_COUNT;++team) for(int id=0;id<1024;++id) {
  const auto u=UnitUtils::GIDfrom(id,team), b=BuildingUtils::GIDfrom(id,team);
  if(u != id+team*1024 || u != b || u == UINT16_MAX || UnitUtils::GIDtoID(u)!=id || UnitUtils::GIDtoTeam(u)!=team || BuildingUtils::GIDtoID(b)!=id || BuildingUtils::GIDtoTeam(b)!=team) return 1;
 }
 return 0;
}
