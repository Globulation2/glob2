from pathlib import Path
import json,hashlib,subprocess,concurrent.futures,time,os,signal,resource,fcntl,sys,gzip,shutil
from telemetry import summarize
p=Path(__file__).resolve().parent;cfg=json.loads((p/'protocol.json').read_text());manifest=json.loads((p/'manifest.json').read_text());runs=p/'runs';runs.mkdir(exist_ok=True)
lock=(p/'dispatcher.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert hashlib.sha256((p/'protocol.json').read_bytes()).hexdigest()==manifest['protocol_sha256']
for name,digest in cfg['tools_sha256'].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest
for a,v in cfg['binaries'].items():assert hashlib.sha256((p/v['path']).read_bytes()).hexdigest()==v['sha256']
def write(path,v):
 tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(v,indent=2)+'\n');os.replace(tmp,path)
def command(j,d):
 cmd=[str(p/cfg['binaries'][j['arm']]['path']),'game','run','--map-file',str(p/j['map']),'--game-seed',str(j['game_seed']),'--ticks',str(cfg['tick_cap']),'--compute-threads',str(cfg['participants']),'--gpu','off','--telemetry','team-timeline','--output-dir',str(d/'game')]
 for ai in j['players']:cmd+=['--player',ai]
 for a in j['alliances']:cmd+=['--alliance',str(a)]
 cmd+=['--win-condition','allies' if j['format']=='teams4v4' else 'death']
 return cmd
def run(j):
 d=runs/j['id'];d.mkdir(exist_ok=True)
 if (d/'attempt.json').exists():return json.loads((d/'attempt.json').read_text())
 if (d/'started.json').exists():raise RuntimeError('Unfinished attempt; refuse replacement: '+j['id'])
 assert hashlib.sha256((p/j['map']).read_bytes()).hexdigest()==j['map_sha256']
 cmd=command(j,d);started=time.time();write(d/'started.json',dict(command=cmd,start_time=started,job=j))
 env=os.environ.copy();env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
 # prlimit avoids fork preexec hooks in the threaded dispatcher.
 full=['prlimit',f"--as={cfg['virtual_memory_limit_bytes']}",'--']+cmd
 timedout=False
 with (d/'stdout.log').open('w') as log:
  proc=subprocess.Popen(full,cwd='/home/bradley/glob2-hiring-profile-20261013',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=proc.wait(timeout=cfg['timeout_seconds'])
  except subprocess.TimeoutExpired:
   timedout=True;os.killpg(proc.pid,signal.SIGTERM)
   try:rc=proc.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);rc=proc.wait()
 error=None;ok=False
 try:
  result=json.loads((d/'game/result.json').read_text());assert rc==0 and not timedout and result['status']=='completed'
  summary=summarize(d/'stdout.log',result,j);write(d/'summary.json',summary);ok=True
 except Exception as e:error=repr(e)
 attempt=dict(id=j['id'],arm=j['arm'],stratum=j['stratum'],completed=ok,returncode=rc,timed_out=timedout,error=error,elapsed_seconds=time.time()-started,command=full)
 raw=d/'stdout.log'; packed=d/'stdout.log.gz'
 with raw.open('rb') as src:digest=hashlib.file_digest(src,'sha256').hexdigest()
 with raw.open('rb') as src,gzip.open(packed,'wb',compresslevel=1) as dst:shutil.copyfileobj(src,dst)
 with gzip.open(packed,'rb') as src:
  check=hashlib.file_digest(src,'sha256').hexdigest()
 assert check==digest
 if ok:attempt['summary_sha256']=hashlib.sha256((d/'summary.json').read_bytes()).hexdigest()
 attempt['stdout_sha256']=digest;attempt['compressed_stdout_sha256']=hashlib.sha256(packed.read_bytes()).hexdigest();raw.unlink()
 write(d/'attempt.json',attempt);return attempt
attempts=[];start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=cfg['concurrent']) as ex:
 futures={ex.submit(run,j):j for j in manifest['games']}
 for future in concurrent.futures.as_completed(futures):
  a=future.result();attempts.append(a)
  progress=dict(attempted=len(attempts),total=cfg['total_games'],completed=sum(x['completed'] for x in attempts),failures=sum(not x['completed'] for x in attempts),elapsed_seconds=time.time()-start,updated_at=time.time())
  write(p/'progress.json',progress)
  if not a['completed']:print('TECHNICAL FAILURE',a['id'],a['error'],flush=True)
  if len(attempts)%100==0:print('attempted',len(attempts),'/',cfg['total_games'],flush=True)
assert len(attempts)==cfg['total_games'];write(p/'finished.json',progress)
subprocess.run([str(p/'analysis-venv/bin/python'),str(p/'analyze.py')],check=True)
