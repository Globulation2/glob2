from pathlib import Path
import subprocess,json,collections,time
from telemetry import summarize
p=Path(__file__).resolve().parent;c=json.loads((p/'protocol.json').read_text());results=[]
for gen in c['generators']:
 for size in c['sizes']:
  for fmt,n in c['formats'].items():
   stem=p/'preflight-v2'/f'{gen}-{size}-{fmt}';stem.parent.mkdir(exist_ok=True)
   cmd=[str(p/'glob2-original'),'map','generate',gen,'--seed','123','--width',str(size),'--height',str(size),'--teams',str(n),'--workers','4','--output',str(stem)+'.map','--report-file',str(stem)+'.json']
   with Path(str(stem)+'-map.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
   assert r.returncode==0,(gen,size,fmt)
   for arm in c['arms']:
    for mix,cycle in c['mixes'].items():
     players=[cycle[i%len(cycle)] for i in range(n)];alliances=[1]*(n//2)+[2]*(n//2) if fmt=='teams4v4' else list(range(1,n+1));d=Path(str(stem)+f'-{arm}-{mix}');logfile=Path(str(d)+'.log')
     cmd=[str(p/('glob2-'+arm)),'game','run','--map-file',str(stem)+'.map.gz','--game-seed','456','--ticks','1024','--compute-threads','4','--gpu','off','--telemetry','team-timeline','--output-dir',str(d)]
     for ai in players:cmd+=['--player',ai]
     for a in alliances:cmd+=['--alliance',str(a)]
     cmd+=['--win-condition','allies' if fmt=='teams4v4' else 'death']
     with logfile.open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=60)
     assert r.returncode==0,(arm,gen,size,fmt,mix)
     result=json.loads((d/'result.json').read_text());j=dict(id=d.name,arm=arm,stratum=d.name,generator=gen,size=size,format=fmt,mix=mix,players=players)
     summarize(logfile,result,j) # Validate schema only; no between-arm gameplay comparison.
     results.append(dict(arm=arm,generator=gen,size=size,format=fmt,mix=mix,returncode=r.returncode))
   print('schema preflight',gen,size,fmt,flush=True)
(p/'preflight.json').write_text(json.dumps(dict(schema_checks=len(results),cases=results),indent=2))
