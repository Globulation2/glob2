from pathlib import Path
import time,json,subprocess,hashlib,fcntl,os
p=Path(__file__).resolve().parent
lock=(p/'launcher.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
while not (p/'manifest.json').exists():
 time.sleep(10)
c=json.loads((p/'protocol.json').read_text());m=json.loads((p/'manifest.json').read_text());assert len(m['games'])==c['total_games']
assert m['protocol_sha256']==hashlib.sha256((p/'protocol.json').read_bytes()).hexdigest()
from collections import Counter
counts=Counter((j['stratum'],j['arm']) for j in m['games']);assert len(counts)==288 and set(counts.values())=={20}
(p/'launch.json').write_text(json.dumps(dict(launch_time=time.time(),manifest_sha256=hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest(),protocol_sha256=m['protocol_sha256'],count=len(m['games'])),indent=2)+'\n')
r=subprocess.run(['python3',str(p/'run.py')],cwd='/home/bradley/glob2-hiring-profile-20261013')
(p/'pipeline-status.json').write_text(json.dumps(dict(returncode=r.returncode,finished_exists=(p/'finished.json').exists(),findings_exists=(p/'findings.json').exists(),time=time.time()),indent=2)+'\n')
print('COHORT PIPELINE RETURNED',r.returncode,flush=True)
