from pathlib import Path
import time,tarfile,hashlib,json
p=Path(__file__).resolve().parent
while not (p/'manifest.json').exists():time.sleep(10)
archive=p/'frozen-inputs.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name in ['protocol.json','manifest.json','input-plan.json','preflight.json','preflight.log','preflight-initial-failure.log','analysis-sanity.log','analysis-sanity-initial-failure.log','analysis-install.log','host.txt','generation.log','launch.json']:
  f=p/name
  if f.exists():tar.add(f,arcname=name)
 for f in sorted(p.glob('*.py')):tar.add(f,arcname=f.name)
 tar.add(p/'inputs',arcname='inputs')
with archive.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
(p/'input-archive.json').write_text(json.dumps(dict(file=archive.name,bytes=archive.stat().st_size,sha256=digest),indent=2)+'\n');print('INPUTS RETAINED',digest,flush=True)
