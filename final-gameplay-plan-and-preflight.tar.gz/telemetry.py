from pathlib import Path
import re,json,collections
from game_telemetry import parse

def summarize(log,result,job):
 finals={};timeline=collections.defaultdict(dict);econ=collections.defaultdict(dict);states={};history=collections.defaultdict(dict)
 for line in Path(log).open(errors='strict'):
  prefix=line.partition(' ')[0]
  if prefix not in {'GLOB2_MEASURE','GLOB2_MEASURE_HISTORY','GLOB2_TL','GLOB2_ECON','GLOB2_TIMELINE'}:continue
  typ,v=parse(line);t=int(v['team'])
  if typ=='GLOB2_MEASURE' and v.get('final')==1:finals[t]=v
  elif typ=='GLOB2_MEASURE_HISTORY':history[t][int(v['tick'])]=v
  elif typ=='GLOB2_TL':timeline[t][int(v['tick'])]=v
  elif typ=='GLOB2_ECON':econ[t][int(v['tick'])]=v
  elif typ=='GLOB2_TIMELINE':states[t]=v
 n=len(job['players']);assert set(finals)==set(range(n)),('missing final telemetry',list(finals));assert set(states)==set(range(n))
 total=lambda pattern:sum(v for m in finals.values() for k,v in m.items() if re.fullmatch(pattern,k))
 ticks=result['ticks'];unit_ticks=critical_ticks=0;trajectory={}
 for t in range(n):
  points=sorted(timeline[t].items());assert points and points[0][0]==0
  for i,(tick,v) in enumerate(points):
   end=min(ticks,points[i+1][0] if i+1<len(points) else ticks);unit_ticks+=v['units']*max(0,end-tick)
   trajectory.setdefault(tick,{'population':0,'colonies_with_units':0});trajectory[tick]['population']+=v['units'];trajectory[tick]['colonies_with_units']+=v['units']>0
  h=history[t]|{int(finals[t]['tick']):finals[t]};pts=sorted(h.items())
  for i,(tick,v) in enumerate(pts):critical_ticks+=v['critical']*max(0,min(ticks,pts[i+1][0] if i+1<len(pts) else ticks)-tick)
 worker=total(r'labour_\d+')+total(r'filling_\d+_\d+')
 assert worker>0 and unit_ticks>0, 'missing exposure'
 return {**{k:job[k] for k in ['id','arm','stratum','generator','size','format','mix','players']},'ticks':ticks,'termination':result['termination'],
 'colonies':n,'lost_colonies':sum(v['result']=='lost' for v in states.values()),'winners':[job['players'][t] for t,v in states.items() if v['result']=='won'],
 'worker_ticks':worker,'sampled_unit_ticks':unit_ticks,'sampled_critical_ticks':critical_ticks,
 'starvation_deaths':total(r'deaths_\d+_1'),'combat_deaths':total(r'deaths_\d+_0'),'other_deaths':total(r'deaths_\d+_[234]'),
 'new_buildings':total(r'completed_0_\d+_\d+'),'upgrades':total(r'completed_1_\d+_\d+'),'births':total(r'births_\d+'),'delivered':total(r'delivered_\d+'),'harvested':total(r'harvested_\d+'),'meals':total(r'meals'),
 'food_worker_ticks':total(r'labour_[123]'),'idle_worker_ticks':total(r'labour_0'),'filling_worker_ticks':total(r'filling_\d+_\d+'),
 'trajectory':trajectory,'team_final_measurements':finals,'team_economy':econ}
