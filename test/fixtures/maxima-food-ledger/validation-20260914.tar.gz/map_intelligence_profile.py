#!/usr/bin/env python3
"""Capture a macOS main-thread profile and estimate spatial-work headroom.

No engine instrumentation or gameplay changes. Estimates are sampling-window
sensitivity calculations, NOT measured cache reuse or promised speedups.
"""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import time


# Attribute exclusive samples to the nearest matching ancestor. This includes
# allocations/library work inside a computation without adding nested time twice.
GROUPS = {
    'food_residual_cache_check': ('AIMaximaFoodLedger::Ledger::prepareResidualSums(',),
    'food_ledger_other': ('AIMaximaFoodLedger::Ledger::',),
    'engine_fields': ('Map::propagateGradient(', 'Map::updateGlobalGradient(',
                      'Map::updateResourcesGradient(', 'Map::updateRoundTripGradient(',
                      'Map::updateGuardAreasGradient(', 'Map::updateClearAreasGradient(',
                      'Map::updateForbiddenGradient('),
    'maxima_placement': ('AIMaximaPlacement::Planner::',
                         'AIMaxima::Maxima::collect_development_world('),
    'maxima_farms': ('AIMaxima::Maxima::update_farming(',
                     'AIMaxima::Maxima::build_maintenance_clearing_plan(',
                     'AIMaxima::Maxima::initialize_farming_cache('),
    'maxima_topology': ('AIMaxima::Defense::',
                        'AIMaxima::Maxima::initialize_topology_profile(',
                        'AIMaxima::Maxima::update_preemptive_defense(',
                        'AIMaxima::Maxima::update_environment_model('),
    'ai_gradients': ('AIMaximaRuntime::Gradients::Gradient::',
                     'AIEcho::Gradients::Gradient::', 'Cabino::Gradient::'),
    'cortex_spatial': ('Cortex::placeCandidates', 'Cortex::placeForwardCandidate',
                       'Cortex::placeFlagTargets', 'Cortex::PlacementGeometry::',
                       'Cortex::assessSwim(', 'Cortex::assessAmphibious(',
                       'Cortex::scanWheatForbidden(', 'Cortex::reconcileWheatForbidden('),
    'castor_fields': tuple('AICastor::compute' + name for name in (
        'Obstacle', 'SpaceForBuilding', 'BuildingNeighbour', 'Work', 'Hydratation',
        'NotGrass', 'Wheat', 'Enemy', 'NeedSwim')),
    'other_ai_spatial': ('Cabino::GridPollingSystem::',
                         'Cabino::DistributedNewConstructionManager::findBestPlace(',
                         'Cabino::DistributedNewConstructionManager::updateImap(',
                         'Cabino::HappinessHandler::computeFruitTrees(',
                         'AIEcho::Construction::BuildingOrder::find_location(',
                         'AIWarrush::buildBuildingOfType(', 'AIWarrush::farm(',
                         'AINumbi::findNewEmplacement(', 'AINumbi::estimateFood('),
    'fertility': ('Fertility::', 'AIMaxima::Farming::ExactFertilityCache::'),
}


def category(name):
    for group, patterns in GROUPS.items():
        if any(pattern in name for pattern in patterns):
            return group
    return None


def analyze(text):
    rows, stack = [], []
    active = False
    for line in text.splitlines():
        if 'Thread_' in line:
            if active:
                break
            active = 'com.apple.main-thread' in line
        if not active:
            continue
        if line.startswith(('Total number', 'Sort by top', 'Binary Images')):
            break
        match = re.match(r'^([ +!|:]*)(\d+) (.+)$', line)
        if not match:
            continue
        depth, count, name = match.start(2), int(match[2]), match[3]
        while stack and rows[stack[-1]]['depth'] >= depth:
            stack.pop()
        parent = stack[-1] if stack else None
        inherited = rows[parent]['category'] if parent is not None else 'unclassified'
        if parent is not None:
            rows[parent]['children'] += count
        rows.append(dict(depth=depth, count=count, children=0, name=name,
                         category=category(name) or inherited))
        stack.append(len(rows) - 1)
    if not rows or 'Thread_' not in rows[0]['name']:
        raise ValueError('No symbolicated macOS main-thread call tree found')
    groups, leaves = Counter(), Counter()
    for row in rows:
        own = row['count'] - row['children']
        if own < 0:
            raise ValueError('Malformed tree: child samples exceed parent samples')
        groups[row['category']] += own
        leaves[row['name'].split('  (in ')[0]] += own
    total = rows[0]['count']
    if total <= 0 or sum(groups.values()) != total:
        raise ValueError('Sample totals do not reconcile')
    spatial = total - groups['unclassified']
    fraction = spatial / total
    scenarios = []
    for removed in (0.25, 0.5, 0.75):
        saved = fraction * removed
        scenarios.append(dict(assumed_fraction_of_candidate_work_removed=removed,
                              modeled_total_time_reduction=saved,
                              modeled_speedup=1 / (1 - saved)))
    return dict(schema_version=1, main_thread_samples=total,
                candidate_samples=spatial, candidate_fraction=fraction,
                groups={k: dict(samples=v, fraction=v / total)
                        for k, v in groups.most_common()},
                top_exclusive_symbols=[dict(symbol=k, samples=v, fraction=v / total)
                                       for k, v in leaves.most_common(20)],
                scenarios=scenarios,
                limitations=['One sampled main-thread wall-time window; not full-match CPU attribution.',
                             'Categories are broad optimization candidates, not proven shareable work.',
                             'Scenarios assume zero added overhead and a representative window.',
                             'No cache-hit, invalidation, memory-bandwidth or duplicate-input measurement.'])


def sha(path):
    with open(path, 'rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def capture(args):
    if platform.system() != 'Darwin':
        raise ValueError('capture requires macOS /usr/bin/sample; analyze is portable')
    cmd = args.command
    if cmd and cmd[0] == '--':
        cmd = cmd[1:]
    if len(cmd) < 2 or cmd[1] != '--run-game' or '--output-dir' in cmd:
        raise ValueError('supply BINARY --run-game ... without --output-dir')
    cmd[0] = str(Path(cmd[0]).resolve(strict=True))
    inputs = {}
    for flag in ('--map-file', '--load-game'):
        if flag in cmd:
            index = cmd.index(flag) + 1
            cmd[index] = str(Path(cmd[index]).resolve(strict=True))
            inputs[flag] = dict(path=cmd[index], sha256=sha(cmd[index]))
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    cmd += ['--output-dir', str(out / 'game')]
    metadata = dict(command=cmd, binary_sha256=sha(cmd[0]), inputs=inputs,
                    machine=platform.platform(), sampling_duration=args.duration,
                    sampling_delay=args.delay, sampling_interval_ms=args.interval)
    metadata['source_commit'] = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], text=True).strip()
    metadata['tracked_diff_sha256'] = hashlib.sha256(subprocess.check_output(
        ['git', 'diff', 'HEAD'])).hexdigest()
    (out / 'command.json').write_text(json.dumps(metadata, indent=2) + '\n')
    started = time.monotonic()
    with (out / 'stdout.log').open('w') as log:
        process = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT)
        try:
            if args.duration:
                time.sleep(args.delay)
                sampled = subprocess.run(
                    ['/usr/bin/sample', str(process.pid), str(args.duration),
                     str(args.interval), '-mayDie', '-file', str(out / 'sample.txt')],
                    capture_output=True, text=True)
                (out / 'sampler.log').write_text(sampled.stdout + sampled.stderr)
                metadata['sampler_exit'] = sampled.returncode
            _, status, usage = os.wait4(process.pid, 0)
            process.returncode = os.waitstatus_to_exitcode(status)
        except BaseException:
            process.terminate()
            process.wait()
            raise
    metadata.update(exit_code=process.returncode, wall_seconds=time.monotonic() - started,
                    user_seconds=usage.ru_utime, system_seconds=usage.ru_stime,
                    peak_rss_bytes=usage.ru_maxrss)
    # Wall includes waiting for the sampler when the game is shorter than capture.
    metadata['wall_note'] = 'For uncontaminated wall timing use --duration 0; user/sys are game-only.'
    result = out / 'game/result.json'
    if result.exists():
        game = json.loads(result.read_text())
        metadata['ticks'] = game.get('ticks')
        metadata['termination'] = game.get('termination')
    (out / 'measurement.json').write_text(json.dumps(metadata, indent=2) + '\n')
    if (out / 'sample.txt').exists():
        try:
            report = analyze((out / 'sample.txt').read_text())
        except ValueError as error:
            report = dict(error=str(error))
        (out / 'analysis.json').write_text(json.dumps(report, indent=2) + '\n')
    print(out)
    return process.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='mode', required=True)
    read = commands.add_parser('analyze')
    read.add_argument('sample', type=Path)
    run = commands.add_parser('capture')
    run.add_argument('--output', required=True)
    run.add_argument('--delay', type=float, default=2)
    run.add_argument('--duration', type=int, default=10, help='0 disables sampling')
    run.add_argument('--interval', type=int, default=1, help='sampling interval in milliseconds')
    run.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.mode == 'analyze':
        print(json.dumps(analyze(args.sample.read_text()), indent=2))
        return 0
    if args.delay < 0 or args.duration < 0 or args.interval < 1:
        parser.error('delay/duration must be nonnegative; interval must be positive')
    return capture(args)


if __name__ == '__main__':
    raise SystemExit(main())
