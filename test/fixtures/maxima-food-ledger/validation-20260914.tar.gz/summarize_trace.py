import csv, hashlib, struct, sys
from pathlib import Path

def summarize(path):
    rows=[]
    with Path(path).open('rb') as f:
        assert f.read(4)==b'GCS1'
        teams,players,count,flags=struct.unpack('<4I',f.read(16))
        for _ in range(count):
            h=hashlib.sha256()
            def read(n):
                data=f.read(n)
                assert len(data)==n
                h.update(data)
                return data
            tick,checksum=struct.unpack('<2I',read(8))
            units=buildings=0
            for team in range(teams):
                read(4)
                for kind in range(2):
                    n=struct.unpack('<I',read(4))[0]
                    if kind==0:units+=n
                    else:buildings+=n
                    for item in range(n):
                        gid,cs,size=struct.unpack('<HII',read(10))
                        read(size*4)
            rows.append((tick,checksum,h.hexdigest(),units,buildings))
        assert not f.read(1)
    return rows
if __name__=='__main__':
    rows=summarize(sys.argv[1])
    with open(sys.argv[2],'w') as f:
        w=csv.writer(f);w.writerow(['tick','checksum','record_sha256','units','buildings']);w.writerows(rows)
    print(len(rows),'ticks',sys.argv[2])
