import hashlib, json, os, subprocess, time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=root/'artifacts/maxima-residual-sums'
initial=root/'artifacts/map-intelligence-pilot/mixed8/initial.game'
def run(name, command):
    started=time.monotonic()
    with (out/(name+'.log')).open('w') as log:
        child=subprocess.Popen(list(map(str,command)),stdout=log,stderr=subprocess.STDOUT,cwd=root)
        _,status,usage=os.wait4(child.pid,0)
        child.returncode=os.waitstatus_to_exitcode(status)
    result=dict(command=list(map(str,command)),exit_code=child.returncode,wall_seconds=time.monotonic()-started,user_seconds=usage.ru_utime,system_seconds=usage.ru_stime,peak_rss_bytes=usage.ru_maxrss)
    result['binary_sha256']=hashlib.sha256(Path(command[0]).read_bytes()).hexdigest()
    (out/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(name,result['exit_code'],round(usage.ru_utime+usage.ru_stime,3),flush=True)
    if child.returncode: raise SystemExit(child.returncode)
if __name__=='__main__':
    for revision in ('before','after'):
        run('kernel-'+revision,[out/('ledger-'+revision),'--benchmark'])
    for revision in ('before','after'):
        binary=out/'glob2-before' if revision=='before' else root/'build/src/glob2'
        run('match-'+revision,[binary,'--run-game','--load-game',initial,'--ticks','12000','--telemetry','checksums','--save','every:6000','--save','final','--output-dir',out/('match-'+revision)])
