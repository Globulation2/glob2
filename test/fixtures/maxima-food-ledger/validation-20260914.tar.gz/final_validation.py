from run_validation import run,out,root,initial
run('match-final',[root/'build/src/glob2','--run-game','--load-game',initial,'--ticks','12000','--telemetry','checksums','--save','every:6000','--save','final','--output-dir',out/'match-final'])
run('maxima4-final',[root/'build/src/glob2','--run-game','--load-game',out/'linux/maxima4-initial.game','--ticks','4096','--telemetry','checksums','--save','every:2048','--save','final','--output-dir',out/'maxima4-final'])
run('maxima4-resumed-final',[root/'build/src/glob2','--run-game','--load-game',out/'maxima4-final/checkpoint-2048.game','--ticks','4096','--telemetry','checksums','--save','final','--output-dir',out/'maxima4-resumed-final'])
