from run_validation import run,out,root
run('before-resumed-probe',[out/'glob2-before','--run-game','--load-game',out/'match-before/checkpoint-6000.game','--ticks','6016','--telemetry','checksums','--output-dir',out/'before-resumed-probe'])
run('maxima4',[root/'build/src/glob2','--run-game','--load-game',out/'linux/maxima4-initial.game','--ticks','4096','--telemetry','checksums','--save','every:2048','--save','final','--output-dir',out/'maxima4'])
run('maxima4-resumed',[root/'build/src/glob2','--run-game','--load-game',out/'maxima4/checkpoint-2048.game','--ticks','4096','--telemetry','checksums','--save','final','--output-dir',out/'maxima4-resumed'])
