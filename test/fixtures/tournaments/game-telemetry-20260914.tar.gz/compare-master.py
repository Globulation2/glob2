import json, os, pathlib, subprocess, sys
sys.path.insert(0, 'test')
from tournament_cli_integration import tick_records
root=pathlib.Path('output/tournament-telemetry').resolve()
master=pathlib.Path('/tmp/glob2-telemetry-master/build/src/glob2')
branch=pathlib.Path('build/src/glob2').resolve()
base=root/'master-comparison';base.mkdir()
commands=[]
def run(name,binary,args):
 out=base/name
 command=[str(binary),*args,'--output-dir',str(out)]
 with (base/(name+'.log')).open('w') as log:
  subprocess.run(command,check=True,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,HOME=str(base/'home')),timeout=180)
 commands.append(command)
 return out
(base/'home').mkdir()
mapdir=run('map',master,['--generate-map','--generator','15','--map-seed','42','--param','width=7','--param','height=7','--param','teams=2','--write-map','true'])
evidence=[]
for a,b in [('numbi','castor'),('warrush','econo'),('nicowar','cortex'),('maxima','cabino')]:
 name=a+'-'+b
 fixture=run(name+'-fixture',master,['--run-game','--map-file',str(mapdir/'map-r0.map'),'--game-seed','19','--player',a,'--player',b,'--ticks','513','--save','initial','--save','final'])
 for suffix,save in [('initial','initial.game'),('continuation','final.game')]:
  args=['--run-game','--load-game',str(fixture/save),'--ticks','2048','--telemetry','checksums']
  reference=run(name+'-'+suffix+'-master',master,args)
  changed=run(name+'-'+suffix+'-branch',branch,args+['--telemetry','team-timeline'])
  x=tick_records(reference/'game.replay.checksums');y=tick_records(changed/'game.replay.checksums')
  assert x==y,(name,suffix,next((t for t in x if x[t]!=y.get(t)),None))
  r=json.loads((reference/'result.json').read_text());s=json.loads((changed/'result.json').read_text())
  assert r['teams']==s['teams'] and r['winning_teams']==s['winning_teams']
  evidence.append({'players':[a,b],'start':suffix,'compared_ticks':len(x),'checksums_equal':True,'outcomes_equal':True})
  print(evidence[-1],flush=True)
(base/'verification.json').write_text(json.dumps({'master':'1537cb280','comparisons':evidence,'commands':commands},indent=2))
