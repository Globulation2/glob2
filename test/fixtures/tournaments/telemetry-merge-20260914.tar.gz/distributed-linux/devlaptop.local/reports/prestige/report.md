# telemetry-devlaptop.local

Policy: prestige, version 1. Results: 7/7.

Elo starts at 1500, K=32, in manifest order. FFA updates are simultaneous and normalized by opponent count.

| Format | Competitor | Elo |
| --- | --- | ---: |

Uncertainty uses 0 complete map/seed blocks, seed 19.
Raw observations, failures, configurations, pairing and distribution summaries are in the adjacent JSON and CSV files.

## Map telemetry

| Generator | Revision | Maps | Missing traces | Incomplete traces |
| --- | --- | ---: | ---: | ---: |
| 15 | 1 | 3 | 0 | 0 |
| 15 | 1 | 1 | 0 | 0 |
| 22 | 2 | 3 | 0 | 0 |

Groups retain complete configuration and build identity in map-telemetry.json.
Numeric summaries average within each map before pooling maps. Raw sequence and subject are preserved.
Observed fallback/choice rates may undercount when traces are missing or incomplete.
