import os,json,subprocess,time
from pathlib import Path
r=Path.cwd();b=r/'artifacts/ci-recovery';d=b/'menu-latest-integration-evidence';w=b/'menu-latest-integration';runtime=w/'build/emscripten/client/release'
env=dict(os.environ,GLOB2_TEST_URL='http://127.0.0.1:8830',GLOB2_TEST_BUILD_DIR=str(runtime),GLOB2_TEST_RENDERER='software',GLOB2_FIREFOX_HEADED='1',PLAYWRIGHT_JUNIT_OUTPUT_FILE=str(d/'browser-junit.xml'),CCACHE='1');env['PATH']=str(b/'node/node_modules/.bin')+':'+env['PATH']
state={'pid':os.getpid(),'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'base':'8382dc99c127ba0cb2578e8903d22b754493a95a','scope':'Exact latest-master telemetry integration plus both fixture-only repairs; both release runtimes, complete Node contracts and24 original cases3browsers. Separate worktree/outputs; existing native/fullbrowser/source/SDL untouched. Shared dependencies use unchanged content-addressed fingerprints; no compiler/SDK/recipe/pin overrides.' ,'results':[]}
def save(phase):state['phase']=phase;(d/'status.json').write_text(json.dumps(state,indent=2)+'\n')
config=d/'playwright.config.cjs';config.write_text('const base=require('+json.dumps(str(w/'browser/playwright.config.js'))+');module.exports={...base,testDir:'+json.dumps(str(w/'browser/tests'))+',testMatch:["marathi.spec.js","campaign-progress.spec.js"],workers:1,reporter:[["list"],["junit"]]};')
steps=[('build',['scons','target=web','release=1','-j8','web-package']),('npm',['npm','ci','--prefix','browser']),('node',['node','--test',*map(str,sorted((w/'browser/unit').glob('*.test.js')))]),('browser',['xvfb-run','-a','-s','-screen 0 2560x2048x24 -noreset','node',str(w/'browser/node_modules/@playwright/test/cli.js'),'test','--config='+str(config),'--output='+str(d/'results'),'--trace=retain-on-failure'])]
for name,cmd in steps:
 save(name);started=time.monotonic();server=None
 with(d/(name+'.log')).open('w')as log:
  try:
   if name=='browser':
    serverlog=(d/'server.log').open('w');server=subprocess.Popen(['python3',str(b/'serve_ci_layout.py'),'8830','--directory',str(runtime)],stdout=serverlog,stderr=subprocess.STDOUT)
   code=subprocess.call(cmd,cwd=w,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  finally:
   if server:server.terminate();server.wait();serverlog.close()
 state['results'].append({'name':name,'command':cmd,'exit_code':code,'seconds':round(time.monotonic()-started,1)});save(name+' finished')
 if code:save('failed; inspect actual log before any rerun');raise SystemExit(code)
save('finished; inspect all results')
