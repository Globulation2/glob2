# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: campaign-progress.spec.js >> campaign persistence failure preserves the durable backup with discard
- Location: browser/tests/campaign-progress.spec.js:75:44

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 60000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [aria-hidden]:
    - status: Starting the game…
    - generic:
      - progressbar
      - generic: 41 of 41 MB
    - combobox
    - paragraph: The first visit downloads the game once. Later visits start from this device's copy.
  - generic "Globulation 2" [active] [ref=e3]
```

# Test source

```ts
  1   | const {waitForMainMenu}=require('./main-menu');
  2   | const {test,expect}=require('@playwright/test');
  3   | const {clickMainMenu,gameURL,clickControl,clickListRow}=require('./main-menu');
  4   | const fs=require('node:fs/promises');
  5   | const state=page=>page.evaluate(()=>glob2Diagnostics.snapshot());
  6   | const screen=async(page,name)=>{
  7   |   if(name==='MainMenuScreen') {
  8   |     await expect.poll(async()=>{
  9   |       const s=await state(page);
  10  |       if(/MainMenuScreen|IntroductionOfferScreen/.test(s.screen+' '+s.screenClass)) return true;
  11  |       if(s.screen.includes('CampaignMainMenu') && s.controls.back?.enabled) {
  12  |         await clickControl(page,'back');
  13  |         // A consumed Back starts the transition. Do not send it again while
  14  |         // the old screen name remains published with its controls removed.
  15  |         return true;
  16  |       }
  17  |       return false;
> 18  |     }, {timeout:60000}).toBe(true);
      |                         ^ Error: expect(received).toBe(expected) // Object.is equality
  19  |     return waitForMainMenu(page);
  20  |   }
  21  |   return expect.poll(async()=>(await state(page)).screen).toContain(name);
  22  | };
  23  | const stored=page=>page.evaluate(()=>glob2Diagnostics.campaignDigest('Browser_Test_Campaign.txt'));
  24  | const fixture=require('node:fs').readFileSync(require('node:path').resolve(__dirname,'../../test/fixtures/campaign/Browser_Test_Campaign.txt'),'utf8');
  25  | async function campaign(page) {
  26  |   // A fixture definition is file input only; all progress and UI changes use real controls.
  27  |   await page.evaluate(text=>FS.writeFile('/campaigns/Browser_Test_Campaign.txt',text),fixture);
  28  |   await clickMainMenu(page,'campaign');await screen(page,'CampaignMainMenu');
  29  |   await clickControl(page,(await stored(page)) ? 'load' : 'new');await screen(page,'CampaignSelectorScreen');
  30  |   await clickListRow(page,'campaigns',0);await clickControl(page,'ok');
  31  |   await screen(page,'CampaignMenuScreen');
  32  | }
  33  | async function backup(page) {
  34  |   const downloading=page.waitForEvent('download');await clickControl(page,'export');
  35  |   const download=await downloading;expect(download.suggestedFilename()).toBe('campaign-progress.campaign');
  36  |   return fs.readFile(await download.path());
  37  | }
  38  | async function restore(page,buffer) {
  39  |   const selecting=page.waitForEvent('filechooser');await clickControl(page,'import');
  40  |   await (await selecting).setFiles({name:'backup.campaign',mimeType:'application/octet-stream',buffer});
  41  | }
  42  | // Produce a prior-progress fixture from an actual exported campaign definition.
  43  | // Tests deliver it through the user's file chooser, never by editing game state.
  44  | function completedFirst(original) {
  45  |   const bytes=Buffer.from(original);let offset=8;
  46  |   const text=()=>{const length=bytes.readUInt32BE(offset);offset+=4+length;};
  47  |   expect(bytes.subarray(0,4).toString()).toBe('G2CP');
  48  |   text();text();const count=bytes.readUInt32BE(offset);offset+=4;expect(count).toBeGreaterThan(0);
  49  |   text();text();const prerequisites=bytes.readUInt32BE(offset);offset+=4;
  50  |   for(let i=0;i<prerequisites;i++)text();
  51  |   bytes[offset]=1;bytes[offset+1]=1;
  52  |   return bytes;
  53  | }
  54  | 
  55  | test.beforeEach(async({page})=>{test.setTimeout(180000);await page.goto(gameURL());await screen(page,'MainMenuScreen');});
  56  | 
  57  | test('campaign progress merges through the chooser, survives reload and rejects invalid backups',async({page},info)=>{
  58  |   await campaign(page);
  59  |   const initial=await backup(page), completed=completedFirst(initial);
  60  |   await restore(page,completed);await expect.poll(async()=>(await state(page)).import).toBe('succeeded');
  61  |   expect(await backup(page)).toEqual(completed);
  62  |   await page.screenshot({path:info.outputPath('campaign-progress-import.png')});
  63  |   await page.reload();await screen(page,'MainMenuScreen');await campaign(page);
  64  |   expect(await backup(page)).toEqual(completed);
  65  |   const future=Buffer.from(completed);future.writeUInt32BE(2,4);
  66  |   const mismatched=Buffer.from(completed);mismatched[12]^=1; // campaign identity
  67  |   for(const invalid of [completed.subarray(0,3),completed.subarray(0,completed.length-1),future,mismatched]) {
  68  |     await restore(page,invalid);await expect.poll(async()=>(await state(page)).import).toBe('invalid');
  69  |     expect(await backup(page)).toEqual(completed);
  70  |   }
  71  |   await restore(page,initial);await expect.poll(async()=>(await state(page)).import).toBe('succeeded');
  72  |   expect(await backup(page)).toEqual(completed); // importing an older backup cannot erase progress
  73  | });
  74  | 
  75  | for(const recovery of ['retry','discard']) test(`campaign persistence failure preserves the durable backup with ${recovery}`,async({page,context},info)=>{
  76  |   await campaign(page);const initial=await backup(page);
  77  |   await clickControl(page,'exit');await screen(page,'MainMenuScreen');
  78  |   const original=await stored(page);expect(original).not.toBeNull();
  79  |   await campaign(page);
  80  |   await page.evaluate(()=>{
  81  |     window.campaignQuota=true;
  82  |     const put=IDBObjectStore.prototype.put;
  83  |     IDBObjectStore.prototype.put=function(...args){
  84  |       if(window.campaignQuota)throw new DOMException('Injected quota exhaustion','QuotaExceededError');
  85  |       return put.apply(this,args);
  86  |     };
  87  |   });
  88  |   const completed=completedFirst(initial);
  89  |   await restore(page,completed);await expect.poll(async()=>(await state(page)).import).toBe('failed');
  90  |   await screen(page,'CampaignMenuScreen');
  91  |   expect(await backup(page)).toEqual(completed);
  92  |   await page.screenshot({path:info.outputPath('campaign-persistence-failure.png')});
  93  |   const recovered=await context.newPage();await recovered.goto(gameURL());await screen(recovered,'MainMenuScreen');
  94  |   expect(await stored(recovered)).toEqual(original);await recovered.close();
  95  |   await page.evaluate(()=>window.campaignQuota=false);
  96  |   if(recovery==='retry') {
  97  |     await clickControl(page,'retry');await expect.poll(async()=>(await state(page)).import).toBe('succeeded');
  98  |   } else {
  99  |     await clickControl(page,'exit');await screen(page,'MainMenuScreen');
  100 |     await expect.poll(async()=>(await state(page)).persistence).toBe('persisted');
  101 |   }
  102 |   await page.reload();await screen(page,'MainMenuScreen');await campaign(page);
  103 |   expect(await backup(page)).toEqual(recovery==='retry'?completed:initial);
  104 | });
  105 | 
  106 | test('leaving a new campaign waits for persistence and discard removes its uncommitted file',async({page})=>{
  107 |   await campaign(page);
  108 |   await page.evaluate(()=>{
  109 |     window.campaignQuota=true;
  110 |     const put=IDBObjectStore.prototype.put;
  111 |     IDBObjectStore.prototype.put=function(...args){
  112 |       if(window.campaignQuota)throw new DOMException('Injected quota exhaustion','QuotaExceededError');
  113 |       return put.apply(this,args);
  114 |     };
  115 |   });
  116 |   await clickControl(page,'exit');
  117 |   await expect.poll(async()=>(await state(page)).import).toBe('failed');
  118 |   await screen(page,'CampaignMenuScreen');
```