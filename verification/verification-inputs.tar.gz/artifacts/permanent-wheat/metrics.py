import json,shlex,collections
def analyze(out,start=0,end=None):
 result=json.loads((out/'result.json').read_text());actual=result['ticks'];end=actual if end is None else end
 scopes={};econ=[];measure=[];all_econ=collections.defaultdict(dict)
 with (out/'stdout.log').open(errors='replace') as f:
  for l in f:
   if l.startswith('GLOB2_PERF_FINAL '):
    d=dict(x.split('=',1) for x in shlex.split(l)[1:] if '=' in x)
    if d.get('scope')!='ai.player':scopes[d['scope']]={k:d[k] for k in ['calls','total_ns','self_ns'] if k in d}
   elif l.startswith('GLOB2_ECON '):
    d=dict(x.split('=',1) for x in l.split()[1:] if '=' in x)
    t=int(d['tick']);pop=sum(int(d[k]) for k in ['workers','warriors','explorers']);all_econ[t][int(d['team'])]=pop
    if d.get('team')=='0' and t<=end:econ.append((t,pop))
   elif l.startswith('GLOB2_MEASURE '):
    d=dict(x.split('=',1) for x in l.split()[1:] if '=' in x)
    if d.get('team')=='0' and int(d['tick'])<=end:measure.append(d)
 econ=sorted(set(econ));measure=sorted({int(d['tick']):d for d in measure}.values(),key=lambda d:int(d['tick']))
 def delta(k):return int(measure[-1].get(k,0))-int(measure[0].get(k,0)) if measure else 0
 unit_ticks=sum((b[0]-a[0])*a[1] for a,b in zip(econ,econ[1:]));obs_ticks=econ[-1][0]-econ[0][0] if len(econ)>1 else 0
 all_full=sorted((t,sum(d.values())) for t,d in all_econ.items());all_common=[x for x in all_full if x[0]<=end]
 full_unit_ticks=sum((b[0]-a[0])*a[1] for a,b in zip(all_full,all_full[1:]));common_unit_ticks=sum((b[0]-a[0])*a[1] for a,b in zip(all_common,all_common[1:]));full_obs=all_full[-1][0]-all_full[0][0] if len(all_full)>1 else 0
 cpu=list(map(float,(out/'cpu.txt').read_text().split()));simticks=actual-start
 return {'all_team_unit_ticks_full_run':full_unit_ticks,'all_team_unit_ticks_common_window':common_unit_ticks,'mean_all_team_population_full_run':full_unit_ticks/full_obs if full_obs else None,'cpu_seconds':sum(cpu[:2]),'wall_seconds':cpu[2],'actual_ticks':actual,'simulation_ticks':simticks,'cpu_ms_per_tick':sum(cpu[:2])*1000/simticks,'common_end':end,'meals_common_window':delta('meals'),'harvested_common_window':delta('harvested_1'),'starved_common_window':sum(delta(f'deaths_{i}_1') for i in range(3)),'sampled_unit_ticks_common_window':unit_ticks,'mean_population_common_window':unit_ticks/obs_ticks if obs_ticks else None,'last_sample_population_common_window':econ[-1][1] if econ else None,'scopes_full_run':scopes}
