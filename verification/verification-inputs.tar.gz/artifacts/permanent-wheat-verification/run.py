from pathlib import Path
import json,subprocess,sys,random,concurrent.futures,socket
R=Path.cwd();V=R/'artifacts/permanent-wheat-verification';P=R/'artifacts/permanent-wheat';sys.path.insert(0,str(P));from metrics import analyze
host=sys.argv[1];cases=[c for c in json.loads((P/'cases.json').read_text()) if c['host']==host];cases.sort(key=lambda c:(-c['size'],c['id']))
variants=['week-ago','pre-farming','experiment-baseline','experiment-boundary']
def run(c):
 order=variants.copy();random.Random(92930+c['seed']+c['rotation']).shuffle(order)
 for v in order:
  out=V/'games'/c['id']/v;out.mkdir(parents=True,exist_ok=True)
  binary=R/'artifacts/farming-history'/f'glob2-{v}' if v in ['week-ago','pre-farming'] else V/f'glob2-{v}'
  cmd=[str(binary),'--run-game','--map-file',str(P/'maps'/f"{c['id']}.map"),'--game-seed',str(c['seed']),'--player','maxima','--player',c['opponent'],'--ticks','32768','--output-dir',str(out),'--telemetry','team-timeline','--replay','false']
  (out/'command.json').write_text(json.dumps(cmd))
  with (out/'stdout.log').open('w') as log:subprocess.run(['/usr/bin/time','-f','%U %S %e','-o',str(out/'cpu.txt'),*cmd],stdout=log,stderr=log,check=True,timeout=1800)
  assert json.loads((out/'result.json').read_text())['ticks']>0
 outs={v:V/'games'/c['id']/v for v in variants};outs.update({v:P/'games'/c['id']/v for v in ['master','permanent']})
 end=min(json.loads((o/'result.json').read_text())['ticks'] for o in outs.values())
 row={'case':c,'host':socket.gethostname(),'common_end':end,'variants':{v:analyze(o,end=end) for v,o in outs.items()}}
 (V/'games'/c['id']/'metrics.json').write_text(json.dumps(row,indent=2));print('CASE_DONE',c['id'],flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=int(sys.argv[2])) as ex:rows=list(ex.map(run,cases))
(V/f'{host}-results.json').write_text(json.dumps(rows,indent=2));print('DONE',len(rows),flush=True)
