from pathlib import Path
import json,subprocess,shlex
R=Path.cwd();V=R/'artifacts/permanent-wheat-verification';s=(R/'test/maxima/MaximaFarmingIntegrationTest.cpp').read_text();s=s[:s.index('int main()')]
files=[c['id'] for c in json.loads((R/'artifacts/permanent-wheat/cases.json').read_text())]
s+='''int main() {
 GlobalContainer container("glob2-farm-mask-audit");globalContainer=&container;container.runNoX=true;container.load();container.buildingsTypes.init();IntBuildingType::init();
 const char* names[]={'''+','.join(json.dumps(x) for x in files)+'''};
 for(const char* name:names) {
  Fixture f;f.ai.reset();std::string path=std::string("artifacts/permanent-wheat/maps/")+name+".map";
  BinaryInputStream input(new FileStreamBackend(fopen(path.c_str(),"rb")));assert(f.game.load(&input));
  f.player.setTeam(f.game.teams[0]);f.ai.reset(new AIMaxima::Maxima(&f.player));f.ai->context.initialize();
  auto& ai=*f.ai;auto& map=f.game.map;ai.budget.farming_enabled=true;ai.budget.farming_protection_enabled=true;
  ai.budget.farming_management_radius=0;ai.budget.farming_wheat_fertility_min=3276;
  for(int y=0;y<map.getH();++y)for(int x=0;x<map.getW();++x)map.setMapDiscovered(x,y,f.player.team->me);
  for(int round=0;round<6;++round) {
   ai.update_farming(ai.context);applyAreaContracts(f);
   uint64_t hash=1469598103934665603ULL;int wheat=0,all=0;
   for(size_t i=0;i<ai.farm_protection_mask.size();++i) {
    hash=(hash^ai.farm_protection_mask[i])*1099511628211ULL;
    hash=(hash^ai.wheat_farm_protection_mask[i])*1099511628211ULL;
    all+=bool(ai.farm_protection_mask[i]);wheat+=bool(ai.wheat_farm_protection_mask[i]);
   }
   std::cout<<"MASK "<<name<<" "<<round<<" "<<hash<<" "<<wheat<<" "<<all<<"\\n";
   for(int y=0;y<map.getH();++y)for(int x=0;x<map.getW();++x)if(map.isResourceTakeable(x,y,WHEAT)) {
    const int i=y*map.getW()+x;
    if(!ai.farm_protection_mask[i] && (i+round)%3==0)map.setNoResource(x,y,0);
    else map.getTile(x,y).resource.amount=1+(round%5);
   }
  }
 }
}
'''
(V/'mask-audit.cpp').write_text(s)
old=(V/'source/Farming-boundary_grid.cpp').read_text();current=(R/'src/ai/maxima/AIMaximaFarmingPolicy.cpp').read_text();fixed=old
for begin,end in [('std::vector<Uint8> Maxima::worker_reachable_circulation(', 'std::vector<std::vector<int> > Maxima::reservation_member_footprints('),('Maxima::WoodReserve Maxima::select_wood_reserve(', 'bool Maxima::wheat_invasion_clearing_required(')]:
 a=fixed.index(begin);b=fixed.index(end,a);x=current.index(begin);y=current.index(end,x);fixed=fixed[:a]+current[x:y]+fixed[b:]
(V/'boundary-reviewed.cpp').write_text(fixed)
lines=(R/'artifacts/permanent-wheat/build.log').read_text().splitlines();compile=next(shlex.split(l) for l in lines if l.startswith('g++ ') and l.endswith('src/ai/maxima/AIMaximaFarmingPolicy.cpp'));link=next(shlex.split(l) for l in lines if l.startswith('g++ -o build/darwin/client/release/src/glob2 '))
def comp(source,obj):
 cmd=compile.copy();cmd[cmd.index('-o')+1]=str(obj);cmd[-1]=str(source);cmd+=['-UNDEBUG']
 subprocess.run(cmd,stdout=log,stderr=log,check=True)
with (V/'mask-build.log').open('w') as log:
 main=V/'mask-audit.o';comp(V/'mask-audit.cpp',main)
 for label,source in [('current',None),('old',V/'source/Farming-boundary_grid.cpp'),('old-reviewed',V/'boundary-reviewed.cpp')]:
  obj=V/f'{label}.o'
  if source:comp(source,obj)
  cmd=link.copy();cmd[cmd.index('-o')+1]=str(V/f'mask-{label}')
  cmd=[str(main) if x.endswith('/Glob2.o') else str(obj) if source and x.endswith('/AIMaximaFarmingPolicy.o') else x for x in cmd]
  subprocess.run(cmd,stdout=log,stderr=log,check=True)
  with (V/f'mask-{label}.log').open('w') as out:subprocess.run([str(V/f'mask-{label}')],stdout=out,stderr=out,check=True)
print('MASK_AUDIT_DONE')
