from pathlib import Path
import subprocess,shlex,json,concurrent.futures,sys
R=Path.cwd();V=R/'artifacts/permanent-wheat-verification';P=R/'artifacts/permanent-wheat';sys.path.insert(0,str(R/'test'));from compare_save_continuation import compare
link=next(shlex.split(l) for l in (P/'build.log').read_text().splitlines() if l.startswith('g++ -o build/darwin/client/release/src/glob2 '));cmd=link.copy();cmd[cmd.index('-o')+1]=str(V/'glob2-reviewed-boundary');cmd=[str(V/'old-reviewed.o') if x.endswith('/AIMaximaFarmingPolicy.o') else x for x in cmd]
with (V/'orders-build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=log,check=True)
cases=[c for c in json.loads((P/'cases.json').read_text()) if c['base_seed']==6101 and c['rotation']==0 and c['generator'] in [1,15,52,58]]
def run(c):
 paths={}
 for v,binary in [('current',R/'build/darwin/client/release/src/glob2'),('reviewed-boundary',V/'glob2-reviewed-boundary')]:
  out=V/'order-check'/c['id']/v;out.mkdir(parents=True,exist_ok=True);paths[v]=out
  cmd=[str(binary),'--run-game','--map-file',str(P/'maps'/f"{c['id']}.map"),'--game-seed',str(c['seed']),'--player','maxima','--player','nicowar','--ticks','8192','--telemetry','checksums','--output-dir',str(out)]
  with (out/'stdout.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=log,check=True)
 try:return {'case':c['id'],'matching_ticks':compare(paths['current']/'game.replay.checksums',paths['reviewed-boundary']/'game.replay.checksums')}
 except Exception as e:return {'case':c['id'],'difference':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(run,cases))
(V/'order-check.json').write_text(json.dumps(rows,indent=2));print(rows)
