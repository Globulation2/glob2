from pathlib import Path
import json
V=Path(__file__).resolve().parent
rows={}
for name in ['current','old','old-reviewed']:
 rows[name]={tuple(l.split()[1:3]):l.split()[3:] for l in (V/f'mask-{name}.log').read_text().splitlines() if l.startswith('MASK ')}
 assert len(rows[name])==768,(name,len(rows[name]))
assert rows['current'].keys()==rows['old'].keys()==rows['old-reviewed'].keys()
out={}
for name in ['old','old-reviewed']:
 diffs=[{'map':k[0],'round':k[1],'current':rows['current'][k],'comparator':rows[name][k]} for k in rows['current'] if rows['current'][k]!=rows[name][k]]
 out[name]={'matching':768-len(diffs),'different':len(diffs),'differences':diffs}
(V/'mask-comparison.json').write_text(json.dumps(out,indent=2));print({k:{x:y for x,y in v.items() if x!='differences'} for k,v in out.items()})
