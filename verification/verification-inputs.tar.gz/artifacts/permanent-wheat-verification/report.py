from pathlib import Path
import json,math,statistics,random,collections
V=Path(__file__).resolve().parent;rows=[]
for h in ['therig','devlaptop']:rows+=json.loads((V/f'{h}-full-results.json').read_text())
assert len(rows)==128
comparisons=[('permanent','week-ago'),('permanent','pre-farming'),('permanent','experiment-baseline'),('permanent','experiment-boundary'),('permanent','master'),('experiment-boundary','experiment-baseline')]
groups=collections.defaultdict(list)
for r in rows:groups[r['case']['generator']].append(r)
families=sorted(groups)
def pooled(rs,a,b,k,field='variants'):
 den=sum(r[field][b][k] for r in rs);return sum(r[field][a][k] for r in rs)/den-1 if den else None
def fullgeo(rs,a,b):return math.exp(statistics.mean(math.log((r['full_variants'][a]['harvested_common_window']+1)/(r['full_variants'][b]['harvested_common_window']+1)) for r in rs))-1
def cpu(rs,a,b):return math.exp(statistics.mean(math.log(r['variants'][a]['cpu_ms_per_tick']/r['variants'][b]['cpu_ms_per_tick']) for r in rs))-1
def starvation(rs,a,b):
 rates=[sum(r['variants'][v]['starved_common_window'] for r in rs)/sum(r['variants'][v]['sampled_unit_ticks_common_window'] for r in rs) for v in [a,b]]
 return rates[0]/rates[1]-1 if rates[1] else None
metrics={'harvest_common':lambda rs,a,b:pooled(rs,a,b,'harvested_common_window'),'meals_common':lambda rs,a,b:pooled(rs,a,b,'meals_common_window'),'population_time_common':lambda rs,a,b:pooled(rs,a,b,'sampled_unit_ticks_common_window'),'harvest_full_geometric':fullgeo,'starvation_rate':starvation}
rng=random.Random(20260929);draws=[rng.choices(families,k=len(families)) for _ in range(5000)]
summary={}
for a,b in comparisons:
 result={}
 for k,f in metrics.items():
  dist=[f([r for fam in d for r in groups[fam]],a,b) for d in draws];dist=sorted(x for x in dist if x is not None)
  result[k]={'change':f(rows,a,b),'ci95':[dist[int(len(dist)*.025)],dist[int(len(dist)*.975)]]}
 if a=='permanent' and b in ['week-ago','pre-farming','master']:
  result['tournament_cpu_per_tick_informational']=cpu(rows,a,b)
 result['by_opponent']={}
 for opponent in ['nicowar','maxima']:
  sub=[r for r in rows if r['case']['opponent']==opponent];subgroups={fam:[r for r in groups[fam] if r['case']['opponent']==opponent] for fam in families};subresult={}
  for k,f in metrics.items():
   dist=[f([r for fam in d for r in subgroups[fam]],a,b) for d in draws];dist=sorted(x for x in dist if x is not None)
   subresult[k]={'change':f(sub,a,b),'ci95':[dist[int(len(dist)*.025)],dist[int(len(dist)*.975)]]}
  result['by_opponent'][opponent]=subresult
 result['families']={str(f):{k:fn(rs,a,b) for k,fn in metrics.items()} for f,rs in groups.items()}
 summary[a+'_vs_'+b]=result
compute=json.loads((V/'compute-results.json').read_text()) if (V/'compute-results.json').exists() else [];summary['cpu_status']='complete' if compute else 'pending';summary['quiet_cpu']={v:statistics.mean(r['cpu_seconds'] for r in compute if r['variant']==v) for v in ['week-ago','pre-farming','master','permanent']} if compute else {}
summary['totals']={v:{k:sum(r['variants'][v][k] for r in rows) for k in ['harvested_common_window','meals_common_window','starved_common_window','sampled_unit_ticks_common_window']} for v in rows[0]['variants']}
(V/'summary.json').write_text(json.dumps(summary,indent=2))
lines=['# Baseline verification','', '128 matched starts, 16 map families, four seeds and two rotations. Four archival builds add512 games to the completed256 current/master games. Common-window food measurements use the last shared logged interval across all six versions. Full-run geometric harvest is also shown for comparability with earlier studies. Intervals bootstrap whole map families (5000 draws), exploratory95%. Retained maps, not an independent holdout.','', '| Comparison | Common-window wheat | 95% interval | Common-window meals | Full-run geometric wheat |','|---|---:|---:|---:|---:|']
for a,b in comparisons:
 d=summary[a+'_vs_'+b];h=d['harvest_common'];m=d['meals_common'];g=d['harvest_full_geometric'];lines.append(f"| {a} vs {b} | {h['change']:+.1%} | {h['ci95'][0]:+.1%} to {h['ci95'][1]:+.1%} | {m['change']:+.1%} | {g['change']:+.1%} |")
lines+=['','## Fixed Nicowar opponent (64 starts)','', '| Comparison | Common-window wheat | 95% interval | Meals | Full-run geometric wheat |','|---|---:|---:|---:|---:|']
for a,b in comparisons:
 d=summary[a+'_vs_'+b]['by_opponent']['nicowar'];h=d['harvest_common'];m=d['meals_common'];g=d['harvest_full_geometric'];lines.append(f"| {a} vs {b} | {h['change']:+.1%} | {h['ci95'][0]:+.1%} to {h['ci95'][1]:+.1%} | {m['change']:+.1%} | {g['change']:+.1%} |")
lines+=['','Half the starts face Nicowar; half face Maxima. Production builds change both Maxima players, while archived experiments change only team 0. Therefore the Nicowar subset is the clean fixed-opponent policy comparison. The all-start table measures complete-version outcomes, including changed opposing behavior in self-play. The opponent groups also use different map seeds, so differences between groups cannot be attributed solely to the opponent. Earlier METHOD wording incorrectly called all opponents Nicowar; cases.json and actual commands preserve the correct assignments.','', '## Quiet crowded-save CPU','', '| Version | Mean CPU,8192 ticks | Permanent vs version |','|---|---:|---:|']
for v,seconds in summary['quiet_cpu'].items():lines.append(f"| {v} | {seconds:.3f}s | {summary['quiet_cpu']['permanent']/seconds-1:+.1%} |")
lines+=['','Same original crowded save, four repetitions per version, pinned physical cores on therig after games and metric parsing finished. Experimental binaries are excluded from CPU comparisons because they include extra diagnostic instrumentation. CPU differences include changed simulation trajectories/populations.','', 'The original experiment baseline already includes expansion support and wood reserves. Pre-farming master predates those changes. Week-old master additionally predates unrelated work. The earlier positive spacing result and a loss versus maturity can coexist; their denominators differ.','', 'The fresh runs last at most32768 ticks, and do not establish indefinite sustainability. See summary.json for full intervals, starvation rates, family effects and totals.']
(V/'REPORT.md').write_text('\n'.join(lines).replace('add512','add 512').replace('completed256','completed 256').replace('exploratory95','exploratory 95').replace('CPU,8192','CPU, 8192').replace('most32768','most 32,768')+'\n')
print('\n'.join(lines[:12]));print(summary['quiet_cpu'])
