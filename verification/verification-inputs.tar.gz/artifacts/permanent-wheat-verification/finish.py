from pathlib import Path
import sys,time,json,tarfile,hashlib,io
R=Path.cwd();V=R/'artifacts/permanent-wheat-verification';P=R/'artifacts/permanent-wheat';sys.path.insert(0,str(P));from metrics import analyze
host=sys.argv[1];deadline=time.monotonic()+3600
while not (V/f'{host}-results.json').exists():
 if time.monotonic()>deadline:raise TimeoutError('tournament incomplete')
 time.sleep(10)
rows=json.loads((V/f'{host}-results.json').read_text())
for r in rows:
 r['full_variants']={v:analyze((P if v in ['master','permanent'] else V)/'games'/r['case']['id']/v) for v in r['variants']}
(V/f'{host}-full-results.json').write_text(json.dumps(rows,indent=2))
print('METRICS_DONE',host,flush=True)
# Avoid competing with the dedicated CPU benchmark on therig.
if host=='therig':
 while not (V/'compute-results.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('compute incomplete')
  time.sleep(10)
manifest={}
with tarfile.open(V/f'{host}-evidence.tar.gz','w:gz') as t:
 paths=list((V/'games').rglob('*'))+(list((V/'compute').rglob('*')) if host=='therig' else [])
 for p in sorted(paths):
  if not p.is_file() or p.name not in ['stdout.log','cpu.txt','command.json','result.json','metrics.json']:continue
  if p.name=='stdout.log':
   raw=p.read_bytes();manifest[str(p.relative_to(V))]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
   data=b''.join(l for l in raw.splitlines(keepends=True) if l.startswith((b'GLOB2_PERF_FINAL ',b'GLOB2_ECON ',b'GLOB2_MEASURE ')))
   i=tarfile.TarInfo(str(p.relative_to(V)));i.size=len(data);t.addfile(i,io.BytesIO(data))
  else:t.add(p,arcname=str(p.relative_to(V)))
 t.add(V/f'{host}-full-results.json',arcname=f'{host}-full-results.json')
 if host=='therig':t.add(V/'compute-results.json',arcname='compute-results.json')
 data=json.dumps(manifest,indent=2).encode();i=tarfile.TarInfo('original-stdout-hashes.json');i.size=len(data);t.addfile(i,io.BytesIO(data))
print('PACKED',host,flush=True)
