from pathlib import Path
import sys,tarfile,json,tempfile
V=Path(__file__).resolve().parent;P=V.parent/'permanent-wheat';sys.path.insert(0,str(P));from metrics import analyze
count=0
with tempfile.TemporaryDirectory() as d:
 for host in ['therig','devlaptop']:
  roots={}
  for name,folder in [('old',V),('current',P)]:
   out=Path(d)/host/name;out.mkdir(parents=True);roots[name]=out
   with tarfile.open(folder/f'{host}-evidence.tar.gz') as t:t.extractall(out,filter='data')
  rows=json.loads((roots['old']/f'{host}-full-results.json').read_text())
  for r in rows:
   for v,expected in r['variants'].items():
    out=roots['current' if v in ['master','permanent'] else 'old']/'games'/r['case']['id']/v
    assert analyze(out,end=r['common_end'])==expected,(host,r['case']['id'],v,'common')
    assert analyze(out)==r['full_variants'][v],(host,r['case']['id'],v,'full')
    count+=1
(V/'evidence-verification.json').write_text(json.dumps({'games':count,'common_and_full_metrics_reproduced':True},indent=2));print('Reproduced common/full metrics for',count,'games')
