from pathlib import Path
import subprocess,json,random,concurrent.futures,time
R=Path.cwd();V=R/'artifacts/permanent-wheat-verification';B=R/'artifacts/continuous-maturity'
variants=['week-ago','pre-farming','master','permanent']
def binary(v):return R/('artifacts/farming-history' if v in ['week-ago','pre-farming'] else 'artifacts/permanent-wheat')/f'glob2-{v}'
def block(core):
 rows=[];order=variants.copy();random.Random(929+core).shuffle(order)
 for v in order:
  out=V/'compute'/f'core{core}-{v}';out.mkdir(parents=True,exist_ok=True)
  cmd=['taskset','-c',str(core),str(binary(v)),'--run-game','--load-game',str(B/'farm-crowding.game'),'--ticks','583520','--output-dir',str(out),'--telemetry','team-timeline','--replay','false']
  (out/'command.json').write_text(json.dumps(cmd))
  with (out/'stdout.log').open('w') as f:subprocess.run(['/usr/bin/time','-f','%U %S %e','-o',str(out/'cpu.txt'),*cmd],stdout=f,stderr=f,check=True,timeout=1200)
  cpu=[float(x) for x in (out/'cpu.txt').read_text().split()];result=json.loads((out/'result.json').read_text());assert result['ticks']==583520
  row={'variant':v,'core':core,'cpu_seconds':sum(cpu[:2]),'wall_seconds':cpu[2],'ticks':8192};rows.append(row)
  (V/f'core{core}.json').write_text(json.dumps(rows,indent=2));print('COMPUTE',row,flush=True)
 return rows

deadline=time.monotonic()+3600
while not (V/'therig-full-results.json').exists():
 if time.monotonic()>deadline:raise TimeoutError('tournament incomplete')
 time.sleep(10)
p=subprocess.run(['pgrep','-x','glob2|cc1plus|clang|clang++'],capture_output=True,text=True)
if p.returncode==0:raise RuntimeError('Competing game/compiler processes: '+p.stdout)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=[r for a in ex.map(block,[0,2,4,6]) for r in a]
(V/'compute-results.json').write_text(json.dumps(rows,indent=2));print('COMPUTE_DONE',flush=True)
