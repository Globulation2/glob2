from pathlib import Path
import hashlib,json,mmap,sys
V=Path(__file__).resolve().parent;sys.path.insert(0,'test');from compare_save_continuation import records
out={}
for case in sorted((V/'order-check').iterdir()):
 row={}
 for v in ['current','reviewed-boundary']:
  f=case/v/'game.replay.checksums';row[v]={'sidecar_sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
  with f.open('rb') as s:
   with mmap.mmap(s.fileno(),0,access=mmap.ACCESS_READ) as data:row[v]['per_tick']={str(t):hashlib.sha256(state).hexdigest() for t,state in records(data)}
 assert row['current']['per_tick']==row['reviewed-boundary']['per_tick'];out[case.name]=row
(V/'order-check-hashes.json').write_text(json.dumps(out));print('Verified',sum(len(v['current']['per_tick']) for v in out.values()),'per-tick records')
