// Link with the game objects (excluding Glob2.cpp) to exercise the real runtime.
#include "/Users/bradley/glob2-pr-help-3/src/GlobalContainer.h"
#include "/Users/bradley/glob2-pr-help-3/src/Version.h"
#include "/Users/bradley/glob2-pr-help-3/src/Game.h"
#include "/Users/bradley/glob2-pr-help-3/src/team/Team.h"
#include "/Users/bradley/glob2-pr-help-3/src/ai/AIImplementation.h"
#include "/Users/bradley/glob2-pr-help-3/src/map/Map.h"
#include "/Users/bradley/glob2-pr-help-3/src/Order.h"
#include "/Users/bradley/glob2-pr-help-3/src/ai/maxima/AIMaximaContinuation.h"
#include "/Users/bradley/glob2-pr-help-3/src/Player.h"
#include "/Users/bradley/glob2-pr-help-3/src/Utilities.h"
#include "/Users/bradley/glob2-pr-help-3/src/TeamStat.h"
#include <memory>
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_comparison.hpp>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
// Access the scheduler boundary without adding a production testing API.
#define private public
#include "/Users/bradley/glob2-pr-help-3/src/ai/maxima/AIMaximaRuntime.h"
#include "/Users/bradley/glob2-pr-help-3/src/ai/maxima/AIMaxima.h"
#undef private
#include "/Users/bradley/glob2-pr-help-3/src/building/Building.h"
#include "/Users/bradley/glob2-pr-help-3/src/game/entities/BuildingType.h"
#include "/Users/bradley/glob2-pr-help-3/src/building/IntBuildingType.h"
#include "/Users/bradley/glob2-pr-help-3/src/unit/Unit.h"
#include <BinaryStream.h>
#include <StreamBackend.h>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <memory>

GlobalContainer* globalContainer = NULL;
using namespace AIMaximaRuntime;


#include "Engine.h"
#include "GameGUI.h"
int main(int argc,char** argv) {
 GlobalContainer globals("glob2-attack-diagnosis"); globalContainer=&globals; globals.runNoX=true;globals.load();
 GameGUI gui; auto mh=Engine::loadMapHeader(argv[1]); auto gh=Engine::loadGameHeader(argv[1]);
 try {if(!gui.loadFromHeaders(mh,gh,true,true,true,argv[1]))return 2;}catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 3;}
 Game& game=gui.game;
 if(std::getenv("MAXIMA_DIAG_FORWARD")){Building* b=nullptr;for(int y=38;y<48&&!b;++y)for(int x=30;x<40&&!b;++x)if(game.map.isFreeForBuilding(x,y,2,2))b=game.addBuilding(x,y,globals.buildingsTypes.getTypeNum("inn",0,false),0,0);assert(b);std::cout<<"FORWARD_INN gid="<<b->gid<<" xy="<<b->posX<<","<<b->posY<<"\n";}

 {std::ofstream grid("/tmp/maxima-attack-investigation/tiles.tsv");grid<<"x\ty\twater\tresource\tbuilding\tforbidden\n";for(int y=0;y<game.map.getH();++y)for(int x=0;x<game.map.getW();++x)grid<<x<<"\t"<<y<<"\t"<<game.map.isWater(x,y)<<"\t"<<game.map.isResource(x,y)<<"\t"<<game.map.getBuilding(x,y)<<"\t"<<game.map.isForbidden(x,y,game.teams[0]->me)<<"\n";}
 for(int t=0;t<game.mapHeader.getNumberOfTeams();++t){auto* team=game.teams[t];for(int id=0;id<Building::MAX_COUNT;++id){auto* b=team->myBuildings[id];if(b)std::cout<<"BUILDING team="<<t<<" gid="<<b->gid<<" type="<<b->type->shortTypeNum<<" xy="<<b->posX<<","<<b->posY<<" size="<<b->type->width<<","<<b->type->height<<" hp="<<b->hp<<"\n";}}

 for(int id=0;id<Unit::MAX_COUNT;++id){auto* u=game.teams[0]->myUnits[id];if(u&&u->typeNum==WARRIOR)std::cout<<"WARRIOR gid="<<u->gid<<" xy="<<u->posX<<","<<u->posY<<" swim="<<u->performance[SWIM]<<" act="<<u->activity<<" medical="<<u->medical<<" attach="<<(u->attachedBuilding?int(u->attachedBuilding->gid):-1)<<"\n";}
 struct Track {int flag;int unit;int launch;int tx;int ty;bool arrived=false;bool fought=false;};
 std::vector<Track> tracks; std::set<int> launched;
 for(int step=0;step<= (argc>2?atoi(argv[2]):0);++step){
 for(int p=0;p<game.gameHeader.getNumberOfPlayers();++p){auto* ai=game.players[p]->ai?dynamic_cast<AIMaxima::Maxima*>(game.players[p]->ai->aiImplementation):nullptr;if(!ai)continue;
 for(auto& wave:ai->offense_waves){auto& reg=ai->context.get_building_register();auto* b=reg.is_building_found(wave.flagId)?reg.get_building(wave.flagId):nullptr;
 if(b&&wave.phase==AIMaxima::Tactics::WaveAdvance&&launched.insert(wave.flagId).second){std::cout<<"LAUNCH tick="<<game.stepCounter<<" wave="<<wave.flagId<<" cohort="<<b->unitsWorking.size()<<" target="<<wave.targetX<<","<<wave.targetY<<"\n";for(auto* u:b->unitsWorking){tracks.push_back({wave.flagId,int(u->gid),int(game.stepCounter),wave.targetX,wave.targetY});std::cout<<"ENROLL tick="<<game.stepCounter<<" wave="<<wave.flagId<<" unit="<<u->gid<<" hunger="<<u->hungry<<" threshold="<<u->trigHungry<<" appetite="<<u->hungriness<<" walk="<<u->performance[WALK]<<" hp="<<u->hp<<"\n";}}
 }
 for(auto it=tracks.begin();it!=tracks.end();){auto* u=game.teams[0]->myUnits[it->unit];auto& reg=ai->context.get_building_register();auto* b=reg.is_building_found(it->flag)?reg.get_building(it->flag):nullptr;
 if(!u||u->isDead||!b||u->attachedBuilding!=b){std::cout<<"LEAVE tick="<<game.stepCounter<<" wave="<<it->flag<<" unit="<<it->unit<<" age="<<int(game.stepCounter)-it->launch<<" arrived="<<it->arrived<<" fought="<<it->fought<<" medical="<<(u?int(u->medical):-1)<<" newflag="<<(u&&u->attachedBuilding?int(u->attachedBuilding->gid):-1)<<" alive="<<(u&&!u->isDead)<<" xy="<<(u?int(u->posX):-1)<<","<<(u?int(u->posY):-1)<<"\n";it=tracks.erase(it);continue;}
 if(!it->arrived&&game.map.warpDistMax(u->posX,u->posY,it->tx,it->ty)<=b->unitStayRange){it->arrived=true;std::cout<<"ARRIVE tick="<<game.stepCounter<<" wave="<<it->flag<<" unit="<<it->unit<<" age="<<int(game.stepCounter)-it->launch<<"\n";}
 if(u->movement==Unit::MOV_ATTACKING_TARGET)it->fought=true;
 ++it;}
 }
 if(step%200==0)for(int p=0;p<game.gameHeader.getNumberOfPlayers();++p){
 auto* ai=game.players[p]->ai?dynamic_cast<AIMaxima::Maxima*>(game.players[p]->ai->aiImplementation):nullptr; if(!ai)continue;
 int enemyBuildings=0,enemyHp=0;for(int id=0;id<Building::MAX_COUNT;++id){auto* e=game.teams[1]->myBuildings[id];if(e&&!e->type->isVirtual){++enemyBuildings;enemyHp+=e->hp;}}std::cout<<"ENEMY tick="<<game.stepCounter<<" buildings="<<enemyBuildings<<" hp="<<enemyHp<<"\n";
 std::cout<<"STATE game="<<game.stepCounter<<" ai="<<ai->timer<<" gate="<<ai->offense_diagnostics.gate<<" decision="<<ai->offense_diagnostics.decision<<" target="<<ai->tactical_mission.targetGid<<" xy="<<ai->tactical_mission.targetX<<","<<ai->tactical_mission.targetY<<" waves="<<ai->offense_waves.size()<<"\n";
 for(auto& w:ai->offense_waves){
 auto& reg=ai->context.get_building_register(); auto* b=reg.is_building_found(w.flagId)?reg.get_building(w.flagId):nullptr;
 std::cout<<"WAVE id="<<w.flagId<<" phase="<<w.phase<<" request="<<w.requestedForce<<" rally="<<w.rallyX<<","<<w.rallyY<<" target="<<w.targetX<<","<<w.targetY<<" start="<<w.startedTick<<" progress="<<w.progressTick<<" best="<<w.bestArrived;
 if(b){std::cout<<" gid="<<b->gid<<" flag="<<b->posX<<","<<b->posY<<" range="<<b->unitStayRange<<" enrolled="<<b->unitsWorking.size();for(auto* u:b->unitsWorking)std::cout<<" unit="<<u->gid<<":"<<u->posX<<","<<u->posY<<":mov"<<u->movement<<":act"<<u->activity<<":hungry"<<u->hungry;}
 std::cout<<"\n";
 if(b && argc>2 && atoi(argv[2])==0){int reachable=0,idle=0,canHire=0;for(int n=0;n<Unit::MAX_COUNT;++n){auto* u=game.players[p]->team->myUnits[n];if(!u||u->typeNum!=WARRIOR||u->isDead)continue;int d=0;if(game.map.buildingAvailable(b,u->swimClass(),u->posX,u->posY,&d))++reachable;if(u->activity==Unit::ACT_RANDOM&&u->medical==Unit::MED_FREE)++idle;}std::cout<<"FLAG_RECRUIT reachable="<<reachable<<" idle="<<idle<<" canHire="<<canHire<<" desired="<<b->desiredMaxUnitWorking<<"\n";}
 }
 }
 if(step==(argc>2?atoi(argv[2]):0))break;
 for(int p=0;p<game.gameHeader.getNumberOfPlayers();++p)if(game.players[p]->ai){auto o=game.players[p]->ai->getOrder(false);o->sender=p;game.executeOrder(o,0);}game.syncStep(0);
 }
}
