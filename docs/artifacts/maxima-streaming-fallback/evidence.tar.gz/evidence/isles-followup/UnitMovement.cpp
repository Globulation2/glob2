// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2001-2004 Stephane Magnenat & Luc-Olivier de Charrière

#include "Unit.h"
#include "Race.h"
#include "Team.h"
#include "Map.h"
#include "Game.h"

#include "Building.h"

#include "FixedPoint.h"
#include "MapInternal.h"
#include "Utilities.h"
#include "GlobalContainer.h"
#include <climits>
#include <iostream>
#include <set>
#include <vector>

void Unit::handleMovement(void)
{
	// Release any clearing-area claim from a prior tick before this unit decides
	// what to do this tick. Note: distance is intentionally NOT reset here — it
	// must survive the per-tick reset (see Unit.h declaration comment).
	if (previousClearingArea)
	{
		owner->map->setClearingAreaUnclaimed(previousClearingArea->x, previousClearingArea->y, owner->teamNumber);
		previousClearingArea.reset();
	}

	if (tryClaimClearingAreaForHarvesting())
		return;

	switch (displacement)
	{
		case DIS_REMOVING_BLACK_AROUND:
			handleMovementRemovingBlackAround();
			break;
		case DIS_ATTACKING_AROUND:
			handleMovementAttackingAround();
			break;
		case DIS_CLEARING_RESOURCES:
			handleMovementClearingResources();
			break;
		case DIS_RANDOM:
			handleMovementRandom();
			break;
		case DIS_GOING_TO_FLAG:
		case DIS_GOING_TO_BUILDING:
			handleMovementGoingToFlagOrBuilding();
			break;
		case DIS_ENTERING_BUILDING:
			handleMovementEnteringBuilding();
			break;
		case DIS_INSIDE:
			handleMovementInside();
			break;
		case DIS_EXITING_BUILDING:
			handleMovementExitingBuilding();
			break;
		case DIS_GOING_TO_RESOURCE:
			handleMovementGoingToResource();
			break;
		case DIS_HARVESTING:
			handleMovementHarvesting();
			break;
		case DIS_FILLING_BUILDING:
			handleMovementFillingBuilding();
			break;
		default:
			assert(false);
			break;
	}
}

bool Unit::tryClaimClearingAreaForHarvesting()
{
	// clearArea code, override behavior locally
	if (typeNum == WORKER &&
		medical == MED_FREE &&
		(displacement == DIS_RANDOM
		|| displacement == DIS_GOING_TO_FLAG
		|| displacement == DIS_GOING_TO_RESOURCE
		|| displacement == DIS_GOING_TO_BUILDING))
	{
		Map *map = owner->map;
		// TODO : be sure this is the right thing to do and add a decent comment
		if (movement == MOV_HARVESTING)
		{
			const Resource clearedBefore = map->getResource(posX + dx, posY + dy);
			recordLethalDamage(race->getUnitType(typeNum, level[HARVEST])->harvestDamage,
							   GameplayMeasurements::CLEARING);
			map->decResource(posX + dx, posY + dy);
			if (clearedBefore.type < MAX_NB_RESOURCES &&
				clearedBefore.getUint32() != map->getResource(posX + dx, posY + dy).getUint32())
				++owner->stats.measurements.cleared[clearedBefore.type];
			hp -= race->getUnitType(typeNum, level[HARVEST])->harvestDamage;
		}
		for (int tdx = -1; tdx <= 1; tdx++)
			for (int tdy = -1; tdy <= 1; tdy++)
			{
				int x = (posX + tdx) & map->wMask;
				int y = (posY + tdy) & map->hMask;
				Tile mapCase = map->tiles[(y << map->wDec) + x];
				if ((mapCase.clearArea & owner->me)
					&& (mapCase.resource.type != NO_RES_TYPE)
					&& globalContainer->resourcesTypes.get(mapCase.resource.type)->clearable
					&& !(mapCase.forbidden & owner->me))
				{
					owner->map->setClearingAreaClaimed(posX+tdx, posY+tdy, owner->teamNumber, gid);
					previousClearingArea = ClearingAreaClaim{
						static_cast<Uint32>((posX+tdx) & map->wMask),
						static_cast<Uint32>((posY+tdy) & map->hMask)
					};
					dx = tdx;
					dy = tdy;
					movement = MOV_HARVESTING;
					return true;
				}
			}
	}
	return false;
}

void Unit::handleMovementRemovingBlackAround()
{
	assert(performance[FLY]);
	if (attachedBuilding)
	{
		movement=MOV_GOING_DX_DY;
		int bposX=attachedBuilding->posX;
		int bposY=attachedBuilding->posY;

		int ldx=bposX-posX;
		int ldy=bposY-posY;
		int cdx, cdy;
		simplifyDirection(ldx, ldy, &cdx, &cdy);

		dx=-cdy;
		dy=cdx;
		if (!owner->map->isMapDiscovered(posX+4*cdx, posY+4*cdy, owner->sharedVisionOther))
		{
			dx=cdx;
			dy=cdy;
		}
	}
	else if ((movement!=MOV_GOING_DX_DY)||((syncRand()&0xFF)<0xEF))
	{
		// "c" is the center of the unit, "x" are the sample spots:
		// oxoooxo
		//ooooooooo
		//xooooooox
		//ooooooooo
		//oooocoooo
		//ooooooooo
		//xooooooox
		//ooooooooo
		// oxoooxo
		bool found = false;
		const int dxTab[8] = {-4, -2, +2, +4, +4, +2, -2, -4};
		const int dyTab[8] = {-2, -4, -4, -2, +2, +4, +4, +2};
		int tab[8];
		for (int i = 0; i < 8; i++)
		{
			tab[i] = owner->map->getExplored(posX + dxTab[i], posY + dyTab[i], owner->teamNumber);
			//also move around enemy towers:
			if(locationIsInEnemyGuardTowerRange(posX + dxTab[i], posY + dyTab[i]))tab[i]=1;
		}
		for (int di = 0; di < 8; di++)
		{
			int d = (di + direction + 4) % 8;
			//Move in a direction in which you circle counter-clockwise
			//about explored area, while exploring.
			if ((tab[d] > 0) && (tab[(d + 1) % 8] == 0) && (tab[(d + 2) % 8] == 0))
			{
				direction = (d + 1) % 8;
				dxDyFromDirection();
				movement = MOV_GOING_DX_DY;
				found = true;
				break;
			}
		}
		if (!found)
		{
			int scoreX = 0;
			int scoreY = 0;
                                        /* The next line should really be calculated only once per game.  How to do this?  The point is to avoid wrapping around the torus in considering what area is closer to us. */
                                        int maxRange = (std::min(owner->map->getW(), owner->map->getH())) / 2;
                                        /* We sample cells at various
                                           distances to decide in what
                                           direction there is more
                                           unexplored territory. */
                                        for (int range = 1; range <= maxRange; range *= 2)
                                          {
                                            for (int delta = -3; delta <= 3; delta++)
                                              {
					scoreX += owner->map->getExplored(posX - (4*range), posY + (delta*range), owner->teamNumber);
					scoreX -= owner->map->getExplored(posX + (4*range), posY + (delta*range), owner->teamNumber);
					scoreY += owner->map->getExplored(posX + (delta*range), posY - (4*range), owner->teamNumber);
					scoreY -= owner->map->getExplored(posX + (delta*range), posY + (4*range), owner->teamNumber);
                                              }
                                          }
			int cdx, cdy;
			simplifyDirection(scoreX, scoreY, &cdx, &cdy);

			if (cdx == 0 && cdy == 0)
				movement = MOV_RANDOM_FLY;
			else
			{
				dx = cdx;
				dy = cdy;
				directionFromDxDy();
				movement = MOV_GOING_DX_DY;
			}
		}
	}
	if (movement!=MOV_GOING_DX_DY || owner->map->getAirUnit(posX+dx, posY+dy)!=NOGUID)
		movement=MOV_RANDOM_FLY;
}

void Unit::handleMovementAttackingAround()
{
	assert(performance[ATTACK_SPEED]);
	int quality=INT_MAX; // Smaller is better.
	movement=MOV_RANDOM_GROUND;

	///Don't change targets if we still have a valid target
	if (auto off = owner->map->doesUnitTouchEnemy(this))
	{
		dx = off->dx;
		dy = off->dy;
		targetX = posX+dx;
		targetY = posY+dy;
		movement=MOV_ATTACKING_TARGET;
	}
	else
	{
		// we look for the best target to attack around us
		for (int x=-UNIT_ATTACK_SEARCH_RADIUS; x<=UNIT_ATTACK_SEARCH_RADIUS; x++)
		{
			for (int y=-UNIT_ATTACK_SEARCH_RADIUS; y<=UNIT_ATTACK_SEARCH_RADIUS; y++)
			{
				if (owner->map->isFOWDiscovered(posX+x, posY+y, owner->sharedVisionOther))
				{
					if (attachedBuilding &&
						owner->map->warpDistSquare(posX+x, posY+y, attachedBuilding->posX, attachedBuilding->posY)
							>((int)attachedBuilding->unitStayRange*(int)attachedBuilding->unitStayRange))
						continue;
					Uint16 gid;
					gid=owner->map->getBuilding(posX+x, posY+y);
					if (gid!=NOGBID)
					{
						int team=Building::GIDtoTeam(gid);
						if (owner->attackableTeams() & (1<<team))
						{
							int id=Building::GIDtoID(gid);
							int newQuality=((x*x+y*y)<<Q8_FIXED_POINT_SHIFT);
							Building *b=owner->game->teams[team]->myBuildings[id];
							BuildingType *bt=b->type;
							int shootDamage=bt->shootDamage;
							newQuality/=(1+shootDamage);
							tryAcquireAttackTarget(x, y, newQuality, quality);
						}
					}
					gid=owner->map->getGroundUnit(posX+x, posY+y);
					if (gid!=NOGUID)
					{
						int team=Unit::GIDtoTeam(gid);
						Uint32 tm=(1<<team);
						if (owner->attackableTeams() & tm)
						{
							int id=Building::GIDtoID(gid);
							Unit *u=owner->game->teams[team]->myUnits[id];
							if (((owner->sharedVisionExchange & tm)==0))
							{
								int attackStrength=u->getRealAttackStrength();
								int newQuality=((x*x+y*y)<<Q8_FIXED_POINT_SHIFT)/(1+attackStrength);
								tryAcquireAttackTarget(x, y, newQuality, quality);
							}
						}
					}
				}
			}
		}
	}

	// if we haven't found anything satisfactory, follow guard area gradients
	if (movement == MOV_RANDOM_GROUND)
	{
		if (!attachedBuilding && owner->map->pathfindArea(Map::AreaKind::Guard, owner->teamNumber, swimClass(), posX, posY, &dx, &dy))
		{
			directionFromDxDy();
			movement = MOV_GOING_DX_DY;
			// get the target position of guard area for display
			owner->map->getGlobalGradientDestination(owner->map->getGuardAreasGradient(owner->teamNumber, swimClass()), posX, posY, &targetX, &targetY);
			validTarget=true;
		}
		else if (attachedBuilding || (owner->map->getGuardAreasGradient(owner->teamNumber, swimClass())[owner->map->coordToIndex(posX, posY)] == GRADIENT_AT_GOAL))
		{
			// are we into the guard area or war flag, and we have to go to the least known area.
			int bestExplored = 3*EXPLORED_FRESH;
			int bestDirection = -1;
			for (int di = 0; di < 8; di++)
			{
				int d = (direction + di) & UNIT_DIRECTION_MASK;
				int cdx, cdy;
				dxDyFromDirection(d, &cdx, &cdy);
				if (!owner->map->isFreeForGroundUnit(posX + cdx, posY + cdy, performance[SWIM]>0, owner->me))
					continue;
				if (attachedBuilding)
				{
					if (owner->map->warpDistSquare(posX + cdx, posY + cdy, attachedBuilding->posX, attachedBuilding->posY)
						> ((int)attachedBuilding->unitStayRange * (int)attachedBuilding->unitStayRange))
						continue;
				}
				else
				{
					if (owner->map->getGuardAreasGradient(owner->teamNumber, swimClass())[owner->map->coordToIndex(posX + cdx, posY + cdy)] != GRADIENT_AT_GOAL)
						continue;
				}
				int explored = owner->map->getExplored(posX + 2*cdx, posY + 2*cdy, owner->teamNumber);
				explored += owner->map->getExplored(posX + 2*cdx - cdy, posY + 2*cdy + cdx, owner->teamNumber);
				explored += owner->map->getExplored(posX + 2*cdx + cdy, posY + 2*cdy - cdx, owner->teamNumber);
				if (bestExplored > explored)
				{
					bestExplored = explored;
					bestDirection = d;
				}
			}
			if (bestDirection >= 0)
			{
				direction = bestDirection;
				dxDyFromDirection();
				movement = MOV_GOING_DX_DY;
				validTarget = false;
			}
			else
			{
				movement = MOV_RANDOM_GROUND;
				validTarget = false;
			}
		}
		else
		{
			// this case happens when no movement could be found because of busy places or because we are in a guard area or because there is no guard area
			movement = MOV_RANDOM_GROUND;
			validTarget = false;
		}
	}
}

void Unit::tryAcquireAttackTarget(int x, int y, int newQuality, int& quality)
{
	if (newQuality >= quality)
		return;
	bool pathfind = owner->map->pathfindPointToPoint(posX, posY, posX+x, posY+y, &dx, &dy, swimClass(), owner->me, GOING_TARGET_MAX_PATH_LENGTH);
	if (!pathfind)
		return;
	if (abs(x)<=1 && abs(y)<=1)
	{
		movement=MOV_ATTACKING_TARGET;
		dx=x;
		dy=y;
	}
	else
	{
		movement=MOV_GOING_TARGET;
	}
	targetX=posX+x;
	targetY=posY+y;
	validTarget=true;
	quality=newQuality;
}

void Unit::handleMovementClearingResources()
{
	Map *map=owner->map;
	if (movement==MOV_HARVESTING)
	{
		const Resource clearedBefore = map->getResource(posX + dx, posY + dy);
		recordLethalDamage(race->getUnitType(typeNum, level[HARVEST])->harvestDamage,
						   GameplayMeasurements::CLEARING);
		map->decResource(posX + dx, posY + dy);
		if (clearedBefore.type < MAX_NB_RESOURCES &&
			clearedBefore.getUint32() != map->getResource(posX + dx, posY + dy).getUint32())
			++owner->stats.measurements.cleared[clearedBefore.type];
		hp -= race->getUnitType(typeNum, level[HARVEST])->harvestDamage;
	}

	int bx=attachedBuilding->posX;
	int by=attachedBuilding->posY;
	int usr=attachedBuilding->unitStayRange;
	int usr2=usr*usr;
	for (int tdx=-1; tdx<=1; tdx++)
		for (int tdy=-1; tdy<=1; tdy++)
		{
			int x=posX+tdx;
			int y=posY+tdy;
			if (map->warpDistSquare(x, y, bx, by)<=usr2 && map->isResourceTakeable(x, y, attachedBuilding->clearingResources) && !(owner->map->isForbidden(x, y, owner->me)))
			{
				dx=tdx;
				dy=tdy;
				movement=MOV_HARVESTING;
				return;
			}
		}
	bool canSwim=performance[SWIM];
	assert(attachedBuilding);
	if (map->pathfindBuilding(attachedBuilding, swimClass(), posX, posY, &dx, &dy))
	{
		directionFromDxDy();
		movement=MOV_GOING_DX_DY;
	}
	else if (attachedBuilding->anyResourceToClear[canSwim]==2)
	{
		stopAttachedForBuilding(false);
		movement=MOV_RANDOM_GROUND;
	}
	else
		movement=MOV_RANDOM_GROUND;
}

void Unit::handleMovementRandom()
{
	Map *map=owner->map;
	std::optional<Offset> enemyOff;
	if (performance[ATTACK_SPEED] && medical==MED_FREE)
		enemyOff = map->doesUnitTouchEnemy(this);
	if (enemyOff)
	{
		dx = enemyOff->dx;
		dy = enemyOff->dy;
		movement=MOV_ATTACKING_TARGET;
	}
	else if (performance[FLY])
		movement=MOV_RANDOM_FLY;
	else if (map->getForbidden(posX, posY)&owner->me)
	{
		if (map->pathfindForbidden(NULL, owner->teamNumber, swimClass(), posX, posY, &dx, &dy))
			directionFromDxDy();
		else
		{
			dx=0;
			dy=0;
			direction=UNIT_DIRECTION_NONE;
		}
		movement=MOV_GOING_DX_DY;
	}
	else if(performance[HARVEST])
	{
		// g==0: on obstacle. g==1: no clearing area reachable from this cell.
		// Both cases mean "nothing found".
		const Uint16 *clearAreasGradient = owner->map->getClearAreasGradient(owner->teamNumber, swimClass());
		Uint16 g = clearAreasGradient[owner->map->coordToIndex(posX, posY)];
		int distance = gradientTiles(g);
		if(g > GRADIENT_UNREACHABLE && distance < ((hungry-trigHungry) / race->hungriness) && medical == MED_FREE)
		{
			int tempTargetX, tempTargetY;
			bool path = owner->map->getGlobalGradientDestination(clearAreasGradient, posX, posY, &tempTargetX, &tempTargetY);
			int guid = owner->map->isClearingAreaClaimed(tempTargetX, tempTargetY, owner->teamNumber);
			int other_distance = INT_MAX;
			if(guid != NOGUID)
			{
				Unit* unit = owner->myUnits[GIDtoID(guid)];
				if(unit)
					other_distance = unit->previousClearingAreaDistance;
			}
			if(path && distance < other_distance)
			{
				dx=0;
				dy=0;
				owner->map->pathfindArea(Map::AreaKind::Clear, owner->teamNumber, swimClass(), posX, posY, &dx, &dy);

				targetX = tempTargetX;
				targetY = tempTargetY;
				previousClearingArea = ClearingAreaClaim{
					static_cast<Uint32>(tempTargetX),
					static_cast<Uint32>(tempTargetY)
				};
				previousClearingAreaDistance = distance;

				if(guid != NOGUID)
				{
					Unit* unit = owner->myUnits[GIDtoID(guid)];
					if(unit)
					{
						unit->previousClearingArea.reset();
						unit->previousClearingAreaDistance=UNIT_CLEAR_AREA_DISTANCE_NONE;
					}
				}

				//Find clearing resource
				directionFromDxDy();
				movement = MOV_GOING_DX_DY;
				owner->map->setClearingAreaClaimed(targetX, targetY, owner->teamNumber, gid);
				validTarget=true;
			}
			else
				movement=MOV_RANDOM_GROUND;
		}
		else
			movement=MOV_RANDOM_GROUND;
	}
	else
		movement=MOV_RANDOM_GROUND;
}

void Unit::handleMovementGoingToFlagOrBuilding()
{
	Map *map=owner->map;

	std::optional<Offset> enemyOff;
	if (performance[ATTACK_SPEED] && medical==MED_FREE)
		enemyOff = map->doesUnitTouchEnemy(this);
	if (enemyOff)
	{
		dx = enemyOff->dx;
		dy = enemyOff->dy;
		movement=MOV_ATTACKING_TARGET;
	}
	else if (performance[FLY])
	{
		movement=MOV_FLYING_TARGET;
	}
	else if (map->pathfindBuilding(targetBuilding, swimClass(), posX, posY, &dx, &dy))
	{
		movement=MOV_GOING_DX_DY;
	}
	else
	{

        if(typeNum==WARRIOR && owner->teamNumber==0 && attachedBuilding && attachedBuilding->type->isVirtual){
          const auto* field=targetBuilding->globalGradient[swimClass()];
          std::cerr<<"PATHFAIL tick="<<owner->game->stepCounter<<" unit="<<gid<<" flag="<<attachedBuilding->gid<<" xy="<<posX<<","<<posY<<" goal="<<targetBuilding->posX<<","<<targetBuilding->posY<<" immobile="<<map->isImmobileUnit(posX,posY)<<" here="<<(field?int(field[map->coordToIndex(posX,posY)]):-1);
          for(int ay=-1;ay<=1;++ay)for(int ax=-1;ax<=1;++ax)if(ax||ay)std::cerr<<" n="<<ax<<","<<ay<<":"<<(field?int(field[map->coordToIndex(posX+ax,posY+ay)]):-1)<<":"<<map->getGroundUnit(posX+ax,posY+ay)<<":"<<map->isFreeForGroundUnit(posX+ax,posY+ay,performance[SWIM]>0,owner->me);
          std::cerr<<"\n";
        }
        if(std::getenv("MAXIMA_DIAG_RECOVER") && typeNum==WARRIOR && owner->teamNumber==0 && attachedBuilding && attachedBuilding->type->isVirtual){
          const auto* field=targetBuilding->globalGradient[swimClass()];
          if(field){
            const int here=field[map->coordToIndex(posX,posY)];bool route=here>GRADIENT_UNREACHABLE;int best=GRADIENT_UNREACHABLE,bx=0,by=0;
            for(int ay=-1;ay<=1;++ay)for(int ax=-1;ax<=1;++ax)if(ax||ay){int g=field[map->coordToIndex(posX+ax,posY+ay)];route=route||g>GRADIENT_UNREACHABLE;if(g>best&&map->isFreeForGroundUnit(posX+ax,posY+ay,performance[SWIM]>0,owner->me)){best=g;bx=ax;by=ay;}}
            if(route){
              dx=here<=GRADIENT_UNREACHABLE?bx:0;dy=here<=GRADIENT_UNREACHABLE?by:0;
              if(here>GRADIENT_UNREACHABLE && std::string(std::getenv("MAXIMA_DIAG_RECOVER"))=="detour"){
                struct P{int x,y,firstX,firstY,depth;};std::vector<P> q={{posX,posY,0,0,0}};std::set<int> seen={int(map->coordToIndex(posX,posY))};bool found=false;
                for(size_t head=0;head<q.size()&&!found;++head){auto p=q[head];if(p.depth==4)continue;for(int d=0;d<8&&!found;++d){int nx=map->normalizeX(p.x+tabClose[d][0]),ny=map->normalizeY(p.y+tabClose[d][1]);int at=map->coordToIndex(nx,ny);if(!seen.insert(at).second||field[at]<=GRADIENT_UNREACHABLE||!map->isFreeForGroundUnit(nx,ny,performance[SWIM]>0,owner->me))continue;int fx=p.depth?p.firstX:tabClose[d][0],fy=p.depth?p.firstY:tabClose[d][1];if(field[at]>here){dx=fx;dy=fy;found=true;break;}q.push_back({nx,ny,fx,fy,p.depth+1});}}
              }
              movement=MOV_GOING_DX_DY;return;
            }
          }
        }
		stopAttachedForBuilding(true);
		movement=MOV_RANDOM_GROUND;
	}
}

void Unit::handleMovementEnteringBuilding()
{
	movement=MOV_ENTERING_BUILDING;
}

void Unit::handleMovementInside()
{
	movement=MOV_INSIDE;
}

void Unit::handleMovementExitingBuilding()
{
	bool exitFound;
	if (performance[FLY])
		exitFound=attachedBuilding->findAirExit(&posX, &posY, &dx, &dy);
	else
		exitFound=attachedBuilding->findGroundExit(&posX, &posY, &dx, &dy, performance[SWIM]);
	if (exitFound)
	{
		activity=ACT_RANDOM;
		movement=MOV_EXITING_BUILDING;
		attachedBuilding->removeUnitFromInside(this);
		attachedBuilding->updateConstructionState();
		attachedBuilding=NULL;
		setTargetBuilding(NULL);
		assert(ownExchangeBuilding==NULL);
		assert(needToRecheckMedical);
	}
	else
	{
		movement=MOV_INSIDE;
	}
}

void Unit::handleMovementGoingToResource()
{
	Map *map=owner->map;
	int teamNumber=owner->teamNumber;
	int swim=swimClass();
	bool stopWork;
	if (map->pathfindResource(teamNumber, destinationPurpose, swim, posX, posY, &dx, &dy, &stopWork, attachedBuilding))
	{
		directionFromDxDy();
		movement=MOV_GOING_DX_DY;
		// targetX/Y (also the debug path line, hotkey T) were set once, by
		// ascending a gradient, when the fetch task started. pathfindResource
		// above re-reads whichever gradient actually governs the step fresh
		// every action -- the round-trip field when attachedBuilding has one
		// and it is valid here, the plain resource gradient otherwise -- and
		// either field can be rebuilt, or the preference between them can
		// flip, while the unit is still walking. Re-ascend from here whenever
		// the stored target has stopped being a peak of that same gradient;
		// isGradientPeak is a cheap check to run every action, the ascent
		// itself only when it actually goes stale.
		const Uint16 *roundTrip = attachedBuilding ? map->roundTripGradient(attachedBuilding, destinationPurpose, swim) : NULL;
		const Uint16 *gradient = (roundTrip && roundTrip[map->coordToIndex(posX, posY)]>GRADIENT_UNREACHABLE)
			? roundTrip : map->getResourceGradient(teamNumber, destinationPurpose, swim);
		if (!map->isGradientPeak(gradient, targetX, targetY))
			map->getGlobalGradientDestination(gradient, posX, posY, &targetX, &targetY);
	}
	else
	{
		if (stopWork)
			stopAttachedForBuilding(false);
		movement=MOV_RANDOM_GROUND;
	}
}

void Unit::handleMovementHarvesting()
{
	movement=MOV_HARVESTING;
}

void Unit::handleMovementFillingBuilding()
{
	movement=MOV_FILLING;
}
