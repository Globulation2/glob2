import subprocess,shlex
from pathlib import Path
root=Path.cwd()
packages=['sdl2','SDL2_net','SDL2_ttf','SDL2_image','vorbisfile','speex','fribidi','epoxy']
cf=shlex.split(subprocess.check_output(['pkg-config','--cflags',*packages],text=True))
libs=shlex.split(subprocess.check_output(['pkg-config','--libs',*packages],text=True))+['-L/opt/homebrew/lib','-lboost_date_time','-lpthread','-lz','-framework','OpenGL','-framework','GLUT']
flags=['-std=gnu++20','-O1','-g','-I.','-Isrc','-Ilibgag/include','-Ilibusl/src',*['-I'+str(p) for p in (root/'src').rglob('*') if p.is_dir()],*cf]
sources=(root/'src/SConscript').read_text().split('"""')[1].split()
objects=[str(root/'build/src'/Path(s).with_suffix('.o')) for s in sources if s not in ['Glob2.cpp','unit/UnitMovement.cpp']]
subprocess.run(['c++',*flags,'-c','/tmp/maxima-attack-investigation/UnitMovement.cpp','-o','/tmp/maxima-attack-investigation/UnitMovement.o'],check=True)
objects.append('/tmp/maxima-attack-investigation/UnitMovement.o')
subprocess.run(['c++',*flags,'-c','/tmp/maxima-attack-investigation/inspect.cpp','-o','/tmp/maxima-attack-investigation/inspect.o'],check=True)
subprocess.run(['c++',*flags,'/tmp/maxima-attack-investigation/inspect.o',*objects,'build/libgag/src/libgag.a','build/libusl/src/libusl.a',*libs,'-o','/tmp/maxima-attack-investigation/inspect'],check=True)
