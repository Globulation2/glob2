# Maxima attack evidence

Final production code: 5f64ee3f3 (test-contract correction: afe603bcf). Historical base: d37c0c353d9c2c68b4543286aa9b14e23ae7e526. Executed on macOS arm64.

`production/` contains the final 80-game matrix and three saved scenarios; `production-plan.json` records exact inputs, SHA-256 hashes, seeds and tick budgets. All 83 inputs and successful exit statuses were checked when packaging. `ProductionStudy.cpp` observes production AI state without overriding its decisions; real recruitment, movement and combat run in the engine.

From a release-built repository root:

```sh
python3 /path/to/evidence/run-production.py --output /tmp/maxima-recheck --jobs 6
# Or select one retained job:
python3 /path/to/evidence/run-production.py --output /tmp/maxima-original --only original-save
python3 /path/to/evidence/check-continuation.py build/src/glob2 /tmp/maxima-continuation
```

The study linker supports macOS/Linux and requires the same development dependencies as the game. Output directories should be fresh. The continuation checker retains 2000 detailed per-tick state hashes and compares reloads at 69000, 69124 (pending streaming flags), and 69500. It imports the repository's save-continuation comparator. New-behavior cross-platform checksum equivalence has not been verified.

Timelines sample every 1000 ticks: `streaming` means the permanent fallback latch. Flag columns cover all offensive flags; filter streaming=1 to study fallback flags. Observed maxima are not exhaustive between samples. Legacy summary column names `measured` and `failed` count failure-counter transitions/increments, not total waves. Events identify the first observer tick after the AI decision.

`single-flag-production/` retains the preceding production experiment. `wave-only-sweep/`, `prototype/`, and `prototype-tools/` retain historical experiments on the base revision; their overlays must not be applied to current production. `isles-followup/` includes both additional saves and historical assembly-stall traces. `continuation/` includes regression logs; historical single-flag hashes are explicitly named.

Historical comparisons are descriptive, not paired win-rate evidence. One archived wave-only run diverged on rerun even with its unchanged old executable and identical input hash. The old and new executable reruns agreed through their common 40000-tick prefix (retained in prefix-base/current). This limits causal interpretation of differences from the historical archive.
