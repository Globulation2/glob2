#!/usr/bin/env python3
"""Run from the repository root: python3 EVIDENCE/check-continuation.py build/src/glob2 /tmp/check"""
import gzip
import hashlib
import json
import mmap
from pathlib import Path
import subprocess
import sys
sys.path.insert(0,str(Path.cwd()/'test'))
from compare_save_continuation import records,compare

binary=Path(sys.argv[1]).resolve(); output=Path(sys.argv[2]).resolve()
evidence=Path(__file__).resolve().parent/'continuation'
output.mkdir(parents=True,exist_ok=False)
initial=output/'initial.game'
initial.write_bytes(gzip.decompress((evidence/'before-68000.game.gz').read_bytes()))
def run(source,dest,save=False,stop=70000,interval=500):
    command=[str(binary),'--run-game','--load-game',str(source),'--ticks',str(stop),
             '--telemetry','checksums','--output-dir',str(dest)]
    if save:command+=['--save','every:'+str(interval)]
    with (output/(dest.name+'.log')).open('w') as log:
        subprocess.run(command,stdout=log,stderr=log,check=True)
run(initial,output/'full',True)
full=output/'full/game.replay.checksums'
with full.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    actual={str(t):hashlib.sha256(state).hexdigest() for t,state in records(data)}
expected=json.loads((evidence/'expected-state-hashes.json').read_text())
assert actual==expected,'per-tick state hashes differ from the retained macOS baseline'
print('PASS: all 2000 per-tick team/entity state hashes match')
run(initial,output/'pending',True,69130,69124)
for tick in [69000,69124,69500]:
    dest=output/('resume-'+str(tick))
    source=output/('pending' if tick==69124 else 'full')/('checkpoint-'+str(tick)+'.game')
    run(source,dest)
    count=compare(full,dest/'game.replay.checksums')
    print(f'PASS: reload at {tick} matches all {count} subsequent records')
