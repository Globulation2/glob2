// Experimental wave-outcome observer; not part of the production engine.
#include "GlobalContainer.h"
#include "Game.h"
#include "Team.h"
#include "AIImplementation.h"
#include "Map.h"
#include "Order.h"
#include "AIMaximaContinuation.h"
#include "Player.h"
#include "Utilities.h"
#include "TeamStat.h"
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_comparison.hpp>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
#define private public
#include "AIMaximaRuntime.h"
#include "AIMaxima.h"
#undef private
#include "Building.h"
#include "BuildingType.h"
#include "Unit.h"
#include "Engine.h"
#include "GameGUI.h"
#include <BinaryStream.h>
#include <StreamBackend.h>
#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>

GlobalContainer* globalContainer = nullptr;
static bool streaming[Team::MAX_COUNT] = {};

// Called only by the study's separately compiled combat object.
bool maximaStudyStreaming(Player* player)
{
    return streaming[player->teamNumber];
}

struct Observer {
    int launches=0, measured=0, failed=0, maxStreak=0, firstTrigger=-1;
    int thresholdPercent=33, requiredFailures=4; bool apply=false;
    int previous=0;
    std::map<int, AIMaxima::Tactics::Wave> prior;
    std::set<int> launched;
    void observe(AIMaxima::Maxima& ai, bool initial, std::ostream& out) {
        int tick=ai.context.player->game->stepCounter, team=ai.context.player->teamNumber;
        std::map<int, AIMaxima::Tactics::Wave> current;
        for(const auto& w:ai.offense_waves) {
            current[w.flagId]=w;
            if(w.phase==AIMaxima::Tactics::WaveAdvance && launched.insert(w.flagId).second) {
                if(!initial)++launches;
                out << "launch\t" << tick << '\t' << team << '\t' << w.flagId << '\n';
            }
        }
        for(const auto& [id,w]:prior)
            if(w.phase==AIMaxima::Tactics::WaveMuster && !current.count(id))
                out << "muster_end\t" << tick << '\t' << team << '\t' << id
                    << '\t' << ai.timer-w.startedTick << '\t' << ai.failed_waves << '\n';
        if(ai.failed_waves!=previous) {
            out << "streak\t" << tick << '\t' << team << '\t' << previous << '\t' << ai.failed_waves << '\n';
            if(ai.failed_waves>previous)failed+=ai.failed_waves-previous;
            ++measured; previous=ai.failed_waves;
            maxStreak=std::max(maxStreak,previous);
        }
        if(ai.failed_waves>=4 && firstTrigger<0) {
            firstTrigger=tick;streaming[team]=true;
            out << "trigger\t" << tick << '\t' << team << "\t1\n";
        }
        prior=std::move(current);
    }
};

int main(int argc, char** argv)
{
    try
    {
        if(argc != 10)
            throw std::runtime_error("usage: study map|save FILE SEED OPPONENT TICKS observe|fallback PERCENT FAILURES OUTPUT_DIR");
        const std::string mode = argv[1], file = argv[2], action = argv[6];
        const unsigned seed = std::stoul(argv[3]);
        const int opponent = std::stoi(argv[4]), ticks = std::stoi(argv[5]);
        const int percent = std::stoi(argv[7]), failures = std::stoi(argv[8]);
        if((action != "observe" && action != "fallback") || ticks < 0
           || percent < 1 || percent > 100 || failures < 1
           || (mode == "map" && opponent != 5 && opponent != 7))
            throw std::runtime_error("invalid parameters (opponent must be Nicowar=5 or Maxima=7)");
        const std::filesystem::path output = std::filesystem::absolute(argv[9]);
        std::filesystem::create_directories(output / "profile");
        SDL_setenv("GLOB2_USER_DIR", (output / "profile").string().c_str(), 1);
        GlobalContainer globals("glob2-wave-study");
        globalContainer = &globals;
        globals.runNoX = true;
        globals.load();
        GameGUI gui;
        auto mapHeader = Engine::loadMapHeader(file);
        auto gameHeader = mode == "save" ? Engine::loadGameHeader(file) : GameHeader{};
        if(mode == "map")
        {
            if(mapHeader.getNumberOfTeams() != 2)
                throw std::runtime_error("study requires a two-team map");
            gameHeader.setNumberOfPlayers(2);
            gameHeader.setRandomSeed(seed);
            for(int p = 0; p < 2; ++p)
                gameHeader.getBasePlayer(p) = BasePlayer(p, p ? "Opponent" : "Maxima", p,
                    BasePlayer::playerTypeFromImplementationID(static_cast<AI::ImplementationID>(p ? opponent : AI::MAXIMA)));
        }
        else if(mode != "save") throw std::runtime_error("invalid input mode");
        if(!gui.loadFromHeaders(mapHeader, gameHeader, true, true, mode == "save", file))
            throw std::runtime_error("could not load input");
        std::ofstream events(output / "events.tsv");
        events << "# wave: tick team flag launched peak_arrived remaining age failed streak\n";
        Observer observers[Team::MAX_COUNT];
        for(auto& observer : observers)
        {
            observer.thresholdPercent = percent;
            observer.requiredFailures = failures;
            observer.apply = action == "fallback";
        }
        Game& game = gui.game;
        const int start = game.stepCounter;
        std::ofstream timeline(output / "timeline.tsv");
        timeline << "tick\tteam\twarriors\twaves\tstreaming\tenemy_buildings\tenemy_hp\tmission_flag\tmission_enrolled\n";
        int elapsed = 0;
        for(; elapsed <= ticks; ++elapsed)
        {
            for(int p = 0; p < game.gameHeader.getNumberOfPlayers(); ++p)
            {
                auto* player = game.players[p];
                auto* ai = player->ai ? dynamic_cast<AIMaxima::Maxima*>(player->ai->aiImplementation) : nullptr;
                if(!ai) continue;
                observers[player->teamNumber].observe(*ai, elapsed == 0, events);
                if(elapsed % 1000 == 0)
                {
                    int warriors = 0, buildings = 0, hp = 0;
                    for(int u = 0; u < Unit::MAX_COUNT; ++u)
                        if(player->team->myUnits[u] && player->team->myUnits[u]->typeNum == WARRIOR)
                            ++warriors;
                    for(int t = 0; t < game.teamsCount(); ++t)
                        if(player->team->enemies & game.teams[t]->me)
                            for(int b = 0; b < Building::MAX_COUNT; ++b)
                                if(auto* building = game.teams[t]->myBuildings[b]; building && !building->type->isVirtual)
                                { ++buildings; hp += building->hp; }
                    auto& reg = ai->context.get_building_register();
                    const int flagId = ai->tactical_mission.flagId;
                    Building* flag = flagId >= 0 && reg.is_building_found(flagId)
                        ? reg.get_building(flagId) : nullptr;
                    timeline << game.stepCounter << '\t' << player->teamNumber << '\t' << warriors
                        << '\t' << ai->offense_waves.size() << '\t' << streaming[player->teamNumber]
                        << '\t' << buildings << '\t' << hp << '\t' << flagId
                        << '\t' << (flag ? flag->unitsWorking.size() : 0) << '\n';
                    events.flush(); timeline.flush();
                }
            }
            if(elapsed == ticks) break;
            int alive = 0;
            for(int t = 0; t < game.teamsCount(); ++t) alive += game.teams[t]->isAlive;
            if(alive < 2) break;
            for(int p = 0; p < game.gameHeader.getNumberOfPlayers(); ++p)
                if(game.players[p]->ai)
                {
                    auto order = game.players[p]->ai->getOrder(false);
                    order->sender = p;
                    game.executeOrder(order, 0);
                }
            game.syncStep(0);
        }
        std::ofstream summary(output / "summary.tsv");
        summary << "team\tstart\tend\tlaunches\tmeasured\tfailed\tmax_streak\ttrigger\tstreaming\n";
        for(int t = 0; t < game.teamsCount(); ++t)
        {
            const auto& o = observers[t];
            summary << t << '\t' << start << '\t' << game.stepCounter << '\t' << o.launches
                << '\t' << o.measured << '\t' << o.failed << '\t' << o.maxStreak
                << '\t' << o.firstTrigger << '\t' << streaming[t] << '\n';
        }
        return 0;
    }
    catch(const std::exception& error)
    {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
