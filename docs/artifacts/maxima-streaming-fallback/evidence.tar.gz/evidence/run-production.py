#!/usr/bin/env python3
"""Run from a built repository root; evidence lives beside this script.
python3 /path/to/evidence/run-production.py --output /tmp/combined --jobs 6
Use --only JOB (repeatable) to select a subset of the retained matrix.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import gzip
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--jobs',type=int,default=4)
    parser.add_argument('--only',action='append')
    args=parser.parse_args()
    root=Path.cwd(); evidence=Path(__file__).resolve().parent
    output=args.output.resolve(); output.mkdir(parents=True,exist_ok=True)
    packages=['sdl2','SDL2_net','SDL2_ttf','SDL2_image','vorbisfile','speex','fribidi','epoxy']
    pkg=lambda kind:shlex.split(subprocess.check_output(['pkg-config',kind,*packages],text=True))
    compiler=shlex.split(os.environ.get('CXX','c++'))
    flags=['-std=gnu++20','-O2','-I.','-Isrc','-Ilibgag/include','-Ilibusl/src',
           *['-I'+str(p) for p in (root/'src').rglob('*') if p.is_dir()],*pkg('--cflags')]
    sources=(root/'src/SConscript').read_text().split('"""')[1].split()
    objects=[root/'build/src'/Path(s).with_suffix('.o') for s in sources if s!='Glob2.cpp']
    libraries=['build/libgag/src/libgag.a','build/libusl/src/libusl.a',*pkg('--libs'),
               '-lboost_date_time','-lpthread','-lz']
    libraries+=['-framework','OpenGL','-framework','GLUT'] if sys.platform=='darwin' else ['-lGL','-lGLU']
    subprocess.run([*compiler,*flags,'-c',str(evidence/'ProductionStudy.cpp'),'-o',str(output/'study.o')],check=True)
    subprocess.run([*compiler,str(output/'study.o'),*map(str,objects),*libraries,'-o',str(output/'study')],check=True)
    plan=json.loads((evidence/'production-plan.json').read_text())
    if args.only:plan=[j for j in plan if j['name'] in args.only]
    inputs=output/'inputs';inputs.mkdir(exist_ok=True)
    for job in plan:
        packed=evidence/job['packed_input']; target=inputs/packed.stem
        if not target.exists():target.write_bytes(gzip.decompress(packed.read_bytes()))
        if hashlib.sha256(target.read_bytes()).hexdigest()!=job['input_sha256']:
            raise RuntimeError('input hash mismatch: '+job['name'])
        job['file']=str(target)
    def run(job):
        dest=output/'runs'/job['name'];dest.mkdir(parents=True,exist_ok=False)
        # The production observer never changes AI state; the linked production
        # AI owns all scoring, saved state and the real streaming handoff.
        command=[str(output/'study'),job['mode'],job['file'],str(job.get('seed',19)),
                 str(job.get('opponent',7)),str(job['ticks']),'observe','33','4',str(dest)]
        (dest/'job.json').write_text(json.dumps(dict(job,command=command),indent=2)+'\n')
        with (dest/'stdout.log').open('w') as stdout,(dest/'stderr.log').open('w') as stderr:
            result=subprocess.run(command,stdout=stdout,stderr=stderr)
        (dest/'exit-code.txt').write_text(str(result.returncode)+'\n')
        print(job['name'],result.returncode,flush=True)
        return result.returncode
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        results=list(pool.map(run,plan))
    if any(results):raise SystemExit(1)

if __name__=='__main__':main()
