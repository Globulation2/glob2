# Broad Maxima wave-fallback sweep — 2026-09-20

The fixed **33% delivery / four consecutive failures** rule would switch **27 of
120 Maxima participants (22.5%)**, affecting **19 of 80 games (23.75%)**. It stays
off for most participants in this matrix and catches persistent bad delivery on
Isles and several other generators. Given the accepted tradeoff that occasional
unnecessary streaming switches are tolerable, these results support keeping the
simple rule rather than adding map checks or more gates.

These were observation-only runs: no fallback was applied. The study measures
trigger frequency, not a change in win rate. A trigger outside Isles is not
automatically a false positive.

## Design

20 generators × two new map/game seeds (2101, 7919) × two opponents (Maxima and
Nicowar), on 128×128, two-team maps at otherwise registered defaults. Each map is
used for both opponents. Mirror games contribute two Maxima participants; games
against Nicowar contribute one, always in team zero. Games stop at 90,000 ticks
(60 simulation minutes at normal speed) or fewer than two living teams. The
threshold was fixed before the sweep, with no seed replacement or threshold
retuning. All 40 maps generated and all 80 games completed successfully.

## Exposure and interpretation

- 713 waves were scored.
- 65 Maximas scored at least four waves; 27/65 (41.5%) triggered.
- 24 Maximas never launched a wave; 26 had no scored wave.
- 27/96 (28.1%) of Maximas that launched any wave triggered.
- 23 games reached the 90,000-tick cap; the others ended earlier.

No-wave cases provide no wave-classification exposure. They can reflect early
elimination, no launched offensive, or use of Maxima's existing amphibious
streaming controller; they do not necessarily mean Maxima failed to attack.
The overall and exposure-conditioned rates answer different questions. This is
a deliberately varied convenience sample, not a frequency-weighted estimate of
players' map choices, and participant outcomes within games are correlated.

## Generator breakdown

Every generator has four games and six Maxima participants. “Eligible” means at
least four scored waves. “Later success” counts triggered Maximas with a successful
scored wave that was **launched after** the trigger; this avoids mistaking an old
wave's delayed scoring for subsequent recovery.

| Generator | Triggered games / 4 | Triggered Maximas / 6 | Eligible Maximas | Scored waves | Later success |
| --- | ---: | ---: | ---: | ---: | ---: |
| braided-delta | 1 | 1 | 3 | 19 | 0 |
| canals | 0 | 0 | 4 | 27 | 0 |
| contested-commons | 0 | 0 | 0 | 0 | 0 |
| drowned-forest | 2 | 3 | 5 | 60 | 3 |
| even-ground | 0 | 0 | 3 | 23 | 0 |
| forts | 0 | 0 | 3 | 27 | 0 |
| hills | 1 | 1 | 6 | 41 | 1 |
| islands | 0 | 0 | 2 | 17 | 0 |
| isles | 3 | 5 | 5 | 134 | 0 |
| maze | 2 | 2 | 4 | 53 | 1 |
| old-town | 0 | 0 | 1 | 9 | 0 |
| portage-lakes | 0 | 0 | 4 | 25 | 0 |
| river | 0 | 0 | 4 | 29 | 0 |
| rugged-archipelago | 1 | 2 | 2 | 19 | 2 |
| savannah | 0 | 0 | 0 | 8 | 0 |
| shattered-coast | 1 | 2 | 2 | 27 | 1 |
| stone-highlands | 1 | 1 | 5 | 40 | 1 |
| swamp | 2 | 3 | 3 | 51 | 0 |
| switchbacks | 2 | 3 | 5 | 60 | 3 |
| symmetric-arena | 3 | 4 | 4 | 44 | 1 |

## After a trigger

13 of the 27 triggered Maximas later delivered at least one successful newly
launched wave. That alone does not mean switching would have hurt them.
Of the **24** triggered Maximas with at least four subsequently launched
and scored waves, **17** still failed to deliver on a majority of those
waves. **2** delivered successfully on every such later wave. Raw
per-team counts are in `analysis/teams.tsv`.

This supports the intended tradeoff: repeated poor delivery often persists, but
some recoverable cases will also switch. No additional decision gates were added.
Only actual fallback-versus-waves matches could quantify the win-rate effect.

## Evidence and reproduction

`design.json`, `plan.json`, and `generation.json` retain settings and generation
commands. `runs/*` contains every event, sampled timeline, summary, exit code,
input hash and exact execution command. The compressed exact maps are in `maps/`;
full generator reports are in `map-reports/`. All input hashes were checked against
the files used by their jobs. `analysis/` has generator, game and participant tables.

Build the normal client first, then use the experiment tools:

```sh
python3 tools/maxima-wave-study/run.py build --output /tmp/wave-broad-replay
mkdir -p /tmp/maxima-wave-broad-inputs
for map in docs/artifacts/maxima-wave-broad/maps/*.map.gz; do
  gzip -dc "$map" > "/tmp/maxima-wave-broad-inputs/$(basename "$map" .gz)"
done
python3 tools/maxima-wave-study/run.py run --output /tmp/wave-broad-replay \
  --plan docs/artifacts/maxima-wave-broad/replay-plan.json --jobs 6
python3 tools/maxima-wave-study/summarize_sweep.py /tmp/wave-broad-replay \
  --output /tmp/wave-broad-replay/analysis
```

To regenerate instead of replaying retained inputs, run `sweep.py --output NEW_DIR
--jobs 6` after building the study there. Only macOS arm64 was exercised. Engine
revision and combat-source hash are in `build.json`. Normal engine sources and
save formats are unchanged; the prototype latch is not serialized.
