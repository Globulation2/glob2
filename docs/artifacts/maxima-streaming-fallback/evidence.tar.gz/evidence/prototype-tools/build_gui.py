#!/usr/bin/env python3
"""Build a standalone GUI prototype using the exact study observer, without editing engine sources."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
from run import ROOT


def replace_once(text, anchor, replacement):
    if text.count(anchor) != 1:
        raise RuntimeError('GUI hook changed; review anchor: ' + anchor)
    return text.replace(anchor, replacement)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    overlays = {}
    combat = (ROOT/'src/ai/maxima/AIMaximaCombat.cpp').read_text()
    overlays['ai/maxima/AIMaximaCombat.cpp'] = 'class Player; extern bool maximaStudyStreaming(Player*);\n' + replace_once(combat,
        'bool Maxima::control_offense_waves(Context& echo)\n{',
        'bool Maxima::control_offense_waves(Context& echo)\n{\n if(maximaStudyStreaming(echo.player)) return false;')
    state = (ROOT/'src/ai/maxima/AIMaximaState.cpp').read_text()
    overlays['ai/maxima/AIMaximaState.cpp'] = 'namespace AIMaxima { class Maxima; } extern void maximaStudyObserve(AIMaxima::Maxima*);\n' + replace_once(state,
        'std::shared_ptr<Order> Maxima::getOrder()\n{',
        'std::shared_ptr<Order> Maxima::getOrder()\n{\n maximaStudyObserve(this);')
    ai = (ROOT/'src/ai/maxima/AIMaxima.cpp').read_text()
    overlays['ai/maxima/AIMaxima.cpp'] = 'namespace AIMaxima { class Maxima; } extern void maximaStudyReset(AIMaxima::Maxima*);\n' + replace_once(ai,
        'Maxima::Maxima(Player *player)\n\t: context(player)\n{',
        'Maxima::Maxima(Player *player)\n\t: context(player)\n{\n maximaStudyReset(this);')
    glob = (ROOT/'src/Glob2.cpp').read_text()
    overlays['Glob2.cpp'] = replace_once(glob, 'auto frontend = std::make_unique<FrontendTheme>();',
        '''auto frontend = std::make_unique<FrontendTheme>();
    if(const char* save = getenv("GLOB2_WAVE_STUDY_SAVE")) {
        Engine engine;
        if(engine.initCustom(save) != Engine::EE_NO_ERROR) return 1;
        isRunning = (engine.run() != -1);
    }''')
    init = (ROOT/'src/EngineInit.cpp').read_text()
    overlays['EngineInit.cpp'] = replace_once(init,
        'if(globalContainer->liveSpectating) gui.configureLiveSpectatorView();',
        '''if(globalContainer->liveSpectating) gui.configureLiveSpectatorView();
    if(getenv("GLOB2_WAVE_STUDY_PAUSE")) { if(globalContainer->liveSpectating) gui.hardPause = true; else gui.gamePaused = true; }''')
    observer = (ROOT/'tools/maxima-wave-study/MaximaWaveStudy.cpp').read_text().split('\nint main(')[0]
    observer = replace_once(observer, 'GlobalContainer* globalContainer = nullptr;', '')
    observer += '''
static Observer guiObservers[Team::MAX_COUNT];
static int guiLastTick[Team::MAX_COUNT];
void maximaStudyReset(AIMaxima::Maxima* ai) {
    const int team = ai->context.player->teamNumber;
    streaming[team] = false;
    guiObservers[team] = Observer{};
    guiObservers[team].thresholdPercent = 33;
    guiObservers[team].requiredFailures = 4;
    guiObservers[team].apply = true;
    guiLastTick[team] = -1;
}
void maximaStudyObserve(AIMaxima::Maxima* ai) {
    const int team = ai->context.player->teamNumber;
    const int tick = ai->context.player->game->stepCounter;
    if(guiLastTick[team] == tick) return;
    guiObservers[team].observe(*ai, guiLastTick[team] < 0, std::cout);
    guiLastTick[team] = tick;
    std::cout.flush();
}
'''
    packages = ['sdl2','SDL2_net','SDL2_ttf','SDL2_image','vorbisfile','speex','fribidi','epoxy']
    pkg = lambda arg: shlex.split(subprocess.check_output(['pkg-config',arg,*packages],text=True))
    flags = ['-std=gnu++20','-O2','-g','-I.','-Isrc','-Ilibgag/include','-Ilibusl/src',
             *['-I'+str(p) for p in (ROOT/'src').rglob('*') if p.is_dir()],*pkg('--cflags')]
    libs = [*pkg('--libs'),'-lboost_date_time','-lpthread','-lz']
    libs += ['-framework','OpenGL','-framework','GLUT'] if sys.platform=='darwin' else ['-lGL','-lGLU']
    compiler = shlex.split(os.environ.get('CXX','c++'))
    sources = (ROOT/'src/SConscript').read_text().split('"""')[1].split()
    objects = [ROOT/'build/src'/Path(s).with_suffix('.o') for s in sources if s not in overlays]
    objects += [ROOT/'build/libgag/src/libgag.a',ROOT/'build/libusl/src/libusl.a']
    overlays['MaximaWaveGui.cpp'] = observer
    for name,text in overlays.items():
        source=output/Path(name).name
        source.write_text(text)
        obj=source.with_suffix('.o')
        subprocess.run([*compiler,*flags,'-c',str(source),'-o',str(obj)],cwd=ROOT,check=True)
        objects.append(obj)
    subprocess.run([*compiler,*map(str,objects),*libs,'-o',str(output/'glob2-wave-prototype')],cwd=ROOT,check=True)
    (output/'build.json').write_text(json.dumps({
        'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'observer_sha256':hashlib.sha256(observer.encode()).hexdigest(),
        'percent':33,'failures':4,'saved_latch':False,
    },indent=2)+'\n')


if __name__=='__main__':main()
