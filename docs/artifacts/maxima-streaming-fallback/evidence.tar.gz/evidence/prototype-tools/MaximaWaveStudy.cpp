// Experimental wave-outcome observer; not part of the production engine.
#include "GlobalContainer.h"
#include "Game.h"
#include "Team.h"
#include "AIImplementation.h"
#include "Map.h"
#include "Order.h"
#include "AIMaximaContinuation.h"
#include "Player.h"
#include "Utilities.h"
#include "TeamStat.h"
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_comparison.hpp>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
#define private public
#include "AIMaximaRuntime.h"
#include "AIMaxima.h"
#undef private
#include "Building.h"
#include "BuildingType.h"
#include "Unit.h"
#include "Engine.h"
#include "GameGUI.h"
#include <BinaryStream.h>
#include <StreamBackend.h>
#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>

GlobalContainer* globalContainer = nullptr;
static bool streaming[Team::MAX_COUNT] = {};

// Called only by the study's separately compiled combat object.
bool maximaStudyStreaming(Player* player)
{
    return streaming[player->teamNumber];
}

struct WaveObservation
{
    int launched = 0;
    int launchTick = 0;
    int peakArrived = 0;
    bool scored = false;
    bool beganBeforeObservation = false;
};

struct Observer
{
    std::map<int, WaveObservation> waves;
    int streak = 0;
    int maxStreak = 0;
    int measured = 0;
    int failed = 0;
    int launches = 0;
    int firstTrigger = -1;
    int thresholdPercent = 25;
    int requiredFailures = 3;
    bool apply = false;

    void score(AIMaxima::Maxima& ai, int id, WaveObservation& record,
               int remaining, int gameTick, std::ostream& out)
    {
        if(record.scored || record.beganBeforeObservation) return;
        record.scored = true;
        const bool failure = record.peakArrived * 100 < record.launched * thresholdPercent;
        ++measured;
        failed += failure;
        streak = failure ? streak + 1 : 0;
        maxStreak = std::max(maxStreak, streak);
        out << "wave\t" << gameTick << '\t' << ai.context.player->teamNumber
            << '\t' << id << '\t' << record.launched << '\t' << record.peakArrived
            << '\t' << remaining << '\t' << gameTick - record.launchTick
            << '\t' << failure << '\t' << streak << '\n';
        if(streak >= requiredFailures && firstTrigger < 0)
        {
            firstTrigger = gameTick;
            out << "trigger\t" << gameTick << '\t' << ai.context.player->teamNumber
                << '\t' << apply << '\n';
        }
    }

    void observe(AIMaxima::Maxima& ai, bool initial, std::ostream& out)
    {
        const int team = ai.context.player->teamNumber;
        if(streaming[team]) return;
        Map& map = *ai.context.player->map;
        const int tick = ai.context.player->game->stepCounter;
        std::set<int> live;
        for(const auto& wave : ai.offense_waves)
        {
            live.insert(wave.flagId);
            if(wave.phase != AIMaxima::Tactics::WaveAdvance) continue;
            auto& reg = ai.context.get_building_register();
            Building* flag = reg.is_building_found(wave.flagId)
                ? reg.get_building(wave.flagId) : nullptr;
            if(!flag) continue;
            auto inserted = waves.emplace(wave.flagId, WaveObservation{});
            WaveObservation& record = inserted.first->second;
            const int remaining = flag->unitsWorking.size();
            if(inserted.second)
            {
                record.launched = remaining;
                record.launchTick = tick;
                record.beganBeforeObservation = initial || remaining == 0;
                if(!record.beganBeforeObservation) ++launches;
                out << "launch\t" << tick << '\t' << team << '\t' << wave.flagId
                    << '\t' << remaining << '\t' << record.beganBeforeObservation << '\n';
            }
            int arrived = 0;
            for(const Unit* unit : flag->unitsWorking)
                if(unit && !unit->isDead && unit->medical == Unit::MED_FREE
                   && map.warpDistMax(unit->posX, unit->posY, wave.targetX, wave.targetY)
                       <= ai.budget.tactical_siege_radius)
                    ++arrived;
            record.peakArrived = std::max(record.peakArrived, arrived);
            if(remaining * 4 <= record.launched)
                score(ai, wave.flagId, record, remaining, tick, out);
        }
        for(auto it = waves.begin(); it != waves.end();)
        {
            if(!live.count(it->first))
            {
                score(ai, it->first, it->second, 0, tick, out);
                it = waves.erase(it);
            }
            else ++it;
        }
        if(apply && firstTrigger >= 0)
        {
            // One-way handoff. The existing controller creates its normal
            // continuously recruiting objective flag on its next review.
            ai.end_offense(ai.context, "prototype_wave_fallback");
            streaming[team] = true;
        }
    }
};

int main(int argc, char** argv)
{
    try
    {
        if(argc != 10)
            throw std::runtime_error("usage: study map|save FILE SEED OPPONENT TICKS observe|fallback PERCENT FAILURES OUTPUT_DIR");
        const std::string mode = argv[1], file = argv[2], action = argv[6];
        const unsigned seed = std::stoul(argv[3]);
        const int opponent = std::stoi(argv[4]), ticks = std::stoi(argv[5]);
        const int percent = std::stoi(argv[7]), failures = std::stoi(argv[8]);
        if((action != "observe" && action != "fallback") || ticks < 0
           || percent < 1 || percent > 100 || failures < 1
           || (mode == "map" && opponent != 5 && opponent != 7))
            throw std::runtime_error("invalid parameters (opponent must be Nicowar=5 or Maxima=7)");
        const std::filesystem::path output = std::filesystem::absolute(argv[9]);
        std::filesystem::create_directories(output / "profile");
        SDL_setenv("GLOB2_USER_DIR", (output / "profile").string().c_str(), 1);
        GlobalContainer globals("glob2-wave-study");
        globalContainer = &globals;
        globals.runNoX = true;
        globals.load();
        GameGUI gui;
        auto mapHeader = Engine::loadMapHeader(file);
        auto gameHeader = mode == "save" ? Engine::loadGameHeader(file) : GameHeader{};
        if(mode == "map")
        {
            if(mapHeader.getNumberOfTeams() != 2)
                throw std::runtime_error("study requires a two-team map");
            gameHeader.setNumberOfPlayers(2);
            gameHeader.setRandomSeed(seed);
            for(int p = 0; p < 2; ++p)
                gameHeader.getBasePlayer(p) = BasePlayer(p, p ? "Opponent" : "Maxima", p,
                    BasePlayer::playerTypeFromImplementationID(static_cast<AI::ImplementationID>(p ? opponent : AI::MAXIMA)));
        }
        else if(mode != "save") throw std::runtime_error("invalid input mode");
        if(!gui.loadFromHeaders(mapHeader, gameHeader, true, true, mode == "save", file))
            throw std::runtime_error("could not load input");
        std::ofstream events(output / "events.tsv");
        events << "# wave: tick team flag launched peak_arrived remaining age failed streak\n";
        Observer observers[Team::MAX_COUNT];
        for(auto& observer : observers)
        {
            observer.thresholdPercent = percent;
            observer.requiredFailures = failures;
            observer.apply = action == "fallback";
        }
        Game& game = gui.game;
        const int start = game.stepCounter;
        std::ofstream timeline(output / "timeline.tsv");
        timeline << "tick\tteam\twarriors\twaves\tstreaming\tenemy_buildings\tenemy_hp\tmission_flag\tmission_enrolled\n";
        int elapsed = 0;
        for(; elapsed <= ticks; ++elapsed)
        {
            for(int p = 0; p < game.gameHeader.getNumberOfPlayers(); ++p)
            {
                auto* player = game.players[p];
                auto* ai = player->ai ? dynamic_cast<AIMaxima::Maxima*>(player->ai->aiImplementation) : nullptr;
                if(!ai) continue;
                observers[player->teamNumber].observe(*ai, elapsed == 0, events);
                if(elapsed % 1000 == 0)
                {
                    int warriors = 0, buildings = 0, hp = 0;
                    for(int u = 0; u < Unit::MAX_COUNT; ++u)
                        if(player->team->myUnits[u] && player->team->myUnits[u]->typeNum == WARRIOR)
                            ++warriors;
                    for(int t = 0; t < game.teamsCount(); ++t)
                        if(player->team->enemies & game.teams[t]->me)
                            for(int b = 0; b < Building::MAX_COUNT; ++b)
                                if(auto* building = game.teams[t]->myBuildings[b]; building && !building->type->isVirtual)
                                { ++buildings; hp += building->hp; }
                    auto& reg = ai->context.get_building_register();
                    const int flagId = ai->tactical_mission.flagId;
                    Building* flag = flagId >= 0 && reg.is_building_found(flagId)
                        ? reg.get_building(flagId) : nullptr;
                    timeline << game.stepCounter << '\t' << player->teamNumber << '\t' << warriors
                        << '\t' << ai->offense_waves.size() << '\t' << streaming[player->teamNumber]
                        << '\t' << buildings << '\t' << hp << '\t' << flagId
                        << '\t' << (flag ? flag->unitsWorking.size() : 0) << '\n';
                    events.flush(); timeline.flush();
                }
            }
            if(elapsed == ticks) break;
            int alive = 0;
            for(int t = 0; t < game.teamsCount(); ++t) alive += game.teams[t]->isAlive;
            if(alive < 2) break;
            for(int p = 0; p < game.gameHeader.getNumberOfPlayers(); ++p)
                if(game.players[p]->ai)
                {
                    auto order = game.players[p]->ai->getOrder(false);
                    order->sender = p;
                    game.executeOrder(order, 0);
                }
            game.syncStep(0);
        }
        std::ofstream summary(output / "summary.tsv");
        summary << "team\tstart\tend\tlaunches\tmeasured\tfailed\tmax_streak\ttrigger\tstreaming\n";
        for(int t = 0; t < game.teamsCount(); ++t)
        {
            const auto& o = observers[t];
            summary << t << '\t' << start << '\t' << game.stepCounter << '\t' << o.launches
                << '\t' << o.measured << '\t' << o.failed << '\t' << o.maxStreak
                << '\t' << o.firstTrigger << '\t' << streaming[t] << '\n';
        }
        return 0;
    }
    catch(const std::exception& error)
    {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
