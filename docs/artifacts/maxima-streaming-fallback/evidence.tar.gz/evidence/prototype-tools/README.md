# Maxima wave fallback prototype

This standalone harness measures real waves in the real simulation and optionally
hands control to Maxima's existing streaming attack controller. It does not change
production engine sources or the normal game executable.

The candidate rule has three pieces (the study also evaluates three failures):

1. Remember the enrolled force when a wave starts advancing and the largest number
   of healthy, still-enrolled warriors simultaneously within the existing siege
   radius of its objective.
2. Score the wave when enrollment falls to at most one quarter of its launch
   force, or its wave record disappears. Delivery below 33% counts as failure;
   successful delivery resets the consecutive-failure counter.
3. After four consecutive failures, end the current wave offensive and use the
   existing streaming controller for the remainder of the run.

The metric counts peak simultaneous presence, not unique arrivals. It does not
identify pathfinding failures specifically: heavy defenders, canceled objectives,
retreats, or dispersed arrivals can also cause a failure. Waves already advancing
when a save is loaded are excluded because their launch force is unknown. Waves
that never launch or never shrink to the scoring boundary are not detected.
There are no new timeouts, path searches, map checks, or retreat heuristics.

## Run

First build the normal client using the repository's development instructions.
The harness links its current objects; rebuild them after any source changes.
From the repository root:

```sh
python3 tools/maxima-wave-study/run.py build --output /tmp/wave-study
python3 tools/maxima-wave-study/run.py run --output /tmp/wave-study \
  --plan /tmp/plan.json --jobs 2
python3 tools/maxima-wave-study/analyze.py /tmp/wave-study/runs
```

Example plan (ticks means additional simulation ticks):

```json
[
  {"name":"normal", "mode":"map", "file":"maps/balanced_for_2.map",
   "seed":41, "opponent":7, "ticks":90000, "percent":33, "action":"observe"},
  {"name":"saved-fallback", "mode":"save", "file":"/absolute/path/input.game",
   "ticks":12000, "percent":33, "failures":4, "action":"fallback"}
]
```

Map mode supports two teams, Maxima against Maxima (`7`) or Nicowar (`5`). Save
mode preserves saved AI players and issues no new human orders. Each job uses an
isolated profile. A run stops at its tick budget or fewer than two living teams.
Run names must be unique within the output directory. `PASS` means the simulation
completed without a process error; it is not a detector-quality assertion.

`events.tsv` contains launch observations and scored waves; `timeline.tsv` samples
army size, wave count, latch state, enemy structures/HP and (in the final harness)
mission flag/enrollment every 1,000 ticks. The `streaming` column is only the
prototype fallback latch; a zero does not exclude Maxima using its existing
amphibious streaming controller. `summary.tsv` includes the
first trigger tick. `job.json` records input hashes and exact commands.
`analyze.py` re-scores the same observations at 25%, 33%, and 50%, with three or four failures; only observe-mode
runs are comparable after a trigger, since fallback changes subsequent play.

## Scope and compatibility

The latch is experimental process-local state: **it is not saved or restored**.
The normal executable has no fallback. This is a measurement and handoff prototype,
not a shippable implementation. A production change needs saved launch/arrival/
failure/latch state, backward-compatible loading, replay/network compatibility
review, and platform checksum verification. Only macOS arm64 was exercised here.

See the [retained study](../../docs/artifacts/maxima-wave-fallback/REPORT.md) for
observations, limitations, inputs and reproduction instructions.

## Fixed-rule generator sweep

The broader sweep keeps 33% delivery / four failures fixed and observes without
switching. It generates 20 named generators at two new seeds, runs each against
Maxima and Nicowar on 128×128 two-team maps, and allows 90,000 ticks per game.
Generation failures are recorded without silently replacing seeds. The initial
matrix is in `sweep.py`; generated `design.json` and `plan.json` record the exact
settings used.

```sh
python3 tools/maxima-wave-study/run.py build --output /tmp/wave-broad
python3 tools/maxima-wave-study/sweep.py --output /tmp/wave-broad --jobs 6
python3 tools/maxima-wave-study/summarize_sweep.py /tmp/wave-broad \
  --output /tmp/wave-broad/analysis
```

The summarizer excludes incomplete/failed jobs from rates, separates games from
individual Maxima teams, counts teams with at least four scored waves, and reports
successful delivery by waves launched after a trigger. Later success demonstrates recovery in
wave delivery, not necessarily a won game or that fallback would have been worse.

The [80-game sweep report](../../docs/artifacts/maxima-wave-broad/REPORT.md)
contains the broader fixed-rule results and exact replay inputs.

## GUI prototype

`build_gui.py --output /tmp/wave-gui` builds `glob2-wave-prototype` with the same
observer extracted directly from `MaximaWaveStudy.cpp`. Generated copies hook
Maxima construction, order polling and wave control; production sources remain
unchanged. Every newly constructed Maxima starts with an empty observer and latch.
The GUI always uses 33% / four failures. `GLOB2_WAVE_STUDY_SAVE` opens a save at
startup; `GLOB2_WAVE_STUDY_PAUSE=1` pauses loaded games (press P to resume).
Use an isolated `GLOB2_USER_DIR` and `-d /absolute/path/to/repository` for assets.
The latch still is not serialized: reload starts its measurements afresh.

The GUI opened in this session is `/tmp/maxima-wave-gui/Maxima Wave Fallback.app`,
using `/tmp/maxima-wave-gui/profile`; its event output is `/tmp/maxima-wave-gui/gui.log`.
