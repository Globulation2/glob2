#!/usr/bin/env python3
"""Re-score retained wave observations at 25%, 33%, and 50% delivery and three/four failures.

Usage: python3 tools/maxima-wave-study/analyze.py RUNS_DIRECTORY
Only observe-mode runs are threshold-comparable after a trigger.
"""
import csv
import json
from pathlib import Path
import sys


def analyze(root):
    writer = csv.writer(sys.stdout, delimiter='\t', lineterminator='\n')
    writer.writerow(['run', 'action', 'team', 'percent', 'failures_required', 'measured', 'failed', 'max_streak', 'trigger'])
    for directory in sorted(root.iterdir()):
        if not (directory / 'summary.tsv').exists():
            continue
        job = json.loads((directory / 'job.json').read_text())
        events = [line.split('\t') for line in (directory / 'events.tsv').read_text().splitlines()
                  if line.startswith('wave\t')]
        teams = sorted({int(row[2]) for row in events})
        for team in teams:
            for percent in (25, 33, 50):
                for required in (3, 4):
                    streak = maximum = failed = count = 0
                    trigger = -1
                    for row in events:
                        if int(row[2]) != team:
                            continue
                        failure = int(row[5]) * 100 < int(row[4]) * percent
                        count += 1
                        failed += failure
                        streak = streak + 1 if failure else 0
                        maximum = max(maximum, streak)
                        if streak >= required and trigger < 0:
                            trigger = int(row[1])
                    writer.writerow([directory.name, job.get('action', 'observe'), team,
                                     percent, required, count, failed, maximum, trigger])



if __name__ == '__main__':
    analyze(Path(sys.argv[1]))
