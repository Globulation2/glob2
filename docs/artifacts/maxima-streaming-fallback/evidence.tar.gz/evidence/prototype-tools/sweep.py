#!/usr/bin/env python3
"""Fixed-threshold, observation-only generator sweep (run from repository root)."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import gzip
import json
import os
from pathlib import Path
import subprocess
import sys

from run import ROOT, run_job

GENERATORS = ['even-ground', 'symmetric-arena', 'savannah', 'contested-commons',
              'isles', 'islands', 'rugged-archipelago', 'shattered-coast',
              'river', 'braided-delta', 'canals', 'portage-lakes',
              'maze', 'switchbacks', 'stone-highlands', 'hills',
              'old-town', 'forts', 'swamp', 'drowned-forest']
SEEDS = [2101, 7919]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--jobs', type=int, default=6)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output / 'design.json').write_text(json.dumps({
        'generators': GENERATORS, 'map_seeds': SEEDS, 'opponents': [7, 5],
        'width': 128, 'height': 128, 'teams': 2, 'ticks': 90000,
        'percent': 33, 'failures': 4, 'action': 'observe',
        'note': 'Defaults otherwise; no retries or seed substitutions for generation failures.',
    }, indent=2) + '\n')
    jobs, generation = [], []
    for generator in GENERATORS:
        for seed in SEEDS:
            dest = output / 'maps' / f'{generator}-{seed}'
            dest.mkdir(parents=True, exist_ok=False)
            profile = dest / 'profile'
            profile.mkdir()
            command = [str(ROOT / 'build/src/glob2'), '--generate-map', generator,
                       '--seed', str(seed), '--width', '128', '--height', '128',
                       '--teams', '2', '--output', str(dest / 'input.map'),
                       '--json', str(dest / 'report.json')]
            with (dest / 'generation.log').open('w') as log:
                result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=log,
                                        env={**os.environ, 'GLOB2_USER_DIR': str(profile)})
            generation.append(dict(generator=generator, seed=seed, command=command,
                                   exit_code=result.returncode))
            print('GENERATE', generator, seed, result.returncode, flush=True)
            if result.returncode:
                continue
            (dest / 'input.map.gz').write_bytes(gzip.compress((dest / 'input.map').read_bytes(), mtime=0))
            for opponent in (7, 5):
                jobs.append(dict(name=f'{generator}-{seed}-ai{opponent}', mode='map',
                                 file=str(dest / 'input.map'), generator=generator,
                                 seed=seed, opponent=opponent, ticks=90000,
                                 percent=33, failures=4, action='observe'))
    (output / 'generation.json').write_text(json.dumps(generation, indent=2) + '\n')
    (output / 'plan.json').write_text(json.dumps(jobs, indent=2) + '\n')
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        results = list(pool.map(lambda job: run_job(output, job), jobs))
    if any(results):
        sys.exit(1)


if __name__ == '__main__':
    main()
