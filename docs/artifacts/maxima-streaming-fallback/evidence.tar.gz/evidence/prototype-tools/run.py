#!/usr/bin/env python3
"""Build/run an isolated wave fallback experiment without changing engine sources.

build: --output /tmp/wave-study
run:   --output /tmp/wave-study --plan plan.json --jobs 2
Each plan entry has name, mode, file, seed, opponent, ticks, action, percent, failures.
Opponent is the engine AI implementation ID; all inputs and results stay local.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]


def build(output, build_dir):
    output.mkdir(parents=True, exist_ok=True)
    packages = ["sdl2", "SDL2_net", "SDL2_ttf", "SDL2_image", "vorbisfile", "speex", "fribidi", "epoxy"]
    pkg = lambda kind: shlex.split(subprocess.check_output(["pkg-config", kind, *packages], text=True))
    flags = ["-std=gnu++20", "-O2", "-g", "-I.", "-Isrc", "-Ilibgag/include", "-Ilibusl/src",
             *["-I" + str(p) for p in (ROOT / "src").rglob("*") if p.is_dir()], *pkg("--cflags")]
    libs = [*pkg("--libs"), "-lboost_date_time", "-lpthread", "-lz"]
    libs += ["-framework", "OpenGL", "-framework", "GLUT"] if sys.platform == "darwin" else ["-lGL", "-lGLU"]
    compiler = shlex.split(os.environ.get("CXX", "c++"))
    combat = ROOT / "src/ai/maxima/AIMaximaCombat.cpp"
    text = combat.read_text()
    anchor = "bool Maxima::control_offense_waves(Context& echo)\n{"
    if text.count(anchor) != 1:
        raise RuntimeError("combat controller changed; review the study hook")
    text = 'class Player;\nextern bool maximaStudyStreaming(Player*);\n' + text.replace(
        anchor, anchor + "\n\tif(maximaStudyStreaming(echo.player)) return false;")
    overlay = output / "AIMaximaCombat.cpp"
    overlay.write_text(text)
    sources = (ROOT / "src/SConscript").read_text().split('"""')[1].split()
    objects = [build_dir / "src" / Path(s).with_suffix(".o") for s in sources
               if s not in ("Glob2.cpp", "ai/maxima/AIMaximaCombat.cpp")]
    objects += [build_dir / "libgag/src/libgag.a", build_dir / "libusl/src/libusl.a"]
    missing = [str(p) for p in objects if not p.exists()]
    if missing:
        raise RuntimeError("Build the client first; missing " + ", ".join(missing))
    for source in [overlay, ROOT / "tools/maxima-wave-study/MaximaWaveStudy.cpp"]:
        obj = output / (source.stem + ".o")
        subprocess.run([*compiler, *flags, "-c", str(source), "-o", str(obj)], cwd=ROOT, check=True)
        objects.append(obj)
    subprocess.run([*compiler, *map(str, objects), *libs, "-o", str(output / "study")], cwd=ROOT, check=True)
    (output / "build.json").write_text(json.dumps({
        "revision": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "combat_sha256": hashlib.sha256(combat.read_bytes()).hexdigest(),
        "platform": sys.platform,
    }, indent=2) + "\n")


def run_job(output, job):
    dest = output / "runs" / job["name"]
    dest.mkdir(parents=True, exist_ok=False)
    source = Path(job["file"]).resolve()
    command = [str(output / "study"), job["mode"], str(source), str(job.get("seed", 19)),
               str(job.get("opponent", 7)), str(job.get("ticks", 60000)), job.get("action", "observe"),
               str(job.get("percent", 33)), str(job.get("failures", 4)), str(dest)]
    (dest / "job.json").write_text(json.dumps({**job, "command": command,
        "input_sha256": hashlib.sha256(source.read_bytes()).hexdigest()}, indent=2) + "\n")
    with (dest / "stdout.log").open("w") as stdout, (dest / "stderr.log").open("w") as stderr:
        result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr)
    (dest / "exit-code.txt").write_text(str(result.returncode) + "\n")
    print(job["name"], "PASS" if result.returncode == 0 else "FAILED", flush=True)
    return result.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["build", "run"])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--build-dir", type=Path, default=ROOT / "build")
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--jobs", type=int, default=2)
    args = parser.parse_args()
    output = args.output.resolve()
    if args.command == "build":
        build(output, args.build_dir.resolve())
    else:
        if not args.plan or args.jobs < 1:
            parser.error("run requires --plan and a positive --jobs")
        jobs = json.loads(args.plan.read_text())
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            results = list(pool.map(lambda job: run_job(output, job), jobs))
        if any(results):
            raise SystemExit(1)


if __name__ == "__main__":
    main()
