#!/usr/bin/env python3
"""Summarize completed fixed-rule sweep games without treating missing games as negatives."""
import argparse
import csv
import json
from pathlib import Path


def write_tsv(path, rows, fields):
    with path.open('w') as out:
        writer = csv.DictWriter(out, fields, delimiter='\t', lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)


def summarize(root, output):
    output.mkdir(parents=True, exist_ok=True)
    plan = json.loads((root / 'plan.json').read_text())
    teams, games, incomplete, errors = [], [], [], []
    for job in plan:
        directory = root / 'runs' / job['name']
        if not (directory / 'exit-code.txt').exists():
            incomplete.append(job['name'])
            continue
        if (directory / 'exit-code.txt').read_text().strip() != '0':
            errors.append(job['name'])
            continue
        summary = list(csv.DictReader((directory / 'summary.tsv').open(), delimiter='\t'))
        events = (directory / 'events.tsv').read_text().splitlines()
        waves = [list(map(int, line.split('\t')[1:]))
                 for line in events if line.startswith('wave\t')]
        launches = {(int(parts[2]), int(parts[3])): int(parts[1])
                    for parts in (line.split('\t') for line in events)
                    if parts[0] == 'launch'}
        game_teams = []
        for row in summary:
            team = int(row['team'])
            if team == 1 and job['opponent'] != 7:
                continue
            records = [w for w in waves if w[1] == team]
            trigger = int(row['trigger'])
            later_scored = [w for w in records if trigger >= 0 and w[0] > trigger]
            after = [w for w in later_scored if launches[(team, w[2])] > trigger]
            successes = [w for w in after if w[7] == 0]
            record = dict(run=job['name'], generator=job['generator'], seed=job['seed'],
                          opponent=job['opponent'], team=team, end=int(row['end']),
                          launches=int(row['launches']), measured=int(row['measured']),
                          failed=int(row['failed']), max_streak=int(row['max_streak']),
                          trigger=trigger, later_scored_waves=len(later_scored),
                          later_scored_successes=sum(w[7] == 0 for w in later_scored),
                          later_waves=len(after), later_successes=len(successes),
                          first_later_success=successes[0][0] if successes else -1)
            assert len(records) == record['measured']
            assert sum(w[7] for w in records) == record['failed']
            assert int(row['streaming']) == 0
            teams.append(record)
            game_teams.append(record)
        games.append(dict(run=job['name'], generator=job['generator'], seed=job['seed'],
                          opponent=job['opponent'], end=int(summary[0]['end']),
                          triggered=int(any(r['trigger'] >= 0 for r in game_teams)),
                          scored_waves=sum(r['measured'] for r in game_teams)))
    totals = dict(planned_games=len(plan), completed_games=len(games),
                  incomplete=incomplete, errors=errors, maxima_teams=len(teams),
                  triggered_games=sum(r['triggered'] for r in games),
                  triggered_teams=sum(r['trigger'] >= 0 for r in teams),
                  teams_with_four_scored_waves=sum(r['measured'] >= 4 for r in teams),
                  teams_without_launches=sum(r['launches'] == 0 for r in teams),
                  teams_without_scored_waves=sum(r['measured'] == 0 for r in teams),
                  scored_waves=sum(r['measured'] for r in teams),
                  triggered_teams_with_later_success=sum(r['later_successes'] > 0 for r in teams),
                  games_reaching_cap=sum(r['end'] == 90000 for r in games))
    groups = []
    for generator in sorted({j['generator'] for j in plan}):
        g = [r for r in games if r['generator'] == generator]
        t = [r for r in teams if r['generator'] == generator]
        groups.append(dict(generator=generator, completed_games=len(g),
                           triggered_games=sum(r['triggered'] for r in g),
                           maxima_teams=len(t), triggered_teams=sum(r['trigger'] >= 0 for r in t),
                           eligible_teams=sum(r['measured'] >= 4 for r in t),
                           zero_launch_teams=sum(r['launches'] == 0 for r in t),
                           scored_waves=sum(r['measured'] for r in t),
                           later_success_teams=sum(r['later_successes'] > 0 for r in t)))
    for name, rows in [('games', games), ('teams', teams), ('generators', groups)]:
        if rows:
            write_tsv(output / f'{name}.tsv', rows, list(rows[0]))
    (output / 'totals.json').write_text(json.dumps(totals, indent=2) + '\n')
    print(json.dumps({k:v for k,v in totals.items() if k not in ['incomplete','errors']}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    summarize(args.root, args.output)
