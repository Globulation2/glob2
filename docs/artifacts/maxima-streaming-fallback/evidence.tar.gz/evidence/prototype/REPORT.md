# Maxima wave fallback experiment — 2026-09-20

The simplest promising candidate is **four consecutive waves delivering less
than 33% of their launch force**, then permanently selecting streaming. It detects
the supplied stalled game and both newly generated Isles seeds, with no triggers
in eight normal-map matches (27 scored waves, including extended runs). Three
failures triggered prematurely in a recovering normal game; four avoids that
observed counterexample without adding another condition.

This is exploratory threshold selection, not independent validation of the final
four-failure rule. Streaming is functional, but improved combat results remain
unproven. Production Maxima is unchanged.

## Candidate

At wave launch, retain enrolled force and then peak simultaneous healthy enrolled
warriors within Maxima's existing siege radius of that wave's objective. Score
once enrollment falls to <=25% of launch force, or the wave disappears. Delivery
below **33%** is failure; other outcomes reset the streak. **Four consecutive
failures** permanently select the existing streaming controller for this run.
The handoff ends current waves through `end_offense()` and bypasses
`control_offense_waves()` thereafter. Existing streaming targeting, recruitment,
retreat and emergency behavior remains responsible for the attack.

This uses two measurements per active wave, a failure counter and a latch. It
adds no pathfinding queries, timing thresholds or map-specific conditions.
Concurrent waves count in scoring order. Already-advancing saved waves are
excluded because the original force is unavailable. The implementation uses
33 percent rather than an exact one-third fraction.

## Threshold exploration (initially three failures)

The first six normal matches and the user save were exploratory. Re-scoring
those same observations found:

| Delivery threshold | Supplied save | Normal-map finding |
| --- | --- | --- |
| 25% | Missed: longest failure streak 2 | No trigger |
| 33% | Trigger at tick 58,681 | No trigger |
| 50% | Trigger at tick 58,681 | Trigger on Balanced for 2 seed 19, team 0, tick 36,183 |

Extending the two capped Balanced games changed the conclusion: seed 19 reaches
three failures at **51,859**, then delivers 4 of 5 warriors at tick 58,546 and ends
at 62,725. Three failures would switch a normal game that subsequently recovers.
With four failures, all eight normal games stay below the threshold, while the
user save triggers at **60,136**, Isles 19 at **44,149 / 24,035** (teams 0 / 1), and
Isles 731 at **25,595**. This adjustment uses the same measurements and changes
only one integer. The final four-failure threshold has no held-out validation yet.

The two held-out normal games (Balanced seed 41, Muka seed 97) and both generated
Isles seeds were run after choosing 33%. These are small convenience samples,
not a statistical estimate of false-positive or false-negative rates. A trigger
on a normal map is not automatically erroneous: genuine repeatedly ineffective
attacks can also justify switching.

## Supplied save

Retained input: `maxima_not_attacking.game.gz` (decompress before loading).
Uncompressed SHA-256:
`4ae1ba52819c61d5c9812ab283e9705b68fb13c036dd8a78619cc3b791b4c9bc`.
Start tick 55,424, end tick 67,424 (12,000 additional ticks).

| Wave launch | Launched | Peak delivered | Scored |
| --- | ---: | ---: | ---: |
| 55,875 | 17 | 3 | 56,654 |
| 56,565 | 17 | 4 | 57,789 |
| 57,668 | 15 | 4 | 58,681 |

The initial three-failure detector triggers 3,257 ticks after loading, approximately 130 seconds at
25 ticks/second. The fallback run has zero waves at every subsequent sample and
keeps streaming mission flag **365** from tick 59,424 through 67,424, with varying
ongoing enrollment. A second execution produced identical wave-event output;
pre-trigger sampled metrics match the observation-only run.

This handoff is functional, but combat improvement is unproven. At tick 67,424:

| Controller | Maxima warriors | Enemy structures | Enemy aggregate HP |
| --- | ---: | ---: | ---: |
| Waves | 59 | 27 | 23,112 |
| Fallback | 39 | 33 | 23,066 |

These endpoint counts are not kill/damage counters: construction and rebuilding
can affect them. They do not support claiming that fallback won or improved this
case; streaming spent more of Maxima's army while leaving similar enemy HP.

The four-failure handoff was also executed, triggering at **60,136** (4,712 ticks,
about 188 seconds after loading). It retains streaming flag **371** through the
end. At tick 67,424 it has **58 warriors**, versus baseline 59, while the enemy has
**20 structures / 14,114 HP**, versus baseline 27 / 23,112. This is a better endpoint
in this saved continuation than either baseline waves or the earlier three-failure
handoff. It is one short continuation, not proof of superior win rate or a general
cure. The difference between three and four also shows that handoff timing matters.

## Fresh Isles observations (three-failure trigger shown)

Both maps use Isles revision 3, 128×128, two teams, default land bridges enabled.
Map seed and game seed match. Compressed map files and generation metadata are
retained under `maps/`. Each observation run covers 60,000 ticks.

| Seed / opponent | Maxima team | Scored waves | Failed at 33% | First trigger |
| --- | ---: | ---: | ---: | ---: |
| 19 / Maxima | 0 | 15 | 14 | 43,611 |
| 19 / Maxima | 1 | 17 | 16 | 22,707 |
| 731 / Nicowar | 0 | 10 | 10 | 23,362 |

These reproduce severe wave-delivery failure on additional Isles games. They do
not independently prove that every lost assignment had the exact engine cause
previously observed in the user save. Seed 19 even delivered some successful waves
before or after its failure streaks; the detector responds to repeated failure,
not absolute impossibility of reaching enemy territory.

Actual three-failure streaming runs also completed to tick 60,000. On seed 731,
the handoff at 23,362 left Maxima with 90 warriors versus baseline 78, and the
enemy with 12 structures / 9,640 HP versus baseline 26 / 19,193. On seed 19 the
mirror-game outcome was mixed: team 1 switched at 22,707, changing the subsequent
game enough that team 0 switched at 58,861 instead of its observation-only trigger.
All sampled latch states remained permanent, with zero active waves after switching.
These runs validate the handoff mechanism; they are not tactical tests of the final
four-failure setting on fresh Isles.

## Normal-map observations

| Map / game seed / opponent | End tick | Scored waves across Maximas | 33%, four-failure triggers |
| --- | ---: | ---: | ---: |
| Balanced for 2 / 19 / Maxima (extended) | 62,725 | 7 | 0 |
| Balanced for 2 / 731 / Nicowar (extended) | 90,000 | 2 | 0 |
| SmallForTwo / 19 / Maxima | 27,945 | 5 | 0 |
| SmallForTwo / 731 / Nicowar | 20,913 | 0 | 0 |
| Muka / 19 / Maxima | 25,756 | 4 | 0 |
| Muka / 731 / Nicowar | 27,800 | 1 | 0 |
| Balanced for 2 / 41 / Maxima (held out) | 45,608 | 6 | 0 |
| Muka / 97 / Maxima (held out) | 17,099 | 2 | 0 |

Runs below their budget ended when fewer than two teams were alive. The zero-wave
case provides no evidence about wave classification; seven matches had measured
waves. Exposure is limited to three normal maps and many teams launched fewer
than three waves. A supplementary army-capacity save produced no launched waves and is not useful
classification evidence. The separate saved arena continuation scored only three waves
across two Maximas, with no trigger, and is supplementary evidence only.

## Limits

- This is a poor-delivery detector, not a pathfinding bug diagnosis. Genuine
  defenses, recalls and tactical cancellation can also produce failed waves.
- Arrival means peak simultaneous healthy assigned presence near the objective,
  not unique arrivals or damage. Replacements are not tracked by identity.
- A wave that never launches or never reaches the attrition scoring boundary is
  not detected. No extra timeout was added to cover these different cases.
- The latch is process-local and is **not serialized**. It lasts the rest of this
  prototype run, not across a save/reload. Production adoption needs durable,
  backward-compatible state and save/replay/network validation.
- No production source or normal executable behavior was changed. Only macOS
  arm64 was tested; no cross-platform equivalence claim is made.
- Detection is promising; tactical superiority and broad normal-map safety are
  not established. Keep the rule simple while gathering more exposure rather
  than adding speculative special cases.

## Reproduce and inspect

See [harness instructions](../../../tools/maxima-wave-study/README.md). Build
metadata records engine revision `d37c0c353d9c2c68b4543286aa9b14e23ae7e526` and the
combat source hash. `runs/*/job.json` records exact commands, seeds, budgets and
input hashes; `events.tsv`, `timeline.tsv`, and `summary.tsv` are the raw evidence.
`thresholds.tsv` re-scores retained events at each exploratory percentage and failure-count threshold. For
observation runs made with 25%, use the re-scored 33% rows rather than the original
summary's threshold-specific failure/trigger columns.

The static normal maps are repository files. The arena input is the existing
`test/maxima/fixtures/save-continuation/checkpoint-30000-v115.game.gz`. Generate
fresh Isles inputs with (replace 19 by 731 for the second seed):

```sh
build/src/glob2 --generate-map --generator 6 --map-seed 19 \
  --param teams=2 --param width=7 --param height=7 \
  --write-map true --output-dir /tmp/isles19
```

Alternatively decompress the retained exact inputs and update the `file` fields
in a plan to those local paths. The retained `job.json` files include extra
provenance fields that the runner ignores, so they can be collected into a JSON
array and rerun after replacing old absolute input paths. Run from the repository
root. Output directories must be fresh.

A ready-to-run `plan.json` reproduces the final four-failure observation matrix
and the saved-game fallback. Prepare its three input paths first:

```sh
mkdir -p /tmp/maxima-wave-study-inputs
gzip -dc docs/artifacts/maxima-wave-fallback/maxima_not_attacking.game.gz > /tmp/maxima-wave-study-inputs/user.game
gzip -dc docs/artifacts/maxima-wave-fallback/maps/isles19/map-r0.map.gz > /tmp/maxima-wave-study-inputs/isles19.map
gzip -dc docs/artifacts/maxima-wave-fallback/maps/isles731/map-r0.map.gz > /tmp/maxima-wave-study-inputs/isles731.map
python3 tools/maxima-wave-study/run.py build --output /tmp/wave-reproduction
python3 tools/maxima-wave-study/run.py run --output /tmp/wave-reproduction \
  --plan docs/artifacts/maxima-wave-fallback/plan.json --jobs 2
```

The final candidate's fresh-Isles classifications are obtained by re-scoring
observation runs; separate fresh-Isles handoff runs use the original three-failure
setting. Do not confuse those runs with a four-failure tactical comparison.
