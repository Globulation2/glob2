import pathlib,subprocess,concurrent.futures,json,os
root=pathlib.Path(__file__).resolve().parent
binary=str(root/'opening-build')
ref=root/'forts.map'
subprocess.run([binary,'--generate-map','forts','--seed','7','--teams','4','--output',str(ref)],check=True)
def run(job):
 ai,kind=job;out=root/f'opening-{kind}-{ai}'
 cmd=[binary,'--run-game','--map-file',str(root/'v4.map' if kind=='kingdom' else ref),'--game-seed','1','--ticks','25000','--telemetry','team-timeline','--save','final','--output-dir',str(out)]
 for k in range(4):cmd+=['--player',ai,'--alliance',str(1 if k==0 else 2)]
 with open(str(out)+'.log','w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 return dict(ai=ai,kind=kind,exit=p.returncode)
with concurrent.futures.ThreadPoolExecutor(2) as pool:
 rows=list(pool.map(run,[(a,k) for a in ['nicowar','cortex','cabino','maxima'] for k in ['kingdom','forts']]))
json.dump(rows,open(root/'opening-results.json','w'),indent=2)
print(rows)
