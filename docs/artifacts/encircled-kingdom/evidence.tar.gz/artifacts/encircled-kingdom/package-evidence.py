"""Package selected reproducible evidence; excludes executables and incomplete runs."""
from pathlib import Path
import tarfile,io,json,hashlib,subprocess
root=Path(__file__).resolve().parent
repo=Path.cwd()
files=set()
def add(path):
 p=root/path
 assert p.is_file(),p
 files.add(p)
for name in ['validation-summary.json','package-evidence.py','parameter-study.py','analyze-parameters.py','parameters.jsonl','parameters.log','parameter-storage-recovery.json','parameter-analysis.json','parameter-analysis.log','fingerprints.py','regression-requests.json','fingerprints-final-before.json','fingerprints-final-after.json','fingerprints-final-comparison.json','benchmark-final.py','benchmark-final.json','benchmark-final.log','profile-final-before.log','profile-final-after.log','profile-final-before-sample.txt','profile-final-after-sample.txt','contracts-final.log','golden-final.log','golden-preservation.json','translations.log','translation-review.md','format.log','game-summary.json','game-provenance.json','timber-play.py','play-matrix.py','opening-results.json','opening-economies.json','openings.py','save-load-final/result.json','save-load-final.log','reviewer-r5/final-review.md','reviewer-r5/check_local_timber.py','reviewer-r5/local-timber-check.json','reviewer-r4/analyze_play.py','reviewer-r4/weak-eight-analysis.json','reviewer-r3/twelve-stack-full.log','reviewer-r3/forts12.map','reviewer-r3/forts12.log']:
 add(name)
for p in (root/'final-previews').iterdir():
 if p.suffix in ('.map','.json','.png'):files.add(p)
# Complete games only; developmental map files allow replaying their exact geometry.
games=[f'play-{n}-{101+n}' for n in range(3,12)] + ['final-twelve','timber-8','timber-12','reviewer-r3/three','reviewer-r3/twelve-cortex','reviewer-r4/three-siege','reviewer-r5/three-siege']
for game in games:
 add(game+'/result.json')
 p=root/game/'generated/map-r0.map'
 if p.exists():
  files.add(p);add(game+'/generated/result.json')
 for name in ['timber-8','timber-12']:
  if game==name:
   add(name+'.map');add(name+'.json')
for game in ['reviewer-r5/three-siege']:
 add(game+'/final.game')
for name in ['reviewer-r5/three-siege-final.png','reviewer-r5/eight-final.png']:
 add(name)
source=repo/'src/map/generator/generators/EncircledKingdomGenerator.cpp'
manifest={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'git_base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'platform':'macOS arm64','files':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}}
(root/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.add(root/'evidence-manifest.json')
archive=repo/'docs/artifacts/encircled-kingdom/evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(repo)),recursive=False)
 # Only telemetry is needed to reproduce the game-summary analysis. Full noisy AI logs remain locally.
 for game in games:
  p=root/(game+'.log')
  lines=b''.join(line for line in p.open('rb') if line.startswith(b'GLOB2_MEASURE '))
  entry=tarfile.TarInfo(str(p.relative_to(repo)));entry.size=len(lines);tar.addfile(entry,io.BytesIO(lines))
print(archive,archive.stat().st_size,'bytes;',len(files),'files plus',len(games),'filtered gameplay logs')
