import pathlib,json,subprocess,tempfile,hashlib,concurrent.futures,sys
root=pathlib.Path(__file__).resolve().parent
label,binary=sys.argv[1:];binary=str(pathlib.Path(binary).resolve())
rows=json.load(open(root/'regression-requests.json'))
rows += [dict(seed=17+n,teams=n,w=512 if n>=7 else 256,h=256,set={'fortress-plan':p}) for n in range(3,13) for p in range(1,4)]
def run(r):
 with tempfile.TemporaryDirectory() as temp:
  dest=pathlib.Path(temp)/'map.map'
  cmd=[binary,'--generate-map','encircled-kingdom','--seed',str(r['seed']),'--teams',str(r['teams']),'--width',str(r['w']),'--height',str(r['h']),'--output',str(dest)]
  for k,v in r['set'].items():cmd+=['--set',f'{k}={v}']
  p=subprocess.run(cmd,capture_output=True,text=True)
  return dict(request={k:r[k] for k in ['seed','teams','w','h','set']},exit=p.returncode,sha256=hashlib.sha256(dest.read_bytes()).hexdigest() if dest.exists() else None,diagnostic=p.stderr if p.returncode else '')
with concurrent.futures.ThreadPoolExecutor(4) as pool:out=list(pool.map(run,rows))
json.dump(out,open(root/f'fingerprints-{label}.json','w'),indent=2)
print(label,len(out),'failed',sum(r['exit']!=0 for r in out))
