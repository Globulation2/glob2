#!/usr/bin/env python3
"""Generate deterministic scarce-resource towns; verify 20-tile timber across all variants."""
import json,subprocess
from pathlib import Path
base=Path(__file__).resolve().parents[1];out=Path(__file__).resolve().parent
seen=set();rows=[]
for seed in range(1,21):
 p=out/f'local-timber24-{seed}'
 cmd=[str(base/'timber24-build'),'--generate-map','--generator','59','--map-seed',str(seed),'--param','teams=4','--param','width=8','--param','height=8','--param','wood-amount=0','--candidates','0','--report','terrain','--output-dir',str(p)]
 if not (p/'result.json').exists():
  with p.with_suffix('.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 j=json.loads((p/'result.json').read_text());m=j['map_report'];records=m['generation']['telemetry']['records'];v=next(r['value'] for r in records if r['key']=='kingdom.town-plan')
 f=(p/'terrain.txt').open();w,h=map(int,f.readline().split());g=[list(map(int,l.split())) for l in f];counts=[]
 for t in m['map']['colonies']:
  x,y=t['start']['x'],t['start']['y'];n=sum(g[(y+dy)%h][(x+dx)%w]==5 for dy in range(-20,21) for dx in range(-20,21) if dx*dx+dy*dy<=400);assert n>=16,(seed,t['team'],n);counts.append(n)
 rows.append({'seed':seed,'variant':v,'wood_amount':0,'nearby_counts':counts});seen.add(v)
 if len(seen)==3:break
assert len(seen)==3,seen
(out/'local-timber-check.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
