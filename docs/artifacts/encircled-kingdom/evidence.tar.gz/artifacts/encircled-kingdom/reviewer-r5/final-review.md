# Encircled Kingdom: final independent agent review

The same review agent inspected successive implementations, previews, live-world validation, cache integration, and AI game evidence. This is implementation review for the author, not independent human maintainer approval or human play feedback. No generator source was edited by the reviewer.

## Verdict

No new code, design, or visual blocker found in the final reviewed implementation. The landscape expresses the intended player-zero role: a connected agricultural heartland surrounded by smaller colonies, with distinct land gates and swimming approaches. Initial and late previews retain readable fortifications, contained fields, and open roads.

Final source uses the existing shared design cache, a 24-step initial wood-access limit, and at least 16 starter wood tiles within a 20-tile Euclidean radius of each actual starting swarm. The latter reallocates the existing wood budget. Cache review found the key covers every input used by layout construction; worker placement remains outside the cached design. Named random streams and telemetry are preserved, and validation still checks the live world. The parent reported 129 uncached fingerprint checks passing; final optimized comparisons, full parameter rerun, and regression checks remained in progress when this review was written.

## Iterative findings addressed

Reviews identified and subsequent revisions addressed oversized corner gates, disconnected town streets, sparse expansion fields, ineffective ambient-resource thresholds, missing balanced front assignments, unverified individual gates and waterfronts, unseeded zero-percent fields, and misleading local growth measurements. Revised routes preserve moat water, connect towns to fronts, and bound assigned walking distances. Farm-area and resource controls now have measurable effects. The nearby timber guarantee addresses a concrete resource-observation weakness discovered during playtesting.

All three town variants were independently generated at wood 0% and checked for the local timber floor. Every colony passed: variants 0 and 1 had 16 nearby tiles; sampled variant 2 towns had 21–26. See `check_local_timber.py` and `local-timber-check.json`.

## Final gameplay observations

- **Three players, final timber build, 30,000 ticks:** Nicowar capital against allied Cortex/Nicowar. Capital finished with 106 units, 23 buildings, 56 worker births, one worker starvation, and 5,659 building damage inflicted. All colonies survived. Outer Nicowar suffered 11 worker starvation deaths, beginning before combat, and later lost buildings. This demonstrates a functioning rich capital and actual fighting, not uniformly healthy economies.
- **Eight players, final timber build, 25,000 ticks:** all colonies survived, with zero worker or warrior starvation. Maxima colonies finished with 45–51 units and six or seven buildings. Formerly weak slot seven finished with 51 units, six buildings, and 32 wood harvested. Cortex colonies developed more slowly, with 16–23 units, including a 16-unit capital. No combat occurred.
- **Twelve players, final timber opening, 10,000 ticks:** all colonies established themselves, with zero worker or warrior starvation; two explorer starvation deaths occurred. This is an opening check, not a completed siege.
- **Earlier twelve-player route-build game, 30,000 ticks:** all colonies survived; the capital took 6,141 building damage, lost 17 buildings, and retained 57 units. First damage preceded first starvation. This demonstrates maximum-count coalition invasion on the preceding layout revision, not a final-timber long-game result.

The final three- and eight-player terrain previews show contained crop growth and clear roads and gates. See `three-siege-final.png` and `eight-final.png`.

## Weak-start investigation and limits

The original weak eight-player Maxima colony had starting wheat and wood access, ample building room, and an interior town location. Its late save contained three unfinished inns near a distant allied colony rather than near its own town. Separately, its initial wood lay outside Maxima's 20-tile local observation radius. The final guarantee repairs this map-level fragility; it does not fix the AI's distant building placement. More wood alone did not clearly resolve the behavior in controlled opening checks.

Do not claim uniform AI improvement from the remedy. Attack trajectories and economic outcomes changed, Cortex remains slow in some seeds, and starvation still occurs in some longer games. No human fun or equal-difficulty claim is established by these tests.

Twelve-player Nicowar has a pre-existing unbounded enemy-team iterator bug, independently reproduced on Forts and traced with LLDB. Maximum-count tests used Cortex/Maxima instead. No AI or simulation fix is included in this generator review.

## Reproduction and evidence

`../reviewer-r4/analyze_play.py` reads completed result files and gameplay logs and emits the per-team economy/combat summary. Run it from the repository root and redirect output as desired. `completed-play-analysis.json` captures all completed games known to the reviewer, preserving developmental and final-build games separately. `check_local_timber.py` reproduces the scarce-resource local-timber checks using the frozen `timber24-build` executable.

Final acceptance remains subject to the parent's final parameter sweep, contracts, golden checks, and optimized fingerprint verification. This review introduces no further requested code changes.
