#!/usr/bin/env python3
"""Reproduce completed-game review: python3 analyze_play.py [artifact-root].
Prints JSON; reads result.json and GLOB2_MEASURE logs without changing inputs.
"""
import json,re,sys
from pathlib import Path
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
paths=sorted(root.glob('play-*/result.json')) + sorted(root.glob('timber-*/result.json'))
paths += [root/'final-twelve/result.json',root/'reviewer-r3/three/result.json',root/'reviewer-r3/twelve-cortex/result.json',root/'reviewer-r4/three-siege/result.json',root/'reviewer-r5/three-siege/result.json']
output=[]
for result in paths:
    if not result.exists(): continue
    game=result.parent; log=game.with_suffix('.log')
    if not log.exists(): continue
    report=json.loads(result.read_text()); latest={}; first_damage={}; first_starvation={}
    for line in log.open(errors='replace'):
        if not line.startswith('GLOB2_MEASURE '): continue
        row={k:int(v) for k,v in re.findall(r'(\S+?)=(-?\d+)',line)}; team=row['team']; latest[team]=row
        if sum(v for k,v in row.items() if k.startswith('damageReceived_')):
            first_damage[team]=min(first_damage.get(team,row['tick']),row['tick'])
        if sum(row.get('deaths_%d_1'%u,0) for u in range(3)):
            first_starvation[team]=min(first_starvation.get(team,row['tick']),row['tick'])
    teams=[]
    for team in report['teams']:
        k=team['team']; row=latest.get(k,{}); history=team.get('history',[])
        teams.append(dict(team=k,ai=next((p['ai'] for p in report['players'] if p['team']==k),'unknown'),
            final_units=history[-1][0] if history else None,peak_units=max((h[0] for h in history),default=None),
            buildings=team['buildings'],eliminated_tick=team['eliminated_tick'],
            worker_births=row.get('births_0',0),wheat_harvest=row.get('harvested_1',0),
            worker_starvation=row.get('deaths_0_1',0),explorer_starvation=row.get('deaths_1_1',0),warrior_starvation=row.get('deaths_2_1',0),
            combat_deaths=sum(row.get('deaths_%d_0'%u,0) for u in range(3)),
            building_damage_received=sum(row.get('damageReceived_%d_1'%s,0) for s in range(3)),
            building_damage_dealt=sum(row.get('damageDealt_%d_1'%s,0) for s in range(3)),
            buildings_destroyed=sum(v for key,v in row.items() if key.startswith('removed_0_')),
            first_damage_tick=first_damage.get(k),first_starvation_tick=first_starvation.get(k),
            hungry=row.get('hungry',0),critical=row.get('critical',0)))
    output.append(dict(game=str(game.relative_to(root)),ticks=report['ticks'],termination=report['termination'],teams=teams))
print(json.dumps(output,indent=2))
