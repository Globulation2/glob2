import pathlib,subprocess,json,concurrent.futures
root=pathlib.Path(__file__).resolve().parent;binary=str(root/'timber-build')
def run(job):
 n,seed,plan,ticks=job;out=root/f'timber-{n}';mp=root/f'timber-{n}.map'
 p=subprocess.run([binary,'--generate-map','encircled-kingdom','--seed',str(seed),'--teams',str(n),'--width','512','--height','256','--set',f'fortress-plan={plan}','--output',str(mp),'--json',str(mp.with_suffix('.json'))],capture_output=True,text=True)
 if p.returncode:print(p.stdout,p.stderr);return
 cmd=[binary,'--run-game','--map-file',str(mp),'--game-seed','1','--ticks',str(ticks),'--telemetry','team-timeline','--save','final','--output-dir',str(out)]
 for k in range(n):cmd+=['--player','cortex' if k%2==0 else 'maxima','--alliance','1' if k==0 else '2']
 with open(str(out)+'.log','w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print(json.dumps(dict(teams=n,exit=p.returncode)),flush=True)
with concurrent.futures.ThreadPoolExecutor(2) as pool:list(pool.map(run,[(8,1994784839,3,25000),(12,213,3,10000)]))
