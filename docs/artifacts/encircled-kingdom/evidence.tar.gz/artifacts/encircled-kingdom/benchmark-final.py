import pathlib,subprocess,resource,time,json,tempfile,statistics
root=pathlib.Path(__file__).resolve().parent
binaries={'before':root/'final-uncached-build','after':pathlib.Path('build/src/glob2').resolve(),'forts':pathlib.Path('build/src/glob2').resolve()}
rows=[]
with tempfile.TemporaryDirectory() as temp:
 for seed in range(1,9):
  for label in ['before','after','forts']:
   gen='forts' if label=='forts' else 'encircled-kingdom'
   command=[str(binaries[label]),'--generate-map',gen,'--seed',str(seed),'--width','512','--height','512','--teams','12','--output',str(pathlib.Path(temp)/'map.map')]
   start=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.monotonic()
   p=subprocess.run(command,capture_output=True,text=True)
   end=resource.getrusage(resource.RUSAGE_CHILDREN)
   rows.append(dict(label=label,seed=seed,exit=p.returncode,cpu_ms=1000*(end.ru_utime+end.ru_stime-start.ru_utime-start.ru_stime),wall_ms=1000*(time.monotonic()-wall)))
json.dump(rows,open(root/'benchmark-final.json','w'),indent=2)
for label in binaries:
 r=[x for x in rows if x['label']==label];print(label,'success',sum(x['exit']==0 for x in r),'CPU ms',round(statistics.mean(x['cpu_ms'] for x in r),2),'wall ms',round(statistics.mean(x['wall_ms'] for x in r),2))
