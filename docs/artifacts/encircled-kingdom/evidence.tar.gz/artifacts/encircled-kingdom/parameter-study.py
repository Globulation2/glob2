import os,sys,pathlib,importlib.util,concurrent.futures,json,random,time
root=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('study',root/'control-study-driver.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
binary=os.environ.get('GLOB2_BINARY',str(pathlib.Path('build/src/glob2').resolve()));controls,defaults=m.controls(binary,'encircled-kingdom')
assert len(controls)==8 and all(controls.values()), controls
base=dict(binary=binary,generator='encircled-kingdom')
jobs=[]
for seed in range(1,9):
 for key,values in controls.items():
  for value in values:jobs.append(dict(base,study='ablation',control=key,value=value,seed=seed,w=256,h=256,teams=4,set={key:value}))
rng=random.Random(20260919)
for k in range(2000):
 n=rng.randint(3,12)
 shapes=[(512,256),(256,512),(512,512)]+([(256,256)] if n<=6 else [])
 w,h=rng.choice(shapes)
 settings={key:rng.choice(values) for key,values in controls.items()};settings['workers']=rng.randint(1,8)
 jobs.append(dict(base,study='random',control='',value=0,seed=100000+k,w=w,h=h,teams=n,set=settings))
# Every count, shape and explicit plan at abundance and layout extremes.
for n in range(3,13):
 for w,h in [(256,256),(256,512),(512,256),(512,512)]:
  if n>=7 and w*h<131072:continue
  for plan in range(1,4):
   for extreme in [0,300]:
    settings={key:extreme for key in controls if key.endswith('-amount')}
    settings.update({'fortress-plan':plan,'gate-width':6 if extreme==0 else 14,'heartland-farmland':75 if extreme==0 else 150,'workers':8})
    jobs.append(dict(base,study='extremes',control='',value=extreme,seed=41,w=w,h=h,teams=n,set=settings))
completed=[]
if '--resume' in sys.argv:
 completed=[json.loads(line) for line in (root/'parameters.jsonl').read_text().splitlines()]
 for row,job in zip(completed,jobs):
  assert all(row[k]==job[k] for k in ['study','control','value','seed','w','h','teams','set'])
 print('resuming after',len(completed),'completed requests',flush=True)
start=time.monotonic()
with concurrent.futures.ThreadPoolExecutor(4) as pool,open(root/'parameters.jsonl','a' if completed else 'w') as out:
 for n,row in enumerate(pool.map(m.run,jobs[len(completed):]),len(completed)+1):
  if row['ok'] and 'm' not in row: row.update(ok=False,detail='Missing parsed measurements: '+row.get('parse','unknown'))
  out.write(json.dumps(row)+'\n');out.flush()
  if not row['ok']:print('FAIL',json.dumps(row),flush=True)
  if n%100==0:print('progress',n,'/',len(jobs),'seconds',round(time.monotonic()-start),flush=True)
print('done',len(jobs),round(time.monotonic()-start),flush=True)
