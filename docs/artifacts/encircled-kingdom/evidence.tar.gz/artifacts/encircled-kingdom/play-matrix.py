import pathlib,subprocess,concurrent.futures,json,sys
root=pathlib.Path(__file__).resolve().parent
binary=str(root/'play-build')
# Newest town designs are fixed by these saved request seeds. P0 never rotates into the exterior.
jobs=[(n,101+n,1+(n%3)) for n in range(3,13)] + [(4,7,3),(6,211,1),(9,212,2),(12,213,3)]
def run(job):
 n,seed,plan=job;out=root/f'play-{n}-{seed}'
 cmd=[binary,'--run-game','--generator','59','--map-seed',str(seed),'--param',f'teams={n}','--param',f'width={9 if n>=7 else 8}','--param','height=8','--param',f'fortress-plan={plan}','--candidates','1','--game-seed','1','--ticks',str(45000 if seed>=200 else 30000),'--telemetry','team-timeline','--save','final','--output-dir',str(out)]
 # Echo/Nicowar's pre-existing full12 iterator crash is independently reproduced on Forts.
 # Cortex and Maxima have separate implementations and cover the full supported count.
 for k in range(n):cmd+=['--player',('cortex' if k%2==0 else 'maxima'),'--alliance',str(1 if k==0 else 2)]
 with open(str(out)+'.log','w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 row=dict(teams=n,seed=seed,plan=plan,exit=p.returncode)
 print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(2) as pool:rows=list(pool.map(run,jobs))
json.dump(rows,open(root/'play-results.json','w'),indent=2)
