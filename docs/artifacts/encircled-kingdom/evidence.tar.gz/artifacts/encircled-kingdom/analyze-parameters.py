import collections,json,pathlib,statistics
root=pathlib.Path(__file__).resolve().parent
rows=[json.loads(x) for x in open(root/'parameters.jsonl')]
assert len(rows)==2828, len(rows)
assert all('m' in r for r in rows if r['ok']), 'Missing measurements'
metrics={'gate-width':'tel:kingdom.gates.area','heartland-farmland':'tel:kingdom.economy.food-potential','wheat-amount':'tiles:wheat','wood-amount':'tiles:wood','stone-amount':'tiles:stone','algae-amount':'tiles:algae','fruit-amount':'tiles:cherry'}
report={'cases':len(rows),'passed':sum(r['ok'] for r in rows),'failed':[{k:r[k] for k in ['seed','teams','w','h','set','detail']} for r in rows if not r['ok']],'controls':{}}
for key,metric in metrics.items():
 group=collections.defaultdict(list);seeds=collections.defaultdict(dict)
 for r in rows:
  if r['ok'] and r['study']=='ablation' and r['control']==key:
   group[r['value']].append(r['m'][metric]);seeds[r['seed']][r['value']]=r['m'][metric]
 steps=[(seed,a,b,data[a],data[b]) for seed,data in seeds.items() for a,b in zip(sorted(data),sorted(data)[1:])]
 report['controls'][key]={'metric':metric,'means':{v:statistics.mean(a) for v,a in sorted(group.items())},'comparisons':len(steps),'nonincreasing':[x for x in steps if x[4]<=x[3]]}
report['by_study']={key:{'cases':sum(r['study']==key for r in rows),'passed':sum(r['study']==key and r['ok'] for r in rows)} for key in set(r['study'] for r in rows)}
json.dump(report,open(root/'parameter-analysis.json','w'),indent=2)
print(json.dumps(report,indent=2))
