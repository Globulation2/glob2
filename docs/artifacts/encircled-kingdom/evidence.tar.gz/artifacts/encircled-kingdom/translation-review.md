# Encircled Kingdom translation review

Reviewed and localized seven labels: **Encircled Kingdom**, **Fortress plan**,
**Automatic**, **Elongated enclosure**, **Bastioned enclosure**, **Paired
courtyards**, and **Heartland farmland**. The existing **Gate width** label is
reused.

Coverage: English and all 32 non-English runtime catalogs: ar, br, ca, cz, de,
dk, eo, es, eu, fa, fi, fr, gr, hu, id, it, ja, ko, nl, pl, pt, ro, ru, si, sk,
sr, sv, tr, uk, vi, zh-cn, and zh-tw. Keys are synchronized in
`data/texts.keys.txt`.

The review checked fortress and bastion terminology and distinguished geographic
heartland from homeland. Translations use natural local descriptions where a
literal architectural term would be awkward. Removed the newly scaffolded,
unused home-size diagnostic. No shared-vocabulary allowlist exceptions were
required. Generator diagnostics are displayed directly by the existing framework,
so no unused diagnostic translation keys were added.

Validation performed after editing:

- `python3 data/check_translations.py --strict`: passed; zero missing keys,
  untranslated entries, or structural errors. Existing obsolete entries were
  reported and left unchanged.
- `python3 test/test_translations.py`: all five tests passed.
- `git diff --check`: passed.

Limitations: this is an agent translation review, not native-speaker certification.
In-game label widths, font coverage, and right-to-left rendering have not been
visually verified. Existing raw-English generator diagnostics remain outside
these catalog edits.
