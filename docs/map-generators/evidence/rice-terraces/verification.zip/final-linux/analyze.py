from pathlib import Path
import json,collections
from tools.tournaments.results import Results
p=Path('artifacts/rice-terraces/final-linux');all={}
for name in ['training','held-out','crowded','scarce']:
 d=p/(name+'-results');out={'outcomes':{},'missing_reports':0,'fallback_maps':{},'maps':[]};counts=collections.Counter();falls=collections.Counter()
 for r in Results(d):
  status=r['result']['status'];counts[status]+=1;m=r['result'].get('map_report');row={'job':r['job'],'status':status}
  if not m:out['missing_reports']+=1;continue
  row['parameters']=m['generation']['parameters'];q=m.get('canonical_quality',{});row['fairness']=q.get('fairness');row['worst_score']=q.get('worst');cs=[c['raw'] for c in q.get('colonies',[])]
  if cs:row.update(min_build_sites=min(c['build_sites_4x4'] for c in cs),max_wheat_distance=max(c['wheat_distance'] for c in cs),max_wood_distance=max(c['wood_distance'] for c in cs))
  ts=m['generation'].get('telemetry',{}).get('records',[]);fs={t['key'] for t in ts if t['kind']=='fallback'};falls.update(fs);row['fallbacks']=sorted(fs);out['maps'].append(row)
 out['outcomes']=dict(counts);out['fallback_maps']=dict(falls);all[name]=out
 print(name,dict(counts),'missing',out['missing_reports'],'fallbacks',dict(falls),'minimum fairness',min((r['fairness'] for r in out['maps'] if isinstance(r['fairness'],(float,int))),default=None))
(p/'analysis.json').write_text(json.dumps(all,indent=2)+'\n')
for name in ['nicowar','numbi']:
 d=json.loads((p/name/'result.json').read_text());print(name,d['ticks'],[(t['alive'],t['units'],t['buildings'],t['warriors'],t['standard_statistics']['needFoodCritical']) for t in d['teams']])
rows=[r for a in all.values() for r in a['maps'] if 'min_build_sites' in r];print('room',min(r['min_build_sites'] for r in rows),'wheat',max(r['max_wheat_distance'] for r in rows),'wood',max(r['max_wood_distance'] for r in rows))
