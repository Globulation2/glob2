"""Summarize accepted logical generation jobs, keeping geometry rejections separate.
Inputs and result hashes are verified by Results. Never count telemetry rows or
worker attempts as map samples. Keep every non-fit failure for seed-level review.
"""
from pathlib import Path
from collections import Counter,defaultdict
import json,statistics,sys,csv
from tools.tournaments.results import Results
root=Path(sys.argv[1]);records=list(Results(root));rows=[];fallbacks=Counter();metrics=defaultdict(list);invariant_violations=[]
for r in records:
 j=r['job'];p=j['config']['params'];result=r['result'];report=result.get('map_report') or {};generation=report.get('generation') or {};outcome=generation.get('outcome') or {};telemetry=generation.get('telemetry') or {}
 status=result.get('status');stage=outcome.get('stage');detail=outcome.get('detail','')
 fit=(status in ('invalid_request','generation_failed') and 'Rice terraces need room for a summit' in detail)
 if status=='completed' and r['category']=='success' and report.get('report_type')=='map' and outcome.get('success') and telemetry.get('enabled') and generation.get('revision')==5:group='generated'
 elif status=='completed':group='unexpected_failure'
 elif fit:group='expected_fit_rejection'
 elif status=='invalid_request':group='invalid_request'
 else:group='unexpected_failure'
 keys={x['key'] for x in telemetry.get('records',[]) if x.get('kind')=='fallback'}
 if group=='generated':fallbacks.update(keys)
 values={x['key']:x['value'] for x in telemetry.get('records',[]) if x.get('kind')=='measurement' and x.get('subject') is None}
 for k,v in values.items():
  if isinstance(v,(int,float)) and not isinstance(v,bool) and group=='generated':metrics[k].append(v)
 if group=='generated':
  checks=[]
  wheat=[x['value'] for x in telemetry.get('records',[]) if x.get('kind')=='measurement' and x.get('key')=='rice.starter.wheat-tiles']
  if len(wheat)!=p.get('teams',4) or min(wheat,default=0)<8*p.get('stairs',3):checks.append('starter_wheat_shortfall')
  if values.get('rice.bands.per-hill',0)<1:checks.append('no_complete_band')
  if values.get('rice.hills.radius-actual',float('inf'))>values.get('rice.hills.radius-budget',float('-inf'))+1e-6:checks.append('radius_exceeds_budget')
  if values.get('rice.inns.per-colony')!=1:checks.append('starter_inn_count')
  if values.get('rice.towers.per-colony')!=(p.get('stairs',3) if p.get('starting-towers',1)>0 else 0):checks.append('tower_count')
  if checks:invariant_violations.append((j['id'],j['seeds']['map'],checks))
 crop_req={x['subject']:x['value'] for x in telemetry.get('records',[]) if x.get('kind')=='measurement' and x.get('key')=='rice.crops.requested'}
 crop_actual={x['subject']:x['value'] for x in telemetry.get('records',[]) if x.get('kind')=='measurement' and x.get('key')=='rice.crops.placed'}
 crop_fill=min((crop_actual.get(k,0)/v for k,v in crop_req.items() if v>0),default=None)
 row={'job':j['id'],'seed':j['seeds']['map'],'variant':j['labels']['variant'],'group':group,'category':r['category'],'status':status,'stage':stage,'error':outcome.get('error'),'detail':detail,'seconds':r['seconds'],'engine_seconds':result.get('seconds'),'width':1<<p.get('width',8),'height':1<<p.get('height',8),'teams':p.get('teams',4),'extra_hills':p.get('extra-hills',0),'band_width':p.get('band-width',100),'stairs':p.get('stairs',3),'towers':p.get('starting-towers',1),'telemetry_dropped':telemetry.get('dropped_records'),'telemetry_invalid':telemetry.get('invalid_values'),'fallbacks':sorted(keys),'crop_min_fill_ratio':crop_fill,'bands':values.get('rice.bands.per-hill'),'radius':values.get('rice.hills.radius-actual')}
 rows.append(row)
bygroup=Counter(x['group'] for x in rows);bycat=Counter(x['category'] for x in rows);byshape=defaultdict(list)
for x in rows:byshape[(x['width'],x['height'],x['teams'])].append(x)
percentiles=lambda v:{'minimum':min(v),'median':statistics.median(v),'p95':sorted(v)[int(.95*(len(v)-1))],'maximum':max(v)} if v else None
strata={f'{w}x{h}/{n}':{'jobs':len(a),'generated':sum(x['group']=='generated' for x in a),'fit_rejections':sum(x['group']=='expected_fit_rejection' for x in a),'other':sum(x['group'] not in ('generated','expected_fit_rejection') for x in a),'seconds_generated':percentiles([x['seconds'] for x in a if x['group']=='generated']),'engine_seconds_generated':percentiles([x['engine_seconds'] for x in a if x['group']=='generated' and isinstance(x['engine_seconds'],(int,float))])} for (w,h,n),a in sorted(byshape.items())}
domains={'width':list(range(6,10)),'height':list(range(6,10)),'teams':list(range(1,13)),'workers':list(range(1,9)),
 'extra-hills':list(range(0,5)),'hill-radius':list(range(44,101,4)),'band-width':[80,90,100,110,120],
 'stairs':[2,3,4],'starting-towers':[0,1,2,3],'valley-river':[0,1]}
for k in ['wheat-amount','wood-amount','stone-amount','algae-amount','fruit-amount']:domains[k]=list(range(0,301,25))
defaults={'width':8,'height':8,'teams':4,'workers':4,'extra-hills':0,'hill-radius':60,'band-width':100,'stairs':3,'starting-towers':1,'valley-river':1}
defaults.update({k:100 for k in ['wheat-amount','wood-amount','stone-amount','algae-amount','fruit-amount']})
generated_ids={x['job'] for x in rows if x['group']=='generated'}
requests=[r['job']['config']['params'] for r in records if r['job']['id'] in generated_ids]
coverage={k:{'observed_on_success':sorted({p.get(k,defaults[k]) for p in requests}),'missing_on_success':sorted(set(v)-{p.get(k,defaults[k]) for p in requests})} for k,v in domains.items()}
summary={'successful_control_coverage':coverage,'accepted':len(rows),'groups':dict(bygroup),'categories':dict(bycat),'strata':strata,'fallbacks_on_generated_maps':dict(fallbacks),'crop_fill_on_generated_maps':percentiles([x['crop_min_fill_ratio'] for x in rows if x['group']=='generated' and x['crop_min_fill_ratio'] is not None]),'telemetry_dropped_jobs':sum(bool(x['telemetry_dropped']) for x in rows),'missing_reports':sum(not (r['result'].get('map_report') or {}) for r in records),'telemetry_invalid_jobs':sum(bool(x['telemetry_invalid']) for x in rows),'metrics':{k:percentiles(v) for k,v in metrics.items() if k.startswith('rice.')},'slowest_generated':sorted((x for x in rows if x['group']=='generated'),key=lambda x:-x['seconds'])[:20],'revision_counts':dict(Counter((r['result'].get('map_report') or {}).get('generation',{}).get('revision') for r in records if r['result'].get('status')=='completed')),'invariant_violations':invariant_violations,'unexpected':[(x['job'],x['seed'],x['width'],x['height'],x['teams'],x['stage'],x['detail']) for x in rows if x['group']=='unexpected_failure']}
(root/'bulk-analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
with (root/'bulk-jobs.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else []);w.writeheader();w.writerows({**x,'fallbacks':','.join(x['fallbacks'])} for x in rows)
print(json.dumps({k:summary[k] for k in ['accepted','groups','categories','fallbacks_on_generated_maps','telemetry_dropped_jobs','telemetry_invalid_jobs','unexpected','invariant_violations']},indent=2))
