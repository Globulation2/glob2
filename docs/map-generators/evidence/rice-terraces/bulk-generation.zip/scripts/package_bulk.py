"""Build the review packet from accepted results and tested source identity."""
from __future__ import annotations

import hashlib
import json
import csv
from pathlib import Path
import zipfile

ROOT = Path(__file__).parent
REPO = ROOT.parent.parent
OUT = REPO / "docs/map-generators/evidence/rice-terraces/bulk-generation.zip"


def add_file(z: zipfile.ZipFile, path: Path, name: str, hashes: list[str]) -> None:
    data = path.read_bytes()
    z.writestr(name, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=7)
    hashes.append(f"{hashlib.sha256(data).hexdigest()}  {name}")


def add_tree(z: zipfile.ZipFile, source: Path, target: str, hashes: list[str]) -> None:
    for path in sorted(source.rglob("*")):
        # The overlay's older broad identity included documentation/test hashes
        # captured before this bulk report; bundle identity covers runtime only.
        if path.is_file() and path.name != "source-identity.json":
            add_file(z, path, f"{target}/{path.relative_to(source)}", hashes)


def main() -> None:
    discovery = json.loads((ROOT / "study-v2/bulk-analysis.json").read_text())
    heldout = json.loads((ROOT / "heldout-study/bulk-analysis.json").read_text())
    assert discovery["accepted"] == 1398
    assert discovery["groups"] == {
        "generated": 637,
        "expected_fit_rejection": 752,
        "unexpected_failure": 7,
        "invalid_request": 2,
    }
    assert heldout["accepted"] == 706
    assert not heldout["unexpected"] and not heldout["invariant_violations"]
    assert not heldout["telemetry_dropped_jobs"] and not heldout["telemetry_invalid_jobs"]
    assert len(list((ROOT / "study-v2/results").glob("*.json"))) == 1398
    assert len(list((ROOT / "heldout-study/results").glob("*.json"))) == 706
    with (ROOT / "heldout-study/bulk-jobs.csv").open(newline="") as f:
        regressions = [row for row in csv.DictReader(f) if row["variant"].startswith("regression-")]
    assert len(regressions) == 7 and all(row["group"] == "generated" for row in regressions)
    assert all(
        j["build"] == "e542befa64185d2b1de8c6a367fe0a8f1d0f95a27e23ba5f743e213389444d8b"
        for j in json.loads((ROOT / "heldout-study/experiment.json").read_text())["jobs"]
    )
    OUT.parent.mkdir(parents=True, exist_ok=True)
    hashes: list[str] = []
    with zipfile.ZipFile(OUT, "w") as z:
        for study in ("study-v2", "heldout-study"):
            for name in ("experiment.json", "bulk-analysis.json", "bulk-jobs.csv"):
                add_file(z, ROOT / study / name, f"{study}/{name}", hashes)
            add_tree(z, ROOT / study / "results", f"{study}/results", hashes)
        add_tree(z, ROOT / "config", "config", hashes)
        add_tree(z, ROOT / "linux-logs", "linux-logs", hashes)
        add_tree(z, ROOT / "regressions", "regressions", hashes)
        add_tree(z, ROOT / "revision5-seed7", "seed7-macos", hashes)
        add_tree(z, ROOT / "revision5-seed7-linux", "seed7-linux", hashes)
        add_tree(z, REPO / "artifacts/rice-playtest/runtime-sources/revision-5", "runtime-source-overlay", hashes)
        for source, target in (
            (REPO / "artifacts/rice-playtest/revision5-runtime-identity.json", "runtime-source-identity.json"),
            (ROOT / "translations.log", "macos-logs/translations.log"),
            (REPO / "artifacts/rice-playtest/revision5-final-macos-build.log", "macos-logs/build.log"),
            (REPO / "artifacts/rice-playtest/revision5-macos-build.log", "macos-logs/initial-build.log"),
            (REPO / "artifacts/rice-playtest/revision5-final-macos-contracts.log", "macos-logs/contracts.log"),
            (REPO / "artifacts/rice-playtest/revision5-final-macos-golden-update.log", "macos-logs/golden-update.log"),
            (REPO / "artifacts/rice-playtest/revision5-final-macos-golden.log", "macos-logs/golden-compare.log"),
            (ROOT / "package_bulk.py", "scripts/package_bulk.py"),
            (ROOT / "analyze-revision4.py", "scripts/analyze-revision4.py"),
            (ROOT / "analyze-revision5.py", "scripts/analyze-revision5.py"),
        ):
            add_file(z, source, target, hashes)
        z.writestr("SHA256SUMS", "\n".join(hashes) + "\n")
    with zipfile.ZipFile(OUT) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(set(z.namelist()))
    print(OUT, OUT.stat().st_size, hashlib.sha256(OUT.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
