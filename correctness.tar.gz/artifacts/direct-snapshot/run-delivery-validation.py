import os,sys,json,pathlib,subprocess,hashlib,time
root=pathlib.Path.cwd();out=root/'artifacts/direct-snapshot';build=root/'build/linux/client/release'
identity={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'base':'52e4d3dc0440e12ff65494ad3eb1681e9c2c0af3','binaries':{name:hashlib.sha256((build/name).read_bytes()).hexdigest() for name in ['test/glob2-engine-tests','test/glob2-unit-tests','src/glob2']},'commands':[]}
commands=[('delivery-headless-10',['--no-display',*sum((['--filter',s+'/*'] for s in ['Scene*','EngineSession','RuntimeContinuation','WorldSnapshot','ComputeExecutor','SharedWorkerLifecycle','SimulationReadPhase','AIPipeline','Save*','Replay*','TurnEngineHarness']),[])],False),('delivery-display-10',['--tag','display',*sum((['--filter',s+'/*'] for s in ['EngineSession','TerrainValidation','TerrainMaterials','TerrainPresentation','EditorPresentation']),[])],True)]
for label,options,display in commands:
 env=dict(os.environ);env.pop('DISPLAY',None);env['SDL_VIDEO_DRIVER']='x11' if display else 'dummy';env['SDL_AUDIO_DRIVER']='dummy';env['WAYLAND_DISPLAY']='codex-no-wayland'
 command=[sys.executable,'test/run_tests.py','-j','2','--display-jobs','1',*options,'--junit',str(out/(label+'.xml')),'--artifacts',str(out/label),'--write-inventory',str(out/(label+'-inventory.json'))]
 record={'label':label,'command':command,'environment':{k:env[k] for k in ['SDL_VIDEO_DRIVER','SDL_AUDIO_DRIVER','WAYLAND_DISPLAY']},'started_epoch':time.time()};identity['commands'].append(record)
 with (out/(label+'.log')).open('w') as log: result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit_code=result.returncode,finished_epoch=time.time())
 (out/'delivery-native-10.json').write_text(json.dumps(identity,indent=2)+'\n')
 if result.returncode:sys.exit(result.returncode)
