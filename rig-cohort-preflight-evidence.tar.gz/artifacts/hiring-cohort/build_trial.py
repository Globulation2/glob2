from pathlib import Path
import json,subprocess,shlex,re,os
p=Path(__file__).resolve().parent;root=Path.cwd().resolve()
databases=list((root/'build/linux').rglob('compile_commands.json'));assert databases, 'Build the matching ordinary release executable/database first'
database=next(d for d in databases if '/client/release/' in str(d) and 'dev-linker-auto' in str(d));entries=json.load(open(database));log=(p/'build-release.log').read_text().splitlines()
sources={'src/building/Step.cpp':'Step.cpp','src/building/HiringStudy.cpp':'HiringStudy.cpp','src/team/TeamStep.cpp':'TeamStep.cpp','src/game/GameAI.cpp':'GameAI.cpp','src/app/cli/Headless.cpp':'Headless.cpp','src/engine/EngineRun.cpp':'EngineRun.cpp','src/unit/Unit.cpp':'Unit.cpp'}
commands=[];replacements={};template=None
for source,private in sources.items():
 entry=next(e for e in entries if str(e['file']).replace('\\','/').endswith(source))
 args=entry.get('arguments') or shlex.split(entry['command']);args=list(args)
 original=args[args.index('-o')+1];dest=p/(Path(private).stem+'.o');args[args.index('-o')+1]=str(dest)
 # Identify the compilation input by path, preserving all feature/compiler flags.
 index=next(i for i,a in enumerate(args) if a.replace('\\','/').endswith(source));args[index]=str(p/private);args+=['-I'+str(p)]
 commands.append(args);replacements[original]=str(dest)
 if private=='Unit.cpp':template=args.copy()
assert template is not None
args=template.copy();args[args.index('-o')+1]=str(p/'CohortTelemetry.o');args[args.index(str(p/'Unit.cpp'))]=str(p/'CohortTelemetry.cpp');commands.append(args)
lines=[re.sub(r'\x1b\[[0-9;]*m','',l).strip() for l in log]
line=next(l for l in reversed(lines) if re.match(r'(?:g\+\+|c\+\+|/\S*/g\+\+) -o ',l) and re.search(r'/src/glob2(?: |$)',l))
link=shlex.split(line);normal=link[link.index('-o')+1];link=[replacements.get(a,a) for a in link];link[link.index('-o')+1]=str(p/'glob2-cohort');link.insert(link.index('-o')+2,str(p/'CohortTelemetry.o'))
(p/'compile-commands-private.json').write_text(json.dumps(commands,indent=2));(p/'link-command-private.json').write_text(json.dumps(link,indent=2));(p/'normal-binary.txt').write_text(str((root/normal).resolve())+'\n')
for c in commands:subprocess.run(c,cwd=root,check=True)
subprocess.run(link,cwd=root,check=True)
