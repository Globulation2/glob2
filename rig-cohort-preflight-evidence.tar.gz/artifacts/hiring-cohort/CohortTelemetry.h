#pragma once
#include <array>
#include <cstdint>
class Unit;
class Game;
namespace CohortTelemetry {
struct Exposure { std::uint64_t units=0,workers=0,hungry=0,critical=0; };
inline std::array<Exposure,32> exposure{};
void observe(Unit&);
void reset();
void sample(const Game&);
void write(const Game&,const char*);
}
