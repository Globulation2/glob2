from pathlib import Path
import json,subprocess,random,hashlib,concurrent.futures,os,time
p=Path(__file__).resolve().parent;root=Path.cwd();protocol=json.load(open(p/'protocol.json'));binary=p/'glob2-cohort';inputs=p/'inputs';inputs.mkdir(exist_ok=True)
seed_rng=random.Random(protocol['seed_generator']);assignment_rng=random.Random(protocol['policy_assignment_seed']);jobs=[];used=set()
for generator in protocol['generators']:
 for mix,composition in protocol['mixes'].items():
  for index in range(100):
   seed=seed_rng.randrange(1,2**32)
   while seed in used:seed=seed_rng.randrange(1,2**32)
   used.add(seed);players=composition.copy();seed_rng.shuffle(players)
   jobs.append({'id':f'{generator}-{mix}-{index:03d}','stratum':f'{generator}/{mix}','generator':generator,'mix':mix,'map_seed':seed,'game_seed':seed_rng.randrange(1,2**32),'players':players})
(p/'input-plan-before-policy.json').write_text(json.dumps(jobs,indent=2))
def generate(job):
 attempts=[]
 for attempt in range(100):
  seed=job['map_seed'] if attempt==0 else int.from_bytes(hashlib.sha256(f"replacement:{job['id']}:{attempt}:{protocol['seed_generator']}".encode()).digest()[:4],'little')
  dest=inputs/job['id'];report=Path(str(dest)+'.json');mapfile=Path(str(dest)+'.map.gz');log=Path(str(dest)+f'-a{attempt}.log')
  cmd=[str(binary),'map','generate',job['generator'],'--seed',str(seed),'--width','128','--height','128','--teams','8','--workers','4','--output',str(dest)+'.map','--report-file',str(report)]
  with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
  attempts.append({'attempt':attempt,'seed':seed,'command':cmd,'returncode':r.returncode})
  if r.returncode==0 and mapfile.exists():
   result=job|{'map_seed':seed,'map':str(mapfile.relative_to(root)),'map_sha256':hashlib.sha256(mapfile.read_bytes()).hexdigest(),'generation_attempts':attempts}
   (inputs/(job['id']+'-manifest.json')).write_text(json.dumps(result,indent=2));return result
  # Preserve failed diagnostic reports before the deterministic next seed.
  if report.exists():report.rename(Path(str(dest)+f'-failed-a{attempt}.json'))
 raise RuntimeError(f"No valid input after100 attempts: {job['id']}")
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
 for i,result in enumerate(executor.map(generate,jobs)):
  results.append(result)
  if (i+1)%50==0:print('generated',i+1,'/1200',flush=True)
assert len(results)==1200
for generator in protocol['generators']:
 for mix in protocol['mixes']:
  group=[j for j in results if j['stratum']==f'{generator}/{mix}'];labels=['original']*50+['cached-material']*50;assignment_rng.shuffle(labels)
  for j,arm in zip(group,labels):j['arm']=arm
# Schedule interleaves arms/strata independently of gameplay results.
schedule_rng=random.Random(protocol['policy_assignment_seed']+1);schedule_rng.shuffle(results)
manifest={'protocol_sha256':hashlib.sha256((p/'protocol.json').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'games':results}
(p/'manifest.json').write_text(json.dumps(manifest,indent=2));print('input/policy manifest',hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest(),flush=True)
