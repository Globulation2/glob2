#include "CohortTelemetry.h"
#include "Game.h"
#include "Unit.h"
#include "Team.h"
#include "Building.h"
#include "BuildingType.h"
#include "TeamStat.h"
#include <nlohmann/json.hpp>
#include <fstream>
#include <utility>
using Json=nlohmann::json;
namespace CohortTelemetry {
static Json samples=Json::array();
static_assert(Team::MAX_COUNT<=32);
void observe(Unit& u) {
 auto& e=exposure[u.owner->teamNumber];++e.units;
 if(u.typeNum==WORKER)++e.workers;
 if(u.isUnitHungry()) {
  ++e.hungry;
  if(u.hp<u.performance[HP] && !(u.attachedBuilding && u.insideTimeout<0 && u.attachedBuilding->type->canFeedUnit))++e.critical;
 }
}
void reset(){exposure={};samples=Json::array();}
static Json team(const Team& t) {
 const auto& m=t.stats.measurements;const auto& e=exposure[t.teamNumber];
 std::uint64_t births=0,starvation=0,combat=0,other=0,newBuildings=0,upgrades=0,repairs=0;
 for(std::size_t u=0;u<t.stats.unitTypeCount;++u) {
  births+=m.births[u];starvation+=m.deaths[u][GameplayMeasurements::STARVATION];combat+=m.deaths[u][GameplayMeasurements::COMBAT];
  for(int c=0;c<GameplayMeasurements::DEATH_CAUSES;++c)if(c!=GameplayMeasurements::STARVATION && c!=GameplayMeasurements::COMBAT)other+=m.deaths[u][c];
 }
 for(int b=0;b<IntBuildingType::NB_BUILDING;++b)for(int l=0;l<NB_UNIT_LEVELS;++l){newBuildings+=m.completed[GameplayMeasurements::NEW_BUILDING][b][l];upgrades+=m.completed[GameplayMeasurements::UPGRADED][b][l];repairs+=m.completed[GameplayMeasurements::REPAIRED][b][l];}
 Json labour=Json::array();for(auto value:m.labour)labour.push_back(value);
 Json filling=Json::array();for(const auto& row:m.filling){Json phases=Json::array();for(auto value:row)phases.push_back(value);filling.push_back(phases);}
 return {{"team",t.teamNumber},{"unit_ticks",e.units},{"worker_ticks",e.workers},{"hungry_ticks",e.hungry},{"critical_hunger_ticks",e.critical},
  {"units",t.liveUnits.size()},{"alive",t.isAlive},{"won",t.hasWon},{"lost",t.hasLost},{"births",births},{"starvation_deaths",starvation},{"combat_deaths",combat},{"other_deaths",other},
  {"new_buildings",newBuildings},{"upgrades",upgrades},{"repairs",repairs},{"harvested",m.harvested},{"delivered",m.delivered},{"meals",m.meals},{"labour",labour},{"filling",filling}};
}
void sample(const Game& g) {
 if(!samples.empty() && samples.back()["tick"]==g.stepCounter)return;
 Json teams=Json::array();for(int t=0;t<g.teamsCount();++t)teams.push_back(team(*g.teams[t]));
 samples.push_back({{"tick",g.stepCounter},{"teams",teams}});
}
void write(const Game& g,const char* path) {
 sample(g);Json teams=Json::array();for(int t=0;t<g.teamsCount();++t)teams.push_back(team(*g.teams[t]));
 Json report={{"schema_version",1},{"ticks",g.stepCounter},{"exposure_definition","One unit-tick per Unit::syncStep after terrain-health/dead guard. Worker ticks use WORKER type. Hungry uses isUnitHungry; critical follows TeamStat hungry/HP/not-already-fed predicate."},{"sample_interval",512},{"teams",teams},{"timeline",samples}};
 std::ofstream output(path);output<<report.dump();if(!output)throw std::runtime_error("Cannot write cohort telemetry");
}
}
