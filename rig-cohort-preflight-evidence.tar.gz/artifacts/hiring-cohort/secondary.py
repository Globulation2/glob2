from pathlib import Path
import json,collections,statistics,hashlib
p=Path(__file__).resolve().parent
manifest=json.load(open(p/'manifest.json'));protocol=json.load(open(p/'protocol.json'))
assert json.load(open(p/'finished.json'))['attempted']==protocol['total_games']
rows=[];trajectories=collections.defaultdict(list)
for job in manifest['games']:
 d=p/'runs'/job['id'];attempt=json.load(open(d/'attempt.json'))
 if not attempt['completed']:continue
 telemetry=json.load(open(d/'game/cohort-telemetry.json'));teams=telemetry['teams']
 row={k:job[k] for k in ['id','arm','stratum']}
 for key in ['unit_ticks','worker_ticks','births','meals','new_buildings','upgrades','repairs','starvation_deaths','combat_deaths','other_deaths']:
  row[key]=sum(t[key] for t in teams)
 for key in ['delivered','harvested']:row[key]=sum(sum(t[key]) for t in teams)
 row['population']=sum(t['units'] for t in teams);row['lost_colonies']=sum(t['lost'] for t in teams)
 row['labour']=[sum(t['labour'][i] for t in teams) for i in range(11)]
 row['filling']=[sum(sum(t['filling'][j]) for t in teams) for j in range(4)]
 row['recorded_worker_time']=sum(row['labour'])+sum(row['filling']);rows.append(row)
 for snapshot in telemetry['timeline']:
  ts=snapshot['teams'];trajectories[job['arm'],snapshot['tick']].append({'population':sum(t['units'] for t in ts),'alive_colonies':sum(t['alive'] for t in ts),'starvation_deaths':sum(t['starvation_deaths'] for t in ts),'new_buildings':sum(t['new_buildings'] for t in ts)})
def summary(group):
 total=lambda k:sum(r[k] for r in group)
 workers=total('worker_ticks');units=total('unit_ticks');worker_time=total('recorded_worker_time')
 return {'games':len(group),'totals':{k:total(k) for k in ['unit_ticks','worker_ticks','births','meals','new_buildings','upgrades','repairs','starvation_deaths','combat_deaths','other_deaths','delivered','harvested','lost_colonies']},'median_final_population':statistics.median(r['population'] for r in group),'mean_final_population':statistics.mean(r['population'] for r in group),'matches_with_any_colony_loss':sum(r['lost_colonies']>0 for r in group),'delivered_per_worker_tick':total('delivered')/workers,'harvested_per_worker_tick':total('harvested')/workers,'births_per_unit_tick':total('births')/units,'food_time_fraction_of_recorded_worker_time':sum(sum(r['labour'][1:4]) for r in group)/worker_time,'idle_fraction_of_recorded_worker_time':sum(r['labour'][0] for r in group)/worker_time,'filling_fraction_of_recorded_worker_time':sum(sum(r['filling']) for r in group)/worker_time,'recorded_worker_time':worker_time}
report={'primary_analysis_unchanged':True,'scope':'Secondary descriptive endpoints only; no multiplicity-adjusted claims. Time-use denominator is the existing recorded labour+filling counter, separately from exact Unit::syncStep exposure. Snapshot means include matches still represented at that tick and report n; early-ended matches are not forward-filled. Do not interpret conditional late trajectories as unconditional survival.','overall':{a:summary([r for r in rows if r['arm']==a]) for a in protocol['arms']},'strata':{s:{a:summary([r for r in rows if r['stratum']==s and r['arm']==a]) for a in protocol['arms']} for s in sorted({r['stratum'] for r in rows})},'trajectories':[{'arm':a,'tick':t,'games_observed':len(v),**{k:statistics.mean(r[k] for r in v) for k in ['population','alive_colonies','starvation_deaths','new_buildings']}} for (a,t),v in sorted(trajectories.items())]}
(p/'secondary-findings.json').write_text(json.dumps(report,indent=2));(p/'secondary-match-summary.json').write_text(json.dumps(rows,indent=2))
print('Secondary descriptive report written',len(rows),'matches')
