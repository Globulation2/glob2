from pathlib import Path
import json,subprocess,os,shlex,re,hashlib
p=Path(__file__).resolve().parent;root=Path.cwd();out=p/'verification';out.mkdir(exist_ok=False)
# Normal-source binary with compact trace export only; no Unit exposure hook or hiring replacement.
log=(p/'build-release.log').read_text().splitlines();line=next(l.strip() for l in reversed(log) if re.match(r'g\+\+ -o ',l.strip()) and '/src/glob2 ' in l)
link=shlex.split(line);originalEngine=next(a for a in link if a.endswith('/src/engine/EngineRun.o'));link[link.index(originalEngine)]=str(p/'EngineRun.o');link[link.index('-o')+1]=str(p/'glob2-reference-compact')
subprocess.run(link,check=True);(p/'link-command-reference.json').write_text(json.dumps(link,indent=2))
protocol=json.load(open(p/'protocol.json'));rows=[]
for generator,seed in [('river',11713),('islands',12017),('swamp',14093)]:
 for mix in ['nicowar','four-ai']:
  name=f'{generator}-{mix}';mapfile=out/(name+'.map.gz');cmd=[str(p/'glob2-cohort'),'map','generate',generator,'--seed',str(seed),'--width','128','--height','128','--teams','8','--workers','4','--output',str(out/(name+'.map')),'--report-file',str(out/(name+'-map.json'))]
  with (out/(name+'-generate.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
  identities={};digests={};telemetry={}
  for mode,n in [('reference',4),('original',4),('cached',1),('cached',4)]:
   dest=out/f'{name}-{mode}-{n}';cmd=[str(p/('glob2-reference-compact' if mode=='reference' else 'glob2-cohort')),'game','run','--map-file',str(mapfile),'--game-seed',str(seed+100000),'--ticks','8192','--benchmark-warmup','0','--compute-threads',str(n),'--gpu','off','--output-dir',str(dest)]
   for ai in protocol['mixes'][mix]:cmd+=['--player',ai]
   env=os.environ.copy();env.pop('GLOB2_ISOLATED_LIVE_HIRING',None);env.pop('GLOB2_SIM_THREAD',None);env['GLOB2_ISOLATED_TRACE']='1';env.update(SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='dummy')
   if mode=='cached':env['GLOB2_ISOLATED_LIVE_HIRING']='1';cmd+=['--hiring-schedule','4:4:128:combined','--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds','--hiring-execution','pool']
   with dest.with_suffix('.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
   result=json.load(open(dest/'result.json'));trace=(dest/'world.checksums').read_bytes();assert len(trace.splitlines())==result['ticks']
   identities[mode,n]=(result['finalChecksum'],hashlib.sha256(trace).hexdigest())
   if mode!='reference':
    t=json.load(open(dest/'cohort-telemetry.json'));assert sum(v['unit_ticks'] for v in t['teams'])>0;assert sum(v['worker_ticks'] for v in t['teams'])>0;telemetry[mode,n]=hashlib.sha256((dest/'cohort-telemetry.json').read_bytes()).hexdigest()
   if mode=='cached':digests[n]=json.load(open(dest/'hiring-compute.json'))['output_digest']
   rows.append({'case':name,'mode':mode,'participants':n,'command':cmd,'ticks':result['ticks'],'identity':identities[mode,n],'telemetry_sha256':telemetry.get((mode,n))});print(name,mode,n,result['ticks'],identities[mode,n],flush=True)
  assert identities['reference',4]==identities['original',4],(name,'observer changes simulation')
  assert identities['cached',1]==identities['cached',4] and digests[1]==digests[4] and telemetry['cached',1]==telemetry['cached',4],(name,'cached nondeterminism')
(out/'comparisons.json').write_text(json.dumps({'passed':True,'scope':'Linuxx86_64 only,3generators×2mixes×4controls,8192ticks or legitimate early termination. Compact per-tick hashes and published-output digests, telemetry identity.','runs':rows},indent=2))
