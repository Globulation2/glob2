from pathlib import Path
import json,math,statistics,random,collections,hashlib,time
p=Path(__file__).resolve().parent;protocol=json.load(open(p/'protocol.json'));manifest=json.load(open(p/'manifest.json'));records=[];failures=[]
for job in manifest['games']:
 directory=p/'runs'/job['id'];attempt=json.load(open(directory/'attempt.json'))
 if not attempt['completed']:failures.append(attempt);continue
 result=json.load(open(directory/'game/result.json'));telemetry=json.load(open(directory/'game/cohort-telemetry.json'));teams=telemetry['teams'];assert result['ticks']==telemetry['ticks']<=protocol['tick_horizon']
 def total(key):return sum(t[key] for t in teams)
 record={k:job[k] for k in ['id','stratum','generator','mix','arm','map_seed','game_seed','players']}
 for key in ['unit_ticks','worker_ticks','critical_hunger_ticks','hungry_ticks','starvation_deaths','combat_deaths','other_deaths','births','new_buildings','upgrades','repairs','meals']:record[key]=total(key)
 assert record['unit_ticks']>0 and record['worker_ticks']>0 and record['critical_hunger_ticks']<=record['unit_ticks']
 record.update(ticks=result['ticks'],population=total('units'),alive_colonies=sum(t['alive'] for t in teams),lost_colonies=sum(t['lost'] for t in teams),delivered=sum(sum(t['delivered']) for t in teams),harvested=sum(sum(t['harvested']) for t in teams),winner_ai=sorted({job['players'][t['team']] for t in teams if t['won']}),finished_before_cap=result['ticks']<protocol['tick_horizon'])
 records.append(record)
(p/'match-summary.json').write_text(json.dumps(records,indent=2));groups=collections.defaultdict(lambda:collections.defaultdict(list))
for r in records:groups[r['stratum']][r['arm']].append(r)
metrics={'starvation_rate':('starvation_deaths','unit_ticks'),'critical_hunger_fraction':('critical_hunger_ticks','unit_ticks'),'construction_rate':('new_buildings','worker_ticks')}
arms=['original','cached-material'];strata=sorted(groups)
def aggregate(rows):return [sum(r[k] for r in rows) for k in ['starvation_deaths','unit_ticks','critical_hunger_ticks','new_buildings','worker_ticks']]
def rates(v):return [v[0]/v[1],v[2]/v[1],v[3]/v[4]]
by_arm={arm:[r for r in records if r['arm']==arm] for arm in arms};totals={arm:aggregate(by_arm[arm]) for arm in arms};observed={arm:rates(totals[arm]) for arm in arms}
point={m:observed[arms[1]][i]/observed[arms[0]][i] for i,m in enumerate(metrics)}
# Resample whole-match event/exposure tuples jointly within arm×stratum.
vectors={s:{a:[aggregate([r]) for r in groups[s][a]] for a in arms} for s in strata};boot={m:[] for m in metrics};rng=random.Random(713013)
for draw in range(10000):
 sums={a:[0]*5 for a in arms}
 for s in strata:
  for a in arms:
   v=vectors[s][a]
   for _ in v:
    row=v[rng.randrange(len(v))]
    for k,value in enumerate(row):sums[a][k]+=value
 ra,rb=rates(sums[arms[0]]),rates(sums[arms[1]])
 for i,m in enumerate(metrics):boot[m].append(rb[i]/ra[i] if ra[i]>0 else float('inf'))
 if (draw+1)%2000==0:print('bootstrap',draw+1,flush=True)
# Fisher policy-label randomization within the allocated strata, not team/unit samples.
counts={m:0 for m in metrics};rng=random.Random(713991)
observed_diff=[observed[arms[1]][i]-observed[arms[0]][i] for i in range(3)]
for draw in range(10000):
 sums={a:[0]*5 for a in arms}
 for s in strata:
  rows=vectors[s][arms[0]]+vectors[s][arms[1]];rng.shuffle(rows);n=len(vectors[s][arms[0]])
  for index,row in enumerate(rows):
   a=arms[0] if index<n else arms[1]
   for k,value in enumerate(row):sums[a][k]+=value
 ra,rb=rates(sums[arms[0]]),rates(sums[arms[1]])
 for i,m in enumerate(metrics):counts[m]+=abs(rb[i]-ra[i])>=abs(observed_diff[i])
 if (draw+1)%2000==0:print('permutations',draw+1,flush=True)
pvalues={m:(counts[m]+1)/10001 for m in metrics};ordered=sorted(pvalues,key=pvalues.get);adjusted={};previous=0
for index,m in enumerate(ordered):previous=max(previous,min(1,pvalues[m]*(len(ordered)-index)));adjusted[m]=previous
primary={}
for i,m in enumerate(metrics):
 samples=sorted(boot[m]);primary[m]={'original_rate':observed[arms[0]][i],'cached_rate':observed[arms[1]][i],'rate_ratio':point[m],'relative_delta':point[m]-1,'match_bootstrap_95_ratio_interval':[samples[249],samples[9749]],'randomization_p':pvalues[m],'holm_p':adjusted[m],'significant_at_0_05':adjusted[m]<.05}
secondary={a:{'games':len(by_arm[a]),'units_at_end':sum(r['population'] for r in by_arm[a]),'starvation_deaths':sum(r['starvation_deaths'] for r in by_arm[a]),'lost_colonies':sum(r['lost_colonies'] for r in by_arm[a]),'new_buildings':sum(r['new_buildings'] for r in by_arm[a]),'mean_ticks':statistics.mean(r['ticks'] for r in by_arm[a]),'early_finished':sum(r['finished_before_cap'] for r in by_arm[a]),'winners_by_ai':dict(collections.Counter(ai for r in by_arm[a] for ai in r['winner_ai']))} for a in arms}
stratified={s:{a:{'games':len(groups[s][a]),'rates':dict(zip(metrics,rates(aggregate(groups[s][a]))))} for a in arms} for s in strata}
report={'protocol_sha256':hashlib.sha256((p/'protocol.json').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest(),'planned_games':protocol['total_games'],'successful_games':len(records),'technical_failures':failures,'primary':primary,'secondary_descriptive':secondary,'strata_descriptive':stratified,'interpretation':'Independent randomized match-level cohort. Bootstrap clustered by match and stratified by arm/generator/mix; policy-label randomization stratified by generator/mix; three primary p-values Holm-adjusted. Secondary/stratum summaries descriptive. Nonsignificance is not equivalence. Failure missingness can invalidate gameplay comparisons. Concurrent timings are not quiet-host performance evidence.'}
(p/'findings.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
