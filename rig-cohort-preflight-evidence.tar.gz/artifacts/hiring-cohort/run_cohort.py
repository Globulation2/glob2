from pathlib import Path
import json,subprocess,concurrent.futures,os,time,hashlib,traceback
p=Path(__file__).resolve().parent;root=Path.cwd();protocol=json.load(open(p/'protocol.json'));manifest=json.load(open(p/'manifest.json'));binary=p/'glob2-cohort';runs=p/'runs';runs.mkdir(exist_ok=True)
assert manifest['binary_sha256']==hashlib.sha256(binary.read_bytes()).hexdigest()
assert manifest['protocol_sha256']==hashlib.sha256((p/'protocol.json').read_bytes()).hexdigest()
def run(job):
 dest=runs/job['id'];status=dest/'attempt.json'
 if status.exists():return json.load(open(status))
 dest.mkdir(exist_ok=True);assert not (dest/'result.json').exists(),'Unexpected incomplete/restarted output'
 env=os.environ.copy();env.pop('GLOB2_ISOLATED_TRACE',None);env.pop('GLOB2_ISOLATED_LIVE_HIRING',None);env.pop('GLOB2_SIM_THREAD',None)
 env.update(SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='dummy')
 cmd=[str(binary),'game','run','--map-file',str(root/job['map']),'--game-seed',str(job['game_seed']),'--ticks',str(protocol['tick_horizon']),'--benchmark-warmup','0','--compute-threads',str(protocol['compute_participants_per_game']),'--gpu','off','--output-dir',str(dest/'game')]
 for ai in job['players']:cmd+=['--player',ai]
 if job['arm']=='cached-material':
  env['GLOB2_ISOLATED_LIVE_HIRING']='1';cmd+=['--hiring-schedule','4:4:128:combined','--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds','--hiring-execution','pool']
 start=time.monotonic();record={'id':job['id'],'arm':job['arm'],'stratum':job['stratum'],'command':cmd,'map_sha256':job['map_sha256'],'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
 (dest/'started.json').write_text(json.dumps(record,indent=2))
 try:
  with (dest/'stdout-stderr.log').open('w') as output:
   proc=subprocess.Popen(cmd,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=proc.wait(timeout=1800)
   except subprocess.TimeoutExpired:
    proc.terminate()
    try:proc.wait(timeout=15)
    except subprocess.TimeoutExpired:proc.kill();proc.wait()
    code=proc.returncode;record['timeout']=True
  record['returncode']=code;record['completed']=code==0 and (dest/'game/result.json').exists() and (dest/'game/cohort-telemetry.json').exists()
 except Exception as error:record.update(returncode=None,completed=False,error=str(error),traceback=traceback.format_exc())
 record['elapsed_wall_s']=time.monotonic()-start;record['end_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());status.write_text(json.dumps(record,indent=2));return record
jobs=manifest['games'];completed=[]
with (p/'cohort-events.jsonl').open('a') as log,concurrent.futures.ThreadPoolExecutor(max_workers=protocol['concurrent_games']) as executor:
 futures={executor.submit(run,j):j for j in jobs}
 for future in concurrent.futures.as_completed(futures):
  result=future.result();completed.append(result);log.write(json.dumps(result)+'\n');log.flush()
  progress={'completed_attempts':len(completed),'target':len(jobs),'successful':sum(r['completed'] for r in completed),'failures':sum(not r['completed'] for r in completed),'last':result['id'],'updated_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
  (p/'progress.json').write_text(json.dumps(progress,indent=2))
  if len(completed)%10==0 or not result['completed']:print(json.dumps(progress),flush=True)
(p/'finished.json').write_text(json.dumps({'target':len(jobs),'attempted':len(completed),'successful':sum(r['completed'] for r in completed),'failures':sum(not r['completed'] for r in completed)},indent=2))
