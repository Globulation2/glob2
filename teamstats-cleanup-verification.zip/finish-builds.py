import os,subprocess,time,json
from pathlib import Path
for pid,log,args in [(85808,'/tmp/stats-cleanup-build-final.log',['engine-tests','unit-tests']),(87874,'/tmp/stats-cleanup-release-final.log',None)]:
    while True:
        try: os.kill(pid,0)
        except ProcessLookupError: break
        time.sleep(2)
    with open(log,'w') as out:
        command=['python3','tools/dev_build.py']+args if args else ['python3','artifacts/teamstats/cleanup/build-release.py']
        subprocess.run(command,env=dict(os.environ,PYTHONPATH=os.getcwd()),stdout=out,stderr=subprocess.STDOUT,check=True)
# Existing thin release harness includes all client objects and selected test suites.
args=json.loads(Path('artifacts/teamstats/efficient/release-integrated-link-args.json').read_text())
args[2]='artifacts/teamstats/cleanup/glob2-engine-tests'
with open('/tmp/stats-cleanup-release-link.log','w') as out: subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,check=True)
