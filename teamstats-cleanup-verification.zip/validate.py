import subprocess,os,time
from pathlib import Path
# Run only when the final rebuild (including new compatibility assertions) is complete.
while not Path('/tmp/stats-cleanup-build-final.log').exists() or 'scons: done building targets.' not in Path('/tmp/stats-cleanup-build-final.log').read_text():
    time.sleep(2)
env=dict(os.environ,PYTHONPATH=os.getcwd())
base=['python3','test/run_tests.py','--build-dir','build/darwin/client/debug/dev-dev_fast-true-linker-auto','--binary','all','--no-display','--timeout','600','-j','2']
filters=['ComputeExecutor/*','ReadOnlyPhase/*','WorldSnapshot/*','TeamStatsPipeline/*','TeamStatsSave/*','TeamLabourStats/*','AIPipeline/*','MCP/*']
with open('artifacts/teamstats/cleanup/correctness.log','w') as log:
    subprocess.run(base+sum((['--filter',f] for f in filters),[])+['--junit','artifacts/teamstats/cleanup/correctness.xml'],stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
for update in [True,False]:
    with open('artifacts/teamstats/cleanup/golden-'+('update' if update else 'verify')+'.log','w') as log:
        subprocess.run(base+['--filter','TurnEngineHarness/the committed*','--junit','artifacts/teamstats/cleanup/golden-'+('update' if update else 'verify')+'.xml']+(['--update-fixtures'] if update else []),stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
