#include EXHEADER
#include <iostream>
struct Work { std::atomic<unsigned> count{0}; };
void job(void* context, std::size_t) { static_cast<Work*>(context)->count.fetch_add(1,std::memory_order_relaxed); }
int main(int argc,char** argv) {
 const unsigned selected=argc>1?std::atoi(argv[1]):0;
 for(unsigned threads : {1u}) for(unsigned depth : {1u,8u,74u}) {
  if(selected && depth!=selected)continue;
  ComputeExecutor e; e.configure(threads); Work work;
  std::array<ComputeExecutor::Batch,74> batches{};
  ComputeExecutor::Group g{2,{job,&work}};
  const auto start=std::chrono::steady_clock::now(); constexpr unsigned count=20000;
  for(unsigned i=0;i<count;++i) {
   if(i>=depth)e.join(batches[i%depth]);
   batches[i%depth]=e.submit(std::span(&g,1),i);
  }
  for(auto& b:batches)if(!b.empty())e.join(b);
  const auto ns=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();
  if(work.count!=2*count)return 1;
  std::cout<<"threads="<<threads<<" depth="<<depth<<" batches="<<count<<" ns_per_batch="<<double(ns)/count<<"\n";
 }
}
