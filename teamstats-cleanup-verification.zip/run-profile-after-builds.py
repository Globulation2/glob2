import os,time,subprocess
for pid in [88997,90844]:
    while True:
        try: os.kill(pid,0)
        except ProcessLookupError: break
        time.sleep(2)
subprocess.run(['python3','artifacts/teamstats/cleanup/profile.py'],check=True)
