# Sub-agent review and cleanup

Reviewed PR #1152 against codex/mcp-test-portability. The sub-agent reviewed the full feature and scheduler diff, then independently checked the cleanup diff.

Addressed:
- Immediate calculation/submission errors were not retained as pipeline failure. Failures now remain sticky at later preparation, publication, drain and save barriers; phase progression only advances after successful admission. Pending owns the callback context before submission, so deque allocation cannot leave a worker using freed storage.
- Snapshot aggregation checked range-element addresses twice. Removed these unconditional guards while retaining traversal, saturation and arithmetic.
- Clarified the dedicated lane's previous-frame chain, used previousFrames naming, corrected one-lane assertions, and formatted pipeline calculation/loading blocks consistently.
- Consolidated smoothing and pending-frame migration into the guide's sampling/save section, corrected replay/network versions and removed stale source-line references.
- Added standalone unit coverage for repeated same-lane groups, empty groups and independent work in serial/threaded modes. Expanded external completion/resumption across early/late handoff and Off/Waits/Trace.
- Added regression coverage for immediate calculation, deferred calculation and submission failure persistence at all owner barriers.

Follow-up review confirmed successful calculation semantics, deadlines and serialization unchanged. Its test-race finding was fixed by protecting vector writes and using an atomic first-callback flag.

Retained the independent live calculation for equivalence tests and legacy save rebuilding, measured buffer reuse and sparse/dense scheduling paths. No new pool, runtime dependency, save-format or simulation-version change. No new speedup claim or release performance qualification for this cleanup.
