import os, subprocess, json, statistics
from pathlib import Path
binary=str(Path('artifacts/teamstats/cleanup/glob2-engine-tests').resolve())
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_PERF_DISABLE='1',GLOB2_STATS_BENCHMARK='1',GLOB2_STATS_BENCHMARK_TICKS='2048',GLOB2_USER_DATA_DIR=str(Path('artifacts/teamstats/cleanup/profile-user').resolve()))
for repeat in range(5):
    with open(f'artifacts/teamstats/cleanup/static-pre-reuse-{repeat}.log','w') as log:
        subprocess.run([str(Path('artifacts/teamstats/cleanup/pre-reuse-engine-tests').resolve()),'--test-suite=TeamStatsPipeline','--test-case=pipeline versus*'],env=dict(env,GLOB2_STATS_PROFILE='1'),stdout=log,stderr=subprocess.STDOUT,check=True)
    with open(f'artifacts/teamstats/cleanup/static-before-{repeat}.log','w') as log:
        subprocess.run([str(Path('artifacts/teamstats/efficient/current-release/test/glob2-engine-tests').resolve()),'--test-suite=TeamStatsPipeline','--test-case=pipeline versus*'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    for prof in [True,False]:
        pe=dict(env,GLOB2_STATS_PROFILE='1' if prof else '0')
        for name,case in [('static','pipeline versus*'),('advancing','advancing match statistics timing*')]:
            with open(f'artifacts/teamstats/cleanup/{name}-profile{int(prof)}-{repeat}.log','w') as log:
                subprocess.run([binary,'--test-suite=TeamStatsPipeline','--test-case='+case],env=pe,stdout=log,stderr=subprocess.STDOUT,check=True)
records=[]
for p in Path('artifacts/teamstats/cleanup').glob('*-profile*-*.log'):
    for line in p.read_text().splitlines():
        if line.startswith(('STATS_BENCH ','STATS_ADVANCING ')):
            values=dict(item.split('=',1) for item in line.split()[1:])
            values={k:int(v) if v.isdigit() else v for k,v in values.items()}
            values['profile']=int(p.name.split('-profile')[1][0]);values['workload']=p.name.split('-profile')[0]; records.append(values)
Path('artifacts/teamstats/cleanup/profiles.json').write_text(json.dumps(records,indent=2)+'\n')
