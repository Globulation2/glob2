from pathlib import Path
import subprocess,os,json,time,hashlib,concurrent.futures
r=Path.cwd();k=r/'artifacts/filipino-localization';rev='1205c785cf7ec0070ce43802ea30c8ffed061af4';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==rev;env=dict(os.environ,GLOB2_SDL3_PREFIX=str(k/'sdl-reused'),LD_LIBRARY_PATH=str(k/'sdl-reused/lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''))
commands=[('b9-strict',['python3','data/check_translations.py','--strict']),('b9-translations',['python3','test/test_translations.py']),('b9-font-coverage',['python3','test/test_font_coverage.py']),('b9-translation-program',['python3','test/test_translation_program.py']),('b9-google-runner',['python3','test/test_google_draft.py']),('b9-mobile-contracts',['python3','test/test_mobile_assets.py']),('b9-web-assets',['python3','test/test_web_assets.py'])]
def run(x):
 name,args=x;start=time.monotonic()
 with (k/(name+'.log')).open('wb') as log:q=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 return {'name':name,'argv':args,'exit_code':q.returncode,'seconds':time.monotonic()-start,'log':name+'.log','log_sha256':hashlib.sha256((k/(name+'.log')).read_bytes()).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,commands))
record={'revision':rev,'commands':results};(k/'b9-data-results.json').write_text(json.dumps(record,indent=2)+'\n');print([(x['name'],x['exit_code']) for x in results],flush=True)
for platform in ['android','ios']:
 folder=k/('mobile-'+platform+'-b9-assets');args=['python3','tools/package_assets.py','--platform',platform,'--output',str(folder),'--lossy-images','--jobs','4'];v=run(('b9-mobile-'+platform,args));record['commands'].append(v)
 if not v['exit_code']:
  files=['data/texts.fil.txt','data/texts.list.txt','data/texts.incomplete.txt','data/fonts/sans.ttf']+['data/fonts/LICENSE-'+s+'.txt' for s in ['DejaVu','Droid','HarfBuzz','Noto']];v['verified_files_sha256']={n:hashlib.sha256((folder/n).read_bytes()).hexdigest() for n in files};assert all((folder/n).read_bytes()==(r/n).read_bytes() for n in files);v['export_file_count']=sum(p.is_file() for p in folder.rglob('*'))
 (k/'b9-data-results.json').write_text(json.dumps(record,indent=2)+'\n');print(platform,v['exit_code'],flush=True)
assert all(not x['exit_code'] for x in record['commands'])
