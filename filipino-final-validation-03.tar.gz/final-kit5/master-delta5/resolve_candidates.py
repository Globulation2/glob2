from pathlib import Path
import re,subprocess
D=Path('artifacts/filipino-localization/master-delta5/merge-candidate');TREE='d8f0d3ff4aefdd4eb552070b22d95401c8c28ed4'
def resolve(n,fn):
 p=D/n;s=p.read_text();count=0
 def sub(m):
  nonlocal count
  count+=1;return fn(m.group(1),m.group(2),count)
 s=re.sub(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',sub,s,flags=re.M|re.S);assert '<<<<<<<'not in s;p.write_text(s)
resolve('src/hud/touch/GameGUITouch.cpp',lambda a,b,i:b)
resolve('src/map/editor/PhoneEditor.cpp',lambda a,b,i:b if i==1 else a)
p=D/'src/map/editor/PhoneEditor.cpp';s=p.read_text();a=s.index('std::vector<std::string> PhoneEditor::headerCaptions() const');b=s.index('void PhoneEditor::draw()',a);s=s[:a]+s[b:];s=s.replace('headerCaptions()','headerLabels()');assert s.count('std::vector<std::string> PhoneEditor::headerLabels() const')==1;p.write_text(s)
resolve('src/map/editor/PhoneEditorTray.cpp',lambda a,b,i:b.replace('const ViewRect r{modeBar.x + i * modeBar.w / modeCount, modeBar.y, modeBar.w / modeCount, modeBar.h};','const auto r = modeRect(i);'))
n='src/map/editor/PhoneEditor.h';p=D/n;p.parent.mkdir(parents=True,exist_ok=True);s=subprocess.check_output(['git','show',TREE+':'+n],text=True);assert s.count('\tstd::vector<std::string> headerCaptions() const;\n')==1;p.write_text(s.replace('\tstd::vector<std::string> headerCaptions() const;\n',''))
print('ROOT4candidatefilesresolved;2inspection+2tests delegated; tracked434untouched')
