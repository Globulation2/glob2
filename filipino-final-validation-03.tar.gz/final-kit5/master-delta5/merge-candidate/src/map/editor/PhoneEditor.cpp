// SPDX-License-Identifier: GPL-3.0-or-later
#include <FormatableString.h>
#include "InGameTouchTheme.h"
#include "TouchReadout.h"
#include "ThumbSide.h"
#include "BrushCoverage.h"
#include "Map.h"
#include "MapEdit.h"
#include "PhoneEditor.h"
#include "MobileSafeArea.h"
#include "GlobalContainer.h"
#include <TouchText.h>
#include <ApplicationHost.h>
#include <Toolkit.h>
#include <StringTable.h>
#include <cmath>
#include <cstdio>
#include <set>
#include <sstream>
using namespace GAGCore;
namespace
{
// Point-based presentation policy. Gesture tuning must not change editor rules.
constexpr double headerHeight = 48;
constexpr double modeHeight = 44;
constexpr double dragThreshold = 8;
constexpr double previewLift = 40;
const char *modeCaptionKeys[] = {"[Terrain]", "[Resources]", "[Buildings]", "[Flags]", "[Teams]"};

std::vector<std::string> modeCaptionLines(int index, double width)
{
	auto *gfx = globalContainer->gfx;
	return wrapTouchText(globalContainer->standardFont,
		Toolkit::getStringTable()->getString(modeCaptionKeys[index]),
		std::max(1., (width - 8 * gfx->logicalUnitsPerPoint()) / gfx->textUnitsPerPoint()));
}
double modeCaptionLineHeight(const std::vector<std::string> &lines)
{
	auto *font = globalContainer->standardFont;
	double height = font->getStringHeight("Ag");
	for (const auto &line : lines)
		height = std::max(height, double(font->getStringHeight(line)));
	return height * globalContainer->gfx->textUnitsPerPoint();
}
} // namespace

PhoneEditor::PhoneEditor(MapEdit &editor) : editor(editor) {}
PhoneEditor::~PhoneEditor()
{
	if (!publishedControls.empty())
		ApplicationHost::controlsChanged(this, nullptr);
}
bool PhoneEditor::hasOverlay() const
{
	return editor.hasDialog();
}
void PhoneEditor::cancel()
{
	if (drag && drag->moving)
		editor.performAction("unselect");
	railTouched = -1;
	peekOpen = false;
	touch.cancel();
	stopScrolling();
	held = -1;
	onMap = false;
	drag.reset();
	commitDeferred(); // A completed tap is not undone by an interruption.
	lastTapTicks.reset();
	stroke.clear();
	quarantined.clear();
	if (auto *dialog = editor.activeDialog())
		dialog->cancelInput();
}
// All rectangles are independent editor presentation bounds. Tray cards come
// from the brush catalogue (PhoneEditorTray.cpp).
void PhoneEditor::prepare()
{
	auto *gfx = globalContainer->gfx;
	const double unit = gfx->logicalUnitsPerPoint();
	safe = mobileDialogSafe(gfx);
	// External keyboard/gallery actions can select an editor mode as well.
	if (editor.panelMode == MapEdit::AddBuildings)
		paletteMode = 2;
	else if (editor.panelMode == MapEdit::AddFlagsAndZones)
		paletteMode = 3;
	else if (editor.panelMode == MapEdit::Teams)
		paletteMode = 4;
	else if (editor.panelMode == MapEdit::Terrain && paletteMode >= 2)
		paletteMode = 0;
	const bool cards = tools && !inspecting() && paletteMode < 4;
	if (cards)
		layoutTray(unit);
	else
	{
		trayLayoutKey.clear();
		rows.clear();
		chips.clear();
	}
	// Short landscape phones keep more of the map: the strips tighten.
	const bool tight = safe.h < 480 * unit;
	double modes = tight ? 38 : modeHeight;
	modeColumns = modeCount;
	if (tools && !inspecting())
	{
		// Every word must fit a cell before wrapping the caption. A balanced
		// three-plus-two grid keeps enlarged text readable without tiny type.
		double wordWidth = 1;
		for (const auto *key : modeCaptionKeys)
		{
			std::istringstream words(Toolkit::getStringTable()->getString(key));
			for (std::string word; words >> word;)
				wordWidth = std::max(wordWidth,
					double(globalContainer->standardFont->getStringWidth(word)) * gfx->textUnitsPerPoint());
		}
		modeColumns = std::clamp(int(safe.w / (wordWidth + 9 * unit)), 1, modeCount);
		if (modeColumns == 4)
			modeColumns = 3;
		const int rows = (modeCount + modeColumns - 1) / modeColumns;
		for (int i = 0; i < modeCount; ++i)
		{
			const int cells = std::min(modeColumns, modeCount - (i / modeColumns) * modeColumns);
			const auto lines = modeCaptionLines(i, safe.w / cells - unit);
			modes = std::max(modes, modeCaptionLineHeight(lines) * lines.size() / unit + 8);
		}
		modes *= rows;
	}
	const double cardsHeight = tight ? cardHeight - 6 : cardHeight;
	const double chipsHeight = cards && chips.size() > 1 ? (tight ? chipHeight - 4 : chipHeight) : 0;
	const double dock = (modes + (tools ? cardsHeight + chipsHeight : 0)) * unit;
	const auto captions = headerLabels();
	std::array<double, 4> widths{}, minimumWidths{};
	widths.fill(safe.w / 4);
	double minimumTotal = 0;
	bool needsWidth = false;
	for (int i = 0; i < 4; ++i)
	{
		double wordWidth = 0;
		std::istringstream words(captions[i]);
		for (std::string word; words >> word;)
			wordWidth = std::max(wordWidth,
				double(globalContainer->standardFont->getStringWidth(word)) * gfx->textUnitsPerPoint());
		minimumWidths[i] = std::max(InGameTouchTheme::target * unit, wordWidth + 9 * unit);
		minimumTotal += minimumWidths[i];
		needsWidth = needsWidth || minimumWidths[i] > widths[i];
	}
	int columns = 4;
	if (needsWidth)
	{
		// Keep the usual quarters when they fit. Otherwise lend space from
		// short actions before resorting to two rows; never shrink the type.
		if (minimumTotal <= safe.w)
			for (int i = 0; i < 4; ++i)
				widths[i] = minimumWidths[i] + (safe.w - minimumTotal) / 4;
		else
		{
			columns = 2;
			widths.fill(safe.w / 2);
		}
	}
	std::array<double, 2> rowHeights{headerHeight * unit, headerHeight * unit};
	for (int i = 0; i < 4; ++i)
	{
		const auto lines = wrapTouchText(globalContainer->standardFont, captions[i],
			std::max(1., (widths[i] - 9 * unit) / gfx->textUnitsPerPoint()));
		rowHeights[i / columns] = std::max(rowHeights[i / columns],
			modeCaptionLineHeight(lines) * lines.size() + 8 * unit);
	}
	double header = 0;
	for (int row = 0; row < 4 / columns; ++row)
	{
		double x = safe.x;
		for (int column = 0; column < columns; ++column)
		{
			const int i = row * columns + column;
			headerButtons[i] = {x, safe.y + header, widths[i], rowHeights[row]};
			x += widths[i];
		}
		header += rowHeights[row];
	}
	content = {safe.x, safe.y + header, safe.w,
			   std::max(0., safe.h - header - dock)};
	modeBar = {safe.x, safe.y + safe.h - dock, safe.w, modes * unit};
	tray = {safe.x, modeBar.y + modeBar.h, safe.w, tools ? (cardsHeight + chipsHeight) * unit : 0};
	chipBar = {tray.x, tray.y, tray.w, chipsHeight * unit};
	cardBar = {tray.x, tray.y + chipBar.h, tray.w, tray.h - chipBar.h};
	if (inspecting())
	{
		prepareInspector();
		return;
	}
	if (cards)
		prepareTray(unit);
}
ViewRect PhoneEditor::modeRect(int index) const
{
	const int row = index / modeColumns;
	const int cells = std::min(modeColumns, modeCount - row * modeColumns);
	const int rows = (modeCount + modeColumns - 1) / modeColumns;
	return {modeBar.x + (index % modeColumns) * modeBar.w / cells,
		modeBar.y + row * modeBar.h / rows, modeBar.w / cells, modeBar.h / rows};
}
void PhoneEditor::syncTray()
{
	if (nativeScrolling && nativeSurface == 1 && trayAxis.externallyMoved(offset))
	{ nativeScroll.cancel(trayAxis.axis); nativeScrolling = false; }
	trayAxis.sync(offset, maximum, tray.w);
}
void PhoneEditor::syncInspector()
{
	if (nativeScrolling && nativeSurface == 2 && inspectorAxis.externallyMoved(inspectorScroll))
	{ nativeScroll.cancel(inspectorAxis.axis); nativeScrolling = false; }
	inspectorAxis.sync(inspectorScroll, inspectorMaximum, inspectorBody.h);
}
void PhoneEditor::stopScrolling()
{
	if (nativeScrolling)
	{
		nativeScroll.cancel(nativeAxis().axis);
		nativeAxis().publish(nativeOffset());
		nativeScrolling = false;
	}
	mapMotion.interrupt();
	trayAxis.axis.interrupt();
	inspectorAxis.axis.interrupt();
}
bool PhoneEditor::animating() const
{
	return (nativeScrolling && nativeScroll.needsFrames()) || mapMotion.isAnimating() || trayAxis.axis.isAnimating() || inspectorAxis.axis.isAnimating();
}
void PhoneEditor::advance(Uint32 tick)
{
	lastTick = tick;
	if (nativeScrolling && (editor.hasDialog() || (nativeSurface == 2 && !inspecting()) || (nativeSurface == 1 && !tools))) stopScrolling();
	if (nativeScrolling)
	{
		if (nativeSurface == 2) syncInspector(); else syncTray();
		nativeScroll.update(tick, nativeAxis().axis);
		nativeAxis().publish(nativeOffset());
	}
	if (mapMotion.isAnimating())
	{
		const auto [dx, dy] = mapMotion.stepDelta(tick);
		if (dx != 0 || dy != 0)
		{
			editor.updateCamera();
			editor.camera.originX += dx / editor.camera.zoom;
			editor.camera.originY += dy / editor.camera.zoom;
			editor.camera.normalize();
			editor.viewportX = editor.camera.tileX() & editor.game.map.wMask;
			editor.viewportY = editor.camera.tileY() & editor.game.map.hMask;
		}
	}
	if (trayAxis.axis.isAnimating())
	{
		trayAxis.axis.step(tick);
		trayAxis.publish(offset);
	}
	if (inspectorAxis.axis.isAnimating())
	{
		inspectorAxis.axis.step(tick);
		inspectorAxis.publish(inspectorScroll);
	}
}
void PhoneEditor::clearTool()
{
	const bool visible = tools;
	chooseMode(paletteMode);
	tools = visible;
	pan = false;
}
void PhoneEditor::chooseMode(int mode)
{
	cancel();
	undo.reset();
	paletteMode = mode;
	offset = 0;
	tools = true;
	const char *modes[modeCount] = {"switch to terrain view", "switch to terrain view",
									"switch to building view", "switch to flag view",
									"switch to teams view"};
	editor.performAction(modes[mode]);
}
int PhoneEditor::hit(ViewPoint point)
{
	// The same positioned model supplies ordinary pointer targets and semantic
	// targets. The map remains a canvas with its existing gesture handling.
	const GAGGUI::ui::Point p{int(point.x), int(point.y)};
	const auto targets = controlTargets();
	for (auto it = targets.rbegin(); it != targets.rend(); ++it)
		if (it->control.contains(p))
			return it->id;
	return -1;
}
void PhoneEditor::placeAt(ViewPoint p)
{
	editor.mouseX = int(p.x);
	editor.mouseY = int(p.y);
	editor.updateCamera();
	if (editor.selectionMode == MapEdit::PlaceBuilding)
		editor.performAction("place building");
	else if (editor.selectionMode == MapEdit::PlaceUnit)
		editor.performAction("place unit");
	else
	{
		editor.performAction("select map unit");
		editor.performAction("select map building");
	}
}
bool PhoneEditor::paintMode() const
{
	const auto mode = editor.selectionMode;
	return !inspecting() && editor.panelMode != MapEdit::Teams &&
		   (mode == MapEdit::PlaceTerrain || mode == MapEdit::PlaceZone || mode == MapEdit::RemoveObject ||
			mode == MapEdit::ChangeAreas || mode == MapEdit::ChangeNoResourceGrowthAreas);
}
BrushHUD::Layout PhoneEditor::rail() const
{
	const double unit = globalContainer->gfx->logicalUnitsPerPoint(), inset = 8 * unit;
	// Paint/Erase applies to every brush except deletion: zones, areas,
	// no-growth areas, resources and terrain (Erase reverts it to grass).
	const bool mode = editor.selectionMode != MapEdit::RemoveObject;
	ViewRect area{content.x + inset, content.y + inset, content.w - 2 * inset, content.h - 2 * inset};
	if (showsMapButton())
	{
		// Reserve the opposite-edge button for every rail row. The thumb-side
		// anchor stays unchanged, so ordinary one/two-column layouts do too.
		const auto map = mapButton();
		const double gap = InGameTouchTheme::gap * unit;
		if (ThumbSide::left())
			area.w = std::max(0., std::min(area.x + area.w, map.x - gap) - area.x);
		else
		{
			const double right = area.x + area.w;
			area.x = std::max(area.x, map.x + map.w + gap);
			area.w = std::max(0., right - area.x);
		}
	}
	return BrushHUD::boundedLayout(area, ThumbSide::left(), unit, mode, true, bool(undo));
}
// Zone, area and no-growth strokes only change tile masks, so their tiles (and
// the displayed zone bits) are restored exactly. Terrain and delete strokes
// remove units, buildings and resources and are not undoable.
void PhoneEditor::applyUndo()
{
	if (!undo)
		return;
	auto &map = editor.game.map;
	for (size_t i = 0; i < undo->cells.size(); ++i)
	{
		const auto [x, y] = undo->cells[i];
		map.replaceTile(x, y, undo->tiles[i]);
		if (undo->zoneView)
			undo->zoneView->set(size_t(map.w * y + x), undo->view[i]);
	}
	editor.game.regenerateDiscoveryMap();
	editor.hasMapBeenModified = true;
	undo.reset();
}
void PhoneEditor::paintStroke()
{
	if (stroke.empty())
		return;
	auto &map = editor.game.map;
	const bool undoable = editor.selectionMode == MapEdit::PlaceZone ||
						  editor.selectionMode == MapEdit::ChangeAreas ||
						  editor.selectionMode == MapEdit::ChangeNoResourceGrowthAreas;
	EditorUndo snapshot;
	if (undoable)
	{
		// Snapshot the covered cells with a one-cell margin.
		std::vector<BrushCoverage::Cell> centres;
		for (const auto &p : stroke)
		{
			const auto [wx, wy] = editor.camera.screenToWorld(p.x, p.y);
			centres.push_back(BrushCoverage::cellAt(wx, wy));
		}
		std::set<std::pair<int, int>> cells;
		for (const auto &[cx, cy] : BrushCoverage::cells(editor.brush.getFigure(), centres))
			for (int dy = -1; dy <= 1; ++dy)
				for (int dx = -1; dx <= 1; ++dx)
					cells.insert({(cx + dx) & map.wMask, (cy + dy) & map.hMask});
		if (editor.selectionMode == MapEdit::PlaceZone)
			snapshot.zoneView = &editor.areaBrushTarget().view;
		for (const auto &cell : cells)
		{
			snapshot.cells.push_back(cell);
			snapshot.tiles.push_back(map.getTile(cell.first, cell.second));
			if (snapshot.zoneView)
				snapshot.view.push_back(snapshot.zoneView->get(size_t(map.w * cell.second + cell.first)));
		}
	}
	const char *prefix = editor.selectionMode == MapEdit::PlaceTerrain   ? "terrain"
						 : editor.selectionMode == MapEdit::PlaceZone    ? "zone"
						 : editor.selectionMode == MapEdit::RemoveObject ? "delete"
						 : editor.selectionMode == MapEdit::ChangeAreas
							 ? "area"
							 : "no ressource growth area";
	editor.updateCamera();
	for (size_t i = 0; i < stroke.size(); ++i)
	{
		editor.mouseX = int(stroke[i].x);
		editor.mouseY = int(stroke[i].y);
		editor.performAction(std::string(prefix) + (i ? " drag motion" : " drag start"));
	}
	editor.performAction(std::string(prefix) + " drag end");
	stroke.clear();
	undo.reset();
	bool changed = false;
	for (size_t i = 0; i < snapshot.cells.size() && !changed; ++i)
	{
		const auto &now = map.getTile(snapshot.cells[i].first, snapshot.cells[i].second);
		const auto &was = snapshot.tiles[i];
		changed = now.forbidden != was.forbidden || now.guardArea != was.guardArea ||
				  now.clearArea != was.clearArea || now.farmArea != was.farmArea || now.scriptAreas != was.scriptAreas ||
				  now.canResourcesGrow != was.canResourcesGrow;
	}
	if (changed)
	{
		snapshot.expires = SDL_GetTicks() + InGameTouchTheme::brushUndoMs;
		undo = std::move(snapshot);
	}
}
bool PhoneEditor::zoomArmed(Uint32 ticks, ViewPoint point) const
{
	const double unit = globalContainer->gfx->logicalUnitsPerPoint();
	return lastTapTicks && Uint32(ticks - *lastTapTicks) <= InGameTouchTheme::doubleTapWindowMs &&
		   std::hypot(point.x - lastTapPoint.x, point.y - lastTapPoint.y) <=
			   InGameTouchTheme::doubleTapRadius * unit &&
		   content.contains(point);
}
bool PhoneEditor::deferredMatchesTool(const DeferredStroke &candidate) const
{
	return candidate.selection == int(editor.selectionMode) &&
		   candidate.terrain == int(editor.terrainType) &&
		   candidate.figure == int(editor.brush.getFigure()) &&
		   candidate.type == int(editor.brush.getType());
}
// A held paint tap lands when its window closes, when another contact begins,
// or on interruption; it is dropped only if its brush is no longer active.
void PhoneEditor::commitDeferred()
{
	if (!deferred)
		return;
	auto held = std::move(*deferred);
	deferred.reset();
	if (held.points.empty() || !deferredMatchesTool(held))
		return;
	auto unfinished = std::move(stroke);
	stroke = std::move(held.points);
	paintStroke();
	stroke = std::move(unfinished);
}
void PhoneEditor::drawZoomReadout()
{
	if (!touch.zoomDragging())
		return;
	char value[16];
	std::snprintf(value, sizeof(value), "%.1f", editor.camera.zoom);
	TouchReadout::draw(touchPoint,
					   GAGCore::FormattableString(Toolkit::getStringTable()->getString("[zoom factor %0]")).arg(value),
					   safe);
}
void PhoneEditor::act(const TouchAction &action)
{
	auto *gfx = globalContainer->gfx;
	const double unit = gfx->logicalUnitsPerPoint();
	ViewPoint p{action.point.x * unit, action.point.y * unit};
	if (action.kind == TouchActionKind::Cancel)
	{
		stroke.clear();
		stopScrolling();
		return;
	}
	if (action.kind == TouchActionKind::PanEnd)
	{
		mapMotion.endDrag(action.time);
		trayAxis.axis.endDrag(action.time);
		inspectorAxis.axis.endDrag(action.time);
		syncTray();
		syncInspector();
		return;
	}
	if (action.kind == TouchActionKind::BeginStroke || action.kind == TouchActionKind::Stroke ||
		action.kind == TouchActionKind::EndStroke)
	{
		if (!onMap)
			return;
		if (!content.contains(p))
		{
			stroke.clear();
			onMap = false;
			return;
		}
		editor.mouseX = int(p.x);
		editor.mouseY = int(p.y);
		stroke.push_back(p);
		if (action.kind == TouchActionKind::EndStroke)
		{
			if (!touchTravelled)
			{
				deferred = DeferredStroke{std::move(stroke), int(editor.selectionMode), int(editor.terrainType),
										  int(editor.brush.getFigure()), int(editor.brush.getType()),
										  SDL_GetTicks()};
				stroke.clear();
				lastTapTicks = eventTicks;
				lastTapPoint = p;
			}
			else
				paintStroke();
		}
		return;
	}
	if (action.kind == TouchActionKind::Pan)
	{
		if (inspecting() && !onMap)
		{
			syncInspector();
			inspectorAxis.axis.drag(action.time, -p.y);
			syncInspector();
			return;
		}
		if (!onMap && held >= 0)
		{
			syncTray();
			trayAxis.axis.drag(action.time, -p.x);
			syncTray();
		}
		else if (onMap)
		{
			// Subpixel panning through the camera, as in the game; the tile
			// viewport is derived from it.
			editor.updateCamera();
			editor.camera.originX -= p.x / editor.camera.zoom;
			editor.camera.originY -= p.y / editor.camera.zoom;
			editor.camera.normalize();
			editor.viewportX = editor.camera.tileX() & editor.game.map.wMask;
			editor.viewportY = editor.camera.tileY() & editor.game.map.hMask;
			if (!mapMotion.isDragging())
				mapMotion.beginDrag(action.time);
			mapMotion.drag(action.time, -p.x, -p.y);
		}
		return;
	}
	// MapCamera::wheel steps by 1.1, so a gesture factor converts with that base.
	if (action.kind == TouchActionKind::Zoom && onMap)
	{
		editor.zoomMap(std::log(action.factor) / std::log(1.1), p.x, p.y);
		return;
	}
	if (action.kind == TouchActionKind::DoubleTap && onMap)
	{
		editor.updateCamera();
		if (!editor.zoomMap(std::log(1.0 / editor.camera.zoom) / std::log(1.1), p.x, p.y) && !pan &&
			content.contains(p))
			placeAt(p); // Without a zoomable renderer the second tap acts as before.
		return;
	}
	if (action.kind != TouchActionKind::Select || hit(p) != held)
		return;
	activateTarget(held, p);
}
void PhoneEditor::activateTarget(int target, ViewPoint p)
{
	const double unit = globalContainer->gfx->logicalUnitsPerPoint();
	if (target == -20)
	{
		clearTool();
		return;
	}
	if (target == -21)
	{
		editor.suspendInput();
		editor.performAction("open teams editor");
		return;
	}
	if (target == -300)
	{
		navigatePeek(p);
		return;
	}
	if (target == -302 || target == -303)
	{
		editor.zoomMap((target == -303 ? 1 : -1) * std::log(InGameTouchTheme::peekZoomStep) / std::log(1.1),
					   content.x + content.w / 2, content.y + content.h / 2);
		return;
	}
	if (target == -301 || target == -304)
	{
		peekOpen = false; // Done, or a tap outside the peek.
		return;
	}
	if (target == -305)
	{
		cancel();
		peekOpen = true;
		return;
	}
	if (target <= -200 && target > -200 - int(BrushTool::BRUSH_COUNT))
	{
		editor.brush.setFigure(unsigned(-200 - target));
		return;
	}
	if (target == -210)
	{
		pan = !pan;
		return;
	}
	if (target == -211)
	{
		editor.brush.setType(editor.brush.getType() == BrushTool::MODE_DEL ? BrushTool::MODE_ADD
																			: BrushTool::MODE_DEL);
		return;
	}
	if (target == -213)
	{
		applyUndo();
		return;
	}
	if (target >= 1000 && inspecting())
	{
		const int index = (target - 1000) / 3, part = (target - 1000) % 3;
		if (index < int(properties.size()))
		{
			auto &property = properties[index];
			auto *value = property.value;
			int requested = value->currentValue() + (part == 0 ? -1 : 1);
			if (part == 1)
				requested = int(
					std::clamp((p.x - property.rect.x - 48 * unit) / (property.rect.w - 96 * unit),
							   0., 1.) *
						value->maximumValue() +
					.5);
			value->setValue(requested);
			editor.hasMapBeenModified = true;
		}
		return;
	}
	if (target == -6)
	{
		tools = true;
		return;
	}
	if (target <= -400 && target > -400 - int(chips.size()))
	{
		jumpToChip(-400 - target);
		return;
	}
	if (target <= -10 && target > -10 - modeCount)
	{
		if (paletteMode == -10 - target)
		{
			tools = false;
			return;
		}
		chooseMode(-10 - target);
		return;
	}
	if (target == -2)
	{
		editor.suspendInput();
		editor.performAction("open menu screen");
		return;
	}
	if (target == -5)
	{
		if (editor.selectionMode != MapEdit::PlaceNothing)
			clearTool();
		else
		{
			cancel();
			pan = !pan;
		}
		return;
	}
	const bool objects = paletteMode >= 2;
	if (target == -3)
	{
		// Brush modes show their size here; the rail changes it.
		if (objects)
			editor.selectActiveTeam((editor.team + 1) % editor.view.scene->entities.teamCount);
		return;
	}
	if (target == -4)
	{
		if (objects)
		{
			if (editor.selectionMode == MapEdit::PlaceUnit)
				editor.performAction("select unit level " +
									 std::to_string((editor.placingUnitLevel + 1) % 4 + 1));
			else
				editor.performAction("switch to building level " +
									 std::to_string((editor.buildingLevel + 1) % editor.buildingLevelCount + 1));
		}
		else if (editor.selectionMode != MapEdit::RemoveObject &&
				 !(editor.selectionMode == MapEdit::PlaceTerrain &&
				   TerrainSelector::isBaseTerrain(editor.terrainType)))
			editor.brush.setType(editor.brush.getType() == BrushTool::MODE_DEL
									 ? BrushTool::MODE_ADD
									 : BrushTool::MODE_DEL);
		return;
	}
	if (target >= 0 && target < int(rows.size()))
	{
		const Row row = rows[target]; // Activation may rebuild the tray.
		activateRow(row, p);
		pan = false;
		return;
	}
	if (onMap && content.contains(p))
	{
		// Placement taps never arm zoom, so repeated placement stays reliable.
		const bool placing = editor.selectionMode == MapEdit::PlaceBuilding ||
							 editor.selectionMode == MapEdit::PlaceUnit;
		if (!pan)
			placeAt(p);
		if (!placing)
		{
			lastTapTicks = eventTicks;
			lastTapPoint = p;
		}
	}
}
bool PhoneEditor::event(SDL_Event event)
{
	if (editor.hasDialog())
	{
		if (nativeScrolling) stopScrolling();
		GAGCore::GraphicContext::translateMouseEvent(&event);
		editor.delegateMenu(event);
		return true;
	}
	if ((event.type >= SDL_EVENT_WINDOW_FIRST && event.type <= SDL_EVENT_WINDOW_LAST) && (event.type == SDL_EVENT_WINDOW_FOCUS_LOST ||
										  event.type == SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED || event.type == SDL_EVENT_WINDOW_RESIZED || event.type == SDL_EVENT_WINDOW_DISPLAY_SCALE_CHANGED))
	{
		cancel();
		return false;
	}
	prepare();
	if (GAGGUI::ui::isSemanticEvent(event))
		return inspectionHost().event(event);
	if (auto sample = scrollGesture(event))
	{
		if (!editor.inputState.hasFocus()) return true;
		GraphicContext::translateMouseEvent(&event);
		sample = scrollGesture(event);
		if (sample->phase == ScrollGesturePhase::Began && sample->sequence != nativeSequence)
		{
			const int previousSurface = nativeScrolling ? nativeSurface : 0;
			const auto previousAxis = nativeAxis().axis;
			stopScrolling();
			nativeSequence = sample->sequence;
			nativeSurface = 0;
			const ViewPoint point{sample->x, sample->y};
			if (inspecting() && inspectorBody.contains(point)) nativeSurface = 2;
			else if (tools && tray.contains(point)) nativeSurface = 1;
			if (nativeSurface)
			{
				if (nativeSurface == previousSurface)
				{
					nativeAxis().axis = previousAxis;
					nativeAxis().publish(nativeOffset());
				}
				auto &axis = nativeAxis().axis;
				nativeScroll.begin(*sample, axis, nativeOffset(), axis.maximum(), nativeSurface == 2 ? inspectorBody.h : tray.w, nativeSurface == 1);
				nativeScrolling = true;
			}
		}
		if (sample->sequence != nativeSequence) return true;
		if (!nativeSurface)
		{
			// Over the map a trackpad or wheel gesture zooms about the pointer.
			const ViewPoint at{sample->x, sample->y};
			if (content.contains(at) && !peekOpen)
			{
				const auto wheel = gestureWheelFallback(*sample);
				const double delta = wheel.wheel.y * (wheel.wheel.direction == SDL_MOUSEWHEEL_FLIPPED ? -1 : 1);
				if (delta != 0)
					editor.zoomMap(delta, int(at.x), int(at.y));
			}
			return true;
		}
		if (nativeScrolling)
		{
			nativeScroll.handle(*sample, nativeAxis().axis);
			if (nativeSurface == 2) syncInspector(); else syncTray();
		}
		return true;
	}
	if (nativeScrolling && (event.type == SDL_EVENT_MOUSE_WHEEL || event.type == SDL_EVENT_MOUSE_BUTTON_DOWN || event.type == SDL_EVENT_KEY_DOWN || event.type == SDL_EVENT_FINGER_DOWN)) stopScrolling();
	// Pointer positions arrive in window coordinates; the tray works in logical
	// pixels like the rest of the editor. Fingers are normalized already.
	if (event.type == SDL_EVENT_MOUSE_BUTTON_DOWN || event.type == SDL_EVENT_MOUSE_BUTTON_UP ||
		event.type == SDL_EVENT_MOUSE_MOTION || event.type == SDL_EVENT_MOUSE_WHEEL)
		GraphicContext::translateMouseEvent(&event);
	ViewPoint p;
	int phase = -1;
	SDL_TouchID device = SDL_MOUSE_TOUCHID;
	SDL_FingerID id = 0;
	switch (event.type)
	{
	case SDL_EVENT_FINGER_DOWN:
	case SDL_EVENT_FINGER_MOTION:
	case SDL_EVENT_FINGER_UP:
		p = {event.tfinger.x * globalContainer->gfx->getW(),
			 event.tfinger.y * globalContainer->gfx->getH()};
		device = event.tfinger.touchID;
		id = event.tfinger.fingerID;
		phase = event.type == SDL_EVENT_FINGER_DOWN ? 0 : event.type == SDL_EVENT_FINGER_UP ? 2 : 1;
		break;
	case SDL_EVENT_MOUSE_BUTTON_DOWN:
	case SDL_EVENT_MOUSE_BUTTON_UP:
		if (event.button.which == SDL_TOUCH_MOUSEID || event.button.button != SDL_BUTTON_LEFT)
			return true;
		p = {double(event.button.x), double(event.button.y)};
		phase = event.type == SDL_EVENT_MOUSE_BUTTON_DOWN ? 0 : 2;
		break;
	case SDL_EVENT_MOUSE_MOTION:
		if (event.motion.which == SDL_TOUCH_MOUSEID)
			return true;
		p = {double(event.motion.x), double(event.motion.y)};
		phase = 1;
		break;
	case SDL_EVENT_MOUSE_WHEEL:
	{
		// The wheel acts on what the pointer is over: the inspector or tray
		// scrolls, the map zooms about the pointer as on the desktop.
		const ViewPoint at{event.wheel.mouse_x, event.wheel.mouse_y};
		const double u = globalContainer->gfx->logicalUnitsPerPoint();
		const double flip = event.wheel.direction == SDL_MOUSEWHEEL_FLIPPED ? -1 : 1;
		const double steps = (event.wheel.y - event.wheel.x) * flip;
		if (inspecting() && inspector.contains(at))
		{
			scrollSurface(true, int(-event.wheel.y * flip * 72 * u));
			return true;
		}
		if (tools && cardBar.contains(at))
		{
			scrollSurface(false, int(-steps * 56 * u));
			return true;
		}
		if (content.contains(at) && !peekOpen && event.wheel.y != 0)
			editor.zoomMap(event.wheel.y * flip, int(at.x), int(at.y));
		return true;
	}
	case SDL_EVENT_KEY_DOWN:
		if (event.key.key == SDLK_ESCAPE)
		{
			cancel();
			tools = !tools;
			return true;
		}
		return false;
	default:
		return false;
	}
	const double unit = globalContainer->gfx->logicalUnitsPerPoint();
	const auto key = std::make_pair(device, id);
	const Uint64 time = (event.common.timestamp / SDL_NS_PER_MS);
	if (phase == 0 && !touch.hasPointers() && !drag)
	{
		// A touch catches coasting content where it is; presets are re-read so
		// the settings sliders apply to the next gesture.
		stopScrolling();
		fingerIsTouch = device != SDL_MOUSE_TOUCHID;
		ScrollPhysicsConfig mapConfig = ScrollPresets::mapViewport();
		mapConfig.momentum = mapConfig.momentum && fingerIsTouch;
		mapMotion.setConfig(mapConfig);
		trayAxis.axis.setConfig(fingerIsTouch ? ScrollPresets::editorTray() : ScrollPresets::mouse());
		inspectorAxis.axis.setConfig(fingerIsTouch ? ScrollPresets::hudPanel() : ScrollPresets::mouse());
	}
	if (!quarantined.empty())
	{
		if (phase == 0)
			quarantined.insert(key);
		if (phase == 2)
			quarantined.erase(key);
		return true;
	}
	if (drag)
	{
		if (key != std::make_pair(drag->device, drag->finger))
		{
			if (phase == 0)
			{
				quarantined.insert(key);
				quarantined.insert({drag->device, drag->finger});
				drag.reset();
				editor.performAction("unselect");
			}
			return true;
		}
		if (!drag->moving &&
			std::hypot(p.x - drag->start.x, p.y - drag->start.y) >= dragThreshold * unit)
		{
			// Horizontal motion browses the tray; moving into the map starts placement.
			if (content.contains(p))
			{
				drag->moving = true;
				editor.performAction(drag->action);
				pan = false;
			}
			else
			{
				drag->browsing = true;
				syncTray();
				if (!trayAxis.axis.isDragging())
					trayAxis.axis.beginDrag(time);
				trayAxis.axis.drag(time, -(p.x - drag->start.x));
				syncTray();
				drag->start = p;
			}
		}
		if (drag->moving)
		{
			editor.mouseX = int(p.x);
			editor.mouseY = int(p.y - previewLift * unit);
		}
		if (phase == 2)
		{
			if (drag->moving)
			{
				if (content.contains(p) && content.contains({p.x, p.y - previewLift * unit}))
					placeAt({p.x, p.y - previewLift * unit});
			}
			else if (!drag->browsing && hit(p) >= 0 && rows[hit(p)].id == drag->id)
			{
				editor.performAction(drag->action);
				pan = false;
			}
			if (drag->browsing)
			{
				trayAxis.axis.endDrag(time);
				syncTray();
			}
			drag.reset();
		}
		return true;
	}
	std::vector<TouchAction> actions;
	if (phase == 0)
	{
		if (!touch.hasPointers())
		{
			held = hit(p);
			onMap = held == -1 && content.contains(p);
			const bool placing = editor.selectionMode == MapEdit::PlaceBuilding ||
								 editor.selectionMode == MapEdit::PlaceUnit;
			const bool zoomDrag = onMap && !placing && zoomArmed(event.common.timestamp / SDL_NS_PER_MS, p);
			if (zoomDrag)
				deferred.reset(); // That tap was the first half of the zoom.
			else
				commitDeferred();
			lastTapTicks.reset();
			touchKey = key;
			touchStart = touchPoint = p;
			touchTravelled = false;
			// Touching a rail size selects it at once; the thumb can then scrub.
			railTouched = held <= -200 && held > -200 - int(BrushTool::BRUSH_COUNT) ? -200 - held : -1;
			if (railTouched >= 0)
				editor.brush.setFigure(unsigned(railTouched));
			if (held >= 0 && held < int(rows.size()) && dragPlaces(rows[held]))
			{
				drag = Drag{device, id, rows[held].id, editor.findBrush(rows[held].id)->action, p};
				return true;
			}
			const bool paint = editor.selectionMode == MapEdit::PlaceTerrain ||
							   editor.selectionMode == MapEdit::PlaceZone ||
							   editor.selectionMode == MapEdit::RemoveObject ||
							   editor.selectionMode == MapEdit::ChangeAreas ||
							   editor.selectionMode == MapEdit::ChangeNoResourceGrowthAreas;
			touch.setMode(zoomDrag ? TouchMode::ZoomDrag
						  : onMap && !pan && paint ? TouchMode::Paint
												   : TouchMode::Navigate);
			touch.setZoomDragDirection(globalContainer->settings.dragUpZoomsIn());
		}
		actions = touch.down(device, id, {p.x / unit, p.y / unit}, time);
	}
	else if (phase == 1)
	{
		if (key == touchKey && held == -300 && peekOpen)
			navigatePeek(p);
		if (key == touchKey && railTouched >= 0)
			if (const int detent = BrushHUD::detentAt(rail(), p, content); detent >= 0)
			{
				editor.brush.setFigure(unsigned(detent));
				railTouched = detent;
			}
		if (key == touchKey)
		{
			touchPoint = p;
			touchTravelled = touchTravelled || std::hypot(p.x - touchStart.x, p.y - touchStart.y) >=
												   TouchInput::slop * unit;
		}
		actions = touch.move(device, id, {p.x / unit, p.y / unit}, time);
	}
	else
	{
		eventTicks = event.common.timestamp / SDL_NS_PER_MS;
		actions = touch.up(device, id, {p.x / unit, p.y / unit}, time);
		if (key == touchKey)
			railTouched = -1;
	}
	for (const auto &a : actions)
		act(a);
	if (phase == 2 && !touch.hasPointers())
	{
		// A touch that stopped a bounce without dragging lets it finish.
		trayAxis.axis.settle(time);
		inspectorAxis.axis.settle(time);
		syncTray();
		syncInspector();
	}
	return true;
}
void PhoneEditor::label(ViewRect r, const std::string &text)
{
	auto *gfx = globalContainer->gfx;
	auto *font = globalContainer->standardFont;
	const double unit = gfx->logicalUnitsPerPoint(), scale = gfx->textUnitsPerPoint();
	font->pushStyle(Font::Style(Font::STYLE_NORMAL, Color(255, 249, 229)));
	SDL_Rect clip{int(r.x + 4 * unit), int(r.y), int(std::max(0., r.w - 8 * unit)), int(r.h)};
	gfx->setUITransform(scale, r.x + 4 * unit, r.y + (r.h - 16 * scale) / 2, &clip);
	// The transform already clips in screen coordinates. A second font-width
	// clip mixes those bounds with local x=0 in the legacy GL path.
	gfx->drawString(0, 0, font, text);
	gfx->setUITransform();
	gfx->setClipRect();
	font->popStyle();
}
void PhoneEditor::centredLabel(ViewRect r, const std::string &text)
{
	auto *gfx = globalContainer->gfx;
	auto *font = globalContainer->standardFont;
	const double scale = gfx->textUnitsPerPoint();
	const double width = font->getStringWidth(text) * scale;
	if (width + 4 * gfx->logicalUnitsPerPoint() > r.w)
	{
		label(r, text); // Too long to centre: start at the edge and clip.
		return;
	}
	font->pushStyle(Font::Style(Font::STYLE_NORMAL, Color(255, 249, 229)));
	SDL_Rect clip{int(r.x), int(r.y), int(r.w), int(r.h)};
	gfx->setUITransform(scale, r.x + (r.w - width) / 2, r.y + (r.h - font->getStringHeight(text) * scale) / 2, &clip);
	gfx->drawString(0, 0, font, text);
	gfx->setUITransform();
	gfx->setClipRect();
	font->popStyle();
}
void PhoneEditor::draw()
{
	if (deferred && SDL_GetTicks() - deferred->ticks >= InGameTouchTheme::doubleTapWindowMs)
		commitDeferred();
	if (editor.hasDialog())
	{
		publishControls(false);
		editor.drawDialog();
		return;
	}
	prepare();
	publishControls(tools && !inspecting());
	if (inspecting())
	{
		drawInspector();
		drawZoomReadout();
		return;
	}
	auto *gfx = globalContainer->gfx;
	const double unit = gfx->logicalUnitsPerPoint();
	const bool objects = paletteMode >= 2;
	const auto labels = headerLabels();
	for (int i = 0; i < 4; ++i)
	{
		auto r = headerButtons[i];
		r.w -= unit;
		r.h -= 4 * unit;
		gfx->drawFilledRect(int(r.x), int(r.y), int(r.w), int(r.h), InGameTouchTheme::paper());
		const auto lines = wrapTouchText(globalContainer->standardFont, labels[i],
			std::max(1., (r.w - 8 * unit) / gfx->textUnitsPerPoint()));
		if (lines.size() == 1)
			label(r, labels[i]); // Preserve the authored one-line header alignment.
		else
		{
			const double lineHeight = modeCaptionLineHeight(lines);
			double y = r.y + (r.h - lineHeight * lines.size()) / 2;
			for (const auto &line : lines)
			{
				centredLabel({r.x, y, r.w, lineHeight}, line);
				y += lineHeight;
			}
		}
		if (i == 1 && objects)
			gfx->drawFilledRect(int(r.x + 4 * unit), int(r.y + r.h - 5 * unit), int(r.w - 8 * unit),
								int(3 * unit), presentationColor(editor.view.scene->entities.teams[editor.team].color));
	}
	drawInteractionPreview();
	if (undo && (!paintMode() || SDL_GetTicks() >= undo->expires))
		undo.reset();
	if (paintMode())
	{
		auto *strings = Toolkit::getStringTable();
		BrushHUD::State state;
		state.figure = editor.brush.getFigure();
		state.erase = editor.brush.getType() == BrushTool::MODE_DEL;
		state.pan = pan;
		state.touched = railTouched;
		state.modeLabel = state.erase ? strings->getString("[Erase]") : strings->getString("[Paint]");
		state.panLabel = strings->getString("[Pan]");
		state.undoLabel = strings->getString("[Undo stroke]");
		BrushHUD::draw(rail(), state, content);
	}
	drawZoomReadout();
	drawPeek(); // The Map button, or the open peek over everything.
	if (!tools)
	{
		gfx->drawFilledRect(int(modeBar.x), int(modeBar.y), int(modeBar.w), int(modeBar.h),
							InGameTouchTheme::paper());
		label(modeBar, GAGCore::Toolkit::getStringTable()->getString("[Show palette]"));
		drawStatusToast();
		return;
	}
	// The mode strip and tray are opaque: cards read against one backdrop.
	Color backdrop = InGameTouchTheme::paper();
	backdrop.a = 255;
	gfx->drawFilledRect(int(modeBar.x), int(modeBar.y), int(modeBar.w), int(modeBar.h + tray.h), backdrop);
	for (int i = 0; i < modeCount; ++i)
	{
		auto r = modeRect(i);
		r.w -= unit;
		if (i == paletteMode)
			gfx->drawFilledRect(int(r.x), int(r.y), int(r.w), int(r.h), InGameTouchTheme::selected());
		const auto lines = modeCaptionLines(i, r.w);
		const double lineHeight = modeCaptionLineHeight(lines);
		double y = r.y + (r.h - lineHeight * lines.size()) / 2;
		for (const auto &line : lines)
		{
			centredLabel({r.x, y, r.w, lineHeight}, line);
			y += lineHeight;
		}
	}
	if (editor.panelMode == MapEdit::Teams)
	{
		// One wide card opens the teams editor.
		const ViewRect card{tray.x + 8 * unit, tray.y + 6 * unit, tray.w - 16 * unit, tray.h - 14 * unit};
		gfx->drawFilledRect(int(card.x), int(card.y), int(card.w), int(card.h), InGameTouchTheme::field());
		for (int i = 0; i < editor.view.scene->entities.teamCount && i < 16; ++i)
			gfx->drawFilledRect(int(card.x + (10 + 22 * i) * unit), int(card.y + card.h - 12 * unit), int(16 * unit),
								int(5 * unit), presentationColor(editor.view.scene->entities.teams[i].color));
		centredLabel({card.x, card.y, card.w, card.h - 10 * unit},
					 GAGCore::FormattableString(GAGCore::Toolkit::getStringTable()->getString("[Manage teams (%0)]"))
						 .arg(editor.view.scene->entities.teamCount));
	}
	drawTray();
	drawStatusToast();
}

std::vector<std::string> PhoneEditor::headerLabels() const
{
	const bool objects = paletteMode >= 2;
	std::vector<std::string> labels = {
		GAGCore::Toolkit::getStringTable()->getString("[Menu]"),
		objects
			? GAGCore::FormattableString(GAGCore::Toolkit::getStringTable()->getString("[Team %0]"))
				  .arg(editor.team + 1)
			: GAGCore::FormattableString(
				  GAGCore::Toolkit::getStringTable()->getString("[Brush %0x%1]"))
				  .arg(BrushTool::getBrushWidth(editor.brush.getFigure()))
				  .arg(BrushTool::getBrushHeight(editor.brush.getFigure())),
		objects ? GAGCore::FormattableString(
					  GAGCore::Toolkit::getStringTable()->getString("[Level %0]"))
					  .arg((editor.selectionMode == MapEdit::PlaceUnit ? editor.placingUnitLevel
																	   : editor.buildingLevel) +
						   1)
				: (editor.brush.getType() == BrushTool::MODE_DEL
					   ? GAGCore::Toolkit::getStringTable()->getString("[Erase]")
					   : GAGCore::Toolkit::getStringTable()->getString("[Paint]")),
		pan ? GAGCore::Toolkit::getStringTable()->getString("[Pan]")
		: editor.selectionMode != MapEdit::PlaceNothing
			? GAGCore::Toolkit::getStringTable()->getString("[Done]")
			: GAGCore::Toolkit::getStringTable()->getString("[Select]")};
	if (editor.selectionMode == MapEdit::PlaceTerrain &&
		TerrainSelector::isBaseTerrain(editor.terrainType))
	{
		const auto type = TerrainSelector::baseTerrain(editor.terrainType);
		const auto *label = editor.view.scene->map.terrainPresentation(type).label;
		labels[2] = unsigned(type) < TERRAIN_COUNT
						? GAGCore::Toolkit::getStringTable()->getString(label)
						: label;
	}
	else if (editor.selectionMode == MapEdit::RemoveObject)
		labels[2] = GAGCore::Toolkit::getStringTable()->getString("[delete]");
	// Zones show Paint/Erase beside the size; the rail also changes both, and
	// its Pan toggle moves the map with one finger.
	if (editor.selectionMode == MapEdit::PlaceZone)
	{
		labels[2] = editor.brush.getType() == BrushTool::MODE_DEL
						? GAGCore::Toolkit::getStringTable()->getString("[Erase]")
						: GAGCore::Toolkit::getStringTable()->getString("[Paint]");
		labels[3] = GAGCore::Toolkit::getStringTable()->getString("[Done]");
	}
	return labels;
}
