"""Artifact-only kit5 envelope: preserve6358 prior values; add one directly reviewed native caption.
Does not edit tracked catalogs, execute tests, or approve/infer any integration gate.
"""
from pathlib import Path
import copy,hashlib,importlib.util,json,shutil,subprocess
R=Path.cwd();K=R/'artifacts/filipino-localization';O=K/'final-kit4';F=K/'final-kit5';D=K/'master-delta5'
spec=importlib.util.spec_from_file_location('T',R/'tools/localization/translation_program.py');T=importlib.util.module_from_spec(spec);spec.loader.exec_module(T)
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();value_sha=lambda s:hashlib.sha256(s.encode()).hexdigest();write=T.write_json
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert revision=='ae20bdb4f9771e61f748fd6be8c6513a29169079';assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True);assert not F.exists(),'Refuse existing kit5'
source_delta=read(D/'source.json')['entries'];author=read(D/'author-final.json');final=read(D/'final.json');assert len(final)==1 and set(final)==set(author)==set(source_delta);assert sha(D/'final.json')=='5539c83d0d157e5723f9bcf9698e04f02cb9e33130b64c54bbfba41fe64372d7'
ids=['native:'+key for key in source_delta]
roles=[('author-review.json','/root/draft_editor',author),('meaning-review.json','/root/meaning_reviewer',author),('editor-review.json','/root/language_editor',final),('meaning-final-review.json','/root/meaning_reviewer',final),('adversarial-review.json','/root/adversarial_reviewer',final)]
def target_value(e):
 for name in ['author_final','final_value','target','final_target','translation']:
  if isinstance(e.get(name),str):return e[name]
 raise AssertionError('No direct target')
def target_hash(e):
 for name in ['final_value_sha256','target_value_sha256','final_target_sha256','target_sha256']:
  if isinstance(e.get(name),str):return e[name]
 raise AssertionError('No direct target hash')
for name,identity,stage in roles:
 record=read(D/name);assert record.get('identity',record.get('reviewer'))==identity
 es=record['entries'];assert len(es)==1 and [e['id'] for e in es]==ids
 for e in es:
  key=e['id'].split(':',1)[1];assert e['source']==source_delta[key] and e['source_value_sha256']==value_sha(source_delta[key]);assert target_value(e)==stage[key] and target_hash(e)==value_sha(stage[key])
 if name in ['editor-review.json','meaning-final-review.json','adversarial-review.json']:
  assert not record.get('unresolved_major') and not record.get('unresolved_critical') and not record.get('unresolved_uncertainty') and not record.get('unresolved_linguistic_uncertainty')
  assert all('approv' in str(e['status']).lower() for e in es)
  assert not record.get('findings')
keys,native,online,files,source=T.sources(R);oldmanifest=read(O/'manifest.json');oldsource=read(O/'source/native.json');oldonline=read(O/'source/online.json');oldtarget=read(O/'drafts/fil/native.json');oldonlinetarget=read(O/'drafts/fil/online.json');target,errors=T.CHECKER.read_table(R/'data/texts.fil.txt');online_target=read(R/'platform/packages/i18n/locales/fil.json');oldofficial=read(O/'reviews/fil.json')
assert not errors and native==dict(oldsource,**source_delta) and target==dict(oldtarget,**final);assert online==oldonline and online_target==oldonlinetarget
assert len(oldsource)==3411 and len(oldonline)==2947 and len(native)==3412 and len(online)==2947 and len(oldmanifest['batches'])==47
assert all(files[p]==oldmanifest['source_files'][p] for p in T.SOURCE_PATHS if p not in ['data/texts.en.txt','data/texts.keys.txt'])
assert sha(R/'platform/packages/i18n/locales/fil.json')==oldofficial['catalog_sha256']['online']=='30c1e0e2f79104b31ba14b7704b0df44b82065436bbee22dd2963bf1116e948c'
assert sha(O/'drafts/fil/texts.fil.txt')==oldofficial['catalog_sha256']['native'];assert sha(O/'drafts/fil/fil.json')==oldofficial['catalog_sha256']['online'];assert len(oldofficial['accepted_english'])==268
# Capture immutable old-kit file hashes to prove this assembler leaves every byte alone.
old_files={str(p.relative_to(O)):sha(p) for p in O.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
shutil.copytree(O,F,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));shutil.copytree(D,F/'master-delta5');B=F/'master-delta5/before';B.mkdir()
for src,name in [(F/'manifest.json','manifest.json'),(F/'source/native.json','source-native.json'),(F/'source/online.json','source-online.json'),(F/'drafts/fil/native.json','target-native.json'),(F/'drafts/fil/texts.fil.txt','target-native.txt'),(F/'drafts/fil/online.json','target-online.json'),(F/'drafts/fil/fil.json','target-online-catalog.json'),(F/'drafts/fil/metadata.json','metadata.json'),(F/'reviews/fil.json','official.json'),(F/'reviews/fil-provenance.json','provenance.json')]:shutil.copyfile(src,B/name)
def ev(p):return {'path':str(p.relative_to(F)),'sha256':sha(p)}
manifest=copy.deepcopy(oldmanifest);bid='native-master-delta-005';manifest.update(revision=revision,source_sha256=source,source_files=files,native_keys=len(native),online_keys=len(online));manifest['batches'].append({'id':bid,'path':'batches/'+bid+'.json','keys':ids});write(F/'manifest.json',manifest);write(F/'source/native.json',native);(F/'source/native-keys.txt').write_text('\n'.join(keys)+'\n')
for batch in oldmanifest['batches']:
 p=F/batch['path'];v=read(p);v['source_sha256']=source;v['source_carry_forward']='master-delta5/source-target-carry.json';write(p,v)
write(F/'batches'/(bid+'.json'),{'id':bid,'source_sha256':source,'surface':'native','domain':'custom-game','context':'Bulk AI selector for every Computer OR Shared colony in new master CustomGameScreen playersTab; individual choices remain editable. Only caption translated, no simulation behavior.','entries':[{'id':'native:'+key,'key':key,'source':native[key]} for key in final]})
write(F/'drafts/fil/native.json',target);shutil.copyfile(R/'data/texts.fil.txt',F/'drafts/fil/texts.fil.txt');paths=T.catalog_paths(F,'fil');hashes={s:sha(p) for s,p in paths.items()};meta=read(F/'drafts/fil/metadata.json');meta.update(source_sha256=source,source_revision=revision,catalog_sha256=hashes);write(F/'drafts/fil/metadata.json',meta)
rolefiles=[n for n,_,_ in roles];changes=[key for key in final if author[key]!=final[key]];assert not changes
proof={'scope':'All6358 previous source/target values exactly unchanged:3411native+2947online. One added native label has five direct stages from four distinct identities; final retained author wording. No fresh6358-entry review claimed.','source_before_sha256':oldmanifest['source_sha256'],'source_after_sha256':source,'catalog_before_sha256':oldofficial['catalog_sha256'],'catalog_after_sha256':hashes,'unchanged_native_ids':['native:'+key for key in oldsource],'unchanged_online_ids':['online:'+key for key in oldonline],'added_ids':ids,'author_stage_sha256':sha(F/'master-delta5/author-final.json'),'final_stage_sha256':sha(F/'master-delta5/final.json'),'actual_editorial_changed_ids':[],'new_unchanged_after_editor_ids':ids,'stage_values':[{'id':'native:'+key,'source_sha256':value_sha(source_delta[key]),'author_sha256':value_sha(author[key]),'final_sha256':value_sha(final[key]),'author':author[key],'final':final[key],'edited_after_author':False} for key in final],'before_evidence':[ev(p) for p in sorted(B.iterdir())],'direct_reviews':[ev(F/'master-delta5'/name) for name in rolefiles]};write(F/'master-delta5/source-target-carry.json',proof)
record=read(F/'reviews/fil.json');prov=read(F/'reviews/fil-provenance.json');targets=T.batch_target_hashes(manifest,paths)
for batch in record['batches']:
 assert batch['target_sha256']==targets[batch['id']],'Old47 batch target hash changed: '+batch['id'];batch['source_sha256']=source;batch.setdefault('provenance',{})['native_delta5_source_carry']=ev(F/'master-delta5/source-target-carry.json')
record['batches'].append({'id':bid,'source_sha256':source,'target_sha256':targets[bid],'author':'/root/draft_editor','reviewer':'/root/meaning_reviewer','editor':'/root/language_editor','rechecked_by':'/root/meaning_reviewer','adversarial_reviewer':'/root/adversarial_reviewer','reviewed_keys':ids,'edited_keys':ids,'rechecked_keys':ids,'adversarial_reviewed_keys':ids,'provenance':{'scope':'edited_keys means actual full editorial coverage of the one added label; actual changed subset is empty, final equals author snapshot.','source_carry':ev(F/'master-delta5/source-target-carry.json'),'direct_reviews':[ev(F/'master-delta5'/name) for name in rolefiles]}})
checked=T.check_draft(F,'fil');assert not checked['errors'] and not checked['untranslated'];queue=set(checked['same_as_english_review_queue']);accepted={e['key'] for e in record['accepted_english']};assert queue==accepted and len(accepted)==268;assert record['accepted_english']==oldofficial['accepted_english']
prov.update(source_sha256=source,catalog_sha256=hashes);prov.setdefault('role_evidence',[]).extend(ev(F/'master-delta5'/name) for name in rolefiles);prov.setdefault('post_review_deltas',[]).append(ev(F/'master-delta5/source-target-carry.json'));prov['method']+=' One new native bulk-AI caption received five direct stages/four identities; prior6358 source/target values retained exactly. No new whole-English exception.';write(F/'reviews/fil-provenance.json',prov);record.update(source_sha256=source,catalog_sha256=hashes,provenance=ev(F/'reviews/fil-provenance.json'))
assert len(record['gates'])==9
for gate in record['gates'].values():gate['passed']=False;gate['invalidated_by']='Master1801 UI/inspection integration plus8 adaptive geometry candidates and1 new native caption require current ae20/scoped carry integration evidence. Kit4 runtime/visual producers remain historical. No approval inferred from assembly.'
write(F/'reviews/fil.json',record);rows=len(native)+sum(len(v) if isinstance(v,dict) else 1 for v in online.values());assert rows==6386 and rows*6==38316 and len(manifest['batches'])==len(record['batches'])==48 and len(native)+len(online)==6359
assert old_files=={str(p.relative_to(O)):sha(p) for p in O.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'},'Original kit4 changed during assembly'
summary={'identity':'/root/language_editor','revision':revision,'source_sha256':source,'catalog_sha256':hashes,'counts':{'native':3412,'online':2947,'keys':6359,'rows':6386,'expected_matrix_samples':38316,'batches':48,'accepted_english':268},'prior_batch_target_hashes_unchanged':47,'prior_source_target_ids_unchanged':6358,'direct_stage_records':5,'distinct_roles':4,'gates_invalidated':9,'original_kit4_tree_files_verified_unchanged':len(old_files),'original_kit4_files_sha256':old_files,'assembler_sha256':sha(D/'assemble_final_kit5.py'),'draft_check':{'errors':checked['errors'],'untranslated':checked['untranslated']},'limits':['Artifact envelope assembly only. No runtime test/visual/gate approval; original source snapshots/stages preserve their actual historical producers.','Kit4 all file bytes checked before/after unchanged. Existing47 batch source hashes rebound via explicit equality carry; their entries/target hashes unchanged.']};write(F/'master-delta5/envelope-assembly.json',summary);print(json.dumps({k:v for k,v in summary.items() if k not in ['original_kit4_files_sha256','limits']}))
