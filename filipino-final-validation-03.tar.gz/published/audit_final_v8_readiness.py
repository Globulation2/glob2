from pathlib import Path
import json,hashlib,subprocess,sys,re,base64,gzip,importlib.util
R=Path.cwd();K=R/'artifacts/filipino-localization';P=K/'published';F=K/'final-kit6';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());plan=read(P/'final-v8-freeze-candidate-evidence-plan.json');sys.path.insert(0,str(R/'tools/localization'));import translation_program as T
m=read(F/'manifest.json');r=read(F/'reviews/fil.json');checks=[];issues=[]
def ck(v,label):
 checks.append({'check':label,'pass':bool(v)})
 if not v:issues.append(label)
_,ns,os,sf,source=T.sources(R);ck(source==m['source_sha256']=='013211b6f2bee9da8f4e9bb990d49fb18c99fedec710ed23603d12875f0960c5','Actual English/source contract current');ck(len(ns)==3412 and len(os)==2978,'6390current English keys');ck(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='c35a7b2ebbdb83b264ecc6b0bcf29d89ef926fab' and not subprocess.check_output(['git','status','--porcelain'],text=True),'Exactclean c35source');ck(T.audit_locale(F,m,r,'fil')==[],'Official current locale audit zeroissues');ck(len(r['gates'])==9 and all(g['passed'] is True for g in r['gates'].values()),'All9officialgates passed')
gaterefs=[]
for name,g in r['gates'].items():
 for e in g['evidence']:
  p=(F/e['path']).resolve();ok=p.is_file() and sha(p)==e['sha256'];ck(ok,name+' exact evidence '+e['path']);gaterefs.append({'gate':name,**e,'pass':ok})
pre=read(F/'reviews/fil-pre-runtime-gates.json');ck(all(g['passed'] is False for g in pre['gates'].values()),'Immutable initial9invalidated gate snapshot preserved');a=read(F/'master-delta6/independent-aggregate-audit.json');ck(a['issues']==[] and len(a['checks'])==1278 and a['total_ids']==6390,'Independent1278check linguistic aggregate zeroissues')
for e in plan['extra_files']:
 p=K/e['path'];ck(p.is_file() and sha(p)==e['sha256'],'Selected currentfile exact '+e['path'])
ck(not plan['pending_gates'] and not plan['unresolved_reference_discrepancies'],'Selection no pendinggates/unreconciledrefs')
# Reproduce curator selection exactly, including retained historical envelopes.
spec=importlib.util.spec_from_file_location('curator',P/'curate_final_evidence.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C);external=read(K/plan['external_archive_index']['path']);members={(e['kit_relative_path'],e['sha256']) for ar in external['archives'] for e in ar['entries']};files={K/e['path'] for e in plan['extra_files']};scripts={e['path']:e['sha256'] for e in plan['reviewed_scripts']}
for name in C.BASE_TREES:
 for p in (K/name).rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(K)
  if set(rel.parts)&C.FORBIDDEN or p.suffix in {'.pyc','.lock'} or p.name in {'ROOT-STATE.json','.lock'}:continue
  C.safe(p,scripts)
  if (str(rel),sha(p)) not in members:files.add(p)
unique={};privacy=[];scanned=0;inline_pngs=0
patterns={'google_access_token':rb'ya29\.[A-Za-z0-9_-]{30,}','google_api_key':rb'AIza[A-Za-z0-9_-]{30,}','github_token':rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{40,})','private_key':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\s*\n[A-Za-z0-9+/=\r\n]{32,}','literal_bearer':rb'Bearer\s+(?:ya29\.[A-Za-z0-9_-]{20,}|eyJ[A-Za-z0-9_.-]{40,})'}
def strip_binary_attachments(v):
 global inline_pngs
 if isinstance(v,dict):
  if v.get('contentType')=='image/png' and isinstance(v.get('body'),str):
   try:raw=base64.b64decode(v['body'],validate=True)
   except ValueError:raw=b''
   if raw.startswith(b'\x89PNG\r\n\x1a\n'):v['body']='[verified PNG binary attachment omitted from textual credential scan]';inline_pngs+=1
  for x in v.values():strip_binary_attachments(x)
 elif isinstance(v,list):
  for x in v:strip_binary_attachments(x)
for p in sorted(files):
 raw=p.read_bytes();unique[(hashlib.sha256(raw).hexdigest(),len(raw))]=len(raw)
 if p.suffix=='.gz' and p.name.endswith(('.log.gz','.json.gz','.jsonl.gz','.txt.gz')):raw=gzip.decompress(raw)
 elif p.suffix not in {'.json','.jsonl','.txt','.md','.log','.py','.sh','.ts','.tsx','.js','.mjs','.cpp','.h','.diff','.xml'}:continue
 scanned+=1
 if p.name.endswith(('.json','.json.gz')):
  try:v=json.loads(raw);strip_binary_attachments(v);raw=json.dumps(v,ensure_ascii=False).encode()
  except (ValueError,UnicodeDecodeError):pass
 for typ,pattern in patterns.items():
  count=len(re.findall(pattern,raw))
  if count:privacy.append({'path':str(p.relative_to(K)),'type':typ,'count':count})
ck(not privacy,'Concrete credential/privatekey patterns zero after verified binary PNG exclusion');logical=sum(p.stat().st_size for p in files);physical=sum(unique.values());ck(len(files)<=5000 and logical<=768*1024**2 and physical<=512*1024**2,'Finalselection file/logical/physicalbounds')
result={'identity':'/root/adversarial_reviewer','status':'passed scoped final readiness/hash/privacy' if not issues else 'issues','revision':'c35a7b2ebbdb83b264ecc6b0bcf29d89ef926fab','source_sha256':source,'official_review_sha256':sha(F/'reviews/fil.json'),'immutable_pre_runtime_review_sha256':sha(F/'reviews/fil-pre-runtime-gates.json'),'independent_aggregate_sha256':sha(F/'master-delta6/independent-aggregate-audit.json'),'checks':checks,'issues':issues,'gate_evidence_hashes':gaterefs,'selection_files':len(files),'logical_bytes':logical,'unique_payload_bytes':physical,'privacy_text_files':scanned,'verified_inline_pngs_excluded_from_text_scan':inline_pngs,'privacy_matches':privacy,'plan_sha256':sha(P/'final-v8-freeze-candidate-evidence-plan.json'),'limits':['Hash/schema/source/privacy audit is not fresh linguistic reread or fresh visualinspection; actual pixel/linguistic reviewers remain independently identified.','Existing source lintbaseline retained in actual data report; no introduced failure hidden.','Scoped Linux/Chromium/asset-only mobile evidence; physicalAndroid/iOS/nativeWindows/macOS execution not claimed.','No claim against arbitrary secretformats; concrete credential andprivatekey patterns scanned without printing matchedbytes.','Final archive compressed60MiB bound andsequential per-member extraction hash verification still enforced bycurator build.']}
out=P/'final-v8-readiness-audit.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'checks':len(checks),'issues':issues,'files':len(files),'logical_bytes':logical,'unique_bytes':physical,'privacy_matches':privacy,'sha256':sha(out)}))
