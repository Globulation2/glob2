#!/usr/bin/env python3
"""Prepare bounded final evidence from explicit plan; never publishes or changes reviews."""
from pathlib import Path,PurePosixPath
import argparse,gzip,hashlib,json,shutil,tarfile
ROOT=Path(__file__).resolve().parents[3];K=ROOT/'artifacts/filipino-localization';PUB=K/'published'
BASE_TREES=['source','batches','google','author','editor','linguistic','adversary','reviews','drafts','final-kit','master-delta','final-kit2','master-delta2','final-kit3','master-delta3']
FORBIDDEN={'.git','node_modules','__pycache__','profile','profiles','trace','traces','cache','caches','bin','lib','include','runtime-assets','assets','db','database'}
EXTENSIONS=('.json','.jsonl','.txt','.md','.log','.log.gz','.json.gz','.jsonl.gz','.txt.gz','.xml','.png','.diff','.py','.sh')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def safe(p,reviewed_scripts=None):
 rel=p.relative_to(K);assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(K.resolve()),p
 assert not set(rel.parts)&FORBIDDEN and not any(x.endswith('-assets') for x in rel.parts),p
 assert p.name!='ROOT-STATE.json',p
 if not p.name.endswith(EXTENSIONS):
  assert p.suffix in {'.js','.mjs'} and reviewed_scripts is not None and str(rel) in reviewed_scripts,p
  assert p.stat().st_size<=128*1024 and sha(p)==reviewed_scripts[str(rel)],'Unreviewed or oversized capture script '+str(rel)
 assert p.stat().st_size<=64*1024**2,'Per-file64MiB bound exceeded: '+str(rel)
 return p

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('plan',type=Path);ap.add_argument('--build',action='store_true',help='Default only validates; explicitly build archive after all gate/evidence updates finish.');a=ap.parse_args();plan=json.loads(a.plan.read_text());files=set();omitted=[];reviewed_scripts={e['path']:e['sha256'] for e in plan.get('reviewed_scripts',[])}
 assert plan.get('final_receipts_frozen') is True,'Root must finish/freeze final evidence first'
 for name in BASE_TREES:
  root=K/name;assert root.is_dir(),root
  for p in root.rglob('*'):
   if not p.is_file():continue
   rel=p.relative_to(K)
   if set(rel.parts)&FORBIDDEN or p.suffix=='.pyc' or p.name=='ROOT-STATE.json':omitted.append(str(rel));continue
   files.add(safe(p,reviewed_scripts))
 for e in plan['extra_files']:
  rel=PurePosixPath(e['path']);assert not rel.is_absolute() and '..' not in rel.parts
  p=safe(K/str(rel),reviewed_scripts);assert sha(p)==e['sha256'],'Pinned final evidence changed '+str(rel);files.add(p)
 assert 1<=len(files)<=5000,'File count bound';total=sum(p.stat().st_size for p in files);assert total<=512*1024**2,'Uncompressed512MiB campaign bound'
 assert shutil.disk_usage(PUB).free>2*total+60*1024**2,'Insufficient campaign free space'
 # Pin aggregate reviews and final evidence before reading payload bytes. No implicit signoff.
 for e in plan['frozen_receipts']:
  p=K/e['path'];assert sha(p)==e['sha256'],'Frozen receipt changed '+e['path']
 entries=[{'path':str(p.relative_to(K)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
 summary={'mode':'build' if a.build else 'validate-only','files':len(entries),'payload_bytes':total,'plan_sha256':sha(a.plan),'archive_limit_bytes':60*1024**2,'uncompressed_limit_bytes':512*1024**2}
 if not a.build:print(json.dumps(summary));return
 archive=PUB/'filipino-final-validation.tar.gz';assert not archive.exists(),'Refuse to overwrite frozen archive; root may choose a reviewed new filename in script explicitly'
 try:
  with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=6,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
   for e in entries:
    p=K/e['path'];assert sha(p)==e['sha256'],'Evidence changed during archive '+e['path']
    info=tar.gettarinfo(str(p),arcname=e['path']);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with p.open('rb') as f:tar.addfile(info,f)
    assert raw.tell()<=60*1024**2,'Compressed60MiB archive bound exceeded'
  assert archive.stat().st_size<=60*1024**2,'Compressed60MiB archive bound exceeded'
  with tarfile.open(archive,'r:gz') as tar:
   members=tar.getmembers();assert len(members)==len(entries)
   for member,e in zip(members,entries):assert member.isfile() and member.name==e['path'] and hashlib.sha256(tar.extractfile(member).read()).hexdigest()==e['sha256'],'Extraction hash mismatch'
  for e in plan['frozen_receipts']:assert sha(K/e['path'])==e['sha256'],'Frozen receipt changed during archive'
 except BaseException:
  archive.unlink(missing_ok=True);raise
 manifest=dict(summary,archive=archive.name,archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),kit_relative_paths=True,entries=entries,omitted_excluded_paths=omitted,original_historical_kit='Original source/batches/Google/four-role/review/draft trees are retained as historical evidence; final-kit is the historical6231key envelope; final-kit2 is historical6243keys; final-kit3 is the authoritative6247key envelope with exact6243carry and4new direct four-role reviews.',frozen_receipts=plan['frozen_receipts'],scope=plan['scope'],limits=plan['limits'])
 (PUB/'final-validation-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:manifest[k] for k in ['archive','archive_bytes','archive_sha256','files']}))
if __name__=='__main__':main()
