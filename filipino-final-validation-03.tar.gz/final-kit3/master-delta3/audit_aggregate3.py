from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[4];K=ROOT/'artifacts/filipino-localization';F=K/'final-kit3';B=K/'final-kit2';sys.path.insert(0,str(ROOT/'tools/localization'));import translation_program as P
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=lambda s:hashlib.sha256(s.encode()).hexdigest();issues=[];checks=[]
def ck(v,label):checks.append({'check':label,'passed':bool(v)});issues.extend([] if v else [label])
m=read(F/'manifest.json');r=read(F/'reviews/fil.json');prov=read(F/'reviews/fil-provenance.json');bm=read(B/'manifest.json');br=read(B/'reviews/fil.json');bp=read(B/'reviews/fil-provenance.json');carry=read(F/'master-delta3/source-target-carry.json');final=read(F/'master-delta3/final.json');author=read(F/'master-delta3/author-final.json');old={s:read(B/'source'/ (s+'.json')) for s in ['native','online']};new={s:read(F/'source'/ (s+'.json')) for s in ['native','online']};oldtarget={s:read(B/'drafts/fil'/(s+'.json')) for s in old};newtarget={s:read(F/'drafts/fil'/(s+'.json')) for s in old};ids={'native:'+k for k in final}
ck(len(old['native'])==3407 and len(old['online'])==2836,'Previous6243entry source inventory')
ck(set(new['native'])==set(old['native'])|set(final) and not(set(old['native'])&set(final)) and len(final)==4,'Only4new native IDs')
ck(all(new['native'][k]==v for k,v in old['native'].items()) and new['online']==old['online'],'All6243previous English source values unchanged')
ck(all(newtarget['native'][k]==v for k,v in oldtarget['native'].items()) and newtarget['online']==oldtarget['online'],'All6243previous target values unchanged')
ck(newtarget['native']==dict(oldtarget['native'],**final),'Final native contains exact previous targets plus4reviewedtargets only')
ck(set(carry['unchanged_native_ids'])=={'native:'+k for k in old['native']} and len(carry['unchanged_native_ids'])==3407 and set(carry['unchanged_online_ids'])=={'online:'+k for k in old['online']} and len(carry['unchanged_online_ids'])==2836,'Exact unique6243carry IDs')
ck(set(carry['added_ids'])==ids and len(carry['added_ids'])==4,'Exact4newcarry IDs')
keys,ns,os,sourcefiles,source=P.sources(ROOT);paths=P.catalog_paths(F,'fil');catalog={s:sha(p) for s,p in paths.items()}
ck(source==m['source_sha256']==r['source_sha256']==prov['source_sha256']==carry['source_after_sha256']=='b7ed54ddecb1840204b30775c4f8cc69c34cc23d0f11695ad9ece2593bd451bb','Final source contract exact')
ck(catalog==r['catalog_sha256']==prov['catalog_sha256']==carry['catalog_after_sha256'] and catalog['native']=='017c3da56738d3005d434fbe5160240b3dc342e4d4ffd8f97fc4991ce14fe54a' and catalog['online']=='99ed554f753390682d437318e20ed9d7ddbd54fbe2c798df41b42d4fb3fb2446','Final catalog file hashes exact')
ck(sha(ROOT/'data/texts.fil.txt')==catalog['native'] and ns==new['native'] and os==new['online'] and sourcefiles==m['source_files'],'Final snapshots equal installed source/Fil targets')
ck(all(sourcefiles[n]==bm['source_files'][n] for n in P.SOURCE_PATHS if n not in ['data/texts.keys.txt','data/texts.en.txt']),'Online plural/invariant/source contracts unchanged')
expected={b['id']:set(b['keys']) for b in m['batches']};flat=[x for b in m['batches'] for x in b['keys']];allids={'native:'+k for k in ns}|{'online:'+k for k in os};ck(len(expected)==len(m['batches'])==len(r['batches'])==46,'Exactly46source/review batches');ck(len(flat)==len(set(flat))==6247 and set(flat)==allids,'Every6247ID covered exactlyonce')
th=P.batch_target_hashes(m,paths);oldb={b['id']:b for b in br['batches']}
for b in r['batches']:
 bid=b['id'];ck(b['source_sha256']==source and b['target_sha256']==th[bid],bid+': correct source envelope/target batch hash')
 ck(len({b[x] for x in ['author','reviewer','editor','adversarial_reviewer']})==4 and b['rechecked_by']==b['reviewer'],bid+':4distinct roles and meaning recheck')
 for field in ['reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys']:ck(set(b[field])==expected[bid] and len(b[field])==len(set(b[field])),bid+': '+field)
 if bid in oldb:
  prev=oldb[bid];ck(all(b[k]==v for k,v in prev.items() if k not in ['source_sha256','provenance']),bid+': all previous identities/coverage/targethash fields unchanged')
  ck(all(b['provenance'].get(k)==v for k,v in prev.get('provenance',{}).items() if k!='master_source_carry'),bid+': historical role reference paths preserved')
roles={'author-review.json':'/root/draft_editor','meaning-review.json':'/root/meaning_reviewer','editor-review.json':'/root/language_editor','meaning-final-review.json':'/root/meaning_reviewer','adversarial-review.json':'/root/adversarial_reviewer'};direct=[]
for name,who in roles.items():
 path=F/'master-delta3'/name;v=read(path);rows={e['id']:e for e in v['entries']};ck(v.get('identity',v.get('reviewer'))==who and len(v['entries'])==4 and set(rows)==ids,name+':actual identity/exact4IDs')
 for key,value in final.items():
  e=rows['native:'+key];ck(e['source']==ns[key] and e['source_value_sha256']==h(ns[key]) and e.get('final_value_sha256',e.get('target_value_sha256'))==h(value) and e.get('author_final',e.get('final_value',e.get('target')))==value,name+':actual source/final hash '+key)
  if name!='author-review.json':ck('approved' in e.get('status',''),name+':actual approval '+key)
 direct.append({'path':str(path.relative_to(F)),'sha256':sha(path),'identity':who})
for name in roles:
 v=read(F/'master-delta3'/name);sourceh=v.get('source_snapshot_sha256',v.get('input_evidence',{}).get('source.json'))
 ck(sourceh==sha(F/'master-delta3/source.json'),name+': exact4source snapshot file hash')
 if name=='author-review.json':targeth=v['output']['sha256']
 elif name=='editor-review.json':targeth=v['final_snapshot']['sha256'];ck(v['author_snapshot_sha256']==sha(F/'master-delta3/author-final.json'),'Editor author-snapshot binding')
 elif name=='adversarial-review.json':targeth=v['final_snapshot_sha256']
 else:targeth=v['author_target_snapshot_sha256']
 ck(targeth==sha(F/'master-delta3/final.json'),name+': exact unchanged final snapshot hash')
ck(author==final and sha(F/'master-delta3/author-final.json')==sha(F/'master-delta3/final.json')==carry['author_stage_sha256']==carry['final_stage_sha256']=='914c1c256521240ba20159d1c399b03b64c675c141d83de182bb40d4ac63b8bf','All4retained identical acrossauthor/editor/final stages')
ck(not carry['actual_editorial_changed_ids'] and set(carry['new_unchanged_after_editor_ids'])==ids,'No editorial delta falsely claimed')
editor=read(F/'master-delta3/editor-review.json');meaning=read(F/'master-delta3/meaning-final-review.json');ck(not editor['changed_entries'] and editor['unchanged_entry_count']==4,'Language editor actual0changed/4unchanged')
ck(meaning['prior_meaning_record_sha256']==sha(F/'master-delta3/meaning-review.json') and meaning['editor_record_sha256']==sha(F/'master-delta3/editor-review.json'),'Finalmeaning explicitly binds prior meaning+editor receipts')
ck(prov['role_evidence'][:len(bp['role_evidence'])]==bp['role_evidence'] and len(prov['role_evidence'])==30,'All25previous rolehash references unchanged plus5new roles')
ck(all({'path':e['path'],'sha256':e['sha256']} in prov['role_evidence'] for e in direct),'All5actual new direct role records included in provenance')
refs=[]
def walk(v,at):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=Path(v['path']);p=p if p.is_absolute() else F/p;ok=p.is_file() and sha(p)==v['sha256'];refs.append({'at':at,**v,'passed':ok});ck(ok,at+':referenced file SHA')
  for key,x in v.items():walk(x,at+'.'+key)
 elif isinstance(v,list):
  for i,x in enumerate(v):walk(x,at+'['+str(i)+']')
walk(prov,'provenance');walk(carry,'carryproof');walk(r['language_brief'],'languagebrief');walk(r['provenance'],'currentreview')
for b in r['batches']:walk(b.get('provenance',{}),'batch:'+b['id'])
checked=P.check_draft(F,'fil');ck(len(r['accepted_english'])==265 and r['accepted_english']==br['accepted_english'] and {e['key'] for e in r['accepted_english']}==set(checked['same_as_english_review_queue']),'All265individually reasonedEnglish exceptions exact and unchanged')
ck(all(g['passed'] is False for g in r['gates'].values()),'All9gates invalidated/pending, no inherited runtime pass')
audit=P.audit_locale(F,m,r,'fil');ck(sorted(audit)==sorted(g+' is pending or lacks evidence' for g in P.GATES),'Toolaudit only9expectedpending gate issues')
rows=len(ns)+sum(len(v) if isinstance(v,dict) else 1 for v in newtarget['online'].values());ck(rows==6274 and rows*6==37644,'Current6274rows/37644matrixsample inventory')
ck(m['revision']=='2430012b570077bc27ea3ad7c0d761e63a30f5a1','Source envelope clean243revision');ck(subprocess.run(['git','merge-base','--is-ancestor','bc8fb2c2bda69af14a7a6c5ed5ca1dfed7575ddb','HEAD']).returncode==0,'Actual masterbc8 ancestor of checkout')
result={'identity':'/root/adversarial_reviewer','status':'pass; aggregate linguistic provenance/schema only, all9gates intentionally pending' if not issues else 'issues found','issues':issues,'checks':checks,'source_sha256':source,'catalog_sha256':catalog,'total_ids':6247,'unchanged_previous_ids':6243,'new_directly_reviewed_ids':4,'batches':46,'english_exceptions':265,'role_evidence_count':30,'evidence_reference_checks':refs,'new_direct_reviews':direct,'expected_pending_gates':list(P.GATES),'expected_matrix_rows':rows,'expected_matrix_samples':rows*6,'envelope_revision':m['revision'],'actual_checkout_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'snapshot_hashes':{str(p.relative_to(F)):sha(p) for p in [F/'manifest.json',F/'reviews/fil.json',F/'reviews/fil-provenance.json',F/'master-delta3/source-target-carry.json']},'scope':'Independent exact-value/ID/hash/identity audit. Originalfullreviews and all prior source-delta receipts remain historical. All6243previous sources+targets carry unchanged; only4new terrain labels have new direct final role reads. No fresh6247entry whole-catalog linguistic read or runtime approval claimed.','limits':['All9gates deliberatelypending in new243source envelope; oldFFF runtime evidence remains historical in kit2.','No previous root/final-kit/final-kit2 receipt or officialgate modified.','Actual newcode rendering/build/platform coverage belongs to separately scoped completed evidence.']}
P.write_json(F/'master-delta3/independent-aggregate-audit.json',result);print(json.dumps({'status':result['status'],'checks':len(checks),'refs':len(refs),'issues':issues}))
