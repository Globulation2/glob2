from pathlib import Path
import json,hashlib,datetime,re
P=Path(__file__).parent;H=lambda s:hashlib.sha256(s.encode()).hexdigest();F=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();s=json.loads((P/'source.json').read_text());d=json.loads((P/'draft.json').read_text());keys=list(s['entries'])
values='''Tanaw sa harap
Tanaw sa likod
Tanaw sa kaliwa
Tanaw sa kanan
Nakapirming pose
Artista
Sinimulan
Mga account bawat araw
Mga laban bawat araw
Mga account ng bisita
Mga nakarehistrong account
Bagong soundtrack
Hintaying matapos ang kasalukuyang kahilingan.
Hindi magamit ang pagbuo. Mabubuksan pa rin ang na-save na musika.
Kailangan ng magagamit na kredito para sa musika upang makapag-chat o bumuo.
Walang nagagastos na kredito sa pag-uusap; kailangan ng 1 magagamit na kredito para sa musika. Awtomatikong nagsisimimula ang pagbuo kapag humiling ng likha · 1 kredito ang ibabawas kapag naihatid. Kasama ang lahat ng tatlong mood.
Lumot at liwanag ng umaga
Isang magiliw na piyesang hango sa kakahuyan, na may plawta, alpa at marahang pagpitik sa mga kuwerdas. Hayaang gumala at bumalik ang himig; sa Labanan ay may mahihinang tambol at kontrahimig ng bassoon.
Munting harding de-susi
Banayad na mga kampanang salamin at mga synth pad na buo ang tunog; mapagtuklas at hindi nagmamadali ang dating. Isang mapaglarong himig na sumasagot, na may mas malalim na pintig habang lumalaki ang kolonya.
Isang waltz para sa ulan
Isang magiliw na folk waltz na may plawtang recorder at kalimba. Mga pariralang musikal na maluwag at may mga pahinga para sa Kalmado, banayad na indayog para sa Pagtatayo, at mainit na tunog ng mga kuwerdas sa mababang rehistro para sa Labanan.
Hindi magamit ang pagbuo. Mabubuksan pa rin ang mga na-save na proyekto.
Kailangan ng magagamit na kredito para sa mapa upang makapag-chat o bumuo.
Walang nagagastos na kredito sa pag-uusap; kailangan ng 1 magagamit na kredito para sa mapa. Awtomatikong nagsisimula ang pagbuo kapag humiling ng likha · 1 kredito ang ibabawas kapag naihatid.
Sine-save ang iyong proyekto…
Hindi magamit ang pagbuo.
Walang nagagastos na kredito sa pag-uusap; kailangan ng 1 magagamit na kredito para sa lupain. Awtomatikong nagsisimula ang pagbuo kapag humiling ng likha · 1 kredito ang ibabawas kapag naihatid.
Mga guhit ng kolonya
Mga batik ng kolonya
Skin na walang pamagat'''.splitlines()
values=[x.replace('nagsisimimula','nagsisimula') for x in values]
assert len(values)==len(keys)==31;final=dict(zip(keys,values))
contexts={
0:'Skin camera orientation preset, not an opinion or strategic outlook; regular Tanaw sa form across four directions.',1:'Rear-facing skin camera preset; consistent Tanaw sa form.',2:'Camera view of the model from its left; not a player departure.',3:'Camera view from the model right; not correctness.',4:'Empty skin animation action means a motionless pose; does not imply standing or a particular physical posture.',5:'Required music publication attribution field paired with title/description/credits; Artista is broad music artist attribution, not translated user-entered artist names.',6:'Admin Match activity chart series started/completed/cancelled counts; Sinimulan parallels Nakumpleto/Kinansela, not a timestamp or command.',7:'Admin daily active-account chart y-axis units, not newly registered-account counts.',8:'Admin daily match-activity y-axis: laban, not lexical matching/tugma.',9:'Anonymous guest-account series in daily activity, not visitors who necessarily registered.',10:'Registered-account activity series, distinct from guest accounts.',11:'Default title of a new Music Studio project, not any authored saved title.',12:'Busy state asks the user to let an in-flight request finish, without sending a new request.',13:'Generation feature unavailable while saved music remains accessible; does not imply stored music is deleted.',14:'Wallet balance prerequisite for Music Studio chat or content generation, not musical creator attribution or in-game construction resources.',15:'Discussion deducts zero credits but requires one available Music credit. Creation starts automatically; exactly one is deducted only on delivery. Covers Calm/Building/Combat arrangements.',16:'Built-in music suggestion title; warm woodland imagery. Does not modify existing user-authored project titles.',17:'Built-in composer suggestion: woodland warmth, flute/harp, softly plucked strings, returning melody; Combat adds quiet drums and bassoon counter-melody, not a bass line or literal hot weather.',18:'Built-in clockwork-themed suggestion title: de-susi evokes mechanical wind-up motion, not a garden made from clocks.',19:'Built-in electronic suggestion: rounded refers to full/soft sustained synth-pad timbre, not circular objects. Keeps curious/unhurried feel, answering melody and deeper pulse as colony grows.',20:'Built-in music suggestion title names the waltz genre and rain imagery; not an instruction to dance.',21:'Built-in folk-waltz prompt: recorder is the wind instrument (qualified plawtang), not a recording device. Sparse breathing phrases become spacious phrasing/rests; building is established Pagtatayo soundtrack mood, not generating music. Low strings are low register, warm timbre.',22:'Generation unavailable while saved projects can still be opened; does not alter or relabel stored user content.',23:'Map Studio spendable credit prerequisite, not source attribution or in-game map resources.',24:'Discussion is free but requires one available Map credit; creation starts automatically and one credit is deducted on delivery.',25:'In-progress persistence notice; existing Filipino software save terminology and source ellipsis preserved.',26:'Feature availability status for generation, without implying saved content unavailable.',27:'Discussion is free but requires one available Terrain credit; creation starts automatically and one credit is deducted on delivery.',28:'Explicit fixed skin SKU/preset label, not an authored custom skin name; striped visual pattern.',29:'Explicit fixed skin SKU/preset label, not a custom design name; spotted visual pattern.',30:'Fallback default name only when a skin design name is blank; cosmetic skin, not literal biological skin. Custom nonblank names remain authored content.'}
loans={4:{'pose':'Existing skin/modeling UI terminology (Pose); distinguishes an animation pose from standing posture.'},11:{'soundtrack':'Existing game music term for a set containing the three synchronized moods.'},15:{'mood':'Existing selector term for Calm/Building/Combat music arrangements, consistent with current catalog.'},17:{'bassoon':'Specific orchestral woodwind instrument; retain its recognizable instrument name rather than substitute a bass line or another instrument.'},19:{'synth pad':'Specific sustained synthesizer texture; retaining the technical name avoids physical pads or geometric-round interpretations.'},20:{'waltz':'Recognizable international music/dance genre in triple meter; source preset genre remains identifiable.'},21:{'folk':'Music genre descriptor, not a claim of specifically Filipino indigenous music.','waltz':'International genre name, consistent with its adjacent preset title.','recorder':'Specific flute-family wind instrument; qualified by plawtang to exclude a recording device.','kalimba':'Specific musical instrument name; no generic substitution.'},30:{'skin':'Existing game cosmetic term (Mga Skin), not literal biological balat.'}}
for i,k in enumerate(keys):
 v=final[k]
 if 'account' in v:loans.setdefault(i,{})['account']='Existing online sign-in/account term, consistent with the guest/registered account UI.'
 if 'chat' in v:loans.setdefault(i,{})['chat']='Existing Studio text-conversation operation; separate from requesting paid generation.'
 if 'save' in v:loans.setdefault(i,{})['save']='Existing software operation for persisted projects/music; does not rewrite authored saved content.'
refs={lang:json.loads((Path('platform/packages/i18n/locales')/(lang+'.json')).read_text()) for lang in ['es','id']};entries=[]
for i,k in enumerate(keys):
 v=final[k];assert re.findall(r'\{[^}]+\}',k)==re.findall(r'\{[^}]+\}',v);assert v==v.strip()
 entries.append({'id':'online:'+k,'source':s['entries'][k],'source_value_sha256':H(s['entries'][k]),'google_draft':d[k],'draft_value_sha256':H(d[k]),'author_final':v,'final_value_sha256':H(v),'edited':v!=d[k],'rationale':contexts[i],'intentional_english_terms':loans.get(i,{}),'reference_translations':{lang:cat.get(k) for lang,cat in refs.items()},'status':'author-edited-awaiting-independent-reviews'})
(P/'author-final.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
files=['platform/apps/web/src/pages/music-studio/ideas.ts','platform/apps/web/src/messages.ts','platform/apps/web/src/music/Library.tsx','platform/apps/web/src/admin/Overview.tsx','platform/apps/web/src/skins/labels.ts','platform/apps/web/src/pages/music-studio/Workspace.tsx','platform/packages/i18n/locales/fil.json','platform/packages/i18n/locales/es.json','platform/packages/i18n/locales/id.json']
r={'role':'draft editor / author','reviewer':'/root/draft_editor','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual source/draft/final read and author edit of exactly31 newly added online keys. Built-in suggestions/defaults are UI copy; no authored user content changed. No fresh read claimed for prior6359 entries; no tracked catalogs edited.','source_revision':s['merge_revision'],'source_program_sha256':s['source_sha256'],'input_sha256':{n:F(P/n) for n in ['source.json','draft.json']},'context_files_actually_read_sha256':{n:F(n) for n in files},'context_scope':'Complete ideas.ts plus relevant declarations/label maps/rendering excerpts of listed source files, and existing Filipino terminology/Spanish+Indonesian references. Hashes bind whole input files; no whole-file review claimed.','final_file_sha256':F(P/'author-final.json'),'entry_count':31,'edited_count':sum(x['edited'] for x in entries),'entries':entries};(P/'author-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(r['final_file_sha256'],'edits',r['edited_count'])
