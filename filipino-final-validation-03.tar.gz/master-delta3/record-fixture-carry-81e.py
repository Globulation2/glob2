from pathlib import Path
import json,hashlib,subprocess,xml.etree.ElementTree as E
r=Path.cwd();k=r/'artifacts/filipino-localization';p=k/'master-delta3';a='4ffe6b1ec042c35cced022ddf496065118051ac5';b='81e09c3b646c7055e1281bf84d2471a84d890f8f';sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest();git=lambda *v:subprocess.check_output(['git',*v],cwd=r).decode();assert git('rev-parse','HEAD').strip()==b
old=p/'final-ui-only-carry-4ffe.json';d=json.loads(old.read_text());paths=git('diff','--name-only',a,b).splitlines();assert paths==['src/hud/touch/GameGUITouchHarness.cpp']
for n,q in d['roundtrip_inputs'].items():assert sha(r/n)==q['current']
for n,q in d['catalog_source_byte_proof'].items():assert sha(r/n)==q['current']
for n,q in d['matrix_input_proof'].items():assert sha(k/'final-kit3/drafts/fil'/n)==q['current']
x=k/'native-hud-final-focused-junit.xml';cases=E.parse(x).getroot().findall('.//testcase');failed=[t for t in cases if t.find('failure') is not None or t.find('error') is not None];assert len(cases)==45 and len(failed)==1
rec={'reviewer':'/root/meaning_reviewer','revision':b,'prior_ui_revision':a,'prior_carry_report':str(old.relative_to(k)),'prior_carry_sha256':sha(old),'two_stage_proof':'f0f→4ffe UI-only exact source/input carry, then4ffe→81e only two fixture corrections in one Harness; production code and original producer labels unchanged.','changed_paths':paths,'fixture_diff':git('diff',a,b),'source_sha256':d['source_sha256'],'catalog_sha256':d['catalog_sha256'],'roundtrip_inputs_checked_unchanged':len(d['roundtrip_inputs']),'matrix_inputs_checked_unchanged':d['matrix_input_proof'],'retained_evidence_sha256':d['retained_evidence_sha256'],'actual_full_suite':{'revision':a,'junit':str(x.relative_to(k)),'junit_sha256':sha(x),'unique_cases':len(cases),'passed':len(cases)-len(failed),'failed':len(failed),'failed_case':failed[0].get('name'),'failure_assertions':[n.get('message') for n in failed[0].findall('failure')],'receipt':'native-hud-final-results.json','receipt_sha256':sha(k/'native-hud-final-results.json')},'current_targeted_status':'pending; no passing claim until completed receipt and JUnit inspected','carry_limits':d['carry_limits']+['Full45case execution was4ffe,44passed/1failed. Targeted81e rerun will be reported separately; never raw45allpass at81e.']}
f=k/'native-fixture-final-results.json'
if f.exists():
 v=json.loads(f.read_text());rec['current_targeted_receipt']=v;rec['current_targeted_receipt_sha256']=sha(f)
 y=k/'native-fixture-final-focused-junit.xml';ys=E.parse(y).getroot().findall('.//testcase');rec['current_targeted_junit']={'sha256':sha(y),'cases':len(ys),'failed':sum(t.find('failure') is not None for t in ys),'errors':sum(t.find('error') is not None for t in ys),'error_messages':[t.find('error').text.splitlines()[-1] for t in ys if t.find('error') is not None]};rec['current_targeted_status']='NOT PASSED: all3 environment initialization errors before assertions; fresh display-backed rerun needed'
 (p/'final-fixture-only-carry-81e.json').write_text(json.dumps(rec,indent=2)+'\n')
else:(p/'final-fixture-only-carry-81e.json').write_text(json.dumps(rec,indent=2)+'\n')
print('PASS source/input carry; actual full45 retained44pass/1fail, current rerun pending inspection')
z=k/'native-fixture-x11-final-results.json'
if z.exists():
 v=json.loads(z.read_text());assert v['revision']==b and v['producer']['revision']==b and not v['producer']['dirty'] and v['commands'][0]['exit_code']==0
 y=k/'native-fixture-x11-final-focused-junit.xml';ys=E.parse(y).getroot().findall('.//testcase');assert len(ys)==3 and not any(t.find('failure') is not None or t.find('error') is not None for t in ys)
 def key(t):return(t.get('classname'),t.get('name'))
 full={key(t) for t in cases};fresh={key(t) for t in ys};assert fresh<=full and key(failed[0]) in fresh
 rec['resolved_targeted_rerun']={'receipt':str(z.relative_to(k)),'receipt_sha256':sha(z),'junit':str(y.relative_to(k)),'junit_sha256':sha(y),'revision':b,'passed':3,'failed':0,'errors':0,'producer':v['producer'],'executable_sha256':v['executable_sha256'],'environment':v['environment'],'case_ids':[list(key(t)) for t in ys]}
 rec['current_targeted_status']='PASS: fresh exact81e executable, explicitx11 isolateddisplay,3of3 pass; prior3environmenterrors preserved separately'
 rec['unique_validation_union']={'unique_cases':45,'original_4ffe_full_passed':44,'fresh_81e_passed':3,'fresh_already_passed_previously':2,'original_passes_carried_without_rerun':42,'fixed_failed_case_retested_pass':1,'unresolved_case_failures':0,'claim':'45distinct cases covered by42unaffected4ffe passes +3actual81e passes. Not45executed/passed at81e.'}
 rec['script_sha256']=sha(__file__)
 (p/'final-fixture-only-carry-81e.json').write_text(json.dumps(rec,indent=2)+'\n')
 print('PASS actual81e3/3; unique45 coverage =42carried4ffe+3fresh81e; old44/45 failure and3displayerrors retained')
