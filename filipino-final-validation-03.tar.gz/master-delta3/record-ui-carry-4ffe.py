from pathlib import Path
import json,hashlib,subprocess
r=Path.cwd();k=r/'artifacts/filipino-localization';out=k/'master-delta3';a='f0f003572e0c204f6d1c16063a9852cf3ade7bf1';b='4ffe6b1ec042c35cced022ddf496065118051ac5';m='6980c28a0f50543329c64eb32fe3e4d9d80244c7'
git=lambda *x:subprocess.check_output(['git',*x],cwd=r)
sha=lambda x:hashlib.sha256(x).hexdigest()
filehash=lambda p:sha(Path(p).read_bytes())
assert git('rev-parse','HEAD').decode().strip()==b
changed=git('diff','--name-only',a,b).decode().splitlines();assert len(changed)==8
report={'reviewer':'/root/meaning_reviewer','before':a,'after':b,'changed_paths':changed,'changed_path_sha256':{p:{'before':sha(git('show',a+':'+p)),'after':filehash(r/p)} for p in changed},'execution_scope':'Read-only hash and source review only; no new tests, builds, paid API requests or runtime execution by this report.'}
old=json.loads((k/'final-243-data-assets-report.json').read_text());report['source_sha256']=old['source_sha256'];report['catalog_sha256']=old['catalog_sha256']
source_paths=['data/texts.en.txt','data/texts.keys.txt','data/texts.fil.txt','platform/packages/i18n/locales/fil.json']
report['catalog_source_byte_proof']={p:{'f0f':sha(git('show',a+':'+p)),'current':filehash(r/p)} for p in source_paths};assert all(v['f0f']==v['current'] for v in report['catalog_source_byte_proof'].values())
rt=json.loads((k/'web-roundtrip-f0f-results.json').read_text());inputs=rt['input_sha256_after'];report['roundtrip_inputs']={str(Path(p).relative_to(r) if Path(p).is_absolute() else Path(p)):{'recorded_f0f':h,'current':filehash(p)} for p,h in inputs.items()};assert len(inputs)==54 and all(v['recorded_f0f']==v['current'] for v in report['roundtrip_inputs'].values())
scopes=['data','libgag','tools','test','platform','scons','SConstruct','src/game','src/net','src/online','src/replay','src/engine','src/app/Version.h','src/team','src/unit','src/building','src/map/Map.cpp']
report['unchanged_scoped_diff_paths']=git('diff','--name-only',a,b,'--',*scopes).decode().splitlines();assert not report['unchanged_scoped_diff_paths']
report['scoped_paths']=scopes
proof=json.loads((k/'rendering/native-final-6980-full-matrix/current-matrix-proof.json').read_text());report['matrix_input_proof']={p:{'recorded_6980':h,'current':filehash(k/'final-kit3/drafts/fil'/p)} for p,h in proof['input_sha256'].items()};assert all(v['recorded_6980']==v['current'] for v in report['matrix_input_proof'].values())
report['matrix_producer_to_current_changed_paths']=git('diff','--name-only',m,b).decode().splitlines()
report['matrix_scope']='Actual 6980 37,644 font-matrix samples retained as measurement evidence: consumed catalogs/metadata, all fonts and font implementation, preview harness, rendering primitives, and build settings unchanged. Changed HUD/PhoneEditor screen layout requires fresh screen validation; matrix is not a 4ffe execution or proof of those screens.'
records=['final-243-data-assets-report.json','web-roundtrip-f0f-results.json','mobile-243-audit.json','data-f0f-native-results.json','data-f0f-web-i18n-unit-results.json','rendering/native-final-6980-full-matrix/catalog-source-binding.json','rendering/native-final-6980-full-matrix/current-matrix-proof.json','visual/native-final-matrix-review-6980.json','master-delta3/author-review.json','master-delta3/meaning-review.json','master-delta3/editor-review.json','master-delta3/meaning-final-review.json','master-delta3/adversarial-review.json']
report['retained_evidence_sha256']={p:filehash(k/p) for p in records}
report['carry_limits']=['Actual 243/f0f native data, mobile exports, web roundtrip, platform checks and baseline-reproduced unit failures retain their original producer/revision labels. Only unaffected inputs are carried.','No Android/iOS device/emulator execution established.','Catalog four-role review values/source entries unchanged; no new whole-catalog review claimed.','Fresh parent-owned 4ffe native HUD/editor and browser execution is pending and is not certified here.']
report['hud_code_review']={'paths':['src/hud/touch/GameGUITouch.cpp','src/hud/touch/GameGUITouch.h','src/hud/touch/GameGUITouchView.cpp'],'findings':[],'major_findings':0,'assessment':'Read committed complete diff and surrounding layout/measurement code. Whole-word minima and wrapping use consistent text-growth units. Balanced columns divide six controls evenly; drawing, hit testing, and keyboard targets share rectangles. Cache hits probe six whole-caption metrics and skip repeated word wrapping. Parent-owned runtime checks remain necessary for fonts and pixels.'}
report['script_sha256']=filehash(__file__)
(out/'final-ui-only-carry-4ffe.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS: 8 changed paths, 54 roundtrip inputs equal, all catalog/source/matrix inputs equal; source review no major findings')
