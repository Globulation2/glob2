import importlib.util,json,hashlib,shutil
from pathlib import Path
spec=importlib.util.spec_from_file_location('program','tools/localization/translation_program.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
r=Path('artifacts/filipino-localization');m=json.loads((r/'manifest.json').read_text());path=r/'drafts/fil/fil.json';online=json.loads(path.read_text());before=online.copy();edits=json.loads((r/'editor/online-edits.json').read_text());assert not set(edits)-set(online),set(edits)-set(online);online.update(edits);path.write_text(json.dumps(online,ensure_ascii=False,indent=2)+'\n');hashes=p.batch_target_hashes(m,p.catalog_paths(r,'fil'));rp=r/'linguistic/language-editor-record.json';record=json.loads(rp.read_text());record['state']='Full editorial pass complete; independent final rechecks pending';record['online_catalog_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
for b in record['batches']:
 if b['id'].startswith('online-'):
  assert b['status'].startswith('read;'),b['id'];b['status']='editorial pass complete; final reviewer recheck pending';b['edited_keys']=b['expected_keys'];b['target_sha256']=hashes[b['id']]
rp.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');shutil.copyfile(path,r/'editor/online-editor.json')
f=json.loads((r/'linguistic/online-meaning-first-pass.json').read_text());res=[]
for x in f['findings']:
 k=x['key'].split(':',1)[1]; assert before[k]!=online[k],f"Finding not changed: {k}"
 res.append({**x,'state':'edited; independent recheck pending','final_target':online[k]})
(r/'editor/online-meaning-resolutions.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
previous=json.loads((r/'editor/online-editor-through-012.json').read_text());changed={k:{'before':previous[k],'after':online[k]} for k in online if previous[k]!=online[k]};(r/'editor/online-since-through012-delta.json').write_text(json.dumps(changed,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'catalog_sha256':record['online_catalog_sha256'],'online_editorial_keys':sum(len(b['edited_keys']) for b in record['batches'] if b['id'].startswith('online-')),'changed_entries':sum(before[k]!=v for k,v in online.items()),'meaning_findings_edited':len(res)}))
