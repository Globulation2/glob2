import importlib.util,json,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('program','tools/localization/translation_program.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
r=Path('artifacts/filipino-localization');m=json.loads((r/'manifest.json').read_text())
meta=next(b for b in m['batches'] if b['id']==sys.argv[1]); b=json.loads((r/meta['path']).read_text())
paths=p.catalog_paths(r,'fil'); native,_=p.CHECKER.read_table(paths['native']);online=json.loads(paths['online'].read_text()); target=native if b['surface']=='native' else online
snapshot={x['key']:target[x['key']] for x in b['entries']}
(r/'editor'/f"{b['id']}.read.json").write_text(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n')
print(b['id'])
for x in b['entries'][int(sys.argv[2]) if len(sys.argv)>2 else 0:int(sys.argv[3]) if len(sys.argv)>3 else len(b['entries'])]: print(json.dumps([x['key'],x['source'],target[x['key']]],ensure_ascii=False))
