from pathlib import Path
import json,hashlib,subprocess,importlib.util
from collections import Counter
B=Path('artifacts/filipino-localization'); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest(); load=lambda p:json.loads(p.read_text()); issues=[];inspected={}
def read(p):inspected[str(p)]=sha(p);return load(p)
s=importlib.util.spec_from_file_location('tp','tools/localization/translation_program.py');tp=importlib.util.module_from_spec(s);s.loader.exec_module(tp)
m=read(B/'manifest.json');o=read(B/'reviews/fil.json');pr=read(B/'reviews/fil-provenance.json');cf=read(B/'reviews/compact-labels-carry-forward.json')
paths={'native':Path('data/texts.fil.txt'),'online':Path('platform/packages/i18n/locales/fil.json')};cataloghash={k:sha(p) for k,p in paths.items()};_,en,on,sourcefiles,sourcehash=tp.sources();assert sourcehash==m['source_sha256']==o['source_sha256']==pr['source_sha256']==cf['source_sha256'];assert cataloghash==o['catalog_sha256']==pr['catalog_sha256']==cf['catalog_after_sha256']
for p in paths.values():inspected[str(p)]=sha(p)
for f in sourcefiles:inspected[f]=sha(Path(f))
expected={b['id']:set(b['keys']) for b in m['batches']};allkeys=set().union(*expected.values());assert len(expected)==43 and len(allkeys)==6229
hashes=tp.batch_target_hashes(m,paths)
for b in o['batches']:
 assert b['target_sha256']==hashes[b['id']]
 for field in ['reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys']:assert set(b[field])==expected[b['id']] and len(b[field])==len(expected[b['id']])
 assert len({b[k] for k in ['author','reviewer','editor','adversarial_reviewer']})==4
# Verify references on current official graph, but retain historical snapshots as historical.
refs=[];seen=set()
def walk(v,owner):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=Path(v['path']);p=p if p.is_absolute() or str(p).startswith(str(B)+'/') else B/p
   ok=p.is_file() and sha(p)==v['sha256'];refs.append({'owner':owner,'path':str(p),'sha256':v['sha256'],'valid':ok});issues.extend([] if ok else [refs[-1]])
   inspected[str(p)]=sha(p)
   historical=any(x in str(p) for x in ['before.json','before.txt','reference-refresh-before','final-language-audit22be.json','fil-provenance-before-adversary-reconcile.json'])
   if p.suffix=='.json' and not historical and str(p) not in seen:
    seen.add(str(p));walk(load(p),str(p))
  for k,x in v.items():
   if k not in ['path','sha256','old_parent_reference']:walk(x,owner)
 elif isinstance(v,list):
  for x in v:walk(x,owner)
walk(o,'reviews/fil.json');walk(pr,'reviews/fil-provenance.json');walk(cf,'reviews/compact-labels-carry-forward.json')
# Original role records enumerate complete actual readings.
coverage={}
for file,field in [('author/native-author-review.json','read_keys'),('author/online-author-review.json','read_keys')]:
 r=read(B/file);keys=r[field];want={k for k in allkeys if k.startswith('native:' if 'native-' in file else 'online:')};assert set(keys)==want and len(keys)==len(want);coverage[file]=len(keys)
for file,field in [('linguistic/native-meaning-first-pass.json','reviewed_keys'),('linguistic/online-meaning-first-pass.json','reviewed_keys'),('linguistic/native-meaning-final-recheck.json','rechecked_keys'),('linguistic/online-meaning-final-recheck.json','rechecked_keys'),('linguistic/language-editor-record.json','expected_keys'),('adversary/review.json','adversarial_reviewed_keys')]:
 r=read(B/file);n=0
 for b in r['batches']:
  values=b.get(field,b.get('reviewed_keys'));assert set(values)==expected[b['id']];n+=len(values)
 coverage[file]=n
# Validate each historical meaning-stage target batch against its immutable snapshot.
stage_bindings=[]
for file,surface,snapshot in [
 ('linguistic/native-meaning-first-pass.json','native','author/native-author.txt'),('linguistic/online-meaning-first-pass.json','online','author/online-author.json'),
 ('linguistic/native-meaning-editor-recheck.json','native','editor/native-editor.txt'),('linguistic/online-meaning-editor-recheck.json','online','editor/online-editor.json'),
 ('linguistic/native-meaning-final-recheck.json','native','editor/native-after-adversary.txt'),('linguistic/online-meaning-final-recheck.json','online','editor/online-final.json')]:
 r=read(B/file);sp=B/snapshot;inspected[str(sp)]=sha(sp);assert r[surface+'_catalog_sha256']==sha(sp)
 historicalpaths=dict(paths);historicalpaths[surface]=sp;hh=tp.batch_target_hashes(m,historicalpaths)
 for batch in r['batches']:assert batch['target_sha256']==hh[batch['id']],(file,batch['id'])
 stage_bindings.append({'record':file,'snapshot':snapshot,'sha256':sha(sp),'all_recorded_batch_hashes_match':True})
delta_proofs=[]
for file,surface,beforepath,afterpath in [('editor/native-adversarial-delta.json','native','editor/native-editor.txt','editor/native-after-adversary.txt'),('editor/online-adversarial-delta.json','online','editor/online-editor.json','editor/online-after-adversary.json'),('editor/online-final-delta.json','online','editor/online-after-adversary.json','editor/online-final.json')]:
 r=read(B/file);bp=B/beforepath;ap=B/afterpath;assert sha(bp)==r['before_sha256'] and sha(ap)==r['after_sha256']
 inspected[str(bp)]=sha(bp);inspected[str(ap)]=sha(ap)
 bv=tp.CHECKER.read_table(bp)[0] if surface=='native' else load(bp);av=tp.CHECKER.read_table(ap)[0] if surface=='native' else load(ap)
 changes={surface+':'+k for k in bv if av[k]!=bv[k]};assert changes=={x['key'] for x in r['changes']}
 for c in r['changes']:
  k=c['key'].split(':',1)[1];assert bv[k]==c['before'] and av[k]==c['after']
 delta_proofs.append({'record':file,'changed_count':len(changes),'unchanged_count':len(bv)-len(changes),'exact_changed_entries_verified':True})
native,err=tp.CHECKER.read_table(paths['native']);assert not err;online=load(paths['online']);before=read(B/'author/compact-labels/native-before.json');onlinebefore=read(B/'author/compact-labels/online-before.json');changed={k for k in native if native[k]!=before[k]};assert changed=={'[Rules]','[Editor tools]'};assert online==onlinebefore;assert len(native)-len(changed)==3391
assert paths['native'].read_bytes()==(B/'author/compact-labels/native-after.txt').read_bytes()
adv=read(B/'adversary/review.json');oldnative=tp.CHECKER.read_table(B/'editor/native-editor.txt')[0];totalchanged={'native:'+k for k in native if oldnative[k]!=native[k]};assert len(totalchanged)==17 and totalchanged==set(adv['native_delta_rechecked_keys'])
for batch in adv['batches']:
 if batch['id'].startswith('native-'):
  assert batch['target_sha256']==hashes[batch['id']]
  assert batch['final_snapshot_sha256']==cataloghash['native']
  assert sha(B/batch['final_snapshot_path'])==cataloghash['native']
for key in ['native_before_snapshot','native_after_snapshot']:assert cf[key]['sha256']==sha(B/cf[key]['path'])
assert set(cf['unchanged_native_keys'])=={'native:'+k for k in native if k not in changed};assert set(cf['unchanged_online_keys'])=={'online:'+k for k in online}
for e in o['accepted_english']:
 surf,key=e['key'].split(':',1);table=native if surf=='native' else online;orig=en if surf=='native' else on
 if key in table:value=table[key];sourcevalue=orig[key]
 else:key,category=key.rsplit('/',1);value=table[key][category];sourcevalue=orig[key][category]
 assert e['reason'].strip();assert hashlib.sha256(value.encode()).hexdigest()==e['value_sha256'];assert value==sourcevalue
assert len(o['accepted_english'])==265
assert cf['intentional_loan_rationales']['native:[Editor tools]']['language_editor'].strip()
assert not o['language_brief'].get('unresolved_uncertainty');assert all(f['state']=='resolved' or (f['severity']=='minor' and f['state']=='accepted') for f in o['findings'])
# Attempt ledger reservations and independently saved successful API responses.
ledger=B/'google/fil/attempts.jsonl';inspected[str(ledger)]=sha(ledger);attempts=[json.loads(l) for l in ledger.read_text().splitlines()];assert len(attempts)==60 and len({x['id'] for x in attempts})==60
chars=sum(x['characters'] for x in attempts);assert chars==231771
responses=[]
for a in attempts:
 p=B/'google/fil/responses'/f"{a['id']}.json";r=read(p);assert len(r['translations'])==len(a['contents_sha256']);responses.append(str(p))
summary=read(B/'google/fil/summary.json');assert summary['attempted_characters_including_failures']==chars;assert abs(summary['estimated_usd_before_credits']-chars*20/1e6)<1e-9
pending=tp.audit_review(m,o,paths,B);want={'desktop_rendering is pending or lacks evidence','phone_rendering is pending or lacks evidence','browser_startup is pending or lacks evidence','browser_platforms is pending or lacks evidence'}
assert set(pending)==want,pending
result={'identity':'/root/language_editor','revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tracked_worktree_clean':not bool(subprocess.check_output(['git','status','--porcelain'],text=True)),'status':'passed with four pending gates' if not issues else 'reference mismatch found; final approval pending reconciliation','reference_issues':issues,'scope':'Read-only integrity/coverage/provenance audit of existing actual reviews and delta proofs. No fresh full-translation reading or new visual approval claimed. No gate or official review mutation.','source_sha256':sourcehash,'catalog_sha256':cataloghash,'batches':43,'entry_ids':6229,'role_coverage':coverage,'historical_stage_snapshot_bindings':stage_bindings,'historical_delta_proofs':delta_proofs,'current_child_references_verified':len(refs),'references':refs,'carry_forward':{'native_unchanged':3391,'online_unchanged':2836,'direct_final_reread_keys':['native:[Editor tools]','native:[Rules]'],'actual_applied_values':{k:native[k] for k in changed},'affected_batch_hash':hashes['native-general-007']},'intentional_english':{'count':265,'native':sum(x['key'].startswith('native:') for x in o['accepted_english']),'online':sum(x['key'].startswith('online:') for x in o['accepted_english']),'all_values_and_rationales_match':True,'additional_tool_loan_rationale_verified':True},'unresolved_linguistic_findings':0,'google':{'attempted_requests':len(attempts),'successful_response_receipts':len(responses),'attempted_characters':chars,'estimated_usd_before_credits':summary['estimated_usd_before_credits'],'not_an_invoice':True},'pending_gates':pending,'inspected_files_sha256':inspected,'adversary_aggregate_verified':{'native_batch_bindings':25,'changed_entry_reread_ids':17,'unchanged_native_values':3376,'current_frozen_aggregate_sha256':sha(B/'adversary/review.json')},'reference_reconciliation':read(B/'reviews/adversary-aggregate-reference-reconciliation.json'),'historical_reference_policy':'Verified frozen before-fix audit and old-parent snapshot bytes as historical leaves; unavailable e398 old aggregate bytes explicitly documented rather than reconstructed. old_parent_reference is a historical mismatch descriptor, not a current child reference.','limitations':['Review receipts and exact snapshot equality establish retained prior signoffs, not a new reading of every Filipino sentence.','Cost is conservative ledger estimate before credits; cloud billing invoice was not checked.','Pending browser execution/startup and final rendering gates remain explicit.']}
(B/'reviews/final-language-audit22be-clean.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(result['status'],len(refs),'refs',len(inspected),'files')
