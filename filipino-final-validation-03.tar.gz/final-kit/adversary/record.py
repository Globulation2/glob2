import json,sys,hashlib,os
from pathlib import Path
r=Path('artifacts/filipino-localization');m=json.loads((r/'manifest.json').read_text());path=r/'adversary/review.json'
a=json.loads(path.read_text()) if path.exists() else {'identity':'/root/adversarial_reviewer','locale':'fil','source_sha256':m['source_sha256'],'state':'in progress','batches':[],'findings':[]}
for b in m['batches']:
 if b['id'] not in sys.argv[1:]:continue
 native=b['id'].startswith('native');p=r/('editor/native-editor.txt' if native else os.environ.get('SNAPSHOT','editor/online-editor.json'))
 row={'id':b['id'],'adversarial_reviewer':a['identity'],'adversarial_reviewed_keys':b['keys'],'snapshot_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'snapshot_path':str(p.relative_to(r))}
 a['batches']=[x for x in a['batches'] if x['id']!=b['id']]+[row]
path.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
print(len(a['batches']),sum(len(x['adversarial_reviewed_keys']) for x in a['batches']))
