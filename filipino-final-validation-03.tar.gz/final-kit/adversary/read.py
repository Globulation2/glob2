import sys,json,hashlib,importlib.util,os
from pathlib import Path
r=Path('artifacts/filipino-localization');sp=importlib.util.spec_from_file_location('p','tools/localization/translation_program.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p)
m=json.loads((r/'manifest.json').read_text());kind=sys.argv[1];ids=sys.argv[2:];source=json.loads((r/f'source/{kind}.json').read_text());target=p.CHECKER.read_table(r/'editor/native-editor.txt')[0] if kind=='native' else json.loads((r/os.environ.get('SNAPSHOT','editor/online-editor.json')).read_text())
for b in m['batches']:
 if b['id'] not in ids:continue
 print('BATCH',b['id'])
 for i in b['keys'][int(os.environ.get('START','0')):int(os.environ.get('END','10000'))]:
  k=i.split(':',1)[1];s=source[k];t=target[k]
  print(k+((' E:'+s) if kind=='native' and s!=k[1:-1] else '')+' ⇒ '+(json.dumps(t,ensure_ascii=False) if isinstance(t,dict) else t))
