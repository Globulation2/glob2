import json,pathlib,importlib.util,sys
root=pathlib.Path('artifacts/filipino-localization')
s=importlib.util.spec_from_file_location('p','tools/localization/translation_program.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
a,e=m.CHECKER.read_table(root/'editor/native-editor.txt');n=json.loads((root/'source/native.json').read_text());man=json.loads((root/'manifest.json').read_text())
for b in man['batches']:
 if b['id'] not in sys.argv[1:]:continue
 print('BATCH',b['id'])
 for id in b['keys']:
  k=id.split(':',1)[1]
  if '-Profile]' in k:continue
  print(k+' ⇒ '+a[k])
