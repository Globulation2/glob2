from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[4];K=ROOT/'artifacts/filipino-localization';F=K/'final-kit2';B=K/'final-kit';sys.path.insert(0,str(ROOT/'tools/localization'));import translation_program as P
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=lambda v:hashlib.sha256(v.encode()).hexdigest();issues=[];checks=[]
def check(ok,label):checks.append({'check':label,'passed':bool(ok)});issues.extend([] if ok else [label])
m=read(F/'manifest.json');r=read(F/'reviews/fil.json');prov=read(F/'reviews/fil-provenance.json');proof=read(F/'master-delta2/source-target-carry.json');oldsrc=read(B/'source/native.json');oldonline=read(B/'source/online.json');oldtarget=read(B/'drafts/fil/native.json');oldonlinetarget=read(B/'drafts/fil/online.json');newsrc=read(F/'source/native.json');newonline=read(F/'source/online.json');newtarget=read(F/'drafts/fil/native.json');newonlinetarget=read(F/'drafts/fil/online.json');final=read(F/'master-delta2/final.json');authorfinal=read(F/'master-delta2/author-final.json');newkeys=set(final)
check(len(oldsrc)==3395 and len(oldonline)==2836,'Original6231entry inventory')
check(set(newsrc)-set(oldsrc)==newkeys and len(newkeys)==12 and newkeys==set(read(F/'master-delta2/source.json')['entries']) and not(set(oldsrc)-set(newsrc)),'Only12new source IDs')
check(all(newsrc[k]==v for k,v in oldsrc.items()) and newonline==oldonline,'All6231original English sources exactly unchanged')
check(all(newtarget[k]==v for k,v in oldtarget.items()) and set(newtarget)==set(oldtarget)|newkeys and newonlinetarget==oldonlinetarget,'All6231original target values exactly unchanged')
check(all(newtarget[k]==v for k,v in final.items()),'All12new final values match actual independent review snapshot')
check(set(proof['unchanged_native_ids'])=={'native:'+k for k in oldsrc} and len(proof['unchanged_native_ids'])==3395 and set(proof['unchanged_online_ids'])=={'online:'+k for k in oldonline} and len(proof['unchanged_online_ids'])==2836,'Carry proof IDs exact and unique')
keys,ns,os,files,source=P.sources(ROOT);paths=P.catalog_paths(F,'fil');catalog={s:sha(p) for s,p in paths.items()}
check(source==m['source_sha256']==r['source_sha256']==prov['source_sha256']==proof['source_after_sha256']=='208de00441b88964cabf364936c7672f696bea676f046da8c537c69843846de4','Current source contract hash exact')
check(catalog==r['catalog_sha256']==prov['catalog_sha256']==proof['catalog_after_sha256'] and catalog['native']=='75fbe6a62c644bb064de38eb2eb07704f46501a7dcd3812f45ce5c0e81e6e17a' and catalog['online']=='99ed554f753390682d437318e20ed9d7ddbd54fbe2c798df41b42d4fb3fb2446','Final catalog file hashes exact')
check(ns==newsrc and os==newonline and files==m['source_files'],'Final snapshot matches installed source contracts')
check(sha(ROOT/'data/texts.fil.txt')==catalog['native'],'Installed native catalog matches final snapshot')
oldm=read(B/'manifest.json');check(all(files[n]==oldm['source_files'][n] for n in P.SOURCE_PATHS if n not in ['data/texts.en.txt','data/texts.keys.txt']),'Online plural/invariant/source contracts unchanged')
expected={b['id']:set(b['keys']) for b in m['batches']};check(len(expected)==len(m['batches'])==len(r['batches'])==45,'Exactly45source/review batches')
flat=[k for b in m['batches'] for k in b['keys']];allids={'native:'+k for k in newsrc}|{'online:'+k for k in newonline};check(len(flat)==len(set(flat))==6243 and set(flat)==allids,'All6243IDs covered exactly once')
th=P.batch_target_hashes(m,paths)
for b in r['batches']:
 bid=b['id'];check(b['target_sha256']==th[bid] and b['source_sha256']==source,bid+': exact new envelope hash')
 people=[b[x] for x in ['author','reviewer','editor','adversarial_reviewer']];check(len(set(people))==4,bid+': four distinct identities')
 for field in ['reviewed_keys','edited_keys','rechecked_keys','adversarial_reviewed_keys']:check(len(b[field])==len(set(b[field])) and set(b[field])==expected[bid],bid+': '+field+' coverage')
 check(b['rechecked_by']==b['reviewer'],bid+': meaning reviewer final recheck')
# Full audit checks expected pending gates but cannot approve them.
audit=P.audit_locale(F,m,r,'fil');pending=[g+' is pending or lacks evidence' for g in P.GATES];check(sorted(audit)==sorted(pending),'Tool audit has exactly9 intentionally pending gates and no linguistic/schema issues')
checked=P.check_draft(F,'fil');accepted=r['accepted_english'];check(len(accepted)==265 and {x['key'] for x in accepted}==set(checked['same_as_english_review_queue']),'All265English matches have exact individual exceptions')
check(accepted==read(B/'reviews/fil.json')['accepted_english'],'265English exception records unchanged from verified historical aggregate')
reviewers={'author-review.json':'/root/draft_editor','meaning-review.json':'/root/meaning_reviewer','editor-review.json':'/root/language_editor','meaning-final-review.json':'/root/meaning_reviewer','adversarial-review.json':'/root/adversarial_reviewer'};direct=[]
for name,identity in reviewers.items():
 path=F/'master-delta2'/name;v=read(path);stage=authorfinal if name in ['author-review.json','meaning-review.json'] else final
 check(v.get('identity',v.get('reviewer'))==identity,name+': actual identity');rows={e['id']:e for e in v['entries']};check(set(rows)=={'native:'+k for k in stage} and len(v['entries'])==12,name+': exact12IDs')
 for key,value in stage.items():
  e=rows['native:'+key];sv=e.get('source_value_sha256',e.get('source_sha256'));tv=e.get('final_value_sha256',e.get('target_value_sha256',e.get('target_sha256')));text=e.get('author_final',e.get('final_value',e.get('final_target',e.get('final',e.get('target')))))
  check(e['source']==newsrc[key] and sv==h(newsrc[key]) and tv==h(value) and text==value,name+': actual stage source/target hash '+key)
  if name!='author-review.json':check('approved' in e.get('status',''),name+': actual approval '+key)
 direct.append({'path':str(path.relative_to(F)),'sha256':sha(path),'identity':identity,'stage':'author-b6' if stage is authorfinal else 'editor-final9e'})
check(sha(F/'master-delta2/author-final.json')=='b6f2f6be85fe4efc4a56f65fc5804030cb71e65b4f23532654fc2f5a528d684e' and sha(F/'master-delta2/final.json')=='9e548a1b65db67322be03cc08139cfc5ed0010468ab51dc384f2f34e0e9b41a8','Exact author and edited final stage snapshots')
changes={k:(authorfinal[k],final[k]) for k in final if authorfinal[k]!=final[k]}
check(set(changes)=={'[stats waiting]','[stats missing readings]'} and all(after==before.replace('estadistika','istatistika') for before,after in changes.values()),'Exactly2new spelling edits,10newtargets unchanged')
editor=read(F/'master-delta2/editor-review.json');check(editor['editorial_delta']['changed_count']==2 and editor['editorial_delta']['unchanged_count']==10,'Editor receipt declares exact2/10split')
for e in editor['editorial_delta']['changes']:
 key=e['id'].split(':',1)[1];check(e['before']==authorfinal[key] and e['after']==final[key] and e['before_value_sha256']==h(authorfinal[key]) and e['after_value_sha256']==h(final[key]),'Actual edited delta hash '+key)
meaning=read(F/'master-delta2/meaning-final-review.json');check(meaning['prior_meaning_record_sha256']==sha(F/'master-delta2/meaning-review.json') and meaning['editor_record_sha256']==sha(F/'master-delta2/editor-review.json') and meaning['final_snapshot_sha256']==sha(F/'master-delta2/final.json'),'Final meaning binds first meaning,editor,andfinal snapshot')
author=read(F/'master-delta2/author-review.json');firstmeaning=read(F/'master-delta2/meaning-review.json');adversary=read(F/'master-delta2/adversarial-review.json')
check(author['output']['sha256']==sha(F/'master-delta2/author-final.json'),'Historical author output hash binds preservedb6author-stage snapshot,not mutablefinalpath')
check(firstmeaning['final_snapshot_sha256']==sha(F/'master-delta2/author-final.json'),'First meaning snapshot binds preservedb6author-stage')
check(editor['author_final_snapshot']['sha256']==sha(F/'master-delta2/author-final.json') and editor['final_snapshot']['sha256']==sha(F/'master-delta2/final.json'),'Editor explicitly linksb6before and9eafter snapshots')
check(adversary['final_file_sha256']==sha(F/'master-delta2/final.json'),'Adversary actual finalfile snapshot binds9e')
check(all(read(F/'master-delta2'/n).get('source_file_sha256',read(F/'master-delta2'/n).get('input_evidence',{}).get('source.json'))==sha(F/'master-delta2/source.json') for n in reviewers),'All5direct stages bind exact12entryEnglish sourcefile')
refs=[]
def walk(v,where):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=Path(v['path']);p=p if p.is_absolute() else F/p;ok=p.is_file() and sha(p)==v['sha256'];refs.append({'at':where,'path':v['path'],'sha256':v['sha256'],'passed':ok});check(ok,where+': referenced evidence SHA')
  for k,x in v.items():walk(x,where+'.'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):walk(x,where+'['+str(i)+']')
walk(prov,'provenance');walk(proof,'source-target-carry');walk(r['language_brief'],'language-brief');walk(r['provenance'],'current-review-provenance')
for b in r['batches']:walk(b.get('provenance',{}),'batch:'+b['id'])
check(len(prov['role_evidence'])==25 and all(x in prov['role_evidence'] for x in [{'path':e['path'],'sha256':e['sha256']} for e in direct]),'Current provenance includes all5new direct role receipts plus20historical records')
check(all(g['passed'] is False for g in r['gates'].values()),'All gate objects intentionally pending; no release approval inferred')
ancestor=subprocess.run(['git','merge-base','--is-ancestor','0d54ef3a99384059e68e78f03f774e062031a3ca','HEAD']).returncode==0;check(ancestor,'Actual master0d54 ancestor of current checkout')
check(subprocess.run(['git','merge-base','--is-ancestor','b9b1a4b7e1cc32956204cde5439af5398bcfc5d2','HEAD']).returncode==0,'Actual masterb9 ancestor of current checkout')
check(subprocess.run(['git','merge-base','--is-ancestor',m['revision'],'HEAD']).returncode==0,'Source envelope revision actual ancestor of current checkout')
post_envelope_paths=subprocess.check_output(['git','diff','--name-only',m['revision'],'HEAD'],text=True).splitlines()
check(set(post_envelope_paths)<={'data/texts.incomplete.txt','data/texts.nb.txt'},'Post-envelope changes restricted to Norwegian blank-key/completeness metadata; English andFil contracts already verified exact')
result={'identity':'/root/adversarial_reviewer','status':'pass; aggregate linguistic provenance/schema only, release gates intentionally pending' if not issues else 'issues found','issues':issues,'checks':checks,'snapshot_evidence':[{'path':str(p.relative_to(F)),'sha256':sha(p)} for p in [F/'manifest.json',F/'reviews/fil.json',F/'reviews/fil-provenance.json',F/'master-delta2/source-target-carry.json']],'source_sha256':source,'catalog_sha256':catalog,'total_ids':6243,'unchanged_original_ids':6231,'new_directly_reviewed_ids':12,'batch_count':45,'english_exception_count':265,'role_evidence_count':len(prov['role_evidence']),'direct_new_reviews':direct,'evidence_reference_checks':refs,'expected_pending_gates':list(P.GATES),'post_envelope_changed_paths':post_envelope_paths,'actual_checkout_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tracked_status':subprocess.check_output(['git','status','--porcelain'],text=True).splitlines(),'historical_envelopes':'Original role receipts retain old source/catalog hashes and their actual full reads. Current45batch envelopes carry exact6231previous source/target values;12newIDs have staged direct reads. Author+firstmeaning bindb6author-stage, editor+finalmeaning+adversary bind9efinal-stage with2actualspelling edits and10unchanged. No oldfullread relabeled and no fresh6243entry read claimed.','limits':['Audit compares snapshots, coverage, hashes and role records; does not redo linguistic reading of previous6231entries.','Nine pending gates are expected and remain untouched. Native/browser/platform rendering and integration evidence are separately scoped by root.']}
P.write_json(F/'master-delta2/independent-aggregate-audit.json',result);print(json.dumps({'status':result['status'],'issues':issues,'checks':len(checks),'reference_checks':len(refs)}))
