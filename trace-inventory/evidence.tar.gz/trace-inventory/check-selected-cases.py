from pathlib import Path
import subprocess,json,shlex
root=Path.cwd();b=root/'artifacts/ci-recovery/trace-inventory';old=json.loads(subprocess.check_output(['git','show','43b153739838207983c922ab4cbeed7773459de9:.github/scripts/ci_browser_matrix.json'],text=True));new=json.loads(Path('/home/bradley/.codex/worktrees/ci-trace-inventory/glob2/.github/scripts/ci_browser_matrix.json').read_text());node='/home/bradley/.local/share/glob2/development/toolchains/emscripten/Linux-x86_64-88a621bc131cd4954413aa39/node/24.19.0_64bit/bin/node';results=[]
def titles(suites):
 out=[]
 for suite in suites:
  out.extend(titles(suite.get('suites',[])))
  out.extend(s['title'] for s in suite.get('specs',[]))
 return out
for browser in ('firefox','webkit'):
 rows=[]
 for label,matrix in [('before',old),('after',new)]:
  row=next(r for r in matrix if r['name']==f'{browser} WSS and simulation');argv=shlex.split(row['command']);argv=argv[argv.index('playwright')+1:];command=[node,str(root/'browser/node_modules/@playwright/test/cli.js'),*argv,'--list','--reporter=json'];raw=subprocess.check_output(command,cwd=root/'browser',text=True);(b/f'{browser}-selected-{label}.json').write_text(raw);rows.append(set(titles(json.loads(raw)['suites'])))
 before,after=rows;assert before<=after;added=after-before;assert len(added)==8,(browser,added);assert all('runtime catalog' in t for t in added);results.append({'browser':browser,'before':len(before),'after':len(after),'removed':[],'added':sorted(added)})
(b/'selected-case-comparison.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
