from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer
import importlib.util,threading,subprocess,os,json,sys
root=Path.cwd();out=root/'artifacts/ci-recovery/trace-inventory/catalog-producers';out.mkdir(parents=True,exist_ok=True);source=root/'build/ci-recovery-web'
spec=importlib.util.spec_from_file_location('serve',root/'browser/serve.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
http_log=(out/'http.log').open('a')
class Handler(module.Handler):
 def log_message(self,format,*args):http_log.write((format%args)+'\n');http_log.flush()
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(source)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
node='/home/bradley/.local/share/glob2/development/toolchains/emscripten/Linux-x86_64-88a621bc131cd4954413aa39/node/24.19.0_64bit/bin/node';env=dict(os.environ,GLOB2_TEST_URL=f'http://127.0.0.1:{server.server_port}',GLOB2_TEST_RENDERER='webgl2',CI='1',LIBGL_ALWAYS_SOFTWARE='1',GLOB2_TEST_BUILD_DIR=str(source),GLOB2_FIREFOX_HEADED='1');env.pop('DISPLAY',None)
command=['xvfb-run','-a',node,str(root/'browser/node_modules/@playwright/test/cli.js'),'test','tests/determinism.spec.js','--project=firefox','--project=webkit','--grep=runtime catalog','--workers=1','--trace=off','--output='+str(out/'playwright-results')]
try:
 with (out/'playwright.log').open('w') as log:result=subprocess.run(command,cwd=root/'browser',env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/'playwright-result.json').write_text(json.dumps({'command':command,'exitCode':result.returncode,'artifactSource':'43b153739838207983c922ab4cbeed7773459de9','addedFile':None},indent=2)+'\n');print('Playwright exit',result.returncode)
finally:server.shutdown();server.server_close();thread.join();http_log.close()
sys.exit(result.returncode)
