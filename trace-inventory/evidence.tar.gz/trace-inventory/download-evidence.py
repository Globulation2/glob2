from pathlib import Path
import json,subprocess,zipfile,io
base=Path('artifacts/ci-recovery/trace-inventory');pages=json.loads(subprocess.check_output(['gh','api','--paginate','--slurp','repos/Globulation2/glob2/actions/runs/38916805749/artifacts?per_page=100'],text=True));listing=[a for page in pages for a in page['artifacts']];rows=[]
for a in listing:
 family='ci-traces' if a['name'].startswith('browser-determinism-') else 'ci-scripting' if a['name'].startswith('javascript-profile-') else None
 if family:
  raw=subprocess.check_output(['gh','api',f"repos/Globulation2/glob2/actions/artifacts/{a['id']}/zip"])
  out=base/family/a['name'];out.mkdir(parents=True,exist_ok=True)
  with zipfile.ZipFile(io.BytesIO(raw)) as z:z.extractall(out)
  rows.append({'id':a['id'],'name':a['name'],'archiveBytes':len(raw)})
(base/'artifact-inventory.json').write_text(json.dumps(rows,indent=2)+'\n');print('Downloaded',len(rows),'artifacts')
