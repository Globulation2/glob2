const {chromium}=require('../../../browser/node_modules/@playwright/test');
const fs=require('node:fs/promises');
(async()=>{const browser=await chromium.launch({args:['--use-angle=metal']});
try{for(const [pass,names] of [[1,['scalar','wasm','sse2']],[2,['sse2','wasm','scalar']]]){
 for(const name of names){const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.goto('http://127.0.0.1:8785/gradient-micro/driver.html?variant='+name);
 await page.waitForFunction(()=>window.result||window.failure,null,{timeout:180000});
 const data=await page.evaluate(()=>({result:window.result,failure:window.failure}));
 if(data.failure||errors.length)throw new Error(JSON.stringify({data,errors}));
 await fs.writeFile('artifacts/browser-performance/gradient-micro/'+name+'-'+pass+'.json',JSON.stringify({browser:browser.version(),...data.result},null,2));
 console.log(name,pass,data.result.verified_cases,data.result.digest);await page.close();
 }
}}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1});
