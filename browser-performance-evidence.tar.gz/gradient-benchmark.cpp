// Local review evidence: real production kernels, independent heap oracle.
#include "src/map/gradient/kernel/GradientPropagation.h"
#include <chrono>
#include <cstdio>
#include <queue>
#include <cstdlib>
#include <functional>
using Field=std::vector<std::uint16_t>;
struct Case {int w,h,c,cap;Field seeds;std::vector<unsigned char> water;};
Case makeCase(int w,int h,int c,int cap,unsigned seed,int obstacles) {
 Case a{w,h,c,cap,Field(w*h,1),std::vector<unsigned char>(w*h)};
 auto random=[&]{seed=1664525u*seed+1013904223u;return seed;};
 for(int i=0;i<w*h;i++){a.water[i]=(random()>>16)%100<25;if((random()>>16)%100<unsigned(obstacles)||(c==0&&a.water[i]))a.seeds[i]=0;}
 for(int i=0;i<8;i++){int cell=(random()>>8)%(w*h);a.seeds[cell]=65535-(i%3)*71;a.water[cell]=0;}
 a.seeds[0]=65535;a.water[0]=0;return a;
}
Field oracle(const Case& a) {
 const int inf=100000000;std::vector<int>d(a.w*a.h,inf);
 using P=std::pair<int,int>;std::priority_queue<P,std::vector<P>,std::greater<P>>q;
 for(int i=0;i<a.w*a.h;i++)if(a.seeds[i]>1){d[i]=65535-a.seeds[i];q.push({d[i],i});}
 const int waterCosts[]={0,5,7,10,13,20,30};
 while(!q.empty()){auto [cost,i]=q.top();q.pop();if(cost!=d[i])continue;
  int step=a.water[i]?waterCosts[a.c]:10;
  for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){if(!x&&!y)continue;
   int n=((i/a.w+y+a.h)%a.h)*a.w+(i%a.w+x+a.w)%a.w;
   int next=cost+((x&&y)?step*14/10:step);
   if(a.seeds[n]&&next<=std::min(a.cap,gradient_kernel::COST_LIMIT)&&next<d[n]){d[n]=next;q.push({next,n});}
  }
 }
 Field g=a.seeds;for(int i=0;i<a.w*a.h;i++)if(a.seeds[i]&&d[i]!=inf)g[i]=65535-d[i];return g;
}
void run(const Case&a,Field&g,GradientWorkspace&work) {
 g=a.seeds;int shift=0;while((1<<shift)<a.w)shift++;
 gradient_kernel::propagateField(g.data(),a.c,a.cap,{g.size(),a.w-1,a.h-1,shift},work,[&](size_t i){return a.water[i]!=0;});
}
unsigned digest(const Field&g){unsigned h=2166136261u;for(auto x:g){h^=x;h*=16777619u;}return h;}
int main(){
 unsigned hash=2166136261u;unsigned cases=0;
 for(int w:{2,4,16,64})for(int h:{2,16,64})for(int c=0;c<7;c++)for(int cap:{0,31,300,65491})for(unsigned seed=1;seed<=3;seed++){
  auto a=makeCase(w,h,c,cap,seed,20);auto expected=oracle(a);Field g;GradientWorkspace work;run(a,g,work);
  if(g!=expected){std::fprintf(stderr,"oracle mismatch %d %d %d %d %u\n",w,h,c,cap,seed);return 1;}
  hash^=digest(g);hash*=16777619u;cases++;
 }
 std::printf("{\"verified_cases\":%u,\"digest\":%u,\"measurements\":[",cases,hash);
 bool first=true;
 for(int w:{64,256,512})for(int c:{0,3,6}){
  auto a=makeCase(w,w,c,65491,42,15);Field g;GradientWorkspace work;run(a,g,work);
  int count=w==512?12:40;
  for(int sample=0;sample<5;sample++){
   auto start=std::chrono::steady_clock::now();for(int n=0;n<count;n++)run(a,g,work);
   double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()/count;
   std::printf("%s{\"width\":%d,\"swim_class\":%d,\"sample\":%d,\"ms_per_field\":%.6f,\"digest\":%u}",first?"":",",w,c,sample,ms,digest(g));first=false;
  }
 }
 std::puts("]}");return 0;
}
