from pathlib import Path
import json,hashlib,time,subprocess
R=Path.cwd();K=R/'artifacts/filipino-localization';import argparse;p=argparse.ArgumentParser();p.add_argument('--revision',required=True);A=p.parse_args();head=A.revision;assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head;cache={};assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
def sha(path):
 path=str(path)
 if path not in cache:cache[path]=hashlib.sha256(Path(path).read_bytes()).hexdigest()
 return cache[path]
texts={p.as_posix() for p in Path('data').glob('texts.*.txt')};excluded={p.as_posix() for p in Path('data/fonts').rglob('*') if p.is_file() and (p.suffix=='.py' or p.name in ['SConscript','script-probes.json'])};fonts={p.as_posix() for p in Path('data/fonts').rglob('*') if p.is_file()}-excluded
assert not (K/'mobile-te-final/audit.json').exists();result={'final_revision':head,'platforms':[],'scope':'New runtime asset exports with current added terrain artwork. Hash audit only; no native mobile binaries or device execution.'}
for platform in ['android','ios']:
 folder=K/('mobile-te-final/'+platform+'-assets');mp=folder.with_suffix('.json');deadline=time.monotonic()+7200
 while not folder.exists() or not mp.exists():
  assert time.monotonic()<deadline,'export unavailable after bounded wait';time.sleep(5)
 manifest=json.loads(mp.read_text());by_source={x['source']:x for x in manifest['files']};assert texts<=by_source.keys();assert fonts<=by_source.keys();bad=[];rows=[];generated=[]
 for entry in manifest['files']:
  outputsha=sha(folder/entry['output']);source=entry['source']
  if Path(source).exists():source_matches=sha(source)==entry['source_sha256']
  elif entry.get('packed_from'):
   source_matches=all(sha(f['source'])==f['sha256'] for f in entry['packed_from']);generated.append({'source':source,'packed_frames':len(entry['packed_from']),'all_frame_hashes_match':source_matches})
  else:
   source_matches=source.endswith('.sheet') and outputsha==entry['source_sha256'];generated.append({'source':source,'generated_index_hash_matches':source_matches})
  if not source_matches or outputsha!=entry['output_sha256']:bad.append({'source':source,'source_matches':source_matches,'output_matches':outputsha==entry['output_sha256']})
  if source in texts|fonts:rows.append({'source':source,'output':entry['output'],'actual_source_sha256':sha(source),'manifest_source_sha256':entry['source_sha256'],'actual_output_sha256':outputsha,'manifest_output_sha256':entry['output_sha256']})
 row={'platform':platform,'manifest':mp.name,'manifest_sha256':sha(mp),'export_file_count':len(manifest['files']),'source_bytes':manifest['source_bytes'],'output_bytes':manifest['output_bytes'],'all_direct_sources_and_packed_frames_match_final':not bad,'all_output_hashes_match_manifest':not bad,'text_file_count':len(texts),'font_license_metadata_count':len(fonts),'text_paths':sorted(texts),'font_paths':sorted(fonts),'excluded_development_font_inputs':sorted(excluded),'coverage_rows':rows,'generated_inputs_checked_without_reencoding':generated,'bad':bad,'image_recipe':manifest['image_recipe']};result['platforms'].append(row);(K/'mobile-te-final/audit.json').write_text(json.dumps(result,indent=2)+'\n');print(platform,'files',row['export_file_count'],'bad',len(bad),flush=True);assert not bad,bad[:5]
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head;assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
result['revision_at_finish']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();result['audit_script_sha256']=sha(__file__);(K/'mobile-te-final/audit.json').write_text(json.dumps(result,indent=2)+'\n')
