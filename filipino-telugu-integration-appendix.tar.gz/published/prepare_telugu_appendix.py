#!/usr/bin/env python3
"""Bounded artifact-only integration appendix; freeze only after actual gate closure."""
from pathlib import Path
import argparse,hashlib,json,subprocess,tarfile,re,base64,io,os
P=Path(__file__).resolve().parent;K=P.parent;R=K.parents[1]
FINAL='d588e65df050f039a4ad306652425bb30d0cce6b'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--freeze',action='store_true');a=ap.parse_args()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==FINAL
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
 baseline=subprocess.check_output(['git','rev-parse','47afe'],cwd=R,text=True).strip()
 roots=['integration-telugu','compatibility-fil114','final-web-te','mobile-te-final','rendering/native-final-v9-screens','browser-v4/telugu-appendix-d588e65d-c1d2f1bae1cf','native-v6-focused-builder/producer-827a22d2a865','browser-matchverify/attempt-d588e65d-1d098e291487','browser-v4/unit-telugu-A-827a22d2']
 omitted=[];selected={}
 allowed={'.json','.jsonl','.log','.txt','.xml','.py','.cpp','.h','.diff','.png','.replay','.bmp'}
 excluded_dirs={'android-assets','ios-assets','static-release','profile','traces','node_modules','__pycache__','build','baseline-telugu-master'}
 for root in roots:
  for directory,dirs,files in os.walk(K/root):
   for d in list(dirs):
    if d in excluded_dirs:
     omitted.append({'path':str((Path(directory)/d).relative_to(K))+'/', 'reason':'Excluded whole runtime asset, profile/cache, trace, or build tree; inventories/provenance retained'})
     dirs.remove(d)
   for name in sorted(files):
    p=Path(directory)/name;rel=p.relative_to(K)
    if p.suffix not in allowed or p.is_symlink():
     omitted.append({'path':str(rel),'reason':'Unsupported payload format; provenance retained'});continue
    selected[str(rel)]=p
 for name in ['browser-telugu-B-final-build-provenance.json','browser-telugu-B-final-build.log']:
  p=K/name;selected[name]=p
 png_counts={root:sum(1 for name in selected if name.startswith(root+'/') and name.endswith('.png')) for root in ['rendering/native-final-v9-screens','final-web-te','browser-v4/telugu-appendix-d588e65d-c1d2f1bae1cf']}
 assert list(png_counts.values())==[15,24,10],png_counts
 # Gate evidence is authoritative, root-owned. Never mutate it here.
 f=K/'final-kit6/reviews/fil.json';g=json.loads(f.read_text());issues=[];refs=[]
 for name,gate in g['gates'].items():
  if not gate.get('passed'):issues.append('Gate pending: '+name)
  for e in gate.get('evidence',[]):
   p=(K/'final-kit6'/e['path']).resolve()
   assert p.is_relative_to(K.resolve()),e
   actual=sha(p.read_bytes());assert actual==e['sha256'],str(p)
   refs.append({'gate':name,'path':str(p.relative_to(K.resolve())),'sha256':actual,'in_appendix':str(p.relative_to(K.resolve())) in selected})
 carry=json.loads((K/'compatibility-fil114/matrix-scoped-carry-A.json').read_text())
 current_inputs={}
 for path,expected in carry['exact_unchanged_input_sha256'].items():
  actual=sha((R/path).read_bytes());old=sha(subprocess.check_output(['git','show','c35a7b2ebbdb83b264ecc6b0bcf29d89ef926fab:'+path],cwd=R))
  assert actual==expected==old,path
  current_inputs[path]=actual
 functions={}
 for name,prefix in [('samples','std::vector<Sample> samples('),('fontMatrix','void fontMatrix(')]:
  versions=[]
  for revision in ['c35a7b2ebbdb83b264ecc6b0bcf29d89ef926fab',FINAL]:
   text=subprocess.check_output(['git','show',revision+':tools/TranslationPreviewHarness.cpp'],cwd=R,text=True)
   start=text.index(prefix);end=text.index('\n}\n',start)+2;versions.append(text[start:end])
  assert versions[0]==versions[1],name
  functions[name]={'byte_identical_c35_to_final':True,'sha256':sha(versions[1].encode()),'bytes':len(versions[1].encode())}
 checks={'actual_clean_final_revision':FINAL,'baseline_published_commit':baseline,'independently_verified_matrix_input_sha256':current_inputs,'independently_compared_matrix_functions':functions,'included_current_png_counts':png_counts,'gate_count':len(g['gates']),'passed_gates':sum(x.get('passed') is True for x in g['gates'].values()),'gate_references_checked':len(refs),'gate_references':refs,'issues':issues,'scope':'New integration validation and exact historical matrix/source carry; no fresh full linguistic reread or matrix rerender claim.'}
 dump(P/'telugu-integration-readiness-candidate.json',checks)
 print(json.dumps({'candidate_files':len(selected),'bytes':sum(x.stat().st_size for x in selected.values()),'issues':issues,'baseline':baseline}))
 if not a.freeze:return
 assert not issues and len(g['gates'])==9
 selected['final-kit6/reviews/fil.json']=f
 for p in (K/'final-kit6').glob('status*telugu*.json'):selected[str(p.relative_to(K))]=p
 for p in (K/'integration-telugu').glob('*'): 
  if p.is_file() and p.suffix in allowed:selected[str(p.relative_to(K))]=p
 # Concrete token/private-key scan; verified base64 PNG attachment strings are binary pixels.
 patterns=[re.compile(rb'AIza[0-9A-Za-z_-]{35}'),re.compile(rb'ya29\.[0-9A-Za-z_-]{20,}'),re.compile(rb'gh[pousr]_[0-9A-Za-z]{30,}'),re.compile(rb'github_pat_[0-9A-Za-z_]{30,}'),re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(rb'Bearer\s+[A-Za-z0-9_.-]{30,}')]
 binary_pngs=0
 def sanitize(v):
  nonlocal binary_pngs
  if isinstance(v,dict):
   if v.get('contentType')=='image/png' and isinstance(v.get('body'),str):
    raw=base64.b64decode(v['body'],validate=True);assert raw.startswith(b'\x89PNG\r\n\x1a\n');v=dict(v);v['body']={'verified_binary_png_sha256':sha(raw),'bytes':len(raw)};binary_pngs+=1
   return {k:sanitize(x) for k,x in v.items()}
  if isinstance(v,list):return [sanitize(x) for x in v]
  return v
 for rel,p in selected.items():
  if p.suffix in {'.png','.bmp','.replay'}:continue
  b=p.read_bytes()
  if p.suffix=='.json':b=json.dumps(sanitize(json.loads(b))).encode()
  assert not any(x.search(b) for x in patterns),'Concrete secret pattern: '+rel
 checks.update({'status':'passed','privacy':{'concrete_secret_matches':0,'verified_binary_png_attachment_strings':binary_pngs,'limits':'Concrete access-token/private-key patterns, not arbitrary secret classification.'},'omitted_payload_policy':omitted})
 audit=P/'telugu-integration-readiness-audit.json';dump(audit,checks);selected[str(audit.relative_to(K))]=audit
 selected[str(Path(__file__).relative_to(K))]=Path(__file__)
 entries=[]
 for rel,p in sorted(selected.items()):
  b=p.read_bytes();assert len(b)<=50*1024**2
  entries.append({'path':rel,'sha256':sha(b),'bytes':len(b)})
 assert sum(e['bytes'] for e in entries)<150*1024**2
 out=P/'filipino-telugu-integration-appendix.tar.gz'
 assert not out.exists(),'Frozen archive already exists'
 try:
  with tarfile.open(out,'w:gz',compresslevel=6) as t:
   for e in entries:
    p=selected[e['path']];b=p.read_bytes();assert sha(b)==e['sha256'];info=tarfile.TarInfo(e['path']);info.size=len(b);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(b))
  assert out.stat().st_size<=50*1024**2
  observed={}
  with tarfile.open(out,'r|gz') as t:
   for info in t:
    assert info.isfile() and info.name not in observed
    b=t.extractfile(info).read();observed[info.name]=(sha(b),len(b))
  assert observed=={e['path']:(e['sha256'],e['bytes']) for e in entries}
 except BaseException:
  out.unlink(missing_ok=True);raise
 manifest={'source_revision':FINAL,'baseline_published_commit':baseline,'archive':out.name,'archive_sha256':sha(out.read_bytes()),'archive_bytes':out.stat().st_size,'bound_bytes':50*1024**2,'included_files':entries,'verified_every_member_sha256_and_size':True,'baseline_reference':'Existing immutable 47afe three-part validation remains historical; no old matrix/archive bytes copied. Gate evidence outside appendix resolves in that baseline or Git-tracked source as explicitly identified.','gate_reference_locations':refs,'excluded_payloads':omitted,'privacy_audit_sha256':sha(audit.read_bytes()),'limits':['Linux software/Chromium phone viewports, no physical Android/iOS.','Native execution actual827; finald588 golden-fixture-only carry.','57753matrix samples are historical1ff/c35 carried by exact rendering inputs/function fingerprints.']}
 dump(P/'telugu-integration-appendix-manifest.json',manifest)
 print(json.dumps({'archive':out.name,'bytes':out.stat().st_size,'sha256':manifest['archive_sha256'],'members':len(entries),'verified':True}))
if __name__=='__main__':main()
