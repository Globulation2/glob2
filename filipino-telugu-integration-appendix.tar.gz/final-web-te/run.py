from pathlib import Path
import argparse,subprocess,os,json,hashlib,time,socket
R=Path.cwd();O=R/'artifacts/filipino-localization/final-web-te';p=argparse.ArgumentParser();p.add_argument('--revision',required=True);p.add_argument('--routes-spec',default='i18n.spec.ts',help='Committed parameterized Filipino seven-route test file');A=p.parse_args();H=A.revision;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def guard():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==H
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
guard();assert not (O/'results.json').exists();assert (R/'platform/apps/web/e2e'/A.routes_spec).is_file()
for port in [45244,45245]:
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',port))!=0,('Port in use',port)
E=dict(os.environ,PATH='/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH'],TEST_DATABASE_URL='postgres://glob2:glob2@127.0.0.1:45220/postgres',PORT='45244',CI='1',SCREENSHOT_DIR=str(O/'web-screens'),PLAYWRIGHT_JSON_OUTPUT_NAME=str(O/'playwright-results.json'))
out={'revision':H,'commands':[],'runner_sha256':sha(__file__),'ports':{'website':45244,'ssr':45245,'postgres':45220},'database_scope':'Existing local isolated test Postgres; createHarness creates random disposable DBs with test users. No external messages or real auth provider writes.'}
inputs=['platform/apps/web/e2e/i18n.spec.ts','platform/apps/web/e2e/'+A.routes_spec,'platform/apps/web/e2e/server.ts','platform/apps/web/e2e/playwright.config.ts','platform/apps/api/src/web/pages.ts','platform/packages/i18n/locales/fil.json','platform/packages/i18n/locales/en.json','platform/package-lock.json','deploy/Caddyfile'];out['input_sha256_before']={n:sha(R/n) for n in inputs}
def run(name,argv,cwd=R,timeout=1800,env=E):
 guard();log=O/(name+'.log');t=time.monotonic()
 with log.open('x') as f:
  try:q=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout);code=q.returncode;err=None
  except subprocess.TimeoutExpired:code=None;err='timeout'+str(timeout)
 row={'name':name,'command':argv,'cwd':str(cwd),'exit_code':code,'error':err,'seconds':time.monotonic()-t,'log':str(log),'log_sha256':sha(log)};out['commands'].append(row);(O/'results.json').write_text(json.dumps(out,indent=2)+'\n');guard();print(name,code,flush=True);assert code==0,row
run('production-build',['npm','run','build','-w','@glob2/web'],R/'platform',1200)
dist=R/'platform/apps/web/dist';out['production_asset_sha256']={str(p.relative_to(dist)):sha(p) for p in sorted(dist.rglob('*')) if p.is_file()};(O/'results.json').write_text(json.dumps(out,indent=2)+'\n')
base=['npm','run','e2e','-w','@glob2/web','--']
studioenv=dict(E,SCREENSHOT_DIR=str(O/'studio-screens'),PLAYWRIGHT_JSON_OUTPUT_NAME=str(O/'studio-playwright-results.json'))
run('filipino-studios-desktop-phone',base+['tamil.spec.ts','--grep','Filipino studio initial interfaces','--project=desktop','--project=phone','--output='+str(O/'playwright-studios'),'--reporter=list,json'],R/'platform',1200,studioenv)
out['input_sha256_after']={n:sha(R/n) for n in inputs};assert out['input_sha256_after']==out['input_sha256_before'];out['all_commands_passed']=True;out['pixel_review_status']='pending independent review';out['limits']=['Chromium phone viewport is not actual Android/iOS device execution.','All test DB/account/room writes are isolated local fixtures; no external authentication or messages.'];(O/'results.json').write_text(json.dumps(out,indent=2)+'\n')
