// SPDX-License-Identifier: GPL-3.0-or-later
#include "EngineFixtures.h"
#include "SGSL.h"
#include <BinaryStream.h>
#include <StreamBackend.h>
#include <StringTable.h>
#include <Toolkit.h>
#include "Version.h"
#include <array>
#include <sstream>
#include <vector>
#include "AI.h"
#include "Player.h"
#include <nlohmann/json.hpp>

namespace
{
struct World
{
    glob2test::HeadlessGame world{glob2test::GameOptions{
        .teams = 2, .clearImmobile=true, .loadDefaultRace=true, .header=true}};
    MapScriptSGSL script;
    World()
    {
        world.gui.init();
        world.game.map.areaNames[0] = "zone";
        for (int y = 4; y < 8; ++y)
            for (int x = 4; x < 8; ++x) world.game.map.setPoint(0,x,y);
    }
    ErrorReport compile(const std::string& source)
    {
        script.sourceCode=source;
        return script.compileScript(&world.game);
    }
    void step(int count = 1) { while (count--) script.syncStep(world.game, world.gui, world.gui.clientRequests); }
};
int units(const Team* team)
{
    int result = 0;
    for (int id = 0; id<Unit::MAX_COUNT; ++id) if (team->myUnits[id]) ++result;
    return result;
}
std::string save(MapScriptSGSL& script, Game& game)
{
    auto* bytes=new GAGCore::MemoryStreamBackend;
    GAGCore::BinaryOutputStream out(bytes);
    script.save(&out,&game);
    out.flush();
    return bytes->takeContents();
}

void loadLanguageInventory(const std::filesystem::path& listing, const std::string& excludedLanguage = {}, bool publishedWithoutTelugu = false)
{
    std::istringstream entries(glob2test::readFile(glob2test::sourceRoot() / "data/texts.list.txt"));
    std::string contents, entry;
    while (std::getline(entries, entry))
    {
        if (!entry.empty() && entry.back() == '\r') entry.pop_back();
        if (entry.empty() || (!excludedLanguage.empty() && entry == "data/texts." + excludedLanguage + ".txt")) continue;
        // Marathi was published before this PR; omit its later Telugu and Filipino additions in that historical fixture.
        if (publishedWithoutTelugu && (entry == "data/texts.te.txt" || entry == "data/texts.fil.txt")) continue;
        contents += (glob2test::sourceRoot() / entry).string() + "\n";
    }
    glob2test::writeFile(listing, contents);
    auto* strings = GAGCore::Toolkit::getStringTable();
    REQUIRE(strings->load(listing.string()));
    REQUIRE(strings->hasLanguage("en"));
    strings->setDefaultLang(strings->getLangCode("en"));
    strings->setLang(strings->getLangCode("en"));
}

// The released pre-152 SGSL layout has no per-story private RNG fields.
// Keep this historical input independent of the current writer.
std::string saveBeforePrivateRandom(MapScriptSGSL& script, Game& game)
{
    REQUIRE(script.areas.empty());
    REQUIRE(script.flags.empty());
    auto* bytes = new GAGCore::MemoryStreamBackend;
    GAGCore::BinaryOutputStream out(bytes);
    out.writeEnterSection("SGSL");
    out.writeText(script.sourceCode, "sourceCode");
    out.writeSint32(script.mainTimer, "mainTimer");
    out.writeEnterSection("victoryConditions");
    for (int team = 0; team < game.mapHeader.getNumberOfTeams(); ++team)
    {
        out.writeEnterSection(team);
        out.writeSint32(script.hasTeamWon(team), "hasWon");
        out.writeSint32(script.hasTeamLost(team), "hasLost");
        out.writeLeaveSection();
    }
    out.writeLeaveSection();
    out.writeEnterSection("stories");
    for (unsigned story = 0; story < script.stories.size(); ++story)
    {
        out.writeEnterSection(story);
        out.writeSint32(script.stories[story].lineSelector, "ProgramCounter");
        out.writeSint32(script.stories[story].internTimer, "internTimer");
        out.writeLeaveSection();
    }
    out.writeLeaveSection();
    out.writeEnterSection("areas");
    out.writeUint32(0, "areasCount");
    out.writeLeaveSection();
    out.writeEnterSection("flags");
    out.writeUint32(0, "flagsCount");
    out.writeLeaveSection();
    out.writeLeaveSection();
    out.flush();
    return bytes->takeContents();
}
void checkCatalogLanguageTokens(const std::string& language, const std::string& message)
{
    glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.loadStrings=true});
    glob2test::TempDir temporary("sgsl-languages");
    const auto listing = temporary.path / "texts.list.txt";
    World w;
    loadLanguageInventory(listing, language);
    CHECK_FALSE(GAGCore::Toolkit::getStringTable()->hasLanguage(language));
    StringAcquisition withoutCatalog(w.script.functions);
    withoutCatalog.open(language);
    withoutCatalog.nextToken();
    CHECK(withoutCatalog.getToken()->type == SGSLToken::NIL);
    CHECK(w.compile("show(\"" + message + "\"," + language + ")").type == ErrorReport::ET_NOT_VALID_LANG_ID);

    loadLanguageInventory(listing);
    REQUIRE(GAGCore::Toolkit::getStringTable()->hasLanguage(language));
    StringAcquisition withCatalog(w.script.functions);
    withCatalog.open(language);
    withCatalog.nextToken();
    CHECK(withCatalog.getToken()->type == SGSLToken::LANG);
    CHECK(withCatalog.getToken()->msg == language);
    CHECK(withCatalog.getToken()->value == GAGCore::Toolkit::getStringTable()->getLangCode(language));
    CHECK(w.compile("show(\"" + message + "\"," + language + ")").type == ErrorReport::ET_OK);
}

void checkCatalogLanguageDisplay(const std::string& language, const std::string& message)
{
    glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.loadStrings=true});
    for (const auto& [selectedLanguage, expected] : {
        std::pair{language, message}, std::pair{std::string("en"), std::string("English message")},
        std::pair{std::string("fr"), std::string("Authored fallback")}})
    {
        CAPTURE(selectedLanguage);
        globals.globals.settings.language = selectedLanguage;
        World w;
        REQUIRE(w.compile("show(\"Authored fallback\") show(\"English message\",en) "
                          "show(\"" + message + "\"," + language + ") wait(2)").type == ErrorReport::ET_OK);
        w.step();
        CHECK(w.script.isTextShown);
        CHECK(w.script.textShown == expected);
    }
}

void checkCatalogLanguageSavedContinuation(const std::string& language)
{
    glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.loadStrings=true});
    glob2test::TempDir temporary("sgsl-save-languages");
    const auto listing = temporary.path / "texts.list.txt";
    const std::string source =
        "# Released script bytes \xC3\xA9\n"
        "show(\"English message\",en) show(\"French message\",fr) wait(3) "
        "show(\"Authored continuation\") win(0)\n";
    for (const int format : {MINIMUM_VERSION_MINOR, VERSION_MINOR})
    {
        CAPTURE(format);
        loadLanguageInventory(listing, language);
        globals.globals.settings.language = "en";
        World w;
        w.world.game.mapHeader.versionMinor = format;
        REQUIRE(w.world.game.mapHeader.loadingVersion() == format);
        REQUIRE(w.compile(source).type == ErrorReport::ET_OK);
        w.step();
        REQUIRE(w.script.stories.size() == 1);
        const auto tokens = w.script.stories.front().line;
        const int pc = w.script.stories.front().lineSelector;
        const int timer = w.script.stories.front().internTimer;
        REQUIRE(timer > 0);
        const bool historical = format < FILE_FORMAT_VERSION_PRIVATE_RANDOM;
        const auto encode = [&](MapScriptSGSL& script) {
            return historical ? saveBeforePrivateRandom(script, w.world.game)
                              : save(script, w.world.game);
        };
        const auto bytes = encode(w.script);

        loadLanguageInventory(listing);
        globals.globals.settings.language = language;
        MapScriptSGSL restored;
        GAGCore::BinaryInputStream input(new GAGCore::MemoryStreamBackend(bytes.data(), bytes.size()));
        input.seekFromStart(0);
        REQUIRE(restored.load(&input, &w.world.game));
        CHECK(input.getPosition() == bytes.size());
        CHECK(restored.sourceCode == source);
        REQUIRE(restored.stories.size() == 1);
        CHECK(restored.stories.front().lineSelector == pc);
        CHECK(restored.stories.front().internTimer == timer);
        REQUIRE(restored.stories.front().line.size() == tokens.size());
        for (size_t i = 0; i < tokens.size(); ++i)
        {
            CHECK(restored.stories.front().line[i].type == tokens[i].type);
            CHECK(restored.stories.front().line[i].value == tokens[i].value);
            CHECK(restored.stories.front().line[i].msg == tokens[i].msg);
        }
        CHECK(encode(restored) == bytes);
        for (int tick = 0; tick < 5; ++tick)
        {
            w.step();
            restored.syncStep(w.world.game, w.world.gui, w.world.gui.clientRequests);
            CHECK(w.script.checkSum() == restored.checkSum());
            CHECK(encode(w.script) == encode(restored));
        }
        CHECK(restored.hasTeamWon(0));
        CHECK(restored.textShown == "Authored continuation");
    }
}

}

TEST_SUITE("LegacyScriptCoverage")
{
    TEST_CASE("Malay SGSL language tokens require the installed catalog")
    {
        checkCatalogLanguageTokens("ms", "Mesej Melayu");
    }

    TEST_CASE("Malay SGSL selects its message and retains an authored default for other locales")
    {
        checkCatalogLanguageDisplay("ms", "Mesej Melayu");
    }

    TEST_CASE("adding Malay preserves legacy SGSL source bytes and saved program counters")
    {
        checkCatalogLanguageSavedContinuation("ms");
    }

    TEST_CASE("Telugu SGSL language tokens require the installed catalog")
    {
        checkCatalogLanguageTokens("te", "తెలుగు సందేశం");
    }

    TEST_CASE("Telugu SGSL selects its message and retains an authored default for other locales")
    {
        checkCatalogLanguageDisplay("te", "తెలుగు సందేశం");
    }

    TEST_CASE("adding Telugu preserves legacy SGSL source bytes and saved program counters")
    {
        checkCatalogLanguageSavedContinuation("te");
    }

    TEST_CASE("Marathi SGSL language tokens require the installed catalog")
    {
        glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.loadStrings=true});
        glob2test::TempDir temporary("sgsl-languages");
        const auto listing = temporary.path / "texts.list.txt";
        World w;
        loadLanguageInventory(listing, "mr", true);
        CHECK_FALSE(GAGCore::Toolkit::getStringTable()->hasLanguage("mr"));
        StringAcquisition withoutMarathi(w.script.functions);
        withoutMarathi.open("mr");
        withoutMarathi.nextToken();
        CHECK(withoutMarathi.getToken()->type == SGSLToken::NIL);
        CHECK(w.compile("show(\"मराठी संदेश\",mr)").type == ErrorReport::ET_NOT_VALID_LANG_ID);
        auto* strings = GAGCore::Toolkit::getStringTable();
        std::vector<std::string> oldCodes;
        for (int i = 0; i < strings->getNumberOfLanguage(); ++i)
            oldCodes.push_back(strings->getStringInLang("[language-code]", i));
        REQUIRE(strings->hasLanguage("ms"));

        loadLanguageInventory(listing, {}, true);
        REQUIRE(strings->getNumberOfLanguage() == int(oldCodes.size()) + 1);
        for (size_t i = 0; i < oldCodes.size(); ++i)
        {
            CAPTURE(oldCodes[i]);
            CHECK(strings->getLangCode(oldCodes[i]) == int(i));
        }
        REQUIRE(GAGCore::Toolkit::getStringTable()->hasLanguage("mr"));
        StringAcquisition withMarathi(w.script.functions);
        withMarathi.open("mr");
        withMarathi.nextToken();
        CHECK(withMarathi.getToken()->type == SGSLToken::LANG);
        CHECK(withMarathi.getToken()->msg == "mr");
        CHECK(withMarathi.getToken()->value == GAGCore::Toolkit::getStringTable()->getLangCode("mr"));
        CHECK(w.compile("show(\"मराठी संदेश\",mr)").type == ErrorReport::ET_OK);
    }

    TEST_CASE("Marathi SGSL selects its message and retains an authored default for other locales")
    {
        glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.loadStrings=true});
        for (const auto& [language, expected] : {
            std::pair{"mr", "मराठी संदेश"}, std::pair{"en", "English message"},
            std::pair{"fr", "Authored fallback"}})
        {
            CAPTURE(language);
            globals.globals.settings.language = language;
            World w;
            REQUIRE(w.compile("show(\"Authored fallback\") show(\"English message\",en) "
                              "show(\"मराठी संदेश\",mr) wait(2)").type == ErrorReport::ET_OK);
            w.step();
            CHECK(w.script.isTextShown);
            CHECK(w.script.textShown == expected);
        }
    }

    TEST_CASE("adding Marathi preserves legacy SGSL source bytes and saved program counters")
    {
        glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.loadStrings=true});
        glob2test::TempDir temporary("sgsl-save-languages");
        const auto listing = temporary.path / "texts.list.txt";
        const std::string source =
            "# Released script bytes \xC3\xA9\n"
            "show(\"English message\",en) show(\"French message\",fr) "
            "show(\"Mesej Melayu\",ms) wait(3) "
            "show(\"Authored continuation\") win(0)\n";
        for (const int format : {MINIMUM_VERSION_MINOR, VERSION_MINOR})
        {
            CAPTURE(format);
            loadLanguageInventory(listing, "mr", true);
            globals.globals.settings.language = "en";
            World w;
            w.world.game.mapHeader.versionMinor = format;
            REQUIRE(w.world.game.mapHeader.loadingVersion() == format);
            REQUIRE(w.compile(source).type == ErrorReport::ET_OK);
            w.step();
            REQUIRE(w.script.stories.size() == 1);
            const auto tokens = w.script.stories.front().line;
            const int pc = w.script.stories.front().lineSelector;
            const int timer = w.script.stories.front().internTimer;
            REQUIRE(timer > 0);
            const bool historical = format < FILE_FORMAT_VERSION_PRIVATE_RANDOM;
            const auto encode = [&](MapScriptSGSL& script) {
                return historical ? saveBeforePrivateRandom(script, w.world.game)
                                  : save(script, w.world.game);
            };
            const auto bytes = encode(w.script);

            loadLanguageInventory(listing, {}, true);
            globals.globals.settings.language = "mr";
            MapScriptSGSL restored;
            GAGCore::BinaryInputStream input(new GAGCore::MemoryStreamBackend(bytes.data(), bytes.size()));
            input.seekFromStart(0);
            REQUIRE(restored.load(&input, &w.world.game));
            CHECK(input.getPosition() == bytes.size());
            CHECK(restored.sourceCode == source);
            REQUIRE(restored.stories.size() == 1);
            CHECK(restored.stories.front().lineSelector == pc);
            CHECK(restored.stories.front().internTimer == timer);
            REQUIRE(restored.stories.front().line.size() == tokens.size());
            for (size_t i = 0; i < tokens.size(); ++i)
            {
                CHECK(restored.stories.front().line[i].type == tokens[i].type);
                CHECK(restored.stories.front().line[i].value == tokens[i].value);
                CHECK(restored.stories.front().line[i].msg == tokens[i].msg);
            }
            CHECK(encode(restored) == bytes);
            for (int tick = 0; tick < 5; ++tick)
            {
                w.step();
                restored.syncStep(w.world.game, w.world.gui, w.world.gui.clientRequests);
                CHECK(w.script.checkSum() == restored.checkSum());
                CHECK(encode(w.script) == encode(restored));
            }
            CHECK(restored.hasTeamWon(0));
            CHECK(restored.textShown == "Authored continuation");
        }
    }

    TEST_CASE("Filipino SGSL language tokens require the installed catalog")
    {
        glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.loadStrings=true});
        glob2test::TempDir temporary("sgsl-languages");
        const auto listing = temporary.path / "texts.list.txt";
        World w;
        loadLanguageInventory(listing, "fil");
        CHECK_FALSE(GAGCore::Toolkit::getStringTable()->hasLanguage("fil"));
        StringAcquisition withoutFilipino(w.script.functions);
        withoutFilipino.open("fil");
        withoutFilipino.nextToken();
        CHECK(withoutFilipino.getToken()->type == SGSLToken::NIL);
        CHECK(w.compile("show(\"Mensahe sa Filipino\",fil)").type == ErrorReport::ET_NOT_VALID_LANG_ID);
        auto* strings = GAGCore::Toolkit::getStringTable();
        std::vector<std::string> oldCodes;
        for (int i = 0; i < strings->getNumberOfLanguage(); ++i)
            oldCodes.push_back(strings->getStringInLang("[language-code]", i));
        REQUIRE(strings->hasLanguage("mr"));

        loadLanguageInventory(listing);
        REQUIRE(strings->getNumberOfLanguage() == int(oldCodes.size()) + 1);
        for (size_t i = 0; i < oldCodes.size(); ++i)
        {
            CAPTURE(oldCodes[i]);
            CHECK(strings->getLangCode(oldCodes[i]) == int(i));
        }
        REQUIRE(GAGCore::Toolkit::getStringTable()->hasLanguage("fil"));
        StringAcquisition withFilipino(w.script.functions);
        withFilipino.open("fil");
        withFilipino.nextToken();
        CHECK(withFilipino.getToken()->type == SGSLToken::LANG);
        CHECK(withFilipino.getToken()->msg == "fil");
        CHECK(withFilipino.getToken()->value == GAGCore::Toolkit::getStringTable()->getLangCode("fil"));
        CHECK(w.compile("show(\"Mensahe sa Filipino\",fil)").type == ErrorReport::ET_OK);
    }

    TEST_CASE("Filipino SGSL selects its message and retains an authored default for other locales")
    {
        glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.loadStrings=true});
        for (const auto& [language, expected] : {
            std::pair{"fil", "Mensahe sa Filipino"}, std::pair{"en", "English message"},
            std::pair{"fr", "Authored fallback"}})
        {
            CAPTURE(language);
            globals.globals.settings.language = language;
            World w;
            REQUIRE(w.compile("show(\"Authored fallback\") show(\"English message\",en) "
                              "show(\"Mensahe sa Filipino\",fil) wait(2)").type == ErrorReport::ET_OK);
            w.step();
            CHECK(w.script.isTextShown);
            CHECK(w.script.textShown == expected);
        }
    }

    TEST_CASE("adding Filipino preserves legacy SGSL source bytes and saved program counters")
    {
        glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.loadStrings=true});
        glob2test::TempDir temporary("sgsl-save-languages");
        const auto listing = temporary.path / "texts.list.txt";
        const std::string source =
            "# Released script bytes \xC3\xA9\n"
            "show(\"English message\",en) show(\"French message\",fr) "
            "show(\"मराठी संदेश\",mr) wait(3) "
            "show(\"Authored continuation\") win(0)\n";
        for (const int format : {MINIMUM_VERSION_MINOR, VERSION_MINOR})
        {
            CAPTURE(format);
            loadLanguageInventory(listing, "fil");
            globals.globals.settings.language = "en";
            World w;
            w.world.game.mapHeader.versionMinor = format;
            REQUIRE(w.world.game.mapHeader.loadingVersion() == format);
            REQUIRE(w.compile(source).type == ErrorReport::ET_OK);
            w.step();
            REQUIRE(w.script.stories.size() == 1);
            const auto tokens = w.script.stories.front().line;
            const int pc = w.script.stories.front().lineSelector;
            const int timer = w.script.stories.front().internTimer;
            REQUIRE(timer > 0);
            const bool historical = format < FILE_FORMAT_VERSION_PRIVATE_RANDOM;
            const auto encode = [&](MapScriptSGSL& script) {
                return historical ? saveBeforePrivateRandom(script, w.world.game)
                                  : save(script, w.world.game);
            };
            const auto bytes = encode(w.script);

            loadLanguageInventory(listing);
            globals.globals.settings.language = "fil";
            MapScriptSGSL restored;
            GAGCore::BinaryInputStream input(new GAGCore::MemoryStreamBackend(bytes.data(), bytes.size()));
            input.seekFromStart(0);
            REQUIRE(restored.load(&input, &w.world.game));
            CHECK(input.getPosition() == bytes.size());
            CHECK(restored.sourceCode == source);
            REQUIRE(restored.stories.size() == 1);
            CHECK(restored.stories.front().lineSelector == pc);
            CHECK(restored.stories.front().internTimer == timer);
            REQUIRE(restored.stories.front().line.size() == tokens.size());
            for (size_t i = 0; i < tokens.size(); ++i)
            {
                CHECK(restored.stories.front().line[i].type == tokens[i].type);
                CHECK(restored.stories.front().line[i].value == tokens[i].value);
                CHECK(restored.stories.front().line[i].msg == tokens[i].msg);
            }
            CHECK(encode(restored) == bytes);
            for (int tick = 0; tick < 5; ++tick)
            {
                w.step();
                restored.syncStep(w.world.game, w.world.gui, w.world.gui.clientRequests);
                CHECK(w.script.checkSum() == restored.checkSum());
                CHECK(encode(w.script) == encode(restored));
            }
            CHECK(restored.hasTeamWon(0));
            CHECK(restored.textShown == "Authored continuation");
        }
    }

    TEST_CASE("catalog languages and quoted locale names preserve suspended story continuation")
    {
        glob2test::HeadlessGlobals globals(glob2test::GlobalsOptions{.loadStrings=true});
        auto* strings=GAGCore::Toolkit::getStringTable();
        struct RestoreLanguage
        {
            GlobalContainer& globals;
            GAGCore::StringTable& strings;
            std::string language;
            int index;
            ~RestoreLanguage() { globals.settings.language=language; strings.setLang(index); }
        } restoreLanguage{*globals,*strings,globals->settings.language,strings->getLang()};
        for (const std::string catalogLanguage : {"nb", "te"})
        {
            CAPTURE(catalogLanguage);
            std::vector<Uint32> inventoryScriptChecksums, inventoryGameChecksums;
            std::vector<std::string> inventorySaves;
            for (const bool excludeCatalog : {false, true})
            {
                CAPTURE(excludeCatalog);
                for (const bool includeCatalogLanguage : {false, true})
                {
                    CAPTURE(includeCatalogLanguage);
                    if (excludeCatalog && includeCatalogLanguage) continue;
                    glob2test::TempDir temporary("sgsl-continuation-inventory");
                    loadLanguageInventory(temporary.path / "texts.list.txt", excludeCatalog ? catalogLanguage : std::string());
                    // Quoted labels/area names remain data even when the same spelling
                    // is an installed language token. Exercise both old and localized sources.
                    const std::string source=
                    std::string("setArea(\"") + catalogLanguage + "\",10,10,4) label(\"" + catalogLanguage + "\") show(\"ancien\",fr) " +
                    (includeCatalogLanguage ? "show(\"ny\"," + catalogLanguage + ") " : "") +
                    "wait(3) summonUnits(\"" + catalogLanguage + "\",2,Worker,0,0) win(0)";
                    std::vector<Uint32> firstChecksums;
                    std::vector<Uint32> firstGameChecksums;
                    std::vector<std::string> firstSaves;
                    for (const std::string language : {std::string("fr"), excludeCatalog ? std::string("en") : catalogLanguage})
                    {
                        CAPTURE(language);
                        globals->settings.language=language;
                        strings->setLang(strings->getLangCode(language));
                        REQUIRE(std::string(strings->getString("[language-code]")) == language);
                        World original, restored;
                        REQUIRE(original.compile(source).type == ErrorReport::ET_OK);
                        CHECK(original.script.stories.front().labels.count(catalogLanguage) == 1);
                        int languageTokens=0;
                        for (const auto& token : original.script.stories.front().line)
                        if (token.type == SGSLToken::LANG)
                        {
                            CHECK(token.value == strings->getLangCode(token.msg));
                            ++languageTokens;
                        }
                        CHECK(languageTokens == (includeCatalogLanguage ? 2 : 1));
                        original.step();
                        CHECK(original.script.isTextShown == (language == "fr" || includeCatalogLanguage));
                        if (original.script.isTextShown)
                        CHECK(original.script.textShown == (language == "fr" ? "ancien" : "ny"));
                        else
                        CHECK(original.script.textShown.empty());
                        REQUIRE(original.script.stories.front().internTimer > 0);
                        const auto bytes=save(original.script,original.world.game);
                        auto* gameBackend=new GAGCore::MemoryStreamBackend;
                        GAGCore::BinaryOutputStream gameOutput(gameBackend);
                        original.world.game.save(&gameOutput,false,"localized story continuation");
                        gameOutput.flush();
                        const auto gameBytes=gameBackend->takeContents();
                        GAGCore::BinaryInputStream gameInput(new GAGCore::MemoryStreamBackend(gameBytes.data(),gameBytes.size()));
                        gameInput.seekFromStart(0);
                        REQUIRE(restored.world.game.load(&gameInput));
                        GAGCore::BinaryInputStream input(new GAGCore::MemoryStreamBackend(bytes.data(),bytes.size()));
                        input.seekFromStart(0);
                        REQUIRE(restored.script.load(&input,&restored.world.game));
                        for (unsigned tick=0;tick<6;++tick)
                        {
                            CAPTURE(tick);
                            CHECK(original.script.stories.front().lineSelector == restored.script.stories.front().lineSelector);
                            CHECK(original.script.stories.front().random == restored.script.stories.front().random);
                            CHECK(original.script.checkSum() == restored.script.checkSum());
                            CHECK(original.world.game.checkSum() == restored.world.game.checkSum());
                            const auto saved=save(original.script,original.world.game);
                            CHECK(saved == save(restored.script,restored.world.game));
                            if (!includeCatalogLanguage && language == "fr")
                            {
                                if (!excludeCatalog)
                                {
                                    inventoryScriptChecksums.push_back(original.script.checkSum());
                                    inventoryGameChecksums.push_back(original.world.game.checkSum());
                                    inventorySaves.push_back(saved);
                                }
                                else
                                {
                                    REQUIRE(inventorySaves.size() == 6);
                                    CHECK(original.script.checkSum() == inventoryScriptChecksums[tick]);
                                    CHECK(original.world.game.checkSum() == inventoryGameChecksums[tick]);
                                    CHECK(saved == inventorySaves[tick]);
                                }
                            }
                            if (language == "fr")
                            {
                                firstChecksums.push_back(original.script.checkSum());
                                firstGameChecksums.push_back(original.world.game.checkSum());
                                firstSaves.push_back(saved);
                            }
                            else
                            {
                                CHECK(original.script.checkSum() == firstChecksums[tick]);
                                CHECK(original.world.game.checkSum() == firstGameChecksums[tick]);
                                CHECK(saved == firstSaves[tick]);
                            }
                            original.step();
                            restored.step();
                        }
                        CHECK(original.script.hasTeamWon(0));
                        CHECK(restored.script.hasTeamWon(0));
                        CHECK(units(original.world.game.teams[0]) == 2);
                        CHECK(units(restored.world.game.teams[0]) == 2);
                    }
                }
            }
        }
        glob2test::TempDir restoredInventory("sgsl-restored-inventory");
        loadLanguageInventory(restoredInventory.path / "texts.list.txt");
    }

    TEST_CASE("random legacy summons preserve story progress through full continuation")
    {
        glob2test::HeadlessGlobals globals;
        World original, restored;
        REQUIRE(original.compile("setArea(\"old\",10,10,4) summonUnits(\"old\",2,Worker,0,0) wait(3) summonUnits(\"old\",2,Worker,0,0)").type==ErrorReport::ET_OK);
        original.step();
        const auto scriptBytes=save(original.script,original.world.game);
        auto* backend=new GAGCore::MemoryStreamBackend;
        GAGCore::BinaryOutputStream out(backend);
        original.world.game.save(&out,false,"story RNG continuation"); out.flush();
        const auto gameBytes=backend->takeContents();
        GAGCore::BinaryInputStream gameInput(new GAGCore::MemoryStreamBackend(gameBytes.data(),gameBytes.size()));
        gameInput.seekFromStart(0);
        REQUIRE(restored.world.game.load(&gameInput));
        GAGCore::BinaryInputStream scriptInput(new GAGCore::MemoryStreamBackend(scriptBytes.data(),scriptBytes.size()));
        scriptInput.seekFromStart(0);
        REQUIRE(restored.script.load(&scriptInput,&restored.world.game));
        CHECK(original.script.checkSum()==restored.script.checkSum());
        CHECK(save(original.script,original.world.game)==save(restored.script,restored.world.game));
        for (unsigned tick=0;tick<5;++tick) {
            original.step(); restored.step();
            CHECK(original.script.checkSum()==restored.script.checkSum());
            CHECK(save(original.script,original.world.game)==save(restored.script,restored.world.game));
            CHECK(units(original.world.game.teams[0])==units(restored.world.game.teams[0]));
            for (unsigned slot=0;slot<Unit::MAX_COUNT;++slot) {
                const auto* a=original.world.game.teams[0]->myUnits[slot];
                const auto* b=restored.world.game.teams[0]->myUnits[slot];
                if (a && b) { CHECK(a->posX==b->posX); CHECK(a->posY==b->posY); CHECK(a->entityRandom==b->entityRandom); }
            }
        }
    }

    TEST_CASE("supported statements and wait forms compile")
    {
        glob2test::HeadlessGlobals globals;
        World w;
        for (const char* source : {
            "summonUnits(\"zone\",30,Worker,3,0)",
            "summonUnits(\"zone\",0,Explorer,0,1)",
            "summonUnits(\"zone\",1,Warrior,1,0)",
            "setArea(\"old\",10,10,4) summonUnits(\"old\",2,Worker,0,0)",
            "summonFlag(\"attack\",3,5,4,2,0) destroyFlag(\"attack\")",
            "alliance(0,1,3) guiDisable(BuildingTab) guiEnable(FlagTab)",
            "show(\"hello\") hide timer(3) win(0) loose(1)",
            "label(\"start\") wait(1) jump(\"start\")",
            "wait(isdead(1))", "wait(area(\"zone\",0))",
            "wait(not(area(\"zone\",enemy(0))))", "wait(area(\"zone\",ally(0)))",
            "wait(Worker(0) > 2)", "wait(Explorer(0) = 0)", "wait(Warrior(1) < 3)",
            "wait(Inn(0,0) > 0)", "wait(only Swarm(0,1) = 1)",
            "wait(not(only Hospital(1,2) < 1))", "space", "wait(1) story wait(2)"})
        {
            INFO(source);
            REQUIRE(w.compile(source).type == ErrorReport::ET_OK);
        }
    }

    TEST_CASE("invalid references and value boundaries report typed errors")
    {
        glob2test::HeadlessGlobals globals;
        World w;
        struct Invalid { const char* source; ErrorReport::ErrorType error; };
        for (const auto& entry : {
            Invalid{"summonUnits(\"missing\",1,Worker,0,0)",ErrorReport::ET_UNDEFINED_AREA_NAME},
            Invalid{"summonUnits(\"zone\",31,Worker,0,0)",ErrorReport::ET_INVALID_VALUE},
            Invalid{"summonUnits(\"zone\",1,Worker,4,0)",ErrorReport::ET_INVALID_VALUE},
            Invalid{"summonUnits(\"zone\",1,Worker,0,2)",ErrorReport::ET_INVALID_TEAM},
            Invalid{"summonUnits(\"zone\",1,Inn,0,0)",ErrorReport::ET_SYNTAX_ERROR},
            Invalid{"setArea(\"old\",1,1,0)",ErrorReport::ET_INVALID_VALUE},
            Invalid{"setArea(\"old\",1,1,2) setArea(\"old\",2,2,2)",ErrorReport::ET_DUPLICATED_AREA_NAME},
            Invalid{"alliance(0,1,4)",ErrorReport::ET_INVALID_ALLIANCE_LEVEL},
            Invalid{"alliance(2,0,1)",ErrorReport::ET_INVALID_TEAM},
            Invalid{"jump(\"missing\")",ErrorReport::ET_UNDEFINED_LABEL},
            Invalid{"wait(0)",ErrorReport::ET_INVALID_VALUE},
            Invalid{"wait(only Worker(0) = 1)",ErrorReport::ET_INVALID_ONLY},
            Invalid{"wait(Inn(0,6) > 0)",ErrorReport::ET_INVALID_VALUE},
            Invalid{"wait(area(\"missing\",0))",ErrorReport::ET_UNDEFINED_AREA_NAME},
            Invalid{"wait(Worker(2) = 0)",ErrorReport::ET_INVALID_TEAM},
            Invalid{"win(2)",ErrorReport::ET_INVALID_TEAM}})
        {
            CAPTURE(entry.source);
            const auto report=w.compile(std::string("\n")+entry.source);
            CHECK(report.type == entry.error);
            CHECK(report.line >= 1);
            CHECK(report.pos <= w.script.sourceCode.size());
        }
    }

    TEST_CASE("truncated arguments fail without accepting incomplete statements")
    {
        glob2test::HeadlessGlobals globals;
        World w;
        for (const std::string source : {
            "summonUnits(\"zone\",2,Worker,0,0)", "setArea(\"old\",1,2,3)",
            "summonFlag(\"f\",1,2,3,4,0)", "destroyFlag(\"f\")", "alliance(0,1,2)",
            "wait(not(area(\"zone\",enemy(0))))", "wait(only Inn(0,0) > 1)",
            "timer(2)", "show(\"text\")", "guiDisable(BuildingTab)", "win(0)"})
        {
            for (size_t length=source.find('('); length<source.size(); ++length)
            {
                INFO(source); CAPTURE(length);
                CHECK(w.compile(source.substr(0,length)).type != ErrorReport::ET_OK);
            }
        }
    }

    TEST_CASE("summons respect painted area capacity and unit attributes")
    {
        glob2test::HeadlessGlobals globals;
        World w;
        REQUIRE(w.compile("summonUnits(\"zone\",30,Warrior,2,1)").type == ErrorReport::ET_OK);
        w.step();
        CHECK(units(w.world.game.teams[0]) == 0);
        CHECK(units(w.world.game.teams[1]) == 16);
        for (int id = 0; id<Unit::MAX_COUNT; ++id) if (auto* unit=w.world.game.teams[1]->myUnits[id])
        {
            CHECK(unit->typeNum == WARRIOR);
            CHECK(w.world.game.map.isPointSet(0,unit->posX,unit->posY));
            CHECK(unit->level[ATTACK_STRENGTH] == 2);
        }
        w.step();
        CHECK(units(w.world.game.teams[1]) == 16);
    }

    TEST_CASE("alliance levels preserve unrelated teams and apply vision masks")
    {
        glob2test::HeadlessGlobals globals;
        World w;
        for (int level = 0; level < 4; ++level)
        {
            REQUIRE(w.compile("alliance(0,1,"+std::to_string(level)+")").type == ErrorReport::ET_OK);
            w.step();
            const auto* team=w.world.team;
            CHECK(bool(team->allies & 2) == (level== 3));
            CHECK(bool(team->enemies & 2) == (level== 0));
            CHECK(bool(team->sharedVisionExchange & 2) == (level>= 1));
            CHECK(bool(team->sharedVisionFood & 2) == (level>= 2));
            CHECK(bool(team->sharedVisionOther & 2) == (level== 3));
            CHECK((team->allies & 1) == 1);
        }
    }

    TEST_CASE("area waits observe team alliance and negation instead of unrelated units")
    {
        glob2test::HeadlessGlobals globals;
        World w;
        for (const char* who : {"0", "ally(0)", "enemy(1)"})
        {
            REQUIRE(w.compile(std::string("wait(area(\"zone\",")+who+")) win(0)").type == ErrorReport::ET_OK);
            w.step();
            CHECK_FALSE(w.script.hasTeamWon(0));
            auto* unit=w.world.addUnit(WORKER,4,4);
            w.step();
            CHECK(w.script.hasTeamWon(0));
            // Move off the scripted area without changing the team queried.
            w.world.game.map.setGroundUnit(4,4,NOGUID);
            w.world.game.map.setGroundUnit(20,20,unit->gid);
            unit->posX = 20; unit->posY = 20;
        }
        REQUIRE(w.compile("wait(not(area(\"zone\",0))) loose(1)").type == ErrorReport::ET_OK);
        w.step();
        CHECK(w.script.hasTeamLost(1));
    }

    TEST_CASE("count waits evaluate all building classes exact levels and unit comparisons")
    {
        glob2test::HeadlessGlobals globals;
        const std::pair<const char*,const char*> classes[] = {
            {"Swarm","swarm"},{"Inn","inn"},{"Hospital","hospital"},
            {"Racetrack","racetrack"},{"Pool","swimmingpool"},{"Camp","barracks"},
            {"School","school"},{"Tower","defencetower"},{"Market","market"},
            {"Wall","stonewall"},{"ExplorationFlag","explorationflag"},
            {"WarFlag","warflag"},{"ClearingFlag","clearingflag"}};
        for (const auto& [token,type] : classes)
        {
            INFO(std::string(token));
            World w;
            REQUIRE(w.compile(std::string("wait(only ")+token+"(0,1) = 1) win(0)").type==ErrorReport::ET_OK);
            w.step(); CHECK_FALSE(w.script.hasTeamWon(0));
            w.world.addBuilding(type,4,4);
            for (int sample=0; sample<TeamStats::STATS_SMOOTH_SIZE; ++sample) w.world.team->stats.step(w.world.team);
            w.step(); CHECK(w.script.hasTeamWon(0));
            REQUIRE(w.compile(std::string("wait(")+token+"(0,0) > 0) win(0)").type==ErrorReport::ET_OK);
            w.step(); CHECK(w.script.hasTeamWon(0));
            REQUIRE(w.compile(std::string("wait(not(only ")+token+"(0,0) < 1)) win(0)").type==ErrorReport::ET_OK);
            w.step(); CHECK_FALSE(w.script.hasTeamWon(0));
        }
        World w;
        for (const auto& [token,type] : {std::pair{"Worker",WORKER},std::pair{"Explorer",EXPLORER},std::pair{"Warrior",WARRIOR}})
        {
            REQUIRE(w.compile(std::string("wait(")+token+"(0) > 0) win(0)").type==ErrorReport::ET_OK);
            w.step(); CHECK_FALSE(w.script.hasTeamWon(0));
            w.world.addUnit(type); for (int sample=0; sample<TeamStats::STATS_SMOOTH_SIZE; ++sample) w.world.team->stats.step(w.world.team);
            w.step(); CHECK(w.script.hasTeamWon(0));
        }
        REQUIRE(w.compile("wait(isdead(1)) win(0)").type==ErrorReport::ET_OK);
        w.step(); CHECK_FALSE(w.script.hasTeamWon(0));
        w.world.game.teams[1]->isAlive=false;
        w.step(); CHECK(w.script.hasTeamWon(0));
    }

    TEST_CASE("flag lifecycle and GUI commands change their real game objects")
    {
        glob2test::HeadlessGlobals globals;
        World w;
        REQUIRE(w.compile("summonFlag(\"attack\",4,4,5,7,0) wait(1) destroyFlag(\"attack\") win(0)").type==ErrorReport::ET_OK);
        w.step(); REQUIRE(w.script.flags.size()==1);
        auto* flag=w.script.flags.at("attack");
        CHECK(flag->posX==4); CHECK(flag->posY==4); CHECK(flag->unitStayRange==5);
        CHECK(flag->maxUnitWorking==7); CHECK(flag->maxUnitWorkingPreferred==7);
        w.step(2); CHECK(w.script.flags.empty()); CHECK(w.script.hasTeamWon(0));
        for (const auto& [token,name] : {std::pair{"Inn","inn"},std::pair{"WarFlag","warflag"}})
        {
            REQUIRE(w.compile(std::string("guiDisable(")+token+") wait(1) guiEnable("+token+")").type==ErrorReport::ET_OK);
            w.step();
            if (std::string(token)=="Inn") CHECK_FALSE(w.world.gui.isBuildingEnabled(name));
            else CHECK_FALSE(w.world.gui.isFlagEnabled(name));
            w.step(2);
            if (std::string(token)=="Inn") CHECK(w.world.gui.isBuildingEnabled(name));
            else CHECK(w.world.gui.isFlagEnabled(name));
        }
        REQUIRE(w.compile("label(\"again\") wait(1) jump(\"again\") win(0)").type==ErrorReport::ET_OK);
        w.step(12); CHECK_FALSE(w.script.hasTeamWon(0));
    }

    TEST_CASE("authored flag aliases resolve game catalog IDs and respect missing definitions")
    {
        glob2test::HeadlessGlobals globals;
        for (const bool missing : {false, true})
        {
            World w;
            auto catalog=nlohmann::json::parse(w.world.game.buildingsTypes.snapshotJson());
            const int old=w.world.game.buildingsTypes.getTypeNum("warflag",0,false);
            auto flag=catalog["variants"][old]; flag["id"]=0;
            flag["semantics"]["assignmentLimit"]=3;
            flag["presentation"]["defaultAssigned"]=3;
            flag["properties"]["maxUnitStayRange"]=6;
            if (missing) flag["properties"]["type"]="different-authored-alias";
            catalog["variants"]=nlohmann::json::array({flag});
            catalog["startingBuilding"]="";
            w.world.game.buildingsTypes.loadSnapshotJson(catalog.dump());
            w.world.game.configureBuildingCatalog();
            REQUIRE(w.compile("summonFlag(\"attack\",4,4,99,99,0) wait(1)").type==ErrorReport::ET_OK);
            w.step();
            if (missing) CHECK(w.script.flags.empty());
            else
            {
                REQUIRE(w.script.flags.size()==1);
                auto* placed=w.script.flags.at("attack");
                CHECK(placed->typeNum==0);
                CHECK(placed->unitStayRange==6);
                CHECK(placed->maxUnitWorking==3);
                CHECK(placed->maxUnitWorkingPreferred==3);
            }
        }
    }

    TEST_CASE("independent stories timers space and saved suspension resume exactly")
    {
        glob2test::HeadlessGlobals globals;
        World w;
        REQUIRE(w.compile("show(\"begin\") wait(3) hide win(0) story wait(1) loose(1)").type == ErrorReport::ET_OK);
        w.step();
        CHECK(w.script.isTextShown);
        CHECK_FALSE(w.script.hasTeamWon(0));
        const auto bytes=save(w.script,w.world.game);
        MapScriptSGSL restored;
        GAGCore::BinaryInputStream input(new GAGCore::MemoryStreamBackend(bytes.data(),bytes.size()));
        input.seekFromStart(0);
        REQUIRE(restored.load(&input,&w.world.game));
        for (int tick = 0; tick < 5; ++tick)
        {
            w.step(); restored.syncStep(w.world.game, w.world.gui, w.world.gui.clientRequests);
            CHECK(save(w.script,w.world.game) == save(restored,w.world.game));
        }
        CHECK(w.script.hasTeamWon(0));
        CHECK(w.script.hasTeamLost(1));
        CHECK_FALSE(w.script.isTextShown);
        REQUIRE(w.compile("timer(3) win(0) space loose(1)").type == ErrorReport::ET_OK);
        w.step(); CHECK_FALSE(w.script.hasTeamWon(0));
        w.step(3); CHECK(w.script.hasTeamWon(0)); CHECK_FALSE(w.script.hasTeamLost(1));
        w.world.gui.setIsSpaceSet(true);
        w.step(); CHECK(w.script.hasTeamLost(1)); CHECK_FALSE(w.world.gui.isSpaceSet());
    }
    TEST_CASE("resetAI changes only the chosen player and rejects unsafe indices")
    {
        glob2test::HeadlessGlobals globals;
        World w;
        const auto other=w.world.game.players[1]->type;
        REQUIRE(w.compile("resetAI(0,2)").type==ErrorReport::ET_OK);
        w.step();
        REQUIRE(w.world.game.players[0]->ai);
        CHECK(w.world.game.players[0]->ai->implementationID==AI::CASTOR);
        CHECK(w.world.game.players[1]->type==other);
        for (const char* source : {"resetAI(2,2)","resetAI(999,2)","resetAI(0,10)","resetAI(0,999)"})
        {
            INFO(source);
            CHECK(w.compile(source).type==ErrorReport::ET_INVALID_VALUE);
        }
    }

    TEST_CASE("resetAI authoring accepts valid slots before an editor map has a player header")
    {
        glob2test::HeadlessGlobals globals;
        glob2test::HeadlessGame w(glob2test::GameOptions{.teams=2,.clearImmobile=true,.loadDefaultRace=true});
        REQUIRE(w.game.gameHeader.getNumberOfPlayers()==0);
        MapScriptSGSL script; script.sourceCode="resetAI(0,2)";
        CHECK(script.compileScript(&w.game).type==ErrorReport::ET_OK);
        script.syncStep(w.game,w.gui,w.gui.clientRequests); // No active player means no runtime replacement.
        CHECK(w.game.players[0]==nullptr);
        script.sourceCode="resetAI(16,2)";
        CHECK(script.compileScript(&w.game).type==ErrorReport::ET_INVALID_VALUE);
    }

    TEST_CASE("legacy resetAI tokens with invalid player or implementation leave players intact")
    {
        glob2test::HeadlessGlobals globals;
        World w;
        for (const auto invalid : {std::pair{999,2},std::pair{0,999},std::pair{-1,2},std::pair{0,-1}})
        {
            REQUIRE(w.compile("resetAI(0,2)").type==ErrorReport::ET_OK);
            REQUIRE(w.script.stories.size()==1);
            auto& tokens=w.script.stories.front().line;
            REQUIRE(tokens.size()>=3);
            tokens[1].value=invalid.first; tokens[2].value=invalid.second;
            const auto first=w.world.game.players[0]->type;
            const auto second=w.world.game.players[1]->type;
            w.step();
            CHECK(w.world.game.players[0]->type==first);
            CHECK(w.world.game.players[1]->type==second);
        }
    }

    TEST_CASE("objectives and hints resolve script numbers and persist in game snapshots")
    {
        glob2test::HeadlessGlobals globals;
        World w;
        auto& goals=w.world.game.objectives; auto& hints=w.world.game.gameHints;
        goals.removeObjective(0); // Fresh games install the default victory objective.
        goals.addNewObjective("other",false,false,false,GameObjectives::Primary,3);
        goals.addNewObjective("target",true,false,false,GameObjectives::Secondary,7);
        hints.addNewHint("other hint",false,3); hints.addNewHint("target hint",true,8);
        REQUIRE(w.compile("objectiveVisible(7) hintVisible(8)").type==ErrorReport::ET_OK);
        w.step(); CHECK(goals.isObjectiveVisible(1)); CHECK(hints.isHintVisible(1));
        CHECK_FALSE(goals.isObjectiveComplete(1));
        REQUIRE(w.compile("objectiveComplete(7)").type==ErrorReport::ET_OK);
        w.step(); CHECK(goals.isObjectiveComplete(1)); CHECK_FALSE(goals.isObjectiveFailed(1));
        REQUIRE(w.compile("objectiveFailed(7) objectiveHidden(7) hintHidden(8)").type==ErrorReport::ET_OK);
        w.step(); CHECK_FALSE(goals.isObjectiveVisible(1)); CHECK_FALSE(hints.isHintVisible(1));
        CHECK_FALSE(goals.isObjectiveComplete(1)); CHECK(goals.isObjectiveFailed(1));
        CHECK(goals.isObjectiveVisible(0)); CHECK_FALSE(goals.isObjectiveComplete(0));
        CHECK_FALSE(goals.isObjectiveFailed(0)); CHECK(hints.isHintVisible(0));
        REQUIRE(w.compile("objectiveComplete(999) objectiveVisible(999) hintHidden(999)").type==ErrorReport::ET_OK);
        w.step(); CHECK_FALSE(goals.isObjectiveComplete(0)); CHECK(hints.isHintVisible(0));
        auto* backend=new GAGCore::MemoryStreamBackend; GAGCore::BinaryOutputStream out(backend);
        w.world.game.save(&out,false,"script objectives"); out.flush();
        const auto bytes=backend->takeContents(); GameGUI restored(false);
        GAGCore::BinaryInputStream in(new GAGCore::MemoryStreamBackend(bytes.data(),bytes.size()));
        in.seekFromStart(0); REQUIRE(restored.game.load(&in));
        CHECK_FALSE(restored.game.objectives.isObjectiveComplete(1));
        CHECK(restored.game.objectives.isObjectiveFailed(1));
        CHECK_FALSE(restored.game.objectives.isObjectiveVisible(1));
        CHECK(restored.game.objectives.getScriptNumber(1)==7);
        CHECK_FALSE(restored.game.gameHints.isHintVisible(1));
        CHECK(restored.game.gameHints.getGameHintText(1)=="target hint");
    }

    TEST_CASE("named highlights target distinct GUI elements and unhighlight restores state")
    {
        glob2test::HeadlessGlobals globals; World w;
        for (const auto& entry : {
            std::pair{"main menu icon",GameGUI::HighlightMainMenuIcon},
            std::pair{"right side panel",GameGUI::HighlightRightSidePanel},
            std::pair{"under minimap icons",GameGUI::HighlightUnderMinimapIcon},
            std::pair{"units assigned bar",GameGUI::HighlightUnitsAssignedBar},
            std::pair{"units ratio bar",GameGUI::HighlightRatioBar},
            std::pair{"workers working free stat",GameGUI::HighlightWorkersWorkingFreeStat},
            std::pair{"explorers working free stat",GameGUI::HighlightExplorersWorkingFreeStat},
            std::pair{"warriors working free stat",GameGUI::HighlightWarriorsWorkingFreeStat},
            std::pair{"forbidden zone on panel",GameGUI::HighlightForbiddenZoneOnPanel},
            std::pair{"guard zone on panel",GameGUI::HighlightGuardZoneOnPanel},
            std::pair{"clearing zone on panel",GameGUI::HighlightClearingZoneOnPanel},
            std::pair{"brush selector",GameGUI::HighlightBrushSelector}})
        {
            INFO(entry.first);
            const std::string argument=std::string("(\"")+entry.first+"\")";
            REQUIRE(w.compile("hilightItem"+argument).type==ErrorReport::ET_OK);
            w.step(); CHECK(w.world.gui.highlights==std::set<int>{entry.second});
            REQUIRE(w.compile("unhilightItem"+argument).type==ErrorReport::ET_OK);
            w.step(); CHECK(w.world.gui.highlights.empty());
        }
        REQUIRE(w.compile("hilightItem(\"unknown item\")").type==ErrorReport::ET_OK);
        w.step(); CHECK(w.world.gui.highlights.empty());
    }

    TEST_CASE("unit and building highlights use map and panel channels independently")
    {
        glob2test::HeadlessGlobals globals; World w;
        REQUIRE(w.compile("hilightUnits(Worker) hilightBuildings(Inn) hilightBuildingOnPanel(Inn)").type==ErrorReport::ET_OK);
        w.step(); CHECK(w.world.gui.highlights.size()==3);
        CHECK(w.world.gui.highlights.count(GameGUI::HighlightWorkers)==1);
        CHECK(w.world.gui.highlights.count(GameGUI::HighlightBuildingOnMap+IntBuildingType::FOOD_BUILDING)==1);
        CHECK(w.world.gui.highlights.count(GameGUI::HighlightBuildingOnPanel+IntBuildingType::FOOD_BUILDING)==1);
        REQUIRE(w.compile("unhilightUnits(Worker) unhilightBuildings(Inn) unhilightBuildingOnPanel(Inn)").type==ErrorReport::ET_OK);
        w.step(); CHECK(w.world.gui.highlights.empty());
    }

}
