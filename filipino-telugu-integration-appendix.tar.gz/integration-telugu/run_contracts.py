from pathlib import Path
import subprocess,os,json,hashlib,time,concurrent.futures
R=Path.cwd();O=R/'artifacts/filipino-localization/integration-telugu';H='827a22d2a8659e265d877962c1d64913aff88f44';E=dict(os.environ,PATH='/home/bradley/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH'])
def guard():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==H
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
def run(case):
 n,a,cwd=case;guard();p=O/(n+'.log');t=time.monotonic()
 with p.open('x') as f:q=subprocess.run(a,cwd=cwd,env=E,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 guard();return {'name':n,'argv':a,'cwd':str(cwd),'exit_code':q.returncode,'seconds':time.monotonic()-t,'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
C=[('strict-native',['python3','data/check_translations.py','--strict'],R),('font',['python3','test/test_font_coverage.py'],R),('online-strict',['npm','run','i18n:check'],R/'platform'),('i18n-units',['npm','test','--','packages/i18n/test'],R/'platform'),('merge-format',['npx','--no-install','prettier','--check','apps/web/e2e/i18n.spec.ts','packages/i18n/src/index.ts','packages/i18n/src/locales.ts','packages/i18n/test/runtime.test.ts'],R/'platform')]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(run,C))
r={'actual_revision':H,'commands':rows,'all_passed':all(x['exit_code']==0 for x in rows),'scope':'Affected Telugu/Filipino registry, aliases, strict contracts and unchanged Latin font coverage. Prior6390pair reviews and fullmatrix remain source/target/font-function identical; no repeated API draft or fullmatrix.'};(O/'contracts.json').write_text(json.dumps(r,indent=2)+'\n');print(r['all_passed'],flush=True);raise SystemExit(0 if r['all_passed'] else 1)
