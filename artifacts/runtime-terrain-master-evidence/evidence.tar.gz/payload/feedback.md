# Master material-renderer integration review

Both original reviewers returned to resolve and review actual conflicts with master `d7e3af8ec` (#795).

- The simulation reviewer moved frozen serialized presentation fields into private registry storage, preserved the field-wise digest, and corrected map editing/loading to use registry-scoped compatibility rather than global built-in lookup. Obsolete visual-profile storage was removed. A final lookup audit covered simulation, reports, image import/export and rendering adapters.
- The presentation reviewer retained the material compositor, cached shipped appearance IDs in scenes, limited legacy corner adapters to built-in canonical IDs, preserved registry identity in render caches, and used embedded custom colors alongside catalog built-in palettes. Tests cover all 16 wrapped neighbor masks with custom aliases, whole-cell identity, thumbnail palettes and software/OpenGL/HD cache invalidation after reimport.
- The parent reviewed the integration, updated development/material/map-authoring documentation, corrected a test fixture call, rebuilt affected executables, and ran the attached suites and renderer scaling measurements.

The earlier 24% software-frame improvement refers to the previous renderer at `7afc0e1c2`, not the final material integration. Historical evidence remains linked separately; final-renderer measurements use the current binary consistently.
