import concurrent.futures,json,pathlib,subprocess,shlex
out=pathlib.Path(__file__).resolve().parent
commands=json.loads((out/'standalone-commands.json').read_text())
def run(entry):
    with (out/(entry['name']+'.log')).open('w') as log:
        log.write('$ '+shlex.join(entry['command'])+'\n');log.flush()
        result=subprocess.run(entry['command'],stdout=log,stderr=subprocess.STDOUT)
        log.write('\nexit_code='+str(result.returncode)+'\n')
    print(entry['name'],result.returncode,flush=True)
    return result.returncode
def variant(i):
    result=run(commands[i])
    if result==0:result=run(commands[i+2])
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    statuses=list(pool.map(variant,[0,1]))
raise SystemExit(any(statuses))
