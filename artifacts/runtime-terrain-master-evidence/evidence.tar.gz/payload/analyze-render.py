import csv,json,random,statistics
from pathlib import Path
p=Path(__file__).resolve().parent
rows=list(csv.DictReader((p/'render-pairs/measurements.csv').open()));rows=[r for r in rows if int(r['round'])>=0]
results={'rounds':len({r['round'] for r in rows}),'load_range':[min(float(r['load_before']) for r in rows),max(float(r['load_after']) for r in rows)],'cases':{},'comparisons':[]}
for name in ['7','259','1024','16384']:
 group=[r for r in rows if r['case']==name]
 results['cases'][name]={field:statistics.median(float(r[field]) for r in group) for field in ['cpu_ms_frame','elapsed_wall_ns','max_rss_kib']}
rng=random.Random(2026)
for name,base in [('259','7'),('1024','259'),('16384','259'),('16384','7')]:
 for field in ['cpu_ms_frame','max_rss_kib']:
  by={r['round']:float(r[field]) for r in rows if r['case']==base}
  deltas=[100*(float(r[field])/by[r['round']]-1) for r in rows if r['case']==name]
  boot=sorted(statistics.mean(rng.choices(deltas,k=len(deltas))) for _ in range(10000))
  results['comparisons'].append({'case':name,'base':base,'metric':field,'pairs':len(deltas),'mean_paired_delta_percent':statistics.mean(deltas),'bootstrap_95_interval_percent':[boot[249],boot[9749]]})
(p/'render-analysis.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
