from pathlib import Path
import hashlib, tarfile, shutil, json
from PIL import Image
root=Path.cwd(); src=root/'artifacts/terrain-runtime-master-integration'; out=root/'artifacts/runtime-terrain-master-evidence'; dst=out/'payload'; dst.mkdir(parents=True,exist_ok=True)
def copy(a,b): b.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(a,b)
exclude={'build-preliminary.log','package-policy.log','package-assets.log'}
for f in src.iterdir():
 if f.is_file() and f.suffix in {'.log','.xml','.json','.py','.md'} and f.name not in exclude: copy(f,dst/f.name)
for name in ['render-pairs','integrated-old-replay','integrated-custom-replay']:
 for f in (src/name).rglob('*'):
  if f.is_file() and 'profile' not in f.parts: copy(f,dst/f.relative_to(src))
shots=root/'artifacts/tests/EditorActionCoverage/custom_terrain_imports_palettes_and_saved_maps_work_on_desktop_and_phone_display_artifacts'
for f in shots.glob('*.bmp'):
 target=out/'screenshots'/f.with_suffix('.png').name;target.parent.mkdir(parents=True,exist_ok=True);Image.open(f).save(target);copy(target,dst/'screenshots'/target.name)
for name in ['sdl3-manifest.json']:
 copy(root/'artifacts/terrain-runtime-review'/name,dst/name)
for name in ['scalar-tests.log','arm64-tests.log']:
 assert 'SUCCESS!' in (dst/name).read_text()
with (dst/'manifest.sha256').open('w') as f:
 for p in sorted(dst.rglob('*')):
  if p.is_file() and p.name!='manifest.sha256': f.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(dst))+'\n')
with tarfile.open(out/'evidence.tar.gz','w:gz') as t:t.add(dst,arcname='payload')
f=out/'evidence.tar.gz';(out/'archive.sha256').write_text(hashlib.sha256(f.read_bytes()).hexdigest()+'  evidence.tar.gz\n')
print(f.stat().st_size)
