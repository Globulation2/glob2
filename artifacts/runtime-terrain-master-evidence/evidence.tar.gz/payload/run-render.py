from pathlib import Path
import os, subprocess, time, json
p=Path(__file__).resolve().parent
while not (p/'correctness-complete').exists(): time.sleep(2)
env=dict(os.environ,LD_LIBRARY_PATH=str(Path('build/runtime-terrain-sdl/prefix/lib').resolve()),SDL_VIDEODRIVER='x11')
cmd=['xvfb-run','-a','python3',str(p/'render-bench.py')]
(p/'render-command.json').write_text(json.dumps({'command':cmd,'environment':{k:env[k] for k in ['LD_LIBRARY_PATH','SDL_VIDEODRIVER']}},indent=2)+'\n')
with (p/'render.log').open('w') as f: subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
(p/'render-complete').write_text('complete\n')
