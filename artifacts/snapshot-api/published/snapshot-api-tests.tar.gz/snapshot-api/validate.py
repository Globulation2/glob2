"""Local snapshot API validation; raw commands/results are retained alongside this script."""
import argparse, hashlib, json, os, statistics, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
STUDY = ROOT / 'artifacts/snapshot-demand'
sys.path.insert(0, str(ROOT / 'test'))
from benchmark_parallel_compute import execute, digest
BASE = STUDY / 'glob2-baseline'
CANDIDATE = OUT / 'glob2-candidate'
CASES = {
    'inactive-64': ('ordinary-control.game', None, 8192),
    'numbi-64': ('small.map.gz', ['numbi','numbi'], 8192),
    'castor-64': ('small.map.gz', ['castor','castor'], 8192),
    'warrush-64': ('small.map.gz', ['warrush','warrush'], 8192),
    'mixed-128': ('large.map.gz', ['numbi','castor','cortex','nicowar'], 8192),
    'large-colony': ('large-colony.game', None, 512),
}
def arguments(case, workers=1):
    name, players, ticks = CASES[case]
    args = ['--ticks',str(ticks),'--benchmark-warmup',str(min(256,ticks//4)),
            '--compute-threads',str(workers),'--gpu','off','--compute-telemetry','off']
    path = str(STUDY/'fixtures'/name)
    args += ['--map-file',path,'--game-seed','713'] if players else ['--load-game',path]
    for player in players or []: args += ['--player',player]
    return args

def run(binary,args,path):
    result=execute(binary,args,path)
    report=result.pop('result')
    result['metrics']={k:report[k] for k in ('ticks','termination','run_ns','benchmark_run_cpu_ns',
        'benchmark_measured_ticks','tick_p50_ns','tick_p95_ns','tick_p99_ns','ai_pipeline') if k in report}
    (path/'execution.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

def correctness():
    os.environ['GLOB2_SNAPSHOT_VERIFY']='1'
    comparisons=[]
    for workers in (1,4):
        for case in CASES:
            if workers==4 and case not in ('castor-64','mixed-128'): continue
            out=OUT/'capture-verification'/f'{case}-{workers}'
            run(CANDIDATE,arguments(case,workers)+['--telemetry','checksums','--write-replay'],out)
            names=['game.replay.checksums','game.replay']
            hashes={name:{'baseline':digest(STUDY/'baseline'/case/name),'candidate':digest(out/name)} for name in names}
            # Saved-fixture replay headers can contain existing run-varying metadata;
            # simulation sidecars must always match, and replay mismatches are reported.
            assert hashes['game.replay.checksums']['baseline']==hashes['game.replay.checksums']['candidate'],(case,workers)
            comparisons.append({'case':case,'workers':workers,'hashes':hashes})
            print('PASS capture verification',case,workers,flush=True)
    (OUT/'capture-verification/summary.json').write_text(json.dumps(comparisons,indent=2)+'\n')

def timing(repeats):
    os.environ.pop('GLOB2_SNAPSHOT_VERIFY',None)
    rows=[]
    for case in CASES:
        for repeat in range(-1,repeats):
            variants=[('baseline',BASE),('candidate',CANDIDATE)]
            if repeat%2: variants.reverse()
            for variant,binary in variants:
                out=OUT/'timing'/case/str(repeat)/variant
                row=run(binary,arguments(case),out)
                row.update(case=case,repeat=repeat,variant=variant)
                rows.append(row)
                print(case,repeat,variant,round(row['cpu_s'],4),flush=True)
                (OUT/'timing/rows.json').write_text(json.dumps(rows,indent=2)+'\n')
    summary={}
    for case in CASES:
        selected=[row for row in rows if row['case']==case and row['repeat']>=0]
        values={variant:{key:statistics.median(r[key] for r in selected if r['variant']==variant)
            for key in ('cpu_s','wall_s','peak_rss_bytes')} for variant in ('baseline','candidate')}
        for variant in values:
            values[variant]['simulation_cpu_s']=statistics.median(r['metrics']['benchmark_run_cpu_ns']/1e9 for r in selected if r['variant']==variant)
            values[variant]['tick_p95_ns']=statistics.median(r['metrics']['tick_p95_ns'] for r in selected if r['variant']==variant)
        for key in ('cpu_s','wall_s','peak_rss_bytes','simulation_cpu_s','tick_p95_ns'):
            values[key+'_change_percent']=100*(values['candidate'][key]/values['baseline'][key]-1)
        summary[case]=values
    (OUT/'timing/summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('phase',choices=('correctness','timing'))
    parser.add_argument('--repeats',type=int,default=5)
    args=parser.parse_args()
    correctness() if args.phase=='correctness' else timing(args.repeats)
