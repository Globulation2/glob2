import hashlib,json,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'artifacts/snapshot-api'
PACK=OUT/'published'
PACK.mkdir(exist_ok=True)

def package(name, paths):
    dest=PACK/(name+'.tar.gz')
    with tarfile.open(dest,'w:gz',compresslevel=6) as tar:
        seen={}
        def add(path):
            if not path.exists(): return
            name=str(path.relative_to(ROOT/'artifacts'))
            if path.is_dir():
                tar.add(path,arcname=name,recursive=False)
                for child in sorted(path.iterdir()): add(child)
                return
            key=None
            if path.is_file() and not path.is_symlink() and path.stat().st_size>=1024:
                h=hashlib.sha256()
                with path.open('rb') as stream:
                    for data in iter(lambda:stream.read(1024*1024),b''):h.update(data)
                key=(path.stat().st_size,h.digest())
            if key is not None and key in seen:
                entry=tar.gettarinfo(path,arcname=name)
                entry.type=tarfile.LNKTYPE;entry.linkname=seen[key];entry.size=0
                tar.addfile(entry)
            else:
                tar.add(path,arcname=name,recursive=False)
                if key is not None:seen[key]=name
        for path in paths:add(path)
    result={'file':dest.name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}
    assert result['bytes']<100_000_000,result
    print(result,flush=True)
    return result

metadata=[p for p in OUT.iterdir() if p.is_file() and p.suffix in ('.py','.json','.xml','.log','.txt','.patch')]
reports=[]
reports.append(package('snapshot-api-tests',metadata+[OUT/'native',OUT/'additional-native',OUT/'gradient-retry',OUT/'gradient-legacy-probe',OUT/'gradient-full-probe']))
reports.append(package('snapshot-api-simulation',[OUT/'simulation-equivalence',OUT/'parallel-equivalence']))
reports.append(package('snapshot-api-capture',[OUT/'capture-verification',ROOT/'artifacts/snapshot-demand/fixtures',ROOT/'artifacts/snapshot-demand/baseline',ROOT/'artifacts/snapshot-demand/baseline-metadata.json']))
reports.append(package('snapshot-api-timings',[OUT/'timing']))
(PACK/'manifest.json').write_text(json.dumps({'head':'f9a9f765f3ea33d741db5cf399d16131be4b7132','base':'277510840054b1416f2defd7d86fe1431dd0ddc0','archives':reports},indent=2)+'\n')
