#include "field/RuntimeTerrainGradient.h"
#include <nlohmann/json.hpp>
#include <chrono>
#include <ctime>
#include <functional>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
#include <stdexcept>

using namespace gradient_kernel;
using WallClock=std::chrono::steady_clock;
struct Clock {
    using duration=std::chrono::nanoseconds;
    using rep=duration::rep;
    using period=duration::period;
    using time_point=std::chrono::time_point<Clock>;
    static constexpr bool is_steady=true;
    static time_point now(){timespec t;clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t);return time_point(duration(int64_t(t.tv_sec)*1000000000+t.tv_nsec));}
};


volatile uint64_t sink;

// Opaque call boundary also prevents repeated timing iterations being hoisted.
template<int Mode> [[gnu::noinline]] uint64_t lookup(const uint16_t* ids,const uint32_t* order,size_t n,const TerrainProperties* defs,const EntrySteps* costs,unsigned sole)
{
    uint64_t sum=0;
    for(size_t i=0;i<n;++i) {
        unsigned id=ids[order[i]];
        if constexpr(Mode==0) {const auto& p=TERRAIN_PROPERTIES[id];sum+=p.groundSpeedQ8+p.growthQ8+p.groundHealthQ8+p.buildable;}
        if constexpr(Mode==1) {const auto& p=defs[id];sum+=p.groundSpeedQ8+p.growthQ8+p.groundHealthQ8+p.buildable;}
        if constexpr(Mode==2) sum+=terrainUsesSwimming(static_cast<TerrainType>(id));
        if constexpr(Mode==3) sum+=defs[id].swimmable;
        if constexpr(Mode==4) sum+=id==sole;
        if constexpr(Mode==5) sum+=TERRAIN_ENTRY_COSTS[4][id].cardinal;
        if constexpr(Mode==6) sum+=costs[id].cardinal;
        if constexpr(Mode==7) {const auto& p=defs[id];sum+=scaledTerrainStep(p.swimmable?WATER_STEP[4]:GRADIENT_STEP,p.groundSpeedQ8);}
    }
    return sum;
}
struct Job {std::string name;std::function<uint64_t()> run;uint64_t expected;size_t units;int reps=1;};
void measure(std::vector<Job>& jobs,unsigned seed)
{
    for(auto& j:jobs) {
        if(j.run()!=j.expected) throw std::runtime_error(j.name+" checksum mismatch");
        auto begin=Clock::now();
        for(int i=0;i<3;++i) sink=j.run();
        double t=std::chrono::duration<double>(Clock::now()-begin).count()/3;
        j.reps=std::clamp(int(.10/t),1,2000);
    }
    std::mt19937 rng(seed);
    std::vector<unsigned> order(jobs.size());std::iota(order.begin(),order.end(),0);
    for(int round=0;round<15;++round) {
        std::shuffle(order.begin(),order.end(),rng);
        for(auto k:order) {
            auto& j=jobs[k];
            auto wallBegin=WallClock::now();
            auto begin=Clock::now();
            for(int i=0;i<j.reps;++i) sink=j.run();
            double ns=std::chrono::duration<double,std::nano>(Clock::now()-begin).count()/j.reps;
            double wallNs=std::chrono::duration<double,std::nano>(WallClock::now()-wallBegin).count()/j.reps;
            std::cout<<seed<<','<<round<<','<<j.name<<','<<j.units<<','<<j.reps<<','<<ns<<','<<j.expected<<','<<wallNs<<'\n';
        }
    }
}
uint64_t hash(const std::vector<uint16_t>& values) {uint64_t h=1469598103934665603ull;for(auto v:values) h=(h^v)*1099511628211ull;return h;}

int main(int argc,char**argv) {
 unsigned seed=argc>1?std::stoul(argv[1]):11;
 std::mt19937 rng(seed);
 std::cout<<"seed,round,case,units,reps,ns,checksum,wall_ns\n";
 using Json=nlohmann::json;
 std::vector<std::shared_ptr<const TerrainRegistry>> registries{TerrainRegistry::builtins()};
 for(unsigned count:{259,1024,16384}) {
  Json entries=Json::array();
  for(unsigned i=7;i<count;++i) {
   const auto base=TerrainPresentations[(i-7)%5].name;
   entries.push_back({{"key","bench:t"+std::to_string(i)},{"name","Benchmark"},{"base",base},{"appearance",base},{"properties",Json::object()}});
  }
  registries.push_back(TerrainRegistry::builtins()->importJson(Json{{"schemaVersion",1},{"terrains",entries}}.dump()));
 }
 for(int width:{256,512}) {
  size_t n=size_t(width)*width;
  std::vector<TerrainType> types(n);
  std::vector<uint16_t> seeds(n,1),out(n),reference;
  for(size_t i=0;i<n;++i){types[i]=TerrainType(rng()%5);if(rng()%20==0)seeds[i]=0;}
  for(int i=0;i<8;++i)seeds[rng()%n]=GRADIENT_AT_GOAL;
  std::vector<std::vector<TerrainType>> expanded(4,types);
  for(unsigned k=1;k<4;++k){
   std::array<std::vector<TerrainType>,5> equivalent;
   for(unsigned t=0;t<registries[k]->size();++t){
    for(unsigned b=0;b<5;++b)
      if(registries[k]->movement(4).entries[t].cardinal==TERRAIN_ENTRY_COSTS[4][b].cardinal && registries[k]->properties(TerrainType(t)).swimmable==TERRAIN_PROPERTIES[b].swimmable)
       equivalent[b].push_back(TerrainType(t));
   }
   for(size_t i=0;i<n;++i){auto& eq=equivalent[types[i]];expanded[k][i]=eq[rng()%eq.size()];}
  }
  std::vector<std::vector<uint8_t>> profiles(4,std::vector<uint8_t>(n)),unusedProfiles=profiles;
  std::array<TerrainRegistry::Movement,4> active,unused;
  auto compact=[&](const std::vector<TerrainType>& ids, const TerrainRegistry& registry,std::vector<uint8_t>& cells,TerrainRegistry::Movement& movement){
   std::array<unsigned,256> remap;remap.fill(256);std::array<bool,256> used{};
   for(size_t i=0;i<n;++i){const auto old=registry.movement(4).profileIds[ids[i]];auto& p=remap[old];if(p==256){p=movement.profiles.size();auto c=registry.movement(4).profiles[old];movement.profiles.push_back(c);for(auto step:{c.cardinal,c.diagonal})if(!used[step]){used[step]=true;movement.steps.push_back(step);}}cells[i]=p;}
   movement.prepare();
  };
  for(unsigned k=0;k<4;++k){compact(expanded[k],*registries[k],profiles[k],active[k]);compact(types,*registries[k],unusedProfiles[k],unused[k]);}
  GradientWorkspace work;
  std::vector<Job> jobs;
  auto add=[&](std::string name,std::function<uint64_t()> fn){auto result=fn();if(reference.empty())reference=out;else if(reference!=out)throw std::runtime_error("field mismatch");jobs.push_back({std::to_string(width)+"/"+name,fn,result,n});};
  add("static",[&]{out=seeds;propagateTerrainField(out.data(),4,COST_LIMIT,{width,width},work,[&](size_t i){return types[i];},true);return uint64_t(out[n/3])+out[n/2]+out.back();});
  for(unsigned k=0;k<4;++k)for(bool used:{false,true}) {
   if(k==0&&used)continue;
   add(std::to_string(registries[k]->size())+(used?"/used":"/unused"),[&,k,used]{out=seeds;if(k==0)propagateTerrainField(out.data(),4,COST_LIMIT,{width,width},work,[&](size_t i){return types[i];},true,*registries[k],64);else propagateTerrainProfiles(out.data(),4,COST_LIMIT,{width,width},work,(used?profiles[k]:unusedProfiles[k]).data(),used?active[k]:unused[k],64);return uint64_t(out[n/3])+out[n/2]+out.back();});
  }
  measure(jobs,seed);
 }
 Json stress=Json::array();
 for(unsigned i=7;i<16384;++i)stress.push_back({{"key","stress:t"+std::to_string(i)},{"name","Stress"},{"base","water"},{"appearance","water"},{"properties",{{"groundSpeedQ8",64+(i%961)}}}});
 auto registry=TerrainRegistry::builtins()->importJson(Json{{"schemaVersion",1},{"terrains",stress}}.dump());
 std::vector<uint8_t> profile(256*256);for(auto& p:profile)p=rng()%registry->movement(6).profiles.size();
 std::vector<uint16_t> seeds(profile.size(),1),out;seeds[0]=GRADIENT_AT_GOAL;GradientWorkspace work;
 auto stressRun=[&]{out=seeds;propagateTerrainProfiles(out.data(),6,COST_LIMIT,{256,256},work,profile.data(),*registry,256);return hash(out);};
 std::vector<Job> stressJobs{{"256/distinct-16384-256b",stressRun,stressRun(),profile.size()}};
 measure(stressJobs,seed);

}
