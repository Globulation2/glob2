import csv,json,random,statistics,math
from pathlib import Path
p=Path(__file__).resolve().parent
rng=random.Random(20261005)
def paired(rows,case,base,metric):
 a={int(x['round']):float(x[metric]) for x in rows if x['case']==case and int(x['round'])>=0}
 b={int(x['round']):float(x[metric]) for x in rows if x['case']==base and int(x['round'])>=0}
 ds=[100*(a[k]/b[k]-1) for k in sorted(a.keys()&b.keys())]
 samples=sorted(statistics.mean(rng.choices(ds,k=len(ds))) for _ in range(5000))
 return {'case':case,'base':base,'metric':metric,'pairs':len(ds),'mean_paired_delta_percent':statistics.mean(ds),'median_paired_delta_percent':statistics.median(ds),'bootstrap_mean_95_interval_percent':[samples[124],samples[4874]],'paired_delta_percent':ds}
def main():
 result={}
 for section,filename,metrics in [('full_match','full-match-pairs/measurements.csv',['cpu_ns','run_wall_ns','max_rss_kib','setup_cpu_ns']),('render','render-pairs/measurements.csv',['cpu_ms_frame','elapsed_wall_ns','max_rss_kib'])]:
  f=p/filename
  if not f.exists():continue
  rows=list(csv.DictReader(f.open()));rows=[x for x in rows if int(x['round'])>=0]
  result[section]={'paired':[paired(rows,c,b,m) for m in metrics for c,b in [('candidate','baseline'),('7','candidate'),('259','7'),('1024','7'),('16384','7')]],'absolute':{c:{m:statistics.median(float(x[m]) for x in rows if x['case']==c) for m in metrics} for c in ['baseline','candidate','7','259','1024','16384']},'load_range':[min(float(x['load_before']) for x in rows),max(float(x['load_before']) for x in rows)]}
 f=p/'kernel-final.log'
 if f.exists():
  rows=list(csv.DictReader(f.open()));cases=sorted(set(x['case'] for x in rows));result['kernel']={'paired':[paired(rows,c,c.split('/')[0]+'/static',m) for c in cases if 'static' not in c and 'distinct' not in c for m in ['ns','wall_ns']],'absolute_ns':{c:statistics.median(float(x['ns']) for x in rows if x['case']==c) for c in cases}}
 (p/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
 for section,value in result.items():
  print(section)
  for x in value['paired']:
   if x['metric'] in ['cpu_ns','cpu_ms_frame','ns']:print(x['case'],'vs',x['base'],round(x['mean_paired_delta_percent'],2),[round(v,2) for v in x['bootstrap_mean_95_interval_percent']])
if __name__=='__main__':main()
