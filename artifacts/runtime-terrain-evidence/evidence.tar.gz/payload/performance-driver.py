from pathlib import Path
import subprocess
out=Path('artifacts/terrain-runtime-implementation').resolve()
for name,cmd in [('full-match-pairs',['python3',str(out/'full-match-bench.py')]),('kernel-final',['taskset','-c','29',str(out/'kernel-bench'),'47']),('render-final',['xvfb-run','-a','python3',str(out/'render-bench.py')])]:
 print(name,flush=True)
 with (out/(name+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
(out/'native-qualification-completed').write_text('completed\n')
