import csv,json,os,random,subprocess,time,platform
from pathlib import Path
root=Path.cwd(); evidence=root/'artifacts/terrain-runtime-implementation'; output=evidence/'full-match-pairs'; output.mkdir(exist_ok=True)
base=evidence/'baseline/build/linux/client/release/src/glob2'; candidate=root/'build/linux/client/release/src/glob2'
fixtures=root/'artifacts/tests/TerrainRuntime/write_equivalent_custom_maps_for_paired_performance_runs_benchmark_artifacts'
cases=[('baseline',base,root/'maps/FourSquares1.map.gz'),('candidate',candidate,root/'maps/FourSquares1.map.gz')]+[(str(n),candidate,fixtures/f'equivalent-{n}.map') for n in (7,259,1024,16384)]
rng=random.Random(2026)
expected_state=None
case_checksums={}
fields=['round','case','ticks','cpu_ns','run_wall_ns','setup_cpu_ns','elapsed_wall_ns','max_rss_kib','termination','load_before','load_after','checksum']
with (output/'measurements.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();f.flush()
 for iteration in range(-1,10):
  order=cases.copy();rng.shuffle(order)
  for name,binary,mapfile in order:
   directory=output/f'{iteration+1:02d}-{name}';directory.mkdir(exist_ok=True)
   cmd=[str(binary),'--run-game','--map-file',str(mapfile),'--game-seed','2026']
   for _ in range(4):cmd+=['--player','warrush']
   cmd+=['--ticks','90000','--benchmark-warmup','1000','--compute-threads','1','--gradient-workers','0','--gradient-delay','8','--output-dir',str(directory)]
   (directory/'command.json').write_text(json.dumps(cmd,indent=2))
   before=os.getloadavg()[0];start=time.perf_counter_ns()
   with (directory/'run.log').open('w') as log:
    subprocess.run(['/usr/bin/time','-f','%M','-o',str(directory/'rss.txt')]+['taskset','-c','29']+cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
   elapsed=time.perf_counter_ns()-start;j=json.loads((directory/'result.json').read_text())
   state={k:j[k] for k in ['ticks','game_seed','termination','resolved','players','teams','winning_teams','winning_alliances','unresolved']}
   state['resolved']=dict(state['resolved']);state['resolved'].pop('save_version',None)
   if expected_state is None:expected_state=state
   elif state!=expected_state:raise RuntimeError('Non-equivalent simulation outcome: '+name)
   signature=(j['initialChecksum'],j['finalChecksum'])
   if name in case_checksums and case_checksums[name]!=signature:raise RuntimeError('Non-repeatable simulation: '+name)
   case_checksums[name]=signature
   row=dict(round=iteration,case=name,ticks=j['ticks'],cpu_ns=j['benchmark_run_cpu_ns'],run_wall_ns=j['run_ns'],setup_cpu_ns=j['benchmark_setup_cpu_ns'],elapsed_wall_ns=elapsed,max_rss_kib=int((directory/'rss.txt').read_text()),termination=j['termination'],load_before=before,load_after=os.getloadavg()[0],checksum=j['finalChecksum'])
   writer.writerow(row);f.flush();print(json.dumps(row),flush=True)
