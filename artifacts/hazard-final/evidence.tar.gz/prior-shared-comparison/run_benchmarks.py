import argparse, csv, hashlib, json, os, platform, statistics, subprocess, time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
base=Path('/home/bradley/.codex/worktrees/hazard-performance-base/glob2')
previous=root/'artifacts/hazard-performance/binaries'
binaries={'baseline':previous/'current-glob2','current':root/'build/linux/client/release/src/glob2'}
harnesses={'baseline':previous/'current-harness','current':root/'build/linux/client/release/test/glob2-engine-tests'}
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_TEST_SOURCE_ROOT=str(root))
parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['micro','games']);parser.add_argument('--output-dir',type=Path);args=parser.parse_args()
fixtures=root/'artifacts/hazard-performance/fixtures'
if args.output_dir:
    out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
def run(cmd,log,extra=None,timeout=300):
    e=dict(env,**(extra or {}))
    with log.open('w') as f:
        subprocess.run(cmd,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=timeout)
rows=[]
if args.mode=='micro':
    for round in range(2):
        for version in (['baseline','current'] if round%2==0 else ['current','baseline']):
            log=out/f'micro-{version}-{round}.log'
            cmd=['taskset','-c','12',str(harnesses[version]),'-ts=TerrainHazardBenchmark','-tc=*idle decisions*,*shared terrain fields*','--no-breaks=true']
            run(cmd,log,timeout=600)
            for line in log.read_text().splitlines():
                if not line.startswith('hazard_bench,'):continue
                c=next(csv.reader([line]))
                if c[1]=='kind':continue
                rows.append(dict(version=version,round=round,kind=c[1],layout=c[2],width=int(c[3]),repeat=int(c[4]),iterations=int(c[5]),cpu_ns=float(c[6]),wall_ns=float(c[7])))
            (out/'micro-results.json').write_text(json.dumps(rows,indent=2)+'\n')
            print('finished micro',version,round,flush=True)
else:
    for repeat in range(7):
        for layout in ['control','sparse-ice','patchwork-ice']:
            for version in (['baseline','current'] if repeat%2==0 else ['current','baseline']):
                directory=out/'games'/f'{layout}-{repeat}-{version}'
                cmd=['taskset','-c','12-14',str(binaries[version]),'--run-game','--load-game',str(fixtures/f'{layout}.game'),
                    '--ticks','90640','--benchmark-warmup','128','--compute-threads','1','--gradient-workers','2','--replay','false','--output-dir',str(directory)]
                run(cmd,out/f'game-{layout}-{repeat}-{version}.log',{'GLOB2_USER_DATA_DIR':str(out/'profiles'/f'{layout}-{repeat}-{version}')})
                result=json.loads((directory/'result.json').read_text())
                assert result['benchmark_measured_ticks']==512,result.get('ticks')
                rows.append(dict(version=version,layout=layout,repeat=repeat,cpu_ns=result['benchmark_run_cpu_ns'],ticks=result['benchmark_measured_ticks'],cpu_ns_per_tick=result['benchmark_run_cpu_ns']/result['benchmark_measured_ticks'],wall_ns=result['run_ns'],initial_checksum=result['initialChecksum'],final_checksum=result['finalChecksum'],command=cmd))
                (out/'game-results.json').write_text(json.dumps(rows,indent=2)+'\n')
                print('finished game',layout,repeat,version,round(rows[-1]['cpu_ns_per_tick']/1e6,3),'ms/tick',flush=True)
