#!/usr/bin/env bash
set -eu
python3 test/run_tests.py -j4 --filter 'TerrainHazardRouting/*' --filter 'TerrainProperties/*' --filter 'TerrainRuntime/*' --filter 'TerrainRegistry/*' --filter 'PathGradient/*' --filter 'UnitContinuation/*' --artifacts artifacts/hazard-final/test-artifacts --junit artifacts/hazard-final/focused.xml > artifacts/hazard-final/focused.log 2>&1
python3 test/run_tests.py -j4 --filter '*Gradient*/*' --filter '*Save*/*' --filter '*Replay*/*' --filter '*Version*/*' --filter '*Resource*/*' --filter 'MapQuery/*' --filter 'JavaScriptCompatibility/*' --filter 'TurnEngineHarness/*' --exclude-tag benchmark --no-display --artifacts artifacts/hazard-final/test-artifacts --junit artifacts/hazard-final/compatibility.xml > artifacts/hazard-final/compatibility.log 2>&1
