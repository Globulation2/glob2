import hashlib,json,platform,subprocess,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
root=Path.cwd(); out=root/'artifacts/hazard-final'
metadata={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'base':subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip(),'platform':platform.platform(),'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'build':'GLOB2_SDL3_PREFIX=/tmp/glob2-terrain-sdl-patched/prefix CCACHE=1 scons -j8 release=1 optimized_assets=0 tests build/linux/client/release/src/glob2','dependencies':'LD_LIBRARY_PATH=/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib; compile/link commands retained in build logs','tests':{},'limits':['Linux x86_64 only locally; hosted platform checks requested separately.','Native browser replay fixture recording verified; local browser playback not run.','141 display cases skipped; --quick excludes slow cases and benchmarks were separately measured. Human gameplay feel review unverified.','Earlier paired performance results precede the master resource integration; final microbenchmark separately recorded.']}
for name in ['focused','quick','golden','resource-golden','png-runtime']:
 cases=list(ET.parse(out/(name+'.xml')).iter('testcase'));metadata['tests'][name]={'cases':len(cases),'failures':sum(c.find('failure') is not None or c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases)}
metadata['binaries']={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ['build/linux/client/release/src/glob2','build/linux/client/release/test/glob2-engine-tests','build/linux/client/release/test/glob2-unit-tests']}
metadata['commands']={'quick':'LD_LIBRARY_PATH=/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib python3 test/run_tests.py -j8 --quick --exclude-tag benchmark --no-display --artifacts artifacts/hazard-final/quick-artifacts --junit artifacts/hazard-final/quick.xml','micro':'LD_LIBRARY_PATH=/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy GLOB2_TEST_SOURCE_ROOT=$PWD taskset -c 12 build/linux/client/release/test/glob2-engine-tests -ts=TerrainHazardBenchmark -tc=*idle\ decisions*,*shared\ terrain\ fields* --no-breaks=true','sim_version':'python3 test/check_sim_revision.py --base origin/master'}
metadata['continuation']=json.loads((out/'continuation.json').read_text())
(out/'verification.json').write_text(json.dumps(metadata,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz','w:gz') as tar:
 for path in sorted(out.iterdir()):
  if path.name in ['evidence.tar.gz','build.log','test-artifacts','quick-artifacts','old-safety.cpp','resolve.py'] or path.name.endswith('-profile') or path.name=='browser-profile':continue
  if path.is_dir() and not path.name.startswith('continuation-patched-'):continue
  tar.add(path,arcname='hazard-final/'+path.name)
 for name in ['summary.json','micro-results.json','game-results.json','run_benchmarks.py','verification.json','report.html']:
  tar.add(root/'artifacts/hazard-shared'/name,arcname='prior-shared-comparison/'+name)
 tar.add(root/'artifacts/hazard-performance/fixtures/patchwork-ice.game',arcname='inputs/patchwork-ice-format139.game')
print(json.dumps(metadata['tests'],indent=2))
print('Archive bytes:',(out/'evidence.tar.gz').stat().st_size)
