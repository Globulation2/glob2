#!/usr/bin/env python3
import argparse,csv,hashlib,json,os,platform,re,statistics,subprocess,tempfile,time
from pathlib import Path
ROOT=Path.cwd(); OUT=ROOT/'artifacts/metal-stalls'; SHADERS=ROOT/'artifacts/metal-vs-opengl/shaders'
SCENARIOS={'motion':{'GLOB2_BENCH_ZOOM':'0.25','GLOB2_BENCH_CAMERA_MOTION':'1'},'overview':{'GLOB2_BENCH_ZOOM':'0.25'},'closeup':{'GLOB2_BENCH_ZOOM':'1','GLOB2_BENCH_UNITS':'400'},'saved-match':{'GLOB2_BENCH_GAME':str(ROOT/'games/gd-bigarena-long.game.gz'),'GLOB2_BENCH_FULL_MAP':'1'}}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--repeat',type=int,default=7);p.add_argument('--scenario',action='append',choices=SCENARIOS);p.add_argument('--output',type=Path,default=OUT/'retake');a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=True)
report={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'baseline_revision':'532292686e9eb12ad49cbaf319d9b7062ce2a4b6','platform':platform.platform(),'hardware':'Apple M3 MacBook Air, 24 GiB, 10 GPU cores','baseline_sha256':digest(OUT/'baseline'),'candidate_sha256':digest(OUT/'candidate'),'shaders_sha256':digest(SHADERS/'metadata.json'),'fixture_sha256':digest(ROOT/'games/gd-bigarena-long.game.gz'),'build_command':'GLOB2_RENDER_SHADER_INPUT="$PWD/artifacts/metal-vs-opengl/shaders" python3 tools/dev_build.py dev_fast=0 release=1 torus-render-benchmark engine-tests','build_log_sha256':digest(OUT/'build-retake.log'),'frames':240,'warmup':120,'repeat':a.repeat,'method':'Each cloud mode in a fresh process and isolated profile, same 120 warmup and 240 measured camera frames; alternate cloud and binary order across pairs. Completion/readback inclusive; excludes simulation, extraction and final presentation. No builds/tests/profilers/other Glob2 instances during timings.','thermal_before':subprocess.check_output(['pmset','-g','therm'],text=True),'runs':[],'summary':[]}
for scenario in a.scenario or ['motion']:
 for pair in range(a.repeat):
  modes=['2D no clouds','2D clouds'] if pair%2==0 else ['2D clouds','2D no clouds']
  labels=['baseline','candidate','legacy-gl'] if pair%2==0 else ['legacy-gl','candidate','baseline']
  for mode in modes:
   for label in labels:
    name=f'{scenario}-{pair}-{label}-'+('clouds' if mode=='2D clouds' else 'no-clouds')
    with tempfile.TemporaryDirectory(prefix='glob2-stalls-fresh-') as profile:
     env={k:v for k,v in os.environ.items() if not k.startswith(('GLOB2_BENCH_','PROFILE_'))}
     env.update(GLOB2_USER_DATA_DIR=profile,GLOB2_UI_SCALE='1',GLOB2_RENDERER_SHADER_DIR=str(SHADERS),GLOB2_BENCH_FLAT='1',GLOB2_BENCH_SIZE='256x256',GLOB2_BENCH_UNITS='1000',GLOB2_BENCH_FRAMES='240',GLOB2_BENCH_WARMUP_FRAMES='120',GLOB2_BENCH_PAUSE_PRESENTATION='1',GLOB2_BENCH_FRAME_TIMES='1',GLOB2_BENCH_MODE=mode)
     env.update(SCENARIOS[scenario]); capture=a.output/f'{name}.ppm'
     if pair==0:env['GLOB2_BENCH_CAPTURE']=str(capture)
     binary=OUT/('baseline' if label=='baseline' else 'candidate'); backend='legacy-gl' if label=='legacy-gl' else 'sdl-gpu'
     cmd=[str(binary),'--renderer',backend,'--window-size','1280x800','--no-fullscreen','--mute']
     start=time.perf_counter();run=subprocess.run(cmd,env=env,cwd=ROOT,capture_output=True,text=True,timeout=600)
     log=run.stdout+run.stderr; path=a.output/f'{name}.log';path.write_text(log)
     status=re.search(r'BACKEND requested=(\S+) active=(\S+) fallback_reason=([^\n]*)',log)
     if run.returncode or not status or status[2]!=backend or status[3]:raise RuntimeError(f'{name}: failure/fallback')
     vals=sorted(map(float,re.findall(re.escape('FRAME mode='+mode)+r' frame=\d+ elapsed_ms=([\d.]+)',log)))
     if len(vals)!=240:raise RuntimeError(f'{name}: missing frames')
     metrics={}
     for tag,keys in [('',('median_ms','p95_ms')),('submission_cpu_',('submission_cpu_median_ms','submission_cpu_p95_ms')),('process_cpu_',('process_cpu_median_ms','process_cpu_p95_ms'))]:
      m=re.search(re.escape(mode+' '+tag)+r'median=([\d.]+) ms '+tag+r'p95=([\d.]+) ms',log)
      if not m:raise RuntimeError(f'{name}: missing summary {tag}')
      metrics.update(zip(keys,map(float,m.groups())))
     metrics.update(p99_ms=vals[(len(vals)*99+99)//100-1],max_ms=vals[-1])
     cache=list(map(int,re.findall(r'FRAME_CACHE frame=-?\d+ bytes=(\d+)',log)));device=list(map(int,re.findall(r'resource_bytes=(\d+)',log)))
     if label=='candidate' and (max(cache,default=0)>256*1024**2 or max(device,default=0)>256*1024**2):raise RuntimeError(f'{name}: memory cap exceeded')
     row={'scenario':scenario,'pair':pair,'label':label,'mode':mode,'command':cmd,'environment':{k:v for k,v in env.items() if k.startswith('GLOB2_') and k!='GLOB2_USER_DATA_DIR'},'exit_code':run.returncode,'elapsed_seconds':time.perf_counter()-start,'log':path.name,'log_sha256':digest(path),'backend':status.groups(),'metrics':metrics,'cache_peak_bytes':max(cache,default=0),'device_peak_bytes':max(device,default=0),'checksums':re.findall(r'simulation_checksum=(\w+)',log),'viewport':re.search(r'viewport=(\S+)',log)[1]}
     if pair==0:row['capture_sha256']=digest(capture)
     report['runs'].append(row);(a.output/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(name,metrics,flush=True)
 rows=[r for r in report['runs'] if r['scenario']==scenario]
 if len({tuple(r['checksums']) for r in rows})!=1 or len({r['viewport'] for r in rows})!=1:raise RuntimeError('Fixture mismatch')
 for mode in ['2D no clouds','2D clouds']:
  row={'scenario':scenario,'mode':mode}
  for label in ['baseline','candidate','legacy-gl']:
   runs=[r for r in rows if r['label']==label and r['mode']==mode]
   for metric in runs[0]['metrics']:row[label+'_'+metric]=statistics.median(r['metrics'][metric] for r in runs)
   for metric in ['median_ms','p95_ms','p99_ms']:
    row[label+'_'+metric+'_min']=min(r['metrics'][metric] for r in runs);row[label+'_'+metric+'_max']=max(r['metrics'][metric] for r in runs)
  report['summary'].append(row)
report['thermal_after']=subprocess.check_output(['pmset','-g','therm'],text=True)
(a.output/'results.json').write_text(json.dumps(report,indent=2)+'\n')
with (a.output/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(report['summary'][0]));w.writeheader();w.writerows(report['summary'])
print(json.dumps(report['summary'],indent=2),flush=True)
