import json,os,subprocess,hashlib
from pathlib import Path
root=Path.cwd(); out=root/'artifacts/hazard-integrated'
commands=[]
for threads in [1,4]:
 dest=out/f'continuation-final-{threads}'
 cmd=[str(root/'build/linux/client/release/src/glob2'),'--run-game','--load-game',str(root/'artifacts/hazard-performance/fixtures/patchwork-ice.game'),'--ticks','90256','--compute-threads',str(threads),'--replay','true','--telemetry','checksums','--save','final','--output-dir',str(dest)]
 env=dict(os.environ,LD_LIBRARY_PATH='/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib',SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_CHECKSUM_SIDECAR='1',GLOB2_USER_DATA_DIR=str(out/f'continuation-{threads}-profile'))
 with (out/f'continuation-{threads}.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 commands.append(cmd)
a=(out/'continuation-final-1/game.replay.checksums').read_bytes();b=(out/'continuation-final-4/game.replay.checksums').read_bytes()
assert a==b,'One/four compute thread checksums differ'
(out/'continuation.json').write_text(json.dumps({'commands':commands,'equal':True,'sha256':hashlib.sha256(a).hexdigest(),'old_save_format':139,'initial_tick':90000,'ticks':256},indent=2)+'\n')
print('Complete 256-tick traces identical across 1/4 compute threads')
