import hashlib,json,platform,subprocess,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
root=Path.cwd(); out=root/'artifacts/hazard-integrated'
metadata={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'base':subprocess.check_output(['git','rev-parse','origin/master'],text=True).strip(),'platform':platform.platform(),'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'build':'GLOB2_SDL3_PREFIX=/tmp/glob2-terrain-sdl-patched/prefix CCACHE=1 scons -j12 release=1 optimized_assets=0 tests build/linux/client/release/src/glob2','dependencies':'LD_LIBRARY_PATH=/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib; compile/link commands retained in build logs','tests':{},'limits':['Linux x86_64 only locally; hosted platform checks requested separately.','Native browser replay fixture recording verified; local browser playback not run.','143 display cases skipped; --quick excludes slow cases and benchmarks were separately measured. Human gameplay feel review unverified.','Earlier paired performance results precede the master resource integration; final microbenchmark separately recorded.']}
for name in ['focused','quick','golden','resource-golden','lan-recheck-1','lan-recheck-2','lan-recheck-3','lan-recheck-4']:
 cases=list(ET.parse(out/(name+'.xml')).iter('testcase'));metadata['tests'][name]={'cases':len(cases),'failures':sum(c.find('failure') is not None or c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases)}
metadata['binaries']={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ['build/linux/client/release/src/glob2','build/linux/client/release/test/glob2-engine-tests','build/linux/client/release/test/glob2-unit-tests']}
metadata['commands']={'quick':'LD_LIBRARY_PATH=/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib python3 test/run_tests.py -j8 --quick --exclude-tag benchmark --no-display --artifacts artifacts/hazard-integrated/quick-artifacts --junit artifacts/hazard-integrated/quick.xml','micro':r'LD_LIBRARY_PATH=/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy GLOB2_TEST_SOURCE_ROOT=$PWD taskset -c 12 build/linux/client/release/test/glob2-engine-tests -ts=TerrainHazardBenchmark -tc=*idle\ decisions*,*shared\ terrain\ fields* --no-breaks=true','sim_version':'python3 test/check_sim_revision.py --base origin/master'}
metadata['timing_failure']='Full quick suite host-to-guest LAN wake measured81ms against50ms; first isolated retry99ms, then three consecutive isolated retries passed. LAN code unchanged; host load was42 on32 logical CPUs. All failure logs retained.'
metadata['prior_evidence']='https://github.com/Globulation2/glob2/blob/74409fe655f312cf88e7ae2767a5838840de8ebc/artifacts/hazard-final/evidence.tar.gz'
metadata['continuation']=json.loads((out/'continuation.json').read_text())
(out/'verification.json').write_text(json.dumps(metadata,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz','w:gz') as tar:
 for path in sorted(out.iterdir()):
  if path.name in ['evidence.tar.gz','test-artifacts','quick-artifacts','old-safety.cpp','resolve.py'] or path.name.endswith('-profile') or path.name=='browser-profile':continue
  if path.is_dir() and not path.name.startswith('continuation-final-'):continue
  tar.add(path,arcname='hazard-integrated/'+path.name)

print(json.dumps(metadata['tests'],indent=2))
print('Archive bytes:',(out/'evidence.tar.gz').stat().st_size)
