import csv,json,os,random,re,subprocess,time,tempfile
from pathlib import Path
root=Path.cwd();ev=root/'artifacts/terrain-runtime-review';out=ev/'render-pairs';out.mkdir(exist_ok=True)
base=ev/'before-review/SoftwareRenderBenchmark';candidate=root/'build/linux/client/release/test/SoftwareRenderBenchmark'
fixtures=root/'artifacts/tests/TerrainRuntime/write_equivalent_custom_maps_for_paired_performance_runs_benchmark_artifacts'
cases=[('baseline',base,root/'artifacts/terrain-runtime-implementation/reference-game-four/initial.game.gz'),('candidate',candidate,root/'artifacts/terrain-runtime-implementation/reference-game-four/initial.game.gz')]+[(str(n),candidate,root/'artifacts/terrain-runtime-implementation/render-fixtures'/str(n)/'initial.game.gz') for n in (7,259,1024,16384)]
cases.append(('before-16384',base,root/'artifacts/terrain-runtime-implementation/render-fixtures/16384/initial.game.gz'))
rng=random.Random(2047)
with (out/'measurements.csv').open('w') as f:
 writer=csv.writer(f);writer.writerow(['round','case','cpu_ms_frame','elapsed_wall_ns','max_rss_kib','load_before','load_after']);f.flush()
 for iteration in range(-1,10):
  order=cases.copy();rng.shuffle(order)
  for name,binary,fixture in order:
   label=f'{iteration+1:02d}-{name}';before=os.getloadavg()[0];start=time.perf_counter_ns()
   with tempfile.TemporaryDirectory(prefix='glob2-runtime-render-') as profile:
    env=dict(os.environ,GLOB2_USER_DATA_DIR=profile,GLOB2_UI_SCALE='1',PROFILE_SAVE=str(fixture),PROFILE_ZOOM='1',PROFILE_FRAMES='120',PROFILE_WARMUP='20',PROFILE_CPU_SCOPES='1',PROFILE_NO_PRESENT='1')
    cmd=['taskset','-c','29',str(binary),'-G','-s','1280x800','-m','-F'];(out/(label+'.command.json')).write_text(json.dumps(dict(command=cmd,environment={k:v for k,v in env.items() if k.startswith('PROFILE_')}),indent=2))
    result=subprocess.run(['/usr/bin/time','-f','%M','-o',str(out/(label+'.rss'))]+cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   elapsed=time.perf_counter_ns()-start;(out/(label+'.log')).write_text(result.stdout)
   result.check_returncode();m=re.search(r'process_cpu_ms_per_frame=([0-9.]+)',result.stdout)
   if not m:raise RuntimeError('Missing CPU output '+label)
   row=[iteration,name,m[1],elapsed,int((out/(label+'.rss')).read_text()),before,os.getloadavg()[0]];writer.writerow(row);f.flush();print(row,flush=True)
