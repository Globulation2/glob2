from pathlib import Path
import subprocess,os,time,json
p=Path(__file__).resolve().parent
while not (p/'correctness-complete').exists():time.sleep(2)
env=dict(os.environ,LD_LIBRARY_PATH=str(Path('build/runtime-terrain-sdl/prefix/lib').resolve()),SDL_VIDEODRIVER='x11')
commands=[]
for name,cmd in [('full-match-pairs',['python3',str(p/'full-match-bench.py')]),('kernel-final',['taskset','-c','29',str(p/'kernel-bench'),'47']),('render-final',['xvfb-run','-a','python3',str(p/'render-bench.py')]),('analysis',['python3',str(p/'analyze.py')])]:
 print(name,flush=True);commands.append({'name':name,'command':cmd});(p/'measurement-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (p/(name+'.log')).open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
(p/'measurements-complete').write_text('complete\n')
