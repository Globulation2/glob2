# Review findings and disposition

Two independent sub-agents reviewed the simulation/persistence and presentation/editor portions, then reviewed the integrated fixes again. The parent inspected their changes and ran the integrated tests.

| Finding | Resolution | Regression coverage |
| --- | --- | --- |
| Public registry copies leave presentation strings borrowing another registry's storage | Copy construction is private; assignment is deleted; factories repair borrowed pointers before publication | Compile-time copy restrictions, snapshot name/key lifetime after reimport |
| Runtime gradient callers could choose an unsafe ring or unsupported size | Validate queue sizes and reachable edge costs before relaxation; compact production views use only distinct profiles | Rejected rings leave fields unchanged; unused slow profiles still work in raw/profile adapters |
| Building search carried unreachable custom-registry fallback and unused metadata | Removed unreachable branch, sole-swimming metadata and unused adapter parameters; clarified queue contract | Existing eager/resumed oracle tests plus actual Map pipeline dispatch, worker execution and stale-field invalidation |
| Equal custom appearances were rendered as separate edge materials | Deduplicated complete visual metadata, added scene visual-index plane, combined equal neighbor masks | All 16 masks across wrapped edges; software/OpenGL cache parity; distinct saved colors/timing do not alias |
| JSON import/load retained duplicate expanded trees | Sort authoring entries in place, release parsed tree before compilation, serialize one definition at a time | Canonical bytes/digest equality, max registry and binary/text embedded save/load |
| Terrain file picker advertised unsupported compressed files | Plain-JSON picker mode with default-preserving behavior for existing map/save dialogs | Compressed-only file excluded; real file confirmation, invalid import, retry, palette selection and cancellation on desktop/phone |
| UI labels bypassed translations and palette height bypassed scaling | Added catalog keys/translations and scaled layout dimensions | Strict catalog audit, five translation tests and actual editor layout interaction |
| Documentation omitted index domains, import retention and file constraints | Documented canonical/property/movement/visual identities, ownership, queue validation, persistence memory behavior and reimport semantics | Documentation cross-checked against implementation; no unsupported completion/performance claim |

Second review found no additional blocking correctness issue. Full platform/performance qualification remains the separate, previously documented draft requirement.
