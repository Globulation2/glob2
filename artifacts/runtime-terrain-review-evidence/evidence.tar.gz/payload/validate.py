from pathlib import Path
import subprocess,os,time,json
p=Path(__file__).resolve().parent
while True:
 try:os.kill(595576,0)
 except ProcessLookupError:break
 time.sleep(2)
env=dict(os.environ,GLOB2_SDL3_PREFIX=str(Path('build/runtime-terrain-sdl/prefix').resolve()))
commands=[]
def run(name,cmd,extra=None):
 print(name,flush=True);commands.append({'name':name,'command':cmd,'extra_environment':extra or {}});(p/'validation-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (p/(name+'.log')).open('w') as f:subprocess.run(cmd,env=env|dict(extra or {}),stdout=f,stderr=subprocess.STDOUT,check=True)
run('build-final',['scons','-j10','release=1','server=0','tests','build/linux/client/release/src/glob2','software-render-benchmark'])
run('focused',['python3','test/run_tests.py','--binary','engine','--filter','TerrainRuntime/*','--filter','TerrainPresentation/*','--filter','EditorActionCoverage/custom terrain*','--junit',str(p/'focused.xml'),'-j2'])
run('engine',['python3','test/run_tests.py','--binary','engine','--no-display','--junit',str(p/'engine.xml'),'-j4'])
run('units',['python3','test/run_tests.py','--binary','unit','--no-display','--junit',str(p/'units.xml'),'-j4'])
run('display',['python3','test/run_tests.py','--binary','engine','--filter','EditorActionCoverage/*','--filter','TerrainPresentation/*','--filter','MapPreview/*','--filter','GameGUITouch/*','--filter','GUIInteractionCoverage/*','--filter','ScriptEditor/*','--junit',str(p/'display.xml'),'-j2'])
old=Path('artifacts/terrain-runtime-implementation/reference-save-run/game.replay').resolve()
custom=Path('artifacts/tests/TurnEngineHarness/embedded_terrain_definitions_travel_with_shared_matches_and_verifier_replays_network-sim_artifacts/verify/match.replay').resolve()
for name,file,extra in [('old-replay',old,{}),('custom-replay',custom,{'GLOB2_REFERENCE_HEAVY':'1'})]:
 run(name,['python3','test/run_tests.py','--binary','engine','--tag','benchmark','--filter','EngineSession/external replay*','--junit',str(p/(name+'.xml')),'--artifacts',str(p/name)],extra|{'GLOB2_REFERENCE_REPLAY':str(file)})
(p/'correctness-complete').write_text('complete\n')
