from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json
out=Path('artifacts/coral-expansion-nodes/sweep');out.mkdir(exist_ok=True)
binary=str(Path('artifacts/coral-expansion-nodes/after-glob2').resolve())
cases=[]
for w,h,teams in [(128,128,4),(256,256,4),(512,256,4),(256,512,4),(512,512,8)]:
 for nodes in [0,1,2,3]:
  for roads in [0,1]:
   for resources in [0,300]:
    cases.append(dict(width=w,height=h,teams=teams,seed=7,workers=1 if roads else 8,options={'expansion-nodes':nodes,'sand-roads':roads,'land-bridges':0 if resources==0 else 3,**{r+'-amount':resources for r in ['wheat','wood','stone','fruit','algae']}}))
(out/'requests.json').write_text(json.dumps(cases,indent=2))
def run(item):
 k,c=item;name=f'{k:03d}';cmd=[binary,'map','generate','coral','--width',str(c['width']),'--height',str(c['height']),'--teams',str(c['teams']),'--workers',str(c['workers']),'--seed',str(c['seed']),'--report-file',str(out/(name+'.json'))]
 for key,value in c['options'].items():cmd+=['--set',f'{key}={value}']
 with (out/(name+'.log')).open('w') as log:
  try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 return {'case':k,'returncode':code}
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,enumerate(cases)))
(out/'results.json').write_text(json.dumps(results,indent=2));bad=[r for r in results if r['returncode']];print('Cases',len(results),'failures',bad,flush=True)
