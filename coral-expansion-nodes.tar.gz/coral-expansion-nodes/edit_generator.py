from pathlib import Path
p=Path('src/map/generator/generators/CoralGenerator.cpp');s=p.read_text().replace('#include "Geometry.h"','#include "Geometry.h"\n#include "Farmland.h"\n#include "Room.h"')
s=s.replace('constexpr double kBridgeApart = 30;','''constexpr double kBridgeApart = 30;
// A neutral building court, with a two-corner sand seal and enough room for four
// separate 4x4 buildings. The wider land disc includes the rasterized sand margin.
constexpr int kExpansionRadius = 8, kExpansionMargin = 2;
constexpr double kExpansionLandRadius = 12;''')
s=s.replace('\tBridge,  // a strip','\tExpansion, // a sand-ringed building court at a junction\n\tBridge,  // a strip')
s=s.replace('std::vector<unsigned char> land, water, bridge; // per tile','std::vector<unsigned char> land, water, bridge, expansion; // per tile\n\tstd::vector<ShapePoint> nodeCentres;\n\tstd::vector<int> nodeOwners;')
s=s.replace('bool keepsClear(const std::vector<StrokePoint> &candidate, int parent) const','bool keepsClear(const std::vector<StrokePoint> &candidate, int parent, bool expansion = false) const')
s=s.replace('''			for (const Piece &piece : pieces)
			{
				if (k == 0''','''			for (const Piece &piece : pieces)
			{
				// A court deliberately widens its own fan's junction. Keep the full
				// strait from pads, other courts, and every rival fan's land.
				if (k == 0 && expansion && piece.kind == Kind::Branch)
					continue;
				if (k == 0''',1)
a=s.index('\t// Every fork, rolled for stone once;')
s=s[:a]+'''	// Reserve courts before buds and bridges, repeating the same sites for every
	// colony. Prefer two different depths of the network; tight fans omit courts
	// rather than shrinking the homes or closing a strait to another fan.
	std::vector<int> junctions;
	int deepest = 1;
	for (int b = 1; b < int(L.tree.size()); ++b)
		if (!L.tree[b].leaf)
		{
			junctions.push_back(b);
			deepest = std::max(deepest, L.tree[b].depth);
		}
	int nodes = 0;
	for (int slot = 0; slot < o.expansionNodes; ++slot)
	{
		const double depth = double(slot + 1) * deepest / (o.expansionNodes + 1);
		std::stable_sort(junctions.begin(), junctions.end(), [&](int a, int b)
		{ return std::abs(L.tree[a].depth - depth) < std::abs(L.tree[b].depth - depth); });
		for (int b : junctions)
		{
			const auto &at = L.tree[b].path.back();
			const std::vector<StrokePoint> court{{at.x, at.y, kExpansionLandRadius}};
			if (L.keepsClear(court, b, true))
			{
				L.add(court, Kind::Expansion, b);
				++nodes;
				break;
			}
		}
	}
	context.telemetry.measure("coral.expansion.requested-per-fan", o.expansionNodes);
	context.telemetry.measure("coral.expansion.actual-per-fan", nodes);
	context.telemetry.measure("coral.expansion.radius", kExpansionRadius);
	if (nodes < o.expansionNodes)
		context.telemetry.fallback("coral.expansion.omitted", "Junctions lack room between pads and rival fans");

'''+s[a:]
s=s.replace('L.bridge.assign(n, 0);','L.bridge.assign(n, 0);\n\tL.expansion.assign(n, 0);',1)
a=s.index('\t\t\tif (piece.kind == Kind::Bud)',s.index('// Stamp every colony'))
s=s[:a]+'''			if (piece.kind == Kind::Expansion)
			{
				strokePath(L.land, t, turned);
				strokePath(L.expansion, t, turned);
				L.nodeCentres.push_back({turned.front().x, turned.front().y});
				L.nodeOwners.push_back(k);
				const int id = int(L.nodeCentres.size()) - 1;
				context.telemetry.measure("coral.expansion.x", int(std::lround(turned.front().x)), id);
				context.telemetry.measure("coral.expansion.y", int(std::lround(turned.front().y)), id);
				context.telemetry.measure("coral.expansion.owner", k, id);
				continue;
			}
'''+s[a:]
s=s.replace('L.padOf[i] < 0 && L.budOf[i] < 0 && !L.bridge[i] &&\n\t\t\t   clearGround','L.padOf[i] < 0 && L.budOf[i] < 0 && !L.bridge[i] && !L.expansion[i] &&\n\t\t\t   clearGround',1)
a=s.index('bool generate(Game &game, GenerationContext &context)')
s=s[:a]+'''std::vector<int> expansionCorners(const Layout &L, ShapePoint centre)
{
	std::vector<int> corners;
	for (const auto &[dx, dy] : discOffsets(kExpansionRadius))
		corners.push_back(L.t.at(int(std::lround(centre.x)) + dx, int(std::lround(centre.y)) + dy));
	return corners;
}

'''+s[a:]
a=s.index('\tlayBeaches(terrain, t);',s.index('bool generate'))
s=s[:a]+'''	// Courts overwrite through-roads and decorative sand inside their grass disc.
	// Their complete sand perimeter stays walkable while sealing all crop growth.
	for (const auto &centre : L.nodeCentres)
		stampContainedPlot(terrain, t, expansionCorners(L, centre), kExpansionMargin);
'''+s[a:]
a=s.index('\tif (o.landBridges > 0)\n',s.index('context.stage = "coral roads";'))
s=s[:a]+'''	for (size_t node = 0; node < L.nodeCentres.size(); ++node)
	{
		const auto &p = L.nodeCentres[node];
		const int target = t.at(int(std::lround(p.x)), int(std::lround(p.y)));
		if (!openRoad(map, t, workers[L.nodeOwners[node]], tileMask(t, {target})))
		{
			context.detail = "A coral expansion court is unreachable from its colony.";
			return false;
		}
	}
'''+s[a:]
a=s.index('\tif (CoralOptions(context.request).landBridges',s.index('std::string validateWorld'))
s=s[:a]+'''	// Verify the actual sand seal, empty grass and room for four separately
	// accessible buildings, including after all resource/route repair stages.
	const auto walking = groundUnitTiles(map);
	const auto buildable = potentialBuildingTiles(map);
	for (size_t node = 0; node < L.nodeCentres.size(); ++node)
	{
		const auto p = L.nodeCentres[node];
		const int x = int(std::lround(p.x)), y = int(std::lround(p.y));
		TerrainSketch seal(t.size(), WATER);
		const auto inside = stampContainedPlot(seal, t, expansionCorners(L, p), kExpansionMargin);
		std::vector<unsigned char> room(t.size(), 0);
		for (int i : inside)
		{
			if (!map.isGrass(t.remainderX(i), i / t.w) ||
				map.getResource(t.remainderX(i), i / t.w).type != NO_RES_TYPE)
				return "A coral expansion court has lost its clear grass interior.";
			room[i] = buildable[i];
		}
		for (int i = 0; i < t.size(); ++i)
			if (seal[i] == SAND && map.vertexTerrainAt(t.remainderX(i), i / t.w) != SAND)
				return "A coral expansion court has a broken sand ring.";
		const BuildingGrid grid{{x - 6, y - 6, x + 6, y + 6}, 4, 4, 2, 1};
		const auto buildings = arrangeBuildingGrid(t, room, walking, grid, workers[L.nodeOwners[node]]);
		if (!buildings.failure.empty() || buildings.footprints.size() != 4)
			return "A coral expansion court lacks four accessible building footprints.";
	}
'''+s[a:]
s=s.replace('homeSize(r.option("home-size")), sandRoads','homeSize(r.option("home-size")), expansionNodes(r.option("expansion-nodes")), sandRoads')
s=s.replace('"Coral",\n\t\t2,','"Coral",\n\t\t// Revision 3: sand-ringed, resource-free expansion courts along each fan.\n\t\t3,')
a=s.index('\t\t // Off, the branches')
s=s[:a]+'''		 GeneratorControl{"expansion-nodes", "Expansion nodes", 0, 3, 1, 2, ControlGroup::Layout},
'''+s[a:]
p.write_text(s)
p=Path('src/map/generator/generators/CoralGenerator.h');s=p.read_text().replace('landBridges, homeSize;','landBridges, homeSize, expansionNodes;');p.write_text(s)
