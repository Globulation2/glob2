import pathlib,subprocess,json,time,hashlib,os
base=pathlib.Path('/evidence');binary=pathlib.Path('/work/build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2');runs=[]
env=dict(os.environ,LD_LIBRARY_PATH='/opt/glob2-sdl/lib',GLOB2_SDL3_PREFIX='/opt/glob2-sdl')
for name,scope,planner in [('engine-disabled','Engine::advanceSession*',False),('engine-shared','Engine::advanceSession*',True),('planner-shared','HiringPlanner::Cache::rank*',True)]:
 dest=base/name;dest.mkdir(exist_ok=True)
 cmd=['valgrind','--tool=callgrind','--collect-atstart=no','--toggle-collect='+scope,'--separate-callers=2','--callgrind-out-file='+str(dest/'callgrind.out'),str(binary),'game','run','--load-game','/fixtures/checkpoint-2048.game.gz','--ticks','2080','--compute-threads','1','--gpu','off','--output-dir',str(dest)]
 if planner:cmd+=['--hiring-schedule','4:4:128:split','--hiring-execution','owner']
 start=time.monotonic()
 with (dest/'stdout.txt').open('w') as out,(dest/'stderr.txt').open('w') as err:p=subprocess.run(cmd,env=env,stdout=out,stderr=err)
 row=dict(name=name,command=cmd,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest());runs.append(row);(base/'profiles.json').write_text(json.dumps(runs,indent=2));print(name,p.returncode,round(row['elapsed_seconds'],2),flush=True)
 assert p.returncode==0,row
 with (dest/'annotate-self.txt').open('w') as out:subprocess.run(['callgrind_annotate','--auto=no','--inclusive=no','--threshold=100',str(dest/'callgrind.out')],stdout=out,env=env,check=True)
 with (dest/'annotate-inclusive.txt').open('w') as out:subprocess.run(['callgrind_annotate','--auto=yes','--inclusive=yes','--threshold=99',str(dest/'callgrind.out'),'/work/src/building/HiringPlanner.cpp'],stdout=out,env=env,check=True)
