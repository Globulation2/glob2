from pathlib import Path
import subprocess,shutil
p=Path('/work/src/building/HiringPlanner.cpp');s=p.read_text();lines=[line for line in s.splitlines() if 'const bool markets=' in line];assert len(lines)==2,lines
for line in lines:s=s.replace(line,line[:len(line)-len(line.lstrip())]+'const bool markets=false; // Fixture-only control: audited empty supplier lists.')
p.write_text(s);Path('/evidence/natural-control.patch').write_bytes(subprocess.check_output(['git','diff','--','src/building/HiringPlanner.cpp','src/engine/EngineRun.cpp'],cwd='/work'))
