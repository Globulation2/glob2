import pathlib,subprocess,json,time,os,hashlib
base=pathlib.Path('/evidence');binary=base/'glob2-linux-natural-control';runs=[]
for name,scope in [('regions-engine-natural','engine'),('regions-planner-natural','planner')]:
 dest=base/name;dest.mkdir(exist_ok=True);env=dict(os.environ,LD_LIBRARY_PATH='/opt/glob2-sdl/lib',GLOB2_CALLGRIND_SCOPE=scope)
 cmd=['valgrind','--tool=callgrind','--instr-atstart=no','--collect-atstart=no','--separate-callers=2','--callgrind-out-file='+str(dest/'callgrind.out'),str(binary),'game','run','--load-game','/fixtures/checkpoint-2048.game.gz','--ticks','2080','--compute-threads','1','--gpu','off','--output-dir',str(dest),'--benchmark-warmup','0','--hiring-schedule','4:4:128:split','--hiring-execution','owner']
 start=time.monotonic()
 with (dest/'stdout.txt').open('w') as out,(dest/'stderr.txt').open('w') as err:p=subprocess.run(cmd,env=env,stdout=out,stderr=err)
 runs.append(dict(name=name,scope=scope,command=cmd,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()));(base/'natural-profiles.json').write_text(json.dumps(runs,indent=2));print(name,p.returncode,round(runs[-1]['elapsed_seconds'],2),flush=True);assert p.returncode==0
 for kind in ['self','inclusive']:
  with (dest/f'annotate-{kind}.txt').open('w') as out,(dest/f'annotate-{kind}-warnings.txt').open('w') as err:subprocess.run(['callgrind_annotate','--auto='+('yes' if kind=='inclusive' else 'no'),'--inclusive='+('yes' if kind=='inclusive' else 'no'),'--threshold=100',str(dest/'callgrind.out'),'/work/src/building/HiringPlanner.cpp'],stdout=out,stderr=err,env=env,check=True)
