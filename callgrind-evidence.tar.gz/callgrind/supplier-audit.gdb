set pagination off
set confirm off
set environment LD_LIBRARY_PATH /opt/glob2-sdl/lib
file /work/build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2
break Map::materialSupplyModesSlot
run game run --load-game /fixtures/checkpoint-2048.game.gz --ticks 2049 --compute-threads 1 --gpu off --output-dir /evidence/supplier-audit
print consumer->gid
print consumer->owner->stockSuppliers
print consumer->owner->directStockSuppliers
print/x consumer->runtime->fetchesStockMask
print/x consumer->runtime->fetchesDirectStockMask
quit
