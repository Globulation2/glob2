import pathlib,subprocess,json,os,time,hashlib
base=pathlib.Path('/evidence');env=dict(os.environ,LD_LIBRARY_PATH='/opt/glob2-sdl/lib');env.pop('GLOB2_CALLGRIND_SCOPE',None)
variants={'natural':base/'glob2-linux-natural-control','partial':base/'glob2-linux-partial-control'};rows=[]
meta={'binaries':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in variants.items()},'fixture_sha256':hashlib.sha256(pathlib.Path('/fixtures/checkpoint-2048.game.gz').read_bytes()).hexdigest(),'warmup':'one process per variant, then ten rotated repetitions; 256 of 512 ticks discarded','scope':'Linux arm64 GCC11 release, source client requests inactive; 1 participant; original hiring authoritative'};(base/'shortlist-pairs-metadata.json').write_text(json.dumps(meta,indent=2))
for rep in range(-1,10):
 names=list(variants);n=rep%3;names=names[n:]+names[:n]
 for name in names:
  dest=base/'shortlist-pairs'/f'{name}-{rep}';dest.mkdir(parents=True,exist_ok=True)
  cmd=[str(variants[name]),'game','run','--load-game','/fixtures/checkpoint-2048.game.gz','--ticks','2560','--compute-threads','1','--gpu','off','--output-dir',str(dest),'--benchmark-warmup','256']
  if name!='disabled':cmd+=['--hiring-schedule','4:4:128:split','--hiring-execution','owner']
  start=time.monotonic()
  with (dest/'stdout.txt').open('w') as out,(dest/'stderr.txt').open('w') as err:r=subprocess.run(cmd,env=env,stdout=out,stderr=err)
  row=dict(variant=name,repetition=rep,command=cmd,exit_code=r.returncode,wall_seconds=time.monotonic()-start,result=json.load((dest/'result.json').open()));rows.append(row)
  with (base/'shortlist-pairs.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
  assert r.returncode==0,row
 print('repetition',rep,flush=True)
