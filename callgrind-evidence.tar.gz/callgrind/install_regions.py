from pathlib import Path
import shutil,subprocess
shutil.copy2('/work/build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2','/evidence/glob2-linux-original')
for filename,marker,scope in [('src/building/HiringPlanner.cpp','    if(capacity<1 || capacity>128)','planner'),('src/engine/EngineRun.cpp','    auto& st = *session;\n    updateTickSpeedAndDrawCadence(st, now);','engine')]:
 p=Path('/work')/filename;s=p.read_text();s='#include "/evidence/CallgrindRegion.h"\n'+s;s=s.replace(marker,f'    HiringCallgrindRegion callgrindRegion("{scope}");\n'+marker,1);p.write_text(s)
Path('/evidence/region-instrumentation.patch').write_bytes(subprocess.check_output(['git','diff','--','src/building/HiringPlanner.cpp','src/engine/EngineRun.cpp'],cwd='/work'))
