from pathlib import Path
import subprocess
p=Path('/work/src/building/HiringPlanner.cpp');s=p.read_text();start=s.index('            std::sort(candidates.begin()');end=s.index('            output.metrics.sortOutputNs+=',start)
s=s[:start]+'''            // Fixture-only split-policy control: exact top prefixes, without
            // fully sorting discarded candidates or constructing combined output.
            std::vector<Candidate> available,busy;
            for(const auto& c:candidates)(c.available?available:busy).push_back(c);
            const auto keep=[&](auto& values,std::size_t limit,auto& destination){
                limit=std::min(limit,values.size());
                const auto compare=[&](const auto& a,const auto& b){return better(a,b,key.job);};
                if(limit<values.size())std::nth_element(values.begin(),values.begin()+limit,values.end(),compare);
                values.resize(limit);std::sort(values.begin(),values.end(),compare);
                destination.assign(values.begin(),values.end());
            };
            keep(available,capacity*3/4,list.available);keep(busy,capacity/4,list.busy);
'''+s[end:];p.write_text(s);Path('/evidence/partial-control.patch').write_bytes(subprocess.check_output(['git','diff','--','src/building/HiringPlanner.cpp','src/engine/EngineRun.cpp'],cwd='/work'))
