// Profiling-only instrumentation, applied in the isolated Linux source copy.
#pragma once
#include <valgrind/callgrind.h>
#include <cstdlib>
#include <cstring>
struct HiringCallgrindRegion
{
    bool active;
    explicit HiringCallgrindRegion(const char* name)
    {
        static const char* selected=std::getenv("GLOB2_CALLGRIND_SCOPE");
        active=selected && std::strcmp(selected,name)==0;
        if(active){CALLGRIND_START_INSTRUMENTATION;CALLGRIND_TOGGLE_COLLECT;}
    }
    ~HiringCallgrindRegion(){if(active){CALLGRIND_TOGGLE_COLLECT;}}
};
