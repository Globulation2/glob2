"""Ignored evidence runner; execute only in coordinator-approved quiet interval."""
import argparse, hashlib, json, os, re, subprocess, time
from pathlib import Path
ROOT=Path('/home/bradley/glob2')
EVIDENCE=Path('/home/bradley/.codex/worktrees/renderer-feasibility/glob2/artifacts/renderer-feasibility')
PLAN=json.loads((EVIDENCE/'final-aeca-release-plan.json').read_text())
BINARY=Path(PLAN['candidate_binaries']['torus'])
FIXTURE=Path(PLAN['save'])
OUTPUT=EVIDENCE/'final-aeca-release-paired'
p=argparse.ArgumentParser();p.add_argument('--start',type=int,default=0);p.add_argument('--stop',type=int,default=7);p.add_argument('--workload',action='append',choices=['flat-warm','flat-streaming','torus','flat-warm-native']);p.add_argument('--frames',type=int,default=300);p.add_argument('--warmup',type=int,default=30);p.add_argument('--mode');args=p.parse_args()
workloads=args.workload or ['flat-warm','flat-streaming','torus','flat-warm-native']
digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
binary_hash=digest(BINARY);fixture_hash=digest(FIXTURE)
OUTPUT.mkdir(exist_ok=True)
collector=ROOT/'tools/rendering/collect_baseline.py'
if args.mode:
 original=collector.read_text()
 mode_line='''                env['GLOB2_BENCH_MODE'] = '''+repr(args.mode)+'''\n'''
 collector=OUTPUT/'collector-limited-mode.py'
 collector.write_text(original.replace('ROOT = Path(__file__).resolve().parents[2]', 'ROOT = Path('+repr(str(ROOT))+')').replace('                if args.zoom is not None:',mode_line+'                if args.zoom is not None:'))
initial={'binary':str(BINARY),'binary_sha256':binary_hash,'fixture_sha256':fixture_hash,'candidate_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'base':'c3cb01070d121752f4c5e9632c5567ef13e58d9a','product_revision':'aeca7b34c14ab32b1a9e04b015b1d7caff75cb79','build_command':PLAN['build_command'],'frames':args.frames,'warmup':args.warmup,'mode':args.mode,'rotating_order':True,'default_promotion':False}
(OUTPUT/('inputs-'+','.join(workloads)+f'-{args.start}-{args.stop}.json')).write_text(json.dumps(initial,indent=2)+'\n')
backends=['legacy-gl','programmable-gl','sdl-gpu'];rows=[]
for round_index in range(args.start,args.stop):
 order=backends[round_index%3:]+backends[:round_index%3]
 if round_index%2:order.reverse()
 for workload in workloads:
  for backend in order:
   if digest(BINARY)!=binary_hash:raise SystemExit('Candidate changed during comparison')
   case=OUTPUT/(workload+'-'+backend+f'-round{round_index}')
   command=['python3',str(collector),'--binary',str(BINARY),'--save',str(FIXTURE),'--build-command',PLAN['build_command'],'--build-log',str(PLAN['build_log']),'--base','c3cb01070d121752f4c5e9632c5567ef13e58d9a','--repeat','1','--frames',str(args.frames),'--warmup',str(args.warmup),'--renderer',backend,'--workload',workload.replace('-native',''),'--output',str(case)]
   if workload.endswith('-native'):command+=['--zoom','1']
   env=dict(os.environ,GLOB2_RENDERER_SHADER_DIR=str(BINARY.parents[1]/'shaders'))
   if args.mode:env['GLOB2_BENCH_MODE']=args.mode
   print(f'Start round{round_index} {workload} {backend}',flush=True)
   started=time.time();result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,timeout=900)
   case.mkdir(parents=True,exist_ok=True)
   (case/'collector.log').write_text(result.stdout+result.stderr)
   report=json.loads((case/'baseline.json').read_text());run=report['runs'][0];log=Path(run['log']).read_text()
   active=re.findall(r'BACKEND .*active=([^ \n]+)',log);checksums=re.findall(r'simulation_checksum=([0-9a-f]+)',log)
   row={'round':round_index,'workload':workload,'requested':backend,'active':active,'checksums':checksums,'case':str(case),'seconds':time.time()-started,'command':command,'exit_code':result.returncode,'deferred':re.findall(r'FRAME_DEFERRED[^\n]+',log)}
   rows.append(row);(OUTPUT/('rounds-'+','.join(workloads)+f'-{args.start}-{args.stop}.json')).write_text(json.dumps(rows,indent=2)+'\n')
   print(json.dumps(row),flush=True)
   if result.returncode or run['exit_code'] or active!=[backend] or not checksums or len(set(checksums))!=1:raise SystemExit('Invalid comparison run')
   if any(set(x['checksums'])!=set(checksums) for x in rows):raise SystemExit('Simulation checksum mismatch')
