"""Summarize actual completed-frame logs, preserving runs and paired variation."""
import json,re,statistics
from pathlib import Path
root=Path(__file__).parent/'final-aeca-release-paired'
rows=[]
for case in sorted(root.glob('*-round*')):
 report_path=case/'baseline.json'
 if not report_path.exists():continue
 report=json.loads(report_path.read_text())
 for run in report['runs']:
  log=Path(run['log']).read_text()
  active=re.findall(r'BACKEND .*active=([^ \n]+)',log)
  groups={}
  pending_device=None;device_groups={}
  for line in log.splitlines():
   if line.startswith('FRAME_DEVICE '):
    pending_device={k:int(v) for k,v in re.findall(r'(\w+)=([0-9]+)',line)}
   elif line.startswith('FRAME mode='):
    match=re.match(r'FRAME mode=(.*?) frame=(-?\d+)',line)
    if match and int(match[2])>=0 and pending_device:device_groups.setdefault(match[1],[]).append(pending_device)
    pending_device=None
  for mode,elapsed,cpu in re.findall(r'^FRAME mode=(.*?) frame=\d+ elapsed_ms=([\d.]+) process_cpu_ms=([\d.]+)',log,re.M):
   g=groups.setdefault(mode,{'wall':[],'processCPU':[]});g['wall'].append(float(elapsed));g['processCPU'].append(float(cpu))
  completions={m:{'completed':int(c),'attempts':int(a),'intentionalHolds':int(h),'admissionDeferrals':int(d)} for m,c,a,h,d in re.findall(r'^COMPLETION_SUMMARY mode=(.*?) completed=(\d+) attempts=(\d+) intentional_holds=(\d+) admission_deferrals=(\d+)',log,re.M)}
  def quantiles(values):
   v=sorted(values)
   return {f'p{q}':v[(len(v)*q+99)//100-1] for q in [50,95,99]}
  for mode,values in groups.items():
   rows.append({'case':case.name,'round':int(case.name.rsplit('round',1)[1]),'mode':mode,'backend':active[0] if len(active)==1 else active,'exitCode':run['exit_code'],'wallMs':quantiles(values['wall']),'processCpuMs':quantiles(values['processCPU']),'completion':completions.get(mode),'frameSamples':len(values['wall']),'deviceTelemetry':{k:{'median':statistics.median(x[k] for x in device_groups.get(mode,[])),'peak':max(x[k] for x in device_groups.get(mode,[]))} for k in ['packets','batches','upload_bytes','resource_bytes','submit_cpu_ns','capture_cpu_ns','capture_drops'] if device_groups.get(mode)},'log':run['log'],'logSHA256':run['log_sha256']})
aggregate=[]
for workload,mode,backend in sorted(set((r['case'].split('-'+str(r['backend'])+'-')[0],r['mode'],r['backend']) for r in rows)):
 group=[r for r in rows if r['case'].startswith(workload+'-'+backend+'-') and r['mode']==mode]
 metrics={}
 for kind in ['wallMs','processCpuMs']:
  for q in ['p50','p95','p99']:
   values=[r[kind][q] for r in group];med=statistics.median(values)
   metrics[kind+'/'+q]={'runValues':values,'median':med,'relativeMedianAbsoluteDeviation':statistics.median(abs(x-med) for x in values)/med}
 aggregate.append({'workload':workload,'mode':mode,'backend':backend,'rounds':[r['round'] for r in group],'metrics':metrics,'completed':sum(r['completion']['completed'] for r in group),'attempts':sum(r['completion']['attempts'] for r in group),'intentionalHolds':sum(r['completion']['intentionalHolds'] for r in group),'admissionDeferrals':sum(r['completion']['admissionDeferrals'] for r in group)})
summary=[]
for key in sorted(set((r['case'].split('-'+str(r['backend'])+'-')[0],r['mode']) for r in rows)):
 workload,mode=key
 for backend in ['programmable-gl','sdl-gpu']:
  candidate={r['round']:r for r in rows if r['case'].startswith(workload+'-'+backend+'-') and r['mode']==mode}
  reference={r['round']:r for r in rows if r['case'].startswith(workload+'-legacy-gl-') and r['mode']==mode}
  common=sorted(candidate.keys()&reference.keys())
  if not common:continue
  metrics={}
  for kind in ['wallMs','processCpuMs']:
   for q in ['p50','p95','p99']:
    ratios=[candidate[n][kind][q]/reference[n][kind][q] for n in common]
    med=statistics.median(ratios)
    metrics[kind+'/'+q]={'pairedRatios':ratios,'medianRatio':med,'relativeMedianAbsoluteDeviation':statistics.median(abs(x-med) for x in ratios)/med}
  summary.append({'workload':workload,'mode':mode,'backend':backend,'pairedRounds':common,'metrics':metrics})
result={'aggregate':aggregate,'runs':rows,'paired':summary,'defaultPromotion':False,'gpuTimestampSupport':False,'timingScope':'fence-completed wall includes synchronous 1x1 readback and all retry/hold turns; excludes final presentation','coverage':'Actual rows only; seven rounds require seven common round IDs','frozenGates':str(Path(__file__).parent/'frozen-release-gates.json')}
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(root/'summary.json')
