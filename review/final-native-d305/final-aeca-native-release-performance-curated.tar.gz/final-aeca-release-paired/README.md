Final native release comparison evidence

Start with review-summary.md and qualification.json. summary.json contains every run plus same-round ratios and variation. Each case directory contains exact commands, provenance, raw frame/counter logs and final rendered PPM. inputs-*.json and support preserve the release binary/fixture hashes, exact sampling plan, scripts, build receipts, frozen gates and native source equivalence.

This compares three backends of the SAME final aeca executable. It is not a pre-migration-versus-new-build comparison. Backend defaults remain unchanged. Performance regression gates fail for the measured cloud/fractional cases; the limited torus sample does not qualify the frozen full gate. The unrelated interactive user application remained active throughout; no uncontended-host claim is made.

Normal installed-app/export and six source-hidden backend proofs are in the separate final-aeca-native-install-evidence.tar.gz. Functional strict torus proofs are in rebased-38152-strict-torus-evidence.tar.gz; the final teardown change does not change those renderer algorithms.
