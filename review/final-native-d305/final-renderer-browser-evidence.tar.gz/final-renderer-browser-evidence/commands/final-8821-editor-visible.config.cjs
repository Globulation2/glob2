const config=require('./amd-gl.config.cjs');
config.outputDir=require('node:path').resolve(__dirname,'../shaders/final-8821-editor-visible-results');
config.reporter=[['list'],['json',{outputFile:require('node:path').resolve(__dirname,'../shaders/final-8821-editor-visible-results.json')}]];
module.exports=config;
