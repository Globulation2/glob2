const config=require('../../browser/playwright.config.js');
config.testDir=require('node:path').resolve(__dirname,'../../browser/tests');
config.projects=config.projects.filter(p=>p.name==='firefox'||p.name==='webkit');
config.use.trace='on';
config.outputDir=require('node:path').resolve(__dirname,'../shaders/final-8821-firefox-results');
config.reporter=[['list'],['json',{outputFile:require('node:path').resolve(__dirname,'../shaders/final-8821-firefox-results.json')}]];
module.exports=config;
