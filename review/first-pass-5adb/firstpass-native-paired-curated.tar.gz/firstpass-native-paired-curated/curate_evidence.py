"""Keep all numerical/raw receipts and representative images; enumerate omissions."""
import argparse,hashlib,json,shutil,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('results',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=a.results.resolve();out=a.output.resolve()
if out.exists():raise SystemExit('Refuse overwrite '+str(out))
out.mkdir(parents=True)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inventory=[];omitted=[]
for src in sorted(root.rglob('*')):
 if not src.is_file():continue
 rel=src.relative_to(root);row={'path':str(rel),'bytes':src.stat().st_size,'sha256':digest(src)};inventory.append(row)
 # Every family's before/after round-zero image for every measured workload.
 if src.suffix.lower() in ['.ppm','.png'] and not any(part.endswith('-round0') for part in rel.parts):omitted.append(row);continue
 dest=out/'results'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
base=Path(__file__).resolve().parent
for name in ['paired_release.py','summarize_pairs.py','curate_evidence.py','provisional-input-comparison.json']:
 if (base/name).exists():shutil.copy2(base/name,out/name)
inputs=base.parent/'renderer-feasibility'
for name in ['checkerboard256-seed1-1000.game','frozen-release-gates.json']:
 shutil.copy2(inputs/name,out/name)
receipt={'fullInventory':inventory,'omittedDuplicateCaptures':omitted,'selection':'All raw logs, commands, metrics and provenance retained; only round-zero captures selected. Omitted capture hashes explicitly recorded.','defaultPromotion':False}
(out/'selection-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
files={str(p.relative_to(out)):digest(p) for p in sorted(out.rglob('*')) if p.is_file()};(out/'SHA256.json').write_text(json.dumps(files,indent=2)+'\n')
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as tar:tar.add(out,arcname=out.name)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),'retainedFiles':len(files),'omittedDuplicateCaptures':len(omitted)},indent=2))
