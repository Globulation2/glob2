const config=require('../../browser/playwright.config.js');
config.testDir=require('node:path').resolve(__dirname,'../../browser/tests');
config.projects=config.projects.filter(p=>p.name==='chromium');
config.projects[0].use.launchOptions={args:['--enable-unsafe-webgpu','--enable-features=Vulkan','--use-vulkan=swiftshader','--use-angle=vulkan','--disable-vulkan-surface']};
module.exports=config;
