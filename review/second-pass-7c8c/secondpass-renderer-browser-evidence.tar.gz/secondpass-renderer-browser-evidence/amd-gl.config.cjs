const config=require('./live.config.cjs');
config.projects[0].use.launchOptions={args:['--use-angle=vulkan','--enable-features=Vulkan','--use-vulkan=native','--disable-vulkan-surface','--ignore-gpu-blocklist']};
config.use.trace='on';
config.outputDir=require('node:path').resolve(__dirname,'../shaders/amd-gl-results');
config.reporter=[['list']];
module.exports=config;
