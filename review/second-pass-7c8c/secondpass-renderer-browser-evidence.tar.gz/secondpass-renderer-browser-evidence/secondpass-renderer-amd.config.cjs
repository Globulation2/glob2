const config=require('./amd-gl.config.cjs');
config.outputDir=require('node:path').resolve(__dirname,'../shaders/secondpass-renderer-amd-results');
config.reporter=[['list'],['json',{outputFile:require('node:path').resolve(__dirname,'../shaders/secondpass-renderer-amd-results.json')}]];
module.exports=config;
