import json
from pathlib import Path
r=Path(__file__).parent/'paired-release';j=json.loads((r/'summary.json').read_text());agg={(x['workload'],x['backend'],x['mode'],x['version']):x for x in j['aggregate']};flags=[]
lines=['# Second-pass native renderer comparison','','Frozen before5adb2b3fa; after920e8e9d8. Identical fixture/runtime artwork/pins,1280×800; three rotating rounds,54 processes,22140 completed intervals.','','| Workload | Backend | Wall p50 before→after ms | CPU p50 before→after ms | Wall p50 ratio | p95 ratio | p99 ratio | p50 paired MAD |','|---|---|---:|---:|---:|---:|---:|---:|']
for x in j['pairedAfterBefore']:
 key=(x['workload'],x['backend'],x['mode']);b=agg[key+('before',)]['metrics'];a=agg[key+('after',)]['metrics'];m=x['metrics']
 lines.append(f"| {x['workload']} {x['mode']} | {x['backend']} | {b['wallMs/p50']['median']:.3f}→{a['wallMs/p50']['median']:.3f} | {b['processCpuMs/p50']['median']:.3f}→{a['processCpuMs/p50']['median']:.3f} | {m['wallMs/p50']['median']:.3f} | {m['wallMs/p95']['median']:.3f} | {m['wallMs/p99']['median']:.3f} | {m['wallMs/p50']['relativeMAD']:.3f} |")
 for metric,z in m.items():
  if z['median']>1.05:flags.append({'workload':x['workload'],'backend':x['backend'],'mode':x['mode'],'metric':metric,**z})
q={'before':'5adb2b3fa3c22d9d6962f95e98542c828ef2e65b','after':'920e8e9d80416bb5dcf8906f06e3c03487f491dd','processes':54,'completedIntervals':sum(x['samples'] for x in j['runs']),'regressionsOverFivePercent':flags,'defaultPromotion':False,'frozenReleaseGateQualified':False,'conclusion':'Observed improvements are modest and often within paired noise; meaningful broad speedup is not established. All tail regressions remain flagged.','limitations':['Three rounds instead of frozen seven-round gate. Torus30 measured/4warmup per process, not300/30.','No cold/streaming/editor/UI/recording/software/WebGPU performance or GPU timestamps.','Wall includes holds/retries/1x1 synchronous readback; final presentation excluded. CPU is whole-process CPU.','Concurrent user Flatpak remains active. No agent-owned GPU activity during window.','Five-percent regression ceiling unchanged; do not enlarge it to accommodate observed tail noise.','Different source bases include upstream tooling changes; dependency pins/runtime asset hashes and fixture checksum remain identical.']}
(r/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');lines+=['','GL torus holds542→543; SDL540→540,90 completions per family/version. No ordinary admission deferrals.','',q['conclusion'],'',*q['limitations']];(r/'review-summary.md').write_text('\n'.join(lines)+'\n');print('flags',len(flags))
# Final round-zero screenshots are auxiliary phase-dependent evidence.
rows=[]
def pixels(p):return p.read_bytes().split(b'\n255\n',1)[1]
for b in sorted(r.glob('*-before-round0')):
 a=r/b.name.replace('-before-','-after-');x=pixels(b/'frame-0.ppm');y=pixels(a/'frame-0.ppm');assert len(x)==len(y);s=0;m=0;c=0
 for i in range(0,len(x),3):
  ds=[abs(x[i+k]-y[i+k]) for k in range(3)];s+=sum(ds);m=max(m,*ds);c+=any(ds)
 rows.append({'case':b.name.replace('-before-round0',''),'pixels':len(x)//3,'changedPixels':c,'meanAbsoluteByteDifference':s/len(x),'maximumByteDifference':m})
(r/'capture-comparison.json').write_text(json.dumps({'note':'Auxiliary completed captures. Torus camera/source phases can depend on completed host-turn count; correctness tests are separate.','cases':rows},indent=2)+'\n');print(rows)
