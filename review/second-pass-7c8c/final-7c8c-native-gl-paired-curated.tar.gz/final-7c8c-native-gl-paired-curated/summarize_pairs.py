"""Summarize only observed complete intervals from paired production logs."""
import argparse,json,re,statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('directory',type=Path);a=p.parse_args();root=a.directory
rows=[]
def quantile(xs):
 xs=sorted(xs);return {f'p{q}':xs[(len(xs)*q+99)//100-1] for q in (50,95,99)}
def distribution(xs):
 med=statistics.median(xs);return {'values':xs,'median':med,'relativeMAD':statistics.median(abs(x-med) for x in xs)/med if med else 0}
for case in sorted(root.glob('*-round*')):
 if not (case/'baseline.json').exists():continue
 m=re.fullmatch(r'(fractional|native|torus)-(legacy-gl|programmable-gl|sdl-gpu)-(before|after)-round(\d+)',case.name)
 if not m:continue
 report=json.loads((case/'baseline.json').read_text());run=report['runs'][0];log=Path(run['log']).read_text();groups={};devices={};pending=None
 for line in log.splitlines():
  if line.startswith('FRAME_DEVICE '):pending={k:int(v) for k,v in re.findall(r'(\w+)=([0-9]+)',line)}
  elif line.startswith('FRAME mode='):
   match=re.match(r'FRAME mode=(.*?) frame=(-?\d+) elapsed_ms=([\d.]+) process_cpu_ms=([\d.]+)',line)
   if match and int(match[2])>=0:
    g=groups.setdefault(match[1],{'wallMs':[],'processCpuMs':[]});g['wallMs'].append(float(match[3]));g['processCpuMs'].append(float(match[4]))
    if pending:devices.setdefault(match[1],[]).append(pending)
   pending=None
 completions={mode:{'completed':int(c),'attempts':int(t),'intentionalHolds':int(h),'admissionDeferrals':int(d)} for mode,c,t,h,d in re.findall(r'^COMPLETION_SUMMARY mode=(.*?) completed=(\d+) attempts=(\d+) intentional_holds=(\d+) admission_deferrals=(\d+)',log,re.M)}
 active=re.findall(r'BACKEND .*active=([^ \n]+)',log)
 for mode,values in groups.items():
  rows.append({'case':case.name,'workload':m[1],'backend':m[2],'version':m[3],'round':int(m[4]),'mode':mode,'active':active,'exitCode':run['exit_code'],'samples':len(values['wallMs']),'completion':completions.get(mode),'metrics':{k:quantile(v) for k,v in values.items()},'deviceTelemetry':{k:distribution([x[k] for x in devices.get(mode,[]) if k in x]) for k in ['packets','batches','upload_bytes','resource_bytes','submit_cpu_ns','capture_cpu_ns','capture_drops'] if any(k in x for x in devices.get(mode,[]))},'logSHA256':run['log_sha256']})
aggregates=[];pairs=[]
for workload,backend,mode in sorted({(x['workload'],x['backend'],x['mode']) for x in rows}):
 grouped={v:{x['round']:x for x in rows if (x['workload'],x['backend'],x['mode'],x['version'])==(workload,backend,mode,v)} for v in ['before','after']}
 for version,g in grouped.items():
  if not g:continue
  aggregates.append({'workload':workload,'backend':backend,'mode':mode,'version':version,'rounds':sorted(g),'metrics':{f'{kind}/{q}':distribution([x['metrics'][kind][q] for x in g.values()]) for kind in ['wallMs','processCpuMs'] for q in ['p50','p95','p99']},'counts':{k:sum(x['completion'][k] for x in g.values()) for k in ['completed','attempts','intentionalHolds','admissionDeferrals']}})
 common=sorted(grouped['before'].keys()&grouped['after'].keys())
 if common:pairs.append({'workload':workload,'backend':backend,'mode':mode,'rounds':common,'metrics':{f'{kind}/{q}':distribution([grouped['after'][r]['metrics'][kind][q]/grouped['before'][r]['metrics'][kind][q] for r in common]) for kind in ['wallMs','processCpuMs'] for q in ['p50','p95','p99']}})
result={'runs':rows,'aggregate':aggregates,'pairedAfterBefore':pairs,'defaultPromotion':False,'qualification':'Three-round first-pass scope is not seven-round frozen release/default qualification. Ratios >1 mean slower. Preserve five-percent regression ceiling; report MAD/noise without enlarging it.','timingScope':'Completed wall includes all holds/retries and tiny synchronous readback, excludes final presentation; CPU is whole-process CPU. No GPU timestamps.'}
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(root/'summary.json')
