import json,os,subprocess,time
from pathlib import Path
root=Path('/home/bradley/glob2');here=Path(__file__).resolve().parent;out=here/'paired-release/supplemental-nativecloud';out.mkdir(parents=True,exist_ok=True)
fixture=here.parent/'renderer-feasibility/checkerboard256-seed1-1000.game';collector=here/'paired-release/collect_pair.py'
stages={'before':here/'frozen-before-5adb2b3fa','after':Path('/home/bradley/glob2/build/renderer-second-pass/frozen-native-920e8e9d8')}
logs={'before':stages['before']/'successful-build.log','after':Path('/tmp/glob2-renderer-secondpass-native.log')};rows=[]
sequence=[('sdl-gpu',0,['after','before']),('legacy-gl',0,['before','after']),('sdl-gpu',1,['before','after']),('sdl-gpu',2,['after','before'])]
for family,rnd,versions in sequence:
 for version in versions:
  stage=stages[version];receipt=json.loads((stage/'provenance.json').read_text());case=out/f'native-{family}-{version}-round{rnd}'
  if case.exists():raise SystemExit('No overwrite')
  cmd=['python3',str(collector),'--binary',str(stage/'test/torus-render-benchmark'),'--save',str(fixture),'--renderer',family,'--workload','flat-warm','--zoom','1','--mode','2D clouds','--frames','300','--warmup','30','--repeat','1','--build-command','scons release=1 client_profile=full -j2 build/linux/client/release/client-full-direct-1111/src/glob2 torus-render-benchmark','--build-log',str(logs[version]),'--base',receipt['base'],'--output',str(case)]
  start=time.time();p=subprocess.run(cmd,cwd=root,env=dict(os.environ,GLOB2_RENDERER_SHADER_DIR=str(stage/'shaders')),capture_output=True,text=True,timeout=600);case.mkdir(exist_ok=True);(case/'collector.log').write_text(p.stdout+p.stderr)
  rows.append({'family':family,'round':rnd,'version':version,'seconds':time.time()-start,'command':cmd,'exit':p.returncode});(out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
  if p.returncode:raise SystemExit('Supplemental failure retained')
