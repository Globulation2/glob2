"""Ignored release evidence orchestration; run only in a coordinated GPU-idle window."""
import argparse,hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
ROOT=Path('/home/bradley/glob2')
HERE=Path(__file__).resolve().parent
OLD=HERE/'frozen-before-5adb2b3fa'
p=argparse.ArgumentParser()
p.add_argument('--optimized-stage',type=Path,required=True)
p.add_argument('--optimized-build-log',type=Path,required=True)
p.add_argument('--optimized-build-command',required=True)
p.add_argument('--output',type=Path,default=HERE/'final-gl-paired')
p.add_argument('--start',type=int,default=0);p.add_argument('--stop',type=int,default=3)
p.add_argument('--family',action='append',choices=['legacy-gl','programmable-gl'])
p.add_argument('--workload',action='append',choices=['fractional','native','torus'])
a=p.parse_args()
out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
optimized=a.optimized_stage.resolve()
fixture=HERE.parent/'renderer-feasibility/checkerboard256-seed1-1000.game'
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
oldReceipt=json.loads((OLD/'provenance.json').read_text());newReceipt=json.loads((optimized/'provenance.json').read_text())
stages={'before':{'root':OLD,'receipt':oldReceipt,'command':'GLOB2_SDL3_PREFIX=build/sdl3/prefix GLOB2_RENDER_SHADER_INPUT=artifacts/renderer-integration/review-shader-input scons release=1 client_profile=full -j2 build/linux/client/release/client-full-direct-1111/src/glob2 torus-render-benchmark','buildLog':OLD/'successful-build.log'},'after':{'root':optimized,'receipt':newReceipt,'command':a.optimized_build_command,'buildLog':a.optimized_build_log.resolve()}}
for label,side in stages.items():
 side['binary']=side['root']/'test/torus-render-benchmark';side['binaryHash']=hashfile(side['binary']);side['provenanceHash']=hashfile(side['root']/'provenance.json')
 expected=side['receipt']['files']['test/torus-render-benchmark']
 if hashfile(side['buildLog'])!=side['receipt']['logSHA256']:raise SystemExit(label+' frozen receipt/build log mismatch')
 if side['binaryHash']!=expected:raise SystemExit(label+' frozen receipt/binary mismatch')
 receipts=out/'inputs'/label;receipts.mkdir(parents=True,exist_ok=True)
 shutil.copy2(side['root']/'provenance.json',receipts/'provenance.json')
 shutil.copy2(side['buildLog'],receipts/'build.log')
 shutil.copy2(side['root']/'shaders/metadata.json',receipts/'shader-metadata.json')
 if 'release=1' not in side['command'] or 'client_profile=full' not in side['command']:raise SystemExit('Both builds require explicit full release profile')
# Both executables resolve artwork through the original full-profile build prefix.
assetPath=ROOT/'build/linux/client/release/client-full-direct-1111/runtime-assets.json'
oldAssets=json.loads((OLD/'runtime-assets.json').read_text());newAssets=json.loads(assetPath.read_text())
assetOutputs=lambda data:{x['source']:x['output_sha256'] for x in data['files']}
if assetOutputs(oldAssets)!=assetOutputs(newAssets):raise SystemExit('Runtime artwork outputs changed; paired fixture is not controlled')
shutil.copy2(assetPath,out/'runtime-assets.json')
shutil.copy2(OLD/'runtime-assets.json',out/'inputs/before/runtime-assets.json')
# Freeze the original tooling bytes; the inventory revision is not a binary source revision.
source=(ROOT/'tools/rendering/collect_baseline.py').read_text()
collector=out/'collect_pair.py'
collector.write_text(source.replace('ROOT = Path(__file__).resolve().parents[2]','ROOT = Path('+repr(str(ROOT))+')').replace("    parser.add_argument('--warmup'","    parser.add_argument('--mode')\n    parser.add_argument('--warmup'").replace('                if args.zoom is not None:',"                if args.mode: env['GLOB2_BENCH_MODE']=args.mode\n                if args.zoom is not None:"))
workloads=a.workload or ['fractional','native','torus']
plan={'fixture':str(fixture),'fixtureSHA256':hashfile(fixture),'stages':{k:{'stage':str(v['root']),'binarySHA256':v['binaryHash'],'product':v['receipt']['revision'],'provenanceSHA256':v['provenanceHash'],'command':v['command'],'buildLog':str(v['buildLog'])} for k,v in stages.items()},'workloads':workloads,'roundRange':[a.start,a.stop],'flatCompleted':300,'flatWarmup':30,'torusCompleted':30,'torusWarmup':4,'torusMode':'Torus no clouds','sourceCheckoutInventoryRevision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'collectorSHA256':hashfile(collector),'runtimeAssetManifestSHA256':hashfile(assetPath),'runtimeAssetOutputCount':len(assetOutputs(newAssets)),'defaultPromotion':False,'limitations':['Three rounds are a first-pass before/after comparison, not the frozen seven-round release/default qualification.','GPU-idle permission is coordinated externally; unrelated user application remains untouched and reported.','Before/after product revision is the immutable stage receipt, not collector checkout revision.','No cold/streaming/UI/recording performance or GPU timestamps.']}
(out/('plan-'+','.join(workloads)+f'-{a.start}-{a.stop}.json')).write_text(json.dumps(plan,indent=2)+'\n')
rows=[];families=a.family or ['legacy-gl','programmable-gl']
for rnd in range(a.start,a.stop):
 order=families[rnd%len(families):]+families[:rnd%len(families)]
 if rnd%2:order.reverse()
 for wi,workload in enumerate(workloads):
  for bi,family in enumerate(order):
   versions=['before','after'] if (rnd+wi+bi)%2==0 else ['after','before']
   for version in versions:
    side=stages[version];case=out/(f'{workload}-{family}-{version}-round{rnd}')
    if case.exists():raise SystemExit('Refuse to overwrite retained evidence '+str(case))
    if hashfile(side['binary'])!=side['binaryHash']:raise SystemExit('Frozen binary mutated')
    frames,warmup=(30,4) if workload=='torus' else (300,30)
    cmd=['python3',str(collector),'--binary',str(side['binary']),'--save',str(fixture),'--renderer',family,'--workload','torus' if workload=='torus' else 'flat-warm','--frames',str(frames),'--warmup',str(warmup),'--repeat','1','--build-command',side['command'],'--build-log',str(side['buildLog']),'--base',side['receipt']['base'],'--output',str(case)]
    if workload=='native':cmd+=['--zoom','1']
    if workload=='torus':cmd+=['--mode','Torus no clouds']
    env=dict(os.environ,GLOB2_RENDERER_SHADER_DIR=str(side['root']/'shaders'))
    print(f'Start round{rnd} {workload} {family} {version}',flush=True)
    start=time.time();run=subprocess.run(cmd,cwd=ROOT,env=env,text=True,capture_output=True,timeout=900)
    case.mkdir(exist_ok=True);(case/'collector.log').write_text(run.stdout+run.stderr)
    report=json.loads((case/'baseline.json').read_text());raw=report['runs'][0];log=Path(raw['log']).read_text()
    active=re.findall(r'BACKEND .*active=([^ \n]+)',log);checksums=re.findall(r'simulation_checksum=([0-9a-f]+)',log)
    row={'round':rnd,'workload':workload,'backend':family,'version':version,'product':side['receipt']['revision'],'seconds':time.time()-start,'active':active,'checksums':checksums,'collectorExit':run.returncode,'benchmarkExit':raw['exit_code'],'case':str(case),'command':cmd,'binarySHA256':side['binaryHash'],'provenanceSHA256':side['provenanceHash']}
    rows.append(row);(out/('runs-'+','.join(workloads)+f'-{a.start}-{a.stop}.json')).write_text(json.dumps(rows,indent=2)+'\n')
    if hashfile(side['binary'])!=side['binaryHash']:raise SystemExit('Frozen binary mutated during run')
    print(json.dumps(row),flush=True)
    if run.returncode or raw['exit_code'] or active!=[family] or not checksums or len(set(checksums))!=1:raise SystemExit('Invalid comparison; preserved failure receipts')
    if any(set(x['checksums'])!=set(checksums) for x in rows):raise SystemExit('Fixture checksum mismatch')
