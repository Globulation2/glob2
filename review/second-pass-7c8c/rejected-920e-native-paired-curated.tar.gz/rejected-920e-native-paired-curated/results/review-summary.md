# Second-pass native renderer comparison

Frozen before5adb2b3fa; after920e8e9d8. Identical fixture/runtime artwork/pins,1280×800; three rotating rounds,54 processes,22140 completed intervals.

| Workload | Backend | Wall p50 before→after ms | CPU p50 before→after ms | Wall p50 ratio | p95 ratio | p99 ratio | p50 paired MAD |
|---|---|---:|---:|---:|---:|---:|---:|
| fractional 2D clouds | legacy-gl | 9.521→9.559 | 9.213→9.260 | 0.992 | 0.984 | 0.991 | 0.001 |
| fractional 2D no clouds | legacy-gl | 2.716→2.810 | 2.903→3.052 | 1.001 | 1.011 | 1.136 | 0.108 |
| fractional 2D clouds | programmable-gl | 12.659→12.713 | 11.490→11.507 | 0.997 | 0.993 | 1.024 | 0.001 |
| fractional 2D no clouds | programmable-gl | 4.290→4.403 | 3.858→3.983 | 1.015 | 1.002 | 1.073 | 0.016 |
| fractional 2D clouds | sdl-gpu | 15.705→15.618 | 15.784→15.743 | 0.987 | 0.984 | 0.997 | 0.010 |
| fractional 2D no clouds | sdl-gpu | 6.125→5.935 | 6.154→5.956 | 0.976 | 1.045 | 0.999 | 0.013 |
| native 2D clouds | legacy-gl | 2.414→2.482 | 1.951→2.027 | 1.028 | 1.174 | 1.094 | 0.001 |
| native 2D no clouds | legacy-gl | 0.490→0.478 | 0.341→0.326 | 0.976 | 0.979 | 1.033 | 0.024 |
| native 2D clouds | programmable-gl | 3.197→3.044 | 2.466→2.317 | 0.952 | 0.948 | 0.872 | 0.011 |
| native 2D no clouds | programmable-gl | 0.478→0.463 | 0.235→0.216 | 0.975 | 0.927 | 0.988 | 0.016 |
| native 2D clouds | sdl-gpu | 3.226→3.299 | 3.004→3.061 | 1.023 | 1.103 | 1.283 | 0.032 |
| native 2D no clouds | sdl-gpu | 0.463→0.453 | 0.256→0.249 | 0.979 | 1.036 | 1.078 | 0.023 |
| torus Torus no clouds | legacy-gl | 6.107→6.201 | 4.949→5.027 | 1.019 | 0.758 | 0.675 | 0.013 |
| torus Torus no clouds | programmable-gl | 16.011→16.214 | 9.916→10.108 | 1.007 | 1.019 | 0.985 | 0.013 |
| torus Torus no clouds | sdl-gpu | 22.550→22.113 | 16.199→16.018 | 0.981 | 0.966 | 0.994 | 0.001 |

GL torus holds542→543; SDL540→540,90 completions per family/version. No ordinary admission deferrals.

Observed improvements are modest and often within paired noise; meaningful broad speedup is not established. All tail regressions remain flagged.

Three rounds instead of frozen seven-round gate. Torus30 measured/4warmup per process, not300/30.
No cold/streaming/editor/UI/recording/software/WebGPU performance or GPU timestamps.
Wall includes holds/retries/1x1 synchronous readback; final presentation excluded. CPU is whole-process CPU.
Concurrent user Flatpak remains active. No agent-owned GPU activity during window.
Five-percent regression ceiling unchanged; do not enlarge it to accommodate observed tail noise.
Different source bases include upstream tooling changes; dependency pins/runtime asset hashes and fixture checksum remain identical.

Supplemental8 nativecloud-only processes (2400intervals), not substituted for original54: SDL wallp99paired ratios1.142/1.218/0.848, median1.142/MAD6.65%; p95median1.081, CPUp99median1.000. Legacy controlwallp99ratio1.015. Original and repeat tails remain above unchanged5% ceiling; no submission CPU slowdown isolated.

Decision: SDL second-pass rejected; revert its code/tests/docs. Preserve all original54 plus supplemental8 receipts. GL/WebGPU retain separate review; final rebuilt source requires refreshed narrower validation.
