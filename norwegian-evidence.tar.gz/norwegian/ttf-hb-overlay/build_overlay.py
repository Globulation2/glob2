import hashlib, importlib.util, json, os, shutil, subprocess, tarfile
from pathlib import Path
root=Path.cwd();work=root/'artifacts/norwegian/ttf-hb-overlay';prefix=work/'prefix'
old=Path('/home/bradley/glob2-claude/build/sdl3/prefix')
hb=Path('/home/bradley/.codex/worktrees/c27d/glob2/build/sdl3')
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
lock=json.loads((root/'scons/sdl3-versions.json').read_text())
archive=old.parent/'sources'/lock['SDL_ttf']['archive']
assert hashfile(archive)==lock['SDL_ttf']['sha256']
assert hashfile(hb/'sources'/lock['harfbuzz']['archive'])==lock['harfbuzz']['sha256']
originals=[old/'lib/libSDL3.so.0.4.16',old/'lib/libSDL3_ttf.so.0.2.2',old/'include/SDL3_ttf/SDL_ttf.h',old/'include/SDL3_ttf/SDL_textengine.h']
before={str(p):hashfile(p) for p in originals}
source_parent=work/'source';source_parent.mkdir(exist_ok=True)
source=source_parent/'SDL3_ttf-3.2.2'
if not source.exists():
 with tarfile.open(archive) as package:package.extractall(source_parent,filter='data')
spec=importlib.util.spec_from_file_location('sdlrecipe',root/'scons/sdl3_dependencies.py');recipe=importlib.util.module_from_spec(spec);spec.loader.exec_module(recipe)
recipe.apply_source_patches(source,recipe.TTF_PATCHES)
hb_input=work/'hb-input';(hb_input/'lib/pkgconfig').mkdir(parents=True,exist_ok=True)
shutil.copytree(hb/'prefix/include/harfbuzz',hb_input/'include/harfbuzz',dirs_exist_ok=True)
shutil.copy2(hb/'prefix/lib/libharfbuzz.a',hb_input/'lib/libharfbuzz.a')
assert hashfile(hb_input/'lib/libharfbuzz.a')==hashfile(hb/'prefix/lib/libharfbuzz.a')
pc=(hb/'prefix/lib/pkgconfig/harfbuzz.pc').read_text().replace(str(hb/'prefix'),str(hb_input))
(hb_input/'lib/pkgconfig/harfbuzz.pc').write_text(pc)
env=dict(os.environ);env['PKG_CONFIG_PATH']=str(hb_input/'lib/pkgconfig')+':'+str(old/'lib/pkgconfig')
command=['cmake','-S',str(source),'-B',str(work/'build'),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_INSTALL_PREFIX='+str(prefix),'-DCMAKE_INSTALL_LIBDIR=lib','-DCMAKE_PREFIX_PATH='+str(old),'-DSDL3_DIR='+str(old/'lib/cmake/SDL3'),'-DSDLTTF_SAMPLES=OFF','-DSDLTTF_TESTS=OFF','-DSDLTTF_VENDORED=OFF','-DSDLTTF_HARFBUZZ=ON','-DBUILD_SHARED_LIBS=ON','-Dharfbuzz_LIBRARY='+str(hb_input/'lib/libharfbuzz.a'),'-Dharfbuzz_INCLUDE_PATH='+str(hb_input/'include/harfbuzz'),'-DCMAKE_INSTALL_RPATH=$ORIGIN']
subprocess.run(command,env=env,check=True)
subprocess.run(['cmake','--build',str(work/'build'),'--parallel','2'],env=env,check=True)
subprocess.run(['cmake','--install',str(work/'build')],env=env,check=True)
headers={}
for name in ('SDL_ttf.h','SDL_textengine.h'):
 a,b=old/'include/SDL3_ttf'/name,prefix/'include/SDL3_ttf'/name
 assert a.read_bytes()==b.read_bytes()
 headers[name]={'old_sha256':hashfile(a),'new_sha256':hashfile(b),'identical':True}
after={str(p):hashfile(p) for p in originals};assert before==after
newttf=prefix/'lib/libSDL3_ttf.so.0.2.2'
run=lambda args:subprocess.check_output(args,text=True)
record={'purpose':'Validation-only same-version SDL_ttf overlay repairing a HarfBuzz-disabled local runtime; no application headers/objects or shared prefix modified.','versions':{name:lock[name] for name in ('SDL','SDL_ttf','harfbuzz')},'configure_command':command,'headers':headers,'shared_prefix_before':before,'shared_prefix_after':after,'new_ttf_sha256':hashfile(newttf),'new_ttf_dynamic_section':run(['readelf','-d',str(newttf)]),'old_ttf_dynamic_section':run(['readelf','-d',str(old/'lib/libSDL3_ttf.so.0.2.2')]),'harfbuzz_static_archive':{'source':str(hb/'prefix/lib/libharfbuzz.a'),'source_tar_sha256':hashfile(hb/'sources'/lock['harfbuzz']['archive']),'archive_sha256':hashfile(hb_input/'lib/libharfbuzz.a'),'build_flags':(hb/'sources/harfbuzz-10.1.0-build/CMakeFiles/harfbuzz.dir/flags.make').read_text(),'cmake_cache_sha256':hashfile(hb/'sources/harfbuzz-10.1.0-build/CMakeCache.txt')},'source_patches':{str(p):hashfile(p) for p in recipe.TTF_PATCHES},'ld_library_path':str(prefix/'lib')+':'+str(old/'lib')}
(work/'build-provenance.json').write_text(json.dumps(record,indent=2)+'\n')
print('OVERLAY_READY',record['ld_library_path'],flush=True)
