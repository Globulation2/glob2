"""Measure raw SDL_ttf hinted bitmap geometry, independent of Glob2 draw normalization."""
import ctypes, hashlib, json, os, subprocess
from pathlib import Path
root=Path.cwd();work=root/'artifacts/norwegian/ttf-hb-overlay';prefix=work/'prefix'
old=Path('/home/bradley/glob2-claude/build/sdl3/prefix')
sdl=ctypes.CDLL(str(old/'lib/libSDL3.so.0'),mode=ctypes.RTLD_GLOBAL)
ttf=ctypes.CDLL(str(prefix/'lib/libSDL3_ttf.so.0'))
class Color(ctypes.Structure):_fields_=[('r',ctypes.c_uint8),('g',ctypes.c_uint8),('b',ctypes.c_uint8),('a',ctypes.c_uint8)]
class Surface(ctypes.Structure):_fields_=[('flags',ctypes.c_uint32),('format',ctypes.c_uint32),('w',ctypes.c_int),('h',ctypes.c_int),('pitch',ctypes.c_int),('pixels',ctypes.c_void_p),('refcount',ctypes.c_int),('reserved',ctypes.c_void_p)]
sdl.SDL_GetVersion.restype=ctypes.c_int
sdl.SDL_GetError.restype=ctypes.c_char_p
sdl.SDL_DestroySurface.argtypes=[ctypes.POINTER(Surface)]
ttf.TTF_Version.restype=ctypes.c_int
ttf.TTF_GetHarfBuzzVersion.argtypes=[ctypes.POINTER(ctypes.c_int)]*3
ttf.TTF_GetFreeTypeVersion.argtypes=[ctypes.POINTER(ctypes.c_int)]*3
ttf.TTF_Init.restype=ctypes.c_bool
ttf.TTF_OpenFont.argtypes=[ctypes.c_char_p,ctypes.c_float];ttf.TTF_OpenFont.restype=ctypes.c_void_p
ttf.TTF_CloseFont.argtypes=[ctypes.c_void_p]
ttf.TTF_SetFontDirection.argtypes=[ctypes.c_void_p,ctypes.c_int];ttf.TTF_SetFontDirection.restype=ctypes.c_bool
ttf.TTF_GetStringSize.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_int),ctypes.POINTER(ctypes.c_int)];ttf.TTF_GetStringSize.restype=ctypes.c_bool
ttf.TTF_RenderText_Blended.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t,Color];ttf.TTF_RenderText_Blended.restype=ctypes.POINTER(Surface)
version=lambda raw:[raw//1000000,(raw//1000)%1000,raw%1000]
def triple(call):
 values=[ctypes.c_int() for _ in range(3)];call(*(ctypes.byref(v) for v in values));return [v.value for v in values]
assert ttf.TTF_Init(),sdl.SDL_GetError()
hb_version=triple(ttf.TTF_GetHarfBuzzVersion);assert hb_version==[10,1,0],hb_version
free_version=triple(ttf.TTF_GetFreeTypeVersion);assert free_version[0]>0,free_version
sample='Det gjennomsnittlige angrepsnivået til koloniens krigere, der angrepshastighet og angrepsstyrke teller likt, på skalaen fra 1'
encoded=sample.encode();fontpath=root/'data/fonts/sans.ttf';measurements=[]
for size in (10,13,20):
 fonts=[ttf.TTF_OpenFont(str(fontpath).encode(),size*scale) for scale in (1,2)]
 assert all(fonts),sdl.SDL_GetError()
 for font in fonts:assert ttf.TTF_SetFontDirection(font,4),sdl.SDL_GetError()
 basew,baseh=ctypes.c_int(),ctypes.c_int();assert ttf.TTF_GetStringSize(fonts[0],encoded,0,ctypes.byref(basew),ctypes.byref(baseh))
 surfaces=[ttf.TTF_RenderText_Blended(font,encoded,0,Color(255,255,255,255)) for font in fonts]
 assert all(surfaces),sdl.SDL_GetError()
 raster=surfaces[1].contents
 measurements.append({'size':size,'authored_width':basew.value,'base_raw_width':surfaces[0].contents.w,'raw_2x_width':raster.w,'raw_2x_logical_width':raster.w/2,'hinting_width_delta_logical_px':raster.w/2-basew.value,'raw_2x_height':raster.h,'render_scale':2,'production_matrix_budget_if_size10':616 if size==10 else None,'size10_authored_fits_but_raw_2x_overruns':basew.value<=616<raster.w/2 if size==10 else None})
 for surface in surfaces:sdl.SDL_DestroySurface(surface)
 for font in fonts:ttf.TTF_CloseFont(font)
ttf.TTF_Quit()
loaded={}
for line in Path('/proc/self/maps').read_text().splitlines():
 path=line.split()[-1]
 if path.startswith('/') and any(name in path for name in ('libSDL3','libfreetype','libharfbuzz')):
  p=Path(path);loaded[str(p.resolve())]=hashlib.sha256(p.read_bytes()).hexdigest()
exported_hb_symbols=[line for line in subprocess.check_output(['nm','-D','--defined-only',str(prefix/'lib/libSDL3_ttf.so.0.2.2')],text=True).splitlines() if line.split()[-1].startswith('hb_')]
assert not exported_hb_symbols,exported_hb_symbols
record={'purpose':'HB-enabled raw hinting control, not a production wrapping/draw test. Same pinned font, source line, base sizes and2x raster sizes measured within one HB10.1.0 runtime. Application authoredDrawWidth normalization is not called.','sample':sample,'source_key':'[stat warrior level about]','font':str(fontpath),'font_sha256':hashlib.sha256(fontpath.read_bytes()).hexdigest(),'sdl_version':version(sdl.SDL_GetVersion()),'ttf_version':version(ttf.TTF_Version()),'harfbuzz_version':hb_version,'freetype_version':free_version,'measurements':measurements,'loaded_libraries':loaded,'harfbuzz_linkage':'TTF statically embeds pinned10.1.0 with LOCAL hb_version/hb_shape symbols and no exported hb_* symbols; any separately loaded system HarfBuzz is not its dependency or its binding.', 'exported_hb_symbols':exported_hb_symbols,'ld_library_path':os.environ.get('LD_LIBRARY_PATH',''),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(work/'raw-hinting-hb1-probe.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(record,ensure_ascii=False,indent=2))
