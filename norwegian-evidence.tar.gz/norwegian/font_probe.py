import ctypes,hashlib,json
from pathlib import Path
from PIL import Image,ImageDraw
root=Path.cwd();out=root/'artifacts/norwegian/font-probes';out.mkdir(exist_ok=True)
prefix=Path('/home/bradley/glob2-claude/build/sdl3/prefix')
sdl=ctypes.CDLL(str(prefix/'lib/libSDL3.so'),mode=ctypes.RTLD_GLOBAL);ttf=ctypes.CDLL(str(prefix/'lib/libSDL3_ttf.so'))
class Color(ctypes.Structure):_fields_=[('r',ctypes.c_uint8),('g',ctypes.c_uint8),('b',ctypes.c_uint8),('a',ctypes.c_uint8)]
ttf.TTF_Init.restype=ctypes.c_bool;assert ttf.TTF_Init()
ttf.TTF_OpenFont.argtypes=[ctypes.c_char_p,ctypes.c_float];ttf.TTF_OpenFont.restype=ctypes.c_void_p
ttf.TTF_FontHasGlyph.argtypes=[ctypes.c_void_p,ctypes.c_uint32];ttf.TTF_FontHasGlyph.restype=ctypes.c_bool
ttf.TTF_CloseFont.argtypes=[ctypes.c_void_p]
ttf.TTF_RenderText_Blended.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t,Color];ttf.TTF_RenderText_Blended.restype=ctypes.c_void_p
sdl.SDL_SaveBMP.argtypes=[ctypes.c_void_p,ctypes.c_char_p];sdl.SDL_SaveBMP.restype=ctypes.c_bool
sdl.SDL_DestroySurface.argtypes=[ctypes.c_void_p]
cat=json.loads((root/'artifacts/norwegian/native-edited.json').read_text());chars=set(''.join(cat.values()));chars={c for c in chars if ord(c)>32}
samples=['Norsk bokmål · æ ø å Æ Ø Å','Øk antall arbeidere · Utforskingsflagg · Løpebane','«Kun erobring» · 95 % · Bygg → Kaserne','Hold vertshusene forsynt. Arbeidere høster hvete.']
records=[];renders=[]
for rel in ('data/fonts/sans.ttf','browser/assets/sans-core.ttf'):
 for size in (10,13,20):
  font=ttf.TTF_OpenFont(str(root/rel).encode(),size);assert font
  missing=sorted(c for c in chars if not ttf.TTF_FontHasGlyph(font,ord(c)));assert not missing,(rel,size,missing)
  paths=[]
  for n,text in enumerate(samples):
   data=text.encode();surf=ttf.TTF_RenderText_Blended(font,data,len(data),Color(238,238,238,255));assert surf
   path=out/f'{Path(rel).stem}-{size}-{n}.bmp';assert sdl.SDL_SaveBMP(surf,str(path).encode());sdl.SDL_DestroySurface(surf);paths.append(str(path.relative_to(root)));renders.append((f'{rel} {size}px',Image.open(path).convert('RGBA')))
  records.append({'font':rel,'font_sha256':hashlib.sha256((root/rel).read_bytes()).hexdigest(),'size':size,'catalog_characters':len(chars),'missing':missing,'renders':paths});ttf.TTF_CloseFont(font)
ttf.TTF_Quit()
width=max(im.width for _,im in renders)+40;sheet=Image.new('RGB',(width,sum(im.height+24 for _,im in renders)+20),(22,26,31));draw=ImageDraw.Draw(sheet);y=10
for label,im in renders:draw.text((10,y),label,fill=(140,160,180));sheet.paste(im,(10,y+16),im);y+=im.height+24
sheet.save(out/'contact-sheet.png')
report={'limits':'Direct SDL_ttf font diagnostic only; production UI layout checks remain separate.','catalog_sha256':hashlib.sha256((root/'data/texts.nb.txt').read_bytes()).hexdigest(),'libraries':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (prefix/'lib/libSDL3.so',prefix/'lib/libSDL3_ttf.so')},'records':records}
(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('All',len(chars),'Norwegian catalog characters covered by full and browser core fonts at10/13/20px.')
