"""Package bounded review evidence; exclude credentials, environments and databases."""
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
files = set()
def include(pattern):
    files.update(p for p in ROOT.glob(pattern) if p.is_file())
for pattern in ('*.json', '*.md', '*test*.log', '*check*.log', '*structure*.log',
                '*build*.log', '*render*.log', '*regression*.log', '*lint*.log', 'hosted-platform-failure.log', 'run_native_renders.py', 'audit_native_renders.py', 'font_probe.py', 'sidebar_qualified_widths.py', '*width*.log', 'ttf-hb-overlay/build-provenance.json', 'ttf-hb-overlay/*.py', 'ttf-hb-overlay/*probe*.json', 'ttf-hb-overlay/*probe*.log', 'native-locale-smoke.*', 'locale-smoke.cpp', 'package_evidence.py', 'focused-site/site_init.py',
                'latest-kit/manifest.json', 'latest-kit/source/*', 'latest-kit/batches/*', 'latest-kit/reviews/*', 'latest-kit/drafts/nb/*', 'baseline-final-input/*', 'delta-renders/**/*.json', 'delta-renders/**/*.log', 'delta-renders/**/*.png', 'delta-render-input/*', 'delta-matrix-input/*', 'run_native_delta.py', 'audit_native_delta.py', 'kit/manifest.json', 'kit/source/*', 'kit/batches/*', 'kit/reviews/*',
                'kit/drafts/nb/*', 'machine-draft/*', 'native-review/*.json', 'browser/*/*.png', 'browser/*/*.json',
                'font-probes/report.json', 'font-probes/contact-sheet.png',
                'render-failed-attempt/*', 'content-audit/*', 'content-audit.py', 'render-input/*', 'renders/**/*.json', 'baseline-renders/**/*.json', 'baseline-renders/**/*.log', 'baseline-renders/**/*.png', 'renders/**/*.log'):
    include(pattern)
# Keep a bounded selection of matrix pages plus every representative screen.
for path in sorted((ROOT / 'renders').rglob('*.png')):
    if path.name.startswith('font-') and not (path.name.endswith('page-001.png') or path.name in {'font-10-scale-2-page-004.png', 'font-13-scale-2-page-006.png', 'font-20-scale-2-page-005.png'}):
        continue
    if not path.name.startswith('font-') and path.relative_to(ROOT / 'renders').as_posix() not in {
        'desktop/settings/settings.png', 'phone/lobby/reset-crop.png',
        'phone/tutorial-walking-training/tutorial-walking-training-briefing.png'}:
        continue
    files.add(path)
files.discard(ROOT / 'evidence-manifest.json')
size = sum(p.stat().st_size for p in files)
if size > 120 * 1024**2:
    raise SystemExit(f'Review evidence exceeds 120 MiB allowance: {size}')
manifest = {'schema':1, 'uncompressed_bytes':size, 'files':{p.relative_to(ROOT).as_posix():
    {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)},
    'limits':['First matrix pages and three before/after width-regression pages are included; complete measurements and page byte/hash inventories retained.',
              'Historical pre-caption-refinement screen PNGs are selected for the three UI regressions; all historical measurements/image hashes and all fresh final screen PNGs are retained.',
              'Raw authenticated API responses remain local; actual machine-draft text catalogs are included.',
              'Native/browsers/platform coverage is stated explicitly in evidence-summary.json.']}
manifest_path = ROOT / 'evidence-manifest.json'
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
files.add(manifest_path)
archive = ROOT / 'norwegian-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as output:
    for path in sorted(files):
        output.add(path,arcname='norwegian/'+path.relative_to(ROOT).as_posix(),recursive=False)
if archive.stat().st_size > 30*1024**2:
    raise SystemExit('Compressed evidence exceeds 30 MiB allowance')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,
                  'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)}))
