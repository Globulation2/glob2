"""Local focused verification only; leave the repository test registry unchanged.

Production objects, compiler flags, dependencies and normal engine support are
unchanged. Select the actual locale and SGSL continuation suites, including
startup, saved-language behavior and real-catalog script save/load boundaries.
"""
import sys
from pathlib import Path
repository = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(repository / 'test'))
import tests
sources = {'#src/app/SystemLanguageTest.cpp',
           '#src/scripting/sgsl/LegacyScriptCoverageTest.cpp',
           '#libgag/src/FontKerningTest.cpp'}
selected = [entry for entry in tests.ENGINE_TESTS
            if (entry if isinstance(entry, str) else entry[0]) in sources]
if len(selected) != len(sources):
    raise RuntimeError('Expected exactly the registered SystemLanguage, LegacyScriptCoverage and FontKerning sources')
tests.ENGINE_TESTS = selected
print('Focused native verification: SystemLanguage, LegacyScriptCoverage and FontKerning; original per-source options and normal production/support objects retained')
