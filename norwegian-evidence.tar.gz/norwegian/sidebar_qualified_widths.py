"""Reproduce actual 10px HUD label widths in the qualified HB-enabled TTF runtime."""
import ctypes,hashlib,json,os
from pathlib import Path
root=Path.cwd();work=root/'artifacts/norwegian/ttf-hb-overlay'
old=Path('/home/bradley/glob2-claude/build/sdl3/prefix')
sdl=ctypes.CDLL(str(old/'lib/libSDL3.so.0'),mode=ctypes.RTLD_GLOBAL)
ttf=ctypes.CDLL(str(work/'prefix/lib/libSDL3_ttf.so.0'))
sdl.SDL_GetError.restype=ctypes.c_char_p;sdl.SDL_GetVersion.restype=ctypes.c_int
ttf.TTF_Init.restype=ctypes.c_bool;ttf.TTF_Version.restype=ctypes.c_int
ttf.TTF_GetHarfBuzzVersion.argtypes=[ctypes.POINTER(ctypes.c_int)]*3
ttf.TTF_GetFreeTypeVersion.argtypes=[ctypes.POINTER(ctypes.c_int)]*3
ttf.TTF_OpenFont.argtypes=[ctypes.c_char_p,ctypes.c_float];ttf.TTF_OpenFont.restype=ctypes.c_void_p
ttf.TTF_CloseFont.argtypes=[ctypes.c_void_p]
ttf.TTF_SetFontDirection.argtypes=[ctypes.c_void_p,ctypes.c_int];ttf.TTF_SetFontDirection.restype=ctypes.c_bool
ttf.TTF_GetStringSize.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_int),ctypes.POINTER(ctypes.c_int)];ttf.TTF_GetStringSize.restype=ctypes.c_bool
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def triple(call):
 values=[ctypes.c_int() for _ in range(3)];call(*(ctypes.byref(v) for v in values));return [v.value for v in values]
version=lambda value:[value//1000000,(value//1000)%1000,value%1000]
assert ttf.TTF_Init(),sdl.SDL_GetError()
hb=triple(ttf.TTF_GetHarfBuzzVersion);assert hb==[10,1,0],hb
ft=triple(ttf.TTF_GetFreeTypeVersion)
fontpath=root/'data/fonts/sans.ttf';font=ttf.TTF_OpenFont(str(fontpath).encode(),10);assert font,sdl.SDL_GetError()
assert ttf.TTF_SetFontDirection(font,4),sdl.SDL_GetError()
labels=json.loads((root/'artifacts/norwegian/sidebar-fit-corrections.json').read_text());native=json.loads((root/'artifacts/norwegian/native-edited.json').read_text())
measurements=[]
for key,proposal in labels.items():
 assert native[key]==proposal,(key,native[key],proposal)
 item={'key':key,'value':native[key],'measurements':[]}
 for count in (1,1024,9999):
  text=native[key].replace('%0',str(count));width,height=ctypes.c_int(),ctypes.c_int()
  assert ttf.TTF_GetStringSize(font,text.encode(),0,ctypes.byref(width),ctypes.byref(height)),sdl.SDL_GetError()
  assert width.value<=134,(key,count,width.value)
  item['measurements'].append({'count':count,'text':text,'width':width.value,'height':height.value,'available_width':134,'fits':True,'margin':134-width.value})
 measurements.append(item)
ttf.TTF_CloseFont(font);ttf.TTF_Quit()
loaded={}
for line in Path('/proc/self/maps').read_text().splitlines():
 path=line.split()[-1]
 if path.startswith('/') and any(name in path for name in ('libSDL3','libfreetype','libharfbuzz')):
  p=Path(path);loaded[str(p.resolve())]=h(p)
record={'purpose':'Qualified-runtime width check of all10 final unwrapped sidebar labels at the actual10px sans font; complements final production captures.','catalog_sha256':h(root/'data/texts.nb.txt'),'native_json_sha256':h(root/'artifacts/norwegian/native-edited.json'),'font_sha256':h(fontpath),'font_size':10,'available_sidebar_width':134,'unit_max_count':1024,'count_rationale':'UnitUtils::MAX_COUNT=1024 per team (src/unit/UnitUtils.h36). Count9999 is a conservative four-digit stress case above any single-team unit count. Count1 verifies category-count wording without direct noun agreement.','versions':{'sdl':version(sdl.SDL_GetVersion()),'ttf':version(ttf.TTF_Version()),'harfbuzz':hb,'freetype':ft},'loaded_libraries':loaded,'harfbuzz_linkage':'Pinned10.1.0 statically embedded in TTF with LOCAL HB symbols; separately loaded systemHB is not its binding. See ttf-hb-overlay/build-provenance.json.','ld_library_path':os.environ.get('LD_LIBRARY_PATH',''),'measurements':measurements,'maximum_width':max(m['width'] for row in measurements for m in row['measurements']),'all_fit':True,'script_sha256':h(Path(__file__))}
assert record['catalog_sha256']=='a8f98ed78bd416ef1b9072a00f79eeb8d92d6404902970567f4cb27f8d83551c',record['catalog_sha256']
(root/'artifacts/norwegian/sidebar-qualified-widths.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print('QualifiedHB10.1.0: all30 widthsfit134; max',record['maximum_width'],'margin',134-record['maximum_width'])
for row in measurements:print(row['key'],[(m['count'],m['width']) for m in row['measurements']])
