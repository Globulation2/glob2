import concurrent.futures,hashlib,json,os,shutil,signal,subprocess,threading,time
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'artifacts/norwegian';OUT=BASE/'delta-renders';INPUT=BASE/'delta-render-input';PROFILES=BASE/'delta-render-profiles';BIN=ROOT/'build/linux/client/debug/dev-dev_fast-true-linker-auto/test/TranslationPreviewHarness';PREFIX=Path('/home/bradley/glob2-claude/build/sdl3/prefix');CAP=200*1024*1024
OUT.mkdir(exist_ok=True);INPUT.mkdir(exist_ok=True);PROFILES.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def storage():
 total=0
 for folder in (OUT,PROFILES):
  for p in folder.rglob('*'):
   try:
    if p.is_file():total+=p.stat().st_size
   except FileNotFoundError:pass
 return total
for source,target in [('native-edited.json','native.json'),('online-edited.json','online.json')]:shutil.copyfile(BASE/source,INPUT/target)
metadata={'locale':'nb','original_catalog_sha256':{'native':digest(ROOT/'data/texts.nb.txt'),'online':digest(ROOT/'platform/packages/i18n/locales/nb.json')},'source_sha256':json.loads((BASE/'latest-kit/manifest.json').read_text())['source_sha256'],'input_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'limits':'Full final catalog overlay; actual native Linux renderer at desktop and emulated-phone viewports, not a native mobile build.'}
(INPUT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
status={'status':'waiting for compiled production harness','input':metadata,'max_capture_workers':3,'storage_cap_bytes':CAP,'commands':[],'limits':['Phone viewport is Linux touch presentation, not Android/iOS platform coverage.','Current harness does not exercise collapsed legacy tutorial messages.','Local campaign capture does not exercise online services or multiplayer connectivity.']};lock=threading.RLock();stop=threading.Event()
def write():
 with lock:
  status['bytes']=storage();(OUT/'summary.json').write_text(json.dumps(status,indent=2)+'\n')
write();deadline=time.monotonic()+10800
while not (BIN.is_file() and BIN.stat().st_size>1000000 and os.access(BIN,os.X_OK)):
 if time.monotonic()>deadline:raise RuntimeError('Harness did not finish building within3h')
 time.sleep(5)
status['status']='compiled harness available; waiting for final build marker';write()
while not (BASE/'render-build-ready').exists():
 if time.monotonic()>deadline:raise RuntimeError('Final build marker not supplied within3h')
 time.sleep(2)
# Root releases this marker only after the final source/catalog freeze and build.
# Refresh the inputs at that boundary, rather than keeping earlier draft hashes.
for source,target in [('native-edited.json','native.json'),('online-edited.json','online.json')]:shutil.copyfile(BASE/source,INPUT/target)
native=json.loads((INPUT/'native.json').read_text());lines=(ROOT/'data/texts.nb.txt').read_text().splitlines();assert native==dict(zip(lines[::2],lines[1::2]))
assert json.loads((INPUT/'online.json').read_text())==json.loads((ROOT/'platform/packages/i18n/locales/nb.json').read_text())
metadata['original_catalog_sha256']={'native':digest(ROOT/'data/texts.nb.txt'),'online':digest(ROOT/'platform/packages/i18n/locales/nb.json')}
metadata['input_revision']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
(INPUT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');status['input']=metadata
old=json.loads((BASE/'baseline-final-input/native.json').read_text())
changed={k for k in native if native[k]!=old.get(k)}
assert changed=={'[Building Defaults]','[settings Building defaults]','[Reset to defaults]','[briefing]','[stat win probability]','[stat win probability about]'},changed
assert json.loads((INPUT/'online.json').read_text())==json.loads((BASE/'baseline-final-input/online.json').read_text())
MATRIXINPUT=BASE/'delta-matrix-input';MATRIXINPUT.mkdir(exist_ok=True)
(MATRIXINPUT/'native.json').write_text(json.dumps({k:native[k] for k in sorted(changed|{'[language-code]'})},ensure_ascii=False,indent=2)+'\n')
(MATRIXINPUT/'online.json').write_text('{}\n');(MATRIXINPUT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
status['changed_keys']=sorted(changed);status['matrix_control_key']='[language-code]'
status['executable_sha256']=digest(BIN);status['qualified_ttf_overlay_provenance']=str(BASE/'ttf-hb-overlay/build-provenance.json');status['status']='capturing';write()
commands=[('matrix','font-matrix',640,960,None)]
for label,w,h in [('desktop',1024,768),('phone',390,844)]:
 for screen in ['main','settings','settings-audio','lobby','lobby-players']:commands.append(('screen',label+'/'+screen,w,h,screen))
 for mode in ['gameplay','tutorial','tutorial:walking-training','tutorial:warrior-training']:commands.append(('game',label+'/'+mode.replace(':','-'),w,h,mode))
for mode,label,w,h,screen in commands:status['commands'].append({'label':label,'status':'pending','mode':mode,'width':w,'height':h,'screen':screen})
write()
def terminate(child):
 if child.poll() is not None:return
 try:os.killpg(child.pid,signal.SIGTERM)
 except ProcessLookupError:return
 try:child.wait(timeout=10)
 except subprocess.TimeoutExpired:
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  child.wait(timeout=10)
def run(item):
 if stop.is_set():
  with lock:item['status']='not run after previous capture failure';write()
  return
 mode,label,w,h,screen=(item[k] for k in ['mode','label','width','height','screen']);folder=OUT/label;folder.mkdir(parents=True,exist_ok=True);profile=PROFILES/label;profile.mkdir(parents=True,exist_ok=True)
 env=dict(os.environ,GLOB2_SDL3_PREFIX=str(PREFIX),GLOB2_USER_DATA_DIR=str(profile),SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='x11',GLOB2_RENDERER='software',GLOB2_MOBILE_UI='touch-auto' if label.startswith('phone/') else '0');env['LD_LIBRARY_PATH']=str(BASE/'ttf-hb-overlay/prefix/lib')+':'+str(PREFIX/'lib')
 args=[str(BIN),mode,str(ROOT),str(MATRIXINPUT if mode=='matrix' else INPUT),str(folder),str(w),str(h)]+([screen] if screen else []);command=args if mode=='matrix' else ['xvfb-run','-a','-s','-screen 0 1280x1024x24']+args
 with lock:
  item.update(status='running',command=command,environment={k:env[k] for k in ['GLOB2_RENDERER','GLOB2_MOBILE_UI','SDL_VIDEODRIVER','SDL_AUDIODRIVER','LD_LIBRARY_PATH','GLOB2_USER_DATA_DIR']});write()
 try:
  with (folder/'run.log').open('w') as log:
   child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);started=time.monotonic();limit=1800 if mode=='matrix' else 600
   with lock:item['timeout_seconds']=limit;write()
   while child.poll() is None:
    if stop.is_set() or storage()>CAP or time.monotonic()-started>limit:
     reason='Another capture failed' if stop.is_set() else 'Storage cap200MiB or explicit command timeout reached';stop.set();terminate(child);raise RuntimeError(reason)
    time.sleep(1)
   with lock:item.update(returncode=child.returncode,seconds=round(time.monotonic()-started,2))
  if child.returncode:raise RuntimeError('Capture returned '+str(child.returncode))
  if storage()>CAP:raise RuntimeError('Final files exceed aggregate200MiB cap')
  for p in profile.glob('translation-preview-*.bmp'):p.unlink()
  with lock:item['status']='complete';write()
 except Exception as exc:
  stop.set()
  with lock:item.update(status='failed',failure=str(exc));write()
  raise
try:
 run(status['commands'][0])
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  futures=[pool.submit(run,item) for item in status['commands'][1:]]
  for future in concurrent.futures.as_completed(futures):future.result()
 status['status']='captures complete; visual inspection pending';write();print('Captures complete',status['bytes'],'bytes')
except Exception:
 status['status']='capture failed; successful qualification not claimed';write();raise
