#include "SystemLanguage.h"
#include <iostream>
#include <string>
#include <vector>
#include <utility>
int main() {
    const std::vector<std::pair<std::string,std::string>> cases = {
        {"nb","nb"},{"nb-NO","nb"},{"NB_no","nb"},{"no","nb"},{"no-NO","nb"},
        {"no-bok","nb"},{"nn",""},{"nn-NO",""},{"no-nyn",""},
        {"no_NO_NY",""},{"no-NO-NY",""},{"no-NO-u-ca-ny","nb"},{"no-NO-x-ny","nb"},{"no-u-ca-nyn","nb"},{"no-x-nyn","nb"},{"de-DE","de"},{"en-US","en"}};
    for (const auto &[tag, expected] : cases) {
        const auto actual = SystemLanguage::catalogCode({tag,""});
        if (actual != expected) { std::cerr << tag << ": unexpected " << actual << '\n'; return 1; }
    }
    auto available = [](const std::string &code) { return code == "nb" || code == "de"; };
    if (SystemLanguage::choose({{"nn","NO"},{"de","DE"}}, available) != "de") return 2;
    if (SystemLanguage::choose({{"no","NO"},{"de","DE"}}, available) != "nb") return 3;
    if (SystemLanguage::choose({{"nb","NO"}}, [](const std::string &) { return false; }) != "en") return 4;
    std::cout << "20 native locale mapping/preference/availability checks passed\n";
}
