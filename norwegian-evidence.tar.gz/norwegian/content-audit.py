import gzip,hashlib,json,re,struct,subprocess
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'artifacts/norwegian/content-audit';OUT.mkdir(exist_ok=True)
PER_FILE=16*1024*1024;TOTAL=256*1024*1024;used=0
paths=[Path(p) for p in subprocess.check_output(['git','ls-files','maps','campaigns'],text=True).splitlines() if p.endswith('.map.gz')]
assert 0<len(paths)<=128
rows=[]
for path in paths:
 with gzip.open(path,'rb') as stream:data=stream.read(PER_FILE+1)
 assert len(data)<=PER_FILE,(path,'per-file cap')
 used+=len(data);assert used<=TOTAL,'total cap'
 def u32(pos):assert pos+4<=len(data);return struct.unpack_from('>I',data,pos)[0]
 def text(pos):
  n=u32(pos);assert n<=1024*1024 and pos+4+n<=len(data);raw=data[pos+4:pos+4+n];return raw.decode('utf-8'),pos+4+n
 name,pos=text(0);major,minor,teams,offset=struct.unpack_from('>iiii',data,pos);saved=data[pos+16];assert saved==0,(path,'not a map; signature shortcut not valid')
 marks=[m.start() for m in re.finditer(b'GaPl',data)];assert len(marks)==1,(path,'ambiguous/missing GaPl signature')
 sgsl,end=text(marks[0]+4);assert '\x00' not in sgsl
 row={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'decompressed_bytes':len(data),'map_name':name,'version_major':major,'version_minor':minor,'teams':teams,'saved':saved,'sgsl_offset':marks[0]+4,'sgsl_length':len(sgsl.encode()),'sgsl_source':sgsl,'sgsl_end':end,'show_calls':len(re.findall(r'\bshow\s*\(',sgsl))}
 # Empty SGSL parses zero stories (Parser.cpp), so the state tail has no PCs.
 assert not sgsl.strip()
 pos=end
 timer=u32(pos);pos+=4+teams*8
 area_count=u32(pos);pos+=4;assert area_count<=65536
 for _ in range(area_count):_,pos=text(pos);pos+=12
 flag_count=u32(pos);pos+=4;assert flag_count<=65536
 for _ in range(flag_count):_,pos=text(pos);pos+=2
 row.update(sgsl_area_count=area_count,sgsl_flag_count=flag_count,sgsl_timer=timer)
 if minor>=82:
  source,pos=text(pos);mode=data[pos];pos+=1;row.update(map_script_source=source,map_script_mode=mode)
  if mode==2:
   profile=u32(pos);pos+=4;state,pos=text(pos);presentation,pos=text(pos);initialized=data[pos];seeded=data[pos+1];pos+=2;_,pos=text(pos)
   row.update(js_profile=profile,js_state=state,js_presentation=presentation,js_initialized=initialized,js_seeded=seeded)
  else:assert mode==1
 if minor<75:
  obsolete,pos=text(pos);row['discarded_legacy_campaign_text']=obsolete
 objectives=[];hints=[]
 if minor>=75:
  count=u32(pos);pos+=4;assert count<=65536
  for _ in range(count):value,pos=text(pos);objectives.append(value);pos+=5 if minor>=76 else 4
 if minor>=76:
  briefing,pos=text(pos);row['mission_briefing']=briefing
  count=u32(pos);pos+=4;assert count<=65536
  for _ in range(count):value,pos=text(pos);hints.append(value);pos+=2
 row.update(objectives=objectives,hints=hints,content_parse_end=pos)
 rows.append(row)
(OUT/'sources.json').write_text(json.dumps({'limits':{'per_file':PER_FILE,'total':TOTAL,'files':128},'files':rows,'decompressed_total':used},ensure_ascii=False,indent=2)+'\n')
print('Files',len(rows),'uncompressed bytes',used,'nonempty SGSL',sum(bool(r['sgsl_source'].strip()) for r in rows))
for r in rows:
 if r['sgsl_source'].strip():print(r['path'],r['version_minor'],'SGSL bytes',r['sgsl_length'],'show',r['show_calls'],'source',r['sgsl_source'][:500])

print('Modern scripts',sum(bool(r.get('map_script_source')) for r in rows),'objectives',sum(len(r['objectives']) for r in rows),'hints',sum(len(r['hints']) for r in rows),'nonblank briefings',sum(bool(r.get('mission_briefing','').strip()) for r in rows))
for r in rows:
 if r['objectives'] or r['hints'] or r.get('mission_briefing','').strip():print(r['path'],'briefing',r.get('mission_briefing'),'objectives',r['objectives'],'hints',r['hints'])
