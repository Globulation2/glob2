import hashlib,json,subprocess
from collections import Counter
from pathlib import Path
R=Path.cwd();B=R/'artifacts/norwegian';O=B/'delta-renders'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=read(O/'summary.json');assert s['status']=='captures complete; visual inspection pending'
assert len(s['commands'])==19 and all(x['status']=='complete' and x['returncode']==0 for x in s['commands'])
old_native=read(B/'baseline-final-input/native.json');new_native=read(B/'delta-render-input/native.json');old_online=read(B/'baseline-final-input/online.json');new_online=read(B/'delta-render-input/online.json')
changed={'[Building Defaults]','[settings Building defaults]','[Reset to defaults]','[briefing]','[stat win probability]','[stat win probability about]'}
assert new_native.keys()-old_native.keys()=={'[stat win probability]','[stat win probability about]'};assert {k for k in new_native if old_native.get(k)!=new_native[k]}==changed;assert old_online==new_online
base=read(B/'renders/font-matrix/font-matrix.json');delta=read(O/'font-matrix/font-matrix.json');baselineaudit=read(B/'renders/audit.json');bidentity=base['evidence_identity'];didentity=delta['evidence_identity']
for field in ('locale','runtime_fonts','sdl_library_path','sdl_ttf_library_path','sdl_version','sdl_ttf_version','harfbuzz_version'):assert bidentity[field]==didentity[field],field
font_sources=[k for k in bidentity['source_sha256'] if k.startswith('libgag/')]
for k in font_sources:assert bidentity['source_sha256'][k]==didentity['source_sha256'][k],k
# Rendering integrations changed HUD/screens; full fresh screen captures cover them.
# Matrix function/samples code and all its production font/layout dependencies stay identical.
old_harness=subprocess.check_output(['git','show',bidentity['producer']['revision']+':tools/TranslationPreviewHarness.cpp'],text=True)
new_harness=(R/'tools/TranslationPreviewHarness.cpp').read_text()
def font_section(code):return code[code.index('std::vector<Sample> samples('):code.index('template<class T> class Preview')]
assert font_section(old_harness)==font_section(new_harness)
assert base['harfbuzz']==delta['harfbuzz']==[10,1,0]
for field,v in baselineaudit['libraries'].items():assert sha(Path(didentity[field]))==v['sha256'],field
assert bidentity['producer']['flags']==didentity['producer']['flags']
assert not didentity['producer']['dirty'];assert didentity['producer']['revision']==s['input']['input_revision']
assert delta['logical_width']==base['logical_width']==640 and delta['logical_height']==base['logical_height']==960
subset=read(B/'delta-matrix-input/native.json')
assert subset=={k:new_native[k] for k in changed|{'[language-code]'}}
assert read(B/'delta-matrix-input/online.json')=={}
old_english_text=subprocess.check_output(['git','show',bidentity['producer']['revision']+':data/texts.en.txt'],text=True).splitlines()
old_english=dict(zip(old_english_text[::2],old_english_text[1::2]))
new_english_text=(R/'data/texts.en.txt').read_text().splitlines();new_english=dict(zip(new_english_text[::2],new_english_text[1::2]))
assert new_english.keys()-old_english.keys()=={'[stat win probability]','[stat win probability about]'}
assert all(new_english[k]==v for k,v in old_english.items())
assert bidentity['source_sha256']['platform/packages/i18n/locales/en.json']==didentity['source_sha256']['platform/packages/i18n/locales/en.json']
control=[x for x in delta['samples'] if x['key']=='[language-code]'];replacements=[x for x in delta['samples'] if x['key'] in changed]
assert len(delta['samples'])==42 and len(control)==6 and len(replacements)==36
assert Counter((x['key'],x['size'],x['scale']) for x in replacements)==Counter((k,z,sc) for k in changed for z in (10,13,20) for sc in (1,2))
assert all(x['surface']=='native' and x['branch']=='' for x in delta['samples'])
assert all(x['has_glyphs'] and all(l['drawn_fits_width'] and l['drawn_fits_height'] for l in x['lines']) for x in delta['samples'])
assert all((O/'font-matrix'/l['png']).is_file() for x in delta['samples'] for l in x['lines'])
carry=[x for x in base['samples'] if not(x['surface']=='native' and x['key'] in changed)]
assert len(carry)==37512
for x in carry:
 values=old_native if x['surface']=='native' else old_online;newvalues=new_native if x['surface']=='native' else new_online
 assert values[x['key']]==newvalues[x['key']]
combined=carry+replacements
expected=[]
for surface,values in [('native',new_native),('online',new_online)]:
 for key,value in values.items():
  for branch in ([''] if isinstance(value,str) else value):
   for size in (10,13,20):
    for scale in (1,2):expected.append((surface,key,branch,size,scale))
assert len(combined)==37548
assert Counter(expected)==Counter((x['surface'],x['key'],x['branch'],x['size'],x['scale']) for x in combined)
identities=[]
for p in O.rglob('*.json'):
 j=read(p)
 if not isinstance(j,dict) or 'evidence_identity' not in j:continue
 i=j['evidence_identity'];assert i['executable_sha256']==s['executable_sha256'];assert i['input_metadata']==s['input'];assert i['producer']==didentity['producer'];assert i['harfbuzz_version']==[10,1,0]
 if 'captures' in j:
  assert all(c['checksum_before_draw']==c['checksum_after_draw'] for c in j['captures']),p
 identities.append((p,i))
assert len(identities)==19
for viewport in ('desktop','phone'):
 game=read(O/viewport/'gameplay/gameplay.json');probe=game['statistics_probe']
 assert probe['title']==new_native['[stat win probability]']
 assert probe['about']==new_native['[stat win probability about]']
 assert (O/viewport/'gameplay/gameplay-statistics.png').is_file()
 if viewport=='phone':
  assert probe['compact_metric_picker_opened']
  assert (O/viewport/'gameplay/gameplay-statistics-about.png').is_file()
 assert all(c['checksum_before_draw']==c['checksum_after_draw'] for c in game['captures'])
export=R/'build/linux/client/debug/dev-dev_fast-true-linker-auto/runtime-assets/data/texts.nb.txt';catalog=R/'data/texts.nb.txt';assert sha(export)==sha(catalog)==s['input']['original_catalog_sha256']['native']
resolved=[]
for p,i in identities:
 matches=[Path(directory)/'data/texts.nb.txt' for directory in i['runtime_search_paths'] if (Path(directory)/'data/texts.nb.txt').is_file()];assert matches and sha(matches[0])==sha(catalog)
 resolved.append({'capture':str(p.relative_to(R)),'first_resolved_catalog':str(matches[0]),'sha256':sha(matches[0])})
report={'status':'final catalog qualified by explicit baseline-plus-delta composition; visual inspection required separately','final_input':s['input'],'final_executable_sha256':s['executable_sha256'],'baseline_revision':bidentity['producer']['revision'],'baseline_input':bidentity['input_metadata'],'baseline_matrix_sha256':sha(B/'renders/font-matrix/font-matrix.json'),'delta_matrix_sha256':sha(O/'font-matrix/font-matrix.json'),'changed_keys':sorted(changed),'unchanged_text_variants':6252,'carried_samples':len(carry),'replaced_samples':len(replacements),'control_samples_excluded_from_final_count':len(control),'final_samples':len(combined),'all_glyphs_present':True,'all_drawn_bounds_fit':True,'font_renderer_source_library_inputs_identical':True,'runtime_export_sha256':sha(export),'runtime_resolution':resolved,'limits':['Baseline images retain actual older source/catalog provenance and are not relabeled final. Four changed UI keys and two new upstream statistic keys are coveredby36delta samples.','Full current native/online overlays applied to all18freshscreen/gamecommands afterrelatedHUDintegration.','Linuxsoftware/touchpresentation only, not physicalmobile; collapsedlegacytutorialmessage state and ScriptEditorScreen context not captured.']}
(O/'composition-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,indent=2))
