# Norwegian language brief

Variety: Norwegian Bokmål. Script: Latin. Region: Norway; neutral contemporary written Bokmål, not a regional dialect. Catalog/tag: nb, display name Norsk bokmål. Generic no may map to nb; explicit nn must not pretend to be Bokmål. Certification: agent-reviewed; not native-human-certified.

## Source basis and editorial rules

English catalog and actual game behavior determine meaning. Existing `data/texts.dk.txt`, `data/texts.sv.txt` and browser `da.json`/`sv.json` are comparison evidence only. Their agreement is not proof of Norwegian correctness. Danish kro / Swedish värdshus clarify that Inn is a service building. Danish sværm / Swedish svärm support keeping the intentional Swarm metaphor rather than inventing a bee-specific Hive.

Use direct du, brief active instructions, imperative buttons, sentence case, and familiar words. Språkrådet's [Kort om klarspråk](https://sprakradet.no/klarsprak/kunnskap-om-klarsprak/kort-om-klarsprak/) recommends audience-specific structure, short active sentences, understandable words and an independent reading. This supports short instructions without dropping conditions or consequences.

Compounds normally remain one word: spillinnstillinger, kartstørrelse, matforsyning, utforskingsflagg. [Språkrådet: Bindestrek](https://sprakradet.no/godt-og-korrekt-sprak/rettskriving-og-grammatikk/tegn/bindestrek/) says ordinary compounds normally have no hyphen, but compounds beginning with abbreviations take one. Therefore KI-motstander, KI-generert, API-nøkkel, JSON-fil. Do not introduce arbitrary spaces to make long compounds fit; shorten the phrase or wrap safely.

[Regjeringen.no's KI style entry](https://www.regjeringen.no/no/om-nettstedet/innholdsstrategi/ti-bud-for-godt-innhold-pa-regjeringen.no/skriveregler-for-regjeringen.no/ki/id3016850/) explicitly uses KI for kunstig intelligens and hyphenated KI compounds. Translate descriptive AI labels to KI. Preserve proper product/model names, source code identifiers, paths and URLs. Whether branded studio labels are invariant must follow the existing catalog invariant contract.

Avoid Danish remnants: enhed→enhet; indstillinger→innstillinger; bygning is Norwegian but bygge/bygger (not bygge-r? inspect form); krigere, arbeidere, utforskere; fuld skærm→fullskjerm; gem→lagre; vælg→velg; tilføj→legg til; fejl→feil. Avoid Swedish remnants: inte→ikke; och→og; arbetare→arbeidere; lägg till→legg til.

## Terminology decisions

| English | Bokmål | Rationale/context |
|---|---|---|
| worker / workers | arbeider / arbeidere | Bokmålsordboka's [arbeider](https://ordbokene.no/nob/bm/arbeider) includes a nonreproductive working individual in insect societies, unusually close to this game. |
| warrior / warriors | kriger / krigere | Retains game role, rather than general soldier terminology. |
| explorer / explorers | utforsker / utforskere | Role explores/scouts. [Bokmålsordboka: utforske](https://ordbokene.no/bm/65315) attests investigating nature; noun derived regularly. |
| unit | enhet | Generic class covering the three unit roles. |
| colony | koloni | Whole player settlement; keep distinct from Swarm building. |
| swarm | sverm | [Bokmålsordboka: sverm](https://ordbokene.no/nob/bm/sverm) describes a moving group, especially insects. An intentional in-game building name; English explanation Creates new units controls its tooltip. |
| inn | vertshus | Feeds units; avoid hotel or restaurant that could change building identity. |
| market | marked | Exchanges fruit between teams. |
| barracks | kaserne | Trains fighting ability; not a unit factory. |
| school / hospital | skole / sykehus | Building ability / healing service respectively. |
| racetrack / swimming pool | løpebane / svømmebasseng | Improve movement/swimming; no implied racing mechanics. |
| defense tower / stone wall | forsvarstårn / steinmur | Defensive buildings. |
| flag | flagg | Assigns attraction/work area; not direct movement orders. |
| exploration flag / war flag / clearing flag | utforskingsflagg / krigsflagg / ryddeflagg | Keep names consistent across UI and tutorial. Clearing removes resources, not resetting the game. |
| forbidden area / guard area | forbudt område / vaktområde | Area designation, not terrain. |
| wood / wheat / stone / algae | trevirke / hvete / stein / alger | Wood as material, distinct from a living tre. |
| fruit / food | frukt / mat | Fruit variety and basic food economy remain distinct. |
| upgrade | oppgrader / oppgradering | Imperative action versus noun; not identical to repair. |
| map / map editor / generator | kart / kartredigering / kartgenerator | Map is terrain, not a card. |
| match / room / team | kamp / rom / lag | Keep online and native multiplayer labels consistent. |
| rating / ranking | rating / rangering | Skill estimate vs ordered list; do not merge concepts. |
| replay / recording | reprise / opptak | Deterministic saved match vs audiovisual capture. |
| sign in / sign out | logg inn / logg ut | Two words as verbs; innlogging as noun. |
| upload / download | last opp / last ned | opplasting/nedlasting as nouns. |
| save / cancel / delete / close | lagre / avbryt / slett / lukk | Separate dismiss/close from canceling an operation. |
| credits (currency) / credits (attribution) | kreditter / bidragsytere | Inspect context; never translate monetary balance as attribution. |
| retry / undo / restore | prøv igjen / angre / gjenopprett | Distinguish retry safety, edit undo and historical restoration. |

## Contract and rendered-context checks

Keep `%0`, `%1`, `{count}`, `{slot0}` and other parameters unchanged in identity and multiplicity. Preserve literal escaped newlines, required markup, key identifiers and protocol names. Use nb one/other plural categories according to runtime Intl.PluralRules; do not copy English singular grammar into other. Number/date formatting belongs to Intl, not hand-inserted English punctuation.

Check æ ø å Æ Ø Å at 10/13/20 game pixels. Render longer compounds, complete tutorial paragraphs, button rows and browser phone layouts. Split building-tooltip lines must be read together: e.g. Market's 'Allows the exchange of' + 'fruits with others'; reorder Norwegian naturally while respecting the layout. A blank optional second line may be valid.

Unresolved uncertainty: Hive Mind is a named interface feature; preserve its branded name if required by invariants, otherwise inspect all surrounding usage before choosing a translation. Likewise Credits uses two unrelated senses. These are review queues, not approved blanket substitutions.

Final decisions: Hive Mind is retained as the feature name across both interfaces. Credits are context-specific: native attribution uses bidragsytere, while online purchasing/admin balances use kreditter. No unresolved terminology findings remain after the final meaning and editorial rechecks.
