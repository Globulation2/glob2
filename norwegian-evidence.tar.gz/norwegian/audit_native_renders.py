import hashlib,json
from collections import Counter
from pathlib import Path
R=Path.cwd();B=R/'artifacts/norwegian';O=B/'renders'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((O/'summary.json').read_text());assert s['status']=='captures complete; visual inspection pending',s['status']
assert len(s['commands'])==19
assert all(x['status']=='complete' and x['returncode']==0 for x in s['commands'])
m=json.loads((O/'font-matrix/font-matrix.json').read_text());actual=m['samples'];expected={}
for surface in ('native','online'):
 for key,value in json.loads((B/f'baseline-final-input/{surface}.json').read_text()).items():
  for branch,text in (([('',value)]) if isinstance(value,str) else value.items()):
   for size in (10,13,20):
    for scale in (1,2):expected[surface,key,branch,size,scale]=text
assert Counter((x['surface'],x['key'],x['branch'],x['size'],x['scale']) for x in actual)==Counter(expected.keys())
assert all(x['has_glyphs'] for x in actual)
bounds_failures=[dict(key=x['key'],surface=x['surface'],size=x['size'],scale=x['scale'],**l) for x in actual for l in x['lines'] if not(l['drawn_fits_width'] and l['drawn_fits_height'])]
page_inventory=json.loads((O/'font-matrix/page-inventory.json').read_text());assert page_inventory['pages_verified_before_pruning']
assert {l['png'] for x in actual for l in x['lines']}=={p['png'] for p in page_inventory['file_inventory']}
for p in page_inventory['file_inventory']:
 if p['retained']:assert sha(O/'font-matrix'/p['png'])==p['sha256']
identities=[]
for p in O.rglob('*.json'):
 if p.name in ('summary.json','audit.json'):continue
 j=json.loads(p.read_text())
 if 'evidence_identity' not in j:continue
 identity=j['evidence_identity'];assert identity['executable_sha256']==s['executable_sha256'],p
 assert identity['input_metadata']==s['input'],p
 identities.append((p,identity))
assert len(identities)==19,len(identities)
overlay=R/'artifacts/norwegian/ttf-hb-overlay/prefix/lib'
for p,i in identities:
 assert str(overlay) in i['sdl_ttf_library_path'],(p,i['sdl_ttf_library_path'])
assert m['harfbuzz']==[10,1,0],m['harfbuzz']
catalog=R/'data/texts.nb.txt';payload=R/'build/linux/client/debug/dev-dev_fast-true-linker-auto/runtime-assets/data/texts.nb.txt'
assert sha(payload)==s['input']['original_catalog_sha256']['native']
live_matches_capture=sha(catalog)==sha(payload)
paths=[]
for p,i in identities:
 matches=[]
 for directory in i['runtime_search_paths']:
  candidate=Path(directory)/'data/texts.nb.txt'
  if candidate.is_file():matches.append({'path':str(candidate.resolve()),'sha256':sha(candidate)})
 assert matches and matches[0]['sha256']==s['input']['original_catalog_sha256']['native'],(p,matches)
 paths.append({'capture':str(p.relative_to(R)),'first_resolved_catalog':matches[0],'all_matching_catalogs':matches})
report={'status':'automated production capture checks passed; visual inspection separately required' if not bounds_failures else 'capture completion, coverage, glyph, provenance and packaging checks passed; scale2 width discrepancies require separate qualification','input':s['input'],'executable_sha256':s['executable_sha256'],'commands':len(s['commands']),'identities':len(identities),'matrix_samples':len(actual),'matrix_lines':sum(len(x['lines']) for x in actual),'matrix_pngs':len({l['png'] for x in actual for l in x['lines']}),'all_glyphs_present':True,'all_production_draw_destinations_fit':not bounds_failures,'drawn_bounds_failures':bounds_failures,'live_catalog_sha256':sha(catalog),'live_matches_capture':live_matches_capture,'qualification':'Frozen capturedrevision validated. Latercatalogdeltas require independenttargetedqualification.' if not live_matches_capture else 'Capturedcatalogmatcheslivepayload.','libraries':{k:{'path':m['evidence_identity'][k],'sha256':sha(Path(m['evidence_identity'][k]))} for k in ('sdl_library_path','sdl_ttf_library_path')},'harfbuzz':m['harfbuzz'],'ttf_overlay':str(overlay),'runtime_export':{'path':str(payload),'sha256':sha(payload)},'runtime_catalog_resolution':paths,'capture_bytes':s['bytes']}
(O/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='runtime_catalog_resolution'},indent=2))
