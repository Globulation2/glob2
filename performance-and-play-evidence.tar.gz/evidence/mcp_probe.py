import json,urllib.request,base64
from pathlib import Path
out=Path('artifacts/direct-flight-performance/interactive');out.mkdir(exist_ok=True)
def rpc(method,params={}):
 req=urllib.request.Request('http://127.0.0.1:27396/mcp',data=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25'})
 return json.load(urllib.request.urlopen(req,timeout=15))
def call(name,args={}):return rpc('tools/call',{'name':name,'arguments':args})
if __name__=='__main__':
 (out/'initialize.json').write_text(json.dumps(rpc('initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'pr1196-visual-review','version':'1'}}),indent=2))
 tools=rpc('tools/list');(out/'tools.json').write_text(json.dumps(tools,indent=2));print(json.dumps(tools,indent=2))
