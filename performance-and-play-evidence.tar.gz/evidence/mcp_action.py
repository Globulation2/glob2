import sys,json,base64
from mcp_probe import call,out
name=sys.argv[1];args=json.loads(sys.argv[2]);label=sys.argv[3]
if name in ['ui_acquire_control','ui_screenshot','ui_status']:pass
else:args['token']=(out/'token.txt').read_text()
r=call(name,args)
for c in r.get('result',{}).get('content',[]):
 if c.get('type')=='image':(out/(label+'.png')).write_bytes(base64.b64decode(c['data']))
 elif c.get('type')=='text':
  print(c['text'])
  if name=='ui_acquire_control':(out/'token.txt').write_text(json.loads(c['text'])['token'])
(out/(label+'.json')).write_text(json.dumps({'tool':name,'arguments':{k:v for k,v in args.items() if k!='token'},'result':{k:v for k,v in r.get('result',{}).items() if k!='content'},'text':[c for c in r.get('result',{}).get('content',[]) if c.get('type')=='text']},indent=2))
