from pathlib import Path
import time,json,subprocess,sys
root=Path.cwd();a=root/'artifacts/resource-refactor';sys.path.insert(0,str(a))
from paired_provenance import sha,environment_snapshot,tools_snapshot
while not (a/'master-f0-controls-summary.json').exists():time.sleep(5)
s=json.loads((a/'master-f0-controls-summary.json').read_text())
for arm in ('pure','approved'):
 v=s['arms'][arm];assert sha(v['binary'])==v['binary_sha256']
 p=json.loads(Path(v['provenance']).read_text());assert p['build_returncode']==0 and p['final_binary_matches_freeze']
 assert p['base_commit']==subprocess.check_output(['git','rev-parse','f0ff8384b'],text=True).strip()
 if arm=='pure':assert not p['final_git_status']
 else:assert all(p['approved_patch_equivalence'].values())
cmd=['python3',str(a/'paired_behavior.py'),s['arms']['pure']['binary'],s['arms']['approved']['binary'],str(a/'full-baseline-corpus/completion.json'),'--baseline-cwd',s['arms']['pure']['source'],'--candidate-cwd',s['arms']['approved']['source'],'--output',str(a/'tournament-f0-approved-fixes'),'--jobs','4','--ticks','90000']
p={'command':cmd,'environment_sha256':environment_snapshot(),'tools_sha256':tools_snapshot(),'control_summary_sha256':sha(a/'master-f0-controls-summary.json'),'timing_valid':False,'concurrency':4,'note':'Fresh base controls; no reuse from ee3 campaign. Concurrent builds/profiling invalidate timing.'}
(a/'tournament-f0-approved-fixes-launch.json').write_text(json.dumps(p,indent=2)+'\n')
with (a/'tournament-f0-approved-fixes.log').open('w') as log:
 result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
p['returncode']=result.returncode;(a/'tournament-f0-approved-fixes-launch.json').write_text(json.dumps(p,indent=2)+'\n');raise SystemExit(result.returncode)
