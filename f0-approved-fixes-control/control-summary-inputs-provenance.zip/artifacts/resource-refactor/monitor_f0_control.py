from pathlib import Path
import json,time,hashlib
root=Path(__file__).resolve().parent;run=root/'tournament-f0-approved-fixes';out=root/'tournament-f0-approved-fixes-monitor';out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
last=None
verified={}
while True:
 rows=[]
 for p in sorted(run.glob('*/*/run.json')):
  try:
   if p in verified:
    rows.append(verified[p]);continue
   r=json.loads(p.read_text());errors=[]
   if r.get('returncode')!=0 or r.get('timeout'):errors.append('nonzero or timeout')
   for name in ('result','engine_log','command_file'):
    file=Path(r[name])
    if not file.exists() or sha(file)!=r.get('artifact_sha256',{}).get(name):errors.append(name+' hash mismatch')
   result=json.loads(Path(r['result']).read_text()) if Path(r['result']).exists() else {}
   if result.get('status')!='completed':errors.append('not completed')
   row={'scenario':r['scenario'],'variant':r['variant'],'errors':errors,'ticks':result.get('ticks'),'termination':result.get('termination')}
   verified[p]=row;rows.append(row)
  except (OSError,ValueError,KeyError):continue
 summary={'timing_valid':False,'completed':len(rows),'failed_records':sum(bool(r['errors']) for r in rows),'classification':'Incremental integrity monitoring, not behavioral equivalence or performance evidence'}
 (out/'status.json').write_text(json.dumps(summary|{'runs':rows},indent=2)+'\n')
 if summary!=last:print(json.dumps(summary),flush=True);last=summary
 if (run/'summary.json').exists() or len(rows)==84:break
 time.sleep(30)
