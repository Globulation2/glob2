from pathlib import Path
import subprocess,os,json
root=Path.cwd();out=root/'artifacts/compact-runtime'
for v in ('reference','compact'):
 folder=out/'panel-profiles'/v;folder.mkdir(parents=True,exist_ok=True)
 env=os.environ.copy();env.update(SDL_VIDEODRIVER='x11',SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(folder/'profile'),GLOB2_PERF_DISABLE='1',PROFILE_SAVE=str(root/'artifacts/movement-planning/fixtures/large-colony.game'),PROFILE_MODE='gui',PROFILE_PAUSED='1',PROFILE_FRAMES='32',PROFILE_WARMUP='16',PROFILE_CLOUDS='0',PROFILE_NO_PRESENT='1',PROFILE_SELECT='unit',RUNTIME_REUSE='1',PROFILE_CAPTURE=str(folder/'frame.bmp'))
 cmd=['xvfb-run','-a','taskset','-c','4,5,6,7','valgrind','--tool=callgrind','--collect-atstart=no','--cache-sim=yes','--branch-sim=yes','--toggle-collect=GameGUI::drawUnitInfos()','--callgrind-out-file='+str(folder/'callgrind.out'),str(out/f'{v}-runtime-probe'),'--renderer','software','--window-size','640x480','--compute-threads','4','--mute','--no-fullscreen']
 (folder/'command.json').write_text(json.dumps({'command':cmd,'env':{k:value for k,value in env.items() if k.startswith(('GLOB2_','SDL_','PROFILE_','RUNTIME_'))}},indent=2))
 with (folder/'run.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 with (folder/'annotated.txt').open('w') as f:subprocess.run(['callgrind_annotate','--inclusive=yes',str(folder/'callgrind.out')],stdout=f,stderr=f,check=True)
 print(v,flush=True)
