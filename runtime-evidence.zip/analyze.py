from pathlib import Path
import json,numpy as np,matplotlib.pyplot as plt
p=Path('artifacts/compact-runtime');rng=np.random.default_rng(713);result={}
def pair(rows,keys,value):
 out={}
 for group in sorted({tuple(r[k] for k in keys) for r in rows if r['repeat']>=0}):
  a={r['repeat']:value(r) for r in rows if r['repeat']>=0 and tuple(r[k] for k in keys)==group and r['variant']=='reference'};b={r['repeat']:value(r) for r in rows if r['repeat']>=0 and tuple(r[k] for k in keys)==group and r['variant']=='compact'}
  ids=sorted(a.keys()&b.keys());av=np.array([a[i] for i in ids]);bv=np.array([b[i] for i in ids]);
  if (av<=0).any() or (bv<=0).any():
   out['/'.join(group)]={'pairs':len(ids),'before_mean':float(av.mean()),'after_mean':float(bv.mean()),'ratio':None,'reduction_pct':None,'ci95_reduction_pct':None};continue
  log=np.log(bv/av);boot=np.exp(log[rng.integers(0,len(log),(50000,len(log)))].mean(axis=1));lo,hi=np.quantile(boot,[.025,.975]);flo,fhi=np.quantile(boot,[.05/24,1-.05/24]);ratio=float(np.exp(log.mean()))
  out['/'.join(group)]={'pairs':len(ids),'before_mean':float(av.mean()),'after_mean':float(bv.mean()),'ratio':ratio,'reduction_pct':100*(1-ratio),'ci95_reduction_pct':[float(100*(1-hi)),float(100*(1-lo))],'ci_family_reduction_pct':[float(100*(1-fhi)),float(100*(1-flo))]}
 return out
for family,keys,metrics in [('render',['fixture','scenario'],{'frame_ms':lambda r:r['frame']['mean_ms'],'cpu_ms':lambda r:r['cpu_ms_per_frame'],'capture_ns_per_frame':lambda r:r['capture']['capture_ns']/r['capture']['frames'],'prepare_ns_per_frame':lambda r:r['capture']['prepare_ns']/r['capture']['frames']}),('engine',['fixture','mode'],{'wall_ns':lambda r:r['run_ns'],'cpu_ns':lambda r:r['cpu_ns'],'tick_p50_ns':lambda r:r['tick_p50_ns']})]:
 file=p/f'{family}-pairs/samples.json'
 if not file.exists():continue
 rows=json.loads(file.read_text());result[family]={name:pair(rows,keys,value) for name,value in metrics.items()}
 for g in {tuple(r[k] for k in keys) for r in rows}:
  for rep in {r['repeat'] for r in rows if tuple(r[k] for k in keys)==g}:
   rr=[r for r in rows if tuple(r[k] for k in keys)==g and r['repeat']==rep]
   assert len({r['checksum'] for r in rr})==1,(family,g,rep)
 if family=='render':
  assert all(r['capture']['captures']==(0 if r['scenario'].startswith('reuse') else r['capture']['frames']) for r in rows),'Expected one capture per frame'
result['method']={'bootstrap_resamples':50000,'seed':713,'summary':'paired geometric mean of run means; 95% pointwise percentile bootstrap; no multiple-comparison/global benefit claim'}
(p/'summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
fig,ax=plt.subplots(1,2,figsize=(14,5),layout='constrained')
for axis,family,metric in [(ax[0],'render','frame_ms'),(ax[1],'engine','wall_ns')]:
 if family not in result:continue
 data=result[family][metric];x=np.arange(len(data));y=np.array([d['reduction_pct'] for d in data.values()]);lo=np.array([d['ci95_reduction_pct'][0] for d in data.values()]);hi=np.array([d['ci95_reduction_pct'][1] for d in data.values()]);axis.errorbar(x,y,yerr=np.stack([y-lo,hi-y]),fmt='o',capsize=5,color='#167b83');axis.axhline(0,color='grey');axis.set_xticks(x,[k.replace('/','\n').replace('large-colony','colony').replace('ordinary-control','ordinary') for k in data],rotation=20,ha='right');axis.set_ylabel('Time reduction (%)');axis.set_title('Capture + scene + GUI drawing' if family=='render' else '512 engine ticks, reference and shadow');axis.grid(axis='y',alpha=.2)
fig.suptitle('Longer paired release runs — pointwise 95% confidence intervals')
for ext in ('png','svg','pdf'):fig.savefig(p/f'runtime-benefit.{ext}',dpi=180)
