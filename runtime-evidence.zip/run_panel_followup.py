from pathlib import Path
import subprocess,os,json,re,hashlib,time,sys
root=Path.cwd();out=root/'artifacts/compact-runtime';first=int(os.environ.get("RUNTIME_FIRST_REP","-1"));last=int(os.environ.get("RUNTIME_LAST_REP","10"));rows=json.loads((out/"panel-followup-pairs/samples.json").read_text()) if first>=10 else []
# Four production presentation cases plus explicit shared-requirement controls.
cases=[('ordinary-control','panels'),('large-colony','reuse-panels'),('large-colony','plain'),('large-colony','panels')]
for repeat in range(first,last):
 for ci,(fixture,scenario) in enumerate(cases):
  for variant in (('reference','compact') if (repeat+ci)%2 else ('compact','reference')):
   folder=out/'panel-followup-pairs'/f'{fixture}-{scenario}'/('warmup' if repeat<0 else f'rep-{repeat:02d}')/variant;folder.mkdir(parents=True,exist_ok=True)
   env=os.environ.copy();env.update(SDL_VIDEODRIVER='x11',SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(folder/'profile'),GLOB2_PERF_DISABLE='1',PROFILE_SAVE=str(root/f'artifacts/movement-planning/fixtures/{fixture}.game'),PROFILE_MODE='gui',PROFILE_PAUSED='1',PROFILE_FRAMES='4096',PROFILE_WARMUP='512',PROFILE_CLOUDS='0',PROFILE_NO_PRESENT='1')
   if scenario in ('panels','reuse-panels'):env['PROFILE_SELECT']='unit'
   if scenario.startswith('reuse'):env['RUNTIME_REUSE']='1'
   if scenario in ('ai','movement'):env['RUNTIME_EXTRA']=scenario
   binary=out/f'{variant}-runtime-probe';cmd=['xvfb-run','-a','taskset','-c','4,5,6,7',str(binary),'--renderer','software','--window-size','640x480','--compute-threads','4','--mute','--no-fullscreen']
   (folder/'command.json').write_text(json.dumps({'command':cmd,'env':{k:v for k,v in env.items() if k.startswith(('GLOB2_','SDL_','PROFILE_','RUNTIME_'))}},indent=2))
   started=time.monotonic()
   with (folder/'run.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
   s=(folder/'run.log').read_text();r={'repeat':repeat,'fixture':fixture,'scenario':scenario,'variant':variant,'process_elapsed_s':time.monotonic()-started,'loadavg':os.getloadavg(),'cpu_freq_khz':{str(c):int(Path(f'/sys/devices/system/cpu/cpu{c}/cpufreq/scaling_cur_freq').read_text()) for c in (4,5,6,7)}}
   for key in ('frame','draw','present'):
    match=re.search(rf'{key} .*',s)
    if not match:raise ValueError(s[-3000:])
    r[key]=dict((k,float(v)) for k,v in re.findall(r'([a-zA-Z0-9_]+)=([\d.]+)',match[0]))
   r['cpu_ms_per_frame']=float(re.search(r'process_cpu_ms_per_frame=([\d.]+)',s)[1]);r['capture']={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',re.search(r'RUNTIME_CAPTURE .*',s)[0])};r['checksum']=int(re.search(r'simulation_checksum=(\d+)',s)[1]);assert r['capture']['frames']==4096 and r['capture']['captures']==(0 if scenario.startswith('reuse') else 4096),r
   rows.append(r);print(json.dumps(r),flush=True)
   (out/'panel-followup-pairs/samples.json').write_text(json.dumps(rows,indent=2))
(out/'followup-binaries.json').write_text(json.dumps({v:{'sha256':hashlib.sha256((out/f'{v}-runtime-probe').read_bytes()).hexdigest()} for v in ('reference','compact')},indent=2))
