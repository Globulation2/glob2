from pathlib import Path
import shlex,subprocess,json
root=Path.cwd();out=root/'artifacts/compact-runtime'
for variant,source in [('reference',root/'artifacts/compact-unit-state/reference-source'),('compact',out/'compact-source')]:
 text=(source/'src/render/SoftwareRenderBenchmark.cpp').read_text()
 text=text.replace('#include "CommandLine.h"','#include "CommandLine.h"\n#include "render/scene/SceneExtract.h"\n#include "unit/planning/MovementShadow.h"')
 text=text.replace('decltype(terrainCache.workMetrics) initialWork{};', 'decltype(terrainCache.workMetrics) initialWork{};\n            decltype(gui.game.snapshots().metrics) captureBefore{};\n            std::uint64_t prepareNs=0;')
 text=text.replace('c0 = cpu(); measuredStart = SDL_GetPerformanceCounter();','c0 = cpu(); measuredStart = SDL_GetPerformanceCounter();\n                    captureBefore=gui.game.snapshots().metrics;')
 text=text.replace('gui.game.snapshots().invalidateBoundary();','if(!std::getenv("RUNTIME_REUSE"))gui.game.snapshots().invalidateBoundary();')
 text=text.replace('gui.prepareLocalPresentation();', '''const auto prepareStart=SDL_GetPerformanceCounter();
                if(const char *extra=std::getenv("RUNTIME_EXTRA")) {
                    auto requirements=SceneExtractor::requirements(gui.sceneRequest());
                    if(std::string(extra)=="ai")requirements|=SimulationSnapshot::Simulation;
                    if(std::string(extra)=="movement")requirements|=MovementPlanning::Shadow::requirements;
                    gui.game.captureReadBoundary({},true,requirements);
                }
                gui.prepareLocalPresentation();
                if(i>=0)prepareNs+=std::uint64_t((SDL_GetPerformanceCounter()-prepareStart)*1000000000ULL/freq);''')
 needle='printf("process_cpu_ms_per_frame=%.4f\\n", totalCpu * 1000 / draw.size());'
 text=text.replace(needle,needle+'''
            const auto& captures=gui.game.snapshots().metrics;
            printf("RUNTIME_CAPTURE frames=%zu captures=%llu capture_ns=%llu prepare_ns=%llu bytes_copied=%llu allocations=%llu\\n",draw.size(),
                (unsigned long long)(captures.captures-captureBefore.captures),
                (unsigned long long)(captures.captureNs-captureBefore.captureNs),
                (unsigned long long)prepareNs,
                (unsigned long long)(captures.bytesCopied-captureBefore.bytesCopied),
                (unsigned long long)(captures.allocations-captureBefore.allocations));''')
 if 'distribution("frame", frame)' not in text:
  text=text.replace('std::vector<double> draw, present;', 'std::vector<double> draw, present, frame;')
  text=text.replace('present.push_back(1000. * (c - b) / freq);', 'present.push_back(1000. * (c - b) / freq);\n                    frame.push_back(1000. * (c - a) / freq);')
  text=text.replace('distribution("present", present);', 'distribution("present", present);\n            distribution("frame", frame);')
 assert 'RUNTIME_CAPTURE' in text and 'captureBefore=gui' in text
 cpp=out/f'{variant}-runtime-probe.cpp';cpp.write_text(text)
 log=(out/f'{variant}-build.log').read_text().splitlines()
 line=next(x for x in log if ' -c ' in x and x.endswith('src/render/SoftwareRenderBenchmark.cpp'))
 args=shlex.split(line);incs=[a if not a.startswith('-I') or a[2:].startswith('/') else '-I'+str(source/a[2:]) for a in args if a.startswith('-I')]
 obj=out/f'{variant}-runtime-probe.o'
 compile=['g++','-std=gnu++20','-O3','-g','-DHAVE_CONFIG_H','-DSDL_MAIN_HANDLED','-DGLOB2_OFFICIAL_INSTANCE_ORIGIN="https://app.glob2online.com"',*incs,'-c',str(cpp),'-o',str(obj)]
 (out/f'{variant}-probe-compile.json').write_text(json.dumps(compile));subprocess.run(compile,check=True)
 link=shlex.split(next(x for x in log if x.startswith('g++ -o ') and '/test/SoftwareRenderBenchmark ' in x))
 link[2]=str(out/f'{variant}-runtime-probe')
 link=[str(obj) if a.endswith('/test/program-src_render_SoftwareRenderBenchmark.o') else a if a.startswith(('-','/')) or a=='g++' else str(source/a) for a in link]
 (out/f'{variant}-probe-link.json').write_text(json.dumps(link));subprocess.run(link,check=True)
