from pathlib import Path
import subprocess,json,os,time,hashlib
root=Path.cwd();out=root/'artifacts/compact-runtime';rows=[]
binaries={v:root/f'artifacts/compact-unit-state/glob2-{suffix}' for v,suffix in [('reference','reference'),('compact','compact-isolated')]}
for repeat in range(-1,10):
 for ci,(fixture,mode) in enumerate((('large-colony','reference'),('large-colony','shadow'),('ordinary-control','reference'),('ordinary-control','shadow'))):
  for variant in (('reference','compact') if (repeat+ci)%2 else ('compact','reference')):
   folder=out/'engine-pairs'/f'{fixture}-{mode}'/('warmup' if repeat<0 else f'rep-{repeat:02d}')/variant;folder.mkdir(parents=True,exist_ok=True)
   cmd=['taskset','-c','4,5,6,7',str(binaries[variant]),'game','run','--load-game',str(root/f'artifacts/movement-planning/fixtures/{fixture}.game'),'--ticks','512','--benchmark-warmup','64','--gradient-backend','cpu','--compute-threads','4','--output-dir',str(folder)]
   if mode=='shadow':cmd+=['--movement-shadow','1']
   env=os.environ.copy();env.update(GLOB2_USER_DATA_DIR=str(folder/'profile'),GLOB2_PERF_DISABLE='1');(folder/'command.json').write_text(json.dumps({'command':cmd,'env':{k:v for k,v in env.items() if k.startswith('GLOB2_')}},indent=2))
   started=time.monotonic()
   with (folder/'run.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
   d=json.loads((folder/'result.json').read_text());r={'repeat':repeat,'fixture':fixture,'mode':mode,'variant':variant,'run_ns':d['run_ns'],'cpu_ns':d['benchmark_run_cpu_ns'],'measured_ticks':d['benchmark_measured_ticks'],'checksum':d['finalChecksum'],'capture':d['ai_pipeline'],'loadavg':os.getloadavg(),'cpu_freq_khz':{str(c):int(Path(f'/sys/devices/system/cpu/cpu{c}/cpufreq/scaling_cur_freq').read_text()) for c in (4,5,6,7)},'process_elapsed_s':time.monotonic()-started,'tick_p50_ns':d['tick_p50_ns'],'tick_p95_ns':d['tick_p95_ns']};rows.append(r);print(json.dumps(r),flush=True);(out/'engine-pairs/samples.json').write_text(json.dumps(rows,indent=2))
(out/'engine-binaries.json').write_text(json.dumps({v:{'path':str(b),'sha256':hashlib.sha256(b.read_bytes()).hexdigest()} for v,b in binaries.items()},indent=2))
