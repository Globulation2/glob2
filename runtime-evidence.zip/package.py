from pathlib import Path
import zipfile,hashlib,json
p=Path('artifacts/compact-runtime');files=set()
for pattern in ('*.py','*.cpp','*.json','*.log','*.md','*.png','*.svg','*.pdf'):files.update(p.glob(pattern))
for folder in ('render-pairs','engine-pairs','panel-followup-pairs','panel-profiles'):
 for f in (p/folder).rglob('*'):
  if f.is_file() and 'profile' not in f.parts and f.suffix in ('.json','.log','.txt','.out','.bmp','.png'):files.add(f)
manifest=[]
with zipfile.ZipFile(p/'runtime-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(files):
  data=f.read_bytes();name=str(f.relative_to(p));z.writestr(name,data);manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
print('Packaged',len(files),'files,',(p/'runtime-evidence.zip').stat().st_size,'bytes')
with zipfile.ZipFile(p/'runtime-evidence.zip') as z:
 assert z.testzip() is None
 for entry in manifest:assert hashlib.sha256(z.read(entry['path'])).hexdigest()==entry['sha256']
