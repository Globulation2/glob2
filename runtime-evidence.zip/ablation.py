from pathlib import Path
import json,numpy as np
p=Path('artifacts/compact-runtime');rows=json.loads((p/'render-pairs/samples.json').read_text());rng=np.random.default_rng(713);out={}
for scenario,reuse in [('plain','reuse'),('panels','reuse-panels')]:
 pairs=[];caps=[];records=[]
 for rep in range(20):
  d={(r['scenario'],r['variant']):r for r in rows if r['repeat']==rep and r['fixture']=='large-colony'}
  before=(d[scenario,'reference']['frame']['mean_ms']-d[reuse,'reference']['frame']['mean_ms'])*1000
  after=(d[scenario,'compact']['frame']['mean_ms']-d[reuse,'compact']['frame']['mean_ms'])*1000
  cap=(d[scenario,'reference']['capture']['capture_ns']-d[scenario,'compact']['capture']['capture_ns'])/1024/1000
  pairs.append(before-after);caps.append(cap);records.append({'repeat':rep,'before_fresh_minus_reuse_us':before,'after_fresh_minus_reuse_us':after,'difference_us':before-after,'capture_counter_saving_us':cap})
 a=np.array(pairs);b=a[rng.integers(0,len(a),(50000,len(a)))].mean(axis=1)
 out[scenario]={'pairs':20,'difference_in_differences_us':float(a.mean()),'ci95_us':np.quantile(b,[.025,.975]).tolist(),'mean_capture_counter_saving_us':float(np.mean(caps)),'samples':records}
(p/'capture-ablation.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:{x:y for x,y in v.items() if x!='samples'} for k,v in out.items()},indent=2))
