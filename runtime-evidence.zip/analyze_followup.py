from pathlib import Path
import json
from analyze import pair
p=Path('artifacts/compact-runtime');rows=json.loads((p/'panel-followup-pairs/samples.json').read_text());r={'frame_ms':pair(rows,['fixture','scenario'],lambda x:x['frame']['mean_ms']),'cpu_ms':pair(rows,['fixture','scenario'],lambda x:x['cpu_ms_per_frame'])};(p/'panel-followup-summary.json').write_text(json.dumps(r,indent=2))
assert all(x['capture']['frames']==4096 and x['capture']['captures']==(0 if x['scenario'].startswith('reuse') else 4096) for x in rows)
for fixture,scenario,rep in {(x['fixture'],x['scenario'],x['repeat']) for x in rows}:
 a=[x for x in rows if (x['fixture'],x['scenario'],x['repeat'])==(fixture,scenario,rep)];assert len(a)==2 and a[0]['checksum']==a[1]['checksum']
print('FOLLOWUP',json.dumps(r,indent=2))
