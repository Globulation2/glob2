import argparse,json,os,subprocess,hashlib,statistics,math,random,platform
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--repeat',type=int,default=10);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
cpus=os.sched_getaffinity(0);cpu=min(cpus)
bins={'baseline':a.baseline.resolve(),'candidate':a.candidate.resolve()}
result={'environment':{'platform':platform.platform(),'cpu':cpu,'load_before':os.getloadavg(),'limits_percent':{'capture_ns':5,'consumer_ns':5,'owner_ns':2}},'binaries':{k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in bins.items()},'pairs':[]}
def ci(values):
 logs=[math.log(x) for x in values];rng=random.Random(391);samples=sorted(statistics.mean(rng.choices(logs,k=len(logs))) for _ in range(10000))
 return {'change_percent':100*math.expm1(statistics.mean(logs)),'lower_95_percent':100*math.expm1(samples[250]),'upper_95_percent':100*math.expm1(samples[9750])}
for rep in range(a.repeat):
 pair={}
 for label in (('baseline','candidate') if rep%2==0 else ('candidate','baseline')):
  out=a.output/f'{rep:02d}-{label}';out.mkdir(exist_ok=True)
  env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',GLOB2_USER_DATA_DIR=str(out.resolve()/'profile'),GLOB2_ENTITY_EVIDENCE_DIR=str(out.resolve()))
  cmd=['taskset','-c',str(cpu),str(bins[label]),'--test-suite=WorldSnapshot','--test-case=paired entity storage workload*','--no-colors=true']
  with (out/'run.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  pair[label]=[json.loads(line[len('ENTITY_BENCH '):]) for line in (out/'run.log').read_text().splitlines() if line.startswith('ENTITY_BENCH ')]
  if len(pair[label])!=5:raise RuntimeError('benchmark case missing')
 for sc in range(5):
  for suffix in ['trace','game']:
   one=(a.output/f'{rep:02d}-baseline'/f'scenario-{sc}.{suffix}').read_bytes();two=(a.output/f'{rep:02d}-candidate'/f'scenario-{sc}.{suffix}').read_bytes()
   if one!=two:raise RuntimeError(f'{suffix} diverged in scenario {sc}, pair {rep}')
 result['pairs'].append(pair)
 (a.output/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
 print(f'pair {rep+1}/{a.repeat} passed canonical saves and per-tick traces',flush=True)
result['summary']=[]
for sc in range(5):
 summary={'scenario':sc,'metrics':{}}
 for metric in ['capture_ns','owner_ns','consumer_ns']:
  bounds=ci([pair['candidate'][sc][metric]/pair['baseline'][sc][metric] for pair in result['pairs']]);summary['metrics'][metric]=bounds
 summary['baseline']=result['pairs'][0]['baseline'][sc];summary['candidate']=result['pairs'][0]['candidate'][sc];result['summary'].append(summary)
result['environment']['load_after']=os.getloadavg()
(a.output/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['summary'],indent=2))
