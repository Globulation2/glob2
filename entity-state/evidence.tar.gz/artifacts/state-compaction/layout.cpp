#include "Unit.h"
#include "Building.h"
#include "sim/snapshot/WorldRecords.h"
#include <iostream>
#define RECORD(T) std::cout << #T << " size=" << sizeof(T) << " align=" << alignof(T) << '\n'
#define FIELD(T,F) std::cout << #T "." #F << " offset=" << offsetof(T,F) << " size=" << sizeof(T::F) << '\n'
int main() {
 RECORD(UnitState); RECORD(Unit); RECORD(BuildingStateRecord); RECORD(Building);
 RECORD(SimulationSnapshot::UnitView); RECORD(SimulationSnapshot::BuildingView);
 FIELD(UnitState,level); FIELD(UnitState,performance); FIELD(UnitState,hp); FIELD(UnitState,underAttackTimer);
 FIELD(BuildingStateRecord,localMaterials); FIELD(BuildingStateRecord,wishedMaterials);
}
