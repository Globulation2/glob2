#!/bin/bash
set -euo pipefail
cd /work
while ! test -f /inline-evidence/candidate-profile-3/result.json || ! grep -q '^totals:' /inline-evidence/candidate-3.callgrind.*-01 2>/dev/null; do sleep 5; done
bash /tmp/run-focused-tests.sh build/linux/client/release/retain-symbols/dev-linker-auto /inline-evidence/focused-tests
for count in 1 8; do
 /inline-evidence/linux-candidate.glob2 match verify test/fixtures/multiplayer/FourSquares1.g2mr --map-file maps/FourSquares1.map.gz --output-dir /inline-evidence/golden-$count --compute-threads "$count" > /inline-evidence/golden-$count.log 2>&1
 cmp test/fixtures/multiplayer/FourSquares1.verify-trace.txt /inline-evidence/golden-$count/checksums.txt
done
python3 /tmp/analyze-results.py /inline-evidence > /inline-evidence/comparison.log
printf 'Focused tests, golden traces at 1/8 threads, and continuation comparison passed.\n' > /inline-evidence/validation-complete.txt
