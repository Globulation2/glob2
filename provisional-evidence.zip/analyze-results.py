#!/usr/bin/env python3
import hashlib,json,re,statistics,sys
from pathlib import Path
root=Path(sys.argv[1]); result={}
for label in ('base','candidate'):
    rows=[]
    for repeat in (1,2,3):
        files=list(root.glob(f'{label}-{repeat}.callgrind.*-01'))
        assert len(files)==1,files
        data=files[0].read_text()
        totals=re.findall(r'^totals: (\d+)',data,re.M)
        assert len(totals)==1
        rows.append({'repeat':repeat,'owner_Ir':int(totals[0]),'dump':files[0].name})
    counts=[r['owner_Ir'] for r in rows]
    result[label]={'runs':rows,'median_Ir':statistics.median(counts),'min_Ir':min(counts),'max_Ir':max(counts)}
result['owner_Ir_change_percent']=100*(result['candidate']['median_Ir']/result['base']['median_Ir']-1)
result['measured_ticks']=1024
checks={}
for path in sorted(root.glob('*/result.json')):
    obj=json.loads(path.read_text())
    if path.parent.name.startswith(('linux-','base-profile-','candidate-profile-')):
        checks[path.parent.name]={'initialChecksum':obj['initialChecksum'],'finalChecksum':obj['finalChecksum'],'ticks':obj['ticks']}
assert len(checks)==8,checks
assert len({r['finalChecksum'] for r in checks.values()})==1,checks
result['continuation_results']=checks
base=(root/'linux-base-run/world.checksums').read_bytes()
candidate=(root/'linux-candidate-run/world.checksums').read_bytes()
assert base==candidate
result['matching_per_tick_checksums_sha256']=hashlib.sha256(base).hexdigest()
(root/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
