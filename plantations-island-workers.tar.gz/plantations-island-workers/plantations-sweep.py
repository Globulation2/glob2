from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json
out=Path('artifacts/plantations-island-workers/plantations-sweep');out.mkdir(exist_ok=True)
binary=str(Path('artifacts/plantations-island-workers/after-glob2').resolve())
cases=[]
for w,h,teams in [(128,128,4),(128,256,3),(256,128,3),(256,256,4),(512,256,4),(256,512,4),(512,512,8)]:
 for islands in [1,3,4]:
  for causeways in [0,1]:
   for workers in [1,8]:
    cases.append(dict(width=w,height=h,teams=teams,seed=7,workers=workers,options={'islands-per-colony':islands,'causeways':causeways,'outpost-inns':causeways,**{r+'-amount':0 if workers==1 else 300 for r in ['wheat','wood','stone','fruit','algae']}}))
(out/'requests.json').write_text(json.dumps(cases,indent=2))
def run(item):
 k,c=item;name=f'{k:03d}';cmd=[binary,'map','generate','plantations','--width',str(c['width']),'--height',str(c['height']),'--teams',str(c['teams']),'--workers',str(c['workers']),'--seed',str(c['seed']),'--report-file',str(out/(name+'.json'))]
 for key,value in c['options'].items():cmd+=['--set',f'{key}={value}']
 with (out/(name+'.log')).open('w') as log:
  try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 return {'case':k,'returncode':code}
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,enumerate(cases)))
(out/'results.json').write_text(json.dumps(results,indent=2));bad=[r for r in results if r['returncode']];print('Cases',len(results),'failures',bad,flush=True)
