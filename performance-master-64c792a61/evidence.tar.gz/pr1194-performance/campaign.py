"""Temporary paired release benchmark; preserves raw commands and results."""
import argparse,csv,hashlib,json,math,os,platform,random,statistics,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'test'))
from benchmark_parallel_compute import execute,digest

def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=['pilot','preflight','timing','verify','waits'],required=True);p.add_argument('--master',type=Path,required=True);p.add_argument('--pr',type=Path,required=True);p.add_argument('--master-cwd',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 manifest=json.loads((ROOT/'artifacts/pr1194-performance/manifest.json').read_text());out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
 variants=[('master',1,a.master.resolve(),a.master_cwd.resolve()),('pr',1,a.pr.resolve(),ROOT),('master',8,a.master.resolve(),a.master_cwd.resolve()),('pr',8,a.pr.resolve(),ROOT)]
 if a.mode=='preflight':variants=[v for v in variants if v[1]==8]
 (out/'metadata.json').write_text(json.dumps({'platform':platform.platform(),'manifest':manifest,'binaries':{str(v[2]):digest(v[2]) for v in variants},'mode':a.mode,'argv':sys.argv,'git_heads':{str(v[3]):subprocess.check_output(['git','-C',str(v[3]),'rev-parse','HEAD'],text=True).strip() for v in variants},'builds':'scons release=1 -j4; no dev_fast/PCH/unity; CPU backend'},indent=2)+'\n')
 rows=[];refs={}
 with (out/'measurements.jsonl').open('w') as log:
  for scenario in manifest['scenarios']:
   inp=Path(scenario['args'][1]);assert digest(inp)==scenario['input_sha256'],inp
   repeats=range(-1,manifest['repeats']) if a.mode=='timing' else [0]
   for repeat in repeats:
    shift=(repeat+1)%len(variants);ordered=variants[shift:]+variants[:shift]
    if repeat%2:ordered=list(reversed(ordered))
    for version,participants,binary,cwd in ordered:
     args=list(scenario['args'])+['--compute-threads',str(participants),'--gradient-backend','cpu','--compute-telemetry','waits' if a.mode=='waits' else 'off']
     if a.mode=='pilot':
      i=args.index('--ticks');args[i+1]=str(256 if '--map-file' in args else int(args[i+1])-2048+256)
      i=args.index('--benchmark-warmup');args[i+1]='0'
     if a.mode=='verify':args+=['--telemetry','checksums']
     dest=out/scenario['id']/str(repeat)/f'{version}-{participants}'
     row={'scenario':scenario['id'],'version':version,'participants':participants,'repeat':repeat,**execute(binary,args,dest,cwd=cwd)}
     result=row['result'];assert result['compute_threads']==participants,(version,result['compute_threads']);assert result['benchmark_measured_ticks']>0
     row['simulation_s']=result['run_ns']/1e9;row['run_cpu_s']=result['benchmark_run_cpu_ns']/1e9;row['cpu_us_per_tick']=result['benchmark_run_cpu_ns']/result['benchmark_measured_ticks']/1000
     row['p95_ms']=result['tick_p95_ns']/1e6;row['p99_ms']=result['tick_p99_ns']/1e6;row['rss_mib']=row['peak_rss_bytes']/1024**2
     histogram=result['benchmark_tick_histogram'];nonzero=[b for b in histogram if b['count']];last=nonzero[-1]
     row['worst_tick_bucket_ms']=[last['upper_ns_exclusive']/2/1e6,last['upper_ns_exclusive']/1e6]
     row['ticks_over_33_55ms']=sum(b['count'] for b in histogram if b['upper_ns_exclusive'] is None or b['upper_ns_exclusive']>=2**26)
     row['units']=sum(t['units'] for t in result['teams']);row['buildings']=sum(t['buildings'] for t in result['teams'])
     if a.mode=='verify':
      trace=sorted(dest.glob('*.checksums'));assert trace,trace
      signature={'traces':{p.name:digest(p) for p in trace},'ticks':result['ticks'],'termination':result['termination'],'finalChecksum':result['finalChecksum']}
      key=(scenario['id'],version)
      if key in refs:assert refs[key]==signature,(key,refs[key],signature)
      refs[key]=signature;row['verification_signature']=signature
     if a.mode=='timing':
      key=(scenario['id'],version)
      signature={k:result[k] for k in ['ticks','termination','initialChecksum','finalChecksum']}
      if key in refs:assert refs[key]==signature,(key,refs[key],signature)
      refs[key]=signature
     rows.append(row);log.write(json.dumps(row)+'\n');log.flush()
     print(f"{a.mode} {scenario['id']} r{repeat} {version}-{participants}: sim={row['simulation_s']:.3f}s cpu={row['run_cpu_s']:.3f}s p99={row['p99_ms']:.3f}ms rss={row['rss_mib']:.1f}MiB units={row['units']} ticks={result['ticks']}",flush=True)
 if a.mode=='timing':
  summary=[]
  for scenario in manifest['scenarios']:
   for participants in [1,8]:
    sets={v:[r for r in rows if r['scenario']==scenario['id'] and r['participants']==participants and r['version']==v and r['repeat']>=0] for v in ['master','pr']}
    entry={'scenario':scenario['id'],'participants':participants}
    for metric in ['simulation_s','run_cpu_s','cpu_us_per_tick','p95_ms','p99_ms','rss_mib','wall_s','cpu_s','units','buildings','ticks_over_33_55ms']:
     before=statistics.median(r[metric] for r in sets['master']);after=statistics.median(r[metric] for r in sets['pr']);entry[metric]={'master':before,'pr':after,'change_pct':100*(after/before-1) if before else None}
    ratios=[pr['simulation_s']/base['simulation_s'] for base,pr in zip(sorted(sets['master'],key=lambda r:r['repeat']),sorted(sets['pr'],key=lambda r:r['repeat']))]
    rng=random.Random(1194);bootstrap=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000));entry['paired_ratio_median']=statistics.median(ratios);entry['paired_ratio_bootstrap_95']=[bootstrap[249],bootstrap[9749]]
    entry['raw_simulation_s']={v:[r['simulation_s'] for r in sets[v]] for v in sets};summary.append(entry)
  (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
  with (out/'summary.csv').open('w') as f:
   writer=csv.writer(f);writer.writerow(['scenario','participants','master_sim_s','pr_sim_s','sim_change_pct','master_cpu_s','pr_cpu_s','master_p99_ms','pr_p99_ms','master_rss_mib','pr_rss_mib','master_units','pr_units'])
   for r in summary:writer.writerow([r['scenario'],r['participants'],r['simulation_s']['master'],r['simulation_s']['pr'],r['simulation_s']['change_pct'],r['run_cpu_s']['master'],r['run_cpu_s']['pr'],r['p99_ms']['master'],r['p99_ms']['pr'],r['rss_mib']['master'],r['rss_mib']['pr'],r['units']['master'],r['units']['pr']])
 print('Completed',len(rows),'runs',flush=True)
if __name__=='__main__':main()
