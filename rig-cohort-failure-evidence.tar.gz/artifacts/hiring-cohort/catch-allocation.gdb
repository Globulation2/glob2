set pagination off
set confirm off
set print thread-events off
set disable-randomization off
set exec-wrapper prlimit --as=4294967296 --cpu=180 --
python
import gdb
class AllocationFailure(gdb.Breakpoint):
 def stop(self):
  try:
   name=gdb.parse_and_eval("*(char **)($rsi+8)").string()
   return "bad_alloc" in name or "bad_array_new_length" in name
  except Exception:return False
AllocationFailure("__cxa_throw")
end
run
thread apply all bt 35
quit
