from pathlib import Path
import json,subprocess,os
p=Path(__file__).resolve().parent;out=p/'failure-diagnostics';record=json.load(open(out/'cached-status.json'));cmd=record['command'];cmd[cmd.index('-x')+1]=str(p/'catch-allocation.gdb');cmd[cmd.index('--output-dir')+1]=str(out/'cached-memory')
env=os.environ.copy();env.update(SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='dummy',GLOB2_ISOLATED_LIVE_HIRING='1');env.pop('GLOB2_ISOLATED_TRACE',None)
with (out/'cached-memory-gdb.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
(out/'cached-memory-status.json').write_text(json.dumps({'command':cmd,'returncode':r.returncode,'diagnostic_only':True},indent=2));print('Allocation failure diagnosis done')
