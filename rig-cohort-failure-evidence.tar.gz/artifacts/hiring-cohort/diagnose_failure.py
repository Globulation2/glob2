from pathlib import Path
import json,subprocess,os,time
p=Path(__file__).resolve().parent;root=Path.cwd();out=p/'failure-diagnostics';out.mkdir(exist_ok=True)
job=next(j for j in json.load(open(p/'manifest.json'))['games'] if j['id']=='river-nicowar-019')
link=json.load(open(p/'link-command-private.json'));link=[x for x in link if x!='-s'];link[link.index('-o')+1]=str(out/'glob2-cohort-symbols');subprocess.run(link,check=True)
base=[str(out/'glob2-cohort-symbols'),'game','run','--map-file',str(root/job['map']),'--game-seed',str(job['game_seed']),'--ticks','32768','--benchmark-warmup','0','--compute-threads','4','--gpu','off']
for ai in job['players']:base+=['--player',ai]
env=os.environ.copy();env.update(SDL_AUDIODRIVER='dummy',SDL_VIDEODRIVER='dummy');env.pop('GLOB2_ISOLATED_TRACE',None);env.pop('GLOB2_ISOLATED_LIVE_HIRING',None)
cmd=['prlimit','--as=4294967296','--cpu=180','--',*base,'--output-dir',str(out/'original')]
with (out/'original.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
(out/'original-status.json').write_text(json.dumps({'command':cmd,'returncode':r.returncode,'diagnostic_only':True},indent=2))
gdbfile=out/'catch-allocation.gdb';gdbfile.write_text('set pagination off\nset confirm off\nset print thread-events off\nset disable-randomization off\nset exec-wrapper prlimit --as=4294967296 --cpu=180 --\ncatch throw std::bad_alloc\nrun\nthread apply all bt 35\nquit\n')
env['GLOB2_ISOLATED_LIVE_HIRING']='1';cmd=['gdb','-batch','-x',str(gdbfile),'--args',*base,'--output-dir',str(out/'cached'),'--hiring-schedule','4:4:128:combined','--hiring-extras','2','--hiring-availability','available','--hiring-diversity','rounds','--hiring-execution','pool']
with (out/'cached-gdb.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
(out/'cached-status.json').write_text(json.dumps({'command':cmd,'returncode':r.returncode,'diagnostic_only':True},indent=2));print('Bounded failure diagnostics complete')
