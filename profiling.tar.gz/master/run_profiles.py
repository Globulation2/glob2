import hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path('/home/bradley/glob2')
SOURCE=Path('/tmp/glob2-air-profile-master')
OUT=ROOT/'artifacts/air-field-callgrind'
BINARY=SOURCE/'build/linux/client/release/retain-symbols/dev-linker-auto/src/glob2'
def run(name,args,extra=None):
    directory=OUT/name; directory.mkdir(exist_ok=True)
    env=dict(os.environ,DEBUGINFOD_URLS='',GLOB2_USER_DIR=str(directory/'profile'),GLOB2_USER_DATA_DIR=str(directory/'profile'))
    env.update(extra or {})
    command=list(map(str,args))
    metadata={'command':command,'cwd':str(SOURCE),'environment':{k:env[k] for k in ['DEBUGINFOD_URLS','GLOB2_USER_DIR','GLOB2_USER_DATA_DIR']},'extra_environment':extra or {},'start':time.time()}
    (directory/'command.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(name,flush=True)
    with (directory/'run.log').open('w') as stream:
        completed=subprocess.run(command,cwd=SOURCE,env=env,stdout=stream,stderr=subprocess.STDOUT)
    metadata.update(returncode=completed.returncode,finished=time.time())
    (directory/'command.json').write_text(json.dumps(metadata,indent=2)+'\n')
    if completed.returncode: raise RuntimeError(f'{name} failed; inspect {directory}/run.log')
    return directory

def profile(name,save,stop,warmup=128):
    common=['game','run','--load-game',str(save),'--ticks',str(stop),'--benchmark-warmup',str(warmup),'--compute-threads','4','--compute-telemetry','off','--gpu','off']
    native=run(name+'-native',[BINARY,*common,'--output-dir',OUT/(name+'-native')/'game'],{'GLOB2_AIR_CALLGRIND':'1'})
    directory=OUT/name; directory.mkdir(exist_ok=True)
    cg=run(name,['valgrind','--tool=callgrind','--instr-atstart=no','--separate-threads=yes','--read-inline-info=yes','--callgrind-out-file='+str(directory/'callgrind.out.%p'),'--log-file='+str(directory/'valgrind.log'),BINARY,*common,'--output-dir',directory/'game'],{'GLOB2_AIR_CALLGRIND':'1'})
    a=json.loads((native/'game/result.json').read_text()); b=json.loads((cg/'game/result.json').read_text())
    comparison={key:{'native':a[key],'callgrind':b[key],'match':a[key]==b[key]} for key in ['initialChecksum','finalChecksum','ticks','benchmark_measured_ticks']}
    comparison['input_sha256']=hashlib.sha256(save.read_bytes()).hexdigest()
    (cg/'verification.json').write_text(json.dumps(comparison,indent=2)+'\n')
    if not all(v['match'] for v in comparison.values() if isinstance(v,dict)):raise RuntimeError('Native and Callgrind simulation checksums differ')

if __name__=='__main__':
    metadata={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),'binary':str(BINARY),'binary_sha256':hashlib.sha256(BINARY.read_bytes()).hexdigest(),'compiler':subprocess.check_output(['g++','--version'],text=True),'valgrind':subprocess.check_output(['valgrind','--version'],text=True),'uname':subprocess.check_output(['uname','-a'],text=True),'flags':'release=1 dev_fast=0 retain_symbols=1 CXXFLAGS=-g1 LINKFLAGS=-g1; -O3, no PCH/unity; four air-field consumer TUs additionally use -g2 -gz=zlib for inline attribution','instrumentation':'Headless.cpp measurement-boundary hooks and premeasurement diagnostic logging; targeted debug flags in dev_compile.py. Complete patch retained.'}
    (OUT/'provenance.json').write_text(json.dumps(metadata,indent=2)+'\n')
    profile('midgame24k',ROOT/'artifacts/pr1193/handoff/fixtures/midgame24k.game.gz',24384)
    for terrain in ['islands','swamp']:
        profile(terrain,ROOT/f'artifacts/hiring-refresh-shortlists-20261015/performance/checkpoints/performance-{terrain}/original/game/final.game.gz',8576)

    profile('lava-shield',OUT/'lava-fixture/final.game.gz',8576)
