import importlib.util,json,hashlib,subprocess
from pathlib import Path
source=Path('/dev/shm/glob2-air-evidence/candidate-final/run_profiles.py')
spec=importlib.util.spec_from_file_location('profiles',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
import sys
variant=sys.argv[1]
m.OUT=Path('/dev/shm/glob2-air-evidence')/('stress-'+variant);m.OUT.mkdir(exist_ok=True)
if variant=='baseline':
    m.BINARY=Path('/dev/shm/glob2-air-baseline-glob2');m.SOURCE=Path('/tmp/glob2-air-profile-master')
save=next(Path('/dev/shm/glob2-air-evidence/policy-regressions').rglob('air-routing-stress-v167.game'))
(m.OUT/'provenance.json').write_text(json.dumps({'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=m.SOURCE,text=True).strip(),'binary_sha256':hashlib.sha256(m.BINARY.read_bytes()).hexdigest(),'warmup':128,'measured':32,'input_sha256':hashlib.sha256(save.read_bytes()).hexdigest(),'flags':'release=1 dev_fast=0 retain_symbols=1, CXXFLAGS=-g1, measurement-boundary Callgrind hooks only'},indent=2))
m.profile('stress32',save,160,128)
