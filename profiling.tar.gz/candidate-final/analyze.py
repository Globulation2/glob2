import importlib.util,json,re
from pathlib import Path
OUT=Path(__file__).resolve().parent
parser_path=OUT/'callgrind_parser.py'
spec=importlib.util.spec_from_file_location('parse_cg',parser_path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

def named_field(name):return name.startswith('field::AirDistanceField<')
def field(name):return named_field(name) or name.startswith('(anonymous namespace)::airDistancesFor(')
def air_steering(name):return name.startswith('Map::pathfindAirPointToPoint(') or name.startswith('bool field::airRoute<')
def selector(name):return any(name.startswith('Unit::'+method+'(') for method in ['findAirClearingDestination','findAirGuardDestination'])
def measure(parsed,predicate):
    edges=[e for e in parsed['edges'] if predicate(e['callee']) and not predicate(e['caller'])]
    return sum(e['cost']['Ir'] for e in edges),edges
runs=[]
for directory in sorted(OUT.iterdir()):
    if not directory.is_dir() or not (directory/'verification.json').exists():continue
    files=[]
    for path in sorted(directory.glob('callgrind.out.*')):
        if path.suffix=='.txt' or path.stat().st_size<100:continue
        f=module.parse_file(path)
        if f['events']:files.append(f)
    owners=[f for f in files if any(e['callee'].startswith(('Game::syncStep(', 'Game::advanceLiveSimulation(')) and e['cost']['Ir'] for e in f['edges'])]
    if len(owners)!=1:raise RuntimeError(f'Expected one simulation owner in {directory}, got {len(owners)}')
    owner=owners[0];total=owner['totals']['Ir']
    fields,field_edges=measure(owner,field)
    named_fields,named_edges=measure(owner,named_field)
    initialization,initialization_edges=measure(owner,lambda n:n.startswith('(anonymous namespace)::airDistancesFor('))
    # Source audit: these three TeamRouting functions own only the air field's
    # three vectors. Their direct operator-delete edges are field cleanup.
    cleanup_edges=[e for e in owner['edges'] if e['caller'].startswith(('Team::findNearestFood(', 'Team::findNearestHeal(', 'Team::findBestUpgrade(')) and e['callee'].startswith('operator delete(')]
    cleanup=sum(e['cost']['Ir'] for e in cleanup_edges)
    fields+=cleanup
    global_count=re.search(r'Collected\s*:\s*(\d+)',(directory/'valgrind.log').read_text())
    if not global_count or sum(f['totals']['Ir'] for f in files)!=int(global_count[1]):raise RuntimeError('Global Callgrind counts do not reconcile')
    selectors,selector_edges=measure(owner,selector)
    steering,steering_edges=measure(owner,air_steering)
    worker_fields=sum(measure(f,field)[0] for f in files if f!=owner)
    game,game_edges=measure(owner,lambda n:n.startswith(('Game::syncStep(', 'Game::advanceLiveSimulation(')))
    log=(directory/'run.log').read_text()
    match=re.search(r'AIR_PROFILE_BEGIN tick=(\d+) air_constraints=(\d+) units=(\d+) flyers=(\d+) width=(\d+) height=(\d+)',log)
    end=re.search(r'AIR_PROFILE_END tick=(\d+)',log)
    if not match or not end:raise RuntimeError('Missing profiling markers')
    begin,constraints,units,flyers,width,height=map(int,match.groups())
    result={'case':directory.name,'start_tick':begin,'end_tick':int(end[1]),'air_constraints':bool(constraints),'units_at_start':units,'flyers_at_start':flyers,'width':width,'height':height,'owner_thread':owner['thread'],'owner_instructions':total,'owner_game_sync_instructions':game,'owner_air_field_instructions':fields,'owner_named_field_instructions':named_fields,'owner_field_initialization_instructions':initialization,'owner_field_cleanup_instructions':cleanup,'field_initialization_edges':initialization_edges,'field_cleanup_edges':cleanup_edges,'owner_air_field_percent':100*fields/total,'owner_destination_selector_instructions':selectors,'owner_destination_selector_percent':100*selectors/total,'owner_air_steering_instructions':steering,'owner_air_steering_percent':100*steering/total,'worker_air_field_instructions':worker_fields,'air_field_entry_edges':field_edges,'destination_selector_entry_edges':selector_edges,'air_steering_entry_edges':steering_edges,'top_owner_self':sorted(owner['functions'],key=lambda f:f['cost']['Ir'],reverse=True)[:25],'thread_totals':[{'thread':f['thread'],'totals':f['totals']} for f in files]}
    (directory/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
    runs.append(result)
    print(directory.name, 'owner Ir',total,'air field %',round(result['owner_air_field_percent'],5),'selector %',round(result['owner_destination_selector_percent'],5),'constraints',bool(constraints),'flyers',flyers)
(OUT/'summary.json').write_text(json.dumps({'runs':runs,'metric':'Callgrind Ir (executed instructions), inclusive entry-edge attribution, including the dedicated airDistancesFor construction wrapper and direct TeamRouting field cleanup; field/selector/steering categories overlap and must not be added. Tiny inlined lifetime bookkeeping outside these boundaries is not separately attributable','checks':'Each per-thread self-cost sum reconciles with its Callgrind footer; summed thread counts equal the global Collected count. Native/profiled final checksums and measured tick counts compared per workload.'},indent=2)+'\n')
