# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: rendering.spec.js >> the default renderer is WebGL2 when the browser accelerates it (serial)
- Location: tests/rendering.spec.js:41:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "webgl2"
Received: "software"
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [aria-hidden]:
    - status: Starting the game…
    - generic:
      - progressbar
      - generic: 33 of 33 MB
    - combobox
  - generic "Globulation 2" [active] [ref=e3]
```

# Test source

```ts
  1   | const {clickCreateMap}=require('./editor-controls');
  2   | const {test, expect} = require('@playwright/test');
  3   | const {clickMainMenu,clickSettingsDone,clickCustomGameStart,clickControl,control}=require('./main-menu');
  4   | const state = page => page.evaluate(() => glob2Diagnostics.snapshot());
  5   | const screen = (page, name) => expect.poll(async () => (await state(page)).screen).toContain(name);
  6   | 
  7   | test('WebGL2 draws a playable match and resizes its drawing buffer', async ({page}, info) => {
  8   |   test.setTimeout(120000);
  9   |   const errors = [];
  10  |   page.on('pageerror', error => errors.push(String(error)));
  11  |   page.on('console', message => { if (/GL_INVALID|GL_INVALID_OPERATION|WebGL:.*(INVALID|error)|GPU mip preparation failed|Aborted/.test(message.text())) errors.push(message.text()); });
  12  |   await page.goto('/?renderer=webgl2&gl-errors=1');
  13  |   await screen(page, 'MainMenuScreen');
  14  |   expect((await state(page)).renderer).toBe('webgl2');
  15  |   expect((await state(page)).renderContext.width).toBeGreaterThan(0);
  16  |   await clickMainMenu(page,'custom'); await screen(page, 'CustomGameScreen');
  17  |   await clickCustomGameStart(page); // The lobby prepares its selected generated landscape.
  18  |   await expect.poll(async () => (await state(page)).tick, {timeout:60000}).toBeGreaterThan(25);
  19  |   await page.setViewportSize({width:1280,height:720});
  20  |   await expect.poll(async () => { const s = await state(page); return [s.width,s.height]; }).toEqual([1280,720]);
  21  |   await expect.poll(async () => { const gl=(await state(page)).renderContext; return [gl.width,gl.height,gl.error]; }).toEqual([1280,720,0]);
  22  |   await expect.poll(() => require('./pixels').hasRenderedPixels(page)).toBe(true);
  23  |   await page.screenshot({path:info.outputPath('webgl2-match.png')});
  24  |   await page.locator('#canvas').press('Escape',{delay:80});
  25  |   await clickControl(page,'quit'); await screen(page,'EndGameScreen');
  26  |   expect(errors).toEqual([]);
  27  | });
  28  | 
  29  | test('software renderer remains available', async ({page}) => {
  30  |   await page.goto('/?renderer=software');
  31  |   await screen(page,'MainMenuScreen');
  32  |   expect((await state(page)).renderer).toBe('software');
  33  |   expect(await page.evaluate(() => Boolean(document.querySelector('#canvas').getContext('2d')))).toBe(true);
  34  |   await clickMainMenu(page,'settings'); await screen(page,'SettingsScreen');
  35  | });
  36  | 
  37  | // Test browsers usually emulate WebGL2. These tests answer the shell's acceleration
  38  | // probe at the browser boundary; its renderer selection runs unchanged.
  39  | const UNMASKED_RENDERER_WEBGL = 0x9246;
  40  | for (const variant of ['serial','threaded']) {
  41  | test(`the default renderer is WebGL2 when the browser accelerates it (${variant})`, async ({page}) => {
  42  |   await page.addInitScript(name => {
  43  |     const getContext = HTMLCanvasElement.prototype.getContext;
  44  |     HTMLCanvasElement.prototype.getContext = function(type, attributes) {
  45  |       return getContext.call(this, type, type === 'webgl2' ? {...attributes, failIfMajorPerformanceCaveat:false} : attributes);
  46  |     };
  47  |     const getParameter = WebGL2RenderingContext.prototype.getParameter;
  48  |     WebGL2RenderingContext.prototype.getParameter = function(parameter) {
  49  |       return parameter === name || parameter === this.RENDERER ? 'Test hardware GPU' : getParameter.call(this, parameter);
  50  |     };
  51  |   }, UNMASKED_RENDERER_WEBGL);
  52  |   await page.goto('/?threads='+variant); await screen(page,'MainMenuScreen');
  53  |   const runtime = await state(page);
  54  |   test.skip(runtime.executionMode !== variant, `Interactive ${variant} runtime unavailable: ${runtime.threadFallback}`);
> 55  |   expect(runtime.renderer).toBe('webgl2');
      |                            ^ Error: expect(received).toBe(expected) // Object.is equality
  56  |   expect((await state(page)).renderContext.width).toBeGreaterThan(0);
  57  |   expect((await state(page)).renderContext.error).toBeNull();
  58  | });
  59  | 
  60  | }
  61  | 
  62  | const fallbacks = {
  63  |   unavailable: () => {
  64  |     const getContext = HTMLCanvasElement.prototype.getContext;
  65  |     HTMLCanvasElement.prototype.getContext = function(type, attributes) {
  66  |       return type === 'webgl2' ? null : getContext.call(this, type, attributes);
  67  |     };
  68  |   },
  69  |   emulated: name => {
  70  |     const getParameter = WebGL2RenderingContext.prototype.getParameter;
  71  |     WebGL2RenderingContext.prototype.getParameter = function(parameter) {
  72  |       return parameter === name ? 'ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (LLVM 10.0.0)), SwiftShader driver)'
  73  |         : getParameter.call(this, parameter);
  74  |     };
  75  |   },
  76  | };
  77  | for (const [reason, stub] of Object.entries(fallbacks)) {
  78  |   test(`the default renderer falls back to software when WebGL2 is ${reason}`, async ({page}) => {
  79  |     await page.addInitScript(stub, UNMASKED_RENDERER_WEBGL);
  80  |     await page.goto('/'); await screen(page,'MainMenuScreen');
  81  |     expect((await state(page)).renderer).toBe('software');
  82  |     expect(await page.evaluate(() => Boolean(document.querySelector('#canvas').getContext('2d')))).toBe(true);
  83  |     await clickMainMenu(page,'settings'); await screen(page,'SettingsScreen');
  84  |   });
  85  | }
  86  | 
  87  | 
  88  | for (const variant of ['serial', 'threaded']) {
  89  | test(`WebGL context restoration keeps the match and can recover repeatedly (${variant})`, async ({page}, info) => {
  90  |   test.setTimeout(240000);
  91  |   const errors = [];
  92  |   page.on('pageerror', error => errors.push(String(error)));
  93  |   await page.goto(`/?renderer=webgl2&gl-errors=1&threads=${variant}`); await screen(page,'MainMenuScreen');
  94  |   await expect.poll(async () => (await state(page)).assets.hd, {timeout:120000}).toBe('ready');
  95  |   await clickMainMenu(page,'custom'); await screen(page,'CustomGameScreen');
  96  |   await clickCustomGameStart(page); // The lobby prepares its selected generated landscape.
  97  |   await expect.poll(async () => (await state(page)).tick, {timeout:60000}).toBeGreaterThan(25);
  98  |   await expect.poll(async () => (await state(page)).artworkReady, {timeout:120000}).toBe(true);
  99  |   for (let count=1; count<=2; ++count) {
  100 |     await page.evaluate(() => {
  101 |       Module._glob2_context_action(0);
  102 |     });
  103 |     await expect.poll(async () => (await state(page)).contextLost).toBe(true);
  104 |     const suspended = await state(page);
  105 |     const paused = suspended.tick;
  106 |     if (count === 1) await page.evaluate(() => {
  107 |       Object.defineProperty(document, 'hidden', {configurable:true, get:() => true});
  108 |       document.dispatchEvent(new Event('visibilitychange'));
  109 |     });
  110 |     const viewport = count === 1 ? {width:1280,height:720} : {width:1200,height:900};
  111 |     await page.setViewportSize(viewport);
  112 |     // Exercise a real suspension interval, not just immediate restoration.
  113 |     await page.waitForTimeout(250);
  114 |     expect((await state(page)).tick).toBe(paused);
  115 |     await page.evaluate(() => Module._glob2_context_action(1));
  116 |     await expect.poll(async () => (await state(page)).contextRestores, {timeout:60000}).toBe(count);
  117 |     if (count === 1) {
  118 |       // Restoring the GPU must not resume a tab that is still hidden.
  119 |       const restored = await state(page);
  120 |       await expect.poll(async () => (await state(page)).loop).toBeGreaterThan(restored.loop + 3);
  121 |       expect((await state(page)).tick).toBe(paused);
  122 |       expect((await state(page)).frames).toBe(suspended.frames);
  123 |       await page.evaluate(() => {
  124 |         delete document.hidden;
  125 |         document.dispatchEvent(new Event('visibilitychange'));
  126 |       });
  127 |     }
  128 |     await expect.poll(async () => (await state(page)).tick).toBeGreaterThan(paused);
  129 |     await expect.poll(async () => {
  130 |       const s = await state(page);
  131 |       return [s.width,s.height,s.renderContext.width,s.renderContext.height];
  132 |     }).toEqual([viewport.width,viewport.height,viewport.width,viewport.height]);
  133 |     await expect.poll(() => require('./pixels').hasRenderedPixels(page)).toBe(true);
  134 |     expect((await state(page)).renderContext.error).toBe(0);
  135 |   }
  136 |   await page.screenshot({path:info.outputPath('webgl2-restored.png')});
  137 |   await page.locator('#canvas').press('Escape',{delay:80});
  138 |   await clickControl(page,'quit'); await screen(page,'EndGameScreen');
  139 |   expect(errors).toEqual([]);
  140 | });
  141 | }
  142 | 
  143 | test('WebGL context restoration retains settings, editor and confirmation controls', async ({page}, info) => {
  144 |   const errors = [];
  145 |   page.on('pageerror', error => errors.push(String(error)));
  146 |   await page.goto('/?renderer=webgl2&gl-errors=1');
  147 |   await screen(page, 'MainMenuScreen');
  148 |   let restores = 0;
  149 |   async function recover(expectedScreen) {
  150 |     await screen(page, expectedScreen);
  151 |     await page.evaluate(() => {
  152 |       Module._glob2_context_action(0);
  153 |     });
  154 |     await expect.poll(async () => (await state(page)).contextLost).toBe(true);
  155 |     await page.evaluate(() => Module._glob2_context_action(1));
```