Accelerated threaded startup reads `Module.renderer` in the application worker, while the browser probe stores the choice in the DOM realm. The worker then chooses software despite receiving a GPU canvas and stalls at loading. Proxy the existing startup query synchronously to the main thread and exercise both execution modes.

Also complete the real first-run hand choice in the touch presentation fixtures before checking text editing, gameplay/save reload and editor rotation. Keep the production onboarding flow unchanged.

Validation: 130 Node unit tests; five supported accelerated-startup cases across Chromium, headed Firefox and WebKit, with interactive threaded WebKit explicitly unavailable; nine responsive touch cases pass (three preexisting fixme). All 24 browser determinism/compatibility cases pass against a clean locally rebuilt Wasm source, including strict source provenance, scripting, catalogs, per-tick traces and save continuation. These are local emulated graphics paths. Full master CI remains pending; separate browser failures are still being repaired. No simulation or native execution changes.

[Before/after startup logs, binary/source provenance, build commands, screenshots and raw determinism outputs](https://github.com/Globulation2/glob2/tree/evidence/master-ci-recovery-1198/browser-startup).
