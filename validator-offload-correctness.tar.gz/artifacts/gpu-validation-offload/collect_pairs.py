from pathlib import Path
import json,subprocess
root=Path.cwd();directory=root/'artifacts/gpu-validation-offload';attempt=0;history=[]
while True:
 attempt+=1
 dest=directory/f'paired-gpu-attempt-{attempt}'
 log=directory/f'paired-gpu-attempt-{attempt}.log'
 command=[str(root/'artifacts/gpu-cost/format-venv/bin/python'),str(directory/'paired_runs.py'),'--mode','gpu','--counts','8','--pairs','8','--output',str(dest)]
 with log.open('w') as output:result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
 history.append(dict(attempt=attempt,command=command,exit=result.returncode,log=str(log)))
 (directory/'pair-collection-history.json').write_text(json.dumps(history,indent=2)+'\n')
 if result.returncode==0:
  (directory/'accepted-pair-dataset.json').write_text(json.dumps(dict(path=str(dest),attempt=attempt),indent=2)+'\n')
  print('complete paired dataset',dest,flush=True);break
 if 'Compiler activity overlapped a measurement' not in log.read_text():raise SystemExit(result.returncode)
 print('rejecting contaminated attempt',attempt,'and repeating',flush=True)
