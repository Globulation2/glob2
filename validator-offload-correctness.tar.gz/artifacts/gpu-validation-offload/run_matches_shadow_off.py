from pathlib import Path
import json,os,subprocess,time
root=Path.cwd(); out=root/'artifacts/gpu-validation-offload/matches-shadow-off';out.mkdir(exist_ok=True)
binary=root/'build/gpu-offload-correctness/src/glob2'
rows=[]
for backend,algorithm,count,repeat in [('cpu','buckets',8,0)]+[(b,a,c,r) for r in range(1) for c in ([1,2,4,8] if r==0 else [8]) for b,a in [('vulkan','frozen8'),('vulkan','jacobi')]]:
 name=f'{backend}-{algorithm}-{count}-{repeat}';dest=out/name
 env={**os.environ,'VK_DRIVER_FILES':'/usr/share/vulkan/icd.d/nvidia_icd.json','GLOB2_GRADIENT_BACKEND':backend,'GLOB2_GRADIENT_ALGORITHM':algorithm,'GLOB2_GRADIENT_VERIFY':'0','GLOB2_GRADIENT_DIAGNOSTICS':'1','GLOB2_TEST_ARTIFACTS':str(out/name/'proofs')}
 command=[str(binary),'match','verify','test/fixtures/multiplayer/FourSquares1.g2mr','--map-file','maps/FourSquares1.map.gz','--compute-threads',str(count),'--output-dir',str(dest)]
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  run=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,command=command,exit=run.returncode,elapsed=time.monotonic()-start)
 if run.returncode==0:
  row['compute']=json.loads((dest/'compute.json').read_text()); row['trace_matches_golden']=(dest/'checksums.txt').read_bytes()==Path('test/fixtures/multiplayer/FourSquares1.verify-trace.txt').read_bytes()
  if count>1 and backend=='vulkan':
   row['gpu_accepted']=row['compute']['gradient_gpu_fields']>0
 rows.append(row);(out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,run.returncode,row.get('compute',{}).get('gradient_gpu_fields'),row.get('trace_matches_golden'),flush=True)
 if run.returncode:break
