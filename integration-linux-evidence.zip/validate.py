from pathlib import Path
import subprocess,os,time,shlex,json,gzip,hashlib,concurrent.futures
root=Path('/dev/shm/glob2-recruitment-profile');out=root/'artifacts/recruitment-integration';os.chdir(root)
env=os.environ.copy();env.update(GLOB2_SDL3_PREFIX='/home/bradley/glob2/build/sdl3/prefix',PYTHONPATH=str(root))
while True:
 log=(out/'build.log').read_text()
 if 'scons: done building targets.' in log:break
 if 'scons: building terminated' in log:raise RuntimeError('build failed')
 time.sleep(5)
commands=[]
def run(args,label):
 args=[str(x) for x in args];commands.append({'label':label,'argv':args});(out/'commands.json').write_text(json.dumps(commands,indent=2))
 print(label,flush=True)
 with (out/(label+'.log')).open('w') as f:subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
if not (out/'tests.xml').exists():run(['python3','test/run_tests.py','--build-dir','build/recruitment-profile','--binary','engine','--filter','BuildingMaterialDemand/*','--filter','Hiring*/*','--filter','FetchHiringScore/*','--filter','UnitContinuation/*','--filter','InnSwap/*','--filter','GradientPreparation/*','--filter','GradientDemandQueue/*','--no-display','-j3','--junit',out/'tests.xml','--artifacts',out/'tests'],'tests')
# Freeze master recruitment implementation, using identical compiler flags and unchanged production objects.
lines=[]
for prior in sorted((root/"artifacts/recruitment-final").glob("*build*.log")):
 lines.extend(prior.read_text(errors="replace").splitlines())
lines.extend(log.splitlines())
master='fc7cf5ecc27d2703dd79d3affa4090b9bdf87d34'
records=[];replacements={}
for name in ['src/team/TeamStep.cpp','src/building/Step.cpp','src/building/Construction.cpp']:
 dst=out/(Path(name).stem+'.master.cpp');dst.write_bytes(subprocess.check_output(['git','show',master+':'+name]))
 command=shlex.split(next(l for l in reversed(lines) if l.endswith(name) and ' -c ' in l and ' -O3 ' in l))
 old=command[command.index('-o')+1];obj=out/(Path(name).stem+'.master.o');command[command.index('-o')+1]=str(obj);command[-1]=str(dst)
 replacements[old]=str(obj);run(command,'compile-'+Path(name).stem);records.append({'file':name,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
command=shlex.split(next(l for l in reversed(lines) if ' -o build/recruitment-profile/src/glob2 ' in l and ' -c ' not in l));command[command.index('-o')+1]=str(out/'glob2-master-reference');command=[replacements.get(x,x) for x in command];run(command,'link-master-reference')
(out/'reference.json').write_text(json.dumps({'master':master,'method':'Frozen master recruitment translation units linked against the final build; Team.h adds only an unused nonvirtual method in this control, no layout change; identical unaffected objects, flags and dependencies. EngineRun contains identical disabled-by-default Callgrind markers.','files':records},indent=2))
comparison={}
for name,save,ticks,threads in [('12k','midgame12k.game.gz',13153,8),('24k','midgame24k.game.gz',25153,8),('24k-serial','midgame24k.game.gz',25153,1)]:
 for label,binary in [('master',out/'glob2-master-reference'),('after',root/'build/recruitment-profile/src/glob2')]:
  run([binary,'game','run','--load-game',root/save,'--compute-threads',threads,'--gpu','off','--ticks',ticks,'--telemetry','checksums','--save','final','--output-dir',out/(label+'-'+name)],label+'-'+name)
 checks={}
 for file in ['world.checksums','snapshot.checksums','final.game.gz']:
  a=(out/('master-'+name)/file).read_bytes();b=(out/('after-'+name)/file).read_bytes()
  if file.endswith('.gz'):a=gzip.decompress(a);b=gzip.decompress(b)
  checks[file]={'identical':a==b,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'rows':len(b.splitlines()) if not file.endswith('.gz') else None}
 assert all(v['identical'] for v in checks.values()),(name,checks)
 comparison[name]=checks;(out/'behavior.json').write_text(json.dumps(comparison,indent=2))
 for label in ['master','after']:
  for sidecar in (out/(label+'-'+name)).glob('*.replay.checksums'):sidecar.unlink()
run([root/'build/recruitment-profile/src/glob2','match','verify','test/fixtures/multiplayer/FourSquares1.g2mr','--map-file','maps/FourSquares1.map.gz','--compute-threads',8,'--output-dir',out/'golden'],'golden')
print('INTEGRATION COMPLETE',flush=True)
