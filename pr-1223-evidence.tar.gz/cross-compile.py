import subprocess
from pathlib import Path
root=Path('/Users/bradley/Library/Application Support/Glob2/Development/toolchains')
ndk=next(root.glob('mobile/*/android-sdk/ndk/28.2.13676358/toolchains/llvm/prebuilt/darwin-x86_64/bin'))
for arch in ['aarch64-linux-android','armv7a-linux-androideabi','x86_64-linux-android']:
 compiler=ndk/(arch+'24-clang++')
 subprocess.run([str(compiler),'-std=c++20','-Wall','-Wextra','-Werror','-c','src/common/ComputeThreads.cpp','-o',f'artifacts/compute-physical/{arch}.o'],check=True)
 print('PASS Android topology compilation:',arch,flush=True)
em=next(root.glob('emscripten/*/upstream/emscripten/em++'))
for variant,flags in [('serial',[]),('threaded',['-pthread'])]:
 out=f'artifacts/compute-physical/browser-policy-{variant}.js'
 subprocess.run([str(em),'-std=c++20','-Wall','-Wextra','-Werror',*flags,'-Isrc/common','src/common/ComputeThreads.cpp','artifacts/compute-physical/browser-policy.cpp','-sENVIRONMENT=node','-sEXIT_RUNTIME=1','-o',out],check=True)
 subprocess.run(['node',out],check=True)
 print('PASS Emscripten compiled policy:',variant,flush=True)
