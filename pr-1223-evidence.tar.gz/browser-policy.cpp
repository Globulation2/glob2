#include "ComputeThreads.h"
#include <cassert>
int main() {
    auto cpu = cpuAvailabilityObservation(32, 2);
    cpu.physicalCoreCount = 1;
    assert(defaultComputeThreadCount(cpu) == 8);
    assert(resolveComputeThreadCount(19, cpu) == 19);
    assert(defaultComputeThreadCount(cpuAvailabilityObservation(0, 2)) == 1);
    assert(defaultComputeThreadCount(cpuAvailabilityObservation(4)) == 4);
}
