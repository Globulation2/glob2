#include "ComputeThreads.h"
#include <cassert>
#include <iostream>
int main() {
    const auto cpu = discoverComputeCpuAvailability();
    std::cout << "{\"logical\":" << cpu.hardwareHint << ",\"eligible\":" << cpu.eligibleLogicalCpuCount.value_or(0)
        << ",\"physical\":" << cpu.physicalCoreCount.value_or(0) << ",\"participants\":" << defaultComputeThreadCount(cpu)
        << ",\"source\":\"" << physicalCoreSourceName(cpu) << "\"}\n";
    assert(resolveComputeThreadCount(27) == 27);
    assert(cpu.physicalCoreCount && *cpu.physicalCoreCount > 0);
    assert(resolveComputeThreadCount(0) == defaultComputeThreadCount(cpu));
}
