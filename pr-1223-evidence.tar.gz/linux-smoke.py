import json
import subprocess
from pathlib import Path
payload={n:Path(p).read_text() for n,p in {'ComputeThreads.h':'src/common/ComputeThreads.h','ComputeThreads.cpp':'src/common/ComputeThreads.cpp','smoke.cpp':'artifacts/compute-physical/discovery-smoke.cpp'}.items()}
remote='''import json,sys,tempfile,pathlib,subprocess,os
files=json.load(sys.stdin)
with tempfile.TemporaryDirectory(prefix="glob2-physical-") as work:
 p=pathlib.Path(work)
 for name,content in files.items(): (p/name).write_text(content)
 subprocess.run(["g++","-std=c++20","-Wall","-Wextra","-Werror","-pthread","ComputeThreads.cpp","smoke.cpp","-o","smoke"],cwd=p,check=True)
 allowed=sorted(os.sched_getaffinity(0))
 def siblings(cpu):
  return pathlib.Path(f"/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list").read_text().strip()
 groups={}
 for cpu in allowed: groups.setdefault(siblings(cpu),[]).append(cpu)
 cases={"all":allowed,"one-logical":[allowed[0]]}
 pair=next((v for v in groups.values() if len(v)>1),None)
 if pair: cases["smt-siblings"]=pair
 cases["distinct-cores"]=[v[0] for v in list(groups.values())[:4]]
 for label,cpus in cases.items():
  def setmask(): os.sched_setaffinity(0,cpus)
  data=json.loads(subprocess.check_output([str(p/"smoke")],preexec_fn=setmask,text=True))
  expected=len({siblings(cpu) for cpu in cpus})
  assert data["physical"]==expected,(label,data,expected)
  assert data["participants"]==expected,(label,data,expected)
  assert data["eligible"]==len(cpus),(label,data,cpus)
  print(label,json.dumps(data),flush=True)
 print("PASS Linux GCC discovery and restricted-affinity sizing",flush=True)
 subprocess.run(["x86_64-w64-mingw32-g++","-std=c++20","-Wall","-Wextra","-Werror","-c","ComputeThreads.cpp","-o","windows.o"],cwd=p,check=True)
 print("PASS MinGW Windows topology compilation",flush=True)
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','devlaptop.local','python3 -c '+__import__('shlex').quote(remote)],input=json.dumps(payload),text=True,capture_output=True)
print(r.stdout,end='');print(r.stderr,end='');raise SystemExit(r.returncode)
