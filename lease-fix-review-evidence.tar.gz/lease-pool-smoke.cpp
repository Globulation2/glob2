#include "SnapshotStorage.h"
#include <thread>
#include <atomic>
#include <cassert>
int main() {
 SimulationSnapshot::BufferPool<std::vector<int>> pool; Uint64 allocations=0;
 for(int i=0;i<200;++i){auto p=pool.acquire(allocations);p->assign(256,i);auto raw=p.get();std::atomic<bool> done{false};int total=0;
 std::thread t([p=std::move(p),&done,&total]()mutable {for(int x:*p)total+=x;p.reset();done.store(true,std::memory_order_relaxed);});
 while(!done.load(std::memory_order_relaxed))std::this_thread::yield();auto q=pool.acquire(allocations);assert(q.get()==raw);q->assign(256,-1);t.join();assert(total==i*256);}
 auto warm=pool.leaseUpstreamAllocations();for(int i=0;i<1000;++i){auto p=pool.acquire(allocations);}assert(pool.leaseUpstreamAllocations()==warm);
 std::weak_ptr<std::vector<int>> weak;std::shared_ptr<std::vector<int>> held;{SimulationSnapshot::BufferPool<std::vector<int>> shortlived;held=shortlived.acquire(allocations);weak=held;} held.reset();assert(weak.expired());weak.reset();
}
