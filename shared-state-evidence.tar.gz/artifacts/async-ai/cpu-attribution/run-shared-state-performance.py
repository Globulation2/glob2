#!/usr/bin/env python3
import os,json,time,subprocess,hashlib,platform,statistics,math,threading
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent
OUT=ROOT/'artifacts/async-ai/shared-state/final-performance'
OUT.mkdir(exist_ok=False)
manifest=json.loads((ROOT/'artifacts/async-ai/performance/optimization-smoke.json').read_text())
base=Path('/Users/bradley/.codex/worktrees/async-ai-baseline-current/glob2')
variants=[('master',BASE/'production-master',False),('before',BASE/'production-query-algorithm',False),('after',ROOT/'artifacts/async-ai/shared-state/final-candidate',False)]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
binaries={str(p):sha(p) for _,p,_ in variants}
metadata={'binaries':binaries,'platform':platform.platform(),'repeats':10,'warmups':1,'scope_clock':'CLOCK_THREAD_CPUTIME_ID','envelope_clock':'CLOCK_PROCESS_CPUTIME_ID','flags':['release=1','server=0'],'diagnostic_sources':{'candidate_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'master_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip()},'manifest':manifest,'diagnostic_probes':False,'before_revision':'e9311a91c','master_revision':'e53a673b2609175e781ad2608a15a220866cf2fa','after_source_provenance':'Final shared authoritative map/unit/building records; source revision recorded before execution.'}
(OUT/'measurement-metadata.json').write_text(json.dumps(metadata,indent=2))
def compiler_active():
 lines=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines()
 return any(Path(line.strip()).name in {'clang','clang++','g++','gcc','cc1','cc1plus','ninja'} for line in lines)
def idle_gate():
 while compiler_active():
  print('Compiler activity: waiting before timing',flush=True);time.sleep(10)
class Monitor:
 def __init__(self):self.stop=threading.Event();self.interference=False
 def watch(self):
  while not self.stop.wait(1):
   if compiler_active():self.interference=True
 def start(self):self.thread=threading.Thread(target=self.watch);self.thread.start()
 def finish(self):self.stop.set();self.thread.join();return self.interference or compiler_active()
rows=[]
with (OUT/'measurements.jsonl').open('w') as records:
 for scenario in manifest['scenarios']:
  for repeat in range(-1,10):
   # Rotate and alternate to balance thermal/order effects; no concurrent runs.
   ordered=variants[repeat%3:]+variants[:repeat%3]
   if repeat%2:ordered=ordered[::-1]
   for name,binary,on in ordered:
    attempt=0
    while True:
     idle_gate()
     path=OUT/'runs'/scenario['group']/f'{repeat}-{name}-attempt{attempt}';path.mkdir(parents=True,exist_ok=False)
     command=[str(binary),'--run-game',*scenario['args'],'--benchmark-warmup','0','--output-dir',str(path)]
     env=os.environ.copy();env.pop('GLOB2_CPU_ATTRIBUTION',None)
     if on:env['GLOB2_CPU_ATTRIBUTION']='1'
     monitor=Monitor();monitor.start()
     start=time.perf_counter()
     with (path/'engine.log').open('w') as log:
      process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
      _,status,usage=os.wait4(process.pid,0);process.returncode=os.waitstatus_to_exitcode(status)
     wall=time.perf_counter()-start
     interference=monitor.finish()
     if interference:
      print('Discarding interrupted measurement '+str(path),flush=True);attempt+=1;time.sleep(10);continue
     break
    if process.returncode:raise RuntimeError(str(path)+' exit '+str(process.returncode))
    result=json.loads((path/'result.json').read_text())
    if result['ticks']!=8192:raise RuntimeError('unexpected duration '+str(path))
    attribution=None
    for line in (path/'engine.log').read_text().splitlines():
     if line.startswith('CPU_ATTRIBUTION '):attribution=json.loads(line[len('CPU_ATTRIBUTION '):])
    if on and not attribution:raise RuntimeError('missing attribution '+str(path))
    row={'scenario':scenario['group'],'repeat':repeat,'variant':name,'cpu_s':usage.ru_utime+usage.ru_stime,'wall_s':wall,'result':result,'attribution':attribution,'command':command}
    rows.append(row);records.write(json.dumps(row)+'\n');records.flush()
   print(scenario['group'],repeat,'complete',flush=True)
for p,h in binaries.items():
 if sha(Path(p))!=h:raise RuntimeError('binary changed '+p)
summary={}
for scenario in {r['scenario'] for r in rows}:
 selected=[r for r in rows if r['scenario']==scenario and r['repeat']>=0]
 summary[scenario]={}
 for name,_,on in variants:
  rr=[r for r in selected if r['variant']==name]
  item={'median_process_cpu_s':statistics.median(r['cpu_s'] for r in rr),'median_run_cpu_s':statistics.median(r['result']['benchmark_run_cpu_ns']/1e9 for r in rr),'median_run_elapsed_s':statistics.median(r['result']['run_ns']/1e9 for r in rr)}
  if on:
   groups={}
   for r in rr:
    for thread in r['attribution']['threads']:
     for k,v in thread['scopes'].items():groups.setdefault(k,[])
   for k in groups:
    groups[k]=statistics.mean(sum(t['scopes'][k]['exclusive_cpu_ns'] for t in r['attribution']['threads'])/1e9 for r in rr)
   item['mean_exclusive_cpu_s']=groups
   item['mean_envelope_cpu_s']=statistics.mean(r['attribution']['process_window_cpu_ns']/1e9 for r in rr)
   item['mean_unattributed_cpu_s']=item['mean_envelope_cpu_s']-sum(groups.values())
  summary[scenario][name]=item
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2),flush=True)
