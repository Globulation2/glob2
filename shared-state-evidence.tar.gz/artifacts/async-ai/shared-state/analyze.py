import json,math,statistics
from pathlib import Path
root=Path(__file__).resolve().parents[3]
base=root/'artifacts/async-ai/shared-state/final-performance'
rows=[json.loads(line) for line in (base/'measurements.jsonl').read_text().splitlines()]
summary={}
for group in dict.fromkeys(r['scenario'] for r in rows):
 rr=[r for r in rows if r['scenario']==group and r['repeat']>=0]
 assert len(rr)==30,(group,len(rr))
 assert len({r['result']['finalChecksum'] for r in rows if r['scenario']==group})==1
 out={'checksum':rr[0]['result']['finalChecksum'],'pairs':10}
 for metric,key in [('cpu','benchmark_run_cpu_ns'),('elapsed','run_ns')]:
  out[metric+'_seconds']={v:statistics.median(r['result'][key]/1e9 for r in rr if r['variant']==v) for v in ['master','before','after']}
  for reference in ['before','master']:
   logs=[]
   for i in range(10):
    pair={r['variant']:r['result'][key] for r in rr if r['repeat']==i}
    logs.append(math.log(pair['after']/pair[reference]))
   mean=statistics.mean(logs); half=2.262157*statistics.stdev(logs)/math.sqrt(10)
   out[metric+'_after_over_'+reference]={'geometric_ratio':math.exp(mean),'95pct_interval':[math.exp(mean-half),math.exp(mean+half)]}
 summary[group]=out
(base/'paired-analysis.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
