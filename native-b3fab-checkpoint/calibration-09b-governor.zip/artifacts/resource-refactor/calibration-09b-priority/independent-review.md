# Independent priority calibration review

The first complete 16-pair case, land-2-1002-maxima-late, fails the declared individual gate: simulation CPU ratio 1.15620245, paired bootstrap 95% interval [1.06970904, 1.25572518]. The calculation uses the runner's exact seed, resample count and quantile indices. No rows were excluded.

This block is substantially noisier than the earlier candidate's case (log-ratio SD 0.17081), with large absolute CPU changes in both arms. Nevertheless the increase is not confined to the final pair: candidate-first/baseline-first geometric ratios are 1.12173/1.19174; first/second halves are 1.19760/1.11623. Every leave-one-out point estimate remains between 1.12987 and 1.17820. The lag-one estimate is 0.012, which is not proof of independent or stationary measurements from only 16 observations.

Per-arm full terminal team objects, initial/final checksums, measured ticks, gradient publication/discard counts and compute jobs are identical across all 16 repeats. Thus varying work caused by nondeterminism is not an observed explanation. Host variability remains a limitation and should be diagnosed independently; it does not justify dropping adverse samples or claiming a pass. Prior 46ae observations are historical only and are not pooled with this changed candidate.

Cortex was still running at this review. No two-case aggregate or full-corpus acceptance is claimed. All arithmetic was lightweight and read-only; no workloads, host settings or source changes were introduced.

## Completed Cortex block

Cortex ratio1.08245023 has the reported interval[0.99916,1.18224], so it remains inconclusive under the5%gate. Candidate-first/baseline-first ratios1.11195/1.05373 and first/second halves1.18408/0.98954 show strong time dependence. Leave-one-out point estimates1.06067–1.10405 remain elevated; no row may be removed. Per-arm terminal state and job counters are stable. Final input verification reports unchanged inputs. The host-context frequency snapshots are relevant confounding evidence, not grounds to relabel the failed Maxima block as passing. Both blocks stay retained independently of subsequent counter diagnostics.
