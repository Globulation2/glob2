import pathlib,json,statistics,math,collections
p=pathlib.Path(__file__).resolve().parent/'calibration-09b-priority';rows=[json.loads(l) for l in (p/'measurements.jsonl').read_text().splitlines() if l.strip()];groups=collections.defaultdict(dict)
for r in rows:
 if r['repeat']>=0:groups[r['scenario']].setdefault(r['repeat'],{})[r['variant']]=r
out=[]
for name,g in groups.items():
 if len(g)!=16 or any(set(v)!={'baseline','candidate'} for v in g.values()):continue
 pairs=[g[i] for i in range(16)];a=[v['baseline']['result']['benchmark_run_cpu_ns']/1e9 for v in pairs];b=[v['candidate']['result']['benchmark_run_cpu_ns']/1e9 for v in pairs];logs=[math.log(y/x) for x,y in zip(a,b)];gm=lambda v:math.exp(statistics.mean(v));sd=statistics.stdev(logs);mean=statistics.mean(logs);center=[x-mean for x in logs];lag=sum(center[i]*center[i-1] for i in range(1,16))/sum(x*x for x in center) if sd else 0
 out.append({'scenario':name,'pairs':16,'geomean_ratio':gm(logs),'ratios':[round(math.exp(v),5) for v in logs],'baseline_cpu':[round(v,4) for v in a],'candidate_cpu':[round(v,4) for v in b],'log_ratio_sd':sd,'candidate_first_ratio':gm(logs[::2]),'baseline_first_ratio':gm(logs[1::2]),'first_half_ratio':gm(logs[:8]),'second_half_ratio':gm(logs[8:]),'lag1':lag,'leave_one_out_range':[min(gm(logs[:i]+logs[i+1:]) for i in range(16)),max(gm(logs[:i]+logs[i+1:]) for i in range(16))],'approx_fresh16_upper_normal':math.exp(mean+1.96*sd/4),'approx_pairs_for_5pct_upper_if_effect_and_variance_persist':math.ceil((1.96*sd/(math.log(1.05)-mean))**2) if mean<math.log(1.05) else None})
result={'note':'Interim read-only completed8-pair cases only. Normal approximations are planning aids, not bootstrap gates or guaranteed sample sizes. No samples removed.','complete_cases':len(out),'cases':out};(p/'independent-completed-review.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
