# Fresh stabilized-governor priority calibration protocol

Run only after the final executable and source revision are frozen, all builds/tests/profiling and other local workloads are finished, and root releases the host. This is a separate environment block; do not pool with schedutil history or substitute it for full-corpus acceptance.

Use the unchanged `food-scan-priority-windows.json`: Maxima land-2-1002 late followed by Cortex land-2-1001 late, each checkpoint24,576→32,768 (8,192 ticks), four compute threads, AI compute experiment, two gradient workers and delay eight. Use frozen pure f0 as baseline and the newly frozen final cache candidate with their respective data roots. No added telemetry or checksum flags. The runner supplies one complete warmup pair per case and16 measured alternating pairs. Retain every measured row, including failures and outliers.

Temporarily set only the resolved policies associated with CPUs0–7 to `performance` through the independently reviewed wrapper. Run the wrapper and benchmark as the normal user; only each sysfs tee uses sudo. Persist original governors before writes, verify stabilized policy state, retain input hashes and CPU frequency context, and require successful verified restoration afterward. Four real smoke cases already demonstrated restoration on success, nonzero exit, timeout and SIGTERM with a descendant. Uncatchable termination remains recoverable through the persisted audit, not guaranteed automatic cleanup.

Keep affinity0–7 and all other host settings unchanged. Each run must complete exactly8,192 measured ticks; compare per-arm checksums, teams and job counts across repeats. The final report must retain order strata, first/second halves, influence, variability, input-verification and governor restoration evidence. Performance-governor selection does not prove effective frequency constancy; review snapshots and timing trends.

The individual gate remains upper95%<=1.05 for a passing case, lower95%>1.05 for a credible failure, otherwise inconclusive. The two selected cases cannot establish the full-corpus2%aggregate gate. Do not discard earlier failed candidates or their variable-clock observations; classify them as separate tested environments and revisions.

## Launch template

From the repository root, replace only `FINAL_FROZEN_BINARY` with the verified new absolute executable path. Choose new output/audit paths if either already exists. Root should record exact final source/binary hashes and the resolved command before launch.

```sh
LD_LIBRARY_PATH=/tmp/glob2-terrain-sdl-patched/prefix/lib:/tmp/glob2-sdl3/prefix/lib \
taskset -c 0-7 python3 artifacts/resource-refactor/run_with_benchmark_governor.py \
  --audit artifacts/resource-refactor/calibration-performance-priority-governors.json \
  --timeout-seconds 7200 -- \
  python3 test/benchmark_resource_refactor.py \
  artifacts/resource-refactor/master-f0-pure-frozen/glob2 \
  FINAL_FROZEN_BINARY \
  artifacts/resource-refactor/food-scan-priority-windows.json \
  --before-root artifacts/resource-refactor/master-f0-pure-source \
  --after-root . \
  --output artifacts/resource-refactor/calibration-performance-priority \
  --repeats 16 \
  > artifacts/resource-refactor/calibration-performance-priority.log 2>&1
```

Inspect the wrapper audit even when the benchmark returns its nonzero inconclusive/regression status. Governor restoration is required independently of the performance outcome. This command has not been executed by the reviewer.
