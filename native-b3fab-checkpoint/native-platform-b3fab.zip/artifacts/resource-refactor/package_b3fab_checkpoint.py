from pathlib import Path
import hashlib,json,zipfile,subprocess
root=Path.cwd();base=root/'artifacts/resource-refactor';out=base/'b3fab-publication';out.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
groups={
'native-platform-b3fab':['platform-46ae-*','platform-native-46ae*','platform-validation-metadata-*','menu-colony-*.log','native-food-scan*','native-food-distance*','native-hard-space*','hard-space-ui-*','infinite-stock-*','native-09b-determinism*','native-b3fab-determinism*','native-09b-final-build.log','candidate-b3fab1a48/*.json','candidate-09b8380bb/*.json','cortex-distance-field-rejected.json'],
'calibration-09b-governor':['calibration-09b-*','food-scan-priority-windows.json','governor-smokes','run_with_benchmark_governor.py','performance-governor-priority-protocol.md','calibration-performance-priority-plan.json','review_09b_completed.py'],
'cache-diagnostics-b3fab':['food-scan-diagnostics','food-distance-diagnostics','hard-space-diagnostics','exact-priority-counters-09b','exact-cortex-profile-09b','food-scan-cortex-profile','symbolized-food-scan/*.json','run_food_scan_diagnostic.py','run_food_distance_diagnostic.py','run_hard_space*.py','run_exact_priority_counters.py','profile_exact_cortex.py','profile_food_scan.py','analyze_food_*diagnostic.py','analyze_hard_space_diagnostic.py','analyze_exact_priority_counters.py','relink_food_scan_symbols.py','exact-priority-counter-plan.md','food-scan-*.log','food-distance-cortex.log','hard-space-*.log','exact-priority-counters-09b.log','exact-cortex-profile-09b.log']}
allowed={'.log','.xml','.json','.jsonl','.txt','.csv','.md','.py','.patch','.h','.png','.trace','.checksums'}
summary={'revision':'b3fab1a48a9ac6ec74a6985e60a839eea54da346','candidate_sha256':'7de08ee1bcbb74b7d711efd29ad84237a499efc4626055d61fb1bab1db0fbbc9','performance_acceptance':False,'status':'09b variable-governor Maxima calibration failed; Cortex inconclusive. New cache exactness/instruction diagnostics pass; final b3fab stabilized calibration has not started.','repairs':{'4996a5f32':'Resource experiment protocol fixture and lint migration','c3ca882ab':'Preserve resource experiment validation metadata','9554357d4':'Typed menu colony harness migration'},'scope':'Historical failures, fixture-only repairs, final native traces/UI captures, all09b timing rows, exact command counters, retained rejected distance-field experiment, governor restoration smokes. Logs identify individual tested revisions; not a single all-green final full-suite claim.','exclusions':['Executables and raw perf.data','Redundant saves/replays; reusable input corpus published separately','Private scratch profiles and generated build products'],'deduplication':'Each archive stores a unique SHA256 payload once. file-inventory.json maps every original repository-relative path to stored_as; identical checksum files remain reconstructible exactly.','archives':[]}
for name,patterns in groups.items():
 paths=set()
 for pattern in patterns:
  matches=list(base.glob(pattern))
  for p in matches:
   paths.update([p] if p.is_file() else (q for q in p.rglob('*') if q.is_file()))
 paths.add(Path(__file__).resolve())
 if name.startswith('calibration'):paths.update(root/p for p in ['test/benchmark_resource_refactor.py','test/benchmark_parallel_compute.py'])
 paths={p for p in paths if p.suffix in allowed and p.name!='perf.data' and '.git' not in p.parts}
 # Cache/profile directories may contain generated user preferences; these are
 # not evidence inputs and are deliberately excluded (run/profile result paths stay).
 paths={p for p in paths if p.name not in ['preferences.txt','keyboard.txt','layout.json']}
 inventory={};payloads={};canonical={}
 for p in sorted(paths):
  digest=sha(p);rel=str(p.relative_to(root));stored=canonical.setdefault(digest,rel);inventory[rel]={'bytes':p.stat().st_size,'sha256':digest,'stored_as':stored};payloads.setdefault(digest,p)
 dest=out/(name+'.zip')
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
  for digest,p in payloads.items():z.write(p,canonical[digest])
  z.writestr('file-inventory.json',json.dumps(inventory,indent=2)+'\n')
 with zipfile.ZipFile(dest) as z:
  assert set(z.namelist())==set(canonical.values())|{'file-inventory.json'}
  for digest,rel in canonical.items():
   h=hashlib.sha256()
   with z.open(rel) as f:
    for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
   assert h.hexdigest()==digest
 record={'path':str(dest.relative_to(root)),'bytes':dest.stat().st_size,'sha256':sha(dest),'original_paths':len(inventory),'unique_payloads':len(payloads),'uncompressed_unique_bytes':sum(p.stat().st_size for p in payloads.values()),'verification':'Every archived payload decompressed and SHA256 verified.'};summary['archives'].append(record);print(json.dumps(record),flush=True)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
