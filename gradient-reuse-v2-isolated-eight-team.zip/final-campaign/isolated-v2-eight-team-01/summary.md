## Separate 512-square/eight-team campaign: representative CPU cost remains

All three retained eight-team mixed-AI windows completed one warmup plus eight alternating measured pairs: 54 children, 48 measured. The independent audit passed exact commands/order/windows, matching repeat-stable initial/final checksums, all statistics, frozen binary/input identities, and governor/cpuset/affinity restoration without forced kill. This campaign remains separate from the 98-window aggregate.

Aggregate simulation CPU ratio is **1.030879 [1.018304, 1.044077]**, or +3.09% CPU [1.83%,4.41%]. This is a representative cost requiring explanation despite the favorable 98-window aggregate; the candidate remains provisional. Historical threshold classification is only a diagnostic.

| Window | Simulation CPU ratio [95% CI] | Simulation wall ratio [95% CI] | Whole-child CPU ratio [95% CI] | RSS ratio [95% CI] |
| --- | --- | --- | --- | --- |
| land-8-1001-mixed-512-initial | 1.040535 [1.015369, 1.068109] | 1.009510 [1.000505, 1.016820] | 1.040162 [1.015487, 1.067255] | 1.055724 [1.045093, 1.066691] |
| land-8-1001-mixed-512-developing | 1.042667 [1.018490, 1.068267] | 1.000296 [0.993808, 1.007552] | 1.037167 [1.017634, 1.058547] | 1.045484 [1.033954, 1.057105] |
| land-8-1001-mixed-512-middle | 1.009765 [0.997282, 1.021895] | 1.002647 [0.996940, 1.008098] | 1.007806 [0.996426, 1.019121] | 1.040060 [1.031401, 1.048121] |

Reserved busy minus whole-child CPU averages 0.098500 cores, maximum 0.205822; outside CPUs average 0.515996 busy cores, maximum 1.550505; reserved SMT siblings total 0.04 CPU-seconds. Residuals include wrapper/kernel work and quantization/boundary skew; outside activity is expected under partitioning, with shared power/memory/thermal/IRQ limits unchanged. Simulation CPU excludes setup/save but includes final drain; whole-child CPU includes setup/exit. Final-checksum agreement does not replace full per-tick correctness evidence.

[Full raw eight-team evidence](gradient-reuse-v2-isolated-eight-team.zip) retains every output, commands, summaries, complete input/restoration audits and independently rerunnable auditor. Custom-resource timing and causal cost investigation remain open.
