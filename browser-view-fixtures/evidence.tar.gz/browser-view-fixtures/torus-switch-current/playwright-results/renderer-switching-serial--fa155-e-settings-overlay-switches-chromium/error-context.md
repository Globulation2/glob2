# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer-switching.spec.js >> serial: gameplay and torus survive settings overlay switches
- Location: tests/renderer-switching.spec.js:268:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 120000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [aria-hidden]:
    - status: Starting the game…
    - generic:
      - progressbar
      - generic: 33 of 33 MB
    - combobox
  - generic "Globulation 2" [active] [ref=e3]
```

# Test source

```ts
  188 |   // inspect the application worker that owns the backend, not the DOM realm.
  189 |   let reason=offered?'Presentation-owner WebGPU realm could not be inspected':'Renderer selector reports WebGPU unavailable';
  190 |   // Idle Emscripten asset pthreads may be inside Atomics.wait forever. Probe
  191 |   // all realms with bounded waits before sending async work to the GPU owner.
  192 |   const realms=await presentationOwners(page);
  193 |   for (let index=0;index<realms.length;++index) {
  194 |     const realm=realms[index];
  195 |     let timer,result;
  196 |     try{result=await Promise.race([realm.evaluate(async()=>{
  197 |       if(!globalThis.navigator?.gpu)return {available:false,reason:'Presentation owner has no navigator.gpu'};
  198 |       try{return await navigator.gpu.requestAdapter() ? {available:true} : {available:false,reason:'Presentation owner returned no WebGPU adapter'};}
  199 |       catch(error){return {available:false,reason:String(error)};}
  200 |     }).catch(()=>null),new Promise(resolve=>{timer=setTimeout(()=>resolve({available:false,reason:'Presentation-owner adapter request timed out'}),15000);})]);}
  201 |     finally{clearTimeout(timer);}
  202 |     if(!result)continue;
  203 |     if(result.available){if(offered)return true;break;}
  204 |     reason=result.reason;break;
  205 |   }
  206 |   page.rendererBackendUnavailableReason=reason;
  207 |   test.info().annotations.push({type:'WebGPU coverage omitted',description:reason});
  208 |   return false;
  209 | }
  210 | for(const mode of ['serial','threaded']) {
  211 |   test(`${mode}: Automatic resolving to the active Software renderer completes without replacing the surface`,async({page},info)=>{
  212 |     test.setTimeout(360000);const verify=await start(page,mode);await match(page);await openOverlay(page);
  213 |     // direct0 keeps Software as its initial automatic policy. Capture the actual
  214 |     // presentation object as well as its generation to detect redundant teardown.
  215 |     expect(await page.evaluate(()=>Module.renderer)).toBe('software');
  216 |     const before={generation:await generation(page),loop:(await state(page)).loop};
  217 |     await page.evaluate(()=>{globalThis.rendererNoopCanvas=Module.canvas;});
  218 |     await clickControl(page,'graphics.renderer');await clickByLabel(page,/popup/,'Automatic');
  219 |     await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['graphics.renderer']?.label)).toContain('Automatic');
  220 |     await expect.poll(async()=>(await state(page)).loop,{timeout:120000}).toBeGreaterThan(before.loop+3);
  221 |     expect(await generation(page)).toBe(before.generation);
  222 |     expect(await page.evaluate(()=>Module.canvas===rendererNoopCanvas&&Module.renderer==='software')).toBe(true);
  223 |     await verify();
  224 |     // A subsequent real switch must be admitted: a no-op left in Preparing
  225 |     // would stall this request and all following capture admission.
  226 |     await choose(page,'Programmable GL');await resumeOverlay(page);
  227 |     const completed=()=>page.evaluate(async()=>{
  228 |       const root=await(await navigator.storage.getDirectory()).getDirectoryHandle('glob2-recordings',{create:true});
  229 |       const paths=[];for await(const [name,handle]of root.entries())if(name.endsWith('.complete')&&(await handle.getFile()).size)paths.push(name);return paths;
  230 |     });
  231 |     const previousRecordings=new Set(await completed());
  232 |     await openMenu(page);
  233 |     await clickControl(page,'recording/toggle');
  234 |     await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['recording/toggle']?.label)).toMatch(/Stop recording/i);
  235 |     await clickControl(page,'return');const tick=(await state(page)).tick;
  236 |     await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(tick+10);
  237 |     await openMenu(page);
  238 |     await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['recording/toggle']?.label)).toMatch(/Stop recording/i);
  239 |     await clickControl(page,'recording/toggle');
  240 |     await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['recording/toggle']?.label)).not.toMatch(/Stop recording/i);
  241 |     await expect.poll(async()=>(await completed()).filter(path=>!previousRecordings.has(path)).length,{timeout:60000}).toBe(1);
  242 |     const recording=(await completed()).find(path=>!previousRecordings.has(path));
  243 |     const metadata=await page.evaluate(async name=>{
  244 |       const root=await(await navigator.storage.getDirectory()).getDirectoryHandle('glob2-recordings');
  245 |       const file=await(await root.getFileHandle(name.slice(0,-9)+'.json')).getFile();
  246 |       return JSON.parse(await file.text());
  247 |     },recording);
  248 |     expect(metadata.complete).toBe(true);expect(metadata.width).toBeGreaterThan(0);expect(metadata.height).toBeGreaterThan(0);
  249 |     await info.attach('automatic-noop-recording-metadata',{body:JSON.stringify(metadata,null,2),contentType:'application/json'});
  250 |     await page.screenshot({path:info.outputPath('automatic-noop-following-capture.png')});await verify();
  251 |   });
  252 |   test(`${mode}: repeated menu switches preserve Wasm lifetime and input`,async({page},info)=>{
  253 |     test.setTimeout(360000);const verify=await start(page,mode);
  254 |     await clickMainMenu(page,'settings');await screen(page,'SettingsScreen');
  255 |     for(let cycle=0;cycle<3;++cycle) {
  256 |       await choose(page,'Programmable GL');
  257 |       await page.screenshot({path:info.outputPath('gl-'+cycle+'.png')});
  258 |       await choose(page,'Software');
  259 |     }
  260 |     await clickSettingsDone(page);await screen(page,'MainMenuScreen');
  261 |     await match(page);await page.setViewportSize({width:1280,height:720});
  262 |     // A single physical key opens exactly one menu after repeated replacement.
  263 |     await page.locator('#canvas').press('Escape',{delay:80});await clickControl(page,'return');
  264 |     const tick=(await state(page)).tick;
  265 |     await expect.poll(async()=>(await state(page)).tick).toBeGreaterThan(tick);
  266 |     await verify();
  267 |   });
  268 |   test(`${mode}: gameplay and torus survive settings overlay switches`,async({page},info)=>{
  269 |     test.setTimeout(360000);const verify=await start(page,mode);await match(page);
  270 |     const tick=(await state(page)).tick;
  271 |     await openOverlay(page);await choose(page,'Programmable GL');await resumeOverlay(page);
  272 |     await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(tick);
  273 |     await page.locator('#canvas').press('g',{delay:80});
  274 |     await expect.poll(async()=>(await state(page)).torusSettled,{timeout:120000}).toBe(true);
  275 |     await page.screenshot({path:info.outputPath('torus-before-switch.png')});
  276 |     await openOverlay(page);await choose(page,'Software');await resumeOverlay(page);
  277 |     await expect.poll(async()=>(await state(page)).torus).toBe(false);
  278 |     await openOverlay(page);await choose(page,'Programmable GL');await resumeOverlay(page);
  279 |     const restored=await state(page);
  280 |     await info.attach('torus-restored-before-key',{body:JSON.stringify({screenClass:restored.screenClass,
  281 |       controls:Object.keys(restored.controls),renderer:restored.renderer,tick:restored.tick,
  282 |       torus:restored.torus,torusSettled:restored.torusSettled}),contentType:'application/json'});
  283 |     expect(restored.screenClass).toContain('GameSessionScreen');
  284 |     expect(restored.controls.done).toBeUndefined();
  285 |     // Software cannot display Torus, but switching back preserves its mode.
  286 |     // Wait for that restoration before explicitly proving the public toggle;
  287 |     // an unconditional G here would turn the restored view off.
> 288 |     await expect.poll(async()=>(await state(page)).torusSettled,{timeout:120000}).toBe(true);
      |                                                                                   ^ Error: expect(received).toBe(expected) // Object.is equality
  289 |     await page.locator('#canvas').press('g',{delay:80});
  290 |     await expect.poll(async()=>(await state(page)).torus,{timeout:120000}).toBe(false);
  291 |     await page.locator('#canvas').press('g',{delay:80});
  292 |     await expect.poll(async()=>(await state(page)).torusSettled,{timeout:120000}).toBe(true);
  293 |     await page.screenshot({path:info.outputPath('torus-after-switch.png')});await verify();
  294 |   });
  295 |   test(`${mode}: editor stays open across live renderer switches and resize`,async({page},info)=>{
  296 |     test.setTimeout(360000);const verify=await start(page,mode);
  297 |     await clickMainMenu(page,'editor');await screen(page,'EditorMainMenu');await clickControl(page,'new-map');
  298 |     await screen(page,'NewMapScreen');await clickCreateMap(page);await screen(page,'MapEditorScreen');
  299 |     for(const label of ['Programmable GL','Software']) {
  300 |       await openOverlay(page);await choose(page,label);await resumeOverlay(page);await screen(page,'MapEditorScreen');
  301 |       const viewport={width:label==='Software'?1200:1001,height:label==='Software'?900:701};
  302 |       await page.setViewportSize(viewport);
  303 |       // Diagnostics retain controls from suspended screen hosts. Inspect the
  304 |       // active editor menu rather than the retained EditorMainMenu's bounds.
  305 |       await openMenu(page);
  306 |       await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls.settings?.surface),
  307 |         {timeout:120000}).toEqual({w:viewport.width,h:viewport.height});
  308 |       await clickControl(page,'return');
  309 |       await page.screenshot({path:info.outputPath('editor-'+label+'.png')});
  310 |     }
  311 |     await openMenu(page);await clickControl(page,'quit');
  312 |     await clickControl(page,'choice/1');await screen(page,'EditorMainMenu');await verify();
  313 |   });
  314 |   test(`${mode}: recording retains one session while changing backend`,async({page},info)=>{
  315 |     test.setTimeout(480000);const verify=await start(page,mode);await match(page);
  316 |     const completed=()=>page.evaluate(async()=>{
  317 |       const root=await(await navigator.storage.getDirectory()).getDirectoryHandle('glob2-recordings',{create:true});
  318 |       const paths=[];for await(const [name,handle]of root.entries())if(name.endsWith('.complete')&&(await handle.getFile()).size)paths.push(decodeURIComponent(name).slice(0,-9));return paths;
  319 |     });
  320 |     const existing=new Set(await completed());
  321 |     await openMenu(page);await clickControl(page,'recording/toggle');
  322 |     await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['recording/toggle']?.label)).toMatch(/Stop recording/i);
  323 |     await clickControl(page,'return');const started=(await state(page)).tick;
  324 |     await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(started+10);
  325 |     await openOverlay(page);
  326 |     if(await available(page,'WebGPU')) {
  327 |       await choose(page,'WebGPU');
  328 |       const owners=await presentationOwners(page);expect(owners).toHaveLength(1);const owner=owners[0];
  329 |       await owner.evaluate(()=>{
  330 |         const recorder=Module.glob2Recording,frame=recorder.frame;
  331 |         globalThis.rendererRecordedWebGPU={frames:0,restore(){recorder.frame=frame;}};
  332 |         recorder.frame=function(...args){const accepted=frame.apply(this,args);if(accepted&&JSON.parse(args[4]).screen==='game_session')rendererRecordedWebGPU.frames++;return accepted;};
  333 |       });
  334 |       try {
  335 |         await resumeOverlay(page);const webgpuTick=(await state(page)).tick;
  336 |         await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(webgpuTick+10);
  337 |         await expect.poll(()=>owner.evaluate(()=>rendererRecordedWebGPU.frames),{timeout:120000}).toBeGreaterThan(0);
  338 |         await info.attach('recording-active-webgpu',{body:JSON.stringify({state:await state(page),acceptedFrames:await owner.evaluate(()=>rendererRecordedWebGPU.frames)},null,2),contentType:'application/json'});
  339 |         await openOverlay(page);
  340 |       } finally {await owner.evaluate(()=>{rendererRecordedWebGPU.restore();delete globalThis.rendererRecordedWebGPU;});}
  341 |     }
  342 |     await choose(page,'Programmable GL');await choose(page,'Software');await resumeOverlay(page);
  343 |     const resumed=(await state(page)).tick;
  344 |     await expect.poll(async()=>(await state(page)).tick,{timeout:120000}).toBeGreaterThan(resumed+10);
  345 |     await openMenu(page);
  346 |     await expect.poll(()=>page.evaluate(()=>glob2Diagnostics.snapshot().controls['recording/toggle']?.label)).toMatch(/Stop recording/i);
  347 |     await clickControl(page,'recording/toggle');
  348 |     try {
  349 |       await expect.poll(async()=>(await completed()).filter(path=>!existing.has(path)).length,{timeout:60000}).toBe(1);
  350 |     } catch(error) {
  351 |       // A writer lock or stalled worker must not hide the original assertion.
  352 |       const inspect=async operation=>{
  353 |         let timer;try{return await Promise.race([
  354 |           Promise.resolve().then(operation).catch(e=>({inspectionError:String(e)})),
  355 |           new Promise(resolve=>{timer=setTimeout(()=>resolve({inspectionTimedOut:true}),5000);})
  356 |         ]);}finally{clearTimeout(timer);}
  357 |       };
  358 |       const evidence={};
  359 |       try {
  360 |         evidence.producer=await inspect(async()=>{
  361 |           const owners=await presentationOwners(page);
  362 |           if(owners.length!==1)throw Error('Expected one actual recording producer');
  363 |           return owners[0].evaluate(()=>({active:Module.glob2Recording.active,
  364 |             status:Module.glob2Recording.status,frames:Module.glob2Recording.frames,audio:Module.glob2Recording.audio}));
  365 |         });
  366 |         evidence.files=await inspect(()=>page.evaluate(async()=>{
  367 |           const root=await(await navigator.storage.getDirectory()).getDirectoryHandle('glob2-recordings');
  368 |           const files=[];for await(const[name,handle]of root.entries()) {
  369 |             const path=decodeURIComponent(name);
  370 |             try {
  371 |               const file=await handle.getFile();
  372 |               files.push({path,size:file.size,text:/manifest|\.json$/.test(path)?(await file.text()).slice(0,20000):undefined});
  373 |             } catch(e) {files.push({path,inspectionError:String(e)});}
  374 |           }return files;
  375 |         }));
  376 |         evidence.workers=await Promise.all(page.workers().filter(worker=>worker.url().includes('recording-worker')).map(worker=>
  377 |           inspect(()=>worker.evaluate(()=>({workerState:state,stopped,processing,frameCredits,
  378 |             closing:!!closing,terminal,files:[...recordingStorage.files].map(([name,value])=>({name,size:value.sync.getSize()}))})))));
  379 |         evidence.snapshot=await inspect(()=>state(page));
  380 |       } catch(e) {evidence.collectionError=String(e);}
  381 |       finally {
  382 |         await inspect(()=>info.attach('recording-completion-failure',{body:JSON.stringify(evidence,null,2),contentType:'application/json'}));
  383 |         throw error;
  384 |       }
  385 |     }
  386 |     const path=(await completed()).find(path=>!existing.has(path));
  387 |     const metadata=await page.evaluate(async path=>{const root=await(await navigator.storage.getDirectory()).getDirectoryHandle('glob2-recordings');return JSON.parse(await(await(await root.getFileHandle(encodeURIComponent(path+'.json'))).getFile()).text());},path);
  388 |     expect(metadata.complete).toBe(true);expect(metadata.width).toBe(1200);expect(metadata.height).toBe(900);
```