# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer-switching.spec.js >> threaded: gameplay and torus survive settings overlay switches
- Location: tests/renderer-switching.spec.js:268:3

# Error details

```
Error: no control matching popup labelled "Software"

no control matching popup labelled "Software"

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 30000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [aria-hidden]:
    - status: Starting the game…
    - generic:
      - progressbar
      - generic: 33 of 33 MB
    - combobox
  - generic "Globulation 2" [active] [ref=e3]
```

# Test source

```ts
  1   | // Screens and dialogs publish their interactive controls, keyed by the same
  2   | // stable keys the native harnesses use, with bounds in logical pixels (see
  3   | // ApplicationHost::controlsChanged and glob2Diagnostics.snapshot().controls).
  4   | // Tests drive those real controls rather than mirroring layout arithmetic.
  5   | const {expect} = require('@playwright/test');
  6   | // Layout runs inside the game's animation frame; two frames after a resize or
  7   | // rebuild the published bounds are current.
  8   | const settled = page => page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  9   | // The logical surface always fills the window at one uniform scale, so bounds
  10  | // published for a previous window size (their surface has another aspect
  11  | // ratio) are stale after a resize and must not be clicked.
  12  | function current(page, bounds) {
  13  |   const {width, height} = page.viewportSize();
  14  |   return Math.abs(width / bounds.surface.w - height / bounds.surface.h) < 0.02;
  15  | }
  16  | async function control(page, key, {timeout = 30000, enabled = true} = {}) {
  17  |   let found;
  18  |   await expect.poll(async () => {
  19  |     found = await page.evaluate(key => glob2Diagnostics.snapshot().controls[key] || null, key);
  20  |     return Boolean(found && (!enabled || found.enabled) && current(page, found));
  21  |   }, {timeout, message: `control "${key}" is not available`}).toBe(true);
  22  |   await settled(page);
  23  |   return (await page.evaluate(key => glob2Diagnostics.snapshot().controls[key] || null, key)) || found;
  24  | }
  25  | // The first control whose key matches and whose text is the label shown.
  26  | exports.clickByLabel = async (page, keyPattern, label, options = {}) => {
  27  |   const source = keyPattern.source;
  28  |   let key;
  29  |   await expect.poll(async () => {
  30  |     key = await page.evaluate(({source, label}) => {
  31  |       const pattern = new RegExp(source);
  32  |       for (const [key, value] of Object.entries(glob2Diagnostics.snapshot().controls))
  33  |         if (pattern.test(key) && value.label.toLowerCase() === label.toLowerCase()) return key;
  34  |       return null;
  35  |     }, {source, label});
  36  |     return Boolean(key);
> 37  |   }, {timeout: options.timeout || 30000, message: `no control matching ${source} labelled "${label}"`}).toBe(true);
      |                                                                                                         ^ Error: no control matching popup labelled "Software"
  38  |   return exports.clickControl(page, key, options);
  39  | };
  40  | // Logical → CSS pixels: the canvas fills the window at the logical surface size,
  41  | // scaled by any interface scale setting.
  42  | function css(page, bounds, point) {
  43  |   const {width, height} = page.viewportSize();
  44  |   const sx = width / bounds.surface.w, sy = height / bounds.surface.h;
  45  |   return {x: point.x * sx, y: point.y * sy};
  46  | }
  47  | function center(page, bounds) {
  48  |   return css(page, bounds, {x: bounds.x + bounds.w / 2, y: bounds.y + bounds.h / 2});
  49  | }
  50  | exports.control = control;
  51  | // The control's bounds in CSS pixels, for pixel checks near a known control.
  52  | exports.controlBox = async (page, key, options) => {
  53  |   const requested = {enabled: false, ...options};
  54  |   const bounds = options?.fullyVisible
  55  |     ? await controlOnScreen(page, key, requested) : await control(page, key, requested);
  56  |   const origin = css(page, bounds, {x: bounds.x, y: bounds.y});
  57  |   const corner = css(page, bounds, {x: bounds.x + bounds.w, y: bounds.y + bounds.h});
  58  |   return {x: origin.x, y: origin.y, width: corner.x - origin.x, height: corner.y - origin.y};
  59  | };
  60  | // The panel of the host owning a control, in CSS pixels.
  61  | exports.rootBox = async (page, key) => {
  62  |   const bounds = await control(page, key, {enabled: false});
  63  |   const origin = css(page, bounds, {x: bounds.root.x, y: bounds.root.y});
  64  |   const corner = css(page, bounds, {x: bounds.root.x + bounds.root.w, y: bounds.root.y + bounds.root.h});
  65  |   return {x: origin.x, y: origin.y, width: corner.x - origin.x, height: corner.y - origin.y};
  66  | };
  67  | // Scroll regions publish every row and card, including ones scrolled out of
  68  | // the window; wheel over the owning panel until the control is on screen.
  69  | // A control's "visible" rect is what its scroll regions leave on screen.
  70  | // Game frames are scheduled by the host, not by requestAnimationFrame, so a
  71  | // scroll shows up in the published bounds only after the next game frame.
  72  | const same = (a, b) => a.x === b.x && a.y === b.y && a.w === b.w && a.h === b.h;
  73  | const shown = bounds => bounds.visible && bounds.visible.w >= Math.min(bounds.w, 8) && bounds.visible.h >= Math.min(bounds.h, 8);
  74  | async function controlOnScreen(page, key, options) {
  75  |   let bounds = await control(page, key, options);
  76  |   // Clicking needs only an exposed hit area; rendered-text checks need the
  77  |   // complete control, including glyphs below a scroll-region clipping edge.
  78  |   const exposed = options?.fullyVisible
  79  |     ? b => b.visible && b.visible.w >= b.w && b.visible.h >= b.h : shown;
  80  |   for (let attempt = 0; attempt < 60; ++attempt) {
  81  |     if (exposed(bounds)) {
  82  |       // Wait until the bounds hold still before clicking.
  83  |       await page.waitForTimeout(150);
  84  |       const again = await control(page, key, options);
  85  |       if (same(again, bounds) && same(again.visible, bounds.visible)) return bounds;
  86  |       bounds = again;
  87  |       continue;
  88  |     }
  89  |     const root = css(page, bounds, {x: bounds.root.x + bounds.root.w / 2, y: bounds.root.y + bounds.root.h / 2});
  90  |     await page.mouse.move(root.x, root.y);
  91  |     const distance = bounds.y + bounds.h / 2 - (bounds.root.y + bounds.root.h / 2);
  92  |     // SDL's browser wheel converts 100 CSS pixels into one scroll step. A
  93  |     // single notch moves only about one row, so use a bounded multi-notch
  94  |     // gesture for distant controls and re-read the real layout after each.
  95  |     const delta = Math.max(120, Math.min(600, bounds.root.h * 0.75, Math.abs(distance) * 3));
  96  |     await page.mouse.wheel(0, (Math.sign(distance) || 1) * delta);
  97  |     await page.waitForTimeout(150);
  98  |     bounds = await control(page, key, options);
  99  |   }
  100 |   throw new Error(`control "${key}" cannot be scrolled into view`);
  101 | }
  102 | // Click the on-screen part of the control.
  103 | function visibleCenter(page, bounds) {
  104 |   const v = shown(bounds) ? bounds.visible : bounds;
  105 |   return css(page, bounds, {x: v.x + v.w / 2, y: v.y + v.h / 2});
  106 | }
  107 | // Input is consumed at the game's next host frame; give that frame a moment
  108 | // to run so a test's next step (a resize, say) cannot overtake the click. A
  109 | // test that holds the loader pauses frames, so this never blocks for long.
  110 | async function consumed(page) {
  111 |   const loop = () => page.evaluate(() => glob2Diagnostics.snapshot().loop);
  112 |   const before = await loop();
  113 |   const deadline = Date.now() + 500;
  114 |   while (Date.now() < deadline) {
  115 |     if ((await loop()) > before) return;
  116 |     await page.waitForTimeout(20);
  117 |   }
  118 | }
  119 | exports.consumed = consumed;
  120 | exports.clickControl = async (page, key, options = {}) => {
  121 |   const bounds = await controlOnScreen(page, key, options);
  122 |   await page.locator('#canvas').click({position: visibleCenter(page, bounds), delay: 80, ...(options.click || {})});
  123 |   await consumed(page);
  124 | };
  125 | exports.tapControl = async (page, key, options = {}) => {
  126 |   const bounds = await control(page, key, options);
  127 |   const at = center(page, bounds);
  128 |   await page.touchscreen.tap(at.x, at.y);
  129 |   await consumed(page);
  130 | };
  131 | // List rows are published as "<list>/<index>" with the text they show.
  132 | exports.clickListRow = async (page, list, match, options = {}) => {
  133 |   let key;
  134 |   await expect.poll(async () => {
  135 |     const rows = await page.evaluate(list => {
  136 |       const controls = glob2Diagnostics.snapshot().controls;
  137 |       return Object.entries(controls).filter(([key]) => key.startsWith(list + '/')).map(([key, value]) => ({key, label: value.label}));
```