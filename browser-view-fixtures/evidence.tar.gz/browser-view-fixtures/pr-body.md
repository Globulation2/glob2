The initial small-viewport fixture waits for the main menu even when first run correctly asks for a hand preference. Complete that real choice before continuing.

The Torus switching fixture also assumes automatic restoration after Software. Both native Torus drawing paths reset an unsupported view, and the native switching harness explicitly activates it again. Check flat mode after returning to Programmable GL, activate through G and retain both off/on toggle, session ownership and progress checks. No production changes.

Validation: both serial/threaded Torus cases pass;21 viewport cases pass acrossChromium,Firefox andWebKit, with3 existing capability skips. [Original failures, corrected screenshots, runtime/source provenance and exact commands](https://github.com/Globulation2/glob2/tree/evidence/master-ci-recovery-1198/browser-view-fixtures).
