from pathlib import Path
import subprocess,shlex,json
b=Path('artifacts/ci-recovery/pause-clock-order');baseline=subprocess.check_output(['git','show','HEAD:src/game/GameSpeedTest.cpp'],text=True);fixed=Path('src/game/GameSpeedTest.cpp').read_text()
compile_cmd=shlex.split(next(l for l in Path('artifacts/ci-recovery/release-engine-build.log').read_text().splitlines() if l.startswith('g++ -o build/ci-recovery-release/test/engine-src_game_GameSpeedTest.o -c ')))
link_cmd=shlex.split(next(l for l in Path('artifacts/ci-recovery/torus-world-admission/build.log').read_text().splitlines() if l.startswith('g++ -o build/ci-recovery-release/test/glob2-engine-tests ')))
for name,source in [('baseline',baseline),('fixed',fixed)]:
 source=source.replace('            REQUIRE(timer.id);','            REQUIRE(timer.id);\n            SDL_Delay(300); // Inject scheduler delay after timer creation.',1);p=b/(name+'.cpp');p.write_text(source);program=b/name;(program/'test').mkdir(parents=True,exist_ok=True)
 c=list(compile_cmd);c[2]=str(b/(name+'.o'));c[-1]=str(p)
 with (b/(name+'-compile.log')).open('w') as f:subprocess.run(c,stdout=f,stderr=subprocess.STDOUT,check=True)
 c=list(link_cmd);c[2]=str(program/'test/glob2-engine-tests');c=[str(b/(name+'.o')) if a=='build/ci-recovery-release/test/engine-src_game_GameSpeedTest.o' else a for a in c];(b/(name+'-link.json')).write_text(json.dumps(c,indent=2)+'\n')
 with (b/(name+'-link.log')).open('w') as f:subprocess.run(c,stdout=f,stderr=subprocess.STDOUT,check=True)
 (program/'shaders').symlink_to(Path('build/ci-recovery-release/shaders').resolve(),target_is_directory=True)
